function _aws_cdk_aws_iotevents_alpha_ActionBindOptions(p) {
}
function _aws_cdk_aws_iotevents_alpha_IAction(p) {
}
function _aws_cdk_aws_iotevents_alpha_ActionConfig(p) {
}
function _aws_cdk_aws_iotevents_alpha_IDetectorModel(p) {
}
function _aws_cdk_aws_iotevents_alpha_EventEvaluation(p) {
}
function _aws_cdk_aws_iotevents_alpha_DetectorModelProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.initialState))
            _aws_cdk_aws_iotevents_alpha_State(p.initialState);
        if (!visitedObjects.has(p.evaluationMethod))
            _aws_cdk_aws_iotevents_alpha_EventEvaluation(p.evaluationMethod);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_iotevents_alpha_DetectorModel(p) {
}
function _aws_cdk_aws_iotevents_alpha_Event(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.actions != null)
            for (const o of p.actions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_iotevents_alpha_IAction(o);
        if (!visitedObjects.has(p.condition))
            _aws_cdk_aws_iotevents_alpha_Expression(p.condition);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_iotevents_alpha_Expression(p) {
}
function _aws_cdk_aws_iotevents_alpha_IInput(p) {
}
function _aws_cdk_aws_iotevents_alpha_InputProps(p) {
}
function _aws_cdk_aws_iotevents_alpha_Input(p) {
}
function _aws_cdk_aws_iotevents_alpha_TransitionOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.when))
            _aws_cdk_aws_iotevents_alpha_Expression(p.when);
        if (p.executing != null)
            for (const o of p.executing)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_iotevents_alpha_IAction(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_iotevents_alpha_StateProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.onEnter != null)
            for (const o of p.onEnter)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_iotevents_alpha_Event(o);
        if (p.onExit != null)
            for (const o of p.onExit)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_iotevents_alpha_Event(o);
        if (p.onInput != null)
            for (const o of p.onInput)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_iotevents_alpha_Event(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_iotevents_alpha_State(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_iotevents_alpha_ActionBindOptions, _aws_cdk_aws_iotevents_alpha_IAction, _aws_cdk_aws_iotevents_alpha_ActionConfig, _aws_cdk_aws_iotevents_alpha_IDetectorModel, _aws_cdk_aws_iotevents_alpha_EventEvaluation, _aws_cdk_aws_iotevents_alpha_DetectorModelProps, _aws_cdk_aws_iotevents_alpha_DetectorModel, _aws_cdk_aws_iotevents_alpha_Event, _aws_cdk_aws_iotevents_alpha_Expression, _aws_cdk_aws_iotevents_alpha_IInput, _aws_cdk_aws_iotevents_alpha_InputProps, _aws_cdk_aws_iotevents_alpha_Input, _aws_cdk_aws_iotevents_alpha_TransitionOptions, _aws_cdk_aws_iotevents_alpha_StateProps, _aws_cdk_aws_iotevents_alpha_State };
