import type * as iotevents from '@aws-cdk/aws-iotevents-alpha';
import type { Construct } from 'constructs';
/**
 * The action to delete an existing timer.
 */
export declare class ClearTimerAction implements iotevents.IAction {
    private readonly timerName;
    /**
     * @param timerName the name of the timer
     */
    constructor(timerName: string);
    /**
     * @internal
     */
    _bind(_scope: Construct, _options: iotevents.ActionBindOptions): iotevents.ActionConfig;
}
