import type * as iotevents from '@aws-cdk/aws-iotevents-alpha';
import type { Construct } from 'constructs';
/**
 * The action to create a variable with a specified value.
 */
export declare class SetVariableAction implements iotevents.IAction {
    private readonly variableName;
    private readonly value;
    /**
     * @param variableName the name of the variable
     * @param value the new value of the variable
     */
    constructor(variableName: string, value: iotevents.Expression);
    /**
     * @internal
     */
    _bind(_scope: Construct, _options: iotevents.ActionBindOptions): iotevents.ActionConfig;
}
