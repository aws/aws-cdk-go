import type * as iotevents from '@aws-cdk/aws-iotevents-alpha';
import type * as lambda from 'aws-cdk-lib/aws-lambda';
import type { Construct } from 'constructs';
/**
 * The action to write the data to an AWS Lambda function.
 */
export declare class LambdaInvokeAction implements iotevents.IAction {
    private readonly func;
    /**
     * @param func the AWS Lambda function to be invoked by this action
     */
    constructor(func: lambda.IFunction);
    /**
     * @internal
     */
    _bind(_scope: Construct, options: iotevents.ActionBindOptions): iotevents.ActionConfig;
}
