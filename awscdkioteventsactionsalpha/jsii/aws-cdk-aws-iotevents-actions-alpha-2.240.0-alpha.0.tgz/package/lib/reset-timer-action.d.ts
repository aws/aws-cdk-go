import type * as iotevents from '@aws-cdk/aws-iotevents-alpha';
import type { Construct } from 'constructs';
/**
 * The action to reset an existing timer.
 */
export declare class ResetTimerAction implements iotevents.IAction {
    private readonly timerName;
    /**
     * @param timerName the name of the timer
     */
    constructor(timerName: string);
    /**
     * @internal
     */
    _bind(_scope: Construct, _options: iotevents.ActionBindOptions): iotevents.ActionConfig;
}
