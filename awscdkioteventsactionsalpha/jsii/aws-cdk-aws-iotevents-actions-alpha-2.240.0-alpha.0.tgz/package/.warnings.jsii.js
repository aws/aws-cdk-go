function _aws_cdk_aws_iotevents_actions_alpha_ClearTimerAction(p) {
}
function _aws_cdk_aws_iotevents_actions_alpha_SetVariableAction(p) {
}
function _aws_cdk_aws_iotevents_actions_alpha_LambdaInvokeAction(p) {
}
function _aws_cdk_aws_iotevents_actions_alpha_ResetTimerAction(p) {
}
function _aws_cdk_aws_iotevents_actions_alpha_SetTimerAction(p) {
}
function _aws_cdk_aws_iotevents_actions_alpha_TimerDuration(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_iotevents_actions_alpha_ClearTimerAction, _aws_cdk_aws_iotevents_actions_alpha_SetVariableAction, _aws_cdk_aws_iotevents_actions_alpha_LambdaInvokeAction, _aws_cdk_aws_iotevents_actions_alpha_ResetTimerAction, _aws_cdk_aws_iotevents_actions_alpha_SetTimerAction, _aws_cdk_aws_iotevents_actions_alpha_TimerDuration };
