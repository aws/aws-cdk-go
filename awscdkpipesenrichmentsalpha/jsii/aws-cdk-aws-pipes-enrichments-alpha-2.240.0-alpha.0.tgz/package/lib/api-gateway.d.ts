import type { EnrichmentParametersConfig, IEnrichment, IPipe, InputTransformation } from '@aws-cdk/aws-pipes-alpha';
import type { IRestApi } from 'aws-cdk-lib/aws-apigateway';
import type { IRole } from 'aws-cdk-lib/aws-iam';
/**
 * Properties for a ApiGatewayEnrichment
 */
export interface ApiGatewayEnrichmentProps {
    /**
     * The input transformation for the enrichment
     * @see https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-pipes-input-transformation.html
     * @default - None
     */
    readonly inputTransformation?: InputTransformation;
    /**
     * The method for API Gateway resource.
     *
     * @default '*' - ANY
     */
    readonly method?: string;
    /**
     * The path for the API Gateway resource.
     *
     * @default '/'
     */
    readonly path?: string;
    /**
     * The deployment stage for the API Gateway resource.
     *
     * @default - the value of `deploymentStage.stageName` of target API Gateway resource.
     */
    readonly stage?: string;
    /**
     * The headers that need to be sent as part of request invoking the API Gateway REST API.
     *
     * @default - none
     */
    readonly headerParameters?: Record<string, string>;
    /**
     * The path parameter values used to populate the API Gateway REST API path wildcards ("*").
     *
     * @default - none
     */
    readonly pathParameterValues?: string[];
    /**
     * The query string keys/values that need to be sent as part of request invoking the EventBridge API destination.
     *
     * @default - none
     */
    readonly queryStringParameters?: Record<string, string>;
}
/**
 * An API Gateway enrichment for a pipe
 */
export declare class ApiGatewayEnrichment implements IEnrichment {
    private readonly restApi;
    readonly enrichmentArn: string;
    private readonly inputTransformation?;
    private readonly headerParameters?;
    private readonly pathParameterValues?;
    private readonly queryStringParameters?;
    constructor(restApi: IRestApi, props?: ApiGatewayEnrichmentProps);
    bind(pipe: IPipe): EnrichmentParametersConfig;
    grantInvoke(pipeRole: IRole): void;
}
