import type { EnrichmentParametersConfig, IEnrichment, IPipe, InputTransformation } from '@aws-cdk/aws-pipes-alpha';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { IStateMachine } from 'aws-cdk-lib/aws-stepfunctions';
/**
 * Properties for a StepFunctionsEnrichment
 */
export interface StepFunctionsEnrichmentProps {
    /**
     * The input transformation for the enrichment
     * @see https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-pipes-input-transformation.html
     * @default - None
     */
    readonly inputTransformation?: InputTransformation;
}
/**
 * A StepFunctions enrichment for a pipe
 */
export declare class StepFunctionsEnrichment implements IEnrichment {
    private readonly stateMachine;
    readonly enrichmentArn: string;
    private readonly inputTransformation?;
    constructor(stateMachine: IStateMachine, props?: StepFunctionsEnrichmentProps);
    bind(pipe: IPipe): EnrichmentParametersConfig;
    grantInvoke(pipeRole: IRole): void;
}
