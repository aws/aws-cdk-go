import type { EnrichmentParametersConfig, IEnrichment, IPipe, InputTransformation } from '@aws-cdk/aws-pipes-alpha';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { IFunction } from 'aws-cdk-lib/aws-lambda';
/**
 * Properties for a LambdaEnrichment
 */
export interface LambdaEnrichmentProps {
    /**
     * The input transformation for the enrichment
     * @see https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-pipes-input-transformation.html
     * @default - None
     */
    readonly inputTransformation?: InputTransformation;
}
/**
 * A Lambda enrichment for a pipe
 */
export declare class LambdaEnrichment implements IEnrichment {
    private readonly lambda;
    readonly enrichmentArn: string;
    private readonly inputTransformation?;
    constructor(lambda: IFunction, props?: LambdaEnrichmentProps);
    bind(pipe: IPipe): EnrichmentParametersConfig;
    grantInvoke(pipeRole: IRole): void;
}
