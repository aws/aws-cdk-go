import type { EnrichmentParametersConfig, IEnrichment, IPipe, InputTransformation } from '@aws-cdk/aws-pipes-alpha';
import type { IApiDestination } from 'aws-cdk-lib/aws-events';
import type { IRole } from 'aws-cdk-lib/aws-iam';
/**
 * Properties for a ApiDestinationEnrichment
 */
export interface ApiDestinationEnrichmentProps {
    /**
     * The input transformation for the enrichment
     * @see https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-pipes-input-transformation.html
     * @default - None
     */
    readonly inputTransformation?: InputTransformation;
    /**
     * The headers that need to be sent as part of request invoking the EventBridge ApiDestination.
     *
     * @default - none
     */
    readonly headerParameters?: Record<string, string>;
    /**
     * The path parameter values used to populate the EventBridge API destination path wildcards ("*").
     *
     * @default - none
     */
    readonly pathParameterValues?: string[];
    /**
     * The query string keys/values that need to be sent as part of request invoking the EventBridge API destination.
     *
     * @default - none
     */
    readonly queryStringParameters?: Record<string, string>;
}
/**
 * An API Destination enrichment for a pipe
 */
export declare class ApiDestinationEnrichment implements IEnrichment {
    private readonly destination;
    readonly enrichmentArn: string;
    private readonly inputTransformation?;
    private readonly headerParameters?;
    private readonly pathParameterValues?;
    private readonly queryStringParameters?;
    constructor(destination: IApiDestination, props?: ApiDestinationEnrichmentProps);
    bind(pipe: IPipe): EnrichmentParametersConfig;
    grantInvoke(pipeRole: IRole): void;
}
