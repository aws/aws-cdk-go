function _aws_cdk_aws_pipes_enrichments_alpha_ApiDestinationEnrichmentProps(p) {
}
function _aws_cdk_aws_pipes_enrichments_alpha_ApiDestinationEnrichment(p) {
}
function _aws_cdk_aws_pipes_enrichments_alpha_ApiGatewayEnrichmentProps(p) {
}
function _aws_cdk_aws_pipes_enrichments_alpha_ApiGatewayEnrichment(p) {
}
function _aws_cdk_aws_pipes_enrichments_alpha_LambdaEnrichmentProps(p) {
}
function _aws_cdk_aws_pipes_enrichments_alpha_LambdaEnrichment(p) {
}
function _aws_cdk_aws_pipes_enrichments_alpha_StepFunctionsEnrichmentProps(p) {
}
function _aws_cdk_aws_pipes_enrichments_alpha_StepFunctionsEnrichment(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_pipes_enrichments_alpha_ApiDestinationEnrichmentProps, _aws_cdk_aws_pipes_enrichments_alpha_ApiDestinationEnrichment, _aws_cdk_aws_pipes_enrichments_alpha_ApiGatewayEnrichmentProps, _aws_cdk_aws_pipes_enrichments_alpha_ApiGatewayEnrichment, _aws_cdk_aws_pipes_enrichments_alpha_LambdaEnrichmentProps, _aws_cdk_aws_pipes_enrichments_alpha_LambdaEnrichment, _aws_cdk_aws_pipes_enrichments_alpha_StepFunctionsEnrichmentProps, _aws_cdk_aws_pipes_enrichments_alpha_StepFunctionsEnrichment };
