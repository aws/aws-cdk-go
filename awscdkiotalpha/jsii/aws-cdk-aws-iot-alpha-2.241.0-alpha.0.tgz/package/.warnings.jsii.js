function _aws_cdk_aws_iot_alpha_IAction(p) {
}
function _aws_cdk_aws_iot_alpha_ActionConfig(p) {
}
function _aws_cdk_aws_iot_alpha_IAccountAuditConfiguration(p) {
}
function _aws_cdk_aws_iot_alpha_CheckConfiguration(p) {
}
function _aws_cdk_aws_iot_alpha_AccountAuditConfigurationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.checkConfiguration))
            _aws_cdk_aws_iot_alpha_CheckConfiguration(p.checkConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_iot_alpha_AccountAuditConfiguration(p) {
}
function _aws_cdk_aws_iot_alpha_IotSqlConfig(p) {
}
function _aws_cdk_aws_iot_alpha_IotSql(p) {
}
function _aws_cdk_aws_iot_alpha_ILogging(p) {
}
function _aws_cdk_aws_iot_alpha_LogLevel(p) {
}
function _aws_cdk_aws_iot_alpha_LoggingProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.logLevel))
            _aws_cdk_aws_iot_alpha_LogLevel(p.logLevel);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_iot_alpha_Logging(p) {
}
function _aws_cdk_aws_iot_alpha_IScheduledAudit(p) {
}
function _aws_cdk_aws_iot_alpha_ScheduledAuditAttributes(p) {
}
function _aws_cdk_aws_iot_alpha_AuditCheck(p) {
}
function _aws_cdk_aws_iot_alpha_DayOfWeek(p) {
}
function _aws_cdk_aws_iot_alpha_DayOfMonth(p) {
}
function _aws_cdk_aws_iot_alpha_Frequency(p) {
}
function _aws_cdk_aws_iot_alpha_ScheduledAuditProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.accountAuditConfiguration))
            _aws_cdk_aws_iot_alpha_IAccountAuditConfiguration(p.accountAuditConfiguration);
        if (p.auditChecks != null)
            for (const o of p.auditChecks)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_iot_alpha_AuditCheck(o);
        if (!visitedObjects.has(p.frequency))
            _aws_cdk_aws_iot_alpha_Frequency(p.frequency);
        if (!visitedObjects.has(p.dayOfMonth))
            _aws_cdk_aws_iot_alpha_DayOfMonth(p.dayOfMonth);
        if (!visitedObjects.has(p.dayOfWeek))
            _aws_cdk_aws_iot_alpha_DayOfWeek(p.dayOfWeek);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_iot_alpha_ScheduledAudit(p) {
}
function _aws_cdk_aws_iot_alpha_ITopicRule(p) {
}
function _aws_cdk_aws_iot_alpha_TopicRuleProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sql))
            _aws_cdk_aws_iot_alpha_IotSql(p.sql);
        if (p.actions != null)
            for (const o of p.actions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_iot_alpha_IAction(o);
        if (!visitedObjects.has(p.errorAction))
            _aws_cdk_aws_iot_alpha_IAction(p.errorAction);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_iot_alpha_TopicRule(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_iot_alpha_IAction, _aws_cdk_aws_iot_alpha_ActionConfig, _aws_cdk_aws_iot_alpha_IAccountAuditConfiguration, _aws_cdk_aws_iot_alpha_CheckConfiguration, _aws_cdk_aws_iot_alpha_AccountAuditConfigurationProps, _aws_cdk_aws_iot_alpha_AccountAuditConfiguration, _aws_cdk_aws_iot_alpha_IotSqlConfig, _aws_cdk_aws_iot_alpha_IotSql, _aws_cdk_aws_iot_alpha_ILogging, _aws_cdk_aws_iot_alpha_LogLevel, _aws_cdk_aws_iot_alpha_LoggingProps, _aws_cdk_aws_iot_alpha_Logging, _aws_cdk_aws_iot_alpha_IScheduledAudit, _aws_cdk_aws_iot_alpha_ScheduledAuditAttributes, _aws_cdk_aws_iot_alpha_AuditCheck, _aws_cdk_aws_iot_alpha_DayOfWeek, _aws_cdk_aws_iot_alpha_DayOfMonth, _aws_cdk_aws_iot_alpha_Frequency, _aws_cdk_aws_iot_alpha_ScheduledAuditProps, _aws_cdk_aws_iot_alpha_ScheduledAudit, _aws_cdk_aws_iot_alpha_ITopicRule, _aws_cdk_aws_iot_alpha_TopicRuleProps, _aws_cdk_aws_iot_alpha_TopicRule };
