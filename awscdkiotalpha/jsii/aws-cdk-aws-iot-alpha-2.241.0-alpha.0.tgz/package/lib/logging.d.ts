import type { IResource } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
/**
 * Represents AWS IoT Logging
 */
export interface ILogging extends IResource {
    /**
     * The log ID
     * @attribute
     */
    readonly logId: string;
}
/**
 * The log level for the AWS IoT Logging
 */
export declare enum LogLevel {
    /**
     * Any error that causes an operation to fail
     *
     * Logs include ERROR information only
     */
    ERROR = "ERROR",
    /**
     * Anything that can potentially cause inconsistencies in the system, but might not cause the operation to fail
     *
     * Logs include ERROR and WARN information
     */
    WARN = "WARN",
    /**
     * High-level information about the flow of things
     *
     * Logs include INFO, ERROR, and WARN information
     */
    INFO = "INFO",
    /**
     * Information that might be helpful when debugging a problem
     *
     * Logs include DEBUG, INFO, ERROR, and WARN information
     */
    DEBUG = "DEBUG",
    /**
     * All logging is disabled
     */
    DISABLED = "DISABLED"
}
/**
 * Properties for defining AWS IoT Logging
 */
export interface LoggingProps {
    /**
     * The log level for the AWS IoT Logging
     *
     * @default LogLevel.ERROR
     */
    readonly logLevel?: LogLevel;
}
/**
 * Defines AWS IoT Logging
 */
export declare class Logging extends Resource implements ILogging {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing AWS IoT Logging
     *
     * @param scope The parent creating construct (usually `this`)
     * @param id The construct's name
     * @param logId AWS IoT Logging ID
     */
    static fromLogId(scope: Construct, id: string, logId: string): ILogging;
    /**
     * The logging ID
     * @attribute
     */
    readonly logId: string;
    constructor(scope: Construct, id: string, props?: LoggingProps);
}
