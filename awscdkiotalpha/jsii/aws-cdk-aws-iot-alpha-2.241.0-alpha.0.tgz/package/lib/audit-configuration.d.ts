import type * as sns from 'aws-cdk-lib/aws-sns';
import type { IResource, Duration } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
/**
 * Represents AWS IoT Audit Configuration
 */
export interface IAccountAuditConfiguration extends IResource {
    /**
     * The account ID
     * @attribute
     */
    readonly accountId: string;
}
/**
 * The types of audit checks
 *
 * @see https://docs.aws.amazon.com/iot-device-defender/latest/devguide/device-defender-audit-checks.html
 */
export interface CheckConfiguration {
    /**
     * Checks the permissiveness of an authenticated Amazon Cognito identity pool role.
     *
     * For this check, AWS IoT Device Defender audits all Amazon Cognito identity pools that have been used to connect to the AWS IoT message broker
     * during the 31 days before the audit is performed.
     *
     * @default true
     */
    readonly authenticatedCognitoRoleOverlyPermissiveCheck?: boolean;
    /**
     * Checks if a CA certificate is expiring.
     *
     * This check applies to CA certificates expiring within 30 days or that have expired.
     *
     * @default true
     */
    readonly caCertificateExpiringCheck?: boolean;
    /**
     * Checks the quality of the CA certificate key.
     *
     * The quality checks if the key is in a valid format, not expired, and if the key meets a minimum required size.
     *
     * This check applies to CA certificates that are ACTIVE or PENDING_TRANSFER.
     *
     * @default true
     */
    readonly caCertificateKeyQualityCheck?: boolean;
    /**
     * Checks if multiple devices connect using the same client ID.
     *
     * @default true
     */
    readonly conflictingClientIdsCheck?: boolean;
    /**
     * Checks when a device certificate has been active for a number of days greater than or equal to the number you specify.
     *
     * @default true
     */
    readonly deviceCertificateAgeCheck?: boolean;
    /**
     * The duration used to check if a device certificate has been active
     * for a number of days greater than or equal to the number you specify.
     *
     * Valid values range from 30 days (minimum) to 3650 days (10 years, maximum).
     *
     * You cannot specify a value for this check if `deviceCertificateAgeCheck` is set to `false`.
     *
     * @default - 365 days
     */
    readonly deviceCertificateAgeCheckDuration?: Duration;
    /**
     * Checks if a device certificate is expiring.
     *
     * This check applies to device certificates expiring within 30 days or that have expired.
     *
     * @default true
     */
    readonly deviceCertificateExpiringCheck?: boolean;
    /**
     * Checks the quality of the device certificate key.
     *
     * The quality checks if the key is in a valid format, not expired, signed by a registered certificate authority,
     * and if the key meets a minimum required size.
     *
     * @default true
     */
    readonly deviceCertificateKeyQualityCheck?: boolean;
    /**
     * Checks if multiple concurrent connections use the same X.509 certificate to authenticate with AWS IoT.
     *
     * @default true
     */
    readonly deviceCertificateSharedCheck?: boolean;
    /**
     * Checks if device certificates are still active despite being revoked by an intermediate CA.
     *
     * @default true
     */
    readonly intermediateCaRevokedForActiveDeviceCertificatesCheck?: boolean;
    /**
     * Checks the permissiveness of a policy attached to an authenticated Amazon Cognito identity pool role.
     *
     * @default true
     */
    readonly iotPolicyOverlyPermissiveCheck?: boolean;
    /**
     * Checks if an AWS IoT policy is potentially misconfigured.
     *
     * Misconfigured policies, including overly permissive policies, can cause security incidents like allowing devices access to unintended resources.
     *
     * This check is a warning for you to make sure that only intended actions are allowed before updating the policy.
     *
     * @default true
     */
    readonly ioTPolicyPotentialMisConfigurationCheck?: boolean;
    /**
     * Checks if a role alias has access to services that haven't been used for the AWS IoT device in the last year.
     *
     * @default true
     */
    readonly iotRoleAliasAllowsAccessToUnusedServicesCheck?: boolean;
    /**
     * Checks if the temporary credentials provided by AWS IoT role aliases are overly permissive.
     *
     * @default true
     */
    readonly iotRoleAliasOverlyPermissiveCheck?: boolean;
    /**
     * Checks if AWS IoT logs are disabled.
     *
     * @default true
     */
    readonly loggingDisabledCheck?: boolean;
    /**
     * Checks if a revoked CA certificate is still active.
     *
     * @default true
     */
    readonly revokedCaCertificateStillActiveCheck?: boolean;
    /**
     * Checks if a revoked device certificate is still active.
     *
     * @default true
     */
    readonly revokedDeviceCertificateStillActiveCheck?: boolean;
    /**
     * Checks if policy attached to an unauthenticated Amazon Cognito identity pool role is too permissive.
     *
     * @default true
     */
    readonly unauthenticatedCognitoRoleOverlyPermissiveCheck?: boolean;
}
/**
 * Properties for defining AWS IoT Audit Configuration
 */
export interface AccountAuditConfigurationProps {
    /**
     * The target SNS topic to which audit notifications are sent.
     *
     * @default - no notifications are sent
     */
    readonly targetTopic?: sns.ITopic;
    /**
     * Specifies which audit checks are enabled and disabled for this account.
     *
     * @default - all checks are enabled
     */
    readonly checkConfiguration?: CheckConfiguration;
}
/**
 * Defines AWS IoT Audit Configuration
 */
export declare class AccountAuditConfiguration extends Resource implements IAccountAuditConfiguration {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing AWS IoT Audit Configuration
     *
     * @param scope The parent creating construct (usually `this`)
     * @param id The construct's name
     * @param accountId The account ID
     */
    static fromAccountId(scope: Construct, id: string, accountId: string): IAccountAuditConfiguration;
    /**
     * The account ID
     * @attribute
     */
    readonly accountId: string;
    constructor(scope: Construct, id: string, props?: AccountAuditConfigurationProps);
    /**
     * Render the audit notification target configurations
     */
    private renderAuditNotificationTargetConfigurations;
    /**
     * Render the audit check configurations
     */
    private renderAuditCheckConfigurations;
    /**
     * Render the audit check configuration
     */
    private renderAuditCheckConfiguration;
}
