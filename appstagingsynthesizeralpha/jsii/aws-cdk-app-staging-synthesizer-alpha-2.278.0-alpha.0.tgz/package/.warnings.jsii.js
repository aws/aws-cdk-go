const VALIDATORS = { _aws_cdk_app_staging_synthesizer_alpha_DefaultStagingStackOptions: function _aws_cdk_app_staging_synthesizer_alpha_DefaultStagingStackOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.stagingBucketEncryption))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_s3_BucketEncryption(p.stagingBucketEncryption);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.deployTimeFileAssetLifetime))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.deployTimeFileAssetLifetime);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_app_staging_synthesizer_alpha_DefaultStagingStackProps: function _aws_cdk_app_staging_synthesizer_alpha_DefaultStagingStackProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.stagingBucketEncryption))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_s3_BucketEncryption(p.stagingBucketEncryption);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.deployTimeFileAssetLifetime))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.deployTimeFileAssetLifetime);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.env))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Environment(p.env);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.permissionsBoundary))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_PermissionsBoundary(p.permissionsBoundary);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.propertyInjectors != null)
                for (const o of p.propertyInjectors)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_IPropertyInjector(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.synthesizer))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_IStackSynthesizer(p.synthesizer);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_app_staging_synthesizer_alpha_DefaultResourcesOptions: function _aws_cdk_app_staging_synthesizer_alpha_DefaultResourcesOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.stagingBucketEncryption))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_s3_BucketEncryption(p.stagingBucketEncryption);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.deployTimeFileAssetLifetime))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.deployTimeFileAssetLifetime);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_app_staging_synthesizer_alpha_FileStagingLocation: function _aws_cdk_app_staging_synthesizer_alpha_FileStagingLocation(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.dependencyStack))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Stack(p.dependencyStack);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_app_staging_synthesizer_alpha_ImageStagingLocation: function _aws_cdk_app_staging_synthesizer_alpha_ImageStagingLocation(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.dependencyStack))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Stack(p.dependencyStack);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
