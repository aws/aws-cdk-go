import { StringSpecializer } from 'aws-cdk-lib/core/lib/helpers-internal';
/**
 * Bootstrapped role specifier. These roles must exist already.
 * This class does not create new IAM Roles.
 */
export declare class BootstrapRole {
    private readonly roleArn;
    /**
     * Use the currently assumed role/credentials
     */
    static cliCredentials(): BootstrapRole;
    /**
     * Specify an existing IAM Role to assume
     */
    static fromRoleArn(arn: string): BootstrapRole;
    private static CLI_CREDS;
    private constructor();
    /**
     * Whether or not this is object was created using BootstrapRole.cliCredentials()
     */
    isCliCredentials(): boolean;
    /**
     * @internal
     */
    _arnForCloudFormation(): string | undefined;
    /**
     * @internal
     */
    _arnForCloudAssembly(): string | undefined;
    /**
     * @internal
     */
    _specialize(spec: StringSpecializer): BootstrapRole;
}
/**
 * Deployment identities are the class of roles to be assumed by the CDK
 * when deploying the App.
 */
export declare class DeploymentIdentities {
    /**
     * Use CLI credentials for all deployment identities.
     */
    static cliCredentials(): DeploymentIdentities;
    /**
     * Specify your own roles for all deployment identities. These roles
     * must already exist.
     */
    static specifyRoles(roles: BootstrapRoles): DeploymentIdentities;
    /**
     * Use the Roles that have been created by the default bootstrap stack
     */
    static defaultBootstrapRoles(options?: DefaultBootstrapRolesOptions): DeploymentIdentities;
    /**
     * CloudFormation Execution Role
     */
    readonly cloudFormationExecutionRole?: BootstrapRole;
    /**
     * Deployment Action Role
     */
    readonly deploymentRole?: BootstrapRole;
    /**
     * Lookup Role
      @default - use bootstrapped role
     */
    readonly lookupRole?: BootstrapRole;
    private constructor();
}
/**
 * Options for `DeploymentIdentities.defaultBootstrappedRoles`
 */
export interface DefaultBootstrapRolesOptions {
    /**
     * The region where the default bootstrap roles have been created
     *
     * By default, the region in which the stack is deployed is used.
     *
     * @default - the stack's current region
     */
    readonly bootstrapRegion?: string;
}
/**
 * Roles that are bootstrapped to your account.
 */
export interface BootstrapRoles {
    /**
     * CloudFormation Execution Role
     *
     * @default - use bootstrapped role
     */
    readonly cloudFormationExecutionRole?: BootstrapRole;
    /**
     * Deployment Action Role
     *
     * @default - use boostrapped role
     */
    readonly deploymentRole?: BootstrapRole;
    /**
     * Lookup Role
     *
     * @default - use bootstrapped role
     */
    readonly lookupRole?: BootstrapRole;
}
/**
 * Roles that are included in the Staging Stack
 * (for access to Staging Resources)
 */
export interface StagingRoles {
    /**
     * File Asset Publishing Role
     *
     * @default - staging stack creates a file asset publishing role
     */
    readonly fileAssetPublishingRole?: BootstrapRole;
    /**
     * Docker Asset Publishing Role
     *
     * @default - staging stack creates a docker asset publishing role
     */
    readonly dockerAssetPublishingRole?: BootstrapRole;
}
