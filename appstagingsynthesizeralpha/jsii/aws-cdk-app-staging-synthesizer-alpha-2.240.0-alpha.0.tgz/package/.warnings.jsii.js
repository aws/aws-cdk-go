function _aws_cdk_app_staging_synthesizer_alpha_UsingAppStagingSynthesizer(p) {
}
function _aws_cdk_app_staging_synthesizer_alpha_DefaultStagingStackOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.fileAssetPublishingRole))
            _aws_cdk_app_staging_synthesizer_alpha_BootstrapRole(p.fileAssetPublishingRole);
        if (!visitedObjects.has(p.imageAssetPublishingRole))
            _aws_cdk_app_staging_synthesizer_alpha_BootstrapRole(p.imageAssetPublishingRole);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_app_staging_synthesizer_alpha_DefaultStagingStackProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.fileAssetPublishingRole))
            _aws_cdk_app_staging_synthesizer_alpha_BootstrapRole(p.fileAssetPublishingRole);
        if (!visitedObjects.has(p.imageAssetPublishingRole))
            _aws_cdk_app_staging_synthesizer_alpha_BootstrapRole(p.imageAssetPublishingRole);
        if (p.propertyInjectors != null)
            for (const o of p.propertyInjectors)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_IPropertyInjector(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_app_staging_synthesizer_alpha_DefaultStagingStack(p) {
}
function _aws_cdk_app_staging_synthesizer_alpha_AppStagingSynthesizerOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.deploymentIdentities))
            _aws_cdk_app_staging_synthesizer_alpha_DeploymentIdentities(p.deploymentIdentities);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_app_staging_synthesizer_alpha_DefaultResourcesOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.deploymentIdentities))
            _aws_cdk_app_staging_synthesizer_alpha_DeploymentIdentities(p.deploymentIdentities);
        if (!visitedObjects.has(p.fileAssetPublishingRole))
            _aws_cdk_app_staging_synthesizer_alpha_BootstrapRole(p.fileAssetPublishingRole);
        if (!visitedObjects.has(p.imageAssetPublishingRole))
            _aws_cdk_app_staging_synthesizer_alpha_BootstrapRole(p.imageAssetPublishingRole);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_app_staging_synthesizer_alpha_CustomFactoryOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.factory))
            _aws_cdk_app_staging_synthesizer_alpha_IStagingResourcesFactory(p.factory);
        if (!visitedObjects.has(p.deploymentIdentities))
            _aws_cdk_app_staging_synthesizer_alpha_DeploymentIdentities(p.deploymentIdentities);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_app_staging_synthesizer_alpha_CustomResourcesOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.resources))
            _aws_cdk_app_staging_synthesizer_alpha_IStagingResources(p.resources);
        if (!visitedObjects.has(p.deploymentIdentities))
            _aws_cdk_app_staging_synthesizer_alpha_DeploymentIdentities(p.deploymentIdentities);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_app_staging_synthesizer_alpha_AppStagingSynthesizer(p) {
}
function _aws_cdk_app_staging_synthesizer_alpha_BootstrapRole(p) {
}
function _aws_cdk_app_staging_synthesizer_alpha_DeploymentIdentities(p) {
}
function _aws_cdk_app_staging_synthesizer_alpha_DefaultBootstrapRolesOptions(p) {
}
function _aws_cdk_app_staging_synthesizer_alpha_BootstrapRoles(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.cloudFormationExecutionRole))
            _aws_cdk_app_staging_synthesizer_alpha_BootstrapRole(p.cloudFormationExecutionRole);
        if (!visitedObjects.has(p.deploymentRole))
            _aws_cdk_app_staging_synthesizer_alpha_BootstrapRole(p.deploymentRole);
        if (!visitedObjects.has(p.lookupRole))
            _aws_cdk_app_staging_synthesizer_alpha_BootstrapRole(p.lookupRole);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_app_staging_synthesizer_alpha_StagingRoles(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.dockerAssetPublishingRole))
            _aws_cdk_app_staging_synthesizer_alpha_BootstrapRole(p.dockerAssetPublishingRole);
        if (!visitedObjects.has(p.fileAssetPublishingRole))
            _aws_cdk_app_staging_synthesizer_alpha_BootstrapRole(p.fileAssetPublishingRole);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_app_staging_synthesizer_alpha_FileStagingLocation(p) {
}
function _aws_cdk_app_staging_synthesizer_alpha_ImageStagingLocation(p) {
}
function _aws_cdk_app_staging_synthesizer_alpha_IStagingResources(p) {
}
function _aws_cdk_app_staging_synthesizer_alpha_IStagingResourcesFactory(p) {
}
function _aws_cdk_app_staging_synthesizer_alpha_ObtainStagingResourcesContext(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_app_staging_synthesizer_alpha_UsingAppStagingSynthesizer, _aws_cdk_app_staging_synthesizer_alpha_DefaultStagingStackOptions, _aws_cdk_app_staging_synthesizer_alpha_DefaultStagingStackProps, _aws_cdk_app_staging_synthesizer_alpha_DefaultStagingStack, _aws_cdk_app_staging_synthesizer_alpha_AppStagingSynthesizerOptions, _aws_cdk_app_staging_synthesizer_alpha_DefaultResourcesOptions, _aws_cdk_app_staging_synthesizer_alpha_CustomFactoryOptions, _aws_cdk_app_staging_synthesizer_alpha_CustomResourcesOptions, _aws_cdk_app_staging_synthesizer_alpha_AppStagingSynthesizer, _aws_cdk_app_staging_synthesizer_alpha_BootstrapRole, _aws_cdk_app_staging_synthesizer_alpha_DeploymentIdentities, _aws_cdk_app_staging_synthesizer_alpha_DefaultBootstrapRolesOptions, _aws_cdk_app_staging_synthesizer_alpha_BootstrapRoles, _aws_cdk_app_staging_synthesizer_alpha_StagingRoles, _aws_cdk_app_staging_synthesizer_alpha_FileStagingLocation, _aws_cdk_app_staging_synthesizer_alpha_ImageStagingLocation, _aws_cdk_app_staging_synthesizer_alpha_IStagingResources, _aws_cdk_app_staging_synthesizer_alpha_IStagingResourcesFactory, _aws_cdk_app_staging_synthesizer_alpha_ObtainStagingResourcesContext };
