const VALIDATORS = { _aws_cdk_aws_imagebuilder_alpha_ComponentProps: function _aws_cdk_aws_imagebuilder_alpha_ComponentProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.kmsKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_kms_IKey(p.kmsKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.supportedOsVersions != null)
                for (const o of p.supportedOsVersions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_OSVersion(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ComponentDocument: function _aws_cdk_aws_imagebuilder_alpha_ComponentDocument(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.phases != null)
                for (const o of p.phases)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ComponentDocumentPhase(o);
            if (p.constants != null)
                for (const o of Object.values(p.constants))
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ComponentConstantValue(o);
            if (p.parameters != null)
                for (const o of Object.values(p.parameters))
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ComponentDocumentParameterDefinition(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentPhase: function _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentPhase(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.steps != null)
                for (const o of p.steps)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ComponentDocumentStep(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentStep: function _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentStep(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.timeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.timeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ContainerRecipeProps: function _aws_cdk_aws_imagebuilder_alpha_ContainerRecipeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.components != null)
                for (const o of p.components)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ComponentConfiguration(o);
            if (p.instanceBlockDevices != null)
                for (const o of p.instanceBlockDevices)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_BlockDevice(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.kmsKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_kms_IKey(p.kmsKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_SSMParameterConfigurations: function _aws_cdk_aws_imagebuilder_alpha_SSMParameterConfigurations(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.parameter))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ssm_IStringParameter(p.parameter);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.dataType))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ssm_ParameterDataType(p.dataType);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_LaunchTemplateConfiguration: function _aws_cdk_aws_imagebuilder_alpha_LaunchTemplateConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.launchTemplate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ILaunchTemplate(p.launchTemplate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_FastLaunchConfiguration: function _aws_cdk_aws_imagebuilder_alpha_FastLaunchConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.launchTemplate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ILaunchTemplate(p.launchTemplate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_AmiDistribution: function _aws_cdk_aws_imagebuilder_alpha_AmiDistribution(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.amiKmsKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_kms_IKey(p.amiKmsKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.fastLaunchConfigurations != null)
                for (const o of p.fastLaunchConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_FastLaunchConfiguration(o);
            if (p.launchTemplates != null)
                for (const o of p.launchTemplates)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_LaunchTemplateConfiguration(o);
            if (p.ssmParameters != null)
                for (const o of p.ssmParameters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_SSMParameterConfigurations(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_DistributionConfigurationProps: function _aws_cdk_aws_imagebuilder_alpha_DistributionConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.amiDistributions != null)
                for (const o of p.amiDistributions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_AmiDistribution(o);
            if (p.containerDistributions != null)
                for (const o of p.containerDistributions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ContainerDistribution(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ImageProps: function _aws_cdk_aws_imagebuilder_alpha_ImageProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.deletionExecutionRole))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.deletionExecutionRole);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.executionRole))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.executionRole);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.imageScanningEcrRepository))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecr_IRepository(p.imageScanningEcrRepository);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.logGroup))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_logs_ILogGroup(p.logGroup);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.workflows != null)
                for (const o of p.workflows)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_WorkflowConfiguration(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ImagePipelineProps: function _aws_cdk_aws_imagebuilder_alpha_ImagePipelineProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.executionRole))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.executionRole);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.imageLogGroup))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_logs_ILogGroup(p.imageLogGroup);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.imagePipelineLogGroup))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_logs_ILogGroup(p.imagePipelineLogGroup);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.imageScanningEcrRepository))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecr_IRepository(p.imageScanningEcrRepository);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.schedule))
                module.exports._aws_cdk_aws_imagebuilder_alpha_ImagePipelineSchedule(p.schedule);
            if (p.workflows != null)
                for (const o of p.workflows)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_WorkflowConfiguration(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ImagePipelineSchedule: function _aws_cdk_aws_imagebuilder_alpha_ImagePipelineSchedule(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.expression))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_events_Schedule(p.expression);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ImageRecipeProps: function _aws_cdk_aws_imagebuilder_alpha_ImageRecipeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.blockDevices != null)
                for (const o of p.blockDevices)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_BlockDevice(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (p.components != null)
                for (const o of p.components)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ComponentConfiguration(o);
            if (!visitedObjects.has(p.userDataOverride))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_UserData(p.userDataOverride);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_InfrastructureConfigurationLogging: function _aws_cdk_aws_imagebuilder_alpha_InfrastructureConfigurationLogging(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.s3Bucket))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_s3_IBucket(p.s3Bucket);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_InfrastructureConfigurationProps: function _aws_cdk_aws_imagebuilder_alpha_InfrastructureConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.instanceProfile))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IInstanceProfile(p.instanceProfile);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.instanceTypes != null)
                for (const o of p.instanceTypes)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_InstanceType(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.keyPair))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_IKeyPair(p.keyPair);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.logging))
                module.exports._aws_cdk_aws_imagebuilder_alpha_InfrastructureConfigurationLogging(p.logging);
            if (!visitedObjects.has(p.notificationTopic))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_sns_ITopic(p.notificationTopic);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.subnetSelection))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(p.subnetSelection);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.vpc))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_IVpc(p.vpc);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyFilter: function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyFilter(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.ageFilter))
                module.exports._aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAgeFilter(p.ageFilter);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAgeFilter: function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAgeFilter(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.age))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.age);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAmiExclusionRules: function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAmiExclusionRules(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.lastLaunched))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.lastLaunched);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyExclusionRules: function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyExclusionRules(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.amiExclusionRules))
                module.exports._aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAmiExclusionRules(p.amiExclusionRules);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyDetail: function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyDetail(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.filter))
                module.exports._aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyFilter(p.filter);
            if (!visitedObjects.has(p.exclusionRules))
                module.exports._aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyExclusionRules(p.exclusionRules);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyProps: function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.details != null)
                for (const o of p.details)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyDetail(o);
            if (!visitedObjects.has(p.executionRole))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.executionRole);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_WorkflowProps: function _aws_cdk_aws_imagebuilder_alpha_WorkflowProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.kmsKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_kms_IKey(p.kmsKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
