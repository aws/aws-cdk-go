const VALIDATORS = { _aws_cdk_aws_imagebuilder_alpha_ComponentProps: function _aws_cdk_aws_imagebuilder_alpha_ComponentProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.supportedOsVersions != null)
                for (const o of p.supportedOsVersions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_OSVersion(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ComponentDocument: function _aws_cdk_aws_imagebuilder_alpha_ComponentDocument(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.phases != null)
                for (const o of p.phases)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ComponentDocumentPhase(o);
            if (p.constants != null)
                for (const o of Object.values(p.constants))
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ComponentConstantValue(o);
            if (p.parameters != null)
                for (const o of Object.values(p.parameters))
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ComponentDocumentParameterDefinition(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentPhase: function _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentPhase(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.steps != null)
                for (const o of p.steps)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ComponentDocumentStep(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ContainerRecipeProps: function _aws_cdk_aws_imagebuilder_alpha_ContainerRecipeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.components != null)
                for (const o of p.components)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ComponentConfiguration(o);
            if (p.instanceBlockDevices != null)
                for (const o of p.instanceBlockDevices)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_BlockDevice(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_AmiDistribution: function _aws_cdk_aws_imagebuilder_alpha_AmiDistribution(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.fastLaunchConfigurations != null)
                for (const o of p.fastLaunchConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_FastLaunchConfiguration(o);
            if (p.launchTemplates != null)
                for (const o of p.launchTemplates)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_LaunchTemplateConfiguration(o);
            if (p.ssmParameters != null)
                for (const o of p.ssmParameters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_SSMParameterConfigurations(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_DistributionConfigurationProps: function _aws_cdk_aws_imagebuilder_alpha_DistributionConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.amiDistributions != null)
                for (const o of p.amiDistributions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_AmiDistribution(o);
            if (p.containerDistributions != null)
                for (const o of p.containerDistributions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ContainerDistribution(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ImageProps: function _aws_cdk_aws_imagebuilder_alpha_ImageProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.workflows != null)
                for (const o of p.workflows)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_WorkflowConfiguration(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ImagePipelineProps: function _aws_cdk_aws_imagebuilder_alpha_ImagePipelineProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.schedule))
                module.exports._aws_cdk_aws_imagebuilder_alpha_ImagePipelineSchedule(p.schedule);
            if (p.workflows != null)
                for (const o of p.workflows)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_WorkflowConfiguration(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_ImageRecipeProps: function _aws_cdk_aws_imagebuilder_alpha_ImageRecipeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.blockDevices != null)
                for (const o of p.blockDevices)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_BlockDevice(o);
            if (p.components != null)
                for (const o of p.components)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_ComponentConfiguration(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_InfrastructureConfigurationProps: function _aws_cdk_aws_imagebuilder_alpha_InfrastructureConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.instanceTypes != null)
                for (const o of p.instanceTypes)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_InstanceType(o);
            if (!visitedObjects.has(p.logging))
                module.exports._aws_cdk_aws_imagebuilder_alpha_InfrastructureConfigurationLogging(p.logging);
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyFilter: function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyFilter(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.ageFilter))
                module.exports._aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAgeFilter(p.ageFilter);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyExclusionRules: function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyExclusionRules(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.amiExclusionRules))
                module.exports._aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAmiExclusionRules(p.amiExclusionRules);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyDetail: function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyDetail(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.filter))
                module.exports._aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyFilter(p.filter);
            if (!visitedObjects.has(p.exclusionRules))
                module.exports._aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyExclusionRules(p.exclusionRules);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyProps: function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.details != null)
                for (const o of p.details)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyDetail(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
