import type { Construct } from 'constructs';
import type { IImage } from './image';
import { ImageArchitecture, ImageType } from './image';
/**
 * Attributes for importing an Amazon-managed image by name (and optionally a version)
 */
export interface AmazonManagedImageAttributes {
    /**
     * The name of the Amazon-managed image. The provided name must be normalized by converting all alphabetical
     * characters to lowercase, and replacing all spaces and underscores with hyphens.
     */
    readonly imageName: string;
    /**
     * The version of the Amazon-managed image
     *
     * @default x.x.x
     */
    readonly imageVersion?: string;
}
/**
 * Options for selecting a predefined Amazon-managed image
 */
export interface AmazonManagedImageOptions {
    /**
     * The architecture of the Amazon-managed image
     */
    readonly imageArchitecture: ImageArchitecture;
    /**
     * The type of the Amazon-managed image
     */
    readonly imageType: ImageType;
    /**
     * The version of the Amazon-managed image
     *
     * @default x.x.x
     */
    readonly imageVersion?: string;
}
/**
 * Helper class for working with Amazon-managed images
 */
export declare class AmazonManagedImage {
    /**
     * Imports the Amazon Linux 2 Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://docs.aws.amazon.com/linux/al2/ug/index.html
     * @see https://gallery.ecr.aws/amazonlinux/amazonlinux
     */
    static amazonLinux2(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the Amazon Linux 2023 Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://docs.aws.amazon.com/linux/al2023/ug/what-is-amazon-linux.html
     * @see https://gallery.ecr.aws/amazonlinux/amazonlinux
     */
    static amazonLinux2023(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the Red Hat Enterprise Linux 10 Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://aws.amazon.com/partners/redhat/faqs
     */
    static redHatEnterpriseLinux10(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the SUSE Linux Enterprise Server 15 Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://aws.amazon.com/linux/commercial-linux/faqs/
     */
    static suseLinuxEnterpriseServer15(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the Ubuntu 22.04 Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://documentation.ubuntu.com/aws
     * @see https://hub.docker.com/_/ubuntu
     */
    static ubuntuServer2204(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the Ubuntu 24.04 Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://documentation.ubuntu.com/aws
     * @see https://hub.docker.com/_/ubuntu
     */
    static ubuntuServer2404(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the Windows Server 2016 Core Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://docs.aws.amazon.com/ec2/latest/windows-ami-reference/index.html
     * @see https://hub.docker.com/r/microsoft/windows-servercore
     */
    static windowsServer2016Core(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the Windows Server 2016 Full Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://docs.aws.amazon.com/ec2/latest/windows-ami-reference/index.html
     */
    static windowsServer2016Full(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the Windows Server 2019 Core Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://docs.aws.amazon.com/ec2/latest/windows-ami-reference/index.html
     * @see https://hub.docker.com/r/microsoft/windows-servercore
     */
    static windowsServer2019Core(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the Windows Server 2019 Full Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://docs.aws.amazon.com/ec2/latest/windows-ami-reference/index.html
     */
    static windowsServer2019Full(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the Windows Server 2022 Core Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://docs.aws.amazon.com/ec2/latest/windows-ami-reference/index.html
     */
    static windowsServer2022Core(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the Windows Server 2022 Full Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://docs.aws.amazon.com/ec2/latest/windows-ami-reference/index.html
     */
    static windowsServer2022Full(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the Windows Server 2025 Core Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://docs.aws.amazon.com/ec2/latest/windows-ami-reference/index.html
     */
    static windowsServer2025Core(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the Windows Server 2025 Full Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://docs.aws.amazon.com/ec2/latest/windows-ami-reference/index.html
     */
    static windowsServer2025Full(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the macOS 14 Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-mac-instances.html
     */
    static macOS14(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports the macOS 15 Amazon-managed image
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed image attributes
     *
     * @see https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-mac-instances.html
     */
    static macOS15(scope: Construct, id: string, opts: AmazonManagedImageOptions): IImage;
    /**
     * Imports an Amazon-managed image from its attributes
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param attrs - The Amazon-managed image attributes
     */
    static fromAmazonManagedImageAttributes(scope: Construct, id: string, attrs: AmazonManagedImageAttributes): IImage;
    /**
     * Imports an Amazon-managed image from its name
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param amazonManagedImageName - The name of the Amazon-managed image
     */
    static fromAmazonManagedImageName(scope: Construct, id: string, amazonManagedImageName: string): IImage;
    private static readonly AMAZON_LINUX_2_CONFIG;
    private static readonly AMAZON_LINUX_2023_CONFIG;
    private static readonly RED_HAT_ENTERPRISE_LINUX_10_CONFIG;
    private static readonly SUSE_LINUX_ENTERPRISE_SERVER_15_CONFIG;
    private static readonly UBUNTU_SERVER_22_04_CONFIG;
    private static readonly UBUNTU_SERVER_24_04_CONFIG;
    private static readonly WINDOWS_SERVER_2016_CORE_CONFIG;
    private static readonly WINDOWS_SERVER_2016_FULL_CONFIG;
    private static readonly WINDOWS_SERVER_2019_CORE_CONFIG;
    private static readonly WINDOWS_SERVER_2019_FULL_CONFIG;
    private static readonly WINDOWS_SERVER_2022_CORE_CONFIG;
    private static readonly WINDOWS_SERVER_2022_FULL_CONFIG;
    private static readonly WINDOWS_SERVER_2025_CORE_CONFIG;
    private static readonly WINDOWS_SERVER_2025_FULL_CONFIG;
    private static readonly MACOS_14_CONFIG;
    private static readonly MACOS_15_CONFIG;
    private static validatePredefinedManagedImageOptions;
    private static predefinedManagedImage;
}
