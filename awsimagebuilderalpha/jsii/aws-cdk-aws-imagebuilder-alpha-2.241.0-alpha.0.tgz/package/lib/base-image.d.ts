import type * as ecr from 'aws-cdk-lib/aws-ecr';
import type * as ssm from 'aws-cdk-lib/aws-ssm';
import type { IImage } from './image';
/**
 * Represents a base image that is used to start from in EC2 Image Builder image builds
 */
export declare class BaseImage {
    /**
     * The AMI ID to use as a base image in an image recipe
     *
     * @param amiId The AMI ID to use as the base image
     */
    static fromAmiId(amiId: string): BaseImage;
    /**
     * The EC2 Image Builder image to use as a base image in an image recipe
     *
     * @param image The EC2 Image Builder image to use as a base image
     */
    static fromImage(image: IImage): BaseImage;
    /**
     * The marketplace product ID for an AMI product to use as the base image in an image recipe
     *
     * @param productId The Marketplace AMI product ID to use as the base image
     */
    static fromMarketplaceProductId(productId: string): BaseImage;
    /**
     * The SSM parameter to use as the base image in an image recipe
     *
     * @param parameter The SSM parameter to use as the base image
     */
    static fromSsmParameter(parameter: ssm.IParameter): BaseImage;
    /**
     * The parameter name for the SSM parameter to use as the base image in an image recipe
     *
     * @param parameterName The name of the SSM parameter to use as the base image
     */
    static fromSsmParameterName(parameterName: string): BaseImage;
    /**
     * The direct string value of the base image to use in an image recipe. This can be an EC2 Image Builder image ARN,
     * an SSM parameter, an AWS Marketplace product ID, or an AMI ID.
     *
     * @param baseImageString The base image as a direct string value
     */
    static fromString(baseImageString: string): BaseImage;
    /**
     * The rendered base image to use
     **/
    readonly image: string;
    protected constructor(image: string);
}
/**
 * Represents a base image that is used to start from in EC2 Image Builder image builds
 */
export declare class BaseContainerImage {
    /**
     * The DockerHub image to use as the base image in a container recipe
     *
     * @param repository The DockerHub repository where the base image resides in
     * @param tag The tag of the base image in the DockerHub repository
     */
    static fromDockerHub(repository: string, tag: string): BaseContainerImage;
    /**
     * The ECR container image to use as the base image in a container recipe
     *
     * @param repository The ECR repository where the base image resides in
     * @param tag The tag of the base image in the ECR repository
     */
    static fromEcr(repository: ecr.IRepository, tag: string): BaseContainerImage;
    /**
     * The ECR public container image to use as the base image in a container recipe
     *
     * @param registryAlias The alias of the ECR public registry where the base image resides in
     * @param repositoryName The name of the ECR public repository, where the base image resides in
     * @param tag The tag of the base image in the ECR public repository
     */
    static fromEcrPublic(registryAlias: string, repositoryName: string, tag: string): BaseContainerImage;
    /**
     * The EC2 Image Builder image to use as a base image in a container recipe
     *
     * @param image The EC2 Image Builder image to use as a base image
     */
    static fromImage(image: IImage): BaseContainerImage;
    /**
     * The string value of the base image to use in a container recipe. This can be an EC2 Image Builder image ARN,
     * an ECR or ECR public image, or a container URI sourced from a third-party container registry such as DockerHub.
     *
     * @param baseContainerImageString The base image as a direct string value
     */
    static fromString(baseContainerImageString: string): BaseContainerImage;
    /**
     * The rendered base image to use
     **/
    readonly image: string;
    protected constructor(image: string);
}
/**
 * Represents a container instance image that is used to launch the instance used for building the container for an
 * EC2 Image Builder container build.
 */
export declare class ContainerInstanceImage {
    /**
     * The AMI ID to use to launch the instance for building the container image
     *
     * @param amiId The AMI ID to use as the container instance image
     */
    static fromAmiId(amiId: string): ContainerInstanceImage;
    /**
     * The SSM parameter to use to launch the instance for building the container image
     *
     * @param parameter The SSM parameter to use as the container instance image
     */
    static fromSsmParameter(parameter: ssm.IStringParameter): ContainerInstanceImage;
    /**
     * The ARN of the SSM parameter used to launch the instance for building the container image
     *
     * @param parameterName The name of the SSM parameter used as the container instance image
     */
    static fromSsmParameterName(parameterName: string): ContainerInstanceImage;
    /**
     * The string value of the container instance image to use in a container recipe. This can either be:
     * - an SSM parameter reference, prefixed with `ssm:` and followed by the parameter name or ARN
     * - an AMI ID
     *
     * @param containerInstanceImageString The container instance image as a direct string value
     */
    static fromString(containerInstanceImageString: string): ContainerInstanceImage;
    /**
     * The rendered container instance image to use
     **/
    readonly image: string;
    protected constructor(image: string);
}
