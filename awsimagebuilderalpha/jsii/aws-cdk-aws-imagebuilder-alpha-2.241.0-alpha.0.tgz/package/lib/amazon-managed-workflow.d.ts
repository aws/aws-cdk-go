import type { Construct } from 'constructs';
import type { IWorkflow } from './workflow';
import { WorkflowType } from './workflow';
/**
 * Properties for an EC2 Image Builder Amazon-managed workflow
 */
export interface AmazonManagedWorkflowAttributes {
    /**
     * The name of the Amazon-managed workflow
     */
    readonly workflowName: string;
    /**
     * The type of the Amazon-managed workflow
     */
    readonly workflowType: WorkflowType;
}
/**
 * Helper class for working with Amazon-managed workflows
 */
export declare class AmazonManagedWorkflow {
    /**
     * Imports the build-container Amazon-managed workflow
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     */
    static buildContainer(scope: Construct, id: string): IWorkflow;
    /**
     * Imports the build-image AWS-managed workflow
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     */
    static buildImage(scope: Construct, id: string): IWorkflow;
    /**
     * Imports the distribute-container AWS-managed workflow
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     */
    static distributeContainer(scope: Construct, id: string): IWorkflow;
    /**
     * Imports the distribute-image AWS-managed workflow
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     */
    static distributeImage(scope: Construct, id: string): IWorkflow;
    /**
     * Imports the test-container AWS-managed workflow
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     */
    static testContainer(scope: Construct, id: string): IWorkflow;
    /**
     * Imports the test-image AWS-managed workflow
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     */
    static testImage(scope: Construct, id: string): IWorkflow;
    /**
     * Imports an AWS-managed workflow from its attributes
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param attrs The attributes of the AWS-managed workflow
     */
    static fromAmazonManagedWorkflowAttributes(scope: Construct, id: string, attrs: AmazonManagedWorkflowAttributes): IWorkflow;
}
