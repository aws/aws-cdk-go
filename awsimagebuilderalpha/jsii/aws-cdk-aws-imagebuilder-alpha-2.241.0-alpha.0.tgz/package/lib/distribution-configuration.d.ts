import * as cdk from 'aws-cdk-lib';
import type * as ec2 from 'aws-cdk-lib/aws-ec2';
import type * as ecr from 'aws-cdk-lib/aws-ecr';
import * as iam from 'aws-cdk-lib/aws-iam';
import type * as kms from 'aws-cdk-lib/aws-kms';
import type * as ssm from 'aws-cdk-lib/aws-ssm';
import type { Construct } from 'constructs';
/**
 * An EC2 Image Builder Distribution Configuration.
 */
export interface IDistributionConfiguration extends cdk.IResource {
    /**
     * The ARN of the distribution configuration
     *
     * @attribute
     */
    readonly distributionConfigurationArn: string;
    /**
     * The name of the distribution configuration
     *
     * @attribute
     */
    readonly distributionConfigurationName: string;
    /**
     * Grant custom actions to the given grantee for the distribution configuration
     *
     * @param grantee The principal
     * @param actions The list of actions
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grant read permissions to the given grantee for the distribution configuration
     *
     * @param grantee The principal
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
}
/**
 * The launch permissions for the AMI, defining which principals are allowed to access the AMI
 */
export interface AmiLaunchPermission {
    /**
     * The ARNs for the AWS Organizations organizational units to share the AMI with
     *
     * @default None
     */
    readonly organizationalUnitArns?: string[];
    /**
     * The ARNs for the AWS Organization that you want to share the AMI with
     *
     * @default None
     */
    readonly organizationArns?: string[];
    /**
     * Whether to make the AMI public. Block public access for AMIs must be disabled to make the AMI public.
     *
     * WARNING: Making an AMI public exposes it to any AWS account globally.
     *  Ensure the AMI does not contain:
     *  - Sensitive data or credentials
     *  - Proprietary software or configurations
     *  - Internal network information or security settings
     *
     * For more information on blocking public access for AMIs, see: [Understand block public access for AMIs](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/block-public-access-to-amis.html)
     *
     *
     * @default false
     */
    readonly isPublicUserGroup?: boolean;
    /**
     * The AWS account IDs to share the AMI with
     *
     * @default None
     */
    readonly accountIds?: string[];
}
/**
 * The SSM parameters to create or update for the distributed AMIs
 */
export interface SSMParameterConfigurations {
    /**
     * The AWS account ID that will own the SSM parameter in the given region. This must be one of the target accounts
     * that was included in the list of AMI distribution target accounts
     *
     * @default The current account is used
     */
    readonly amiAccount?: string;
    /**
     * The data type of the SSM parameter
     *
     * @default ssm.ParameterDataType.AWS_EC2_IMAGE
     */
    readonly dataType?: ssm.ParameterDataType;
    /**
     * The SSM parameter to create or update
     */
    readonly parameter: ssm.IStringParameter;
}
/**
 * The launch template to apply the distributed AMI to
 */
export interface LaunchTemplateConfiguration {
    /**
     * The launch template to apply the distributed AMI to. A new launch template version will be created for the
     * provided launch template with the distributed AMI applied.
     *
     * *Note:* The launch template should expose a `launchTemplateId`. Templates
     * imported by name only are not supported.
     *
     */
    readonly launchTemplate: ec2.ILaunchTemplate;
    /**
     * The AWS account ID that owns the launch template
     *
     * @default The current account is used
     */
    readonly accountId?: string;
    /**
     * Whether to set the new launch template version that is created as the default launch template version. After
     * creation of the launch template version containing the distributed AMI, it will be automatically set as the
     * default version for the launch template.
     *
     * @default false
     */
    readonly setDefaultVersion?: boolean;
}
/**
 * The EC2 Fast Launch configuration to use for the Windows AMI
 */
export interface FastLaunchConfiguration {
    /**
     * Whether to enable fast launch for the AMI
     *
     * @default false
     */
    readonly enabled?: boolean;
    /**
     * The launch template that the fast-launch enabled Windows AMI uses when it launches Windows instances to create
     * pre-provisioned snapshots
     *
     * @default None
     */
    readonly launchTemplate?: ec2.ILaunchTemplate;
    /**
     * The maximum number of parallel instances that are launched for creating resources
     *
     * @default A maximum of 6 instances are launched in parallel
     * @see https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_EnableFastLaunch.html
     */
    readonly maxParallelLaunches?: number;
    /**
     * The number of pre-provisioned snapshots to keep on hand for a fast-launch enabled Windows AMI
     *
     * @default 10 snapshots are kept pre-provisioned
     * @see https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_EnableFastLaunch.html
     */
    readonly targetSnapshotCount?: number;
}
/**
 * The regional distribution settings to use for an AMI build
 */
export interface AmiDistribution {
    /**
     * The target region to distribute AMIs to
     *
     * @default The current region is used
     */
    readonly region?: string;
    /**
     * The tags to apply to the distributed AMIs
     *
     * @default None
     */
    readonly amiTags?: {
        [key: string]: string;
    };
    /**
     * The description of the AMI
     *
     * @default None
     */
    readonly amiDescription?: string;
    /**
     * The KMS key to encrypt the distributed AMI with
     *
     * @default None
     */
    readonly amiKmsKey?: kms.IKey;
    /**
     * The launch permissions for the AMI, defining which principals are allowed to access the AMI
     *
     * @default None
     */
    readonly amiLaunchPermission?: AmiLaunchPermission;
    /**
     * The name to use for the distributed AMIs
     *
     * @default A name is generated from the image recipe name
     */
    readonly amiName?: string;
    /**
     * The account IDs to copy the output AMI to
     *
     * @default None
     */
    readonly amiTargetAccountIds?: string[];
    /**
     * The SSM parameters to create or update for the distributed AMIs
     *
     * @default None
     */
    readonly ssmParameters?: SSMParameterConfigurations[];
    /**
     * The launch templates to apply the distributed AMI to
     *
     * @default None
     */
    readonly launchTemplates?: LaunchTemplateConfiguration[];
    /**
     * The fast launch configurations to use for enabling EC2 Fast Launch on the distributed Windows AMI
     *
     * @default None
     * @see https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_EnableFastLaunch.html
     */
    readonly fastLaunchConfigurations?: FastLaunchConfiguration[];
    /**
     * The License Manager license configuration ARNs to apply to the distributed AMIs
     *
     * @default None
     */
    readonly licenseConfigurationArns?: string[];
}
/**
 * The regional distribution settings to use for a container build
 */
export interface ContainerDistribution {
    /**
     * The target region to distribute containers to
     *
     * @default The current region is used
     */
    readonly region?: string;
    /**
     * The destination repository to distribute the output container to
     *
     * @default The target repository in the container recipe is used
     */
    readonly containerRepository: Repository;
    /**
     * The description of the container image
     *
     * @default None
     */
    readonly containerDescription?: string;
    /**
     * The additional tags to apply to the distributed container images
     *
     * @default None
     */
    readonly containerTags?: string[];
}
/**
 * Properties for creating a Distribution Configuration resource
 */
export interface DistributionConfigurationProps {
    /**
     * The list of target regions and associated AMI distribution settings where the built AMI will be distributed. AMI
     * distributions may also be added with the `addAmiDistributions` method.
     *
     * @default None if container distributions are provided. Otherwise, at least one AMI or container distribution must
     *          be provided
     */
    readonly amiDistributions?: AmiDistribution[];
    /**
     * The list of target regions and associated container distribution settings where the built container will be
     * distributed. Container distributions may also be added with the `addContainerDistributions` method.
     *
     * @default None if AMI distributions are provided. Otherwise, at least one AMI or container distribution must be
     *          provided
     */
    readonly containerDistributions?: ContainerDistribution[];
    /**
     * The name of the distribution configuration.
     *
     * @default A name is generated
     */
    readonly distributionConfigurationName?: string;
    /**
     * The description of the distribution configuration.
     *
     * @default None
     */
    readonly description?: string;
    /**
     * The tags to apply to the distribution configuration
     *
     * @default None
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * A new or imported Distribution Configuration
 */
declare abstract class DistributionConfigurationBase extends cdk.Resource implements IDistributionConfiguration {
    /**
     * The ARN of the distribution configuration
     */
    abstract readonly distributionConfigurationArn: string;
    /**
     * The name of the distribution configuration
     */
    abstract readonly distributionConfigurationName: string;
    /**
     * Grant custom actions to the given grantee for the distribution configuration
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal
     * @param actions The list of actions
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grant read permissions to the given grantee for the distribution configuration
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
}
/**
 * The service in which a container should be registered
 */
export declare enum RepositoryService {
    /**
     * Indicates the container should be registered in ECR
     */
    ECR = "ECR"
}
/**
 * A container repository used to distribute container images in EC2 Image Builder
 */
export declare abstract class Repository {
    /**
     * The ECR repository to use as the target container repository
     *
     * @param repository The ECR repository to use
     */
    static fromEcr(repository: ecr.IRepository): Repository;
    /**
     * The name of the container repository where the output container image is stored
     */
    abstract readonly repositoryName: string;
    /**
     * The service in which the container repository is hosted
     */
    abstract readonly service: RepositoryService;
}
/**
 * Represents an EC2 Image Builder Distribution Configuration.
 *
 * @see https://docs.aws.amazon.com/imagebuilder/latest/userguide/manage-distribution-settings.html
 */
export declare class DistributionConfiguration extends DistributionConfigurationBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing distribution configuration given its ARN.
     */
    static fromDistributionConfigurationArn(scope: Construct, id: string, distributionConfigurationArn: string): IDistributionConfiguration;
    /**
     * Import an existing distribution configuration given its name. The provided name must be normalized by converting
     * all alphabetical characters to lowercase, and replacing all spaces and underscores with hyphens.
     */
    static fromDistributionConfigurationName(scope: Construct, id: string, distributionConfigurationName: string): IDistributionConfiguration;
    /**
     * Return whether the given object is a DistributionConfiguration.
     */
    static isDistributionConfiguration(x: any): x is DistributionConfiguration;
    private readonly resource;
    private readonly amiDistributionsByRegion;
    private readonly containerDistributionsByRegion;
    constructor(scope: Construct, id: string, props?: DistributionConfigurationProps);
    get distributionConfigurationName(): string;
    get distributionConfigurationArn(): string;
    /**
     * Adds AMI distribution settings to the distribution configuration
     *
     * @param amiDistributions The list of AMI distribution settings to apply
     */
    addAmiDistributions(...amiDistributions: AmiDistribution[]): void;
    /**
     * Adds container distribution settings to the distribution configuration
     *
     * @param containerDistributions The list of container distribution settings to apply
     */
    addContainerDistributions(...containerDistributions: ContainerDistribution[]): void;
    private validateDistributionConfigurationName;
    /**
     * Renders the AMI and container distributions provided as input to the construct, into the `Distribution[]` structure
     * that CfnDistributionConfiguration expects to receive. Distributions provided to CfnDistributionConfiguration must
     * map to a unique region per entry in the list - this render function also handles combining AMI and container
     * distributions in the same region into a single entry.
     *
     * This is rendered at synthesis time, as users can add additional AMI and container distributions with
     * `addAmiDistributions` and `addContainerDistributions`, after the construct has been instantiated.
     *
     * @private
     */
    private renderDistributions;
    private buildAmiDistribution;
    private buildContainerDistribution;
    private buildAmiLaunchPermissions;
    private buildFastLaunchConfigurations;
    private buildLaunchTemplateConfigurations;
    private buildLicenseConfigurationArns;
    private buildSsmParameterConfigurations;
}
export {};
