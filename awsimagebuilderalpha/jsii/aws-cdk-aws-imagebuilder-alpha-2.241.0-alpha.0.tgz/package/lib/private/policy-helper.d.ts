import * as iam from 'aws-cdk-lib/aws-iam';
import type * as logs from 'aws-cdk-lib/aws-logs';
import type { Construct } from 'constructs';
import type { ImageProps } from '../image';
import type { ImagePipelineProps } from '../image-pipeline';
import type { WorkflowConfiguration } from '../workflow';
/**
 * Returns the default execution role policy, for auto-generated execution roles.
 *
 * @param scope The construct scope
 * @param props Props input for the construct
 *
 * @see https://docs.aws.amazon.com/aws-managed-policy/latest/reference/AWSServiceRoleForImageBuilder.html
 */
export declare const defaultExecutionRolePolicy: <PropsT extends ImagePipelineProps | ImageProps>(scope: Construct, props?: PropsT) => iam.PolicyStatement[];
export declare const getExecutionRole: (scope: Construct, grantDefaultExecutionRolePermissions: (grantee: iam.IGrantable) => void, { executionRole, workflows, imageLogGroup, imagePipelineLogGroup, }: {
    executionRole?: iam.IRole;
    imageLogGroup?: logs.ILogGroup;
    imagePipelineLogGroup?: logs.ILogGroup;
    workflows?: WorkflowConfiguration[];
}) => iam.IRole | undefined;
