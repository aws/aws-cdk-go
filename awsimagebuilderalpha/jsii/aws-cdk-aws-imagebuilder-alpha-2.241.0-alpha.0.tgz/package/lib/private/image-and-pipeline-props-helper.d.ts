import type { CfnImage, CfnImagePipeline } from 'aws-cdk-lib/aws-imagebuilder';
import type { Construct } from 'constructs';
import type { ImageProps } from '../image';
import type { ImagePipelineProps } from '../image-pipeline';
/**
 * Generates the image tests configuration property into the `ImageTestsConfiguration` type in the CloudFormation L1
 * definition.
 *
 * @param props Props input for the construct
 */
export declare const buildImageTestsConfiguration: <PropsT extends ImagePipelineProps | ImageProps, OutputT extends CfnImagePipeline.ImageTestsConfigurationProperty | CfnImage.ImageTestsConfigurationProperty>(props: PropsT) => OutputT | undefined;
/**
 * Generates the image scanning configuration property into the `ImageScanningConfiguration` type in the CloudFormation
 * L1 definition.
 *
 * @param scope The construct scope
 * @param props Props input for the construct
 */
export declare const buildImageScanningConfiguration: <PropsT extends ImagePipelineProps | ImageProps, OutputT extends CfnImagePipeline.ImageScanningConfigurationProperty | CfnImage.ImageScanningConfigurationProperty>(scope: Construct, props: PropsT) => OutputT | undefined;
/**
 * Generates the workflows property into the `WorkflowConfiguration` type in the CloudFormation L1
 * definition.
 *
 * @param props Props input for the construct
 */
export declare const buildWorkflows: <PropsT extends ImagePipelineProps | ImageProps, OutputT extends CfnImagePipeline.WorkflowConfigurationProperty[] | CfnImage.WorkflowConfigurationProperty[]>(props: PropsT) => OutputT | undefined;
