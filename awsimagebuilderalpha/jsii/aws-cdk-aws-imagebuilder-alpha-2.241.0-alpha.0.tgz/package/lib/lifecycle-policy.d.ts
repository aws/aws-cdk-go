import * as cdk from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import type { IRecipeBase } from './recipe-base';
/**
 * An EC2 Image Builder Lifecycle Policy.
 */
export interface ILifecyclePolicy extends cdk.IResource {
    /**
     * The ARN of the lifecycle policy
     *
     * @attribute
     */
    readonly lifecyclePolicyArn: string;
    /**
     * The name of the lifecycle policy
     *
     * @attribute
     */
    readonly lifecyclePolicyName: string;
    /**
     * Grant custom actions to the given grantee for the lifecycle policy
     *
     * @param grantee - The principal
     * @param actions - The list of actions
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grant read permissions to the given grantee for the lifecycle policy
     *
     * @param grantee - The principal
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
}
/**
 * The action to perform on the resources which the policy applies to
 */
export declare enum LifecyclePolicyActionType {
    /**
     * Indicates that the rule should delete the resource when it is applied
     */
    DELETE = "DELETE",
    /**
     * Indicates that the rule should deprecate the resource when it is applied
     */
    DEPRECATE = "DEPRECATE",
    /**
     * Indicates that the rule should disable the resource when it is applied
     */
    DISABLE = "DISABLE"
}
/**
 * The status of the lifecycle policy, indicating whether it will run
 */
export declare enum LifecyclePolicyStatus {
    /**
     * Indicates that the lifecycle policy should be enabled
     */
    ENABLED = "ENABLED",
    /**
     * Indicates that the lifecycle policy should be disabled
     */
    DISABLED = "DISABLED"
}
/**
 * The resource type which the lifecycle policy is applied to
 */
export declare enum LifecyclePolicyResourceType {
    /**
     * Indicates the policy applies to AMI-based images
     */
    AMI_IMAGE = "AMI_IMAGE",
    /**
     * Indicates the policy applies to container images
     */
    CONTAINER_IMAGE = "CONTAINER_IMAGE"
}
/**
 * The action to perform in the lifecycle policy rule
 */
export interface LifecyclePolicyAction {
    /**
     * The action to perform on the resources selected in the lifecycle policy rule
     */
    readonly type: LifecyclePolicyActionType;
    /**
     * Whether to include AMIs in the scope of the lifecycle rule
     *
     * @default - true for AMI-based policies, false otherwise
     */
    readonly includeAmis?: boolean;
    /**
     * Whether to include containers in the scope of the lifecycle rule
     *
     * @default - true for container-based policies, false otherwise
     */
    readonly includeContainers?: boolean;
    /**
     * Whether to include snapshots in the scope of the lifecycle rule
     *
     * @default - true for AMI-based policies, false otherwise
     */
    readonly includeSnapshots?: boolean;
}
/**
 * The resource filtering to apply in the lifecycle policy rule
 */
export interface LifecyclePolicyFilter {
    /**
     * The resource age filter to apply in the lifecycle policy rule
     *
     * @default - none if a count filter is provided. Otherwise, an age filter is required.
     */
    readonly ageFilter?: LifecyclePolicyAgeFilter;
    /**
     * The resource count filter to apply in the lifecycle policy rule
     *
     * @default - none if an age filter is provided. Otherwise, a count filter is required.
     */
    readonly countFilter?: LifecyclePolicyCountFilter;
}
/**
 * The count-based filtering to apply in a lifecycle policy rule
 */
export interface LifecyclePolicyCountFilter {
    /**
     * The minimum number of resources to keep on hand as part of resource filtering
     */
    readonly count: number;
}
/**
 * The age-based filtering to apply in a lifecycle policy rule
 */
export interface LifecyclePolicyAgeFilter {
    /**
     * The minimum age of the resource to filter. The provided duration will be rounded up to the nearest
     * day/week/month/year value.
     */
    readonly age: cdk.Duration;
    /**
     * For age-based filters, the number of EC2 Image Builder images to keep on hand once the rule is applied. The value
     * must be between 1 and 10.
     *
     * @default 0
     */
    readonly retainAtLeast?: number;
}
/**
 * The rules to apply for excluding EC2 Image Builder images from the lifecycle policy rule
 */
export interface LifecyclePolicyImageExclusionRules {
    /**
     * Excludes EC2 Image Builder images with any of the provided tags from the lifecycle policy rule
     */
    readonly tags: {
        [key: string]: string;
    };
}
/**
 * The rules to apply for excluding AMIs from the lifecycle policy rule
 */
export interface LifecyclePolicyAmiExclusionRules {
    /**
     * Excludes public AMIs from the lifecycle policy rule if true
     *
     * @default false
     */
    readonly isPublic?: boolean;
    /**
     * Excludes AMIs which were launched from within the provided duration
     *
     * @default None
     */
    readonly lastLaunched?: cdk.Duration;
    /**
     * Excludes AMIs which reside in any of the provided regions
     *
     * @default None
     */
    readonly regions?: string[];
    /**
     * Excludes AMIs which are shared with any of the provided shared accounts
     *
     * @default None
     */
    readonly sharedAccounts?: string[];
    /**
     * Excludes AMIs which have any of the provided tags applied to it
     *
     * @default None
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * The rules to apply for excluding resources from the lifecycle policy rule
 */
export interface LifecyclePolicyExclusionRules {
    /**
     * The rules to apply for excluding EC2 Image Builder images from the lifecycle policy rule
     *
     * @default - no exclusion rules are applied on the image
     */
    readonly imageExclusionRules?: LifecyclePolicyImageExclusionRules;
    /**
     * The rules to apply for excluding AMIs from the lifecycle policy rule
     *
     * @default - no exclusion rules are applied on the AMI
     */
    readonly amiExclusionRules?: LifecyclePolicyAmiExclusionRules;
}
/**
 * Configuration details for the lifecycle policy rules
 */
export interface LifecyclePolicyDetail {
    /**
     * The action to perform in the lifecycle policy rule
     */
    readonly action: LifecyclePolicyAction;
    /**
     * The resource filtering to apply in the lifecycle policy rule
     */
    readonly filter: LifecyclePolicyFilter;
    /**
     * The rules to apply for excluding resources from the lifecycle policy rule
     *
     * @default - no exclusion rules are applied on any resource
     */
    readonly exclusionRules?: LifecyclePolicyExclusionRules;
}
/**
 * Selection criteria for the resources that the lifecycle policy applies to
 */
export interface LifecyclePolicyResourceSelection {
    /**
     * The list of image recipes or container recipes to apply the lifecycle policy to
     *
     * @default - none if tag selections are provided. Otherwise, at least one recipe or tag selection must be provided
     */
    readonly recipes?: IRecipeBase[];
    /**
     * Selects EC2 Image Builder images containing any of the provided tags
     *
     * @default - none if recipe selections are provided. Otherwise, at least one recipe or tag selection must be provided
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Properties for creating a Lifecycle Policy resource
 */
export interface LifecyclePolicyProps {
    /**
     * The type of Image Builder resource that the lifecycle policy applies to.
     */
    readonly resourceType: LifecyclePolicyResourceType;
    /**
     * Configuration details for the lifecycle policy rules.
     */
    readonly details: LifecyclePolicyDetail[];
    /**
     * Selection criteria for the resources that the lifecycle policy applies to.
     */
    readonly resourceSelection: LifecyclePolicyResourceSelection;
    /**
     * The name of the lifecycle policy.
     *
     * @default - a name is generated
     */
    readonly lifecyclePolicyName?: string;
    /**
     * The description of the lifecycle policy.
     *
     * @default None
     */
    readonly description?: string;
    /**
     * The status of the lifecycle policy.
     *
     * @default LifecyclePolicyStatus.ENABLED
     */
    readonly status?: LifecyclePolicyStatus;
    /**
     * The execution role that grants Image Builder access to run lifecycle actions.
     *
     * By default, an execution role will be created with the minimal permissions needed to execute the lifecycle policy
     * actions.
     *
     * @default - an execution role will be generated
     */
    readonly executionRole?: iam.IRole;
    /**
     * The tags to apply to the lifecycle policy
     *
     * @default - none
     */
    readonly tags?: {
        [key: string]: string;
    };
}
declare abstract class LifecyclePolicyBase extends cdk.Resource implements ILifecyclePolicy {
    abstract readonly lifecyclePolicyArn: string;
    abstract readonly lifecyclePolicyName: string;
    /**
     * [disable-awslint:no-grants]
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * [disable-awslint:no-grants]
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
}
/**
 * Represents an EC2 Image Builder Lifecycle Policy.
 *
 * @see https://docs.aws.amazon.com/imagebuilder/latest/userguide/manage-image-lifecycles.html
 */
export declare class LifecyclePolicy extends LifecyclePolicyBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing lifecycle policy given its ARN.
     */
    static fromLifecyclePolicyArn(scope: Construct, id: string, lifecyclePolicyArn: string): ILifecyclePolicy;
    /**
     * Import an existing lifecycle policy given its name. If the name is a token representing a dynamic CloudFormation
     * expression, you must ensure all alphabetic characters in the expression are already lowercased
     */
    static fromLifecyclePolicyName(scope: Construct, id: string, lifecyclePolicyName: string): ILifecyclePolicy;
    /**
     * Return whether the given object is a LifecyclePolicy.
     */
    static isLifecyclePolicy(x: any): x is LifecyclePolicy;
    /**
     * The execution role used for lifecycle policy executions
     */
    readonly executionRole: iam.IRole;
    private resource;
    constructor(scope: Construct, id: string, props: LifecyclePolicyProps);
    get lifecyclePolicyName(): string;
    get lifecyclePolicyArn(): string;
    /**
     * Generates the policy details property into the `PolicyDetail` type in the CloudFormation L1 definition.
     *
     * @param resourceType The resource type of the lifecycle policy
     * @param details The lifecycle policy rules
     * @private
     */
    private buildPolicyDetails;
    /**
     * Generates the recipes property in the resource selection into the `RecipeSelection` type in the CloudFormation L1
     * definition.
     *
     * @param resourceType The resource type of the lifecycle policy
     * @param recipes The recipes passed in the props
     * @private
     */
    private buildRecipes;
    /**
     * Generates the exclusion rules property into the `ExclusionRules` type in the CloudFormation L1 definition.
     *
     * @param exclusionRules The exclusion rules for resources applied in the lifecycle policy rule
     * @private
     */
    private buildExclusionRules;
    /**
     * Generates the action property into the `Action` type in the CloudFormation L1 definition.
     *
     * @param resourceType The resource type of the lifecycle policy
     * @param action The action being taken in the lifecycle policy rule
     * @private
     */
    private buildAction;
    /**
     * Validates the top-level properties of the policy
     *
     * @param props The props passed as input to the construct
     * @private
     */
    private validatePolicy;
    /**
     * Validates a policy detail filter within a lifecycle policy rule
     *
     * @param resourceType The resource type of the lifecycle policy
     * @param action The action being taken in the lifecycle policy rule
     * @param amiExclusionRules The AMI exclusion rules in the lifecycle policy rule
     * @private
     */
    private validatePolicyDetailAction;
    /**
     * Validates a policy detail filter
     *
     * @param filter The lifecycle policy resource filter applied in the rule
     * @private
     */
    private validatePolicyDetailFilter;
    /**
     * Converts a `cdk.Duration` into the value and unit which is accepted as filter age and last launched age in the
     * lifecycle policy. The value is rounded up to the nearest whole number.
     *
     * @param duration The duration to convert
     * @param valueLimit The maximum value that can be specified
     * @private
     */
    private convertDurationToTimeUnitValue;
    private validateLifecyclePolicyName;
}
export {};
