import type { Construct } from 'constructs';
import type { IComponent } from './component';
import { Platform } from './os-version';
/**
 * Properties for an EC2 Image Builder Amazon-managed component
 */
export interface AmazonManagedComponentAttributes {
    /**
     * The name of the Amazon-managed component
     */
    readonly componentName: string;
    /**
     * The version of the Amazon-managed component
     *
     * @default - the latest version of the component, x.x.x
     */
    readonly componentVersion?: string;
}
/**
 * Options for selecting a predefined Amazon-managed image
 */
export interface AmazonManagedComponentOptions {
    /**
     * The platform of the Amazon-managed component
     */
    readonly platform: Platform;
    /**
     * The version of the Amazon-managed component
     *
     * @default - the latest version of the component, x.x.x
     */
    readonly componentVersion?: string;
}
/**
 * Helper class for working with Amazon-managed components
 */
export declare abstract class AmazonManagedComponent {
    /**
     * Imports the AWS CLI v2 Amazon-managed component
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed component options
     */
    static awsCliV2(scope: Construct, id: string, opts: AmazonManagedComponentOptions): IComponent;
    /**
     * Imports the hello world Amazon-managed component
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed component options
     */
    static helloWorld(scope: Construct, id: string, opts: AmazonManagedComponentOptions): IComponent;
    /**
     * Imports the Python 3 Amazon-managed component
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed component options
     */
    static python3(scope: Construct, id: string, opts: AmazonManagedComponentOptions): IComponent;
    /**
     * Imports the reboot Amazon-managed component
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed component options
     */
    static reboot(scope: Construct, id: string, opts: AmazonManagedComponentOptions): IComponent;
    /**
     * Imports the STIG hardening Amazon-managed component
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed component options
     *
     * @see https://docs.aws.amazon.com/imagebuilder/latest/userguide/ib-stig.html
     */
    static stigBuild(scope: Construct, id: string, opts: AmazonManagedComponentOptions): IComponent;
    /**
     * Imports the OS update Amazon-managed component
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param opts The Amazon-managed component attributes
     */
    static updateOs(scope: Construct, id: string, opts: AmazonManagedComponentOptions): IComponent;
    /**
     * Imports an Amazon-managed component from its attributes
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param attrs The Amazon-managed component attributes
     */
    static fromAmazonManagedComponentAttributes(scope: Construct, id: string, attrs: AmazonManagedComponentAttributes): IComponent;
    /**
     * Imports an Amazon-managed component from its name
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param amazonManagedComponentName - The name of the Amazon-managed component
     */
    static fromAmazonManagedComponentName(scope: Construct, id: string, amazonManagedComponentName: string): IComponent;
    private static readonly AWS_CLI_V2_CONFIG;
    private static readonly HELLO_WORLD_CONFIG;
    private static readonly PYTHON_3_CONFIG;
    private static readonly REBOOT_CONFIG;
    private static readonly STIG_BUILD_CONFIG;
    private static readonly UPDATE_OS_CONFIG;
    private static validatePredefinedManagedComponentOptions;
    private static predefinedManagedComponent;
}
