import * as cdk from 'aws-cdk-lib';
import * as iam from 'aws-cdk-lib/aws-iam';
import type * as kms from 'aws-cdk-lib/aws-kms';
import type * as s3 from 'aws-cdk-lib/aws-s3';
import * as s3assets from 'aws-cdk-lib/aws-s3-assets';
import type { Construct } from 'constructs';
/**
 * An EC2 Image Builder Workflow.
 */
export interface IWorkflow extends cdk.IResource {
    /**
     * The ARN of the workflow
     *
     * @attribute
     */
    readonly workflowArn: string;
    /**
     * The name of the workflow
     *
     * @attribute
     */
    readonly workflowName: string;
    /**
     * The type of the workflow
     *
     * @attribute
     */
    readonly workflowType: string;
    /**
     * The version of the workflow
     *
     * @attribute
     */
    readonly workflowVersion: string;
    /**
     * Grant custom actions to the given grantee for the workflow
     *
     * @param grantee The principal
     * @param actions The list of actions
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grant read permissions to the given grantee for the workflow
     *
     * @param grantee The principal
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
}
/**
 * Properties for creating a Workflow resource
 */
export interface WorkflowProps {
    /**
     * The workflow document content that defines the image creation process.
     */
    readonly data: WorkflowData;
    /**
     * The phase in the image build process for which the workflow resource is responsible.
     */
    readonly workflowType: WorkflowType;
    /**
     * The name of the workflow.
     *
     * @default - a name is generated
     */
    readonly workflowName?: string;
    /**
     * The version of the workflow.
     *
     * @default 1.0.0
     */
    readonly workflowVersion?: string;
    /**
     * The description of the workflow.
     *
     * @default None
     */
    readonly description?: string;
    /**
     * The change description of the workflow. Describes what change has been made in this version of the workflow, or
     * what makes this version different from other versions.
     *
     * @default None
     */
    readonly changeDescription?: string;
    /**
     * The KMS key used to encrypt this workflow.
     *
     * @default - an Image Builder owned key will be used to encrypt the workflow.
     */
    readonly kmsKey?: kms.IKey;
    /**
     * The tags to apply to the workflow
     *
     * @default None
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Properties for an EC2 Image Builder Workflow
 */
export interface WorkflowAttributes {
    /**
     * The ARN of the workflow
     *
     * @default - the ARN is automatically constructed if a workflowName and workflowType is provided, otherwise a
     * workflowArn is required
     */
    readonly workflowArn?: string;
    /**
     * The name of the workflow
     *
     * @default - the name is automatically constructed if a workflowArn is provided, otherwise a workflowName is required
     */
    readonly workflowName?: string;
    /**
     * The type of the workflow
     *
     * @default - the type is automatically constructed if a workflowArn is provided, otherwise a workflowType is required
     */
    readonly workflowType?: WorkflowType;
    /**
     * The version of the workflow
     *
     * @default x.x.x
     */
    readonly workflowVersion?: string;
}
/**
 * The action for a step within the workflow document
 */
export declare enum WorkflowAction {
    /**
     * Applies customizations and configurations to the input AMIs, such as publishing the AMI to SSM Parameter Store,
     * or creating launch template versions with the AMI IDs provided in the input
     */
    APPLY_IMAGE_CONFIGURATIONS = "ApplyImageConfigurations",
    /**
     * The BootstrapInstanceForContainer action runs a service script to bootstrap the instance with minimum requirements
     * to run container workflows
     */
    BOOTSTRAP_INSTANCE_FOR_CONTAINER = "BootstrapInstanceForContainer",
    /**
     * The CollectImageMetadata action collects additional information about the instance, such as the list of packages
     * and their respective versions
     */
    COLLECT_IMAGE_METADATA = "CollectImageMetadata",
    /**
     * The CollectImageScanFindings action collects findings reported by Amazon Inspector for the provided instance
     */
    COLLECT_IMAGE_SCAN_FINDINGS = "CollectImageScanFindings",
    /**
     * The CreateImage action creates an AMI from a running instance with the ec2:CreateImage API
     */
    CREATE_IMAGE = "CreateImage",
    /**
     * The DistributeImage action copies an AMI using the image's distribution configuration, or using the distribution
     * settings in the step input
     */
    DISTRIBUTE_IMAGE = "DistributeImage",
    /**
     * The ExecuteComponents action runs components that are specified in the recipe for the current image being built
     */
    EXECUTE_COMPONENTS = "ExecuteComponents",
    /**
     * The ExecuteStateMachine action executes a the state machine provided and waits for completion as part of the
     * workflow
     */
    EXECUTE_STATE_MACHINE = "ExecuteStateMachine",
    /**
     * The LaunchInstance action launches an instance using the settings from your recipe and infrastructure configuration
     * resources
     */
    LAUNCH_INSTANCE = "LaunchInstance",
    /**
     * Applies attribute updates to the provided set of distributed images, such as launch permission updates
     */
    MODIFY_IMAGE_ATTRIBUTES = "ModifyImageAttributes",
    /**
     * The RunCommand action runs a command document against the provided instance
     */
    RUN_COMMAND = "RunCommand",
    /**
     * The RegisterImage action creates an AMI from a set of snapshots with the ec2:RegisterImage API
     */
    REGISTER_IMAGE = "RegisterImage",
    /**
     * The RunSysprep action runs the Sysprep document on the provided Windows instance
     */
    RUN_SYS_PREP = "RunSysPrep",
    /**
     * The SanitizeInstance action runs a recommended sanitization script on Linux instances
     */
    SANITIZE_INSTANCE = "SanitizeInstance",
    /**
     * The TerminateInstance action terminates the provided instance
     */
    TERMINATE_INSTANCE = "TerminateInstance",
    /**
     * The WaitForAction action pauses the workflow and waits to receive an external signal from the
     * imagebuilder:SendWorkflowStepAction API
     */
    WAIT_FOR_ACTION = "WaitForAction",
    /**
     * The WaitForSSMAgent action waits for the given instance to have connectivity with SSM before proceeding
     */
    WAIT_FOR_SSM_AGENT = "WaitForSSMAgent"
}
/**
 * The action to take if the workflow fails
 */
export declare enum WorkflowOnFailure {
    /**
     * Fails the image build if the workflow fails
     */
    ABORT = "Abort",
    /**
     * Continues with the image build if the workflow fails
     */
    CONTINUE = "Continue"
}
/**
 * The parameter type for the workflow parameter
 */
export declare enum WorkflowParameterType {
    /**
     * Indicates the workflow parameter has a boolean value
     */
    BOOLEAN = "boolean",
    /**
     * Indicates the workflow parameter has an integer value
     */
    INTEGER = "integer",
    /**
     * Indicates the workflow parameter has a string value
     */
    STRING = "string",
    /**
     * Indicates the workflow parameter has a string list value
     */
    STRING_LIST = "stringList"
}
/**
 * The schema version of the workflow
 */
export declare enum WorkflowSchemaVersion {
    /**
     * Schema version 1.0 for the workflow document
     */
    V1_0 = "1.0"
}
/**
 * The type of the workflow
 */
export declare enum WorkflowType {
    /**
     * Indicates the workflow is for building images
     */
    BUILD = "BUILD",
    /**
     * Indicates the workflow is for testing images
     */
    TEST = "TEST",
    /**
     * Indicates the workflow is for distributing images
     */
    DISTRIBUTION = "DISTRIBUTION"
}
/**
 * The rendered workflow data value, for use in CloudFormation.
 * - For inline workflows, data is the workflow text
 * - For S3-backed workflows, uri is the S3 URL
 */
export interface WorkflowDataConfig {
    /**
     * The rendered workflow data, for use in CloudFormation
     *
     * @default - none if uri is set
     */
    readonly data?: string;
    /**
     * The rendered workflow data URI, for use in CloudFormation
     *
     * @default - none if data is set
     */
    readonly uri?: string;
}
/**
 * Helper class for referencing and uploading workflow data
 */
export declare abstract class WorkflowData {
    /**
     * Uploads workflow data from a local file to S3 to use as the workflow data
     *
     * @param scope The construct scope
     * @param id Identifier of the construct
     * @param path The local path to the workflow data file
     * @param options S3 asset upload options
     */
    static fromAsset(scope: Construct, id: string, path: string, options?: s3assets.AssetOptions): S3WorkflowData;
    /**
     * References workflow data from a pre-existing S3 object
     *
     * @param bucket The S3 bucket where the workflow data is stored
     * @param key The S3 key of the workflow data file
     */
    static fromS3(bucket: s3.IBucket, key: string): S3WorkflowData;
    /**
     * Uses an inline JSON object as the workflow data
     *
     * @param data An inline JSON object representing the workflow data
     */
    static fromJsonObject(data: {
        [key: string]: any;
    }): WorkflowData;
    /**
     * Uses an inline JSON or YAML string as the workflow data
     *
     * @param data An inline JSON or YAML string representing the workflow data
     */
    static fromInline(data: string): WorkflowData;
    /**
     * The rendered workflow data value, for use in CloudFormation.
     * - For inline workflows, data is the workflow text
     * - For S3-backed workflows, uri is the S3 URL
     */
    abstract render(): WorkflowDataConfig;
}
/**
 * Helper class for S3-based workflow data references, containing additional permission grant methods on the S3 object
 */
export declare abstract class S3WorkflowData extends WorkflowData {
    protected readonly bucket: s3.IBucket;
    protected readonly key: string;
    protected constructor(bucket: s3.IBucket, key: string);
    /**
     * The rendered workflow data text, for use in CloudFormation
     */
    render(): WorkflowDataConfig;
    /**
     * Grant put permissions to the given grantee for the workflow data in S3
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal
     */
    grantPut(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant read permissions to the given grantee for the workflow data in S3
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
}
/**
 * The parameter value for a workflow parameter
 */
export declare class WorkflowParameterValue {
    /**
     * The value of the parameter as a boolean
     *
     * @param value The boolean value of the parameter
     */
    static fromBoolean(value: boolean): WorkflowParameterValue;
    /**
     * The value of the parameter as an integer
     *
     * @param value The integer value of the parameter
     */
    static fromInteger(value: number): WorkflowParameterValue;
    /**
     * The value of the parameter as a string
     * @param value The string value of the parameter
     */
    static fromString(value: string): WorkflowParameterValue;
    /**
     * The value of the parameter as a string list
     *
     * @param values The string list value of the parameter
     */
    static fromStringList(values: string[]): WorkflowParameterValue;
    /**
     * The rendered parameter value
     */
    readonly value: string[];
    protected constructor(value: string[]);
}
/**
 * Configuration details for a workflow
 */
export interface WorkflowConfiguration {
    /**
     * The workflow to execute in the image build
     */
    readonly workflow: IWorkflow;
    /**
     * The action to take if the workflow fails
     *
     * @default WorkflowOnFailure.ABORT
     */
    readonly onFailure?: WorkflowOnFailure;
    /**
     * The named parallel group to include this workflow in. Workflows in the same parallel group run in parallel of each
     * other.
     *
     * @default None
     */
    readonly parallelGroup?: string;
    /**
     * The parameters to pass to the workflow at execution time
     *
     * @default - none if the workflow has no parameters, otherwise the default parameter values are used
     */
    readonly parameters?: {
        [name: string]: WorkflowParameterValue;
    };
}
/**
 * A new or imported Workflow
 */
declare abstract class WorkflowBase extends cdk.Resource implements IWorkflow {
    /**
     * The ARN of the workflow
     */
    abstract readonly workflowArn: string;
    /**
     * The name of the workflow
     */
    abstract readonly workflowName: string;
    /**
     * The type of the workflow
     */
    abstract readonly workflowType: string;
    /**
     * The version of the workflow
     */
    abstract readonly workflowVersion: string;
    /**
     * Grant custom actions to the given grantee for the workflow
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal
     * @param actions The list of actions
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grant read permissions to the given grantee for the workflow
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
}
/**
 * Represents an EC2 Image Builder Workflow.
 *
 * @see https://docs.aws.amazon.com/imagebuilder/latest/userguide/manage-image-workflows.html
 */
export declare class Workflow extends WorkflowBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing workflow given its ARN.
     */
    static fromWorkflowArn(scope: Construct, id: string, workflowArn: string): IWorkflow;
    /**
     * Import an existing workflow by providing its attributes. The provided name must be normalized by converting
     * all alphabetical characters to lowercase, and replacing all spaces and underscores with hyphens. You may not
     * provide a dynamic expression for the workflowArn or workflowType
     */
    static fromWorkflowAttributes(scope: Construct, id: string, attrs: WorkflowAttributes): IWorkflow;
    /**
     * Return whether the given object is a Workflow.
     */
    static isWorkflow(x: any): x is Workflow;
    /**
     * The type of the workflow
     */
    readonly workflowType: string;
    /**
     * The version of the workflow
     */
    readonly workflowVersion: string;
    private resource;
    constructor(scope: Construct, id: string, props: WorkflowProps);
    get workflowName(): string;
    get workflowArn(): string;
    private validateWorkflowName;
}
export {};
