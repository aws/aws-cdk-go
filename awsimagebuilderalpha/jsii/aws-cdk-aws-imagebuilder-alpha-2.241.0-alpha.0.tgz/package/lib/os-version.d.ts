/**
 * Represents a platform for an EC2 Image Builder image
 */
export declare enum Platform {
    /**
     * Platform for Linux
     */
    LINUX = "Linux",
    /**
     * Platform for Windows
     */
    WINDOWS = "Windows",
    /**
     * Platform for macOS
     */
    MAC_OS = "macOS"
}
/**
 * Represents an OS version for an EC2 Image Builder image
 */
export declare class OSVersion {
    /**
     * OS version for all Linux images
     */
    static readonly LINUX: OSVersion;
    /**
     * OS version for all macOS images
     */
    static readonly MAC_OS: OSVersion;
    /**
     * OS version for all Windows images
     */
    static readonly WINDOWS: OSVersion;
    /**
     * OS version for all Amazon Linux images
     */
    static readonly AMAZON_LINUX: OSVersion;
    /**
     * OS version for Amazon Linux 2
     */
    static readonly AMAZON_LINUX_2: OSVersion;
    /**
     * OS version for Amazon Linux 2023
     */
    static readonly AMAZON_LINUX_2023: OSVersion;
    /**
     * OS version for macOS 14
     */
    static readonly MAC_OS_14: OSVersion;
    /**
     * OS version for macOS 15
     */
    static readonly MAC_OS_15: OSVersion;
    /**
     * OS version for all Red Hat Enterprise Linux images
     */
    static readonly REDHAT_ENTERPRISE_LINUX: OSVersion;
    /**
     * OS version for Red Hat Enterprise Linux 8
     */
    static readonly REDHAT_ENTERPRISE_LINUX_8: OSVersion;
    /**
     * OS version for Red Hat Enterprise Linux 9
     */
    static readonly REDHAT_ENTERPRISE_LINUX_9: OSVersion;
    /**
     * OS version for Red Hat Enterprise Linux 10
     */
    static readonly REDHAT_ENTERPRISE_LINUX_10: OSVersion;
    /**
     * OS version for all SLES images
     */
    static readonly SLES: OSVersion;
    /**
     * OS version for SLES 15
     */
    static readonly SLES_15: OSVersion;
    /**
     * OS version for all Ubuntu images
     */
    static readonly UBUNTU: OSVersion;
    /**
     * OS version for Ubuntu 22.04
     */
    static readonly UBUNTU_22_04: OSVersion;
    /**
     * OS version for Ubuntu 24.04
     */
    static readonly UBUNTU_24_04: OSVersion;
    /**
     * OS version for all Windows server images
     */
    static readonly WINDOWS_SERVER: OSVersion;
    /**
     * OS version for Windows Server 2016
     */
    static readonly WINDOWS_SERVER_2016: OSVersion;
    /**
     * OS version for Windows Server 2019
     */
    static readonly WINDOWS_SERVER_2019: OSVersion;
    /**
     * OS version for Windows Server 2022
     */
    static readonly WINDOWS_SERVER_2022: OSVersion;
    /**
     * OS version for Windows Server 2025
     */
    static readonly WINDOWS_SERVER_2025: OSVersion;
    /**
     * Constructs an OS version with a custom name
     *
     * @param platform The platform of the OS version
     * @param osVersion The custom OS version to use
     */
    static custom(platform: Platform, osVersion?: string): OSVersion;
    /**
     * The Platform of the OS version
     */
    readonly platform: Platform;
    /**
     * The OS version name
     */
    readonly osVersion?: string;
    protected constructor(platform: Platform, osVersion?: string);
}
