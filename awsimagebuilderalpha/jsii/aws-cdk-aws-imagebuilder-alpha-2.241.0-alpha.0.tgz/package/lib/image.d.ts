import * as cdk from 'aws-cdk-lib';
import type * as ecr from 'aws-cdk-lib/aws-ecr';
import * as iam from 'aws-cdk-lib/aws-iam';
import type * as logs from 'aws-cdk-lib/aws-logs';
import type { Construct } from 'constructs';
import { BaseContainerImage, BaseImage } from './base-image';
import type { IDistributionConfiguration } from './distribution-configuration';
import type { IInfrastructureConfiguration } from './infrastructure-configuration';
import type { IRecipeBase } from './recipe-base';
import type { WorkflowConfiguration } from './workflow';
/**
 * An EC2 Image Builder Image
 */
export interface IImage extends cdk.IResource {
    /**
     * The ARN of the image
     *
     * @attribute
     */
    readonly imageArn: string;
    /**
     * The name of the image
     *
     * @attribute
     */
    readonly imageName: string;
    /**
     * The version of the image
     *
     * @attribute
     */
    readonly imageVersion: string;
    /**
     * Grant custom actions to the given grantee for the image
     *
     * @param grantee The principal
     * @param actions The list of actions
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grants the default permissions for building an image to the provided execution role.
     *
     * @param grantee The execution role used for the image build.
     */
    grantDefaultExecutionRolePermissions(grantee: iam.IGrantable): iam.Grant[];
    /**
     * Grant read permissions to the given grantee for the image
     *
     * @param grantee The principal
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Converts the image to a BaseImage, to use as the parent image in an image recipe
     */
    toBaseImage(): BaseImage;
    /**
     * Converts the image to a ContainerBaseImage, to use as the parent image in a container recipe
     */
    toContainerBaseImage(): BaseContainerImage;
}
/**
 * Properties for creating an Image resource
 */
export interface ImageProps {
    /**
     * The recipe that defines the base image, components, and customizations used to build the image. This can either be
     * an image recipe, or a container recipe.
     */
    readonly recipe: IRecipeBase;
    /**
     * The infrastructure configuration used for building the image.
     *
     * A default infrastructure configuration will be used if one is not provided.
     *
     * The default configuration will create an instance profile and role with minimal permissions needed to build the
     * image, attached to the EC2 instance.
     *
     * IMDSv2 will be required by default on the instances used to build and test the image.
     *
     * @default - an infrastructure configuration will be created with the default settings
     */
    readonly infrastructureConfiguration?: IInfrastructureConfiguration;
    /**
     * The distribution configuration used for distributing the image.
     *
     * @default None
     */
    readonly distributionConfiguration?: IDistributionConfiguration;
    /**
     * The list of workflow configurations used to build the image.
     *
     * @default - Image Builder will use a default set of workflows for the build to build, test, and distribute the
     * image
     */
    readonly workflows?: WorkflowConfiguration[];
    /**
     * The execution role used to perform workflow actions to build the image.
     *
     * By default, the Image Builder Service Linked Role (SLR) will be created automatically and used as the execution
     * role. However, when providing a custom set of image workflows for the image, an execution role will be
     * generated with the minimal permissions needed to execute the workflows.
     *
     * @default - Image Builder will use the SLR if possible. Otherwise, an execution role will be generated
     */
    readonly executionRole?: iam.IRole;
    /**
     * The log group to use for the image. By default, a log group will be created with the format
     * `/aws/imagebuilder/<image-name>`
     *
     * @default - a log group will be created
     */
    readonly logGroup?: logs.ILogGroup;
    /**
     * Indicates whether Image Builder keeps a snapshot of the vulnerability scans that Amazon Inspector runs against the
     * build instance when you create a new image.
     *
     * @default false
     */
    readonly imageScanningEnabled?: boolean;
    /**
     * The container repository that Amazon Inspector scans to identify findings for your container images. If a
     * repository is not provided, Image Builder creates a repository named `image-builder-image-scanning-repository`
     * for vulnerability scanning.
     *
     * @default - if scanning is enabled, a repository will be created by Image Builder if one is not provided
     */
    readonly imageScanningEcrRepository?: ecr.IRepository;
    /**
     * The tags for Image Builder to apply to the output container image that Amazon Inspector scans.
     *
     * @default None
     */
    readonly imageScanningEcrTags?: string[];
    /**
     * If enabled, collects additional information about the image being created, including the operating system (OS)
     * version and package list for the AMI.
     *
     * @default true
     */
    readonly enhancedImageMetadataEnabled?: boolean;
    /**
     * Whether to run tests after building an image.
     *
     * @default true
     */
    readonly imageTestsEnabled?: boolean;
    /**
     * The execution role to use for deleting the image as well as the underlying resources, such as the AMIs, snapshots,
     * and containers. This role should contain resource lifecycle permissions required to delete the underlying
     * AMIs/containers.
     *
     * @default - no execution role. Only the Image Builder image will be deleted.
     */
    readonly deletionExecutionRole?: iam.IRole;
    /**
     * The tags to apply to the image
     *
     * @default None
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Properties for an EC2 Image Builder image
 */
export interface ImageAttributes {
    /**
     * The ARN of the image
     *
     * @default - derived from the imageName
     */
    readonly imageArn?: string;
    /**
     * The name of the image
     *
     * @default - derived from the imageArn
     */
    readonly imageName?: string;
    /**
     * The version of the image
     *
     * @default - the latest version of the image, x.x.x
     */
    readonly imageVersion?: string;
}
/**
 * The architecture of the image
 */
export declare enum ImageArchitecture {
    /**
     * 64 bit architecture with the ARM instruction set
     */
    ARM64 = "arm64",
    /**
     * 64 bit architecture with x86 instruction set
     */
    X86_64 = "x86_64"
}
/**
 * The type of the image
 */
export declare enum ImageType {
    /**
     * Indicates the image produced is an AMI
     */
    AMI = "AMI",
    /**
     * Indicates the image produced is a Docker image
     */
    DOCKER = "DOCKER"
}
/**
 * A new or imported Image
 */
declare abstract class ImageBase extends cdk.Resource implements IImage {
    /**
     * The ARN of the image
     */
    abstract readonly imageArn: string;
    /**
     * The name of the image
     */
    abstract readonly imageName: string;
    /**
     * The version of the image
     */
    abstract readonly imageVersion: string;
    /**
     * Grant custom actions to the given grantee for the image
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal
     * @param actions The list of actions
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grants the default permissions for building an image to the provided execution role.
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee The execution role used for the image build.
     */
    grantDefaultExecutionRolePermissions(grantee: iam.IGrantable): iam.Grant[];
    /**
     * Grant read permissions to the given grantee for the image
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee The principal
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Converts the image to a BaseImage, to use as the parent image in an image recipe
     */
    toBaseImage(): BaseImage;
    /**
     * Converts the image to a ContainerBaseImage, to use as the parent image in a container recipe
     */
    toContainerBaseImage(): BaseContainerImage;
}
/**
 * Represents an EC2 Image Builder Image.
 *
 * @see https://docs.aws.amazon.com/imagebuilder/latest/userguide/create-images.html
 */
export declare class Image extends ImageBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing image given its ARN
     */
    static fromImageArn(scope: Construct, id: string, imageArn: string): IImage;
    /**
     * Import an existing image given its name. The provided name must be normalized by converting all alphabetical
     * characters to lowercase, and replacing all spaces and underscores with hyphens.
     */
    static fromImageName(scope: Construct, id: string, imageName: string): IImage;
    /**
     * Import an existing image by providing its attributes. If the image name is provided as an attribute, it must be
     * normalized by converting all alphabetical characters to lowercase, and replacing all spaces and underscores with
     * hyphens.
     */
    static fromImageAttributes(scope: Construct, id: string, attrs: ImageAttributes): IImage;
    /**
     * Return whether the given object is an Image.
     */
    static isImage(x: any): x is Image;
    /**
     * The infrastructure configuration used for the image build
     */
    readonly infrastructureConfiguration: IInfrastructureConfiguration;
    /**
     * The execution role used for the image build
     */
    readonly executionRole?: iam.IRole;
    private readonly props;
    private resource;
    constructor(scope: Construct, id: string, props: ImageProps);
    /**
     * Grants the default permissions for building an image to the provided execution role.
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee The execution role used for the image build.
     */
    grantDefaultExecutionRolePermissions(grantee: iam.IGrantable): iam.Grant[];
    get imageName(): string;
    get imageArn(): string;
    get imageVersion(): string;
    /**
     * The AMI ID of the EC2 AMI, or URI for the container
     *
     * @attribute
     */
    get imageId(): string;
    /**
     * Creates a CfnImage resource from the recipe and props provided.
     *
     * @param props Props input for the construct
     * @private
     */
    private createImageFromRecipe;
    /**
     * Generates the loggingConfiguration property into the `LoggingConfiguration` type in the CloudFormation L1
     * definition.
     *
     * @param props Props input for the construct
     */
    private buildLoggingConfiguration;
    /**
     * Generates the deletionSettings property into the `DeletionSettings` type in the CloudFormation L1 definition.
     *
     * @param props Props input for the construct
     */
    private buildDeletionSettings;
}
export {};
