function _aws_cdk_aws_imagebuilder_alpha_IComponent(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.data))
            _aws_cdk_aws_imagebuilder_alpha_ComponentData(p.data);
        if (!visitedObjects.has(p.platform))
            _aws_cdk_aws_imagebuilder_alpha_Platform(p.platform);
        if (p.supportedOsVersions != null)
            for (const o of p.supportedOsVersions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_OSVersion(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentAttributes(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_AwsMarketplaceComponentAttributes(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentDocument(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.phases != null)
            for (const o of p.phases)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentPhase(o);
        if (!visitedObjects.has(p.schemaVersion))
            _aws_cdk_aws_imagebuilder_alpha_ComponentSchemaVersion(p.schemaVersion);
        if (p.constants != null)
            for (const o of Object.values(p.constants))
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_ComponentConstantValue(o);
        if (p.parameters != null)
            for (const o of Object.values(p.parameters))
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentParameterDefinition(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentPhase(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.name))
            _aws_cdk_aws_imagebuilder_alpha_ComponentPhaseName(p.name);
        if (p.steps != null)
            for (const o of p.steps)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentStep(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentStep(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.action))
            _aws_cdk_aws_imagebuilder_alpha_ComponentAction(p.action);
        if (!visitedObjects.has(p.inputs))
            _aws_cdk_aws_imagebuilder_alpha_ComponentStepInputs(p.inputs);
        if (!visitedObjects.has(p.if))
            _aws_cdk_aws_imagebuilder_alpha_ComponentStepIfCondition(p.if);
        if (!visitedObjects.has(p.loop))
            _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentLoop(p.loop);
        if (!visitedObjects.has(p.onFailure))
            _aws_cdk_aws_imagebuilder_alpha_ComponentOnFailure(p.onFailure);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentLoop(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.for))
            _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentForLoop(p.for);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentForLoop(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentConstantValue(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentParameterDefinition(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.type))
            _aws_cdk_aws_imagebuilder_alpha_ComponentParameterType(p.type);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentAction(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentOnFailure(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentParameterType(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentPhaseName(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentSchemaVersion(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentStepInputs(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentStepIfCondition(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentDataConfig(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentData(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_S3ComponentData(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_AwsMarketplaceComponent(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_Component(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_IContainerRecipe(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ContainerRecipeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.baseImage))
            _aws_cdk_aws_imagebuilder_alpha_BaseContainerImage(p.baseImage);
        if (!visitedObjects.has(p.targetRepository))
            _aws_cdk_aws_imagebuilder_alpha_Repository(p.targetRepository);
        if (p.components != null)
            for (const o of p.components)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_ComponentConfiguration(o);
        if (!visitedObjects.has(p.dockerfile))
            _aws_cdk_aws_imagebuilder_alpha_DockerfileData(p.dockerfile);
        if (p.instanceBlockDevices != null)
            for (const o of p.instanceBlockDevices)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_BlockDevice(o);
        if (!visitedObjects.has(p.instanceImage))
            _aws_cdk_aws_imagebuilder_alpha_ContainerInstanceImage(p.instanceImage);
        if (!visitedObjects.has(p.osVersion))
            _aws_cdk_aws_imagebuilder_alpha_OSVersion(p.osVersion);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_ContainerType(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_DockerfileTemplateConfig(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_DockerfileData(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_S3DockerfileData(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ContainerRecipeAttributes(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ContainerRecipeBase(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ContainerRecipe(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_IDistributionConfiguration(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_AmiLaunchPermission(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_SSMParameterConfigurations(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_LaunchTemplateConfiguration(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_FastLaunchConfiguration(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_AmiDistribution(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.amiLaunchPermission))
            _aws_cdk_aws_imagebuilder_alpha_AmiLaunchPermission(p.amiLaunchPermission);
        if (p.fastLaunchConfigurations != null)
            for (const o of p.fastLaunchConfigurations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_FastLaunchConfiguration(o);
        if (p.launchTemplates != null)
            for (const o of p.launchTemplates)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_LaunchTemplateConfiguration(o);
        if (p.ssmParameters != null)
            for (const o of p.ssmParameters)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_SSMParameterConfigurations(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_ContainerDistribution(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.containerRepository))
            _aws_cdk_aws_imagebuilder_alpha_Repository(p.containerRepository);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_DistributionConfigurationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.amiDistributions != null)
            for (const o of p.amiDistributions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_AmiDistribution(o);
        if (p.containerDistributions != null)
            for (const o of p.containerDistributions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_ContainerDistribution(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_RepositoryService(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_Repository(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_DistributionConfiguration(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_IImage(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ImageProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.recipe))
            _aws_cdk_aws_imagebuilder_alpha_IRecipeBase(p.recipe);
        if (!visitedObjects.has(p.distributionConfiguration))
            _aws_cdk_aws_imagebuilder_alpha_IDistributionConfiguration(p.distributionConfiguration);
        if (!visitedObjects.has(p.infrastructureConfiguration))
            _aws_cdk_aws_imagebuilder_alpha_IInfrastructureConfiguration(p.infrastructureConfiguration);
        if (p.workflows != null)
            for (const o of p.workflows)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_WorkflowConfiguration(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_ImageAttributes(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ImageArchitecture(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ImageType(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_Image(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_IImagePipeline(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ImagePipelineProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.recipe))
            _aws_cdk_aws_imagebuilder_alpha_IRecipeBase(p.recipe);
        if (!visitedObjects.has(p.distributionConfiguration))
            _aws_cdk_aws_imagebuilder_alpha_IDistributionConfiguration(p.distributionConfiguration);
        if (!visitedObjects.has(p.infrastructureConfiguration))
            _aws_cdk_aws_imagebuilder_alpha_IInfrastructureConfiguration(p.infrastructureConfiguration);
        if (!visitedObjects.has(p.schedule))
            _aws_cdk_aws_imagebuilder_alpha_ImagePipelineSchedule(p.schedule);
        if (!visitedObjects.has(p.status))
            _aws_cdk_aws_imagebuilder_alpha_ImagePipelineStatus(p.status);
        if (p.workflows != null)
            for (const o of p.workflows)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_WorkflowConfiguration(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_ImagePipelineSchedule(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.startCondition))
            _aws_cdk_aws_imagebuilder_alpha_ScheduleStartCondition(p.startCondition);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_ScheduleStartCondition(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ImagePipelineStatus(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ImagePipeline(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_IImageRecipe(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ImageRecipeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.baseImage))
            _aws_cdk_aws_imagebuilder_alpha_BaseImage(p.baseImage);
        if (p.blockDevices != null)
            for (const o of p.blockDevices)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_BlockDevice(o);
        if (p.components != null)
            for (const o of p.components)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_ComponentConfiguration(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_ImageRecipeAttributes(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ImageRecipe(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_IInfrastructureConfiguration(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_HttpTokens(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_Tenancy(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_InfrastructureConfigurationLogging(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_InfrastructureConfigurationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.ec2InstanceTenancy))
            _aws_cdk_aws_imagebuilder_alpha_Tenancy(p.ec2InstanceTenancy);
        if (!visitedObjects.has(p.httpTokens))
            _aws_cdk_aws_imagebuilder_alpha_HttpTokens(p.httpTokens);
        if (p.instanceTypes != null)
            for (const o of p.instanceTypes)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_InstanceType(o);
        if (!visitedObjects.has(p.logging))
            _aws_cdk_aws_imagebuilder_alpha_InfrastructureConfigurationLogging(p.logging);
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_InfrastructureConfiguration(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ILifecyclePolicy(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyActionType(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyStatus(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyResourceType(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAction(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.type))
            _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyActionType(p.type);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyFilter(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.ageFilter))
            _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAgeFilter(p.ageFilter);
        if (!visitedObjects.has(p.countFilter))
            _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyCountFilter(p.countFilter);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyCountFilter(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAgeFilter(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyImageExclusionRules(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAmiExclusionRules(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyExclusionRules(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.amiExclusionRules))
            _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAmiExclusionRules(p.amiExclusionRules);
        if (!visitedObjects.has(p.imageExclusionRules))
            _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyImageExclusionRules(p.imageExclusionRules);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyDetail(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.action))
            _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAction(p.action);
        if (!visitedObjects.has(p.filter))
            _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyFilter(p.filter);
        if (!visitedObjects.has(p.exclusionRules))
            _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyExclusionRules(p.exclusionRules);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyResourceSelection(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recipes != null)
            for (const o of p.recipes)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_IRecipeBase(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.details != null)
            for (const o of p.details)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyDetail(o);
        if (!visitedObjects.has(p.resourceSelection))
            _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyResourceSelection(p.resourceSelection);
        if (!visitedObjects.has(p.resourceType))
            _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyResourceType(p.resourceType);
        if (!visitedObjects.has(p.status))
            _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyStatus(p.status);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicy(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_IWorkflow(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_WorkflowProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.data))
            _aws_cdk_aws_imagebuilder_alpha_WorkflowData(p.data);
        if (!visitedObjects.has(p.workflowType))
            _aws_cdk_aws_imagebuilder_alpha_WorkflowType(p.workflowType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_WorkflowAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.workflowType))
            _aws_cdk_aws_imagebuilder_alpha_WorkflowType(p.workflowType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_WorkflowAction(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_WorkflowOnFailure(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_WorkflowParameterType(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_WorkflowSchemaVersion(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_WorkflowType(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_WorkflowDataConfig(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_WorkflowData(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_S3WorkflowData(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_WorkflowParameterValue(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_WorkflowConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.workflow))
            _aws_cdk_aws_imagebuilder_alpha_IWorkflow(p.workflow);
        if (!visitedObjects.has(p.onFailure))
            _aws_cdk_aws_imagebuilder_alpha_WorkflowOnFailure(p.onFailure);
        if (p.parameters != null)
            for (const o of Object.values(p.parameters))
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_WorkflowParameterValue(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_Workflow(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_AmazonManagedComponentAttributes(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_AmazonManagedComponentOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.platform))
            _aws_cdk_aws_imagebuilder_alpha_Platform(p.platform);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_AmazonManagedComponent(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_AmazonManagedImageAttributes(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_AmazonManagedImageOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.imageArchitecture))
            _aws_cdk_aws_imagebuilder_alpha_ImageArchitecture(p.imageArchitecture);
        if (!visitedObjects.has(p.imageType))
            _aws_cdk_aws_imagebuilder_alpha_ImageType(p.imageType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_AmazonManagedImage(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_AmazonManagedWorkflowAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.workflowType))
            _aws_cdk_aws_imagebuilder_alpha_WorkflowType(p.workflowType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_AmazonManagedWorkflow(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_BaseImage(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_BaseContainerImage(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ContainerInstanceImage(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_Platform(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_OSVersion(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentParameterValue(p) {
}
function _aws_cdk_aws_imagebuilder_alpha_ComponentConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.component))
            _aws_cdk_aws_imagebuilder_alpha_IComponent(p.component);
        if (p.parameters != null)
            for (const o of Object.values(p.parameters))
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_imagebuilder_alpha_ComponentParameterValue(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_imagebuilder_alpha_IRecipeBase(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_imagebuilder_alpha_IComponent, _aws_cdk_aws_imagebuilder_alpha_ComponentProps, _aws_cdk_aws_imagebuilder_alpha_ComponentAttributes, _aws_cdk_aws_imagebuilder_alpha_AwsMarketplaceComponentAttributes, _aws_cdk_aws_imagebuilder_alpha_ComponentDocument, _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentPhase, _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentStep, _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentLoop, _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentForLoop, _aws_cdk_aws_imagebuilder_alpha_ComponentConstantValue, _aws_cdk_aws_imagebuilder_alpha_ComponentDocumentParameterDefinition, _aws_cdk_aws_imagebuilder_alpha_ComponentAction, _aws_cdk_aws_imagebuilder_alpha_ComponentOnFailure, _aws_cdk_aws_imagebuilder_alpha_ComponentParameterType, _aws_cdk_aws_imagebuilder_alpha_ComponentPhaseName, _aws_cdk_aws_imagebuilder_alpha_ComponentSchemaVersion, _aws_cdk_aws_imagebuilder_alpha_ComponentStepInputs, _aws_cdk_aws_imagebuilder_alpha_ComponentStepIfCondition, _aws_cdk_aws_imagebuilder_alpha_ComponentDataConfig, _aws_cdk_aws_imagebuilder_alpha_ComponentData, _aws_cdk_aws_imagebuilder_alpha_S3ComponentData, _aws_cdk_aws_imagebuilder_alpha_AwsMarketplaceComponent, _aws_cdk_aws_imagebuilder_alpha_Component, _aws_cdk_aws_imagebuilder_alpha_IContainerRecipe, _aws_cdk_aws_imagebuilder_alpha_ContainerRecipeProps, _aws_cdk_aws_imagebuilder_alpha_ContainerType, _aws_cdk_aws_imagebuilder_alpha_DockerfileTemplateConfig, _aws_cdk_aws_imagebuilder_alpha_DockerfileData, _aws_cdk_aws_imagebuilder_alpha_S3DockerfileData, _aws_cdk_aws_imagebuilder_alpha_ContainerRecipeAttributes, _aws_cdk_aws_imagebuilder_alpha_ContainerRecipeBase, _aws_cdk_aws_imagebuilder_alpha_ContainerRecipe, _aws_cdk_aws_imagebuilder_alpha_IDistributionConfiguration, _aws_cdk_aws_imagebuilder_alpha_AmiLaunchPermission, _aws_cdk_aws_imagebuilder_alpha_SSMParameterConfigurations, _aws_cdk_aws_imagebuilder_alpha_LaunchTemplateConfiguration, _aws_cdk_aws_imagebuilder_alpha_FastLaunchConfiguration, _aws_cdk_aws_imagebuilder_alpha_AmiDistribution, _aws_cdk_aws_imagebuilder_alpha_ContainerDistribution, _aws_cdk_aws_imagebuilder_alpha_DistributionConfigurationProps, _aws_cdk_aws_imagebuilder_alpha_RepositoryService, _aws_cdk_aws_imagebuilder_alpha_Repository, _aws_cdk_aws_imagebuilder_alpha_DistributionConfiguration, _aws_cdk_aws_imagebuilder_alpha_IImage, _aws_cdk_aws_imagebuilder_alpha_ImageProps, _aws_cdk_aws_imagebuilder_alpha_ImageAttributes, _aws_cdk_aws_imagebuilder_alpha_ImageArchitecture, _aws_cdk_aws_imagebuilder_alpha_ImageType, _aws_cdk_aws_imagebuilder_alpha_Image, _aws_cdk_aws_imagebuilder_alpha_IImagePipeline, _aws_cdk_aws_imagebuilder_alpha_ImagePipelineProps, _aws_cdk_aws_imagebuilder_alpha_ImagePipelineSchedule, _aws_cdk_aws_imagebuilder_alpha_ScheduleStartCondition, _aws_cdk_aws_imagebuilder_alpha_ImagePipelineStatus, _aws_cdk_aws_imagebuilder_alpha_ImagePipeline, _aws_cdk_aws_imagebuilder_alpha_IImageRecipe, _aws_cdk_aws_imagebuilder_alpha_ImageRecipeProps, _aws_cdk_aws_imagebuilder_alpha_ImageRecipeAttributes, _aws_cdk_aws_imagebuilder_alpha_ImageRecipe, _aws_cdk_aws_imagebuilder_alpha_IInfrastructureConfiguration, _aws_cdk_aws_imagebuilder_alpha_HttpTokens, _aws_cdk_aws_imagebuilder_alpha_Tenancy, _aws_cdk_aws_imagebuilder_alpha_InfrastructureConfigurationLogging, _aws_cdk_aws_imagebuilder_alpha_InfrastructureConfigurationProps, _aws_cdk_aws_imagebuilder_alpha_InfrastructureConfiguration, _aws_cdk_aws_imagebuilder_alpha_ILifecyclePolicy, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyActionType, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyStatus, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyResourceType, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAction, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyFilter, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyCountFilter, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAgeFilter, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyImageExclusionRules, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyAmiExclusionRules, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyExclusionRules, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyDetail, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyResourceSelection, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicyProps, _aws_cdk_aws_imagebuilder_alpha_LifecyclePolicy, _aws_cdk_aws_imagebuilder_alpha_IWorkflow, _aws_cdk_aws_imagebuilder_alpha_WorkflowProps, _aws_cdk_aws_imagebuilder_alpha_WorkflowAttributes, _aws_cdk_aws_imagebuilder_alpha_WorkflowAction, _aws_cdk_aws_imagebuilder_alpha_WorkflowOnFailure, _aws_cdk_aws_imagebuilder_alpha_WorkflowParameterType, _aws_cdk_aws_imagebuilder_alpha_WorkflowSchemaVersion, _aws_cdk_aws_imagebuilder_alpha_WorkflowType, _aws_cdk_aws_imagebuilder_alpha_WorkflowDataConfig, _aws_cdk_aws_imagebuilder_alpha_WorkflowData, _aws_cdk_aws_imagebuilder_alpha_S3WorkflowData, _aws_cdk_aws_imagebuilder_alpha_WorkflowParameterValue, _aws_cdk_aws_imagebuilder_alpha_WorkflowConfiguration, _aws_cdk_aws_imagebuilder_alpha_Workflow, _aws_cdk_aws_imagebuilder_alpha_AmazonManagedComponentAttributes, _aws_cdk_aws_imagebuilder_alpha_AmazonManagedComponentOptions, _aws_cdk_aws_imagebuilder_alpha_AmazonManagedComponent, _aws_cdk_aws_imagebuilder_alpha_AmazonManagedImageAttributes, _aws_cdk_aws_imagebuilder_alpha_AmazonManagedImageOptions, _aws_cdk_aws_imagebuilder_alpha_AmazonManagedImage, _aws_cdk_aws_imagebuilder_alpha_AmazonManagedWorkflowAttributes, _aws_cdk_aws_imagebuilder_alpha_AmazonManagedWorkflow, _aws_cdk_aws_imagebuilder_alpha_BaseImage, _aws_cdk_aws_imagebuilder_alpha_BaseContainerImage, _aws_cdk_aws_imagebuilder_alpha_ContainerInstanceImage, _aws_cdk_aws_imagebuilder_alpha_Platform, _aws_cdk_aws_imagebuilder_alpha_OSVersion, _aws_cdk_aws_imagebuilder_alpha_ComponentParameterValue, _aws_cdk_aws_imagebuilder_alpha_ComponentConfiguration, _aws_cdk_aws_imagebuilder_alpha_IRecipeBase };
