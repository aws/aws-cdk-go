import type { IResource } from 'aws-cdk-lib';
import type { ISecurityGroup, ISubnet } from 'aws-cdk-lib/aws-ec2';
import type { IRouterNetworkInterfaceRef } from 'aws-cdk-lib/aws-mediaconnect';
import type { Construct } from 'constructs';
/**
 * Interface for Router Network Interface
 */
export interface IRouterNetworkInterface extends IResource, IRouterNetworkInterfaceRef {
    /**
     * The Amazon Resource Name (ARN) of the router network interface.
     *
     * @attribute
     */
    readonly routerNetworkInterfaceArn: string;
    /**
     * The unique identifier of the router network interface.
     *
     * @attribute
     */
    readonly routerNetworkInterfaceId: string;
    /**
     * The date and time the router network interface was created.
     *
     * @attribute
     */
    readonly createdAt?: string;
    /**
     * The date and time the router network interface was last updated.
     *
     * @attribute
     */
    readonly updatedAt?: string;
}
/**
 * Properties for Router Network Interface
 */
export interface RouterNetworkInterfaceProps {
    /**
     * The name of the router network interface.
     * @default - Generated automatically
     */
    readonly routerNetworkInterfaceName?: string;
    /**
     * Network configuration for the router network interface.
     */
    readonly configuration: RouterNetworkConfiguration;
    /**
     * The AWS Region where the router network interface will be created.
     *
     * @default - Same region as the stack
     */
    readonly regionName?: string;
    /**
     * Tags to add to the network interface
     *
     * @default - No tagging
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Attributes for importing an existing Router Network Interface.
 */
export interface RouterNetworkInterfaceAttributes {
    /**
     * The Amazon Resource Name (ARN) of the router network interface.
     */
    readonly routerNetworkInterfaceArn: string;
    /**
     * The unique identifier of the router network interface.
     *
     * @default - accessing `routerNetworkInterfaceId` on the imported interface throws; only provide when available.
     */
    readonly routerNetworkInterfaceId?: string;
}
/**
 * Properties for public network configuration
 */
export interface PublicNetworkConfigurationProps {
    /** CIDR blocks allowed to access the network interface */
    readonly cidr: string[];
}
/**
 * Properties for VPC network configuration
 */
export interface VpcNetworkConfigurationProps {
    /** Security groups to associate with the network interface */
    readonly securityGroups: ISecurityGroup[];
    /** Subnet where the network interface will be created */
    readonly subnet: ISubnet;
}
/**
 * Factory class for creating Router Network configurations
 */
export declare class RouterNetworkConfiguration {
    /**
     * Create a public network configuration
     * @param props Public network configuration properties
     * @returns RouterNetworkConfiguration instance for public setup
     */
    static publicNetwork(props: PublicNetworkConfigurationProps): RouterNetworkConfiguration;
    /**
     * Create a VPC network configuration
     * @param props VPC network configuration properties
     * @returns RouterNetworkConfiguration instance for VPC setup
     */
    static vpc(props: VpcNetworkConfigurationProps): RouterNetworkConfiguration;
    private readonly _config;
    private readonly _publicCidrs?;
    private constructor();
}
/**
 * Defines a AWS Elemental MediaConnect Router Network Interface
 */
export declare class RouterNetworkInterface extends RouterNetworkInterfaceBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing Router Network Interface from its ARN.
     *
     * @param scope The parent construct
     * @param id The construct id
     * @param routerNetworkInterfaceArn The ARN of the Router Network Interface
     * @returns A Router Network Interface construct
     */
    static fromRouterNetworkInterfaceArn(scope: Construct, id: string, routerNetworkInterfaceArn: string): IRouterNetworkInterface;
    /**
     * Import an existing Router Network Interface from its attributes.
     *
     * Provide `routerNetworkInterfaceId` when importing an interface that was deployed
     * externally — otherwise accessing it on the imported construct will throw.
     *
     * @param scope The parent construct
     * @param id The construct id
     * @param attrs The Router Network Interface attributes
     * @returns A Router Network Interface construct
     */
    static fromRouterNetworkInterfaceAttributes(scope: Construct, id: string, attrs: RouterNetworkInterfaceAttributes): IRouterNetworkInterface;
    readonly routerNetworkInterfaceArn: string;
    readonly routerNetworkInterfaceId: string;
    /**
     * The date and time the router network interface was created.
     * @attribute
     */
    readonly createdAt?: string;
    /**
     * The date and time the router network interface was last updated.
     * @attribute
     */
    readonly updatedAt?: string;
    constructor(scope: Construct, id: string, props: RouterNetworkInterfaceProps);
}
