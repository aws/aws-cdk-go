import type { IResource } from 'aws-cdk-lib';
import type { IFlowSourceRef } from 'aws-cdk-lib/aws-mediaconnect';
import type { Construct } from 'constructs';
import type { IFlow } from './flow';
import type { SourceConfiguration } from './flow-source-configuration';
/**
 * Interface for Flow Source
 */
export interface IFlowSource extends IResource, IFlowSourceRef {
    /**
     * The Amazon Resource Name (ARN) of the flow source.
     *
     * @attribute
     */
    readonly flowSourceArn: string;
    /**
     * The name of the flow source.
     *
     * @attribute
     */
    readonly flowSourceName: string;
    /**
     * The IP address that the flow will be listening on for incoming content.
     *
     * @attribute
     */
    readonly ingestIp: string;
    /**
     * The port that the flow will be listening on for incoming content.
     *
     * @attribute
     */
    readonly sourceIngestPort: string;
}
/**
 * Properties for the flow source
 */
export interface FlowSourceProps {
    /**
     * Additional Source Configuration.
     *
     * Set the source's name via `name` on the configuration (e.g. `SourceConfiguration.rtp({ name })`).
     * When no name is set there, one is generated from construct naming.
     */
    readonly source: SourceConfiguration;
    /**
     * The flow this source is connected to. The flow must have Failover enabled to add an additional source.
     */
    readonly flow: IFlow;
}
/**
 * Attributes for importing an existing Flow Source.
 */
export interface FlowSourceAttributes {
    /**
     * The Amazon Resource Name (ARN) of the flow source.
     */
    readonly flowSourceArn: string;
    /**
     * The name of the flow source.
     *
     * @default - accessing `flowSourceName` on the imported source throws; only provide when available.
     */
    readonly flowSourceName?: string;
    /**
     * The IP address that the flow will be listening on for incoming content.
     *
     * @default - accessing `ingestIp` on the imported source throws; only provide when available.
     */
    readonly ingestIp?: string;
    /**
     * The port that the flow will be listening on for incoming content.
     *
     * @default - accessing `sourceIngestPort` on the imported source throws; only provide when available.
     */
    readonly sourceIngestPort?: string;
}
/**
 * Adds source to an existing flow.
 *
 * Adding an additional source requires Failover to be enabled. When you enable Failover,
 * the additional source must use the same protocol as the existing source. A source is
 * the external video content that includes configuration information (encryption and source type)
 * and a network address. Each flow has at least one source. A standard source comes from a source
 * other than another AWS Elemental MediaConnect flow, such as an on-premises encoder.
 */
export declare class FlowSource extends FlowSourceBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing Flow Source from its ARN.
     *
     * @param scope The parent construct
     * @param id The construct id
     * @param flowSourceArn The ARN of the Flow Source
     * @returns A Flow Source construct
     */
    static fromFlowSourceArn(scope: Construct, id: string, flowSourceArn: string): IFlowSource;
    /**
     * Import an existing Flow Source from its attributes.
     *
     * Provide `ingestIp` and/or `sourceIngestPort` when importing a source that was deployed
     * externally — otherwise accessing those properties on the imported construct will throw.
     *
     * @param scope The parent construct
     * @param id The construct id
     * @param attrs The Flow Source attributes
     * @returns A Flow Source construct
     */
    static fromFlowSourceAttributes(scope: Construct, id: string, attrs: FlowSourceAttributes): IFlowSource;
    readonly flowSourceArn: string;
    readonly flowSourceName: string;
    readonly ingestIp: string;
    readonly sourceIngestPort: string;
    constructor(scope: Construct, id: string, props: FlowSourceProps);
}
