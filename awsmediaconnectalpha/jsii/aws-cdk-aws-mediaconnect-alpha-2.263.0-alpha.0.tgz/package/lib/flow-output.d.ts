import type { Duration, IResource } from 'aws-cdk-lib';
import type { IFlowOutputRef } from 'aws-cdk-lib/aws-mediaconnect';
import type { Construct } from 'constructs';
import type { IFlow } from './flow';
import type { SrtPasswordEncryption, StaticKeyEncryption, TransitEncryption, VpcInterfaceConfig } from './shared';
import { State } from './shared';
/**
 * Interface for Flow Output
 */
export interface IFlowOutput extends IResource, IFlowOutputRef {
    /**
     * The Amazon Resource Name (ARN) of the flow output.
     *
     * @attribute
     */
    readonly flowOutputArn: string;
}
/**
 * Properties for flow output
 */
export interface FlowOutputProps {
    /**
     * The name of the output.
     *
     * @default - auto-generated
     */
    readonly flowOutputName?: string;
    /**
     * A description of the output.
     *
     * This description appears only on the MediaConnect console and will not be seen by the end user.
     *
     * @default - no description
     */
    readonly description?: string;
    /**
     * An indication of whether the output should transmit data or not.
     *
     * @default - undefined; when omitted, MediaConnect enables the output (ENABLED) at deploy time
     */
    readonly outputStatus?: State;
    /**
     * The flow this output is attached to.
     */
    readonly flow: IFlow;
    /**
     * Output configuration
     */
    readonly output: OutputConfiguration;
}
/**
 * Configuration options for RTP outputs.
 */
export interface RtpOutputConfig {
    /**
     * The smoothing latency for RIST, RTP, and RTP-FEC streams.
     *
     * @default - no smoothing latency
     */
    readonly smoothingLatency?: Duration;
    /**
     * The IP address where you want to send the output.
     */
    readonly destination: string;
    /**
     * The port to use when content is distributed to this output.
     */
    readonly port: number;
    /**
     * The name of the VPC interface attachment to use for this output.
     *
     * @default - no VPC interface attachment
     */
    readonly vpcInterfaceAttachment?: VpcInterfaceConfig;
}
/**
 * Configuration options for RTP-FEC outputs.
 */
export interface RtpFecOutputConfig extends RtpOutputConfig {
}
/**
 * Configuration options for RIST outputs.
 */
export interface RistOutputConfig extends RtpOutputConfig {
}
/**
 * Configuration options for Zixi Pull outputs.
 */
export interface ZixiPullOutputConfig {
    /**
     * The stream ID that you want to use for this transport.
     */
    readonly streamId: string;
    /**
     * The remote ID for the Zixi-pull stream.
     */
    readonly remoteId: string;
    /**
     * The maximum latency for Zixi-based streams.
     */
    readonly maxLatency: Duration;
    /**
     * The range of IP addresses that should be allowed to initiate output requests to this flow.
     * These IP addresses should be in the form of a Classless Inter-Domain Routing (CIDR) block; for example, 10.0.0.0/16.
     *
     * Required by the MediaConnect service for Zixi Pull outputs.
     */
    readonly cidrAllowList: string[];
    /**
     * Static key encryption for this output.
     *
     * @default - no encryption
     */
    readonly encryption?: StaticKeyEncryption;
    /**
     * The VPC interface attachment to use for this output.
     *
     * @default - no VPC interface attachment
     */
    readonly vpcInterfaceAttachment?: VpcInterfaceConfig;
}
/**
 * Configuration options for Zixi Push outputs.
 */
export interface ZixiPushOutputConfig {
    /**
     * The stream ID that you want to use for this transport.
     */
    readonly streamId: string;
    /**
     * The maximum latency for Zixi-based streams.
     */
    readonly maxLatency: Duration;
    /**
     * The range of IP addresses that should be allowed to initiate output requests to this flow.
     * These IP addresses should be in the form of a Classless Inter-Domain Routing (CIDR) block; for example, 10.0.0.0/16.
     *
     * @default - no CIDR allow list
     */
    readonly cidrAllowList?: string[];
    /**
     * Static key encryption for this output.
     *
     * @default - no encryption
     */
    readonly encryption?: StaticKeyEncryption;
    /**
     * The IP address where you want to send the output.
     */
    readonly destination: string;
    /**
     * The port to use when content is distributed to this output.
     */
    readonly port: number;
    /**
     * The VPC interface attachment to use for this output.
     *
     * @default - no VPC interface attachment
     */
    readonly vpcInterfaceAttachment?: VpcInterfaceConfig;
}
/**
 * Configuration options for SRT Caller outputs.
 */
export interface SrtCallerOutputConfig {
    /**
     * The minimum latency in milliseconds for SRT-based streams. The value you set on your
     * MediaConnect output represents the minimal potential latency of that connection. The
     * latency of the stream is set to the higher of the sender's minimum latency and the
     * receiver's minimum latency.
     *
     * @default - no minimum latency
     */
    readonly minLatency?: Duration;
    /**
     * The stream ID that you want to use for this transport.
     *
     * @default - no stream ID
     */
    readonly streamId?: string;
    /**
     * The IP address where you want to send the output.
     */
    readonly destination: string;
    /**
     * The port to use when content is distributed to this output.
     */
    readonly port: number;
    /**
     * SRT password encryption for this output.
     *
     * @default - no encryption
     */
    readonly encryption?: SrtPasswordEncryption;
    /**
     * The VPC interface attachment to use for this output.
     *
     * @default - no VPC interface attachment
     */
    readonly vpcInterfaceAttachment?: VpcInterfaceConfig;
}
/**
 * Configuration options for SRT Listener outputs.
 */
export interface SrtListenerOutputConfig {
    /**
     * The minimum latency in milliseconds for SRT-based streams. The value you set on your
     * MediaConnect output represents the minimal potential latency of that connection. The
     * latency of the stream is set to the higher of the sender's minimum latency and the
     * receiver's minimum latency.
     *
     * @default - no minimum latency
     */
    readonly minLatency?: Duration;
    /**
     * The port to use when content is distributed to this output.
     */
    readonly port: number;
    /**
     * The range of IP addresses that should be allowed to initiate output requests to this flow.
     * These IP addresses should be in the form of a Classless Inter-Domain Routing (CIDR) block; for example, 10.0.0.0/16.
     *
     * @default - no CIDR allow list
     */
    readonly cidrAllowList?: string[];
    /**
     * SRT password encryption for this output.
     *
     * @default - no encryption
     */
    readonly encryption?: SrtPasswordEncryption;
    /**
     * The VPC interface attachment to use for this output.
     *
     * @default - no VPC interface attachment
     */
    readonly vpcInterfaceAttachment?: VpcInterfaceConfig;
}
/**
 * Configuration options for NDI outputs.
 */
export interface NdiOutputConfig {
    /**
     * A suffix for the names of the NDI sources that the flow creates.
     *
     * @default - the output name is used
     */
    readonly ndiProgramName?: string;
    /**
     * A quality setting for the NDI Speed HQ encoder, expressed as a percentage.
     *
     * Valid range: 100-200. Higher values produce higher quality and larger bitrate.
     *
     * @see https://aws.amazon.com/about-aws/whats-new/2025/03/aws-elemental-mediaconnect-support-ndi-outputs/
     * @default - the MediaConnect service default
     */
    readonly ndiSpeedHqQuality?: number;
}
/**
 * Output configuration to Router
 */
export interface RouterTransitConfig {
    /**
     * Specifies whether encryption is to be used.
     *
     * @default no encryption
     */
    readonly encryption?: TransitEncryption;
}
/**
 * Configuration options to define a FlowOutput by protocol.
 */
export declare class OutputConfiguration {
    private readonly _output;
    /**
     * The source configuration for flows receiving a stream from router.
     */
    static router(input?: RouterTransitConfig): OutputConfiguration;
    /**
     * Option for RTP configuration
     */
    static rtp(input: RtpOutputConfig): OutputConfiguration;
    /**
     * Option for RTP-FEC configuration
     */
    static rtpFec(input: RtpFecOutputConfig): OutputConfiguration;
    /**
     * Option for RIST configuration
     */
    static rist(input: RistOutputConfig): OutputConfiguration;
    /**
     * Option for Zixi Push configuration
     */
    static zixiPush(input: ZixiPushOutputConfig): OutputConfiguration;
    /**
     * Option for Zixi Pull configuration
     */
    static zixiPull(input: ZixiPullOutputConfig): OutputConfiguration;
    /**
     * Option for SRT Caller configuration
     */
    static srtCaller(input: SrtCallerOutputConfig): OutputConfiguration;
    /**
     * Option for SRT Listener configuration
     */
    static srtListener(input: SrtListenerOutputConfig): OutputConfiguration;
    /**
     * Option for NDI configuration
     */
    static ndi(input?: NdiOutputConfig): OutputConfiguration;
    /**
     * @param output - Configuration for outputs in output
     */
    private constructor();
}
/**
 * Resource defines the destination address, protocol, and port that
 * AWS Elemental MediaConnect sends the ingested video to.
 */
export declare class FlowOutput extends FlowOutputBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Creates a Flow Ouput construct that represents an external (imported) Flow Output.
     */
    static fromFlowOutputArn(scope: Construct, id: string, flowOutputArn: string): IFlowOutput;
    readonly flowOutputArn: string;
    constructor(scope: Construct, id: string, props: FlowOutputProps);
}
