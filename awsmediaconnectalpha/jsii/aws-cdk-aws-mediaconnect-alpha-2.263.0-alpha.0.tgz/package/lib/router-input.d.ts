import type { Bitrate, IResource } from 'aws-cdk-lib';
import { Duration, Resource } from 'aws-cdk-lib';
import type { MetricOptions } from 'aws-cdk-lib/aws-cloudwatch';
import { Metric } from 'aws-cdk-lib/aws-cloudwatch';
import type { IRouterInputRef, RouterInputReference } from 'aws-cdk-lib/aws-mediaconnect';
import type { ISecret } from 'aws-cdk-lib/aws-secretsmanager';
import type { Construct } from 'constructs';
import type { IFlow } from './flow';
import type { IFlowOutput } from './flow-output';
import { RouterInputGrants } from './mediaconnect-grants.generated';
import type { IRouterNetworkInterface } from './router-network-interface';
import type { MaintenanceDay, MediaLivePipeline, RouterSrtEncryption, TransitEncryption } from './shared';
/**
 * Protocol options available for Router Input configurations
 */
export declare class RouterInputProtocolOptions {
    readonly value: string;
    /** Real-time Transport Protocol */
    static readonly RTP: RouterInputProtocolOptions;
    /** Reliable Internet Stream Transport */
    static readonly RIST: RouterInputProtocolOptions;
    /** Secure Reliable Transport - Caller mode */
    static readonly SRT_CALLER: RouterInputProtocolOptions;
    /** Secure Reliable Transport - Listener mode */
    static readonly SRT_LISTENER: RouterInputProtocolOptions;
    /**
     * Use a custom protocol value
     * @param value The protocol string value
     */
    static of(value: string): RouterInputProtocolOptions;
    /** @param value The protocol string value */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * A single ingest endpoint where the router input listens for upstream content.
 *
 * Failover and merge configurations expose two endpoints; standard configurations
 * expose one. Returned by {@link IRouterInput.endpoints}.
 */
export interface RouterInputEndpoint {
    /**
     * The full ingest URL combining protocol scheme, IP, and port. For example:
     * `srt://203.0.113.10:5000` or `rtp://203.0.113.10:5001`.
     */
    readonly url: string;
    /**
     * The listening port at which the router input accepts upstream content.
     */
    readonly port: number;
}
/**
 * Interface for Router Input
 */
export interface IRouterInput extends IResource, IRouterInputRef {
    /**
     * The Amazon Resource Name (ARN) of the router input.
     *
     * @attribute
     */
    readonly routerInputArn: string;
    /**
     * The unique identifier of the router input.
     *
     * @attribute
     */
    readonly routerInputId: string;
    /**
     * The IP address of the router input.
     *
     * @attribute
     */
    readonly ipAddress: string;
    /**
     * The timestamp when the router input was created.
     *
     * @attribute
     */
    readonly createdAt?: string;
    /**
     * The timestamp when the router input was last updated.
     *
     * @attribute
     */
    readonly updatedAt?: string;
    /**
     * The ingest endpoints (URL + port) where the router input listens.
     *
     * Returns one entry for standard protocol-based variants (RTP, RIST, SRT listener),
     * and one entry per source for failover and merge configurations built from those
     * protocols. For example a failover RTP input will return:
     *
     * ```
     * [
     *   { url: 'rtp://203.0.113.10:5000', port: 5000 },
     *   { url: 'rtp://203.0.113.10:5001', port: 5001 },
     * ]
     * ```
     *
     * Accessing this on SRT caller (where the router input dials out to a remote
     * source), MediaConnect Flow, MediaLive Channel, or imported inputs throws — those
     * variants do not expose host:port pairs the input listens on.
     */
    readonly endpoints: RouterInputEndpoint[];
    /**
     * The Secrets Manager secret containing the transit encryption passphrase.
     *
     * Only available when the Router Input was created with explicit
     * `transitEncryption` configuration. Not available for
     * automatic encryption or imported inputs.
     */
    readonly transitEncryptionSecret?: ISecret;
    /**
     * Collection of grant methods for this router input.
     */
    readonly grants: RouterInputGrants;
    /**
     * Create a CloudWatch metric for this router input.
     *
     * Router input metrics are dimensioned by `RouterInputARN`. See the MediaConnect
     * documentation for available metric names (e.g. `RouterInputBitRate`,
     * `RouterInputNotRecoveredPackets`).
     */
    metric(metricName: string, props?: MetricOptions): Metric;
    /**
     * Metric for the bitrate of the router input's payload.
     * @default - average over 60 seconds
     */
    metricBitrate(props?: MetricOptions): Metric;
    /**
     * Metric for packets lost in transit that were not recovered by error correction.
     * @default - sum over 60 seconds
     */
    metricNotRecoveredPackets(props?: MetricOptions): Metric;
    /**
     * Metric for the total number of packets received by the router input.
     * @default - sum over 60 seconds
     */
    metricTotalPackets(props?: MetricOptions): Metric;
    /**
     * Metric for the router input connection state (1 connected, 0 disconnected). Applies to SRT sources only.
     * @default - minimum over 60 seconds
     */
    metricConnected(props?: MetricOptions): Metric;
    /**
     * Metric for continuity counter errors in the transport stream.
     * @default - sum over 60 seconds
     */
    metricContinuityCounterErrors(props?: MetricOptions): Metric;
    /**
     * Metric for the recovery latency of the input stream. Applies to RIST, SRT, and RTP-FEC.
     * @default - average over 60 seconds
     */
    metricLatency(props?: MetricOptions): Metric;
    /**
     * Metric for the number of times the router input has switched sources in Failover mode.
     * @default - sum over 60 seconds
     */
    metricFailoverSwitches(props?: MetricOptions): Metric;
}
/**
 * Routing scope for the Router Input
 */
export declare class RoutingScope {
    readonly value: string;
    /** Route traffic within the same AWS region */
    static readonly REGIONAL: RoutingScope;
    /** Route traffic globally across AWS regions */
    static readonly GLOBAL: RoutingScope;
    /**
     * Use a custom routing scope value
     * @param value The routing scope string value
     */
    static of(value: string): RoutingScope;
    /** @param value The routing scope string value */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Routing tier based on your maximum bitrate requirements.
 */
export declare class RouterInputTier {
    readonly value: string;
    /** Supports a maximum bitrate up to 100 megabits per second. */
    static readonly INPUT_100: RouterInputTier;
    /** Supports a maximum bitrate up to 50 megabits per second. */
    static readonly INPUT_50: RouterInputTier;
    /** Supports a maximum bitrate up to 20 megabits per second. */
    static readonly INPUT_20: RouterInputTier;
    /**
     * Use a custom tier value
     * @param value The tier string value
     */
    static of(value: string): RouterInputTier;
    /** @param value The tier string value */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Configuration for scheduled maintenance windows
 */
export interface MaintenanceConfiguration {
    /** Day of the week for maintenance (e.g., 'Monday', 'Tuesday') */
    readonly day: MaintenanceDay;
    /** Time of day for maintenance in HH:MM format (e.g., '02:00') */
    readonly time: string;
}
/**
 * Properties for creating a Router Input
 */
export interface RouterInputProps {
    /**
     * Name of the Router Input
     * @default - Generated automatically
     */
    readonly routerInputName?: string;
    /** Maximum bitrate in bits per second that the Router Input can handle */
    readonly maximumBitrate: Bitrate;
    /** Routing scope for the Router Input */
    readonly routingScope: RoutingScope;
    /**
     * Select a tier based on your maximum bitrate requirements.
     *
     * @default RouterInputTier.INPUT_20
     */
    readonly tier?: RouterInputTier;
    /** Configuration for the Router Input (standard, failover, merge, or MediaConnect flow) */
    readonly configuration: RouterInputConfiguration;
    /**
     * Maintenance window configuration
     * @default - Default maintenance window will be used
     */
    readonly maintenanceConfiguration?: MaintenanceConfiguration;
    /**
     * AWS region where the Router Input will be created (i.e. us-east-1).
     *
     * Must match the region of the flows, flow outputs, and network interfaces it connects to —
     * MediaConnect rejects a cross-region connection at deploy.
     *
     * @default - Same as the stack's region
     */
    readonly regionName?: string;
    /**
     * Tags to add to the Router Input
     * @default - No tagging
     */
    readonly tags?: {
        [key: string]: string;
    };
    /**
     * Transit encryption configuration using AWS Secrets Manager.
     *
     * When provided without a role, a scoped IAM role is automatically created with read
     * access to the secret.
     *
     * @default - Automatic encryption will be configured
     */
    readonly transitEncryption?: TransitEncryption;
}
/**
 * Attributes for importing an existing Router Input.
 */
export interface RouterInputAttributes {
    /**
     * The Amazon Resource Name (ARN) of the router input.
     */
    readonly routerInputArn: string;
    /**
     * The unique identifier of the router input.
     *
     * @default - accessing `routerInputId` on the imported input throws; only provide when available.
     */
    readonly routerInputId?: string;
    /**
     * The IP address that the router input uses to ingest content.
     *
     * @default - accessing `ipAddress` on the imported input throws; only provide when available.
     */
    readonly ipAddress?: string;
}
/**
 * Forward Error Correction (FEC) options for RTP protocol
 */
export declare enum ForwardErrorCorrection {
    /** Enable Forward Error Correction */
    ENABLED = "ENABLED",
    /** Disable Forward Error Correction */
    DISABLED = "DISABLED"
}
/**
 * Identifies which protocol in a failover configuration's protocols array is primary.
 */
export declare enum PrimarySource {
    /** The first protocol in the failover protocols array. */
    FIRST_SOURCE = 0,
    /** The second protocol in the failover protocols array. */
    SECOND_SOURCE = 1
}
/**
 * Source priority configuration for failover Router Input configurations.
 */
export declare class SourcePriorityConfig {
    private readonly _mode;
    private readonly _primary;
    /**
     * Treat both sources with equal priority — MediaConnect picks one when needed.
     */
    static none(): SourcePriorityConfig;
    /**
     * Designate one of the two sources as primary; the other is treated as backup.
     */
    static primarySecondary(primary: PrimarySource): SourcePriorityConfig;
    private constructor();
}
/**
 * Properties for RTP protocol configuration
 */
export interface RtpProtocolProps {
    /** Port number for RTP traffic */
    readonly port: number;
    /**
     * Forward Error Correction setting
     * @default - undefined; when omitted, MediaConnect applies ForwardErrorCorrection.DISABLED at deploy time
     */
    readonly forwardErrorCorrection?: ForwardErrorCorrection;
}
/**
 * Properties for RIST protocol configuration
 */
export interface RistProtocolProps {
    /** Port number for RIST traffic */
    readonly port: number;
    /** Recovery latency for RIST */
    readonly recoveryLatency: Duration;
}
/**
 * Properties for SRT Listener protocol configuration
 */
export interface SrtListenerProtocolProps {
    /** Port number for SRT listener */
    readonly port: number;
    /** Minimum latency for SRT */
    readonly minimumLatency: Duration;
    /**
     * Optional decryption configuration for encrypted SRT streams
     * @default - No decryption
     */
    readonly decryptionConfiguration?: RouterSrtEncryption;
}
/**
 * Properties for SRT Caller protocol configuration
 */
export interface SrtCallerProtocolProps {
    /** Source IP address to connect to */
    readonly sourceAddress: string;
    /** Source port to connect to */
    readonly sourcePort: number;
    /** Minimum latency for SRT */
    readonly minimumLatency: Duration;
    /**
     * Optional stream ID for SRT connection
     * @default - No stream ID
     */
    readonly streamId?: string;
    /**
     * Optional decryption configuration for encrypted SRT streams
     * @default - No decryption
     */
    readonly decryptionConfiguration?: RouterSrtEncryption;
}
/**
 * Factory class for creating Router Input protocol configurations
 */
export declare class RouterInputProtocol {
    /**
     * Create an RTP protocol configuration
     * @param props RTP protocol properties
     * @returns RouterInputProtocol instance configured for RTP
     */
    static rtp(props: RtpProtocolProps): RouterInputProtocol;
    /**
     * Create a RIST protocol configuration
     * @param props RIST protocol properties
     * @returns RouterInputProtocol instance configured for RIST
     */
    static rist(props: RistProtocolProps): RouterInputProtocol;
    /**
     * Create an SRT Listener protocol configuration
     * @param props SRT Listener protocol properties
     * @returns RouterInputProtocol instance configured for SRT Listener
     */
    static srtListener(props: SrtListenerProtocolProps): RouterInputProtocol;
    /**
     * Create an SRT Caller protocol configuration
     * @param props SRT Caller protocol properties
     * @returns RouterInputProtocol instance configured for SRT Caller
     */
    static srtCaller(props: SrtCallerProtocolProps): RouterInputProtocol;
    /**
     * Validate that port is within the valid range (3000-30000)
     */
    private static validatePort;
    /**
     * Validate that SRT Caller port is within the valid range (0-65535)
     */
    private static validateSrtCallerPort;
    private readonly _protocolName;
    private readonly _config;
    private readonly _port?;
    private readonly _decryption?;
    private constructor();
}
/**
 * Properties for standard Router Input configuration
 */
export interface StandardConfigurationProps {
    /** Network interface for the Router Input */
    readonly networkInterface: IRouterNetworkInterface;
    /** Protocol configuration for the input */
    readonly protocol: RouterInputProtocol;
}
/**
 * Properties for failover Router Input configuration
 */
export interface FailoverConfigurationProps {
    /** Network interface for the Router Input */
    readonly networkInterface: IRouterNetworkInterface;
    /** Array of exactly 2 protocol configurations for failover (must be same protocol type) */
    readonly protocols: RouterInputProtocol[];
    /**
     * Source priority configuration for failover.
     *
     * @default SourcePriorityConfig.none()
     */
    readonly sourcePriority?: SourcePriorityConfig;
}
/**
 * Properties for merge Router Input configuration
 */
export interface MergeConfigurationProps {
    /** Network interface for the Router Input */
    readonly networkInterface: IRouterNetworkInterface;
    /** Array of exactly 2 protocol configurations for merge (must be same non-SRT protocol type) */
    readonly protocols: RouterInputProtocol[];
    /** Recovery window for merge operation */
    readonly mergeRecoveryWindow: Duration;
}
/**
 * Properties for MediaConnect Flow Router Input configuration
 */
export interface MediaConnectFlowConfigurationProps {
    /** The MediaConnect flow to use as input */
    readonly flow: IFlow;
    /** The flow output that feeds this router input */
    readonly flowOutput: IFlowOutput;
    /**
     * Optional transit encryption configuration
     * @default - Automatic encryption will be used
     */
    readonly sourceTransitDecryption?: TransitEncryption;
}
/**
 * Properties for MediaConnect Flow Router Input configuration - without a connection
 */
export interface MediaConnectFlowConfigurationWithoutConnectionProps {
    /**
     * Availability Zone the router input will be placed in.
     */
    readonly availabilityZone: string;
    /**
     * Optional transit encryption configuration
     * @default - Automatic encryption will be used
     */
    readonly sourceTransitDecryption?: TransitEncryption;
}
/**
 * Properties for MediaLive Channel Router Input configuration.
 *
 * Use this when the MediaLive channel already exists and you want to ingest
 * from one of its outputs immediately.
 */
export interface MediaLiveChannelConfigurationProps {
    /**
     * ARN of the MediaLive channel to use as input.
     *
     * Note: This will change to accept a typed MediaLive channel reference
     * when the @aws-cdk/aws-medialive-alpha L2 construct is released.
     */
    readonly mediaLiveChannelArn: string;
    /**
     * The name of the MediaLive channel output to connect to this router input.
     */
    readonly mediaLiveChannelOutputName: string;
    /**
     * The MediaLive pipeline to connect to this router input.
     */
    readonly mediaLivePipelineId: MediaLivePipeline;
    /**
     * Optional transit encryption configuration.
     *
     * @default - Automatic encryption will be used
     */
    readonly sourceTransitDecryption?: TransitEncryption;
}
/**
 * Properties for MediaLive Channel Router Input configuration without a specific channel connection.
 *
 * Use this when you want to set up the router input before the target MediaLive channel exists.
 */
export interface MediaLiveChannelConfigurationWithoutConnectionProps {
    /**
     * Availability Zone the router input will be placed in.
     */
    readonly availabilityZone: string;
    /**
     * Optional transit encryption configuration.
     *
     * @default - Automatic encryption will be used
     */
    readonly sourceTransitDecryption?: TransitEncryption;
}
/**
 * Factory class for creating Router Input configurations
 */
export declare abstract class RouterInputConfiguration {
    /**
     * Create a standard Router Input configuration with a single protocol
     * @param props Standard configuration properties
     * @returns RouterInputConfiguration instance for standard setup
     */
    static standard(props: StandardConfigurationProps): RouterInputConfiguration;
    /**
     * Create a failover Router Input configuration with two matching protocols
     * @param props Failover configuration properties
     * @returns RouterInputConfiguration instance for failover setup
     * @throws Error if protocols don't match or count is not exactly 2
     */
    static failover(props: FailoverConfigurationProps): RouterInputConfiguration;
    /**
     * Create a merge Router Input configuration with two matching non-SRT protocols
     * @param props Merge configuration properties
     * @returns RouterInputConfiguration instance for merge setup
     * @throws Error if protocols don't match, count is not exactly 2, or SRT protocols are used
     */
    static merge(props: MergeConfigurationProps): RouterInputConfiguration;
    /**
     * Create a MediaConnect Flow Router Input configuration without connecting to a specific flow
     * Use this when you want to prepare the router input for a flow connection later
     * @param props MediaConnect Flow configuration properties without connection
     * @returns RouterInputConfiguration instance for MediaConnect Flow setup without connection
     */
    static mediaConnectFlowWithoutConnection(props: MediaConnectFlowConfigurationWithoutConnectionProps): RouterInputConfiguration;
    /**
     * Create a MediaConnect Flow Router Input configuration.
     *
     * Use this when the source flow already exists and you want to connect immediately.
     *
     * @param props MediaConnect Flow configuration properties
     * @returns RouterInputConfiguration instance for MediaConnect Flow setup
     */
    static mediaConnectFlow(props: MediaConnectFlowConfigurationProps): RouterInputConfiguration;
    /**
     * Create a MediaLive Channel Router Input configuration.
     *
     * Use this when the source MediaLive channel already exists and you want to
     * ingest from one of its outputs immediately.
     *
     * @param props MediaLive channel configuration properties
     * @returns RouterInputConfiguration instance for MediaLive channel setup
     */
    static mediaLiveChannel(props: MediaLiveChannelConfigurationProps): RouterInputConfiguration;
    /**
     * Create a MediaLive Channel Router Input configuration without a specific channel connection.
     *
     * Use this when you want to set up the router input before the target MediaLive channel exists.
     *
     * @param props MediaLive channel no-connection properties
     * @returns RouterInputConfiguration instance for MediaLive channel setup without connection
     */
    static mediaLiveChannelWithoutConnection(props: MediaLiveChannelConfigurationWithoutConnectionProps): RouterInputConfiguration;
}
/**
 * A MediaConnect Router Input that receives media streams and routes them to outputs.
 *
 * Router Inputs support multiple configuration types:
 * - Standard: Single protocol input
 * - Failover: Two matching protocols for redundancy
 * - Merge: Two matching non-SRT protocols for stream merging
 * - MediaConnect Flow: Input from an existing MediaConnect Flow
 */
declare abstract class RouterInputBase extends Resource implements IRouterInput {
    abstract readonly routerInputArn: string;
    abstract readonly routerInputId: string;
    abstract readonly ipAddress: string;
    abstract readonly createdAt?: string;
    abstract readonly updatedAt?: string;
    abstract readonly endpoints: RouterInputEndpoint[];
    abstract readonly transitEncryptionSecret?: ISecret;
    abstract readonly grants: RouterInputGrants;
    /**
     * A reference to this Router Input resource.
     * Required by the auto-generated IRouterInputRef interface.
     */
    get routerInputRef(): RouterInputReference;
    /**
     * Create a CloudWatch metric for this router input.
     */
    metric(metricName: string, props?: MetricOptions): Metric;
    /**
     * Metric for the bitrate of the router input's payload.
     */
    metricBitrate(props?: MetricOptions): Metric;
    /**
     * Metric for packets lost in transit that were not recovered by error correction.
     */
    metricNotRecoveredPackets(props?: MetricOptions): Metric;
    /**
     * Metric for the total number of packets received by the router input.
     */
    metricTotalPackets(props?: MetricOptions): Metric;
    /**
     * Metric for the router input connection state (1 connected, 0 disconnected). Applies to SRT sources only.
     */
    metricConnected(props?: MetricOptions): Metric;
    /**
     * Metric for continuity counter errors in the transport stream.
     */
    metricContinuityCounterErrors(props?: MetricOptions): Metric;
    /**
     * Metric for the recovery latency of the input stream. Applies to RIST, SRT, and RTP-FEC.
     */
    metricLatency(props?: MetricOptions): Metric;
    /**
     * Metric for the number of times the router input has switched sources in Failover mode.
     */
    metricFailoverSwitches(props?: MetricOptions): Metric;
}
/**
 * Defines an AWS Elemental MediaConnect Router Input.
 */
export declare class RouterInput extends RouterInputBase implements IRouterInput {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing Router Input from its ARN.
     *
     * Use `fromRouterInputAttributes()` instead if you need to expose `routerInputId`
     * or `ipAddress` on the imported construct.
     *
     * @param scope The parent construct
     * @param id The construct id
     * @param routerInputArn The ARN of the Router Input
     * @returns A Router Input construct
     */
    static fromRouterInputArn(scope: Construct, id: string, routerInputArn: string): IRouterInput;
    /**
     * Import an existing Router Input from its attributes.
     *
     * Provide `routerInputId` and/or `ipAddress` when importing an input that was deployed
     * externally — otherwise accessing those properties on the imported construct will throw.
     *
     * @param scope The parent construct
     * @param id The construct id
     * @param attrs The Router Input attributes
     * @returns A Router Input construct
     */
    static fromRouterInputAttributes(scope: Construct, id: string, attrs: RouterInputAttributes): IRouterInput;
    /**
     * Returns the maximum bitrate in Mbps for a known tier, or undefined for custom tiers.
     */
    private static tierLimitMbps;
    readonly routerInputArn: string;
    readonly routerInputId: string;
    readonly ipAddress: string;
    readonly createdAt?: string;
    readonly updatedAt?: string;
    private readonly _endpoints;
    readonly transitEncryptionSecret?: ISecret;
    readonly grants: RouterInputGrants;
    get endpoints(): RouterInputEndpoint[];
    constructor(scope: Construct, id: string, props: RouterInputProps);
}
export {};
