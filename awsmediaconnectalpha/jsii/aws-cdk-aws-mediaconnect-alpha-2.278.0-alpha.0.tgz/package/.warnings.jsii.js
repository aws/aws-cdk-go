const VALIDATORS = { _aws_cdk_aws_mediaconnect_alpha_MergeFailoverOptions: function _aws_cdk_aws_mediaconnect_alpha_MergeFailoverOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.recoveryWindow))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.recoveryWindow);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MonitoringMetric: function _aws_cdk_aws_mediaconnect_alpha_MonitoringMetric(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.threshold))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.threshold);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SourceMonitoringConfig: function _aws_cdk_aws_mediaconnect_alpha_SourceMonitoringConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.blackFrames))
                module.exports._aws_cdk_aws_mediaconnect_alpha_MonitoringMetric(p.blackFrames);
            if (!visitedObjects.has(p.frozenFrames))
                module.exports._aws_cdk_aws_mediaconnect_alpha_MonitoringMetric(p.frozenFrames);
            if (!visitedObjects.has(p.silentAudio))
                module.exports._aws_cdk_aws_mediaconnect_alpha_MonitoringMetric(p.silentAudio);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_NdiDiscoveryServerConfig: function _aws_cdk_aws_mediaconnect_alpha_NdiDiscoveryServerConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.vpcInterface))
                module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(p.vpcInterface);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_NdiConfig: function _aws_cdk_aws_mediaconnect_alpha_NdiConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.ndiDiscoveryServers != null)
                for (const o of p.ndiDiscoveryServers)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_NdiDiscoveryServerConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_EncodingConfig: function _aws_cdk_aws_mediaconnect_alpha_EncodingConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.videoMaxBitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.videoMaxBitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_FlowProps: function _aws_cdk_aws_mediaconnect_alpha_FlowProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encodingConfig))
                module.exports._aws_cdk_aws_mediaconnect_alpha_EncodingConfig(p.encodingConfig);
            if (p.mediaStreams != null)
                for (const o of p.mediaStreams)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_MediaStream(o);
            if (!visitedObjects.has(p.ndiConfig))
                module.exports._aws_cdk_aws_mediaconnect_alpha_NdiConfig(p.ndiConfig);
            if (!visitedObjects.has(p.sourceMonitoringConfig))
                module.exports._aws_cdk_aws_mediaconnect_alpha_SourceMonitoringConfig(p.sourceMonitoringConfig);
            if (p.vpcInterfaces != null)
                for (const o of p.vpcInterfaces)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaStreamSourceConfigurationJpegXs: function _aws_cdk_aws_mediaconnect_alpha_MediaStreamSourceConfigurationJpegXs(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.inputInterface != null)
                for (const o of p.inputInterface)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SourceRtp: function _aws_cdk_aws_mediaconnect_alpha_SourceRtp(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.maxBitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.maxBitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SourceRist: function _aws_cdk_aws_mediaconnect_alpha_SourceRist(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.maxBitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.maxBitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.maxLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.maxLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SourceSrtListener: function _aws_cdk_aws_mediaconnect_alpha_SourceSrtListener(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_SrtPasswordEncryption(p.decryption);
            if (!visitedObjects.has(p.maxBitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.maxBitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.minLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.minLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SourceSrtCaller: function _aws_cdk_aws_mediaconnect_alpha_SourceSrtCaller(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_SrtPasswordEncryption(p.decryption);
            if (!visitedObjects.has(p.maxBitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.maxBitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.maxLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.maxLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.minLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.minLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.vpcInterface))
                module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(p.vpcInterface);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SourceZixiPush: function _aws_cdk_aws_mediaconnect_alpha_SourceZixiPush(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_StaticKeyEncryption(p.decryption);
            if (!visitedObjects.has(p.maxLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.maxLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SourceCdi: function _aws_cdk_aws_mediaconnect_alpha_SourceCdi(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.mediaStreamSourceConfigurations != null)
                for (const o of p.mediaStreamSourceConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_MediaStreamSourceConfigurationCdi(o);
            if (!visitedObjects.has(p.vpcInterface))
                module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(p.vpcInterface);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SourceJpegXs: function _aws_cdk_aws_mediaconnect_alpha_SourceJpegXs(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.mediaStreamSourceConfigurations != null)
                for (const o of p.mediaStreamSourceConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_MediaStreamSourceConfigurationJpegXs(o);
            if (p.vpcInterface != null)
                for (const o of p.vpcInterface)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_GatewayBridgeSource: function _aws_cdk_aws_mediaconnect_alpha_GatewayBridgeSource(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.vpcInterface))
                module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(p.vpcInterface);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_RouterSource: function _aws_cdk_aws_mediaconnect_alpha_RouterSource(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.decryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_EntitlementSource: function _aws_cdk_aws_mediaconnect_alpha_EntitlementSource(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_StaticKeyEncryption(p.decryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_BridgeFlowSource: function _aws_cdk_aws_mediaconnect_alpha_BridgeFlowSource(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.vpcInterface))
                module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(p.vpcInterface);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_BridgeFlowInput: function _aws_cdk_aws_mediaconnect_alpha_BridgeFlowInput(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.source))
                module.exports._aws_cdk_aws_mediaconnect_alpha_BridgeFlowSource(p.source);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_IngressBridgeConfiguration: function _aws_cdk_aws_mediaconnect_alpha_IngressBridgeConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.maxBitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.maxBitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.networkSources != null)
                for (const o of p.networkSources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_BridgeNetworkInput(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_EgressBridgeConfiguration: function _aws_cdk_aws_mediaconnect_alpha_EgressBridgeConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.flowSources != null)
                for (const o of p.flowSources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_BridgeFlowInput(o);
            if (!visitedObjects.has(p.maxBitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.maxBitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.networkOutputs != null)
                for (const o of p.networkOutputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_BridgeNetworkOutput(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_FlowEntitlementProps: function _aws_cdk_aws_mediaconnect_alpha_FlowEntitlementProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_StaticKeyEncryption(p.encryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_RtpOutputConfig: function _aws_cdk_aws_mediaconnect_alpha_RtpOutputConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.smoothingLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.smoothingLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_RtpFecOutputConfig: function _aws_cdk_aws_mediaconnect_alpha_RtpFecOutputConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.smoothingLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.smoothingLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_RistOutputConfig: function _aws_cdk_aws_mediaconnect_alpha_RistOutputConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.smoothingLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.smoothingLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_ZixiPullOutputConfig: function _aws_cdk_aws_mediaconnect_alpha_ZixiPullOutputConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.maxLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.maxLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.encryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_StaticKeyEncryption(p.encryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_ZixiPushOutputConfig: function _aws_cdk_aws_mediaconnect_alpha_ZixiPushOutputConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.maxLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.maxLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.encryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_StaticKeyEncryption(p.encryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SrtCallerOutputConfig: function _aws_cdk_aws_mediaconnect_alpha_SrtCallerOutputConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_SrtPasswordEncryption(p.encryption);
            if (!visitedObjects.has(p.minLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.minLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SrtListenerOutputConfig: function _aws_cdk_aws_mediaconnect_alpha_SrtListenerOutputConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_SrtPasswordEncryption(p.encryption);
            if (!visitedObjects.has(p.minLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.minLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_RouterTransitConfig: function _aws_cdk_aws_mediaconnect_alpha_RouterTransitConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.encryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig: function _aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.subnet))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISubnet(p.subnet);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_VpcInterfaceDefineProps: function _aws_cdk_aws_mediaconnect_alpha_VpcInterfaceDefineProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.subnet))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISubnet(p.subnet);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_VpcInterfaceFromNetworkInterfacesProps: function _aws_cdk_aws_mediaconnect_alpha_VpcInterfaceFromNetworkInterfacesProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.subnet))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISubnet(p.subnet);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_StaticKeyEncryption: function _aws_cdk_aws_mediaconnect_alpha_StaticKeyEncryption(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.secret))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_secretsmanager_ISecret(p.secret);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SrtPasswordEncryption: function _aws_cdk_aws_mediaconnect_alpha_SrtPasswordEncryption(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.secret))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_secretsmanager_ISecret(p.secret);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_TransitEncryption: function _aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.secret))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_secretsmanager_ISecret(p.secret);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_RouterSrtEncryption: function _aws_cdk_aws_mediaconnect_alpha_RouterSrtEncryption(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.secret))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_secretsmanager_ISecret(p.secret);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_RouterInputProps: function _aws_cdk_aws_mediaconnect_alpha_RouterInputProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.maximumBitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.maximumBitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.transitEncryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.transitEncryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_RistProtocolProps: function _aws_cdk_aws_mediaconnect_alpha_RistProtocolProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.recoveryLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.recoveryLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SrtListenerProtocolProps: function _aws_cdk_aws_mediaconnect_alpha_SrtListenerProtocolProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.minimumLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.minimumLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.decryptionConfiguration))
                module.exports._aws_cdk_aws_mediaconnect_alpha_RouterSrtEncryption(p.decryptionConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SrtCallerProtocolProps: function _aws_cdk_aws_mediaconnect_alpha_SrtCallerProtocolProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.minimumLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.minimumLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.decryptionConfiguration))
                module.exports._aws_cdk_aws_mediaconnect_alpha_RouterSrtEncryption(p.decryptionConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MergeConfigurationProps: function _aws_cdk_aws_mediaconnect_alpha_MergeConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.mergeRecoveryWindow))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.mergeRecoveryWindow);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.protocols != null)
                for (const o of p.protocols)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_RouterInputProtocol(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowConfigurationProps: function _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.sourceTransitDecryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.sourceTransitDecryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowConfigurationWithoutConnectionProps: function _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowConfigurationWithoutConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.sourceTransitDecryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.sourceTransitDecryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaLiveChannelConfigurationProps: function _aws_cdk_aws_mediaconnect_alpha_MediaLiveChannelConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.channel))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_medialive_IChannelRef(p.channel);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.sourceTransitDecryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.sourceTransitDecryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaLiveChannelConfigurationWithoutConnectionProps: function _aws_cdk_aws_mediaconnect_alpha_MediaLiveChannelConfigurationWithoutConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.sourceTransitDecryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.sourceTransitDecryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_VpcNetworkConfigurationProps: function _aws_cdk_aws_mediaconnect_alpha_VpcNetworkConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.subnet))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISubnet(p.subnet);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_RouterOutputProps: function _aws_cdk_aws_mediaconnect_alpha_RouterOutputProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.maximumBitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.maximumBitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SrtListenerOutputProtocolProps: function _aws_cdk_aws_mediaconnect_alpha_SrtListenerOutputProtocolProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.minimumLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.minimumLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.encryptionConfiguration))
                module.exports._aws_cdk_aws_mediaconnect_alpha_RouterSrtEncryption(p.encryptionConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SrtCallerOutputProtocolProps: function _aws_cdk_aws_mediaconnect_alpha_SrtCallerOutputProtocolProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.minimumLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.minimumLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.encryptionConfiguration))
                module.exports._aws_cdk_aws_mediaconnect_alpha_RouterSrtEncryption(p.encryptionConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaLiveInputConnectionProps: function _aws_cdk_aws_mediaconnect_alpha_MediaLiveInputConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.input))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_medialive_IInputRef(p.input);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.destinationTransitEncryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.destinationTransitEncryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaLiveNoInputConnectionProps: function _aws_cdk_aws_mediaconnect_alpha_MediaLiveNoInputConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.destinationTransitEncryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.destinationTransitEncryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowConnectionProps: function _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.destinationTransitEncryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.destinationTransitEncryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowNoConnectionProps: function _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowNoConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.destinationTransitEncryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.destinationTransitEncryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
