import type { Bitrate, Duration } from 'aws-cdk-lib';
import type { IBridge } from './bridge';
import type { MediaStream } from './flow';
import type { IFlowEntitlement } from './flow-entitlement';
import type { IRouterOutput } from './router-output';
import type { SrtPasswordEncryption, StaticKeyEncryption, TransitEncryption, VpcInterfaceConfig } from './shared';
/**
 * Encoding options
 */
export declare class Encoding {
    readonly value: string;
    /**
     * Option for JXSV
     */
    static readonly JXSV: Encoding;
    /**
     * Option for raw
     */
    static readonly RAW: Encoding;
    /**
     * Option for SMPTE-291
     */
    static readonly SMPTE291: Encoding;
    /**
     * Option for PCM
     */
    static readonly PCM: Encoding;
    /**
     * Use a custom encoding value
     * @param value The encoding string value
     */
    static of(value: string): Encoding;
    /**
     * @param value The encoding string value
     */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Defines network configuration for a source — either a public network with a CIDR allowlist, or a VPC interface.
 */
export declare class NetworkConfiguration {
    /**
     * Use a public network with a CIDR allowlist.
     */
    static publicNetwork(allowlistCidr: string): NetworkConfiguration;
    /**
     * Use a VPC interface.
     */
    static vpc(vpcInterface: VpcInterfaceConfig): NetworkConfiguration;
    /**
     * The CIDR allowlist for public internet sources, or undefined if using VPC.
     */
    readonly allowlistCidr?: string;
    /**
     * The VPC interface name, or undefined if using public internet.
     */
    readonly vpcInterfaceName?: string;
    private constructor();
}
/**
 * Options for Media Stream Source Configuration
 */
export interface MediaStreamSourceConfigurationCdi {
    /**
     * The format that was used to encode the data. For ancillary data streams, set the encoding name to smpte291.
     * If the encoding name is smpte291, set the color space to one of the following:
     * BT601, BT709, BT2020, or BT2100. For all other ancillary data streams, set the color space to SDR-NOCOLOR.
     */
    readonly encoding: Encoding;
    /**
     * The name of the media stream.
     */
    readonly mediaStream: MediaStream;
}
/**
 * Options for Media Stream Source Configuration
 */
export interface MediaStreamSourceConfigurationJpegXs {
    /**
     * The format that was used to encode the data. For ancillary data streams, set the encoding name to smpte291.
     * If the encoding name is smpte291, set the color space to one of the following:
     * BT601, BT709, BT2020, or BT2100. For all other ancillary data streams, set the color space to SDR-NOCOLOR.
     */
    readonly encoding: Encoding;
    /**
     * The port that the flow listens on for this incoming media stream.
     */
    readonly port: number;
    /**
     * The VPC interfaces where the media stream comes in from.
     */
    readonly inputInterface: VpcInterfaceConfig[];
    /**
     * The name of the media stream.
     */
    readonly mediaStream: MediaStream;
}
/**
 * Common configuration across all inputs
 */
export interface SourceBase {
    /**
     * The name of the source.
     *
     * @default - a name is generated automatically
     */
    readonly flowSourceName?: string;
    /**
     * A description of the source. This description appears only on the MediaConnect console and will not be seen by the end user.
     *
     * @default - no description
     */
    readonly description?: string;
}
/**
 * Configuration for RTP
 */
export interface SourceRtp extends SourceBase {
    /**
     * The port that the flow will be listening on for incoming content.
     */
    readonly port: number;
    /**
     * The maximum bitrate for RIST, RTP, and RTP-FEC streams.
     *
     * @default - no maximum bitrate
     */
    readonly maxBitrate?: Bitrate;
    /**
     * Defines networking configuration
     */
    readonly network: NetworkConfiguration;
}
/**
 * Configuration for RIST
 */
export interface SourceRist extends SourceBase {
    /**
     * The maximum latency in milliseconds for a RIST or Zixi-based source.
     *
     * @default - undefined; when omitted, MediaConnect applies its service default maximum latency
     */
    readonly maxLatency?: Duration;
    /**
     * The port that the flow will be listening on for incoming content.
     */
    readonly port: number;
    /**
     * The maximum bitrate for RIST, RTP, and RTP-FEC streams.
     *
     * @default - no maximum bitrate
     */
    readonly maxBitrate?: Bitrate;
    /**
     * Defines networking configuration
     */
    readonly network: NetworkConfiguration;
}
/**
 * Configuration for SRT Listener
 */
export interface SourceSrtListener extends SourceBase {
    /**
     * The port that the flow listens on for incoming content.
     *
     * Valid range: 1024–65535. Ports 2077 and 2088 are reserved by MediaConnect for Zixi
     * traffic and cannot be used for SRT Listener.
     */
    readonly port: number;
    /**
     * The maximum bitrate for streams.
     *
     * @default - no maximum bitrate
     */
    readonly maxBitrate?: Bitrate;
    /**
     * Defines networking configuration
     */
    readonly network: NetworkConfiguration;
    /**
     * The minimum latency in milliseconds for SRT-based streams. The value you set on your
     * MediaConnect source represents the minimal potential latency of that connection. The
     * latency of the stream is set to the higher of the sender's minimum latency and the
     * receiver's minimum latency.
     *
     * @default - no minimum latency
     */
    readonly minLatency?: Duration;
    /**
     * SRT Decryption options
     *
     * @default - no decryption
     */
    readonly decryption?: SrtPasswordEncryption;
}
/**
 * Configuration for SRT Caller
 */
export interface SourceSrtCaller extends SourceBase {
    /**
     * Source IP or domain name for SRT-caller protocol.
     */
    readonly sourceListenerAddress: string;
    /**
     * Source port for SRT-caller protocol.
     *
     * Valid range: 1024–65535. Ports 2077 and 2088 are reserved by MediaConnect for Zixi
     * traffic and cannot be used for SRT Caller.
     */
    readonly sourceListenerPort: number;
    /**
     * The maximum bitrate for streams.
     *
     * @default - no maximum bitrate
     */
    readonly maxBitrate?: Bitrate;
    /**
     * The maximum latency in milliseconds for SRT-based streams.
     *
     * @default - no maximum latency
     */
    readonly maxLatency?: Duration;
    /**
     * The minimum latency in milliseconds for SRT-based streams. The value you set on your
     * MediaConnect source represents the minimal potential latency of that connection. The
     * latency of the stream is set to the higher of the sender's minimum latency and the
     * receiver's minimum latency.
     *
     * @default - no minimum latency
     */
    readonly minLatency?: Duration;
    /**
     * The stream ID that you want to use for the transport.
     *
     * @default - no stream ID
     */
    readonly streamId?: string;
    /**
     * Optional VPC interface for the outbound SRT Caller connection. SRT Caller initiates
     * the connection to the configured `sourceListenerAddress` and `sourceListenerPort`,
     * so no CIDR allow list is needed.
     *
     * @default - outbound connection via the public internet; no VPC interface
     */
    readonly vpcInterface?: VpcInterfaceConfig;
    /**
     * SRT Decryption options
     *
     * @default - no decryption
     */
    readonly decryption?: SrtPasswordEncryption;
}
/**
 * Configuration for Zixi Push.
 *
 * No port option is exposed: MediaConnect assigns the Zixi Push ingest port itself —
 * public sources are served on 2088, VPC sources are auto-assigned a port in 2090–2099.
 * The service rejects any user-supplied port value, so the L2 surface doesn't accept one.
 *
 * @see https://docs.aws.amazon.com/mediaconnect/latest/ug/source-ports.html
 */
export interface SourceZixiPush extends SourceBase {
    /**
     * The maximum latency in milliseconds for a Zixi-based source.
     *
     * @default - chosen by MediaConnect
     */
    readonly maxLatency?: Duration;
    /**
     * The stream ID that you want to use for the transport. This parameter applies only to Zixi-based streams.
     *
     * @default - no stream ID
     */
    readonly streamId?: string;
    /**
     * Defines networking configuration
     */
    readonly network: NetworkConfiguration;
    /**
     * Decrypt source with static keys
     *
     * @default - no decryption
     */
    readonly decryption?: StaticKeyEncryption;
}
/**
 * Configuration for CDI
 */
export interface SourceCdi {
    /**
     * The name of the source.
     *
     * @default - a name is generated automatically
     */
    readonly flowSourceName?: string;
    /**
     * The VPC interface attachment to use for this bridge source.
     */
    readonly vpcInterface: VpcInterfaceConfig;
    /**
     * The size of the buffer (in ms) to use to sync incoming source data.
     *
     * Required by the MediaConnect service for CDI sources.
     */
    readonly maxSyncBuffer: number;
    /**
     * The port that the flow will be listening on for incoming content.
     */
    readonly port: number;
    /**
     * The media stream that is associated with the source, and the parameters for that association.
     */
    readonly mediaStreamSourceConfigurations: MediaStreamSourceConfigurationCdi[];
}
/**
 * Configuration for Jpeg XS
 */
export interface SourceJpegXs {
    /**
     * The name of the source.
     *
     * @default - a name is generated automatically
     */
    readonly flowSourceName?: string;
    /**
     * The size of the buffer (in ms) to use to sync incoming source data.
     *
     * @default 100
     */
    readonly maxSyncBuffer?: number;
    /**
     * The media stream that is associated with the source, and the parameters for that association.
     */
    readonly mediaStreamSourceConfigurations: MediaStreamSourceConfigurationJpegXs[];
    /**
     * The VPC interface attachment to use for this bridge source.
     *
     * @default - no VPC interface
     */
    readonly vpcInterface?: VpcInterfaceConfig[];
}
/**
 * Configuration for NDI (SpeedHQ) source.
 *
 * NDI sources are ingested from NDI senders inside your VPC. The flow must be
 * configured with `flowSize: FlowSize.LARGE` and `ndiConfig.ndiState = ENABLED`
 * with at least one NDI discovery server. The VPC connectivity for NDI is
 * configured on the discovery server entries in `NdiConfig`, not on the source
 * itself.
 */
export interface SourceNdi {
    /**
     * The name of the source.
     *
     * @default - a name is generated automatically
     */
    readonly flowSourceName?: string;
    /**
     * A description of the source. This description appears only on the MediaConnect
     * console and will not be seen by the end user.
     *
     * @default - no description
     */
    readonly description?: string;
    /**
     * The exact name of an existing NDI sender that's registered with your discovery
     * server. If included, the format of this name must be `MACHINENAME (ProgramName)`.
     *
     * If not specified, you can select the upstream NDI sender from the console
     * after starting the flow.
     *
     * @default - select the NDI sender after starting the flow
     */
    readonly sourceName?: string;
}
/**
 * Options for Gateway Bridge Source
 */
export interface GatewayBridgeSource {
    /**
     * The bridge feeding this flow.
     */
    readonly bridge: IBridge;
    /**
     * The VPC interface attachment to use for this bridge source.
     *
     * @default - no VPC interface
     */
    readonly vpcInterface?: VpcInterfaceConfig;
}
/**
 * Options for Router Source
 */
export interface RouterSource {
    /**
     * The router output that feeds this flow source.
     *
     * @default - no router output connected
     */
    readonly routerOutput?: IRouterOutput;
    /**
     * Options to decrypt incoming feed
     *
     * @default - no decryption
     */
    readonly decryption?: TransitEncryption;
}
/**
 * Options for Entitlement
 */
export interface EntitlementSource {
    /**
     * The entitlement that allows you to subscribe to content that comes from another AWS account.
     *
     * @remarks Entitlements are always imported from another AWS account using
     * `FlowEntitlement.fromFlowEntitlementArn()`. You cannot create new entitlements
     * in the same stack where you're consuming them.
     */
    readonly entitlement: IFlowEntitlement;
    /**
     * Options to decrypt incoming feed
     *
     * @default - no decryption
     */
    readonly decryption?: StaticKeyEncryption;
}
/**
 * Protocol Options for Sources
 */
export declare class SourceProtocol {
    readonly value: string;
    /**
     * Options for Zixi Push
     */
    static readonly ZIXI_PUSH: SourceProtocol;
    /**
     * Options for RTP-FEC
     */
    static readonly RTP_FEC: SourceProtocol;
    /**
     * Options for RTP
     */
    static readonly RTP: SourceProtocol;
    /**
     * Options for RIST
     */
    static readonly RIST: SourceProtocol;
    /**
     * Options for SRT Listener
     */
    static readonly SRT_LISTENER: SourceProtocol;
    /**
     * Options for SRT Caller
     */
    static readonly SRT_CALLER: SourceProtocol;
    /**
     * Options for 2110
     */
    static readonly JPEGXS: SourceProtocol;
    /**
     * Options for CDI
     */
    static readonly CDI: SourceProtocol;
    /**
     * Options for NDI (SpeedHQ)
     */
    static readonly NDI_SPEED_HQ: SourceProtocol;
    /**
     * Use a custom source protocol value
     * @param value The source protocol string value
     */
    static of(value: string): SourceProtocol;
    /**
     * @param value The source protocol string value
     */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Configurations for sources
 */
export declare class SourceConfiguration {
    private readonly input;
    private readonly staticKeyDecryption?;
    private readonly srtPasswordDecryption?;
    private readonly routerDecryption?;
    /**
     * The source configuration for flows receiving a stream from router.
     */
    static router(input?: RouterSource): SourceConfiguration;
    /**
     * The source configuration for cloud flows receiving a stream from a bridge.
     */
    static gatewayBridge(input: GatewayBridgeSource): SourceConfiguration;
    /**
     * The entitlement that allows you to subscribe to content that comes from another AWS account. The entitlement is set by the
     * content originator and the ARN is generated as part of the originator's flow.
     *
     * @remarks The entitlement must be imported using `FlowEntitlement.fromFlowEntitlementArn()`
     * as entitlements are created by the content originator in a different AWS account.
     */
    static entitlement(input: EntitlementSource): SourceConfiguration;
    /**
     * Source option for RTP input
     */
    static rtp(input: SourceRtp): SourceConfiguration;
    /**
     * Source option for RTP-FEC input
     */
    static rtpFec(input: SourceRtp): SourceConfiguration;
    /**
     * Source option for RIST input
     */
    static rist(input: SourceRist): SourceConfiguration;
    /**
     * Source option for SRT Listener input
     */
    static srtListener(input: SourceSrtListener): SourceConfiguration;
    /**
     * Source option for Zixi Push input
     */
    static zixiPush(input: SourceZixiPush): SourceConfiguration;
    /**
     * Source option for SRT Caller input
     */
    static srtCaller(input: SourceSrtCaller): SourceConfiguration;
    /**
     * Source option for CDI input
     */
    static cdi(input: SourceCdi): SourceConfiguration;
    /**
     * Source option for Jpeg-XS input
     */
    static jpegXs(input: SourceJpegXs): SourceConfiguration;
    /**
     * Source option for NDI (SpeedHQ) input.
     *
     * The flow must be configured with `flowSize: FlowSize.LARGE` and
     * `ndiConfig.ndiState = State.ENABLED` with at least one NDI discovery server.
     */
    static ndi(input: SourceNdi): SourceConfiguration;
    /**
     * The name of this source, if one was set on the configuration.
     */
    readonly flowSourceName?: string;
    /**
     * @param input - CFN-shaped source properties (encryption fields are merged in `_bind`).
     * @param staticKeyDecryption - Optional static-key decryption. Set at most one of
     *   `staticKeyDecryption` / `srtPasswordDecryption`.
     * @param srtPasswordDecryption - Optional SRT-password decryption.
     * @param routerDecryption - Optional transit decryption for router integration.
     */
    private constructor();
    private renderDecryption;
}
