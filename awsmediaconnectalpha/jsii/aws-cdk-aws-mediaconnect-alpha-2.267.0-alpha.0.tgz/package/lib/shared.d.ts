import type { ISecurityGroup, ISubnet } from 'aws-cdk-lib/aws-ec2';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { ISecret } from 'aws-cdk-lib/aws-secretsmanager';
/**
 * Encryption Algorithms used in AWS Elemental MediaConnect
 */
export declare class EncryptionAlgorithm {
    readonly value: string;
    /**
     * Option for AES128
     */
    static readonly AES128: EncryptionAlgorithm;
    /**
     * Option for AES192
     */
    static readonly AES192: EncryptionAlgorithm;
    /**
     * Option for AES256
     */
    static readonly AES256: EncryptionAlgorithm;
    /**
     * Use a custom encryption algorithm value
     * @param value The encryption algorithm string value
     */
    static of(value: string): EncryptionAlgorithm;
    /**
     * @param value The encryption algorithm string value
     */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Key types used across AWS Elemental MediaConnect
 */
export declare class KeyType {
    readonly value: string;
    /**
     * Option for Static Key
     */
    static readonly STATIC_KEY: KeyType;
    /**
     * Option for SRT Password
     */
    static readonly SRT_PASSWORD: KeyType;
    /**
     * Use a custom key type value
     * @param value The key type string value
     */
    static of(value: string): KeyType;
    /**
     * @param value The key type string value
     */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * State configuration used across AWS Elemental MediaConnect
 */
export declare enum State {
    /**
     * Option for Enabled
     */
    ENABLED = "ENABLED",
    /**
     * Option for Disabled
     */
    DISABLED = "DISABLED"
}
/**
 * Days of the week for scheduled maintenance windows.
 *
 * Used by both Flow and Router maintenance configurations.
 */
export declare enum MaintenanceDay {
    /** Monday */
    MONDAY = "MONDAY",
    /** Tuesday */
    TUESDAY = "TUESDAY",
    /** Wednesday */
    WEDNESDAY = "WEDNESDAY",
    /** Thursday */
    THURSDAY = "THURSDAY",
    /** Friday */
    FRIDAY = "FRIDAY",
    /** Saturday */
    SATURDAY = "SATURDAY",
    /** Sunday */
    SUNDAY = "SUNDAY"
}
/**
 * Options for bridge network source and output protocols.
 */
export declare class BridgeProtocol {
    readonly value: string;
    /**
     * Option for RTP-FEC
     */
    static readonly RTP_FEC: BridgeProtocol;
    /**
     * Option for RTP
     */
    static readonly RTP: BridgeProtocol;
    /**
     * Option for UDP
     */
    static readonly UDP: BridgeProtocol;
    /**
     * Use a custom bridge protocol value
     * @param value The bridge protocol string value
     */
    static of(value: string): BridgeProtocol;
    /**
     * @param value The bridge protocol string value
     */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Properties for defining a Gateway network.
 */
export interface GatewayNetworkDefineProps {
    /**
     * The name of the network. Used to reference this network from bridge sources
     * and outputs, and must be unique among the networks on the gateway.
     *
     * Maximum 64 characters; alphanumeric, hyphens, and underscores only.
     */
    readonly name: string;
    /**
     * A unique IP address range to use for this network. Must be in CIDR notation
     * (for example, `10.0.0.0/16`).
     */
    readonly cidrBlock: string;
}
/**
 * A network on a MediaConnect Gateway.
 *
 * Use {@link GatewayNetwork.define} to create a network and reference it from
 * gateway, bridge source, and bridge output configurations.
 *
 * @example
 *
 *    const productionNetwork = GatewayNetwork.define({
 *      name: 'production',
 *      cidrBlock: '10.0.0.0/16',
 *    });
 */
export declare class GatewayNetwork {
    /**
     * Define a new gateway network.
     *
     * @param props network properties
     */
    static define(props: GatewayNetworkDefineProps): GatewayNetwork;
    /**
     * The name of the network.
     */
    readonly name: string;
    /**
     * A unique IP address range to use for this network in CIDR notation.
     */
    readonly cidrBlock: string;
    private constructor();
}
/**
 * Bridge network source options
 */
export interface BridgeNetworkSource {
    /**
     * The network source multicast IP.
     *
     * Must be a valid Multicast IP address.
     */
    readonly multicastIp: string;
    /**
     * The setting related to the multicast source.
     *
     * The IP address of the source for source-specific multicast (SSM).
     *
     * @default - no multicast source IP
     */
    readonly multicastSourceIp?: string;
    /**
     * The gateway network this source listens on.
     *
     * Use {@link GatewayNetwork.define} to create the network and pass the same
     * instance to the gateway and to each source that uses it.
     */
    readonly network: GatewayNetwork;
    /**
     * The network source port.
     */
    readonly port: number;
    /**
     * The network source protocol.
     */
    readonly protocol: BridgeProtocol;
}
/**
 * Failover Mode
 */
export declare class FailoverMode {
    readonly value: string;
    /**
     * MERGE combines the source streams into a single stream, allowing graceful
     * recovery from any single-source loss.
     */
    static readonly MERGE: FailoverMode;
    /**
     * FAILOVER allows switching between different streams.
     */
    static readonly FAILOVER: FailoverMode;
    /**
     * Use a custom failover mode value
     * @param value The failover mode string value
     */
    static of(value: string): FailoverMode;
    /**
     * @param value The failover mode string value
     */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * MediaLive pipeline options.
 */
export declare enum MediaLivePipeline {
    /** Pipeline 0 */
    PIPELINE_0 = "PIPELINE_0",
    /** Pipeline 1 */
    PIPELINE_1 = "PIPELINE_1"
}
/**
 * Network interface options
 */
export declare class NetworkInterface {
    readonly value: string;
    /**
     * Option for ENA
     */
    static readonly ENA: NetworkInterface;
    /**
     * Option for EFA.
     * For CDI ensure you use EFA.
     */
    static readonly EFA: NetworkInterface;
    /**
     * Use a custom network interface value
     * @param value The network interface string value
     */
    static of(value: string): NetworkInterface;
    /**
     * @param value The network interface string value
     */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * VPC Interface configuration
 */
export interface VpcInterfaceConfig {
    /**
     * Unique name for this VPC interface within the flow. Cannot be changed after creation.
     */
    readonly name: string;
    /**
     * IDs of the network interfaces. Set this when importing existing ENIs via
     * `VpcInterface.fromNetworkInterfaces()`; leave unset to have MediaConnect create them.
     *
     * @default - MediaConnect creates network interfaces automatically
     */
    readonly networkInterfaceIds?: string[];
    /**
     * The type of network interface. Use `EFA` for CDI workflows.
     *
     * @default - undefined; when omitted, MediaConnect applies NetworkInterface.ENA at deploy time
     */
    readonly networkInterfaceType?: NetworkInterface;
    /**
     * IAM role that MediaConnect assumes to create ENIs in your account.
     */
    readonly role: IRole;
    /**
     * Security groups to apply to the ENI.
     */
    readonly securityGroups: ISecurityGroup[];
    /**
     * Subnet where the ENI is created. Must be in the same Availability Zone as the flow.
     */
    readonly subnet: ISubnet;
}
/**
 * Properties for defining a new VPC Interface configuration
 */
export interface VpcInterfaceDefineProps {
    /**
     * Unique name for this VPC interface within the flow. Cannot be changed after creation.
     */
    readonly vpcInterfaceName: string;
    /**
     * IAM role that MediaConnect assumes to create ENIs in your account.
     */
    readonly role: IRole;
    /**
     * Security groups to apply to the ENI.
     */
    readonly securityGroups: ISecurityGroup[];
    /**
     * Subnet where the ENI is created. Must be in the same Availability Zone as the flow.
     */
    readonly subnet: ISubnet;
    /**
     * The type of network interface. Use `EFA` for CDI workflows.
     *
     * @default - undefined; when omitted, MediaConnect applies NetworkInterface.ENA at deploy time
     */
    readonly networkInterfaceType?: NetworkInterface;
}
/**
 * Properties for creating a VPC Interface from existing network interfaces
 */
export interface VpcInterfaceFromNetworkInterfacesProps {
    /**
     * Unique name for this VPC interface within the flow. Cannot be changed after creation.
     */
    readonly vpcInterfaceName: string;
    /**
     * IAM role that MediaConnect assumes to access the ENIs.
     */
    readonly role: IRole;
    /**
     * Security groups applied to the existing ENIs.
     */
    readonly securityGroups: ISecurityGroup[];
    /**
     * Subnet where the existing ENIs live. Must be in the same Availability Zone as the flow.
     */
    readonly subnet: ISubnet;
    /**
     * IDs of the pre-created network interfaces to reuse.
     */
    readonly networkInterfaceIds: string[];
}
/**
 * Factory class for creating VPC Interface configurations
 */
export declare class VpcInterface {
    /**
     * Define a new VPC Interface configuration. MediaConnect will create network interfaces automatically.
     *
     * @param props VPC Interface properties
     * @returns VpcInterfaceConfig configuration object
     */
    static define(props: VpcInterfaceDefineProps): VpcInterfaceConfig;
    /**
     * Create a VPC Interface configuration using existing network interfaces.
     *
     * @param props VPC Interface properties with existing network interface IDs
     * @returns VpcInterfaceConfig configuration object
     */
    static fromNetworkInterfaces(props: VpcInterfaceFromNetworkInterfacesProps): VpcInterfaceConfig;
}
/**
 * Static key encryption/decryption configuration for Zixi protocol sources and outputs,
 * and flow entitlements.
 *
 * The secret must live in the same AWS account and Region as the resource (source,
 * output, or entitlement) that uses it. MediaConnect does not support cross-account or
 * cross-Region secrets.
 *
 * @see https://docs.aws.amazon.com/mediaconnect/latest/ug/encryption-static-key-set-up.html
 * @see https://docs.aws.amazon.com/mediaconnect/latest/ug/cross-service-confused-deputy-prevention.html
 */
export interface StaticKeyEncryption {
    /**
     * IAM role that MediaConnect assumes to access the Secrets Manager secret.
     *
     * If provided, the role is used as-is; you must grant it the necessary permissions
     * yourself.
     *
     * @default - a scoped role is auto-created with read access to the secret (including
     * `kms:Decrypt` for a customer-managed key) and a confused-deputy trust condition. See
     * the **Encryption** section of the module README for the generated trust policy.
     */
    readonly role?: IRole;
    /**
     * Secrets Manager secret containing the static encryption key.
     */
    readonly secret: ISecret;
    /**
     * The encryption algorithm to use.
     */
    readonly algorithm: EncryptionAlgorithm;
}
/**
 * SRT password encryption/decryption configuration for SRT Listener and SRT Caller
 * sources and outputs on flows.
 *
 * The secret must live in the same AWS account and Region as the resource (source or
 * output) that uses it. MediaConnect does not support cross-account or cross-Region
 * secrets.
 *
 * @see https://docs.aws.amazon.com/mediaconnect/latest/ug/encryption-srt-password-set-up.html
 * @see https://docs.aws.amazon.com/mediaconnect/latest/ug/cross-service-confused-deputy-prevention.html
 */
export interface SrtPasswordEncryption {
    /**
     * IAM role that MediaConnect assumes to access the Secrets Manager secret.
     *
     * If provided, the role is used as-is; you must grant it the necessary permissions
     * yourself.
     *
     * @default - a scoped role is auto-created with read access to the secret and a
     * confused-deputy trust condition. See the **Encryption** section of the module README
     * for the generated trust policy.
     */
    readonly role?: IRole;
    /**
     * Secrets Manager secret containing the SRT passphrase.
     */
    readonly secret: ISecret;
}
/**
 * Transit encryption configuration for router integrations — securing the link between a
 * router and a flow or a MediaLive channel/input. Uses AWS Secrets Manager for key
 * management.
 *
 * The secret must live in the same AWS account and Region as the consuming resource.
 * MediaConnect does not support cross-account or cross-Region secrets.
 *
 * **Trust-policy scope on routers.** Router I/O ids are service-generated (unknown at synth
 * time), and pinning the live ARN would create a CloudFormation dependency cycle — so the
 * auto-created role pins `aws:SourceArn` to a wildcarded ARN (`arn:...:routerInput:*` /
 * `arn:...:routerOutput:*`) plus `aws:SourceAccount`. To pin a tighter trust policy, supply
 * your own `role`.
 *
 * @see https://docs.aws.amazon.com/mediaconnect/latest/ug/cross-service-confused-deputy-prevention.html
 */
export interface TransitEncryption {
    /**
     * IAM role that MediaConnect assumes to access the Secrets Manager secret.
     *
     * If provided, the role is used as-is; you must grant it the necessary permissions
     * yourself.
     *
     * @default - a scoped role is auto-created with read access to the secret and a
     * confused-deputy trust condition. See the **Encryption** section of the module README
     * for the generated trust policy.
     */
    readonly role?: IRole;
    /**
     * Secrets Manager secret containing the transit encryption key.
     */
    readonly secret: ISecret;
}
/**
 * SRT encryption configuration for router inputs and outputs (SRT Listener and SRT
 * Caller). Uses AWS Secrets Manager for key management. Distinct from
 * {@link SrtPasswordEncryption}, which is used for flow sources and outputs.
 *
 * The secret must live in the same AWS account and Region as the router I/O that uses
 * it. MediaConnect does not support cross-account or cross-Region secrets.
 *
 * **Trust-policy scope on routers.** Router I/O ids are service-generated (unknown at synth
 * time), and pinning the live ARN would create a CloudFormation dependency cycle — so the
 * auto-created role pins `aws:SourceArn` to a wildcarded ARN (`arn:...:routerInput:*` /
 * `arn:...:routerOutput:*`) plus `aws:SourceAccount`. To pin a tighter trust policy, supply
 * your own `role`.
 *
 * @see https://docs.aws.amazon.com/mediaconnect/latest/ug/cross-service-confused-deputy-prevention.html
 */
export interface RouterSrtEncryption {
    /**
     * IAM role that MediaConnect assumes to access the Secrets Manager secret.
     *
     * If provided, the role is used as-is; you must grant it the necessary permissions
     * yourself.
     *
     * @default - a scoped role is auto-created with read access to the secret and a
     * confused-deputy trust condition. See the **Encryption** section of the module README
     * for the generated trust policy.
     */
    readonly role?: IRole;
    /**
     * Secrets Manager secret containing the SRT passphrase.
     */
    readonly secret: ISecret;
}
/**
 * A video frame rate expressed as a rational number (numerator/denominator).
 *
 * Use the predefined constants for standard rates, or {@link Framerate.of} for a custom rate.
 */
export declare class Framerate {
    /** 24 fps (cinema) — `24/1`. */
    static readonly FPS_24: Framerate;
    /** 25 fps — `25/1`. */
    static readonly FPS_25: Framerate;
    /** 29.97 fps — `30000/1001`. */
    static readonly FPS_29_97: Framerate;
    /** 30 fps — `30/1`. */
    static readonly FPS_30: Framerate;
    /** 50 fps — `50/1`. */
    static readonly FPS_50: Framerate;
    /** 59.94 fps — `60000/1001`. */
    static readonly FPS_59_94: Framerate;
    /** 60 fps — `60/1`. */
    static readonly FPS_60: Framerate;
    /**
     * Define a custom frame rate.
     *
     * @param numerator Numerator of the rate.
     * @param denominator Denominator of the rate.
     */
    static of(numerator: number, denominator: number): Framerate;
    private constructor();
    /** Returns the string value. */
    toString(): string;
}
/**
 * The pixel aspect ratio (PAR) of the video.
 *
 * Use the predefined constants for standard ratios, or {@link PixelAspectRatio.of} for
 * a custom ratio.
 */
export declare class PixelAspectRatio {
    /** Square pixels (`1:1`). */
    static readonly SQUARE: PixelAspectRatio;
    /**
     * Define a pixel aspect ratio.
     *
     * @param numerator Numerator of the ratio.
     * @param denominator Denominator of the ratio.
     */
    static of(numerator: number, denominator: number): PixelAspectRatio;
    /**
     * @param numerator Numerator of the ratio.
     * @param denominator Denominator of the ratio.
     */
    private constructor();
    /** Returns the string value in `numerator:denominator` form. */
    toString(): string;
}
