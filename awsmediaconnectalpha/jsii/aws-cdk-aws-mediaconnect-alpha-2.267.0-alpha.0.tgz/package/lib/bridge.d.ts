import type { Bitrate, IResource } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { MetricOptions } from 'aws-cdk-lib/aws-cloudwatch';
import { Metric } from 'aws-cdk-lib/aws-cloudwatch';
import type { IBridgeRef, BridgeReference } from 'aws-cdk-lib/aws-mediaconnect';
import type { Construct } from 'constructs';
import type { IBridgeOutput } from './bridge-output';
import type { IFlow } from './flow';
import type { IGateway } from './gateway';
import type { BridgeProtocol, BridgeNetworkSource, GatewayNetwork, VpcInterfaceConfig } from './shared';
import { State } from './shared';
/**
 * The source of the bridge. A flow source originates in MediaConnect as an existing cloud flow.
 */
export interface BridgeFlowSource {
    /**
     * The cloud flow used as a source of this bridge.
     */
    readonly flow: IFlow;
    /**
     * The VPC interface attachment to use for this source.
     *
     * @default - no VPC interface
     */
    readonly vpcInterface?: VpcInterfaceConfig;
}
/**
 * A named flow source for an egress bridge.
 */
export interface BridgeFlowInput {
    /**
     * The name of the flow source. Must be unique among sources on the bridge.
     */
    readonly name: string;
    /**
     * The flow source configuration describing where the bridge consumes content from.
     */
    readonly source: BridgeFlowSource;
}
/**
 * A named network source for an ingress bridge.
 */
export interface BridgeNetworkInput {
    /**
     * The name of the network source. Must be unique among sources on the bridge.
     */
    readonly name: string;
    /**
     * The network source configuration describing the multicast endpoint the bridge listens to.
     */
    readonly source: BridgeNetworkSource;
}
/**
 * Configuration of bridge type
 */
export declare class BridgeType {
    readonly value: string;
    /**
     * Ingress Bridge
     */
    static readonly INGRESS_BRIDGE: BridgeType;
    /**
     * Egress Bridge
     */
    static readonly EGRESS_BRIDGE: BridgeType;
    /**
     * Use a custom bridge type value
     * @param value The bridge type string value
     */
    static of(value: string): BridgeType;
    /** @param value The bridge type string value */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Base bridge configuration properties
 */
interface BridgeConfigurationBase {
    /**
     * The maximum expected bitrate (in bps) of the bridge.
     */
    readonly maxBitrate: Bitrate;
}
/**
 * Ingress bridge configuration
 */
export interface IngressBridgeConfiguration extends BridgeConfigurationBase {
    /**
     * The maximum number of outputs on the ingress bridge.
     */
    readonly maxOutputs: number;
    /**
     * The network sources for the ingress bridge.
     */
    readonly networkSources: BridgeNetworkInput[];
}
/**
 * Egress bridge configuration
 */
export interface EgressBridgeConfiguration extends BridgeConfigurationBase {
    /**
     * The flow sources for the egress bridge.
     */
    readonly flowSources: BridgeFlowInput[];
    /**
     * The network outputs for the egress bridge.
     */
    readonly networkOutputs: BridgeNetworkOutput[];
}
/**
 * Interface for Bridge
 */
export interface IBridge extends IResource, IBridgeRef {
    /**
     * The Amazon Resource Name (ARN) of the bridge.
     *
     * @attribute
     */
    readonly bridgeArn: string;
    /**
     * The name of the bridge.
     *
     * @attribute
     */
    readonly bridgeName: string;
    /**
     * The type of bridge (ingress or egress).
     *
     * @attribute
     */
    readonly bridgeType: BridgeType;
    /**
     * The current state of the bridge.
     *
     * @attribute
     */
    readonly bridgeState?: string;
    /**
     * Failover Configuration for Bridge
     */
    readonly isFailoverEnabled?: boolean;
    /**
     * Add a network output to this bridge (for egress bridges only).
     *
     * @param id Construct id for the new BridgeOutput
     * @param networkOutput The named output to add. The `name` is the output's identity on the bridge and must be unique among outputs.
     */
    addOutput(id: string, networkOutput: BridgeNetworkOutput): IBridgeOutput;
    /**
     * Create a CloudWatch metric for this bridge.
     *
     * Bridge metrics are dimensioned by `BridgeARN`. See the MediaConnect
     * documentation for available metric names (e.g. `IngressBridgeBitRate`,
     * `EgressBridgeBitRate`, `IngressBridgePacketLossPercent`).
     */
    metric(metricName: string, props?: MetricOptions): Metric;
    /**
     * Metric for the bitrate of a specific bridge source.
     *
     * Uses `IngressBridgeSourceBitRate` for ingress bridges and
     * `EgressBridgeSourceBitRate` for egress bridges.
     *
     * @param bridgeSourceName The name of the bridge source
     * @default - average over 60 seconds
     */
    metricSourceBitrate(bridgeSourceName: string, props?: MetricOptions): Metric;
    /**
     * Metric for the percentage of packets lost on a specific bridge source.
     *
     * Uses `IngressBridgeSourcePacketLossPercent` for ingress bridges and
     * `EgressBridgeSourcePacketLossPercent` for egress bridges.
     *
     * @param bridgeSourceName The name of the bridge source
     * @default - average over 60 seconds
     */
    metricSourcePacketLossPercent(bridgeSourceName: string, props?: MetricOptions): Metric;
    /**
     * Metric for the total number of times the bridge switches between sources
     * when using the `FAILOVER` failover mode.
     *
     * Uses `IngressBridgeFailoverSwitches` for ingress bridges and
     * `EgressBridgeFailoverSwitches` for egress bridges.
     *
     * @default - sum over 60 seconds
     */
    metricFailoverSwitches(props?: MetricOptions): Metric;
}
/**
 * Properties for a bridge network output.
 */
export interface BridgeNetworkOutputProps {
    /**
     * The IP address where the output will send content.
     */
    readonly ipAddress: string;
    /**
     * The port to use for the output.
     */
    readonly port: number;
    /**
     * The gateway network this output sends content out of.
     *
     * Use {@link GatewayNetwork.define} to create the network and pass the same
     * instance to the gateway and to each output that uses it.
     */
    readonly network: GatewayNetwork;
    /**
     * The protocol to use for the output.
     */
    readonly protocol: BridgeProtocol;
    /**
     * Time to live (TTL) for the output packets in hops (1-255).
     *
     * TTL represents the maximum number of network hops a packet can traverse
     * before being discarded.
     */
    readonly ttl: number;
}
/**
 * A named network output for an egress bridge.
 */
export interface BridgeNetworkOutput {
    /**
     * The name of the network output. Must be unique among outputs on the bridge.
     *
     * Used as the physical name of the underlying CFN resource.
     */
    readonly name: string;
    /**
     * The network configuration describing where this output sends content.
     */
    readonly output: BridgeOutputConfiguration;
}
/**
 * Configuration for a bridge output.
 */
export declare class BridgeOutputConfiguration {
    private readonly _network;
    /**
     * Create a network output configuration for a bridge.
     */
    static network(props: BridgeNetworkOutputProps): BridgeOutputConfiguration;
    private constructor();
}
/**
 * Options for bridge source failover.
 */
export interface BridgeFailoverOptions {
    /**
     * Whether failover is enabled. Set to `State.DISABLED` to keep the configuration
     * on the bridge without switching failover on.
     *
     * @default State.ENABLED
     */
    readonly state?: State;
    /**
     * The name of the source you want to treat as primary. If set, MediaConnect always
     * uses this source when it is available. When unset, both sources are treated with
     * equal priority.
     *
     * @default - both sources are equal priority
     */
    readonly primarySource?: string;
}
/**
 * Source failover configuration for a bridge.
 *
 * Bridges only support `FAILOVER` (switchover) mode — the `MERGE` mode available on
 * `Flow.sourceFailoverConfig` is not allowed on bridges by the service. Use
 * {@link BridgeFailoverConfig.failover} to construct the configuration.
 */
export declare class BridgeFailoverConfig {
    private readonly _state;
    private readonly _primarySource;
    /**
     * Configure switchover-mode failover. The bridge swaps to the backup source when
     * the primary source stops receiving data.
     */
    static failover(options?: BridgeFailoverOptions): BridgeFailoverConfig;
    private constructor();
}
/**
 * Bridge configuration to set ingress and egress options on the bridge
 */
export declare class BridgeConfiguration {
    private readonly _bridgeType;
    private readonly _ingressConfig?;
    private readonly _egressConfig?;
    /**
     * An ingress bridge is a ground-to-cloud bridge. The content originates at your premises and is delivered to the cloud.
     */
    static ingress(config: IngressBridgeConfiguration): BridgeConfiguration;
    /**
     * An egress bridge is a cloud-to-ground bridge. The content comes from an existing MediaConnect flow and is delivered to your premises.
     */
    static egress(config: EgressBridgeConfiguration): BridgeConfiguration;
    private constructor();
}
/**
 * Properties for the Bridge
 */
export interface BridgeProps {
    /**
     * The name of the bridge. Cannot be modified after the bridge is created.
     *
     * @default - autogenerated
     */
    readonly bridgeName?: string;
    /**
     * The bridge configuration specifying ingress or egress settings.
     */
    readonly config: BridgeConfiguration;
    /**
     * The gateway that the bridge is associated with.
     */
    readonly gateway: IGateway;
    /**
     * The source failover configuration for the bridge.
     *
     * @default - No failover configuration
     */
    readonly sourceFailoverConfig?: BridgeFailoverConfig;
}
/**
 * Attributes for importing an existing Bridge.
 */
export interface BridgeAttributes {
    /**
     * The ARN of the bridge.
     */
    readonly bridgeArn: string;
    /**
     * The name of the bridge.
     *
     * Not encoded in the bridge ARN, so must be provided explicitly if the imported
     * bridge needs to expose `bridgeName`.
     *
     * @default - bridgeName is not available on the imported construct
     */
    readonly bridgeName?: string;
    /**
     * Indicates what type of bridge is imported.
     *
     * Not encoded in the bridge ARN, so must be provided explicitly if the imported
     * bridge is used with `addOutput()` or other methods that need the bridge type.
     *
     * @default - bridgeType is not available on the imported construct
     */
    readonly bridgeType?: BridgeType;
    /**
     * Failover Configuration for Bridge
     *
     * @default false
     */
    readonly isFailoverEnabled?: boolean;
}
declare abstract class BridgeBase extends Resource implements IBridge {
    /**
     * Creates a Bridge construct that represents an external (imported) Bridge.
     */
    static fromBridgeAttributes(scope: Construct, id: string, attrs: BridgeAttributes): IBridge;
    /**
     * Import an existing Bridge from its ARN.
     *
     * Use `fromBridgeAttributes()` instead if you need access to `bridgeName`, `bridgeType`
     * (required for `addOutput()`), or `isFailoverEnabled`.
     */
    static fromBridgeArn(scope: Construct, id: string, bridgeArn: string): IBridge;
    abstract readonly bridgeArn: string;
    abstract readonly bridgeName: string;
    abstract readonly bridgeType: BridgeType;
    abstract readonly bridgeState?: string;
    abstract readonly isFailoverEnabled?: boolean;
    /** A reference to this Bridge resource. */
    get bridgeRef(): BridgeReference;
    /**
     * Create a CloudWatch metric for this bridge.
     */
    metric(metricName: string, props?: MetricOptions): Metric;
    /**
     * Metric for the bitrate of a specific bridge source.
     */
    metricSourceBitrate(bridgeSourceName: string, props?: MetricOptions): Metric;
    /**
     * Metric for the percentage of packets lost on a specific bridge source.
     */
    metricSourcePacketLossPercent(bridgeSourceName: string, props?: MetricOptions): Metric;
    /**
     * Metric for the total number of times the bridge switches between sources
     * when using the `FAILOVER` failover mode.
     */
    metricFailoverSwitches(props?: MetricOptions): Metric;
    /**
     * Add a network output to this bridge (for egress bridges only).
     *
     * @param id Construct id for the new BridgeOutput
     * @param networkOutput The named output to add. The `name` is the output's identity on the bridge and must be unique among outputs.
     */
    addOutput(id: string, networkOutput: BridgeNetworkOutput): IBridgeOutput;
}
/**
 * Defines a AWS Elemental MediaConnect Bridge
 */
export declare class Bridge extends BridgeBase implements IBridge {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    readonly bridgeArn: string;
    readonly bridgeName: string;
    readonly bridgeType: BridgeType;
    readonly bridgeState?: string;
    readonly isFailoverEnabled?: boolean;
    constructor(scope: Construct, id: string, props: BridgeProps);
    /**
     * Format bridge flow source into BridgeSourceProperty format
     */
    private formatBridgeFlowSource;
}
export {};
