import type { Bitrate, IResource } from 'aws-cdk-lib';
import { Resource, Duration } from 'aws-cdk-lib';
import type { MetricOptions } from 'aws-cdk-lib/aws-cloudwatch';
import { Metric } from 'aws-cdk-lib/aws-cloudwatch';
import type { IFlowRef, FlowReference } from 'aws-cdk-lib/aws-mediaconnect';
import type { Construct } from 'constructs';
import type { IFlowOutput, OutputConfiguration } from './flow-output';
import type { SourceConfiguration } from './flow-source-configuration';
import { FlowGrants } from './mediaconnect-grants.generated';
import type { VpcInterfaceConfig, MaintenanceDay, Framerate, PixelAspectRatio } from './shared';
import { State } from './shared';
/**
 * Interface for Flow
 */
export interface IFlow extends IResource, IFlowRef {
    /**
     * The Amazon Resource Name (ARN) of the flow.
     *
     * @attribute
     */
    readonly flowArn: string;
    /**
     * The Amazon Resource Name (ARN) of the source defined on the flow.
     *
     * @attribute
     */
    readonly sourceArn: string;
    /**
     * The IP address that the flow uses to send outbound content.
     *
     * @attribute
     */
    readonly egressIp: string;
    /**
     * The IP address that the flow listens on for incoming content.
     *
     * Available for listener-style source protocols (RTP, RTP-FEC, RIST, SRT listener,
     * Zixi push). Accessing this on SRT caller, entitlement, gateway bridge, router,
     * CDI, JPEG XS, or imported flows throws — those sources don't expose a listening
     * IP address.
     *
     * @attribute
     */
    readonly sourceIngestIp: string;
    /**
     * The port that the flow listens on for incoming content.
     *
     * Available for the same listener-style source protocols as `sourceIngestIp`.
     * Accessing this on SRT caller, entitlement, gateway bridge, router, CDI, JPEG XS,
     * or imported flows throws.
     *
     * @attribute
     */
    readonly sourceIngestPort: string;
    /**
     * The full ingest URL for the flow source, combining protocol, IP, and port.
     * For example: `srt://203.0.113.10:5000`
     *
     * Available for listener-style source protocols (RTP, RTP-FEC, RIST, SRT listener,
     * Zixi push) where the flow listens for an upstream sender. Accessing this on
     * SRT caller, entitlement, gateway bridge, router, CDI, JPEG XS, or imported
     * flows throws — those sources don't expose a single host:port ingest URL.
     */
    readonly sourceIngestUrl: string;
    /**
     * The Availability Zone that the flow was created in.
     *
     * @attribute
     */
    readonly flowAvailabilityZone?: string;
    /**
     * Failover Configuration for flow
     */
    readonly isFailoverEnabled?: boolean;
    /**
     * Collection of grant methods for this flow.
     */
    readonly grants: FlowGrants;
    /**
     * Create a CloudWatch metric for this flow.
     */
    metric(metricName: string, props?: MetricOptions): Metric;
    /**
     * Metric for the bitrate of content ingested into the flow.
     * @default - average over 60 seconds
     */
    metricSourceBitrate(props?: MetricOptions): Metric;
    /**
     * Metric for packets that were not recovered by the flow source.
     * @default - sum over 60 seconds
     */
    metricSourceNotRecoveredPackets(props?: MetricOptions): Metric;
    /**
     * Metric for the total number of packets received by the flow source.
     * @default - sum over 60 seconds
     */
    metricSourceTotalPackets(props?: MetricOptions): Metric;
    /**
     * Metric indicating which source is selected for ingest when using `Failover` failover mode.
     * @default - maximum over 60 seconds
     */
    metricSourceSelected(props?: MetricOptions): Metric;
    /**
     * Metric indicating the connection state of the source (1 connected, 0 disconnected).
     * Applies only to Zixi, SRT, and RIST sources.
     * @default - minimum over 60 seconds
     */
    metricSourceConnected(props?: MetricOptions): Metric;
    /**
     * Metric for the number of times the source transitioned from connected to disconnected.
     * @default - sum over 60 seconds
     */
    metricSourceDisconnections(props?: MetricOptions): Metric;
    /**
     * Metric for the number of packets lost during transit, measured before any error correction.
     * @default - sum over 60 seconds
     */
    metricSourceDroppedPackets(props?: MetricOptions): Metric;
    /**
     * Metric for the percentage of packets lost during transit, even if they were recovered.
     * @default - average over 60 seconds
     */
    metricSourcePacketLossPercent(props?: MetricOptions): Metric;
    /**
     * Metric for the round-trip time between the source and MediaConnect.
     * Applies only to RIST, Zixi, and SRT sources.
     * @default - average over 60 seconds
     */
    metricSourceRoundTripTime(props?: MetricOptions): Metric;
    /**
     * Metric for the current network jitter of the source, measured in milliseconds.
     * @default - average over 60 seconds
     */
    metricSourceJitter(props?: MetricOptions): Metric;
    /**
     * Add an output to this flow
     */
    addOutput(id: string, options: AddFlowOutputOptions): IFlowOutput;
}
/**
 * Options for adding an output to a flow.
 */
export interface AddFlowOutputOptions {
    /**
     * The output configuration.
     */
    readonly output: OutputConfiguration;
    /**
     * The name of the flow output.
     * @default - auto-generated
     */
    readonly flowOutputName?: string;
    /**
     * A description of the output.
     * @default - no description
     */
    readonly description?: string;
    /**
     * Whether the output is enabled.
     * @default State.ENABLED
     */
    readonly outputStatus?: State;
}
/**
 * Options for Flow Size
 */
export declare class FlowSize {
    readonly value: string;
    /**
     * Medium flow size. The default — standard transport stream distribution; does not
     * support NDI, CDI, or JPEG XS.
     *
     * @see https://docs.aws.amazon.com/mediaconnect/latest/ug/flow-sizes-capabilities.html
     */
    static readonly MEDIUM: FlowSize;
    /**
     * Large flow size. Required when the flow uses NDI sources or outputs. Supports
     * transport stream distribution plus NDI; does not support CDI or JPEG XS.
     *
     * @see https://docs.aws.amazon.com/mediaconnect/latest/ug/flow-sizes-capabilities.html
     */
    static readonly LARGE: FlowSize;
    /**
     * Option for large 4x flow size. Required for JPEG XS and CDI protocols. Does not support transport streams or NDI.
     */
    static readonly LARGE_4X: FlowSize;
    /**
     * Use a custom flow size value
     * @param value The flow size string value
     */
    static of(value: string): FlowSize;
    /** @param value The flow size string value */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Configuration for scheduled maintenance windows.
 */
export interface MaintenanceWindow {
    /** A day of a week when the maintenance will happen. */
    readonly day: MaintenanceDay;
    /** The maintenance start time in UTC, 24-hour HH:MM format. Minutes must be 00 (e.g., '02:00', '13:00'). */
    readonly time: string;
}
/**
 * Options for merge-mode source failover.
 */
export interface MergeFailoverOptions {
    /**
     * Whether failover is enabled. Set to `State.DISABLED` to keep the configuration
     * on the flow without switching failover on.
     *
     * @default State.ENABLED
     */
    readonly state?: State;
    /**
     * Search window time to look for SMPTE 2022-7 packets. A larger recovery window
     * means a longer delay in transmitting the stream, but more room for error
     * correction. A smaller window means a shorter delay but less room for correction.
     *
     * Valid range: 100–15000 ms.
     *
     * @default - 200 ms
     */
    readonly recoveryWindow?: Duration;
}
/**
 * Options for switchover-mode source failover.
 */
export interface FailoverFailoverOptions {
    /**
     * Whether failover is enabled. Set to `State.DISABLED` to keep the configuration
     * on the flow without switching failover on.
     *
     * @default State.ENABLED
     */
    readonly state?: State;
    /**
     * The name of the source you want to treat as primary. If set, MediaConnect always
     * uses this source when it is available. When unset, both sources are treated with
     * equal priority.
     *
     * @default - both sources are equal priority
     */
    readonly primarySource?: string;
}
/**
 * Source failover configuration for a flow.
 *
 * MediaConnect supports two failover modes:
 * - {@link FailoverConfig.merge} combines two binary-identical sources into a single
 *   stream, recovering lost packets from the other source (SMPTE 2022-7).
 * - {@link FailoverConfig.failover} switches between a primary and backup source when
 *   the active source stops receiving data.
 */
export declare class FailoverConfig {
    private readonly _failoverMode;
    private readonly _state;
    private readonly _recoveryWindow;
    private readonly _primarySource;
    /**
     * Configure merge-mode failover. Requires two binary-identical sources.
     */
    static merge(options?: MergeFailoverOptions): FailoverConfig;
    /**
     * Configure switchover-mode failover. The flow swaps to the backup source when the
     * primary source stops receiving data.
     */
    static failover(options?: FailoverFailoverOptions): FailoverConfig;
    private constructor();
}
/**
 * Configures a source monitoring metric.
 */
export interface MonitoringMetric {
    /**
     * Whether the metric is enabled or disabled. The threshold is persisted by the
     * service either way, so you can toggle the metric on and off without losing
     * the threshold value.
     */
    readonly state: State;
    /**
     * Threshold in seconds that triggers the metric's alert. Valid range: 10–60 seconds.
     */
    readonly threshold: Duration;
}
/**
 * Source monitoring settings.
 */
export interface SourceMonitoringConfig {
    /**
     * Indicates whether content quality analysis is enabled or disabled.
     *
     * @default - content quality analysis is disabled
     */
    readonly contentQualityAnalysisState?: State;
    /**
     * The current state of the thumbnail monitoring.
     *
     * @default - thumbnail monitoring is disabled
     */
    readonly thumbnailState?: State;
    /**
     * Silent-audio detection on the source.
     *
     * @default - silent audio monitoring is not configured
     */
    readonly silentAudio?: MonitoringMetric;
    /**
     * Black-frames detection on the source.
     *
     * @default - black frames monitoring is not configured
     */
    readonly blackFrames?: MonitoringMetric;
    /**
     * Frozen-frames detection on the source.
     *
     * @default - frozen frames monitoring is not configured
     */
    readonly frozenFrames?: MonitoringMetric;
}
/**
 * NDI Configuration
 */
export interface NdiDiscoveryServerConfig {
    /**
     * The unique network address of the NDI discovery server.
     */
    readonly discoveryServerAddress: string;
    /**
     * The port for the NDI discovery server. Defaults to 5959 if a custom port isn't specified.
     *
     * @default - undefined; when omitted, MediaConnect applies 5959 at deploy time
     */
    readonly discoveryServerPort?: number;
    /**
     * The VPC interface that the NDI discovery server uses to reach the flow.
     */
    readonly vpcInterface: VpcInterfaceConfig;
}
/**
 * Configuration for NDI Config
 */
export interface NdiConfig {
    /**
     * A prefix for the names of the NDI sources that the flow creates.
     * If a custom name isn't specified, MediaConnect generates a unique 12-character ID as the prefix.
     *
     * @default - MediaConnect generates a unique 12-character ID
     */
    readonly machineName?: string;
    /**
     * Specifies the configuration settings for individual NDI discovery servers.
     * A maximum of 3 servers is allowed.
     *
     * @default - no NDI discovery servers
     */
    readonly ndiDiscoveryServers?: NdiDiscoveryServerConfig[];
    /**
     * A setting that controls whether NDI sources or outputs can be used in the flow.
     * Must be ENABLED for the flow to support NDI sources or outputs.
     *
     * @default State.DISABLED
     */
    readonly ndiState?: State;
}
/**
 * Encoding profiles supported when transcoding an NDI source to a transport stream.
 */
export declare enum EncodingProfile {
    /**
     * H.264 profile tuned for contribution workflows — higher quality, higher bitrate.
     */
    CONTRIBUTION_H264_DEFAULT = "CONTRIBUTION_H264_DEFAULT",
    /**
     * H.264 profile tuned for distribution workflows — lower bitrate, wider compatibility.
     */
    DISTRIBUTION_H264_DEFAULT = "DISTRIBUTION_H264_DEFAULT"
}
/**
 * Encoding configuration applied to an NDI source when transcoding it to a transport
 * stream for downstream distribution.
 */
export interface EncodingConfig {
    /**
     * The encoding profile to use when transcoding the NDI source content to a transport
     * stream. You can change this value while the flow is running.
     *
     * @default - the MediaConnect service default
     */
    readonly encodingProfile?: EncodingProfile;
    /**
     * The maximum video bitrate to use when transcoding the NDI source to a transport stream.
     *
     * The supported range is 10 Mbps – 50 Mbps.
     *
     * @default - undefined; when omitted, MediaConnect applies 20 Mbps at deploy time
     */
    readonly videoMaxBitrate?: Bitrate;
}
/**
 * Option for Colorimetry
 */
export declare class Colorimetry {
    readonly value: string;
    /** Option for BT601 */
    static readonly BT601: Colorimetry;
    /** Option for BT709 */
    static readonly BT709: Colorimetry;
    /** Option for BT2020 */
    static readonly BT2020: Colorimetry;
    /** Option for BT2100 */
    static readonly BT2100: Colorimetry;
    /** Option for ST2065-1 */
    static readonly ST2065_1: Colorimetry;
    /** Option for ST2065-3 */
    static readonly ST2065_3: Colorimetry;
    /** Option for XYZ */
    static readonly XYZ: Colorimetry;
    /** Use a custom colorimetry value */
    static of(value: string): Colorimetry;
    /** @param value The colorimetry string value */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Options for Video Range
 */
export declare class VideoRange {
    readonly value: string;
    /** Option for Narrow */
    static readonly NARROW: VideoRange;
    /** Option for Full */
    static readonly FULL: VideoRange;
    /** Option for Full Protect */
    static readonly FULLPROTECT: VideoRange;
    /** Use a custom video range value */
    static of(value: string): VideoRange;
    /** @param value The video range string value */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Options for Scan Mode
 */
export declare class ScanMode {
    readonly value: string;
    /** Option for Progressive */
    static readonly PROGRESSIVE: ScanMode;
    /** Option for Interlace */
    static readonly INTERLACE: ScanMode;
    /** Option for Progressive Segmented Frame */
    static readonly PROGRESSIVE_SEGMENTED_FRAME: ScanMode;
    /** Use a custom scan mode value */
    static of(value: string): ScanMode;
    /** @param value The scan mode string value */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Options for Tcs
 */
export declare class Tcs {
    readonly value: string;
    /** Option for SDR */
    static readonly SDR: Tcs;
    /** Option for PQ */
    static readonly PQ: Tcs;
    /** Option for HLG */
    static readonly HLG: Tcs;
    /** Option for Linear */
    static readonly LINEAR: Tcs;
    /** Option for BT2100LINPQ */
    static readonly BT2100LINPQ: Tcs;
    /** Option for BT2100LINHLG */
    static readonly BT2100LINHLG: Tcs;
    /** Option for ST2065-1 */
    static readonly ST2065_1: Tcs;
    /** Option for ST428-1 */
    static readonly ST428_1: Tcs;
    /** Option for Density */
    static readonly DENSITY: Tcs;
    /** Use a custom TCS value */
    static of(value: string): Tcs;
    /** @param value The TCS string value */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Options for FMTP Video
 */
export interface FmtpVideo {
    /**
     * The format used for the representation of color.
     *
     * @default - no colorimetry specified
     */
    readonly colorimetry?: Colorimetry;
    /**
     * The frame rate for the video stream.
     *
     * @default - no frame rate specified
     */
    readonly exactFramerate?: Framerate;
    /**
     * The pixel aspect ratio (PAR) of the video — the shape of a single pixel, not the
     * display aspect ratio. Use `PixelAspectRatio.SQUARE` for most modern content.
     *
     * @default - no pixel aspect ratio specified
     */
    readonly par?: PixelAspectRatio;
    /**
     * The encoding range of the video.
     *
     * @default - no video range specified
     */
    readonly videoRange?: VideoRange;
    /**
     * The type of compression that was used to smooth the video's appearance.
     *
     * @default - no scan mode specified
     */
    readonly scanMode?: ScanMode;
    /**
     * The transfer characteristic system (TCS) that is used in the video.
     *
     * @default - no TCS specified
     */
    readonly tcs?: Tcs;
}
/**
 * Audio Stream Order Options
 */
export declare class AudioStreamOrderOptions {
    readonly value: string;
    /** Mono */
    static readonly MONO: AudioStreamOrderOptions;
    /** Dual Mono */
    static readonly DUAL_MONO: AudioStreamOrderOptions;
    /** Standard Stereo */
    static readonly STANDARD_STEREO: AudioStreamOrderOptions;
    /** Left Right Matrix Stereo */
    static readonly LTRT_MATRIX_STEREO: AudioStreamOrderOptions;
    /** 5.1 Surround */
    static readonly SURROUND_5_1: AudioStreamOrderOptions;
    /** 7.1 Surround */
    static readonly SURROUND_7_1: AudioStreamOrderOptions;
    /** 22.2 Surround */
    static readonly SURROUND_22_2: AudioStreamOrderOptions;
    /** One SDI Audio Group */
    static readonly ONE_SDI_AUDIO_GROUP: AudioStreamOrderOptions;
    /** Use a custom audio stream order value */
    static of(value: string): AudioStreamOrderOptions;
    /** @param value The audio stream order string value */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Options for Media Video format
 */
export declare class MediaVideoFormat {
    readonly value: string;
    /** Option for 2160p */
    static readonly UHD_2160P: MediaVideoFormat;
    /** Option for 1080p */
    static readonly HD_1080P: MediaVideoFormat;
    /** Option for 1080i */
    static readonly HD_1080I: MediaVideoFormat;
    /** Option for 720p */
    static readonly HD_720P: MediaVideoFormat;
    /** Option for 480p */
    static readonly SD_480P: MediaVideoFormat;
    /** Use a custom video format value */
    static of(value: string): MediaVideoFormat;
    /** @param value The video format string value */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Base configuration for Media Stream.
 */
export interface MediaStreamBase {
    /**
     * A unique identifier for the media stream.
     */
    readonly mediaStreamId: number;
    /**
     * A name that helps you distinguish one media stream from another.
     */
    readonly mediaStreamName: string;
    /**
     * A description that can help you quickly identify what your media stream is used for.
     *
     * @default - no description
     */
    readonly description?: string;
}
/**
 * A media stream represents one component of your content, such as video, audio, or ancillary data.
 * After you add a media stream to your flow, you can associate it with sources and outputs that use
 * the ST 2110 JPEG XS or CDI protocol.
 */
export interface MediaStreamVideo extends MediaStreamBase {
    /**
     * Attributes that are related to the media stream.
     */
    readonly fmtp: FmtpVideo;
    /**
     * The sample rate for the stream. This value is measured in Hz.
     *
     * @default - default clock rate for the media stream type
     */
    readonly clockRate?: number;
    /**
     * The format type number (sometimes referred to as RTP payload type) of the media stream.
     * MediaConnect assigns this value to the media stream. For ST 2110 JPEG XS outputs, you need to provide this value to the receiver.
     *
     * @default - assigned by MediaConnect
     */
    readonly fmt?: number;
    /**
     * The resolution of the video.
     */
    readonly videoFormat: MediaVideoFormat;
}
/**
 * A media stream represents one component of your content, such as video, audio, or ancillary data.
 * After you add a media stream to your flow, you can associate it with sources and outputs that use
 * the ST 2110 JPEG XS or CDI protocol.
 */
export interface MediaStreamAudio extends MediaStreamBase {
    /**
     * The format of the audio channel.
     *
     * @default - the MediaConnect service default
     */
    readonly channelOrder?: AudioStreamOrderOptions;
    /**
     * The sample rate for the stream. This value is measured in Hz.
     *
     * @default - default clock rate for the media stream type
     */
    readonly clockRate?: number;
    /**
     * The format type number (sometimes referred to as RTP payload type) of the media stream.
     * MediaConnect assigns this value to the media stream. For ST 2110 JPEG XS outputs, you need to provide this value to the receiver.
     *
     * @default - assigned by MediaConnect
     */
    readonly fmt?: number;
    /**
     * The audio language, in a format that is recognized by the receiver.
     *
     * @default - no language specified
     */
    readonly lang?: string;
}
/**
 * A media stream represents one component of your content, such as video, audio, or ancillary data.
 * After you add a media stream to your flow, you can associate it with sources and outputs that use
 * the ST 2110 JPEG XS or CDI protocol.
 */
export interface MediaStreamAncillaryData extends MediaStreamBase {
}
/**
 * Properties for the Flow
 */
export interface FlowProps {
    /**
     * The name of the flow.
     *
     * @default - autogenerated
     */
    readonly flowName?: string;
    /**
     * The Availability Zone that you want to create the flow in. These options are limited to the Availability Zones within the current AWS Region.
     *
     * @default - chosen by MediaConnect
     */
    readonly availabilityZone?: string;
    /**
     * Determines the processing capacity and feature set of the flow. Set this optional parameter to LARGE if you want to enable NDI outputs on the flow.
     *
     * @default - undefined; when omitted, MediaConnect applies FlowSize.MEDIUM at deploy time
     */
    readonly flowSize?: FlowSize;
    /**
     * The maintenance window for the flow.
     *
     * @default - chosen by MediaConnect
     */
    readonly maintenanceConfiguration?: MaintenanceWindow;
    /**
     * The media streams that are associated with the flow. After you associate a media stream with a source, you can also associate it with outputs on the flow.
     *
     * @default No Media Streams
     */
    readonly mediaStreams?: MediaStream[];
    /**
     * Specifies the configuration settings for a flow's NDI source or output. Required when the flow includes an NDI source or output.
     *
     * @default No NDI Configuration applied
     */
    readonly ndiConfig?: NdiConfig;
    /**
     * Encoding configuration applied to the NDI source when transcoding it to a transport
     * stream for downstream distribution.
     *
     * Required when the flow source uses the NDI SpeedHQ protocol
     * (see {@link SourceConfiguration.ndi}).
     *
     * @default - no encoding config; required for NDI sources
     */
    readonly encodingConfig?: EncodingConfig;
    /**
     * The settings for the source that you want to use for the new flow.
     */
    readonly source: SourceConfiguration;
    /**
     * The settings for source failover.
     *
     * @default No source failover configuration applied
     */
    readonly sourceFailoverConfig?: FailoverConfig;
    /**
     * The settings for source monitoring.
     *
     * @default No source monitoring configuration applied
     */
    readonly sourceMonitoringConfig?: SourceMonitoringConfig;
    /**
     * The VPC Interfaces for this flow.
     * @default No VPC Interface configuration applied
     */
    readonly vpcInterfaces?: VpcInterfaceConfig[];
}
/**
 * Simplified configuration for Media Streams
 */
export declare class MediaStream {
    private readonly _config;
    /**
     * Configuration for MediaStream Video
     */
    static video(config: MediaStreamVideo): MediaStream;
    /**
     * Configuration for MediaStream audio
     */
    static audio(config: MediaStreamAudio): MediaStream;
    /**
     * Configuration for MediaStream ancillary data
     */
    static ancillaryData(config: MediaStreamAncillaryData): MediaStream;
    private constructor();
}
/**
 * Attributes for importing an existing Flow.
 */
export interface FlowAttributes {
    /**
     * The ARN of the flow.
     */
    readonly flowArn: string;
    /**
     * Indicates whether failover configured
     *
     * @default false
     */
    readonly isFailoverEnabled?: boolean;
    /**
     * ARN of the source defined on the flow.
     *
     * Not encoded in the flow ARN, so must be provided explicitly when you need
     * access to `sourceArn` on the imported construct.
     *
     * @default - sourceArn is not available on the imported construct
     */
    readonly sourceArn?: string;
    /**
     * The IP address that the flow uses to send outbound content.
     *
     * @default - accessing `egressIp` on the imported flow throws; only provide when available.
     */
    readonly egressIp?: string;
    /**
     * The IP address that the flow listens on for incoming content.
     *
     * @default - accessing `sourceIngestIp` on the imported flow throws; only provide when available.
     */
    readonly sourceIngestIp?: string;
    /**
     * The port that the flow listens on for incoming content.
     *
     * @default - accessing `sourceIngestPort` on the imported flow throws; only provide when available.
     */
    readonly sourceIngestPort?: string;
    /**
     * The Availability Zone that the flow was created in.
     *
     * @default - `flowAvailabilityZone` is undefined on the imported flow.
     */
    readonly flowAvailabilityZone?: string;
}
declare abstract class FlowBase extends Resource implements IFlow {
    /**
     * Creates a Flow construct that represents an external (imported) Flow.
     */
    static fromFlowAttributes(scope: Construct, id: string, attrs: FlowAttributes): IFlow;
    /**
     * Import an existing Flow from its ARN.
     *
     * Use `fromFlowAttributes()` instead if you need access to `sourceArn` or any other
     * attribute not encoded in the flow ARN.
     */
    static fromFlowArn(scope: Construct, id: string, flowArn: string): IFlow;
    abstract readonly sourceArn: string;
    abstract readonly flowArn: string;
    abstract readonly egressIp: string;
    abstract readonly sourceIngestIp: string;
    abstract readonly sourceIngestPort: string;
    abstract readonly sourceIngestUrl: string;
    abstract readonly flowAvailabilityZone?: string;
    abstract readonly isFailoverEnabled?: boolean;
    /**
     * Collection of grant methods for this flow.
     */
    readonly grants: FlowGrants;
    /**
     * A reference to this Flow resource.
     * Required by the auto-generated IFlowRef interface.
     */
    get flowRef(): FlowReference;
    /**
     * Add an output to this flow
     */
    addOutput(id: string, options: AddFlowOutputOptions): IFlowOutput;
    /**
     * Create a CloudWatch metric for this flow.
     */
    metric(metricName: string, props?: MetricOptions): Metric;
    /**
     * Metric for the bitrate of content ingested into the flow.
     *
     * Emits the `SourceBitRate` metric with dimension `FlowARN`, which aggregates across
     * all sources on the flow. To narrow to a specific source on a multi-source flow, call
     * {@link metric} with an additional `SourceARN` dimension.
     *
     * @default - average over 60 seconds
     */
    metricSourceBitrate(props?: MetricOptions): Metric;
    /**
     * Metric for packets that were lost in transit and not recovered by error correction.
     *
     * Emits the `SourceNotRecoveredPackets` metric with dimension `FlowARN`, which aggregates
     * across all sources on the flow.
     *
     * @default - sum over 60 seconds
     */
    metricSourceNotRecoveredPackets(props?: MetricOptions): Metric;
    /**
     * Metric for the total number of packets received by the flow sources.
     *
     * Emits the `SourceTotalPackets` metric with dimension `FlowARN`, which aggregates across
     * all sources on the flow.
     *
     * @default - sum over 60 seconds
     */
    metricSourceTotalPackets(props?: MetricOptions): Metric;
    /**
     * Metric indicating which source is selected for ingest when using `Failover` failover mode.
     * A value of 1 indicates the source is being used as the input; 0 indicates it is standby.
     *
     * Emits the `SourceSelected` metric with dimension `FlowARN`. To narrow to a specific source,
     * call {@link metric} with an additional `SourceARN` dimension.
     *
     * @default - maximum over 60 seconds
     */
    metricSourceSelected(props?: MetricOptions): Metric;
    /**
     * Metric indicating the connection state of the source. 1 for connected, 0 for disconnected.
     * Applies only to Zixi, SRT, and RIST sources.
     *
     * Emits the `SourceConnected` metric with dimension `FlowARN`.
     *
     * @default - minimum over 60 seconds
     */
    metricSourceConnected(props?: MetricOptions): Metric;
    /**
     * Metric for the number of times the source transitioned from connected to disconnected.
     *
     * Emits the `SourceDisconnections` metric with dimension `FlowARN`.
     *
     * @default - sum over 60 seconds
     */
    metricSourceDisconnections(props?: MetricOptions): Metric;
    /**
     * Metric for the number of packets lost during transit, measured before any error
     * correction takes place.
     *
     * Emits the `SourceDroppedPackets` metric with dimension `FlowARN`.
     *
     * @default - sum over 60 seconds
     */
    metricSourceDroppedPackets(props?: MetricOptions): Metric;
    /**
     * Metric for the percentage of packets lost during transit, even if they were recovered.
     *
     * Emits the `SourcePacketLossPercent` metric with dimension `FlowARN`.
     *
     * @default - average over 60 seconds
     */
    metricSourcePacketLossPercent(props?: MetricOptions): Metric;
    /**
     * Metric for the round-trip time between the source and MediaConnect. Applies only to
     * RIST, Zixi, and SRT sources.
     *
     * Emits the `SourceRoundTripTime` metric with dimension `FlowARN`.
     *
     * @default - average over 60 seconds
     */
    metricSourceRoundTripTime(props?: MetricOptions): Metric;
    /**
     * Metric for the current network jitter of the source, measured in milliseconds.
     *
     * Emits the `SourceJitter` metric with dimension `FlowARN`.
     *
     * @default - average over 60 seconds
     */
    metricSourceJitter(props?: MetricOptions): Metric;
}
/**
 * Defines an AWS Elemental MediaConnect Flow.
 */
export declare class Flow extends FlowBase implements IFlow {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * The set of source protocols where the flow opens an IP:port and listens for
     * upstream content. Determines availability of `sourceIngestIp`, `sourceIngestPort`,
     * and `sourceIngestUrl`. Maps each protocol to the URL scheme used to construct
     * the ingest URL.
     */
    private static readonly LISTENER_PROTOCOL_SCHEMES;
    private static isListenerStyleProtocol;
    readonly flowArn: string;
    readonly sourceArn: string;
    readonly egressIp: string;
    private readonly _sourceIngestIp;
    private readonly _sourceIngestPort;
    private readonly _hasListenerSource;
    readonly flowAvailabilityZone?: string;
    readonly isFailoverEnabled?: boolean;
    private vpcInterfaces;
    get sourceIngestIp(): string;
    get sourceIngestPort(): string;
    get sourceIngestUrl(): string;
    constructor(scope: Construct, id: string, props: FlowProps);
    /** Validate the flow name length and character set, when a concrete value is provided. */
    private validateName;
    /**
     * Validate source-monitoring thresholds (10-60 seconds) and that the per-metric checks are only
     * used when content-quality analysis is enabled.
     */
    private validateMonitoring;
    /** Validate the encoding config's video max bitrate range (10-50 Mbps). */
    private validateEncoding;
    /**
     * Validate NDI constraints: discovery-server limit, mutual exclusivity with CDI/JPEG XS, the
     * required LARGE flow size, and the requirements an NDI source places on the flow.
     */
    private validateNdi;
    /** Validate the EFA VPC-interface count (at most one), when the list is concrete. */
    private validateVpcEfaCount;
    /**
     * Build the URL for a listener-style source protocol. The caller must have already
     * checked `_hasListenerSource`; this method assumes the protocol is in
     * `LISTENER_PROTOCOL_SCHEMES` and throws an unscoped error otherwise.
     */
    private computeIngestUrl;
    /**
     * Add a VPC interface to this flow.
     */
    addVpcInterface(vpc: VpcInterfaceConfig): VpcInterfaceConfig;
}
export {};
