import * as mediaconnect from "aws-cdk-lib/aws-mediaconnect";
import * as iam from "aws-cdk-lib/aws-iam";
import * as cdk from "aws-cdk-lib/core";
/**
 * Collection of grant methods for a IFlowRef
 */
export declare class FlowGrants {
    /**
     * Creates grants for FlowGrants
     */
    static fromFlow(resource: mediaconnect.IFlowRef): FlowGrants;
    protected readonly resource: mediaconnect.IFlowRef;
    private constructor();
    /**
     * Grant the given identity custom permissions
     */
    actions(grantee: iam.IGrantable, actions: Array<string>, options?: cdk.PermissionsOptions): iam.Grant;
    /**
     * Grant permissions to start this flow
     */
    start(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant permissions to stop this flow
     */
    stop(grantee: iam.IGrantable): iam.Grant;
}
/**
 * Collection of grant methods for a IRouterInputRef
 */
export declare class RouterInputGrants {
    /**
     * Creates grants for RouterInputGrants
     */
    static fromRouterInput(resource: mediaconnect.IRouterInputRef): RouterInputGrants;
    protected readonly resource: mediaconnect.IRouterInputRef;
    private constructor();
    /**
     * Grant the given identity custom permissions
     */
    actions(grantee: iam.IGrantable, actions: Array<string>, options?: cdk.PermissionsOptions): iam.Grant;
    /**
     * Grant permissions to start this router input
     */
    start(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant permissions to stop this router input
     */
    stop(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant permissions to restart this router input
     */
    restart(grantee: iam.IGrantable): iam.Grant;
}
