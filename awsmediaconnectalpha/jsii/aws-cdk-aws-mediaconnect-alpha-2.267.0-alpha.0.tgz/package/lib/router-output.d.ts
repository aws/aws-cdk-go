import type { Bitrate, IResource } from 'aws-cdk-lib';
import { Duration, Resource } from 'aws-cdk-lib';
import type { MetricOptions } from 'aws-cdk-lib/aws-cloudwatch';
import { Metric } from 'aws-cdk-lib/aws-cloudwatch';
import type { IRouterOutputRef, RouterOutputReference } from 'aws-cdk-lib/aws-mediaconnect';
import type { Construct } from 'constructs';
import type { IFlow } from './flow';
import type { MaintenanceConfiguration, ForwardErrorCorrection, RoutingScope } from './router-input';
import type { IRouterNetworkInterface } from './router-network-interface';
import type { MediaLivePipeline, RouterSrtEncryption, TransitEncryption } from './shared';
/**
 * Protocol options available for Router Output configurations
 */
export declare class RouterOutputProtocolOptions {
    readonly value: string;
    /** Real-time Transport Protocol */
    static readonly RTP: RouterOutputProtocolOptions;
    /** Reliable Internet Stream Transport */
    static readonly RIST: RouterOutputProtocolOptions;
    /** Secure Reliable Transport - Caller mode */
    static readonly SRT_CALLER: RouterOutputProtocolOptions;
    /** Secure Reliable Transport - Listener mode */
    static readonly SRT_LISTENER: RouterOutputProtocolOptions;
    /**
     * Use a custom protocol value
     * @param value The protocol string value
     */
    static of(value: string): RouterOutputProtocolOptions;
    /** @param value The protocol string value */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Routing tier that determines the maximum bitrate (in Mbps) for a Router Output.
 */
export declare class RouterOutputTier {
    readonly value: string;
    /** Up to 100 Mbps */
    static readonly OUTPUT_100: RouterOutputTier;
    /** Up to 50 Mbps */
    static readonly OUTPUT_50: RouterOutputTier;
    /** Up to 20 Mbps */
    static readonly OUTPUT_20: RouterOutputTier;
    /**
     * Use a custom tier value
     * @param value The tier string value
     */
    static of(value: string): RouterOutputTier;
    /** @param value The tier string value */
    private constructor();
    /** Returns the string value */
    toString(): string;
}
/**
 * Interface for Router Output
 */
export interface IRouterOutput extends IResource, IRouterOutputRef {
    /**
     * The name of the router output.
     *
     * @attribute
     */
    readonly routerOutputName: string;
    /**
     * The Amazon Resource Name (ARN) of the router output.
     *
     * @attribute
     */
    readonly routerOutputArn: string;
    /**
     * The unique identifier of the router output.
     *
     * @attribute
     */
    readonly routerOutputId: string;
    /**
     * The IP address of the router output.
     *
     * @attribute
     */
    readonly ipAddress: string;
    /**
     * The timestamp when the router output was created.
     *
     * @attribute
     */
    readonly createdAt?: string;
    /**
     * The timestamp when the router output was last updated.
     *
     * @attribute
     */
    readonly updatedAt?: string;
    /**
     * Create a CloudWatch metric for this router output.
     *
     * Router output metrics are dimensioned by `RouterOutputARN`. See the MediaConnect
     * documentation for available metric names (e.g. `RouterOutputBitRate`,
     * `RouterOutputTotalPackets`).
     */
    metric(metricName: string, props?: MetricOptions): Metric;
    /**
     * Metric for the bitrate of the router output's payload.
     * @default - average over 60 seconds
     */
    metricBitrate(props?: MetricOptions): Metric;
    /**
     * Metric for the total number of packets sent by the router output.
     * @default - sum over 60 seconds
     */
    metricTotalPackets(props?: MetricOptions): Metric;
    /**
     * Metric for the router output connection state (1 connected, 0 disconnected). Applies to SRT outputs only.
     * @default - minimum over 60 seconds
     */
    metricConnected(props?: MetricOptions): Metric;
    /**
     * Metric for the number of retransmitted packets requested through automatic repeat request (ARQ).
     * Applies to RIST and SRT outputs only.
     *
     * @default - sum over 60 seconds
     */
    metricArqRequests(props?: MetricOptions): Metric;
}
/**
 * Properties for creating a Router Output
 */
export interface RouterOutputProps {
    /**
     * Name of the Router Output
     * @default - Generated automatically
     */
    readonly routerOutputName?: string;
    /** The maximum bitrate for the router output. */
    readonly maximumBitrate: Bitrate;
    /** Indicates whether the router output is configured for Regional or global routing. */
    readonly routingScope: RoutingScope;
    /**
     * Select a tier based on your maximum bitrate requirements.
     * @default RouterOutputTier.OUTPUT_20
     */
    readonly tier?: RouterOutputTier;
    /** Configuration for the Router Output (standard, MediaConnect Flow, or MediaLive) */
    readonly configuration: RouterOutputConfiguration;
    /**
     * Maintenance window configuration
     * @default - Default maintenance window will be used
     */
    readonly maintenanceConfiguration?: MaintenanceConfiguration;
    /**
     * The AWS Region where the router output is located.
     * @default - Defaults to the same region as stack
     */
    readonly regionName?: string;
    /**
     * Tags to add to the Router Output
     * @default - No tagging
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Attributes for importing an existing Router Output.
 */
export interface RouterOutputAttributes {
    /**
     * The ARN of the router output.
     */
    readonly routerOutputArn: string;
    /**
     * The name of the router output.
     *
     * The name is not encoded in the ARN (the ARN contains only the service-generated ID),
     * so provide it here if you need to access `routerOutputName` on the imported construct.
     *
     * @default - routerOutputName is not available on the imported construct
     */
    readonly routerOutputName?: string;
    /**
     * The unique identifier of the router output.
     *
     * @default - parsed from the ARN when available
     */
    readonly routerOutputId?: string;
}
/**
 * Properties for RTP protocol configuration for outputs
 */
export interface RtpOutputProtocolProps {
    /** Destination IP address for RTP traffic */
    readonly destinationAddress: string;
    /** Port number for RTP traffic */
    readonly port: number;
    /**
     * Forward Error Correction setting
     * @default - undefined; when omitted, MediaConnect applies ForwardErrorCorrection.DISABLED at deploy time
     */
    readonly forwardErrorCorrection?: ForwardErrorCorrection;
}
/**
 * Properties for RIST protocol configuration for outputs
 */
export interface RistOutputProtocolProps {
    /** Destination IP address for RIST traffic */
    readonly destinationAddress: string;
    /** Port number for RIST traffic */
    readonly port: number;
}
/**
 * Properties for SRT Listener protocol configuration for outputs
 */
export interface SrtListenerOutputProtocolProps {
    /** Port number for SRT listener */
    readonly port: number;
    /** Minimum latency for SRT */
    readonly minimumLatency: Duration;
    /**
     * Optional encryption configuration for SRT streams
     * @default - No encryption
     */
    readonly encryptionConfiguration?: RouterSrtEncryption;
}
/**
 * Properties for SRT Caller protocol configuration for outputs
 */
export interface SrtCallerOutputProtocolProps {
    /** Destination IP address to connect to */
    readonly destinationAddress: string;
    /** Destination port to connect to */
    readonly destinationPort: number;
    /** Minimum latency for SRT */
    readonly minimumLatency: Duration;
    /**
     * Optional stream ID for SRT connection
     * @default - No stream ID
     */
    readonly streamId?: string;
    /**
     * Optional encryption configuration for SRT streams
     * @default - No encryption
     */
    readonly encryptionConfiguration?: RouterSrtEncryption;
}
/**
 * Factory class for creating Router Output protocol configurations.
 *
 * Supported protocols: RTP, RIST, SRT (Listener and Caller).
 */
export declare class RouterOutputProtocol {
    /**
     * Create an RTP protocol configuration
     *
     * @example
     *
     *    RouterOutputProtocol.rtp({
     *      destinationAddress: '10.0.0.1',
     *      port: 5000,
     *    });
     *
     * @param props RTP protocol properties
     * @returns RouterOutputProtocol instance configured for RTP
     */
    static rtp(props: RtpOutputProtocolProps): RouterOutputProtocol;
    /**
     * Create a RIST protocol configuration
     *
     * @example
     *
     *    RouterOutputProtocol.rist({
     *      destinationAddress: '10.0.0.1',
     *      port: 5000,
     *    });
     *
     * @param props RIST protocol properties
     * @returns RouterOutputProtocol instance configured for RIST
     */
    static rist(props: RistOutputProtocolProps): RouterOutputProtocol;
    /**
     * Create an SRT Listener protocol configuration
     *
     * @example
     *
     *    RouterOutputProtocol.srtListener({
     *      port: 5000,
     *      minimumLatency: Duration.millis(125),
     *    });
     *
     * @param props SRT Listener protocol properties
     * @returns RouterOutputProtocol instance configured for SRT Listener
     */
    static srtListener(props: SrtListenerOutputProtocolProps): RouterOutputProtocol;
    /**
     * Create an SRT Caller protocol configuration
     *
     * @example
     *
     *    RouterOutputProtocol.srtCaller({
     *      destinationAddress: '10.0.0.1',
     *      destinationPort: 5000,
     *      minimumLatency: Duration.millis(125),
     *    });
     *
     * @param props SRT Caller protocol properties
     * @returns RouterOutputProtocol instance configured for SRT Caller
     */
    static srtCaller(props: SrtCallerOutputProtocolProps): RouterOutputProtocol;
    /**
     * Validate that port is within the valid range (3000-30000)
     */
    private static validatePort;
    /**
     * Validate that SRT Caller port is within the valid range (0-65535)
     */
    private static validateSrtCallerPort;
    private readonly _protocolName;
    private readonly _config;
    private readonly _encryption?;
    private constructor();
}
/**
 * Properties for standard Router Output configuration
 */
export interface StandardOutputConfigurationProps {
    /** Network interface for the Router Output */
    readonly networkInterface: IRouterNetworkInterface;
    /** Protocol configuration for the output */
    readonly protocol: RouterOutputProtocol;
    /**
     * The availability zone where the router output is located.
     *
     * @default - assigned by the MediaConnect service
     */
    readonly availabilityZone?: string;
}
/**
 * Properties for MediaLive Router Output configuration with specific input connection
 */
export interface MediaLiveInputConnectionProps {
    /**
     * ARN of the MediaLive input to send output to.
     *
     * Note: This will change to accept an IInputRef (typed MediaLive Input reference)
     * when the @aws-cdk/aws-medialive-alpha L2 construct is released.
     */
    readonly mediaLiveInputArn: string;
    /** Pipeline ID for MediaLive input */
    readonly mediaLivePipelineId: MediaLivePipeline;
    /**
     * Optional transit encryption configuration
     * @default - Automatic encryption will be used
     */
    readonly destinationTransitEncryption?: TransitEncryption;
}
/**
 * Properties for MediaLive Router Output configuration without specific input connection
 */
export interface MediaLiveNoInputConnectionProps {
    /** Availability zone for the router output when not connecting to a specific input */
    readonly availabilityZone: string;
    /**
     * Optional transit encryption configuration
     * @default - Automatic encryption will be used
     */
    readonly destinationTransitEncryption?: TransitEncryption;
}
/**
 * Properties for MediaConnect Flow Router Output configuration with specific flow connection
 */
export interface MediaConnectFlowConnectionProps {
    /** MediaConnect Flow to send output to */
    readonly flow: IFlow;
    /**
     * Optional transit encryption configuration
     * @default - Automatic encryption will be used
     */
    readonly destinationTransitEncryption?: TransitEncryption;
}
/**
 * Properties for MediaConnect Flow Router Output configuration without specific flow connection
 */
export interface MediaConnectFlowNoConnectionProps {
    /** Availability zone for the router output when not connecting to a specific flow */
    readonly availabilityZone: string;
    /**
     * Optional transit encryption configuration
     * @default - Automatic encryption will be used
     */
    readonly destinationTransitEncryption?: TransitEncryption;
}
/**
 * Factory class for creating Router Output configurations
 */
export declare abstract class RouterOutputConfiguration {
    /**
     * Create a standard Router Output configuration with a single protocol
     *
     * @example
     *
     *    declare const networkInterface: RouterNetworkInterface;
     *
     *    RouterOutputConfiguration.standard({
     *      networkInterface,
     *      protocol: RouterOutputProtocol.rtp({
     *        destinationAddress: '10.0.0.1',
     *        port: 5000,
     *      }),
     *    });
     *
     * @param props Standard configuration properties
     * @returns RouterOutputConfiguration instance for standard setup
     */
    static standard(props: StandardOutputConfigurationProps): RouterOutputConfiguration;
    /**
     * Create a MediaLive Router Output configuration with a specific input connection.
     *
     * Use this when the MediaLive input already exists and you want to connect immediately.
     *
     * @example
     *
     *    RouterOutputConfiguration.mediaLiveInput({
     *      mediaLiveInputArn: 'arn:aws:medialive:us-east-1:123456789012:input:1234567',
     *      mediaLivePipelineId: MediaLivePipeline.PIPELINE_0,
     *    });
     *
     * @param props MediaLive input connection properties
     * @returns RouterOutputConfiguration instance for MediaLive setup with input connection
     */
    static mediaLiveInput(props: MediaLiveInputConnectionProps): RouterOutputConfiguration;
    /**
     * Create a MediaLive Router Output configuration without a specific input connection.
     *
     * Use this when you want to set up the router output before the MediaLive input exists.
     *
     * @example
     *
     *    RouterOutputConfiguration.mediaLiveInputWithoutConnection({
     *      availabilityZone: 'us-east-1a',
     *    });
     *
     * @param props MediaLive no input connection properties
     * @returns RouterOutputConfiguration instance for MediaLive setup without input connection
     */
    static mediaLiveInputWithoutConnection(props: MediaLiveNoInputConnectionProps): RouterOutputConfiguration;
    /**
     * Create a MediaConnect Flow Router Output configuration with a specific flow connection.
     *
     * Use this when the target flow already exists and you want to connect immediately.
     *
     * @example
     *
     *    declare const flow: Flow;
     *
     *    RouterOutputConfiguration.mediaConnectFlow({
     *      flow,
     *    });
     *
     * @param props MediaConnect Flow connection properties
     * @returns RouterOutputConfiguration instance for MediaConnect Flow setup with flow connection
     */
    static mediaConnectFlow(props: MediaConnectFlowConnectionProps): RouterOutputConfiguration;
    /**
     * Create a MediaConnect Flow Router Output configuration without a specific flow connection.
     *
     * Use this when you want to set up the router output before the target flow exists.
     *
     * @example
     *
     *    RouterOutputConfiguration.mediaConnectFlowWithoutConnection({
     *      availabilityZone: 'us-east-1a',
     *    });
     *
     * @param props MediaConnect Flow no connection properties
     * @returns RouterOutputConfiguration instance for MediaConnect Flow setup without flow connection
     */
    static mediaConnectFlowWithoutConnection(props: MediaConnectFlowNoConnectionProps): RouterOutputConfiguration;
}
/**
 * A MediaConnect Router Output that sends media streams to destinations.
 *
 * Router Outputs support multiple configuration types:
 * - Standard: Single protocol output
 * - MediaLive Input: Output to AWS Elemental MediaLive
 * - MediaConnect Flow: Output to another MediaConnect Flow
 */
declare abstract class RouterOutputBase extends Resource implements IRouterOutput {
    abstract readonly routerOutputArn: string;
    abstract readonly routerOutputName: string;
    abstract readonly routerOutputId: string;
    abstract readonly ipAddress: string;
    abstract readonly createdAt?: string;
    abstract readonly updatedAt?: string;
    /**
     * A reference to this Router Output resource.
     * Required by the auto-generated IRouterOutputRef interface.
     */
    get routerOutputRef(): RouterOutputReference;
    /**
     * Create a CloudWatch metric for this router output.
     */
    metric(metricName: string, props?: MetricOptions): Metric;
    /**
     * Metric for the bitrate of the router output's payload.
     */
    metricBitrate(props?: MetricOptions): Metric;
    /**
     * Metric for the total number of packets sent by the router output.
     */
    metricTotalPackets(props?: MetricOptions): Metric;
    /**
     * Metric for the router output connection state (1 connected, 0 disconnected). Applies to SRT outputs only.
     */
    metricConnected(props?: MetricOptions): Metric;
    /**
     * Metric for the number of retransmitted packets requested through ARQ. Applies to RIST and SRT outputs.
     */
    metricArqRequests(props?: MetricOptions): Metric;
}
/**
 * Defines an AWS Elemental MediaConnect Router Output.
 */
export declare class RouterOutput extends RouterOutputBase implements IRouterOutput {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing Router Output from its ARN.
     *
     * The ARN only contains the service-generated ID (not the router output name). Accessing
     * `routerOutputName` on an ARN import throws — use `fromRouterOutputAttributes()` to provide
     * the name explicitly.
     *
     * @param scope The parent construct
     * @param id The construct id
     * @param routerOutputArn The ARN of the Router Output
     * @returns A Router Output construct
     */
    static fromRouterOutputArn(scope: Construct, id: string, routerOutputArn: string): IRouterOutput;
    /**
     * Import an existing Router Output from attributes.
     *
     * Use this when you need to reference a router output by name.
     *
     * @param scope The parent construct
     * @param id The construct id
     * @param attrs The Router Output attributes
     * @returns A Router Output construct
     */
    static fromRouterOutputAttributes(scope: Construct, id: string, attrs: RouterOutputAttributes): IRouterOutput;
    /**
     * Returns the maximum bitrate in Mbps for a known tier, or undefined for custom tiers.
     */
    private static tierLimitMbps;
    readonly routerOutputArn: string;
    readonly routerOutputName: string;
    readonly routerOutputId: string;
    readonly ipAddress: string;
    readonly createdAt?: string;
    readonly updatedAt?: string;
    constructor(scope: Construct, id: string, props: RouterOutputProps);
}
export {};
