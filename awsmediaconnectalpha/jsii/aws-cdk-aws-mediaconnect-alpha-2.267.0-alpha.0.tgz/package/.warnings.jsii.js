const VALIDATORS = { _aws_cdk_aws_mediaconnect_alpha_SourceMonitoringConfig: function _aws_cdk_aws_mediaconnect_alpha_SourceMonitoringConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.blackFrames))
                module.exports._aws_cdk_aws_mediaconnect_alpha_MonitoringMetric(p.blackFrames);
            if (!visitedObjects.has(p.frozenFrames))
                module.exports._aws_cdk_aws_mediaconnect_alpha_MonitoringMetric(p.frozenFrames);
            if (!visitedObjects.has(p.silentAudio))
                module.exports._aws_cdk_aws_mediaconnect_alpha_MonitoringMetric(p.silentAudio);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_NdiDiscoveryServerConfig: function _aws_cdk_aws_mediaconnect_alpha_NdiDiscoveryServerConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.vpcInterface))
                module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(p.vpcInterface);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_NdiConfig: function _aws_cdk_aws_mediaconnect_alpha_NdiConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.ndiDiscoveryServers != null)
                for (const o of p.ndiDiscoveryServers)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_NdiDiscoveryServerConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_FlowProps: function _aws_cdk_aws_mediaconnect_alpha_FlowProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encodingConfig))
                module.exports._aws_cdk_aws_mediaconnect_alpha_EncodingConfig(p.encodingConfig);
            if (p.mediaStreams != null)
                for (const o of p.mediaStreams)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_MediaStream(o);
            if (!visitedObjects.has(p.ndiConfig))
                module.exports._aws_cdk_aws_mediaconnect_alpha_NdiConfig(p.ndiConfig);
            if (!visitedObjects.has(p.sourceMonitoringConfig))
                module.exports._aws_cdk_aws_mediaconnect_alpha_SourceMonitoringConfig(p.sourceMonitoringConfig);
            if (p.vpcInterfaces != null)
                for (const o of p.vpcInterfaces)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaStreamSourceConfigurationJpegXs: function _aws_cdk_aws_mediaconnect_alpha_MediaStreamSourceConfigurationJpegXs(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.inputInterface != null)
                for (const o of p.inputInterface)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SourceSrtListener: function _aws_cdk_aws_mediaconnect_alpha_SourceSrtListener(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_SrtPasswordEncryption(p.decryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SourceSrtCaller: function _aws_cdk_aws_mediaconnect_alpha_SourceSrtCaller(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_SrtPasswordEncryption(p.decryption);
            if (!visitedObjects.has(p.vpcInterface))
                module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(p.vpcInterface);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SourceZixiPush: function _aws_cdk_aws_mediaconnect_alpha_SourceZixiPush(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_StaticKeyEncryption(p.decryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SourceCdi: function _aws_cdk_aws_mediaconnect_alpha_SourceCdi(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.mediaStreamSourceConfigurations != null)
                for (const o of p.mediaStreamSourceConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_MediaStreamSourceConfigurationCdi(o);
            if (!visitedObjects.has(p.vpcInterface))
                module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(p.vpcInterface);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SourceJpegXs: function _aws_cdk_aws_mediaconnect_alpha_SourceJpegXs(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.mediaStreamSourceConfigurations != null)
                for (const o of p.mediaStreamSourceConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_MediaStreamSourceConfigurationJpegXs(o);
            if (p.vpcInterface != null)
                for (const o of p.vpcInterface)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_GatewayBridgeSource: function _aws_cdk_aws_mediaconnect_alpha_GatewayBridgeSource(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.vpcInterface))
                module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(p.vpcInterface);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_RouterSource: function _aws_cdk_aws_mediaconnect_alpha_RouterSource(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.decryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_EntitlementSource: function _aws_cdk_aws_mediaconnect_alpha_EntitlementSource(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_StaticKeyEncryption(p.decryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_BridgeFlowSource: function _aws_cdk_aws_mediaconnect_alpha_BridgeFlowSource(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.vpcInterface))
                module.exports._aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(p.vpcInterface);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_BridgeFlowInput: function _aws_cdk_aws_mediaconnect_alpha_BridgeFlowInput(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.source))
                module.exports._aws_cdk_aws_mediaconnect_alpha_BridgeFlowSource(p.source);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_IngressBridgeConfiguration: function _aws_cdk_aws_mediaconnect_alpha_IngressBridgeConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.networkSources != null)
                for (const o of p.networkSources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_BridgeNetworkInput(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_EgressBridgeConfiguration: function _aws_cdk_aws_mediaconnect_alpha_EgressBridgeConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.flowSources != null)
                for (const o of p.flowSources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_BridgeFlowInput(o);
            if (p.networkOutputs != null)
                for (const o of p.networkOutputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_BridgeNetworkOutput(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_FlowEntitlementProps: function _aws_cdk_aws_mediaconnect_alpha_FlowEntitlementProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_StaticKeyEncryption(p.encryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_ZixiPullOutputConfig: function _aws_cdk_aws_mediaconnect_alpha_ZixiPullOutputConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_StaticKeyEncryption(p.encryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_ZixiPushOutputConfig: function _aws_cdk_aws_mediaconnect_alpha_ZixiPushOutputConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_StaticKeyEncryption(p.encryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SrtCallerOutputConfig: function _aws_cdk_aws_mediaconnect_alpha_SrtCallerOutputConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_SrtPasswordEncryption(p.encryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SrtListenerOutputConfig: function _aws_cdk_aws_mediaconnect_alpha_SrtListenerOutputConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_SrtPasswordEncryption(p.encryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_RouterTransitConfig: function _aws_cdk_aws_mediaconnect_alpha_RouterTransitConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.encryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig: function _aws_cdk_aws_mediaconnect_alpha_VpcInterfaceConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_VpcInterfaceDefineProps: function _aws_cdk_aws_mediaconnect_alpha_VpcInterfaceDefineProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_VpcInterfaceFromNetworkInterfacesProps: function _aws_cdk_aws_mediaconnect_alpha_VpcInterfaceFromNetworkInterfacesProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_RouterInputProps: function _aws_cdk_aws_mediaconnect_alpha_RouterInputProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.transitEncryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.transitEncryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SrtListenerProtocolProps: function _aws_cdk_aws_mediaconnect_alpha_SrtListenerProtocolProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryptionConfiguration))
                module.exports._aws_cdk_aws_mediaconnect_alpha_RouterSrtEncryption(p.decryptionConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SrtCallerProtocolProps: function _aws_cdk_aws_mediaconnect_alpha_SrtCallerProtocolProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryptionConfiguration))
                module.exports._aws_cdk_aws_mediaconnect_alpha_RouterSrtEncryption(p.decryptionConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MergeConfigurationProps: function _aws_cdk_aws_mediaconnect_alpha_MergeConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.protocols != null)
                for (const o of p.protocols)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediaconnect_alpha_RouterInputProtocol(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowConfigurationProps: function _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.sourceTransitDecryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.sourceTransitDecryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowConfigurationWithoutConnectionProps: function _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowConfigurationWithoutConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.sourceTransitDecryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.sourceTransitDecryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaLiveChannelConfigurationProps: function _aws_cdk_aws_mediaconnect_alpha_MediaLiveChannelConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.sourceTransitDecryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.sourceTransitDecryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaLiveChannelConfigurationWithoutConnectionProps: function _aws_cdk_aws_mediaconnect_alpha_MediaLiveChannelConfigurationWithoutConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.sourceTransitDecryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.sourceTransitDecryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_VpcNetworkConfigurationProps: function _aws_cdk_aws_mediaconnect_alpha_VpcNetworkConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SrtListenerOutputProtocolProps: function _aws_cdk_aws_mediaconnect_alpha_SrtListenerOutputProtocolProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionConfiguration))
                module.exports._aws_cdk_aws_mediaconnect_alpha_RouterSrtEncryption(p.encryptionConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_SrtCallerOutputProtocolProps: function _aws_cdk_aws_mediaconnect_alpha_SrtCallerOutputProtocolProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionConfiguration))
                module.exports._aws_cdk_aws_mediaconnect_alpha_RouterSrtEncryption(p.encryptionConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaLiveInputConnectionProps: function _aws_cdk_aws_mediaconnect_alpha_MediaLiveInputConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.destinationTransitEncryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.destinationTransitEncryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaLiveNoInputConnectionProps: function _aws_cdk_aws_mediaconnect_alpha_MediaLiveNoInputConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.destinationTransitEncryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.destinationTransitEncryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowConnectionProps: function _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.destinationTransitEncryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.destinationTransitEncryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowNoConnectionProps: function _aws_cdk_aws_mediaconnect_alpha_MediaConnectFlowNoConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.destinationTransitEncryption))
                module.exports._aws_cdk_aws_mediaconnect_alpha_TransitEncryption(p.destinationTransitEncryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
