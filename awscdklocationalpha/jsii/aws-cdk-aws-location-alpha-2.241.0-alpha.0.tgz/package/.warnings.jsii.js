function _aws_cdk_aws_location_alpha_IApiKey(p) {
}
function _aws_cdk_aws_location_alpha_ApiKeyProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.allowMapsActions != null)
            for (const o of p.allowMapsActions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_location_alpha_AllowMapsAction(o);
        if (p.allowPlacesActions != null)
            for (const o of p.allowPlacesActions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_location_alpha_AllowPlacesAction(o);
        if (p.allowRoutesActions != null)
            for (const o of p.allowRoutesActions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_location_alpha_AllowRoutesAction(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_location_alpha_AllowMapsAction(p) {
}
function _aws_cdk_aws_location_alpha_AllowPlacesAction(p) {
}
function _aws_cdk_aws_location_alpha_AllowRoutesAction(p) {
}
function _aws_cdk_aws_location_alpha_ApiKey(p) {
}
function _aws_cdk_aws_location_alpha_IGeofenceCollection(p) {
}
function _aws_cdk_aws_location_alpha_GeofenceCollectionProps(p) {
}
function _aws_cdk_aws_location_alpha_GeofenceCollection(p) {
}
function _aws_cdk_aws_location_alpha_IMap(p) {
}
function _aws_cdk_aws_location_alpha_MapProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.style))
            _aws_cdk_aws_location_alpha_Style(p.style);
        if (p.customLayers != null)
            for (const o of p.customLayers)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_location_alpha_CustomLayer(o);
        if (!visitedObjects.has(p.politicalView))
            _aws_cdk_aws_location_alpha_PoliticalView(p.politicalView);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_location_alpha_CustomLayer(p) {
}
function _aws_cdk_aws_location_alpha_Style(p) {
}
function _aws_cdk_aws_location_alpha_PoliticalView(p) {
}
function _aws_cdk_aws_location_alpha_Map(p) {
}
function _aws_cdk_aws_location_alpha_IPlaceIndex(p) {
}
function _aws_cdk_aws_location_alpha_PlaceIndexProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.dataSource))
            _aws_cdk_aws_location_alpha_DataSource(p.dataSource);
        if (!visitedObjects.has(p.intendedUse))
            _aws_cdk_aws_location_alpha_IntendedUse(p.intendedUse);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_location_alpha_IntendedUse(p) {
}
function _aws_cdk_aws_location_alpha_PlaceIndex(p) {
}
function _aws_cdk_aws_location_alpha_IRouteCalculator(p) {
}
function _aws_cdk_aws_location_alpha_RouteCalculatorProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.dataSource))
            _aws_cdk_aws_location_alpha_DataSource(p.dataSource);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_location_alpha_RouteCalculator(p) {
}
function _aws_cdk_aws_location_alpha_ITracker(p) {
}
function _aws_cdk_aws_location_alpha_TrackerProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.geofenceCollections != null)
            for (const o of p.geofenceCollections)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_location_alpha_IGeofenceCollection(o);
        if (!visitedObjects.has(p.positionFiltering))
            _aws_cdk_aws_location_alpha_PositionFiltering(p.positionFiltering);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_location_alpha_PositionFiltering(p) {
}
function _aws_cdk_aws_location_alpha_Tracker(p) {
}
function _aws_cdk_aws_location_alpha_DataSource(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_location_alpha_IApiKey, _aws_cdk_aws_location_alpha_ApiKeyProps, _aws_cdk_aws_location_alpha_AllowMapsAction, _aws_cdk_aws_location_alpha_AllowPlacesAction, _aws_cdk_aws_location_alpha_AllowRoutesAction, _aws_cdk_aws_location_alpha_ApiKey, _aws_cdk_aws_location_alpha_IGeofenceCollection, _aws_cdk_aws_location_alpha_GeofenceCollectionProps, _aws_cdk_aws_location_alpha_GeofenceCollection, _aws_cdk_aws_location_alpha_IMap, _aws_cdk_aws_location_alpha_MapProps, _aws_cdk_aws_location_alpha_CustomLayer, _aws_cdk_aws_location_alpha_Style, _aws_cdk_aws_location_alpha_PoliticalView, _aws_cdk_aws_location_alpha_Map, _aws_cdk_aws_location_alpha_IPlaceIndex, _aws_cdk_aws_location_alpha_PlaceIndexProps, _aws_cdk_aws_location_alpha_IntendedUse, _aws_cdk_aws_location_alpha_PlaceIndex, _aws_cdk_aws_location_alpha_IRouteCalculator, _aws_cdk_aws_location_alpha_RouteCalculatorProps, _aws_cdk_aws_location_alpha_RouteCalculator, _aws_cdk_aws_location_alpha_ITracker, _aws_cdk_aws_location_alpha_TrackerProps, _aws_cdk_aws_location_alpha_PositionFiltering, _aws_cdk_aws_location_alpha_Tracker, _aws_cdk_aws_location_alpha_DataSource };
