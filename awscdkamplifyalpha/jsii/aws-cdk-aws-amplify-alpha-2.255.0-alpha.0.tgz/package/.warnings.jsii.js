const VALIDATORS = { _aws_cdk_aws_amplify_alpha_AppProps: function _aws_cdk_aws_amplify_alpha_AppProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.autoBranchCreation))
                module.exports._aws_cdk_aws_amplify_alpha_AutoBranchCreation(p.autoBranchCreation);
            if (p.customResponseHeaders != null)
                for (const o of p.customResponseHeaders)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_amplify_alpha_CustomResponseHeader(o);
            if (p.customRules != null)
                for (const o of p.customRules)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_amplify_alpha_CustomRule(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_amplify_alpha_DomainOptions: function _aws_cdk_aws_amplify_alpha_DomainOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.subDomains != null)
                for (const o of p.subDomains)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_amplify_alpha_SubDomain(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_amplify_alpha_DomainProps: function _aws_cdk_aws_amplify_alpha_DomainProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.subDomains != null)
                for (const o of p.subDomains)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_amplify_alpha_SubDomain(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
