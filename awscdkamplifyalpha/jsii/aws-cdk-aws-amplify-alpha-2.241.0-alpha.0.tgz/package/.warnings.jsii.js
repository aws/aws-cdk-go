function _aws_cdk_aws_amplify_alpha_IApp(p) {
}
function _aws_cdk_aws_amplify_alpha_SourceCodeProviderConfig(p) {
}
function _aws_cdk_aws_amplify_alpha_ISourceCodeProvider(p) {
}
function _aws_cdk_aws_amplify_alpha_AppProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.autoBranchCreation))
            _aws_cdk_aws_amplify_alpha_AutoBranchCreation(p.autoBranchCreation);
        if (!visitedObjects.has(p.basicAuth))
            _aws_cdk_aws_amplify_alpha_BasicAuth(p.basicAuth);
        if (!visitedObjects.has(p.buildComputeType))
            _aws_cdk_aws_amplify_alpha_BuildComputeType(p.buildComputeType);
        if (!visitedObjects.has(p.cacheConfigType))
            _aws_cdk_aws_amplify_alpha_CacheConfigType(p.cacheConfigType);
        if (p.customResponseHeaders != null)
            for (const o of p.customResponseHeaders)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_amplify_alpha_CustomResponseHeader(o);
        if (p.customRules != null)
            for (const o of p.customRules)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_amplify_alpha_CustomRule(o);
        if (!visitedObjects.has(p.platform))
            _aws_cdk_aws_amplify_alpha_Platform(p.platform);
        if (!visitedObjects.has(p.sourceCodeProvider))
            _aws_cdk_aws_amplify_alpha_ISourceCodeProvider(p.sourceCodeProvider);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_amplify_alpha_App(p) {
}
function _aws_cdk_aws_amplify_alpha_AutoBranchCreation(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.basicAuth))
            _aws_cdk_aws_amplify_alpha_BasicAuth(p.basicAuth);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_amplify_alpha_RedirectStatus(p) {
}
function _aws_cdk_aws_amplify_alpha_CustomRuleOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.status))
            _aws_cdk_aws_amplify_alpha_RedirectStatus(p.status);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_amplify_alpha_CustomRule(p) {
}
function _aws_cdk_aws_amplify_alpha_CustomResponseHeader(p) {
}
function _aws_cdk_aws_amplify_alpha_Platform(p) {
}
function _aws_cdk_aws_amplify_alpha_CacheConfigType(p) {
}
function _aws_cdk_aws_amplify_alpha_BuildComputeType(p) {
}
function _aws_cdk_aws_amplify_alpha_IBranch(p) {
}
function _aws_cdk_aws_amplify_alpha_BranchOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.basicAuth))
            _aws_cdk_aws_amplify_alpha_BasicAuth(p.basicAuth);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_amplify_alpha_BranchProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.app))
            _aws_cdk_aws_amplify_alpha_IApp(p.app);
        if (!visitedObjects.has(p.basicAuth))
            _aws_cdk_aws_amplify_alpha_BasicAuth(p.basicAuth);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_amplify_alpha_Branch(p) {
}
function _aws_cdk_aws_amplify_alpha_DomainOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.subDomains != null)
            for (const o of p.subDomains)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_amplify_alpha_SubDomain(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_amplify_alpha_DomainProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.app))
            _aws_cdk_aws_amplify_alpha_IApp(p.app);
        if (p.subDomains != null)
            for (const o of p.subDomains)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_amplify_alpha_SubDomain(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_amplify_alpha_Domain(p) {
}
function _aws_cdk_aws_amplify_alpha_SubDomain(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.branch))
            _aws_cdk_aws_amplify_alpha_IBranch(p.branch);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_amplify_alpha_BasicAuthProps(p) {
}
function _aws_cdk_aws_amplify_alpha_BasicAuthConfig(p) {
}
function _aws_cdk_aws_amplify_alpha_BasicAuth(p) {
}
function _aws_cdk_aws_amplify_alpha_GitHubSourceCodeProviderProps(p) {
}
function _aws_cdk_aws_amplify_alpha_GitHubSourceCodeProvider(p) {
}
function _aws_cdk_aws_amplify_alpha_GitLabSourceCodeProviderProps(p) {
}
function _aws_cdk_aws_amplify_alpha_GitLabSourceCodeProvider(p) {
}
function _aws_cdk_aws_amplify_alpha_CodeCommitSourceCodeProviderProps(p) {
}
function _aws_cdk_aws_amplify_alpha_CodeCommitSourceCodeProvider(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_amplify_alpha_IApp, _aws_cdk_aws_amplify_alpha_SourceCodeProviderConfig, _aws_cdk_aws_amplify_alpha_ISourceCodeProvider, _aws_cdk_aws_amplify_alpha_AppProps, _aws_cdk_aws_amplify_alpha_App, _aws_cdk_aws_amplify_alpha_AutoBranchCreation, _aws_cdk_aws_amplify_alpha_RedirectStatus, _aws_cdk_aws_amplify_alpha_CustomRuleOptions, _aws_cdk_aws_amplify_alpha_CustomRule, _aws_cdk_aws_amplify_alpha_CustomResponseHeader, _aws_cdk_aws_amplify_alpha_Platform, _aws_cdk_aws_amplify_alpha_CacheConfigType, _aws_cdk_aws_amplify_alpha_BuildComputeType, _aws_cdk_aws_amplify_alpha_IBranch, _aws_cdk_aws_amplify_alpha_BranchOptions, _aws_cdk_aws_amplify_alpha_BranchProps, _aws_cdk_aws_amplify_alpha_Branch, _aws_cdk_aws_amplify_alpha_DomainOptions, _aws_cdk_aws_amplify_alpha_DomainProps, _aws_cdk_aws_amplify_alpha_Domain, _aws_cdk_aws_amplify_alpha_SubDomain, _aws_cdk_aws_amplify_alpha_BasicAuthProps, _aws_cdk_aws_amplify_alpha_BasicAuthConfig, _aws_cdk_aws_amplify_alpha_BasicAuth, _aws_cdk_aws_amplify_alpha_GitHubSourceCodeProviderProps, _aws_cdk_aws_amplify_alpha_GitHubSourceCodeProvider, _aws_cdk_aws_amplify_alpha_GitLabSourceCodeProviderProps, _aws_cdk_aws_amplify_alpha_GitLabSourceCodeProvider, _aws_cdk_aws_amplify_alpha_CodeCommitSourceCodeProviderProps, _aws_cdk_aws_amplify_alpha_CodeCommitSourceCodeProvider };
