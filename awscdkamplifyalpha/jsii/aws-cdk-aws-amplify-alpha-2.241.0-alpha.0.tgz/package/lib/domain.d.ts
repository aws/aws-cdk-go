import type * as acm from 'aws-cdk-lib/aws-certificatemanager';
import type * as iam from 'aws-cdk-lib/aws-iam';
import type { IResolvable } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import type { IApp } from './app';
import type { IBranch } from './branch';
/**
 * Options to add a domain to an application
 */
export interface DomainOptions {
    /**
     * The name of the domain
     *
     * @default - the construct's id
     */
    readonly domainName?: string;
    /**
     * Subdomains
     *
     * @default - use `addSubDomain()` to add subdomains
     */
    readonly subDomains?: SubDomain[];
    /**
     * Automatically create subdomains for connected branches
     *
     * @default false
     */
    readonly enableAutoSubdomain?: boolean;
    /**
     * Branches which should automatically create subdomains
     *
     * @default - all repository branches ['*', 'pr*']
     */
    readonly autoSubdomainCreationPatterns?: string[];
    /**
     * The type of SSL/TLS certificate to use for your custom domain
     *
     * @default - Amplify uses the default certificate that it provisions and manages for you
     */
    readonly customCertificate?: acm.ICertificate;
}
/**
 * Properties for a Domain
 */
export interface DomainProps extends DomainOptions {
    /**
     * The application to which the domain must be connected
     */
    readonly app: IApp;
    /**
     * The IAM role with access to Route53 when using enableAutoSubdomain
     * @default - the IAM role from App.grantPrincipal
     */
    readonly autoSubDomainIamRole?: iam.IRole;
}
/**
 * An Amplify Console domain
 */
export declare class Domain extends Resource {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * The ARN of the domain
     *
     * @attribute
     */
    readonly arn: string;
    /**
     * The DNS Record for certificate verification
     *
     * @attribute
     */
    readonly certificateRecord: string;
    /**
     * The name of the domain
     *
     * @attribute
     */
    readonly domainName: string;
    /**
     * The status of the domain association
     *
     * @attribute
     */
    readonly domainStatus: string;
    /**
     * The reason for the current status of the domain
     *
     * @attribute
     */
    readonly statusReason: string;
    /**
     * Branch patterns for the automatically created subdomain.
     *
     * @attribute
     */
    readonly domainAutoSubDomainCreationPatterns: string[];
    /**
     * The IAM service role for the subdomain.
     *
     * @attribute
     */
    readonly domainAutoSubDomainIamRole: string;
    /**
     * Specifies whether the automated creation of subdomains for branches is enabled.
     *
     * @attribute
     */
    readonly domainEnableAutoSubDomain: IResolvable;
    private readonly subDomains;
    constructor(scope: Construct, id: string, props: DomainProps);
    /**
     * Maps a branch to a sub domain
     *
     * @param branch The branch
     * @param prefix The prefix. Use '' to map to the root of the domain. Defaults to branch name.
     */
    mapSubDomain(branch: IBranch, prefix?: string): this;
    /**
     * Maps a branch to the domain root
     */
    mapRoot(branch: IBranch): this;
    private validateDomain;
    private renderSubDomainSettings;
}
/**
 * Sub domain settings
 */
export interface SubDomain {
    /**
     * The branch
     */
    readonly branch: IBranch;
    /**
     * The prefix. Use '' to map to the root of the domain
     *
     * @default - the branch name
     */
    readonly prefix?: string;
}
