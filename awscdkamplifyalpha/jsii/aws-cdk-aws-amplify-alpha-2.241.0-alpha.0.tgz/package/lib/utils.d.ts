import { Platform } from './app';
export declare function renderEnvironmentVariables(vars: {
    [name: string]: string;
}): {
    name: string;
    value: string;
}[];
/**
 * Utility function to check if the platform is a server-side rendering platform
 */
export declare function isServerSideRendered(platform?: Platform): boolean;
