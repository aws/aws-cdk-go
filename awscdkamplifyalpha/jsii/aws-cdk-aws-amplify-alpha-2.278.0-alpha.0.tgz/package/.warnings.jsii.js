const VALIDATORS = { _aws_cdk_aws_amplify_alpha_SourceCodeProviderConfig: function _aws_cdk_aws_amplify_alpha_SourceCodeProviderConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.accessToken))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_SecretValue(p.accessToken);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.oauthToken))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_SecretValue(p.oauthToken);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_amplify_alpha_AppProps: function _aws_cdk_aws_amplify_alpha_AppProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.autoBranchCreation))
                module.exports._aws_cdk_aws_amplify_alpha_AutoBranchCreation(p.autoBranchCreation);
            if (!visitedObjects.has(p.buildSpec))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_codebuild_BuildSpec(p.buildSpec);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.computeRole))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.computeRole);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.customResponseHeaders != null)
                for (const o of p.customResponseHeaders)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_amplify_alpha_CustomResponseHeader(o);
            if (p.customRules != null)
                for (const o of p.customRules)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_amplify_alpha_CustomRule(o);
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_amplify_alpha_AutoBranchCreation: function _aws_cdk_aws_amplify_alpha_AutoBranchCreation(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.buildSpec))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_codebuild_BuildSpec(p.buildSpec);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_amplify_alpha_BranchOptions: function _aws_cdk_aws_amplify_alpha_BranchOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.asset))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_s3_assets_Asset(p.asset);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.buildSpec))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_codebuild_BuildSpec(p.buildSpec);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.computeRole))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.computeRole);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_amplify_alpha_BranchProps: function _aws_cdk_aws_amplify_alpha_BranchProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.asset))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_s3_assets_Asset(p.asset);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.buildSpec))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_codebuild_BuildSpec(p.buildSpec);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.computeRole))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.computeRole);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_amplify_alpha_DomainOptions: function _aws_cdk_aws_amplify_alpha_DomainOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.customCertificate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_certificatemanager_ICertificate(p.customCertificate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.subDomains != null)
                for (const o of p.subDomains)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_amplify_alpha_SubDomain(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_amplify_alpha_DomainProps: function _aws_cdk_aws_amplify_alpha_DomainProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.autoSubDomainIamRole))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.autoSubDomainIamRole);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.customCertificate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_certificatemanager_ICertificate(p.customCertificate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.subDomains != null)
                for (const o of p.subDomains)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_amplify_alpha_SubDomain(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_amplify_alpha_BasicAuthProps: function _aws_cdk_aws_amplify_alpha_BasicAuthProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_kms_IKey(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.password))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_SecretValue(p.password);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_amplify_alpha_GitHubSourceCodeProviderProps: function _aws_cdk_aws_amplify_alpha_GitHubSourceCodeProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.oauthToken))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_SecretValue(p.oauthToken);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_amplify_alpha_GitLabSourceCodeProviderProps: function _aws_cdk_aws_amplify_alpha_GitLabSourceCodeProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.oauthToken))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_SecretValue(p.oauthToken);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_amplify_alpha_CodeCommitSourceCodeProviderProps: function _aws_cdk_aws_amplify_alpha_CodeCommitSourceCodeProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.repository))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_codecommit_IRepository(p.repository);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
