import * as lambda from 'aws-cdk-lib/aws-lambda';
import type { Construct } from 'constructs';
import type { BundlingOptions } from './types';
/**
 * Properties for a GolangFunction
 */
export interface GoFunctionProps extends lambda.FunctionOptions {
    /**
     * The path to the folder or file that contains the main application entry point files for the project.
     *
     * This accepts either a path to a directory or file.
     *
     * If a directory path is provided then it will assume there is a Go entry file (i.e. `main.go`) and
     * will construct the build command using the directory path.
     *
     * For example, if you provide the entry as:
     *
     *     entry: 'my-lambda-app/cmd/api'
     *
     * Then the `go build` command would be:
     *
     *     `go build ./cmd/api`
     *
     * If a path to a file is provided then it will use the filepath in the build command.
     *
     * For example, if you provide the entry as:
     *
     *     entry: 'my-lambda-app/cmd/api/main.go'
     *
     * Then the `go build` command would be:
     *
     *     `go build ./cmd/api/main.go`
     */
    readonly entry: string;
    /**
     * The runtime environment. Only runtimes of the Golang family and provided family are supported.
     *
     * @default lambda.Runtime.PROVIDED_AL2
     */
    readonly runtime?: lambda.Runtime;
    /**
     * Directory containing your go.mod file
     *
     * This will accept either a directory path containing a `go.mod` file
     * or a filepath to your `go.mod` file (i.e. `path/to/go.mod`).
     *
     * This will be used as the source of the volume mounted in the Docker
     * container and will be the directory where it will run `go build` from.
     *
     * @default - the path is found by walking up parent directories searching for
     *  a `go.mod` file from the location of `entry`
     */
    readonly moduleDir?: string;
    /**
     * Bundling options
     *
     * @default - use default bundling options
     */
    readonly bundling?: BundlingOptions;
}
/**
 * A Golang Lambda function
 */
export declare class GoFunction extends lambda.Function {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * The address of the Google Go proxy
     */
    static readonly GOOGLE_GOPROXY = "https://proxy.golang.org";
    constructor(scope: Construct, id: string, props: GoFunctionProps);
}
