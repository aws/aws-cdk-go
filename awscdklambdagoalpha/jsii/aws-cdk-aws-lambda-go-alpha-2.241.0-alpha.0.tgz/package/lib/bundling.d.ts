import type { Architecture, AssetCode } from 'aws-cdk-lib/aws-lambda';
import { Runtime } from 'aws-cdk-lib/aws-lambda';
import * as cdk from 'aws-cdk-lib/core';
import type { BundlingOptions } from './types';
/**
 * Options for bundling
 */
export interface BundlingProps extends BundlingOptions {
    /**
     * Directory containing your go.mod file
     *
     * This will accept either a directory path containing a `go.mod` file
     * or a filepath to your `go.mod` file (i.e. `path/to/go.mod`).
     *
     * This will be used as the source of the volume mounted in the Docker
     * container and will be the directory where it will run `go build` from.
     *
     * @default - the path is found by walking up parent directories searching for
     *  a `go.mod` file from the location of `entry`
     */
    readonly moduleDir: string;
    /**
     * The path to the folder or file that contains the main application entry point files for the project.
     *
     * This accepts either a path to a directory or file.
     *
     * If a directory path is provided then it will assume there is a Go entry file (i.e. `main.go`) and
     * will construct the build command using the directory path.
     *
     * For example, if you provide the entry as:
     *
     *     entry: 'my-lambda-app/cmd/api'
     *
     * Then the `go build` command would be:
     *
     *     `go build ./cmd/api`
     *
     * If a path to a file is provided then it will use the filepath in the build command.
     *
     * For example, if you provide the entry as:
     *
     *     entry: 'my-lambda-app/cmd/api/main.go'
     *
     * Then the `go build` command would be:
     *
     *     `go build ./cmd/api/main.go`
     */
    readonly entry: string;
    /**
     * The runtime of the lambda function
     */
    readonly runtime: Runtime;
    /**
     * The system architecture of the lambda function
     */
    readonly architecture: Architecture;
    /**
     * Which option to use to copy the source files to the docker container and output files back
     * @default - BundlingFileAccess.BIND_MOUNT
     */
    readonly bundlingFileAccess?: cdk.BundlingFileAccess;
}
/**
 * Bundling
 */
export declare class Bundling implements cdk.BundlingOptions {
    private readonly props;
    static bundle(options: BundlingProps): AssetCode;
    static clearRunsLocallyCache(): void;
    private static runsLocally?;
    readonly image: cdk.DockerImage;
    readonly command: string[];
    readonly environment?: {
        [key: string]: string;
    };
    readonly local?: cdk.ILocalBundling;
    readonly entrypoint?: string[];
    readonly volumes?: cdk.DockerVolume[];
    readonly volumesFrom?: string[];
    readonly workingDirectory?: string;
    readonly user?: string;
    readonly securityOpt?: string;
    readonly network?: string;
    readonly bundlingFileAccess?: cdk.BundlingFileAccess;
    private readonly relativeEntryPath;
    constructor(props: BundlingProps);
    createBundlingCommand(inputDir: string, outputDir: string, osPlatform?: NodeJS.Platform): string;
}
