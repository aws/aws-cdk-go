import type { SpawnSyncOptions } from 'child_process';
export declare function getGoBuildVersion(): boolean | undefined;
/**
 * Spawn sync with error handling
 */
export declare function exec(cmd: string, args: string[], options?: SpawnSyncOptions): import("child_process").SpawnSyncReturns<string | Buffer<ArrayBufferLike>>;
export declare function findUp(name: string, directory?: string): string | undefined;
