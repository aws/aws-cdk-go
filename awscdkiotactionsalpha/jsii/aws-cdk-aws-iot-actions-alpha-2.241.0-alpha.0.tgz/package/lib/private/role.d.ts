import * as iam from 'aws-cdk-lib/aws-iam';
import type { IConstruct } from 'constructs';
/**
 * Obtain the Role for the TopicRule
 *
 * If a role already exists, it will be returned. This ensures that if a rule have multiple
 * actions, they will share a role.
 * @internal
 */
export declare function singletonActionRole(scope: IConstruct): iam.IRole;
