import type * as iot from '@aws-cdk/aws-iot-alpha';
import { Duration, Size } from 'aws-cdk-lib';
import type { CommonActionProps } from './common-action-props';
export interface HttpActionSigV4Auth {
    /**
     * The service name.
     */
    readonly serviceName: string;
    /**
     * The signing region.
     */
    readonly signingRegion: string;
}
export interface HttpActionHeader {
    /**
     * The HTTP header key.
     */
    readonly key: string;
    /**
     * The HTTP header value. Substitution templates are supported.
     */
    readonly value: string;
}
/**
 * Configuration for batching HTTP action messages.
 *
 * @see https://docs.aws.amazon.com/iot/latest/developerguide/http_batching.html
 */
export interface HttpActionBatchConfig {
    /**
     * The maximum amount of time an outgoing message waits for other messages to create the batch.
     *
     * Must be between 5 ms and 200 ms.
     *
     * @default Duration.millis(20)
     */
    readonly maxBatchOpenDuration?: Duration;
    /**
     * The maximum number of messages that are batched together in a single IoT rule action execution.
     *
     * Must be between 2 and 10.
     *
     * @default 10
     */
    readonly maxBatchSize?: number;
    /**
     * Maximum size of a message batch.
     *
     * Must be between 100 bytes and 128 KiB.
     *
     * @default Size.kibibytes(5)
     */
    readonly maxBatchSizeBytes?: Size;
}
/**
 * Configuration properties of an HTTPS action.
 *
 * @see https://docs.aws.amazon.com/iot/latest/developerguide/https-rule-action.html
 */
export interface HttpsActionProps extends CommonActionProps {
    /**
     * If specified, AWS IoT uses the confirmation URL to create a matching topic rule destination.
     */
    readonly confirmationUrl?: string;
    /**
     * The headers to include in the HTTPS request to the endpoint.
     */
    readonly headers?: Array<HttpActionHeader>;
    /**
     * Use Sigv4 authorization.
     */
    readonly auth?: HttpActionSigV4Auth;
    /**
     * Configuration for batching HTTP action messages.
     *
     * When provided, batching is automatically enabled.
     *
     * @see https://docs.aws.amazon.com/iot/latest/developerguide/http_batching.html
     * @default - Batching is disabled
     */
    readonly batchConfig?: HttpActionBatchConfig;
}
/**
 * The action to send data from an MQTT message to a web application or service.
 */
export declare class HttpsAction implements iot.IAction {
    private readonly role?;
    private readonly url;
    private readonly confirmationUrl?;
    private readonly headers?;
    private readonly auth?;
    private readonly batchConfig?;
    /**
     * @param url The url to which to send post request.
     * @param props Optional properties to not use default.
     */
    constructor(url: string, props?: HttpsActionProps);
    private validateBatchConfig;
    /**
     * @internal
     */
    _bind(topicRule: iot.ITopicRule): iot.ActionConfig;
}
