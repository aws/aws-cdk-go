import type * as iot from '@aws-cdk/aws-iot-alpha';
import type * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import type { CommonActionProps } from './common-action-props';
/**
 * Configuration properties of an action for CloudWatch alarm.
 */
export interface CloudWatchSetAlarmStateActionProps extends CommonActionProps {
    /**
     * The reason for the alarm change.
     *
     * @default None
     */
    readonly reason?: string;
    /**
     * The value of the alarm state to set.
     */
    readonly alarmStateToSet: cloudwatch.AlarmState;
}
/**
 * The action to change the state of an Amazon CloudWatch alarm.
 */
export declare class CloudWatchSetAlarmStateAction implements iot.IAction {
    private readonly alarm;
    private readonly props;
    constructor(alarm: cloudwatch.IAlarm, props: CloudWatchSetAlarmStateActionProps);
    /**
     * @internal
     */
    _bind(topicRule: iot.ITopicRule): iot.ActionConfig;
}
