import type * as iot from '@aws-cdk/aws-iot-alpha';
import type * as lambda from 'aws-cdk-lib/aws-lambda';
/**
 * The action to invoke an AWS Lambda function, passing in an MQTT message.
 */
export declare class LambdaFunctionAction implements iot.IAction {
    private readonly func;
    /**
     * @param func The lambda function to be invoked by this action
     */
    constructor(func: lambda.IFunction);
    /**
     * @internal
     */
    _bind(topicRule: iot.ITopicRule): iot.ActionConfig;
}
