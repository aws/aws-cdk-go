function _aws_cdk_aws_iot_actions_alpha_CloudWatchLogsActionProps(p) {
}
function _aws_cdk_aws_iot_actions_alpha_CloudWatchLogsAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_CloudWatchPutMetricActionProps(p) {
}
function _aws_cdk_aws_iot_actions_alpha_CloudWatchPutMetricAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_CloudWatchSetAlarmStateActionProps(p) {
}
function _aws_cdk_aws_iot_actions_alpha_CloudWatchSetAlarmStateAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_CommonActionProps(p) {
}
function _aws_cdk_aws_iot_actions_alpha_DynamoDBv2PutItemActionProps(p) {
}
function _aws_cdk_aws_iot_actions_alpha_DynamoDBv2PutItemAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_FirehoseRecordSeparator(p) {
}
function _aws_cdk_aws_iot_actions_alpha_FirehosePutRecordActionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.recordSeparator))
            _aws_cdk_aws_iot_actions_alpha_FirehoseRecordSeparator(p.recordSeparator);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_iot_actions_alpha_FirehosePutRecordAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_IotEventsPutMessageActionProps(p) {
}
function _aws_cdk_aws_iot_actions_alpha_IotEventsPutMessageAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_MqttQualityOfService(p) {
}
function _aws_cdk_aws_iot_actions_alpha_IotRepublishMqttActionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.qualityOfService))
            _aws_cdk_aws_iot_actions_alpha_MqttQualityOfService(p.qualityOfService);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_iot_actions_alpha_IotRepublishMqttAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_KinesisPutRecordActionProps(p) {
}
function _aws_cdk_aws_iot_actions_alpha_KinesisPutRecordAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_LambdaFunctionAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_OpenSearchActionProps(p) {
}
function _aws_cdk_aws_iot_actions_alpha_OpenSearchAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_S3PutObjectActionProps(p) {
}
function _aws_cdk_aws_iot_actions_alpha_S3PutObjectAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_SqsQueueActionProps(p) {
}
function _aws_cdk_aws_iot_actions_alpha_SqsQueueAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_SnsActionMessageFormat(p) {
}
function _aws_cdk_aws_iot_actions_alpha_SnsTopicActionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.messageFormat))
            _aws_cdk_aws_iot_actions_alpha_SnsActionMessageFormat(p.messageFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_iot_actions_alpha_SnsTopicAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_HttpActionSigV4Auth(p) {
}
function _aws_cdk_aws_iot_actions_alpha_HttpActionHeader(p) {
}
function _aws_cdk_aws_iot_actions_alpha_HttpActionBatchConfig(p) {
}
function _aws_cdk_aws_iot_actions_alpha_HttpsActionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.auth))
            _aws_cdk_aws_iot_actions_alpha_HttpActionSigV4Auth(p.auth);
        if (!visitedObjects.has(p.batchConfig))
            _aws_cdk_aws_iot_actions_alpha_HttpActionBatchConfig(p.batchConfig);
        if (p.headers != null)
            for (const o of p.headers)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_iot_actions_alpha_HttpActionHeader(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_iot_actions_alpha_HttpsAction(p) {
}
function _aws_cdk_aws_iot_actions_alpha_StepFunctionsStateMachineActionProps(p) {
}
function _aws_cdk_aws_iot_actions_alpha_StepFunctionsStateMachineAction(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_iot_actions_alpha_CloudWatchLogsActionProps, _aws_cdk_aws_iot_actions_alpha_CloudWatchLogsAction, _aws_cdk_aws_iot_actions_alpha_CloudWatchPutMetricActionProps, _aws_cdk_aws_iot_actions_alpha_CloudWatchPutMetricAction, _aws_cdk_aws_iot_actions_alpha_CloudWatchSetAlarmStateActionProps, _aws_cdk_aws_iot_actions_alpha_CloudWatchSetAlarmStateAction, _aws_cdk_aws_iot_actions_alpha_CommonActionProps, _aws_cdk_aws_iot_actions_alpha_DynamoDBv2PutItemActionProps, _aws_cdk_aws_iot_actions_alpha_DynamoDBv2PutItemAction, _aws_cdk_aws_iot_actions_alpha_FirehoseRecordSeparator, _aws_cdk_aws_iot_actions_alpha_FirehosePutRecordActionProps, _aws_cdk_aws_iot_actions_alpha_FirehosePutRecordAction, _aws_cdk_aws_iot_actions_alpha_IotEventsPutMessageActionProps, _aws_cdk_aws_iot_actions_alpha_IotEventsPutMessageAction, _aws_cdk_aws_iot_actions_alpha_MqttQualityOfService, _aws_cdk_aws_iot_actions_alpha_IotRepublishMqttActionProps, _aws_cdk_aws_iot_actions_alpha_IotRepublishMqttAction, _aws_cdk_aws_iot_actions_alpha_KinesisPutRecordActionProps, _aws_cdk_aws_iot_actions_alpha_KinesisPutRecordAction, _aws_cdk_aws_iot_actions_alpha_LambdaFunctionAction, _aws_cdk_aws_iot_actions_alpha_OpenSearchActionProps, _aws_cdk_aws_iot_actions_alpha_OpenSearchAction, _aws_cdk_aws_iot_actions_alpha_S3PutObjectActionProps, _aws_cdk_aws_iot_actions_alpha_S3PutObjectAction, _aws_cdk_aws_iot_actions_alpha_SqsQueueActionProps, _aws_cdk_aws_iot_actions_alpha_SqsQueueAction, _aws_cdk_aws_iot_actions_alpha_SnsActionMessageFormat, _aws_cdk_aws_iot_actions_alpha_SnsTopicActionProps, _aws_cdk_aws_iot_actions_alpha_SnsTopicAction, _aws_cdk_aws_iot_actions_alpha_HttpActionSigV4Auth, _aws_cdk_aws_iot_actions_alpha_HttpActionHeader, _aws_cdk_aws_iot_actions_alpha_HttpActionBatchConfig, _aws_cdk_aws_iot_actions_alpha_HttpsActionProps, _aws_cdk_aws_iot_actions_alpha_HttpsAction, _aws_cdk_aws_iot_actions_alpha_StepFunctionsStateMachineActionProps, _aws_cdk_aws_iot_actions_alpha_StepFunctionsStateMachineAction };
