const VALIDATORS = { _aws_cdk_aws_iot_actions_alpha_HttpsActionProps: function _aws_cdk_aws_iot_actions_alpha_HttpsActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.batchConfig))
                module.exports._aws_cdk_aws_iot_actions_alpha_HttpActionBatchConfig(p.batchConfig);
            if (p.headers != null)
                for (const o of p.headers)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_iot_actions_alpha_HttpActionHeader(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
