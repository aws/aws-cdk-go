const VALIDATORS = { _aws_cdk_aws_pipes_targets_alpha_ApiDestinationTargetParameters: function _aws_cdk_aws_pipes_targets_alpha_ApiDestinationTargetParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputTransformation))
                try {
                    require("@aws-cdk/aws-pipes-alpha/.warnings.jsii.js")._aws_cdk_aws_pipes_alpha_IInputTransformation(p.inputTransformation);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_targets_alpha_ApiGatewayTargetParameters: function _aws_cdk_aws_pipes_targets_alpha_ApiGatewayTargetParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputTransformation))
                try {
                    require("@aws-cdk/aws-pipes-alpha/.warnings.jsii.js")._aws_cdk_aws_pipes_alpha_IInputTransformation(p.inputTransformation);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_targets_alpha_CloudWatchLogsTargetParameters: function _aws_cdk_aws_pipes_targets_alpha_CloudWatchLogsTargetParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputTransformation))
                try {
                    require("@aws-cdk/aws-pipes-alpha/.warnings.jsii.js")._aws_cdk_aws_pipes_alpha_IInputTransformation(p.inputTransformation);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_targets_alpha_EventBridgeTargetParameters: function _aws_cdk_aws_pipes_targets_alpha_EventBridgeTargetParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputTransformation))
                try {
                    require("@aws-cdk/aws-pipes-alpha/.warnings.jsii.js")._aws_cdk_aws_pipes_alpha_IInputTransformation(p.inputTransformation);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_targets_alpha_FirehoseTargetParameters: function _aws_cdk_aws_pipes_targets_alpha_FirehoseTargetParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputTransformation))
                try {
                    require("@aws-cdk/aws-pipes-alpha/.warnings.jsii.js")._aws_cdk_aws_pipes_alpha_IInputTransformation(p.inputTransformation);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_targets_alpha_KinesisTargetParameters: function _aws_cdk_aws_pipes_targets_alpha_KinesisTargetParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputTransformation))
                try {
                    require("@aws-cdk/aws-pipes-alpha/.warnings.jsii.js")._aws_cdk_aws_pipes_alpha_IInputTransformation(p.inputTransformation);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_targets_alpha_LambdaFunctionParameters: function _aws_cdk_aws_pipes_targets_alpha_LambdaFunctionParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputTransformation))
                try {
                    require("@aws-cdk/aws-pipes-alpha/.warnings.jsii.js")._aws_cdk_aws_pipes_alpha_IInputTransformation(p.inputTransformation);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_targets_alpha_SageMakerTargetParameters: function _aws_cdk_aws_pipes_targets_alpha_SageMakerTargetParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputTransformation))
                try {
                    require("@aws-cdk/aws-pipes-alpha/.warnings.jsii.js")._aws_cdk_aws_pipes_alpha_IInputTransformation(p.inputTransformation);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_targets_alpha_SnsTargetParameters: function _aws_cdk_aws_pipes_targets_alpha_SnsTargetParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputTransformation))
                try {
                    require("@aws-cdk/aws-pipes-alpha/.warnings.jsii.js")._aws_cdk_aws_pipes_alpha_IInputTransformation(p.inputTransformation);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_targets_alpha_SqsTargetParameters: function _aws_cdk_aws_pipes_targets_alpha_SqsTargetParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputTransformation))
                try {
                    require("@aws-cdk/aws-pipes-alpha/.warnings.jsii.js")._aws_cdk_aws_pipes_alpha_IInputTransformation(p.inputTransformation);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_targets_alpha_SfnStateMachineParameters: function _aws_cdk_aws_pipes_targets_alpha_SfnStateMachineParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputTransformation))
                try {
                    require("@aws-cdk/aws-pipes-alpha/.warnings.jsii.js")._aws_cdk_aws_pipes_alpha_IInputTransformation(p.inputTransformation);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
