function _aws_cdk_aws_pipes_targets_alpha_ApiDestinationTargetParameters(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_ApiDestinationTarget(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_ApiGatewayTargetParameters(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_ApiGatewayTarget(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_CloudWatchLogsTargetParameters(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_CloudWatchLogsTarget(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_EventBridgeTargetParameters(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_EventBridgeTarget(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_FirehoseTargetParameters(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_FirehoseTarget(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_KinesisTargetParameters(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_KinesisTarget(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_LambdaFunctionParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.invocationType))
            _aws_cdk_aws_pipes_targets_alpha_LambdaFunctionInvocationType(p.invocationType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_pipes_targets_alpha_LambdaFunctionInvocationType(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_LambdaFunction(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_SageMakerTargetParameters(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_SageMakerTarget(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_SnsTargetParameters(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_SnsTarget(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_SqsTargetParameters(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_SqsTarget(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_SfnStateMachineParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.invocationType))
            _aws_cdk_aws_pipes_targets_alpha_StateMachineInvocationType(p.invocationType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_pipes_targets_alpha_StateMachineInvocationType(p) {
}
function _aws_cdk_aws_pipes_targets_alpha_SfnStateMachine(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_pipes_targets_alpha_ApiDestinationTargetParameters, _aws_cdk_aws_pipes_targets_alpha_ApiDestinationTarget, _aws_cdk_aws_pipes_targets_alpha_ApiGatewayTargetParameters, _aws_cdk_aws_pipes_targets_alpha_ApiGatewayTarget, _aws_cdk_aws_pipes_targets_alpha_CloudWatchLogsTargetParameters, _aws_cdk_aws_pipes_targets_alpha_CloudWatchLogsTarget, _aws_cdk_aws_pipes_targets_alpha_EventBridgeTargetParameters, _aws_cdk_aws_pipes_targets_alpha_EventBridgeTarget, _aws_cdk_aws_pipes_targets_alpha_FirehoseTargetParameters, _aws_cdk_aws_pipes_targets_alpha_FirehoseTarget, _aws_cdk_aws_pipes_targets_alpha_KinesisTargetParameters, _aws_cdk_aws_pipes_targets_alpha_KinesisTarget, _aws_cdk_aws_pipes_targets_alpha_LambdaFunctionParameters, _aws_cdk_aws_pipes_targets_alpha_LambdaFunctionInvocationType, _aws_cdk_aws_pipes_targets_alpha_LambdaFunction, _aws_cdk_aws_pipes_targets_alpha_SageMakerTargetParameters, _aws_cdk_aws_pipes_targets_alpha_SageMakerTarget, _aws_cdk_aws_pipes_targets_alpha_SnsTargetParameters, _aws_cdk_aws_pipes_targets_alpha_SnsTarget, _aws_cdk_aws_pipes_targets_alpha_SqsTargetParameters, _aws_cdk_aws_pipes_targets_alpha_SqsTarget, _aws_cdk_aws_pipes_targets_alpha_SfnStateMachineParameters, _aws_cdk_aws_pipes_targets_alpha_StateMachineInvocationType, _aws_cdk_aws_pipes_targets_alpha_SfnStateMachine };
