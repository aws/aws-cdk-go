import type { IInputTransformation, IPipe, ITarget, TargetConfig } from '@aws-cdk/aws-pipes-alpha';
import type { IRestApi } from 'aws-cdk-lib/aws-apigateway';
import type { IRole } from 'aws-cdk-lib/aws-iam';
/**
 * API Gateway REST API target properties.
 */
export interface ApiGatewayTargetParameters {
    /**
     * The input transformation to apply to the message before sending it to the target.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargetparameters.html#cfn-pipes-pipe-pipetargetparameters-inputtemplate
     * @default - none
     */
    readonly inputTransformation?: IInputTransformation;
    /**
     * The method for API Gateway resource.
     *
     * @default '*' - ANY
     */
    readonly method?: string;
    /**
     * The path for the API Gateway resource.
     *
     * @default '/'
     */
    readonly path?: string;
    /**
     * The deployment stage for the API Gateway resource.
     *
     * @default - the value of `deploymentStage.stageName` of target API Gateway resource.
     */
    readonly stage?: string;
    /**
     * The headers to send as part of the request invoking the API Gateway REST API.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargethttpparameters.html#cfn-pipes-pipe-pipetargethttpparameters-headerparameters
     * @default - none
     */
    readonly headerParameters?: Record<string, string>;
    /**
     * The path parameter values used to populate the API Gateway REST API path wildcards ("*").
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargethttpparameters.html#cfn-pipes-pipe-pipetargethttpparameters-pathparametervalues
     * @default - none
     */
    readonly pathParameterValues?: string[];
    /**
     * The query string keys/values that need to be sent as part of request invoking the API Gateway REST API.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargethttpparameters.html#cfn-pipes-pipe-pipetargethttpparameters-querystringparameters
     * @default - none
     */
    readonly queryStringParameters?: Record<string, string>;
}
/**
 * An EventBridge Pipes target that sends messages to an EventBridge API destination.
 */
export declare class ApiGatewayTarget implements ITarget {
    private restApi;
    private restApiParameters?;
    private restApiArn;
    readonly targetArn: string;
    constructor(restApi: IRestApi, parameters?: ApiGatewayTargetParameters);
    grantPush(grantee: IRole): void;
    bind(pipe: IPipe): TargetConfig;
}
