import type { IInputTransformation, IPipe, ITarget, TargetConfig } from '@aws-cdk/aws-pipes-alpha';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { IStream } from 'aws-cdk-lib/aws-kinesis';
/**
 * Kinesis target properties.
 */
export interface KinesisTargetParameters {
    /**
     * The input transformation to apply to the message before sending it to the target.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargetparameters.html#cfn-pipes-pipe-pipetargetparameters-inputtemplate
     * @default - none
     */
    readonly inputTransformation?: IInputTransformation;
    /**
     * Determines which shard in the stream the data record is assigned to.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargetkinesisstreamparameters.html#cfn-pipes-pipe-pipetargetkinesisstreamparameters-partitionkey
     */
    readonly partitionKey: string;
}
/**
 * An EventBridge Pipes target that sends messages to a Kinesis stream.
 */
export declare class KinesisTarget implements ITarget {
    private stream;
    private streamParameters;
    readonly targetArn: string;
    constructor(stream: IStream, parameters: KinesisTargetParameters);
    grantPush(grantee: IRole): void;
    bind(pipe: IPipe): TargetConfig;
}
