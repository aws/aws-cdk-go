import type { IInputTransformation, IPipe, ITarget, TargetConfig } from '@aws-cdk/aws-pipes-alpha';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { ILogGroup } from 'aws-cdk-lib/aws-logs';
/**
 * CloudWatch Logs target properties.
 */
export interface CloudWatchLogsTargetParameters {
    /**
     * The input transformation to apply to the message before sending it to the target.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargetparameters.html#cfn-pipes-pipe-pipetargetparameters-inputtemplate
     * @default - none
     */
    readonly inputTransformation?: IInputTransformation;
    /**
     * The name of the log stream.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargetcloudwatchlogsparameters.html#cfn-pipes-pipe-pipetargetcloudwatchlogsparameters-logstreamname
     * @default - none
     */
    readonly logStreamName?: string;
    /**
     * The JSON path expression that references the timestamp in the payload.
     * This is the time that the event occurred, as a JSON path expression in the payload.
     *
     * @example '$.data.timestamp'
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargetcloudwatchlogsparameters.html#cfn-pipes-pipe-pipetargetcloudwatchlogsparameters-timestamp
     * @default - current time
     */
    readonly timestamp?: string;
}
/**
 * An EventBridge Pipes target that sends messages to a CloudWatch Logs log group.
 */
export declare class CloudWatchLogsTarget implements ITarget {
    private logGroup;
    private cloudWatchLogsParameters?;
    readonly targetArn: string;
    constructor(logGroup: ILogGroup, parameters?: CloudWatchLogsTargetParameters);
    grantPush(grantee: IRole): void;
    bind(pipe: IPipe): TargetConfig;
}
