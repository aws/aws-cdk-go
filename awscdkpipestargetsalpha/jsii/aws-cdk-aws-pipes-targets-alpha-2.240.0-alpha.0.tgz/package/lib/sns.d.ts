import type { IInputTransformation, IPipe, ITarget, TargetConfig } from '@aws-cdk/aws-pipes-alpha';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { ITopic } from 'aws-cdk-lib/aws-sns';
/**
 * SNS target properties.
 */
export interface SnsTargetParameters {
    /**
     * The input transformation to apply to the message before sending it to the target.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargetparameters.html#cfn-pipes-pipe-pipetargetparameters-inputtemplate
     * @default - none
     */
    readonly inputTransformation?: IInputTransformation;
}
/**
 * A EventBridge Pipes target that sends messages to an SNS topic.
 */
export declare class SnsTarget implements ITarget {
    private topic;
    private topicParameters?;
    readonly targetArn: string;
    constructor(topic: ITopic, parameters?: SnsTargetParameters);
    grantPush(grantee: IRole): void;
    bind(pipe: IPipe): TargetConfig;
}
