import type { IInputTransformation, IPipe, ITarget, TargetConfig } from '@aws-cdk/aws-pipes-alpha';
import type { IEventBus } from 'aws-cdk-lib/aws-events';
import type { IRole } from 'aws-cdk-lib/aws-iam';
/**
 * EventBridge target properties.
 */
export interface EventBridgeTargetParameters {
    /**
     * The input transformation to apply to the message before sending it to the target.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargetparameters.html#cfn-pipes-pipe-pipetargetparameters-inputtemplate
     * @default - none
     */
    readonly inputTransformation?: IInputTransformation;
    /**
     * A free-form string used to decide what fields to expect in the event detail.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargeteventbridgeeventbusparameters.html#cfn-pipes-pipe-pipetargeteventbridgeeventbusparameters-detailtype
     * @default - none
     */
    readonly detailType?: string;
    /**
     * The URL subdomain of the endpoint.
     *
     * @example
     * // if the URL for the endpoint is https://abcde.veo.endpoints.event.amazonaws.com
     * 'abcde.veo'
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargeteventbridgeeventbusparameters.html#cfn-pipes-pipe-pipetargeteventbridgeeventbusparameters-endpointid
     * @default - none
     */
    readonly endpointId?: string;
    /**
     * AWS resources, identified by Amazon Resource Name (ARN), which the event primarily concerns.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargeteventbridgeeventbusparameters.html#cfn-pipes-pipe-pipetargeteventbridgeeventbusparameters-resources
     * @default - none
     */
    readonly resources?: string[];
    /**
     * The source of the event.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargeteventbridgeeventbusparameters.html#cfn-pipes-pipe-pipetargeteventbridgeeventbusparameters-source
     * @default - none
     */
    readonly source?: string;
    /**
     * The time stamp of the event, per RFC3339.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargeteventbridgeeventbusparameters.html#cfn-pipes-pipe-pipetargeteventbridgeeventbusparameters-time
     * @default - the time stamp of the PutEvents call
     */
    readonly time?: string;
}
/**
 * An EventBridge Pipes target that sends messages to an EventBridge event bus.
 */
export declare class EventBridgeTarget implements ITarget {
    private eventBus;
    private eventBridgeParameters?;
    readonly targetArn: string;
    constructor(eventBus: IEventBus, parameters?: EventBridgeTargetParameters);
    grantPush(grantee: IRole): void;
    bind(pipe: IPipe): TargetConfig;
}
