import type { IInputTransformation, IPipe, ITarget, TargetConfig } from '@aws-cdk/aws-pipes-alpha';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { IDeliveryStream } from 'aws-cdk-lib/aws-kinesisfirehose';
/**
 * Amazon Data Firehose target properties.
 */
export interface FirehoseTargetParameters {
    /**
     * The input transformation to apply to the message before sending it to the target.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargetparameters.html#cfn-pipes-pipe-pipetargetparameters-inputtemplate
     * @default - none
     */
    readonly inputTransformation?: IInputTransformation;
}
/**
 * An EventBridge Pipes target that sends messages to an Amazon Data Firehose delivery stream.
 */
export declare class FirehoseTarget implements ITarget {
    private deliveryStream;
    private deliveryStreamParameters;
    readonly targetArn: string;
    constructor(deliveryStream: IDeliveryStream, parameters?: FirehoseTargetParameters);
    grantPush(grantee: IRole): void;
    bind(pipe: IPipe): TargetConfig;
}
