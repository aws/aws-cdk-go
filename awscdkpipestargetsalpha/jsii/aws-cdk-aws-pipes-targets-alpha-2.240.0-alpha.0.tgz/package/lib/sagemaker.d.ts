import type { IInputTransformation, IPipe, ITarget, TargetConfig } from '@aws-cdk/aws-pipes-alpha';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { IPipeline } from 'aws-cdk-lib/aws-sagemaker';
/**
 * SageMaker target properties.
 */
export interface SageMakerTargetParameters {
    /**
     * The input transformation to apply to the message before sending it to the target.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargetparameters.html#cfn-pipes-pipe-pipetargetparameters-inputtemplate
     * @default - none
     */
    readonly inputTransformation?: IInputTransformation;
    /**
     * List of parameter names and values for SageMaker Model Building Pipeline execution.
     *
     * The Name/Value pairs are passed to start execution of the pipeline.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipetargetsagemakerpipelineparameters.html#cfn-pipes-pipe-pipetargetsagemakerpipelineparameters-pipelineparameterlist
     * @default - none
     */
    readonly pipelineParameters?: Record<string, string>;
}
/**
 * An EventBridge Pipes target that sends messages to a SageMaker pipeline.
 */
export declare class SageMakerTarget implements ITarget {
    private pipeline;
    private sageMakerParameters?;
    private pipelineParameters?;
    readonly targetArn: string;
    constructor(pipeline: IPipeline, parameters?: SageMakerTargetParameters);
    grantPush(grantee: IRole): void;
    bind(pipe: IPipe): TargetConfig;
}
