const VALIDATORS = { _aws_cdk_aws_medialive_alpha_MediaConnectInputProps: function _aws_cdk_aws_medialive_alpha_MediaConnectInputProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.flows != null)
                for (const o of p.flows)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_mediaconnect_IFlowRef(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_SrtCallerSourceProps: function _aws_cdk_aws_medialive_alpha_SrtCallerSourceProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_medialive_alpha_SrtDecryptionProps(p.decryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_SrtListenerInputProps: function _aws_cdk_aws_medialive_alpha_SrtListenerInputProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.inputSecurityGroups != null)
                for (const o of p.inputSecurityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_medialive_IInputSecurityGroupRef(o);
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_medialive_alpha_SrtDecryptionProps(p.decryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_CdiInputProps: function _aws_cdk_aws_medialive_alpha_CdiInputProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.subnets != null)
                for (const o of p.subnets)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_ec2_ISubnetRef(o);
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_ec2_ISecurityGroupRef(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_PushInputProps: function _aws_cdk_aws_medialive_alpha_PushInputProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_PushInputDestination(o);
            if (p.inputSecurityGroups != null)
                for (const o of p.inputSecurityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_medialive_IInputSecurityGroupRef(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_PushInputDestination: function _aws_cdk_aws_medialive_alpha_PushInputDestination(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.networkRoutes != null)
                for (const o of p.networkRoutes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_NetworkRoute(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_ChannelProps: function _aws_cdk_aws_medialive_alpha_ChannelProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.inputs != null)
                for (const o of p.inputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_InputAttachment(o);
            if (p.outputGroups != null)
                for (const o of p.outputGroups)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_OutputGroupConfiguration(o);
            if (!visitedObjects.has(p.anywhereSettings))
                module.exports._aws_cdk_aws_medialive_alpha_AnywhereSettings(p.anywhereSettings);
            if (p.channelSecurityGroups != null)
                for (const o of p.channelSecurityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_medialive_IInputSecurityGroupRef(o);
            if (p.colorCorrections != null)
                for (const o of p.colorCorrections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_ColorCorrection(o);
            if (!visitedObjects.has(p.globalConfiguration))
                module.exports._aws_cdk_aws_medialive_alpha_GlobalConfiguration(p.globalConfiguration);
            if (!visitedObjects.has(p.vpc))
                module.exports._aws_cdk_aws_medialive_alpha_VpcOutputSettings(p.vpc);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_GlobalConfiguration: function _aws_cdk_aws_medialive_alpha_GlobalConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputLossBehavior))
                module.exports._aws_cdk_aws_medialive_alpha_InputLossBehavior(p.inputLossBehavior);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_VpcOutputSettings: function _aws_cdk_aws_medialive_alpha_VpcOutputSettings(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.subnets != null)
                for (const o of p.subnets)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_ec2_ISubnetRef(o);
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_elasticache_ISecurityGroupRef(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_EsamSettings: function _aws_cdk_aws_medialive_alpha_EsamSettings(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.pois))
                module.exports._aws_cdk_aws_medialive_alpha_PoisEndpoint(p.pois);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_NetworkInputSettings: function _aws_cdk_aws_medialive_alpha_NetworkInputSettings(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.hlsInputSettings))
                module.exports._aws_cdk_aws_medialive_alpha_HlsInputSettings(p.hlsInputSettings);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_AutomaticInputFailover: function _aws_cdk_aws_medialive_alpha_AutomaticInputFailover(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.failoverConditions != null)
                for (const o of p.failoverConditions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_FailoverCondition(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_InputAttachment: function _aws_cdk_aws_medialive_alpha_InputAttachment(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.audioSelectors != null)
                for (const o of p.audioSelectors)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_AudioSelector(o);
            if (!visitedObjects.has(p.automaticInputFailover))
                module.exports._aws_cdk_aws_medialive_alpha_AutomaticInputFailover(p.automaticInputFailover);
            if (p.captionSelectors != null)
                for (const o of p.captionSelectors)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CaptionSelector(o);
            if (!visitedObjects.has(p.networkInputSettings))
                module.exports._aws_cdk_aws_medialive_alpha_NetworkInputSettings(p.networkInputSettings);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_MediaPackageV2OutputGroupBaseProps: function _aws_cdk_aws_medialive_alpha_MediaPackageV2OutputGroupBaseProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2OutputDefinition(o);
            if (p.additionalDestinations != null)
                for (const o of p.additionalDestinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2Destination(o);
            if (p.captionLanguageMappings != null)
                for (const o of p.captionLanguageMappings)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CaptionLanguageMapping(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_MediaPackageV2OutputGroupProps: function _aws_cdk_aws_medialive_alpha_MediaPackageV2OutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2OutputDefinition(o);
            if (p.additionalDestinations != null)
                for (const o of p.additionalDestinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2Destination(o);
            if (p.captionLanguageMappings != null)
                for (const o of p.captionLanguageMappings)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CaptionLanguageMapping(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_MediaPackageV2PerPipelineOutputGroupProps: function _aws_cdk_aws_medialive_alpha_MediaPackageV2PerPipelineOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2Destination(o);
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2OutputDefinition(o);
            if (p.additionalDestinations != null)
                for (const o of p.additionalDestinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2Destination(o);
            if (p.captionLanguageMappings != null)
                for (const o of p.captionLanguageMappings)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CaptionLanguageMapping(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_HlsOutputGroupProps: function _aws_cdk_aws_medialive_alpha_HlsOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_OutputDestination(o);
            if (p.adMarkers != null)
                for (const o of p.adMarkers)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_HlsAdMarkers(o);
            if (p.captionLanguageMappings != null)
                for (const o of p.captionLanguageMappings)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CaptionLanguageMapping(o);
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_HlsOutputDefinition(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_UdpOutputGroupProps: function _aws_cdk_aws_medialive_alpha_UdpOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_UdpOutputDestination(o);
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_UdpOutputDefinition(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_ArchiveOutputGroupProps: function _aws_cdk_aws_medialive_alpha_ArchiveOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_S3OutputDestination(o);
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_ArchiveOutputDefinition(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_RtmpOutputGroupProps: function _aws_cdk_aws_medialive_alpha_RtmpOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_RtmpOutputDefinition(o);
            if (p.adMarkers != null)
                for (const o of p.adMarkers)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_RtmpAdMarkers(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_SrtOutputGroupProps: function _aws_cdk_aws_medialive_alpha_SrtOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_SrtOutputDefinition(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_CmafIngestOutputGroupProps: function _aws_cdk_aws_medialive_alpha_CmafIngestOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_OutputDestination(o);
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CmafIngestOutputDefinition(o);
            if (p.additionalDestinations != null)
                for (const o of p.additionalDestinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_OutputDestination(o);
            if (p.captionLanguageMappings != null)
                for (const o of p.captionLanguageMappings)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CmafCaptionLanguageMapping(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_MsSmoothOutputGroupProps: function _aws_cdk_aws_medialive_alpha_MsSmoothOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_OutputDestination(o);
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MsSmoothOutputDefinition(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_MediaConnectRouterPerPipelineSettings: function _aws_cdk_aws_medialive_alpha_MediaConnectRouterPerPipelineSettings(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.pipeline0))
                module.exports._aws_cdk_aws_medialive_alpha_MediaConnectRouterPipelineConfig(p.pipeline0);
            if (!visitedObjects.has(p.pipeline1))
                module.exports._aws_cdk_aws_medialive_alpha_MediaConnectRouterPipelineConfig(p.pipeline1);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_UdpOutputDefinition: function _aws_cdk_aws_medialive_alpha_UdpOutputDefinition(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.encodes != null)
                for (const o of p.encodes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_EncodeConfiguration(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_RtmpOutputDefinition: function _aws_cdk_aws_medialive_alpha_RtmpOutputDefinition(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_RtmpDestination(o);
            if (p.encodes != null)
                for (const o of p.encodes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_EncodeConfiguration(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_SrtOutputDefinition: function _aws_cdk_aws_medialive_alpha_SrtOutputDefinition(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_SrtDestination(o);
            if (p.encodes != null)
                for (const o of p.encodes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_EncodeConfiguration(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_M2tsSettingsProps: function _aws_cdk_aws_medialive_alpha_M2tsSettingsProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.dvbNitSettings))
                module.exports._aws_cdk_aws_medialive_alpha_DvbNitSettings(p.dvbNitSettings);
            if (!visitedObjects.has(p.dvbSdtSettings))
                module.exports._aws_cdk_aws_medialive_alpha_DvbSdtSettings(p.dvbSdtSettings);
            if (!visitedObjects.has(p.dvbTdtSettings))
                module.exports._aws_cdk_aws_medialive_alpha_DvbTdtSettings(p.dvbTdtSettings);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
