import type { Bitrate } from 'aws-cdk-lib';
/**
 * Audio sample rate for AAC, MP2, and WAV codecs.
 *
 * Use one of the standard presets or `AudioSampleRate.of(hz)` for a custom value.
 */
export declare class AudioSampleRate {
    private readonly hz;
    /** 8,000 Hz */
    static readonly HZ_8000: AudioSampleRate;
    /** 12,000 Hz */
    static readonly HZ_12000: AudioSampleRate;
    /** 16,000 Hz */
    static readonly HZ_16000: AudioSampleRate;
    /** 22,050 Hz */
    static readonly HZ_22050: AudioSampleRate;
    /** 24,000 Hz */
    static readonly HZ_24000: AudioSampleRate;
    /** 32,000 Hz */
    static readonly HZ_32000: AudioSampleRate;
    /** 44,100 Hz */
    static readonly HZ_44100: AudioSampleRate;
    /** 48,000 Hz */
    static readonly HZ_48000: AudioSampleRate;
    /** 88,200 Hz */
    static readonly HZ_88200: AudioSampleRate;
    /** 96,000 Hz */
    static readonly HZ_96000: AudioSampleRate;
    /**
     * A custom sample rate in Hz.
     * @param hz the sample rate in Hz
     */
    static of(hz: number): AudioSampleRate;
    private constructor();
}
/**
 * Audio bit depth for WAV codec.
 *
 * Use one of the standard presets or `AudioBitDepth.of(bits)` for a custom value.
 */
export declare class AudioBitDepth {
    private readonly bits;
    /** 16-bit */
    static readonly DEPTH_16: AudioBitDepth;
    /** 24-bit */
    static readonly DEPTH_24: AudioBitDepth;
    /**
     * A custom bit depth.
     * @param bits the bit depth
     */
    static of(bits: number): AudioBitDepth;
    private constructor();
}
/**
 * AAC profile.
 */
export declare class AacProfile {
    /** HEV1 */
    static readonly HEV1: AacProfile;
    /** HEV2 */
    static readonly HEV2: AacProfile;
    /** LC (Low Complexity) */
    static readonly LC: AacProfile;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AacProfile;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AAC coding mode.
 */
export declare class AacCodingMode {
    /** Ad receiver mix — receives stereo audio description + control track per ETSI TS 101 154 Annex E. */
    static readonly AD_RECEIVER_MIX: AacCodingMode;
    /** 1.0 (mono) */
    static readonly CODING_MODE_1_0: AacCodingMode;
    /** 1+1 (dual mono) */
    static readonly CODING_MODE_1_1: AacCodingMode;
    /** 2.0 (stereo) */
    static readonly CODING_MODE_2_0: AacCodingMode;
    /** 5.1 surround */
    static readonly CODING_MODE_5_1: AacCodingMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AacCodingMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AAC rate control mode.
 */
export declare class AacRateControlMode {
    /** Constant bitrate */
    static readonly CBR: AacRateControlMode;
    /** Variable bitrate */
    static readonly VBR: AacRateControlMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AacRateControlMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AAC raw format.
 */
export declare class AacRawFormat {
    /** LATM/LOAS */
    static readonly LATM_LOAS: AacRawFormat;
    /** None */
    static readonly NONE: AacRawFormat;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AacRawFormat;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AAC specification.
 */
export declare class AacSpec {
    /** MPEG-2 AAC */
    static readonly MPEG2: AacSpec;
    /** MPEG-4 AAC */
    static readonly MPEG4: AacSpec;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AacSpec;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AAC input type.
 */
export declare class AacInputType {
    /** Broadcaster mixed AD */
    static readonly BROADCASTER_MIXED_AD: AacInputType;
    /** Normal */
    static readonly NORMAL: AacInputType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AacInputType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AAC VBR quality level.
 */
export declare class AacVbrQuality {
    /** High */
    static readonly HIGH: AacVbrQuality;
    /** Low */
    static readonly LOW: AacVbrQuality;
    /** Medium high */
    static readonly MEDIUM_HIGH: AacVbrQuality;
    /** Medium low */
    static readonly MEDIUM_LOW: AacVbrQuality;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AacVbrQuality;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AC3 attenuation control.
 */
export declare class Ac3AttenuationControl {
    /** Apply 3 dB attenuation to surround channels */
    static readonly ATTENUATE_3_DB: Ac3AttenuationControl;
    /** No attenuation */
    static readonly NONE: Ac3AttenuationControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Ac3AttenuationControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AC3 bitstream mode.
 */
export declare class Ac3BitstreamMode {
    /** Commentary */
    static readonly COMMENTARY: Ac3BitstreamMode;
    /** Complete main */
    static readonly COMPLETE_MAIN: Ac3BitstreamMode;
    /** Dialogue */
    static readonly DIALOGUE: Ac3BitstreamMode;
    /** Emergency */
    static readonly EMERGENCY: Ac3BitstreamMode;
    /** Hearing impaired */
    static readonly HEARING_IMPAIRED: Ac3BitstreamMode;
    /** Music and effects */
    static readonly MUSIC_AND_EFFECTS: Ac3BitstreamMode;
    /** Visually impaired */
    static readonly VISUALLY_IMPAIRED: Ac3BitstreamMode;
    /** Voice over */
    static readonly VOICE_OVER: Ac3BitstreamMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Ac3BitstreamMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AC3 coding mode.
 */
export declare class Ac3CodingMode {
    /** 1.0 (mono) */
    static readonly CODING_MODE_1_0: Ac3CodingMode;
    /** 1+1 (dual mono) */
    static readonly CODING_MODE_1_1: Ac3CodingMode;
    /** 2.0 (stereo) */
    static readonly CODING_MODE_2_0: Ac3CodingMode;
    /** 3/2 (5.0 surround) */
    static readonly CODING_MODE_3_2_LFE: Ac3CodingMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Ac3CodingMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AC3 DRC profile.
 */
export declare class Ac3DrcProfile {
    /** Film standard */
    static readonly FILM_STANDARD: Ac3DrcProfile;
    /** None */
    static readonly NONE: Ac3DrcProfile;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Ac3DrcProfile;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AC3 LFE filter.
 */
export declare class Ac3LfeFilter {
    /** Disabled */
    static readonly DISABLED: Ac3LfeFilter;
    /** Enabled */
    static readonly ENABLED: Ac3LfeFilter;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Ac3LfeFilter;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AC3 metadata control.
 */
export declare class Ac3MetadataControl {
    /** Follow input */
    static readonly FOLLOW_INPUT: Ac3MetadataControl;
    /** Use configured */
    static readonly USE_CONFIGURED: Ac3MetadataControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Ac3MetadataControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 attenuation control.
 */
export declare class Eac3AttenuationControl {
    /** Apply 3 dB attenuation to surround channels */
    static readonly ATTENUATE_3_DB: Eac3AttenuationControl;
    /** No attenuation */
    static readonly NONE: Eac3AttenuationControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3AttenuationControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 bitstream mode.
 */
export declare class Eac3BitstreamMode {
    /** Commentary */
    static readonly COMMENTARY: Eac3BitstreamMode;
    /** Complete main */
    static readonly COMPLETE_MAIN: Eac3BitstreamMode;
    /** Emergency */
    static readonly EMERGENCY: Eac3BitstreamMode;
    /** Hearing impaired */
    static readonly HEARING_IMPAIRED: Eac3BitstreamMode;
    /** Visually impaired */
    static readonly VISUALLY_IMPAIRED: Eac3BitstreamMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3BitstreamMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 coding mode.
 */
export declare class Eac3CodingMode {
    /** 1.0 (mono) */
    static readonly CODING_MODE_1_0: Eac3CodingMode;
    /** 2.0 (stereo) */
    static readonly CODING_MODE_2_0: Eac3CodingMode;
    /** 3/2 (5.0 surround) */
    static readonly CODING_MODE_3_2: Eac3CodingMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3CodingMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 DC filter.
 */
export declare class Eac3DcFilter {
    /** Disabled */
    static readonly DISABLED: Eac3DcFilter;
    /** Enabled */
    static readonly ENABLED: Eac3DcFilter;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3DcFilter;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 DRC line mode profile.
 */
export declare class Eac3DrcLine {
    /** Film light */
    static readonly FILM_LIGHT: Eac3DrcLine;
    /** Film standard */
    static readonly FILM_STANDARD: Eac3DrcLine;
    /** Music light */
    static readonly MUSIC_LIGHT: Eac3DrcLine;
    /** Music standard */
    static readonly MUSIC_STANDARD: Eac3DrcLine;
    /** None */
    static readonly NONE: Eac3DrcLine;
    /** Speech */
    static readonly SPEECH: Eac3DrcLine;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3DrcLine;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 DRC RF mode profile.
 */
export declare class Eac3DrcRf {
    /** Film light */
    static readonly FILM_LIGHT: Eac3DrcRf;
    /** Film standard */
    static readonly FILM_STANDARD: Eac3DrcRf;
    /** Music light */
    static readonly MUSIC_LIGHT: Eac3DrcRf;
    /** Music standard */
    static readonly MUSIC_STANDARD: Eac3DrcRf;
    /** None */
    static readonly NONE: Eac3DrcRf;
    /** Speech */
    static readonly SPEECH: Eac3DrcRf;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3DrcRf;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 LFE control.
 */
export declare class Eac3LfeControl {
    /** LFE */
    static readonly LFE: Eac3LfeControl;
    /** No LFE */
    static readonly NO_LFE: Eac3LfeControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3LfeControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 LFE filter.
 */
export declare class Eac3LfeFilter {
    /** Disabled */
    static readonly DISABLED: Eac3LfeFilter;
    /** Enabled */
    static readonly ENABLED: Eac3LfeFilter;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3LfeFilter;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 metadata control.
 */
export declare class Eac3MetadataControl {
    /** Follow input */
    static readonly FOLLOW_INPUT: Eac3MetadataControl;
    /** Use configured */
    static readonly USE_CONFIGURED: Eac3MetadataControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3MetadataControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 passthrough control.
 */
export declare class Eac3PassthroughControl {
    /** No passthrough */
    static readonly NO_PASSTHROUGH: Eac3PassthroughControl;
    /** When possible */
    static readonly WHEN_POSSIBLE: Eac3PassthroughControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3PassthroughControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 phase control.
 */
export declare class Eac3PhaseControl {
    /** No shift */
    static readonly NO_SHIFT: Eac3PhaseControl;
    /** Shift 90 degrees */
    static readonly SHIFT_90_DEGREES: Eac3PhaseControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3PhaseControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 stereo downmix preference.
 */
export declare class Eac3StereoDownmix {
    /** DPL2 */
    static readonly DPL2: Eac3StereoDownmix;
    /** Lo/Ro */
    static readonly LO_RO: Eac3StereoDownmix;
    /** Lt/Rt */
    static readonly LT_RT: Eac3StereoDownmix;
    /** Not indicated */
    static readonly NOT_INDICATED: Eac3StereoDownmix;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3StereoDownmix;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 surround ex mode.
 */
export declare class Eac3SurroundExMode {
    /** Disabled */
    static readonly DISABLED: Eac3SurroundExMode;
    /** Enabled */
    static readonly ENABLED: Eac3SurroundExMode;
    /** Not indicated */
    static readonly NOT_INDICATED: Eac3SurroundExMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3SurroundExMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 surround mode.
 */
export declare class Eac3SurroundMode {
    /** Disabled */
    static readonly DISABLED: Eac3SurroundMode;
    /** Enabled */
    static readonly ENABLED: Eac3SurroundMode;
    /** Not indicated */
    static readonly NOT_INDICATED: Eac3SurroundMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3SurroundMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 Atmos coding mode.
 */
export declare class Eac3AtmosCodingMode {
    /** 5.1.4 surround */
    static readonly CODING_MODE_5_1_4: Eac3AtmosCodingMode;
    /** 7.1.4 surround */
    static readonly CODING_MODE_7_1_4: Eac3AtmosCodingMode;
    /** 9.1.6 surround */
    static readonly CODING_MODE_9_1_6: Eac3AtmosCodingMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3AtmosCodingMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 Atmos DRC line mode profile.
 */
export declare class Eac3AtmosDrcLine {
    /** Film light */
    static readonly FILM_LIGHT: Eac3AtmosDrcLine;
    /** Film standard */
    static readonly FILM_STANDARD: Eac3AtmosDrcLine;
    /** Music light */
    static readonly MUSIC_LIGHT: Eac3AtmosDrcLine;
    /** Music standard */
    static readonly MUSIC_STANDARD: Eac3AtmosDrcLine;
    /** None */
    static readonly NONE: Eac3AtmosDrcLine;
    /** Speech */
    static readonly SPEECH: Eac3AtmosDrcLine;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3AtmosDrcLine;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * EAC3 Atmos DRC RF mode profile.
 */
export declare class Eac3AtmosDrcRf {
    /** Film light */
    static readonly FILM_LIGHT: Eac3AtmosDrcRf;
    /** Film standard */
    static readonly FILM_STANDARD: Eac3AtmosDrcRf;
    /** Music light */
    static readonly MUSIC_LIGHT: Eac3AtmosDrcRf;
    /** Music standard */
    static readonly MUSIC_STANDARD: Eac3AtmosDrcRf;
    /** None */
    static readonly NONE: Eac3AtmosDrcRf;
    /** Speech */
    static readonly SPEECH: Eac3AtmosDrcRf;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Eac3AtmosDrcRf;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * MP2 coding mode.
 */
export declare class Mp2CodingMode {
    /** 1.0 (mono) */
    static readonly CODING_MODE_1_0: Mp2CodingMode;
    /** 2.0 (stereo) */
    static readonly CODING_MODE_2_0: Mp2CodingMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Mp2CodingMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * WAV coding mode.
 */
export declare class WavCodingMode {
    /** 1.0 (mono) */
    static readonly CODING_MODE_1_0: WavCodingMode;
    /** 2.0 (stereo) */
    static readonly CODING_MODE_2_0: WavCodingMode;
    /** 4.0 */
    static readonly CODING_MODE_4_0: WavCodingMode;
    /** 8.0 */
    static readonly CODING_MODE_8_0: WavCodingMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): WavCodingMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Properties for AAC codec settings.
 */
export interface AacSettingsProps {
    /**
     * The average bitrate.
     * @default Bitrate.kbps(192)
     */
    readonly bitrate?: Bitrate;
    /**
     * The AAC profile.
     * @default AacProfile.LC
     */
    readonly profile?: AacProfile;
    /**
     * The coding mode (mono, stereo, 5.1).
     * @default AacCodingMode.CODING_MODE_2_0
     */
    readonly codingMode?: AacCodingMode;
    /**
     * The rate control mode.
     * @default AacRateControlMode.CBR
     */
    readonly rateControlMode?: AacRateControlMode;
    /**
     * The sample rate.
     * @default AudioSampleRate.HZ_48000
     */
    readonly sampleRate?: AudioSampleRate;
    /**
     * Set to broadcasterMixedAd when the input contains pre-mixed main audio + AD (narration) as a stereo pair.
     * @default AacInputType.NORMAL
     */
    readonly inputType?: AacInputType;
    /**
     * Sets the LATM/LOAS AAC output for raw containers.
     * @default AacRawFormat.NONE
     */
    readonly rawFormat?: AacRawFormat;
    /**
     * The AAC specification (MPEG-4 or MPEG-2) used to encode the audio.
     *
     * Set to `AacSpec.MPEG2` to emit MPEG-2 AAC instead of MPEG-4 AAC for raw or MPEG-2 Transport
     * Stream containers.
     * @default AacSpec.MPEG4
     */
    readonly spec?: AacSpec;
    /**
     * The VBR quality level. Used only if rateControlMode is VBR.
     * @default - service default
     */
    readonly vbrQuality?: AacVbrQuality;
}
/**
 * Properties for AC3 codec settings.
 */
export interface Ac3SettingsProps {
    /**
     * The average bitrate.
     * @default - service default
     */
    readonly bitrate?: Bitrate;
    /**
     * The Dolby Digital coding mode.
     * @default Ac3CodingMode.CODING_MODE_2_0
     */
    readonly codingMode?: Ac3CodingMode;
    /**
     * The dialogue normalization level (1–31).
     * @default - service default
     */
    readonly dialNorm?: number;
    /**
     * Applies a 3 dB attenuation to the surround channels. Used only for the 3/2 coding mode.
     * @default - service default
     */
    readonly attenuationControl?: Ac3AttenuationControl;
    /**
     * Specifies the bitstream mode (bsmod) for the emitted AC-3 stream.
     * @default Ac3BitstreamMode.COMPLETE_MAIN
     */
    readonly bitstreamMode?: Ac3BitstreamMode;
    /**
     * If set to filmStandard, adds dynamic range compression signaling to the output bitstream.
     * @default - service default
     */
    readonly drcProfile?: Ac3DrcProfile;
    /**
     * When set to enabled, applies a 120Hz lowpass filter to the LFE channel prior to encoding.
     * Valid only in codingMode32Lfe mode.
     * @default Ac3LfeFilter.DISABLED
     */
    readonly lfeFilter?: Ac3LfeFilter;
    /**
     * When set to followInput, encoder metadata is sourced from the DD, DD+, or DolbyE decoder that supplies this audio data.
     * @default - service default
     */
    readonly metadataControl?: Ac3MetadataControl;
}
/**
 * Properties for EAC3 codec settings.
 */
export interface Eac3SettingsProps {
    /**
     * The average bitrate.
     * @default - service default
     */
    readonly bitrate?: Bitrate;
    /**
     * The Dolby Digital Plus coding mode.
     * @default Eac3CodingMode.CODING_MODE_3_2
     */
    readonly codingMode?: Eac3CodingMode;
    /**
     * The dialogue normalization level (1–31).
     * @default - service default
     */
    readonly dialNorm?: number;
    /**
     * When set to attenuate3Db, applies a 3 dB attenuation to the surround channels. Used only for the 3/2 coding mode.
     * @default Eac3AttenuationControl.NONE
     */
    readonly attenuationControl?: Eac3AttenuationControl;
    /**
     * Specifies the bitstream mode (bsmod) for the emitted E-AC-3 stream.
     * @default Eac3BitstreamMode.COMPLETE_MAIN
     */
    readonly bitstreamMode?: Eac3BitstreamMode;
    /**
     * When set to enabled, activates a DC highpass filter for all input channels.
     * @default - service default
     */
    readonly dcFilter?: Eac3DcFilter;
    /**
     * Sets the Dolby dynamic range compression profile.
     * @default - service default
     */
    readonly drcLine?: Eac3DrcLine;
    /**
     * Sets the profile for heavy Dolby dynamic range compression, ensuring that the instantaneous signal peaks do not exceed specified levels.
     * @default - service default
     */
    readonly drcRf?: Eac3DrcRf;
    /**
     * When encoding 3/2 audio, setting to lfe enables the LFE channel.
     * @default - service default
     */
    readonly lfeControl?: Eac3LfeControl;
    /**
     * When set to enabled, applies a 120Hz lowpass filter to the LFE channel prior to encoding.
     * Valid only with a codingMode32 coding mode.
     * @default - service default
     */
    readonly lfeFilter?: Eac3LfeFilter;
    /**
     * The Left only/Right only center mix level. Used only for the 3/2 coding mode.
     * @default - service default
     */
    readonly loRoCenterMixLevel?: number;
    /**
     * The Left only/Right only surround mix level. Used only for a 3/2 coding mode.
     * @default - service default
     */
    readonly loRoSurroundMixLevel?: number;
    /**
     * The Left total/Right total center mix level. Used only for a 3/2 coding mode.
     * @default - service default
     */
    readonly ltRtCenterMixLevel?: number;
    /**
     * The Left total/Right total surround mix level. Used only for the 3/2 coding mode.
     * @default - service default
     */
    readonly ltRtSurroundMixLevel?: number;
    /**
     * When set to followInput, encoder metadata is sourced from the DD, DD+, or DolbyE decoder that supplies this audio data.
     * @default - service default
     */
    readonly metadataControl?: Eac3MetadataControl;
    /**
     * When set to whenPossible, input DD+ audio will be passed through if it is present on the input.
     * @default - service default
     */
    readonly passthroughControl?: Eac3PassthroughControl;
    /**
     * When set to shift90Degrees, applies a 90-degree phase shift to the surround channels. Used only for a 3/2 coding mode.
     * @default - service default
     */
    readonly phaseControl?: Eac3PhaseControl;
    /**
     * A stereo downmix preference. Used only for the 3/2 coding mode.
     * @default - service default
     */
    readonly stereoDownmix?: Eac3StereoDownmix;
    /**
     * When encoding 3/2 audio, sets whether an extra center back surround channel is matrix encoded into the left and right surround channels.
     * @default - service default
     */
    readonly surroundExMode?: Eac3SurroundExMode;
    /**
     * When encoding 2/0 audio, sets whether Dolby Surround is matrix-encoded into the two channels.
     * @default - service default
     */
    readonly surroundMode?: Eac3SurroundMode;
}
/**
 * Properties for EAC3 Atmos codec settings.
 */
export interface Eac3AtmosSettingsProps {
    /**
     * The average bitrate.
     * @default - service default
     */
    readonly bitrate?: Bitrate;
    /**
     * The coding mode (e.g. CODING_MODE_5_1_4, CODING_MODE_7_1_4, CODING_MODE_9_1_6).
     * @default Eac3AtmosCodingMode.CODING_MODE_5_1_4
     */
    readonly codingMode?: Eac3AtmosCodingMode;
    /**
     * The dialogue normalization level (1–31).
     * @default - service default
     */
    readonly dialNorm?: number;
    /**
     * Sets the Dolby dynamic range compression line mode profile.
     * @default - service default
     */
    readonly drcLine?: Eac3AtmosDrcLine;
    /**
     * Sets the Dolby dynamic range compression RF mode profile.
     * @default - service default
     */
    readonly drcRf?: Eac3AtmosDrcRf;
    /**
     * Height channel trim level.
     * @default - service default
     */
    readonly heightTrim?: number;
    /**
     * Surround channel trim level.
     * @default - service default
     */
    readonly surroundTrim?: number;
}
/**
 * Properties for MP2 codec settings.
 */
export interface Mp2SettingsProps {
    /**
     * The average bitrate.
     * @default - service default
     */
    readonly bitrate?: Bitrate;
    /**
     * The MPEG2 Audio coding mode.
     * @default Mp2CodingMode.CODING_MODE_2_0
     */
    readonly codingMode?: Mp2CodingMode;
    /**
     * The sample rate.
     * @default AudioSampleRate.HZ_48000
     */
    readonly sampleRate?: AudioSampleRate;
}
/**
 * Properties for WAV codec settings.
 */
export interface WavSettingsProps {
    /**
     * The bit depth of the WAV output.
     * @default AudioBitDepth.DEPTH_16
     */
    readonly bitDepth?: AudioBitDepth;
    /**
     * The audio coding mode for the WAV audio.
     * @default WavCodingMode.CODING_MODE_2_0
     */
    readonly codingMode?: WavCodingMode;
    /**
     * The sample rate.
     * @default AudioSampleRate.HZ_48000
     */
    readonly sampleRate?: AudioSampleRate;
}
/**
 * Audio codec settings. Use the static factory methods to create.
 */
export declare abstract class AudioCodecSettings {
    /**
     * Create AAC codec settings.
     */
    static aac(props?: AacSettingsProps): AudioCodecSettings;
    /**
     * Create AC3 codec settings.
     */
    static ac3(props?: Ac3SettingsProps): AudioCodecSettings;
    /**
     * Create EAC3 (Dolby Digital Plus) codec settings.
     */
    static eac3(props?: Eac3SettingsProps): AudioCodecSettings;
    /**
     * Create EAC3 Atmos (Dolby Digital Plus with Atmos) codec settings.
     */
    static eac3Atmos(props?: Eac3AtmosSettingsProps): AudioCodecSettings;
    /**
     * Create MP2 codec settings.
     */
    static mp2(props?: Mp2SettingsProps): AudioCodecSettings;
    /**
     * Create WAV codec settings.
     */
    static wav(props?: WavSettingsProps): AudioCodecSettings;
    /**
     * Create passthrough audio settings (no transcoding).
     */
    static passthrough(): AudioCodecSettings;
}
