import type { Lut } from './file-location';
/**
 * A color space supported for 3D-LUT color conversion in a color-correction rule.
 */
export declare class ColorSpace {
    /** HDR10. */
    static readonly HDR10: ColorSpace;
    /** HLG (Rec. 2020). */
    static readonly HLG_2020: ColorSpace;
    /** Rec. 601 (SD). */
    static readonly REC_601: ColorSpace;
    /** Rec. 709 (HD). */
    static readonly REC_709: ColorSpace;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): ColorSpace;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * A color space correction rule.
 */
export interface ColorCorrection {
    /**
     * The input color space to match.
     */
    readonly inputColorSpace: ColorSpace;
    /**
     * The output color space to convert to.
     */
    readonly outputColorSpace: ColorSpace;
    /**
     * The 3D LUT file for the color correction. MediaLive reads the LUT from S3 at runtime, so it
     * must be an S3 location — provide it via `Lut.fromBucket()` (which uses the secure `s3ssl://`
     * form and auto-grants the channel role read access) or `Lut.url()` with an `s3://`/`s3ssl://` URL.
     * @default - no LUT file
     */
    readonly lut?: Lut;
}
