import type { Duration, IResource } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { ISecurityGroupRef, ISubnetRef } from 'aws-cdk-lib/aws-ec2';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { IFlowRef } from 'aws-cdk-lib/aws-mediaconnect';
import type { IInputRef, InputReference, IInputSecurityGroupRef, INetworkRef } from 'aws-cdk-lib/aws-medialive';
import type { IBucket } from 'aws-cdk-lib/aws-s3';
import type { ISecret } from 'aws-cdk-lib/aws-secretsmanager';
import type { IStringParameter } from 'aws-cdk-lib/aws-ssm';
import type { Construct } from 'constructs';
import type { ChannelClass } from './channel';
import type { NetworkRoute } from './network';
import type { ISdiSource } from './sdi-source';
/**
 * Represents a MediaLive Input.
 */
export interface IInput extends IResource, IInputRef {
    /**
     * The Amazon Resource Name (ARN) of the input.
     * @attribute
     */
    readonly inputArn: string;
    /**
     * The ID of the input.
     * @attribute
     */
    readonly inputId: string;
    /**
     * The input class (STANDARD or SINGLE_PIPELINE).
     * Only available for input types where the pipeline count is known at construct time
     * (e.g. mediaConnectRouter). Undefined for imported inputs and other types.
     *
     * @attribute
     */
    readonly inputClass?: string;
    /**
     * The input type (e.g. SRT_CALLER, MP4_FILE, URL_PULL).
     * Undefined for imported inputs.
     *
     * @attribute
     */
    readonly inputType?: string;
    /**
     * For push inputs, the destination URLs where the upstream system sends content.
     * @attribute
     */
    readonly inputDestinations?: string[];
    /**
     * For pull inputs, the source URLs where MediaLive pulls content from.
     * @attribute
     */
    readonly inputSources?: string[];
}
/**
 * The network location of a MediaLive input — the AWS cloud, or an on-premises network for
 * MediaLive Anywhere.
 */
export declare class InputNetworkLocation {
    /** The input exists in the AWS cloud (the default). */
    static readonly AWS: InputNetworkLocation;
    /** The input exists in an on-premises network (MediaLive Anywhere). */
    static readonly ON_PREMISES: InputNetworkLocation;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): InputNetworkLocation;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Properties for creating a MediaLive Input.
 */
export interface InputProps {
    /**
     * Input name.
     * @default - auto-generated
     */
    readonly inputName?: string;
    /**
     * Input configuration that defines the input type and source settings.
     */
    readonly input: InputConfiguration;
    /**
     * The network location of the input — AWS cloud or on-premises (MediaLive Anywhere).
     * @default - AWS, applied by MediaLive
     */
    readonly inputNetworkLocation?: InputNetworkLocation;
    /**
     * Tags to add to the input.
     * @default - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Options for a URL-based input source.
 */
export interface InputSourceOptions {
    /**
     * The username for accessing the upstream system.
     * @default - no username
     */
    readonly username?: string;
    /**
     * The SSM parameter that holds the password for accessing the upstream system.
     * @default - no password
     */
    readonly password?: IStringParameter;
}
/**
 * A source for a pull-type input. Use the static factory methods to create.
 */
export declare abstract class InputSource {
    /**
     * Create a source from a URL.
     * @param url The URL where MediaLive pulls the source content from.
     * @param options Optional credentials.
     */
    static url(url: string, options?: InputSourceOptions): InputSource;
    /**
     * Create a source from an S3 bucket. Automatically grants read access
     * to the channel's role.
     *
     * @param bucket The S3 bucket containing the source file.
     * @param key The object key within the bucket (e.g. 'videos/intro.mp4').
     */
    static fromBucket(bucket: IBucket, key: string): InputSource;
}
/** Properties for a MediaConnect router input. */
export interface MediaConnectRouterInputProps {
    /**
     * The availability zones for the router input pipelines.
     *
     * Provide one AZ for a single pipeline, or two for redundant pipelines.
     * If omitted, defaults to the stack's first availability zone (single pipeline).
     *
     * @default - single pipeline using the stack's first availability zone
     */
    readonly availabilityZones?: string[];
    /**
     * The Secrets Manager secret for custom encryption.
     * If not provided, automatic encryption is used.
     * @default - automatic encryption
     */
    readonly encryptionSecret?: ISecret;
}
/** Properties for a MediaConnect input. */
export interface MediaConnectInputProps {
    /**
     * The MediaConnect flows to use as sources (one, or two for pipeline redundancy).
     */
    readonly flows: IFlowRef[];
    /**
     * The IAM role MediaLive uses to manage the output it adds to the flow for this input.
     *
     * When omitted, a role is created and granted the required permissions.
     * When you provide a role, no permissions are added — you own all the permissions it needs.
     *
     * @default - a role is created with the medialive.amazonaws.com service principal
     *
     * [disable-awslint:prefer-ref-interface]
     */
    readonly role?: IRole;
}
/** Properties for an SRT caller input. */
export interface SrtCallerSourceProps {
    /** The address of the SRT listener to connect to. */
    readonly srtListenerAddress: string;
    /** The port of the SRT listener. */
    readonly srtListenerPort: number;
    /**
     * The minimum latency.
     * @default - service default
     */
    readonly minimumLatency?: Duration;
    /**
     * The stream ID for the SRT connection.
     * @default - no stream ID
     */
    readonly streamId?: string;
    /**
     * Decryption settings for the SRT connection.
     * @default - no decryption
     */
    readonly decryption?: SrtDecryptionProps;
}
/** The encryption algorithm for SRT decryption. */
export declare class SrtDecryptionAlgorithm {
    /** AES-128. */
    static readonly AES128: SrtDecryptionAlgorithm;
    /** AES-192. */
    static readonly AES192: SrtDecryptionAlgorithm;
    /** AES-256. */
    static readonly AES256: SrtDecryptionAlgorithm;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): SrtDecryptionAlgorithm;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Properties for SRT decryption. */
export interface SrtDecryptionProps {
    /**
     * The encryption algorithm.
     * @default - no algorithm
     */
    readonly algorithm?: SrtDecryptionAlgorithm;
    /**
     * The Secrets Manager secret containing the passphrase used to decrypt the content.
     * @default - no passphrase
     */
    readonly passphraseSecret?: ISecret;
}
/** Properties for an SRT listener input. */
export interface SrtListenerInputProps {
    /**
     * Decryption settings for the SRT connection.
     * @default - no decryption
     */
    readonly decryption?: SrtDecryptionProps;
    /**
     * The minimum latency.
     * @default - service default
     */
    readonly minimumLatency?: Duration;
    /**
     * The stream ID that the upstream system uses when connecting to this listener.
     * @default - no stream ID
     */
    readonly streamId?: string;
    /**
     * The input security groups. Required for SRT listener inputs.
     */
    readonly inputSecurityGroups: IInputSecurityGroupRef[];
    /**
     * Whether this is a STANDARD (two-pipeline) or SINGLE_PIPELINE input. A STANDARD input creates
     * two listener endpoints for pipeline redundancy.
     * @default ChannelClass.SINGLE_PIPELINE
     */
    readonly inputClass?: ChannelClass;
}
/** Properties for an Elemental Link input device input. */
export interface InputDeviceInputProps {
    /** The IDs of one or two registered Elemental Link devices. Two provides pipeline redundancy. */
    readonly deviceIds: string[];
}
/** The transport protocol for a multicast source. */
export declare class MulticastProtocol {
    /** UDP transport. */
    static readonly UDP: MulticastProtocol;
    /** RTP transport. */
    static readonly RTP: MulticastProtocol;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MulticastProtocol;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** A source for a multicast input. */
export interface MulticastInputSource {
    /** The multicast group address. */
    readonly address: string;
    /** The multicast port. */
    readonly port: number;
    /**
     * The transport protocol.
     * @default MulticastProtocol.UDP
     */
    readonly protocol?: MulticastProtocol;
    /**
     * Filter to a specific source IP (source-specific multicast).
     * @default - accept any source
     */
    readonly sourceIp?: string;
}
/** Properties for a multicast input. Requires `anywhereSettings` on the channel. */
export interface MulticastInputProps {
    /** The multicast sources. Provide two for a STANDARD (redundant-pipeline) channel. */
    readonly sources: MulticastInputSource[];
}
/** A reference to an SDP file that describes a SMPTE 2110 stream to ingest. */
export interface Smpte2110SdpLocation {
    /** The URL of the SDP file. */
    readonly sdpUrl: string;
    /**
     * The index of the media stream within the SDP to ingest. Use when the SDP describes
     * more than one stream of that media type.
     * @default - service default
     */
    readonly mediaIndex?: number;
}
/**
 * Properties for a SMPTE 2110 receiver group input. Requires `anywhereSettings` on the channel.
 *
 * You specify the SDP files that describe the streams to ingest — one video SDP, and any
 * number of audio and ancillary SDPs.
 */
export interface Smpte2110InputProps {
    /**
     * The SDP describing the video stream.
     * @default - no video stream
     */
    readonly videoSdp?: Smpte2110SdpLocation;
    /**
     * The SDPs describing the audio streams. Up to 50.
     * @default - no audio streams
     */
    readonly audioSdps?: Smpte2110SdpLocation[];
    /**
     * The SDPs describing the ancillary data streams (SCTE-35 or captions). Up to 50.
     * @default - no ancillary data streams
     */
    readonly ancillarySdps?: Smpte2110SdpLocation[];
}
/** Properties for a CDI (uncompressed) input. */
export interface CdiInputProps {
    /**
     * Two VPC subnets, in two different availability zones, for the CDI input network interfaces.
     */
    readonly subnets: ISubnetRef[];
    /**
     * Security groups to attach to the CDI input network interfaces.
     * @default - VPC default security group
     */
    readonly securityGroups?: ISecurityGroupRef[];
    /**
     * The IAM role MediaLive assumes to create network interfaces in the VPC.
     *
     * When omitted, a role is created and granted the required permissions.
     * When you provide a role, no permissions are added — you own all the permissions it needs.
     *
     * @default - a role is created with the medialive.amazonaws.com service principal
     *
     * [disable-awslint:prefer-ref-interface]
     */
    readonly role?: IRole;
}
/**
 * Properties for push-type inputs (RTMP_PUSH, RTP_PUSH, UDP_PUSH).
 */
export interface PushInputProps {
    /**
     * The input security groups that control which CIDR blocks can push to this input. Required for
     * cloud inputs; must be omitted for on-premises inputs (`InputNetworkLocation.ON_PREMISES`),
     * which do not support security groups.
     * @default - none (only valid for on-premises inputs)
     */
    readonly inputSecurityGroups?: IInputSecurityGroupRef[];
    /**
     * The destinations for push inputs. For RTMP push, each destination can have a stream name.
     * @default - MediaLive auto-generates destinations
     */
    readonly destinations?: PushInputDestination[];
}
/**
 * A destination for a push-type input.
 */
export interface PushInputDestination {
    /**
     * The stream name for RTMP push destinations (application name/instance).
     * @default - auto-generated
     */
    readonly streamName?: string;
    /**
     * The MediaLive Anywhere network this push destination lives on. Required when the input's
     * `inputNetworkLocation` is `ON_PREMISES`.
     * @default - AWS-managed network
     */
    readonly network?: INetworkRef;
    /**
     * The routes to the push destination on the local network. Required for
     * on-premises (`ON_PREMISES`) push inputs.
     * @default - no routes
     */
    readonly networkRoutes?: NetworkRoute[];
    /**
     * A static IP address to assign to the push destination on the local network.
     * @default - MediaLive Anywhere uses one from the IP pool specified on the selected network (service default)
     */
    readonly staticIpAddress?: string;
}
/**
 * Defines the input configuration for a MediaLive Input.
 *
 * Use the static factory methods to create the appropriate configuration for your input type.
 */
export declare class InputConfiguration {
    private readonly _bindFn;
    /**
     * Create a URL pull input for HLS or TS streams.
     *
     * @example
     *
     *    InputConfiguration.urlPull([
     *      InputSource.url('https://example.com/stream.m3u8'),
     *    ]);
     *
     */
    static urlPull(sources: InputSource[]): InputConfiguration;
    /** Create an RTMP pull input. */
    static rtmpPull(sources: InputSource[]): InputConfiguration;
    /** Create an MP4 file pull input. */
    static mp4File(sources: InputSource[]): InputConfiguration;
    /** Create a TS file pull input. */
    static tsFile(sources: InputSource[]): InputConfiguration;
    /**
     * Create an RTMP push input.
     *
     * @example
     *
     *    declare const securityGroup: InputSecurityGroup;
     *
     *    InputConfiguration.rtmpPush({
     *      inputSecurityGroups: [securityGroup],
     *    });
     *
     */
    static rtmpPush(props: PushInputProps): InputConfiguration;
    /** Create an RTP push input. */
    static rtpPush(props: PushInputProps): InputConfiguration;
    /** Create a UDP push input. */
    static udpPush(props: PushInputProps): InputConfiguration;
    /**
     * Create a MediaConnect router input configuration.
     *
     * @example
     *
     *    // Single pipeline with default AZ
     *    InputConfiguration.mediaConnectRouter();
     *
     * @example
     *
     *    // Redundant pipelines with explicit AZs
     *    InputConfiguration.mediaConnectRouter({
     *      availabilityZones: ['us-east-1a', 'us-east-1b'],
     *    });
     *
     */
    static mediaConnectRouter(props?: MediaConnectRouterInputProps): InputConfiguration;
    /**
     * Create a MediaConnect flow input configuration.
     *
     * @example
     *
     *    declare const role: iam.IRole;
     *    declare const flow: mediaconnect.IFlowRef;
     *
     *    InputConfiguration.mediaConnect({
     *      flows: [flow],
     *      role,
     *    });
     *
     */
    static mediaConnect(props: MediaConnectInputProps): InputConfiguration;
    /** Create an SDI input configuration. */
    static sdi(sources: ISdiSource[]): InputConfiguration;
    /** Create an Elemental Link input from one or two registered Link device IDs. */
    static inputDevice(props: InputDeviceInputProps): InputConfiguration;
    /**
     * Create a CDI (uncompressed) input delivered into a VPC.
     *
     * MediaLive creates network interfaces in the supplied subnets and hands back the CDI push
     * endpoints. The required EC2 permissions are granted to the role automatically.
     */
    static cdi(props: CdiInputProps): InputConfiguration;
    /** Create a multicast input. Requires `anywhereSettings` on the channel. */
    static multicast(props: MulticastInputProps): InputConfiguration;
    /** Create a SMPTE 2110 receiver group input. Requires `anywhereSettings` on the channel. */
    static smpte2110ReceiverGroup(props: Smpte2110InputProps): InputConfiguration;
    /**
     * Create an SRT caller input configuration.
     *
     * @example
     *
     *    InputConfiguration.srtCaller([{
     *      srtListenerAddress: '10.0.0.1',
     *      srtListenerPort: 5000,
     *    }]);
     *
     */
    static srtCaller(sources: SrtCallerSourceProps[]): InputConfiguration;
    /** Create an SRT listener input configuration. */
    static srtListener(props: SrtListenerInputProps): InputConfiguration;
    private static createPullInput;
    private constructor();
}
/**
 * Defines an AWS Elemental MediaLive Input.
 */
export declare class Input extends Resource implements IInput {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /** Import an existing input by its ARN. The id is parsed out of the ARN. */
    static fromInputArn(scope: Construct, id: string, inputArn: string): IInput;
    readonly inputArn: string;
    readonly inputId: string;
    readonly inputClass?: string;
    readonly inputType?: string;
    readonly inputDestinations?: string[];
    readonly inputSources?: string[];
    /** A reference to this Input resource. */
    get inputRef(): InputReference;
    private readonly inputSourceRefs;
    constructor(scope: Construct, id: string, props: InputProps);
}
