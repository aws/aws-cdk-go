import type { IResource } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { ISdiSourceRef, SdiSourceReference } from 'aws-cdk-lib/aws-medialive';
import type { Construct } from 'constructs';
/**
 * Represents a MediaLive SDI Source.
 */
export interface ISdiSource extends IResource, ISdiSourceRef {
    /**
     * The SDI Source ARN.
     * @attribute
     */
    readonly sdiSourceArn: string;
    /**
     * The SDI Source ID.
     * @attribute
     */
    readonly sdiSourceId: string;
    /**
     * The list of inputs currently using this SDI source.
     * @attribute
     */
    readonly sdiSourceInputs?: string[];
    /**
     * The current state of the SDI source.
     * @attribute
     */
    readonly sdiSourceState?: string;
}
/**
 * Properties for creating an SDI Source.
 */
export interface SdiSourceProps {
    /**
     * The name of the SDI source.
     * @default - auto-generated name
     */
    readonly sdiSourceName?: string;
    /**
     * Type of SDI input.
     */
    readonly type: SdiType;
    /**
     * SDI Mode, only applicable for QUAD type.
     * @default - no mode
     */
    readonly mode?: SdiMode;
    /**
     * Tags to add to the SDI source.
     * @default - no tagging
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * The type of SDI input.
 */
export declare class SdiType {
    /** Single SDI input */
    static readonly SINGLE: SdiType;
    /** Quad SDI input */
    static readonly QUAD: SdiType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): SdiType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Mode when quad SDI input is selected.
 */
export declare class SdiMode {
    /** Interleave mode */
    static readonly INTERLEAVE: SdiMode;
    /** Quadrant mode */
    static readonly QUADRANT: SdiMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): SdiMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Attributes for importing an existing SDI Source.
 */
export interface SdiSourceAttributes {
    /**
     * The SDI Source ARN.
     * @attribute
     */
    readonly sdiSourceArn: string;
    /**
     * The SDI Source ID.
     * @attribute
     */
    readonly sdiSourceId: string;
}
/**
 * Defines an AWS Elemental MediaLive SDI Source.
 */
export declare class SdiSource extends Resource implements ISdiSource {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /** Import an existing SDI source by its attributes. */
    static fromSdiSourceAttributes(scope: Construct, id: string, attrs: SdiSourceAttributes): ISdiSource;
    readonly sdiSourceArn: string;
    /**
     * The SDI Source ID.
     * @attribute
     */
    readonly sdiSourceId: string;
    /**
     * The list of inputs currently using this SDI source.
     */
    readonly sdiSourceInputs?: string[];
    /**
     * The current state of the SDI source.
     */
    readonly sdiSourceState?: string;
    /** A reference to this SDI Source resource. */
    get sdiSourceRef(): SdiSourceReference;
    constructor(scope: Construct, id: string, props: SdiSourceProps);
}
