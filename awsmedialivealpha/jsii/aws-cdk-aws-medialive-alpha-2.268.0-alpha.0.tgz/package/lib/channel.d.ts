import type { Duration, IResource } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { MetricOptions } from 'aws-cdk-lib/aws-cloudwatch';
import { Metric } from 'aws-cdk-lib/aws-cloudwatch';
import type { ISubnetRef } from 'aws-cdk-lib/aws-ec2';
import type { ISecurityGroupRef } from 'aws-cdk-lib/aws-elasticache';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { IChannelRef, ChannelReference, IInputSecurityGroupRef, IClusterRef, IChannelPlacementGroupRef } from 'aws-cdk-lib/aws-medialive';
import type { Construct } from 'constructs';
import { type AvailBlanking, type AvailSettings, type Scte35SegmentationScope, type BlackoutSlate } from './avail-settings';
import { type FeatureActivations, type MotionGraphicsConfiguration, type NielsenConfiguration, type ThumbnailConfiguration } from './channel-features';
import type { ColorCorrection } from './color-correction';
import type { FileLocation } from './file-location';
import { type InputAttachment } from './input-attachment';
import { InputSpecification } from './input-specification';
import { ChannelGrants } from './medialive-grants.generated';
import type { OutputGroupConfiguration } from './output-group';
export { VideoCodecSettings, H264Profile, H264RateControl, H264AdaptiveQuantization, GopSize, H265Profile, H265Tier, H265RateControl, Av1RateControl, AfdSignaling, ColorMetadata, ScanType, FlickerAq, GopBReference, LookAheadRateControl, TimecodeInsertion, SubgopLength, H264EntropyEncoding, H264ForceFieldPictures, H264Syntax, H264QualityLevel, H265AdaptiveQuantization, H265AlternativeTransferFunction, H265Deblocking, H265MvOverPictureBoundaries, H265MvTemporalPredictor, H265TilePadding, H265TreeblockSize, Av1BitDepth, Av1SceneChangeDetect, Av1SpatialAq, Av1TemporalAq, Av1TimecodeInsertion, H264SceneChangeDetect, H264SpatialAq, H264TemporalAq, H265SceneChangeDetect, TimecodeBurninFontSize, TimecodeBurninPosition, } from './video-codec-settings';
export type { H264SettingsProps, H265SettingsProps, Av1SettingsProps, FrameCaptureSettingsProps, TimecodeBurninSettings, } from './video-codec-settings';
export { AudioCodecSettings, AacProfile, AacCodingMode, AacRateControlMode, AacRawFormat, AacSpec, AacInputType, AacVbrQuality, Ac3AttenuationControl, Ac3BitstreamMode, Ac3CodingMode, Ac3DrcProfile, Ac3LfeFilter, Ac3MetadataControl, Eac3AttenuationControl, Eac3BitstreamMode, Eac3CodingMode, Eac3DcFilter, Eac3DrcLine, Eac3DrcRf, Eac3LfeControl, Eac3LfeFilter, Eac3MetadataControl, Eac3PassthroughControl, Eac3PhaseControl, Eac3StereoDownmix, Eac3SurroundExMode, Eac3SurroundMode, Eac3AtmosCodingMode, Eac3AtmosDrcLine, Eac3AtmosDrcRf, Mp2CodingMode, WavCodingMode, } from './audio-codec-settings';
export type { AacSettingsProps, Ac3SettingsProps, Eac3SettingsProps, Eac3AtmosSettingsProps, Mp2SettingsProps, WavSettingsProps, } from './audio-codec-settings';
/**
 * Represents a MediaLive Channel.
 */
export interface IChannel extends IResource, IChannelRef {
    /**
     * The ARN of the channel.
     * @attribute
     */
    readonly channelArn: string;
    /**
     * The ID of the channel.
     * @attribute
     */
    readonly channelId: string;
    /**
     * The IDs of the inputs attached to this channel.
     * @attribute
     */
    readonly channelInputs?: string[];
    /**
     * Collection of grant methods for this channel — start, stop, and update its schedule.
     */
    readonly grants: ChannelGrants;
    /**
     * Create a CloudWatch metric for this channel scoped to a specific pipeline.
     *
     * Channel metrics are published per-pipeline. `STANDARD` channels run two
     * redundant pipelines (`PIPELINE_0` and `PIPELINE_1`); to cover both, build
     * a metric for each. `SINGLE_PIPELINE` channels only publish on `PIPELINE_0`.
     * See the
     * {@link https://docs.aws.amazon.com/medialive/latest/ug/monitoring-eml-metrics.html | MediaLive metrics docs}
     * for the full set of metric names and recommended statistics.
     */
    metric(metricName: string, pipeline: Pipeline, props?: MetricOptions): Metric;
    /**
     * Metric for the total number of active alerts on this channel.
     *
     * @default - max over 5 minutes
     */
    metricActiveAlerts(pipeline: Pipeline, props?: MetricOptions): Metric;
    /**
     * Metric for the rate of inbound network traffic to MediaLive in Mbps.
     *
     * @default - average over 5 minutes
     */
    metricNetworkIn(pipeline: Pipeline, props?: MetricOptions): Metric;
    /**
     * Metric for the rate of outbound network traffic from MediaLive in Mbps.
     *
     * @default - average over 5 minutes
     */
    metricNetworkOut(pipeline: Pipeline, props?: MetricOptions): Metric;
    /**
     * Metric for the input video frame rate (frames per second).
     *
     * @default - max over 5 minutes
     */
    metricInputVideoFrameRate(pipeline: Pipeline, props?: MetricOptions): Metric;
    /**
     * Metric for fill milliseconds — the time MediaLive has filled the video output
     * with fill frames because the input did not deliver content within the
     * expected window. A non-zero value indicates an unhealthy input.
     *
     * @default - max over 5 minutes
     */
    metricFillMsec(pipeline: Pipeline, props?: MetricOptions): Metric;
    /**
     * Metric for input loss seconds (RTP and MediaConnect inputs only).
     *
     * @default - sum over 5 minutes
     */
    metricInputLossSeconds(pipeline: Pipeline, props?: MetricOptions): Metric;
    /**
     * Metric for dropped frames. A non-zero value indicates the encoder cannot
     * keep up with the incoming video in real time.
     *
     * @default - sum over 5 minutes
     */
    metricDroppedFrames(pipeline: Pipeline, props?: MetricOptions): Metric;
    /**
     * Metric for SVQ time (speed-vs-quality), expressed as a percent. Indicates
     * the share of time MediaLive reduced quality optimisations to keep up with
     * real-time output.
     *
     * @default - max over 5 minutes
     */
    metricSvqTime(pipeline: Pipeline, props?: MetricOptions): Metric;
}
/**
 * MediaLive pipeline (channel pipeline 0 or 1).
 *
 * `STANDARD` channels run two redundant pipelines (`PIPELINE_0`, `PIPELINE_1`).
 * `SINGLE_PIPELINE` channels run only `PIPELINE_0`.
 */
export declare class Pipeline {
    private readonly value;
    /** Pipeline 0. Always available on every channel. */
    static readonly PIPELINE_0: Pipeline;
    /** Pipeline 1. Available only on `STANDARD` channels. */
    static readonly PIPELINE_1: Pipeline;
    private constructor();
    /** Returns the CloudWatch dimension value for this pipeline (`'0'` or `'1'`). */
    toString(): string;
}
/**
 * The class of the channel. Determines the pipeline redundancy.
 */
export declare class ChannelClass {
    /** Single pipeline — no redundancy */
    static readonly SINGLE_PIPELINE: ChannelClass;
    /** Standard — two pipelines for redundancy */
    static readonly STANDARD: ChannelClass;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): ChannelClass;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * The log level for the channel.
 */
export declare class LogLevel {
    /** Log errors only */
    static readonly ERROR: LogLevel;
    /** Log warnings and errors */
    static readonly WARNING: LogLevel;
    /** Log info, warnings, and errors */
    static readonly INFO: LogLevel;
    /** Log everything */
    static readonly DEBUG: LogLevel;
    /** Disable logging */
    static readonly DISABLED: LogLevel;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): LogLevel;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * The source of timecode for the channel outputs.
 */
export declare class TimecodeSource {
    /** Use embedded timecode from the source. Falls back to zero-based if not detected. */
    static readonly EMBEDDED: TimecodeSource;
    /** Use the system clock (UTC). */
    static readonly SYSTEMCLOCK: TimecodeSource;
    /** Start at 00:00:00:00. */
    static readonly ZEROBASED: TimecodeSource;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): TimecodeSource;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Timecode configuration for the channel.
 */
export interface TimecodeConfig {
    /**
     * The source of timecode.
     * @default TimecodeSource.EMBEDDED
     */
    readonly source?: TimecodeSource;
    /**
     * The threshold in frames beyond which output timecode is resynchronized to the input timecode.
     * @default - no sync threshold
     */
    readonly syncThreshold?: number;
}
/**
 * Properties for creating a MediaLive Channel.
 */
export interface ChannelProps {
    /**
     * The name of the channel.
     * @default - auto-generated
     */
    readonly channelName?: string;
    /**
     * The class of the channel (STANDARD for redundancy, SINGLE_PIPELINE for cost savings).
     * @default ChannelClass.SINGLE_PIPELINE
     */
    readonly channelClass?: ChannelClass;
    /**
     * The IAM role for MediaLive to assume when running this channel.
     *
     * [disable-awslint:prefer-ref-interface]
     *
     * @default - a role is auto-created with confused-deputy prevention
     */
    readonly role?: IRole;
    /**
     * The input attachments for this channel. At least one is required.
     * Additional inputs can be added with `addInput()`.
     */
    readonly inputs: InputAttachment[];
    /**
     * The initial output groups for this channel. At least one is required.
     * Additional output groups can be added with `addOutputGroup()`.
     *
     * A single channel can contain multiple output groups with different codecs
     * (e.g. H.264 and H.265 ladders) sharing the same input.
     */
    readonly outputGroups: OutputGroupConfiguration[];
    /**
     * The log level for the channel.
     * @default LogLevel.DISABLED
     */
    readonly logLevel?: LogLevel;
    /**
     * The input specification for this channel. Defines the expected codec, bitrate, and
     * resolution of the inputs, and whether they are standard, CDI, or Elemental Link inputs.
     * @default - InputSpecification.standard() (AVC codec, 20 Mbps max, HD resolution)
     */
    readonly inputSpecification?: InputSpecification;
    /**
     * Global configuration settings for the channel.
     * @default - default global configuration
     */
    readonly globalConfiguration?: GlobalConfiguration;
    /**
     * Tags to add to the channel.
     * @default - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
    /**
     * Maintenance window configuration for the channel.
     * @default - default maintenance window
     */
    readonly maintenance?: MaintenanceSettings;
    /**
     * Timecode configuration for the channel.
     * @default - EMBEDDED source, no sync threshold
     */
    readonly timecodeConfig?: TimecodeConfig;
    /**
     * VPC output settings. When set, all output endpoints are created in the specified VPC.
     * @default - no VPC (outputs use public endpoints)
     */
    readonly vpc?: VpcOutputSettings;
    /**
     * Settings for blanking video, audio, and captions during ad avails.
     * @default - avail blanking disabled
     */
    readonly availBlanking?: AvailBlanking;
    /**
     * Ad avail handling configuration. Defines how SCTE-35 markers are processed.
     * @default - no avail configuration
     */
    readonly availSettings?: AvailSettings;
    /**
     * Which output groups receive SCTE-35 segmentation cues.
     * @default - service default
     */
    readonly scte35SegmentationScope?: Scte35SegmentationScope;
    /**
     * Feature activations for the channel (e.g. Input Prepare schedule actions).
     * @default - all features disabled
     */
    readonly featureActivations?: FeatureActivations;
    /**
     * Motion graphics overlay configuration.
     * @default - motion graphics disabled
     */
    readonly motionGraphicsConfiguration?: MotionGraphicsConfiguration;
    /**
     * Nielsen watermark configuration.
     * @default - no Nielsen configuration
     */
    readonly nielsenConfiguration?: NielsenConfiguration;
    /**
     * Thumbnail generation configuration.
     * @default - thumbnails disabled
     */
    readonly thumbnailConfiguration?: ThumbnailConfiguration;
    /**
     * Blackout slate configuration. Controls what is displayed during blackout events.
     * @default - blackout slate disabled
     */
    readonly blackoutSlate?: BlackoutSlate;
    /**
     * Global color correction rules applied to all outputs.
     * @default - no color corrections
     */
    readonly colorCorrections?: ColorCorrection[];
    /**
     * Anywhere settings for running the channel on AWS Elemental Anywhere.
     * @default - not an Anywhere channel
     */
    readonly anywhereSettings?: AnywhereSettings;
    /**
     * The engine version for the channel.
     * @default - service default
     */
    readonly channelEngineVersion?: string;
    /**
     * Linked channel settings for primary/follower channel configurations.
     * @default - not a linked channel
     */
    readonly linkedChannelSettings?: LinkedChannelSettings;
    /**
     * Input security groups to associate with the channel. Controls which IP addresses can connect
     * to the channel's outputs (pull-style outputs where downstream systems initiate connections).
     *
     * @default - no channel security groups
     */
    readonly channelSecurityGroups?: IInputSecurityGroupRef[];
    /**
     * An AWS Elemental Inference feed to send this channel's media to for inference
     * processing.
     *
     * Future breaking change: this will change when Elemental Inference is released as an L2 construct.
     *
     * @default - the channel is not associated to an inference feed
     */
    readonly inferenceFeedArn?: string;
}
/**
 * Action to take when the current input completes.
 */
export declare class InputEndAction {
    /** Restart at the beginning of the first input */
    static readonly SWITCH_AND_LOOP_INPUTS: InputEndAction;
    /** Do nothing — show slate or black until next input switch */
    static readonly NONE: InputEndAction;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): InputEndAction;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Source of output timing.
 */
export declare class OutputTimingSource {
    /** Use the input clock */
    static readonly INPUT_CLOCK: OutputTimingSource;
    /** Use the system clock */
    static readonly SYSTEM_CLOCK: OutputTimingSource;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): OutputTimingSource;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** The image MediaLive substitutes into the output on input loss. */
export declare class InputLossImageType {
    /** Substitute a solid color. */
    static readonly COLOR: InputLossImageType;
    /** Substitute a slate image. */
    static readonly SLATE: InputLossImageType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): InputLossImageType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Behavior on input loss: substitute black, optionally repeat the last frame, then show a solid
 * color or a slate image.
 */
export interface InputLossBehavior {
    /**
     * How long to substitute black before showing the input-loss image (up to Duration.seconds(1000);
     * Duration.seconds(1000) is interpreted as infinite).
     * @default - service default
     */
    readonly blackFrame?: Duration;
    /**
     * How long to repeat the previous picture before substituting black (up to Duration.seconds(1000);
     * Duration.seconds(1000) is interpreted as infinite).
     * @default - service default
     */
    readonly repeatFrame?: Duration;
    /**
     * Whether to substitute a solid color or a slate image after the black period.
     * @default - service default
     */
    readonly imageType?: InputLossImageType;
    /**
     * The image color as 6 hex characters (RGB). Used when InputLossImageType.COLOR.
     * @default - service default
     */
    readonly imageColor?: string;
    /**
     * The slate image to display. Used when `imageType` is SLATE. Provide a `FileLocation`
     * referencing an S3 bucket (`FileLocation.fromBucket`, which auto-grants read access) or
     * a URL (`FileLocation.url`).
     * @default - service default
     */
    readonly imageSlate?: FileLocation;
}
/** Properties for epoch output locking. */
export interface EpochOutputLockingProps {
    /**
     * A custom epoch (ISO-8601 timestamp) to lock outputs to.
     * @default - service default
     */
    readonly customEpoch?: string;
    /**
     * A jam-sync time (ISO-8601 timestamp).
     * @default - service default
     */
    readonly jamSyncTime?: string;
}
/** The method MediaLive uses to synchronise pipelines for pipeline output locking. */
export declare class PipelineLockingMethod {
    /** Use the timecode in the source (the default). Requires reliable embedded timecodes. */
    static readonly SOURCE_TIMECODE: PipelineLockingMethod;
    /**
     * Lock frames the encoder identifies as having matching content (visual signature comparison).
     * Does not require embedded timecodes; existing timecodes are ignored for locking decisions.
     */
    static readonly VIDEO_ALIGNMENT: PipelineLockingMethod;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): PipelineLockingMethod;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Properties for pipeline output locking. */
export interface PipelineOutputLockingProps {
    /**
     * A custom epoch (ISO-8601 timestamp) to lock outputs to.
     * @default - service default
     */
    readonly customEpoch?: string;
    /**
     * The method MediaLive uses to synchronise the pipelines.
     * @default - SOURCE_TIMECODE, applied by MediaLive
     */
    readonly method?: PipelineLockingMethod;
}
/**
 * Output locking synchronises the frames emitted by a channel's two pipelines. Use the static
 * factory methods to select a strategy:
 *
 * - `OutputLocking.pipeline()` — synchronise each pipeline's output to the other.
 * - `OutputLocking.epoch()` — synchronise each pipeline's output to the Unix epoch.
 * - `OutputLocking.disabled()` — do not synchronise pipelines.
 *
 * @see https://docs.aws.amazon.com/medialive/latest/ug/plan-redundancy-mode.html
 * @see https://docs.aws.amazon.com/medialive/latest/ug/pipeline-lock.html
 */
export declare abstract class OutputLocking {
    /** Disable output locking (optionally with a custom epoch). */
    static disabled(customEpoch?: string): OutputLocking;
    /** Lock outputs to an epoch. */
    static epoch(props?: EpochOutputLockingProps): OutputLocking;
    /** Lock pipelines to each other. */
    static pipeline(props?: PipelineOutputLockingProps): OutputLocking;
}
/**
 * Global configuration settings that apply to the entire channel.
 */
export interface GlobalConfiguration {
    /**
     * The initial audio gain for the channel (-60 to 60 dB).
     * @default - service default
     */
    readonly initialAudioGain?: number;
    /**
     * Action to take when the current input completes.
     * @default - service default
     */
    readonly inputEndAction?: InputEndAction;
    /**
     * Source of output timing.
     * @default - service default
     */
    readonly outputTimingSource?: OutputTimingSource;
    /**
     * Enable support for low framerate inputs (e.g. music channels with less than 1 fps).
     * @default false
     */
    readonly supportLowFramerateInputs?: boolean;
    /**
     * Behavior on input loss (substitute black / repeat frame, then a color or slate image).
     * @default - service default
     */
    readonly inputLossBehavior?: InputLossBehavior;
    /**
     * How MediaLive pipelines are synchronised — `OutputLocking.pipeline()`,
     * `OutputLocking.epoch()`, or `OutputLocking.disabled()`.
     *
     * @see https://docs.aws.amazon.com/medialive/latest/ug/plan-redundancy-mode.html
     * @see https://docs.aws.amazon.com/medialive/latest/ug/pipeline-lock.html
     * @default - service default
     */
    readonly outputLocking?: OutputLocking;
}
/**
 * Day of the week for maintenance.
 */
export declare class MaintenanceDay {
    /** Monday */
    static readonly MONDAY: MaintenanceDay;
    /** Tuesday */
    static readonly TUESDAY: MaintenanceDay;
    /** Wednesday */
    static readonly WEDNESDAY: MaintenanceDay;
    /** Thursday */
    static readonly THURSDAY: MaintenanceDay;
    /** Friday */
    static readonly FRIDAY: MaintenanceDay;
    /** Saturday */
    static readonly SATURDAY: MaintenanceDay;
    /** Sunday */
    static readonly SUNDAY: MaintenanceDay;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MaintenanceDay;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Maintenance window settings for the channel.
 */
export interface MaintenanceSettings {
    /**
     * The day of the week for maintenance.
     */
    readonly day: MaintenanceDay;
    /**
     * The start time for maintenance in UTC (HH:MM format, e.g. '02:00').
     * @default '02:00'
     */
    readonly time?: string;
}
/**
 * Anywhere settings for running the channel on AWS Elemental Anywhere.
 */
export interface AnywhereSettings {
    /**
     * The cluster for this channel.
     */
    readonly cluster: IClusterRef;
    /**
     * The channel placement group for this channel.
     *
     * @default - no placement group
     */
    readonly channelPlacementGroup?: IChannelPlacementGroupRef;
}
/**
 * Linked channel settings for primary/follower channel configurations.
 * Use the static factory methods to create.
 */
export declare abstract class LinkedChannelSettings {
    /**
     * Configure this channel as a primary in a linked channel pair.
     */
    static primary(): LinkedChannelSettings;
    /**
     * Configure this channel as a follower of a primary channel.
     *
     * @param primaryChannel The primary channel this channel follows. Use a `Channel`
     * instance or import one with `Channel.fromChannelArn()`.
     */
    static follower(primaryChannel: IChannel): LinkedChannelSettings;
}
/**
 * VPC output settings for the channel.
 * When configured, all output endpoints are created within the specified VPC.
 */
export interface VpcOutputSettings {
    /**
     * The subnets to use for the channel's output endpoints.
     * For STANDARD channels, provide subnets in two different availability zones.
     * For SINGLE_PIPELINE channels, provide at least one subnet.
     */
    readonly subnets: ISubnetRef[];
    /**
     * The security groups to attach to the output VPC network interfaces.
     *
     * @default - VPC default security group
     */
    readonly securityGroups?: ISecurityGroupRef[];
    /**
     * Public address allocation IDs to associate with ENIs created in the output VPC.
     * Must specify one for SINGLE_PIPELINE, two for STANDARD channels.
     * @default - no public addresses
     */
    readonly publicAddressAllocationIds?: string[];
}
/**
 * Shared metric implementation for both real and imported channels.
 */
declare abstract class ChannelBase extends Resource implements IChannel {
    abstract readonly channelArn: string;
    abstract readonly channelId: string;
    abstract readonly channelInputs?: string[];
    abstract get channelRef(): ChannelReference;
    /** Collection of grant methods for this channel — start, stop, and update its schedule. */
    readonly grants: ChannelGrants;
    metric(metricName: string, pipeline: Pipeline, props?: MetricOptions): Metric;
    metricActiveAlerts(pipeline: Pipeline, props?: MetricOptions): Metric;
    metricNetworkIn(pipeline: Pipeline, props?: MetricOptions): Metric;
    metricNetworkOut(pipeline: Pipeline, props?: MetricOptions): Metric;
    metricInputVideoFrameRate(pipeline: Pipeline, props?: MetricOptions): Metric;
    metricFillMsec(pipeline: Pipeline, props?: MetricOptions): Metric;
    metricInputLossSeconds(pipeline: Pipeline, props?: MetricOptions): Metric;
    metricDroppedFrames(pipeline: Pipeline, props?: MetricOptions): Metric;
    metricSvqTime(pipeline: Pipeline, props?: MetricOptions): Metric;
}
/**
 * Defines an AWS Elemental MediaLive Channel.
 */
export declare class Channel extends ChannelBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /** Import an existing channel by its ARN. The id is parsed out of the ARN. */
    static fromChannelArn(scope: Construct, id: string, channelArn: string): IChannel;
    readonly channelArn: string;
    readonly channelId: string;
    readonly channelInputs?: string[];
    /** The IAM role used by this channel. */
    readonly role: IRole;
    /** A reference to this Channel resource. */
    get channelRef(): ChannelReference;
    private readonly inputAttachments;
    private readonly attachments;
    private readonly hasAnywhereSettings;
    private readonly outputGroups;
    /**
     * Whether the caller supplied their own `role`. When true, the channel makes no automatic
     * grants.
     */
    private readonly userProvidedRole;
    private readonly usesEpochLocking;
    constructor(scope: Construct, id: string, props: ChannelProps);
    /**
     * Grant the channel's service role the permissions implied by channel-level features.
     *
     * Mirrors the AWS-documented MediaLive trusted-entity requirements:
     * https://docs.aws.amazon.com/medialive/latest/ug/trusted-entity-requirements.html
     *
     * Resource-level scoping is applied where the service supports it; EC2 `Describe*`
     * actions don't support resource-level permissions, so they require `*`.
     */
    private grantServiceRolePermissions;
    /**
     * Attach an input to this channel.
     */
    addInput(attachment: InputAttachment): void;
    /**
     * Validate automatic-input-failover pairs against MediaLive's create-time rules. The secondary
     * input is rejected by the service at deploy unless it is also attached to the channel, so we
     * fail fast at synth.
     */
    /**
     * Synth-time input validations, run over all attached inputs (initial + addInput()).
     */
    private validateInputs;
    private buildInputAttachment;
    /**
     * Add an output group to this channel.
     *
     * Outputs are declared up front via the `outputs` prop on the group configuration.
     */
    addOutputGroup(config: OutputGroupConfiguration): void;
    /** Synth-time epoch-locking checks for configs MediaLive rejects at deploy. */
    private validateEpochLocking;
}
