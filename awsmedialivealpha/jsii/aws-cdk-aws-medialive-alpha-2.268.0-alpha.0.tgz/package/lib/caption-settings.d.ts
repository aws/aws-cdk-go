import type { FileLocation } from './file-location';
/** Caption alignment for burn-in and DVB-Sub outputs. */
export declare class CaptionAlignment {
    /** Center the captions. */
    static readonly CENTERED: CaptionAlignment;
    /** Left-align the captions. */
    static readonly LEFT: CaptionAlignment;
    /** Smart: left-justify live subtitles, center-justify pre-recorded subtitles. */
    static readonly SMART: CaptionAlignment;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): CaptionAlignment;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Font color for burn-in and DVB-Sub captions. */
export declare class CaptionFontColor {
    /** Black. */
    static readonly BLACK: CaptionFontColor;
    /** Blue. */
    static readonly BLUE: CaptionFontColor;
    /** Green. */
    static readonly GREEN: CaptionFontColor;
    /** Red. */
    static readonly RED: CaptionFontColor;
    /** White. */
    static readonly WHITE: CaptionFontColor;
    /** Yellow. */
    static readonly YELLOW: CaptionFontColor;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): CaptionFontColor;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Font outline color for burn-in and DVB-Sub captions. */
export declare class CaptionOutlineColor {
    /** Black. */
    static readonly BLACK: CaptionOutlineColor;
    /** Blue. */
    static readonly BLUE: CaptionOutlineColor;
    /** Green. */
    static readonly GREEN: CaptionOutlineColor;
    /** Red. */
    static readonly RED: CaptionOutlineColor;
    /** White. */
    static readonly WHITE: CaptionOutlineColor;
    /** Yellow. */
    static readonly YELLOW: CaptionOutlineColor;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): CaptionOutlineColor;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Background color for burn-in and DVB-Sub captions. */
export declare class CaptionBackgroundColor {
    /** Black. */
    static readonly BLACK: CaptionBackgroundColor;
    /** None (transparent). */
    static readonly NONE: CaptionBackgroundColor;
    /** White. */
    static readonly WHITE: CaptionBackgroundColor;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): CaptionBackgroundColor;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Shadow color for burn-in and DVB-Sub captions. */
export declare class CaptionShadowColor {
    /** Black. */
    static readonly BLACK: CaptionShadowColor;
    /** None (transparent). */
    static readonly NONE: CaptionShadowColor;
    /** White. */
    static readonly WHITE: CaptionShadowColor;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): CaptionShadowColor;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Controls whether a fixed grid is used to generate the subtitle bitmap (Teletext input). */
export declare class CaptionTeletextGridControl {
    /** Fixed grid. */
    static readonly FIXED: CaptionTeletextGridControl;
    /** Scaled grid. */
    static readonly SCALED: CaptionTeletextGridControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): CaptionTeletextGridControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Whether EBU-TT-D fills the gap between multi-line captions. */
export declare class EbuTtDFillLineGap {
    /** Leave the gap unfilled. */
    static readonly DISABLED: EbuTtDFillLineGap;
    /** Fill with the captions background color. */
    static readonly ENABLED: EbuTtDFillLineGap;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): EbuTtDFillLineGap;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Whether EBU-TT-D includes source style information. */
export declare class EbuTtDStyleControl {
    /** Set the font family to monospaced and exclude other style info. */
    static readonly EXCLUDE: EbuTtDStyleControl;
    /** Include source style (color, position) in the font data. */
    static readonly INCLUDE: EbuTtDStyleControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): EbuTtDStyleControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Whether TTML passes through source style/position. */
export declare class TtmlStyleControl {
    /** Pass through style and position from a TTML-like source. */
    static readonly PASSTHROUGH: TtmlStyleControl;
    /** Use the configured style. */
    static readonly USE_CONFIGURED: TtmlStyleControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): TtmlStyleControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Whether WebVTT passes through source style/position. */
export declare class WebvttStyleControl {
    /** Do not pass through style; output contains no font styling. */
    static readonly NO_STYLE_DATA: WebvttStyleControl;
    /** Pass through style (valid only for EMBEDDED or TELETEXT sources). */
    static readonly PASSTHROUGH: WebvttStyleControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): WebvttStyleControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Font size for burn-in and DVB-Sub captions.
 *
 * Use {@link CaptionFontSize.AUTO} to scale the font size with the output resolution, or
 * {@link CaptionFontSize.of} to set an exact size in points.
 */
export declare class CaptionFontSize {
    private readonly value;
    /** Scale the font size automatically to match the output resolution. */
    static readonly AUTO: CaptionFontSize;
    /**
     * An exact font size, in points.
     *
     * @param points the font size in points; must be a positive integer
     */
    static of(points: number): CaptionFontSize;
    private constructor();
}
/**
 * Font and positioning settings for a rendered caption output (burn-in or DVB-Sub).
 */
export interface CaptionFontStyleProps {
    /**
     * Caption alignment. With explicit x/y positions, the font is justified relative to them.
     * @default CaptionAlignment.CENTERED
     */
    readonly alignment?: CaptionAlignment;
    /**
     * The color of the rectangle behind the captions.
     * @default - service default
     */
    readonly backgroundColor?: CaptionBackgroundColor;
    /**
     * The opacity of the background rectangle (0 transparent .. 255 opaque).
     * @default - service default
     */
    readonly backgroundOpacity?: number;
    /**
     * An external font file (.ttf or .tte) used for burn-in. Provide a `FileLocation` referencing
     * an S3 bucket (`FileLocation.fromBucket`, which auto-grants read access) or a URL
     * (`FileLocation.url`).
     * @default - service default font
     */
    readonly font?: FileLocation;
    /**
     * The color of the burned-in captions.
     * @default CaptionFontColor.WHITE
     */
    readonly fontColor?: CaptionFontColor;
    /**
     * The opacity of the burned-in captions (0 transparent .. 255 opaque).
     * @default 255
     */
    readonly fontOpacity?: number;
    /**
     * The font resolution in DPI.
     * @default 96
     */
    readonly fontResolution?: number;
    /**
     * Font size — `CaptionFontSize.AUTO` to scale with the output, or `CaptionFontSize.of(points)`
     * for an exact size in points.
     * @default CaptionFontSize.AUTO
     */
    readonly fontSize?: CaptionFontSize;
    /**
     * The font outline color.
     * @default CaptionOutlineColor.BLACK
     */
    readonly outlineColor?: CaptionOutlineColor;
    /**
     * The font outline size in pixels.
     * @default 2
     */
    readonly outlineSize?: number;
    /**
     * The color of the shadow cast by the captions.
     * @default CaptionShadowColor.NONE
     */
    readonly shadowColor?: CaptionShadowColor;
    /**
     * The opacity of the shadow (0 transparent .. 255 opaque).
     * @default 0
     */
    readonly shadowOpacity?: number;
    /**
     * The horizontal offset of the shadow in pixels (negative shifts left).
     * @default - service default
     */
    readonly shadowXOffset?: number;
    /**
     * The vertical offset of the shadow in pixels (negative shifts up).
     * @default - service default
     */
    readonly shadowYOffset?: number;
    /**
     * For Teletext input, the number of lines for the captions bitmap.
     * @default - service default
     */
    readonly subtitleRows?: string;
    /**
     * Whether a fixed grid is used to generate the subtitle bitmap (Teletext input).
     * @default CaptionTeletextGridControl.FIXED
     */
    readonly teletextGridControl?: CaptionTeletextGridControl;
    /**
     * The horizontal position of the captions in pixels from the left.
     * @default - determined by `alignment`
     */
    readonly xPosition?: number;
    /**
     * The vertical position of the captions in pixels from the top.
     * @default - positioned towards the bottom
     */
    readonly yPosition?: number;
}
/**
 * Properties for burn-in captions.
 */
export interface BurnInDestinationProps extends CaptionFontStyleProps {
}
/**
 * Properties for DVB-Sub captions.
 */
export interface DvbSubDestinationProps extends CaptionFontStyleProps {
}
/** Properties for EBU-TT-D caption output. */
export interface EbuTtDDestinationProps {
    /**
     * The copyright holder included in the TTML copyright metadata tag.
     * @default - no copyright holder
     */
    readonly copyrightHolder?: string;
    /**
     * The default font size.
     * @default - service default
     */
    readonly defaultFontSize?: number;
    /**
     * The default line height.
     * @default - service default
     */
    readonly defaultLineHeight?: number;
    /**
     * How to handle the gap between multi-line captions.
     * @default - service default
     */
    readonly fillLineGap?: EbuTtDFillLineGap;
    /**
     * A comma-separated list of font families to include (valid only when `styleControl` is INCLUDE).
     * @default - 'monospaced'
     */
    readonly fontFamily?: string;
    /**
     * Whether source style information is included in the EBU-TT-D font data.
     * @default - service default
     */
    readonly styleControl?: EbuTtDStyleControl;
}
/** Properties for TTML caption output. */
export interface TtmlDestinationProps {
    /**
     * Whether to pass through style and position from a TTML-like source.
     * @default TtmlStyleControl.PASSTHROUGH
     */
    readonly styleControl?: TtmlStyleControl;
}
/** Properties for WebVTT caption output. */
export interface WebvttDestinationProps {
    /**
     * Whether to pass through source color and position to the WebVTT output.
     * PASSTHROUGH is only valid for EMBEDDED or TELETEXT sources.
     * @default WebvttStyleControl.NO_STYLE_DATA
     */
    readonly styleControl?: WebvttStyleControl;
}
/**
 * The output caption format for a caption encode. Use the static factory methods to select one of
 * the supported destination types.
 */
export declare abstract class CaptionDestination {
    /** Burned-in captions rendered into the video. */
    static burnIn(props?: BurnInDestinationProps): CaptionDestination;
    /** DVB-Sub bitmap captions. */
    static dvbSub(props?: DvbSubDestinationProps): CaptionDestination;
    /** EBU-TT-D sidecar captions. */
    static ebuTtD(props?: EbuTtDDestinationProps): CaptionDestination;
    /** TTML sidecar captions. */
    static ttml(props?: TtmlDestinationProps): CaptionDestination;
    /** WebVTT sidecar captions. */
    static webvtt(props?: WebvttDestinationProps): CaptionDestination;
    /** ARIB captions. */
    static arib(): CaptionDestination;
    /** Embedded (CEA-608/708) captions. */
    static embedded(): CaptionDestination;
    /** Embedded plus SCTE-20 captions. */
    static embeddedPlusScte20(): CaptionDestination;
    /** SCTE-20 plus embedded captions. */
    static scte20PlusEmbedded(): CaptionDestination;
    /** SMPTE-TT sidecar captions. */
    static smpteTt(): CaptionDestination;
    /** Teletext captions. */
    static teletext(): CaptionDestination;
    /** RTMP CaptionInfo captions. */
    static rtmpCaptionInfo(): CaptionDestination;
}
