/**
 * Feature activation state.
 */
export declare class FeatureActivationState {
    /** Enable the feature */
    static readonly ENABLED: FeatureActivationState;
    /** Disable the feature */
    static readonly DISABLED: FeatureActivationState;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): FeatureActivationState;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Feature activations for the channel.
 */
export interface FeatureActivations {
    /**
     * Enable Input Prepare schedule actions.
     * @default - DISABLED, applied by MediaLive
     */
    readonly inputPrepareScheduleActions?: FeatureActivationState;
    /**
     * Enable output static image overlay schedule actions.
     * @default - DISABLED, applied by MediaLive
     */
    readonly outputStaticImageOverlayScheduleActions?: FeatureActivationState;
}
/**
 * Motion graphics insertion state.
 */
export declare class MotionGraphicsInsertion {
    /** Enable motion graphics overlay */
    static readonly ENABLED: MotionGraphicsInsertion;
    /** Disable motion graphics overlay */
    static readonly DISABLED: MotionGraphicsInsertion;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MotionGraphicsInsertion;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Motion graphics overlay configuration.
 */
export interface MotionGraphicsConfiguration {
    /**
     * Whether to enable the motion graphics overlay.
     * @default MotionGraphicsInsertion.DISABLED
     */
    readonly motionGraphicsInsertion?: MotionGraphicsInsertion;
}
/**
 * Whether Nielsen PCM to ID3 tagging is enabled.
 */
export declare class NielsenPcmToId3TaggingState {
    /** Disabled. */
    static readonly DISABLED: NielsenPcmToId3TaggingState;
    /** Enabled. */
    static readonly ENABLED: NielsenPcmToId3TaggingState;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): NielsenPcmToId3TaggingState;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Nielsen watermark configuration.
 */
export interface NielsenConfiguration {
    /**
     * The Distributor ID assigned to your organization by Nielsen.
     * @default - no distributor ID
     */
    readonly distributorId?: string;
    /**
     * Whether to enable Nielsen PCM to ID3 tagging.
     * @default - service default
     */
    readonly nielsenPcmToId3Tagging?: NielsenPcmToId3TaggingState;
}
/**
 * Thumbnail state.
 */
export declare class ThumbnailState {
    /** Enable thumbnail generation. */
    static readonly AUTO: ThumbnailState;
    /** Disable thumbnail generation. */
    static readonly DISABLED: ThumbnailState;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): ThumbnailState;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Thumbnail configuration for the channel.
 */
export interface ThumbnailConfiguration {
    /**
     * Whether to enable thumbnail generation.
     * @default ThumbnailState.AUTO
     */
    readonly state?: ThumbnailState;
}
