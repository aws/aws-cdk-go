import type { IResource } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { INetworkRef, NetworkReference } from 'aws-cdk-lib/aws-medialive';
import type { Construct } from 'constructs';
/**
 * A route for a MediaLive Network.
 */
export interface NetworkRoute {
    /**
     * The CIDR block for the route.
     */
    readonly cidr: string;
    /**
     * The gateway for the route.
     */
    readonly gateway: string;
}
/**
 * Represents a MediaLive Network.
 */
export interface INetwork extends IResource, INetworkRef {
    /**
     * The ARN of the network.
     * @attribute
     */
    readonly networkArn: string;
    /**
     * The ID of the network.
     * @attribute
     */
    readonly networkId: string;
}
/**
 * Properties for creating a MediaLive Network.
 */
export interface NetworkProps {
    /**
     * The name of the network.
     * @default - auto-generated name
     */
    readonly networkName?: string;
    /**
     * The list of IP address CIDR pools for the network.
     */
    readonly ipPools: string[];
    /**
     * The routes for the network.
     * @default - no routes
     */
    readonly routes?: NetworkRoute[];
    /**
     * Tags to add to the network.
     * @default - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Attributes for importing an existing Network.
 */
export interface NetworkAttributes {
    /** The ARN of the network. */
    readonly networkArn: string;
    /** The ID of the network. */
    readonly networkId: string;
}
/**
 * Defines an AWS Elemental MediaLive Network.
 *
 * A network represents a collection of IP address pools and routes used by MediaLive Anywhere resources.
 */
export declare class Network extends Resource implements INetwork {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /** Import an existing network by its attributes. */
    static fromNetworkAttributes(scope: Construct, id: string, attrs: NetworkAttributes): INetwork;
    readonly networkArn: string;
    readonly networkId: string;
    /** A reference to this Network resource. */
    get networkRef(): NetworkReference;
    constructor(scope: Construct, id: string, props: NetworkProps);
}
