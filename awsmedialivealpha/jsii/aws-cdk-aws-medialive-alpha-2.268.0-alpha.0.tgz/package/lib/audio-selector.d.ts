import type { AudioNormalizationSettings, RemixSettings } from './encode-configuration';
/**
 * Policy for how MediaLive identifies the audio stream when selecting by language, on a
 * transport-stream PMT update.
 */
export declare class AudioLanguageSelectionPolicy {
    /**
     * Strictly identify audio by its language descriptor. If the matching language is no
     * longer present after a PMT update, mute is encoded until the language returns.
     */
    static readonly STRICT: AudioLanguageSelectionPolicy;
    /**
     * On a PMT update, fall back to another audio stream of the same type in the program if a
     * stream with the same language can't be found.
     */
    static readonly LOOSE: AudioLanguageSelectionPolicy;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AudioLanguageSelectionPolicy;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Options for selecting an HLS audio rendition.
 */
export interface HlsRenditionSelectionOptions {
    /** The `GROUP-ID` in the `#EXT-X-MEDIA` tag of the target HLS audio rendition. */
    readonly groupId: string;
    /** The `NAME` in the `#EXT-X-MEDIA` tag of the target HLS audio rendition. */
    readonly renditionName: string;
}
/**
 * Which Dolby E program to decode from a selected audio track.
 */
export declare class DolbyEProgramSelection {
    /** Decode all channels. */
    static readonly ALL_CHANNELS: DolbyEProgramSelection;
    /** Decode Dolby E program 1. */
    static readonly PROGRAM_1: DolbyEProgramSelection;
    /** Decode Dolby E program 2. */
    static readonly PROGRAM_2: DolbyEProgramSelection;
    /** Decode Dolby E program 3. */
    static readonly PROGRAM_3: DolbyEProgramSelection;
    /** Decode Dolby E program 4. */
    static readonly PROGRAM_4: DolbyEProgramSelection;
    /** Decode Dolby E program 5. */
    static readonly PROGRAM_5: DolbyEProgramSelection;
    /** Decode Dolby E program 6. */
    static readonly PROGRAM_6: DolbyEProgramSelection;
    /** Decode Dolby E program 7. */
    static readonly PROGRAM_7: DolbyEProgramSelection;
    /** Decode Dolby E program 8. */
    static readonly PROGRAM_8: DolbyEProgramSelection;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): DolbyEProgramSelection;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Configuration for a single audio PID in a PID-based selector.
 */
export interface AudioPidConfig {
    /** The packet identifier (PID) value from within the source. */
    readonly pid: number;
    /**
     * Which Dolby E program to decode from this PID.
     * @default - no Dolby E decoding
     */
    readonly dolbyEDecode?: DolbyEProgramSelection;
    /**
     * Pre-mixer settings for this PID (gain, channel remix, loudness normalization).
     * @default - no pre-mixing
     */
    readonly premixSettings?: AudioPreMixerSettings;
}
/**
 * Configuration for a single audio track in a track-based selector.
 */
export interface AudioTrackConfig {
    /** The 1-based track number to extract. */
    readonly track: number;
    /**
     * Pre-mixer settings for this track (gain, channel remix, loudness normalization).
     * @default - no pre-mixing
     */
    readonly premixSettings?: AudioPreMixerSettings;
}
/**
 * Audio pre-mixer settings for normalizing audio before interleaving.
 * Applied per-PID or per-track before tracks are combined.
 */
export declare class AudioPreMixerSettings {
    private readonly props;
    /**
     * Create pre-mixer settings.
     */
    static of(props: AudioPreMixerSettingsProps): AudioPreMixerSettings;
    private constructor();
}
/**
 * Properties for audio pre-mixer settings.
 */
export interface AudioPreMixerSettingsProps {
    /**
     * The gain adjustment in decibels (dB).
     * @default - no gain adjustment
     */
    readonly gainDb?: number;
    /**
     * The number of audio channels to remix to. Overridden by `remixSettings` if specified.
     * @default - pass through original channel count
     */
    readonly channels?: number;
    /**
     * Remix settings for fine-grained channel mapping and gain levels.
     * @default - no remixing
     */
    readonly remixSettings?: RemixSettings;
    /**
     * Audio normalization settings for loudness control.
     * @default - no normalization
     */
    readonly audioNormalizationSettings?: AudioNormalizationSettings;
}
/**
 * An audio selector that identifies which audio to extract from the input.
 */
export declare abstract class AudioSelector {
    /**
     * Select audio by language code.
     *
     * @param name a name for this selector
     * @param languageCode the three-letter (ISO 639-2) language code to select
     * @param languageSelectionPolicy how strictly to identify the stream by language on a PMT update
     */
    static byLanguage(name: string, languageCode: string, languageSelectionPolicy?: AudioLanguageSelectionPolicy): AudioSelector;
    /**
     * Select one or more audio PIDs from the source.
     *
     * @param name a name for this selector
     * @param pids the PID configurations (each with optional Dolby E decode and pre-mix settings)
     */
    static byPid(name: string, pids: AudioPidConfig[]): AudioSelector;
    /**
     * Select one or more audio tracks (1-based) from the source.
     *
     * @param name a name for this selector
     * @param tracks the track configurations (each with optional pre-mix settings)
     * @param dolbyEProgramSelection which Dolby E program to decode from the selected track(s)
     */
    static byTrack(name: string, tracks: AudioTrackConfig[], dolbyEProgramSelection?: DolbyEProgramSelection): AudioSelector;
    /**
     * Select an HLS audio rendition by its `#EXT-X-MEDIA` `GROUP-ID` and `NAME`.
     *
     * @param name a name for this selector
     * @param options the target rendition's group id and name
     */
    static hlsRendition(name: string, options: HlsRenditionSelectionOptions): AudioSelector;
    /**
     * Select the default audio track (no specific selector settings).
     */
    static default(name: string): AudioSelector;
    /**
     * The name of this audio selector. Reference it from features that monitor a specific
     * selector, such as an audio-silence {@link FailoverCondition}.
     */
    readonly name: string;
    protected constructor(name: string);
}
