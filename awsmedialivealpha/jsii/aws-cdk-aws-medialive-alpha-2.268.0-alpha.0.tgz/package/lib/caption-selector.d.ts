/**
 * The OCR language to use when converting an image-based caption source to text.
 */
export declare class OcrLanguage {
    /** German */
    static readonly DEU: OcrLanguage;
    /** English */
    static readonly ENG: OcrLanguage;
    /** French */
    static readonly FRA: OcrLanguage;
    /** Dutch */
    static readonly NLD: OcrLanguage;
    /** Portuguese */
    static readonly POR: OcrLanguage;
    /** Spanish */
    static readonly SPA: OcrLanguage;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): OcrLanguage;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Whether to upconvert 608 captions to 708.
 */
export declare class Convert608To708 {
    /** Pass through 608 captions without upconverting. */
    static readonly DISABLED: Convert608To708;
    /** Upconvert 608 captions to 708 (608 data is also passed through). */
    static readonly UPCONVERT: Convert608To708;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Convert608To708;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * SCTE-20 detection mode for an embedded caption source.
 */
export declare class Scte20Detection {
    /** Handle streams with intermittent or non-aligned SCTE-20 and embedded captions. */
    static readonly AUTO: Scte20Detection;
    /** Do not detect SCTE-20 captions. */
    static readonly OFF: Scte20Detection;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Scte20Detection;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Options for an embedded (CEA-608/708) caption source.
 */
export interface EmbeddedCaptionSourceOptions {
    /**
     * Whether to upconvert 608 captions to 708.
     * @default Convert608To708.DISABLED
     */
    readonly convert608To708?: Convert608To708;
    /**
     * SCTE-20 detection mode.
     * @default Scte20Detection.OFF
     */
    readonly scte20Detection?: Scte20Detection;
    /**
     * The 608/708 channel number within the video track to extract captions from.
     * @default - MediaLive service default
     */
    readonly source608ChannelNumber?: number;
}
/**
 * Options for an ancillary caption source.
 */
export interface AncillaryCaptionSourceOptions {
    /**
     * The captions channel (1-4) to extract from the ancillary captions. Required when
     * converting to another caption format; ignored when passing through as embedded.
     * @default - MediaLive ignores the channel (passthrough)
     */
    readonly sourceChannelNumber?: number;
}
/**
 * Options for a DVB-Sub caption source.
 */
export interface DvbSubCaptionSourceOptions {
    /**
     * The PID of the source content. Unused for DVB-Sub passthrough.
     * @default - MediaLive service default
     */
    readonly pid?: number;
    /**
     * The OCR language to use when converting this image-based source to text.
     * @default - MediaLive service default
     */
    readonly ocrLanguage?: OcrLanguage;
}
/**
 * Options for an SCTE-20 caption source.
 */
export interface Scte20CaptionSourceOptions {
    /**
     * Whether to upconvert 608 captions to 708.
     * @default Convert608To708.DISABLED
     */
    readonly convert608To708?: Convert608To708;
    /**
     * The 608/708 channel number within the video track to extract captions from.
     * @default - MediaLive service default
     */
    readonly source608ChannelNumber?: number;
}
/**
 * Options for an SCTE-27 caption source.
 */
export interface Scte27CaptionSourceOptions {
    /**
     * The PID to extract captions from. See the MediaLive docs for how PID and `languageCode`
     * interact.
     * @default - MediaLive service default
     */
    readonly pid?: number;
    /**
     * The OCR language to use when converting this image-based source to text.
     * @default - MediaLive service default
     */
    readonly ocrLanguage?: OcrLanguage;
}
/**
 * A display rectangle, expressed as percentages of the underlying video frame, for captions
 * converted to EBU-TT-D or TTML.
 */
export interface CaptionRectangle {
    /** Height of the rectangle, as a percentage of the frame height (0–100). */
    readonly height: number;
    /** Width of the rectangle, as a percentage of the frame width (0–100). */
    readonly width: number;
    /** Left edge position, as a percentage of the frame width (0–100). */
    readonly leftOffset: number;
    /** Top edge position, as a percentage of the frame height (0–100). */
    readonly topOffset: number;
}
/**
 * Options for a Teletext caption source.
 */
export interface TeletextCaptionSourceOptions {
    /**
     * The Teletext page number to extract captions from, as a hexadecimal string with no
     * `0x` prefix (range `100`–`8FF`). Unused for passthrough.
     * @default - MediaLive service default
     */
    readonly pageNumber?: string;
    /**
     * The caption rectangle to use when converting this source to EBU-TT-D or TTML.
     * @default - no rectangle (service default)
     */
    readonly outputRectangle?: CaptionRectangle;
}
/**
 * Controls whether MediaLive delays video to synchronize captions with audio and video output.
 */
export declare class CaptionSynchronizationMode {
    /** MediaLive does not delay video for caption alignment. */
    static readonly NO_VIDEO_DELAY: CaptionSynchronizationMode;
    /** MediaLive delays video to ensure captions are synchronized with audio and video. */
    static readonly VIDEO_ALIGNED_CAPTIONS: CaptionSynchronizationMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): CaptionSynchronizationMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Options for a smart subtitle caption source (AI-generated subtitles via Elemental Inference).
 */
export interface SmartSubtitleSourceOptions {
    /**
     * The name of the Elemental Inference feed output that provides the subtitles.
     * @default - service default
     */
    readonly inferenceFeedOutput?: string;
    /**
     * Controls whether MediaLive delays video to synchronize captions with audio and video output.
     * @default - service default
     */
    readonly captionSynchronizationMode?: CaptionSynchronizationMode;
}
/**
 * A caption selector that identifies which captions to extract from the input. Create with
 * the static factory methods — one per caption source format.
 */
export declare abstract class CaptionSelector {
    /**
     * Select captions by language code (no specific source format).
     */
    static byLanguage(name: string, languageCode: string): CaptionSelector;
    /**
     * Select embedded (CEA-608/708) captions.
     */
    static embedded(name: string, options?: EmbeddedCaptionSourceOptions): CaptionSelector;
    /**
     * Select ancillary captions.
     */
    static ancillary(name: string, options?: AncillaryCaptionSourceOptions): CaptionSelector;
    /**
     * Select ARIB captions.
     */
    static arib(name: string): CaptionSelector;
    /**
     * Select DVB-Sub (image-based) captions.
     */
    static dvbSub(name: string, options?: DvbSubCaptionSourceOptions): CaptionSelector;
    /**
     * Select SCTE-20 captions.
     */
    static scte20(name: string, options?: Scte20CaptionSourceOptions): CaptionSelector;
    /**
     * Select SCTE-27 (image-based) captions.
     */
    static scte27(name: string, options?: Scte27CaptionSourceOptions): CaptionSelector;
    /**
     * Select Teletext captions.
     */
    static teletext(name: string, options?: TeletextCaptionSourceOptions): CaptionSelector;
    /**
     * Select smart subtitles generated by Elemental Inference.
     */
    static smartSubtitle(name: string, options?: SmartSubtitleSourceOptions): CaptionSelector;
    /**
     * The name of this caption selector, used to associate it with caption outputs. Unique
     * within a channel.
     */
    readonly name: string;
    protected constructor(name: string);
}
