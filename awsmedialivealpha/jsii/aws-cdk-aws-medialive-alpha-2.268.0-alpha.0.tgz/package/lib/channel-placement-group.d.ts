import type { IResource } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { ChannelPlacementGroupReference, IChannelPlacementGroupRef, IClusterRef } from 'aws-cdk-lib/aws-medialive';
import type { Construct } from 'constructs';
/**
 * Represents a MediaLive Channel Placement Group.
 */
export interface IChannelPlacementGroup extends IResource, IChannelPlacementGroupRef {
    /**
     * The ARN of the channel placement group.
     * @attribute
     */
    readonly channelPlacementGroupArn: string;
    /**
     * The ID of the channel placement group.
     * @attribute
     */
    readonly channelPlacementGroupId: string;
}
/**
 * Properties for creating a MediaLive Channel Placement Group.
 */
export interface ChannelPlacementGroupProps {
    /**
     * The name of the channel placement group.
     * @default - auto-generated name
     */
    readonly channelPlacementGroupName?: string;
    /**
     * The cluster this channel placement group belongs to.
     */
    readonly cluster: IClusterRef;
    /**
     * List of node IDs for the channel placement group.
     * @default - no nodes
     */
    readonly nodes?: string[];
    /**
     * Tags to add to the channel placement group.
     * @default - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Attributes for importing an existing Channel Placement Group.
 */
export interface ChannelPlacementGroupAttributes {
    /** The ARN of the channel placement group. */
    readonly channelPlacementGroupArn: string;
    /** The ID of the channel placement group. */
    readonly channelPlacementGroupId: string;
    /** The ID of the cluster this group belongs to. */
    readonly clusterId: string;
}
/**
 * Defines an AWS Elemental MediaLive Channel Placement Group.
 *
 * A channel placement group assigns channels to specific nodes within a cluster.
 */
export declare class ChannelPlacementGroup extends Resource implements IChannelPlacementGroup {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /** Import an existing channel placement group by its attributes. */
    static fromChannelPlacementGroupAttributes(scope: Construct, id: string, attrs: ChannelPlacementGroupAttributes): IChannelPlacementGroup;
    readonly channelPlacementGroupArn: string;
    readonly channelPlacementGroupId: string;
    private readonly clusterId;
    /** A reference to this Channel Placement Group resource. */
    get channelPlacementGroupRef(): ChannelPlacementGroupReference;
    constructor(scope: Construct, id: string, props: ChannelPlacementGroupProps);
}
