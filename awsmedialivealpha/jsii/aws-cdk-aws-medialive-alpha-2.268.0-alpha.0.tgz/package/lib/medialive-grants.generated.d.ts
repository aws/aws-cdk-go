import * as medialive from "aws-cdk-lib/aws-medialive";
import * as iam from "aws-cdk-lib/aws-iam";
import * as cdk from "aws-cdk-lib/core";
/**
 * Collection of grant methods for a IChannelRef
 */
export declare class ChannelGrants {
    /**
     * Creates grants for ChannelGrants
     */
    static fromChannel(resource: medialive.IChannelRef): ChannelGrants;
    protected readonly resource: medialive.IChannelRef;
    private constructor();
    /**
     * Grant the given identity custom permissions
     */
    actions(grantee: iam.IGrantable, actions: Array<string>, options?: cdk.PermissionsOptions): iam.Grant;
    /**
     * Grant permissions to start this channel
     */
    start(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant permissions to stop this channel
     */
    stop(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant permissions to update the schedule of this channel
     */
    updateSchedule(grantee: iam.IGrantable): iam.Grant;
}
