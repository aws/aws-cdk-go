import type { IBucket } from 'aws-cdk-lib/aws-s3';
import type { IStringParameter } from 'aws-cdk-lib/aws-ssm';
/**
 * Options for a URL-based file location (`FileLocation.url`).
 */
export interface FileLocationOptions {
    /**
     * The username for accessing the upstream system.
     * @default - no credentials
     */
    readonly username?: string;
    /**
     * The SSM parameter that holds the password for accessing the upstream system. The channel
     * role is granted read access to the parameter automatically.
     * @default - no credentials
     */
    readonly password?: IStringParameter;
}
/**
 * A reference to a file MediaLive reads at runtime — for example an input-loss slate image,
 * an avail-blanking image, a burn-in caption font, or a color-correction LUT.
 *
 * Use the static factory methods to create one from an S3 bucket (which auto-grants the
 * channel role read access) or from a raw URL.
 */
export declare abstract class FileLocation {
    /**
     * Reference a file in an S3 bucket. Automatically grants the channel role read access.
     *
     * @param bucket The S3 bucket containing the file.
     * @param key The object key within the bucket (e.g. 'slates/offline.png').
     */
    static fromBucket(bucket: IBucket, key: string): FileLocation;
    /**
     * Reference a file by URL (e.g. an `https://` endpoint or an `s3ssl://` path).
     *
     * @param url The URL MediaLive reads the file from.
     * @param options Optional credentials.
     */
    static url(url: string, options?: FileLocationOptions): FileLocation;
}
/**
 * The S3 location of a 3D LUT (look-up table) file used by a color-correction rule. MediaLive
 * reads the LUT from S3 at runtime, so the file must be in an S3 bucket — the URI must use the
 * `s3://` or `s3ssl://` protocol. Unlike a `FileLocation`, a LUT has no credentials.
 *
 * Use the static factory methods to create one from an S3 bucket (which uses the secure
 * `s3ssl://` form and auto-grants the channel role read access) or a raw S3 URL.
 */
export declare abstract class Lut {
    /**
     * Reference a LUT file in an S3 bucket. Uses the secure `s3ssl://` form and automatically
     * grants the channel role read access.
     *
     * @param bucket The S3 bucket containing the LUT file.
     * @param key The object key within the bucket (e.g. 'luts/rec709.cube').
     */
    static fromBucket(bucket: IBucket, key: string): Lut;
    /**
     * Reference a LUT file by S3 URL. The URL must use the `s3://` or `s3ssl://` protocol.
     *
     * @param url The `s3://` or `s3ssl://` URL of the LUT file.
     */
    static url(url: string): Lut;
}
