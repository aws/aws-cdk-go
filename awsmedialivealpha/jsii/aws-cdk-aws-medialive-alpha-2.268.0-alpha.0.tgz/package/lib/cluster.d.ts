import type { IResource } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { ClusterReference, IClusterRef } from 'aws-cdk-lib/aws-medialive';
import type { Construct } from 'constructs';
/**
 * The hardware type for the cluster.
 */
export declare class ClusterType {
    /** On-premises cluster */
    static readonly ON_PREMISES: ClusterType;
    /** AWS Outposts rack */
    static readonly OUTPOSTS_RACK: ClusterType;
    /** AWS Outposts server */
    static readonly OUTPOSTS_SERVER: ClusterType;
    /** Amazon EC2 */
    static readonly EC2: ClusterType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): ClusterType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * A mapping between a logical interface name and a network ID.
 */
export interface InterfaceMapping {
    /**
     * The logical interface name.
     */
    readonly logicalInterfaceName: string;
    /**
     * The network ID to map to.
     */
    readonly networkId: string;
}
/**
 * Network settings for a MediaLive Cluster.
 */
export interface ClusterNetworkSettings {
    /**
     * The default route for the cluster.
     * @default - no default route
     */
    readonly defaultRoute?: string;
    /**
     * The interface mappings for the cluster.
     * @default - no interface mappings
     */
    readonly interfaceMappings?: InterfaceMapping[];
}
/**
 * Represents a MediaLive Cluster.
 */
export interface ICluster extends IResource, IClusterRef {
    /**
     * The ARN of the cluster.
     * @attribute
     */
    readonly clusterArn: string;
    /**
     * The ID of the cluster.
     * @attribute
     */
    readonly clusterId: string;
    /**
     * The IDs of channels running on this cluster.
     * @attribute
     */
    readonly clusterChannelIds?: string[];
    /**
     * The current state of the cluster.
     * @attribute
     */
    readonly clusterState?: string;
}
/**
 * Properties for creating a MediaLive Cluster.
 */
export interface ClusterProps {
    /**
     * The name of the cluster.
     * @default - auto-generated name
     */
    readonly clusterName?: string;
    /**
     * The hardware type for the cluster.
     * @default ClusterType.ON_PREMISES
     */
    readonly clusterType?: ClusterType;
    /**
     * The IAM role for nodes in the cluster.
     *
     * [disable-awslint:prefer-ref-interface]
     */
    readonly instanceRole: IRole;
    /**
     * Network settings for the cluster - only required if your networking setup requires it.
     * @see https://docs.aws.amazon.com/medialive/latest/ug/emla-deploy-identify-network-requirements.html
     *
     * @default - no network settings
     */
    readonly networkSettings?: ClusterNetworkSettings;
    /**
     * Tags to add to the cluster.
     * @default - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Defines an AWS Elemental MediaLive Cluster.
 *
 * A cluster represents a group of on-premises hardware nodes used by MediaLive Anywhere.
 */
export declare class Cluster extends Resource implements ICluster {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /** Import an existing cluster by its ARN. The id is parsed out of the ARN. */
    static fromClusterArn(scope: Construct, id: string, clusterArn: string): ICluster;
    readonly clusterArn: string;
    readonly clusterId: string;
    readonly clusterChannelIds?: string[];
    readonly clusterState?: string;
    /** A reference to this Cluster resource. */
    get clusterRef(): ClusterReference;
    constructor(scope: Construct, id: string, props: ClusterProps);
}
