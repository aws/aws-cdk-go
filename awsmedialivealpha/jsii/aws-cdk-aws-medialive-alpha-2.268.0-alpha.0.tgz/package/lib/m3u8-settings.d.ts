import type { Duration } from 'aws-cdk-lib';
import type { FileLocation } from './file-location';
/** Controls insertion of the Program Clock Reference (PCR) in an M3U8 container. */
export declare class M3u8PcrControl {
    /** Insert PCR at the configured `pcrPeriod`. */
    static readonly CONFIGURED_PCR_PERIOD: M3u8PcrControl;
    /** Insert a PCR for every Packetized Elementary Stream (PES) header. */
    static readonly PCR_EVERY_PES_PACKET: M3u8PcrControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M3u8PcrControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** SCTE-35 passthrough behavior for an M3U8 container. */
export declare class M3u8Scte35Behavior {
    /** Do not pass SCTE-35 signals through. */
    static readonly NO_PASSTHROUGH: M3u8Scte35Behavior;
    /** Pass SCTE-35 signals from the input through to the output. */
    static readonly PASSTHROUGH: M3u8Scte35Behavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M3u8Scte35Behavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Timed-metadata passthrough behavior for an M3U8 container. */
export declare class M3u8TimedMetadataBehavior {
    /** Do not pass timed metadata through. */
    static readonly NO_PASSTHROUGH: M3u8TimedMetadataBehavior;
    /** Pass timed metadata from the input through to the output. */
    static readonly PASSTHROUGH: M3u8TimedMetadataBehavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M3u8TimedMetadataBehavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Nielsen ID3 passthrough behavior for an M3U8 container. */
export declare class M3u8NielsenId3Behavior {
    /** Do not insert Nielsen ID3 tags. */
    static readonly NO_PASSTHROUGH: M3u8NielsenId3Behavior;
    /** Nielsen inaudible tones for media tracking will be detected in the input audio and an equivalent ID3 tag will be inserted in the output. */
    static readonly PASSTHROUGH: M3u8NielsenId3Behavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M3u8NielsenId3Behavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** KLV data passthrough behavior for an M3U8 container. */
export declare class M3u8KlvBehavior {
    /** Do not pass KLV data through. */
    static readonly NONE: M3u8KlvBehavior;
    /** Pass KLV data from the input through to the output. */
    static readonly PASSTHROUGH: M3u8KlvBehavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M3u8KlvBehavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Properties for M3U8 container settings.
 *
 * PID properties accept a decimal or hexadecimal value (and, where noted, ranges or
 * comma-separated lists). Interval properties are `Duration` values rendered as milliseconds.
 */
export interface M3u8SettingsProps {
    /**
     * The number of audio frames to insert for each PES packet.
     * @default - service default
     */
    readonly audioFramesPerPes?: number;
    /**
     * The PID(s) of the elementary audio streams. Accepts ranges and comma separation.
     * @default - service default
     */
    readonly audioPids?: string;
    /**
     * KLV data passthrough behavior.
     * @default - service default
     */
    readonly klvBehavior?: M3u8KlvBehavior;
    /**
     * The PID(s) of the KLV data streams.
     * @default - service default
     */
    readonly klvDataPids?: string;
    /**
     * Nielsen ID3 passthrough behavior.
     * @default - service default
     */
    readonly nielsenId3Behavior?: M3u8NielsenId3Behavior;
    /**
     * The interval between instances of the PAT in the output. A value of 0 writes the PAT once
     * per segment file.
     * @default - service default
     */
    readonly patInterval?: Duration;
    /**
     * Controls insertion of the Program Clock Reference (PCR).
     * @default - service default
     */
    readonly pcrControl?: M3u8PcrControl;
    /**
     * The maximum interval between Program Clock References (PCRs).
     * @default - service default
     */
    readonly pcrPeriod?: Duration;
    /**
     * The PID of the Program Clock Reference (PCR). Defaults to the video PID.
     * @default - same as the video PID
     */
    readonly pcrPid?: string;
    /**
     * The interval between instances of the PMT in the output. A value of 0 writes the PMT once
     * per segment file.
     * @default - service default
     */
    readonly pmtInterval?: Duration;
    /**
     * The PID of the Program Map Table (PMT).
     * @default - service default
     */
    readonly pmtPid?: string;
    /**
     * The value of the program number field in the PMT.
     * @default - service default
     */
    readonly programNum?: number;
    /**
     * SCTE-35 passthrough behavior.
     * @default - service default
     */
    readonly scte35Behavior?: M3u8Scte35Behavior;
    /**
     * The PID of the SCTE-35 stream.
     * @default - service default
     */
    readonly scte35Pid?: string;
    /**
     * Timed-metadata passthrough behavior.
     * @default - service default
     */
    readonly timedMetadataBehavior?: M3u8TimedMetadataBehavior;
    /**
     * The PID of the timed-metadata stream. Valid values are 32 (0x20)..8182 (0x1ff6).
     * @default - service default
     */
    readonly timedMetadataPid?: string;
    /**
     * The value of the transport stream ID field in the PMT.
     * @default - service default
     */
    readonly transportStreamId?: number;
    /**
     * The PID of the elementary video stream.
     * @default - service default
     */
    readonly videoPid?: string;
}
/**
 * M3U8 container settings for a standard HLS output.
 *
 * Use `M3u8Settings.of()` to control the transport stream produced by a standard HLS output.
 * Omitting it uses MediaLive's service defaults.
 */
export declare class M3u8Settings {
    private readonly props;
    /** Create M3U8 container settings. */
    static of(props: M3u8SettingsProps): M3u8Settings;
    private constructor();
}
/** The audio track type for an audio-only HLS output. */
export declare class HlsAudioTrackType {
    /** A playable audio-only variant stream (EXT-X-STREAM-INF). */
    static readonly AUDIO_ONLY_VARIANT_STREAM: HlsAudioTrackType;
    /** Alternate rendition, auto-select, default (DEFAULT=YES, AUTOSELECT=YES). */
    static readonly ALTERNATE_AUDIO_AUTO_SELECT_DEFAULT: HlsAudioTrackType;
    /** Alternate rendition, auto-select, not default (DEFAULT=NO, AUTOSELECT=YES). */
    static readonly ALTERNATE_AUDIO_AUTO_SELECT: HlsAudioTrackType;
    /** Alternate rendition, not auto-select (DEFAULT=NO, AUTOSELECT=NO). */
    static readonly ALTERNATE_AUDIO_NOT_AUTO_SELECT: HlsAudioTrackType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsAudioTrackType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** The segment container type for an audio-only HLS output. */
export declare class HlsAudioOnlySegmentType {
    /** AAC segments. */
    static readonly AAC: HlsAudioOnlySegmentType;
    /** fMP4 segments. */
    static readonly FMP4: HlsAudioOnlySegmentType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsAudioOnlySegmentType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Properties for standard (video) HLS settings. */
export interface StandardHlsSettingsProps {
    /**
     * The audio GROUP-IDs used with this video output stream, comma-separated.
     * @default - service default
     */
    readonly audioRenditionSets?: string;
    /**
     * The M3U8 container settings.
     * @default - service defaults
     */
    readonly m3u8Settings?: M3u8Settings;
}
/** Properties for audio-only HLS settings. */
export interface AudioOnlyHlsSettingsProps {
    /**
     * The group that this audio rendition belongs to.
     * @default - service default
     */
    readonly audioGroupId?: string;
    /**
     * A .jpg or .png cover-art image embedded in each audio-only segment. Provide a `FileLocation`
     * referencing an S3 bucket (`FileLocation.fromBucket`, which auto-grants read access) or a URL
     * (`FileLocation.url`).
     * @default - no cover art
     */
    readonly audioOnlyImage?: FileLocation;
    /**
     * How the audio rendition is signaled in the HLS manifest.
     * @default - service default
     */
    readonly audioTrackType?: HlsAudioTrackType;
    /**
     * The segment container type.
     * @default - service default
     */
    readonly segmentType?: HlsAudioOnlySegmentType;
}
/** Properties for fMP4 HLS settings. */
export interface Fmp4HlsSettingsProps {
    /**
     * The audio GROUP-IDs used with this video output stream, comma-separated.
     * @default - service default
     */
    readonly audioRenditionSets?: string;
    /**
     * Nielsen ID3 passthrough behavior.
     * @default - service default
     */
    readonly nielsenId3Behavior?: M3u8NielsenId3Behavior;
    /**
     * Timed-metadata passthrough behavior.
     * @default - service default
     */
    readonly timedMetadataBehavior?: M3u8TimedMetadataBehavior;
}
/**
 * Per-output HLS settings. Select the variant that matches the output: a standard (video)
 * output, an audio-only rendition, an fMP4 output, or a frame-capture output.
 */
export declare abstract class HlsSettings {
    /** Settings for a standard (video) HLS output. */
    static standard(props?: StandardHlsSettingsProps): HlsSettings;
    /** Settings for an audio-only HLS rendition. */
    static audioOnly(props?: AudioOnlyHlsSettingsProps): HlsSettings;
    /** Settings for an fMP4 HLS output. */
    static fmp4(props?: Fmp4HlsSettingsProps): HlsSettings;
    /** Settings for a frame-capture output in an HLS output group. */
    static frameCapture(): HlsSettings;
}
