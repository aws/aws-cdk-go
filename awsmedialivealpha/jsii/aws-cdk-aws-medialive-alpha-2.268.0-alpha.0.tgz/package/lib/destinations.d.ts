import type { IChannel as IMediaPackageV2Channel } from '@aws-cdk/aws-mediapackagev2-alpha';
import type { IBucket } from 'aws-cdk-lib/aws-s3';
import type { ISecret } from 'aws-cdk-lib/aws-secretsmanager';
import type { IStringParameter } from 'aws-cdk-lib/aws-ssm';
/**
 * A destination address (IP or host) and port for a transport-stream output.
 */
export interface TransportOutputDestinationProps {
    /** The destination address — a unicast or multicast IP, or a hostname. */
    readonly address: string;
    /** The destination port. */
    readonly port: number;
}
/**
 * Options for a URL-based output destination.
 */
export interface OutputDestinationOptions {
    /**
     * The username for accessing the downstream system.
     * @default - no credentials
     */
    readonly username?: string;
    /**
     * An SSM String Parameter holding the password for accessing the downstream system. MediaLive
     * reads it from Parameter Store at channel runtime, so the channel role is granted read access.
     * @default - no credentials
     */
    readonly password?: IStringParameter;
}
/**
 * A general URL-based output destination — an S3 bucket or an HTTP(S) endpoint.
 *
 * Used by HLS, MS Smooth, and CMAF Ingest output groups. Each output group's `destinations`
 * prop is typed to the destination valid for its protocol, so an invalid pairing (e.g. a UDP
 * destination on an HLS group) is a compile-time error rather than a deploy-time failure.
 */
export declare class OutputDestination {
    private readonly destUrl;
    private readonly bucket?;
    private readonly options?;
    /** Deliver to an S3 bucket (auto-grants write to the channel role). */
    static toBucket(bucket: IBucket, prefix?: string): OutputDestination;
    /** Deliver to a raw URL — typically an `https://` origin (or an `s3ssl://` path). */
    static url(url: string, options?: OutputDestinationOptions): OutputDestination;
    private constructor();
}
/**
 * A destination for an Archive or Frame Capture output group — always an S3 bucket.
 */
export declare class S3OutputDestination {
    private readonly destUrl;
    private readonly bucket?;
    /** Deliver to an S3 bucket (auto-grants write to the channel role). */
    static toBucket(bucket: IBucket, prefix?: string): S3OutputDestination;
    /** Deliver to a raw `s3ssl://` path (escape hatch when you don't have a bucket construct). */
    static url(url: string): S3OutputDestination;
    private constructor();
}
/**
 * A destination for a UDP output group — a UDP or RTP transport endpoint.
 */
export declare class UdpOutputDestination {
    private readonly destUrl;
    /** Deliver over UDP — builds `udp://address:port`. */
    static udp(props: TransportOutputDestinationProps): UdpOutputDestination;
    /** Deliver over RTP — builds `rtp://address:port`. */
    static rtp(props: TransportOutputDestinationProps): UdpOutputDestination;
    /** Deliver to a raw transport URL (escape hatch). */
    static url(url: string): UdpOutputDestination;
    private constructor();
}
/**
 * A destination for an RTMP output group. Use the static factory methods to create.
 */
export declare abstract class RtmpDestination {
    /**
     * Create an RTMP destination.
     * @param url The RTMP endpoint URL (e.g. rtmp://host/appname).
     * @param streamName The stream name (stream key).
     * @param options Optional credentials.
     */
    static url(url: string, streamName: string, options?: OutputDestinationOptions): RtmpDestination;
}
/**
 * SRT caller destination properties.
 */
export interface SrtCallerDestinationProps {
    /** The address (IP or host) of the SRT listener to connect to. */
    readonly address: string;
    /** The port of the SRT listener to connect to. */
    readonly port: number;
    /**
     * The stream ID for the SRT connection.
     * @default - no stream ID
     */
    readonly streamId?: string;
    /**
     * The Secrets Manager secret containing the encryption passphrase.
     *
     * [disable-awslint:prefer-ref-interface]
     */
    readonly encryptionPassphraseSecret: ISecret;
}
/**
 * Options for a URL-based SRT caller destination (`SrtDestination.callerUrl`).
 */
export interface SrtCallerUrlOptions {
    /**
     * The stream ID for the SRT connection.
     * @default - no stream ID
     */
    readonly streamId?: string;
    /**
     * The Secrets Manager secret containing the encryption passphrase.
     *
     * [disable-awslint:prefer-ref-interface]
     */
    readonly encryptionPassphraseSecret: ISecret;
}
/**
 * SRT listener destination properties.
 *
 * In listener mode, MediaLive opens a socket on `listenerPort` and waits for the downstream
 * system to connect. The downstream system needs the channel's outbound IP and this port —
 * AWS does not require (or use) a destination URL in listener mode.
 */
export interface SrtListenerDestinationProps {
    /** The port that MediaLive will listen on. AWS reserves the range 5000–5200 for SRT listener output. */
    readonly listenerPort: number;
    /**
     * The stream ID for the SRT connection.
     * @default - no stream ID
     */
    readonly streamId?: string;
    /**
     * The Secrets Manager secret containing the encryption passphrase.
     *
     * [disable-awslint:prefer-ref-interface]
     */
    readonly encryptionPassphraseSecret: ISecret;
}
/**
 * A destination for an SRT output group. Use the static factory methods to create.
 */
export declare abstract class SrtDestination {
    /** Create a caller-mode SRT destination. MediaLive connects to the remote listener. */
    static caller(props: SrtCallerDestinationProps): SrtDestination;
    /**
     * Create a caller-mode SRT destination from a full SRT URL.
     *
     * Use this when you already have a URL rather than a separate host and port — for example a
     * MediaConnect Router Input's ingest endpoint (`routerInput.endpoints[0].url`).
     */
    static callerUrl(url: string, options: SrtCallerUrlOptions): SrtDestination;
    /** Create a listener-mode SRT destination. MediaLive listens for incoming connections. */
    static listener(props: SrtListenerDestinationProps): SrtDestination;
}
/**
 * The pipeline endpoint for a MediaPackage V2 destination.
 */
export declare class MediaPackageV2EndpointId {
    /** Pipeline 0 endpoint */
    static readonly ENDPOINT_1: MediaPackageV2EndpointId;
    /** Pipeline 1 endpoint */
    static readonly ENDPOINT_2: MediaPackageV2EndpointId;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MediaPackageV2EndpointId;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * A MediaPackage V2 destination for a MediaLive output group.
 * Use the static factory method to create.
 */
export declare abstract class MediaPackageV2Destination {
    /**
     * Create a MediaPackage V2 destination.
     *
     * The region is resolved from the channel's `region` property. Import the MediaPackage V2
     * channel with its region (e.g. via `fromChannelAttributes`) for cross-region delivery.
     *
     * @param channel The MediaPackage V2 channel to send output to.
     * @param endpointId The pipeline endpoint to send to. When omitted, `channelEndpointId` and the
     * region are left unset and MediaLive maps the pipeline automatically (same-region only).
     */
    static channel(channel: IMediaPackageV2Channel, endpointId?: MediaPackageV2EndpointId): MediaPackageV2Destination;
}
/**
 * Per-pipeline settings for a MediaConnect Router output destination.
 *
 * Today this carries only transit encryption, but it is a struct so that future per-pipeline
 * MediaConnect Router settings can be added without an API break.
 */
export interface MediaConnectRouterPipelineConfig {
    /**
     * A Secrets Manager secret holding the transit-encryption passphrase. When set, the pipeline
     * uses `SECRETS_MANAGER` encryption; the channel role is granted read access to the secret.
     *
     * @default - AUTOMATIC (service-managed) transit encryption
     */
    readonly encryptionSecret?: ISecret;
}
/**
 * Per-pipeline settings for `MediaConnectRouterSettings.perPipeline()`.
 *
 * MediaLive maps a channel's pipelines to MediaConnect Router output destinations positionally;
 * the console labels them "Destination A" (pipeline 0) and "Destination B" (pipeline 1). An
 * omitted pipeline uses AUTOMATIC transit encryption.
 */
export interface MediaConnectRouterPerPipelineSettings {
    /**
     * Settings for pipeline 0 ("Destination A" in the MediaLive console).
     * @default - AUTOMATIC transit encryption
     */
    readonly pipeline0?: MediaConnectRouterPipelineConfig;
    /**
     * Settings for pipeline 1 ("Destination B" in the console). STANDARD channels only —
     * SINGLE_PIPELINE channels have no second pipeline.
     * @default - AUTOMATIC transit encryption
     */
    readonly pipeline1?: MediaConnectRouterPipelineConfig;
}
/**
 * Transit-encryption settings for a MediaConnect Router output group, applied per channel pipeline.
 *
 * Omit the output group's `routerSettings` entirely for AUTOMATIC (service-managed) encryption on
 * every pipeline. Use `shared()` to apply one secret across all pipelines, or `perPipeline()` to
 * control each pipeline independently.
 */
export declare abstract class MediaConnectRouterSettings {
    /**
     * Apply the same settings to every pipeline.
     *
     * @param settings the settings to apply to all pipelines. Omit `encryptionSecret` for AUTOMATIC.
     */
    static shared(settings?: MediaConnectRouterPipelineConfig): MediaConnectRouterSettings;
    /**
     * Configure each pipeline independently. An omitted pipeline uses AUTOMATIC encryption.
     */
    static perPipeline(settings: MediaConnectRouterPerPipelineSettings): MediaConnectRouterSettings;
}
