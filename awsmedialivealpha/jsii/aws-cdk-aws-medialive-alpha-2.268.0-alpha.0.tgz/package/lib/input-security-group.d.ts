import type { IResource } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { IInputSecurityGroupRef, InputSecurityGroupReference } from 'aws-cdk-lib/aws-medialive';
import type { Construct } from 'constructs';
/**
 * Represents a MediaLive Input Security Group.
 */
export interface IInputSecurityGroup extends IResource, IInputSecurityGroupRef {
    /**
     * The ARN of the input security group.
     * @attribute
     */
    readonly inputSecurityGroupArn: string;
    /**
     * The ID of the input security group.
     * @attribute
     */
    readonly inputSecurityGroupId: string;
}
/**
 * Properties for creating a MediaLive Input Security Group.
 */
export interface InputSecurityGroupProps {
    /**
     * The list of IPv4 CIDR addresses to allow.
     */
    readonly allowlistRules: string[];
    /**
     * Tags to add to the input security group.
     * @default - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Defines an AWS Elemental MediaLive Input Security Group.
 *
 * An input security group controls which IPv4 CIDR blocks can push content to a push-type input.
 */
export declare class InputSecurityGroup extends Resource implements IInputSecurityGroup {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /** Import an existing input security group by its ARN. The id is parsed out of the ARN. */
    static fromInputSecurityGroupArn(scope: Construct, id: string, inputSecurityGroupArn: string): IInputSecurityGroup;
    readonly inputSecurityGroupArn: string;
    readonly inputSecurityGroupId: string;
    /** A reference to this Input Security Group resource. */
    get inputSecurityGroupRef(): InputSecurityGroupReference;
    constructor(scope: Construct, id: string, props: InputSecurityGroupProps);
}
