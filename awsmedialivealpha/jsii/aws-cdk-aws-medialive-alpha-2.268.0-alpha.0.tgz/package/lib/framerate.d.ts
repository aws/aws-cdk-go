/**
 * A video frame rate expressed as a rational number (numerator/denominator).
 *
 * Use the predefined constants for standard rates, or {@link Framerate.of} for a custom rate.
 */
export declare class Framerate {
    /** 24 fps (cinema) — `24/1`. */
    static readonly FPS_24: Framerate;
    /** 25 fps — `25/1`. */
    static readonly FPS_25: Framerate;
    /** 29.97 fps — `30000/1001`. */
    static readonly FPS_29_97: Framerate;
    /** 30 fps — `30/1`. */
    static readonly FPS_30: Framerate;
    /** 50 fps — `50/1`. */
    static readonly FPS_50: Framerate;
    /** 59.94 fps — `60000/1001`. */
    static readonly FPS_59_94: Framerate;
    /** 60 fps — `60/1`. */
    static readonly FPS_60: Framerate;
    /**
     * Define a custom frame rate.
     *
     * @param numerator Numerator of the rate.
     * @param denominator Denominator of the rate.
     */
    static of(numerator: number, denominator: number): Framerate;
    private constructor();
    /** Returns the string value. */
    toString(): string;
}
