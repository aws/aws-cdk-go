import type { Bitrate, Duration } from 'aws-cdk-lib';
import type { Framerate } from './framerate';
import { PixelAspectRatio } from './shared';
/**
 * H.264 profile.
 */
export declare class H264Profile {
    /** Baseline profile */
    static readonly BASELINE: H264Profile;
    /** Main profile */
    static readonly MAIN: H264Profile;
    /** High profile */
    static readonly HIGH: H264Profile;
    /** High 10-bit profile */
    static readonly HIGH_10BIT: H264Profile;
    /** High 4:2:2 profile */
    static readonly HIGH_422: H264Profile;
    /** High 4:2:2 10-bit profile */
    static readonly HIGH_422_10BIT: H264Profile;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H264Profile;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.264 level.
 */
export declare class H264Level {
    /** Level 1 */
    static readonly H264_LEVEL_1: H264Level;
    /** Level 1.1 */
    static readonly H264_LEVEL_1_1: H264Level;
    /** Level 1.2 */
    static readonly H264_LEVEL_1_2: H264Level;
    /** Level 1.3 */
    static readonly H264_LEVEL_1_3: H264Level;
    /** Level 2 */
    static readonly H264_LEVEL_2: H264Level;
    /** Level 2.1 */
    static readonly H264_LEVEL_2_1: H264Level;
    /** Level 2.2 */
    static readonly H264_LEVEL_2_2: H264Level;
    /** Level 3 */
    static readonly H264_LEVEL_3: H264Level;
    /** Level 3.1 */
    static readonly H264_LEVEL_3_1: H264Level;
    /** Level 3.2 */
    static readonly H264_LEVEL_3_2: H264Level;
    /** Level 4 */
    static readonly H264_LEVEL_4: H264Level;
    /** Level 4.1 */
    static readonly H264_LEVEL_4_1: H264Level;
    /** Level 4.2 */
    static readonly H264_LEVEL_4_2: H264Level;
    /** Level 5 */
    static readonly H264_LEVEL_5: H264Level;
    /** Level 5.1 */
    static readonly H264_LEVEL_5_1: H264Level;
    /** Level 5.2 */
    static readonly H264_LEVEL_5_2: H264Level;
    /** Auto-select the level based on the encode configuration */
    static readonly H264_LEVEL_AUTO: H264Level;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H264Level;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.265 level.
 */
export declare class H265Level {
    /** Level 1 */
    static readonly H265_LEVEL_1: H265Level;
    /** Level 2 */
    static readonly H265_LEVEL_2: H265Level;
    /** Level 2.1 */
    static readonly H265_LEVEL_2_1: H265Level;
    /** Level 3 */
    static readonly H265_LEVEL_3: H265Level;
    /** Level 3.1 */
    static readonly H265_LEVEL_3_1: H265Level;
    /** Level 4 */
    static readonly H265_LEVEL_4: H265Level;
    /** Level 4.1 */
    static readonly H265_LEVEL_4_1: H265Level;
    /** Level 5 */
    static readonly H265_LEVEL_5: H265Level;
    /** Level 5.1 */
    static readonly H265_LEVEL_5_1: H265Level;
    /** Level 5.2 */
    static readonly H265_LEVEL_5_2: H265Level;
    /** Level 6 */
    static readonly H265_LEVEL_6: H265Level;
    /** Level 6.1 */
    static readonly H265_LEVEL_6_1: H265Level;
    /** Level 6.2 */
    static readonly H265_LEVEL_6_2: H265Level;
    /** Auto-select the level based on the encode configuration */
    static readonly H265_LEVEL_AUTO: H265Level;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H265Level;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AV1 level.
 */
export declare class Av1Level {
    /** Level 2 */
    static readonly AV1_LEVEL_2: Av1Level;
    /** Level 2.1 */
    static readonly AV1_LEVEL_2_1: Av1Level;
    /** Level 3 */
    static readonly AV1_LEVEL_3: Av1Level;
    /** Level 3.1 */
    static readonly AV1_LEVEL_3_1: Av1Level;
    /** Level 4 */
    static readonly AV1_LEVEL_4: Av1Level;
    /** Level 4.1 */
    static readonly AV1_LEVEL_4_1: Av1Level;
    /** Level 5 */
    static readonly AV1_LEVEL_5: Av1Level;
    /** Level 5.1 */
    static readonly AV1_LEVEL_5_1: Av1Level;
    /** Level 5.2 */
    static readonly AV1_LEVEL_5_2: Av1Level;
    /** Level 5.3 */
    static readonly AV1_LEVEL_5_3: Av1Level;
    /** Level 6 */
    static readonly AV1_LEVEL_6: Av1Level;
    /** Level 6.1 */
    static readonly AV1_LEVEL_6_1: Av1Level;
    /** Level 6.2 */
    static readonly AV1_LEVEL_6_2: Av1Level;
    /** Level 6.3 */
    static readonly AV1_LEVEL_6_3: Av1Level;
    /** Auto-select the level based on the encode configuration */
    static readonly AV1_LEVEL_AUTO: Av1Level;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Av1Level;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.264 adaptive quantization strength.
 */
export declare class H264AdaptiveQuantization {
    /** Auto */
    static readonly AUTO: H264AdaptiveQuantization;
    /** High */
    static readonly HIGH: H264AdaptiveQuantization;
    /** Higher */
    static readonly HIGHER: H264AdaptiveQuantization;
    /** Low */
    static readonly LOW: H264AdaptiveQuantization;
    /** Max */
    static readonly MAX: H264AdaptiveQuantization;
    /** Medium */
    static readonly MEDIUM: H264AdaptiveQuantization;
    /** Off */
    static readonly OFF: H264AdaptiveQuantization;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H264AdaptiveQuantization;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * GOP size (keyframe interval). Use the static factory methods to specify in frames or seconds.
 *
 * The value must be greater than zero. When expressed in frames it must be a whole number;
 * when expressed in seconds it may be fractional.
 */
export declare class GopSize {
    /** GOP size in seconds. May be fractional (e.g. `1.5`). */
    static seconds(value: number): GopSize;
    /** GOP size in frames. Must be a whole number. */
    static frames(value: number): GopSize;
    private constructor();
}
/**
 * AFD signaling mode.
 */
export declare class AfdSignaling {
    /** Auto — preserve input AFD value */
    static readonly AUTO: AfdSignaling;
    /** Fixed — use the value from fixedAfd */
    static readonly FIXED: AfdSignaling;
    /** None — do not write AFD */
    static readonly NONE: AfdSignaling;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AfdSignaling;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Color metadata inclusion.
 */
export declare class ColorMetadata {
    /** Ignore — do not include color metadata */
    static readonly IGNORE: ColorMetadata;
    /** Insert — include color metadata */
    static readonly INSERT: ColorMetadata;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): ColorMetadata;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Scan type for the output video.
 */
export declare class ScanType {
    /** Interlaced (top field first) */
    static readonly INTERLACED: ScanType;
    /** Progressive */
    static readonly PROGRESSIVE: ScanType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): ScanType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Flicker adaptive quantization.
 */
export declare class FlickerAq {
    /** Enabled */
    static readonly ENABLED: FlickerAq;
    /** Disabled */
    static readonly DISABLED: FlickerAq;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): FlickerAq;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * GOP B-frame reference.
 */
export declare class GopBReference {
    /** Enabled */
    static readonly ENABLED: GopBReference;
    /** Disabled */
    static readonly DISABLED: GopBReference;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): GopBReference;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Lookahead rate control.
 */
export declare class LookAheadRateControl {
    /** High — better quality, more latency and memory */
    static readonly HIGH: LookAheadRateControl;
    /** Low — less latency and memory */
    static readonly LOW: LookAheadRateControl;
    /** Medium */
    static readonly MEDIUM: LookAheadRateControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): LookAheadRateControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Timecode insertion mode.
 *
 * @remarks This controls timecode insertion in the output elementary stream.
 * To preserve source timecodes, set `TimecodeSource.EMBEDDED` on the channel's `timecodeConfig`.
 */
export declare class TimecodeInsertion {
    /** Disabled — do not include timecodes */
    static readonly DISABLED: TimecodeInsertion;
    /** PIC_TIMING_SEI — pass through picture timing SEI messages */
    static readonly PIC_TIMING_SEI: TimecodeInsertion;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): TimecodeInsertion;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Sub-GOP length mode.
 */
export declare class SubgopLength {
    /** Dynamic — let MediaLive optimize B-frames per sub-GOP */
    static readonly DYNAMIC: SubgopLength;
    /** Fixed — use gopNumBFrames in each sub-GOP */
    static readonly FIXED: SubgopLength;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): SubgopLength;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.264 entropy encoding mode.
 */
export declare class H264EntropyEncoding {
    /** CABAC (requires Main or High profile) */
    static readonly CABAC: H264EntropyEncoding;
    /** CAVLC */
    static readonly CAVLC: H264EntropyEncoding;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H264EntropyEncoding;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.264 force field pictures.
 */
export declare class H264ForceFieldPictures {
    /** Enabled — force coding on a field basis */
    static readonly ENABLED: H264ForceFieldPictures;
    /** Disabled — let encoder decide */
    static readonly DISABLED: H264ForceFieldPictures;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H264ForceFieldPictures;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.264 syntax mode.
 */
export declare class H264Syntax {
    /** Default */
    static readonly DEFAULT: H264Syntax;
    /** RP-2027 compliant */
    static readonly RP2027: H264Syntax;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H264Syntax;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.264 quality level.
 */
export declare class H264QualityLevel {
    /** Enhanced quality (may incur additional cost) */
    static readonly ENHANCED_QUALITY: H264QualityLevel;
    /** Standard quality */
    static readonly STANDARD_QUALITY: H264QualityLevel;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H264QualityLevel;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.265 adaptive quantization.
 */
export declare class H265AdaptiveQuantization {
    /** Auto */
    static readonly AUTO: H265AdaptiveQuantization;
    /** High */
    static readonly HIGH: H265AdaptiveQuantization;
    /** Higher */
    static readonly HIGHER: H265AdaptiveQuantization;
    /** Low */
    static readonly LOW: H265AdaptiveQuantization;
    /** Max */
    static readonly MAX: H265AdaptiveQuantization;
    /** Medium */
    static readonly MEDIUM: H265AdaptiveQuantization;
    /** Off */
    static readonly OFF: H265AdaptiveQuantization;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H265AdaptiveQuantization;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.265 alternative transfer function.
 */
export declare class H265AlternativeTransferFunction {
    /** Insert */
    static readonly INSERT: H265AlternativeTransferFunction;
    /** Omit */
    static readonly OMIT: H265AlternativeTransferFunction;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H265AlternativeTransferFunction;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.265 deblocking filter.
 */
export declare class H265Deblocking {
    /** Disabled */
    static readonly DISABLED: H265Deblocking;
    /** Enabled */
    static readonly ENABLED: H265Deblocking;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H265Deblocking;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.265 motion vector over picture boundaries.
 */
export declare class H265MvOverPictureBoundaries {
    /** Disabled */
    static readonly DISABLED: H265MvOverPictureBoundaries;
    /** Enabled */
    static readonly ENABLED: H265MvOverPictureBoundaries;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H265MvOverPictureBoundaries;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.265 motion vector temporal predictor.
 */
export declare class H265MvTemporalPredictor {
    /** Disabled */
    static readonly DISABLED: H265MvTemporalPredictor;
    /** Enabled */
    static readonly ENABLED: H265MvTemporalPredictor;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H265MvTemporalPredictor;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.265 tile padding.
 */
export declare class H265TilePadding {
    /** None */
    static readonly NONE: H265TilePadding;
    /** Padded */
    static readonly PADDED: H265TilePadding;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H265TilePadding;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.265 treeblock size.
 */
export declare class H265TreeblockSize {
    /** Auto */
    static readonly AUTO: H265TreeblockSize;
    /** 32x32 */
    static readonly TREE_SIZE_32X32: H265TreeblockSize;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H265TreeblockSize;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AV1 bit depth.
 */
export declare class Av1BitDepth {
    /** 8-bit */
    static readonly BIT_DEPTH_8: Av1BitDepth;
    /** 10-bit */
    static readonly BIT_DEPTH_10: Av1BitDepth;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Av1BitDepth;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AV1 scene change detection.
 */
export declare class Av1SceneChangeDetect {
    /** Disabled */
    static readonly DISABLED: Av1SceneChangeDetect;
    /** Enabled */
    static readonly ENABLED: Av1SceneChangeDetect;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Av1SceneChangeDetect;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AV1 spatial adaptive quantization.
 */
export declare class Av1SpatialAq {
    /** Disabled */
    static readonly DISABLED: Av1SpatialAq;
    /** Enabled */
    static readonly ENABLED: Av1SpatialAq;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Av1SpatialAq;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AV1 temporal adaptive quantization.
 */
export declare class Av1TemporalAq {
    /** Disabled */
    static readonly DISABLED: Av1TemporalAq;
    /** Enabled */
    static readonly ENABLED: Av1TemporalAq;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Av1TemporalAq;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.264 scene change detection.
 */
export declare class H264SceneChangeDetect {
    /** Disabled */
    static readonly DISABLED: H264SceneChangeDetect;
    /** Enabled */
    static readonly ENABLED: H264SceneChangeDetect;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H264SceneChangeDetect;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.264 spatial adaptive quantization.
 */
export declare class H264SpatialAq {
    /** Disabled */
    static readonly DISABLED: H264SpatialAq;
    /** Enabled */
    static readonly ENABLED: H264SpatialAq;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H264SpatialAq;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.264 temporal adaptive quantization.
 */
export declare class H264TemporalAq {
    /** Disabled */
    static readonly DISABLED: H264TemporalAq;
    /** Enabled */
    static readonly ENABLED: H264TemporalAq;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H264TemporalAq;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.265 scene change detection.
 */
export declare class H265SceneChangeDetect {
    /** Disabled */
    static readonly DISABLED: H265SceneChangeDetect;
    /** Enabled */
    static readonly ENABLED: H265SceneChangeDetect;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H265SceneChangeDetect;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * AV1 timecode insertion.
 */
export declare class Av1TimecodeInsertion {
    /** Disabled — do not insert timecodes */
    static readonly DISABLED: Av1TimecodeInsertion;
    /**
     * Include timecodes as a metadata OBU (Open Bitstream Unit) of type
     * `METADATA_TYPE_TIMECODE`, based on the source specified in the channel's timecode config.
     */
    static readonly METADATA_OBU: Av1TimecodeInsertion;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Av1TimecodeInsertion;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Font size for timecode burn-in.
 */
export declare class TimecodeBurninFontSize {
    /** Extra small */
    static readonly EXTRA_SMALL_10: TimecodeBurninFontSize;
    /** Large */
    static readonly LARGE_48: TimecodeBurninFontSize;
    /** Medium */
    static readonly MEDIUM_32: TimecodeBurninFontSize;
    /** Small */
    static readonly SMALL_16: TimecodeBurninFontSize;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): TimecodeBurninFontSize;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Position for timecode burn-in overlay.
 */
export declare class TimecodeBurninPosition {
    /** Bottom center */
    static readonly BOTTOM_CENTER: TimecodeBurninPosition;
    /** Bottom left */
    static readonly BOTTOM_LEFT: TimecodeBurninPosition;
    /** Bottom right */
    static readonly BOTTOM_RIGHT: TimecodeBurninPosition;
    /** Middle center */
    static readonly MIDDLE_CENTER: TimecodeBurninPosition;
    /** Middle left */
    static readonly MIDDLE_LEFT: TimecodeBurninPosition;
    /** Middle right */
    static readonly MIDDLE_RIGHT: TimecodeBurninPosition;
    /** Top center */
    static readonly TOP_CENTER: TimecodeBurninPosition;
    /** Top left */
    static readonly TOP_LEFT: TimecodeBurninPosition;
    /** Top right */
    static readonly TOP_RIGHT: TimecodeBurninPosition;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): TimecodeBurninPosition;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Settings for burning a timecode overlay into the video output.
 */
export interface TimecodeBurninSettings {
    /**
     * The font size of the timecode overlay.
     * @default - service default
     */
    readonly fontSize?: TimecodeBurninFontSize;
    /**
     * The position of the timecode overlay on the video.
     * @default - service default
     */
    readonly position?: TimecodeBurninPosition;
    /**
     * A string prepended to the timecode (e.g. a channel name).
     * @default - no prefix
     */
    readonly prefix?: string;
}
/** Properties for CBR rate control. */
export interface CbrRateControlProps {
    /** The constant bitrate. */
    readonly bitrate: Bitrate;
}
/** Properties for VBR rate control. */
export interface VbrRateControlProps {
    /** The average bitrate. */
    readonly bitrate: Bitrate;
    /** The maximum bitrate. */
    readonly maxBitrate: Bitrate;
}
/** Properties for QVBR rate control. */
export interface QvbrRateControlProps {
    /** The maximum bitrate. */
    readonly maxBitrate: Bitrate;
    /**
     * The QVBR quality level (1-10). Leave unset to let MediaLive infer the target quality from the
     * output resolution and max bitrate.
     * @default - MediaLive infers the quality level from the resolution and max bitrate
     */
    readonly qvbrQualityLevel?: number;
}
/**
 * H.264 rate control. Use the static factory methods to create.
 */
export declare class H264RateControl {
    /** Constant bitrate. */
    static cbr(props: CbrRateControlProps): H264RateControl;
    /** Variable bitrate. */
    static vbr(props: VbrRateControlProps): H264RateControl;
    /** Quality-defined variable bitrate. */
    static qvbr(props: QvbrRateControlProps): H264RateControl;
    private constructor();
}
/**
 * H.265 rate control. Use the static factory methods to create.
 */
export declare class H265RateControl {
    /** Constant bitrate. */
    static cbr(props: CbrRateControlProps): H265RateControl;
    /** Variable bitrate. */
    static vbr(props: VbrRateControlProps): H265RateControl;
    /** Quality-defined variable bitrate. */
    static qvbr(props: QvbrRateControlProps): H265RateControl;
    private constructor();
}
/**
 * AV1 rate control. AV1 supports QVBR and CBR.
 */
export declare class Av1RateControl {
    /** Quality-defined variable bitrate. */
    static qvbr(props: QvbrRateControlProps): Av1RateControl;
    /** Constant bitrate. */
    static cbr(props: CbrRateControlProps): Av1RateControl;
    private constructor();
}
/**
 * Color space settings for H.264 video.
 */
export declare class H264ColorSpaceSettings {
    /** Pass through the source color space with no conversion. */
    static passthrough(): H264ColorSpaceSettings;
    /** Convert to Rec.601 color space. */
    static rec601(): H264ColorSpaceSettings;
    /** Convert to Rec.709 color space. */
    static rec709(): H264ColorSpaceSettings;
    private readonly config;
    private constructor();
}
/**
 * Properties for HDR10 color space settings.
 */
export interface Hdr10SettingsProps {
    /**
     * Maximum Content Light Level — the maximum light level of any single pixel in nits.
     * @default - service default
     */
    readonly maxCll?: number;
    /**
     * Maximum Frame Average Light Level — the maximum average light level of any single frame in nits.
     * @default - service default
     */
    readonly maxFall?: number;
}
/**
 * Color space settings for H.265 video.
 */
export declare class H265ColorSpaceSettings {
    /** Pass through the source color space with no conversion. */
    static passthrough(): H265ColorSpaceSettings;
    /** Dolby Vision 8.1 color space. */
    static dolbyVision81(): H265ColorSpaceSettings;
    /** HDR10 color space. */
    static hdr10(props?: Hdr10SettingsProps): H265ColorSpaceSettings;
    /** HLG 2020 color space. */
    static hlg2020(): H265ColorSpaceSettings;
    /** Convert to Rec.601 color space. */
    static rec601(): H265ColorSpaceSettings;
    /** Convert to Rec.709 color space. */
    static rec709(): H265ColorSpaceSettings;
    private readonly config;
    private constructor();
}
/**
 * Color space settings for AV1 video.
 */
export declare class Av1ColorSpaceSettings {
    /** Pass through the source color space with no conversion. */
    static passthrough(): Av1ColorSpaceSettings;
    /** HDR10 color space. */
    static hdr10(props?: Hdr10SettingsProps): Av1ColorSpaceSettings;
    /** HLG 2020 color space. */
    static hlg2020(): Av1ColorSpaceSettings;
    /** Convert to Rec.601 color space. */
    static rec601(): Av1ColorSpaceSettings;
    /** Convert to Rec.709 color space. */
    static rec709(): Av1ColorSpaceSettings;
    private readonly config;
    private constructor();
}
/**
 * Post-filter sharpening for temporal filter.
 */
export declare class TemporalFilterPostFilterSharpening {
    /** Auto */
    static readonly AUTO: TemporalFilterPostFilterSharpening;
    /** Disabled */
    static readonly DISABLED: TemporalFilterPostFilterSharpening;
    /** Enabled */
    static readonly ENABLED: TemporalFilterPostFilterSharpening;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): TemporalFilterPostFilterSharpening;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Temporal filter strength.
 */
export declare class TemporalFilterStrength {
    /** Auto */
    static readonly AUTO: TemporalFilterStrength;
    /** Strength 1 (recommended) */
    static readonly STRENGTH_1: TemporalFilterStrength;
    /** Strength 2 (recommended) */
    static readonly STRENGTH_2: TemporalFilterStrength;
    /** Strength 3 */
    static readonly STRENGTH_3: TemporalFilterStrength;
    /** Strength 4 */
    static readonly STRENGTH_4: TemporalFilterStrength;
    /** Strength 5 */
    static readonly STRENGTH_5: TemporalFilterStrength;
    /** Strength 6 */
    static readonly STRENGTH_6: TemporalFilterStrength;
    /** Strength 7 */
    static readonly STRENGTH_7: TemporalFilterStrength;
    /** Strength 8 */
    static readonly STRENGTH_8: TemporalFilterStrength;
    /** Strength 9 */
    static readonly STRENGTH_9: TemporalFilterStrength;
    /** Strength 10 */
    static readonly STRENGTH_10: TemporalFilterStrength;
    /** Strength 11 */
    static readonly STRENGTH_11: TemporalFilterStrength;
    /** Strength 12 */
    static readonly STRENGTH_12: TemporalFilterStrength;
    /** Strength 13 */
    static readonly STRENGTH_13: TemporalFilterStrength;
    /** Strength 14 */
    static readonly STRENGTH_14: TemporalFilterStrength;
    /** Strength 15 */
    static readonly STRENGTH_15: TemporalFilterStrength;
    /** Strength 16 */
    static readonly STRENGTH_16: TemporalFilterStrength;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): TemporalFilterStrength;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Post-filter sharpening for bandwidth reduction filter.
 */
export declare class BandwidthReductionPostFilterSharpening {
    /** Disabled */
    static readonly DISABLED: BandwidthReductionPostFilterSharpening;
    /** Sharpening level 1 */
    static readonly SHARPENING_1: BandwidthReductionPostFilterSharpening;
    /** Sharpening level 2 */
    static readonly SHARPENING_2: BandwidthReductionPostFilterSharpening;
    /** Sharpening level 3 */
    static readonly SHARPENING_3: BandwidthReductionPostFilterSharpening;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): BandwidthReductionPostFilterSharpening;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Bandwidth reduction filter strength.
 */
export declare class BandwidthReductionStrength {
    /** Auto */
    static readonly AUTO: BandwidthReductionStrength;
    /** Strength 1 */
    static readonly STRENGTH_1: BandwidthReductionStrength;
    /** Strength 2 */
    static readonly STRENGTH_2: BandwidthReductionStrength;
    /** Strength 3 */
    static readonly STRENGTH_3: BandwidthReductionStrength;
    /** Strength 4 */
    static readonly STRENGTH_4: BandwidthReductionStrength;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): BandwidthReductionStrength;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Properties for a temporal filter.
 */
export interface TemporalFilterProps {
    /**
     * Post-filter sharpening control.
     *
     * @default - service default
     */
    readonly postFilterSharpening?: TemporalFilterPostFilterSharpening;
    /**
     * Filter strength. We recommend 1 or 2. Higher values may remove useful detail.
     *
     * @default - service default
     */
    readonly strength?: TemporalFilterStrength;
}
/**
 * Properties for a bandwidth reduction filter.
 */
export interface BandwidthReductionFilterProps {
    /**
     * Post-filter sharpening control.
     *
     * @default - service default
     */
    readonly postFilterSharpening?: BandwidthReductionPostFilterSharpening;
    /**
     * Bandwidth reduction strength.
     *
     * @default - service default
     */
    readonly strength?: BandwidthReductionStrength;
}
/**
 * Filter settings for H.264 video. Supports temporal filter and bandwidth reduction filter.
 */
export declare class H264FilterSettings {
    /** Apply a temporal filter. */
    static temporalFilter(props?: TemporalFilterProps): H264FilterSettings;
    /** Apply a bandwidth reduction filter. */
    static bandwidthReductionFilter(props?: BandwidthReductionFilterProps): H264FilterSettings;
    private readonly config;
    private constructor();
}
/**
 * Filter settings for H.265 video. Supports temporal filter and bandwidth reduction filter.
 */
export declare class H265FilterSettings {
    /** Apply a temporal filter. */
    static temporalFilter(props?: TemporalFilterProps): H265FilterSettings;
    /** Apply a bandwidth reduction filter. */
    static bandwidthReductionFilter(props?: BandwidthReductionFilterProps): H265FilterSettings;
    private readonly config;
    private constructor();
}
/**
 * Properties for H.264 codec settings.
 */
export interface H264SettingsProps {
    /**
     * The rate control configuration.
     * @default - CBR with no bitrate (service default)
     */
    readonly rateControl?: H264RateControl;
    /**
     * The H.264 profile.
     * @default H264Profile.MAIN
     */
    readonly profile?: H264Profile;
    /**
     * The GOP size (keyframe interval).
     * @default GopSize.seconds(1)
     */
    readonly gopSize?: GopSize;
    /**
     * The number of B-frames between reference frames.
     * @default - service default
     */
    readonly gopNumBFrames?: number;
    /**
     * The adaptive quantization. This allows intra-frame quantizers to vary to improve visual quality.
     * @default H264AdaptiveQuantization.AUTO
     */
    readonly adaptiveQuantization?: H264AdaptiveQuantization;
    /**
     * The video frame rate.
     * @default - follow source
     */
    readonly framerate?: Framerate;
    /**
     * The pixel aspect ratio (PAR) of the video.
     * @default - follow source (or square pixels when framerate is specified)
     */
    readonly pixelAspectRatio?: PixelAspectRatio;
    /**
     * Timecode burn-in settings to overlay timecode on the video.
     * @default - no timecode burn-in
     */
    readonly timecodeBurnin?: TimecodeBurninSettings;
    /**
     * Indicates that AFD values will be written into the output stream. If afdSignaling is auto, the
     * system tries to preserve the input AFD value (in cases where multiple AFD values are valid). If
     * set to fixed, the AFD value is the value configured in the fixedAfd parameter.
     * @default AfdSignaling.NONE
     */
    readonly afdSignaling?: AfdSignaling;
    /**
     * Percentage of the buffer that should initially be filled (HRD buffer model).
     * @default - service default
     */
    readonly bufFillPct?: number;
    /**
     * Size of the buffer (HRD buffer model) in bits/second.
     * @default - service default
     */
    readonly bufSize?: number;
    /**
     * Whether to include color space metadata in the output.
     * @default - service default
     */
    readonly colorMetadata?: ColorMetadata;
    /**
     * Color space settings for the video.
     *
     * @default - service default
     */
    readonly colorSpaceSettings?: H264ColorSpaceSettings;
    /**
     * The entropy encoding mode. CABAC requires Main or High profile.
     * @default - service default
     */
    readonly entropyEncoding?: H264EntropyEncoding;
    /**
     * Optional video filter settings.
     *
     * @default - service default
     */
    readonly filterSettings?: H264FilterSettings;
    /**
     * Four-bit AFD value to write on all frames. Only valid when afdSignaling is FIXED.
     *
     * Valid values: FIXED_0000, FIXED_0010, FIXED_0011, FIXED_0100, FIXED_1000,
     * FIXED_1001, FIXED_1010, FIXED_1011, FIXED_1100, FIXED_1101, FIXED_1110, FIXED_1111.
     *
     * @default - service default
     */
    readonly fixedAfd?: string;
    /**
     * If enabled, adjusts quantization within each frame to reduce flicker on I-frames.
     * @default FlickerAq.ENABLED
     */
    readonly flickerAq?: FlickerAq;
    /**
     * Controls whether coding is on a field basis or frame basis when scan type is interlaced.
     * @default - service default
     */
    readonly forceFieldPictures?: H264ForceFieldPictures;
    /**
     * If enabled, uses reference B frames for GOP structures that have B frames > 1.
     * @default - service default
     */
    readonly gopBReference?: GopBReference;
    /**
     * Frequency of closed GOPs. Set to 1 for streaming so decoders joining mid-stream get an IDR frame quickly.
     * @default - service default
     */
    readonly gopClosedCadence?: number;
    /**
     * The H.264 level.
     *
     * Valid values: H264_LEVEL_1, H264_LEVEL_1_1, H264_LEVEL_1_2, H264_LEVEL_1_3,
     * H264_LEVEL_2, H264_LEVEL_2_1, H264_LEVEL_2_2, H264_LEVEL_3, H264_LEVEL_3_1,
     * H264_LEVEL_3_2, H264_LEVEL_4, H264_LEVEL_4_1, H264_LEVEL_4_2, H264_LEVEL_5,
     * H264_LEVEL_5_1, H264_LEVEL_5_2, H264_LEVEL_AUTO.
     *
     * @default H264Level.H264_LEVEL_AUTO
     */
    readonly level?: H264Level;
    /**
     * Amount of lookahead. Low decreases latency/memory; high can produce better quality.
     * @default LookAheadRateControl.HIGH
     */
    readonly lookAheadRateControl?: LookAheadRateControl;
    /**
     * Only meaningful if sceneChangeDetect is enabled. Enforces separation between
     * repeated (cadence) I-frames and I-frames inserted by scene change detection.
     * @default - service default
     */
    readonly minIInterval?: number;
    /**
     * The number of reference frames to use. The encoder might use more if B-frames or interlaced encoding is used.
     * @default - service default
     */
    readonly numRefFrames?: number;
    /**
     * Sets the scan type of the output.
     * @default ScanType.PROGRESSIVE
     */
    readonly scanType?: ScanType;
    /**
     * Number of slices per picture. Must be <= macroblock rows (progressive) or half (interlaced).
     * @default - encoder chooses based on resolution
     */
    readonly slices?: number;
    /**
     * Softness. Selects a quantizer matrix; larger values reduce high-frequency content.
     * @default - service default
     */
    readonly softness?: number;
    /**
     * Produces a bitstream compliant with SMPTE RP-2027.
     * @default H264Syntax.DEFAULT
     */
    readonly syntax?: H264Syntax;
    /**
     * Determines how timecodes are inserted into the video elementary stream.
     * This controls insertion into the output elementary stream. The channel's `timecodeConfig` controls the
     * source of the timecode used for output.
     * @default - service default
     */
    readonly timecodeInsertion?: TimecodeInsertion;
    /**
     * Minimum QP value. Sets a floor on the quantization parameter.
     * @default - service default
     */
    readonly minQp?: number;
    /**
     * Minimum bitrate in bits/second.
     * @default - service default
     */
    readonly minBitrate?: number;
    /**
     * Quality level. ENHANCED_QUALITY produces slightly better video without increasing bitrate.
     * @default - service default
     */
    readonly qualityLevel?: H264QualityLevel;
    /**
     * Whether scene change detection inserts I-frames on scene changes.
     * @default H264SceneChangeDetect.ENABLED
     */
    readonly sceneChangeDetect?: H264SceneChangeDetect;
    /**
     * Whether spatial adaptive quantization adjusts quantization within each frame based on spatial variation.
     * @default H264SpatialAq.ENABLED
     */
    readonly spatialAq?: H264SpatialAq;
    /**
     * Whether temporal adaptive quantization adjusts quantization based on temporal variation between frames.
     * @default H264TemporalAq.ENABLED
     */
    readonly temporalAq?: H264TemporalAq;
    /**
     * Sub-GOP length mode.
     * @default - service default
     */
    readonly subgopLength?: SubgopLength;
}
/**
 * H.265 profile.
 */
export declare class H265Profile {
    /** Main profile */
    static readonly MAIN: H265Profile;
    /** Main 10-bit profile */
    static readonly MAIN_10BIT: H265Profile;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H265Profile;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * H.265 tier.
 */
export declare class H265Tier {
    /** Main tier */
    static readonly MAIN: H265Tier;
    /** High tier */
    static readonly HIGH: H265Tier;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H265Tier;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Properties for H.265 codec settings.
 */
export interface H265SettingsProps {
    /**
     * The rate control configuration.
     * @default - CBR with no bitrate (service default)
     */
    readonly rateControl?: H265RateControl;
    /**
     * The H.265 profile.
     * @default H265Profile.MAIN
     */
    readonly profile?: H265Profile;
    /**
     * The H.265 tier.
     * @default H265Tier.MAIN
     */
    readonly tier?: H265Tier;
    /**
     * The GOP size (keyframe interval).
     * @default GopSize.seconds(1)
     */
    readonly gopSize?: GopSize;
    /**
     * The video frame rate. Required for H.265.
     */
    readonly framerate: Framerate;
    /**
     * The pixel aspect ratio (PAR) of the video.
     * @default - square pixels
     */
    readonly pixelAspectRatio?: PixelAspectRatio;
    /**
     * Timecode burn-in settings to overlay timecode on the video.
     * @default - no timecode burn-in
     */
    readonly timecodeBurnin?: TimecodeBurninSettings;
    /**
     * The adaptive quantization. Allows intra-frame quantizers to vary to improve visual quality.
     * @default H265AdaptiveQuantization.AUTO
     */
    readonly adaptiveQuantization?: H265AdaptiveQuantization;
    /**
     * AFD signaling mode.
     * @default AfdSignaling.NONE
     */
    readonly afdSignaling?: AfdSignaling;
    /**
     * Whether to insert an Alternative Transfer Function SEI message for backwards compatibility with non-HDR decoders.
     * @default - service default
     */
    readonly alternativeTransferFunction?: H265AlternativeTransferFunction;
    /**
     * Size of buffer (HRD buffer model) in bits.
     * @default - service default
     */
    readonly bufSize?: number;
    /**
     * Whether to include color space metadata in the output.
     * @default - service default
     */
    readonly colorMetadata?: ColorMetadata;
    /**
     * Color space settings for the video.
     *
     * @default - service default
     */
    readonly colorSpaceSettings?: H265ColorSpaceSettings;
    /**
     * Deblocking filter control.
     * @default - service default
     */
    readonly deblocking?: H265Deblocking;
    /**
     * Optional video filter settings.
     *
     * @default - service default
     */
    readonly filterSettings?: H265FilterSettings;
    /**
     * Four-bit AFD value to write on all frames. Only valid when afdSignaling is FIXED.
     *
     * Valid values: FIXED_0000, FIXED_0010, FIXED_0011, FIXED_0100, FIXED_1000,
     * FIXED_1001, FIXED_1010, FIXED_1011, FIXED_1100, FIXED_1101, FIXED_1110, FIXED_1111.
     *
     * @default - service default
     */
    readonly fixedAfd?: string;
    /**
     * If enabled, adjusts quantization within each frame to reduce flicker on I-frames.
     * @default - service default
     */
    readonly flickerAq?: FlickerAq;
    /**
     * If enabled, uses reference B frames for GOP structures that have B frames > 1.
     * @default - service default
     */
    readonly gopBReference?: GopBReference;
    /**
     * Frequency of closed GOPs. Set to 1 for streaming so decoders joining mid-stream get an IDR frame quickly.
     * @default - service default
     */
    readonly gopClosedCadence?: number;
    /**
     * Number of B-frames between reference frames.
     * @default - service default
     */
    readonly gopNumBFrames?: number;
    /**
     * The H.265 level.
     *
     * Valid values: H265_LEVEL_1, H265_LEVEL_2, H265_LEVEL_2_1, H265_LEVEL_3,
     * H265_LEVEL_3_1, H265_LEVEL_4, H265_LEVEL_4_1, H265_LEVEL_5, H265_LEVEL_5_1,
     * H265_LEVEL_5_2, H265_LEVEL_6, H265_LEVEL_6_1, H265_LEVEL_6_2, H265_LEVEL_AUTO.
     *
     * @default - service default (auto)
     */
    readonly level?: H265Level;
    /**
     * Amount of lookahead. Low decreases latency/memory; high can produce better quality.
     * @default - service default
     */
    readonly lookAheadRateControl?: LookAheadRateControl;
    /**
     * Only meaningful if sceneChangeDetect is enabled. Enforces separation between
     * repeated (cadence) I-frames and I-frames inserted by scene change detection.
     * @default - service default
     */
    readonly minIInterval?: number;
    /**
     * Sets the scan type of the output.
     * @default ScanType.PROGRESSIVE
     */
    readonly scanType?: ScanType;
    /**
     * Number of slices per picture.
     * @default - encoder chooses based on resolution
     */
    readonly slices?: number;
    /**
     * Determines how timecodes are inserted into the video elementary stream.
     * This controls insertion into the output elementary stream. The channel's `timecodeConfig` controls the
     * source of the timecode used for output.
     * @default - service default
     */
    readonly timecodeInsertion?: TimecodeInsertion;
    /**
     * Minimum QP value.
     * @default - service default
     */
    readonly minQp?: number;
    /**
     * Minimum bitrate in bits/second.
     * @default - service default
     */
    readonly minBitrate?: number;
    /**
     * Whether motion vectors can cross picture boundaries.
     * @default - service default
     */
    readonly mvOverPictureBoundaries?: H265MvOverPictureBoundaries;
    /**
     * Whether to use temporal motion vector prediction.
     * @default - service default
     */
    readonly mvTemporalPredictor?: H265MvTemporalPredictor;
    /**
     * Sub-GOP length mode.
     * @default - service default
     */
    readonly subgopLength?: SubgopLength;
    /**
     * Tile height in pixels. Must be a multiple of the CTU size.
     * @default - service default
     */
    readonly tileHeight?: number;
    /**
     * Tile padding mode.
     * @default - service default
     */
    readonly tilePadding?: H265TilePadding;
    /**
     * Tile width in pixels. Must be a multiple of the CTU size.
     * @default - service default
     */
    readonly tileWidth?: number;
    /**
     * Treeblock size for the encoder.
     * @default - service default
     */
    readonly treeblockSize?: H265TreeblockSize;
    /**
     * Whether scene change detection inserts I-frames on scene changes.
     * @default H265SceneChangeDetect.ENABLED
     */
    readonly sceneChangeDetect?: H265SceneChangeDetect;
}
/**
 * Properties for AV1 codec settings.
 */
export interface Av1SettingsProps {
    /**
     * The rate control configuration.
     * @default - service default
     */
    readonly rateControl?: Av1RateControl;
    /**
     * The GOP size (keyframe interval).
     * @default GopSize.seconds(1)
     */
    readonly gopSize?: GopSize;
    /**
     * The video frame rate.
     * @default - follow source
     */
    readonly framerate?: Framerate;
    /**
     * Timecode burn-in settings to overlay timecode on the video.
     * @default - no timecode burn-in
     */
    readonly timecodeBurnin?: TimecodeBurninSettings;
    /**
     * AFD signaling mode.
     * @default AfdSignaling.NONE
     */
    readonly afdSignaling?: AfdSignaling;
    /**
     * Bit depth for the AV1 encode.
     * @default - service default
     */
    readonly bitDepth?: Av1BitDepth;
    /**
     * Size of buffer (HRD buffer model) in bits.
     * @default - service default
     */
    readonly bufSize?: number;
    /**
     * Color space settings for the video.
     *
     * @default - service default
     */
    readonly colorSpaceSettings?: Av1ColorSpaceSettings;
    /**
     * Four-bit AFD value to write on all frames. Only valid when afdSignaling is FIXED.
     *
     * Valid values: FIXED_0000, FIXED_0010, FIXED_0011, FIXED_0100, FIXED_1000,
     * FIXED_1001, FIXED_1010, FIXED_1011, FIXED_1100, FIXED_1101, FIXED_1110, FIXED_1111.
     *
     * @default - service default
     */
    readonly fixedAfd?: string;
    /**
     * The AV1 level.
     *
     * Valid values: AV1_LEVEL_2, AV1_LEVEL_2_1, AV1_LEVEL_3, AV1_LEVEL_3_1,
     * AV1_LEVEL_4, AV1_LEVEL_4_1, AV1_LEVEL_5, AV1_LEVEL_5_1, AV1_LEVEL_5_2,
     * AV1_LEVEL_5_3, AV1_LEVEL_6, AV1_LEVEL_6_1, AV1_LEVEL_6_2, AV1_LEVEL_6_3,
     * AV1_LEVEL_AUTO.
     *
     * @default Av1Level.AV1_LEVEL_AUTO
     */
    readonly level?: Av1Level;
    /**
     * Amount of lookahead. Low decreases latency/memory; high can produce better quality.
     * @default LookAheadRateControl.HIGH
     */
    readonly lookAheadRateControl?: LookAheadRateControl;
    /**
     * Minimum bitrate in bits/second.
     * @default - service default
     */
    readonly minBitrate?: number;
    /**
     * Only meaningful if sceneChangeDetect is enabled. Enforces separation between
     * repeated (cadence) I-frames and I-frames inserted by scene change detection.
     * @default - service default
     */
    readonly minIInterval?: number;
    /**
     * The pixel aspect ratio (PAR) of the video.
     * @default - service default
     */
    readonly pixelAspectRatio?: PixelAspectRatio;
    /**
     * Scene change detection.
     * @default Av1SceneChangeDetect.ENABLED
     */
    readonly sceneChangeDetect?: Av1SceneChangeDetect;
    /**
     * Spatial adaptive quantization.
     * @default Av1SpatialAq.ENABLED
     */
    readonly spatialAq?: Av1SpatialAq;
    /**
     * Temporal adaptive quantization.
     * @default Av1TemporalAq.ENABLED
     */
    readonly temporalAq?: Av1TemporalAq;
    /**
     * Timecode insertion mode.
     * @default - service default
     */
    readonly timecodeInsertion?: Av1TimecodeInsertion;
}
/**
 * Properties for frame capture codec settings.
 */
export interface FrameCaptureSettingsProps {
    /**
     * The interval between frame captures.
     * @default - service default
     */
    readonly captureInterval?: Duration;
    /**
     * Timecode burn-in settings to overlay timecode on the video.
     * @default - no timecode burn-in
     */
    readonly timecodeBurnin?: TimecodeBurninSettings;
}
/**
 * Video codec settings. Use the static factory methods to create.
 */
export declare abstract class VideoCodecSettings {
    /** Create H.264 (AVC) codec settings. */
    static h264(props?: H264SettingsProps): VideoCodecSettings;
    /** Create H.265 (HEVC) codec settings. Framerate is required for H.265. */
    static h265(props: H265SettingsProps): VideoCodecSettings;
    /** Create AV1 codec settings. */
    static av1(props?: Av1SettingsProps): VideoCodecSettings;
    /** Create frame capture codec settings. */
    static frameCapture(props?: FrameCaptureSettingsProps): VideoCodecSettings;
}
