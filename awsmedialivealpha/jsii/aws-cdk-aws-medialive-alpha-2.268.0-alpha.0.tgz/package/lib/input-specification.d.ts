/**
 * The codec for the input specification.
 */
export declare class InputCodec {
    /** AVC (H.264) */
    static readonly AVC: InputCodec;
    /** HEVC (H.265) */
    static readonly HEVC: InputCodec;
    /** MPEG2 */
    static readonly MPEG2: InputCodec;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): InputCodec;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * The maximum input bitrate for the input specification.
 */
export declare class InputMaximumBitrate {
    /** Max 10 Mbps */
    static readonly MAX_10_MBPS: InputMaximumBitrate;
    /** Max 20 Mbps */
    static readonly MAX_20_MBPS: InputMaximumBitrate;
    /** Max 50 Mbps */
    static readonly MAX_50_MBPS: InputMaximumBitrate;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): InputMaximumBitrate;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * The resolution for the input specification.
 */
export declare class InputResolution {
    /** SD */
    static readonly SD: InputResolution;
    /** HD */
    static readonly HD: InputResolution;
    /** UHD */
    static readonly UHD: InputResolution;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): InputResolution;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Maximum CDI input resolution.
 */
export declare class CdiInputResolution {
    /** SD resolution */
    static readonly SD: CdiInputResolution;
    /** HD resolution */
    static readonly HD: CdiInputResolution;
    /** Full HD resolution */
    static readonly FHD: CdiInputResolution;
    /** UHD resolution */
    static readonly UHD: CdiInputResolution;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): CdiInputResolution;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Properties shared by all input specifications.
 */
export interface StandardInputSpecificationProps {
    /**
     * The codec of the input.
     * This should match the codec of your source content, not the output codec.
     * @default InputCodec.AVC
     */
    readonly codec?: InputCodec;
    /**
     * The maximum bitrate of the input.
     * @default InputMaximumBitrate.MAX_20_MBPS
     */
    readonly maximumBitrate?: InputMaximumBitrate;
    /**
     * The resolution of the input.
     * @default InputResolution.HD
     */
    readonly resolution?: InputResolution;
}
/**
 * Properties for a CDI input specification.
 */
export interface CdiInputSpecificationProps extends StandardInputSpecificationProps {
    /**
     * The maximum resolution of the most demanding CDI input.
     * @default CdiInputResolution.HD
     */
    readonly cdiResolution?: CdiInputResolution;
}
/**
 * The input specification for a channel.
 *
 * Use the static factory methods to select the input type — mirroring the console's
 * "Other" / "CDI" / "Elemental Link" choice.
 */
export declare abstract class InputSpecification {
    /** Standard inputs ("Other" in the console) — the most common case. */
    static standard(props?: StandardInputSpecificationProps): InputSpecification;
    /** CDI (uncompressed) inputs. Adds the maximum CDI input resolution. */
    static cdi(props?: CdiInputSpecificationProps): InputSpecification;
    /** Elemental Link inputs. No additional specification is required. */
    static elementalLink(): InputSpecification;
}
