/** HLS output mode. */
export declare class HlsMode {
    /** Live mode — older segments are removed */
    static readonly LIVE: HlsMode;
    /** VOD mode — all segments are kept */
    static readonly VOD: HlsMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS input loss action. */
export declare class HlsInputLossAction {
    /** Emit output with slate/black frames */
    static readonly EMIT_OUTPUT: HlsInputLossAction;
    /** Pause the output */
    static readonly PAUSE_OUTPUT: HlsInputLossAction;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsInputLossAction;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS client cache control. */
export declare class HlsClientCache {
    /** Enable client caching */
    static readonly ENABLED: HlsClientCache;
    /** Disable client caching */
    static readonly DISABLED: HlsClientCache;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsClientCache;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS codec specification. */
export declare class HlsCodecSpecification {
    /** RFC 4281 */
    static readonly RFC_4281: HlsCodecSpecification;
    /** RFC 6381 */
    static readonly RFC_6381: HlsCodecSpecification;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsCodecSpecification;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS directory structure. */
export declare class HlsDirectoryStructure {
    /** Single directory */
    static readonly SINGLE_DIRECTORY: HlsDirectoryStructure;
    /** Subdirectory per stream */
    static readonly SUBDIRECTORY_PER_STREAM: HlsDirectoryStructure;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsDirectoryStructure;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS discontinuity tags. */
export declare class HlsDiscontinuityTags {
    /** Insert discontinuity tags */
    static readonly INSERT: HlsDiscontinuityTags;
    /** Never insert discontinuity tags */
    static readonly NEVER_INSERT: HlsDiscontinuityTags;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsDiscontinuityTags;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS encryption type. */
export declare class HlsEncryptionType {
    /** AES-128 encryption */
    static readonly AES128: HlsEncryptionType;
    /** Sample AES encryption */
    static readonly SAMPLE_AES: HlsEncryptionType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsEncryptionType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS ID3 segment tagging state. */
export declare class HlsId3SegmentTaggingState {
    /** Disabled */
    static readonly DISABLED: HlsId3SegmentTaggingState;
    /** Enabled */
    static readonly ENABLED: HlsId3SegmentTaggingState;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsId3SegmentTaggingState;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS I-frame only playlists. */
export declare class HlsIFrameOnlyPlaylists {
    /** Disabled */
    static readonly DISABLED: HlsIFrameOnlyPlaylists;
    /** Standard */
    static readonly STANDARD: HlsIFrameOnlyPlaylists;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsIFrameOnlyPlaylists;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS incomplete segment behavior. */
export declare class HlsIncompleteSegmentBehavior {
    /** Auto */
    static readonly AUTO: HlsIncompleteSegmentBehavior;
    /** Suppress */
    static readonly SUPPRESS: HlsIncompleteSegmentBehavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsIncompleteSegmentBehavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS IV in manifest. */
export declare class HlsIvInManifest {
    /** Include IV in manifest */
    static readonly INCLUDE: HlsIvInManifest;
    /** Exclude IV from manifest */
    static readonly EXCLUDE: HlsIvInManifest;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsIvInManifest;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS IV source. */
export declare class HlsIvSource {
    /** IV follows segment number */
    static readonly FOLLOWS_SEGMENT_NUMBER: HlsIvSource;
    /** Explicit IV */
    static readonly EXPLICIT: HlsIvSource;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsIvSource;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS manifest compression. */
export declare class HlsManifestCompression {
    /** No compression */
    static readonly NONE: HlsManifestCompression;
    /** Gzip compression */
    static readonly GZIP: HlsManifestCompression;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsManifestCompression;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS manifest duration format. */
export declare class HlsManifestDurationFormat {
    /** Floating point */
    static readonly FLOATING_POINT: HlsManifestDurationFormat;
    /** Integer */
    static readonly INTEGER: HlsManifestDurationFormat;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsManifestDurationFormat;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS output selection. */
export declare class HlsOutputSelection {
    /** Manifests and segments */
    static readonly MANIFESTS_AND_SEGMENTS: HlsOutputSelection;
    /** Segments only */
    static readonly SEGMENTS_ONLY: HlsOutputSelection;
    /** Variant manifests and segments */
    static readonly VARIANT_MANIFESTS_AND_SEGMENTS: HlsOutputSelection;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsOutputSelection;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS program date time. */
export declare class HlsProgramDateTime {
    /** Include */
    static readonly INCLUDE: HlsProgramDateTime;
    /** Exclude */
    static readonly EXCLUDE: HlsProgramDateTime;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsProgramDateTime;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS program date time clock. */
export declare class HlsProgramDateTimeClock {
    /** Initialize from output timecode */
    static readonly INITIALIZE_FROM_OUTPUT_TIMECODE: HlsProgramDateTimeClock;
    /** System clock */
    static readonly SYSTEM_CLOCK: HlsProgramDateTimeClock;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsProgramDateTimeClock;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS redundant manifest. */
export declare class HlsRedundantManifest {
    /** Disabled */
    static readonly DISABLED: HlsRedundantManifest;
    /** Enabled */
    static readonly ENABLED: HlsRedundantManifest;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsRedundantManifest;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS segmentation mode. */
export declare class HlsSegmentationMode {
    /** Use input segmentation */
    static readonly USE_INPUT_SEGMENTATION: HlsSegmentationMode;
    /** Use segment duration */
    static readonly USE_SEGMENT_DURATION: HlsSegmentationMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsSegmentationMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS stream inf resolution. */
export declare class HlsStreamInfResolution {
    /** Include */
    static readonly INCLUDE: HlsStreamInfResolution;
    /** Exclude */
    static readonly EXCLUDE: HlsStreamInfResolution;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsStreamInfResolution;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS caption language setting. */
export declare class HlsCaptionLanguageSetting {
    /** Insert */
    static readonly INSERT: HlsCaptionLanguageSetting;
    /** None */
    static readonly NONE: HlsCaptionLanguageSetting;
    /** Omit */
    static readonly OMIT: HlsCaptionLanguageSetting;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsCaptionLanguageSetting;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Whether MediaPackage sets a MediaPackage V2 audio rendition as default / auto-select in the HLS
 * manifest. Across all renditions: at most one may be `YES`; not all may be `NO`.
 */
export declare class MediaPackageV2HlsSetting {
    /** Set this rendition as default / auto-select. */
    static readonly YES: MediaPackageV2HlsSetting;
    /** Do not set this rendition as default / auto-select. */
    static readonly NO: MediaPackageV2HlsSetting;
    /** Let MediaPackage decide for this rendition. */
    static readonly OMIT: MediaPackageV2HlsSetting;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MediaPackageV2HlsSetting;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Ad marker type for an HLS output group. */
export declare class HlsAdMarkers {
    /** Adobe ad markers. */
    static readonly ADOBE: HlsAdMarkers;
    /** Elemental ad markers. */
    static readonly ELEMENTAL: HlsAdMarkers;
    /** Elemental SCTE-35 ad markers. */
    static readonly ELEMENTAL_SCTE35: HlsAdMarkers;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsAdMarkers;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Ad marker type for an RTMP output group. */
export declare class RtmpAdMarkers {
    /** onCuePoint SCTE-35 ad markers. */
    static readonly ON_CUE_POINT_SCTE35: RtmpAdMarkers;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): RtmpAdMarkers;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS timed metadata ID3 frame. */
export declare class HlsTimedMetadataId3Frame {
    /** None */
    static readonly NONE: HlsTimedMetadataId3Frame;
    /** PRIV */
    static readonly PRIV: HlsTimedMetadataId3Frame;
    /** TDRL */
    static readonly TDRL: HlsTimedMetadataId3Frame;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsTimedMetadataId3Frame;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Whether to use chunked transfer encoding for an HLS CDN connection (Akamai, WebDAV). */
export declare class HttpTransferMode {
    /** Use chunked transfer encoding. */
    static readonly CHUNKED: HttpTransferMode;
    /** Do not use chunked transfer encoding. */
    static readonly NON_CHUNKED: HttpTransferMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HttpTransferMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** HLS TS file mode. */
export declare class HlsTsFileMode {
    /** Segmented files */
    static readonly SEGMENTED_FILES: HlsTsFileMode;
    /** Single file */
    static readonly SINGLE_FILE: HlsTsFileMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): HlsTsFileMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** RTMP authentication scheme. */
export declare class RtmpAuthenticationScheme {
    /** Common authentication */
    static readonly COMMON: RtmpAuthenticationScheme;
    /** Akamai authentication */
    static readonly AKAMAI: RtmpAuthenticationScheme;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): RtmpAuthenticationScheme;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** RTMP cache full behavior. */
export declare class RtmpCacheFullBehavior {
    /** Disconnect immediately */
    static readonly DISCONNECT_IMMEDIATELY: RtmpCacheFullBehavior;
    /** Wait for server */
    static readonly WAIT_FOR_SERVER: RtmpCacheFullBehavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): RtmpCacheFullBehavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** RTMP caption data. */
export declare class RtmpCaptionData {
    /** All */
    static readonly ALL: RtmpCaptionData;
    /** Field 1 and field 2 608 */
    static readonly FIELD1_AND_FIELD2_608: RtmpCaptionData;
    /** Field 1 608 */
    static readonly FIELD1_608: RtmpCaptionData;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): RtmpCaptionData;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** RTMP input loss action. */
export declare class RtmpInputLossAction {
    /** Emit output */
    static readonly EMIT_OUTPUT: RtmpInputLossAction;
    /** Pause output */
    static readonly PAUSE_OUTPUT: RtmpInputLossAction;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): RtmpInputLossAction;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** RTMP include filler NAL units. */
export declare class RtmpIncludeFillerNalUnits {
    /** Auto */
    static readonly AUTO: RtmpIncludeFillerNalUnits;
    /** Drop */
    static readonly DROP: RtmpIncludeFillerNalUnits;
    /** Include */
    static readonly INCLUDE: RtmpIncludeFillerNalUnits;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): RtmpIncludeFillerNalUnits;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** RTMP TLS certificate verification mode. */
export declare class RtmpCertificateMode {
    /** Verify the TLS certificate chain */
    static readonly VERIFY_AUTHENTICITY: RtmpCertificateMode;
    /** Do not verify the TLS certificate */
    static readonly SELF_SIGNED: RtmpCertificateMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): RtmpCertificateMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Behavior of last resort when input video is lost and no more backup inputs are available,
 * for an SRT output group.
 */
export declare class SrtInputLossAction {
    /** Drop the entire transport stream. */
    static readonly DROP_TS: SrtInputLossAction;
    /** Drop the program from the transport stream (replaced with null packets to meet bitrate). */
    static readonly DROP_PROGRAM: SrtInputLossAction;
    /** Continue emitting with repeat, black, or slate frames substituted for the absent video. */
    static readonly EMIT_PROGRAM: SrtInputLossAction;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): SrtInputLossAction;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** SRT output encryption type. */
export declare class SrtEncryptionType {
    /** AES-128 encryption */
    static readonly AES128: SrtEncryptionType;
    /** AES-192 encryption */
    static readonly AES192: SrtEncryptionType;
    /** AES-256 encryption */
    static readonly AES256: SrtEncryptionType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): SrtEncryptionType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** UDP input loss action. */
export declare class UdpInputLossAction {
    /** Drop the entire transport stream */
    static readonly DROP_TS: UdpInputLossAction;
    /** Drop the program from the transport stream */
    static readonly DROP_PROGRAM: UdpInputLossAction;
    /** Continue emitting with substitute frames */
    static readonly EMIT_PROGRAM: UdpInputLossAction;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): UdpInputLossAction;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Enables column-only or column-and-row FEC for a UDP output. */
export declare class FecMode {
    /** Column-only FEC. */
    static readonly COLUMN: FecMode;
    /** Column-and-row FEC (more robust). */
    static readonly COLUMN_AND_ROW: FecMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): FecMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** UDP timed metadata ID3 frame. */
export declare class UdpTimedMetadataId3Frame {
    /** None */
    static readonly NONE: UdpTimedMetadataId3Frame;
    /** PRIV */
    static readonly PRIV: UdpTimedMetadataId3Frame;
    /** TDRL */
    static readonly TDRL: UdpTimedMetadataId3Frame;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): UdpTimedMetadataId3Frame;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** MS Smooth audio-only timecode control. */
export declare class MsSmoothAudioOnlyTimecodeControl {
    /** Passthrough */
    static readonly PASSTHROUGH: MsSmoothAudioOnlyTimecodeControl;
    /** Use configured clock */
    static readonly USE_CONFIGURED_CLOCK: MsSmoothAudioOnlyTimecodeControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MsSmoothAudioOnlyTimecodeControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** MS Smooth certificate mode. */
export declare class MsSmoothCertificateMode {
    /** Self-signed */
    static readonly SELF_SIGNED: MsSmoothCertificateMode;
    /** Verify authenticity */
    static readonly VERIFY_AUTHENTICITY: MsSmoothCertificateMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MsSmoothCertificateMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** MS Smooth event ID mode. */
export declare class MsSmoothEventIdMode {
    /** No event ID */
    static readonly NO_EVENT_ID: MsSmoothEventIdMode;
    /** Use configured */
    static readonly USE_CONFIGURED: MsSmoothEventIdMode;
    /** Use timestamp */
    static readonly USE_TIMESTAMP: MsSmoothEventIdMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MsSmoothEventIdMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** MS Smooth event stop behavior. */
export declare class MsSmoothEventStopBehavior {
    /** None */
    static readonly NONE: MsSmoothEventStopBehavior;
    /** Send EOS */
    static readonly SEND_EOS: MsSmoothEventStopBehavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MsSmoothEventStopBehavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** MS Smooth input loss action. */
export declare class MsSmoothInputLossAction {
    /** Emit output */
    static readonly EMIT_OUTPUT: MsSmoothInputLossAction;
    /** Pause output */
    static readonly PAUSE_OUTPUT: MsSmoothInputLossAction;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MsSmoothInputLossAction;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** MS Smooth segmentation mode. */
export declare class MsSmoothSegmentationMode {
    /** Use input segmentation */
    static readonly USE_INPUT_SEGMENTATION: MsSmoothSegmentationMode;
    /** Use segment duration */
    static readonly USE_SEGMENT_DURATION: MsSmoothSegmentationMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MsSmoothSegmentationMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** MS Smooth sparse track type. */
export declare class MsSmoothSparseTrackType {
    /** None */
    static readonly NONE: MsSmoothSparseTrackType;
    /** SCTE-35 */
    static readonly SCTE_35: MsSmoothSparseTrackType;
    /** SCTE-35 without segmentation */
    static readonly SCTE_35_WITHOUT_SEGMENTATION: MsSmoothSparseTrackType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MsSmoothSparseTrackType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** MS Smooth stream manifest behavior. */
export declare class MsSmoothStreamManifestBehavior {
    /** Do not send */
    static readonly DO_NOT_SEND: MsSmoothStreamManifestBehavior;
    /** Send */
    static readonly SEND: MsSmoothStreamManifestBehavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MsSmoothStreamManifestBehavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** MS Smooth timestamp offset mode. */
export declare class MsSmoothTimestampOffsetMode {
    /** Use configured offset */
    static readonly USE_CONFIGURED_OFFSET: MsSmoothTimestampOffsetMode;
    /** Use event start date */
    static readonly USE_EVENT_START_DATE: MsSmoothTimestampOffsetMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): MsSmoothTimestampOffsetMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** ID3 metadata insertion behavior (CMAF Ingest and MediaPackage V2 output groups). */
export declare class Id3Behavior {
    /** Do not insert ID3 metadata. */
    static readonly DISABLED: Id3Behavior;
    /** Enable ID3 metadata insertion. */
    static readonly ENABLED: Id3Behavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Id3Behavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** CMAF Ingest KLV behavior. */
export declare class KlvBehavior {
    /** No passthrough */
    static readonly NO_PASSTHROUGH: KlvBehavior;
    /** Passthrough */
    static readonly PASSTHROUGH: KlvBehavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): KlvBehavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** CMAF Ingest Nielsen ID3 behavior. */
export declare class NielsenId3Behavior {
    /** No passthrough */
    static readonly NO_PASSTHROUGH: NielsenId3Behavior;
    /** Passthrough */
    static readonly PASSTHROUGH: NielsenId3Behavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): NielsenId3Behavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** CMAF Ingest SCTE-35 type. */
export declare class Scte35Type {
    /** None */
    static readonly NONE: Scte35Type;
    /** SCTE-35 without segmentation */
    static readonly SCTE_35_WITHOUT_SEGMENTATION: Scte35Type;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Scte35Type;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** CMAF Ingest timed metadata ID3 frame. */
export declare class TimedMetadataId3Frame {
    /** None */
    static readonly NONE: TimedMetadataId3Frame;
    /** PRIV */
    static readonly PRIV: TimedMetadataId3Frame;
    /** TDRL */
    static readonly TDRL: TimedMetadataId3Frame;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): TimedMetadataId3Frame;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** CMAF Ingest timed metadata passthrough. */
export declare class TimedMetadataPassthrough {
    /** Disabled */
    static readonly DISABLED: TimedMetadataPassthrough;
    /** Enabled */
    static readonly ENABLED: TimedMetadataPassthrough;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): TimedMetadataPassthrough;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * S3 canned ACL for output destinations.
 */
export declare class S3CannedAcl {
    /** Grants the owner full control and authenticated AWS users read access. */
    static readonly AUTHENTICATED_READ: S3CannedAcl;
    /** Grants the object owner and bucket owner full control. */
    static readonly BUCKET_OWNER_FULL_CONTROL: S3CannedAcl;
    /** Grants the owner full control and the bucket owner read access. */
    static readonly BUCKET_OWNER_READ: S3CannedAcl;
    /** Grants the owner full control and all users read access. */
    static readonly PUBLIC_READ: S3CannedAcl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): S3CannedAcl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** H.265 packaging type for HLS/MS Smooth outputs. */
export declare class H265PackagingType {
    /** HEV1 packaging */
    static readonly HEV1: H265PackagingType;
    /** HVC1 packaging */
    static readonly HVC1: H265PackagingType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): H265PackagingType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
