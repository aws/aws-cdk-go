import type { Duration } from 'aws-cdk-lib';
import type { RtmpDestination, SrtDestination } from './destinations';
import type { EncodeConfiguration } from './encode-configuration';
import type { FecMode, H265PackagingType, RtmpCertificateMode, SrtEncryptionType } from './enums';
import { MediaPackageV2HlsSetting } from './enums';
import type { M2tsSettings } from './m2ts-settings';
import { HlsSettings } from './m3u8-settings';
/**
 * Base output definition — shared by all output group types.
 */
export interface OutputDefinition {
    /**
     * The encode configurations to wire to this output.
     */
    readonly encodes: EncodeConfiguration[];
    /**
     * The name of this output. Must be unique across all outputs in the channel.
     */
    readonly outputName: string;
}
/**
 * Represents an output within an output group.
 * Each output group type has its own Output subclass that knows how to render its output settings.
 */
export declare abstract class Output {
    protected readonly outputName: string;
    private readonly encodes;
}
/**
 * Output definition for a MediaPackage V2 output group.
 *
 * MediaPackage V2 uses CMAF ingest which requires one media track (video or audio) per output.
 * In-band captions (burn-in, embedded) can ride alongside the primary encode because they do not
 * produce a separate track.
 */
export interface MediaPackageV2OutputDefinition {
    /**
     * The primary encode for this output — one video or one audio track.
     */
    readonly encode: EncodeConfiguration;
    /**
     * Caption encodes that ride alongside the primary encode. Only in-band caption types are
     * allowed (burn-in, embedded) — out-of-band captions must go in their own output.
     *
     * @default - no captions on this output
     */
    readonly captions?: EncodeConfiguration[];
    /**
     * The name of this output. Must be unique across all outputs in the channel.
     */
    readonly outputName: string;
    /**
     * The audio group ID for audio outputs.
     * @default - service default
     */
    readonly audioGroupId?: string;
    /**
     * For audio outputs, whether MediaPackage sets this rendition as the auto-select rendition in the
     * HLS manifest.
     * @default MediaPackageV2HlsSetting.OMIT
     */
    readonly hlsAutoSelect?: MediaPackageV2HlsSetting;
    /**
     * For audio outputs, whether MediaPackage sets this rendition as the default rendition in the HLS
     * manifest.
     * @default MediaPackageV2HlsSetting.OMIT
     */
    readonly hlsDefault?: MediaPackageV2HlsSetting;
    /**
     * The audio rendition sets for video outputs.
     * @default - service default
     */
    readonly audioRenditionSets?: string;
}
/**
 * Output definition for an HLS output group.
 */
export interface HlsOutputDefinition extends OutputDefinition {
    /**
     * A string concatenated to the end of the destination file name.
     * @default - service default
     */
    readonly nameModifier?: string;
    /**
     * A string concatenated to the end of segment file names.
     * @default - no segment modifier
     */
    readonly segmentModifier?: string;
    /**
     * For H.265 video, whether to package as HEV1 or HVC1.
     * @default - service default
     */
    readonly h265PackagingType?: H265PackagingType;
    /**
     * The per-output HLS settings (standard, audio-only, fMP4, or frame-capture). Use the
     * `HlsSettings` factory methods. Standard outputs additionally configure the M3U8 container
     * via `HlsSettings.standard({ m3u8Settings })`.
     * @default - HlsSettings.standard() with service-default M3U8 settings
     */
    readonly hlsSettings?: HlsSettings;
}
/**
 * Forward Error Correction (FEC) settings for a UDP output (SMPTE 2022-1).
 */
export interface FecOutputSettings {
    /**
     * Whether to enable column-only or column-and-row FEC.
     * @default - service default
     */
    readonly mode?: FecMode;
    /**
     * Parameter D from SMPTE 2022-1 — the height of the FEC protection matrix (number of
     * transport stream packets per column error-correction packet). Must be 4..20.
     * @default - service default
     */
    readonly columnDepth?: number;
    /**
     * Parameter L from SMPTE 2022-1 — the width of the FEC protection matrix. Must be 1..20
     * for column-only FEC, or 4..20 for column-and-row FEC.
     * @default - service default
     */
    readonly rowLength?: number;
}
/**
 * Output definition for a UDP output group.
 */
export interface UdpOutputDefinition extends OutputDefinition {
    /**
     * The output buffering (overrides group-level setting). Applied at millisecond granularity.
     * @default - uses group-level buffer
     */
    readonly buffer?: Duration;
    /**
     * MPEG-TS (M2TS) container settings for this output.
     * @default - service defaults
     */
    readonly m2tsSettings?: M2tsSettings;
    /**
     * Forward Error Correction (FEC) settings for this output.
     * @default - no FEC
     */
    readonly fec?: FecOutputSettings;
}
/**
 * The container (transport stream) for an Archive output. Use the static factory methods to
 * select between an MPEG-TS (M2TS) container or a raw container.
 */
export declare abstract class ArchiveContainer {
    /** An MPEG-TS (M2TS) container, optionally configured via `M2tsSettings`. */
    static m2ts(settings?: M2tsSettings): ArchiveContainer;
    /** A raw container (no transport-stream wrapping). */
    static raw(): ArchiveContainer;
}
/**
 * Output definition for an Archive output group.
 */
export interface ArchiveOutputDefinition extends OutputDefinition {
    /**
     * A string concatenated to the end of the destination file name. Required if the output group
     * contains more than one output of the same container type.
     * @default - no name modifier
     */
    readonly nameModifier?: string;
    /**
     * The output file extension.
     * @default - auto-selected from container type
     */
    readonly extension?: string;
    /**
     * The container (transport stream) for this output — an MPEG-TS (M2TS) or raw container.
     * Use the `ArchiveContainer` factory methods.
     * @default - ArchiveContainer.m2ts() with service-default M2TS settings
     */
    readonly container?: ArchiveContainer;
}
/**
 * Output definition for an RTMP output group.
 * `outputName` is normalised (underscores → hyphens) for use as the destination reference ID.
 */
export interface RtmpOutputDefinition extends OutputDefinition {
    /**
     * The RTMP destination(s) for this output — one per channel pipeline.
     *
     * MediaLive publishes each RTMP output to one destination per pipeline (the console
     * calls these "Destination A" and "Destination B"). Provide a single destination for a
     * `SINGLE_PIPELINE` channel, or two (A then B) for a `STANDARD` channel.
     */
    readonly destinations: RtmpDestination[];
    /**
     * The TLS certificate verification mode.
     * @default - service default
     */
    readonly certificateMode?: RtmpCertificateMode;
    /**
     * The interval between connection retry attempts.
     * @default - service default
     */
    readonly connectionRetryInterval?: Duration;
    /**
     * The number of retry attempts.
     * @default - service default
     */
    readonly numRetries?: number;
}
/**
 * Output definition for an SRT output group.
 * `outputName` is normalised (underscores → hyphens) for use as the destination reference ID.
 */
export interface SrtOutputDefinition extends OutputDefinition {
    /**
     * The SRT destination(s) for this output — one per channel pipeline.
     *
     * MediaLive publishes each SRT output to one destination per pipeline (the console
     * calls these "Destination A" and "Destination B"). Provide a single destination for a
     * `SINGLE_PIPELINE` channel, or two (A then B) for a `STANDARD` channel. Each pipeline
     * can target a different listener and carry its own encryption passphrase.
     */
    readonly destinations: SrtDestination[];
    /**
     * The output buffering. Applied at millisecond granularity.
     * @default - service default
     */
    readonly buffer?: Duration;
    /**
     * The encryption type for the SRT output.
     * @default - no encryption
     */
    readonly encryptionType?: SrtEncryptionType;
    /**
     * The SRT latency.
     * @default - service default
     */
    readonly latency?: Duration;
    /**
     * MPEG-TS (M2TS) container settings for this output.
     * @default - service defaults
     */
    readonly m2tsSettings?: M2tsSettings;
}
/**
 * Output definition for a CMAF Ingest output group.
 *
 * CMAF Ingest requires one media track (video or audio) per output. In-band captions (burn-in,
 * embedded) can ride alongside the primary encode.
 */
export interface CmafIngestOutputDefinition {
    /**
     * The primary encode for this output — one video or one audio track.
     */
    readonly encode: EncodeConfiguration;
    /**
     * Caption encodes that ride alongside the primary encode. Only in-band caption types are
     * allowed (burn-in, embedded) — out-of-band captions must go in their own output.
     *
     * @default - no captions on this output
     */
    readonly captions?: EncodeConfiguration[];
    /**
     * The name of this output. Must be unique across all outputs in the channel.
     */
    readonly outputName: string;
    /**
     * A string concatenated to the end of the destination file name.
     * @default - no name modifier
     */
    readonly nameModifier?: string;
}
/**
 * Output definition for a Frame Capture output group.
 */
export interface FrameCaptureOutputDefinition extends OutputDefinition {
    /**
     * A string concatenated to the end of the destination file name.
     * Required if the output group contains more than one output.
     * @default - no name modifier
     */
    readonly nameModifier?: string;
}
/**
 * Output definition for an MS Smooth output group.
 */
export interface MsSmoothOutputDefinition extends OutputDefinition {
    /**
     * A string concatenated to the end of the destination file name. Required if the output group
     * contains more than one output.
     * @default - no name modifier
     */
    readonly nameModifier?: string;
    /**
     * For H.265 video, whether to package as HEV1 or HVC1.
     * @default - service default
     */
    readonly h265PackagingType?: H265PackagingType;
}
/**
 * Output definition for a MediaConnect Router output group.
 */
export interface MediaConnectRouterOutputDefinition extends OutputDefinition {
    /**
     * MPEG-TS (M2TS) container settings for this output.
     * @default - service defaults
     */
    readonly m2tsSettings?: M2tsSettings;
}
