import type { Duration } from 'aws-cdk-lib';
import type { IStringParameter } from 'aws-cdk-lib/aws-ssm';
import type { FileLocation } from './file-location';
/**
 * Avail blanking state.
 */
export declare class AvailBlankingState {
    /** Enable blanking during ad avails */
    static readonly ENABLED: AvailBlankingState;
    /** Disable blanking during ad avails */
    static readonly DISABLED: AvailBlankingState;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AvailBlankingState;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Settings for blanking video, audio, and captions during ad avails.
 */
export interface AvailBlanking {
    /**
     * Whether to blank the output during ad avails.
     * @default - ENABLED if image is provided, DISABLED otherwise
     */
    readonly state?: AvailBlankingState;
    /**
     * A blanking image to display during ad avails. Provide a `FileLocation` referencing an S3
     * bucket (`FileLocation.fromBucket`, which auto-grants read access) or a URL (`FileLocation.url`).
     * Only .bmp and .png images are supported. If not set, solid black is used.
     * @default - solid black
     */
    readonly image?: FileLocation;
}
/**
 * How to handle SCTE-35 regional blackout and web delivery flags.
 */
export declare class Scte35FlagBehavior {
    /** Follow the flag — trigger blackouts/slates when the flag is set */
    static readonly FOLLOW: Scte35FlagBehavior;
    /** Ignore the flag */
    static readonly IGNORE: Scte35FlagBehavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Scte35FlagBehavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * SCTE-35 splice insert avail settings.
 */
export interface Scte35SpliceInsertSettings {
    /**
     * Offset in milliseconds added to the input ad avail PTS time.
     * Applies only to embedded SCTE 104/35 messages.
     * @default - service default
     */
    readonly adAvailOffset?: number;
    /**
     * When set to `IGNORE`, segment descriptors with `noRegionalBlackoutFlag` set to 0 no longer
     * trigger blackouts or ad avail slates.
     * @default - service default
     */
    readonly noRegionalBlackoutFlag?: Scte35FlagBehavior;
    /**
     * When set to `IGNORE`, segment descriptors with `webDeliveryAllowedFlag` set to 0 no longer
     * trigger blackouts or ad avail slates.
     * @default - service default
     */
    readonly webDeliveryAllowedFlag?: Scte35FlagBehavior;
}
/**
 * SCTE-35 time signal APOS avail settings.
 */
export interface Scte35TimeSignalAposSettings {
    /**
     * Offset in milliseconds added to the input ad avail PTS time.
     * Applies only to embedded SCTE 104/35 messages.
     * @default - service default
     */
    readonly adAvailOffset?: number;
    /**
     * When set to `IGNORE`, segment descriptors with `noRegionalBlackoutFlag` set to 0 no longer
     * trigger blackouts or ad avail slates.
     * @default - service default
     */
    readonly noRegionalBlackoutFlag?: Scte35FlagBehavior;
    /**
     * When set to `IGNORE`, segment descriptors with `webDeliveryAllowedFlag` set to 0 no longer
     * trigger blackouts or ad avail slates.
     * @default - service default
     */
    readonly webDeliveryAllowedFlag?: Scte35FlagBehavior;
}
/**
 * Controls which output groups receive SCTE-35 segmentation cues.
 */
export declare class Scte35SegmentationScope {
    /** Insert segment breaks in all output groups. */
    static readonly ALL_OUTPUT_GROUPS: Scte35SegmentationScope;
    /** Insert segment breaks only in output groups with SCTE-35 passthrough enabled (recommended). */
    static readonly SCTE35_ENABLED_OUTPUT_GROUPS: Scte35SegmentationScope;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): Scte35SegmentationScope;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Connection details for an ESAM POIS (Placement Opportunity Information System) endpoint.
 */
export interface PoisEndpoint {
    /**
     * The POIS endpoint URL that MediaLive sends signal conditioning information to.
     */
    readonly url: string;
    /**
     * The username used to connect to the POIS endpoint.
     * @default - no credentials
     */
    readonly username?: string;
    /**
     * An SSM parameter holding the password for the POIS endpoint. The channel role is granted
     * read access to the parameter automatically.
     * @default - no credentials
     */
    readonly password?: IStringParameter;
}
/**
 * Settings for ESAM (Event Signaling and Management) ad avail handling. MediaLive signals ad avail
 * events to an external POIS (Placement Opportunity Information System) endpoint.
 */
export interface EsamSettings {
    /**
     * The POIS endpoint connection details — URL and optional credentials.
     */
    readonly pois: PoisEndpoint;
    /**
     * The acquisition point identity sent to the POIS in MCC requests.
     */
    readonly acquisitionPointId: string;
    /**
     * Offset added to the input ad avail PTS time.
     * @default - service default
     */
    readonly adAvailOffset?: Duration;
    /**
     * The ID of a zone the POIS uses to control the placement of ad avails.
     * @default - service default
     */
    readonly zoneIdentity?: string;
}
/**
 * Avail settings — how SCTE-35 ad avail markers are handled.
 * Use the static factory methods to create.
 */
export declare abstract class AvailSettings {
    /**
     * Use SCTE-35 splice insert mode for ad avail handling.
     */
    static spliceInsert(props?: Scte35SpliceInsertSettings): AvailSettings;
    /**
     * Use SCTE-35 time signal APOS mode for ad avail handling.
     */
    static timeSignalApos(props?: Scte35TimeSignalAposSettings): AvailSettings;
    /**
     * Use ESAM (Event Signaling and Management) mode, signaling ad avails to an external POIS.
     */
    static esam(props: EsamSettings): AvailSettings;
}
/**
 * Blackout slate state.
 */
export declare class BlackoutSlateState {
    /** Enable blackout slate */
    static readonly ENABLED: BlackoutSlateState;
    /** Disable blackout slate */
    static readonly DISABLED: BlackoutSlateState;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): BlackoutSlateState;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Network end blackout state.
 */
export declare class NetworkEndBlackout {
    /** Enable network end blackout */
    static readonly ENABLED: NetworkEndBlackout;
    /** Disable network end blackout */
    static readonly DISABLED: NetworkEndBlackout;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): NetworkEndBlackout;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Blackout slate configuration for the channel.
 */
export interface BlackoutSlate {
    /**
     * Whether to enable the blackout slate.
     * @default - ENABLED if image is provided, DISABLED otherwise
     */
    readonly state?: BlackoutSlateState;
    /**
     * The blackout slate image. Provide a `FileLocation` referencing an S3 bucket
     * (`FileLocation.fromBucket`, which auto-grants read access) or a URL (`FileLocation.url`).
     * Only .bmp and .png supported.
     * @default - solid black
     */
    readonly image?: FileLocation;
    /**
     * Whether to enable network end blackout (triggered by SCTE-35 Network End Segmentation Descriptor).
     * @default - ENABLED if networkEndBlackoutImage is provided, DISABLED otherwise
     */
    readonly networkEndBlackout?: NetworkEndBlackout;
    /**
     * The network end blackout image. Provide a `FileLocation` referencing an S3 bucket
     * (`FileLocation.fromBucket`, which auto-grants read access) or a URL (`FileLocation.url`).
     * @default - solid black
     */
    readonly networkEndBlackoutImage?: FileLocation;
    /**
     * The EIDR network ID (e.g. '10.XXXX/XXXX-XXXX-XXXX-XXXX-XXXX-C').
     * @default - no network ID
     */
    readonly networkId?: string;
}
