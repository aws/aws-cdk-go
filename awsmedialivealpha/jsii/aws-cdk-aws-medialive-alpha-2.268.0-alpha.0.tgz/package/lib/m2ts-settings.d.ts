import type { Bitrate, Duration } from 'aws-cdk-lib';
/** The output bitrate mode of the transport stream. */
export declare class M2tsRateMode {
    /** Constant bitrate — inserts null packets to fill the configured bitrate. */
    static readonly CBR: M2tsRateMode;
    /** Variable bitrate — the configured bitrate acts as the maximum. */
    static readonly VBR: M2tsRateMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsRateMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** The buffer model used for the transport stream. */
export declare class M2tsBufferModel {
    /** Uses the multiplex buffer model for accurate interleaving. */
    static readonly MULTIPLEX: M2tsBufferModel;
    /** Can lead to lower latency, but low-memory devices might not be able to play back the stream without interruptions. */
    static readonly NONE: M2tsBufferModel;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsBufferModel;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** The buffer model used for Dolby Digital audio. */
export declare class M2tsAudioBufferModel {
    /** ATSC buffer model. */
    static readonly ATSC: M2tsAudioBufferModel;
    /** DVB buffer model. */
    static readonly DVB: M2tsAudioBufferModel;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsAudioBufferModel;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** The stream type used for audio elementary streams. */
export declare class M2tsAudioStreamType {
    /** ATSC — stream type 0x81 for AC3, 0x87 for EAC3. */
    static readonly ATSC: M2tsAudioStreamType;
    /** DVB — stream type 0x06. */
    static readonly DVB: M2tsAudioStreamType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsAudioStreamType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Controls insertion of the Program Clock Reference (PCR). */
export declare class M2tsPcrControl {
    /** Insert PCR at the configured `pcrPeriod`. */
    static readonly CONFIGURED_PCR_PERIOD: M2tsPcrControl;
    /** Insert a PCR for every Packetized Elementary Stream (PES) header. */
    static readonly PCR_EVERY_PES_PACKET: M2tsPcrControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsPcrControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Whether to include the ES Rate field in the PES header. */
export declare class M2tsEsRateInPes {
    /** Exclude the ES Rate field. */
    static readonly EXCLUDE: M2tsEsRateInPes;
    /** Include the ES Rate field. */
    static readonly INCLUDE: M2tsEsRateInPes;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsEsRateInPes;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** ARIB-compliant field muxing. */
export declare class M2tsArib {
    /** Disabled. */
    static readonly DISABLED: M2tsArib;
    /** Enabled — uses ARIB-compliant field muxing and removes the video descriptor. */
    static readonly ENABLED: M2tsArib;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsArib;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** How the ARIB Captions PID is selected. */
export declare class M2tsAribCaptionsPidControl {
    /** Auto-select the PID from unused PIDs. */
    static readonly AUTO: M2tsAribCaptionsPidControl;
    /** Use the configured `aribCaptionsPid`. */
    static readonly USE_CONFIGURED: M2tsAribCaptionsPidControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsAribCaptionsPidControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** KLV data passthrough behavior. */
export declare class M2tsKlv {
    /** Do not pass KLV data through. */
    static readonly NONE: M2tsKlv;
    /** Pass KLV data from the input through to the output. */
    static readonly PASSTHROUGH: M2tsKlv;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsKlv;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** EBIF data passthrough behavior. */
export declare class M2tsEbif {
    /** Do not pass EBIF data through. */
    static readonly NONE: M2tsEbif;
    /** Pass EBIF data from the input through to the output. */
    static readonly PASSTHROUGH: M2tsEbif;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsEbif;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Nielsen ID3 passthrough behavior. */
export declare class M2tsNielsenId3Behavior {
    /** Do not insert Nielsen ID3 tags. */
    static readonly NO_PASSTHROUGH: M2tsNielsenId3Behavior;
    /** Nielsen inaudible tones for media tracking will be detected in the input audio and an equivalent ID3 tag will be inserted in the output. */
    static readonly PASSTHROUGH: M2tsNielsenId3Behavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsNielsenId3Behavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Whether to generate the captionServiceDescriptor in the PMT. */
export declare class M2tsCcDescriptor {
    /** Disabled. */
    static readonly DISABLED: M2tsCcDescriptor;
    /** Enabled. */
    static readonly ENABLED: M2tsCcDescriptor;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsCcDescriptor;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Behavior when the selected input audio stream is removed from the input. */
export declare class M2tsAbsentInputAudioBehavior {
    /** Remove the output audio streams from the program. */
    static readonly DROP: M2tsAbsentInputAudioBehavior;
    /** Output encoded silence when not connected to an active input stream. */
    static readonly ENCODE_SILENCE: M2tsAbsentInputAudioBehavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsAbsentInputAudioBehavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Controls placement of audio Encoder Boundary Point (EBP) markers. */
export declare class M2tsEbpAudioInterval {
    /** Add audio EBP markers to partitions 3 and 4 at a fixed interval. */
    static readonly VIDEO_AND_FIXED_INTERVALS: M2tsEbpAudioInterval;
    /** Follow the video EBP interval. */
    static readonly VIDEO_INTERVAL: M2tsEbpAudioInterval;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsEbpAudioInterval;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Controls placement of EBP markers on audio PIDs. */
export declare class M2tsEbpPlacement {
    /** Place EBP markers on the video PID and all audio PIDs. */
    static readonly VIDEO_AND_AUDIO_PIDS: M2tsEbpPlacement;
    /** Place EBP markers only on the video PID. */
    static readonly VIDEO_PID: M2tsEbpPlacement;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsEbpPlacement;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** SCTE-35 passthrough behavior. */
export declare class M2tsScte35Control {
    /** Do not pass SCTE-35 signals through. */
    static readonly NONE: M2tsScte35Control;
    /** Pass SCTE-35 signals from the input through to the output. */
    static readonly PASSTHROUGH: M2tsScte35Control;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsScte35Control;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** The type of segmentation markers to insert. */
export declare class M2tsSegmentationMarkers {
    /** No segmentation markers. */
    static readonly NONE: M2tsSegmentationMarkers;
    /** Set the Random Access Indicator (RAI) bit in the adaptation field. */
    static readonly RAI_SEGSTART: M2tsSegmentationMarkers;
    /** Set the RAI bit and add the current timecode in the private data bytes. */
    static readonly RAI_ADAPT: M2tsSegmentationMarkers;
    /** Insert PAT and PMT tables at the start of segments. */
    static readonly PSI_SEGSTART: M2tsSegmentationMarkers;
    /** Add Encoder Boundary Point information (OC-SP-EBP-I01-130118). */
    static readonly EBP: M2tsSegmentationMarkers;
    /** Add Encoder Boundary Point information using the legacy proprietary format. */
    static readonly EBP_LEGACY: M2tsSegmentationMarkers;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsSegmentationMarkers;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** How segmentation markers respond to avails truncating a segment. */
export declare class M2tsSegmentationStyle {
    /** Do not reset the segmentation cadence after a truncated segment. */
    static readonly MAINTAIN_CADENCE: M2tsSegmentationStyle;
    /** Reset the segmentation cadence after a truncated segment. */
    static readonly RESET_CADENCE: M2tsSegmentationStyle;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsSegmentationStyle;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Timed metadata passthrough behavior. */
export declare class M2tsTimedMetadataBehavior {
    /** Do not pass timed metadata through. */
    static readonly NO_PASSTHROUGH: M2tsTimedMetadataBehavior;
    /** Pass timed metadata from the input through to the output. */
    static readonly PASSTHROUGH: M2tsTimedMetadataBehavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): M2tsTimedMetadataBehavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** How DVB Service Description Table (SDT) information is inserted. */
export declare class DvbSdtOutputMode {
    /** Copy SDT information from the input stream to the output stream. */
    static readonly SDT_FOLLOW: DvbSdtOutputMode;
    /** Copy SDT from the input if present, otherwise use the configured values. */
    static readonly SDT_FOLLOW_IF_PRESENT: DvbSdtOutputMode;
    /** Use the user-defined SDT information. */
    static readonly SDT_MANUAL: DvbSdtOutputMode;
    /** Do not include SDT information in the output. */
    static readonly SDT_NONE: DvbSdtOutputMode;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): DvbSdtOutputMode;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/** Settings for inserting a DVB Network Information Table (NIT). */
export interface DvbNitSettings {
    /**
     * The numeric value placed in the Network Information Table (NIT).
     * @default - no network ID
     */
    readonly networkId?: number;
    /**
     * The network name placed in the networkNameDescriptor inside the NIT (max 256 characters).
     * @default - no network name
     */
    readonly networkName?: string;
    /**
     * The interval between instances of this table in the output transport stream.
     * @default - service default
     */
    readonly repInterval?: Duration;
}
/** Settings for inserting a DVB Service Description Table (SDT). */
export interface DvbSdtSettings {
    /**
     * The method of inserting SDT information into the output stream.
     * @default - service default
     */
    readonly outputSdt?: DvbSdtOutputMode;
    /**
     * The interval between instances of this table in the output transport stream.
     * @default - service default
     */
    readonly repInterval?: Duration;
    /**
     * The service name placed in the serviceDescriptor in the SDT (max 256 characters).
     * @default - no service name
     */
    readonly serviceName?: string;
    /**
     * The service provider name placed in the serviceDescriptor in the SDT (max 256 characters).
     * @default - no service provider name
     */
    readonly serviceProviderName?: string;
}
/** Settings for inserting a DVB Time and Date Table (TDT). */
export interface DvbTdtSettings {
    /**
     * The interval between instances of this table in the output transport stream.
     * @default - service default
     */
    readonly repInterval?: Duration;
}
/**
 * Properties for MPEG-2 transport stream (M2TS) container settings.
 *
 * Used by the UDP, Archive, SRT, and MediaConnect Router output groups. All properties are
 * optional; omit them to use MediaLive's service defaults.
 *
 * PID properties accept a decimal or hexadecimal value (and, where noted, ranges or comma-separated
 * lists). Each PID must be in the range 32 (0x20)..8182 (0x1ff6).
 *
 * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-medialive-channel-m2tssettings.html
 */
export interface M2tsSettingsProps {
    /** Behavior when the selected input audio stream is removed. @default - service default */
    readonly absentInputAudioBehavior?: M2tsAbsentInputAudioBehavior;
    /** ARIB-compliant field muxing. @default - service default */
    readonly arib?: M2tsArib;
    /** The PID for ARIB Captions. @default - service default */
    readonly aribCaptionsPid?: string;
    /** How the ARIB Captions PID is selected. @default - service default */
    readonly aribCaptionsPidControl?: M2tsAribCaptionsPidControl;
    /** The buffer model for Dolby Digital audio. @default - service default */
    readonly audioBufferModel?: M2tsAudioBufferModel;
    /** The number of audio frames to insert per PES packet. @default - service default */
    readonly audioFramesPerPes?: number;
    /** The PID(s) of the elementary audio streams (ranges/comma-separated allowed). @default - service default */
    readonly audioPids?: string;
    /** The stream type used for audio elementary streams. @default - service default */
    readonly audioStreamType?: M2tsAudioStreamType;
    /** The output bitrate of the transport stream. Set to 0 bps to let the muxer choose. @default - muxer chooses */
    readonly bitrate?: Bitrate;
    /** The transport stream buffer model. @default - service default */
    readonly bufferModel?: M2tsBufferModel;
    /** Whether to generate the captionServiceDescriptor in the PMT. @default - service default */
    readonly ccDescriptor?: M2tsCcDescriptor;
    /** DVB Network Information Table (NIT) settings. @default - no NIT */
    readonly dvbNitSettings?: DvbNitSettings;
    /** DVB Service Description Table (SDT) settings. @default - no SDT */
    readonly dvbSdtSettings?: DvbSdtSettings;
    /** The PID(s) for input source DVB Subtitle data (ranges/comma-separated allowed). @default - service default */
    readonly dvbSubPids?: string;
    /** DVB Time and Date Table (TDT) settings. @default - no TDT */
    readonly dvbTdtSettings?: DvbTdtSettings;
    /** The PID for input source DVB Teletext data. @default - service default */
    readonly dvbTeletextPid?: string;
    /** EBIF data passthrough behavior. @default - service default */
    readonly ebif?: M2tsEbif;
    /** Placement of audio EBP markers. @default - service default */
    readonly ebpAudioInterval?: M2tsEbpAudioInterval;
    /** The EBP lookahead interval. @default - service default */
    readonly ebpLookahead?: Duration;
    /** Placement of EBP markers on audio PIDs. @default - service default */
    readonly ebpPlacement?: M2tsEbpPlacement;
    /** Whether to include the ES Rate field in the PES header. @default - service default */
    readonly esRateInPes?: M2tsEsRateInPes;
    /** The PID for input source ETV Platform data. @default - service default */
    readonly etvPlatformPid?: string;
    /** The PID for input source ETV Signal data. @default - service default */
    readonly etvSignalPid?: string;
    /** The length of each fragment (used only with EBP markers). @default - service default */
    readonly fragmentTime?: Duration;
    /** KLV data passthrough behavior. @default - service default */
    readonly klv?: M2tsKlv;
    /** The PID(s) for input source KLV data (ranges/comma-separated allowed). @default - service default */
    readonly klvDataPids?: string;
    /** Nielsen ID3 passthrough behavior. @default - service default */
    readonly nielsenId3Behavior?: M2tsNielsenId3Behavior;
    /** The bitrate of extra null packets to insert into the transport stream. @default - no null packets */
    readonly nullPacketBitrate?: Bitrate;
    /** The interval between PAT instances (0, or 10ms..1000ms). @default - service default */
    readonly patInterval?: Duration;
    /** Controls insertion of the Program Clock Reference (PCR). @default - service default */
    readonly pcrControl?: M2tsPcrControl;
    /** The maximum interval between Program Clock References (PCRs). @default - service default */
    readonly pcrPeriod?: Duration;
    /** The PID of the Program Clock Reference. @default - same as the video PID */
    readonly pcrPid?: string;
    /** The interval between PMT instances (0, or 10ms..1000ms). @default - service default */
    readonly pmtInterval?: Duration;
    /** The PID for the Program Map Table (PMT). @default - service default */
    readonly pmtPid?: string;
    /** The value of the program number field in the PMT. @default - service default */
    readonly programNum?: number;
    /** The transport stream bitrate mode (CBR/VBR). @default - service default */
    readonly rateMode?: M2tsRateMode;
    /** The PID(s) for input source SCTE-27 data (ranges/comma-separated allowed). @default - service default */
    readonly scte27Pids?: string;
    /** SCTE-35 passthrough behavior. @default - service default */
    readonly scte35Control?: M2tsScte35Control;
    /** The PID of the SCTE-35 stream. @default - service default */
    readonly scte35Pid?: string;
    /** The SCTE-35 preroll pullup interval. @default - service default */
    readonly scte35PrerollPullup?: Duration;
    /** The type of segmentation markers to insert. @default - service default */
    readonly segmentationMarkers?: M2tsSegmentationMarkers;
    /** How segmentation markers respond to avails. @default - service default */
    readonly segmentationStyle?: M2tsSegmentationStyle;
    /** The length of each segment (required unless `segmentationMarkers` is NONE). @default - service default */
    readonly segmentationTime?: Duration;
    /** Timed metadata passthrough behavior. @default - service default */
    readonly timedMetadataBehavior?: M2tsTimedMetadataBehavior;
    /** The PID of the timed metadata stream. @default - service default */
    readonly timedMetadataPid?: string;
    /** The value of the transport stream ID field in the PMT. @default - service default */
    readonly transportStreamId?: number;
    /** The PID of the elementary video stream. @default - service default */
    readonly videoPid?: string;
}
/**
 * MPEG-2 transport stream (M2TS) container settings for an MPEG-TS output.
 *
 * Use `M2tsSettings.of()` to configure the transport stream produced by a UDP, Archive, SRT, or
 * MediaConnect Router output. Omitting it entirely uses MediaLive's service defaults.
 */
export declare class M2tsSettings {
    private readonly props;
    /** Create M2TS container settings. */
    static of(props: M2tsSettingsProps): M2tsSettings;
    private constructor();
}
