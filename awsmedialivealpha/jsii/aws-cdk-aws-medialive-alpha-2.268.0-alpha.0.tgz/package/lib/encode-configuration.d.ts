import type { AudioCodecSettings } from './audio-codec-settings';
import type { CaptionDestination } from './caption-settings';
import type { VideoCodecSettings } from './video-codec-settings';
/**
 * Base interface for an encode configuration (video, audio, or caption).
 *
 * The same EncodeConfiguration instance can be shared across multiple output groups within a channel.
 * The channel automatically deduplicates encode descriptions by name at synth time.
 */
export declare abstract class EncodeConfiguration {
    /**
     * Create a video encode configuration.
     */
    static video(props: VideoEncodeProps): EncodeConfiguration;
    /**
     * Create an audio encode configuration.
     */
    static audio(props: AudioEncodeProps): EncodeConfiguration;
    /**
     * Create a caption encode configuration.
     */
    static caption(props: CaptionEncodeProps): EncodeConfiguration;
    /** The unique name for this encode, used to reference it from outputs. */
    abstract readonly name: string;
}
/**
 * How to respond to AFD values in the input stream.
 */
export declare class RespondToAfd {
    /** Clip input video based on AFD values */
    static readonly RESPOND: RespondToAfd;
    /** Pass AFD values through without clipping */
    static readonly PASSTHROUGH: RespondToAfd;
    /** Ignore AFD values */
    static readonly NONE: RespondToAfd;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): RespondToAfd;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Video scaling behavior.
 */
export declare class ScalingBehavior {
    /** May insert black boxes to match output resolution */
    static readonly DEFAULT: ScalingBehavior;
    /** Stretch video to fill the output resolution */
    static readonly STRETCH_TO_OUTPUT: ScalingBehavior;
    /** Intelligently crop the video to focus on key subjects (9:16 vertical). Requires an Elemental Inference feed on the channel via `inferenceFeed`. Do NOT include `FeedOutput.cropping()` on the feed — MediaLive auto-inserts it. */
    static readonly SMART_CROP: ScalingBehavior;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): ScalingBehavior;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Properties for a video encode configuration.
 */
export interface VideoEncodeProps {
    /**
     * A unique name for this video encode.
     */
    readonly name: string;
    /**
     * The width of the output video in pixels. Must be an even number.
     */
    readonly width: number;
    /**
     * The height of the output video in pixels. Must be an even number.
     */
    readonly height: number;
    /**
     * The codec for the video encode.
     *
     * Choose the codec explicitly (e.g. `VideoCodecSettings.h264(...)`)
     */
    readonly codec: VideoCodecSettings;
    /**
     * How to respond to AFD values in the input stream.
     * @default RespondToAfd.NONE
     */
    readonly respondToAfd?: RespondToAfd;
    /**
     * The video scaling behavior.
     * @default ScalingBehavior.DEFAULT
     */
    readonly scalingBehavior?: ScalingBehavior;
    /**
     * The anti-alias filter strength (0-100). 0 is softest, 100 is sharpest.
     * @default 50
     */
    readonly sharpness?: number;
}
/**
 * Audio normalization algorithm.
 */
export declare class AudioNormalizationAlgorithm {
    /** CALM Act specification (ITU-R BS.1770-1) */
    static readonly ITU_1770_1: AudioNormalizationAlgorithm;
    /** EBU R-128 specification (ITU-R BS.1770-2) */
    static readonly ITU_1770_2: AudioNormalizationAlgorithm;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AudioNormalizationAlgorithm;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Audio normalization algorithm control.
 */
export declare class AudioNormalizationAlgorithmControl {
    /** Correct the audio using the chosen algorithm */
    static readonly CORRECT_AUDIO: AudioNormalizationAlgorithmControl;
    /** Measure audio but do not adjust */
    static readonly MEASURE_ONLY: AudioNormalizationAlgorithmControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AudioNormalizationAlgorithmControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Peak calculation method for audio normalization.
 */
export declare class AudioNormalizationPeakCalculation {
    /** Calculate and log the TruePeak for each audio track. */
    static readonly TRUE_PEAK: AudioNormalizationPeakCalculation;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AudioNormalizationPeakCalculation;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Audio normalization settings.
 */
export interface AudioNormalizationSettings {
    /**
     * The normalization algorithm.
     * @default - service default
     */
    readonly algorithm?: AudioNormalizationAlgorithm;
    /**
     * Whether to correct or only measure.
     * @default - service default
     */
    readonly algorithmControl?: AudioNormalizationAlgorithmControl;
    /**
     * The target loudness in LKFS. CALM Act recommends -24, EBU R-128 recommends -23.
     * @default - service default
     */
    readonly targetLkfs?: number;
    /**
     * Whether to use a peak limiter and how to calculate peak levels.
     * @default - service default
     */
    readonly peakCalculation?: AudioNormalizationPeakCalculation;
    /**
     * The peak limiter threshold in dBFS. Only used when peak limiting is enabled.
     * @default - service default
     */
    readonly peakLimiterThreshold?: number;
}
/**
 * An input channel level for audio remixing.
 */
export interface InputChannelLevel {
    /**
     * The index of the input channel to use as a source.
     */
    readonly inputChannel: number;
    /**
     * The remixing gain in dB (-60 to 6).
     * @default 0
     */
    readonly gain?: number;
}
/**
 * A mapping from input channels to an output channel.
 */
export interface AudioChannelMapping {
    /**
     * The index of the output channel being produced.
     */
    readonly outputChannel: number;
    /**
     * The input channels and their gain levels to mix into this output channel.
     */
    readonly inputChannelLevels: InputChannelLevel[];
}
/**
 * Audio remix settings for channel remapping.
 */
export interface RemixSettings {
    /**
     * The channel mappings from input to output.
     */
    readonly channelMappings: AudioChannelMapping[];
    /**
     * The number of input channels.
     * @default - auto-detected
     */
    readonly channelsIn?: number;
    /**
     * The number of output channels. Valid values: 1, 2, 4, 6, 8.
     * @default - auto-detected
     */
    readonly channelsOut?: number;
}
/**
 * CBET insertion behavior when prior encoding is detected on the same layer.
 */
export declare class NielsenCbetStepaside {
    /**
     * Existing Nielsen watermarks are removed. New watermarks are inserted throughout the audio.
     */
    static readonly DISABLED: NielsenCbetStepaside;
    /**
     * Existing Nielsen watermarks are left intact. New watermarks are inserted only in portions
     * of the audio where there are no existing watermarks.
     */
    static readonly ENABLED: NielsenCbetStepaside;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): NielsenCbetStepaside;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Timezone applied to the timestamps in a Nielsen NAES II/NW watermark.
 */
export declare class NielsenWatermarkTimezone {
    /** America/Puerto Rico */
    static readonly AMERICA_PUERTO_RICO: NielsenWatermarkTimezone;
    /** US Alaska */
    static readonly US_ALASKA: NielsenWatermarkTimezone;
    /** US Arizona */
    static readonly US_ARIZONA: NielsenWatermarkTimezone;
    /** US Central */
    static readonly US_CENTRAL: NielsenWatermarkTimezone;
    /** US Eastern */
    static readonly US_EASTERN: NielsenWatermarkTimezone;
    /** US Hawaii */
    static readonly US_HAWAII: NielsenWatermarkTimezone;
    /** US Mountain */
    static readonly US_MOUNTAIN: NielsenWatermarkTimezone;
    /** US Pacific */
    static readonly US_PACIFIC: NielsenWatermarkTimezone;
    /** US Samoa */
    static readonly US_SAMOA: NielsenWatermarkTimezone;
    /** Coordinated Universal Time */
    static readonly UTC: NielsenWatermarkTimezone;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): NielsenWatermarkTimezone;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Nielsen CBET watermark settings.
 */
export interface NielsenCbetSettings {
    /**
     * The CBET check digit string.
     */
    readonly cbetCheckDigitString: string;
    /**
     * The CBET Source ID (CSID).
     */
    readonly csid: string;
    /**
     * The CBET stepaside behavior when prior encoding is detected.
     * @default - service default
     */
    readonly cbetStepaside?: NielsenCbetStepaside;
}
/**
 * Nielsen NAES II/NW watermark settings.
 */
export interface NielsenNaesIiNwSettings {
    /**
     * The check digit string for the watermark.
     */
    readonly checkDigitString: string;
    /**
     * The Nielsen Source ID (SID).
     */
    readonly sid: number;
    /**
     * The timezone for the timestamps in the watermark.
     * @default - Coordinated Universal Time (UTC)
     */
    readonly timezone?: NielsenWatermarkTimezone;
}
/**
 * Nielsen watermark distribution type.
 */
export declare class NielsenDistributionType {
    /** Program content */
    static readonly PROGRAM_CONTENT: NielsenDistributionType;
    /** Final distributor */
    static readonly FINAL_DISTRIBUTOR: NielsenDistributionType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): NielsenDistributionType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Nielsen watermark settings for audio.
 */
export interface NielsenWatermarksSettings {
    /**
     * The distribution type for the watermark.
     * @default - service default
     */
    readonly distributionType?: NielsenDistributionType;
    /**
     * Nielsen CBET watermark settings.
     * @default - no CBET watermarks
     */
    readonly cbetSettings?: NielsenCbetSettings;
    /**
     * Nielsen NAES II/NW watermark settings.
     * @default - no NAES II/NW watermarks
     */
    readonly naesIiNwSettings?: NielsenNaesIiNwSettings;
}
/**
 * Audio watermarking settings.
 */
export interface AudioWatermarkSettings {
    /**
     * Nielsen watermark settings.
     * @default - no Nielsen watermarks
     */
    readonly nielsenWatermarks?: NielsenWatermarksSettings;
}
/**
 * Determines how the audio type is signaled in the output.
 */
export declare class AudioTypeControl {
    /**
     * If the input contains an ISO 639 audioType it is passed through; otherwise the
     * configured `audioType` is used.
     */
    static readonly FOLLOW_INPUT: AudioTypeControl;
    /** The configured `audioType` is always used. */
    static readonly USE_CONFIGURED: AudioTypeControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AudioTypeControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Determines how the audio language code is signaled in the output.
 */
export declare class AudioLanguageCodeControl {
    /**
     * If the input contains a language code it is passed through; otherwise the configured
     * `languageCode` is used as a fallback.
     */
    static readonly FOLLOW_INPUT: AudioLanguageCodeControl;
    /** The configured `languageCode` is always used. */
    static readonly USE_CONFIGURED: AudioLanguageCodeControl;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AudioLanguageCodeControl;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * The audio type, as defined in ISO/IEC 13818-1.
 */
export declare class AudioType {
    /** Clean effects (no dialogue). */
    static readonly CLEAN_EFFECTS: AudioType;
    /** Hearing impaired. */
    static readonly HEARING_IMPAIRED: AudioType;
    /** Undefined. */
    static readonly UNDEFINED: AudioType;
    /** Visual impaired commentary. */
    static readonly VISUAL_IMPAIRED_COMMENTARY: AudioType;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AudioType;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * DVB DASH accessibility signaling for an audio output.
 */
export declare class DvbDashAccessibility {
    /** Visually impaired. */
    static readonly VISUALLY_IMPAIRED: DvbDashAccessibility;
    /** Hard of hearing. */
    static readonly HARD_OF_HEARING: DvbDashAccessibility;
    /** Supplemental commentary. */
    static readonly SUPPLEMENTAL_COMMENTARY: DvbDashAccessibility;
    /** Director's commentary. */
    static readonly DIRECTORS_COMMENTARY: DvbDashAccessibility;
    /** Educational notes. */
    static readonly EDUCATIONAL_NOTES: DvbDashAccessibility;
    /** Main program. */
    static readonly MAIN_PROGRAM: DvbDashAccessibility;
    /** Clean feed. */
    static readonly CLEAN_FEED: DvbDashAccessibility;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): DvbDashAccessibility;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * A DASH role to assign to an audio output (used when the output carries DVB DASH accessibility
 * signaling).
 */
export declare class AudioDashRole {
    /** Alternate. */
    static readonly ALTERNATE: AudioDashRole;
    /** Commentary. */
    static readonly COMMENTARY: AudioDashRole;
    /** Description. */
    static readonly DESCRIPTION: AudioDashRole;
    /** Dub. */
    static readonly DUB: AudioDashRole;
    /** Emergency. */
    static readonly EMERGENCY: AudioDashRole;
    /** Enhanced audio intelligibility. */
    static readonly ENHANCED_AUDIO_INTELLIGIBILITY: AudioDashRole;
    /** Karaoke. */
    static readonly KARAOKE: AudioDashRole;
    /** Main. */
    static readonly MAIN: AudioDashRole;
    /** Supplementary. */
    static readonly SUPPLEMENTARY: AudioDashRole;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): AudioDashRole;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Properties for an audio encode configuration.
 */
export interface AudioEncodeProps {
    /**
     * A unique name for this audio encode.
     */
    readonly name: string;
    /**
     * The name of the audio selector in the input to use as the source. Must match the `name` of an
     * `AudioSelector` on the input attachment. When omitted, MediaLive uses the input's default audio.
     * @default - the input's default audio
     */
    readonly audioSelectorName?: string;
    /**
     * The codec for the audio encode.
     *
     * Choose the codec explicitly (e.g. `AudioCodecSettings.aac(...)`)
     */
    readonly codec: AudioCodecSettings;
    /**
     * The ISO 639-2 language code for the audio output track (e.g. 'eng', 'spa').
     * @default - follow input
     */
    readonly languageCode?: string;
    /**
     * How the audio language code is signaled in the output. When `FOLLOW_INPUT`, a configured
     * `languageCode` is used only as a fallback when the input has none.
     * @default - USE_CONFIGURED when `languageCode` is set, otherwise FOLLOW_INPUT
     */
    readonly languageCodeControl?: AudioLanguageCodeControl;
    /**
     * The display name for the audio track (e.g. 'English', 'Director Commentary').
     * Used for HLS and MS Smooth outputs.
     * @default - no stream name
     */
    readonly streamName?: string;
    /**
     * Audio normalization settings for loudness correction.
     * @default - no normalization
     */
    readonly audioNormalization?: AudioNormalizationSettings;
    /**
     * The audio type when audioTypeControl is USE_CONFIGURED. The values are defined in ISO-IEC 13818-1.
     * @default - follow input
     */
    readonly audioType?: AudioType;
    /**
     * How the audio type is signaled in the output.
     * @default - USE_CONFIGURED when `audioType` is set, otherwise FOLLOW_INPUT
     */
    readonly audioTypeControl?: AudioTypeControl;
    /**
     * The DASH roles to assign to this audio output. Applies only when the output is configured
     * for DVB DASH accessibility signaling.
     * @default - no DASH roles
     */
    readonly audioDashRoles?: AudioDashRole[];
    /**
     * DVB DASH accessibility signaling for this audio output.
     * @default - no DVB DASH accessibility signaling
     */
    readonly dvbDashAccessibility?: DvbDashAccessibility;
    /**
     * Audio remix settings for channel remapping.
     * @default - no remixing
     */
    readonly remixSettings?: RemixSettings;
    /**
     * Audio watermarking settings (e.g. Nielsen watermarks).
     * @default - no watermarking
     */
    readonly audioWatermarkSettings?: AudioWatermarkSettings;
}
/**
 * Whether a caption track implements accessibility features (written descriptions of dialog,
 * music, and sounds). Signaled in HLS and MediaPackage output groups.
 */
export declare class CaptionAccessibility {
    /** The captions do not implement accessibility features. */
    static readonly DOES_NOT_IMPLEMENT_ACCESSIBILITY_FEATURES: CaptionAccessibility;
    /** The captions implement accessibility features. */
    static readonly IMPLEMENTS_ACCESSIBILITY_FEATURES: CaptionAccessibility;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): CaptionAccessibility;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * A DASH role to assign to a captions output (used when the output carries DVB DASH accessibility
 * signaling).
 */
export declare class CaptionDashRole {
    /** Alternate. */
    static readonly ALTERNATE: CaptionDashRole;
    /** Caption. */
    static readonly CAPTION: CaptionDashRole;
    /** Commentary. */
    static readonly COMMENTARY: CaptionDashRole;
    /** Description. */
    static readonly DESCRIPTION: CaptionDashRole;
    /** Dub. */
    static readonly DUB: CaptionDashRole;
    /** Easy reader. */
    static readonly EASYREADER: CaptionDashRole;
    /** Emergency. */
    static readonly EMERGENCY: CaptionDashRole;
    /** Forced subtitle. */
    static readonly FORCED_SUBTITLE: CaptionDashRole;
    /** Karaoke. */
    static readonly KARAOKE: CaptionDashRole;
    /** Main. */
    static readonly MAIN: CaptionDashRole;
    /** Metadata. */
    static readonly METADATA: CaptionDashRole;
    /** Subtitle. */
    static readonly SUBTITLE: CaptionDashRole;
    /** Supplementary. */
    static readonly SUPPLEMENTARY: CaptionDashRole;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): CaptionDashRole;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Properties for a caption encode configuration.
 */
export interface CaptionEncodeProps {
    /**
     * A unique name for this caption encode.
     */
    readonly name: string;
    /**
     * The name of the caption selector in the input to use as the source.
     */
    readonly captionSelectorName: string;
    /**
     * The output caption format. Use the `CaptionDestination` factory methods (e.g.
     * `CaptionDestination.burnIn()`, `.webvtt()`, `.embedded()`).
     */
    readonly destination: CaptionDestination;
    /**
     * The ISO 639-2 language code for the captions (e.g. 'eng', 'spa').
     * @default - no language code
     */
    readonly languageCode?: string;
    /**
     * Human-readable description of the captions (e.g. 'English', 'Spanish').
     * @default - no language description
     */
    readonly languageDescription?: string;
    /**
     * Whether this caption track implements accessibility features.
     * @default - The captions do not implement accessibility features
     */
    readonly accessibility?: CaptionAccessibility;
    /**
     * The DASH roles to assign to this captions output. Applies only when the output is configured
     * for DVB DASH accessibility signaling.
     * @default - no DASH roles
     */
    readonly captionDashRoles?: CaptionDashRole[];
    /**
     * DVB DASH accessibility signaling for this captions output.
     * @default - no DVB DASH accessibility signaling
     */
    readonly dvbDashAccessibility?: DvbDashAccessibility;
}
