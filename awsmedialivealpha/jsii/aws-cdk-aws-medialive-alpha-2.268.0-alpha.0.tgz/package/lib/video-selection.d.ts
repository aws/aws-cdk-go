/**
 * Video color space.
 */
export declare class VideoColorSpace {
    /** Follow the source color space */
    static readonly FOLLOW: VideoColorSpace;
    /** Rec. 601 */
    static readonly REC_601: VideoColorSpace;
    /** Rec. 709 */
    static readonly REC_709: VideoColorSpace;
    /** HDR10 */
    static readonly HDR10: VideoColorSpace;
    /** HLG 2020 */
    static readonly HLG_2020: VideoColorSpace;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): VideoColorSpace;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * Controls how the `colorSpace` value is used when it is not `FOLLOW`.
 */
export declare class VideoColorSpaceUsage {
    /**
     * Use the input's color space data when present; fall back to `colorSpace` only when the
     * input has none.
     */
    static readonly FALLBACK: VideoColorSpaceUsage;
    /** Always use `colorSpace`, ignoring any color space data in the input. */
    static readonly FORCE: VideoColorSpaceUsage;
    /** A value not yet modelled by AWS CDK. */
    static of(value: string): VideoColorSpaceUsage;
    /** The underlying string value passed to CloudFormation. */
    readonly value: string;
    private constructor();
}
/**
 * HDR10 color space metadata for the input video.
 */
export interface Hdr10Settings {
    /**
     * Maximum Content Light Level (MaxCLL) — the maximum light level, in nits, of any single
     * pixel in the stream.
     * @default - not set
     */
    readonly maxContentLightLevel?: number;
    /**
     * Maximum Frame Average Light Level (MaxFALL) — the maximum average light level, in nits,
     * of any single frame in the stream.
     * @default - not set
     */
    readonly maxFrameAverageLightLevel?: number;
}
/**
 * Selects the specific video to extract from the input — by PID or by program. Create with
 * the static factory methods; exactly one selection applies, enforced by the type.
 */
export declare abstract class VideoSelection {
    /** Extract the video with this PID. */
    static byPid(pid: number): VideoSelection;
    /**
     * Extract the video from this program within a multi-program transport stream. If the
     * program doesn't exist, MediaLive selects the first program in the stream.
     */
    static byProgramId(programId: number): VideoSelection;
}
/**
 * Video selector settings for an input.
 */
export interface VideoSelectorSettings {
    /**
     * The color space of the input video.
     * @default - service default
     */
    readonly colorSpace?: VideoColorSpace;
    /**
     * How `colorSpace` is applied when it is not `FOLLOW`.
     * @default - MediaLive service default
     */
    readonly colorSpaceUsage?: VideoColorSpaceUsage;
    /**
     * HDR10 color space metadata for the input.
     * @default - none
     */
    readonly hdr10?: Hdr10Settings;
    /**
     * Selects the specific video to extract from the input (by PID or by program).
     * @default - MediaLive selects the video automatically
     */
    readonly selectBy?: VideoSelection;
}
