/**
 * The length of a media segment for an output group.
 *
 * Express the length in whole seconds with {@link Segment.seconds} or in milliseconds
 * with {@link Segment.milliseconds}. Some output groups (e.g. HLS) only support
 * whole-second segments and will reject sub-second millisecond values.
 */
export declare class Segment {
    /**
     * A segment length in whole seconds.
     * @param value Number of seconds (non-negative integer).
     */
    static seconds(value: number): Segment;
    /**
     * A segment length in milliseconds.
     * @param value Number of milliseconds (non-negative integer).
     */
    static milliseconds(value: number): Segment;
    private constructor();
}
/**
 * The pixel aspect ratio (PAR) of the video.
 *
 * Use the predefined constants for standard ratios, or {@link PixelAspectRatio.of} for
 * a custom ratio.
 */
export declare class PixelAspectRatio {
    /** Square pixels (`1:1`). */
    static readonly SQUARE: PixelAspectRatio;
    /**
     * Define a pixel aspect ratio.
     *
     * @param numerator Numerator of the ratio.
     * @param denominator Denominator of the ratio.
     */
    static of(numerator: number, denominator: number): PixelAspectRatio;
    /**
     * @param numerator Numerator of the ratio.
     * @param denominator Denominator of the ratio.
     */
    private constructor();
    /** Returns the string value in `numerator:denominator` form. */
    toString(): string;
}
