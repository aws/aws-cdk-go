const VALIDATORS = { _aws_cdk_aws_medialive_alpha_InputSourceOptions: function _aws_cdk_aws_medialive_alpha_InputSourceOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.password))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ssm_IStringParameter(p.password);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_MediaConnectRouterInputProps: function _aws_cdk_aws_medialive_alpha_MediaConnectRouterInputProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionSecret))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_secretsmanager_ISecret(p.encryptionSecret);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_MediaConnectInputProps: function _aws_cdk_aws_medialive_alpha_MediaConnectInputProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.flows != null)
                for (const o of p.flows)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_mediaconnect_IFlowRef(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_SrtCallerSourceProps: function _aws_cdk_aws_medialive_alpha_SrtCallerSourceProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_medialive_alpha_SrtDecryptionProps(p.decryption);
            if (!visitedObjects.has(p.minimumLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.minimumLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_SrtDecryptionProps: function _aws_cdk_aws_medialive_alpha_SrtDecryptionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.passphraseSecret))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_secretsmanager_ISecret(p.passphraseSecret);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_SrtListenerInputProps: function _aws_cdk_aws_medialive_alpha_SrtListenerInputProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.inputSecurityGroups != null)
                for (const o of p.inputSecurityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_medialive_IInputSecurityGroupRef(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.decryption))
                module.exports._aws_cdk_aws_medialive_alpha_SrtDecryptionProps(p.decryption);
            if (!visitedObjects.has(p.minimumLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.minimumLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_CdiInputProps: function _aws_cdk_aws_medialive_alpha_CdiInputProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.subnets != null)
                for (const o of p.subnets)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_ec2_ISubnetRef(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_ec2_ISecurityGroupRef(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_PushInputProps: function _aws_cdk_aws_medialive_alpha_PushInputProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_PushInputDestination(o);
            if (p.inputSecurityGroups != null)
                for (const o of p.inputSecurityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_medialive_IInputSecurityGroupRef(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_PushInputDestination: function _aws_cdk_aws_medialive_alpha_PushInputDestination(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.network))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_medialive_INetworkRef(p.network);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.networkRoutes != null)
                for (const o of p.networkRoutes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_NetworkRoute(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_FileLocationOptions: function _aws_cdk_aws_medialive_alpha_FileLocationOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.password))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ssm_IStringParameter(p.password);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_FrameCaptureSettingsProps: function _aws_cdk_aws_medialive_alpha_FrameCaptureSettingsProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.captureInterval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.captureInterval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_AacSettingsProps: function _aws_cdk_aws_medialive_alpha_AacSettingsProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.bitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_Ac3SettingsProps: function _aws_cdk_aws_medialive_alpha_Ac3SettingsProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.bitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_Eac3SettingsProps: function _aws_cdk_aws_medialive_alpha_Eac3SettingsProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.bitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_Eac3AtmosSettingsProps: function _aws_cdk_aws_medialive_alpha_Eac3AtmosSettingsProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.bitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_Mp2SettingsProps: function _aws_cdk_aws_medialive_alpha_Mp2SettingsProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.bitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_ChannelProps: function _aws_cdk_aws_medialive_alpha_ChannelProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.inputs != null)
                for (const o of p.inputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_InputAttachment(o);
            if (p.outputGroups != null)
                for (const o of p.outputGroups)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_OutputGroupConfiguration(o);
            if (!visitedObjects.has(p.anywhereSettings))
                module.exports._aws_cdk_aws_medialive_alpha_AnywhereSettings(p.anywhereSettings);
            if (p.channelSecurityGroups != null)
                for (const o of p.channelSecurityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_medialive_IInputSecurityGroupRef(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (p.colorCorrections != null)
                for (const o of p.colorCorrections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_ColorCorrection(o);
            if (!visitedObjects.has(p.globalConfiguration))
                module.exports._aws_cdk_aws_medialive_alpha_GlobalConfiguration(p.globalConfiguration);
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.vpc))
                module.exports._aws_cdk_aws_medialive_alpha_VpcOutputSettings(p.vpc);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_InputLossBehavior: function _aws_cdk_aws_medialive_alpha_InputLossBehavior(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.blackFrame))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.blackFrame);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.repeatFrame))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.repeatFrame);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_GlobalConfiguration: function _aws_cdk_aws_medialive_alpha_GlobalConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputLossBehavior))
                module.exports._aws_cdk_aws_medialive_alpha_InputLossBehavior(p.inputLossBehavior);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_AnywhereSettings: function _aws_cdk_aws_medialive_alpha_AnywhereSettings(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.cluster))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_medialive_IClusterRef(p.cluster);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.channelPlacementGroup))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_medialive_IChannelPlacementGroupRef(p.channelPlacementGroup);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_VpcOutputSettings: function _aws_cdk_aws_medialive_alpha_VpcOutputSettings(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.subnets != null)
                for (const o of p.subnets)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_ec2_ISubnetRef(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_elasticache_ISecurityGroupRef(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_PoisEndpoint: function _aws_cdk_aws_medialive_alpha_PoisEndpoint(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.password))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ssm_IStringParameter(p.password);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_EsamSettings: function _aws_cdk_aws_medialive_alpha_EsamSettings(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.pois))
                module.exports._aws_cdk_aws_medialive_alpha_PoisEndpoint(p.pois);
            if (!visitedObjects.has(p.adAvailOffset))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.adAvailOffset);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_NetworkInputSettings: function _aws_cdk_aws_medialive_alpha_NetworkInputSettings(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.hlsInputSettings))
                module.exports._aws_cdk_aws_medialive_alpha_HlsInputSettings(p.hlsInputSettings);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_HlsInputSettings: function _aws_cdk_aws_medialive_alpha_HlsInputSettings(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bandwidth))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.bandwidth);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.retryInterval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.retryInterval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_InputLossFailoverProps: function _aws_cdk_aws_medialive_alpha_InputLossFailoverProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.threshold))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.threshold);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_AudioSilenceFailoverProps: function _aws_cdk_aws_medialive_alpha_AudioSilenceFailoverProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.threshold))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.threshold);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_VideoBlackFailoverProps: function _aws_cdk_aws_medialive_alpha_VideoBlackFailoverProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.threshold))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.threshold);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_AutomaticInputFailover: function _aws_cdk_aws_medialive_alpha_AutomaticInputFailover(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.errorClearTime))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.errorClearTime);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.failoverConditions != null)
                for (const o of p.failoverConditions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_FailoverCondition(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_InputAttachment: function _aws_cdk_aws_medialive_alpha_InputAttachment(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.audioSelectors != null)
                for (const o of p.audioSelectors)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_AudioSelector(o);
            if (!visitedObjects.has(p.automaticInputFailover))
                module.exports._aws_cdk_aws_medialive_alpha_AutomaticInputFailover(p.automaticInputFailover);
            if (p.captionSelectors != null)
                for (const o of p.captionSelectors)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CaptionSelector(o);
            if (!visitedObjects.has(p.networkInputSettings))
                module.exports._aws_cdk_aws_medialive_alpha_NetworkInputSettings(p.networkInputSettings);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_HlsStaticKeyProps: function _aws_cdk_aws_medialive_alpha_HlsStaticKeyProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.staticKeyValue))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_SecretValue(p.staticKeyValue);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_HlsBasicPutCdnProps: function _aws_cdk_aws_medialive_alpha_HlsBasicPutCdnProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.filecacheDuration))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.filecacheDuration);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_HlsAkamaiCdnProps: function _aws_cdk_aws_medialive_alpha_HlsAkamaiCdnProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.filecacheDuration))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.filecacheDuration);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_HlsWebdavCdnProps: function _aws_cdk_aws_medialive_alpha_HlsWebdavCdnProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.filecacheDuration))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.filecacheDuration);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_MediaPackageV2OutputGroupBaseProps: function _aws_cdk_aws_medialive_alpha_MediaPackageV2OutputGroupBaseProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2OutputDefinition(o);
            if (p.additionalDestinations != null)
                for (const o of p.additionalDestinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2Destination(o);
            if (p.captionLanguageMappings != null)
                for (const o of p.captionLanguageMappings)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CaptionLanguageMapping(o);
            if (!visitedObjects.has(p.timedMetadataId3Period))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.timedMetadataId3Period);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_MediaPackageV2OutputGroupProps: function _aws_cdk_aws_medialive_alpha_MediaPackageV2OutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.channel))
                try {
                    require("@aws-cdk/aws-mediapackagev2-alpha/.warnings.jsii.js")._aws_cdk_aws_mediapackagev2_alpha_IChannel(p.channel);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2OutputDefinition(o);
            if (p.additionalDestinations != null)
                for (const o of p.additionalDestinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2Destination(o);
            if (p.captionLanguageMappings != null)
                for (const o of p.captionLanguageMappings)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CaptionLanguageMapping(o);
            if (!visitedObjects.has(p.timedMetadataId3Period))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.timedMetadataId3Period);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_MediaPackageV2PerPipelineOutputGroupProps: function _aws_cdk_aws_medialive_alpha_MediaPackageV2PerPipelineOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2Destination(o);
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2OutputDefinition(o);
            if (p.additionalDestinations != null)
                for (const o of p.additionalDestinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MediaPackageV2Destination(o);
            if (p.captionLanguageMappings != null)
                for (const o of p.captionLanguageMappings)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CaptionLanguageMapping(o);
            if (!visitedObjects.has(p.timedMetadataId3Period))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.timedMetadataId3Period);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_HlsOutputGroupProps: function _aws_cdk_aws_medialive_alpha_HlsOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_OutputDestination(o);
            if (p.adMarkers != null)
                for (const o of p.adMarkers)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_HlsAdMarkers(o);
            if (p.captionLanguageMappings != null)
                for (const o of p.captionLanguageMappings)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CaptionLanguageMapping(o);
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_HlsOutputDefinition(o);
            if (!visitedObjects.has(p.programDateTimePeriod))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.programDateTimePeriod);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.timedMetadataId3Period))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.timedMetadataId3Period);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.timestampDelta))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.timestampDelta);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_UdpOutputGroupProps: function _aws_cdk_aws_medialive_alpha_UdpOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_UdpOutputDestination(o);
            if (!visitedObjects.has(p.buffer))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.buffer);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_UdpOutputDefinition(o);
            if (!visitedObjects.has(p.timedMetadataId3Period))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.timedMetadataId3Period);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_ArchiveOutputGroupProps: function _aws_cdk_aws_medialive_alpha_ArchiveOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_S3OutputDestination(o);
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_ArchiveOutputDefinition(o);
            if (!visitedObjects.has(p.rolloverInterval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.rolloverInterval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_RtmpOutputGroupProps: function _aws_cdk_aws_medialive_alpha_RtmpOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_RtmpOutputDefinition(o);
            if (p.adMarkers != null)
                for (const o of p.adMarkers)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_RtmpAdMarkers(o);
            if (!visitedObjects.has(p.cacheLength))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.cacheLength);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.restartDelay))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.restartDelay);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_SrtOutputGroupProps: function _aws_cdk_aws_medialive_alpha_SrtOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_SrtOutputDefinition(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_CmafIngestOutputGroupProps: function _aws_cdk_aws_medialive_alpha_CmafIngestOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_OutputDestination(o);
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CmafIngestOutputDefinition(o);
            if (p.additionalDestinations != null)
                for (const o of p.additionalDestinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_OutputDestination(o);
            if (p.captionLanguageMappings != null)
                for (const o of p.captionLanguageMappings)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_CmafCaptionLanguageMapping(o);
            if (!visitedObjects.has(p.timedMetadataId3Period))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.timedMetadataId3Period);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_MsSmoothOutputGroupProps: function _aws_cdk_aws_medialive_alpha_MsSmoothOutputGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_OutputDestination(o);
            if (!visitedObjects.has(p.connectionRetryInterval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.connectionRetryInterval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.filecacheDuration))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.filecacheDuration);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.fragmentLength))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.fragmentLength);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.outputs != null)
                for (const o of p.outputs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_MsSmoothOutputDefinition(o);
            if (!visitedObjects.has(p.restartDelay))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.restartDelay);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_OutputDestinationOptions: function _aws_cdk_aws_medialive_alpha_OutputDestinationOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.password))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ssm_IStringParameter(p.password);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_SrtCallerDestinationProps: function _aws_cdk_aws_medialive_alpha_SrtCallerDestinationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionPassphraseSecret))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_secretsmanager_ISecret(p.encryptionPassphraseSecret);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_SrtCallerUrlOptions: function _aws_cdk_aws_medialive_alpha_SrtCallerUrlOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionPassphraseSecret))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_secretsmanager_ISecret(p.encryptionPassphraseSecret);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_SrtListenerDestinationProps: function _aws_cdk_aws_medialive_alpha_SrtListenerDestinationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionPassphraseSecret))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_secretsmanager_ISecret(p.encryptionPassphraseSecret);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_MediaConnectRouterPipelineConfig: function _aws_cdk_aws_medialive_alpha_MediaConnectRouterPipelineConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionSecret))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_secretsmanager_ISecret(p.encryptionSecret);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_MediaConnectRouterPerPipelineSettings: function _aws_cdk_aws_medialive_alpha_MediaConnectRouterPerPipelineSettings(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.pipeline0))
                module.exports._aws_cdk_aws_medialive_alpha_MediaConnectRouterPipelineConfig(p.pipeline0);
            if (!visitedObjects.has(p.pipeline1))
                module.exports._aws_cdk_aws_medialive_alpha_MediaConnectRouterPipelineConfig(p.pipeline1);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_UdpOutputDefinition: function _aws_cdk_aws_medialive_alpha_UdpOutputDefinition(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.buffer))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.buffer);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.encodes != null)
                for (const o of p.encodes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_EncodeConfiguration(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_RtmpOutputDefinition: function _aws_cdk_aws_medialive_alpha_RtmpOutputDefinition(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_RtmpDestination(o);
            if (!visitedObjects.has(p.connectionRetryInterval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.connectionRetryInterval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.encodes != null)
                for (const o of p.encodes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_EncodeConfiguration(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_SrtOutputDefinition: function _aws_cdk_aws_medialive_alpha_SrtOutputDefinition(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_SrtDestination(o);
            if (!visitedObjects.has(p.buffer))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.buffer);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.latency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.latency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.encodes != null)
                for (const o of p.encodes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_medialive_alpha_EncodeConfiguration(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_DvbNitSettings: function _aws_cdk_aws_medialive_alpha_DvbNitSettings(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.repInterval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.repInterval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_DvbSdtSettings: function _aws_cdk_aws_medialive_alpha_DvbSdtSettings(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.repInterval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.repInterval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_DvbTdtSettings: function _aws_cdk_aws_medialive_alpha_DvbTdtSettings(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.repInterval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.repInterval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_M2tsSettingsProps: function _aws_cdk_aws_medialive_alpha_M2tsSettingsProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.bitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.dvbNitSettings))
                module.exports._aws_cdk_aws_medialive_alpha_DvbNitSettings(p.dvbNitSettings);
            if (!visitedObjects.has(p.dvbSdtSettings))
                module.exports._aws_cdk_aws_medialive_alpha_DvbSdtSettings(p.dvbSdtSettings);
            if (!visitedObjects.has(p.dvbTdtSettings))
                module.exports._aws_cdk_aws_medialive_alpha_DvbTdtSettings(p.dvbTdtSettings);
            if (!visitedObjects.has(p.ebpLookahead))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.ebpLookahead);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.fragmentTime))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.fragmentTime);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.nullPacketBitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.nullPacketBitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.patInterval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.patInterval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.pcrPeriod))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.pcrPeriod);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.pmtInterval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.pmtInterval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.scte35PrerollPullup))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.scte35PrerollPullup);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.segmentationTime))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.segmentationTime);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_M3u8SettingsProps: function _aws_cdk_aws_medialive_alpha_M3u8SettingsProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.patInterval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.patInterval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.pcrPeriod))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.pcrPeriod);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.pmtInterval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.pmtInterval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_CbrRateControlProps: function _aws_cdk_aws_medialive_alpha_CbrRateControlProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.bitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_VbrRateControlProps: function _aws_cdk_aws_medialive_alpha_VbrRateControlProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.bitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.maxBitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.maxBitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_QvbrRateControlProps: function _aws_cdk_aws_medialive_alpha_QvbrRateControlProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.maxBitrate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Bitrate(p.maxBitrate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_ClusterProps: function _aws_cdk_aws_medialive_alpha_ClusterProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.instanceRole))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.instanceRole);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_medialive_alpha_ChannelPlacementGroupProps: function _aws_cdk_aws_medialive_alpha_ChannelPlacementGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.cluster))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_medialive_IClusterRef(p.cluster);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
