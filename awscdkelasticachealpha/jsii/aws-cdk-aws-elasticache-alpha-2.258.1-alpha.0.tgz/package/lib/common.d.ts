/**
 * Engine type for ElastiCache users and user groups.
 *
 * Use the named static members for the engines currently supported by ElastiCache
 * user/user-group resources. To target an engine not yet represented by a named
 * instance, use `UserEngine.of(engineType)`.
 */
export declare class UserEngine {
    /**
     * Valkey engine.
     */
    static readonly VALKEY: UserEngine;
    /**
     * Redis engine.
     */
    static readonly REDIS: UserEngine;
    /**
     * Create a new `UserEngine` with an arbitrary engine type.
     *
     * @param engineType the engine type (for example, `'valkey'` or `'redis'`)
     */
    static of(engineType: string): UserEngine;
    /**
     * The engine type, for example `'valkey'` or `'redis'`.
     * Maps directly to the `Engine` property of `AWS::ElastiCache::User` and
     * `AWS::ElastiCache::UserGroup`.
     */
    readonly engineType: string;
    private constructor();
    /**
     * Returns the engine type as a string (for example, `'valkey'`).
     */
    toString(): string;
}
