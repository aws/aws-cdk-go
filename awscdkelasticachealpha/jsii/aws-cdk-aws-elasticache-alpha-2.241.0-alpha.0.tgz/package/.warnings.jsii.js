function _aws_cdk_aws_elasticache_alpha_UserEngine(p) {
}
function _aws_cdk_aws_elasticache_alpha_UserGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.engine))
            _aws_cdk_aws_elasticache_alpha_UserEngine(p.engine);
        if (p.users != null)
            for (const o of p.users)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_elasticache_alpha_IUser(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_elasticache_alpha_IUserGroup(p) {
}
function _aws_cdk_aws_elasticache_alpha_UserGroupBase(p) {
}
function _aws_cdk_aws_elasticache_alpha_UserGroupAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.engine))
            _aws_cdk_aws_elasticache_alpha_UserEngine(p.engine);
        if (p.users != null)
            for (const o of p.users)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_elasticache_alpha_IUser(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_elasticache_alpha_UserGroup(p) {
}
function _aws_cdk_aws_elasticache_alpha_AccessControl(p) {
}
function _aws_cdk_aws_elasticache_alpha_UserBaseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.accessControl))
            _aws_cdk_aws_elasticache_alpha_AccessControl(p.accessControl);
        if (!visitedObjects.has(p.engine))
            _aws_cdk_aws_elasticache_alpha_UserEngine(p.engine);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_elasticache_alpha_IUser(p) {
}
function _aws_cdk_aws_elasticache_alpha_UserBaseAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.engine))
            _aws_cdk_aws_elasticache_alpha_UserEngine(p.engine);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_elasticache_alpha_UserBase(p) {
}
function _aws_cdk_aws_elasticache_alpha_IamUserProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.accessControl))
            _aws_cdk_aws_elasticache_alpha_AccessControl(p.accessControl);
        if (!visitedObjects.has(p.engine))
            _aws_cdk_aws_elasticache_alpha_UserEngine(p.engine);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_elasticache_alpha_IamUser(p) {
}
function _aws_cdk_aws_elasticache_alpha_PasswordUserProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.passwords != null)
            for (const o of p.passwords)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_SecretValue(o);
        if (!visitedObjects.has(p.accessControl))
            _aws_cdk_aws_elasticache_alpha_AccessControl(p.accessControl);
        if (!visitedObjects.has(p.engine))
            _aws_cdk_aws_elasticache_alpha_UserEngine(p.engine);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_elasticache_alpha_PasswordUser(p) {
}
function _aws_cdk_aws_elasticache_alpha_NoPasswordUserProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.accessControl))
            _aws_cdk_aws_elasticache_alpha_AccessControl(p.accessControl);
        if (!visitedObjects.has(p.engine))
            _aws_cdk_aws_elasticache_alpha_UserEngine(p.engine);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_elasticache_alpha_NoPasswordUser(p) {
}
function _aws_cdk_aws_elasticache_alpha_CacheEngine(p) {
}
function _aws_cdk_aws_elasticache_alpha_IServerlessCache(p) {
}
function _aws_cdk_aws_elasticache_alpha_ServerlessCacheBase(p) {
}
function _aws_cdk_aws_elasticache_alpha_CacheUsageLimitsProperty(p) {
}
function _aws_cdk_aws_elasticache_alpha_BackupSettings(p) {
}
function _aws_cdk_aws_elasticache_alpha_ServerlessCacheProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.backup))
            _aws_cdk_aws_elasticache_alpha_BackupSettings(p.backup);
        if (!visitedObjects.has(p.cacheUsageLimits))
            _aws_cdk_aws_elasticache_alpha_CacheUsageLimitsProperty(p.cacheUsageLimits);
        if (!visitedObjects.has(p.engine))
            _aws_cdk_aws_elasticache_alpha_CacheEngine(p.engine);
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        if (!visitedObjects.has(p.userGroup))
            _aws_cdk_aws_elasticache_alpha_IUserGroup(p.userGroup);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_elasticache_alpha_ServerlessCacheAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.engine))
            _aws_cdk_aws_elasticache_alpha_CacheEngine(p.engine);
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        if (p.subnets != null)
            for (const o of p.subnets)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISubnet(o);
        if (!visitedObjects.has(p.userGroup))
            _aws_cdk_aws_elasticache_alpha_IUserGroup(p.userGroup);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_elasticache_alpha_ServerlessCache(p) {
}
function _aws_cdk_aws_elasticache_alpha_ServerlessCacheGrants(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_elasticache_alpha_UserEngine, _aws_cdk_aws_elasticache_alpha_UserGroupProps, _aws_cdk_aws_elasticache_alpha_IUserGroup, _aws_cdk_aws_elasticache_alpha_UserGroupBase, _aws_cdk_aws_elasticache_alpha_UserGroupAttributes, _aws_cdk_aws_elasticache_alpha_UserGroup, _aws_cdk_aws_elasticache_alpha_AccessControl, _aws_cdk_aws_elasticache_alpha_UserBaseProps, _aws_cdk_aws_elasticache_alpha_IUser, _aws_cdk_aws_elasticache_alpha_UserBaseAttributes, _aws_cdk_aws_elasticache_alpha_UserBase, _aws_cdk_aws_elasticache_alpha_IamUserProps, _aws_cdk_aws_elasticache_alpha_IamUser, _aws_cdk_aws_elasticache_alpha_PasswordUserProps, _aws_cdk_aws_elasticache_alpha_PasswordUser, _aws_cdk_aws_elasticache_alpha_NoPasswordUserProps, _aws_cdk_aws_elasticache_alpha_NoPasswordUser, _aws_cdk_aws_elasticache_alpha_CacheEngine, _aws_cdk_aws_elasticache_alpha_IServerlessCache, _aws_cdk_aws_elasticache_alpha_ServerlessCacheBase, _aws_cdk_aws_elasticache_alpha_CacheUsageLimitsProperty, _aws_cdk_aws_elasticache_alpha_BackupSettings, _aws_cdk_aws_elasticache_alpha_ServerlessCacheProps, _aws_cdk_aws_elasticache_alpha_ServerlessCacheAttributes, _aws_cdk_aws_elasticache_alpha_ServerlessCache, _aws_cdk_aws_elasticache_alpha_ServerlessCacheGrants };
