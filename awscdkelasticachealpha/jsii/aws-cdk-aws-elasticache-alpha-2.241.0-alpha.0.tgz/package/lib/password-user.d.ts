import type { SecretValue } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import { UserEngine } from './common';
import type { UserBaseProps } from './user-base';
import { UserBase } from './user-base';
/**
 * Properties for defining an ElastiCache user with password authentication.
 */
export interface PasswordUserProps extends UserBaseProps {
    /**
     * The name of the user.
     *
     * @default - Same as userId.
     */
    readonly userName?: string;
    /**
     * The passwords for the user.
     * Password authentication requires using 1-2 passwords.
     */
    readonly passwords: SecretValue[];
}
/**
 * Define an ElastiCache user with password authentication.
 *
 * @resource AWS::ElastiCache::User
 */
export declare class PasswordUser extends UserBase {
    /**
     * Uniquely identifies this class.
     */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Return whether the given object is a `PasswordUser`.
     */
    static isPasswordUser(x: any): x is PasswordUser;
    /**
     * The engine for the user.
     */
    readonly engine?: UserEngine;
    /**
     * The user's ID.
     *
     * @attribute
     */
    readonly userId: string;
    /**
     * The user's name.
     *
     * @attribute
     */
    readonly userName?: string;
    /**
     * The access string that defines the user's permissions.
     */
    readonly accessString: string;
    /**
     * The user's ARN.
     *
     * @attribute
     */
    readonly userArn: string;
    /**
     * The user's status.
     * Can be 'active', 'modifying', 'deleting'.
     *
     * @attribute
     */
    readonly userStatus: string;
    private readonly resource;
    constructor(scope: Construct, id: string, props: PasswordUserProps);
}
