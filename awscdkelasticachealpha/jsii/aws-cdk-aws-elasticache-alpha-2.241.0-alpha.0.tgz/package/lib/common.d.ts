/**
 * Engine type for ElastiCache users and user groups
 */
export declare enum UserEngine {
    /**
     * Valkey engine
     */
    VALKEY = "valkey",
    /**
     * Redis engine
     */
    REDIS = "redis"
}
