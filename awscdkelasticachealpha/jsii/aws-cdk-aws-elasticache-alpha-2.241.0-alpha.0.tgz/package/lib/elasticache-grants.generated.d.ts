import * as elasticache from "aws-cdk-lib/aws-elasticache";
import * as iam from "aws-cdk-lib/aws-iam";
/**
 * Collection of grant methods for a IServerlessCacheRef
 */
export declare class ServerlessCacheGrants {
    /**
     * Creates grants for ServerlessCacheGrants
     */
    static fromServerlessCache(resource: elasticache.IServerlessCacheRef): ServerlessCacheGrants;
    protected readonly resource: elasticache.IServerlessCacheRef;
    private constructor();
    /**
     * Grant connect permissions to the cache
     */
    connect(grantee: iam.IGrantable): iam.Grant;
}
