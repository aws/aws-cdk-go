const VALIDATORS = { _aws_cdk_mixins_preview_aws_appmesh_events_AWSServiceEventViaCloudTrail_AWSServiceEventViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_appmesh_events_AWSServiceEventViaCloudTrail_AWSServiceEventViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_athena_events_AthenaQueryStateChange_AthenaQueryStateChangeProps: function _aws_cdk_mixins_preview_aws_athena_events_AthenaQueryStateChange_AthenaQueryStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchLifecycleAction_EC2InstanceLaunchLifecycleActionProps: function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchLifecycleAction_EC2InstanceLaunchLifecycleActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchSuccessful_EC2InstanceLaunchSuccessfulProps: function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchSuccessful_EC2InstanceLaunchSuccessfulProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchUnsuccessful_EC2InstanceLaunchUnsuccessfulProps: function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchUnsuccessful_EC2InstanceLaunchUnsuccessfulProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateLifecycleAction_EC2InstanceTerminateLifecycleActionProps: function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateLifecycleAction_EC2InstanceTerminateLifecycleActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateSuccessful_EC2InstanceTerminateSuccessfulProps: function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateSuccessful_EC2InstanceTerminateSuccessfulProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateUnsuccessful_EC2InstanceTerminateUnsuccessfulProps: function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateUnsuccessful_EC2InstanceTerminateUnsuccessfulProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementCompleted_AcknowledgementCompletedProps: function _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementCompleted_AcknowledgementCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementFailed_AcknowledgementFailedProps: function _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementFailed_AcknowledgementFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_b2bi_events_TransformationCompleted_TransformationCompletedProps: function _aws_cdk_mixins_preview_aws_b2bi_events_TransformationCompleted_TransformationCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_b2bi_events_TransformationFailed_TransformationFailedProps: function _aws_cdk_mixins_preview_aws_b2bi_events_TransformationFailed_TransformationFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_BatchJobStateChangeProps: function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_BatchJobStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.attempts != null)
                for (const o of p.attempts)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_BatchJobStateChangeItem(o);
            if (p.dependsOn != null)
                for (const o of p.dependsOn)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_JobDependency(o);
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_chime_events_ChimeVoiceConnectorStreamingStatus_ChimeVoiceConnectorStreamingStatusProps: function _aws_cdk_mixins_preview_aws_chime_events_ChimeVoiceConnectorStreamingStatus_ChimeVoiceConnectorStreamingStatusProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress_CloudFormationHookInvocationProgressProps: function _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress_CloudFormationHookInvocationProgressProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsS3Props: function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsS3Props: function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_CloudWatchAlarmConfigurationChangeProps: function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_CloudWatchAlarmConfigurationChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_CloudWatchAlarmStateChangeProps: function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_CloudWatchAlarmStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codebuild_events_AWSServiceEventViaCloudTrail_AWSServiceEventViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_codebuild_events_AWSServiceEventViaCloudTrail_AWSServiceEventViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_CodeBuildBuildPhaseChangeProps: function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_CodeBuildBuildPhaseChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_CodeBuildBuildStateChangeProps: function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_CodeBuildBuildStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.resources != null)
                for (const o of p.resources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitApprovalRuleTemplateChange_CodeCommitApprovalRuleTemplateChangeProps: function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitApprovalRuleTemplateChange_CodeCommitApprovalRuleTemplateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitPullRequestStateChange_CodeCommitPullRequestStateChangeProps: function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitPullRequestStateChange_CodeCommitPullRequestStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitCommentOnCommit_CodeCommitCommentOnCommitProps: function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitCommentOnCommit_CodeCommitCommentOnCommitProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitCommentOnPullRequest_CodeCommitCommentOnPullRequestProps: function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitCommentOnPullRequest_CodeCommitCommentOnPullRequestProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitRepositoryStateChange_CodeCommitRepositoryStateChangeProps: function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitRepositoryStateChange_CodeCommitRepositoryStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codedeploy_events_CodeDeployDeploymentStateChangeNotification_CodeDeployDeploymentStateChangeNotificationProps: function _aws_cdk_mixins_preview_aws_codedeploy_events_CodeDeployDeploymentStateChangeNotification_CodeDeployDeploymentStateChangeNotificationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codedeploy_events_CodeDeployInstanceStateChangeNotification_CodeDeployInstanceStateChangeNotificationProps: function _aws_cdk_mixins_preview_aws_codedeploy_events_CodeDeployInstanceStateChangeNotification_CodeDeployInstanceStateChangeNotificationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_CodeGuruProfilerRecommendationStateChangeProps: function _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_CodeGuruProfilerRecommendationStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_CodePipelineActionExecutionStateChangeProps: function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_CodePipelineActionExecutionStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelinePipelineExecutionStateChange_CodePipelinePipelineExecutionStateChangeProps: function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelinePipelineExecutionStateChange_CodePipelinePipelineExecutionStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineStageExecutionStateChange_CodePipelineStageExecutionStateChangeProps: function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineStageExecutionStateChange_CodePipelineStageExecutionStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_connect_events_CodeConnectContact_CodeConnectContactProps: function _aws_cdk_mixins_preview_aws_connect_events_CodeConnectContact_CodeConnectContactProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_connect_events_ContactLensPostCallRulesMatched_ContactLensPostCallRulesMatchedProps: function _aws_cdk_mixins_preview_aws_connect_events_ContactLensPostCallRulesMatched_ContactLensPostCallRulesMatchedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_connect_events_ContactLensRealtimeRulesMatched_ContactLensRealtimeRulesMatchedProps: function _aws_cdk_mixins_preview_aws_connect_events_ContactLensRealtimeRulesMatched_ContactLensRealtimeRulesMatchedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_dataexchange_events_DataSetUpdateDelayed_DataSetUpdateDelayedProps: function _aws_cdk_mixins_preview_aws_dataexchange_events_DataSetUpdateDelayed_DataSetUpdateDelayedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_dataexchange_events_DataUpdatedInDataSet_DataUpdatedInDataSetProps: function _aws_cdk_mixins_preview_aws_dataexchange_events_DataUpdatedInDataSet_DataUpdatedInDataSetProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_dataexchange_events_DeprecationPlannedForDataSet_DeprecationPlannedForDataSetProps: function _aws_cdk_mixins_preview_aws_dataexchange_events_DeprecationPlannedForDataSet_DeprecationPlannedForDataSetProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_dataexchange_events_SchemaChangePlannedForDataSet_SchemaChangePlannedForDataSetProps: function _aws_cdk_mixins_preview_aws_dataexchange_events_SchemaChangePlannedForDataSet_SchemaChangePlannedForDataSetProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_datasync_events_DataSyncAgentStateChange_DataSyncAgentStateChangeProps: function _aws_cdk_mixins_preview_aws_datasync_events_DataSyncAgentStateChange_DataSyncAgentStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_datasync_events_DataSyncLocationStateChange_DataSyncLocationStateChangeProps: function _aws_cdk_mixins_preview_aws_datasync_events_DataSyncLocationStateChange_DataSyncLocationStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_datasync_events_DataSyncTaskExecutionStateChange_DataSyncTaskExecutionStateChangeProps: function _aws_cdk_mixins_preview_aws_datasync_events_DataSyncTaskExecutionStateChange_DataSyncTaskExecutionStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_datasync_events_DataSyncTaskStateChange_DataSyncTaskStateChangeProps: function _aws_cdk_mixins_preview_aws_datasync_events_DataSyncTaskStateChange_DataSyncTaskStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_deadline_events_FleetSizeRecommendationChange_FleetSizeRecommendationChangeProps: function _aws_cdk_mixins_preview_aws_deadline_events_FleetSizeRecommendationChange_FleetSizeRecommendationChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_DevOpsGuruInsightClosedProps: function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_DevOpsGuruInsightClosedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.anomalies != null)
                for (const o of p.anomalies)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_Anomaly(o);
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_DevOpsGuruInsightSeverityUpgradedProps: function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_DevOpsGuruInsightSeverityUpgradedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.anomalies != null)
                for (const o of p.anomalies)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_Anomaly(o);
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_DevOpsGuruNewAnomalyAssociationProps: function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_DevOpsGuruNewAnomalyAssociationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.anomalies != null)
                for (const o of p.anomalies)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_Anomaly(o);
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_DevOpsGuruNewInsightOpenProps: function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_DevOpsGuruNewInsightOpenProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.anomalies != null)
                for (const o of p.anomalies)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_Anomaly(o);
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_DevOpsGuruNewRecommendationCreatedProps: function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_DevOpsGuruNewRecommendationCreatedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recommendations != null)
                for (const o of p.recommendations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_Recommendation(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_dlm_events_DLMPolicyStateChange_DLMPolicyStateChangeProps: function _aws_cdk_mixins_preview_aws_dlm_events_DLMPolicyStateChange_DLMPolicyStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_dsql_mixins_CfnClusterAuditLogsS3Props: function _aws_cdk_mixins_preview_aws_dsql_mixins_CfnClusterAuditLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_dsql_mixins_CfnClusterAuditLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ec2_events_EBSMultiVolumeSnapshotsCompletionStatus_EBSMultiVolumeSnapshotsCompletionStatusProps: function _aws_cdk_mixins_preview_aws_ec2_events_EBSMultiVolumeSnapshotsCompletionStatus_EBSMultiVolumeSnapshotsCompletionStatusProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.snapshots != null)
                for (const o of p.snapshots)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ec2_events_EBSMultiVolumeSnapshotsCompletionStatus_Snapshot(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ec2_events_EBSSnapshotNotification_EBSSnapshotNotificationProps: function _aws_cdk_mixins_preview_aws_ec2_events_EBSSnapshotNotification_EBSSnapshotNotificationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ec2_events_EBSVolumeNotification_EBSVolumeNotificationProps: function _aws_cdk_mixins_preview_aws_ec2_events_EBSVolumeNotification_EBSVolumeNotificationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ec2_events_EC2FastLaunchStateChangeNotification_EC2FastLaunchStateChangeNotificationProps: function _aws_cdk_mixins_preview_aws_ec2_events_EC2FastLaunchStateChangeNotification_EC2FastLaunchStateChangeNotificationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ec2_events_EC2InstanceStateChangeNotification_EC2InstanceStateChangeNotificationProps: function _aws_cdk_mixins_preview_aws_ec2_events_EC2InstanceStateChangeNotification_EC2InstanceStateChangeNotificationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ec2_events_EC2SpotInstanceInterruptionWarning_EC2SpotInstanceInterruptionWarningProps: function _aws_cdk_mixins_preview_aws_ec2_events_EC2SpotInstanceInterruptionWarning_EC2SpotInstanceInterruptionWarningProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnInstanceConsoleLogsS3Props: function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnInstanceConsoleLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ec2_mixins_CfnInstanceConsoleLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsS3Props: function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.resources != null)
                for (const o of p.resources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecr_events_ECRImageAction_ECRImageActionProps: function _aws_cdk_mixins_preview_aws_ecr_events_ECRImageAction_ECRImageActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecr_events_ECRImageScan_ECRImageScanProps: function _aws_cdk_mixins_preview_aws_ecr_events_ECRImageScan_ECRImageScanProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecr_events_ECRPullThroughCacheAction_ECRPullThroughCacheActionProps: function _aws_cdk_mixins_preview_aws_ecr_events_ECRPullThroughCacheAction_ECRPullThroughCacheActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecr_events_ECRReferrerAction_ECRReferrerActionProps: function _aws_cdk_mixins_preview_aws_ecr_events_ECRReferrerAction_ECRReferrerActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecr_events_ECRReplicationAction_ECRReplicationActionProps: function _aws_cdk_mixins_preview_aws_ecr_events_ECRReplicationAction_ECRReplicationActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ECSContainerInstanceStateChangeProps: function _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ECSContainerInstanceStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.attachments != null)
                for (const o of p.attachments)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_AttachmentDetails(o);
            if (p.attributes != null)
                for (const o of p.attributes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_AttributesDetails(o);
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.registeredResources != null)
                for (const o of p.registeredResources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ResourceDetails(o);
            if (p.remainingResources != null)
                for (const o of p.remainingResources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ResourceDetails(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecs_events_ECSServiceAction_ECSServiceActionProps: function _aws_cdk_mixins_preview_aws_ecs_events_ECSServiceAction_ECSServiceActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_ECSTaskStateChangeProps: function _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_ECSTaskStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.attachments != null)
                for (const o of p.attachments)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_AttachmentDetails(o);
            if (p.attributes != null)
                for (const o of p.attributes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_AttributesDetails(o);
            if (p.containers != null)
                for (const o of p.containers)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_ContainerDetails(o);
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecs_mixins_CfnClusterActionLogsS3Props: function _aws_cdk_mixins_preview_aws_ecs_mixins_CfnClusterActionLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_mixins_CfnClusterActionLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdCommitserverLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdCommitserverLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdNotificationLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdNotificationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdNotificationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdServerLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdServerLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdServerLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationsetLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationsetLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdReposerverLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdReposerverLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticache_events_CacheCreated_CacheCreatedProps: function _aws_cdk_mixins_preview_aws_elasticache_events_CacheCreated_CacheCreatedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticache_events_CacheCreationFailed_CacheCreationFailedProps: function _aws_cdk_mixins_preview_aws_elasticache_events_CacheCreationFailed_CacheCreationFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticache_events_CacheDeleted_CacheDeletedProps: function _aws_cdk_mixins_preview_aws_elasticache_events_CacheDeleted_CacheDeletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticache_events_CacheLimitApproaching_CacheLimitApproachingProps: function _aws_cdk_mixins_preview_aws_elasticache_events_CacheLimitApproaching_CacheLimitApproachingProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticache_events_CacheUpdated_CacheUpdatedProps: function _aws_cdk_mixins_preview_aws_elasticache_events_CacheUpdated_CacheUpdatedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticache_events_CacheUpdateFailed_CacheUpdateFailedProps: function _aws_cdk_mixins_preview_aws_elasticache_events_CacheUpdateFailed_CacheUpdateFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCopyFailed_SnapshotCopyFailedProps: function _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCopyFailed_SnapshotCopyFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCreated_SnapshotCreatedProps: function _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCreated_SnapshotCreatedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCreationFailed_SnapshotCreationFailedProps: function _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCreationFailed_SnapshotCreationFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotExportFailed_SnapshotExportFailedProps: function _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotExportFailed_SnapshotExportFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticloadbalancing_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_elasticloadbalancing_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsS3Props: function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsS3Props: function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsS3Props: function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsS3Props: function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elementalinference_mixins_CfnFeedApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_elementalinference_mixins_CfnFeedApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_elementalinference_mixins_CfnFeedApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_emr_events_EMRAutoScalingPolicyStateChange_EMRAutoScalingPolicyStateChangeProps: function _aws_cdk_mixins_preview_aws_emr_events_EMRAutoScalingPolicyStateChange_EMRAutoScalingPolicyStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_emr_events_EMRClusterStateChange_EMRClusterStateChangeProps: function _aws_cdk_mixins_preview_aws_emr_events_EMRClusterStateChange_EMRClusterStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_emr_events_EMRConfigurationError_EMRConfigurationErrorProps: function _aws_cdk_mixins_preview_aws_emr_events_EMRConfigurationError_EMRConfigurationErrorProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceFleetStateChange_EMRInstanceFleetStateChangeProps: function _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceFleetStateChange_EMRInstanceFleetStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceGroupStateChange_EMRInstanceGroupStateChangeProps: function _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceGroupStateChange_EMRInstanceGroupStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceGroupStatusNotification_EMRInstanceGroupStatusNotificationProps: function _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceGroupStatusNotification_EMRInstanceGroupStatusNotificationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_emr_events_EMRStepStatusChange_EMRStepStatusChangeProps: function _aws_cdk_mixins_preview_aws_emr_events_EMRStepStatusChange_EMRStepStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsS3Props: function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsS3Props: function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_events_events_ScheduledJson_ScheduledJsonProps: function _aws_cdk_mixins_preview_aws_events_events_ScheduledJson_ScheduledJsonProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsS3Props: function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsS3Props: function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsS3Props: function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_fis_events_FISExperimentStateChange_FISExperimentStateChangeProps: function _aws_cdk_mixins_preview_aws_fis_events_FISExperimentStateChange_FISExperimentStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_GameLiftMatchmakingEventProps: function _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_GameLiftMatchmakingEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.ruleEvaluationMetrics != null)
                for (const o of p.ruleEvaluationMetrics)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_RuleEvaluationMetrics(o);
            if (p.tickets != null)
                for (const o of p.tickets)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_Ticket(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftQueuePlacementEvent_GameLiftQueuePlacementEventProps: function _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftQueuePlacementEvent_GameLiftQueuePlacementEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.placedPlayerSessions != null)
                for (const o of p.placedPlayerSessions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_gamelift_events_GameLiftQueuePlacementEvent_GameLiftQueuePlacementEventItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_gamelift_mixins_CfnGameSessionQueueQueuePlacementLogsS3Props: function _aws_cdk_mixins_preview_aws_gamelift_mixins_CfnGameSessionQueueQueuePlacementLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_gamelift_mixins_CfnGameSessionQueueQueuePlacementLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_glue_events_GlueDataCatalogDatabaseStateChange_GlueDataCatalogDatabaseStateChangeProps: function _aws_cdk_mixins_preview_aws_glue_events_GlueDataCatalogDatabaseStateChange_GlueDataCatalogDatabaseStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_glue_events_GlueDataCatalogTableStateChange_GlueDataCatalogTableStateChangeProps: function _aws_cdk_mixins_preview_aws_glue_events_GlueDataCatalogTableStateChange_GlueDataCatalogTableStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_glue_events_GlueJobRunStatus_GlueJobRunStatusProps: function _aws_cdk_mixins_preview_aws_glue_events_GlueJobRunStatus_GlueJobRunStatusProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_glue_events_GlueJobStateChange_GlueJobStateChangeProps: function _aws_cdk_mixins_preview_aws_glue_events_GlueJobStateChange_GlueJobStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult_GuardDutyMalwareProtectionObjectScanResultProps: function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult_GuardDutyMalwareProtectionObjectScanResultProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_GuardDutyMalwareProtectionPostScanActionFailedProps: function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_GuardDutyMalwareProtectionPostScanActionFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.postScanActions != null)
                for (const o of p.postScanActions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_PostScanAction(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusActive_GuardDutyMalwareProtectionResourceStatusActiveProps: function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusActive_GuardDutyMalwareProtectionResourceStatusActiveProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_GuardDutyMalwareProtectionResourceStatusErrorProps: function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_GuardDutyMalwareProtectionResourceStatusErrorProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.statusReasons != null)
                for (const o of p.statusReasons)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_StatusReason(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_GuardDutyMalwareProtectionResourceStatusWarningProps: function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_GuardDutyMalwareProtectionResourceStatusWarningProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.statusReasons != null)
                for (const o of p.statusReasons)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_StatusReason(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_GuardDutyFindingProps: function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_GuardDutyFindingProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreated_DataStoreCreatedProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreated_DataStoreCreatedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreating_DataStoreCreatingProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreating_DataStoreCreatingProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreationFailed_DataStoreCreationFailedProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreationFailed_DataStoreCreationFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreDeleted_DataStoreDeletedProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreDeleted_DataStoreDeletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreDeleting_DataStoreDeletingProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreDeleting_DataStoreDeletingProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopied_ImageSetCopiedProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopied_ImageSetCopiedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopyFailed_ImageSetCopyFailedProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopyFailed_ImageSetCopyFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopying_ImageSetCopyingProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopying_ImageSetCopyingProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopyingWithReadOnlyAccess_ImageSetCopyingWithReadOnlyAccessProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopyingWithReadOnlyAccess_ImageSetCopyingWithReadOnlyAccessProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCreated_ImageSetCreatedProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCreated_ImageSetCreatedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetDeleted_ImageSetDeletedProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetDeleted_ImageSetDeletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetDeleting_ImageSetDeletingProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetDeleting_ImageSetDeletingProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdated_ImageSetUpdatedProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdated_ImageSetUpdatedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdateFailed_ImageSetUpdateFailedProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdateFailed_ImageSetUpdateFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdating_ImageSetUpdatingProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdating_ImageSetUpdatingProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobCompleted_ImportJobCompletedProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobCompleted_ImportJobCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobFailed_ImportJobFailedProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobFailed_ImportJobFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobInProgress_ImportJobInProgressProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobInProgress_ImportJobInProgressProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobSubmitted_ImportJobSubmittedProps: function _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobSubmitted_ImportJobSubmittedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreActive_DataStoreActiveProps: function _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreActive_DataStoreActiveProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreCreating_DataStoreCreatingProps: function _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreCreating_DataStoreCreatingProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreDeleted_DataStoreDeletedProps: function _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreDeleted_DataStoreDeletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreDeleting_DataStoreDeletingProps: function _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreDeleting_DataStoreDeletingProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompleted_ExportJobCompletedProps: function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompleted_ExportJobCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompletedWithErrors_ExportJobCompletedWithErrorsProps: function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompletedWithErrors_ExportJobCompletedWithErrorsProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobFailed_ExportJobFailedProps: function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobFailed_ExportJobFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobInProgress_ExportJobInProgressProps: function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobInProgress_ExportJobInProgressProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobSubmitted_ExportJobSubmittedProps: function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobSubmitted_ExportJobSubmittedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompleted_ImportJobCompletedProps: function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompleted_ImportJobCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompletedWithErrors_ImportJobCompletedWithErrorsProps: function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompletedWithErrors_ImportJobCompletedWithErrorsProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobFailed_ImportJobFailedProps: function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobFailed_ImportJobFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobInProgress_ImportJobInProgressProps: function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobInProgress_ImportJobInProgressProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobSubmitted_ImportJobSubmittedProps: function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobSubmitted_ImportJobSubmittedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderCVEDetected_EC2ImageBuilderCVEDetectedProps: function _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderCVEDetected_EC2ImageBuilderCVEDetectedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderImageStateChange_EC2ImageBuilderImageStateChangeProps: function _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderImageStateChange_EC2ImageBuilderImageStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderWorkflowStepWaiting_EC2ImageBuilderWorkflowStepWaitingProps: function _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderWorkflowStepWaiting_EC2ImageBuilderWorkflowStepWaitingProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_iotanalytics_events_IoTAnalyticsDataSetLifeCycleNotification_IoTAnalyticsDataSetLifeCycleNotificationProps: function _aws_cdk_mixins_preview_aws_iotanalytics_events_IoTAnalyticsDataSetLifeCycleNotification_IoTAnalyticsDataSetLifeCycleNotificationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ivs_events_LimitBreach_LimitBreachProps: function _aws_cdk_mixins_preview_aws_ivs_events_LimitBreach_LimitBreachProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ivs_events_RecordingStateChange_RecordingStateChangeProps: function _aws_cdk_mixins_preview_aws_ivs_events_RecordingStateChange_RecordingStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ivs_events_StreamHealthChange_StreamHealthChangeProps: function _aws_cdk_mixins_preview_aws_ivs_events_StreamHealthChange_StreamHealthChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ivs_events_StreamStateChange_StreamStateChangeProps: function _aws_cdk_mixins_preview_aws_ivs_events_StreamStateChange_StreamStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.resources != null)
                for (const o of p.resources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_kms_events_KMSCMKDeletion_KMSCMKDeletionProps: function _aws_cdk_mixins_preview_aws_kms_events_KMSCMKDeletion_KMSCMKDeletionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_kms_events_KMSCMKRotation_KMSCMKRotationProps: function _aws_cdk_mixins_preview_aws_kms_events_KMSCMKRotation_KMSCMKRotationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_kms_events_KMSImportedKeyMaterialExpiration_KMSImportedKeyMaterialExpirationProps: function _aws_cdk_mixins_preview_aws_kms_events_KMSImportedKeyMaterialExpiration_KMSImportedKeyMaterialExpirationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_logs_S3LogsDeliveryProps: function _aws_cdk_mixins_preview_aws_logs_S3LogsDeliveryProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.kmsKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.kmsKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_logs_S3DeliveryDestinationProps: function _aws_cdk_mixins_preview_aws_logs_S3DeliveryDestinationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bucket))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_s3_IBucketRef(p.bucket);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_logs_FirehoseDeliveryDestinationProps: function _aws_cdk_mixins_preview_aws_logs_FirehoseDeliveryDestinationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.deliveryStream))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kinesisfirehose_IDeliveryStreamRef(p.deliveryStream);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_logs_CloudwatchDeliveryDestinationProps: function _aws_cdk_mixins_preview_aws_logs_CloudwatchDeliveryDestinationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.logGroup))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_logs_ILogGroupRef(p.logGroup);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_managedblockchain_events_ManagedBlockchainInvitationStatusChange_ManagedBlockchainInvitationStatusChangeProps: function _aws_cdk_mixins_preview_aws_managedblockchain_events_ManagedBlockchainInvitationStatusChange_ManagedBlockchainInvitationStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_managedblockchain_events_ManagedBlockchainProposalStatusChange_ManagedBlockchainProposalStatusChangeProps: function _aws_cdk_mixins_preview_aws_managedblockchain_events_ManagedBlockchainProposalStatusChange_ManagedBlockchainProposalStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelAlert_MediaLiveChannelAlertProps: function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelAlert_MediaLiveChannelAlertProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelStateChange_MediaLiveChannelStateChangeProps: function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelStateChange_MediaLiveChannelStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveMultiplexAlert_MediaLiveMultiplexAlertProps: function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveMultiplexAlert_MediaLiveMultiplexAlertProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveMultiplexStateChange_MediaLiveMultiplexStateChangeProps: function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveMultiplexStateChange_MediaLiveMultiplexStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelInputChange_MediaLiveChannelInputChangeProps: function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelInputChange_MediaLiveChannelInputChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mediapackage_events_MediaPackageInputNotification_MediaPackageInputNotificationProps: function _aws_cdk_mixins_preview_aws_mediapackage_events_MediaPackageInputNotification_MediaPackageInputNotificationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mediapackage_events_MediaPackageKeyProviderNotification_MediaPackageKeyProviderNotificationProps: function _aws_cdk_mixins_preview_aws_mediapackage_events_MediaPackageKeyProviderNotification_MediaPackageKeyProviderNotificationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mediapackage_events_MediaPackageHarvestJobNotification_MediaPackageHarvestJobNotificationProps: function _aws_cdk_mixins_preview_aws_mediapackage_events_MediaPackageHarvestJobNotification_MediaPackageHarvestJobNotificationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsS3Props: function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsS3Props: function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsS3Props: function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsS3Props: function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsS3Props: function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mgn_events_MGNSourceServerDataReplicationStalledChange_MGNSourceServerDataReplicationStalledChangeProps: function _aws_cdk_mixins_preview_aws_mgn_events_MGNSourceServerDataReplicationStalledChange_MGNSourceServerDataReplicationStalledChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mgn_events_MGNSourceServerLaunchResult_MGNSourceServerLaunchResultProps: function _aws_cdk_mixins_preview_aws_mgn_events_MGNSourceServerLaunchResult_MGNSourceServerLaunchResultProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mgn_events_MGNSourceServerLifecycleStateChange_MGNSourceServerLifecycleStateChangeProps: function _aws_cdk_mixins_preview_aws_mgn_events_MGNSourceServerLifecycleStateChange_MGNSourceServerLifecycleStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_FirewallAttachmentStatusChangedProps: function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_FirewallAttachmentStatusChangedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.data != null)
                for (const o of p.data)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_DataItem(o);
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_FirewallConfigurationChangedProps: function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_FirewallConfigurationChangedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.data != null)
                for (const o of p.data)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_DataItem(o);
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallTransitGatewayAttachmentStatusChanged_FirewallTransitGatewayAttachmentStatusChangedProps: function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallTransitGatewayAttachmentStatusChanged_FirewallTransitGatewayAttachmentStatusChangedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallDenyLogsS3Props: function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallDenyLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallDenyLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsS3Props: function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAllowLogsS3Props: function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAllowLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAllowLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_networkmanager_events_NetworkManagerPolicyUpdate_NetworkManagerPolicyUpdateProps: function _aws_cdk_mixins_preview_aws_networkmanager_events_NetworkManagerPolicyUpdate_NetworkManagerPolicyUpdateProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_networkmanager_events_NetworkManagerSegmentUpdate_NetworkManagerSegmentUpdateProps: function _aws_cdk_mixins_preview_aws_networkmanager_events_NetworkManagerSegmentUpdate_NetworkManagerSegmentUpdateProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_AnnotationImportJobStatusChange_AnnotationImportJobStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_AnnotationImportJobStatusChange_AnnotationImportJobStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_AnnotationStoreStatusChange_AnnotationStoreStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_AnnotationStoreStatusChange_AnnotationStoreStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_ReferenceStoreStatusChange_ReferenceStoreStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_ReferenceStoreStatusChange_ReferenceStoreStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_RunStatusChange_RunStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_RunStatusChange_RunStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_S3AccessPolicyStatusChange_S3AccessPolicyStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_S3AccessPolicyStatusChange_S3AccessPolicyStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_SequenceStoreStatusChange_SequenceStoreStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_SequenceStoreStatusChange_SequenceStoreStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_TaskStatusChange_TaskStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_TaskStatusChange_TaskStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_VariantImportJobStatusChange_VariantImportJobStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_VariantImportJobStatusChange_VariantImportJobStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_VariantStoreStatusChange_VariantStoreStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_VariantStoreStatusChange_VariantStoreStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_WorkflowStatusChange_WorkflowStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_WorkflowStatusChange_WorkflowStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_ReferenceImportJobStatusChange_ReferenceImportJobStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_ReferenceImportJobStatusChange_ReferenceImportJobStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_ReferenceStatusChange_ReferenceStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_ReferenceStatusChange_ReferenceStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_ReadSetActivationJobStatusChange_ReadSetActivationJobStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_ReadSetActivationJobStatusChange_ReadSetActivationJobStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_ReadSetExportJobStatusChange_ReadSetExportJobStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_ReadSetExportJobStatusChange_ReadSetExportJobStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_ReadSetImportJobStatusChange_ReadSetImportJobStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_ReadSetImportJobStatusChange_ReadSetImportJobStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_omics_events_ReadSetStatusChange_ReadSetStatusChangeProps: function _aws_cdk_mixins_preview_aws_omics_events_ReadSetStatusChange_ReadSetStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksAlert_OpsWorksAlertProps: function _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksAlert_OpsWorksAlertProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksCommandStateChange_OpsWorksCommandStateChangeProps: function _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksCommandStateChange_OpsWorksCommandStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksDeploymentStateChange_OpsWorksDeploymentStateChangeProps: function _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksDeploymentStateChange_OpsWorksDeploymentStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksInstanceStateChange_OpsWorksInstanceStateChangeProps: function _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksInstanceStateChange_OpsWorksInstanceStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail_AWSServiceEventViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail_AWSServiceEventViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsScalingLogsS3Props: function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsScalingLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsScalingLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsS3Props: function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsS3Props: function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsS3Props: function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsS3Props: function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsS3Props: function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_qldb_events_QLDBLedgerStateChange_QLDBLedgerStateChangeProps: function _aws_cdk_mixins_preview_aws_qldb_events_QLDBLedgerStateChange_QLDBLedgerStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_rds_events_RDSDBClusterEvent_RDSDBClusterEventProps: function _aws_cdk_mixins_preview_aws_rds_events_RDSDBClusterEvent_RDSDBClusterEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_rds_events_RDSDBClusterSnapshotEvent_RDSDBClusterSnapshotEventProps: function _aws_cdk_mixins_preview_aws_rds_events_RDSDBClusterSnapshotEvent_RDSDBClusterSnapshotEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_rds_events_RDSDBInstanceEvent_RDSDBInstanceEventProps: function _aws_cdk_mixins_preview_aws_rds_events_RDSDBInstanceEvent_RDSDBInstanceEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_rds_events_RDSDBParameterGroupEvent_RDSDBParameterGroupEventProps: function _aws_cdk_mixins_preview_aws_rds_events_RDSDBParameterGroupEvent_RDSDBParameterGroupEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_rds_events_RDSDBProxyEvent_RDSDBProxyEventProps: function _aws_cdk_mixins_preview_aws_rds_events_RDSDBProxyEvent_RDSDBProxyEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_rds_events_RDSDBSecurityGroupEvent_RDSDBSecurityGroupEventProps: function _aws_cdk_mixins_preview_aws_rds_events_RDSDBSecurityGroupEvent_RDSDBSecurityGroupEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_rds_events_RDSDBSnapshotEvent_RDSDBSnapshotEventProps: function _aws_cdk_mixins_preview_aws_rds_events_RDSDBSnapshotEvent_RDSDBSnapshotEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerCellReadinessStatusChange_Route53ApplicationRecoveryControllerCellReadinessStatusChangeProps: function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerCellReadinessStatusChange_Route53ApplicationRecoveryControllerCellReadinessStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerReadinessCheckStatusChange_Route53ApplicationRecoveryControllerReadinessCheckStatusChangeProps: function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerReadinessCheckStatusChange_Route53ApplicationRecoveryControllerReadinessCheckStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChangeProps: function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_DNSFirewallAlertProps: function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_DNSFirewallAlertProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.resources != null)
                for (const o of p.resources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_DnsFirewallAlertItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_DNSFirewallBlockProps: function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_DNSFirewallBlockProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.resources != null)
                for (const o of p.resources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_DnsFirewallBlockItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_rtbfabric_mixins_CfnLinkApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_rtbfabric_mixins_CfnLinkApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_rtbfabric_mixins_CfnLinkApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.resources != null)
                for (const o of p.resources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_events_ObjectAccessTierChanged_ObjectAccessTierChangedProps: function _aws_cdk_mixins_preview_aws_s3_events_ObjectAccessTierChanged_ObjectAccessTierChangedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_events_ObjectACLUpdated_ObjectACLUpdatedProps: function _aws_cdk_mixins_preview_aws_s3_events_ObjectACLUpdated_ObjectACLUpdatedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_events_ObjectCreated_ObjectCreatedProps: function _aws_cdk_mixins_preview_aws_s3_events_ObjectCreated_ObjectCreatedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_events_ObjectDeleted_ObjectDeletedProps: function _aws_cdk_mixins_preview_aws_s3_events_ObjectDeleted_ObjectDeletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreCompleted_ObjectRestoreCompletedProps: function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreCompleted_ObjectRestoreCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreExpired_ObjectRestoreExpiredProps: function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreExpired_ObjectRestoreExpiredProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreInitiated_ObjectRestoreInitiatedProps: function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreInitiated_ObjectRestoreInitiatedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_events_ObjectStorageClassChanged_ObjectStorageClassChangedProps: function _aws_cdk_mixins_preview_aws_s3_events_ObjectStorageClassChanged_ObjectStorageClassChangedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsAdded_ObjectTagsAddedProps: function _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsAdded_ObjectTagsAddedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsDeleted_ObjectTagsDeletedProps: function _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsDeleted_ObjectTagsDeletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsS3Props: function _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerAlgorithmStateChange_SageMakerAlgorithmStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerAlgorithmStateChange_SageMakerAlgorithmStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerAlgorithmStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_SageMakerEndpointConfigStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_SageMakerEndpointConfigStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.productionVariants != null)
                for (const o of p.productionVariants)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_SageMakerEndpointConfigStateChangeItem(o);
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointStateChange_SageMakerEndpointStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointStateChange_SageMakerEndpointStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerGroundTruthLabelingJobTaskStatusChange_SageMakerGroundTruthLabelingJobTaskStatusChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerGroundTruthLabelingJobTaskStatusChange_SageMakerGroundTruthLabelingJobTaskStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_SageMakerHyperParameterTuningJobStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_SageMakerHyperParameterTuningJobStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStatusChange_SageMakerModelBuildingPipelineExecutionStatusChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStatusChange_SageMakerModelBuildingPipelineExecutionStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange_SageMakerModelBuildingPipelineExecutionStepStatusChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange_SageMakerModelBuildingPipelineExecutionStepStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelPackageStateChange_SageMakerModelPackageStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelPackageStateChange_SageMakerModelPackageStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelPackageStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_SageMakerModelStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_SageMakerModelStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookInstanceStateChange_SageMakerNotebookInstanceStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookInstanceStateChange_SageMakerNotebookInstanceStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookInstanceStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookLifecycleConfigStateChange_SageMakerNotebookLifecycleConfigStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookLifecycleConfigStateChange_SageMakerNotebookLifecycleConfigStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookLifecycleConfigStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.inputDataConfig != null)
                for (const o of p.inputDataConfig)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeItem(o);
            if (p.secondaryStatusTransitions != null)
                for (const o of p.secondaryStatusTransitions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeItem1(o);
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_SageMakerTransformJobStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_SageMakerTransformJobStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubFindingsCustomAction_SecurityHubFindingsCustomActionProps: function _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubFindingsCustomAction_SecurityHubFindingsCustomActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubFindingsImported_SecurityHubFindingsImportedProps: function _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubFindingsImported_SecurityHubFindingsImportedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubInsightResults_SecurityHubInsightResultsProps: function _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubInsightResults_SecurityHubInsightResultsProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ses_events_AdvisorRecommendationStatusOpen_AdvisorRecommendationStatusOpenProps: function _aws_cdk_mixins_preview_aws_ses_events_AdvisorRecommendationStatusOpen_AdvisorRecommendationStatusOpenProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ses_events_AdvisorRecommendationStatusResolved_AdvisorRecommendationStatusResolvedProps: function _aws_cdk_mixins_preview_aws_ses_events_AdvisorRecommendationStatusResolved_AdvisorRecommendationStatusResolvedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props: function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsS3Props: function _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ssm_events_CalendarStateChange_CalendarStateChangeProps: function _aws_cdk_mixins_preview_aws_ssm_events_CalendarStateChange_CalendarStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_storagegateway_events_StorageGatewayFileUploadEvent_StorageGatewayFileUploadEventProps: function _aws_cdk_mixins_preview_aws_storagegateway_events_StorageGatewayFileUploadEvent_StorageGatewayFileUploadEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_storagegateway_events_StorageGatewayObjectUploadEvent_StorageGatewayObjectUploadEventProps: function _aws_cdk_mixins_preview_aws_storagegateway_events_StorageGatewayObjectUploadEvent_StorageGatewayObjectUploadEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_storagegateway_events_StorageGatewayRefreshCacheEvent_StorageGatewayRefreshCacheEventProps: function _aws_cdk_mixins_preview_aws_storagegateway_events_StorageGatewayRefreshCacheEvent_StorageGatewayRefreshCacheEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange_SyntheticsCanaryStatusChangeProps: function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange_SyntheticsCanaryStatusChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunFailure_SyntheticsCanaryTestRunFailureProps: function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunFailure_SyntheticsCanaryTestRunFailureProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunSuccessful_SyntheticsCanaryTestRunSuccessfulProps: function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunSuccessful_SyntheticsCanaryTestRunSuccessfulProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transcribe_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_transcribe_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transcribe_events_CallAnalyticsJobStateChange_CallAnalyticsJobStateChangeProps: function _aws_cdk_mixins_preview_aws_transcribe_events_CallAnalyticsJobStateChange_CallAnalyticsJobStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transcribe_events_TranscribeJobStateChange_TranscribeJobStateChangeProps: function _aws_cdk_mixins_preview_aws_transcribe_events_TranscribeJobStateChange_TranscribeJobStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryCreateCompleted_FTPServerDirectoryCreateCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryCreateCompleted_FTPServerDirectoryCreateCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryCreateFailed_FTPServerDirectoryCreateFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryCreateFailed_FTPServerDirectoryCreateFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryDeleteCompleted_FTPServerDirectoryDeleteCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryDeleteCompleted_FTPServerDirectoryDeleteCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryDeleteFailed_FTPServerDirectoryDeleteFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryDeleteFailed_FTPServerDirectoryDeleteFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDeleteCompleted_FTPServerFileDeleteCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDeleteCompleted_FTPServerFileDeleteCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDeleteFailed_FTPServerFileDeleteFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDeleteFailed_FTPServerFileDeleteFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDownloadCompleted_FTPServerFileDownloadCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDownloadCompleted_FTPServerFileDownloadCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDownloadFailed_FTPServerFileDownloadFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDownloadFailed_FTPServerFileDownloadFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileRenameCompleted_FTPServerFileRenameCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileRenameCompleted_FTPServerFileRenameCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileRenameFailed_FTPServerFileRenameFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileRenameFailed_FTPServerFileRenameFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileUploadCompleted_FTPServerFileUploadCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileUploadCompleted_FTPServerFileUploadCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileUploadFailed_FTPServerFileUploadFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileUploadFailed_FTPServerFileUploadFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryCreateCompleted_FTPSServerDirectoryCreateCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryCreateCompleted_FTPSServerDirectoryCreateCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryCreateFailed_FTPSServerDirectoryCreateFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryCreateFailed_FTPSServerDirectoryCreateFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryDeleteCompleted_FTPSServerDirectoryDeleteCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryDeleteCompleted_FTPSServerDirectoryDeleteCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryDeleteFailed_FTPSServerDirectoryDeleteFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryDeleteFailed_FTPSServerDirectoryDeleteFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDeleteCompleted_FTPSServerFileDeleteCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDeleteCompleted_FTPSServerFileDeleteCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDeleteFailed_FTPSServerFileDeleteFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDeleteFailed_FTPSServerFileDeleteFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDownloadCompleted_FTPSServerFileDownloadCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDownloadCompleted_FTPSServerFileDownloadCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDownloadFailed_FTPSServerFileDownloadFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDownloadFailed_FTPSServerFileDownloadFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileRenameCompleted_FTPSServerFileRenameCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileRenameCompleted_FTPSServerFileRenameCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileRenameFailed_FTPSServerFileRenameFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileRenameFailed_FTPSServerFileRenameFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileUploadCompleted_FTPSServerFileUploadCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileUploadCompleted_FTPSServerFileUploadCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileUploadFailed_FTPSServerFileUploadFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileUploadFailed_FTPSServerFileUploadFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryCreateCompleted_SFTPServerDirectoryCreateCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryCreateCompleted_SFTPServerDirectoryCreateCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryCreateFailed_SFTPServerDirectoryCreateFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryCreateFailed_SFTPServerDirectoryCreateFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryDeleteCompleted_SFTPServerDirectoryDeleteCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryDeleteCompleted_SFTPServerDirectoryDeleteCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryDeleteFailed_SFTPServerDirectoryDeleteFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryDeleteFailed_SFTPServerDirectoryDeleteFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDeleteCompleted_SFTPServerFileDeleteCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDeleteCompleted_SFTPServerFileDeleteCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDeleteFailed_SFTPServerFileDeleteFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDeleteFailed_SFTPServerFileDeleteFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDownloadCompleted_SFTPServerFileDownloadCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDownloadCompleted_SFTPServerFileDownloadCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDownloadFailed_SFTPServerFileDownloadFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDownloadFailed_SFTPServerFileDownloadFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileRenameCompleted_SFTPServerFileRenameCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileRenameCompleted_SFTPServerFileRenameCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileRenameFailed_SFTPServerFileRenameFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileRenameFailed_SFTPServerFileRenameFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileUploadCompleted_SFTPServerFileUploadCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileUploadCompleted_SFTPServerFileUploadCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileUploadFailed_SFTPServerFileUploadFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileUploadFailed_SFTPServerFileUploadFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendCompleted_AS2MDNSendCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendCompleted_AS2MDNSendCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendFailed_AS2MDNSendFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendFailed_AS2MDNSendFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveCompleted_AS2PayloadReceiveCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveCompleted_AS2PayloadReceiveCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveFailed_AS2PayloadReceiveFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveFailed_AS2PayloadReceiveFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveCompleted_AS2MDNReceiveCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveCompleted_AS2MDNReceiveCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveFailed_AS2MDNReceiveFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveFailed_AS2MDNReceiveFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendCompleted_AS2PayloadSendCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendCompleted_AS2PayloadSendCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendFailed_AS2PayloadSendFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendFailed_AS2PayloadSendFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingCompleted_SFTPConnectorDirectoryListingCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingCompleted_SFTPConnectorDirectoryListingCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingFailed_SFTPConnectorDirectoryListingFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingFailed_SFTPConnectorDirectoryListingFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveCompleted_SFTPConnectorFileRetrieveCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveCompleted_SFTPConnectorFileRetrieveCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveFailed_SFTPConnectorFileRetrieveFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveFailed_SFTPConnectorFileRetrieveFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendCompleted_SFTPConnectorFileSendCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendCompleted_SFTPConnectorFileSendCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendFailed_SFTPConnectorFileSendFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendFailed_SFTPConnectorFileSendFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteDeleteCompleted_SFTPConnectorRemoteDeleteCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteDeleteCompleted_SFTPConnectorRemoteDeleteCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteDeleteFailed_SFTPConnectorRemoteDeleteFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteDeleteFailed_SFTPConnectorRemoteDeleteFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteMoveCompleted_SFTPConnectorRemoteMoveCompletedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteMoveCompleted_SFTPConnectorRemoteMoveCompletedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteMoveFailed_SFTPConnectorRemoteMoveFailedProps: function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteMoveFailed_SFTPConnectorRemoteMoveFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_translate_events_TranslateParallelDataStateChange_TranslateParallelDataStateChangeProps: function _aws_cdk_mixins_preview_aws_translate_events_TranslateParallelDataStateChange_TranslateParallelDataStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_translate_events_TranslateTextTranslationJobStateChange_TranslateTextTranslationJobStateChangeProps: function _aws_cdk_mixins_preview_aws_translate_events_TranslateTextTranslationJobStateChange_TranslateTextTranslationJobStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_VoiceIdBatchFraudsterRegistrationActionProps: function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_VoiceIdBatchFraudsterRegistrationActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_VoiceIdBatchSpeakerEnrollmentActionProps: function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_VoiceIdBatchSpeakerEnrollmentActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_VoiceIdEvaluateSessionActionProps: function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_VoiceIdEvaluateSessionActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdFraudsterAction_VoiceIdFraudsterActionProps: function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdFraudsterAction_VoiceIdFraudsterActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSessionSpeakerEnrollmentAction_VoiceIdSessionSpeakerEnrollmentActionProps: function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSessionSpeakerEnrollmentAction_VoiceIdSessionSpeakerEnrollmentActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction_VoiceIdSpeakerActionProps: function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction_VoiceIdSpeakerActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_VoiceIdStartSessionActionProps: function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_VoiceIdStartSessionActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_VoiceIdUpdateSessionActionProps: function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_VoiceIdUpdateSessionActionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_wellarchitected_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_wellarchitected_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsS3Props: function _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_workspaces_events_WorkSpacesAccess_WorkSpacesAccessProps: function _aws_cdk_mixins_preview_aws_workspaces_events_WorkSpacesAccess_WorkSpacesAccessProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_AWSXRayInsightUpdateProps: function _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_AWSXRayInsightUpdateProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventMetadata))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AWSEventMetadataProps(p.eventMetadata);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.topAnomalousServices != null)
                for (const o of p.topAnomalousServices)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_AwsxRayInsightUpdateItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
