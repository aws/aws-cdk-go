"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateAll = generateAll;
const spec2cdk_1 = require("@aws-cdk/spec2cdk");
const builder_1 = require("./builder");
const config_1 = require("../config");
const module_topology_1 = require("@aws-cdk/spec2cdk/lib/module-topology");
const db_1 = require("@aws-cdk/spec2cdk/lib/util/db");
async function generateAll(options) {
    const db = await (0, spec2cdk_1.loadPatchedSpec)();
    const services = (0, db_1.getAllServices)(db, options.orgs);
    const moduleMap = (0, module_topology_1.loadModuleMap)({
        packageBases: config_1.MIXINS_PREVIEW_BASE_NAMES,
        respectOverrides: false,
    });
    const moduleRequests = {};
    for (const service of services) {
        if (moduleMap[service.name]) {
            moduleRequests[service.name] = {
                services: [{ namespace: service.cloudFormationNamespace }],
            };
        }
    }
    const generated = await (0, spec2cdk_1.generate)(moduleRequests, {
        ...options,
        db,
        astBuilder: builder_1.EventBridgeBuilder,
    });
    return {
        moduleMap: Object.fromEntries(Object.entries(generated.modules).map(([moduleName, moduleInfo]) => [
            moduleName,
            {
                files: moduleInfo.outputFiles,
                name: moduleName,
                resources: moduleInfo.resources,
                scopes: moduleMap[moduleName]?.scopes ?? [],
                definition: moduleMap[moduleName]?.definition,
                targets: moduleMap[moduleName]?.targets,
            },
        ])),
        contributions: [{
                barrelFile: 'events.ts',
                exportLines: ["export * from './events.generated';"],
                jsiircNamespace: 'events',
            }],
    };
}
