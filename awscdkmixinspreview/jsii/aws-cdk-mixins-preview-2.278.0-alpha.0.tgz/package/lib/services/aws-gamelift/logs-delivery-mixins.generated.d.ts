import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-gamelift";
/**
 * Builder for CfnGameSessionQueueLogsMixin to generate QUEUE_PLACEMENT_LOGS for CfnGameSessionQueue
 *
 * @cloudformationResource AWS::GameLift::GameSessionQueue
 * @logType QUEUE_PLACEMENT_LOGS
 * @stability external
 */
export declare class CfnGameSessionQueueQueuePlacementLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnGameSessionQueueQueuePlacementLogsS3Props): CfnGameSessionQueueLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnGameSessionQueueQueuePlacementLogsLogGroupProps): CfnGameSessionQueueLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnGameSessionQueueQueuePlacementLogsFirehoseProps): CfnGameSessionQueueLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnGameSessionQueueQueuePlacementLogsDestProps): CfnGameSessionQueueLogsMixin;
}
/**
 * The `AWS::GameLift::GameSessionQueue` resource creates a placement queue that processes requests for new game sessions.
 *
 * A queue uses FleetIQ algorithms to determine the best placement locations and find an available game server, then prompts the game server to start a new game session. Queues can have destinations (GameLift fleets or aliases), which determine where the queue can place new game sessions. A queue can have destinations with varied fleet type (Spot and On-Demand), instance type, and AWS Region .
 *
 * @cloudformationResource AWS::GameLift::GameSessionQueue
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-gamelift-gamesessionqueue.html
 */
export declare class CfnGameSessionQueueLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly QUEUE_PLACEMENT_LOGS: CfnGameSessionQueueQueuePlacementLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::GameLift::GameSessionQueue`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnGameSessionQueue;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnGameSessionQueueQueuePlacementLogs.
 */
export declare class CfnGameSessionQueueQueuePlacementLogsOutputFormat {
}
export declare namespace CfnGameSessionQueueQueuePlacementLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnGameSessionQueueQueuePlacementLogsRecordFields {
    TIMESTAMP = "timestamp",
    PLACEMENT_ID = "placement_id",
    EVENT_TYPE = "event_type",
    SUMMARY = "summary",
    DATA = "data",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnGameSessionQueueQueuePlacementLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnGameSessionQueueQueuePlacementLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGameSessionQueueQueuePlacementLogsRecordFields>;
}
export interface CfnGameSessionQueueQueuePlacementLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnGameSessionQueueQueuePlacementLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGameSessionQueueQueuePlacementLogsRecordFields>;
}
export interface CfnGameSessionQueueQueuePlacementLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnGameSessionQueueQueuePlacementLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGameSessionQueueQueuePlacementLogsRecordFields>;
}
export interface CfnGameSessionQueueQueuePlacementLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGameSessionQueueQueuePlacementLogsRecordFields>;
}
