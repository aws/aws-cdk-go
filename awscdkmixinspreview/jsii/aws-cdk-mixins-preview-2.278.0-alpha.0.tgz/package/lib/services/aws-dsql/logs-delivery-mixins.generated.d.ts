import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-dsql";
/**
 * Builder for CfnClusterLogsMixin to generate AUDIT_LOGS for CfnCluster
 *
 * @cloudformationResource AWS::DSQL::Cluster
 * @logType AUDIT_LOGS
 * @stability external
 */
export declare class CfnClusterAuditLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnClusterAuditLogsS3Props): CfnClusterLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnClusterAuditLogsDestProps): CfnClusterLogsMixin;
}
/**
 * The `AWS::DSQL::Cluster` resource specifies an cluster. You can use this resource to create, modify, and manage clusters.
 *
 * This resource supports both single-Region clusters and multi-Region clusters through the `MultiRegionProperties` parameter.
 *
 * > Creating multi-Region clusters requires additional IAM permissions beyond those needed for single-Region clusters. > - The witness Region specified in `multiRegionProperties.witnessRegion` cannot be the same as the cluster's Region.
 *
 * *Required permissions*
 *
 * - **dsql:CreateCluster** - Required to create a cluster.
 *
 * Resources: `arn:aws:dsql:region:account-id:cluster/*`
 * - **dsql:TagResource** - Permission to add tags to a resource.
 *
 * Resources: `arn:aws:dsql:region:account-id:cluster/*`
 * - **dsql:PutMultiRegionProperties** - Permission to configure multi-Region properties for a cluster.
 *
 * Resources: `arn:aws:dsql:region:account-id:cluster/*`
 * - **dsql:AddPeerCluster** - When specifying `multiRegionProperties.clusters` , permission to add peer clusters.
 *
 * Resources:
 *
 * - Local cluster: `arn:aws:dsql:region:account-id:cluster/*`
 * - Each peer cluster: exact ARN of each specified peer cluster
 * - **dsql:PutWitnessRegion** - When specifying `multiRegionProperties.witnessRegion` , permission to set a witness Region. This permission is checked both in the cluster Region and in the witness Region.
 *
 * Resources: `arn:aws:dsql:region:account-id:cluster/*`
 *
 * Condition Keys: `dsql:WitnessRegion` (matching the specified witness region)
 *
 * @cloudformationResource AWS::DSQL::Cluster
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dsql-cluster.html
 */
export declare class CfnClusterLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly AUDIT_LOGS: CfnClusterAuditLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::DSQL::Cluster`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCluster;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnClusterAuditLogs.
 */
export declare class CfnClusterAuditLogsOutputFormat {
}
export declare namespace CfnClusterAuditLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
}
export declare enum CfnClusterAuditLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    RESOURCE_ID = "resource_id",
    SCHEMA_VERSION = "schema_version",
    AWS_REGION = "aws_region",
    CLUSTER_ID = "cluster_id",
    TYPE = "type",
    DATABASE = "database",
    SESSION_ID = "session_id",
    IAM_PRINCIPAL = "iam_principal",
    IAM_ARN = "iam_arn",
    SESSION_USER = "session_user",
    USER_ID = "user_id",
    CLIENT_APPLICATION = "client_application",
    TRANSACTION_ID = "transaction_id",
    STATEMENT_ID = "statement_id",
    SUBSTATEMENT_ID = "substatement_id",
    CLASS = "class",
    COMMAND = "command",
    OBJECT_TYPE = "object_type",
    OBJECT_NAME = "object_name",
    STATEMENT_TEXT = "statement_text",
    PARAMETERS = "parameters",
    ROWS_AFFECTED = "rows_affected"
}
export interface CfnClusterAuditLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnClusterAuditLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAuditLogsRecordFields>;
}
export interface CfnClusterAuditLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAuditLogsRecordFields>;
}
