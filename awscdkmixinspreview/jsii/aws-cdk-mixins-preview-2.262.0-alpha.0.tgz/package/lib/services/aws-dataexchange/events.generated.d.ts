import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.dataexchange@DataSetUpdateDelayed
 */
export declare class DataSetUpdateDelayed {
    /**
     * EventBridge event pattern for Data Set Update Delayed
     */
    static eventPattern(options?: DataSetUpdateDelayed.DataSetUpdateDelayedProps): events.EventPattern;
}
export declare namespace DataSetUpdateDelayed {
    /**
     * Props type for aws.dataexchange@DataSetUpdateDelayed event
     */
    interface DataSetUpdateDelayedProps {
        /**
         * DataSet property
         *
         * Specify an array of string values to match this event if the actual value of DataSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSet?: DataSetUpdateDelayed.DataSet;
        /**
         * Notification property
         *
         * Specify an array of string values to match this event if the actual value of Notification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notification?: DataSetUpdateDelayed.Notification;
        /**
         * Product property
         *
         * Specify an array of string values to match this event if the actual value of Product is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly product?: DataSetUpdateDelayed.Product;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for DataSet
     *
     * @struct
     */
    interface DataSet {
        /**
         * AssetType property
         *
         * Specify an array of string values to match this event if the actual value of AssetType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly assetType?: Array<string>;
        /**
         * Id property
         *
         * Specify an array of string values to match this event if the actual value of Id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * Name property
         *
         * Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Notification
     *
     * @struct
     */
    interface Notification {
        /**
         * Scope property
         *
         * Specify an array of string values to match this event if the actual value of Scope is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scope?: DataSetUpdateDelayed.Scope;
        /**
         * Comment property
         *
         * Specify an array of string values to match this event if the actual value of Comment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly comment?: Array<string>;
        /**
         * Type property
         *
         * Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Scope
     *
     * @struct
     */
    interface Scope {
        /**
         * LakeFormationTagPolicies property
         *
         * Specify an array of string values to match this event if the actual value of LakeFormationTagPolicies is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lakeFormationTagPolicies?: Array<DataSetUpdateDelayed.LakeFormationTagPolicyDetails>;
        /**
         * RedshiftDataShares property
         *
         * Specify an array of string values to match this event if the actual value of RedshiftDataShares is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly redshiftDataShares?: Array<DataSetUpdateDelayed.RedshiftDataShareDetails>;
        /**
         * S3DataAccesses property
         *
         * Specify an array of string values to match this event if the actual value of S3DataAccesses is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataAccesses?: Array<DataSetUpdateDelayed.S3DataAccessDetails>;
    }
    /**
     * Type definition for LakeFormationTagPolicyDetails
     *
     * @struct
     */
    interface LakeFormationTagPolicyDetails {
        /**
         * Database property
         *
         * Specify an array of string values to match this event if the actual value of Database is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly database?: Array<string>;
        /**
         * Table property
         *
         * Specify an array of string values to match this event if the actual value of Table is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly table?: Array<string>;
    }
    /**
     * Type definition for RedshiftDataShareDetails
     *
     * @struct
     */
    interface RedshiftDataShareDetails {
        /**
         * Arn property
         *
         * Specify an array of string values to match this event if the actual value of Arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * Database property
         *
         * Specify an array of string values to match this event if the actual value of Database is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly database?: Array<string>;
        /**
         * Function property
         *
         * Specify an array of string values to match this event if the actual value of Function is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly function?: Array<string>;
        /**
         * Table property
         *
         * Specify an array of string values to match this event if the actual value of Table is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly table?: Array<string>;
        /**
         * View property
         *
         * Specify an array of string values to match this event if the actual value of View is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly view?: Array<string>;
    }
    /**
     * Type definition for S3DataAccessDetails
     *
     * @struct
     */
    interface S3DataAccessDetails {
        /**
         * KeyPrefixes property
         *
         * Specify an array of string values to match this event if the actual value of KeyPrefixes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly keyPrefixes?: Array<string>;
        /**
         * Keys property
         *
         * Specify an array of string values to match this event if the actual value of Keys is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly keys?: Array<string>;
    }
    /**
     * Type definition for Product
     *
     * @struct
     */
    interface Product {
        /**
         * Id property
         *
         * Specify an array of string values to match this event if the actual value of Id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * Name property
         *
         * Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * ProviderContact property
         *
         * Specify an array of string values to match this event if the actual value of ProviderContact is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly providerContact?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.dataexchange@DataUpdatedInDataSet
 */
export declare class DataUpdatedInDataSet {
    /**
     * EventBridge event pattern for Data Updated in Data Set
     */
    static eventPattern(options?: DataUpdatedInDataSet.DataUpdatedInDataSetProps): events.EventPattern;
}
export declare namespace DataUpdatedInDataSet {
    /**
     * Props type for aws.dataexchange@DataUpdatedInDataSet event
     */
    interface DataUpdatedInDataSetProps {
        /**
         * DataSet property
         *
         * Specify an array of string values to match this event if the actual value of DataSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSet?: DataUpdatedInDataSet.DataSet;
        /**
         * Notification property
         *
         * Specify an array of string values to match this event if the actual value of Notification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notification?: DataUpdatedInDataSet.Notification;
        /**
         * Product property
         *
         * Specify an array of string values to match this event if the actual value of Product is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly product?: DataUpdatedInDataSet.Product;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for DataSet
     *
     * @struct
     */
    interface DataSet {
        /**
         * AssetType property
         *
         * Specify an array of string values to match this event if the actual value of AssetType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly assetType?: Array<string>;
        /**
         * Id property
         *
         * Specify an array of string values to match this event if the actual value of Id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * Name property
         *
         * Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Notification
     *
     * @struct
     */
    interface Notification {
        /**
         * Details property
         *
         * Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly details?: DataUpdatedInDataSet.Details;
        /**
         * Scope property
         *
         * Specify an array of string values to match this event if the actual value of Scope is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scope?: DataUpdatedInDataSet.Scope;
        /**
         * Comment property
         *
         * Specify an array of string values to match this event if the actual value of Comment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly comment?: Array<string>;
        /**
         * Type property
         *
         * Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Details
     *
     * @struct
     */
    interface Details {
        /**
         * DataUpdate property
         *
         * Specify an array of string values to match this event if the actual value of DataUpdate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataUpdate?: DataUpdatedInDataSet.DataUpdate;
    }
    /**
     * Type definition for DataUpdate
     *
     * @struct
     */
    interface DataUpdate {
        /**
         * DataUpdatedAt property
         *
         * Specify an array of string values to match this event if the actual value of DataUpdatedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataUpdatedAt?: Array<string>;
    }
    /**
     * Type definition for Scope
     *
     * @struct
     */
    interface Scope {
        /**
         * LakeFormationTagPolicies property
         *
         * Specify an array of string values to match this event if the actual value of LakeFormationTagPolicies is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lakeFormationTagPolicies?: Array<DataUpdatedInDataSet.LakeFormationTagPolicyDetails>;
        /**
         * RedshiftDataShares property
         *
         * Specify an array of string values to match this event if the actual value of RedshiftDataShares is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly redshiftDataShares?: Array<DataUpdatedInDataSet.RedshiftDataShareDetails>;
        /**
         * S3DataAccesses property
         *
         * Specify an array of string values to match this event if the actual value of S3DataAccesses is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataAccesses?: Array<DataUpdatedInDataSet.S3DataAccessDetails>;
    }
    /**
     * Type definition for LakeFormationTagPolicyDetails
     *
     * @struct
     */
    interface LakeFormationTagPolicyDetails {
        /**
         * Database property
         *
         * Specify an array of string values to match this event if the actual value of Database is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly database?: Array<string>;
        /**
         * Table property
         *
         * Specify an array of string values to match this event if the actual value of Table is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly table?: Array<string>;
    }
    /**
     * Type definition for RedshiftDataShareDetails
     *
     * @struct
     */
    interface RedshiftDataShareDetails {
        /**
         * Arn property
         *
         * Specify an array of string values to match this event if the actual value of Arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * Database property
         *
         * Specify an array of string values to match this event if the actual value of Database is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly database?: Array<string>;
        /**
         * Function property
         *
         * Specify an array of string values to match this event if the actual value of Function is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly function?: Array<string>;
        /**
         * Schema property
         *
         * Specify an array of string values to match this event if the actual value of Schema is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly schema?: Array<string>;
        /**
         * View property
         *
         * Specify an array of string values to match this event if the actual value of View is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly view?: Array<string>;
    }
    /**
     * Type definition for S3DataAccessDetails
     *
     * @struct
     */
    interface S3DataAccessDetails {
        /**
         * KeyPrefixes property
         *
         * Specify an array of string values to match this event if the actual value of KeyPrefixes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly keyPrefixes?: Array<string>;
        /**
         * Keys property
         *
         * Specify an array of string values to match this event if the actual value of Keys is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly keys?: Array<string>;
    }
    /**
     * Type definition for Product
     *
     * @struct
     */
    interface Product {
        /**
         * Id property
         *
         * Specify an array of string values to match this event if the actual value of Id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * Name property
         *
         * Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * ProviderContact property
         *
         * Specify an array of string values to match this event if the actual value of ProviderContact is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly providerContact?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.dataexchange@DeprecationPlannedForDataSet
 */
export declare class DeprecationPlannedForDataSet {
    /**
     * EventBridge event pattern for Deprecation Planned for Data Set
     */
    static eventPattern(options?: DeprecationPlannedForDataSet.DeprecationPlannedForDataSetProps): events.EventPattern;
}
export declare namespace DeprecationPlannedForDataSet {
    /**
     * Props type for aws.dataexchange@DeprecationPlannedForDataSet event
     */
    interface DeprecationPlannedForDataSetProps {
        /**
         * DataSet property
         *
         * Specify an array of string values to match this event if the actual value of DataSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSet?: DeprecationPlannedForDataSet.DataSet;
        /**
         * Notification property
         *
         * Specify an array of string values to match this event if the actual value of Notification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notification?: DeprecationPlannedForDataSet.Notification;
        /**
         * Product property
         *
         * Specify an array of string values to match this event if the actual value of Product is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly product?: DeprecationPlannedForDataSet.Product;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for DataSet
     *
     * @struct
     */
    interface DataSet {
        /**
         * AssetType property
         *
         * Specify an array of string values to match this event if the actual value of AssetType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly assetType?: Array<string>;
        /**
         * Id property
         *
         * Specify an array of string values to match this event if the actual value of Id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * Name property
         *
         * Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Notification
     *
     * @struct
     */
    interface Notification {
        /**
         * Details property
         *
         * Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly details?: DeprecationPlannedForDataSet.Details;
        /**
         * Scope property
         *
         * Specify an array of string values to match this event if the actual value of Scope is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scope?: DeprecationPlannedForDataSet.Scope;
        /**
         * Comment property
         *
         * Specify an array of string values to match this event if the actual value of Comment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly comment?: Array<string>;
        /**
         * Type property
         *
         * Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Details
     *
     * @struct
     */
    interface Details {
        /**
         * Deprecation property
         *
         * Specify an array of string values to match this event if the actual value of Deprecation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deprecation?: DeprecationPlannedForDataSet.Deprecation;
    }
    /**
     * Type definition for Deprecation
     *
     * @struct
     */
    interface Deprecation {
        /**
         * DeprecationAt property
         *
         * Specify an array of string values to match this event if the actual value of DeprecationAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deprecationAt?: Array<string>;
    }
    /**
     * Type definition for Scope
     *
     * @struct
     */
    interface Scope {
        /**
         * LakeFormationTagPolicies property
         *
         * Specify an array of string values to match this event if the actual value of LakeFormationTagPolicies is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lakeFormationTagPolicies?: Array<DeprecationPlannedForDataSet.LakeFormationTagPolicyDetails>;
        /**
         * RedshiftDataShares property
         *
         * Specify an array of string values to match this event if the actual value of RedshiftDataShares is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly redshiftDataShares?: Array<DeprecationPlannedForDataSet.RedshiftDataShareDetails>;
        /**
         * S3DataAccesses property
         *
         * Specify an array of string values to match this event if the actual value of S3DataAccesses is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataAccesses?: Array<DeprecationPlannedForDataSet.S3DataAccessDetails>;
    }
    /**
     * Type definition for LakeFormationTagPolicyDetails
     *
     * @struct
     */
    interface LakeFormationTagPolicyDetails {
        /**
         * Database property
         *
         * Specify an array of string values to match this event if the actual value of Database is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly database?: Array<string>;
        /**
         * Table property
         *
         * Specify an array of string values to match this event if the actual value of Table is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly table?: Array<string>;
    }
    /**
     * Type definition for RedshiftDataShareDetails
     *
     * @struct
     */
    interface RedshiftDataShareDetails {
        /**
         * Arn property
         *
         * Specify an array of string values to match this event if the actual value of Arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * Database property
         *
         * Specify an array of string values to match this event if the actual value of Database is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly database?: Array<string>;
        /**
         * Function property
         *
         * Specify an array of string values to match this event if the actual value of Function is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly function?: Array<string>;
        /**
         * Schema property
         *
         * Specify an array of string values to match this event if the actual value of Schema is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly schema?: Array<string>;
        /**
         * Table property
         *
         * Specify an array of string values to match this event if the actual value of Table is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly table?: Array<string>;
        /**
         * View property
         *
         * Specify an array of string values to match this event if the actual value of View is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly view?: Array<string>;
    }
    /**
     * Type definition for S3DataAccessDetails
     *
     * @struct
     */
    interface S3DataAccessDetails {
        /**
         * KeyPrefixes property
         *
         * Specify an array of string values to match this event if the actual value of KeyPrefixes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly keyPrefixes?: Array<string>;
        /**
         * Keys property
         *
         * Specify an array of string values to match this event if the actual value of Keys is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly keys?: Array<string>;
    }
    /**
     * Type definition for Product
     *
     * @struct
     */
    interface Product {
        /**
         * Id property
         *
         * Specify an array of string values to match this event if the actual value of Id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * Name property
         *
         * Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * ProviderContact property
         *
         * Specify an array of string values to match this event if the actual value of ProviderContact is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly providerContact?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.dataexchange@SchemaChangePlannedForDataSet
 */
export declare class SchemaChangePlannedForDataSet {
    /**
     * EventBridge event pattern for Schema Change Planned for Data Set
     */
    static eventPattern(options?: SchemaChangePlannedForDataSet.SchemaChangePlannedForDataSetProps): events.EventPattern;
}
export declare namespace SchemaChangePlannedForDataSet {
    /**
     * Props type for aws.dataexchange@SchemaChangePlannedForDataSet event
     */
    interface SchemaChangePlannedForDataSetProps {
        /**
         * DataSet property
         *
         * Specify an array of string values to match this event if the actual value of DataSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSet?: SchemaChangePlannedForDataSet.DataSet;
        /**
         * Notification property
         *
         * Specify an array of string values to match this event if the actual value of Notification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notification?: SchemaChangePlannedForDataSet.Notification;
        /**
         * Product property
         *
         * Specify an array of string values to match this event if the actual value of Product is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly product?: SchemaChangePlannedForDataSet.Product;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for DataSet
     *
     * @struct
     */
    interface DataSet {
        /**
         * AssetType property
         *
         * Specify an array of string values to match this event if the actual value of AssetType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly assetType?: Array<string>;
        /**
         * Id property
         *
         * Specify an array of string values to match this event if the actual value of Id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * Name property
         *
         * Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Notification
     *
     * @struct
     */
    interface Notification {
        /**
         * Details property
         *
         * Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly details?: SchemaChangePlannedForDataSet.Details;
        /**
         * Scope property
         *
         * Specify an array of string values to match this event if the actual value of Scope is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scope?: SchemaChangePlannedForDataSet.Scope;
        /**
         * Comment property
         *
         * Specify an array of string values to match this event if the actual value of Comment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly comment?: Array<string>;
        /**
         * Type property
         *
         * Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Details
     *
     * @struct
     */
    interface Details {
        /**
         * SchemaChange property
         *
         * Specify an array of string values to match this event if the actual value of SchemaChange is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly schemaChange?: SchemaChangePlannedForDataSet.SchemaChange;
    }
    /**
     * Type definition for SchemaChange
     *
     * @struct
     */
    interface SchemaChange {
        /**
         * Changes property
         *
         * Specify an array of string values to match this event if the actual value of Changes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly changes?: Array<SchemaChangePlannedForDataSet.SchemaChangeItem>;
        /**
         * SchemaChangeAt property
         *
         * Specify an array of string values to match this event if the actual value of SchemaChangeAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly schemaChangeAt?: Array<string>;
    }
    /**
     * Type definition for SchemaChangeItem
     *
     * @struct
     */
    interface SchemaChangeItem {
        /**
         * Description property
         *
         * Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * Name property
         *
         * Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * Type property
         *
         * Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Scope
     *
     * @struct
     */
    interface Scope {
        /**
         * LakeFormationTagPolicies property
         *
         * Specify an array of string values to match this event if the actual value of LakeFormationTagPolicies is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lakeFormationTagPolicies?: Array<SchemaChangePlannedForDataSet.LakeFormationTagPolicyDetails>;
        /**
         * RedshiftDataShares property
         *
         * Specify an array of string values to match this event if the actual value of RedshiftDataShares is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly redshiftDataShares?: Array<SchemaChangePlannedForDataSet.RedshiftDataShareDetails>;
        /**
         * S3DataAccesses property
         *
         * Specify an array of string values to match this event if the actual value of S3DataAccesses is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataAccesses?: Array<SchemaChangePlannedForDataSet.S3DataAccessDetails>;
    }
    /**
     * Type definition for LakeFormationTagPolicyDetails
     *
     * @struct
     */
    interface LakeFormationTagPolicyDetails {
        /**
         * Database property
         *
         * Specify an array of string values to match this event if the actual value of Database is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly database?: Array<string>;
        /**
         * Table property
         *
         * Specify an array of string values to match this event if the actual value of Table is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly table?: Array<string>;
    }
    /**
     * Type definition for RedshiftDataShareDetails
     *
     * @struct
     */
    interface RedshiftDataShareDetails {
        /**
         * Arn property
         *
         * Specify an array of string values to match this event if the actual value of Arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * Database property
         *
         * Specify an array of string values to match this event if the actual value of Database is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly database?: Array<string>;
        /**
         * Function property
         *
         * Specify an array of string values to match this event if the actual value of Function is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly function?: Array<string>;
        /**
         * Schema property
         *
         * Specify an array of string values to match this event if the actual value of Schema is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly schema?: Array<string>;
        /**
         * Table property
         *
         * Specify an array of string values to match this event if the actual value of Table is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly table?: Array<string>;
        /**
         * View property
         *
         * Specify an array of string values to match this event if the actual value of View is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly view?: Array<string>;
    }
    /**
     * Type definition for S3DataAccessDetails
     *
     * @struct
     */
    interface S3DataAccessDetails {
        /**
         * KeyPrefixes property
         *
         * Specify an array of string values to match this event if the actual value of KeyPrefixes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly keyPrefixes?: Array<string>;
        /**
         * Keys property
         *
         * Specify an array of string values to match this event if the actual value of Keys is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly keys?: Array<string>;
    }
    /**
     * Type definition for Product
     *
     * @struct
     */
    interface Product {
        /**
         * Id property
         *
         * Specify an array of string values to match this event if the actual value of Id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * Name property
         *
         * Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * ProviderContact property
         *
         * Specify an array of string values to match this event if the actual value of ProviderContact is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly providerContact?: Array<string>;
    }
}
