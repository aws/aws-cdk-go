/**
 * ATTENTION: these functions are partly copied from the aws-cdk-lib package, because
 * they are not exported from there. Before mixins goes GA, vended logs should be
 * updated to use resource traits instead and duplicate reflections removed.
 */
import type { IConstruct } from 'constructs';
import type { CfnBucketPolicy } from 'aws-cdk-lib/aws-s3';
import { type IBucketRef } from 'aws-cdk-lib/aws-s3';
import type { CfnDeliverySource } from 'aws-cdk-lib/aws-logs';
import type { CfnKey, IKeyRef } from 'aws-cdk-lib/aws-kms';
/**
 * Attempts to find an existing bucket policy for the specified S3 bucket.
 * Finds the closest matching policy to the specified bucket.
 *
 * @param bucket - The S3 bucket reference to search for an associated bucket policy
 * @returns The bucket policy if found, undefined otherwise
 */
export declare function tryFindBucketPolicyForBucket(bucket: IBucketRef): CfnBucketPolicy | undefined;
export declare function tryFindDeliverySourceForResource(source: IConstruct, sourceArn: string, logType: string): CfnDeliverySource | undefined;
export declare function tryFindKmsKeyforBucket(bucket: IBucketRef): CfnKey | undefined;
export declare function tryFindKmsKeyConstruct(kmsKey: IKeyRef): CfnKey | undefined;
