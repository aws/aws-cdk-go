import * as logs from 'aws-cdk-lib/aws-logs';
import * as s3 from 'aws-cdk-lib/aws-s3';
import type { Construct } from 'constructs';
import type { IKeyRef } from 'aws-cdk-lib/aws-kms';
import type { IDeliveryStreamRef } from 'aws-cdk-lib/aws-kinesisfirehose';
import { S3LogsDeliveryPermissionsVersion } from './logs-delivery';
/**
 * Properties that are shared between most delivery destinations
 */
interface DeliveryDestinationProps {
    /**
     * Format of the logs that are sent to this delivery destination
     */
    readonly outputFormat?: string;
}
/**
 * Properties for Delivery Destinations the participate in Cross Account Delivery
 */
interface CrossAccountDestinationProps extends DeliveryDestinationProps {
    /**
     * Optional acount id for account the delivery source is in for cross account Vended Logs
     */
    readonly sourceAccountId?: string;
}
/**
 * Properties for S3 delivery destination.
 */
export interface S3DeliveryDestinationProps extends CrossAccountDestinationProps {
    /**
     * The S3 bucket to deliver logs to.
     */
    readonly bucket: s3.IBucketRef;
    /**
     * The permissions version ('V1' or 'V2') to be used for this delivery.
     * Depending on the source of the logs, different permissions are required.
     *
     * @default "V2"
     */
    readonly permissionsVersion?: S3LogsDeliveryPermissionsVersion;
    /**
     * KMS key to use for encrypting logs in the S3 bucket.
     * When provided, grants the logs delivery service permissions to use the key.
     *
     * @default - No encryption key is configured
     */
    readonly encryptionKey?: IKeyRef;
}
/**
 * Properties for Firehose delivery destination
 */
export interface FirehoseDeliveryDestinationProps extends CrossAccountDestinationProps {
    /**
     * Delivery stream to delivery logs to
     */
    readonly deliveryStream: IDeliveryStreamRef;
}
/**
 * Properties for Cloudwatch delivery destination
 */
export interface CloudwatchDeliveryDestinationProps extends DeliveryDestinationProps {
    /**
     * Log group to deliver logs to
     */
    readonly logGroup: logs.ILogGroupRef;
}
/**
 * Properties for XRay delivery destination
 */
export interface XRayDeliveryDestinationProps {
    /**
     * Arn of the source resource
     */
    readonly sourceResource: string;
}
/**
 * Creates an S3 delivery destination for CloudWatch Logs.
 */
export declare class S3DeliveryDestination extends logs.CfnDeliveryDestination {
    private readonly bucket;
    private readonly permissions;
    private readonly kmsKey;
    private readonly sourceAccount;
    constructor(scope: Construct, id: string, props: S3DeliveryDestinationProps);
    /**
     * Gets or creates a bucket policy for the S3 destination Bucket.
     * @param scope - The construct scope
     * @returns The bucket policy
     */
    private getOrCreateBucketPolicy;
    /**
     * Grants permissions for log delivery to the bucket policy.
     * @param policy - The bucket policy
     */
    private grantLogsDelivery;
    private findEncryptionKey;
    private addToEncryptionKeyPolicy;
}
/**
 * Firehose delivery destination for CloudWatch Logs.
 */
export declare class FirehoseDeliveryDestination extends logs.CfnDeliveryDestination {
    constructor(scope: Construct, id: string, props: FirehoseDeliveryDestinationProps);
}
/**
 * CloudWatch delivery destination for CloudWatch Logs.
 */
export declare class CloudwatchDeliveryDestination extends logs.CfnDeliveryDestination {
    private readonly logGroup;
    constructor(scope: Construct, id: string, props: CloudwatchDeliveryDestinationProps);
    /**
     * Gets or creates a singleton Logs Resource Policy.
     * @param scope - The construct scope
     * @returns The resource policy
     */
    private getOrCreateLogsResourcePolicy;
    /**
     * Grants permissions for log delivery to the resource policy.
     * @param policy - The resource policy
     */
    private grantLogsDelivery;
}
/**
 * XRay delivery destination for XRay traces.
 */
export declare class XRayDeliveryDestination extends logs.CfnDeliveryDestination {
    constructor(scope: Construct, id: string, props: XRayDeliveryDestinationProps);
    /**
     * Gets or creates a singleton X-Ray resource policy.
     *
     * @param scope - The construct scope
     * @returns The X-Ray resource policy
     */
    private getOrCreateResourcePolicy;
    /**
     * Grants permissions for log delivery to resource policy.
     * @param policy - The resource policy
     */
    private grantLogsDelivery;
}
export {};
