import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.transcribe@AWSAPICallViaCloudTrail
 */
export declare class AWSAPICallViaCloudTrail {
    /**
     * EventBridge event pattern for AWS API Call via CloudTrail
     */
    static eventPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
}
export declare namespace AWSAPICallViaCloudTrail {
    /**
     * Props type for aws.transcribe@AWSAPICallViaCloudTrail event
     */
    interface AWSAPICallViaCloudTrailProps {
        /**
         * requestParameters property
         *
         * Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestParameters?: AWSAPICallViaCloudTrail.RequestParameters;
        /**
         * responseElements property
         *
         * Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly responseElements?: AWSAPICallViaCloudTrail.ResponseElements;
        /**
         * userIdentity property
         *
         * Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userIdentity?: AWSAPICallViaCloudTrail.UserIdentity;
        /**
         * awsRegion property
         *
         * Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsRegion?: Array<string>;
        /**
         * eventID property
         *
         * Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * eventSource property
         *
         * Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventSource?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * eventVersion property
         *
         * Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventVersion?: Array<string>;
        /**
         * requestID property
         *
         * Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * sourceIPAddress property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for RequestParameters
     *
     * @struct
     */
    interface RequestParameters {
        /**
         * media property
         *
         * Specify an array of string values to match this event if the actual value of media is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly media?: AWSAPICallViaCloudTrail.Media;
        /**
         * settings property
         *
         * Specify an array of string values to match this event if the actual value of settings is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly settings?: AWSAPICallViaCloudTrail.Settings;
        /**
         * languageCode property
         *
         * Specify an array of string values to match this event if the actual value of languageCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly languageCode?: Array<string>;
        /**
         * mediaFormat property
         *
         * Specify an array of string values to match this event if the actual value of mediaFormat is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mediaFormat?: Array<string>;
        /**
         * mediaSampleRateHertz property
         *
         * Specify an array of string values to match this event if the actual value of mediaSampleRateHertz is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mediaSampleRateHertz?: Array<string>;
        /**
         * transcriptionJobName property
         *
         * Specify an array of string values to match this event if the actual value of transcriptionJobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transcriptionJobName?: Array<string>;
        /**
         * vocabularyName property
         *
         * Specify an array of string values to match this event if the actual value of vocabularyName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vocabularyName?: Array<string>;
    }
    /**
     * Type definition for Media
     *
     * @struct
     */
    interface Media {
        /**
         * mediaFileUri property
         *
         * Specify an array of string values to match this event if the actual value of mediaFileUri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mediaFileUri?: Array<string>;
    }
    /**
     * Type definition for Settings
     *
     * @struct
     */
    interface Settings {
        /**
         * channelIdentification property
         *
         * Specify an array of string values to match this event if the actual value of channelIdentification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelIdentification?: Array<string>;
        /**
         * vocabularyName property
         *
         * Specify an array of string values to match this event if the actual value of vocabularyName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vocabularyName?: Array<string>;
    }
    /**
     * Type definition for ResponseElements
     *
     * @struct
     */
    interface ResponseElements {
        /**
         * transcriptionJob property
         *
         * Specify an array of string values to match this event if the actual value of transcriptionJob is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transcriptionJob?: AWSAPICallViaCloudTrail.TranscriptionJob;
        /**
         * languageCode property
         *
         * Specify an array of string values to match this event if the actual value of languageCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly languageCode?: Array<string>;
        /**
         * vocabularyName property
         *
         * Specify an array of string values to match this event if the actual value of vocabularyName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vocabularyName?: Array<string>;
        /**
         * vocabularyState property
         *
         * Specify an array of string values to match this event if the actual value of vocabularyState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vocabularyState?: Array<string>;
    }
    /**
     * Type definition for TranscriptionJob
     *
     * @struct
     */
    interface TranscriptionJob {
        /**
         * media property
         *
         * Specify an array of string values to match this event if the actual value of media is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly media?: AWSAPICallViaCloudTrail.Media1;
        /**
         * settings property
         *
         * Specify an array of string values to match this event if the actual value of settings is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly settings?: AWSAPICallViaCloudTrail.Settings1;
        /**
         * creationTime property
         *
         * Specify an array of string values to match this event if the actual value of creationTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationTime?: Array<string>;
        /**
         * languageCode property
         *
         * Specify an array of string values to match this event if the actual value of languageCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly languageCode?: Array<string>;
        /**
         * mediaFormat property
         *
         * Specify an array of string values to match this event if the actual value of mediaFormat is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mediaFormat?: Array<string>;
        /**
         * mediaSampleRateHertz property
         *
         * Specify an array of string values to match this event if the actual value of mediaSampleRateHertz is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mediaSampleRateHertz?: Array<string>;
        /**
         * transcriptionJobName property
         *
         * Specify an array of string values to match this event if the actual value of transcriptionJobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transcriptionJobName?: Array<string>;
        /**
         * transcriptionJobStatus property
         *
         * Specify an array of string values to match this event if the actual value of transcriptionJobStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transcriptionJobStatus?: Array<string>;
    }
    /**
     * Type definition for Media_1
     *
     * @struct
     */
    interface Media1 {
        /**
         * mediaFileUri property
         *
         * Specify an array of string values to match this event if the actual value of mediaFileUri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mediaFileUri?: Array<string>;
    }
    /**
     * Type definition for Settings_1
     *
     * @struct
     */
    interface Settings1 {
        /**
         * channelIdentification property
         *
         * Specify an array of string values to match this event if the actual value of channelIdentification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelIdentification?: Array<string>;
        /**
         * vocabularyName property
         *
         * Specify an array of string values to match this event if the actual value of vocabularyName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vocabularyName?: Array<string>;
    }
    /**
     * Type definition for UserIdentity
     *
     * @struct
     */
    interface UserIdentity {
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * userName property
         *
         * Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userName?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.transcribe@CallAnalyticsJobStateChange
 */
export declare class CallAnalyticsJobStateChange {
    /**
     * EventBridge event pattern for Call Analytics Job State Change
     */
    static eventPattern(options?: CallAnalyticsJobStateChange.CallAnalyticsJobStateChangeProps): events.EventPattern;
}
export declare namespace CallAnalyticsJobStateChange {
    /**
     * Props type for aws.transcribe@CallAnalyticsJobStateChange event
     */
    interface CallAnalyticsJobStateChangeProps {
        /**
         * JobName property
         *
         * Specify an array of string values to match this event if the actual value of JobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobName?: Array<string>;
        /**
         * JobStatus property
         *
         * Specify an array of string values to match this event if the actual value of JobStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobStatus?: Array<string>;
        /**
         * AnalyticsJobDetails property
         *
         * Specify an array of string values to match this event if the actual value of AnalyticsJobDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly analyticsJobDetails?: CallAnalyticsJobStateChange.AnalyticsJobDetails;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for AnalyticsJobDetails
     *
     * @struct
     */
    interface AnalyticsJobDetails {
        /**
         * Skipped property
         *
         * Specify an array of string values to match this event if the actual value of Skipped is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly skipped?: Array<CallAnalyticsJobStateChange.CallAnalyticsSkippedFeature>;
    }
    /**
     * Type definition for CallAnalyticsSkippedFeature
     *
     * @struct
     */
    interface CallAnalyticsSkippedFeature {
        /**
         * feature property
         *
         * Specify an array of string values to match this event if the actual value of feature is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly feature?: Array<string>;
        /**
         * reasonCode property
         *
         * Specify an array of string values to match this event if the actual value of reasonCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reasonCode?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.transcribe@TranscribeJobStateChange
 */
export declare class TranscribeJobStateChange {
    /**
     * EventBridge event pattern for Transcribe Job State Change
     */
    static eventPattern(options?: TranscribeJobStateChange.TranscribeJobStateChangeProps): events.EventPattern;
}
export declare namespace TranscribeJobStateChange {
    /**
     * Props type for aws.transcribe@TranscribeJobStateChange event
     */
    interface TranscribeJobStateChangeProps {
        /**
         * TranscriptionJobName property
         *
         * Specify an array of string values to match this event if the actual value of TranscriptionJobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transcriptionJobName?: Array<string>;
        /**
         * TranscriptionJobStatus property
         *
         * Specify an array of string values to match this event if the actual value of TranscriptionJobStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transcriptionJobStatus?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
