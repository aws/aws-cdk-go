import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.storagegateway@StorageGatewayFileUploadEvent
 */
export declare class StorageGatewayFileUploadEvent {
    /**
     * EventBridge event pattern for Storage Gateway File Upload Event
     */
    static eventPattern(options?: StorageGatewayFileUploadEvent.StorageGatewayFileUploadEventProps): events.EventPattern;
}
export declare namespace StorageGatewayFileUploadEvent {
    /**
     * Props type for aws.storagegateway@StorageGatewayFileUploadEvent event
     */
    interface StorageGatewayFileUploadEventProps {
        /**
         * completed property
         *
         * Specify an array of string values to match this event if the actual value of completed is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly completed?: Array<string>;
        /**
         * event-type property
         *
         * Specify an array of string values to match this event if the actual value of event-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * notification-id property
         *
         * Specify an array of string values to match this event if the actual value of notification-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notificationId?: Array<string>;
        /**
         * request-received property
         *
         * Specify an array of string values to match this event if the actual value of request-received is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestReceived?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.storagegateway@StorageGatewayObjectUploadEvent
 */
export declare class StorageGatewayObjectUploadEvent {
    /**
     * EventBridge event pattern for Storage Gateway Object Upload Event
     */
    static eventPattern(options?: StorageGatewayObjectUploadEvent.StorageGatewayObjectUploadEventProps): events.EventPattern;
}
export declare namespace StorageGatewayObjectUploadEvent {
    /**
     * Props type for aws.storagegateway@StorageGatewayObjectUploadEvent event
     */
    interface StorageGatewayObjectUploadEventProps {
        /**
         * bucket-name property
         *
         * Specify an array of string values to match this event if the actual value of bucket-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucketName?: Array<string>;
        /**
         * event-type property
         *
         * Specify an array of string values to match this event if the actual value of event-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * modification-time property
         *
         * Specify an array of string values to match this event if the actual value of modification-time is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modificationTime?: Array<string>;
        /**
         * object-key property
         *
         * Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectKey?: Array<string>;
        /**
         * object-size property
         *
         * Specify an array of string values to match this event if the actual value of object-size is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectSize?: Array<string>;
        /**
         * prefix property
         *
         * Specify an array of string values to match this event if the actual value of prefix is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly prefix?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.storagegateway@StorageGatewayRefreshCacheEvent
 */
export declare class StorageGatewayRefreshCacheEvent {
    /**
     * EventBridge event pattern for Storage Gateway Refresh Cache Event
     */
    static eventPattern(options?: StorageGatewayRefreshCacheEvent.StorageGatewayRefreshCacheEventProps): events.EventPattern;
}
export declare namespace StorageGatewayRefreshCacheEvent {
    /**
     * Props type for aws.storagegateway@StorageGatewayRefreshCacheEvent event
     */
    interface StorageGatewayRefreshCacheEventProps {
        /**
         * completed property
         *
         * Specify an array of string values to match this event if the actual value of completed is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly completed?: Array<string>;
        /**
         * event-type property
         *
         * Specify an array of string values to match this event if the actual value of event-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * folderList property
         *
         * Specify an array of string values to match this event if the actual value of folderList is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly folderList?: Array<string>;
        /**
         * notification-id property
         *
         * Specify an array of string values to match this event if the actual value of notification-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notificationId?: Array<string>;
        /**
         * started property
         *
         * Specify an array of string values to match this event if the actual value of started is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly started?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
