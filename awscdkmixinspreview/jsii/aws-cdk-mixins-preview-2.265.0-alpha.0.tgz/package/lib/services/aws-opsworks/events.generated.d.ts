import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.opsworks@OpsWorksAlert
 */
export declare class OpsWorksAlert {
    /**
     * EventBridge event pattern for OpsWorks Alert
     */
    static eventPattern(options?: OpsWorksAlert.OpsWorksAlertProps): events.EventPattern;
}
export declare namespace OpsWorksAlert {
    /**
     * Props type for aws.opsworks@OpsWorksAlert event
     */
    interface OpsWorksAlertProps {
        /**
         * stack-id property
         *
         * Specify an array of string values to match this event if the actual value of stack-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stackId?: Array<string>;
        /**
         * instance-id property
         *
         * Specify an array of string values to match this event if the actual value of instance-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.opsworks@OpsWorksCommandStateChange
 */
export declare class OpsWorksCommandStateChange {
    /**
     * EventBridge event pattern for OpsWorks Command State Change
     */
    static eventPattern(options?: OpsWorksCommandStateChange.OpsWorksCommandStateChangeProps): events.EventPattern;
}
export declare namespace OpsWorksCommandStateChange {
    /**
     * Props type for aws.opsworks@OpsWorksCommandStateChange event
     */
    interface OpsWorksCommandStateChangeProps {
        /**
         * command-id property
         *
         * Specify an array of string values to match this event if the actual value of command-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly commandId?: Array<string>;
        /**
         * instance-id property
         *
         * Specify an array of string values to match this event if the actual value of instance-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.opsworks@OpsWorksDeploymentStateChange
 */
export declare class OpsWorksDeploymentStateChange {
    /**
     * EventBridge event pattern for OpsWorks Deployment State Change
     */
    static eventPattern(options?: OpsWorksDeploymentStateChange.OpsWorksDeploymentStateChangeProps): events.EventPattern;
}
export declare namespace OpsWorksDeploymentStateChange {
    /**
     * Props type for aws.opsworks@OpsWorksDeploymentStateChange event
     */
    interface OpsWorksDeploymentStateChangeProps {
        /**
         * duration property
         *
         * Specify an array of string values to match this event if the actual value of duration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly duration?: Array<string>;
        /**
         * stack-id property
         *
         * Specify an array of string values to match this event if the actual value of stack-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stackId?: Array<string>;
        /**
         * instance-ids property
         *
         * Specify an array of string values to match this event if the actual value of instance-ids is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceIds?: Array<string>;
        /**
         * deployment-id property
         *
         * Specify an array of string values to match this event if the actual value of deployment-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deploymentId?: Array<string>;
        /**
         * command property
         *
         * Specify an array of string values to match this event if the actual value of command is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly command?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.opsworks@OpsWorksInstanceStateChange
 */
export declare class OpsWorksInstanceStateChange {
    /**
     * EventBridge event pattern for OpsWorks Instance State Change
     */
    static eventPattern(options?: OpsWorksInstanceStateChange.OpsWorksInstanceStateChangeProps): events.EventPattern;
}
export declare namespace OpsWorksInstanceStateChange {
    /**
     * Props type for aws.opsworks@OpsWorksInstanceStateChange event
     */
    interface OpsWorksInstanceStateChangeProps {
        /**
         * initiated_by property
         *
         * Specify an array of string values to match this event if the actual value of initiated_by is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly initiatedBy?: Array<string>;
        /**
         * hostname property
         *
         * Specify an array of string values to match this event if the actual value of hostname is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hostname?: Array<string>;
        /**
         * stack-id property
         *
         * Specify an array of string values to match this event if the actual value of stack-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stackId?: Array<string>;
        /**
         * layer-ids property
         *
         * Specify an array of string values to match this event if the actual value of layer-ids is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly layerIds?: Array<string>;
        /**
         * instance-id property
         *
         * Specify an array of string values to match this event if the actual value of instance-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceId?: Array<string>;
        /**
         * ec2-instance-id property
         *
         * Specify an array of string values to match this event if the actual value of ec2-instance-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ec2InstanceId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
