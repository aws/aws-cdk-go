import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-bedrock";
/**
 * Builder for CfnAgentAliasLogsMixin to generate EVENT_LOGS for CfnAgentAlias
 *
 * @cloudformationResource AWS::Bedrock::AgentAlias
 * @logType EVENT_LOGS
 * @stability external
 */
export declare class CfnAgentAliasEventLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnAgentAliasEventLogsS3Props): CfnAgentAliasLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnAgentAliasEventLogsLogGroupProps): CfnAgentAliasLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnAgentAliasEventLogsFirehoseProps): CfnAgentAliasLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnAgentAliasEventLogsDestProps): CfnAgentAliasLogsMixin;
}
/**
 * Builder for CfnAgentAliasLogsMixin to generate APPLICATION_LOGS for CfnAgentAlias
 *
 * @cloudformationResource AWS::Bedrock::AgentAlias
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnAgentAliasApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnAgentAliasApplicationLogsS3Props): CfnAgentAliasLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnAgentAliasApplicationLogsLogGroupProps): CfnAgentAliasLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnAgentAliasApplicationLogsFirehoseProps): CfnAgentAliasLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnAgentAliasApplicationLogsDestProps): CfnAgentAliasLogsMixin;
}
/**
 * Specifies an agent alias as a resource in a top-level template. Minimally, you must specify the following properties:.
 *
 * - AgentAliasName – Specify a name for the alias.
 *
 * For more information about creating aliases for an agent in Amazon Bedrock , see [Deploy an Amazon Bedrock agent](https://docs.aws.amazon.com/bedrock/latest/userguide/agents-deploy.html) .
 *
 * See the *Properties* section below for descriptions of both the required and optional properties.
 *
 * @cloudformationResource AWS::Bedrock::AgentAlias
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-agentalias.html
 */
export declare class CfnAgentAliasLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly EVENT_LOGS: CfnAgentAliasEventLogs;
    static readonly APPLICATION_LOGS: CfnAgentAliasApplicationLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::Bedrock::AgentAlias`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAgentAlias;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnAgentAliasEventLogs.
 */
export declare class CfnAgentAliasEventLogsOutputFormat {
}
export declare namespace CfnAgentAliasEventLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnAgentAliasEventLogsRecordFields {
    RESOURCE_ID = "resource_id",
    TIMESTAMP = "timestamp",
    RESOURCEID = "resourceId",
    TRACEID = "traceId",
    SPANID = "spanId",
    SESSIONID = "sessionId",
    REQUESTID = "requestId",
    OPERATION = "operation",
    ATTRIBUTES = "attributes",
    BODY = "body",
    EVENTTYPE = "eventType",
    EVENTVERSION = "eventVersion",
    EVENTNAME = "eventName",
    LEVEL = "level"
}
export interface CfnAgentAliasEventLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnAgentAliasEventLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentAliasEventLogsRecordFields>;
}
export interface CfnAgentAliasEventLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnAgentAliasEventLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentAliasEventLogsRecordFields>;
}
export interface CfnAgentAliasEventLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnAgentAliasEventLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentAliasEventLogsRecordFields>;
}
export interface CfnAgentAliasEventLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentAliasEventLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnAgentAliasApplicationLogs.
 */
export declare class CfnAgentAliasApplicationLogsOutputFormat {
}
export declare namespace CfnAgentAliasApplicationLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnAgentAliasApplicationLogsRecordFields {
    TIMESTAMP = "timestamp",
    AGENT_ALIAS_ARN = "agent_alias_arn",
    RESOURCE_ID = "resource_id",
    EVENT_TIMESTAMP = "event_timestamp",
    EVENT_VERSION = "event_version",
    OPERATION = "operation",
    EVENT_TYPE = "event_type",
    WORKFLOW = "workflow",
    LEVEL = "level",
    EVENT = "event",
    AGENT_ID = "agent_id",
    AGENT_ALIAS_ID = "agent_alias_id",
    AGENT_ARN = "agent_arn"
}
export interface CfnAgentAliasApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnAgentAliasApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentAliasApplicationLogsRecordFields>;
}
export interface CfnAgentAliasApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnAgentAliasApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentAliasApplicationLogsRecordFields>;
}
export interface CfnAgentAliasApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnAgentAliasApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentAliasApplicationLogsRecordFields>;
}
export interface CfnAgentAliasApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentAliasApplicationLogsRecordFields>;
}
/**
 * Builder for CfnKnowledgeBaseLogsMixin to generate TRACES for CfnKnowledgeBase
 *
 * @cloudformationResource AWS::Bedrock::KnowledgeBase
 * @logType TRACES
 * @stability external
 */
export declare class CfnKnowledgeBaseTraces {
    /**
     * Send traces to X-Ray
     *
     * @param props Additional properties that are optionally used in log delivery for XRay destinations
     */
    toXRay(props?: CfnKnowledgeBaseTracesXRayProps): CfnKnowledgeBaseLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are XRAY
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnKnowledgeBaseTracesDestProps): CfnKnowledgeBaseLogsMixin;
}
/**
 * Builder for CfnKnowledgeBaseLogsMixin to generate APPLICATION_LOGS for CfnKnowledgeBase
 *
 * @cloudformationResource AWS::Bedrock::KnowledgeBase
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnKnowledgeBaseApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnKnowledgeBaseApplicationLogsS3Props): CfnKnowledgeBaseLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnKnowledgeBaseApplicationLogsLogGroupProps): CfnKnowledgeBaseLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnKnowledgeBaseApplicationLogsFirehoseProps): CfnKnowledgeBaseLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnKnowledgeBaseApplicationLogsDestProps): CfnKnowledgeBaseLogsMixin;
}
/**
 * Specifies a knowledge base as a resource in a top-level template. Minimally, you must specify the following properties:.
 *
 * - Name – Specify a name for the knowledge base.
 * - RoleArn – Specify the Amazon Resource Name (ARN) of the IAM role with permissions to invoke API operations on the knowledge base. For more information, see [Create a service role for Knowledge base for Amazon Bedrock](https://docs.aws.amazon.com/bedrock/latest/userguide/kb-permissions.html) .
 * - KnowledgeBaseConfiguration – Specify the embeddings configuration of the knowledge base. The following sub-properties are required:
 *
 * - Type – Specify the value `VECTOR` .
 * - StorageConfiguration – Specify information about the vector store in which the data source is stored. The following sub-properties are required:
 *
 * - Type – Specify the vector store service that you are using.
 *
 * > Redis Enterprise Cloud vector stores are currently unsupported in CloudFormation .
 *
 * For more information about using knowledge bases in Amazon Bedrock , see [Knowledge base for Amazon Bedrock](https://docs.aws.amazon.com/bedrock/latest/userguide/knowledge-base.html) .
 *
 * See the *Properties* section below for descriptions of both the required and optional properties.
 *
 * @cloudformationResource AWS::Bedrock::KnowledgeBase
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-knowledgebase.html
 */
export declare class CfnKnowledgeBaseLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly TRACES: CfnKnowledgeBaseTraces;
    static readonly APPLICATION_LOGS: CfnKnowledgeBaseApplicationLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::Bedrock::KnowledgeBase`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnKnowledgeBase;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnKnowledgeBaseTraces.
 */
export declare class CfnKnowledgeBaseTracesOutputFormat {
}
export declare enum CfnKnowledgeBaseTracesRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCEARN = "resourceArn",
    TRACE = "trace"
}
export interface CfnKnowledgeBaseTracesXRayProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseTracesRecordFields>;
}
export interface CfnKnowledgeBaseTracesDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseTracesRecordFields>;
}
/**
 * Output Format options for each destination of CfnKnowledgeBaseApplicationLogs.
 */
export declare class CfnKnowledgeBaseApplicationLogsOutputFormat {
}
export declare namespace CfnKnowledgeBaseApplicationLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnKnowledgeBaseApplicationLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ID = "resource_id",
    EVENT_TIMESTAMP = "event_timestamp",
    EVENT = "event",
    EVENT_VERSION = "event_version",
    EVENT_TYPE = "event_type",
    LEVEL = "level"
}
export interface CfnKnowledgeBaseApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c
     */
    readonly outputFormat?: CfnKnowledgeBaseApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseApplicationLogsRecordFields>;
}
export interface CfnKnowledgeBaseApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnKnowledgeBaseApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseApplicationLogsRecordFields>;
}
export interface CfnKnowledgeBaseApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnKnowledgeBaseApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseApplicationLogsRecordFields>;
}
export interface CfnKnowledgeBaseApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseApplicationLogsRecordFields>;
}
