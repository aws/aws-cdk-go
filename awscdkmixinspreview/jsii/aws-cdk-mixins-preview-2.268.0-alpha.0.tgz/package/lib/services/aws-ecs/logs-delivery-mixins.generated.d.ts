import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-ecs";
/**
 * Builder for CfnClusterLogsMixin to generate ACTION_LOGS for CfnCluster
 *
 * @cloudformationResource AWS::ECS::Cluster
 * @logType ACTION_LOGS
 * @stability external
 */
export declare class CfnClusterActionLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnClusterActionLogsS3Props): CfnClusterLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnClusterActionLogsLogGroupProps): CfnClusterLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnClusterActionLogsFirehoseProps): CfnClusterLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnClusterActionLogsDestProps): CfnClusterLogsMixin;
}
/**
 * The `AWS::ECS::Cluster` resource creates an Amazon Elastic Container Service (Amazon ECS) cluster.
 *
 * @cloudformationResource AWS::ECS::Cluster
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ecs-cluster.html
 */
export declare class CfnClusterLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly ACTION_LOGS: CfnClusterActionLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::ECS::Cluster`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCluster;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnClusterActionLogs.
 */
export declare class CfnClusterActionLogsOutputFormat {
}
export declare namespace CfnClusterActionLogsOutputFormat {
    enum S3 {
        JSON = "json"
    }
    enum LogGroup {
        JSON = "json"
    }
    enum Firehose {
        JSON = "json"
    }
}
export declare enum CfnClusterActionLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCEARN = "resourceArn",
    ACTIONSOURCEID = "actionSourceId",
    LOGLEVEL = "logLevel",
    EVENTTIMESTAMP = "eventTimestamp",
    DETAIL = "detail"
}
export interface CfnClusterActionLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json
     */
    readonly outputFormat?: CfnClusterActionLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterActionLogsRecordFields>;
}
export interface CfnClusterActionLogsLogGroupProps {
    /**
     * Format for log output, options are json
     */
    readonly outputFormat?: CfnClusterActionLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterActionLogsRecordFields>;
}
export interface CfnClusterActionLogsFirehoseProps {
    /**
     * Format for log output, options are json
     */
    readonly outputFormat?: CfnClusterActionLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterActionLogsRecordFields>;
}
export interface CfnClusterActionLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterActionLogsRecordFields>;
}
