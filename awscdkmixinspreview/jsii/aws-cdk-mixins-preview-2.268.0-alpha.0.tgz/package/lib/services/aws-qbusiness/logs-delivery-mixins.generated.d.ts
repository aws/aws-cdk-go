import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-qbusiness";
/**
 * Builder for CfnApplicationLogsMixin to generate EVENT_LOGS for CfnApplication
 *
 * @cloudformationResource AWS::QBusiness::Application
 * @logType EVENT_LOGS
 * @stability external
 */
export declare class CfnApplicationEventLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnApplicationEventLogsS3Props): CfnApplicationLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnApplicationEventLogsLogGroupProps): CfnApplicationLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnApplicationEventLogsFirehoseProps): CfnApplicationLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnApplicationEventLogsDestProps): CfnApplicationLogsMixin;
}
/**
 * Builder for CfnApplicationLogsMixin to generate SYNC_JOB_LOGS for CfnApplication
 *
 * @cloudformationResource AWS::QBusiness::Application
 * @logType SYNC_JOB_LOGS
 * @stability external
 */
export declare class CfnApplicationSyncJobLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnApplicationSyncJobLogsS3Props): CfnApplicationLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnApplicationSyncJobLogsLogGroupProps): CfnApplicationLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnApplicationSyncJobLogsFirehoseProps): CfnApplicationLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnApplicationSyncJobLogsDestProps): CfnApplicationLogsMixin;
}
/**
 * Creates an Amazon Q Business application.
 *
 * > There are new tiers for Amazon Q Business. Not all features in Amazon Q Business Pro are also available in Amazon Q Business Lite. For information on what's included in Amazon Q Business Lite and what's included in Amazon Q Business Pro, see [Amazon Q Business tiers](https://docs.aws.amazon.com/amazonq/latest/qbusiness-ug/tiers.html#user-sub-tiers) . You must use the Amazon Q Business console to assign subscription tiers to users.
 * >
 * > An Amazon Q Apps service linked role will be created if it's absent in the AWS account when `QAppsConfiguration` is enabled in the request. For more information, see [Using service-linked roles for Q Apps](https://docs.aws.amazon.com/amazonq/latest/qbusiness-ug/using-service-linked-roles-qapps.html) .
 * >
 * > When you create an application, Amazon Q Business may securely transmit data for processing from your selected AWS region, but within your geography. For more information, see [Cross region inference in Amazon Q Business](https://docs.aws.amazon.com/amazonq/latest/qbusiness-ug/cross-region-inference.html) .
 *
 * @cloudformationResource AWS::QBusiness::Application
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-qbusiness-application.html
 */
export declare class CfnApplicationLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly EVENT_LOGS: CfnApplicationEventLogs;
    static readonly SYNC_JOB_LOGS: CfnApplicationSyncJobLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::QBusiness::Application`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnApplication;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnApplicationEventLogs.
 */
export declare class CfnApplicationEventLogsOutputFormat {
}
export declare namespace CfnApplicationEventLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnApplicationEventLogsRecordFields {
    TIMESTAMP = "timestamp",
    APPLICATION_ID = "application_id",
    EVENT_TIMESTAMP = "event_timestamp",
    LOG_TYPE = "log_type",
    ACCOUNT_ID = "account_id",
    CONVERSATION_ID = "conversation_id",
    SYSTEM_MESSAGE_ID = "system_message_id",
    USER_MESSAGE_ID = "user_message_id",
    USER_MESSAGE = "user_message",
    SYSTEM_MESSAGE = "system_message",
    OUTPUT_METRICS_IS_MESSAGE_BLOCKED = "output_metrics_is_message_blocked",
    OUTPUT_METRICS_IS_MESSAGE_WITH_NO_ANSWER = "output_metrics_is_message_with_no_answer",
    COMMENT = "comment",
    USEFULNESS_REASON = "usefulness_reason",
    USEFULNESS = "usefulness",
    USER_EMAIL = "user_email",
    HALLUCINATED_MESSAGE = "hallucinated_message",
    CHAT_MODE = "chat_mode",
    CHAT_LATENCY = "chat_latency",
    TIME_TO_FIRST_TOKEN = "time_to_first_token",
    TITLE = "title",
    URL = "url",
    CHAT_TYPE = "chat_type",
    PLUGIN_ID = "plugin_id",
    PLUGIN_TYPE = "plugin_type",
    UNIQUE_USER_ID = "unique_user_id"
}
export interface CfnApplicationEventLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnApplicationEventLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnApplicationEventLogsRecordFields>;
}
export interface CfnApplicationEventLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnApplicationEventLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnApplicationEventLogsRecordFields>;
}
export interface CfnApplicationEventLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnApplicationEventLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnApplicationEventLogsRecordFields>;
}
export interface CfnApplicationEventLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnApplicationEventLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnApplicationSyncJobLogs.
 */
export declare class CfnApplicationSyncJobLogsOutputFormat {
}
export declare namespace CfnApplicationSyncJobLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnApplicationSyncJobLogsRecordFields {
    TIMESTAMP = "timestamp",
    AWSACCOUNTID = "AwsAccountId",
    DATASOURCEID = "DataSourceId",
    SYNCJOBID = "SyncJobId",
    INDEXID = "IndexId",
    MEMBERNAME = "MemberName",
    MEMBERGLOBALNAME = "MemberGlobalName",
    DOCUMENTID = "DocumentId",
    DOCUMENTTITLE = "DocumentTitle",
    SOURCEURI = "SourceUri",
    ACL = "Acl",
    METADATA = "Metadata",
    TYPE = "Type",
    CRAWLACTION = "CrawlAction",
    CRAWLSTATUS = "CrawlStatus",
    SYNCSTATUS = "SyncStatus",
    INDEXSTATUS = "IndexStatus",
    CONNECTORDOCUMENTSTATUS = "ConnectorDocumentStatus",
    MEMBERTYPE = "MemberType",
    ISMEMBERFEDERATED = "IsMemberFederated",
    MESSAGE = "Message",
    JSONMESSAGE = "JsonMessage",
    GROUPNAME = "GroupName",
    GROUPGLOBALNAME = "GroupGlobalName",
    ISGROUPFEDERATED = "IsGroupFederated",
    HASHEDDOCUMENTID = "HashedDocumentId",
    CONTENTTYPE = "ContentType",
    INTERMEDIATESTATUS = "IntermediateStatus",
    ERRORMSG = "ErrorMsg",
    APPLICATIONID = "applicationId",
    EVENT_TIMESTAMP = "event_timestamp",
    FEATURENAME = "FeatureName",
    LOGLEVEL = "LogLevel"
}
export interface CfnApplicationSyncJobLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnApplicationSyncJobLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnApplicationSyncJobLogsRecordFields>;
}
export interface CfnApplicationSyncJobLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnApplicationSyncJobLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnApplicationSyncJobLogsRecordFields>;
}
export interface CfnApplicationSyncJobLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnApplicationSyncJobLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnApplicationSyncJobLogsRecordFields>;
}
export interface CfnApplicationSyncJobLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnApplicationSyncJobLogsRecordFields>;
}
