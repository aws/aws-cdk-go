import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-s3";
/**
 * Builder for CfnBucketLogsMixin to generate S3_SERVER_ACCESS_LOGS for CfnBucket
 *
 * @cloudformationResource AWS::S3::Bucket
 * @logType S3_SERVER_ACCESS_LOGS
 * @stability external
 */
export declare class CfnBucketS3ServerAccessLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnBucketS3ServerAccessLogsS3Props): CfnBucketLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnBucketS3ServerAccessLogsLogGroupProps): CfnBucketLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnBucketS3ServerAccessLogsFirehoseProps): CfnBucketLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnBucketS3ServerAccessLogsDestProps): CfnBucketLogsMixin;
}
/**
 * The `AWS::S3::Bucket` resource creates an Amazon S3 bucket in the same AWS Region where you create the AWS CloudFormation stack.
 *
 * To control how AWS CloudFormation handles the bucket when the stack is deleted, you can set a deletion policy for your bucket. You can choose to *retain* the bucket or to *delete* the bucket. For more information, see [DeletionPolicy Attribute](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-attribute-deletionpolicy.html) .
 *
 * > You can only delete empty buckets. Deletion fails for buckets that have contents.
 *
 * @cloudformationResource AWS::S3::Bucket
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3-bucket.html
 */
export declare class CfnBucketLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly S3_SERVER_ACCESS_LOGS: CfnBucketS3ServerAccessLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::S3::Bucket`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnBucket;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnBucketS3ServerAccessLogs.
 */
export declare class CfnBucketS3ServerAccessLogsOutputFormat {
}
export declare namespace CfnBucketS3ServerAccessLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PARQUET = "parquet"
    }
    enum LogGroup {
        JSON = "json"
    }
    enum Firehose {
        JSON = "json"
    }
}
export declare enum CfnBucketS3ServerAccessLogsRecordFields {
    SCHEMA_VERSION_ID = "schema_version_id",
    BUCKET_ARN = "bucket_arn",
    BUCKET_NAME = "bucket_name",
    REQUEST_TIME = "request_time",
    BUCKET_OWNER_ID = "bucket_owner_id",
    REMOTE_IP = "remote_ip",
    REQUESTER = "requester",
    REQUEST_ID = "request_id",
    OPERATION = "operation",
    KEY_NAME = "key_name",
    REQUEST_URI = "request_uri",
    HTTP_STATUS = "http_status",
    ERROR_CODE = "error_code",
    BYTES_SENT_SIZE = "bytes_sent_size",
    OBJECT_SIZE = "object_size",
    TOTAL_DURATION = "total_duration",
    TURN_AROUND_DURATION = "turn_around_duration",
    REFERER = "referer",
    USER_AGENT = "user_agent",
    VERSION_ID = "version_id",
    HOST_ID = "host_id",
    SIGNATURE_VERSION = "signature_version",
    CIPHER_SUITE = "cipher_suite",
    AUTHENTICATION_TYPE = "authentication_type",
    HOST_HEADER = "host_header",
    TLS_VERSION = "tls_version",
    ACCESS_POINT_ARN = "access_point_arn",
    ACL_REQUIRED = "acl_required",
    SOURCE_REGION = "source_region"
}
export interface CfnBucketS3ServerAccessLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,parquet
     */
    readonly outputFormat?: CfnBucketS3ServerAccessLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnBucketS3ServerAccessLogsRecordFields>;
}
export interface CfnBucketS3ServerAccessLogsLogGroupProps {
    /**
     * Format for log output, options are json
     */
    readonly outputFormat?: CfnBucketS3ServerAccessLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnBucketS3ServerAccessLogsRecordFields>;
}
export interface CfnBucketS3ServerAccessLogsFirehoseProps {
    /**
     * Format for log output, options are json
     */
    readonly outputFormat?: CfnBucketS3ServerAccessLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnBucketS3ServerAccessLogsRecordFields>;
}
export interface CfnBucketS3ServerAccessLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnBucketS3ServerAccessLogsRecordFields>;
}
