import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-cloudfront";
/**
 * Builder for CfnDistributionLogsMixin to generate CONNECTION_LOGS for CfnDistribution
 *
 * @cloudformationResource AWS::CloudFront::Distribution
 * @logType CONNECTION_LOGS
 * @stability external
 */
export declare class CfnDistributionConnectionLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnDistributionConnectionLogsS3Props): CfnDistributionLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnDistributionConnectionLogsLogGroupProps): CfnDistributionLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnDistributionConnectionLogsFirehoseProps): CfnDistributionLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnDistributionConnectionLogsDestProps): CfnDistributionLogsMixin;
}
/**
 * Builder for CfnDistributionLogsMixin to generate ACCESS_LOGS for CfnDistribution
 *
 * @cloudformationResource AWS::CloudFront::Distribution
 * @logType ACCESS_LOGS
 * @stability external
 */
export declare class CfnDistributionAccessLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnDistributionAccessLogsS3Props): CfnDistributionLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnDistributionAccessLogsLogGroupProps): CfnDistributionLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnDistributionAccessLogsFirehoseProps): CfnDistributionLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnDistributionAccessLogsDestProps): CfnDistributionLogsMixin;
}
/**
 * A distribution tells CloudFront where you want content to be delivered from, and the details about how to track and manage content delivery.
 *
 * @cloudformationResource AWS::CloudFront::Distribution
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudfront-distribution.html
 */
export declare class CfnDistributionLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly CONNECTION_LOGS: CfnDistributionConnectionLogs;
    static readonly ACCESS_LOGS: CfnDistributionAccessLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::CloudFront::Distribution`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDistribution;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnDistributionConnectionLogs.
 */
export declare class CfnDistributionConnectionLogsOutputFormat {
}
export declare namespace CfnDistributionConnectionLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnDistributionConnectionLogsRecordFields {
    TIMESTAMP = "timestamp",
    CONNECTIONSTATUS = "connectionStatus",
    CLIENTIP = "clientIp",
    CLIENTPORT = "clientPort",
    SERVERIP = "serverIp",
    DISTRIBUTIONTENANTID = "distributionTenantId",
    TLSPROTOCOL = "tlsProtocol",
    TLSCIPHER = "tlsCipher",
    TLSHANDSHAKEDURATION = "tlsHandshakeDuration",
    TLSSNI = "tlsSni",
    CLIENTLEAFCERTSERIALNUMBER = "clientLeafCertSerialNumber",
    CLIENTLEAFCERTSUBJECT = "clientLeafCertSubject",
    CLIENTLEAFCERTISSUER = "clientLeafCertIssuer",
    CLIENTLEAFCERTVALIDITY = "clientLeafCertValidity",
    CONNECTIONLOGCUSTOMDATA = "connectionLogCustomData",
    EVENTTIMESTAMP = "eventTimestamp",
    DISTRIBUTIONID = "distributionId",
    CONNECTIONID = "connectionId"
}
export interface CfnDistributionConnectionLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnDistributionConnectionLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnDistributionConnectionLogsRecordFields>;
}
export interface CfnDistributionConnectionLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnDistributionConnectionLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnDistributionConnectionLogsRecordFields>;
}
export interface CfnDistributionConnectionLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnDistributionConnectionLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnDistributionConnectionLogsRecordFields>;
}
export interface CfnDistributionConnectionLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnDistributionConnectionLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnDistributionAccessLogs.
 */
export declare class CfnDistributionAccessLogsOutputFormat {
}
export declare namespace CfnDistributionAccessLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnDistributionAccessLogsRecordFields {
    TIMESTAMP = "timestamp",
    DATE = "date",
    TIME = "time",
    X_EDGE_LOCATION = "x-edge-location",
    SC_BYTES = "sc-bytes",
    C_IP = "c-ip",
    CS_METHOD = "cs-method",
    CS_HOST_ = "cs(Host)",
    CS_URI_STEM = "cs-uri-stem",
    SC_STATUS = "sc-status",
    CS_REFERER_ = "cs(Referer)",
    CS_USER_AGENT_ = "cs(User-Agent)",
    CS_URI_QUERY = "cs-uri-query",
    CS_COOKIE_ = "cs(Cookie)",
    X_EDGE_RESULT_TYPE = "x-edge-result-type",
    X_EDGE_REQUEST_ID = "x-edge-request-id",
    X_HOST_HEADER = "x-host-header",
    CS_PROTOCOL = "cs-protocol",
    CS_BYTES = "cs-bytes",
    TIME_TAKEN = "time-taken",
    X_FORWARDED_FOR = "x-forwarded-for",
    SSL_PROTOCOL = "ssl-protocol",
    SSL_CIPHER = "ssl-cipher",
    X_EDGE_RESPONSE_RESULT_TYPE = "x-edge-response-result-type",
    CS_PROTOCOL_VERSION = "cs-protocol-version",
    FLE_STATUS = "fle-status",
    FLE_ENCRYPTED_FIELDS = "fle-encrypted-fields",
    C_PORT = "c-port",
    TIME_TO_FIRST_BYTE = "time-to-first-byte",
    X_EDGE_DETAILED_RESULT_TYPE = "x-edge-detailed-result-type",
    SC_CONTENT_TYPE = "sc-content-type",
    SC_CONTENT_LEN = "sc-content-len",
    SC_RANGE_START = "sc-range-start",
    SC_RANGE_END = "sc-range-end",
    TIMESTAMP_MS_ = "timestamp(ms)",
    ORIGIN_FBL = "origin-fbl",
    ORIGIN_LBL = "origin-lbl",
    ASN = "asn",
    C_COUNTRY = "c-country",
    CACHE_BEHAVIOR_PATH_PATTERN = "cache-behavior-path-pattern",
    DISTRIBUTION_TENANT_ID = "distribution-tenant-id",
    CONNECTION_ID = "connection-id",
    VIEWER_REQUEST_LOG_DATA = "viewer-request-log-data",
    VIEWER_RESPONSE_LOG_DATA = "viewer-response-log-data",
    CMCD_ENCODED_BITRATE = "cmcd-encoded-bitrate",
    CMCD_BUFFER_LENGTH = "cmcd-buffer-length",
    CMCD_BUFFER_STARVATION = "cmcd-buffer-starvation",
    CMCD_CONTENT_ID = "cmcd-content-id",
    CMCD_OBJECT_DURATION = "cmcd-object-duration",
    CMCD_DEADLINE = "cmcd-deadline",
    CMCD_MEASURED_THROUGHPUT = "cmcd-measured-throughput",
    CMCD_NEXT_OBJECT_REQUEST = "cmcd-next-object-request",
    CMCD_NEXT_RANGE_REQUEST = "cmcd-next-range-request",
    CMCD_OBJECT_TYPE = "cmcd-object-type",
    CMCD_PLAYBACK_RATE = "cmcd-playback-rate",
    CMCD_REQUESTED_MAXIMUM_THROUGHPUT = "cmcd-requested-maximum-throughput",
    CMCD_STREAMING_FORMAT = "cmcd-streaming-format",
    CMCD_SESSION_ID = "cmcd-session-id",
    CMCD_STREAM_TYPE = "cmcd-stream-type",
    CMCD_STARTUP = "cmcd-startup",
    CMCD_TOP_BITRATE = "cmcd-top-bitrate",
    CMCD_VERSION = "cmcd-version",
    S_IP = "s-ip",
    PRIMARY_DISTRIBUTION_ID = "primary-distribution-id",
    PRIMARY_DISTRIBUTION_DNS_NAME = "primary-distribution-dns-name",
    R_HOST = "r-host",
    SR_REASON = "sr-reason",
    X_EDGE_MQCS = "x-edge-mqcs"
}
export interface CfnDistributionAccessLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnDistributionAccessLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnDistributionAccessLogsRecordFields>;
}
export interface CfnDistributionAccessLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnDistributionAccessLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnDistributionAccessLogsRecordFields>;
}
export interface CfnDistributionAccessLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnDistributionAccessLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnDistributionAccessLogsRecordFields>;
}
export interface CfnDistributionAccessLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnDistributionAccessLogsRecordFields>;
}
