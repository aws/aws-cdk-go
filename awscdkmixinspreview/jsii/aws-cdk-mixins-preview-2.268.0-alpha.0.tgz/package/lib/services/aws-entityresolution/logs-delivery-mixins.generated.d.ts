import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-entityresolution";
/**
 * Builder for CfnMatchingWorkflowLogsMixin to generate WORKFLOW_LOGS for CfnMatchingWorkflow
 *
 * @cloudformationResource AWS::EntityResolution::MatchingWorkflow
 * @logType WORKFLOW_LOGS
 * @stability external
 */
export declare class CfnMatchingWorkflowWorkflowLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnMatchingWorkflowWorkflowLogsS3Props): CfnMatchingWorkflowLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnMatchingWorkflowWorkflowLogsLogGroupProps): CfnMatchingWorkflowLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnMatchingWorkflowWorkflowLogsFirehoseProps): CfnMatchingWorkflowLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnMatchingWorkflowWorkflowLogsDestProps): CfnMatchingWorkflowLogsMixin;
}
/**
 * Creates a matching workflow that defines the configuration for a data processing job.
 *
 * The workflow name must be unique. To modify an existing workflow, use `UpdateMatchingWorkflow` .
 *
 * > For workflows where `resolutionType` is `ML_MATCHING` or `PROVIDER` , incremental processing is not supported.
 *
 * @cloudformationResource AWS::EntityResolution::MatchingWorkflow
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-matchingworkflow.html
 */
export declare class CfnMatchingWorkflowLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly WORKFLOW_LOGS: CfnMatchingWorkflowWorkflowLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::EntityResolution::MatchingWorkflow`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnMatchingWorkflow;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnMatchingWorkflowWorkflowLogs.
 */
export declare class CfnMatchingWorkflowWorkflowLogsOutputFormat {
}
export declare namespace CfnMatchingWorkflowWorkflowLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnMatchingWorkflowWorkflowLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ARN = "resource_arn",
    RESOURCE_ID = "resource_id",
    EVENT_TYPE = "event_type",
    EVENT_TIMESTAMP = "event_timestamp",
    JOB_ID = "job_id",
    WORKFLOW_NAME = "workflow_name",
    WORKFLOW_START_TIME = "workflow_start_time",
    WORKFLOW_COMPLETE_TIME = "workflow_complete_time",
    DATA_PROCESSING_PROGRESSION = "data_processing_progression",
    ERROR_COUNT_MAP = "error_count_map",
    ERROR_MESSAGE = "error_message",
    ERROR_COUNT = "error_count",
    MATCHED_RECORD_COUNT_MAP = "matched_record_count_map",
    MATCH_RULE = "match_rule",
    MATCH_COUNT = "match_count",
    TOTAL_RECORDS_PROCESSED = "total_records_processed",
    TOTAL_RECORDS_UNPROCESSED = "total_records_unprocessed",
    INCREMENTAL_RECORDS_PROCESSED = "incremental_records_processed",
    WORKFLOW_DURATION = "workflow_duration",
    RAW_WORKFLOW_DURATION = "raw_workflow_duration",
    INPUT_FILE_SIZE = "input_file_size"
}
export interface CfnMatchingWorkflowWorkflowLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnMatchingWorkflowWorkflowLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMatchingWorkflowWorkflowLogsRecordFields>;
}
export interface CfnMatchingWorkflowWorkflowLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnMatchingWorkflowWorkflowLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMatchingWorkflowWorkflowLogsRecordFields>;
}
export interface CfnMatchingWorkflowWorkflowLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnMatchingWorkflowWorkflowLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMatchingWorkflowWorkflowLogsRecordFields>;
}
export interface CfnMatchingWorkflowWorkflowLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMatchingWorkflowWorkflowLogsRecordFields>;
}
/**
 * Builder for CfnIdMappingWorkflowLogsMixin to generate WORKFLOW_LOGS for CfnIdMappingWorkflow
 *
 * @cloudformationResource AWS::EntityResolution::IdMappingWorkflow
 * @logType WORKFLOW_LOGS
 * @stability external
 */
export declare class CfnIdMappingWorkflowWorkflowLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnIdMappingWorkflowWorkflowLogsS3Props): CfnIdMappingWorkflowLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnIdMappingWorkflowWorkflowLogsLogGroupProps): CfnIdMappingWorkflowLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnIdMappingWorkflowWorkflowLogsFirehoseProps): CfnIdMappingWorkflowLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnIdMappingWorkflowWorkflowLogsDestProps): CfnIdMappingWorkflowLogsMixin;
}
/**
 * Creates an `IdMappingWorkflow` object which stores the configuration of the data processing job to be run.
 *
 * Each `IdMappingWorkflow` must have a unique workflow name. To modify an existing workflow, use the UpdateIdMappingWorkflow API.
 *
 * > Incremental processing is not supported for ID mapping workflows.
 *
 * @cloudformationResource AWS::EntityResolution::IdMappingWorkflow
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idmappingworkflow.html
 */
export declare class CfnIdMappingWorkflowLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly WORKFLOW_LOGS: CfnIdMappingWorkflowWorkflowLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::EntityResolution::IdMappingWorkflow`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnIdMappingWorkflow;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnIdMappingWorkflowWorkflowLogs.
 */
export declare class CfnIdMappingWorkflowWorkflowLogsOutputFormat {
}
export declare namespace CfnIdMappingWorkflowWorkflowLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnIdMappingWorkflowWorkflowLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ARN = "resource_arn",
    RESOURCE_ID = "resource_id",
    EVENT_TYPE = "event_type",
    EVENT_TIMESTAMP = "event_timestamp",
    JOB_ID = "job_id",
    WORKFLOW_NAME = "workflow_name",
    WORKFLOW_START_TIME = "workflow_start_time",
    WORKFLOW_COMPLETE_TIME = "workflow_complete_time",
    DATA_PROCESSING_PROGRESSION = "data_processing_progression",
    ERROR_COUNT_MAP = "error_count_map",
    ERROR_MESSAGE = "error_message",
    ERROR_COUNT = "error_count",
    MATCHED_RECORD_COUNT_MAP = "matched_record_count_map",
    MATCH_RULE = "match_rule",
    MATCH_COUNT = "match_count",
    TOTAL_RECORDS_PROCESSED = "total_records_processed",
    TOTAL_RECORDS_UNPROCESSED = "total_records_unprocessed",
    INCREMENTAL_RECORDS_PROCESSED = "incremental_records_processed",
    WORKFLOW_DURATION = "workflow_duration",
    RAW_WORKFLOW_DURATION = "raw_workflow_duration",
    INPUT_FILE_SIZE = "input_file_size"
}
export interface CfnIdMappingWorkflowWorkflowLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnIdMappingWorkflowWorkflowLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnIdMappingWorkflowWorkflowLogsRecordFields>;
}
export interface CfnIdMappingWorkflowWorkflowLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnIdMappingWorkflowWorkflowLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnIdMappingWorkflowWorkflowLogsRecordFields>;
}
export interface CfnIdMappingWorkflowWorkflowLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnIdMappingWorkflowWorkflowLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnIdMappingWorkflowWorkflowLogsRecordFields>;
}
export interface CfnIdMappingWorkflowWorkflowLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnIdMappingWorkflowWorkflowLogsRecordFields>;
}
