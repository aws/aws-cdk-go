import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-rtbfabric";
/**
 * Builder for CfnLinkLogsMixin to generate APPLICATION_LOGS for CfnLink
 *
 * @cloudformationResource AWS::RTBFabric::Link
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnLinkApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnLinkApplicationLogsS3Props): CfnLinkLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnLinkApplicationLogsLogGroupProps): CfnLinkLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnLinkApplicationLogsFirehoseProps): CfnLinkLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnLinkApplicationLogsDestProps): CfnLinkLogsMixin;
}
/**
 * Creates a new link between gateways.
 *
 * Establishes a connection that allows gateways to communicate and exchange bid requests and responses.
 *
 * @cloudformationResource AWS::RTBFabric::Link
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rtbfabric-link.html
 */
export declare class CfnLinkLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnLinkApplicationLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::RTBFabric::Link`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnLink;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnLinkApplicationLogs.
 */
export declare class CfnLinkApplicationLogsOutputFormat {
}
export declare namespace CfnLinkApplicationLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnLinkApplicationLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ARN = "resource_arn",
    RESOURCE_ID = "resource_id",
    EVENT_TIMESTAMP = "event_timestamp",
    BID_REQUEST_ID = "bid_request_id",
    RTBFABRIC_REQUEST_ID = "rtbfabric_request_id",
    MESSAGE = "message",
    STATUS_CODE = "status_code",
    CORRELATION_ID = "correlation_id",
    RTBFABRIC_EVENT_TIMESTAMP = "rtbfabric_event_timestamp",
    EVENT_TYPE = "event_type",
    LINK_ID = "link_id"
}
export interface CfnLinkApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnLinkApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLinkApplicationLogsRecordFields>;
}
export interface CfnLinkApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnLinkApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLinkApplicationLogsRecordFields>;
}
export interface CfnLinkApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnLinkApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLinkApplicationLogsRecordFields>;
}
export interface CfnLinkApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLinkApplicationLogsRecordFields>;
}
