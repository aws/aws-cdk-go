import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.sagemaker@AWSAPICallViaCloudTrail
 */
export declare class AWSAPICallViaCloudTrail {
    /**
     * EventBridge event pattern for AWS API Call via CloudTrail
     */
    static eventPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
}
export declare namespace AWSAPICallViaCloudTrail {
    /**
     * Props type for aws.sagemaker@AWSAPICallViaCloudTrail event
     */
    interface AWSAPICallViaCloudTrailProps {
        /**
         * responseElements property
         *
         * Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly responseElements?: AWSAPICallViaCloudTrail.ResponseElements;
        /**
         * requestParameters property
         *
         * Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestParameters?: AWSAPICallViaCloudTrail.RequestParameters;
        /**
         * userIdentity property
         *
         * Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userIdentity?: AWSAPICallViaCloudTrail.UserIdentity;
        /**
         * eventID property
         *
         * Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * awsRegion property
         *
         * Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsRegion?: Array<string>;
        /**
         * eventVersion property
         *
         * Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventVersion?: Array<string>;
        /**
         * sourceIPAddress property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * eventSource property
         *
         * Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventSource?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * requestID property
         *
         * Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ResponseElements
     *
     * @struct
     */
    interface ResponseElements {
        /**
         * endpointConfigArn property
         *
         * Specify an array of string values to match this event if the actual value of endpointConfigArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endpointConfigArn?: Array<string>;
        /**
         * trainingJobArn property
         *
         * Specify an array of string values to match this event if the actual value of trainingJobArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingJobArn?: Array<string>;
        /**
         * modelArn property
         *
         * Specify an array of string values to match this event if the actual value of modelArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modelArn?: Array<string>;
        /**
         * transformJobArn property
         *
         * Specify an array of string values to match this event if the actual value of transformJobArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformJobArn?: Array<string>;
    }
    /**
     * Type definition for RequestParameters
     *
     * @struct
     */
    interface RequestParameters {
        /**
         * primaryContainer property
         *
         * Specify an array of string values to match this event if the actual value of primaryContainer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly primaryContainer?: AWSAPICallViaCloudTrail.PrimaryContainer;
        /**
         * stoppingCondition property
         *
         * Specify an array of string values to match this event if the actual value of stoppingCondition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stoppingCondition?: AWSAPICallViaCloudTrail.StoppingCondition;
        /**
         * outputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputDataConfig?: AWSAPICallViaCloudTrail.OutputDataConfig;
        /**
         * transformInput property
         *
         * Specify an array of string values to match this event if the actual value of transformInput is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformInput?: AWSAPICallViaCloudTrail.TransformInput;
        /**
         * algorithmSpecification property
         *
         * Specify an array of string values to match this event if the actual value of algorithmSpecification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly algorithmSpecification?: AWSAPICallViaCloudTrail.AlgorithmSpecification;
        /**
         * resourceConfig property
         *
         * Specify an array of string values to match this event if the actual value of resourceConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceConfig?: AWSAPICallViaCloudTrail.ResourceConfig;
        /**
         * transformOutput property
         *
         * Specify an array of string values to match this event if the actual value of transformOutput is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformOutput?: AWSAPICallViaCloudTrail.TransformOutput;
        /**
         * hyperParameters property
         *
         * Specify an array of string values to match this event if the actual value of hyperParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hyperParameters?: AWSAPICallViaCloudTrail.HyperParameters;
        /**
         * transformResources property
         *
         * Specify an array of string values to match this event if the actual value of transformResources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformResources?: AWSAPICallViaCloudTrail.TransformResources;
        /**
         * endpointConfigName property
         *
         * Specify an array of string values to match this event if the actual value of endpointConfigName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endpointConfigName?: Array<string>;
        /**
         * productionVariants property
         *
         * Specify an array of string values to match this event if the actual value of productionVariants is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly productionVariants?: Array<AWSAPICallViaCloudTrail.RequestParametersItem>;
        /**
         * endpointName property
         *
         * Specify an array of string values to match this event if the actual value of endpointName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endpointName?: Array<string>;
        /**
         * enableNetworkIsolation property
         *
         * Specify an array of string values to match this event if the actual value of enableNetworkIsolation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly enableNetworkIsolation?: Array<string>;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<any>;
        /**
         * modelName property
         *
         * Specify an array of string values to match this event if the actual value of modelName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modelName?: Array<string>;
        /**
         * executionRoleArn property
         *
         * Specify an array of string values to match this event if the actual value of executionRoleArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly executionRoleArn?: Array<string>;
        /**
         * trainingJobName property
         *
         * Specify an array of string values to match this event if the actual value of trainingJobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingJobName?: Array<string>;
        /**
         * roleArn property
         *
         * Specify an array of string values to match this event if the actual value of roleArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly roleArn?: Array<string>;
        /**
         * enableManagedSpotTraining property
         *
         * Specify an array of string values to match this event if the actual value of enableManagedSpotTraining is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly enableManagedSpotTraining?: Array<string>;
        /**
         * inputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputDataConfig?: Array<AWSAPICallViaCloudTrail.RequestParametersItem2>;
        /**
         * enableInterContainerTrafficEncryption property
         *
         * Specify an array of string values to match this event if the actual value of enableInterContainerTrafficEncryption is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly enableInterContainerTrafficEncryption?: Array<string>;
        /**
         * transformJobName property
         *
         * Specify an array of string values to match this event if the actual value of transformJobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformJobName?: Array<string>;
    }
    /**
     * Type definition for PrimaryContainer
     *
     * @struct
     */
    interface PrimaryContainer {
        /**
         * image property
         *
         * Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly image?: Array<string>;
        /**
         * modelDataUrl property
         *
         * Specify an array of string values to match this event if the actual value of modelDataUrl is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modelDataUrl?: Array<string>;
        /**
         * containerHostname property
         *
         * Specify an array of string values to match this event if the actual value of containerHostname is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerHostname?: Array<string>;
    }
    /**
     * Type definition for StoppingCondition
     *
     * @struct
     */
    interface StoppingCondition {
        /**
         * maxRuntimeInSeconds property
         *
         * Specify an array of string values to match this event if the actual value of maxRuntimeInSeconds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxRuntimeInSeconds?: Array<string>;
    }
    /**
     * Type definition for OutputDataConfig
     *
     * @struct
     */
    interface OutputDataConfig {
        /**
         * removeJobNameFromS3OutputPath property
         *
         * Specify an array of string values to match this event if the actual value of removeJobNameFromS3OutputPath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly removeJobNameFromS3OutputPath?: Array<string>;
        /**
         * s3OutputPath property
         *
         * Specify an array of string values to match this event if the actual value of s3OutputPath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3OutputPath?: Array<string>;
    }
    /**
     * Type definition for TransformInput
     *
     * @struct
     */
    interface TransformInput {
        /**
         * dataSource property
         *
         * Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSource?: AWSAPICallViaCloudTrail.DataSource;
        /**
         * compressionType property
         *
         * Specify an array of string values to match this event if the actual value of compressionType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly compressionType?: Array<string>;
        /**
         * contentType property
         *
         * Specify an array of string values to match this event if the actual value of contentType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly contentType?: Array<string>;
    }
    /**
     * Type definition for DataSource
     *
     * @struct
     */
    interface DataSource {
        /**
         * s3DataSource property
         *
         * Specify an array of string values to match this event if the actual value of s3DataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataSource?: AWSAPICallViaCloudTrail.S3DataSource;
    }
    /**
     * Type definition for S3DataSource
     *
     * @struct
     */
    interface S3DataSource {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
        /**
         * s3DataType property
         *
         * Specify an array of string values to match this event if the actual value of s3DataType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataType?: Array<string>;
    }
    /**
     * Type definition for AlgorithmSpecification
     *
     * @struct
     */
    interface AlgorithmSpecification {
        /**
         * trainingInputMode property
         *
         * Specify an array of string values to match this event if the actual value of trainingInputMode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingInputMode?: Array<string>;
        /**
         * trainingImage property
         *
         * Specify an array of string values to match this event if the actual value of trainingImage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingImage?: Array<string>;
    }
    /**
     * Type definition for ResourceConfig
     *
     * @struct
     */
    interface ResourceConfig {
        /**
         * volumeSizeInGB property
         *
         * Specify an array of string values to match this event if the actual value of volumeSizeInGB is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly volumeSizeInGb?: Array<string>;
        /**
         * instanceCount property
         *
         * Specify an array of string values to match this event if the actual value of instanceCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceCount?: Array<string>;
        /**
         * instanceType property
         *
         * Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
    }
    /**
     * Type definition for TransformOutput
     *
     * @struct
     */
    interface TransformOutput {
        /**
         * s3OutputPath property
         *
         * Specify an array of string values to match this event if the actual value of s3OutputPath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3OutputPath?: Array<string>;
    }
    /**
     * Type definition for HyperParameters
     *
     * @struct
     */
    interface HyperParameters {
        /**
         * eval_metric property
         *
         * Specify an array of string values to match this event if the actual value of eval_metric is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly evalMetric?: Array<string>;
        /**
         * num_round property
         *
         * Specify an array of string values to match this event if the actual value of num_round is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly numRound?: Array<string>;
        /**
         * objective property
         *
         * Specify an array of string values to match this event if the actual value of objective is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objective?: Array<string>;
    }
    /**
     * Type definition for TransformResources
     *
     * @struct
     */
    interface TransformResources {
        /**
         * instanceCount property
         *
         * Specify an array of string values to match this event if the actual value of instanceCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceCount?: Array<string>;
        /**
         * instanceType property
         *
         * Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
    }
    /**
     * Type definition for RequestParametersItem
     *
     * @struct
     */
    interface RequestParametersItem {
        /**
         * modelName property
         *
         * Specify an array of string values to match this event if the actual value of modelName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modelName?: Array<string>;
        /**
         * instanceType property
         *
         * Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
        /**
         * initialVariantWeight property
         *
         * Specify an array of string values to match this event if the actual value of initialVariantWeight is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly initialVariantWeight?: Array<string>;
        /**
         * variantName property
         *
         * Specify an array of string values to match this event if the actual value of variantName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly variantName?: Array<string>;
        /**
         * initialInstanceCount property
         *
         * Specify an array of string values to match this event if the actual value of initialInstanceCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly initialInstanceCount?: Array<string>;
    }
    /**
     * Type definition for RequestParametersItem_2
     *
     * @struct
     */
    interface RequestParametersItem2 {
        /**
         * dataSource property
         *
         * Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSource?: AWSAPICallViaCloudTrail.DataSource1;
        /**
         * channelName property
         *
         * Specify an array of string values to match this event if the actual value of channelName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelName?: Array<string>;
        /**
         * contentType property
         *
         * Specify an array of string values to match this event if the actual value of contentType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly contentType?: Array<string>;
    }
    /**
     * Type definition for DataSource_1
     *
     * @struct
     */
    interface DataSource1 {
        /**
         * s3DataSource property
         *
         * Specify an array of string values to match this event if the actual value of s3DataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataSource?: AWSAPICallViaCloudTrail.S3DataSource1;
    }
    /**
     * Type definition for S3DataSource_1
     *
     * @struct
     */
    interface S3DataSource1 {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
        /**
         * s3DataType property
         *
         * Specify an array of string values to match this event if the actual value of s3DataType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataType?: Array<string>;
        /**
         * s3DataDistributionType property
         *
         * Specify an array of string values to match this event if the actual value of s3DataDistributionType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataDistributionType?: Array<string>;
    }
    /**
     * Type definition for UserIdentity
     *
     * @struct
     */
    interface UserIdentity {
        /**
         * sessionContext property
         *
         * Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionContext?: AWSAPICallViaCloudTrail.SessionContext;
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * invokedBy property
         *
         * Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly invokedBy?: Array<string>;
    }
    /**
     * Type definition for SessionContext
     *
     * @struct
     */
    interface SessionContext {
        /**
         * webIdFederationData property
         *
         * Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly webIdFederationData?: Array<string>;
        /**
         * sessionIssuer property
         *
         * Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionIssuer?: AWSAPICallViaCloudTrail.SessionIssuer;
        /**
         * attributes property
         *
         * Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attributes?: AWSAPICallViaCloudTrail.Attributes;
    }
    /**
     * Type definition for SessionIssuer
     *
     * @struct
     */
    interface SessionIssuer {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * userName property
         *
         * Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userName?: Array<string>;
    }
    /**
     * Type definition for Attributes
     *
     * @struct
     */
    interface Attributes {
        /**
         * mfaAuthenticated property
         *
         * Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mfaAuthenticated?: Array<string>;
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.sagemaker@SageMakerAlgorithmStateChange
 */
export declare class SageMakerAlgorithmStateChange {
    /**
     * EventBridge event pattern for SageMaker Algorithm State Change
     */
    static eventPattern(options?: SageMakerAlgorithmStateChange.SageMakerAlgorithmStateChangeProps): events.EventPattern;
}
export declare namespace SageMakerAlgorithmStateChange {
    /**
     * Props type for aws.sagemaker@SageMakerAlgorithmStateChange event
     */
    interface SageMakerAlgorithmStateChangeProps {
        /**
         * AlgorithmArn property
         *
         * Specify an array of string values to match this event if the actual value of AlgorithmArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly algorithmArn?: Array<string>;
        /**
         * AlgorithmDescription property
         *
         * Specify an array of string values to match this event if the actual value of AlgorithmDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly algorithmDescription?: Array<string>;
        /**
         * AlgorithmName property
         *
         * Specify an array of string values to match this event if the actual value of AlgorithmName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly algorithmName?: Array<string>;
        /**
         * CertifyForMarketplace property
         *
         * Specify an array of string values to match this event if the actual value of CertifyForMarketplace is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly certifyForMarketplace?: Array<string>;
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<SageMakerAlgorithmStateChange.Tags>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Tags
     *
     * @struct
     */
    interface Tags {
        /**
         * Key property
         *
         * Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * Value property
         *
         * Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.sagemaker@SageMakerEndpointConfigStateChange
 */
export declare class SageMakerEndpointConfigStateChange {
    /**
     * EventBridge event pattern for SageMaker Endpoint Config State Change
     */
    static eventPattern(options?: SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeProps): events.EventPattern;
}
export declare namespace SageMakerEndpointConfigStateChange {
    /**
     * Props type for aws.sagemaker@SageMakerEndpointConfigStateChange event
     */
    interface SageMakerEndpointConfigStateChangeProps {
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<SageMakerEndpointConfigStateChange.Tags>;
        /**
         * ProductionVariants property
         *
         * Specify an array of string values to match this event if the actual value of ProductionVariants is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly productionVariants?: Array<SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeItem>;
        /**
         * EndpointConfigName property
         *
         * Specify an array of string values to match this event if the actual value of EndpointConfigName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endpointConfigName?: Array<string>;
        /**
         * CreationTime property
         *
         * Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationTime?: Array<string>;
        /**
         * EndpointConfigArn property
         *
         * Specify an array of string values to match this event if the actual value of EndpointConfigArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endpointConfigArn?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Tags
     *
     * @struct
     */
    interface Tags {
        /**
         * Key property
         *
         * Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * Value property
         *
         * Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for SageMakerEndpointConfigStateChangeItem
     *
     * @struct
     */
    interface SageMakerEndpointConfigStateChangeItem {
        /**
         * ModelName property
         *
         * Specify an array of string values to match this event if the actual value of ModelName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modelName?: Array<string>;
        /**
         * VariantName property
         *
         * Specify an array of string values to match this event if the actual value of VariantName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly variantName?: Array<string>;
        /**
         * InitialInstanceCount property
         *
         * Specify an array of string values to match this event if the actual value of InitialInstanceCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly initialInstanceCount?: Array<string>;
        /**
         * InstanceType property
         *
         * Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
        /**
         * InitialVariantWeight property
         *
         * Specify an array of string values to match this event if the actual value of InitialVariantWeight is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly initialVariantWeight?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.sagemaker@SageMakerEndpointStateChange
 */
export declare class SageMakerEndpointStateChange {
    /**
     * EventBridge event pattern for SageMaker Endpoint State Change
     */
    static eventPattern(options?: SageMakerEndpointStateChange.SageMakerEndpointStateChangeProps): events.EventPattern;
}
export declare namespace SageMakerEndpointStateChange {
    /**
     * Props type for aws.sagemaker@SageMakerEndpointStateChange event
     */
    interface SageMakerEndpointStateChangeProps {
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<SageMakerEndpointStateChange.Tags>;
        /**
         * CreationTime property
         *
         * Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationTime?: Array<string>;
        /**
         * EndpointArn property
         *
         * Specify an array of string values to match this event if the actual value of EndpointArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endpointArn?: Array<string>;
        /**
         * EndpointConfigName property
         *
         * Specify an array of string values to match this event if the actual value of EndpointConfigName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endpointConfigName?: Array<string>;
        /**
         * EndpointName property
         *
         * Specify an array of string values to match this event if the actual value of EndpointName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endpointName?: Array<string>;
        /**
         * EndpointStatus property
         *
         * Specify an array of string values to match this event if the actual value of EndpointStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endpointStatus?: Array<string>;
        /**
         * LastModifiedTime property
         *
         * Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastModifiedTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Tags
     *
     * @struct
     */
    interface Tags {
        /**
         * Key property
         *
         * Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * Value property
         *
         * Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.sagemaker@SageMakerGroundTruthLabelingJobTaskStatusChange
 */
export declare class SageMakerGroundTruthLabelingJobTaskStatusChange {
    /**
     * EventBridge event pattern for SageMaker Ground Truth Labeling Job Task Status Change
     */
    static eventPattern(options?: SageMakerGroundTruthLabelingJobTaskStatusChange.SageMakerGroundTruthLabelingJobTaskStatusChangeProps): events.EventPattern;
}
export declare namespace SageMakerGroundTruthLabelingJobTaskStatusChange {
    /**
     * Props type for aws.sagemaker@SageMakerGroundTruthLabelingJobTaskStatusChange event
     */
    interface SageMakerGroundTruthLabelingJobTaskStatusChangeProps {
        /**
         * State property
         *
         * Specify an array of string values to match this event if the actual value of State is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * labeling-job-arn property
         *
         * Specify an array of string values to match this event if the actual value of labeling-job-arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly labelingJobArn?: Array<string>;
        /**
         * workteam-team-arn property
         *
         * Specify an array of string values to match this event if the actual value of workteam-team-arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly workteamTeamArn?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.sagemaker@SageMakerHyperParameterTuningJobStateChange
 */
export declare class SageMakerHyperParameterTuningJobStateChange {
    /**
     * EventBridge event pattern for SageMaker HyperParameter Tuning Job State Change
     */
    static eventPattern(options?: SageMakerHyperParameterTuningJobStateChange.SageMakerHyperParameterTuningJobStateChangeProps): events.EventPattern;
}
export declare namespace SageMakerHyperParameterTuningJobStateChange {
    /**
     * Props type for aws.sagemaker@SageMakerHyperParameterTuningJobStateChange event
     */
    interface SageMakerHyperParameterTuningJobStateChangeProps {
        /**
         * TrainingJobStatusCounters property
         *
         * Specify an array of string values to match this event if the actual value of TrainingJobStatusCounters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingJobStatusCounters?: SageMakerHyperParameterTuningJobStateChange.TrainingJobStatusCounters;
        /**
         * ObjectiveStatusCounters property
         *
         * Specify an array of string values to match this event if the actual value of ObjectiveStatusCounters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectiveStatusCounters?: SageMakerHyperParameterTuningJobStateChange.ObjectiveStatusCounters;
        /**
         * TrainingJobDefinition property
         *
         * Specify an array of string values to match this event if the actual value of TrainingJobDefinition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingJobDefinition?: SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinition;
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<SageMakerHyperParameterTuningJobStateChange.Tags>;
        /**
         * CreationTime property
         *
         * Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationTime?: Array<string>;
        /**
         * LastModifiedTime property
         *
         * Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastModifiedTime?: Array<string>;
        /**
         * HyperParameterTuningJobName property
         *
         * Specify an array of string values to match this event if the actual value of HyperParameterTuningJobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hyperParameterTuningJobName?: Array<string>;
        /**
         * HyperParameterTuningJobStatus property
         *
         * Specify an array of string values to match this event if the actual value of HyperParameterTuningJobStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hyperParameterTuningJobStatus?: Array<string>;
        /**
         * HyperParameterTuningJobArn property
         *
         * Specify an array of string values to match this event if the actual value of HyperParameterTuningJobArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hyperParameterTuningJobArn?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for TrainingJobStatusCounters
     *
     * @struct
     */
    interface TrainingJobStatusCounters {
        /**
         * RetryableError property
         *
         * Specify an array of string values to match this event if the actual value of RetryableError is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly retryableError?: Array<string>;
        /**
         * Stopped property
         *
         * Specify an array of string values to match this event if the actual value of Stopped is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stopped?: Array<string>;
        /**
         * Completed property
         *
         * Specify an array of string values to match this event if the actual value of Completed is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly completed?: Array<string>;
        /**
         * InProgress property
         *
         * Specify an array of string values to match this event if the actual value of InProgress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inProgress?: Array<string>;
        /**
         * NonRetryableError property
         *
         * Specify an array of string values to match this event if the actual value of NonRetryableError is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly nonRetryableError?: Array<string>;
    }
    /**
     * Type definition for ObjectiveStatusCounters
     *
     * @struct
     */
    interface ObjectiveStatusCounters {
        /**
         * Succeeded property
         *
         * Specify an array of string values to match this event if the actual value of Succeeded is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly succeeded?: Array<string>;
        /**
         * Failed property
         *
         * Specify an array of string values to match this event if the actual value of Failed is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failed?: Array<string>;
        /**
         * Pending property
         *
         * Specify an array of string values to match this event if the actual value of Pending is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pending?: Array<string>;
    }
    /**
     * Type definition for TrainingJobDefinition
     *
     * @struct
     */
    interface TrainingJobDefinition {
        /**
         * AlgorithmSpecification property
         *
         * Specify an array of string values to match this event if the actual value of AlgorithmSpecification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly algorithmSpecification?: SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecification;
        /**
         * StoppingCondition property
         *
         * Specify an array of string values to match this event if the actual value of StoppingCondition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stoppingCondition?: SageMakerHyperParameterTuningJobStateChange.StoppingCondition;
        /**
         * VpcConfig property
         *
         * Specify an array of string values to match this event if the actual value of VpcConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcConfig?: SageMakerHyperParameterTuningJobStateChange.VpcConfig;
        /**
         * OutputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of OutputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputDataConfig?: SageMakerHyperParameterTuningJobStateChange.OutputDataConfig;
        /**
         * StaticHyperParameters property
         *
         * Specify an array of string values to match this event if the actual value of StaticHyperParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly staticHyperParameters?: SageMakerHyperParameterTuningJobStateChange.Tags;
        /**
         * ResourceConfig property
         *
         * Specify an array of string values to match this event if the actual value of ResourceConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceConfig?: SageMakerHyperParameterTuningJobStateChange.ResourceConfig;
        /**
         * InputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of InputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputDataConfig?: Array<SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinitionItem>;
        /**
         * RoleArn property
         *
         * Specify an array of string values to match this event if the actual value of RoleArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly roleArn?: Array<string>;
    }
    /**
     * Type definition for AlgorithmSpecification
     *
     * @struct
     */
    interface AlgorithmSpecification {
        /**
         * TrainingInputMode property
         *
         * Specify an array of string values to match this event if the actual value of TrainingInputMode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingInputMode?: Array<string>;
        /**
         * MetricDefinitions property
         *
         * Specify an array of string values to match this event if the actual value of MetricDefinitions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricDefinitions?: Array<SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecificationItem>;
        /**
         * TrainingImage property
         *
         * Specify an array of string values to match this event if the actual value of TrainingImage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingImage?: Array<string>;
    }
    /**
     * Type definition for AlgorithmSpecificationItem
     *
     * @struct
     */
    interface AlgorithmSpecificationItem {
        /**
         * Regex property
         *
         * Specify an array of string values to match this event if the actual value of Regex is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly regex?: Array<string>;
        /**
         * Name property
         *
         * Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for StoppingCondition
     *
     * @struct
     */
    interface StoppingCondition {
        /**
         * MaxRuntimeInSeconds property
         *
         * Specify an array of string values to match this event if the actual value of MaxRuntimeInSeconds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxRuntimeInSeconds?: Array<string>;
    }
    /**
     * Type definition for VpcConfig
     *
     * @struct
     */
    interface VpcConfig {
        /**
         * Subnets property
         *
         * Specify an array of string values to match this event if the actual value of Subnets is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnets?: Array<string>;
        /**
         * SecurityGroupIds property
         *
         * Specify an array of string values to match this event if the actual value of SecurityGroupIds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly securityGroupIds?: Array<string>;
    }
    /**
     * Type definition for OutputDataConfig
     *
     * @struct
     */
    interface OutputDataConfig {
        /**
         * KmsKeyId property
         *
         * Specify an array of string values to match this event if the actual value of KmsKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly kmsKeyId?: Array<string>;
        /**
         * S3OutputPath property
         *
         * Specify an array of string values to match this event if the actual value of S3OutputPath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3OutputPath?: Array<string>;
    }
    /**
     * Type definition for Tags
     *
     * @struct
     */
    interface Tags {
        /**
         * Key property
         *
         * Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * Value property
         *
         * Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for ResourceConfig
     *
     * @struct
     */
    interface ResourceConfig {
        /**
         * InstanceCount property
         *
         * Specify an array of string values to match this event if the actual value of InstanceCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceCount?: Array<string>;
        /**
         * VolumeSizeInGB property
         *
         * Specify an array of string values to match this event if the actual value of VolumeSizeInGB is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly volumeSizeInGb?: Array<string>;
        /**
         * VolumeKmsKeyId property
         *
         * Specify an array of string values to match this event if the actual value of VolumeKmsKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly volumeKmsKeyId?: Array<string>;
        /**
         * InstanceType property
         *
         * Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
    }
    /**
     * Type definition for TrainingJobDefinitionItem
     *
     * @struct
     */
    interface TrainingJobDefinitionItem {
        /**
         * DataSource property
         *
         * Specify an array of string values to match this event if the actual value of DataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSource?: SageMakerHyperParameterTuningJobStateChange.DataSource;
        /**
         * ChannelName property
         *
         * Specify an array of string values to match this event if the actual value of ChannelName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelName?: Array<string>;
        /**
         * ContentType property
         *
         * Specify an array of string values to match this event if the actual value of ContentType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly contentType?: Array<string>;
        /**
         * RecordWrapperType property
         *
         * Specify an array of string values to match this event if the actual value of RecordWrapperType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly recordWrapperType?: Array<string>;
        /**
         * CompressionType property
         *
         * Specify an array of string values to match this event if the actual value of CompressionType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly compressionType?: Array<string>;
    }
    /**
     * Type definition for DataSource
     *
     * @struct
     */
    interface DataSource {
        /**
         * S3DataSource property
         *
         * Specify an array of string values to match this event if the actual value of S3DataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataSource?: SageMakerHyperParameterTuningJobStateChange.S3DataSource;
    }
    /**
     * Type definition for S3DataSource
     *
     * @struct
     */
    interface S3DataSource {
        /**
         * S3DataDistributionType property
         *
         * Specify an array of string values to match this event if the actual value of S3DataDistributionType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataDistributionType?: Array<string>;
        /**
         * S3Uri property
         *
         * Specify an array of string values to match this event if the actual value of S3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
        /**
         * S3DataType property
         *
         * Specify an array of string values to match this event if the actual value of S3DataType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataType?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.sagemaker@SageMakerModelBuildingPipelineExecutionStatusChange
 */
export declare class SageMakerModelBuildingPipelineExecutionStatusChange {
    /**
     * EventBridge event pattern for SageMaker Model Building Pipeline Execution Status Change
     */
    static eventPattern(options?: SageMakerModelBuildingPipelineExecutionStatusChange.SageMakerModelBuildingPipelineExecutionStatusChangeProps): events.EventPattern;
}
export declare namespace SageMakerModelBuildingPipelineExecutionStatusChange {
    /**
     * Props type for aws.sagemaker@SageMakerModelBuildingPipelineExecutionStatusChange event
     */
    interface SageMakerModelBuildingPipelineExecutionStatusChangeProps {
        /**
         * currentPipelineExecutionStatus property
         *
         * Specify an array of string values to match this event if the actual value of currentPipelineExecutionStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentPipelineExecutionStatus?: Array<string>;
        /**
         * executionEndTime property
         *
         * Specify an array of string values to match this event if the actual value of executionEndTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly executionEndTime?: Array<string>;
        /**
         * executionStartTime property
         *
         * Specify an array of string values to match this event if the actual value of executionStartTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly executionStartTime?: Array<string>;
        /**
         * pipelineArn property
         *
         * Specify an array of string values to match this event if the actual value of pipelineArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipelineArn?: Array<string>;
        /**
         * pipelineExecutionArn property
         *
         * Specify an array of string values to match this event if the actual value of pipelineExecutionArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipelineExecutionArn?: Array<string>;
        /**
         * pipelineExecutionDescription property
         *
         * Specify an array of string values to match this event if the actual value of pipelineExecutionDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipelineExecutionDescription?: Array<string>;
        /**
         * pipelineExecutionDisplayName property
         *
         * Specify an array of string values to match this event if the actual value of pipelineExecutionDisplayName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipelineExecutionDisplayName?: Array<string>;
        /**
         * previousPipelineExecutionStatus property
         *
         * Specify an array of string values to match this event if the actual value of previousPipelineExecutionStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousPipelineExecutionStatus?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.sagemaker@SageMakerModelBuildingPipelineExecutionStepStatusChange
 */
export declare class SageMakerModelBuildingPipelineExecutionStepStatusChange {
    /**
     * EventBridge event pattern for SageMaker Model Building Pipeline Execution Step Status Change
     */
    static eventPattern(options?: SageMakerModelBuildingPipelineExecutionStepStatusChange.SageMakerModelBuildingPipelineExecutionStepStatusChangeProps): events.EventPattern;
}
export declare namespace SageMakerModelBuildingPipelineExecutionStepStatusChange {
    /**
     * Props type for aws.sagemaker@SageMakerModelBuildingPipelineExecutionStepStatusChange event
     */
    interface SageMakerModelBuildingPipelineExecutionStepStatusChangeProps {
        /**
         * cacheHitResult property
         *
         * Specify an array of string values to match this event if the actual value of cacheHitResult is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cacheHitResult?: SageMakerModelBuildingPipelineExecutionStepStatusChange.CacheHitResult;
        /**
         * metadata property
         *
         * Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metadata?: SageMakerModelBuildingPipelineExecutionStepStatusChange.Metadata;
        /**
         * currentStepStatus property
         *
         * Specify an array of string values to match this event if the actual value of currentStepStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentStepStatus?: Array<string>;
        /**
         * failureReason property
         *
         * Specify an array of string values to match this event if the actual value of failureReason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureReason?: Array<string>;
        /**
         * pipelineArn property
         *
         * Specify an array of string values to match this event if the actual value of pipelineArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipelineArn?: Array<string>;
        /**
         * pipelineExecutionArn property
         *
         * Specify an array of string values to match this event if the actual value of pipelineExecutionArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipelineExecutionArn?: Array<string>;
        /**
         * previousStepStatus property
         *
         * Specify an array of string values to match this event if the actual value of previousStepStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousStepStatus?: Array<string>;
        /**
         * stepEndTime property
         *
         * Specify an array of string values to match this event if the actual value of stepEndTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stepEndTime?: Array<string>;
        /**
         * stepName property
         *
         * Specify an array of string values to match this event if the actual value of stepName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stepName?: Array<string>;
        /**
         * stepStartTime property
         *
         * Specify an array of string values to match this event if the actual value of stepStartTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stepStartTime?: Array<string>;
        /**
         * stepType property
         *
         * Specify an array of string values to match this event if the actual value of stepType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stepType?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for CacheHitResult
     *
     * @struct
     */
    interface CacheHitResult {
        /**
         * sourcePipelineExecutionArn property
         *
         * Specify an array of string values to match this event if the actual value of sourcePipelineExecutionArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourcePipelineExecutionArn?: Array<string>;
    }
    /**
     * Type definition for Metadata
     *
     * @struct
     */
    interface Metadata {
        /**
         * processingJob property
         *
         * Specify an array of string values to match this event if the actual value of processingJob is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly processingJob?: SageMakerModelBuildingPipelineExecutionStepStatusChange.ProcessingJob;
    }
    /**
     * Type definition for ProcessingJob
     *
     * @struct
     */
    interface ProcessingJob {
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.sagemaker@SageMakerModelPackageStateChange
 */
export declare class SageMakerModelPackageStateChange {
    /**
     * EventBridge event pattern for SageMaker Model Package State Change
     */
    static eventPattern(options?: SageMakerModelPackageStateChange.SageMakerModelPackageStateChangeProps): events.EventPattern;
}
export declare namespace SageMakerModelPackageStateChange {
    /**
     * Props type for aws.sagemaker@SageMakerModelPackageStateChange event
     */
    interface SageMakerModelPackageStateChangeProps {
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<SageMakerModelPackageStateChange.Tags>;
        /**
         * CertifyForMarketplace property
         *
         * Specify an array of string values to match this event if the actual value of CertifyForMarketplace is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly certifyForMarketplace?: Array<string>;
        /**
         * ModelPackageArn property
         *
         * Specify an array of string values to match this event if the actual value of ModelPackageArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modelPackageArn?: Array<string>;
        /**
         * ModelPackageDescription property
         *
         * Specify an array of string values to match this event if the actual value of ModelPackageDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modelPackageDescription?: Array<string>;
        /**
         * ModelPackageName property
         *
         * Specify an array of string values to match this event if the actual value of ModelPackageName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modelPackageName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Tags
     *
     * @struct
     */
    interface Tags {
        /**
         * Key property
         *
         * Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * Value property
         *
         * Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.sagemaker@SageMakerModelStateChange
 */
export declare class SageMakerModelStateChange {
    /**
     * EventBridge event pattern for SageMaker Model State Change
     */
    static eventPattern(options?: SageMakerModelStateChange.SageMakerModelStateChangeProps): events.EventPattern;
}
export declare namespace SageMakerModelStateChange {
    /**
     * Props type for aws.sagemaker@SageMakerModelStateChange event
     */
    interface SageMakerModelStateChangeProps {
        /**
         * PrimaryContainer property
         *
         * Specify an array of string values to match this event if the actual value of PrimaryContainer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly primaryContainer?: SageMakerModelStateChange.PrimaryContainer;
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<SageMakerModelStateChange.Tags>;
        /**
         * ModelArn property
         *
         * Specify an array of string values to match this event if the actual value of ModelArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modelArn?: Array<string>;
        /**
         * ExecutionRoleArn property
         *
         * Specify an array of string values to match this event if the actual value of ExecutionRoleArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly executionRoleArn?: Array<string>;
        /**
         * ModelName property
         *
         * Specify an array of string values to match this event if the actual value of ModelName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modelName?: Array<string>;
        /**
         * CreationTime property
         *
         * Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for PrimaryContainer
     *
     * @struct
     */
    interface PrimaryContainer {
        /**
         * ContainerHostname property
         *
         * Specify an array of string values to match this event if the actual value of ContainerHostname is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerHostname?: Array<string>;
        /**
         * ModelDataUrl property
         *
         * Specify an array of string values to match this event if the actual value of ModelDataUrl is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modelDataUrl?: Array<string>;
        /**
         * Image property
         *
         * Specify an array of string values to match this event if the actual value of Image is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly image?: Array<string>;
    }
    /**
     * Type definition for Tags
     *
     * @struct
     */
    interface Tags {
        /**
         * Key property
         *
         * Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * Value property
         *
         * Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.sagemaker@SageMakerNotebookInstanceStateChange
 */
export declare class SageMakerNotebookInstanceStateChange {
    /**
     * EventBridge event pattern for SageMaker Notebook Instance State Change
     */
    static eventPattern(options?: SageMakerNotebookInstanceStateChange.SageMakerNotebookInstanceStateChangeProps): events.EventPattern;
}
export declare namespace SageMakerNotebookInstanceStateChange {
    /**
     * Props type for aws.sagemaker@SageMakerNotebookInstanceStateChange event
     */
    interface SageMakerNotebookInstanceStateChangeProps {
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<SageMakerNotebookInstanceStateChange.Tags>;
        /**
         * CreationTime property
         *
         * Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationTime?: Array<string>;
        /**
         * InstanceType property
         *
         * Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
        /**
         * LastModifiedTime property
         *
         * Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastModifiedTime?: Array<string>;
        /**
         * NotebookInstanceArn property
         *
         * Specify an array of string values to match this event if the actual value of NotebookInstanceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notebookInstanceArn?: Array<string>;
        /**
         * NotebookInstanceLifecycleConfigName property
         *
         * Specify an array of string values to match this event if the actual value of NotebookInstanceLifecycleConfigName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notebookInstanceLifecycleConfigName?: Array<string>;
        /**
         * NotebookInstanceName property
         *
         * Specify an array of string values to match this event if the actual value of NotebookInstanceName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notebookInstanceName?: Array<string>;
        /**
         * NotebookInstanceStatus property
         *
         * Specify an array of string values to match this event if the actual value of NotebookInstanceStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notebookInstanceStatus?: Array<string>;
        /**
         * RoleArn property
         *
         * Specify an array of string values to match this event if the actual value of RoleArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly roleArn?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Tags
     *
     * @struct
     */
    interface Tags {
        /**
         * Key property
         *
         * Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * Value property
         *
         * Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.sagemaker@SageMakerNotebookLifecycleConfigStateChange
 */
export declare class SageMakerNotebookLifecycleConfigStateChange {
    /**
     * EventBridge event pattern for SageMaker Notebook Lifecycle Config State Change
     */
    static eventPattern(options?: SageMakerNotebookLifecycleConfigStateChange.SageMakerNotebookLifecycleConfigStateChangeProps): events.EventPattern;
}
export declare namespace SageMakerNotebookLifecycleConfigStateChange {
    /**
     * Props type for aws.sagemaker@SageMakerNotebookLifecycleConfigStateChange event
     */
    interface SageMakerNotebookLifecycleConfigStateChangeProps {
        /**
         * CreationTime property
         *
         * Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationTime?: Array<string>;
        /**
         * LastModifiedTime property
         *
         * Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastModifiedTime?: Array<string>;
        /**
         * NotebookInstanceLifecycleConfigArn property
         *
         * Specify an array of string values to match this event if the actual value of NotebookInstanceLifecycleConfigArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notebookInstanceLifecycleConfigArn?: Array<string>;
        /**
         * NotebookInstanceLifecycleConfigName property
         *
         * Specify an array of string values to match this event if the actual value of NotebookInstanceLifecycleConfigName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notebookInstanceLifecycleConfigName?: Array<string>;
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<SageMakerNotebookLifecycleConfigStateChange.Tags>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Tags
     *
     * @struct
     */
    interface Tags {
        /**
         * Key property
         *
         * Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * Value property
         *
         * Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.sagemaker@SageMakerTrainingJobStateChange
 */
export declare class SageMakerTrainingJobStateChange {
    /**
     * EventBridge event pattern for SageMaker Training Job State Change
     */
    static eventPattern(options?: SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeProps): events.EventPattern;
}
export declare namespace SageMakerTrainingJobStateChange {
    /**
     * Props type for aws.sagemaker@SageMakerTrainingJobStateChange event
     */
    interface SageMakerTrainingJobStateChangeProps {
        /**
         * HyperParameters property
         *
         * Specify an array of string values to match this event if the actual value of HyperParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hyperParameters?: Array<string>;
        /**
         * AlgorithmSpecification property
         *
         * Specify an array of string values to match this event if the actual value of AlgorithmSpecification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly algorithmSpecification?: SageMakerTrainingJobStateChange.AlgorithmSpecification;
        /**
         * OutputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of OutputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputDataConfig?: SageMakerTrainingJobStateChange.OutputDataConfig;
        /**
         * ModelArtifacts property
         *
         * Specify an array of string values to match this event if the actual value of ModelArtifacts is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modelArtifacts?: SageMakerTrainingJobStateChange.ModelArtifacts;
        /**
         * StoppingCondition property
         *
         * Specify an array of string values to match this event if the actual value of StoppingCondition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stoppingCondition?: SageMakerTrainingJobStateChange.StoppingCondition;
        /**
         * ResourceConfig property
         *
         * Specify an array of string values to match this event if the actual value of ResourceConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceConfig?: SageMakerTrainingJobStateChange.ResourceConfig;
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<SageMakerTrainingJobStateChange.Tags>;
        /**
         * TrainingJobName property
         *
         * Specify an array of string values to match this event if the actual value of TrainingJobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingJobName?: Array<string>;
        /**
         * SecondaryStatus property
         *
         * Specify an array of string values to match this event if the actual value of SecondaryStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly secondaryStatus?: Array<string>;
        /**
         * InputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of InputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputDataConfig?: Array<SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem>;
        /**
         * SecondaryStatusTransitions property
         *
         * Specify an array of string values to match this event if the actual value of SecondaryStatusTransitions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly secondaryStatusTransitions?: Array<SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem1>;
        /**
         * RoleArn property
         *
         * Specify an array of string values to match this event if the actual value of RoleArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly roleArn?: Array<string>;
        /**
         * TrainingJobStatus property
         *
         * Specify an array of string values to match this event if the actual value of TrainingJobStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingJobStatus?: Array<string>;
        /**
         * TrainingJobArn property
         *
         * Specify an array of string values to match this event if the actual value of TrainingJobArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingJobArn?: Array<string>;
        /**
         * CreationTime property
         *
         * Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationTime?: Array<string>;
        /**
         * LastModifiedTime property
         *
         * Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastModifiedTime?: Array<string>;
        /**
         * TrainingStartTime property
         *
         * Specify an array of string values to match this event if the actual value of TrainingStartTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingStartTime?: Array<string>;
        /**
         * TrainingEndTime property
         *
         * Specify an array of string values to match this event if the actual value of TrainingEndTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingEndTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for AlgorithmSpecification
     *
     * @struct
     */
    interface AlgorithmSpecification {
        /**
         * TrainingInputMode property
         *
         * Specify an array of string values to match this event if the actual value of TrainingInputMode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingInputMode?: Array<string>;
        /**
         * TrainingImage property
         *
         * Specify an array of string values to match this event if the actual value of TrainingImage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly trainingImage?: Array<string>;
    }
    /**
     * Type definition for OutputDataConfig
     *
     * @struct
     */
    interface OutputDataConfig {
        /**
         * S3OutputPath property
         *
         * Specify an array of string values to match this event if the actual value of S3OutputPath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3OutputPath?: Array<string>;
    }
    /**
     * Type definition for ModelArtifacts
     *
     * @struct
     */
    interface ModelArtifacts {
        /**
         * S3ModelArtifacts property
         *
         * Specify an array of string values to match this event if the actual value of S3ModelArtifacts is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3ModelArtifacts?: Array<string>;
    }
    /**
     * Type definition for StoppingCondition
     *
     * @struct
     */
    interface StoppingCondition {
        /**
         * MaxRuntimeInSeconds property
         *
         * Specify an array of string values to match this event if the actual value of MaxRuntimeInSeconds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxRuntimeInSeconds?: Array<string>;
    }
    /**
     * Type definition for ResourceConfig
     *
     * @struct
     */
    interface ResourceConfig {
        /**
         * InstanceCount property
         *
         * Specify an array of string values to match this event if the actual value of InstanceCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceCount?: Array<string>;
        /**
         * VolumeSizeInGB property
         *
         * Specify an array of string values to match this event if the actual value of VolumeSizeInGB is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly volumeSizeInGb?: Array<string>;
        /**
         * InstanceType property
         *
         * Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
    }
    /**
     * Type definition for Tags
     *
     * @struct
     */
    interface Tags {
        /**
         * Key property
         *
         * Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * Value property
         *
         * Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for SageMakerTrainingJobStateChangeItem
     *
     * @struct
     */
    interface SageMakerTrainingJobStateChangeItem {
        /**
         * DataSource property
         *
         * Specify an array of string values to match this event if the actual value of DataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSource?: SageMakerTrainingJobStateChange.DataSource;
        /**
         * ChannelName property
         *
         * Specify an array of string values to match this event if the actual value of ChannelName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelName?: Array<string>;
        /**
         * ContentType property
         *
         * Specify an array of string values to match this event if the actual value of ContentType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly contentType?: Array<string>;
        /**
         * RecordWrapperType property
         *
         * Specify an array of string values to match this event if the actual value of RecordWrapperType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly recordWrapperType?: Array<string>;
        /**
         * CompressionType property
         *
         * Specify an array of string values to match this event if the actual value of CompressionType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly compressionType?: Array<string>;
    }
    /**
     * Type definition for DataSource
     *
     * @struct
     */
    interface DataSource {
        /**
         * S3DataSource property
         *
         * Specify an array of string values to match this event if the actual value of S3DataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataSource?: SageMakerTrainingJobStateChange.S3DataSource;
    }
    /**
     * Type definition for S3DataSource
     *
     * @struct
     */
    interface S3DataSource {
        /**
         * S3DataDistributionType property
         *
         * Specify an array of string values to match this event if the actual value of S3DataDistributionType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataDistributionType?: Array<string>;
        /**
         * S3Uri property
         *
         * Specify an array of string values to match this event if the actual value of S3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
        /**
         * S3DataType property
         *
         * Specify an array of string values to match this event if the actual value of S3DataType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataType?: Array<string>;
    }
    /**
     * Type definition for SageMakerTrainingJobStateChangeItem_1
     *
     * @struct
     */
    interface SageMakerTrainingJobStateChangeItem1 {
        /**
         * Status property
         *
         * Specify an array of string values to match this event if the actual value of Status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * StartTime property
         *
         * Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * StatusMessage property
         *
         * Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusMessage?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.sagemaker@SageMakerTransformJobStateChange
 */
export declare class SageMakerTransformJobStateChange {
    /**
     * EventBridge event pattern for SageMaker Transform Job State Change
     */
    static eventPattern(options?: SageMakerTransformJobStateChange.SageMakerTransformJobStateChangeProps): events.EventPattern;
}
export declare namespace SageMakerTransformJobStateChange {
    /**
     * Props type for aws.sagemaker@SageMakerTransformJobStateChange event
     */
    interface SageMakerTransformJobStateChangeProps {
        /**
         * TransformResources property
         *
         * Specify an array of string values to match this event if the actual value of TransformResources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformResources?: SageMakerTransformJobStateChange.TransformResources;
        /**
         * TransformOutput property
         *
         * Specify an array of string values to match this event if the actual value of TransformOutput is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformOutput?: SageMakerTransformJobStateChange.TransformOutput;
        /**
         * TransformInput property
         *
         * Specify an array of string values to match this event if the actual value of TransformInput is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformInput?: SageMakerTransformJobStateChange.TransformInput;
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<SageMakerTransformJobStateChange.Tags>;
        /**
         * TransformStartTime property
         *
         * Specify an array of string values to match this event if the actual value of TransformStartTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformStartTime?: Array<string>;
        /**
         * ModelName property
         *
         * Specify an array of string values to match this event if the actual value of ModelName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly modelName?: Array<string>;
        /**
         * CreationTime property
         *
         * Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationTime?: Array<string>;
        /**
         * TransformJobArn property
         *
         * Specify an array of string values to match this event if the actual value of TransformJobArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformJobArn?: Array<string>;
        /**
         * TransformJobStatus property
         *
         * Specify an array of string values to match this event if the actual value of TransformJobStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformJobStatus?: Array<string>;
        /**
         * TransformJobName property
         *
         * Specify an array of string values to match this event if the actual value of TransformJobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformJobName?: Array<string>;
        /**
         * TransformEndTime property
         *
         * Specify an array of string values to match this event if the actual value of TransformEndTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformEndTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for TransformResources
     *
     * @struct
     */
    interface TransformResources {
        /**
         * InstanceCount property
         *
         * Specify an array of string values to match this event if the actual value of InstanceCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceCount?: Array<string>;
        /**
         * InstanceType property
         *
         * Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
    }
    /**
     * Type definition for TransformOutput
     *
     * @struct
     */
    interface TransformOutput {
        /**
         * AssembleWith property
         *
         * Specify an array of string values to match this event if the actual value of AssembleWith is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly assembleWith?: Array<string>;
        /**
         * S3OutputPath property
         *
         * Specify an array of string values to match this event if the actual value of S3OutputPath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3OutputPath?: Array<string>;
    }
    /**
     * Type definition for TransformInput
     *
     * @struct
     */
    interface TransformInput {
        /**
         * DataSource property
         *
         * Specify an array of string values to match this event if the actual value of DataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSource?: SageMakerTransformJobStateChange.DataSource;
        /**
         * ContentType property
         *
         * Specify an array of string values to match this event if the actual value of ContentType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly contentType?: Array<string>;
        /**
         * SplitType property
         *
         * Specify an array of string values to match this event if the actual value of SplitType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly splitType?: Array<string>;
        /**
         * CompressionType property
         *
         * Specify an array of string values to match this event if the actual value of CompressionType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly compressionType?: Array<string>;
    }
    /**
     * Type definition for DataSource
     *
     * @struct
     */
    interface DataSource {
        /**
         * S3DataSource property
         *
         * Specify an array of string values to match this event if the actual value of S3DataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataSource?: SageMakerTransformJobStateChange.S3DataSource;
    }
    /**
     * Type definition for S3DataSource
     *
     * @struct
     */
    interface S3DataSource {
        /**
         * S3Uri property
         *
         * Specify an array of string values to match this event if the actual value of S3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
        /**
         * S3DataType property
         *
         * Specify an array of string values to match this event if the actual value of S3DataType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3DataType?: Array<string>;
    }
    /**
     * Type definition for Tags
     *
     * @struct
     */
    interface Tags {
        /**
         * Key property
         *
         * Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * Value property
         *
         * Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
}
