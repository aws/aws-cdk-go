import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.mgn@MGNSourceServerDataReplicationStalledChange
 */
export declare class MGNSourceServerDataReplicationStalledChange {
    /**
     * EventBridge event pattern for MGN Source Server Data Replication Stalled Change
     */
    static eventPattern(options?: MGNSourceServerDataReplicationStalledChange.MGNSourceServerDataReplicationStalledChangeProps): events.EventPattern;
}
export declare namespace MGNSourceServerDataReplicationStalledChange {
    /**
     * Props type for aws.mgn@MGNSourceServerDataReplicationStalledChange event
     */
    interface MGNSourceServerDataReplicationStalledChangeProps {
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.mgn@MGNSourceServerLaunchResult
 */
export declare class MGNSourceServerLaunchResult {
    /**
     * EventBridge event pattern for MGN Source Server Launch Result
     */
    static eventPattern(options?: MGNSourceServerLaunchResult.MGNSourceServerLaunchResultProps): events.EventPattern;
}
export declare namespace MGNSourceServerLaunchResult {
    /**
     * Props type for aws.mgn@MGNSourceServerLaunchResult event
     */
    interface MGNSourceServerLaunchResultProps {
        /**
         * job-id property
         *
         * Specify an array of string values to match this event if the actual value of job-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.mgn@MGNSourceServerLifecycleStateChange
 */
export declare class MGNSourceServerLifecycleStateChange {
    /**
     * EventBridge event pattern for MGN Source Server Lifecycle State Change
     */
    static eventPattern(options?: MGNSourceServerLifecycleStateChange.MGNSourceServerLifecycleStateChangeProps): events.EventPattern;
}
export declare namespace MGNSourceServerLifecycleStateChange {
    /**
     * Props type for aws.mgn@MGNSourceServerLifecycleStateChange event
     */
    interface MGNSourceServerLifecycleStateChangeProps {
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
