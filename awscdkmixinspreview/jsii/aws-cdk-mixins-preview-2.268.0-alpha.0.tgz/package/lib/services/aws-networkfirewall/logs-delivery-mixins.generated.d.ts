import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-networkfirewall";
/**
 * Builder for CfnFirewallLogsMixin to generate DENY_LOGS for CfnFirewall
 *
 * @cloudformationResource AWS::NetworkFirewall::Firewall
 * @logType DENY_LOGS
 * @stability external
 */
export declare class CfnFirewallDenyLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnFirewallDenyLogsS3Props): CfnFirewallLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnFirewallDenyLogsLogGroupProps): CfnFirewallLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnFirewallDenyLogsFirehoseProps): CfnFirewallLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnFirewallDenyLogsDestProps): CfnFirewallLogsMixin;
}
/**
 * Builder for CfnFirewallLogsMixin to generate ALERT_LOGS for CfnFirewall
 *
 * @cloudformationResource AWS::NetworkFirewall::Firewall
 * @logType ALERT_LOGS
 * @stability external
 */
export declare class CfnFirewallAlertLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnFirewallAlertLogsS3Props): CfnFirewallLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnFirewallAlertLogsLogGroupProps): CfnFirewallLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnFirewallAlertLogsFirehoseProps): CfnFirewallLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnFirewallAlertLogsDestProps): CfnFirewallLogsMixin;
}
/**
 * Builder for CfnFirewallLogsMixin to generate ALLOW_LOGS for CfnFirewall
 *
 * @cloudformationResource AWS::NetworkFirewall::Firewall
 * @logType ALLOW_LOGS
 * @stability external
 */
export declare class CfnFirewallAllowLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnFirewallAllowLogsS3Props): CfnFirewallLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnFirewallAllowLogsLogGroupProps): CfnFirewallLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnFirewallAllowLogsFirehoseProps): CfnFirewallLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnFirewallAllowLogsDestProps): CfnFirewallLogsMixin;
}
/**
 * Use the firewall to provide stateful, managed, network firewall and intrusion detection and prevention filtering for your VPCs in Amazon VPC .
 *
 * The firewall defines the configuration settings for an AWS Network Firewall firewall. The settings include the firewall policy, the subnets in your VPC to use for the firewall endpoints, and any tags that are attached to the firewall AWS resource.
 *
 * @cloudformationResource AWS::NetworkFirewall::Firewall
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkfirewall-firewall.html
 */
export declare class CfnFirewallLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly DENY_LOGS: CfnFirewallDenyLogs;
    static readonly ALERT_LOGS: CfnFirewallAlertLogs;
    static readonly ALLOW_LOGS: CfnFirewallAllowLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::NetworkFirewall::Firewall`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnFirewall;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnFirewallDenyLogs.
 */
export declare class CfnFirewallDenyLogsOutputFormat {
}
export declare namespace CfnFirewallDenyLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnFirewallDenyLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ARN = "resource_arn",
    RESOURCEID = "resourceId",
    CLIENT_SRC_IP = "client_src_ip",
    CLIENT_SRC_PORT = "client_src_port",
    SRC_VPC = "src_vpc",
    SRC_VPCE = "src_vpce",
    VPCE_ACCOUNT_ID = "vpce_account_id",
    DEST_DOMAIN = "dest_domain",
    URL = "url",
    HTTP_METHOD = "http_method",
    DEST_IP = "dest_ip",
    DEST_PORT = "dest_port",
    HTTP_STATUS_CODE = "http_status_code",
    FIRST_ALERT_MATCH = "first_alert_match",
    ALL_MATCHES = "all_matches",
    FINAL_RULE_NAME = "final_rule_name",
    FINAL_RULE_GROUP_NAME = "final_rule_group_name",
    REQUEST_SIZE = "request_size",
    RESPONSE_SIZE = "response_size",
    EVENT_TIMESTAMP = "event_timestamp",
    PROXY_NAME = "proxy_name",
    FINAL_ACTION = "final_action"
}
export interface CfnFirewallDenyLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnFirewallDenyLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFirewallDenyLogsRecordFields>;
}
export interface CfnFirewallDenyLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnFirewallDenyLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFirewallDenyLogsRecordFields>;
}
export interface CfnFirewallDenyLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnFirewallDenyLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFirewallDenyLogsRecordFields>;
}
export interface CfnFirewallDenyLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFirewallDenyLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnFirewallAlertLogs.
 */
export declare class CfnFirewallAlertLogsOutputFormat {
}
export declare namespace CfnFirewallAlertLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnFirewallAlertLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ARN = "resource_arn",
    RESOURCEID = "resourceId",
    CLIENT_SRC_IP = "client_src_ip",
    CLIENT_SRC_PORT = "client_src_port",
    SRC_VPC = "src_vpc",
    SRC_VPCE = "src_vpce",
    VPCE_ACCOUNT_ID = "vpce_account_id",
    DEST_DOMAIN = "dest_domain",
    URL = "url",
    HTTP_METHOD = "http_method",
    DEST_IP = "dest_ip",
    DEST_PORT = "dest_port",
    HTTP_STATUS_CODE = "http_status_code",
    FIRST_ALERT_MATCH = "first_alert_match",
    ALL_MATCHES = "all_matches",
    FINAL_RULE_NAME = "final_rule_name",
    FINAL_RULE_GROUP_NAME = "final_rule_group_name",
    REQUEST_SIZE = "request_size",
    RESPONSE_SIZE = "response_size",
    EVENT_TIMESTAMP = "event_timestamp",
    PROXY_NAME = "proxy_name",
    FINAL_ACTION = "final_action"
}
export interface CfnFirewallAlertLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnFirewallAlertLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFirewallAlertLogsRecordFields>;
}
export interface CfnFirewallAlertLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnFirewallAlertLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFirewallAlertLogsRecordFields>;
}
export interface CfnFirewallAlertLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnFirewallAlertLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFirewallAlertLogsRecordFields>;
}
export interface CfnFirewallAlertLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFirewallAlertLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnFirewallAllowLogs.
 */
export declare class CfnFirewallAllowLogsOutputFormat {
}
export declare namespace CfnFirewallAllowLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnFirewallAllowLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ARN = "resource_arn",
    RESOURCEID = "resourceId",
    CLIENT_SRC_IP = "client_src_ip",
    CLIENT_SRC_PORT = "client_src_port",
    SRC_VPC = "src_vpc",
    SRC_VPCE = "src_vpce",
    VPCE_ACCOUNT_ID = "vpce_account_id",
    DEST_DOMAIN = "dest_domain",
    URL = "url",
    HTTP_METHOD = "http_method",
    DEST_IP = "dest_ip",
    DEST_PORT = "dest_port",
    HTTP_STATUS_CODE = "http_status_code",
    FIRST_ALERT_MATCH = "first_alert_match",
    ALL_MATCHES = "all_matches",
    FINAL_RULE_NAME = "final_rule_name",
    FINAL_RULE_GROUP_NAME = "final_rule_group_name",
    REQUEST_SIZE = "request_size",
    RESPONSE_SIZE = "response_size",
    EVENT_TIMESTAMP = "event_timestamp",
    PROXY_NAME = "proxy_name",
    FINAL_ACTION = "final_action"
}
export interface CfnFirewallAllowLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnFirewallAllowLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFirewallAllowLogsRecordFields>;
}
export interface CfnFirewallAllowLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnFirewallAllowLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFirewallAllowLogsRecordFields>;
}
export interface CfnFirewallAllowLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnFirewallAllowLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFirewallAllowLogsRecordFields>;
}
export interface CfnFirewallAllowLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFirewallAllowLogsRecordFields>;
}
