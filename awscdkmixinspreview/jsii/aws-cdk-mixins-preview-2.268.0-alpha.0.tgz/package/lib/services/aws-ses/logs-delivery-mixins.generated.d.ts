import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-ses";
/**
 * Builder for CfnMailManagerIngressPointLogsMixin to generate APPLICATION_LOGS for CfnMailManagerIngressPoint
 *
 * @cloudformationResource AWS::SES::MailManagerIngressPoint
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnMailManagerIngressPointApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnMailManagerIngressPointApplicationLogsS3Props): CfnMailManagerIngressPointLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnMailManagerIngressPointApplicationLogsLogGroupProps): CfnMailManagerIngressPointLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnMailManagerIngressPointApplicationLogsFirehoseProps): CfnMailManagerIngressPointLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnMailManagerIngressPointApplicationLogsDestProps): CfnMailManagerIngressPointLogsMixin;
}
/**
 * Builder for CfnMailManagerIngressPointLogsMixin to generate TRAFFIC_POLICY_DEBUG_LOGS for CfnMailManagerIngressPoint
 *
 * @cloudformationResource AWS::SES::MailManagerIngressPoint
 * @logType TRAFFIC_POLICY_DEBUG_LOGS
 * @stability external
 */
export declare class CfnMailManagerIngressPointTrafficPolicyDebugLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props): CfnMailManagerIngressPointLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnMailManagerIngressPointTrafficPolicyDebugLogsLogGroupProps): CfnMailManagerIngressPointLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnMailManagerIngressPointTrafficPolicyDebugLogsFirehoseProps): CfnMailManagerIngressPointLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnMailManagerIngressPointTrafficPolicyDebugLogsDestProps): CfnMailManagerIngressPointLogsMixin;
}
/**
 * Resource to provision an ingress endpoint for receiving email.
 *
 * An ingress endpoint serves as the entry point for incoming emails, allowing you to define how emails are received and processed within your AWS environment.
 *
 * @cloudformationResource AWS::SES::MailManagerIngressPoint
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ses-mailmanageringresspoint.html
 */
export declare class CfnMailManagerIngressPointLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnMailManagerIngressPointApplicationLogs;
    static readonly TRAFFIC_POLICY_DEBUG_LOGS: CfnMailManagerIngressPointTrafficPolicyDebugLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::SES::MailManagerIngressPoint`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnMailManagerIngressPoint;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnMailManagerIngressPointApplicationLogs.
 */
export declare class CfnMailManagerIngressPointApplicationLogsOutputFormat {
}
export declare namespace CfnMailManagerIngressPointApplicationLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnMailManagerIngressPointApplicationLogsRecordFields {
    TIMESTAMP = "timestamp",
    INGRESS_POINT_ID = "ingress_point_id",
    INGRESS_POINT_TYPE = "ingress_point_type",
    SENDER_IP_ADDRESS = "sender_ip_address",
    SMTP_MAIL_FROM = "smtp_mail_from",
    SMTP_HELO = "smtp_helo",
    TLS_PROTOCOL = "tls_protocol",
    RECIPIENTS = "recipients",
    INGRESS_POINT_METADATA = "ingress_point_metadata",
    TLS_CIPHER_SUITE = "tls_cipher_suite",
    MESSAGE_SIZE_BYTES = "message_size_bytes",
    RULE_SET_ID = "rule_set_id",
    VPC_ENDPOINT_ID = "vpc_endpoint_id",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    MESSAGE_ID = "message_id"
}
export interface CfnMailManagerIngressPointApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnMailManagerIngressPointApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMailManagerIngressPointApplicationLogsRecordFields>;
}
export interface CfnMailManagerIngressPointApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnMailManagerIngressPointApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMailManagerIngressPointApplicationLogsRecordFields>;
}
export interface CfnMailManagerIngressPointApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnMailManagerIngressPointApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMailManagerIngressPointApplicationLogsRecordFields>;
}
export interface CfnMailManagerIngressPointApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMailManagerIngressPointApplicationLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnMailManagerIngressPointTrafficPolicyDebugLogs.
 */
export declare class CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat {
}
export declare namespace CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields {
    TIMESTAMP = "timestamp",
    INGRESS_POINT_ID = "ingress_point_id",
    INGRESS_POINT_TYPE = "ingress_point_type",
    INGRESS_POINT_SESSION_ID = "ingress_point_session_id",
    TRAFFIC_POLICY_ID = "traffic_policy_id",
    TRAFFIC_POLICY_EVALUATION = "traffic_policy_evaluation",
    TRAFFIC_POLICY_VERDICT = "traffic_policy_verdict",
    SENDER_IP_ADDRESS = "sender_ip_address",
    SMTP_MAIL_FROM = "smtp_mail_from",
    SMTP_HELO = "smtp_helo",
    TLS_PROTOCOL = "tls_protocol",
    RECIPIENT = "recipient",
    TLS_CIPHER_SUITE = "tls_cipher_suite",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields>;
}
export interface CfnMailManagerIngressPointTrafficPolicyDebugLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields>;
}
export interface CfnMailManagerIngressPointTrafficPolicyDebugLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields>;
}
export interface CfnMailManagerIngressPointTrafficPolicyDebugLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields>;
}
/**
 * Builder for CfnMailManagerRuleSetLogsMixin to generate APPLICATION_LOGS for CfnMailManagerRuleSet
 *
 * @cloudformationResource AWS::SES::MailManagerRuleSet
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnMailManagerRuleSetApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnMailManagerRuleSetApplicationLogsS3Props): CfnMailManagerRuleSetLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnMailManagerRuleSetApplicationLogsLogGroupProps): CfnMailManagerRuleSetLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnMailManagerRuleSetApplicationLogsFirehoseProps): CfnMailManagerRuleSetLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnMailManagerRuleSetApplicationLogsDestProps): CfnMailManagerRuleSetLogsMixin;
}
/**
 * Resource to create a rule set for a Mail Manager ingress endpoint which contains a list of rules that are evaluated sequentially for each email.
 *
 * @cloudformationResource AWS::SES::MailManagerRuleSet
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ses-mailmanagerruleset.html
 */
export declare class CfnMailManagerRuleSetLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnMailManagerRuleSetApplicationLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::SES::MailManagerRuleSet`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnMailManagerRuleSet;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnMailManagerRuleSetApplicationLogs.
 */
export declare class CfnMailManagerRuleSetApplicationLogsOutputFormat {
}
export declare namespace CfnMailManagerRuleSetApplicationLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnMailManagerRuleSetApplicationLogsRecordFields {
    TIMESTAMP = "timestamp",
    RULE_SET_ID = "rule_set_id",
    RULE_NAME = "rule_name",
    RULE_INDEX = "rule_index",
    RECIPIENTS_MATCHED = "recipients_matched",
    ACTION_METADATA = "action_metadata",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    MESSAGE_ID = "message_id",
    RULE_SET_NAME = "rule_set_name"
}
export interface CfnMailManagerRuleSetApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnMailManagerRuleSetApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMailManagerRuleSetApplicationLogsRecordFields>;
}
export interface CfnMailManagerRuleSetApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnMailManagerRuleSetApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMailManagerRuleSetApplicationLogsRecordFields>;
}
export interface CfnMailManagerRuleSetApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnMailManagerRuleSetApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMailManagerRuleSetApplicationLogsRecordFields>;
}
export interface CfnMailManagerRuleSetApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMailManagerRuleSetApplicationLogsRecordFields>;
}
