import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-ec2";
/**
 * Builder for CfnRouteServerPeerLogsMixin to generate EVENT_LOGS for CfnRouteServerPeer
 *
 * @cloudformationResource AWS::EC2::RouteServerPeer
 * @logType EVENT_LOGS
 * @stability external
 */
export declare class CfnRouteServerPeerEventLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnRouteServerPeerEventLogsS3Props): CfnRouteServerPeerLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnRouteServerPeerEventLogsLogGroupProps): CfnRouteServerPeerLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnRouteServerPeerEventLogsFirehoseProps): CfnRouteServerPeerLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnRouteServerPeerEventLogsDestProps): CfnRouteServerPeerLogsMixin;
}
/**
 * Specifies a BGP peer configuration for a route server endpoint.
 *
 * A route server peer is a session between a route server endpoint and the device deployed in AWS (such as a firewall appliance or other network security function running on an EC2 instance).
 *
 * @cloudformationResource AWS::EC2::RouteServerPeer
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-routeserverpeer.html
 */
export declare class CfnRouteServerPeerLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly EVENT_LOGS: CfnRouteServerPeerEventLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::EC2::RouteServerPeer`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnRouteServerPeer;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnRouteServerPeerEventLogs.
 */
export declare class CfnRouteServerPeerEventLogsOutputFormat {
}
export declare namespace CfnRouteServerPeerEventLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnRouteServerPeerEventLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ID = "resource_id",
    STATUS = "status",
    MESSAGE = "message",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    TYPE = "type"
}
export interface CfnRouteServerPeerEventLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnRouteServerPeerEventLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRouteServerPeerEventLogsRecordFields>;
}
export interface CfnRouteServerPeerEventLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnRouteServerPeerEventLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRouteServerPeerEventLogsRecordFields>;
}
export interface CfnRouteServerPeerEventLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnRouteServerPeerEventLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRouteServerPeerEventLogsRecordFields>;
}
export interface CfnRouteServerPeerEventLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRouteServerPeerEventLogsRecordFields>;
}
