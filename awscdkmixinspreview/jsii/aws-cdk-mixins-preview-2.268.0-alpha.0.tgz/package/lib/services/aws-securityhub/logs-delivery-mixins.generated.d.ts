import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-securityhub";
/**
 * Builder for CfnHubLogsMixin to generate SECURITY_FINDING_LOGS for CfnHub
 *
 * @cloudformationResource AWS::SecurityHub::Hub
 * @logType SECURITY_FINDING_LOGS
 * @stability external
 */
export declare class CfnHubSecurityFindingLogs {
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnHubSecurityFindingLogsLogGroupProps): CfnHubLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are CWL
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnHubSecurityFindingLogsDestProps): CfnHubLogsMixin;
}
/**
 * The `AWS::SecurityHub::Hub` resource specifies the enablement of the AWS Security Hub CSPM service in your AWS account .
 *
 * The service is enabled in the current AWS Region or the specified Region. You create a separate `Hub` resource in each Region in which you want to enable Security Hub CSPM .
 *
 * When you use this resource to enable Security Hub CSPM , default security standards are enabled. To disable default standards, set the `EnableDefaultStandards` property to `false` . You can use the [`AWS::SecurityHub::Standard`](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityhub-standard.html) resource to enable additional standards.
 *
 * When you use this resource to enable Security Hub CSPM , new controls are automatically enabled for your enabled standards. To disable automatic enablement of new controls, set the `AutoEnableControls` property to `false` .
 *
 * You must create an `AWS::SecurityHub::Hub` resource for an account before you can create other types of Security Hub CSPM resources for the account through CloudFormation . Use a [DependsOn attribute](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-attribute-dependson.html) , such as `"DependsOn": "Hub"` , to ensure that you've created an `AWS::SecurityHub::Hub` resource before creating other Security Hub CSPM resources for an account.
 *
 * @cloudformationResource AWS::SecurityHub::Hub
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityhub-hub.html
 */
export declare class CfnHubLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly SECURITY_FINDING_LOGS: CfnHubSecurityFindingLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::SecurityHub::Hub`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnHub;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnHubSecurityFindingLogs.
 */
export declare class CfnHubSecurityFindingLogsOutputFormat {
}
export declare namespace CfnHubSecurityFindingLogsOutputFormat {
    enum LogGroup {
        PLAIN = "plain"
    }
}
export declare enum CfnHubSecurityFindingLogsRecordFields {
    EVENT = "event"
}
export interface CfnHubSecurityFindingLogsLogGroupProps {
    /**
     * Format for log output, options are plain
     */
    readonly outputFormat?: CfnHubSecurityFindingLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnHubSecurityFindingLogsRecordFields>;
}
export interface CfnHubSecurityFindingLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnHubSecurityFindingLogsRecordFields>;
}
/**
 * Builder for CfnHubV2LogsMixin to generate SECURITY_FINDING_LOGS for CfnHubV2
 *
 * @cloudformationResource AWS::SecurityHub::HubV2
 * @logType SECURITY_FINDING_LOGS
 * @stability external
 */
export declare class CfnHubV2SecurityFindingLogs {
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnHubV2SecurityFindingLogsLogGroupProps): CfnHubV2LogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are CWL
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnHubV2SecurityFindingLogsDestProps): CfnHubV2LogsMixin;
}
/**
 * Returns details about the service resource in your account.
 *
 * @cloudformationResource AWS::SecurityHub::HubV2
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityhub-hubv2.html
 */
export declare class CfnHubV2LogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly SECURITY_FINDING_LOGS: CfnHubV2SecurityFindingLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::SecurityHub::HubV2`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnHubV2;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnHubV2SecurityFindingLogs.
 */
export declare class CfnHubV2SecurityFindingLogsOutputFormat {
}
export declare namespace CfnHubV2SecurityFindingLogsOutputFormat {
    enum LogGroup {
        PLAIN = "plain"
    }
}
export declare enum CfnHubV2SecurityFindingLogsRecordFields {
    EVENT = "event"
}
export interface CfnHubV2SecurityFindingLogsLogGroupProps {
    /**
     * Format for log output, options are plain
     */
    readonly outputFormat?: CfnHubV2SecurityFindingLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnHubV2SecurityFindingLogsRecordFields>;
}
export interface CfnHubV2SecurityFindingLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnHubV2SecurityFindingLogsRecordFields>;
}
