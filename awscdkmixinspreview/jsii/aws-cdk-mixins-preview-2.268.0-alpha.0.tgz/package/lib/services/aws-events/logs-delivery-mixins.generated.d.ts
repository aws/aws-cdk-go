import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-events";
/**
 * Builder for CfnEventBusLogsMixin to generate ERROR_LOGS for CfnEventBus
 *
 * @cloudformationResource AWS::Events::EventBus
 * @logType ERROR_LOGS
 * @stability external
 */
export declare class CfnEventBusErrorLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnEventBusErrorLogsS3Props): CfnEventBusLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnEventBusErrorLogsLogGroupProps): CfnEventBusLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnEventBusErrorLogsFirehoseProps): CfnEventBusLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnEventBusErrorLogsDestProps): CfnEventBusLogsMixin;
}
/**
 * Builder for CfnEventBusLogsMixin to generate INFO_LOGS for CfnEventBus
 *
 * @cloudformationResource AWS::Events::EventBus
 * @logType INFO_LOGS
 * @stability external
 */
export declare class CfnEventBusInfoLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnEventBusInfoLogsS3Props): CfnEventBusLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnEventBusInfoLogsLogGroupProps): CfnEventBusLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnEventBusInfoLogsFirehoseProps): CfnEventBusLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnEventBusInfoLogsDestProps): CfnEventBusLogsMixin;
}
/**
 * Builder for CfnEventBusLogsMixin to generate TRACE_LOGS for CfnEventBus
 *
 * @cloudformationResource AWS::Events::EventBus
 * @logType TRACE_LOGS
 * @stability external
 */
export declare class CfnEventBusTraceLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnEventBusTraceLogsS3Props): CfnEventBusLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnEventBusTraceLogsLogGroupProps): CfnEventBusLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnEventBusTraceLogsFirehoseProps): CfnEventBusLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnEventBusTraceLogsDestProps): CfnEventBusLogsMixin;
}
/**
 * Specifies an event bus within your account.
 *
 * This can be a custom event bus which you can use to receive events from your custom applications and services, or it can be a partner event bus which can be matched to a partner event source.
 *
 * > As an aid to help you jumpstart developing CloudFormation templates, the EventBridge console enables you to create templates from the existing event buses in your account. For more information, see [Generating CloudFormation templates from an EventBridge event bus](https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-generate-event-bus-template.html) in the *Amazon EventBridge User Guide* .
 *
 * @cloudformationResource AWS::Events::EventBus
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-events-eventbus.html
 */
export declare class CfnEventBusLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly ERROR_LOGS: CfnEventBusErrorLogs;
    static readonly INFO_LOGS: CfnEventBusInfoLogs;
    static readonly TRACE_LOGS: CfnEventBusTraceLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::Events::EventBus`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnEventBus;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnEventBusErrorLogs.
 */
export declare class CfnEventBusErrorLogsOutputFormat {
}
export declare namespace CfnEventBusErrorLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnEventBusErrorLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ARN = "resource_arn",
    MESSAGE_TIMESTAMP_MS = "message_timestamp_ms",
    EVENT_BUS_NAME = "event_bus_name",
    REQUEST_ID = "request_id",
    EVENT_ID = "event_id",
    INVOCATION_ID = "invocation_id",
    MESSAGE_TYPE = "message_type",
    LOG_LEVEL = "log_level",
    DETAILS = "details",
    ERROR = "error"
}
export interface CfnEventBusErrorLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnEventBusErrorLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnEventBusErrorLogsRecordFields>;
}
export interface CfnEventBusErrorLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnEventBusErrorLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnEventBusErrorLogsRecordFields>;
}
export interface CfnEventBusErrorLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnEventBusErrorLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnEventBusErrorLogsRecordFields>;
}
export interface CfnEventBusErrorLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnEventBusErrorLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnEventBusInfoLogs.
 */
export declare class CfnEventBusInfoLogsOutputFormat {
}
export declare namespace CfnEventBusInfoLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnEventBusInfoLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ARN = "resource_arn",
    MESSAGE_TIMESTAMP_MS = "message_timestamp_ms",
    EVENT_BUS_NAME = "event_bus_name",
    REQUEST_ID = "request_id",
    EVENT_ID = "event_id",
    INVOCATION_ID = "invocation_id",
    MESSAGE_TYPE = "message_type",
    LOG_LEVEL = "log_level",
    DETAILS = "details",
    ERROR = "error"
}
export interface CfnEventBusInfoLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnEventBusInfoLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnEventBusInfoLogsRecordFields>;
}
export interface CfnEventBusInfoLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnEventBusInfoLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnEventBusInfoLogsRecordFields>;
}
export interface CfnEventBusInfoLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnEventBusInfoLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnEventBusInfoLogsRecordFields>;
}
export interface CfnEventBusInfoLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnEventBusInfoLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnEventBusTraceLogs.
 */
export declare class CfnEventBusTraceLogsOutputFormat {
}
export declare namespace CfnEventBusTraceLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnEventBusTraceLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ARN = "resource_arn",
    MESSAGE_TIMESTAMP_MS = "message_timestamp_ms",
    EVENT_BUS_NAME = "event_bus_name",
    REQUEST_ID = "request_id",
    EVENT_ID = "event_id",
    INVOCATION_ID = "invocation_id",
    MESSAGE_TYPE = "message_type",
    LOG_LEVEL = "log_level",
    DETAILS = "details",
    ERROR = "error"
}
export interface CfnEventBusTraceLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnEventBusTraceLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnEventBusTraceLogsRecordFields>;
}
export interface CfnEventBusTraceLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnEventBusTraceLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnEventBusTraceLogsRecordFields>;
}
export interface CfnEventBusTraceLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnEventBusTraceLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnEventBusTraceLogsRecordFields>;
}
export interface CfnEventBusTraceLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnEventBusTraceLogsRecordFields>;
}
