import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-eks";
/**
 * Builder for CfnClusterLogsMixin to generate AUTO_MODE_LOAD_BALANCING_LOGS for CfnCluster
 *
 * @cloudformationResource AWS::EKS::Cluster
 * @logType AUTO_MODE_LOAD_BALANCING_LOGS
 * @stability external
 */
export declare class CfnClusterAutoModeLoadBalancingLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnClusterAutoModeLoadBalancingLogsS3Props): CfnClusterLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnClusterAutoModeLoadBalancingLogsLogGroupProps): CfnClusterLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnClusterAutoModeLoadBalancingLogsFirehoseProps): CfnClusterLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnClusterAutoModeLoadBalancingLogsDestProps): CfnClusterLogsMixin;
}
/**
 * Builder for CfnClusterLogsMixin to generate AUTO_MODE_COMPUTE_LOGS for CfnCluster
 *
 * @cloudformationResource AWS::EKS::Cluster
 * @logType AUTO_MODE_COMPUTE_LOGS
 * @stability external
 */
export declare class CfnClusterAutoModeComputeLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnClusterAutoModeComputeLogsS3Props): CfnClusterLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnClusterAutoModeComputeLogsLogGroupProps): CfnClusterLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnClusterAutoModeComputeLogsFirehoseProps): CfnClusterLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnClusterAutoModeComputeLogsDestProps): CfnClusterLogsMixin;
}
/**
 * Builder for CfnClusterLogsMixin to generate AUTO_MODE_IPAM_LOGS for CfnCluster
 *
 * @cloudformationResource AWS::EKS::Cluster
 * @logType AUTO_MODE_IPAM_LOGS
 * @stability external
 */
export declare class CfnClusterAutoModeIpamLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnClusterAutoModeIpamLogsS3Props): CfnClusterLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnClusterAutoModeIpamLogsLogGroupProps): CfnClusterLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnClusterAutoModeIpamLogsFirehoseProps): CfnClusterLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnClusterAutoModeIpamLogsDestProps): CfnClusterLogsMixin;
}
/**
 * Builder for CfnClusterLogsMixin to generate AUTO_MODE_BLOCK_STORAGE_LOGS for CfnCluster
 *
 * @cloudformationResource AWS::EKS::Cluster
 * @logType AUTO_MODE_BLOCK_STORAGE_LOGS
 * @stability external
 */
export declare class CfnClusterAutoModeBlockStorageLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnClusterAutoModeBlockStorageLogsS3Props): CfnClusterLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnClusterAutoModeBlockStorageLogsLogGroupProps): CfnClusterLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnClusterAutoModeBlockStorageLogsFirehoseProps): CfnClusterLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnClusterAutoModeBlockStorageLogsDestProps): CfnClusterLogsMixin;
}
/**
 * Creates an Amazon EKS control plane.
 *
 * The Amazon EKS control plane consists of control plane instances that run the Kubernetes software, such as `etcd` and the API server. The control plane runs in an account managed by AWS , and the Kubernetes API is exposed by the Amazon EKS API server endpoint. Each Amazon EKS cluster control plane is single tenant and unique. It runs on its own set of Amazon EC2 instances.
 *
 * The cluster control plane is provisioned across multiple Availability Zones and fronted by an ELB Network Load Balancer. Amazon EKS also provisions elastic network interfaces in your VPC subnets to provide connectivity from the control plane instances to the nodes (for example, to support `kubectl exec` , `logs` , and `proxy` data flows).
 *
 * Amazon EKS nodes run in your AWS account and connect to your cluster's control plane over the Kubernetes API server endpoint and a certificate file that is created for your cluster.
 *
 * You can use the `endpointPublicAccess` and `endpointPrivateAccess` parameters to enable or disable public and private access to your cluster's Kubernetes API server endpoint. By default, public access is enabled, and private access is disabled. The endpoint domain name and IP address family depends on the value of the `ipFamily` for the cluster. For more information, see [Amazon EKS Cluster Endpoint Access Control](https://docs.aws.amazon.com/eks/latest/userguide/cluster-endpoint.html) in the **Amazon EKS User Guide** .
 *
 * You can use the `logging` parameter to enable or disable exporting the Kubernetes control plane logs for your cluster to CloudWatch Logs. By default, cluster control plane logs aren't exported to CloudWatch Logs. For more information, see [Amazon EKS Cluster Control Plane Logs](https://docs.aws.amazon.com/eks/latest/userguide/control-plane-logs.html) in the **Amazon EKS User Guide** .
 *
 * > CloudWatch Logs ingestion, archive storage, and data scanning rates apply to exported control plane logs. For more information, see [CloudWatch Pricing](https://docs.aws.amazon.com/cloudwatch/pricing/) .
 *
 * In most cases, it takes several minutes to create a cluster. After you create an Amazon EKS cluster, you must configure your Kubernetes tooling to communicate with the API server and launch nodes into your cluster. For more information, see [Allowing users to access your cluster](https://docs.aws.amazon.com/eks/latest/userguide/cluster-auth.html) and [Launching Amazon EKS nodes](https://docs.aws.amazon.com/eks/latest/userguide/launch-workers.html) in the *Amazon EKS User Guide* .
 *
 * @cloudformationResource AWS::EKS::Cluster
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eks-cluster.html
 */
export declare class CfnClusterLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly AUTO_MODE_LOAD_BALANCING_LOGS: CfnClusterAutoModeLoadBalancingLogs;
    static readonly AUTO_MODE_COMPUTE_LOGS: CfnClusterAutoModeComputeLogs;
    static readonly AUTO_MODE_IPAM_LOGS: CfnClusterAutoModeIpamLogs;
    static readonly AUTO_MODE_BLOCK_STORAGE_LOGS: CfnClusterAutoModeBlockStorageLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::EKS::Cluster`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCluster;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnClusterAutoModeLoadBalancingLogs.
 */
export declare class CfnClusterAutoModeLoadBalancingLogsOutputFormat {
}
export declare namespace CfnClusterAutoModeLoadBalancingLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnClusterAutoModeLoadBalancingLogsRecordFields {
    LEVEL = "level",
    STREAM = "stream",
    MESSAGE = "message",
    ERR = "err",
    ERROR = "error",
    CONTROLLER = "controller",
    CONTROLLERGROUP = "controllerGroup",
    CONTROLLERKIND = "controllerKind",
    RECONCILEID = "reconcileID",
    WORKER_COUNT = "worker-count",
    ATTEMPT = "attempt",
    DELAY = "delay",
    TOTALITEMS = "totalItems",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnClusterAutoModeLoadBalancingLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnClusterAutoModeLoadBalancingLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeLoadBalancingLogsRecordFields>;
}
export interface CfnClusterAutoModeLoadBalancingLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnClusterAutoModeLoadBalancingLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeLoadBalancingLogsRecordFields>;
}
export interface CfnClusterAutoModeLoadBalancingLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnClusterAutoModeLoadBalancingLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeLoadBalancingLogsRecordFields>;
}
export interface CfnClusterAutoModeLoadBalancingLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeLoadBalancingLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnClusterAutoModeComputeLogs.
 */
export declare class CfnClusterAutoModeComputeLogsOutputFormat {
}
export declare namespace CfnClusterAutoModeComputeLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnClusterAutoModeComputeLogsRecordFields {
    LEVEL = "level",
    STREAM = "stream",
    MESSAGE = "message",
    ERR = "err",
    ERROR = "error",
    CONTROLLER = "controller",
    CONTROLLERGROUP = "controllerGroup",
    CONTROLLERKIND = "controllerKind",
    RECONCILEID = "reconcileID",
    WORKER_COUNT = "worker-count",
    COUNT = "count",
    INSTANCE_TYPE_COUNT = "instance-type-count",
    MODE = "mode",
    OFFERING_COUNT = "offering-count",
    NODEPOOL = "NodePool",
    NODECLAIM = "NodeClaim",
    NODE = "Node",
    ZONES = "zones",
    SUBNETS = "subnets",
    ALLOCATABLE = "allocatable",
    COMMAND = "command",
    COMMAND_ID = "command-id",
    DECISION = "decision",
    DELETING_PODS = "deleting-pods",
    DISRUPTED_NODE_COUNT = "disrupted-node-count",
    DISRUPTED_NODES = "disrupted-nodes",
    DISRUPTION_COST = "disruption-cost",
    MESSAGEKIND = "messageKind",
    PENDING_PODS = "pending-pods",
    POD_COUNT = "pod-count",
    REPLACEMENT_NODE_COUNT = "replacement-node-count",
    REPLACEMENT_NODES = "replacement-nodes",
    RESOURCECLAIM = "ResourceClaim",
    SAVINGS = "savings",
    TOTAL = "total",
    ACTION = "action",
    REASON = "reason",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnClusterAutoModeComputeLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnClusterAutoModeComputeLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeComputeLogsRecordFields>;
}
export interface CfnClusterAutoModeComputeLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnClusterAutoModeComputeLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeComputeLogsRecordFields>;
}
export interface CfnClusterAutoModeComputeLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnClusterAutoModeComputeLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeComputeLogsRecordFields>;
}
export interface CfnClusterAutoModeComputeLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeComputeLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnClusterAutoModeIpamLogs.
 */
export declare class CfnClusterAutoModeIpamLogsOutputFormat {
}
export declare namespace CfnClusterAutoModeIpamLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnClusterAutoModeIpamLogsRecordFields {
    LEVEL = "level",
    STREAM = "stream",
    MESSAGE = "message",
    ERR = "err",
    ERROR = "error",
    CONTROLLER = "controller",
    CONTROLLERGROUP = "controllerGroup",
    CONTROLLERKIND = "controllerKind",
    RECONCILEID = "reconcileID",
    WORKER_COUNT = "worker-count",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnClusterAutoModeIpamLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnClusterAutoModeIpamLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeIpamLogsRecordFields>;
}
export interface CfnClusterAutoModeIpamLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnClusterAutoModeIpamLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeIpamLogsRecordFields>;
}
export interface CfnClusterAutoModeIpamLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnClusterAutoModeIpamLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeIpamLogsRecordFields>;
}
export interface CfnClusterAutoModeIpamLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeIpamLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnClusterAutoModeBlockStorageLogs.
 */
export declare class CfnClusterAutoModeBlockStorageLogsOutputFormat {
}
export declare namespace CfnClusterAutoModeBlockStorageLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnClusterAutoModeBlockStorageLogsRecordFields {
    LEVEL = "level",
    STREAM = "stream",
    MESSAGE = "message",
    ERR = "err",
    ERROR = "error",
    ENABLED = "enabled",
    FEATURE = "feature",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnClusterAutoModeBlockStorageLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnClusterAutoModeBlockStorageLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeBlockStorageLogsRecordFields>;
}
export interface CfnClusterAutoModeBlockStorageLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnClusterAutoModeBlockStorageLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeBlockStorageLogsRecordFields>;
}
export interface CfnClusterAutoModeBlockStorageLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnClusterAutoModeBlockStorageLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeBlockStorageLogsRecordFields>;
}
export interface CfnClusterAutoModeBlockStorageLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterAutoModeBlockStorageLogsRecordFields>;
}
/**
 * Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_ARGOCD_COMMITSERVER_LOGS for CfnCapability
 *
 * @cloudformationResource AWS::EKS::Capability
 * @logType EKS_CAPABILITY_ARGOCD_COMMITSERVER_LOGS
 * @stability external
 */
export declare class CfnCapabilityEksCapabilityArgocdCommitserverLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnCapabilityEksCapabilityArgocdCommitserverLogsS3Props): CfnCapabilityLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnCapabilityEksCapabilityArgocdCommitserverLogsLogGroupProps): CfnCapabilityLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnCapabilityEksCapabilityArgocdCommitserverLogsFirehoseProps): CfnCapabilityLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnCapabilityEksCapabilityArgocdCommitserverLogsDestProps): CfnCapabilityLogsMixin;
}
/**
 * Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_ACK_LOGS for CfnCapability
 *
 * @cloudformationResource AWS::EKS::Capability
 * @logType EKS_CAPABILITY_ACK_LOGS
 * @stability external
 */
export declare class CfnCapabilityEksCapabilityAckLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnCapabilityEksCapabilityAckLogsS3Props): CfnCapabilityLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnCapabilityEksCapabilityAckLogsLogGroupProps): CfnCapabilityLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnCapabilityEksCapabilityAckLogsFirehoseProps): CfnCapabilityLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnCapabilityEksCapabilityAckLogsDestProps): CfnCapabilityLogsMixin;
}
/**
 * Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_ARGOCD_SERVER_LOGS for CfnCapability
 *
 * @cloudformationResource AWS::EKS::Capability
 * @logType EKS_CAPABILITY_ARGOCD_SERVER_LOGS
 * @stability external
 */
export declare class CfnCapabilityEksCapabilityArgocdServerLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnCapabilityEksCapabilityArgocdServerLogsS3Props): CfnCapabilityLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnCapabilityEksCapabilityArgocdServerLogsLogGroupProps): CfnCapabilityLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnCapabilityEksCapabilityArgocdServerLogsFirehoseProps): CfnCapabilityLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnCapabilityEksCapabilityArgocdServerLogsDestProps): CfnCapabilityLogsMixin;
}
/**
 * Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_ARGOCD_APPLICATION_LOGS for CfnCapability
 *
 * @cloudformationResource AWS::EKS::Capability
 * @logType EKS_CAPABILITY_ARGOCD_APPLICATION_LOGS
 * @stability external
 */
export declare class CfnCapabilityEksCapabilityArgocdApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props): CfnCapabilityLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnCapabilityEksCapabilityArgocdApplicationLogsLogGroupProps): CfnCapabilityLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnCapabilityEksCapabilityArgocdApplicationLogsFirehoseProps): CfnCapabilityLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnCapabilityEksCapabilityArgocdApplicationLogsDestProps): CfnCapabilityLogsMixin;
}
/**
 * Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_ARGOCD_APPLICATIONSET_LOGS for CfnCapability
 *
 * @cloudformationResource AWS::EKS::Capability
 * @logType EKS_CAPABILITY_ARGOCD_APPLICATIONSET_LOGS
 * @stability external
 */
export declare class CfnCapabilityEksCapabilityArgocdApplicationsetLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnCapabilityEksCapabilityArgocdApplicationsetLogsS3Props): CfnCapabilityLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnCapabilityEksCapabilityArgocdApplicationsetLogsLogGroupProps): CfnCapabilityLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnCapabilityEksCapabilityArgocdApplicationsetLogsFirehoseProps): CfnCapabilityLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnCapabilityEksCapabilityArgocdApplicationsetLogsDestProps): CfnCapabilityLogsMixin;
}
/**
 * Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_ARGOCD_REPOSERVER_LOGS for CfnCapability
 *
 * @cloudformationResource AWS::EKS::Capability
 * @logType EKS_CAPABILITY_ARGOCD_REPOSERVER_LOGS
 * @stability external
 */
export declare class CfnCapabilityEksCapabilityArgocdReposerverLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnCapabilityEksCapabilityArgocdReposerverLogsS3Props): CfnCapabilityLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnCapabilityEksCapabilityArgocdReposerverLogsLogGroupProps): CfnCapabilityLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnCapabilityEksCapabilityArgocdReposerverLogsFirehoseProps): CfnCapabilityLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnCapabilityEksCapabilityArgocdReposerverLogsDestProps): CfnCapabilityLogsMixin;
}
/**
 * Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_KRO_LOGS for CfnCapability
 *
 * @cloudformationResource AWS::EKS::Capability
 * @logType EKS_CAPABILITY_KRO_LOGS
 * @stability external
 */
export declare class CfnCapabilityEksCapabilityKroLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnCapabilityEksCapabilityKroLogsS3Props): CfnCapabilityLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnCapabilityEksCapabilityKroLogsLogGroupProps): CfnCapabilityLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnCapabilityEksCapabilityKroLogsFirehoseProps): CfnCapabilityLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnCapabilityEksCapabilityKroLogsDestProps): CfnCapabilityLogsMixin;
}
/**
 * An object representing a managed capability in an Amazon EKS cluster.
 *
 * This includes all configuration, status, and health information for the capability.
 *
 * @cloudformationResource AWS::EKS::Capability
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eks-capability.html
 */
export declare class CfnCapabilityLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly EKS_CAPABILITY_ARGOCD_COMMITSERVER_LOGS: CfnCapabilityEksCapabilityArgocdCommitserverLogs;
    static readonly EKS_CAPABILITY_ACK_LOGS: CfnCapabilityEksCapabilityAckLogs;
    static readonly EKS_CAPABILITY_ARGOCD_SERVER_LOGS: CfnCapabilityEksCapabilityArgocdServerLogs;
    static readonly EKS_CAPABILITY_ARGOCD_APPLICATION_LOGS: CfnCapabilityEksCapabilityArgocdApplicationLogs;
    static readonly EKS_CAPABILITY_ARGOCD_APPLICATIONSET_LOGS: CfnCapabilityEksCapabilityArgocdApplicationsetLogs;
    static readonly EKS_CAPABILITY_ARGOCD_REPOSERVER_LOGS: CfnCapabilityEksCapabilityArgocdReposerverLogs;
    static readonly EKS_CAPABILITY_KRO_LOGS: CfnCapabilityEksCapabilityKroLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::EKS::Capability`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCapability;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnCapabilityEksCapabilityArgocdCommitserverLogs.
 */
export declare class CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat {
}
export declare namespace CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ID = "resource_id",
    STREAM = "stream",
    LEVEL = "level",
    MESSAGE = "message",
    ERROR = "error",
    VERSION = "version",
    COMPONENT = "component",
    DURATION = "duration",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnCapabilityEksCapabilityArgocdCommitserverLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdCommitserverLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdCommitserverLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdCommitserverLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnCapabilityEksCapabilityAckLogs.
 */
export declare class CfnCapabilityEksCapabilityAckLogsOutputFormat {
}
export declare namespace CfnCapabilityEksCapabilityAckLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnCapabilityEksCapabilityAckLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ID = "resource_id",
    STREAM = "stream",
    LEVEL = "level",
    MESSAGE = "message",
    ERR = "err",
    ERROR = "error",
    CONTROLLER = "controller",
    CONTROLLERGROUP = "controllerGroup",
    CONTROLLERKIND = "controllerKind",
    RECONCILEID = "reconcileID",
    WORKER_COUNT = "worker-count",
    KIND = "kind",
    NAME = "name",
    NAMESPACE = "namespace",
    AWS_SERVICE = "aws.service",
    VERSION = "version",
    TYPE = "type",
    GENERATION = "generation",
    IS_ADOPTED = "is_adopted",
    IAM_ROLE_SELECTOR = "iam_role_selector",
    ROLE = "role",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnCapabilityEksCapabilityAckLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityAckLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityAckLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityAckLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityAckLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityAckLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityAckLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityAckLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityAckLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityAckLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityAckLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnCapabilityEksCapabilityArgocdServerLogs.
 */
export declare class CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat {
}
export declare namespace CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnCapabilityEksCapabilityArgocdServerLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ID = "resource_id",
    STREAM = "stream",
    LEVEL = "level",
    MESSAGE = "message",
    ERROR = "error",
    NAME = "name",
    NAMESPACE = "namespace",
    REASON = "reason",
    APPLICATION = "application",
    USER = "user",
    GRPC_CODE = "grpc.code",
    GRPC_METHOD = "grpc.method",
    GRPC_SERVICE = "grpc.service",
    GRPC_TIME_MS = "grpc.time_ms",
    GRPC_METHOD_TYPE = "grpc.method_type",
    GRPC_ERROR = "grpc.error",
    TYPE = "type",
    DURATION = "duration",
    DEST_NAMESPACE = "dest-namespace",
    DEST_SERVER = "dest-server",
    PROJECT = "project",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnCapabilityEksCapabilityArgocdServerLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdServerLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdServerLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdServerLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdServerLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdServerLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdServerLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdServerLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnCapabilityEksCapabilityArgocdApplicationLogs.
 */
export declare class CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat {
}
export declare namespace CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ID = "resource_id",
    STREAM = "stream",
    LEVEL = "level",
    MESSAGE = "message",
    ERROR = "error",
    APPLICATION = "application",
    APP_NAMESPACE = "app-namespace",
    PROJECT = "project",
    DEST_SERVER = "dest-server",
    DEST_NAMESPACE = "dest-namespace",
    DEST_NAME = "dest-name",
    COMPARISON_LEVEL = "comparison-level",
    TIME_MS = "time_ms",
    PATCH_MS = "patch_ms",
    SETOP_MS = "setop_ms",
    COMPARE_APP_STATE_MS = "compare_app_state_ms",
    REFRESH_APP_CONDITIONS_MS = "refresh_app_conditions_ms",
    PROCESS_REFRESH_APP_CONDITIONS_ERRORS_MS = "process_refresh_app_conditions_errors_ms",
    COMPARISON_WITH_NOTHING_MS = "comparison_with_nothing_ms",
    NAME = "name",
    NAMESPACE = "namespace",
    APP_STATUS_UPDATE_MS = "app_status_update_ms",
    AUTO_SYNC_MS = "auto_sync_ms",
    DIFF_MS = "diff_ms",
    GIT_MS = "git_ms",
    HEALTH_MS = "health_ms",
    LIVE_MS = "live_ms",
    MANIFESTS_MS = "manifests_ms",
    REPO_MS = "repo_ms",
    SYNC_MS = "sync_ms",
    CLUSTER = "cluster",
    SYNCID = "syncId",
    DURATION = "duration",
    EVENTTYPE = "eventType",
    KIND = "kind",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnCapabilityEksCapabilityArgocdApplicationsetLogs.
 */
export declare class CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat {
}
export declare namespace CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ID = "resource_id",
    STREAM = "stream",
    LEVEL = "level",
    MESSAGE = "message",
    ERROR = "error",
    CONTROLLER = "controller",
    CONTROLLERGROUP = "controllerGroup",
    CONTROLLERKIND = "controllerKind",
    RECONCILEID = "reconcileID",
    WORKER_COUNT = "worker-count",
    NAME = "name",
    NAMESPACE = "namespace",
    APPLICATION = "application",
    APP_NAMESPACE = "app-namespace",
    PROJECT = "project",
    APPLICATIONSET = "applicationset",
    ACTION = "action",
    COUNT = "count",
    REQUEUEAFTER = "requeueAfter",
    TYPE = "type",
    VERSION = "version",
    ERR = "err",
    REPOURL = "repoURL",
    REVISION = "revision",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnCapabilityEksCapabilityArgocdApplicationsetLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdApplicationsetLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdApplicationsetLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdApplicationsetLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnCapabilityEksCapabilityArgocdReposerverLogs.
 */
export declare class CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat {
}
export declare namespace CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ID = "resource_id",
    STREAM = "stream",
    LEVEL = "level",
    MESSAGE = "message",
    ERROR = "error",
    GRPC_CODE = "grpc.code",
    GRPC_METHOD = "grpc.method",
    GRPC_SERVICE = "grpc.service",
    GRPC_TIME_MS = "grpc.time_ms",
    GRPC_METHOD_TYPE = "grpc.method_type",
    GRPC_COMPONENT = "grpc.component",
    GRPC_ERROR = "grpc.error",
    VERSION = "version",
    COMPONENT = "component",
    DURATION = "duration",
    EXECID = "execID",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnCapabilityEksCapabilityArgocdReposerverLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdReposerverLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdReposerverLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityArgocdReposerverLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnCapabilityEksCapabilityKroLogs.
 */
export declare class CfnCapabilityEksCapabilityKroLogsOutputFormat {
}
export declare namespace CfnCapabilityEksCapabilityKroLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnCapabilityEksCapabilityKroLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ID = "resource_id",
    STREAM = "stream",
    LEVEL = "level",
    MESSAGE = "message",
    ERR = "err",
    ERROR = "error",
    CONTROLLER = "controller",
    CONTROLLERGROUP = "controllerGroup",
    CONTROLLERKIND = "controllerKind",
    RECONCILEID = "reconcileID",
    WORKER_COUNT = "worker-count",
    GVR = "gvr",
    CRD = "crd",
    NAME = "name",
    NAMESPACE = "namespace",
    TYPE = "type",
    BREAKINGCHANGES = "breakingChanges",
    SUMMARY = "summary",
    EXISTINGRGDID = "existingRGDID",
    NEWRGDID = "newRGDID",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnCapabilityEksCapabilityKroLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityKroLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityKroLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityKroLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityKroLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityKroLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityKroLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnCapabilityEksCapabilityKroLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityKroLogsRecordFields>;
}
export interface CfnCapabilityEksCapabilityKroLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCapabilityEksCapabilityKroLogsRecordFields>;
}
