import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.translate@TranslateParallelDataStateChange
 */
export declare class TranslateParallelDataStateChange {
    /**
     * EventBridge event pattern for Translate TextTranslationJob State Change
     */
    static eventPattern(options?: TranslateParallelDataStateChange.TranslateParallelDataStateChangeProps): events.EventPattern;
}
export declare namespace TranslateParallelDataStateChange {
    /**
     * Props type for aws.translate@TranslateParallelDataStateChange event
     */
    interface TranslateParallelDataStateChangeProps {
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * jobStatus property
         *
         * Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobStatus?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.translate@TranslateTextTranslationJobStateChange
 */
export declare class TranslateTextTranslationJobStateChange {
    /**
     * EventBridge event pattern for Translate Parallel Data State Change
     */
    static eventPattern(options?: TranslateTextTranslationJobStateChange.TranslateTextTranslationJobStateChangeProps): events.EventPattern;
}
export declare namespace TranslateTextTranslationJobStateChange {
    /**
     * Props type for aws.translate@TranslateTextTranslationJobStateChange event
     */
    interface TranslateTextTranslationJobStateChangeProps {
        /**
         * latestUpdateAttemptAt property
         *
         * Specify an array of string values to match this event if the actual value of latestUpdateAttemptAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly latestUpdateAttemptAt?: Array<string>;
        /**
         * latestUpdateAttemptStatus property
         *
         * Specify an array of string values to match this event if the actual value of latestUpdateAttemptStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly latestUpdateAttemptStatus?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * operation property
         *
         * Specify an array of string values to match this event if the actual value of operation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly operation?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
