import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-pcs";
/**
 * Builder for CfnClusterLogsMixin to generate PCS_SCHEDULER_AUDIT_LOGS for CfnCluster
 *
 * @cloudformationResource AWS::PCS::Cluster
 * @logType PCS_SCHEDULER_AUDIT_LOGS
 * @stability external
 */
export declare class CfnClusterPcsSchedulerAuditLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnClusterPcsSchedulerAuditLogsS3Props): CfnClusterLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnClusterPcsSchedulerAuditLogsLogGroupProps): CfnClusterLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnClusterPcsSchedulerAuditLogsFirehoseProps): CfnClusterLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnClusterPcsSchedulerAuditLogsDestProps): CfnClusterLogsMixin;
}
/**
 * Builder for CfnClusterLogsMixin to generate PCS_JOBCOMP_LOGS for CfnCluster
 *
 * @cloudformationResource AWS::PCS::Cluster
 * @logType PCS_JOBCOMP_LOGS
 * @stability external
 */
export declare class CfnClusterPcsJobcompLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnClusterPcsJobcompLogsS3Props): CfnClusterLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnClusterPcsJobcompLogsLogGroupProps): CfnClusterLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnClusterPcsJobcompLogsFirehoseProps): CfnClusterLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnClusterPcsJobcompLogsDestProps): CfnClusterLogsMixin;
}
/**
 * Builder for CfnClusterLogsMixin to generate PCS_SCHEDULER_LOGS for CfnCluster
 *
 * @cloudformationResource AWS::PCS::Cluster
 * @logType PCS_SCHEDULER_LOGS
 * @stability external
 */
export declare class CfnClusterPcsSchedulerLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnClusterPcsSchedulerLogsS3Props): CfnClusterLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnClusterPcsSchedulerLogsLogGroupProps): CfnClusterLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnClusterPcsSchedulerLogsFirehoseProps): CfnClusterLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnClusterPcsSchedulerLogsDestProps): CfnClusterLogsMixin;
}
/**
 * Creates an AWS PCS cluster resource.
 *
 * For more information, see [Creating a cluster in Parallel Computing Service](https://docs.aws.amazon.com/pcs/latest/userguide/working-with_clusters_create.html) in the *AWS PCS User Guide* .
 *
 * @cloudformationResource AWS::PCS::Cluster
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-cluster.html
 */
export declare class CfnClusterLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly PCS_SCHEDULER_AUDIT_LOGS: CfnClusterPcsSchedulerAuditLogs;
    static readonly PCS_JOBCOMP_LOGS: CfnClusterPcsJobcompLogs;
    static readonly PCS_SCHEDULER_LOGS: CfnClusterPcsSchedulerLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::PCS::Cluster`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCluster;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnClusterPcsSchedulerAuditLogs.
 */
export declare class CfnClusterPcsSchedulerAuditLogsOutputFormat {
}
export declare namespace CfnClusterPcsSchedulerAuditLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnClusterPcsSchedulerAuditLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ID = "resource_id",
    RESOURCE_TYPE = "resource_type",
    EVENT_TIMESTAMP = "event_timestamp",
    LOG_LEVEL = "log_level",
    LOG_NAME = "log_name",
    SCHEDULER_TYPE = "scheduler_type",
    SCHEDULER_MAJOR_VERSION = "scheduler_major_version",
    SCHEDULER_PATCH_VERSION = "scheduler_patch_version",
    NODE_TYPE = "node_type",
    LOG_TYPE = "log_type",
    MESSAGE = "message"
}
export interface CfnClusterPcsSchedulerAuditLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnClusterPcsSchedulerAuditLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterPcsSchedulerAuditLogsRecordFields>;
}
export interface CfnClusterPcsSchedulerAuditLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnClusterPcsSchedulerAuditLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterPcsSchedulerAuditLogsRecordFields>;
}
export interface CfnClusterPcsSchedulerAuditLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnClusterPcsSchedulerAuditLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterPcsSchedulerAuditLogsRecordFields>;
}
export interface CfnClusterPcsSchedulerAuditLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterPcsSchedulerAuditLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnClusterPcsJobcompLogs.
 */
export declare class CfnClusterPcsJobcompLogsOutputFormat {
}
export declare namespace CfnClusterPcsJobcompLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnClusterPcsJobcompLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ID = "resource_id",
    RESOURCE_TYPE = "resource_type",
    EVENT_TIMESTAMP = "event_timestamp",
    SCHEDULER_TYPE = "scheduler_type",
    SCHEDULER_MAJOR_VERSION = "scheduler_major_version",
    FIELDS = "fields"
}
export interface CfnClusterPcsJobcompLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnClusterPcsJobcompLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterPcsJobcompLogsRecordFields>;
}
export interface CfnClusterPcsJobcompLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnClusterPcsJobcompLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterPcsJobcompLogsRecordFields>;
}
export interface CfnClusterPcsJobcompLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnClusterPcsJobcompLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterPcsJobcompLogsRecordFields>;
}
export interface CfnClusterPcsJobcompLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterPcsJobcompLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnClusterPcsSchedulerLogs.
 */
export declare class CfnClusterPcsSchedulerLogsOutputFormat {
}
export declare namespace CfnClusterPcsSchedulerLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnClusterPcsSchedulerLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ID = "resource_id",
    RESOURCE_TYPE = "resource_type",
    EVENT_TIMESTAMP = "event_timestamp",
    LOG_LEVEL = "log_level",
    LOG_NAME = "log_name",
    SCHEDULER_TYPE = "scheduler_type",
    SCHEDULER_MAJOR_VERSION = "scheduler_major_version",
    SCHEDULER_PATCH_VERSION = "scheduler_patch_version",
    NODE_TYPE = "node_type",
    MESSAGE = "message"
}
export interface CfnClusterPcsSchedulerLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnClusterPcsSchedulerLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterPcsSchedulerLogsRecordFields>;
}
export interface CfnClusterPcsSchedulerLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnClusterPcsSchedulerLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterPcsSchedulerLogsRecordFields>;
}
export interface CfnClusterPcsSchedulerLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnClusterPcsSchedulerLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterPcsSchedulerLogsRecordFields>;
}
export interface CfnClusterPcsSchedulerLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnClusterPcsSchedulerLogsRecordFields>;
}
