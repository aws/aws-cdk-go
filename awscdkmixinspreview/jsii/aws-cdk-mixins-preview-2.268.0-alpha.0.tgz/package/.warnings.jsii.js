const VALIDATORS = { _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_BatchJobStateChangeProps: function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_BatchJobStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.attempts != null)
                for (const o of p.attempts)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_BatchJobStateChangeItem(o);
            if (p.dependsOn != null)
                for (const o of p.dependsOn)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_JobDependency(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsS3Props: function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsS3Props: function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.resources != null)
                for (const o of p.resources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_DevOpsGuruInsightClosedProps: function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_DevOpsGuruInsightClosedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.anomalies != null)
                for (const o of p.anomalies)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_Anomaly(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_DevOpsGuruInsightSeverityUpgradedProps: function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_DevOpsGuruInsightSeverityUpgradedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.anomalies != null)
                for (const o of p.anomalies)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_Anomaly(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_DevOpsGuruNewAnomalyAssociationProps: function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_DevOpsGuruNewAnomalyAssociationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.anomalies != null)
                for (const o of p.anomalies)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_Anomaly(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_DevOpsGuruNewInsightOpenProps: function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_DevOpsGuruNewInsightOpenProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.anomalies != null)
                for (const o of p.anomalies)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_Anomaly(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_DevOpsGuruNewRecommendationCreatedProps: function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_DevOpsGuruNewRecommendationCreatedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recommendations != null)
                for (const o of p.recommendations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_Recommendation(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ec2_events_EBSMultiVolumeSnapshotsCompletionStatus_EBSMultiVolumeSnapshotsCompletionStatusProps: function _aws_cdk_mixins_preview_aws_ec2_events_EBSMultiVolumeSnapshotsCompletionStatus_EBSMultiVolumeSnapshotsCompletionStatusProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.snapshots != null)
                for (const o of p.snapshots)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ec2_events_EBSMultiVolumeSnapshotsCompletionStatus_Snapshot(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsS3Props: function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.resources != null)
                for (const o of p.resources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ECSContainerInstanceStateChangeProps: function _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ECSContainerInstanceStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.attachments != null)
                for (const o of p.attachments)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_AttachmentDetails(o);
            if (p.attributes != null)
                for (const o of p.attributes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_AttributesDetails(o);
            if (p.registeredResources != null)
                for (const o of p.registeredResources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ResourceDetails(o);
            if (p.remainingResources != null)
                for (const o of p.remainingResources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ResourceDetails(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_ECSTaskStateChangeProps: function _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_ECSTaskStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.attachments != null)
                for (const o of p.attachments)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_AttachmentDetails(o);
            if (p.attributes != null)
                for (const o of p.attributes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_AttributesDetails(o);
            if (p.containers != null)
                for (const o of p.containers)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_ContainerDetails(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ecs_mixins_CfnClusterActionLogsS3Props: function _aws_cdk_mixins_preview_aws_ecs_mixins_CfnClusterActionLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ecs_mixins_CfnClusterActionLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdCommitserverLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdCommitserverLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdServerLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdServerLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdServerLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationsetLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationsetLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdReposerverLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdReposerverLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsS3Props: function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsS3Props: function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsS3Props: function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsS3Props: function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsS3Props: function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsS3Props: function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsS3Props: function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsS3Props: function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsS3Props: function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsS3Props: function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_GameLiftMatchmakingEventProps: function _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_GameLiftMatchmakingEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.ruleEvaluationMetrics != null)
                for (const o of p.ruleEvaluationMetrics)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_RuleEvaluationMetrics(o);
            if (p.tickets != null)
                for (const o of p.tickets)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_Ticket(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftQueuePlacementEvent_GameLiftQueuePlacementEventProps: function _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftQueuePlacementEvent_GameLiftQueuePlacementEventProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.placedPlayerSessions != null)
                for (const o of p.placedPlayerSessions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_gamelift_events_GameLiftQueuePlacementEvent_GameLiftQueuePlacementEventItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_GuardDutyMalwareProtectionPostScanActionFailedProps: function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_GuardDutyMalwareProtectionPostScanActionFailedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.postScanActions != null)
                for (const o of p.postScanActions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_PostScanAction(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_GuardDutyMalwareProtectionResourceStatusErrorProps: function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_GuardDutyMalwareProtectionResourceStatusErrorProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.statusReasons != null)
                for (const o of p.statusReasons)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_StatusReason(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_GuardDutyMalwareProtectionResourceStatusWarningProps: function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_GuardDutyMalwareProtectionResourceStatusWarningProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.statusReasons != null)
                for (const o of p.statusReasons)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_StatusReason(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.resources != null)
                for (const o of p.resources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsS3Props: function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsS3Props: function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsS3Props: function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsS3Props: function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsS3Props: function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_FirewallAttachmentStatusChangedProps: function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_FirewallAttachmentStatusChangedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.data != null)
                for (const o of p.data)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_DataItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_FirewallConfigurationChangedProps: function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_FirewallConfigurationChangedProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.data != null)
                for (const o of p.data)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_DataItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallDenyLogsS3Props: function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallDenyLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallDenyLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsS3Props: function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAllowLogsS3Props: function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAllowLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAllowLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsS3Props: function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsS3Props: function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsS3Props: function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsS3Props: function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsS3Props: function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_DNSFirewallAlertProps: function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_DNSFirewallAlertProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.resources != null)
                for (const o of p.resources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_DnsFirewallAlertItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_DNSFirewallBlockProps: function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_DNSFirewallBlockProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.resources != null)
                for (const o of p.resources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_DnsFirewallBlockItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_rtbfabric_mixins_CfnLinkApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_rtbfabric_mixins_CfnLinkApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_rtbfabric_mixins_CfnLinkApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps: function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.resources != null)
                for (const o of p.resources)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsS3Props: function _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerAlgorithmStateChange_SageMakerAlgorithmStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerAlgorithmStateChange_SageMakerAlgorithmStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerAlgorithmStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_SageMakerEndpointConfigStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_SageMakerEndpointConfigStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.productionVariants != null)
                for (const o of p.productionVariants)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_SageMakerEndpointConfigStateChangeItem(o);
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointStateChange_SageMakerEndpointStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointStateChange_SageMakerEndpointStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_SageMakerHyperParameterTuningJobStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_SageMakerHyperParameterTuningJobStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelPackageStateChange_SageMakerModelPackageStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelPackageStateChange_SageMakerModelPackageStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelPackageStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_SageMakerModelStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_SageMakerModelStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookInstanceStateChange_SageMakerNotebookInstanceStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookInstanceStateChange_SageMakerNotebookInstanceStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookInstanceStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookLifecycleConfigStateChange_SageMakerNotebookLifecycleConfigStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookLifecycleConfigStateChange_SageMakerNotebookLifecycleConfigStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookLifecycleConfigStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.inputDataConfig != null)
                for (const o of p.inputDataConfig)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeItem(o);
            if (p.secondaryStatusTransitions != null)
                for (const o of p.secondaryStatusTransitions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeItem1(o);
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_SageMakerTransformJobStateChangeProps: function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_SageMakerTransformJobStateChangeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_Tags(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props: function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsS3Props: function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsS3Props: function _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsS3Props: function _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsS3Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.recordFields != null)
                for (const o of p.recordFields)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsRecordFields(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_AWSXRayInsightUpdateProps: function _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_AWSXRayInsightUpdateProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.topAnomalousServices != null)
                for (const o of p.topAnomalousServices)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_AwsxRayInsightUpdateItem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
