import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-connect";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.connect@CodeConnectContact
 */
export declare class CodeConnectContact {
    /**
     * EventBridge event pattern for Amazon Connect Contact Event
     */
    static eventPattern(options?: CodeConnectContact.CodeConnectContactProps): events.EventPattern;
}
export declare namespace CodeConnectContact {
    /**
     * Props type for aws.connect@CodeConnectContact event
     */
    interface CodeConnectContactProps {
        /**
         * agentInfo property
         *
         * Specify an array of string values to match this event if the actual value of agentInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly agentInfo?: CodeConnectContact.AgentInfo;
        /**
         * queueInfo property
         *
         * Specify an array of string values to match this event if the actual value of queueInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queueInfo?: CodeConnectContact.QueueInfo;
        /**
         * channel property
         *
         * Specify an array of string values to match this event if the actual value of channel is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channel?: Array<string>;
        /**
         * contactId property
         *
         * Specify an array of string values to match this event if the actual value of contactId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly contactId?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * initialContactId property
         *
         * Specify an array of string values to match this event if the actual value of initialContactId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly initialContactId?: Array<string>;
        /**
         * initiationMethod property
         *
         * Specify an array of string values to match this event if the actual value of initiationMethod is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly initiationMethod?: Array<string>;
        /**
         * instanceArn property
         *
         * Specify an array of string values to match this event if the actual value of instanceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Instance reference
         */
        readonly instanceArn?: Array<string>;
        /**
         * previousContactId property
         *
         * Specify an array of string values to match this event if the actual value of previousContactId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousContactId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for AgentInfo
     *
     * @struct
     */
    interface AgentInfo {
        /**
         * agentArn property
         *
         * Specify an array of string values to match this event if the actual value of agentArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly agentArn?: Array<string>;
    }
    /**
     * Type definition for QueueInfo
     *
     * @struct
     */
    interface QueueInfo {
        /**
         * queueArn property
         *
         * Specify an array of string values to match this event if the actual value of queueArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queueArn?: Array<string>;
        /**
         * queueType property
         *
         * Specify an array of string values to match this event if the actual value of queueType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queueType?: Array<string>;
    }
}
/**
 * EventBridge event patterns for Instance
 */
export declare class InstanceEvents {
    /**
     * Create InstanceEvents from a Instance reference
     */
    static fromInstance(instanceRef: service.IInstanceRef): InstanceEvents;
    /**
     * Reference to the Instance construct
     */
    private readonly instanceRef;
    private constructor();
    /**
     * EventBridge event pattern for Instance Amazon Connect Contact Event
     */
    codeConnectContactPattern(options?: CodeConnectContact.CodeConnectContactProps): events.EventPattern;
    /**
     * EventBridge event pattern for Instance Contact Lens Post Call Rules Matched
     */
    contactLensPostCallRulesMatchedPattern(options?: ContactLensPostCallRulesMatched.ContactLensPostCallRulesMatchedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Instance Contact Lens Realtime Rules Matched
     */
    contactLensRealtimeRulesMatchedPattern(options?: ContactLensRealtimeRulesMatched.ContactLensRealtimeRulesMatchedProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.connect@ContactLensPostCallRulesMatched
 */
export declare class ContactLensPostCallRulesMatched {
    /**
     * EventBridge event pattern for Contact Lens Post Call Rules Matched
     */
    static eventPattern(options?: ContactLensPostCallRulesMatched.ContactLensPostCallRulesMatchedProps): events.EventPattern;
}
export declare namespace ContactLensPostCallRulesMatched {
    /**
     * Props type for aws.connect@ContactLensPostCallRulesMatched event
     */
    interface ContactLensPostCallRulesMatchedProps {
        /**
         * actionName property
         *
         * Specify an array of string values to match this event if the actual value of actionName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionName?: Array<string>;
        /**
         * agentArn property
         *
         * Specify an array of string values to match this event if the actual value of agentArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly agentArn?: Array<string>;
        /**
         * contactArn property
         *
         * Specify an array of string values to match this event if the actual value of contactArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly contactArn?: Array<string>;
        /**
         * instanceArn property
         *
         * Specify an array of string values to match this event if the actual value of instanceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Instance reference
         */
        readonly instanceArn?: Array<string>;
        /**
         * queueArn property
         *
         * Specify an array of string values to match this event if the actual value of queueArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queueArn?: Array<string>;
        /**
         * ruleName property
         *
         * Specify an array of string values to match this event if the actual value of ruleName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ruleName?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.connect@ContactLensRealtimeRulesMatched
 */
export declare class ContactLensRealtimeRulesMatched {
    /**
     * EventBridge event pattern for Contact Lens Realtime Rules Matched
     */
    static eventPattern(options?: ContactLensRealtimeRulesMatched.ContactLensRealtimeRulesMatchedProps): events.EventPattern;
}
export declare namespace ContactLensRealtimeRulesMatched {
    /**
     * Props type for aws.connect@ContactLensRealtimeRulesMatched event
     */
    interface ContactLensRealtimeRulesMatchedProps {
        /**
         * actionName property
         *
         * Specify an array of string values to match this event if the actual value of actionName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionName?: Array<string>;
        /**
         * agentArn property
         *
         * Specify an array of string values to match this event if the actual value of agentArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly agentArn?: Array<string>;
        /**
         * contactArn property
         *
         * Specify an array of string values to match this event if the actual value of contactArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly contactArn?: Array<string>;
        /**
         * instanceArn property
         *
         * Specify an array of string values to match this event if the actual value of instanceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Instance reference
         */
        readonly instanceArn?: Array<string>;
        /**
         * queueArn property
         *
         * Specify an array of string values to match this event if the actual value of queueArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queueArn?: Array<string>;
        /**
         * ruleName property
         *
         * Specify an array of string values to match this event if the actual value of ruleName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ruleName?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
