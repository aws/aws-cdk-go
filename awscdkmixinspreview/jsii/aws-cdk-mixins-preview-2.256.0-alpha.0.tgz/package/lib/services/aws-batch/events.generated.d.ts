import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.batch@AWSAPICallViaCloudTrail
 */
export declare class AWSAPICallViaCloudTrail {
    /**
     * EventBridge event pattern for AWS API Call via CloudTrail
     */
    static eventPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
}
export declare namespace AWSAPICallViaCloudTrail {
    /**
     * Props type for aws.batch@AWSAPICallViaCloudTrail event
     */
    interface AWSAPICallViaCloudTrailProps {
        /**
         * responseElements property
         *
         * Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly responseElements?: AWSAPICallViaCloudTrail.ResponseElements;
        /**
         * requestParameters property
         *
         * Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestParameters?: AWSAPICallViaCloudTrail.RequestParameters;
        /**
         * userIdentity property
         *
         * Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userIdentity?: AWSAPICallViaCloudTrail.UserIdentity;
        /**
         * eventID property
         *
         * Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * awsRegion property
         *
         * Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsRegion?: Array<string>;
        /**
         * eventVersion property
         *
         * Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventVersion?: Array<string>;
        /**
         * sourceIPAddress property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * eventSource property
         *
         * Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventSource?: Array<string>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * readOnly property
         *
         * Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly readOnly?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * requestID property
         *
         * Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ResponseElements
     *
     * @struct
     */
    interface ResponseElements {
        /**
         * jobName property
         *
         * Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobName?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
    }
    /**
     * Type definition for RequestParameters
     *
     * @struct
     */
    interface RequestParameters {
        /**
         * containerOverrides property
         *
         * Specify an array of string values to match this event if the actual value of containerOverrides is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerOverrides?: AWSAPICallViaCloudTrail.ContainerOverrides;
        /**
         * jobName property
         *
         * Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobName?: Array<string>;
        /**
         * jobQueue property
         *
         * Specify an array of string values to match this event if the actual value of jobQueue is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobQueue?: Array<string>;
        /**
         * jobDefinition property
         *
         * Specify an array of string values to match this event if the actual value of jobDefinition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobDefinition?: Array<string>;
    }
    /**
     * Type definition for ContainerOverrides
     *
     * @struct
     */
    interface ContainerOverrides {
        /**
         * environment property
         *
         * Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly environment?: Array<AWSAPICallViaCloudTrail.ContainerOverridesItem>;
    }
    /**
     * Type definition for ContainerOverridesItem
     *
     * @struct
     */
    interface ContainerOverridesItem {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for UserIdentity
     *
     * @struct
     */
    interface UserIdentity {
        /**
         * sessionContext property
         *
         * Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionContext?: AWSAPICallViaCloudTrail.SessionContext;
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * invokedBy property
         *
         * Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly invokedBy?: Array<string>;
    }
    /**
     * Type definition for SessionContext
     *
     * @struct
     */
    interface SessionContext {
        /**
         * sessionIssuer property
         *
         * Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionIssuer?: AWSAPICallViaCloudTrail.SessionIssuer;
        /**
         * attributes property
         *
         * Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attributes?: AWSAPICallViaCloudTrail.Attributes;
    }
    /**
     * Type definition for SessionIssuer
     *
     * @struct
     */
    interface SessionIssuer {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * userName property
         *
         * Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userName?: Array<string>;
    }
    /**
     * Type definition for Attributes
     *
     * @struct
     */
    interface Attributes {
        /**
         * mfaAuthenticated property
         *
         * Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mfaAuthenticated?: Array<string>;
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.batch@BatchJobStateChange
 */
export declare class BatchJobStateChange {
    /**
     * EventBridge event pattern for Batch Job State Change
     */
    static eventPattern(options?: BatchJobStateChange.BatchJobStateChangeProps): events.EventPattern;
}
export declare namespace BatchJobStateChange {
    /**
     * Props type for aws.batch@BatchJobStateChange event
     */
    interface BatchJobStateChangeProps {
        /**
         * container property
         *
         * Specify an array of string values to match this event if the actual value of container is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly container?: BatchJobStateChange.Container;
        /**
         * retryStrategy property
         *
         * Specify an array of string values to match this event if the actual value of retryStrategy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly retryStrategy?: BatchJobStateChange.RetryStrategy;
        /**
         * parameters property
         *
         * Specify an array of string values to match this event if the actual value of parameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly parameters?: Array<string>;
        /**
         * jobName property
         *
         * Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobName?: Array<string>;
        /**
         * jobQueue property
         *
         * Specify an array of string values to match this event if the actual value of jobQueue is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobQueue?: Array<string>;
        /**
         * dependsOn property
         *
         * Specify an array of string values to match this event if the actual value of dependsOn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dependsOn?: Array<BatchJobStateChange.JobDependency>;
        /**
         * startedAt property
         *
         * Specify an array of string values to match this event if the actual value of startedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startedAt?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * createdAt property
         *
         * Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createdAt?: Array<string>;
        /**
         * stoppedAt property
         *
         * Specify an array of string values to match this event if the actual value of stoppedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stoppedAt?: Array<string>;
        /**
         * statusReason property
         *
         * Specify an array of string values to match this event if the actual value of statusReason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusReason?: Array<string>;
        /**
         * jobDefinition property
         *
         * Specify an array of string values to match this event if the actual value of jobDefinition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobDefinition?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * attempts property
         *
         * Specify an array of string values to match this event if the actual value of attempts is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attempts?: Array<BatchJobStateChange.BatchJobStateChangeItem>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Container
     *
     * @struct
     */
    interface Container {
        /**
         * image property
         *
         * Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly image?: Array<string>;
        /**
         * memory property
         *
         * Specify an array of string values to match this event if the actual value of memory is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly memory?: Array<string>;
        /**
         * logStreamName property
         *
         * Specify an array of string values to match this event if the actual value of logStreamName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly logStreamName?: Array<string>;
        /**
         * taskArn property
         *
         * Specify an array of string values to match this event if the actual value of taskArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly taskArn?: Array<string>;
        /**
         * volumes property
         *
         * Specify an array of string values to match this event if the actual value of volumes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly volumes?: Array<BatchJobStateChange.Volumes>;
        /**
         * vcpus property
         *
         * Specify an array of string values to match this event if the actual value of vcpus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vcpus?: Array<string>;
        /**
         * command property
         *
         * Specify an array of string values to match this event if the actual value of command is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly command?: Array<string>;
        /**
         * resourceRequirements property
         *
         * Specify an array of string values to match this event if the actual value of resourceRequirements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceRequirements?: Array<BatchJobStateChange.ResourceRequirement>;
        /**
         * environment property
         *
         * Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly environment?: Array<BatchJobStateChange.ContainerItem>;
        /**
         * ulimits property
         *
         * Specify an array of string values to match this event if the actual value of ulimits is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ulimits?: Array<BatchJobStateChange.ULimit>;
        /**
         * networkInterfaces property
         *
         * Specify an array of string values to match this event if the actual value of networkInterfaces is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterfaces?: Array<BatchJobStateChange.NetworkInterface>;
        /**
         * mountPoints property
         *
         * Specify an array of string values to match this event if the actual value of mountPoints is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mountPoints?: Array<BatchJobStateChange.MountPoint>;
        /**
         * exitCode property
         *
         * Specify an array of string values to match this event if the actual value of exitCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly exitCode?: Array<string>;
        /**
         * containerInstanceArn property
         *
         * Specify an array of string values to match this event if the actual value of containerInstanceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerInstanceArn?: Array<string>;
    }
    /**
     * Type definition for Volumes
     *
     * @struct
     */
    interface Volumes {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * host property
         *
         * Specify an array of string values to match this event if the actual value of host is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly host?: BatchJobStateChange.Host;
    }
    /**
     * Type definition for Host
     *
     * @struct
     */
    interface Host {
        /**
         * sourcePath property
         *
         * Specify an array of string values to match this event if the actual value of sourcePath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourcePath?: Array<string>;
    }
    /**
     * Type definition for ResourceRequirement
     *
     * @struct
     */
    interface ResourceRequirement {
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for ContainerItem
     *
     * @struct
     */
    interface ContainerItem {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for ULimit
     *
     * @struct
     */
    interface ULimit {
        /**
         * hardLimit property
         *
         * Specify an array of string values to match this event if the actual value of hardLimit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hardLimit?: Array<string>;
        /**
         * softLimit property
         *
         * Specify an array of string values to match this event if the actual value of softLimit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly softLimit?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for NetworkInterface
     *
     * @struct
     */
    interface NetworkInterface {
        /**
         * attachmentId property
         *
         * Specify an array of string values to match this event if the actual value of attachmentId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attachmentId?: Array<string>;
        /**
         * ipv6Address property
         *
         * Specify an array of string values to match this event if the actual value of ipv6Address is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipv6Address?: Array<string>;
        /**
         * privateIpv4Address property
         *
         * Specify an array of string values to match this event if the actual value of privateIpv4Address is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateIpv4Address?: Array<string>;
    }
    /**
     * Type definition for MountPoint
     *
     * @struct
     */
    interface MountPoint {
        /**
         * containerPath property
         *
         * Specify an array of string values to match this event if the actual value of containerPath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerPath?: Array<string>;
        /**
         * readOnly property
         *
         * Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly readOnly?: Array<string>;
        /**
         * sourceVolume property
         *
         * Specify an array of string values to match this event if the actual value of sourceVolume is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceVolume?: Array<string>;
    }
    /**
     * Type definition for RetryStrategy
     *
     * @struct
     */
    interface RetryStrategy {
        /**
         * attempts property
         *
         * Specify an array of string values to match this event if the actual value of attempts is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attempts?: Array<string>;
    }
    /**
     * Type definition for JobDependency
     *
     * @struct
     */
    interface JobDependency {
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for BatchJobStateChangeItem
     *
     * @struct
     */
    interface BatchJobStateChangeItem {
        /**
         * container property
         *
         * Specify an array of string values to match this event if the actual value of container is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly container?: BatchJobStateChange.Container1;
        /**
         * stoppedAt property
         *
         * Specify an array of string values to match this event if the actual value of stoppedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stoppedAt?: Array<string>;
        /**
         * statusReason property
         *
         * Specify an array of string values to match this event if the actual value of statusReason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusReason?: Array<string>;
        /**
         * startedAt property
         *
         * Specify an array of string values to match this event if the actual value of startedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startedAt?: Array<string>;
    }
    /**
     * Type definition for Container_1
     *
     * @struct
     */
    interface Container1 {
        /**
         * networkInterfaces property
         *
         * Specify an array of string values to match this event if the actual value of networkInterfaces is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterfaces?: Array<any>;
        /**
         * logStreamName property
         *
         * Specify an array of string values to match this event if the actual value of logStreamName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly logStreamName?: Array<string>;
        /**
         * taskArn property
         *
         * Specify an array of string values to match this event if the actual value of taskArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly taskArn?: Array<string>;
        /**
         * exitCode property
         *
         * Specify an array of string values to match this event if the actual value of exitCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly exitCode?: Array<string>;
        /**
         * containerInstanceArn property
         *
         * Specify an array of string values to match this event if the actual value of containerInstanceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerInstanceArn?: Array<string>;
    }
}
