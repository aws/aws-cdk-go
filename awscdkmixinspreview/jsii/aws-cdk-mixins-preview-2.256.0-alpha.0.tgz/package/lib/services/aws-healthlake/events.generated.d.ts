import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.healthlake@DataStoreActive
 */
export declare class DataStoreActive {
    /**
     * EventBridge event pattern for Data Store Active
     */
    static eventPattern(options?: DataStoreActive.DataStoreActiveProps): events.EventPattern;
}
export declare namespace DataStoreActive {
    /**
     * Props type for aws.healthlake@DataStoreActive event
     */
    interface DataStoreActiveProps {
        /**
         * datastoreEndpoint property
         *
         * Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreEndpoint?: Array<string>;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * datastoreName property
         *
         * Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreName?: Array<string>;
        /**
         * datastoreTypeVersion property
         *
         * Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreTypeVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthlake@DataStoreCreating
 */
export declare class DataStoreCreating {
    /**
     * EventBridge event pattern for Data Store Creating
     */
    static eventPattern(options?: DataStoreCreating.DataStoreCreatingProps): events.EventPattern;
}
export declare namespace DataStoreCreating {
    /**
     * Props type for aws.healthlake@DataStoreCreating event
     */
    interface DataStoreCreatingProps {
        /**
         * datastoreEndpoint property
         *
         * Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreEndpoint?: Array<string>;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * datastoreName property
         *
         * Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreName?: Array<string>;
        /**
         * datastoreTypeVersion property
         *
         * Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreTypeVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthlake@DataStoreDeleted
 */
export declare class DataStoreDeleted {
    /**
     * EventBridge event pattern for Data Store Deleted
     */
    static eventPattern(options?: DataStoreDeleted.DataStoreDeletedProps): events.EventPattern;
}
export declare namespace DataStoreDeleted {
    /**
     * Props type for aws.healthlake@DataStoreDeleted event
     */
    interface DataStoreDeletedProps {
        /**
         * datastoreEndpoint property
         *
         * Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreEndpoint?: Array<string>;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * datastoreName property
         *
         * Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreName?: Array<string>;
        /**
         * datastoreTypeVersion property
         *
         * Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreTypeVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthlake@DataStoreDeleting
 */
export declare class DataStoreDeleting {
    /**
     * EventBridge event pattern for Data Store Deleting
     */
    static eventPattern(options?: DataStoreDeleting.DataStoreDeletingProps): events.EventPattern;
}
export declare namespace DataStoreDeleting {
    /**
     * Props type for aws.healthlake@DataStoreDeleting event
     */
    interface DataStoreDeletingProps {
        /**
         * datastoreEndpoint property
         *
         * Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreEndpoint?: Array<string>;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * datastoreName property
         *
         * Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreName?: Array<string>;
        /**
         * datastoreTypeVersion property
         *
         * Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreTypeVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthlake@ExportJobCompleted
 */
export declare class ExportJobCompleted {
    /**
     * EventBridge event pattern for Export Job Completed
     */
    static eventPattern(options?: ExportJobCompleted.ExportJobCompletedProps): events.EventPattern;
}
export declare namespace ExportJobCompleted {
    /**
     * Props type for aws.healthlake@ExportJobCompleted event
     */
    interface ExportJobCompletedProps {
        /**
         * outputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputDataConfig?: ExportJobCompleted.OutputDataConfig;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * submitTime property
         *
         * Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly submitTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for OutputDataConfig
     *
     * @struct
     */
    interface OutputDataConfig {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.healthlake@ExportJobCompletedWithErrors
 */
export declare class ExportJobCompletedWithErrors {
    /**
     * EventBridge event pattern for Export Job Completed With Errors
     */
    static eventPattern(options?: ExportJobCompletedWithErrors.ExportJobCompletedWithErrorsProps): events.EventPattern;
}
export declare namespace ExportJobCompletedWithErrors {
    /**
     * Props type for aws.healthlake@ExportJobCompletedWithErrors event
     */
    interface ExportJobCompletedWithErrorsProps {
        /**
         * outputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputDataConfig?: ExportJobCompletedWithErrors.OutputDataConfig;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * submitTime property
         *
         * Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly submitTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for OutputDataConfig
     *
     * @struct
     */
    interface OutputDataConfig {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.healthlake@ExportJobFailed
 */
export declare class ExportJobFailed {
    /**
     * EventBridge event pattern for Export Job Failed
     */
    static eventPattern(options?: ExportJobFailed.ExportJobFailedProps): events.EventPattern;
}
export declare namespace ExportJobFailed {
    /**
     * Props type for aws.healthlake@ExportJobFailed event
     */
    interface ExportJobFailedProps {
        /**
         * outputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputDataConfig?: ExportJobFailed.OutputDataConfig;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * submitTime property
         *
         * Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly submitTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for OutputDataConfig
     *
     * @struct
     */
    interface OutputDataConfig {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.healthlake@ExportJobInProgress
 */
export declare class ExportJobInProgress {
    /**
     * EventBridge event pattern for Export Job In Progress
     */
    static eventPattern(options?: ExportJobInProgress.ExportJobInProgressProps): events.EventPattern;
}
export declare namespace ExportJobInProgress {
    /**
     * Props type for aws.healthlake@ExportJobInProgress event
     */
    interface ExportJobInProgressProps {
        /**
         * outputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputDataConfig?: ExportJobInProgress.OutputDataConfig;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * submitTime property
         *
         * Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly submitTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for OutputDataConfig
     *
     * @struct
     */
    interface OutputDataConfig {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.healthlake@ExportJobSubmitted
 */
export declare class ExportJobSubmitted {
    /**
     * EventBridge event pattern for Export Job Submitted
     */
    static eventPattern(options?: ExportJobSubmitted.ExportJobSubmittedProps): events.EventPattern;
}
export declare namespace ExportJobSubmitted {
    /**
     * Props type for aws.healthlake@ExportJobSubmitted event
     */
    interface ExportJobSubmittedProps {
        /**
         * outputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputDataConfig?: ExportJobSubmitted.OutputDataConfig;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * submitTime property
         *
         * Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly submitTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for OutputDataConfig
     *
     * @struct
     */
    interface OutputDataConfig {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.healthlake@ImportJobCompleted
 */
export declare class ImportJobCompleted {
    /**
     * EventBridge event pattern for Import Job Completed
     */
    static eventPattern(options?: ImportJobCompleted.ImportJobCompletedProps): events.EventPattern;
}
export declare namespace ImportJobCompleted {
    /**
     * Props type for aws.healthlake@ImportJobCompleted event
     */
    interface ImportJobCompletedProps {
        /**
         * inputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputDataConfig?: ImportJobCompleted.InputDataConfig;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * submitTime property
         *
         * Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly submitTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for InputDataConfig
     *
     * @struct
     */
    interface InputDataConfig {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.healthlake@ImportJobCompletedWithErrors
 */
export declare class ImportJobCompletedWithErrors {
    /**
     * EventBridge event pattern for Import Job Completed With Errors
     */
    static eventPattern(options?: ImportJobCompletedWithErrors.ImportJobCompletedWithErrorsProps): events.EventPattern;
}
export declare namespace ImportJobCompletedWithErrors {
    /**
     * Props type for aws.healthlake@ImportJobCompletedWithErrors event
     */
    interface ImportJobCompletedWithErrorsProps {
        /**
         * inputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputDataConfig?: ImportJobCompletedWithErrors.InputDataConfig;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * submitTime property
         *
         * Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly submitTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for InputDataConfig
     *
     * @struct
     */
    interface InputDataConfig {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.healthlake@ImportJobFailed
 */
export declare class ImportJobFailed {
    /**
     * EventBridge event pattern for Import Job Failed
     */
    static eventPattern(options?: ImportJobFailed.ImportJobFailedProps): events.EventPattern;
}
export declare namespace ImportJobFailed {
    /**
     * Props type for aws.healthlake@ImportJobFailed event
     */
    interface ImportJobFailedProps {
        /**
         * inputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputDataConfig?: ImportJobFailed.InputDataConfig;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * submitTime property
         *
         * Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly submitTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for InputDataConfig
     *
     * @struct
     */
    interface InputDataConfig {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.healthlake@ImportJobInProgress
 */
export declare class ImportJobInProgress {
    /**
     * EventBridge event pattern for Import Job In Progress
     */
    static eventPattern(options?: ImportJobInProgress.ImportJobInProgressProps): events.EventPattern;
}
export declare namespace ImportJobInProgress {
    /**
     * Props type for aws.healthlake@ImportJobInProgress event
     */
    interface ImportJobInProgressProps {
        /**
         * inputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputDataConfig?: ImportJobInProgress.InputDataConfig;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * submitTime property
         *
         * Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly submitTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for InputDataConfig
     *
     * @struct
     */
    interface InputDataConfig {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.healthlake@ImportJobSubmitted
 */
export declare class ImportJobSubmitted {
    /**
     * EventBridge event pattern for Import Job Submitted
     */
    static eventPattern(options?: ImportJobSubmitted.ImportJobSubmittedProps): events.EventPattern;
}
export declare namespace ImportJobSubmitted {
    /**
     * Props type for aws.healthlake@ImportJobSubmitted event
     */
    interface ImportJobSubmittedProps {
        /**
         * inputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputDataConfig?: ImportJobSubmitted.InputDataConfig;
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreId?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * submitTime property
         *
         * Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly submitTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for InputDataConfig
     *
     * @struct
     */
    interface InputDataConfig {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
}
