import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-networkmanager";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.networkmanager@NetworkManagerPolicyUpdate
 */
export declare class NetworkManagerPolicyUpdate {
    /**
     * EventBridge event pattern for Network Manager Policy Update
     */
    static eventPattern(options?: NetworkManagerPolicyUpdate.NetworkManagerPolicyUpdateProps): events.EventPattern;
}
export declare namespace NetworkManagerPolicyUpdate {
    /**
     * Props type for aws.networkmanager@NetworkManagerPolicyUpdate event
     */
    interface NetworkManagerPolicyUpdateProps {
        /**
         * changeDescription property
         *
         * Specify an array of string values to match this event if the actual value of changeDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly changeDescription?: Array<string>;
        /**
         * changeType property
         *
         * Specify an array of string values to match this event if the actual value of changeType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly changeType?: Array<string>;
        /**
         * coreNetworkArn property
         *
         * Specify an array of string values to match this event if the actual value of coreNetworkArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the CoreNetwork reference
         */
        readonly coreNetworkArn?: Array<string>;
        /**
         * policyVersionId property
         *
         * Specify an array of string values to match this event if the actual value of policyVersionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly policyVersionId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event patterns for CoreNetwork
 */
export declare class CoreNetworkEvents {
    /**
     * Create CoreNetworkEvents from a CoreNetwork reference
     */
    static fromCoreNetwork(coreNetworkRef: service.ICoreNetworkRef): CoreNetworkEvents;
    /**
     * Reference to the CoreNetwork construct
     */
    private readonly coreNetworkRef;
    private constructor();
    /**
     * EventBridge event pattern for CoreNetwork Network Manager Policy Update
     */
    networkManagerPolicyUpdatePattern(options?: NetworkManagerPolicyUpdate.NetworkManagerPolicyUpdateProps): events.EventPattern;
    /**
     * EventBridge event pattern for CoreNetwork Network Manager Segment Update
     */
    networkManagerSegmentUpdatePattern(options?: NetworkManagerSegmentUpdate.NetworkManagerSegmentUpdateProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.networkmanager@NetworkManagerSegmentUpdate
 */
export declare class NetworkManagerSegmentUpdate {
    /**
     * EventBridge event pattern for Network Manager Segment Update
     */
    static eventPattern(options?: NetworkManagerSegmentUpdate.NetworkManagerSegmentUpdateProps): events.EventPattern;
}
export declare namespace NetworkManagerSegmentUpdate {
    /**
     * Props type for aws.networkmanager@NetworkManagerSegmentUpdate event
     */
    interface NetworkManagerSegmentUpdateProps {
        /**
         * attachmentArn property
         *
         * Specify an array of string values to match this event if the actual value of attachmentArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attachmentArn?: Array<string>;
        /**
         * changeDescription property
         *
         * Specify an array of string values to match this event if the actual value of changeDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly changeDescription?: Array<string>;
        /**
         * changeType property
         *
         * Specify an array of string values to match this event if the actual value of changeType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly changeType?: Array<string>;
        /**
         * coreNetworkArn property
         *
         * Specify an array of string values to match this event if the actual value of coreNetworkArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the CoreNetwork reference
         */
        readonly coreNetworkArn?: Array<string>;
        /**
         * edgeLocation property
         *
         * Specify an array of string values to match this event if the actual value of edgeLocation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly edgeLocation?: Array<string>;
        /**
         * segmentName property
         *
         * Specify an array of string values to match this event if the actual value of segmentName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly segmentName?: Array<string>;
        /**
         * newSegmentName property
         *
         * Specify an array of string values to match this event if the actual value of newSegmentName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly newSegmentName?: Array<string>;
        /**
         * previousSegmentName property
         *
         * Specify an array of string values to match this event if the actual value of previousSegmentName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousSegmentName?: Array<string>;
        /**
         * networkFunctionGroupName property
         *
         * Specify an array of string values to match this event if the actual value of networkFunctionGroupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkFunctionGroupName?: Array<string>;
        /**
         * newNetworkFunctionGroupName property
         *
         * Specify an array of string values to match this event if the actual value of newNetworkFunctionGroupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly newNetworkFunctionGroupName?: Array<string>;
        /**
         * previousNetworkFunctionGroupName property
         *
         * Specify an array of string values to match this event if the actual value of previousNetworkFunctionGroupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousNetworkFunctionGroupName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
