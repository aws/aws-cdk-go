import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.networkfirewall@FirewallAttachmentStatusChanged
 */
export declare class FirewallAttachmentStatusChanged {
    /**
     * EventBridge event pattern for Firewall Attachment Status Changed
     */
    static eventPattern(options?: FirewallAttachmentStatusChanged.FirewallAttachmentStatusChangedProps): events.EventPattern;
}
export declare namespace FirewallAttachmentStatusChanged {
    /**
     * Props type for aws.networkfirewall@FirewallAttachmentStatusChanged event
     */
    interface FirewallAttachmentStatusChangedProps {
        /**
         * data property
         *
         * Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly data?: Array<FirewallAttachmentStatusChanged.DataItem>;
        /**
         * metadata property
         *
         * Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metadata?: FirewallAttachmentStatusChanged.Metadata;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for DataItem
     *
     * @struct
     */
    interface DataItem {
        /**
         * Availability Zone property
         *
         * Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly availabilityZone?: Array<string>;
        /**
         * Current Attachment Status property
         *
         * Specify an array of string values to match this event if the actual value of Current Attachment Status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentAttachmentStatus?: Array<string>;
        /**
         * Endpoint ID property
         *
         * Specify an array of string values to match this event if the actual value of Endpoint ID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endpointId?: Array<string>;
        /**
         * Previous Attachment Status property
         *
         * Specify an array of string values to match this event if the actual value of Previous Attachment Status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousAttachmentStatus?: Array<string>;
    }
    /**
     * Type definition for Metadata
     *
     * @struct
     */
    interface Metadata {
        /**
         * State Change ID property
         *
         * Specify an array of string values to match this event if the actual value of State Change ID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stateChangeId?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.networkfirewall@FirewallConfigurationChanged
 */
export declare class FirewallConfigurationChanged {
    /**
     * EventBridge event pattern for Firewall Configuration Changed
     */
    static eventPattern(options?: FirewallConfigurationChanged.FirewallConfigurationChangedProps): events.EventPattern;
}
export declare namespace FirewallConfigurationChanged {
    /**
     * Props type for aws.networkfirewall@FirewallConfigurationChanged event
     */
    interface FirewallConfigurationChangedProps {
        /**
         * data property
         *
         * Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly data?: Array<FirewallConfigurationChanged.DataItem>;
        /**
         * metadata property
         *
         * Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metadata?: FirewallConfigurationChanged.Metadata;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for DataItem
     *
     * @struct
     */
    interface DataItem {
        /**
         * Availability Zone property
         *
         * Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly availabilityZone?: Array<string>;
        /**
         * Configuration Resource ARN property
         *
         * Specify an array of string values to match this event if the actual value of Configuration Resource ARN is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly configurationResourceArn?: Array<string>;
        /**
         * Current Configuration Sync Status property
         *
         * Specify an array of string values to match this event if the actual value of Current Configuration Sync Status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentConfigurationSyncStatus?: Array<string>;
        /**
         * Previous Configuration Sync Status property
         *
         * Specify an array of string values to match this event if the actual value of Previous Configuration Sync Status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousConfigurationSyncStatus?: Array<string>;
        /**
         * Current Configuration Update Token property
         *
         * Specify an array of string values to match this event if the actual value of Current Configuration Update Token is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentConfigurationUpdateToken?: Array<string>;
        /**
         * Previous Configuration Update Token property
         *
         * Specify an array of string values to match this event if the actual value of Previous Configuration Update Token is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousConfigurationUpdateToken?: Array<string>;
    }
    /**
     * Type definition for Metadata
     *
     * @struct
     */
    interface Metadata {
        /**
         * State Change ID property
         *
         * Specify an array of string values to match this event if the actual value of State Change ID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stateChangeId?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.networkfirewall@FirewallTransitGatewayAttachmentStatusChanged
 */
export declare class FirewallTransitGatewayAttachmentStatusChanged {
    /**
     * EventBridge event pattern for Firewall Transit Gateway Attachment Status Changed
     */
    static eventPattern(options?: FirewallTransitGatewayAttachmentStatusChanged.FirewallTransitGatewayAttachmentStatusChangedProps): events.EventPattern;
}
export declare namespace FirewallTransitGatewayAttachmentStatusChanged {
    /**
     * Props type for aws.networkfirewall@FirewallTransitGatewayAttachmentStatusChanged event
     */
    interface FirewallTransitGatewayAttachmentStatusChangedProps {
        /**
         * data property
         *
         * Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly data?: FirewallTransitGatewayAttachmentStatusChanged.Data;
        /**
         * metadata property
         *
         * Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metadata?: FirewallTransitGatewayAttachmentStatusChanged.Metadata;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Data
     *
     * @struct
     */
    interface Data {
        /**
         * Current Transit Gateway Attachment Status property
         *
         * Specify an array of string values to match this event if the actual value of Current Transit Gateway Attachment Status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentTransitGatewayAttachmentStatus?: Array<string>;
        /**
         * Attachment ID property
         *
         * Specify an array of string values to match this event if the actual value of Attachment ID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attachmentId?: Array<string>;
        /**
         * Previous Transit Gateway Attachment Status property
         *
         * Specify an array of string values to match this event if the actual value of Previous Transit Gateway Attachment Status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousTransitGatewayAttachmentStatus?: Array<string>;
    }
    /**
     * Type definition for Metadata
     *
     * @struct
     */
    interface Metadata {
        /**
         * State Change ID property
         *
         * Specify an array of string values to match this event if the actual value of State Change ID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stateChangeId?: Array<string>;
    }
}
