import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-ec2";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.ec2@EBSMultiVolumeSnapshotsCompletionStatus
 */
export declare class EBSMultiVolumeSnapshotsCompletionStatus {
    /**
     * EventBridge event pattern for EBS Multi-Volume Snapshots Completion Status
     */
    static eventPattern(options?: EBSMultiVolumeSnapshotsCompletionStatus.EBSMultiVolumeSnapshotsCompletionStatusProps): events.EventPattern;
}
export declare namespace EBSMultiVolumeSnapshotsCompletionStatus {
    /**
     * Props type for aws.ec2@EBSMultiVolumeSnapshotsCompletionStatus event
     */
    interface EBSMultiVolumeSnapshotsCompletionStatusProps {
        /**
         * cause property
         *
         * Specify an array of string values to match this event if the actual value of cause is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cause?: Array<string>;
        /**
         * endTime property
         *
         * Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * event property
         *
         * Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly event?: Array<string>;
        /**
         * request-id property
         *
         * Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * result property
         *
         * Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly result?: Array<string>;
        /**
         * snapshots property
         *
         * Specify an array of string values to match this event if the actual value of snapshots is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly snapshots?: Array<EBSMultiVolumeSnapshotsCompletionStatus.Snapshot>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Snapshot
     *
     * @struct
     */
    interface Snapshot {
        /**
         * snapshot_id property
         *
         * Specify an array of string values to match this event if the actual value of snapshot_id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly snapshotId?: Array<string>;
        /**
         * source property
         *
         * Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly source?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.ec2@EBSSnapshotNotification
 */
export declare class EBSSnapshotNotification {
    /**
     * EventBridge event pattern for EBS Snapshot Notification
     */
    static eventPattern(options?: EBSSnapshotNotification.EBSSnapshotNotificationProps): events.EventPattern;
}
export declare namespace EBSSnapshotNotification {
    /**
     * Props type for aws.ec2@EBSSnapshotNotification event
     */
    interface EBSSnapshotNotificationProps {
        /**
         * result property
         *
         * Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly result?: Array<string>;
        /**
         * EndTime property
         *
         * Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * snapshot_id property
         *
         * Specify an array of string values to match this event if the actual value of snapshot_id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly snapshotId?: Array<string>;
        /**
         * StartTime property
         *
         * Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * cause property
         *
         * Specify an array of string values to match this event if the actual value of cause is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cause?: Array<string>;
        /**
         * source property
         *
         * Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly source?: Array<string>;
        /**
         * event property
         *
         * Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly event?: Array<string>;
        /**
         * request-id property
         *
         * Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.ec2@EBSVolumeNotification
 */
export declare class EBSVolumeNotification {
    /**
     * EventBridge event pattern for EBS Volume Notification
     */
    static eventPattern(options?: EBSVolumeNotification.EBSVolumeNotificationProps): events.EventPattern;
}
export declare namespace EBSVolumeNotification {
    /**
     * Props type for aws.ec2@EBSVolumeNotification event
     */
    interface EBSVolumeNotificationProps {
        /**
         * result property
         *
         * Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly result?: Array<string>;
        /**
         * cause property
         *
         * Specify an array of string values to match this event if the actual value of cause is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cause?: Array<string>;
        /**
         * event property
         *
         * Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly event?: Array<string>;
        /**
         * request-id property
         *
         * Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.ec2@EC2FastLaunchStateChangeNotification
 */
export declare class EC2FastLaunchStateChangeNotification {
    /**
     * EventBridge event pattern for EC2 Fast Launch State-change Notification
     */
    static eventPattern(options?: EC2FastLaunchStateChangeNotification.EC2FastLaunchStateChangeNotificationProps): events.EventPattern;
}
export declare namespace EC2FastLaunchStateChangeNotification {
    /**
     * Props type for aws.ec2@EC2FastLaunchStateChangeNotification event
     */
    interface EC2FastLaunchStateChangeNotificationProps {
        /**
         * imageId property
         *
         * Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageId?: Array<string>;
        /**
         * resourceType property
         *
         * Specify an array of string values to match this event if the actual value of resourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceType?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * stateTransitionReason property
         *
         * Specify an array of string values to match this event if the actual value of stateTransitionReason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stateTransitionReason?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.ec2@AWSAPICallViaCloudTrail
 */
export declare class AWSAPICallViaCloudTrail {
    /**
     * EventBridge event pattern for AWS API Call via CloudTrail
     */
    static eventPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
}
export declare namespace AWSAPICallViaCloudTrail {
    /**
     * Props type for aws.ec2@AWSAPICallViaCloudTrail event
     */
    interface AWSAPICallViaCloudTrailProps {
        /**
         * responseElements property
         *
         * Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly responseElements?: AWSAPICallViaCloudTrail.ResponseElements;
        /**
         * requestParameters property
         *
         * Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestParameters?: AWSAPICallViaCloudTrail.RequestParameters;
        /**
         * userIdentity property
         *
         * Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userIdentity?: AWSAPICallViaCloudTrail.UserIdentity;
        /**
         * eventID property
         *
         * Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * awsRegion property
         *
         * Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsRegion?: Array<string>;
        /**
         * eventVersion property
         *
         * Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventVersion?: Array<string>;
        /**
         * sourceIPAddress property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * eventSource property
         *
         * Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventSource?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * requestID property
         *
         * Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ResponseElements
     *
     * @struct
     */
    interface ResponseElements {
        /**
         * instancesSet property
         *
         * Specify an array of string values to match this event if the actual value of instancesSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instancesSet?: AWSAPICallViaCloudTrail.InstancesSet;
        /**
         * CreateFleetResponse property
         *
         * Specify an array of string values to match this event if the actual value of CreateFleetResponse is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createFleetResponse?: AWSAPICallViaCloudTrail.CreateFleetResponse;
        /**
         * DeleteLaunchTemplateResponse property
         *
         * Specify an array of string values to match this event if the actual value of DeleteLaunchTemplateResponse is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deleteLaunchTemplateResponse?: AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse;
        /**
         * networkInterface property
         *
         * Specify an array of string values to match this event if the actual value of networkInterface is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterface?: AWSAPICallViaCloudTrail.NetworkInterface;
        /**
         * CreateLaunchTemplateResponse property
         *
         * Specify an array of string values to match this event if the actual value of CreateLaunchTemplateResponse is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createLaunchTemplateResponse?: AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse;
        /**
         * groupSet property
         *
         * Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupSet?: Array<string>;
        /**
         * _return property
         *
         * Specify an array of string values to match this event if the actual value of _return is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly return?: Array<string>;
        /**
         * requesterId property
         *
         * Specify an array of string values to match this event if the actual value of requesterId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requesterId?: Array<string>;
        /**
         * reservationId property
         *
         * Specify an array of string values to match this event if the actual value of reservationId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reservationId?: Array<string>;
        /**
         * requestId property
         *
         * Specify an array of string values to match this event if the actual value of requestId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * groupId property
         *
         * Specify an array of string values to match this event if the actual value of groupId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupId?: Array<string>;
        /**
         * ownerId property
         *
         * Specify an array of string values to match this event if the actual value of ownerId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ownerId?: Array<string>;
    }
    /**
     * Type definition for InstancesSet
     *
     * @struct
     */
    interface InstancesSet {
        /**
         * items property
         *
         * Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly items?: Array<AWSAPICallViaCloudTrail.InstancesSetItem>;
    }
    /**
     * Type definition for InstancesSetItem
     *
     * @struct
     */
    interface InstancesSetItem {
        /**
         * capacityReservationSpecification property
         *
         * Specify an array of string values to match this event if the actual value of capacityReservationSpecification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly capacityReservationSpecification?: AWSAPICallViaCloudTrail.CapacityReservationSpecification;
        /**
         * stateReason property
         *
         * Specify an array of string values to match this event if the actual value of stateReason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stateReason?: AWSAPICallViaCloudTrail.StateReason;
        /**
         * groupSet property
         *
         * Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupSet?: AWSAPICallViaCloudTrail.GroupSet2;
        /**
         * tagSet property
         *
         * Specify an array of string values to match this event if the actual value of tagSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tagSet?: AWSAPICallViaCloudTrail.TagSet;
        /**
         * instanceState property
         *
         * Specify an array of string values to match this event if the actual value of instanceState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceState?: AWSAPICallViaCloudTrail.InstanceState;
        /**
         * productCodes property
         *
         * Specify an array of string values to match this event if the actual value of productCodes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly productCodes?: Array<string>;
        /**
         * networkInterfaceSet property
         *
         * Specify an array of string values to match this event if the actual value of networkInterfaceSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterfaceSet?: AWSAPICallViaCloudTrail.NetworkInterfaceSet1;
        /**
         * blockDeviceMapping property
         *
         * Specify an array of string values to match this event if the actual value of blockDeviceMapping is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly blockDeviceMapping?: Array<string>;
        /**
         * cpuOptions property
         *
         * Specify an array of string values to match this event if the actual value of cpuOptions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cpuOptions?: AWSAPICallViaCloudTrail.CpuOptions;
        /**
         * monitoring property
         *
         * Specify an array of string values to match this event if the actual value of monitoring is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly monitoring?: AWSAPICallViaCloudTrail.Monitoring1;
        /**
         * previousState property
         *
         * Specify an array of string values to match this event if the actual value of previousState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousState?: AWSAPICallViaCloudTrail.InstanceState;
        /**
         * enclaveOptions property
         *
         * Specify an array of string values to match this event if the actual value of enclaveOptions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly enclaveOptions?: AWSAPICallViaCloudTrail.EnclaveOptions;
        /**
         * placement property
         *
         * Specify an array of string values to match this event if the actual value of placement is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly placement?: AWSAPICallViaCloudTrail.Placement;
        /**
         * currentState property
         *
         * Specify an array of string values to match this event if the actual value of currentState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentState?: AWSAPICallViaCloudTrail.InstanceState;
        /**
         * subnetId property
         *
         * Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
        /**
         * virtualizationType property
         *
         * Specify an array of string values to match this event if the actual value of virtualizationType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly virtualizationType?: Array<string>;
        /**
         * amiLaunchIndex property
         *
         * Specify an array of string values to match this event if the actual value of amiLaunchIndex is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly amiLaunchIndex?: Array<string>;
        /**
         * sourceDestCheck property
         *
         * Specify an array of string values to match this event if the actual value of sourceDestCheck is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceDestCheck?: Array<string>;
        /**
         * instanceId property
         *
         * Specify an array of string values to match this event if the actual value of instanceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Instance reference
         */
        readonly instanceId?: Array<string>;
        /**
         * vpcId property
         *
         * Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcId?: Array<string>;
        /**
         * hypervisor property
         *
         * Specify an array of string values to match this event if the actual value of hypervisor is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hypervisor?: Array<string>;
        /**
         * rootDeviceName property
         *
         * Specify an array of string values to match this event if the actual value of rootDeviceName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rootDeviceName?: Array<string>;
        /**
         * architecture property
         *
         * Specify an array of string values to match this event if the actual value of architecture is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly architecture?: Array<string>;
        /**
         * ebsOptimized property
         *
         * Specify an array of string values to match this event if the actual value of ebsOptimized is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ebsOptimized?: Array<string>;
        /**
         * imageId property
         *
         * Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageId?: Array<string>;
        /**
         * clientToken property
         *
         * Specify an array of string values to match this event if the actual value of clientToken is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientToken?: Array<string>;
        /**
         * instanceType property
         *
         * Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
        /**
         * privateIpAddress property
         *
         * Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateIpAddress?: Array<string>;
        /**
         * instanceLifecycle property
         *
         * Specify an array of string values to match this event if the actual value of instanceLifecycle is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceLifecycle?: Array<string>;
        /**
         * rootDeviceType property
         *
         * Specify an array of string values to match this event if the actual value of rootDeviceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rootDeviceType?: Array<string>;
        /**
         * launchTime property
         *
         * Specify an array of string values to match this event if the actual value of launchTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTime?: Array<string>;
        /**
         * spotInstanceRequestId property
         *
         * Specify an array of string values to match this event if the actual value of spotInstanceRequestId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly spotInstanceRequestId?: Array<string>;
    }
    /**
     * Type definition for CapacityReservationSpecification
     *
     * @struct
     */
    interface CapacityReservationSpecification {
        /**
         * capacityReservationPreference property
         *
         * Specify an array of string values to match this event if the actual value of capacityReservationPreference is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly capacityReservationPreference?: Array<string>;
    }
    /**
     * Type definition for StateReason
     *
     * @struct
     */
    interface StateReason {
        /**
         * code property
         *
         * Specify an array of string values to match this event if the actual value of code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly code?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
    }
    /**
     * Type definition for GroupSet_2
     *
     * @struct
     */
    interface GroupSet2 {
        /**
         * items property
         *
         * Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly items?: Array<AWSAPICallViaCloudTrail.GroupSet2Item>;
    }
    /**
     * Type definition for GroupSet_2Item
     *
     * @struct
     */
    interface GroupSet2Item {
        /**
         * groupName property
         *
         * Specify an array of string values to match this event if the actual value of groupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupName?: Array<string>;
        /**
         * groupId property
         *
         * Specify an array of string values to match this event if the actual value of groupId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupId?: Array<string>;
    }
    /**
     * Type definition for TagSet
     *
     * @struct
     */
    interface TagSet {
        /**
         * items property
         *
         * Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly items?: Array<AWSAPICallViaCloudTrail.TagSpecificationSetItemItem>;
    }
    /**
     * Type definition for TagSpecificationSetItemItem
     *
     * @struct
     */
    interface TagSpecificationSetItemItem {
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
    }
    /**
     * Type definition for InstanceState
     *
     * @struct
     */
    interface InstanceState {
        /**
         * code property
         *
         * Specify an array of string values to match this event if the actual value of code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly code?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for NetworkInterfaceSet_1
     *
     * @struct
     */
    interface NetworkInterfaceSet1 {
        /**
         * items property
         *
         * Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly items?: Array<AWSAPICallViaCloudTrail.NetworkInterfaceSet1Item>;
    }
    /**
     * Type definition for NetworkInterfaceSet_1Item
     *
     * @struct
     */
    interface NetworkInterfaceSet1Item {
        /**
         * groupSet property
         *
         * Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupSet?: AWSAPICallViaCloudTrail.GroupSet3;
        /**
         * tagSet property
         *
         * Specify an array of string values to match this event if the actual value of tagSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tagSet?: Array<string>;
        /**
         * attachment property
         *
         * Specify an array of string values to match this event if the actual value of attachment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attachment?: AWSAPICallViaCloudTrail.Attachment;
        /**
         * ipv6AddressesSet property
         *
         * Specify an array of string values to match this event if the actual value of ipv6AddressesSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipv6AddressesSet?: Array<string>;
        /**
         * privateIpAddressesSet property
         *
         * Specify an array of string values to match this event if the actual value of privateIpAddressesSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateIpAddressesSet?: AWSAPICallViaCloudTrail.PrivateIpAddressesSet2;
        /**
         * networkInterfaceId property
         *
         * Specify an array of string values to match this event if the actual value of networkInterfaceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterfaceId?: Array<string>;
        /**
         * subnetId property
         *
         * Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
        /**
         * ownerId property
         *
         * Specify an array of string values to match this event if the actual value of ownerId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ownerId?: Array<string>;
        /**
         * sourceDestCheck property
         *
         * Specify an array of string values to match this event if the actual value of sourceDestCheck is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceDestCheck?: Array<string>;
        /**
         * privateIpAddress property
         *
         * Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateIpAddress?: Array<string>;
        /**
         * interfaceType property
         *
         * Specify an array of string values to match this event if the actual value of interfaceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly interfaceType?: Array<string>;
        /**
         * macAddress property
         *
         * Specify an array of string values to match this event if the actual value of macAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly macAddress?: Array<string>;
        /**
         * vpcId property
         *
         * Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
    }
    /**
     * Type definition for GroupSet_3
     *
     * @struct
     */
    interface GroupSet3 {
        /**
         * items property
         *
         * Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly items?: Array<AWSAPICallViaCloudTrail.GroupSet2Item>;
    }
    /**
     * Type definition for Attachment
     *
     * @struct
     */
    interface Attachment {
        /**
         * attachmentId property
         *
         * Specify an array of string values to match this event if the actual value of attachmentId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attachmentId?: Array<string>;
        /**
         * deleteOnTermination property
         *
         * Specify an array of string values to match this event if the actual value of deleteOnTermination is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deleteOnTermination?: Array<string>;
        /**
         * deviceIndex property
         *
         * Specify an array of string values to match this event if the actual value of deviceIndex is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deviceIndex?: Array<string>;
        /**
         * attachTime property
         *
         * Specify an array of string values to match this event if the actual value of attachTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attachTime?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
    }
    /**
     * Type definition for PrivateIpAddressesSet_2
     *
     * @struct
     */
    interface PrivateIpAddressesSet2 {
        /**
         * item property
         *
         * Specify an array of string values to match this event if the actual value of item is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly item?: Array<AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item>;
    }
    /**
     * Type definition for PrivateIpAddressesSet_1Item
     *
     * @struct
     */
    interface PrivateIpAddressesSet1Item {
        /**
         * privateIpAddress property
         *
         * Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateIpAddress?: Array<string>;
        /**
         * primary property
         *
         * Specify an array of string values to match this event if the actual value of primary is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly primary?: Array<string>;
    }
    /**
     * Type definition for CpuOptions
     *
     * @struct
     */
    interface CpuOptions {
        /**
         * threadsPerCore property
         *
         * Specify an array of string values to match this event if the actual value of threadsPerCore is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threadsPerCore?: Array<string>;
        /**
         * coreCount property
         *
         * Specify an array of string values to match this event if the actual value of coreCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly coreCount?: Array<string>;
    }
    /**
     * Type definition for Monitoring_1
     *
     * @struct
     */
    interface Monitoring1 {
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
    }
    /**
     * Type definition for EnclaveOptions
     *
     * @struct
     */
    interface EnclaveOptions {
        /**
         * enabled property
         *
         * Specify an array of string values to match this event if the actual value of enabled is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly enabled?: Array<string>;
    }
    /**
     * Type definition for Placement
     *
     * @struct
     */
    interface Placement {
        /**
         * tenancy property
         *
         * Specify an array of string values to match this event if the actual value of tenancy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tenancy?: Array<string>;
        /**
         * availabilityZone property
         *
         * Specify an array of string values to match this event if the actual value of availabilityZone is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly availabilityZone?: Array<string>;
    }
    /**
     * Type definition for CreateFleetResponse
     *
     * @struct
     */
    interface CreateFleetResponse {
        /**
         * fleetInstanceSet property
         *
         * Specify an array of string values to match this event if the actual value of fleetInstanceSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fleetInstanceSet?: Array<string>;
        /**
         * xmlns property
         *
         * Specify an array of string values to match this event if the actual value of xmlns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly xmlns?: Array<string>;
        /**
         * requestId property
         *
         * Specify an array of string values to match this event if the actual value of requestId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * fleetId property
         *
         * Specify an array of string values to match this event if the actual value of fleetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fleetId?: Array<string>;
        /**
         * errorSet property
         *
         * Specify an array of string values to match this event if the actual value of errorSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorSet?: Array<string>;
    }
    /**
     * Type definition for DeleteLaunchTemplateResponse
     *
     * @struct
     */
    interface DeleteLaunchTemplateResponse {
        /**
         * launchTemplate property
         *
         * Specify an array of string values to match this event if the actual value of launchTemplate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplate?: AWSAPICallViaCloudTrail.LaunchTemplate1;
        /**
         * xmlns property
         *
         * Specify an array of string values to match this event if the actual value of xmlns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly xmlns?: Array<string>;
        /**
         * requestId property
         *
         * Specify an array of string values to match this event if the actual value of requestId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
    }
    /**
     * Type definition for LaunchTemplate_1
     *
     * @struct
     */
    interface LaunchTemplate1 {
        /**
         * createTime property
         *
         * Specify an array of string values to match this event if the actual value of createTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createTime?: Array<string>;
        /**
         * createdBy property
         *
         * Specify an array of string values to match this event if the actual value of createdBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createdBy?: Array<string>;
        /**
         * launchTemplateId property
         *
         * Specify an array of string values to match this event if the actual value of launchTemplateId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplateId?: Array<string>;
        /**
         * latestVersionNumber property
         *
         * Specify an array of string values to match this event if the actual value of latestVersionNumber is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly latestVersionNumber?: Array<string>;
        /**
         * defaultVersionNumber property
         *
         * Specify an array of string values to match this event if the actual value of defaultVersionNumber is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly defaultVersionNumber?: Array<string>;
        /**
         * launchTemplateName property
         *
         * Specify an array of string values to match this event if the actual value of launchTemplateName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplateName?: Array<string>;
    }
    /**
     * Type definition for NetworkInterface
     *
     * @struct
     */
    interface NetworkInterface {
        /**
         * groupSet property
         *
         * Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupSet?: AWSAPICallViaCloudTrail.GroupSet2;
        /**
         * tagSet property
         *
         * Specify an array of string values to match this event if the actual value of tagSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tagSet?: Array<string>;
        /**
         * ipv6AddressesSet property
         *
         * Specify an array of string values to match this event if the actual value of ipv6AddressesSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipv6AddressesSet?: Array<string>;
        /**
         * privateIpAddressesSet property
         *
         * Specify an array of string values to match this event if the actual value of privateIpAddressesSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateIpAddressesSet?: AWSAPICallViaCloudTrail.PrivateIpAddressesSet1;
        /**
         * networkInterfaceId property
         *
         * Specify an array of string values to match this event if the actual value of networkInterfaceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterfaceId?: Array<string>;
        /**
         * subnetId property
         *
         * Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
        /**
         * requesterId property
         *
         * Specify an array of string values to match this event if the actual value of requesterId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requesterId?: Array<string>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * ownerId property
         *
         * Specify an array of string values to match this event if the actual value of ownerId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ownerId?: Array<string>;
        /**
         * sourceDestCheck property
         *
         * Specify an array of string values to match this event if the actual value of sourceDestCheck is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceDestCheck?: Array<string>;
        /**
         * availabilityZone property
         *
         * Specify an array of string values to match this event if the actual value of availabilityZone is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly availabilityZone?: Array<string>;
        /**
         * requesterManaged property
         *
         * Specify an array of string values to match this event if the actual value of requesterManaged is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requesterManaged?: Array<string>;
        /**
         * privateIpAddress property
         *
         * Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateIpAddress?: Array<string>;
        /**
         * interfaceType property
         *
         * Specify an array of string values to match this event if the actual value of interfaceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly interfaceType?: Array<string>;
        /**
         * macAddress property
         *
         * Specify an array of string values to match this event if the actual value of macAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly macAddress?: Array<string>;
        /**
         * vpcId property
         *
         * Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
    }
    /**
     * Type definition for PrivateIpAddressesSet_1
     *
     * @struct
     */
    interface PrivateIpAddressesSet1 {
        /**
         * item property
         *
         * Specify an array of string values to match this event if the actual value of item is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly item?: Array<AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item>;
    }
    /**
     * Type definition for RequestParameters
     *
     * @struct
     */
    interface RequestParameters {
        /**
         * CreateLaunchTemplateRequest property
         *
         * Specify an array of string values to match this event if the actual value of CreateLaunchTemplateRequest is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createLaunchTemplateRequest?: AWSAPICallViaCloudTrail.CreateLaunchTemplateRequest;
        /**
         * groupSet property
         *
         * Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupSet?: AWSAPICallViaCloudTrail.GroupSet1;
        /**
         * instancesSet property
         *
         * Specify an array of string values to match this event if the actual value of instancesSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instancesSet?: AWSAPICallViaCloudTrail.InstancesSet1;
        /**
         * CreateFleetRequest property
         *
         * Specify an array of string values to match this event if the actual value of CreateFleetRequest is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createFleetRequest?: AWSAPICallViaCloudTrail.CreateFleetRequest;
        /**
         * DeleteLaunchTemplateRequest property
         *
         * Specify an array of string values to match this event if the actual value of DeleteLaunchTemplateRequest is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deleteLaunchTemplateRequest?: AWSAPICallViaCloudTrail.DeleteLaunchTemplateRequest;
        /**
         * privateIpAddressesSet property
         *
         * Specify an array of string values to match this event if the actual value of privateIpAddressesSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateIpAddressesSet?: Array<string>;
        /**
         * networkInterfaceSet property
         *
         * Specify an array of string values to match this event if the actual value of networkInterfaceSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterfaceSet?: AWSAPICallViaCloudTrail.NetworkInterfaceSet;
        /**
         * blockDeviceMapping property
         *
         * Specify an array of string values to match this event if the actual value of blockDeviceMapping is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly blockDeviceMapping?: Array<string>;
        /**
         * tagSpecificationSet property
         *
         * Specify an array of string values to match this event if the actual value of tagSpecificationSet is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tagSpecificationSet?: AWSAPICallViaCloudTrail.TagSpecificationSet;
        /**
         * monitoring property
         *
         * Specify an array of string values to match this event if the actual value of monitoring is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly monitoring?: AWSAPICallViaCloudTrail.Monitoring;
        /**
         * instanceMarketOptions property
         *
         * Specify an array of string values to match this event if the actual value of instanceMarketOptions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceMarketOptions?: AWSAPICallViaCloudTrail.InstanceMarketOptions;
        /**
         * launchTemplate property
         *
         * Specify an array of string values to match this event if the actual value of launchTemplate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplate?: AWSAPICallViaCloudTrail.LaunchTemplate;
        /**
         * subnetId property
         *
         * Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
        /**
         * userData property
         *
         * Specify an array of string values to match this event if the actual value of userData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userData?: Array<string>;
        /**
         * groupId property
         *
         * Specify an array of string values to match this event if the actual value of groupId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupId?: Array<string>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * availabilityZone property
         *
         * Specify an array of string values to match this event if the actual value of availabilityZone is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly availabilityZone?: Array<string>;
        /**
         * vpcId property
         *
         * Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcId?: Array<string>;
        /**
         * networkInterfaceId property
         *
         * Specify an array of string values to match this event if the actual value of networkInterfaceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterfaceId?: Array<string>;
        /**
         * clientToken property
         *
         * Specify an array of string values to match this event if the actual value of clientToken is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientToken?: Array<string>;
        /**
         * instanceType property
         *
         * Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
        /**
         * ipv6AddressCount property
         *
         * Specify an array of string values to match this event if the actual value of ipv6AddressCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipv6AddressCount?: Array<string>;
        /**
         * groupName property
         *
         * Specify an array of string values to match this event if the actual value of groupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupName?: Array<string>;
        /**
         * disableApiTermination property
         *
         * Specify an array of string values to match this event if the actual value of disableApiTermination is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly disableApiTermination?: Array<string>;
        /**
         * groupDescription property
         *
         * Specify an array of string values to match this event if the actual value of groupDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupDescription?: Array<string>;
    }
    /**
     * Type definition for CreateLaunchTemplateRequest
     *
     * @struct
     */
    interface CreateLaunchTemplateRequest {
        /**
         * LaunchTemplateData property
         *
         * Specify an array of string values to match this event if the actual value of LaunchTemplateData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplateData?: AWSAPICallViaCloudTrail.LaunchTemplateData;
        /**
         * LaunchTemplateName property
         *
         * Specify an array of string values to match this event if the actual value of LaunchTemplateName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplateName?: Array<string>;
    }
    /**
     * Type definition for LaunchTemplateData
     *
     * @struct
     */
    interface LaunchTemplateData {
        /**
         * InstanceMarketOptions property
         *
         * Specify an array of string values to match this event if the actual value of InstanceMarketOptions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceMarketOptions?: AWSAPICallViaCloudTrail.InstanceMarketOptions1;
        /**
         * NetworkInterface property
         *
         * Specify an array of string values to match this event if the actual value of NetworkInterface is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterface?: AWSAPICallViaCloudTrail.NetworkInterface1;
        /**
         * UserData property
         *
         * Specify an array of string values to match this event if the actual value of UserData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userData?: Array<string>;
        /**
         * ImageId property
         *
         * Specify an array of string values to match this event if the actual value of ImageId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageId?: Array<string>;
        /**
         * InstanceType property
         *
         * Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
    }
    /**
     * Type definition for InstanceMarketOptions_1
     *
     * @struct
     */
    interface InstanceMarketOptions1 {
        /**
         * SpotOptions property
         *
         * Specify an array of string values to match this event if the actual value of SpotOptions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly spotOptions?: AWSAPICallViaCloudTrail.SpotOptions2;
        /**
         * MarketType property
         *
         * Specify an array of string values to match this event if the actual value of MarketType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly marketType?: Array<string>;
    }
    /**
     * Type definition for SpotOptions_2
     *
     * @struct
     */
    interface SpotOptions2 {
        /**
         * SpotInstanceType property
         *
         * Specify an array of string values to match this event if the actual value of SpotInstanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly spotInstanceType?: Array<string>;
        /**
         * MaxPrice property
         *
         * Specify an array of string values to match this event if the actual value of MaxPrice is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxPrice?: Array<string>;
    }
    /**
     * Type definition for NetworkInterface_1
     *
     * @struct
     */
    interface NetworkInterface1 {
        /**
         * SecurityGroupId property
         *
         * Specify an array of string values to match this event if the actual value of SecurityGroupId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly securityGroupId?: AWSAPICallViaCloudTrail.SecurityGroupId;
        /**
         * DeviceIndex property
         *
         * Specify an array of string values to match this event if the actual value of DeviceIndex is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deviceIndex?: Array<string>;
        /**
         * tag property
         *
         * Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tag?: Array<string>;
        /**
         * SubnetId property
         *
         * Specify an array of string values to match this event if the actual value of SubnetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
    }
    /**
     * Type definition for SecurityGroupId
     *
     * @struct
     */
    interface SecurityGroupId {
        /**
         * tag property
         *
         * Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tag?: Array<string>;
        /**
         * content property
         *
         * Specify an array of string values to match this event if the actual value of content is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly content?: Array<string>;
    }
    /**
     * Type definition for GroupSet_1
     *
     * @struct
     */
    interface GroupSet1 {
        /**
         * items property
         *
         * Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly items?: Array<AWSAPICallViaCloudTrail.GroupSet1Item>;
    }
    /**
     * Type definition for GroupSet_1Item
     *
     * @struct
     */
    interface GroupSet1Item {
        /**
         * groupId property
         *
         * Specify an array of string values to match this event if the actual value of groupId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupId?: Array<string>;
    }
    /**
     * Type definition for InstancesSet_1
     *
     * @struct
     */
    interface InstancesSet1 {
        /**
         * items property
         *
         * Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly items?: Array<AWSAPICallViaCloudTrail.InstancesSet1Item>;
    }
    /**
     * Type definition for InstancesSet_1Item
     *
     * @struct
     */
    interface InstancesSet1Item {
        /**
         * instanceId property
         *
         * Specify an array of string values to match this event if the actual value of instanceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceId?: Array<string>;
        /**
         * imageId property
         *
         * Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageId?: Array<string>;
        /**
         * minCount property
         *
         * Specify an array of string values to match this event if the actual value of minCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly minCount?: Array<string>;
        /**
         * maxCount property
         *
         * Specify an array of string values to match this event if the actual value of maxCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxCount?: Array<string>;
    }
    /**
     * Type definition for CreateFleetRequest
     *
     * @struct
     */
    interface CreateFleetRequest {
        /**
         * TargetCapacitySpecification property
         *
         * Specify an array of string values to match this event if the actual value of TargetCapacitySpecification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetCapacitySpecification?: AWSAPICallViaCloudTrail.TargetCapacitySpecification;
        /**
         * OnDemandOptions property
         *
         * Specify an array of string values to match this event if the actual value of OnDemandOptions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly onDemandOptions?: AWSAPICallViaCloudTrail.OnDemandOptions;
        /**
         * SpotOptions property
         *
         * Specify an array of string values to match this event if the actual value of SpotOptions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly spotOptions?: AWSAPICallViaCloudTrail.SpotOptions;
        /**
         * ExistingInstances property
         *
         * Specify an array of string values to match this event if the actual value of ExistingInstances is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly existingInstances?: AWSAPICallViaCloudTrail.ExistingInstances;
        /**
         * LaunchTemplateConfigs property
         *
         * Specify an array of string values to match this event if the actual value of LaunchTemplateConfigs is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplateConfigs?: AWSAPICallViaCloudTrail.LaunchTemplateConfigs;
        /**
         * TagSpecification property
         *
         * Specify an array of string values to match this event if the actual value of TagSpecification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tagSpecification?: AWSAPICallViaCloudTrail.TagSpecification;
        /**
         * Type property
         *
         * Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * ClientToken property
         *
         * Specify an array of string values to match this event if the actual value of ClientToken is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientToken?: Array<string>;
    }
    /**
     * Type definition for TargetCapacitySpecification
     *
     * @struct
     */
    interface TargetCapacitySpecification {
        /**
         * DefaultTargetCapacityType property
         *
         * Specify an array of string values to match this event if the actual value of DefaultTargetCapacityType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly defaultTargetCapacityType?: Array<string>;
        /**
         * TotalTargetCapacity property
         *
         * Specify an array of string values to match this event if the actual value of TotalTargetCapacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly totalTargetCapacity?: Array<string>;
        /**
         * OnDemandTargetCapacity property
         *
         * Specify an array of string values to match this event if the actual value of OnDemandTargetCapacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly onDemandTargetCapacity?: Array<string>;
        /**
         * SpotTargetCapacity property
         *
         * Specify an array of string values to match this event if the actual value of SpotTargetCapacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly spotTargetCapacity?: Array<string>;
    }
    /**
     * Type definition for OnDemandOptions
     *
     * @struct
     */
    interface OnDemandOptions {
        /**
         * AllocationStrategy property
         *
         * Specify an array of string values to match this event if the actual value of AllocationStrategy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly allocationStrategy?: Array<string>;
        /**
         * MaxTargetCapacity property
         *
         * Specify an array of string values to match this event if the actual value of MaxTargetCapacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxTargetCapacity?: Array<string>;
        /**
         * MaxInstanceCount property
         *
         * Specify an array of string values to match this event if the actual value of MaxInstanceCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxInstanceCount?: Array<string>;
        /**
         * InstancePoolConstraintFilterDisabled property
         *
         * Specify an array of string values to match this event if the actual value of InstancePoolConstraintFilterDisabled is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instancePoolConstraintFilterDisabled?: Array<string>;
    }
    /**
     * Type definition for SpotOptions
     *
     * @struct
     */
    interface SpotOptions {
        /**
         * AllocationStrategy property
         *
         * Specify an array of string values to match this event if the actual value of AllocationStrategy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly allocationStrategy?: Array<string>;
        /**
         * MaxTargetCapacity property
         *
         * Specify an array of string values to match this event if the actual value of MaxTargetCapacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxTargetCapacity?: Array<string>;
        /**
         * MaxInstanceCount property
         *
         * Specify an array of string values to match this event if the actual value of MaxInstanceCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxInstanceCount?: Array<string>;
        /**
         * InstancePoolsToUseCount property
         *
         * Specify an array of string values to match this event if the actual value of InstancePoolsToUseCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instancePoolsToUseCount?: Array<string>;
        /**
         * InstancePoolConstraintFilterDisabled property
         *
         * Specify an array of string values to match this event if the actual value of InstancePoolConstraintFilterDisabled is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instancePoolConstraintFilterDisabled?: Array<string>;
    }
    /**
     * Type definition for ExistingInstances
     *
     * @struct
     */
    interface ExistingInstances {
        /**
         * OperatingSystem property
         *
         * Specify an array of string values to match this event if the actual value of OperatingSystem is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly operatingSystem?: Array<string>;
        /**
         * AvailabilityZone property
         *
         * Specify an array of string values to match this event if the actual value of AvailabilityZone is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly availabilityZone?: Array<string>;
        /**
         * tag property
         *
         * Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tag?: Array<string>;
        /**
         * Count property
         *
         * Specify an array of string values to match this event if the actual value of Count is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly count?: Array<string>;
        /**
         * InstanceType property
         *
         * Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
        /**
         * MarketOption property
         *
         * Specify an array of string values to match this event if the actual value of MarketOption is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly marketOption?: Array<string>;
    }
    /**
     * Type definition for LaunchTemplateConfigs
     *
     * @struct
     */
    interface LaunchTemplateConfigs {
        /**
         * LaunchTemplateSpecification property
         *
         * Specify an array of string values to match this event if the actual value of LaunchTemplateSpecification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplateSpecification?: AWSAPICallViaCloudTrail.LaunchTemplateSpecification;
        /**
         * Overrides property
         *
         * Specify an array of string values to match this event if the actual value of Overrides is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly overrides?: Array<any>;
        /**
         * tag property
         *
         * Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tag?: Array<string>;
    }
    /**
     * Type definition for LaunchTemplateSpecification
     *
     * @struct
     */
    interface LaunchTemplateSpecification {
        /**
         * Version property
         *
         * Specify an array of string values to match this event if the actual value of Version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * LaunchTemplateId property
         *
         * Specify an array of string values to match this event if the actual value of LaunchTemplateId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplateId?: Array<string>;
    }
    /**
     * Type definition for TagSpecification
     *
     * @struct
     */
    interface TagSpecification {
        /**
         * Tag property
         *
         * Specify an array of string values to match this event if the actual value of Tag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tag?: AWSAPICallViaCloudTrail.TagType;
        /**
         * ResourceType property
         *
         * Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceType?: Array<string>;
    }
    /**
     * Type definition for Tag
     *
     * @struct
     */
    interface TagType {
        /**
         * Value property
         *
         * Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
        /**
         * tag property
         *
         * Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tag?: Array<string>;
        /**
         * Key property
         *
         * Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
    }
    /**
     * Type definition for DeleteLaunchTemplateRequest
     *
     * @struct
     */
    interface DeleteLaunchTemplateRequest {
        /**
         * LaunchTemplateName property
         *
         * Specify an array of string values to match this event if the actual value of LaunchTemplateName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplateName?: Array<string>;
    }
    /**
     * Type definition for NetworkInterfaceSet
     *
     * @struct
     */
    interface NetworkInterfaceSet {
        /**
         * items property
         *
         * Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly items?: Array<AWSAPICallViaCloudTrail.NetworkInterfaceSetItem>;
    }
    /**
     * Type definition for NetworkInterfaceSetItem
     *
     * @struct
     */
    interface NetworkInterfaceSetItem {
        /**
         * subnetId property
         *
         * Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
        /**
         * deviceIndex property
         *
         * Specify an array of string values to match this event if the actual value of deviceIndex is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deviceIndex?: Array<string>;
    }
    /**
     * Type definition for TagSpecificationSet
     *
     * @struct
     */
    interface TagSpecificationSet {
        /**
         * items property
         *
         * Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly items?: Array<AWSAPICallViaCloudTrail.TagSpecificationSetItem>;
    }
    /**
     * Type definition for TagSpecificationSetItem
     *
     * @struct
     */
    interface TagSpecificationSetItem {
        /**
         * resourceType property
         *
         * Specify an array of string values to match this event if the actual value of resourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceType?: Array<string>;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<AWSAPICallViaCloudTrail.TagSpecificationSetItemItem>;
    }
    /**
     * Type definition for Monitoring
     *
     * @struct
     */
    interface Monitoring {
        /**
         * enabled property
         *
         * Specify an array of string values to match this event if the actual value of enabled is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly enabled?: Array<string>;
    }
    /**
     * Type definition for InstanceMarketOptions
     *
     * @struct
     */
    interface InstanceMarketOptions {
        /**
         * spotOptions property
         *
         * Specify an array of string values to match this event if the actual value of spotOptions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly spotOptions?: AWSAPICallViaCloudTrail.SpotOptions1;
        /**
         * marketType property
         *
         * Specify an array of string values to match this event if the actual value of marketType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly marketType?: Array<string>;
    }
    /**
     * Type definition for SpotOptions_1
     *
     * @struct
     */
    interface SpotOptions1 {
        /**
         * spotInstanceType property
         *
         * Specify an array of string values to match this event if the actual value of spotInstanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly spotInstanceType?: Array<string>;
        /**
         * maxPrice property
         *
         * Specify an array of string values to match this event if the actual value of maxPrice is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxPrice?: Array<string>;
    }
    /**
     * Type definition for LaunchTemplate
     *
     * @struct
     */
    interface LaunchTemplate {
        /**
         * launchTemplateId property
         *
         * Specify an array of string values to match this event if the actual value of launchTemplateId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplateId?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
    }
    /**
     * Type definition for UserIdentity
     *
     * @struct
     */
    interface UserIdentity {
        /**
         * sessionContext property
         *
         * Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionContext?: AWSAPICallViaCloudTrail.SessionContext;
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * invokedBy property
         *
         * Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly invokedBy?: Array<string>;
    }
    /**
     * Type definition for SessionContext
     *
     * @struct
     */
    interface SessionContext {
        /**
         * webIdFederationData property
         *
         * Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly webIdFederationData?: Array<string>;
        /**
         * sessionIssuer property
         *
         * Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionIssuer?: AWSAPICallViaCloudTrail.SessionIssuer;
        /**
         * attributes property
         *
         * Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attributes?: AWSAPICallViaCloudTrail.Attributes;
    }
    /**
     * Type definition for SessionIssuer
     *
     * @struct
     */
    interface SessionIssuer {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * userName property
         *
         * Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userName?: Array<string>;
    }
    /**
     * Type definition for Attributes
     *
     * @struct
     */
    interface Attributes {
        /**
         * mfaAuthenticated property
         *
         * Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mfaAuthenticated?: Array<string>;
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
    }
}
/**
 * EventBridge event patterns for Instance
 */
export declare class InstanceEvents {
    /**
     * Create InstanceEvents from a Instance reference
     */
    static fromInstance(instanceRef: service.IInstanceRef): InstanceEvents;
    /**
     * Reference to the Instance construct
     */
    private readonly instanceRef;
    private constructor();
    /**
     * EventBridge event pattern for Instance AWS API Call via CloudTrail
     */
    awsAPICallViaCloudTrailPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
    /**
     * EventBridge event pattern for Instance EC2 Instance State-change Notification
     */
    ec2InstanceStateChangeNotificationPattern(options?: EC2InstanceStateChangeNotification.EC2InstanceStateChangeNotificationProps): events.EventPattern;
    /**
     * EventBridge event pattern for Instance EC2 Spot Instance Interruption Warning
     */
    ec2SpotInstanceInterruptionWarningPattern(options?: EC2SpotInstanceInterruptionWarning.EC2SpotInstanceInterruptionWarningProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.ec2@EC2InstanceStateChangeNotification
 */
export declare class EC2InstanceStateChangeNotification {
    /**
     * EventBridge event pattern for EC2 Instance State-change Notification
     */
    static eventPattern(options?: EC2InstanceStateChangeNotification.EC2InstanceStateChangeNotificationProps): events.EventPattern;
}
export declare namespace EC2InstanceStateChangeNotification {
    /**
     * Props type for aws.ec2@EC2InstanceStateChangeNotification event
     */
    interface EC2InstanceStateChangeNotificationProps {
        /**
         * instance-id property
         *
         * Specify an array of string values to match this event if the actual value of instance-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Instance reference
         */
        readonly instanceId?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.ec2@EC2SpotInstanceInterruptionWarning
 */
export declare class EC2SpotInstanceInterruptionWarning {
    /**
     * EventBridge event pattern for EC2 Spot Instance Interruption Warning
     */
    static eventPattern(options?: EC2SpotInstanceInterruptionWarning.EC2SpotInstanceInterruptionWarningProps): events.EventPattern;
}
export declare namespace EC2SpotInstanceInterruptionWarning {
    /**
     * Props type for aws.ec2@EC2SpotInstanceInterruptionWarning event
     */
    interface EC2SpotInstanceInterruptionWarningProps {
        /**
         * instance-id property
         *
         * Specify an array of string values to match this event if the actual value of instance-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Instance reference
         */
        readonly instanceId?: Array<string>;
        /**
         * instance-action property
         *
         * Specify an array of string values to match this event if the actual value of instance-action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceAction?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
