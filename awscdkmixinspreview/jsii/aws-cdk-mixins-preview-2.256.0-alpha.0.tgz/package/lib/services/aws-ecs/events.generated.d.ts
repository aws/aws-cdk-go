import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-ecs";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.ecs@AWSAPICallViaCloudTrail
 */
export declare class AWSAPICallViaCloudTrail {
    /**
     * EventBridge event pattern for AWS API Call via CloudTrail
     */
    static eventPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
}
export declare namespace AWSAPICallViaCloudTrail {
    /**
     * Props type for aws.ecs@AWSAPICallViaCloudTrail event
     */
    interface AWSAPICallViaCloudTrailProps {
        /**
         * responseElements property
         *
         * Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly responseElements?: AWSAPICallViaCloudTrail.ResponseElements;
        /**
         * requestParameters property
         *
         * Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestParameters?: AWSAPICallViaCloudTrail.RequestParameters;
        /**
         * userIdentity property
         *
         * Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userIdentity?: AWSAPICallViaCloudTrail.UserIdentity;
        /**
         * eventID property
         *
         * Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * awsRegion property
         *
         * Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsRegion?: Array<string>;
        /**
         * eventVersion property
         *
         * Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventVersion?: Array<string>;
        /**
         * sourceIPAddress property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * eventSource property
         *
         * Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventSource?: Array<string>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * requestID property
         *
         * Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ResponseElements
     *
     * @struct
     */
    interface ResponseElements {
        /**
         * endpoint property
         *
         * Specify an array of string values to match this event if the actual value of endpoint is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endpoint?: Array<string>;
        /**
         * failures property
         *
         * Specify an array of string values to match this event if the actual value of failures is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failures?: Array<string>;
        /**
         * telemetryEndpoint property
         *
         * Specify an array of string values to match this event if the actual value of telemetryEndpoint is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly telemetryEndpoint?: Array<string>;
        /**
         * tasks property
         *
         * Specify an array of string values to match this event if the actual value of tasks is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tasks?: Array<AWSAPICallViaCloudTrail.ResponseElementsItem>;
        /**
         * acknowledgment property
         *
         * Specify an array of string values to match this event if the actual value of acknowledgment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly acknowledgment?: Array<string>;
    }
    /**
     * Type definition for ResponseElementsItem
     *
     * @struct
     */
    interface ResponseElementsItem {
        /**
         * overrides property
         *
         * Specify an array of string values to match this event if the actual value of overrides is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly overrides?: AWSAPICallViaCloudTrail.Overrides1;
        /**
         * memory property
         *
         * Specify an array of string values to match this event if the actual value of memory is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly memory?: Array<string>;
        /**
         * attachments property
         *
         * Specify an array of string values to match this event if the actual value of attachments is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attachments?: Array<AWSAPICallViaCloudTrail.ResponseElementsItemItem>;
        /**
         * startedBy property
         *
         * Specify an array of string values to match this event if the actual value of startedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startedBy?: Array<string>;
        /**
         * taskArn property
         *
         * Specify an array of string values to match this event if the actual value of taskArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly taskArn?: Array<string>;
        /**
         * cpu property
         *
         * Specify an array of string values to match this event if the actual value of cpu is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cpu?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<any>;
        /**
         * createdAt property
         *
         * Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createdAt?: Array<string>;
        /**
         * clusterArn property
         *
         * Specify an array of string values to match this event if the actual value of clusterArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Cluster reference
         */
        readonly clusterArn?: Array<string>;
        /**
         * taskDefinitionArn property
         *
         * Specify an array of string values to match this event if the actual value of taskDefinitionArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly taskDefinitionArn?: Array<string>;
        /**
         * platformVersion property
         *
         * Specify an array of string values to match this event if the actual value of platformVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly platformVersion?: Array<string>;
        /**
         * containers property
         *
         * Specify an array of string values to match this event if the actual value of containers is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containers?: Array<AWSAPICallViaCloudTrail.ResponseElementsItemItem1>;
        /**
         * containerInstanceArn property
         *
         * Specify an array of string values to match this event if the actual value of containerInstanceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerInstanceArn?: Array<string>;
        /**
         * lastStatus property
         *
         * Specify an array of string values to match this event if the actual value of lastStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastStatus?: Array<string>;
        /**
         * desiredStatus property
         *
         * Specify an array of string values to match this event if the actual value of desiredStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly desiredStatus?: Array<string>;
        /**
         * group property
         *
         * Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly group?: Array<string>;
        /**
         * launchType property
         *
         * Specify an array of string values to match this event if the actual value of launchType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchType?: Array<string>;
    }
    /**
     * Type definition for Overrides_1
     *
     * @struct
     */
    interface Overrides1 {
        /**
         * containerOverrides property
         *
         * Specify an array of string values to match this event if the actual value of containerOverrides is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerOverrides?: Array<AWSAPICallViaCloudTrail.Overrides1Item>;
        /**
         * inferenceAcceleratorOverrides property
         *
         * Specify an array of string values to match this event if the actual value of inferenceAcceleratorOverrides is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inferenceAcceleratorOverrides?: Array<any>;
    }
    /**
     * Type definition for Overrides_1Item
     *
     * @struct
     */
    interface Overrides1Item {
        /**
         * resourceRequirements property
         *
         * Specify an array of string values to match this event if the actual value of resourceRequirements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceRequirements?: Array<any>;
        /**
         * environment property
         *
         * Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly environment?: Array<any>;
        /**
         * memory property
         *
         * Specify an array of string values to match this event if the actual value of memory is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly memory?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * cpu property
         *
         * Specify an array of string values to match this event if the actual value of cpu is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cpu?: Array<string>;
        /**
         * command property
         *
         * Specify an array of string values to match this event if the actual value of command is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly command?: Array<string>;
    }
    /**
     * Type definition for ResponseElementsItemItem
     *
     * @struct
     */
    interface ResponseElementsItemItem {
        /**
         * details property
         *
         * Specify an array of string values to match this event if the actual value of details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly details?: Array<AWSAPICallViaCloudTrail.ResponseElementsItemItemItem>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
    }
    /**
     * Type definition for ResponseElementsItemItemItem
     *
     * @struct
     */
    interface ResponseElementsItemItemItem {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for ResponseElementsItemItem_1
     *
     * @struct
     */
    interface ResponseElementsItemItem1 {
        /**
         * image property
         *
         * Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly image?: Array<string>;
        /**
         * networkInterfaces property
         *
         * Specify an array of string values to match this event if the actual value of networkInterfaces is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterfaces?: Array<any>;
        /**
         * memory property
         *
         * Specify an array of string values to match this event if the actual value of memory is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly memory?: Array<string>;
        /**
         * taskArn property
         *
         * Specify an array of string values to match this event if the actual value of taskArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly taskArn?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * cpu property
         *
         * Specify an array of string values to match this event if the actual value of cpu is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cpu?: Array<string>;
        /**
         * containerArn property
         *
         * Specify an array of string values to match this event if the actual value of containerArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerArn?: Array<string>;
        /**
         * lastStatus property
         *
         * Specify an array of string values to match this event if the actual value of lastStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastStatus?: Array<string>;
    }
    /**
     * Type definition for RequestParameters
     *
     * @struct
     */
    interface RequestParameters {
        /**
         * networkConfiguration property
         *
         * Specify an array of string values to match this event if the actual value of networkConfiguration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkConfiguration?: AWSAPICallViaCloudTrail.NetworkConfiguration;
        /**
         * overrides property
         *
         * Specify an array of string values to match this event if the actual value of overrides is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly overrides?: AWSAPICallViaCloudTrail.Overrides;
        /**
         * placementConstraints property
         *
         * Specify an array of string values to match this event if the actual value of placementConstraints is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly placementConstraints?: Array<AWSAPICallViaCloudTrail.RequestParametersItem>;
        /**
         * cluster property
         *
         * Specify an array of string values to match this event if the actual value of cluster is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cluster?: Array<string>;
        /**
         * reason property
         *
         * Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reason?: Array<string>;
        /**
         * executionStoppedAt property
         *
         * Specify an array of string values to match this event if the actual value of executionStoppedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly executionStoppedAt?: Array<string>;
        /**
         * pullStoppedAt property
         *
         * Specify an array of string values to match this event if the actual value of pullStoppedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullStoppedAt?: Array<string>;
        /**
         * startedBy property
         *
         * Specify an array of string values to match this event if the actual value of startedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startedBy?: Array<string>;
        /**
         * pullStartedAt property
         *
         * Specify an array of string values to match this event if the actual value of pullStartedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullStartedAt?: Array<string>;
        /**
         * count property
         *
         * Specify an array of string values to match this event if the actual value of count is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly count?: Array<string>;
        /**
         * task property
         *
         * Specify an array of string values to match this event if the actual value of task is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly task?: Array<string>;
        /**
         * containerInstance property
         *
         * Specify an array of string values to match this event if the actual value of containerInstance is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerInstance?: Array<string>;
        /**
         * containers property
         *
         * Specify an array of string values to match this event if the actual value of containers is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containers?: Array<AWSAPICallViaCloudTrail.RequestParametersItem1>;
        /**
         * taskDefinition property
         *
         * Specify an array of string values to match this event if the actual value of taskDefinition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly taskDefinition?: Array<string>;
        /**
         * enableECSManagedTags property
         *
         * Specify an array of string values to match this event if the actual value of enableECSManagedTags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly enableEcsManagedTags?: Array<string>;
        /**
         * launchType property
         *
         * Specify an array of string values to match this event if the actual value of launchType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchType?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
    }
    /**
     * Type definition for NetworkConfiguration
     *
     * @struct
     */
    interface NetworkConfiguration {
        /**
         * awsvpcConfiguration property
         *
         * Specify an array of string values to match this event if the actual value of awsvpcConfiguration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsvpcConfiguration?: AWSAPICallViaCloudTrail.AwsvpcConfiguration;
    }
    /**
     * Type definition for AwsvpcConfiguration
     *
     * @struct
     */
    interface AwsvpcConfiguration {
        /**
         * assignPublicIp property
         *
         * Specify an array of string values to match this event if the actual value of assignPublicIp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly assignPublicIp?: Array<string>;
        /**
         * subnets property
         *
         * Specify an array of string values to match this event if the actual value of subnets is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnets?: Array<string>;
    }
    /**
     * Type definition for Overrides
     *
     * @struct
     */
    interface Overrides {
        /**
         * containerOverrides property
         *
         * Specify an array of string values to match this event if the actual value of containerOverrides is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerOverrides?: Array<AWSAPICallViaCloudTrail.OverridesItem>;
    }
    /**
     * Type definition for OverridesItem
     *
     * @struct
     */
    interface OverridesItem {
        /**
         * resourceRequirements property
         *
         * Specify an array of string values to match this event if the actual value of resourceRequirements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceRequirements?: Array<any>;
        /**
         * environment property
         *
         * Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly environment?: Array<any>;
        /**
         * memory property
         *
         * Specify an array of string values to match this event if the actual value of memory is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly memory?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * cpu property
         *
         * Specify an array of string values to match this event if the actual value of cpu is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cpu?: Array<string>;
        /**
         * command property
         *
         * Specify an array of string values to match this event if the actual value of command is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly command?: Array<string>;
    }
    /**
     * Type definition for RequestParametersItem
     *
     * @struct
     */
    interface RequestParametersItem {
        /**
         * expression property
         *
         * Specify an array of string values to match this event if the actual value of expression is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly expression?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for RequestParametersItem_1
     *
     * @struct
     */
    interface RequestParametersItem1 {
        /**
         * containerName property
         *
         * Specify an array of string values to match this event if the actual value of containerName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerName?: Array<string>;
        /**
         * exitCode property
         *
         * Specify an array of string values to match this event if the actual value of exitCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly exitCode?: Array<string>;
        /**
         * networkBindings property
         *
         * Specify an array of string values to match this event if the actual value of networkBindings is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkBindings?: Array<any>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
    }
    /**
     * Type definition for UserIdentity
     *
     * @struct
     */
    interface UserIdentity {
        /**
         * sessionContext property
         *
         * Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionContext?: AWSAPICallViaCloudTrail.SessionContext;
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * invokedBy property
         *
         * Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly invokedBy?: Array<string>;
    }
    /**
     * Type definition for SessionContext
     *
     * @struct
     */
    interface SessionContext {
        /**
         * webIdFederationData property
         *
         * Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly webIdFederationData?: Array<string>;
        /**
         * sessionIssuer property
         *
         * Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionIssuer?: AWSAPICallViaCloudTrail.SessionIssuer;
        /**
         * attributes property
         *
         * Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attributes?: AWSAPICallViaCloudTrail.Attributes;
    }
    /**
     * Type definition for SessionIssuer
     *
     * @struct
     */
    interface SessionIssuer {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * userName property
         *
         * Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userName?: Array<string>;
    }
    /**
     * Type definition for Attributes
     *
     * @struct
     */
    interface Attributes {
        /**
         * mfaAuthenticated property
         *
         * Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mfaAuthenticated?: Array<string>;
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
    }
}
/**
 * EventBridge event patterns for Cluster
 */
export declare class ClusterEvents {
    /**
     * Create ClusterEvents from a Cluster reference
     */
    static fromCluster(clusterRef: service.IClusterRef): ClusterEvents;
    /**
     * Reference to the Cluster construct
     */
    private readonly clusterRef;
    private constructor();
    /**
     * EventBridge event pattern for Cluster AWS API Call via CloudTrail
     */
    awsAPICallViaCloudTrailPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
    /**
     * EventBridge event pattern for Cluster ECS Container Instance State Change
     */
    ecsContainerInstanceStateChangePattern(options?: ECSContainerInstanceStateChange.ECSContainerInstanceStateChangeProps): events.EventPattern;
    /**
     * EventBridge event pattern for Cluster ECS Service Action
     */
    ecsServiceActionPattern(options?: ECSServiceAction.ECSServiceActionProps): events.EventPattern;
    /**
     * EventBridge event pattern for Cluster ECS Task State Change
     */
    ecsTaskStateChangePattern(options?: ECSTaskStateChange.ECSTaskStateChangeProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.ecs@ECSContainerInstanceStateChange
 */
export declare class ECSContainerInstanceStateChange {
    /**
     * EventBridge event pattern for ECS Container Instance State Change
     */
    static eventPattern(options?: ECSContainerInstanceStateChange.ECSContainerInstanceStateChangeProps): events.EventPattern;
}
export declare namespace ECSContainerInstanceStateChange {
    /**
     * Props type for aws.ecs@ECSContainerInstanceStateChange event
     */
    interface ECSContainerInstanceStateChangeProps {
        /**
         * versionInfo property
         *
         * Specify an array of string values to match this event if the actual value of versionInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionInfo?: ECSContainerInstanceStateChange.VersionInfo;
        /**
         * ec2InstanceId property
         *
         * Specify an array of string values to match this event if the actual value of ec2InstanceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ec2InstanceId?: Array<string>;
        /**
         * attachments property
         *
         * Specify an array of string values to match this event if the actual value of attachments is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attachments?: Array<ECSContainerInstanceStateChange.AttachmentDetails>;
        /**
         * registeredResources property
         *
         * Specify an array of string values to match this event if the actual value of registeredResources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly registeredResources?: Array<ECSContainerInstanceStateChange.ResourceDetails>;
        /**
         * remainingResources property
         *
         * Specify an array of string values to match this event if the actual value of remainingResources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly remainingResources?: Array<ECSContainerInstanceStateChange.ResourceDetails>;
        /**
         * runningTasksCount property
         *
         * Specify an array of string values to match this event if the actual value of runningTasksCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly runningTasksCount?: Array<string>;
        /**
         * registeredAt property
         *
         * Specify an array of string values to match this event if the actual value of registeredAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly registeredAt?: Array<string>;
        /**
         * agentConnected property
         *
         * Specify an array of string values to match this event if the actual value of agentConnected is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly agentConnected?: Array<string>;
        /**
         * agentUpdateStatus property
         *
         * Specify an array of string values to match this event if the actual value of agentUpdateStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly agentUpdateStatus?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * pendingTasksCount property
         *
         * Specify an array of string values to match this event if the actual value of pendingTasksCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pendingTasksCount?: Array<string>;
        /**
         * clusterArn property
         *
         * Specify an array of string values to match this event if the actual value of clusterArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Cluster reference
         */
        readonly clusterArn?: Array<string>;
        /**
         * attributes property
         *
         * Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attributes?: Array<ECSContainerInstanceStateChange.AttributesDetails>;
        /**
         * containerInstanceArn property
         *
         * Specify an array of string values to match this event if the actual value of containerInstanceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerInstanceArn?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * statusReason property
         *
         * Specify an array of string values to match this event if the actual value of statusReason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusReason?: Array<string>;
        /**
         * updatedAt property
         *
         * Specify an array of string values to match this event if the actual value of updatedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly updatedAt?: Array<string>;
        /**
         * accountType property
         *
         * Specify an array of string values to match this event if the actual value of accountType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountType?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for VersionInfo
     *
     * @struct
     */
    interface VersionInfo {
        /**
         * dockerVersion property
         *
         * Specify an array of string values to match this event if the actual value of dockerVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dockerVersion?: Array<string>;
        /**
         * agentHash property
         *
         * Specify an array of string values to match this event if the actual value of agentHash is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly agentHash?: Array<string>;
        /**
         * agentVersion property
         *
         * Specify an array of string values to match this event if the actual value of agentVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly agentVersion?: Array<string>;
    }
    /**
     * Type definition for AttachmentDetails
     *
     * @struct
     */
    interface AttachmentDetails {
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * details property
         *
         * Specify an array of string values to match this event if the actual value of details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly details?: Array<ECSContainerInstanceStateChange.DetailsItems>;
    }
    /**
     * Type definition for detailsItems
     *
     * @struct
     */
    interface DetailsItems {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for ResourceDetails
     *
     * @struct
     */
    interface ResourceDetails {
        /**
         * integerValue property
         *
         * Specify an array of string values to match this event if the actual value of integerValue is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly integerValue?: Array<string>;
        /**
         * longValue property
         *
         * Specify an array of string values to match this event if the actual value of longValue is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly longValue?: Array<string>;
        /**
         * doubleValue property
         *
         * Specify an array of string values to match this event if the actual value of doubleValue is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly doubleValue?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * stringSetValue property
         *
         * Specify an array of string values to match this event if the actual value of stringSetValue is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stringSetValue?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for AttributesDetails
     *
     * @struct
     */
    interface AttributesDetails {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.ecs@ECSServiceAction
 */
export declare class ECSServiceAction {
    /**
     * EventBridge event pattern for ECS Service Action
     */
    static eventPattern(options?: ECSServiceAction.ECSServiceActionProps): events.EventPattern;
}
export declare namespace ECSServiceAction {
    /**
     * Props type for aws.ecs@ECSServiceAction event
     */
    interface ECSServiceActionProps {
        /**
         * capacityProviderArns property
         *
         * Specify an array of string values to match this event if the actual value of capacityProviderArns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly capacityProviderArns?: Array<string>;
        /**
         * clusterArn property
         *
         * Specify an array of string values to match this event if the actual value of clusterArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Cluster reference
         */
        readonly clusterArn?: Array<string>;
        /**
         * createdAt property
         *
         * Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createdAt?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * reason property
         *
         * Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reason?: Array<string>;
        /**
         * desiredCount property
         *
         * Specify an array of string values to match this event if the actual value of desiredCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly desiredCount?: Array<string>;
        /**
         * containerPort property
         *
         * Specify an array of string values to match this event if the actual value of containerPort is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerPort?: Array<string>;
        /**
         * taskArns property
         *
         * Specify an array of string values to match this event if the actual value of taskArns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly taskArns?: Array<string>;
        /**
         * taskSetArns property
         *
         * Specify an array of string values to match this event if the actual value of taskSetArns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly taskSetArns?: Array<string>;
        /**
         * containerInstanceArns property
         *
         * Specify an array of string values to match this event if the actual value of containerInstanceArns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerInstanceArns?: Array<string>;
        /**
         * ec2InstanceIds property
         *
         * Specify an array of string values to match this event if the actual value of ec2InstanceIds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ec2InstanceIds?: Array<string>;
        /**
         * targetGroupArns property
         *
         * Specify an array of string values to match this event if the actual value of targetGroupArns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetGroupArns?: Array<string>;
        /**
         * serviceRegistryArns property
         *
         * Specify an array of string values to match this event if the actual value of serviceRegistryArns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serviceRegistryArns?: Array<string>;
        /**
         * targets property
         *
         * Specify an array of string values to match this event if the actual value of targets is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targets?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.ecs@ECSTaskStateChange
 */
export declare class ECSTaskStateChange {
    /**
     * EventBridge event pattern for ECS Task State Change
     */
    static eventPattern(options?: ECSTaskStateChange.ECSTaskStateChangeProps): events.EventPattern;
}
export declare namespace ECSTaskStateChange {
    /**
     * Props type for aws.ecs@ECSTaskStateChange event
     */
    interface ECSTaskStateChangeProps {
        /**
         * overrides property
         *
         * Specify an array of string values to match this event if the actual value of overrides is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly overrides?: ECSTaskStateChange.Overrides;
        /**
         * executionStoppedAt property
         *
         * Specify an array of string values to match this event if the actual value of executionStoppedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly executionStoppedAt?: Array<string>;
        /**
         * memory property
         *
         * Specify an array of string values to match this event if the actual value of memory is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly memory?: Array<string>;
        /**
         * attachments property
         *
         * Specify an array of string values to match this event if the actual value of attachments is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attachments?: Array<ECSTaskStateChange.AttachmentDetails>;
        /**
         * attributes property
         *
         * Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attributes?: Array<ECSTaskStateChange.AttributesDetails>;
        /**
         * pullStartedAt property
         *
         * Specify an array of string values to match this event if the actual value of pullStartedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullStartedAt?: Array<string>;
        /**
         * taskArn property
         *
         * Specify an array of string values to match this event if the actual value of taskArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly taskArn?: Array<string>;
        /**
         * startedAt property
         *
         * Specify an array of string values to match this event if the actual value of startedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startedAt?: Array<string>;
        /**
         * createdAt property
         *
         * Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createdAt?: Array<string>;
        /**
         * clusterArn property
         *
         * Specify an array of string values to match this event if the actual value of clusterArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Cluster reference
         */
        readonly clusterArn?: Array<string>;
        /**
         * connectivity property
         *
         * Specify an array of string values to match this event if the actual value of connectivity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly connectivity?: Array<string>;
        /**
         * platformVersion property
         *
         * Specify an array of string values to match this event if the actual value of platformVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly platformVersion?: Array<string>;
        /**
         * containerInstanceArn property
         *
         * Specify an array of string values to match this event if the actual value of containerInstanceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerInstanceArn?: Array<string>;
        /**
         * launchType property
         *
         * Specify an array of string values to match this event if the actual value of launchType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchType?: Array<string>;
        /**
         * group property
         *
         * Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly group?: Array<string>;
        /**
         * updatedAt property
         *
         * Specify an array of string values to match this event if the actual value of updatedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly updatedAt?: Array<string>;
        /**
         * stopCode property
         *
         * Specify an array of string values to match this event if the actual value of stopCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stopCode?: Array<string>;
        /**
         * pullStoppedAt property
         *
         * Specify an array of string values to match this event if the actual value of pullStoppedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullStoppedAt?: Array<string>;
        /**
         * connectivityAt property
         *
         * Specify an array of string values to match this event if the actual value of connectivityAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly connectivityAt?: Array<string>;
        /**
         * startedBy property
         *
         * Specify an array of string values to match this event if the actual value of startedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startedBy?: Array<string>;
        /**
         * cpu property
         *
         * Specify an array of string values to match this event if the actual value of cpu is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cpu?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * stoppingAt property
         *
         * Specify an array of string values to match this event if the actual value of stoppingAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stoppingAt?: Array<string>;
        /**
         * stoppedAt property
         *
         * Specify an array of string values to match this event if the actual value of stoppedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stoppedAt?: Array<string>;
        /**
         * taskDefinitionArn property
         *
         * Specify an array of string values to match this event if the actual value of taskDefinitionArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly taskDefinitionArn?: Array<string>;
        /**
         * stoppedReason property
         *
         * Specify an array of string values to match this event if the actual value of stoppedReason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stoppedReason?: Array<string>;
        /**
         * containers property
         *
         * Specify an array of string values to match this event if the actual value of containers is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containers?: Array<ECSTaskStateChange.ContainerDetails>;
        /**
         * desiredStatus property
         *
         * Specify an array of string values to match this event if the actual value of desiredStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly desiredStatus?: Array<string>;
        /**
         * lastStatus property
         *
         * Specify an array of string values to match this event if the actual value of lastStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastStatus?: Array<string>;
        /**
         * availabilityZone property
         *
         * Specify an array of string values to match this event if the actual value of availabilityZone is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly availabilityZone?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Overrides
     *
     * @struct
     */
    interface Overrides {
        /**
         * containerOverrides property
         *
         * Specify an array of string values to match this event if the actual value of containerOverrides is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerOverrides?: Array<ECSTaskStateChange.OverridesItem>;
    }
    /**
     * Type definition for OverridesItem
     *
     * @struct
     */
    interface OverridesItem {
        /**
         * environment property
         *
         * Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly environment?: Array<Record<string, string>>;
        /**
         * memory property
         *
         * Specify an array of string values to match this event if the actual value of memory is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly memory?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * cpu property
         *
         * Specify an array of string values to match this event if the actual value of cpu is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cpu?: Array<string>;
        /**
         * command property
         *
         * Specify an array of string values to match this event if the actual value of command is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly command?: Array<string>;
    }
    /**
     * Type definition for AttachmentDetails
     *
     * @struct
     */
    interface AttachmentDetails {
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * details property
         *
         * Specify an array of string values to match this event if the actual value of details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly details?: ECSTaskStateChange.Details;
    }
    /**
     * Type definition for details
     *
     * @struct
     */
    interface Details {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for AttributesDetails
     *
     * @struct
     */
    interface AttributesDetails {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for ContainerDetails
     *
     * @struct
     */
    interface ContainerDetails {
        /**
         * image property
         *
         * Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly image?: Array<string>;
        /**
         * imageDigest property
         *
         * Specify an array of string values to match this event if the actual value of imageDigest is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageDigest?: Array<string>;
        /**
         * networkInterfaces property
         *
         * Specify an array of string values to match this event if the actual value of networkInterfaces is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterfaces?: Array<ECSTaskStateChange.NetworkInterfaceDetails>;
        /**
         * networkBindings property
         *
         * Specify an array of string values to match this event if the actual value of networkBindings is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkBindings?: Array<ECSTaskStateChange.NetworkBindingDetails>;
        /**
         * memory property
         *
         * Specify an array of string values to match this event if the actual value of memory is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly memory?: Array<string>;
        /**
         * memoryReservation property
         *
         * Specify an array of string values to match this event if the actual value of memoryReservation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly memoryReservation?: Array<string>;
        /**
         * taskArn property
         *
         * Specify an array of string values to match this event if the actual value of taskArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly taskArn?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * exitCode property
         *
         * Specify an array of string values to match this event if the actual value of exitCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly exitCode?: Array<string>;
        /**
         * cpu property
         *
         * Specify an array of string values to match this event if the actual value of cpu is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cpu?: Array<string>;
        /**
         * containerArn property
         *
         * Specify an array of string values to match this event if the actual value of containerArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerArn?: Array<string>;
        /**
         * lastStatus property
         *
         * Specify an array of string values to match this event if the actual value of lastStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastStatus?: Array<string>;
        /**
         * runtimeId property
         *
         * Specify an array of string values to match this event if the actual value of runtimeId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly runtimeId?: Array<string>;
        /**
         * reason property
         *
         * Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reason?: Array<string>;
        /**
         * gpuIds property
         *
         * Specify an array of string values to match this event if the actual value of gpuIds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly gpuIds?: Array<string>;
    }
    /**
     * Type definition for NetworkInterfaceDetails
     *
     * @struct
     */
    interface NetworkInterfaceDetails {
        /**
         * privateIpv4Address property
         *
         * Specify an array of string values to match this event if the actual value of privateIpv4Address is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateIpv4Address?: Array<string>;
        /**
         * ipv6Address property
         *
         * Specify an array of string values to match this event if the actual value of ipv6Address is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipv6Address?: Array<string>;
        /**
         * attachmentId property
         *
         * Specify an array of string values to match this event if the actual value of attachmentId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attachmentId?: Array<string>;
    }
    /**
     * Type definition for NetworkBindingDetails
     *
     * @struct
     */
    interface NetworkBindingDetails {
        /**
         * bindIP property
         *
         * Specify an array of string values to match this event if the actual value of bindIP is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bindIp?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * containerPort property
         *
         * Specify an array of string values to match this event if the actual value of containerPort is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerPort?: Array<string>;
        /**
         * hostPort property
         *
         * Specify an array of string values to match this event if the actual value of hostPort is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hostPort?: Array<string>;
    }
}
