import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-s3";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.s3@AWSAPICallViaCloudTrail
 */
export declare class AWSAPICallViaCloudTrail {
    /**
     * EventBridge event pattern for AWS API Call via CloudTrail
     */
    static eventPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
}
export declare namespace AWSAPICallViaCloudTrail {
    /**
     * Props type for aws.s3@AWSAPICallViaCloudTrail event
     */
    interface AWSAPICallViaCloudTrailProps {
        /**
         * requestParameters property
         *
         * Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestParameters?: AWSAPICallViaCloudTrail.RequestParameters;
        /**
         * tlsDetails property
         *
         * Specify an array of string values to match this event if the actual value of tlsDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tlsDetails?: AWSAPICallViaCloudTrail.TlsDetails;
        /**
         * userIdentity property
         *
         * Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userIdentity?: AWSAPICallViaCloudTrail.UserIdentity;
        /**
         * additionalEventData property
         *
         * Specify an array of string values to match this event if the actual value of additionalEventData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly additionalEventData?: AWSAPICallViaCloudTrail.AdditionalEventData;
        /**
         * eventID property
         *
         * Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * awsRegion property
         *
         * Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsRegion?: Array<string>;
        /**
         * eventCategory property
         *
         * Specify an array of string values to match this event if the actual value of eventCategory is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategory?: Array<string>;
        /**
         * responseElements property
         *
         * Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly responseElements?: Array<string>;
        /**
         * sourceIPAddress property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * eventSource property
         *
         * Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventSource?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * eventVersion property
         *
         * Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventVersion?: Array<string>;
        /**
         * managementEvent property
         *
         * Specify an array of string values to match this event if the actual value of managementEvent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly managementEvent?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * resources property
         *
         * Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resources?: Array<AWSAPICallViaCloudTrail.AwsapiCallViaCloudTrailItem>;
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * readOnly property
         *
         * Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly readOnly?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * vpcEndpointId property
         *
         * Specify an array of string values to match this event if the actual value of vpcEndpointId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcEndpointId?: Array<string>;
        /**
         * requestID property
         *
         * Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * recipientAccountId property
         *
         * Specify an array of string values to match this event if the actual value of recipientAccountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly recipientAccountId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for RequestParameters
     *
     * @struct
     */
    interface RequestParameters {
        /**
         * bucketName property
         *
         * Specify an array of string values to match this event if the actual value of bucketName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Bucket reference
         */
        readonly bucketName?: Array<string>;
        /**
         * legal-hold property
         *
         * Specify an array of string values to match this event if the actual value of legal-hold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly legalHold?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * retention property
         *
         * Specify an array of string values to match this event if the actual value of retention is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly retention?: Array<string>;
        /**
         * Host property
         *
         * Specify an array of string values to match this event if the actual value of Host is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly host?: Array<string>;
    }
    /**
     * Type definition for TlsDetails
     *
     * @struct
     */
    interface TlsDetails {
        /**
         * cipherSuite property
         *
         * Specify an array of string values to match this event if the actual value of cipherSuite is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cipherSuite?: Array<string>;
        /**
         * clientProvidedHostHeader property
         *
         * Specify an array of string values to match this event if the actual value of clientProvidedHostHeader is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientProvidedHostHeader?: Array<string>;
        /**
         * tlsVersion property
         *
         * Specify an array of string values to match this event if the actual value of tlsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tlsVersion?: Array<string>;
    }
    /**
     * Type definition for UserIdentity
     *
     * @struct
     */
    interface UserIdentity {
        /**
         * sessionContext property
         *
         * Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionContext?: AWSAPICallViaCloudTrail.SessionContext;
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
    }
    /**
     * Type definition for SessionContext
     *
     * @struct
     */
    interface SessionContext {
        /**
         * attributes property
         *
         * Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attributes?: AWSAPICallViaCloudTrail.Attributes;
        /**
         * sessionIssuer property
         *
         * Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionIssuer?: AWSAPICallViaCloudTrail.SessionIssuer;
        /**
         * webIdFederationData property
         *
         * Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly webIdFederationData?: Array<string>;
    }
    /**
     * Type definition for Attributes
     *
     * @struct
     */
    interface Attributes {
        /**
         * mfaAuthenticated property
         *
         * Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mfaAuthenticated?: Array<string>;
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
    }
    /**
     * Type definition for SessionIssuer
     *
     * @struct
     */
    interface SessionIssuer {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * userName property
         *
         * Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userName?: Array<string>;
    }
    /**
     * Type definition for AdditionalEventData
     *
     * @struct
     */
    interface AdditionalEventData {
        /**
         * objectRetentionInfo property
         *
         * Specify an array of string values to match this event if the actual value of objectRetentionInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectRetentionInfo?: AWSAPICallViaCloudTrail.ObjectRetentionInfo;
        /**
         * x-amz-id-2 property
         *
         * Specify an array of string values to match this event if the actual value of x-amz-id-2 is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly xAmzId2?: Array<string>;
        /**
         * AuthenticationMethod property
         *
         * Specify an array of string values to match this event if the actual value of AuthenticationMethod is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly authenticationMethod?: Array<string>;
        /**
         * CipherSuite property
         *
         * Specify an array of string values to match this event if the actual value of CipherSuite is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cipherSuite?: Array<string>;
        /**
         * SignatureVersion property
         *
         * Specify an array of string values to match this event if the actual value of SignatureVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly signatureVersion?: Array<string>;
        /**
         * bytesTransferredIn property
         *
         * Specify an array of string values to match this event if the actual value of bytesTransferredIn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytesTransferredIn?: Array<string>;
        /**
         * bytesTransferredOut property
         *
         * Specify an array of string values to match this event if the actual value of bytesTransferredOut is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytesTransferredOut?: Array<string>;
    }
    /**
     * Type definition for ObjectRetentionInfo
     *
     * @struct
     */
    interface ObjectRetentionInfo {
        /**
         * legalHoldInfo property
         *
         * Specify an array of string values to match this event if the actual value of legalHoldInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly legalHoldInfo?: AWSAPICallViaCloudTrail.LegalHoldInfo;
        /**
         * retentionInfo property
         *
         * Specify an array of string values to match this event if the actual value of retentionInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly retentionInfo?: AWSAPICallViaCloudTrail.RetentionInfo;
    }
    /**
     * Type definition for LegalHoldInfo
     *
     * @struct
     */
    interface LegalHoldInfo {
        /**
         * lastModifiedTime property
         *
         * Specify an array of string values to match this event if the actual value of lastModifiedTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastModifiedTime?: Array<string>;
        /**
         * isUnderLegalHold property
         *
         * Specify an array of string values to match this event if the actual value of isUnderLegalHold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly isUnderLegalHold?: Array<string>;
    }
    /**
     * Type definition for RetentionInfo
     *
     * @struct
     */
    interface RetentionInfo {
        /**
         * lastModifiedTime property
         *
         * Specify an array of string values to match this event if the actual value of lastModifiedTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastModifiedTime?: Array<string>;
        /**
         * retainUntilTime property
         *
         * Specify an array of string values to match this event if the actual value of retainUntilTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly retainUntilTime?: Array<string>;
        /**
         * retainUntilMode property
         *
         * Specify an array of string values to match this event if the actual value of retainUntilMode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly retainUntilMode?: Array<string>;
    }
    /**
     * Type definition for AWSAPICallViaCloudTrailItem
     *
     * @struct
     */
    interface AwsapiCallViaCloudTrailItem {
        /**
         * ARN property
         *
         * Specify an array of string values to match this event if the actual value of ARN is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
}
/**
 * EventBridge event patterns for Bucket
 */
export declare class BucketEvents {
    /**
     * Create BucketEvents from a Bucket reference
     */
    static fromBucket(bucketRef: service.IBucketRef): BucketEvents;
    /**
     * Reference to the Bucket construct
     */
    private readonly bucketRef;
    private constructor();
    /**
     * EventBridge event pattern for Bucket AWS API Call via CloudTrail
     */
    awsAPICallViaCloudTrailPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
    /**
     * EventBridge event pattern for Bucket Object Access Tier Changed
     */
    objectAccessTierChangedPattern(options?: ObjectAccessTierChanged.ObjectAccessTierChangedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Bucket Object ACL Updated
     */
    objectACLUpdatedPattern(options?: ObjectACLUpdated.ObjectACLUpdatedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Bucket Object Created
     */
    objectCreatedPattern(options?: ObjectCreated.ObjectCreatedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Bucket Object Deleted
     */
    objectDeletedPattern(options?: ObjectDeleted.ObjectDeletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Bucket Object Restore Completed
     */
    objectRestoreCompletedPattern(options?: ObjectRestoreCompleted.ObjectRestoreCompletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Bucket Object Restore Expired
     */
    objectRestoreExpiredPattern(options?: ObjectRestoreExpired.ObjectRestoreExpiredProps): events.EventPattern;
    /**
     * EventBridge event pattern for Bucket Object Restore Initiated
     */
    objectRestoreInitiatedPattern(options?: ObjectRestoreInitiated.ObjectRestoreInitiatedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Bucket Object Storage Class Changed
     */
    objectStorageClassChangedPattern(options?: ObjectStorageClassChanged.ObjectStorageClassChangedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Bucket Object Tags Added
     */
    objectTagsAddedPattern(options?: ObjectTagsAdded.ObjectTagsAddedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Bucket Object Tags Deleted
     */
    objectTagsDeletedPattern(options?: ObjectTagsDeleted.ObjectTagsDeletedProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.s3@ObjectAccessTierChanged
 */
export declare class ObjectAccessTierChanged {
    /**
     * EventBridge event pattern for Object Access Tier Changed
     */
    static eventPattern(options?: ObjectAccessTierChanged.ObjectAccessTierChangedProps): events.EventPattern;
}
export declare namespace ObjectAccessTierChanged {
    /**
     * Props type for aws.s3@ObjectAccessTierChanged event
     */
    interface ObjectAccessTierChangedProps {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: ObjectAccessTierChanged.Bucket;
        /**
         * object property
         *
         * Specify an array of string values to match this event if the actual value of object is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly object?: ObjectAccessTierChanged.ObjectType;
        /**
         * destination-access-tier property
         *
         * Specify an array of string values to match this event if the actual value of destination-access-tier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destinationAccessTier?: Array<string>;
        /**
         * request-id property
         *
         * Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * requester property
         *
         * Specify an array of string values to match this event if the actual value of requester is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requester?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Bucket
     *
     * @struct
     */
    interface Bucket {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Bucket reference
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Object
     *
     * @struct
     */
    interface ObjectType {
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * size property
         *
         * Specify an array of string values to match this event if the actual value of size is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly size?: Array<string>;
        /**
         * version-id property
         *
         * Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.s3@ObjectACLUpdated
 */
export declare class ObjectACLUpdated {
    /**
     * EventBridge event pattern for Object ACL Updated
     */
    static eventPattern(options?: ObjectACLUpdated.ObjectACLUpdatedProps): events.EventPattern;
}
export declare namespace ObjectACLUpdated {
    /**
     * Props type for aws.s3@ObjectACLUpdated event
     */
    interface ObjectACLUpdatedProps {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: ObjectACLUpdated.Bucket;
        /**
         * object property
         *
         * Specify an array of string values to match this event if the actual value of object is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly object?: ObjectACLUpdated.ObjectType;
        /**
         * request-id property
         *
         * Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * requester property
         *
         * Specify an array of string values to match this event if the actual value of requester is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requester?: Array<string>;
        /**
         * source-ip-address property
         *
         * Specify an array of string values to match this event if the actual value of source-ip-address is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Bucket
     *
     * @struct
     */
    interface Bucket {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Bucket reference
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Object
     *
     * @struct
     */
    interface ObjectType {
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * version-id property
         *
         * Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.s3@ObjectCreated
 */
export declare class ObjectCreated {
    /**
     * EventBridge event pattern for Object Created
     */
    static eventPattern(options?: ObjectCreated.ObjectCreatedProps): events.EventPattern;
}
export declare namespace ObjectCreated {
    /**
     * Props type for aws.s3@ObjectCreated event
     */
    interface ObjectCreatedProps {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: ObjectCreated.Bucket;
        /**
         * object property
         *
         * Specify an array of string values to match this event if the actual value of object is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly object?: ObjectCreated.ObjectType;
        /**
         * reason property
         *
         * Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reason?: Array<string>;
        /**
         * request-id property
         *
         * Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * requester property
         *
         * Specify an array of string values to match this event if the actual value of requester is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requester?: Array<string>;
        /**
         * source-ip-address property
         *
         * Specify an array of string values to match this event if the actual value of source-ip-address is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Bucket
     *
     * @struct
     */
    interface Bucket {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Bucket reference
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Object
     *
     * @struct
     */
    interface ObjectType {
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * sequencer property
         *
         * Specify an array of string values to match this event if the actual value of sequencer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sequencer?: Array<string>;
        /**
         * size property
         *
         * Specify an array of string values to match this event if the actual value of size is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly size?: Array<string>;
        /**
         * version-id property
         *
         * Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.s3@ObjectDeleted
 */
export declare class ObjectDeleted {
    /**
     * EventBridge event pattern for Object Deleted
     */
    static eventPattern(options?: ObjectDeleted.ObjectDeletedProps): events.EventPattern;
}
export declare namespace ObjectDeleted {
    /**
     * Props type for aws.s3@ObjectDeleted event
     */
    interface ObjectDeletedProps {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: ObjectDeleted.Bucket;
        /**
         * object property
         *
         * Specify an array of string values to match this event if the actual value of object is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly object?: ObjectDeleted.ObjectType;
        /**
         * deletion-type property
         *
         * Specify an array of string values to match this event if the actual value of deletion-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deletionType?: Array<string>;
        /**
         * reason property
         *
         * Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reason?: Array<string>;
        /**
         * request-id property
         *
         * Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * requester property
         *
         * Specify an array of string values to match this event if the actual value of requester is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requester?: Array<string>;
        /**
         * source-ip-address property
         *
         * Specify an array of string values to match this event if the actual value of source-ip-address is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Bucket
     *
     * @struct
     */
    interface Bucket {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Bucket reference
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Object
     *
     * @struct
     */
    interface ObjectType {
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * sequencer property
         *
         * Specify an array of string values to match this event if the actual value of sequencer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sequencer?: Array<string>;
        /**
         * version-id property
         *
         * Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.s3@ObjectRestoreCompleted
 */
export declare class ObjectRestoreCompleted {
    /**
     * EventBridge event pattern for Object Restore Completed
     */
    static eventPattern(options?: ObjectRestoreCompleted.ObjectRestoreCompletedProps): events.EventPattern;
}
export declare namespace ObjectRestoreCompleted {
    /**
     * Props type for aws.s3@ObjectRestoreCompleted event
     */
    interface ObjectRestoreCompletedProps {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: ObjectRestoreCompleted.Bucket;
        /**
         * object property
         *
         * Specify an array of string values to match this event if the actual value of object is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly object?: ObjectRestoreCompleted.ObjectType;
        /**
         * request-id property
         *
         * Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * requester property
         *
         * Specify an array of string values to match this event if the actual value of requester is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requester?: Array<string>;
        /**
         * restore-expiry-time property
         *
         * Specify an array of string values to match this event if the actual value of restore-expiry-time is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly restoreExpiryTime?: Array<string>;
        /**
         * source-storage-class property
         *
         * Specify an array of string values to match this event if the actual value of source-storage-class is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceStorageClass?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Bucket
     *
     * @struct
     */
    interface Bucket {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Bucket reference
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Object
     *
     * @struct
     */
    interface ObjectType {
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * size property
         *
         * Specify an array of string values to match this event if the actual value of size is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly size?: Array<string>;
        /**
         * version-id property
         *
         * Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.s3@ObjectRestoreExpired
 */
export declare class ObjectRestoreExpired {
    /**
     * EventBridge event pattern for Object Restore Expired
     */
    static eventPattern(options?: ObjectRestoreExpired.ObjectRestoreExpiredProps): events.EventPattern;
}
export declare namespace ObjectRestoreExpired {
    /**
     * Props type for aws.s3@ObjectRestoreExpired event
     */
    interface ObjectRestoreExpiredProps {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: ObjectRestoreExpired.Bucket;
        /**
         * object property
         *
         * Specify an array of string values to match this event if the actual value of object is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly object?: ObjectRestoreExpired.ObjectType;
        /**
         * request-id property
         *
         * Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * requester property
         *
         * Specify an array of string values to match this event if the actual value of requester is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requester?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Bucket
     *
     * @struct
     */
    interface Bucket {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Bucket reference
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Object
     *
     * @struct
     */
    interface ObjectType {
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * version-id property
         *
         * Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.s3@ObjectRestoreInitiated
 */
export declare class ObjectRestoreInitiated {
    /**
     * EventBridge event pattern for Object Restore Initiated
     */
    static eventPattern(options?: ObjectRestoreInitiated.ObjectRestoreInitiatedProps): events.EventPattern;
}
export declare namespace ObjectRestoreInitiated {
    /**
     * Props type for aws.s3@ObjectRestoreInitiated event
     */
    interface ObjectRestoreInitiatedProps {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: ObjectRestoreInitiated.Bucket;
        /**
         * object property
         *
         * Specify an array of string values to match this event if the actual value of object is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly object?: ObjectRestoreInitiated.ObjectType;
        /**
         * request-id property
         *
         * Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * requester property
         *
         * Specify an array of string values to match this event if the actual value of requester is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requester?: Array<string>;
        /**
         * source-ip-address property
         *
         * Specify an array of string values to match this event if the actual value of source-ip-address is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * source-storage-class property
         *
         * Specify an array of string values to match this event if the actual value of source-storage-class is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceStorageClass?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Bucket
     *
     * @struct
     */
    interface Bucket {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Bucket reference
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Object
     *
     * @struct
     */
    interface ObjectType {
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * size property
         *
         * Specify an array of string values to match this event if the actual value of size is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly size?: Array<string>;
        /**
         * version-id property
         *
         * Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.s3@ObjectStorageClassChanged
 */
export declare class ObjectStorageClassChanged {
    /**
     * EventBridge event pattern for Object Storage Class Changed
     */
    static eventPattern(options?: ObjectStorageClassChanged.ObjectStorageClassChangedProps): events.EventPattern;
}
export declare namespace ObjectStorageClassChanged {
    /**
     * Props type for aws.s3@ObjectStorageClassChanged event
     */
    interface ObjectStorageClassChangedProps {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: ObjectStorageClassChanged.Bucket;
        /**
         * object property
         *
         * Specify an array of string values to match this event if the actual value of object is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly object?: ObjectStorageClassChanged.ObjectType;
        /**
         * destination-storage-class property
         *
         * Specify an array of string values to match this event if the actual value of destination-storage-class is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destinationStorageClass?: Array<string>;
        /**
         * request-id property
         *
         * Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * requester property
         *
         * Specify an array of string values to match this event if the actual value of requester is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requester?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Bucket
     *
     * @struct
     */
    interface Bucket {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Bucket reference
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Object
     *
     * @struct
     */
    interface ObjectType {
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * size property
         *
         * Specify an array of string values to match this event if the actual value of size is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly size?: Array<string>;
        /**
         * version-id property
         *
         * Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.s3@ObjectTagsAdded
 */
export declare class ObjectTagsAdded {
    /**
     * EventBridge event pattern for Object Tags Added
     */
    static eventPattern(options?: ObjectTagsAdded.ObjectTagsAddedProps): events.EventPattern;
}
export declare namespace ObjectTagsAdded {
    /**
     * Props type for aws.s3@ObjectTagsAdded event
     */
    interface ObjectTagsAddedProps {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: ObjectTagsAdded.Bucket;
        /**
         * object property
         *
         * Specify an array of string values to match this event if the actual value of object is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly object?: ObjectTagsAdded.ObjectType;
        /**
         * request-id property
         *
         * Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * requester property
         *
         * Specify an array of string values to match this event if the actual value of requester is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requester?: Array<string>;
        /**
         * source-ip-address property
         *
         * Specify an array of string values to match this event if the actual value of source-ip-address is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Bucket
     *
     * @struct
     */
    interface Bucket {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Bucket reference
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Object
     *
     * @struct
     */
    interface ObjectType {
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * version-id property
         *
         * Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.s3@ObjectTagsDeleted
 */
export declare class ObjectTagsDeleted {
    /**
     * EventBridge event pattern for Object Tags Deleted
     */
    static eventPattern(options?: ObjectTagsDeleted.ObjectTagsDeletedProps): events.EventPattern;
}
export declare namespace ObjectTagsDeleted {
    /**
     * Props type for aws.s3@ObjectTagsDeleted event
     */
    interface ObjectTagsDeletedProps {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: ObjectTagsDeleted.Bucket;
        /**
         * object property
         *
         * Specify an array of string values to match this event if the actual value of object is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly object?: ObjectTagsDeleted.ObjectType;
        /**
         * request-id property
         *
         * Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * requester property
         *
         * Specify an array of string values to match this event if the actual value of requester is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requester?: Array<string>;
        /**
         * source-ip-address property
         *
         * Specify an array of string values to match this event if the actual value of source-ip-address is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Bucket
     *
     * @struct
     */
    interface Bucket {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Bucket reference
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for Object
     *
     * @struct
     */
    interface ObjectType {
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * version-id property
         *
         * Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
    }
}
