import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-route53resolver";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.route53resolver@DNSFirewallAlert
 */
export declare class DNSFirewallAlert {
    /**
     * EventBridge event pattern for DNS Firewall Alert
     */
    static eventPattern(options?: DNSFirewallAlert.DNSFirewallAlertProps): events.EventPattern;
}
export declare namespace DNSFirewallAlert {
    /**
     * Props type for aws.route53resolver@DNSFirewallAlert event
     */
    interface DNSFirewallAlertProps {
        /**
         * account-id property
         *
         * Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * firewall-domain-list-id property
         *
         * Specify an array of string values to match this event if the actual value of firewall-domain-list-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the FirewallDomainList reference
         */
        readonly firewallDomainListId?: Array<string>;
        /**
         * firewall-rule-action property
         *
         * Specify an array of string values to match this event if the actual value of firewall-rule-action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly firewallRuleAction?: Array<string>;
        /**
         * firewall-rule-group-id property
         *
         * Specify an array of string values to match this event if the actual value of firewall-rule-group-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly firewallRuleGroupId?: Array<string>;
        /**
         * last-observed-at property
         *
         * Specify an array of string values to match this event if the actual value of last-observed-at is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastObservedAt?: Array<string>;
        /**
         * query-class property
         *
         * Specify an array of string values to match this event if the actual value of query-class is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queryClass?: Array<string>;
        /**
         * query-name property
         *
         * Specify an array of string values to match this event if the actual value of query-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queryName?: Array<string>;
        /**
         * query-type property
         *
         * Specify an array of string values to match this event if the actual value of query-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queryType?: Array<string>;
        /**
         * resources property
         *
         * Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resources?: Array<DNSFirewallAlert.DnsFirewallAlertItem>;
        /**
         * src-addr property
         *
         * Specify an array of string values to match this event if the actual value of src-addr is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly srcAddr?: Array<string>;
        /**
         * src-port property
         *
         * Specify an array of string values to match this event if the actual value of src-port is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly srcPort?: Array<string>;
        /**
         * transport property
         *
         * Specify an array of string values to match this event if the actual value of transport is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transport?: Array<string>;
        /**
         * vpc-id property
         *
         * Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for DNSFirewallAlertItem
     *
     * @struct
     */
    interface DnsFirewallAlertItem {
        /**
         * resolver-endpoint-details property
         *
         * Specify an array of string values to match this event if the actual value of resolver-endpoint-details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resolverEndpointDetails?: DNSFirewallAlert.ResolverEndpointDetails;
        /**
         * resolver-network-interface-details property
         *
         * Specify an array of string values to match this event if the actual value of resolver-network-interface-details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resolverNetworkInterfaceDetails?: DNSFirewallAlert.ResolverNetworkInterfaceDetails;
        /**
         * resource-type property
         *
         * Specify an array of string values to match this event if the actual value of resource-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceType?: Array<string>;
    }
    /**
     * Type definition for Resolver-endpoint-details
     *
     * @struct
     */
    interface ResolverEndpointDetails {
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
    }
    /**
     * Type definition for Resolver-network-interface-details
     *
     * @struct
     */
    interface ResolverNetworkInterfaceDetails {
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
    }
}
/**
 * EventBridge event patterns for FirewallDomainList
 */
export declare class FirewallDomainListEvents {
    /**
     * Create FirewallDomainListEvents from a FirewallDomainList reference
     */
    static fromFirewallDomainList(firewallDomainListRef: service.IFirewallDomainListRef): FirewallDomainListEvents;
    /**
     * Reference to the FirewallDomainList construct
     */
    private readonly firewallDomainListRef;
    private constructor();
    /**
     * EventBridge event pattern for FirewallDomainList DNS Firewall Alert
     */
    dnsFirewallAlertPattern(options?: DNSFirewallAlert.DNSFirewallAlertProps): events.EventPattern;
    /**
     * EventBridge event pattern for FirewallDomainList DNS Firewall Block
     */
    dnsFirewallBlockPattern(options?: DNSFirewallBlock.DNSFirewallBlockProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.route53resolver@DNSFirewallBlock
 */
export declare class DNSFirewallBlock {
    /**
     * EventBridge event pattern for DNS Firewall Block
     */
    static eventPattern(options?: DNSFirewallBlock.DNSFirewallBlockProps): events.EventPattern;
}
export declare namespace DNSFirewallBlock {
    /**
     * Props type for aws.route53resolver@DNSFirewallBlock event
     */
    interface DNSFirewallBlockProps {
        /**
         * account-id property
         *
         * Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * firewall-domain-list-id property
         *
         * Specify an array of string values to match this event if the actual value of firewall-domain-list-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the FirewallDomainList reference
         */
        readonly firewallDomainListId?: Array<string>;
        /**
         * firewall-rule-action property
         *
         * Specify an array of string values to match this event if the actual value of firewall-rule-action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly firewallRuleAction?: Array<string>;
        /**
         * firewall-rule-group-id property
         *
         * Specify an array of string values to match this event if the actual value of firewall-rule-group-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly firewallRuleGroupId?: Array<string>;
        /**
         * last-observed-at property
         *
         * Specify an array of string values to match this event if the actual value of last-observed-at is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastObservedAt?: Array<string>;
        /**
         * query-class property
         *
         * Specify an array of string values to match this event if the actual value of query-class is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queryClass?: Array<string>;
        /**
         * query-name property
         *
         * Specify an array of string values to match this event if the actual value of query-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queryName?: Array<string>;
        /**
         * query-type property
         *
         * Specify an array of string values to match this event if the actual value of query-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queryType?: Array<string>;
        /**
         * resources property
         *
         * Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resources?: Array<DNSFirewallBlock.DnsFirewallBlockItem>;
        /**
         * src-addr property
         *
         * Specify an array of string values to match this event if the actual value of src-addr is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly srcAddr?: Array<string>;
        /**
         * src-port property
         *
         * Specify an array of string values to match this event if the actual value of src-port is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly srcPort?: Array<string>;
        /**
         * transport property
         *
         * Specify an array of string values to match this event if the actual value of transport is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transport?: Array<string>;
        /**
         * vpc-id property
         *
         * Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for DNSFirewallBlockItem
     *
     * @struct
     */
    interface DnsFirewallBlockItem {
        /**
         * resolver-endpoint-details property
         *
         * Specify an array of string values to match this event if the actual value of resolver-endpoint-details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resolverEndpointDetails?: DNSFirewallBlock.ResolverEndpointDetails;
        /**
         * resolver-network-interface-details property
         *
         * Specify an array of string values to match this event if the actual value of resolver-network-interface-details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resolverNetworkInterfaceDetails?: DNSFirewallBlock.ResolverNetworkInterfaceDetails;
        /**
         * resource-type property
         *
         * Specify an array of string values to match this event if the actual value of resource-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceType?: Array<string>;
    }
    /**
     * Type definition for Resolver-endpoint-details
     *
     * @struct
     */
    interface ResolverEndpointDetails {
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
    }
    /**
     * Type definition for Resolver-network-interface-details
     *
     * @struct
     */
    interface ResolverNetworkInterfaceDetails {
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
    }
}
