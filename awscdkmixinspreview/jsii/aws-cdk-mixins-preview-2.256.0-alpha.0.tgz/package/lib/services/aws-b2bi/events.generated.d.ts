import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.b2bi@AcknowledgementCompleted
 */
export declare class AcknowledgementCompleted {
    /**
     * EventBridge event pattern for Acknowledgement Completed
     */
    static eventPattern(options?: AcknowledgementCompleted.AcknowledgementCompletedProps): events.EventPattern;
}
export declare namespace AcknowledgementCompleted {
    /**
     * Props type for aws.b2bi@AcknowledgementCompleted event
     */
    interface AcknowledgementCompletedProps {
        /**
         * ack-file-s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of ack-file-s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ackFileS3Attributes?: AcknowledgementCompleted.AckFileS3Attributes;
        /**
         * input-file-s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputFileS3Attributes?: AcknowledgementCompleted.InputFileS3Attributes;
        /**
         * ack-error-code-detected property
         *
         * Specify an array of string values to match this event if the actual value of ack-error-code-detected is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ackErrorCodeDetected?: Array<string>;
        /**
         * ack-x12-type property
         *
         * Specify an array of string values to match this event if the actual value of ack-x12-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ackX12Type?: Array<string>;
        /**
         * ack-x12-version property
         *
         * Specify an array of string values to match this event if the actual value of ack-x12-version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ackX12Version?: Array<string>;
        /**
         * input-x12-transaction-set property
         *
         * Specify an array of string values to match this event if the actual value of input-x12-transaction-set is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputX12TransactionSet?: Array<string>;
        /**
         * input-x12-version property
         *
         * Specify an array of string values to match this event if the actual value of input-x12-version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputX12Version?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * trading-partner-id property
         *
         * Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tradingPartnerId?: Array<string>;
        /**
         * transformer-job-id property
         *
         * Specify an array of string values to match this event if the actual value of transformer-job-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformerJobId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Ack-file-s3-attributes
     *
     * @struct
     */
    interface AckFileS3Attributes {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: Array<string>;
        /**
         * object-key property
         *
         * Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectKey?: Array<string>;
        /**
         * object-size-bytes property
         *
         * Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectSizeBytes?: Array<string>;
    }
    /**
     * Type definition for Input-file-s3-attributes
     *
     * @struct
     */
    interface InputFileS3Attributes {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: Array<string>;
        /**
         * object-key property
         *
         * Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectKey?: Array<string>;
        /**
         * object-size-bytes property
         *
         * Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectSizeBytes?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.b2bi@AcknowledgementFailed
 */
export declare class AcknowledgementFailed {
    /**
     * EventBridge event pattern for Acknowledgement Failed
     */
    static eventPattern(options?: AcknowledgementFailed.AcknowledgementFailedProps): events.EventPattern;
}
export declare namespace AcknowledgementFailed {
    /**
     * Props type for aws.b2bi@AcknowledgementFailed event
     */
    interface AcknowledgementFailedProps {
        /**
         * input-file-s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputFileS3Attributes?: AcknowledgementFailed.InputFileS3Attributes;
        /**
         * ack-x12-type property
         *
         * Specify an array of string values to match this event if the actual value of ack-x12-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ackX12Type?: Array<string>;
        /**
         * ack-x12-version property
         *
         * Specify an array of string values to match this event if the actual value of ack-x12-version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ackX12Version?: Array<string>;
        /**
         * input-x12-transaction-set property
         *
         * Specify an array of string values to match this event if the actual value of input-x12-transaction-set is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputX12TransactionSet?: Array<string>;
        /**
         * input-x12-version property
         *
         * Specify an array of string values to match this event if the actual value of input-x12-version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputX12Version?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * trading-partner-id property
         *
         * Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tradingPartnerId?: Array<string>;
        /**
         * transformer-job-id property
         *
         * Specify an array of string values to match this event if the actual value of transformer-job-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transformerJobId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Input-file-s3-attributes
     *
     * @struct
     */
    interface InputFileS3Attributes {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: Array<string>;
        /**
         * object-key property
         *
         * Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectKey?: Array<string>;
        /**
         * object-size-bytes property
         *
         * Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectSizeBytes?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.b2bi@TransformationCompleted
 */
export declare class TransformationCompleted {
    /**
     * EventBridge event pattern for Transformation Completed
     */
    static eventPattern(options?: TransformationCompleted.TransformationCompletedProps): events.EventPattern;
}
export declare namespace TransformationCompleted {
    /**
     * Props type for aws.b2bi@TransformationCompleted event
     */
    interface TransformationCompletedProps {
        /**
         * input-file-s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputFileS3Attributes?: TransformationCompleted.InputFileS3Attributes;
        /**
         * output-file-s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of output-file-s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputFileS3Attributes?: TransformationCompleted.OutputFileS3Attributes;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * trading-partner-id property
         *
         * Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tradingPartnerId?: Array<string>;
        /**
         * x12-transaction-set property
         *
         * Specify an array of string values to match this event if the actual value of x12-transaction-set is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly x12TransactionSet?: Array<string>;
        /**
         * x12-version property
         *
         * Specify an array of string values to match this event if the actual value of x12-version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly x12Version?: Array<string>;
        /**
         * ack-error-code-detected property
         *
         * Specify an array of string values to match this event if the actual value of ack-error-code-detected is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ackErrorCodeDetected?: Array<string>;
        /**
         * ack-generation-status property
         *
         * Specify an array of string values to match this event if the actual value of ack-generation-status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ackGenerationStatus?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Input-file-s3-attributes
     *
     * @struct
     */
    interface InputFileS3Attributes {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: Array<string>;
        /**
         * object-key property
         *
         * Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectKey?: Array<string>;
        /**
         * object-size-bytes property
         *
         * Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectSizeBytes?: Array<string>;
    }
    /**
     * Type definition for Output-file-s3-attributes
     *
     * @struct
     */
    interface OutputFileS3Attributes {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: Array<string>;
        /**
         * object-key property
         *
         * Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectKey?: Array<string>;
        /**
         * object-size-bytes property
         *
         * Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectSizeBytes?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.b2bi@TransformationFailed
 */
export declare class TransformationFailed {
    /**
     * EventBridge event pattern for Transformation Failed
     */
    static eventPattern(options?: TransformationFailed.TransformationFailedProps): events.EventPattern;
}
export declare namespace TransformationFailed {
    /**
     * Props type for aws.b2bi@TransformationFailed event
     */
    interface TransformationFailedProps {
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * trading-partner-id property
         *
         * Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tradingPartnerId?: Array<string>;
        /**
         * x12-transaction-set property
         *
         * Specify an array of string values to match this event if the actual value of x12-transaction-set is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly x12TransactionSet?: Array<string>;
        /**
         * x12-version property
         *
         * Specify an array of string values to match this event if the actual value of x12-version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly x12Version?: Array<string>;
        /**
         * input-file-s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputFileS3Attributes?: TransformationFailed.InputFileS3Attributes;
        /**
         * ack-error-code-detected property
         *
         * Specify an array of string values to match this event if the actual value of ack-error-code-detected is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ackErrorCodeDetected?: Array<string>;
        /**
         * ack-generation-status property
         *
         * Specify an array of string values to match this event if the actual value of ack-generation-status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ackGenerationStatus?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Input-file-s3-attributes
     *
     * @struct
     */
    interface InputFileS3Attributes {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: Array<string>;
        /**
         * object-key property
         *
         * Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectKey?: Array<string>;
        /**
         * object-size-bytes property
         *
         * Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectSizeBytes?: Array<string>;
    }
}
