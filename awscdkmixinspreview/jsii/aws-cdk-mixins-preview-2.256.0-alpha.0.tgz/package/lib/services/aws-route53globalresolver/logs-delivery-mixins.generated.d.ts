import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-route53globalresolver";
/**
 * Builder for CfnGlobalResolverLogsMixin to generate GLOBAL_RESOLVER_LOGS for CfnGlobalResolver
 *
 * @cloudformationResource AWS::Route53GlobalResolver::GlobalResolver
 * @logType GLOBAL_RESOLVER_LOGS
 * @stability external
 */
export declare class CfnGlobalResolverGlobalResolverLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnGlobalResolverGlobalResolverLogsS3Props): CfnGlobalResolverLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnGlobalResolverGlobalResolverLogsLogGroupProps): CfnGlobalResolverLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnGlobalResolverGlobalResolverLogsFirehoseProps): CfnGlobalResolverLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnGlobalResolverGlobalResolverLogsDestProps): CfnGlobalResolverLogsMixin;
}
/**
 * Resource schema for AWS::Route53GlobalResolver::GlobalResolver.
 *
 * @cloudformationResource AWS::Route53GlobalResolver::GlobalResolver
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-route53globalresolver-globalresolver.html
 */
export declare class CfnGlobalResolverLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly GLOBAL_RESOLVER_LOGS: CfnGlobalResolverGlobalResolverLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::Route53GlobalResolver::GlobalResolver`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnGlobalResolver;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnGlobalResolverGlobalResolverLogs.
 */
export declare class CfnGlobalResolverGlobalResolverLogsOutputFormat {
}
export declare namespace CfnGlobalResolverGlobalResolverLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnGlobalResolverGlobalResolverLogsRecordFields {
    ACTION_NAME = "action_name",
    ACTIVITY_NAME = "activity_name",
    ANSWERS = "answers",
    CATEGORY_NAME = "category_name",
    CLASS_NAME = "class_name",
    CONNECTION_INFO = "connection_info",
    DISPOSITION = "disposition",
    DISPOSITION_ID = "disposition_id",
    DURATION = "duration",
    END_TIME = "end_time",
    ENRICHMENTS = "enrichments",
    MESSAGE = "message",
    QUERY = "query",
    QUERY_TIME = "query_time",
    RCODE = "rcode",
    RCODE_ID = "rcode_id",
    RESPONSE_TIME = "response_time",
    SEVERITY = "severity",
    START_TIME = "start_time",
    STATUS = "status",
    STATUS_ID = "status_id",
    TYPE_NAME = "type_name",
    ACTION_ID = "action_id",
    ACTIVITY_ID = "activity_id",
    CATEGORY_UID = "category_uid",
    CLASS_UID = "class_uid",
    CLOUD = "cloud",
    METADATA = "metadata",
    SEVERITY_ID = "severity_id",
    SRC_ENDPOINT = "src_endpoint",
    TIME = "time",
    TYPE_UID = "type_uid"
}
export interface CfnGlobalResolverGlobalResolverLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnGlobalResolverGlobalResolverLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGlobalResolverGlobalResolverLogsRecordFields>;
}
export interface CfnGlobalResolverGlobalResolverLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnGlobalResolverGlobalResolverLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGlobalResolverGlobalResolverLogsRecordFields>;
}
export interface CfnGlobalResolverGlobalResolverLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnGlobalResolverGlobalResolverLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGlobalResolverGlobalResolverLogsRecordFields>;
}
export interface CfnGlobalResolverGlobalResolverLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGlobalResolverGlobalResolverLogsRecordFields>;
}
