import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.chime@ChimeVoiceConnectorStreamingStatus
 */
export declare class ChimeVoiceConnectorStreamingStatus {
    /**
     * EventBridge event pattern for Chime VoiceConnector Streaming Status
     */
    static eventPattern(options?: ChimeVoiceConnectorStreamingStatus.ChimeVoiceConnectorStreamingStatusProps): events.EventPattern;
}
export declare namespace ChimeVoiceConnectorStreamingStatus {
    /**
     * Props type for aws.chime@ChimeVoiceConnectorStreamingStatus event
     */
    interface ChimeVoiceConnectorStreamingStatusProps {
        /**
         * callId property
         *
         * Specify an array of string values to match this event if the actual value of callId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly callId?: Array<string>;
        /**
         * direction property
         *
         * Specify an array of string values to match this event if the actual value of direction is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly direction?: Array<string>;
        /**
         * mediaType property
         *
         * Specify an array of string values to match this event if the actual value of mediaType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mediaType?: Array<string>;
        /**
         * startFragmentNumber property
         *
         * Specify an array of string values to match this event if the actual value of startFragmentNumber is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startFragmentNumber?: Array<string>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * streamArn property
         *
         * Specify an array of string values to match this event if the actual value of streamArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly streamArn?: Array<string>;
        /**
         * streamingStatus property
         *
         * Specify an array of string values to match this event if the actual value of streamingStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly streamingStatus?: Array<string>;
        /**
         * transactionId property
         *
         * Specify an array of string values to match this event if the actual value of transactionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transactionId?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * voiceConnectorId property
         *
         * Specify an array of string values to match this event if the actual value of voiceConnectorId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly voiceConnectorId?: Array<string>;
        /**
         * inviteHeaders property
         *
         * Specify an array of string values to match this event if the actual value of inviteHeaders is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inviteHeaders?: Record<string, string>;
        /**
         * siprecMetadata property
         *
         * Specify an array of string values to match this event if the actual value of siprecMetadata is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly siprecMetadata?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
