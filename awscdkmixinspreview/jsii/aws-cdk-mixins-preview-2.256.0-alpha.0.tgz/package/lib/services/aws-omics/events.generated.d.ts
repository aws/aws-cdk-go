import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-omics";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.omics@AnnotationImportJobStatusChange
 */
export declare class AnnotationImportJobStatusChange {
    /**
     * EventBridge event pattern for Annotation Import Job Status Change
     */
    static eventPattern(options?: AnnotationImportJobStatusChange.AnnotationImportJobStatusChangeProps): events.EventPattern;
}
export declare namespace AnnotationImportJobStatusChange {
    /**
     * Props type for aws.omics@AnnotationImportJobStatusChange event
     */
    interface AnnotationImportJobStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * storeId property
         *
         * Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly storeId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * storeName property
         *
         * Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly storeName?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.omics@AnnotationStoreStatusChange
 */
export declare class AnnotationStoreStatusChange {
    /**
     * EventBridge event pattern for Annotation Store Status Change
     */
    static eventPattern(options?: AnnotationStoreStatusChange.AnnotationStoreStatusChangeProps): events.EventPattern;
}
export declare namespace AnnotationStoreStatusChange {
    /**
     * Props type for aws.omics@AnnotationStoreStatusChange event
     */
    interface AnnotationStoreStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * storeId property
         *
         * Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly storeId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * storeName property
         *
         * Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly storeName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.omics@ReferenceStoreStatusChange
 */
export declare class ReferenceStoreStatusChange {
    /**
     * EventBridge event pattern for Reference Store Status Change
     */
    static eventPattern(options?: ReferenceStoreStatusChange.ReferenceStoreStatusChangeProps): events.EventPattern;
}
export declare namespace ReferenceStoreStatusChange {
    /**
     * Props type for aws.omics@ReferenceStoreStatusChange event
     */
    interface ReferenceStoreStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.omics@RunStatusChange
 */
export declare class RunStatusChange {
    /**
     * EventBridge event pattern for Run Status Change
     */
    static eventPattern(options?: RunStatusChange.RunStatusChangeProps): events.EventPattern;
}
export declare namespace RunStatusChange {
    /**
     * Props type for aws.omics@RunStatusChange event
     */
    interface RunStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.omics@S3AccessPolicyStatusChange
 */
export declare class S3AccessPolicyStatusChange {
    /**
     * EventBridge event pattern for S3 Access Policy Status Change
     */
    static eventPattern(options?: S3AccessPolicyStatusChange.S3AccessPolicyStatusChangeProps): events.EventPattern;
}
export declare namespace S3AccessPolicyStatusChange {
    /**
     * Props type for aws.omics@S3AccessPolicyStatusChange event
     */
    interface S3AccessPolicyStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * s3AccessPointArn property
         *
         * Specify an array of string values to match this event if the actual value of s3AccessPointArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3AccessPointArn?: Array<string>;
        /**
         * storeId property
         *
         * Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly storeId?: Array<string>;
        /**
         * storeType property
         *
         * Specify an array of string values to match this event if the actual value of storeType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly storeType?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.omics@SequenceStoreStatusChange
 */
export declare class SequenceStoreStatusChange {
    /**
     * EventBridge event pattern for Sequence Store Status Change
     */
    static eventPattern(options?: SequenceStoreStatusChange.SequenceStoreStatusChangeProps): events.EventPattern;
}
export declare namespace SequenceStoreStatusChange {
    /**
     * Props type for aws.omics@SequenceStoreStatusChange event
     */
    interface SequenceStoreStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.omics@TaskStatusChange
 */
export declare class TaskStatusChange {
    /**
     * EventBridge event pattern for Task Status Change
     */
    static eventPattern(options?: TaskStatusChange.TaskStatusChangeProps): events.EventPattern;
}
export declare namespace TaskStatusChange {
    /**
     * Props type for aws.omics@TaskStatusChange event
     */
    interface TaskStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.omics@VariantImportJobStatusChange
 */
export declare class VariantImportJobStatusChange {
    /**
     * EventBridge event pattern for Variant Import Job Status Change
     */
    static eventPattern(options?: VariantImportJobStatusChange.VariantImportJobStatusChangeProps): events.EventPattern;
}
export declare namespace VariantImportJobStatusChange {
    /**
     * Props type for aws.omics@VariantImportJobStatusChange event
     */
    interface VariantImportJobStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * storeId property
         *
         * Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly storeId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * storeName property
         *
         * Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly storeName?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.omics@VariantStoreStatusChange
 */
export declare class VariantStoreStatusChange {
    /**
     * EventBridge event pattern for Variant Store Status Change
     */
    static eventPattern(options?: VariantStoreStatusChange.VariantStoreStatusChangeProps): events.EventPattern;
}
export declare namespace VariantStoreStatusChange {
    /**
     * Props type for aws.omics@VariantStoreStatusChange event
     */
    interface VariantStoreStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * storeId property
         *
         * Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly storeId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * storeName property
         *
         * Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly storeName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.omics@WorkflowStatusChange
 */
export declare class WorkflowStatusChange {
    /**
     * EventBridge event pattern for Workflow Status Change
     */
    static eventPattern(options?: WorkflowStatusChange.WorkflowStatusChangeProps): events.EventPattern;
}
export declare namespace WorkflowStatusChange {
    /**
     * Props type for aws.omics@WorkflowStatusChange event
     */
    interface WorkflowStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.omics@ReferenceImportJobStatusChange
 */
export declare class ReferenceImportJobStatusChange {
    /**
     * EventBridge event pattern for Reference Import Job Status Change
     */
    static eventPattern(options?: ReferenceImportJobStatusChange.ReferenceImportJobStatusChangeProps): events.EventPattern;
}
export declare namespace ReferenceImportJobStatusChange {
    /**
     * Props type for aws.omics@ReferenceImportJobStatusChange event
     */
    interface ReferenceImportJobStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * referenceStoreId property
         *
         * Specify an array of string values to match this event if the actual value of referenceStoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the ReferenceStore reference
         */
        readonly referenceStoreId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * statusMessage property
         *
         * Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusMessage?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event patterns for ReferenceStore
 */
export declare class ReferenceStoreEvents {
    /**
     * Create ReferenceStoreEvents from a ReferenceStore reference
     */
    static fromReferenceStore(referenceStoreRef: service.IReferenceStoreRef): ReferenceStoreEvents;
    /**
     * Reference to the ReferenceStore construct
     */
    private readonly referenceStoreRef;
    private constructor();
    /**
     * EventBridge event pattern for ReferenceStore Reference Import Job Status Change
     */
    referenceImportJobStatusChangePattern(options?: ReferenceImportJobStatusChange.ReferenceImportJobStatusChangeProps): events.EventPattern;
    /**
     * EventBridge event pattern for ReferenceStore Reference Status Change
     */
    referenceStatusChangePattern(options?: ReferenceStatusChange.ReferenceStatusChangeProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.omics@ReferenceStatusChange
 */
export declare class ReferenceStatusChange {
    /**
     * EventBridge event pattern for Reference Status Change
     */
    static eventPattern(options?: ReferenceStatusChange.ReferenceStatusChangeProps): events.EventPattern;
}
export declare namespace ReferenceStatusChange {
    /**
     * Props type for aws.omics@ReferenceStatusChange event
     */
    interface ReferenceStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * referenceStoreId property
         *
         * Specify an array of string values to match this event if the actual value of referenceStoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the ReferenceStore reference
         */
        readonly referenceStoreId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * creationJobId property
         *
         * Specify an array of string values to match this event if the actual value of creationJobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationJobId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.omics@ReadSetActivationJobStatusChange
 */
export declare class ReadSetActivationJobStatusChange {
    /**
     * EventBridge event pattern for Read Set Activation Job Status Change
     */
    static eventPattern(options?: ReadSetActivationJobStatusChange.ReadSetActivationJobStatusChangeProps): events.EventPattern;
}
export declare namespace ReadSetActivationJobStatusChange {
    /**
     * Props type for aws.omics@ReadSetActivationJobStatusChange event
     */
    interface ReadSetActivationJobStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * sequenceStoreId property
         *
         * Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the SequenceStore reference
         */
        readonly sequenceStoreId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * statusMessage property
         *
         * Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusMessage?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event patterns for SequenceStore
 */
export declare class SequenceStoreEvents {
    /**
     * Create SequenceStoreEvents from a SequenceStore reference
     */
    static fromSequenceStore(sequenceStoreRef: service.ISequenceStoreRef): SequenceStoreEvents;
    /**
     * Reference to the SequenceStore construct
     */
    private readonly sequenceStoreRef;
    private constructor();
    /**
     * EventBridge event pattern for SequenceStore Read Set Activation Job Status Change
     */
    readSetActivationJobStatusChangePattern(options?: ReadSetActivationJobStatusChange.ReadSetActivationJobStatusChangeProps): events.EventPattern;
    /**
     * EventBridge event pattern for SequenceStore Read Set Export Job Status Change
     */
    readSetExportJobStatusChangePattern(options?: ReadSetExportJobStatusChange.ReadSetExportJobStatusChangeProps): events.EventPattern;
    /**
     * EventBridge event pattern for SequenceStore Read Set Import Job Status Change
     */
    readSetImportJobStatusChangePattern(options?: ReadSetImportJobStatusChange.ReadSetImportJobStatusChangeProps): events.EventPattern;
    /**
     * EventBridge event pattern for SequenceStore Read Set Status Change
     */
    readSetStatusChangePattern(options?: ReadSetStatusChange.ReadSetStatusChangeProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.omics@ReadSetExportJobStatusChange
 */
export declare class ReadSetExportJobStatusChange {
    /**
     * EventBridge event pattern for Read Set Export Job Status Change
     */
    static eventPattern(options?: ReadSetExportJobStatusChange.ReadSetExportJobStatusChangeProps): events.EventPattern;
}
export declare namespace ReadSetExportJobStatusChange {
    /**
     * Props type for aws.omics@ReadSetExportJobStatusChange event
     */
    interface ReadSetExportJobStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * sequenceStoreId property
         *
         * Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the SequenceStore reference
         */
        readonly sequenceStoreId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * statusMessage property
         *
         * Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusMessage?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.omics@ReadSetImportJobStatusChange
 */
export declare class ReadSetImportJobStatusChange {
    /**
     * EventBridge event pattern for Read Set Import Job Status Change
     */
    static eventPattern(options?: ReadSetImportJobStatusChange.ReadSetImportJobStatusChangeProps): events.EventPattern;
}
export declare namespace ReadSetImportJobStatusChange {
    /**
     * Props type for aws.omics@ReadSetImportJobStatusChange event
     */
    interface ReadSetImportJobStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * sequenceStoreId property
         *
         * Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the SequenceStore reference
         */
        readonly sequenceStoreId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * statusMessage property
         *
         * Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusMessage?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.omics@ReadSetStatusChange
 */
export declare class ReadSetStatusChange {
    /**
     * EventBridge event pattern for Read Set Status Change
     */
    static eventPattern(options?: ReadSetStatusChange.ReadSetStatusChangeProps): events.EventPattern;
}
export declare namespace ReadSetStatusChange {
    /**
     * Props type for aws.omics@ReadSetStatusChange event
     */
    interface ReadSetStatusChangeProps {
        /**
         * omicsVersion property
         *
         * Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly omicsVersion?: Array<string>;
        /**
         * sequenceStoreId property
         *
         * Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the SequenceStore reference
         */
        readonly sequenceStoreId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * statusMessage property
         *
         * Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusMessage?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * creationJobId property
         *
         * Specify an array of string values to match this event if the actual value of creationJobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationJobId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
