import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-autoscaling";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.autoscaling@AWSAPICallViaCloudTrail
 */
export declare class AWSAPICallViaCloudTrail {
    /**
     * EventBridge event pattern for AWS API Call via CloudTrail
     */
    static eventPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
}
export declare namespace AWSAPICallViaCloudTrail {
    /**
     * Props type for aws.autoscaling@AWSAPICallViaCloudTrail event
     */
    interface AWSAPICallViaCloudTrailProps {
        /**
         * responseElements property
         *
         * Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly responseElements?: AWSAPICallViaCloudTrail.ResponseElements;
        /**
         * requestParameters property
         *
         * Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestParameters?: AWSAPICallViaCloudTrail.RequestParameters;
        /**
         * userIdentity property
         *
         * Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userIdentity?: AWSAPICallViaCloudTrail.UserIdentity;
        /**
         * eventID property
         *
         * Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * awsRegion property
         *
         * Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsRegion?: Array<string>;
        /**
         * eventVersion property
         *
         * Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventVersion?: Array<string>;
        /**
         * sourceIPAddress property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * eventSource property
         *
         * Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventSource?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * requestID property
         *
         * Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ResponseElements
     *
     * @struct
     */
    interface ResponseElements {
        /**
         * policyARN property
         *
         * Specify an array of string values to match this event if the actual value of policyARN is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly policyArn?: Array<string>;
        /**
         * failedScheduledActions property
         *
         * Specify an array of string values to match this event if the actual value of failedScheduledActions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failedScheduledActions?: Array<any>;
        /**
         * failedScheduledUpdateGroupActions property
         *
         * Specify an array of string values to match this event if the actual value of failedScheduledUpdateGroupActions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failedScheduledUpdateGroupActions?: Array<any>;
        /**
         * alarms property
         *
         * Specify an array of string values to match this event if the actual value of alarms is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alarms?: Array<any>;
    }
    /**
     * Type definition for RequestParameters
     *
     * @struct
     */
    interface RequestParameters {
        /**
         * targetTrackingConfiguration property
         *
         * Specify an array of string values to match this event if the actual value of targetTrackingConfiguration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetTrackingConfiguration?: AWSAPICallViaCloudTrail.TargetTrackingConfiguration;
        /**
         * mixedInstancesPolicy property
         *
         * Specify an array of string values to match this event if the actual value of mixedInstancesPolicy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mixedInstancesPolicy?: AWSAPICallViaCloudTrail.MixedInstancesPolicy;
        /**
         * launchTemplate property
         *
         * Specify an array of string values to match this event if the actual value of launchTemplate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplate?: AWSAPICallViaCloudTrail.LaunchTemplate;
        /**
         * healthCheckType property
         *
         * Specify an array of string values to match this event if the actual value of healthCheckType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly healthCheckType?: Array<string>;
        /**
         * userData property
         *
         * Specify an array of string values to match this event if the actual value of userData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userData?: Array<string>;
        /**
         * spotPrice property
         *
         * Specify an array of string values to match this event if the actual value of spotPrice is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly spotPrice?: Array<string>;
        /**
         * breachThreshold property
         *
         * Specify an array of string values to match this event if the actual value of breachThreshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly breachThreshold?: Array<string>;
        /**
         * adjustmentType property
         *
         * Specify an array of string values to match this event if the actual value of adjustmentType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly adjustmentType?: Array<string>;
        /**
         * defaultCooldown property
         *
         * Specify an array of string values to match this event if the actual value of defaultCooldown is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly defaultCooldown?: Array<string>;
        /**
         * metricValue property
         *
         * Specify an array of string values to match this event if the actual value of metricValue is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricValue?: Array<string>;
        /**
         * availabilityZones property
         *
         * Specify an array of string values to match this event if the actual value of availabilityZones is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly availabilityZones?: Array<string>;
        /**
         * maxSize property
         *
         * Specify an array of string values to match this event if the actual value of maxSize is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxSize?: Array<string>;
        /**
         * targetGroupARNs property
         *
         * Specify an array of string values to match this event if the actual value of targetGroupARNs is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetGroupArns?: Array<string>;
        /**
         * honorCooldown property
         *
         * Specify an array of string values to match this event if the actual value of honorCooldown is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly honorCooldown?: Array<string>;
        /**
         * launchConfigurationName property
         *
         * Specify an array of string values to match this event if the actual value of launchConfigurationName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchConfigurationName?: Array<string>;
        /**
         * autoScalingGroupName property
         *
         * Specify an array of string values to match this event if the actual value of autoScalingGroupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly autoScalingGroupName?: Array<string>;
        /**
         * forceDelete property
         *
         * Specify an array of string values to match this event if the actual value of forceDelete is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly forceDelete?: Array<string>;
        /**
         * scheduledUpdateGroupActions property
         *
         * Specify an array of string values to match this event if the actual value of scheduledUpdateGroupActions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scheduledUpdateGroupActions?: Array<any>;
        /**
         * scheduledActionName property
         *
         * Specify an array of string values to match this event if the actual value of scheduledActionName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scheduledActionName?: Array<string>;
        /**
         * healthCheckGracePeriod property
         *
         * Specify an array of string values to match this event if the actual value of healthCheckGracePeriod is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly healthCheckGracePeriod?: Array<string>;
        /**
         * newInstancesProtectedFromScaleIn property
         *
         * Specify an array of string values to match this event if the actual value of newInstancesProtectedFromScaleIn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly newInstancesProtectedFromScaleIn?: Array<string>;
        /**
         * instanceIds property
         *
         * Specify an array of string values to match this event if the actual value of instanceIds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceIds?: Array<string>;
        /**
         * minSize property
         *
         * Specify an array of string values to match this event if the actual value of minSize is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly minSize?: Array<string>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * topicARN property
         *
         * Specify an array of string values to match this event if the actual value of topicARN is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly topicArn?: Array<string>;
        /**
         * lifecycleHookSpecificationList property
         *
         * Specify an array of string values to match this event if the actual value of lifecycleHookSpecificationList is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lifecycleHookSpecificationList?: Array<any>;
        /**
         * imageId property
         *
         * Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageId?: Array<string>;
        /**
         * loadBalancerNames property
         *
         * Specify an array of string values to match this event if the actual value of loadBalancerNames is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly loadBalancerNames?: Array<string>;
        /**
         * policyName property
         *
         * Specify an array of string values to match this event if the actual value of policyName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly policyName?: Array<string>;
        /**
         * scheduledActionNames property
         *
         * Specify an array of string values to match this event if the actual value of scheduledActionNames is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scheduledActionNames?: Array<string>;
        /**
         * instanceType property
         *
         * Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<AWSAPICallViaCloudTrail.RequestParametersItem>;
        /**
         * serviceLinkedRoleARN property
         *
         * Specify an array of string values to match this event if the actual value of serviceLinkedRoleARN is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serviceLinkedRoleArn?: Array<string>;
        /**
         * stepAdjustments property
         *
         * Specify an array of string values to match this event if the actual value of stepAdjustments is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stepAdjustments?: Array<AWSAPICallViaCloudTrail.RequestParametersItem1>;
        /**
         * granularity property
         *
         * Specify an array of string values to match this event if the actual value of granularity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly granularity?: Array<string>;
        /**
         * policyType property
         *
         * Specify an array of string values to match this event if the actual value of policyType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly policyType?: Array<string>;
        /**
         * scalingAdjustment property
         *
         * Specify an array of string values to match this event if the actual value of scalingAdjustment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scalingAdjustment?: Array<string>;
        /**
         * securityGroups property
         *
         * Specify an array of string values to match this event if the actual value of securityGroups is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly securityGroups?: Array<string>;
        /**
         * notificationTypes property
         *
         * Specify an array of string values to match this event if the actual value of notificationTypes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notificationTypes?: Array<string>;
        /**
         * time property
         *
         * Specify an array of string values to match this event if the actual value of time is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly time?: Array<string>;
        /**
         * metrics property
         *
         * Specify an array of string values to match this event if the actual value of metrics is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metrics?: Array<string>;
        /**
         * protectedFromScaleIn property
         *
         * Specify an array of string values to match this event if the actual value of protectedFromScaleIn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protectedFromScaleIn?: Array<string>;
        /**
         * desiredCapacity property
         *
         * Specify an array of string values to match this event if the actual value of desiredCapacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly desiredCapacity?: Array<string>;
        /**
         * vPCZoneIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of vPCZoneIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vPcZoneIdentifier?: Array<string>;
    }
    /**
     * Type definition for TargetTrackingConfiguration
     *
     * @struct
     */
    interface TargetTrackingConfiguration {
        /**
         * predefinedMetricSpecification property
         *
         * Specify an array of string values to match this event if the actual value of predefinedMetricSpecification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly predefinedMetricSpecification?: AWSAPICallViaCloudTrail.PredefinedMetricSpecification;
        /**
         * customizedMetricSpecification property
         *
         * Specify an array of string values to match this event if the actual value of customizedMetricSpecification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly customizedMetricSpecification?: AWSAPICallViaCloudTrail.CustomizedMetricSpecification;
        /**
         * targetValue property
         *
         * Specify an array of string values to match this event if the actual value of targetValue is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetValue?: Array<string>;
    }
    /**
     * Type definition for PredefinedMetricSpecification
     *
     * @struct
     */
    interface PredefinedMetricSpecification {
        /**
         * predefinedMetricType property
         *
         * Specify an array of string values to match this event if the actual value of predefinedMetricType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly predefinedMetricType?: Array<string>;
    }
    /**
     * Type definition for CustomizedMetricSpecification
     *
     * @struct
     */
    interface CustomizedMetricSpecification {
        /**
         * unit property
         *
         * Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unit?: Array<string>;
        /**
         * statistic property
         *
         * Specify an array of string values to match this event if the actual value of statistic is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statistic?: Array<string>;
        /**
         * metricName property
         *
         * Specify an array of string values to match this event if the actual value of metricName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricName?: Array<string>;
        /**
         * namespace property
         *
         * Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly namespace?: Array<string>;
        /**
         * dimensions property
         *
         * Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dimensions?: Array<AWSAPICallViaCloudTrail.CustomizedMetricSpecificationItem>;
    }
    /**
     * Type definition for CustomizedMetricSpecificationItem
     *
     * @struct
     */
    interface CustomizedMetricSpecificationItem {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for MixedInstancesPolicy
     *
     * @struct
     */
    interface MixedInstancesPolicy {
        /**
         * launchTemplate property
         *
         * Specify an array of string values to match this event if the actual value of launchTemplate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplate?: AWSAPICallViaCloudTrail.LaunchTemplate1;
        /**
         * instancesDistribution property
         *
         * Specify an array of string values to match this event if the actual value of instancesDistribution is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instancesDistribution?: AWSAPICallViaCloudTrail.InstancesDistribution;
    }
    /**
     * Type definition for LaunchTemplate_1
     *
     * @struct
     */
    interface LaunchTemplate1 {
        /**
         * launchTemplateSpecification property
         *
         * Specify an array of string values to match this event if the actual value of launchTemplateSpecification is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplateSpecification?: AWSAPICallViaCloudTrail.LaunchTemplateSpecification;
        /**
         * overrides property
         *
         * Specify an array of string values to match this event if the actual value of overrides is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly overrides?: Array<any>;
    }
    /**
     * Type definition for LaunchTemplateSpecification
     *
     * @struct
     */
    interface LaunchTemplateSpecification {
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * launchTemplateName property
         *
         * Specify an array of string values to match this event if the actual value of launchTemplateName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplateName?: Array<string>;
    }
    /**
     * Type definition for InstancesDistribution
     *
     * @struct
     */
    interface InstancesDistribution {
        /**
         * onDemandBaseCapacity property
         *
         * Specify an array of string values to match this event if the actual value of onDemandBaseCapacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly onDemandBaseCapacity?: Array<string>;
        /**
         * spotInstancePools property
         *
         * Specify an array of string values to match this event if the actual value of spotInstancePools is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly spotInstancePools?: Array<string>;
        /**
         * spotAllocationStrategy property
         *
         * Specify an array of string values to match this event if the actual value of spotAllocationStrategy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly spotAllocationStrategy?: Array<string>;
        /**
         * onDemandAllocationStrategy property
         *
         * Specify an array of string values to match this event if the actual value of onDemandAllocationStrategy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly onDemandAllocationStrategy?: Array<string>;
        /**
         * onDemandPercentageAboveBaseCapacity property
         *
         * Specify an array of string values to match this event if the actual value of onDemandPercentageAboveBaseCapacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly onDemandPercentageAboveBaseCapacity?: Array<string>;
    }
    /**
     * Type definition for LaunchTemplate
     *
     * @struct
     */
    interface LaunchTemplate {
        /**
         * launchTemplateName property
         *
         * Specify an array of string values to match this event if the actual value of launchTemplateName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTemplateName?: Array<string>;
    }
    /**
     * Type definition for RequestParametersItem
     *
     * @struct
     */
    interface RequestParametersItem {
        /**
         * resourceId property
         *
         * Specify an array of string values to match this event if the actual value of resourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceId?: Array<string>;
        /**
         * propagateAtLaunch property
         *
         * Specify an array of string values to match this event if the actual value of propagateAtLaunch is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly propagateAtLaunch?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * resourceType property
         *
         * Specify an array of string values to match this event if the actual value of resourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceType?: Array<string>;
    }
    /**
     * Type definition for RequestParametersItem_1
     *
     * @struct
     */
    interface RequestParametersItem1 {
        /**
         * metricIntervalLowerBound property
         *
         * Specify an array of string values to match this event if the actual value of metricIntervalLowerBound is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricIntervalLowerBound?: Array<string>;
        /**
         * scalingAdjustment property
         *
         * Specify an array of string values to match this event if the actual value of scalingAdjustment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scalingAdjustment?: Array<string>;
    }
    /**
     * Type definition for UserIdentity
     *
     * @struct
     */
    interface UserIdentity {
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.autoscaling@EC2InstanceLaunchLifecycleAction
 */
export declare class EC2InstanceLaunchLifecycleAction {
    /**
     * EventBridge event pattern for EC2 Instance-launch Lifecycle Action
     */
    static eventPattern(options?: EC2InstanceLaunchLifecycleAction.EC2InstanceLaunchLifecycleActionProps): events.EventPattern;
}
export declare namespace EC2InstanceLaunchLifecycleAction {
    /**
     * Props type for aws.autoscaling@EC2InstanceLaunchLifecycleAction event
     */
    interface EC2InstanceLaunchLifecycleActionProps {
        /**
         * LifecycleHookName property
         *
         * Specify an array of string values to match this event if the actual value of LifecycleHookName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lifecycleHookName?: Array<string>;
        /**
         * LifecycleTransition property
         *
         * Specify an array of string values to match this event if the actual value of LifecycleTransition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lifecycleTransition?: Array<string>;
        /**
         * AutoScalingGroupName property
         *
         * Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the AutoScalingGroup reference
         */
        readonly autoScalingGroupName?: Array<string>;
        /**
         * EC2InstanceId property
         *
         * Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ec2InstanceId?: Array<string>;
        /**
         * LifecycleActionToken property
         *
         * Specify an array of string values to match this event if the actual value of LifecycleActionToken is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lifecycleActionToken?: Array<string>;
        /**
         * NotificationMetadata property
         *
         * Specify an array of string values to match this event if the actual value of NotificationMetadata is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notificationMetadata?: Array<string>;
        /**
         * Origin property
         *
         * Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly origin?: Array<string>;
        /**
         * Destination property
         *
         * Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destination?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event patterns for AutoScalingGroup
 */
export declare class AutoScalingGroupEvents {
    /**
     * Create AutoScalingGroupEvents from a AutoScalingGroup reference
     */
    static fromAutoScalingGroup(autoScalingGroupRef: service.IAutoScalingGroupRef): AutoScalingGroupEvents;
    /**
     * Reference to the AutoScalingGroup construct
     */
    private readonly autoScalingGroupRef;
    private constructor();
    /**
     * EventBridge event pattern for AutoScalingGroup EC2 Instance-launch Lifecycle Action
     */
    ec2InstanceLaunchLifecycleActionPattern(options?: EC2InstanceLaunchLifecycleAction.EC2InstanceLaunchLifecycleActionProps): events.EventPattern;
    /**
     * EventBridge event pattern for AutoScalingGroup EC2 Instance Launch Successful
     */
    ec2InstanceLaunchSuccessfulPattern(options?: EC2InstanceLaunchSuccessful.EC2InstanceLaunchSuccessfulProps): events.EventPattern;
    /**
     * EventBridge event pattern for AutoScalingGroup EC2 Instance Launch Unsuccessful
     */
    ec2InstanceLaunchUnsuccessfulPattern(options?: EC2InstanceLaunchUnsuccessful.EC2InstanceLaunchUnsuccessfulProps): events.EventPattern;
    /**
     * EventBridge event pattern for AutoScalingGroup EC2 Instance-terminate Lifecycle Action
     */
    ec2InstanceTerminateLifecycleActionPattern(options?: EC2InstanceTerminateLifecycleAction.EC2InstanceTerminateLifecycleActionProps): events.EventPattern;
    /**
     * EventBridge event pattern for AutoScalingGroup EC2 Instance Terminate Successful
     */
    ec2InstanceTerminateSuccessfulPattern(options?: EC2InstanceTerminateSuccessful.EC2InstanceTerminateSuccessfulProps): events.EventPattern;
    /**
     * EventBridge event pattern for AutoScalingGroup EC2 Instance Terminate Unsuccessful
     */
    ec2InstanceTerminateUnsuccessfulPattern(options?: EC2InstanceTerminateUnsuccessful.EC2InstanceTerminateUnsuccessfulProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.autoscaling@EC2InstanceLaunchSuccessful
 */
export declare class EC2InstanceLaunchSuccessful {
    /**
     * EventBridge event pattern for EC2 Instance Launch Successful
     */
    static eventPattern(options?: EC2InstanceLaunchSuccessful.EC2InstanceLaunchSuccessfulProps): events.EventPattern;
}
export declare namespace EC2InstanceLaunchSuccessful {
    /**
     * Props type for aws.autoscaling@EC2InstanceLaunchSuccessful event
     */
    interface EC2InstanceLaunchSuccessfulProps {
        /**
         * Details property
         *
         * Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly details?: EC2InstanceLaunchSuccessful.Details;
        /**
         * Description property
         *
         * Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * EndTime property
         *
         * Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * RequestId property
         *
         * Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * ActivityId property
         *
         * Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly activityId?: Array<string>;
        /**
         * Cause property
         *
         * Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cause?: Array<string>;
        /**
         * AutoScalingGroupName property
         *
         * Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the AutoScalingGroup reference
         */
        readonly autoScalingGroupName?: Array<string>;
        /**
         * StartTime property
         *
         * Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * EC2InstanceId property
         *
         * Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ec2InstanceId?: Array<string>;
        /**
         * StatusCode property
         *
         * Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * StatusMessage property
         *
         * Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusMessage?: Array<string>;
        /**
         * Origin property
         *
         * Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly origin?: Array<string>;
        /**
         * Destination property
         *
         * Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destination?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Details
     *
     * @struct
     */
    interface Details {
        /**
         * Subnet ID property
         *
         * Specify an array of string values to match this event if the actual value of Subnet ID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
        /**
         * Availability Zone property
         *
         * Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly availabilityZone?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.autoscaling@EC2InstanceLaunchUnsuccessful
 */
export declare class EC2InstanceLaunchUnsuccessful {
    /**
     * EventBridge event pattern for EC2 Instance Launch Unsuccessful
     */
    static eventPattern(options?: EC2InstanceLaunchUnsuccessful.EC2InstanceLaunchUnsuccessfulProps): events.EventPattern;
}
export declare namespace EC2InstanceLaunchUnsuccessful {
    /**
     * Props type for aws.autoscaling@EC2InstanceLaunchUnsuccessful event
     */
    interface EC2InstanceLaunchUnsuccessfulProps {
        /**
         * Details property
         *
         * Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly details?: EC2InstanceLaunchUnsuccessful.Details;
        /**
         * Description property
         *
         * Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * EndTime property
         *
         * Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * RequestId property
         *
         * Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * ActivityId property
         *
         * Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly activityId?: Array<string>;
        /**
         * Cause property
         *
         * Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cause?: Array<string>;
        /**
         * AutoScalingGroupName property
         *
         * Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the AutoScalingGroup reference
         */
        readonly autoScalingGroupName?: Array<string>;
        /**
         * StartTime property
         *
         * Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * EC2InstanceId property
         *
         * Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ec2InstanceId?: Array<string>;
        /**
         * StatusCode property
         *
         * Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * StatusMessage property
         *
         * Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusMessage?: Array<string>;
        /**
         * Origin property
         *
         * Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly origin?: Array<string>;
        /**
         * Destination property
         *
         * Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destination?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Details
     *
     * @struct
     */
    interface Details {
        /**
         * Subnet ID property
         *
         * Specify an array of string values to match this event if the actual value of Subnet ID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
        /**
         * Availability Zone property
         *
         * Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly availabilityZone?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.autoscaling@EC2InstanceTerminateLifecycleAction
 */
export declare class EC2InstanceTerminateLifecycleAction {
    /**
     * EventBridge event pattern for EC2 Instance-terminate Lifecycle Action
     */
    static eventPattern(options?: EC2InstanceTerminateLifecycleAction.EC2InstanceTerminateLifecycleActionProps): events.EventPattern;
}
export declare namespace EC2InstanceTerminateLifecycleAction {
    /**
     * Props type for aws.autoscaling@EC2InstanceTerminateLifecycleAction event
     */
    interface EC2InstanceTerminateLifecycleActionProps {
        /**
         * LifecycleHookName property
         *
         * Specify an array of string values to match this event if the actual value of LifecycleHookName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lifecycleHookName?: Array<string>;
        /**
         * LifecycleTransition property
         *
         * Specify an array of string values to match this event if the actual value of LifecycleTransition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lifecycleTransition?: Array<string>;
        /**
         * AutoScalingGroupName property
         *
         * Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the AutoScalingGroup reference
         */
        readonly autoScalingGroupName?: Array<string>;
        /**
         * EC2InstanceId property
         *
         * Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ec2InstanceId?: Array<string>;
        /**
         * LifecycleActionToken property
         *
         * Specify an array of string values to match this event if the actual value of LifecycleActionToken is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lifecycleActionToken?: Array<string>;
        /**
         * NotificationMetadata property
         *
         * Specify an array of string values to match this event if the actual value of NotificationMetadata is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notificationMetadata?: Array<string>;
        /**
         * Origin property
         *
         * Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly origin?: Array<string>;
        /**
         * Destination property
         *
         * Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destination?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.autoscaling@EC2InstanceTerminateSuccessful
 */
export declare class EC2InstanceTerminateSuccessful {
    /**
     * EventBridge event pattern for EC2 Instance Terminate Successful
     */
    static eventPattern(options?: EC2InstanceTerminateSuccessful.EC2InstanceTerminateSuccessfulProps): events.EventPattern;
}
export declare namespace EC2InstanceTerminateSuccessful {
    /**
     * Props type for aws.autoscaling@EC2InstanceTerminateSuccessful event
     */
    interface EC2InstanceTerminateSuccessfulProps {
        /**
         * Details property
         *
         * Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly details?: EC2InstanceTerminateSuccessful.Details;
        /**
         * Description property
         *
         * Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * EndTime property
         *
         * Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * RequestId property
         *
         * Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * ActivityId property
         *
         * Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly activityId?: Array<string>;
        /**
         * Cause property
         *
         * Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cause?: Array<string>;
        /**
         * AutoScalingGroupName property
         *
         * Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the AutoScalingGroup reference
         */
        readonly autoScalingGroupName?: Array<string>;
        /**
         * StartTime property
         *
         * Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * EC2InstanceId property
         *
         * Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ec2InstanceId?: Array<string>;
        /**
         * StatusCode property
         *
         * Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * StatusMessage property
         *
         * Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusMessage?: Array<string>;
        /**
         * Origin property
         *
         * Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly origin?: Array<string>;
        /**
         * Destination property
         *
         * Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destination?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Details
     *
     * @struct
     */
    interface Details {
        /**
         * Subnet ID property
         *
         * Specify an array of string values to match this event if the actual value of Subnet ID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
        /**
         * Availability Zone property
         *
         * Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly availabilityZone?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.autoscaling@EC2InstanceTerminateUnsuccessful
 */
export declare class EC2InstanceTerminateUnsuccessful {
    /**
     * EventBridge event pattern for EC2 Instance Terminate Unsuccessful
     */
    static eventPattern(options?: EC2InstanceTerminateUnsuccessful.EC2InstanceTerminateUnsuccessfulProps): events.EventPattern;
}
export declare namespace EC2InstanceTerminateUnsuccessful {
    /**
     * Props type for aws.autoscaling@EC2InstanceTerminateUnsuccessful event
     */
    interface EC2InstanceTerminateUnsuccessfulProps {
        /**
         * Details property
         *
         * Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly details?: EC2InstanceTerminateUnsuccessful.Details;
        /**
         * Description property
         *
         * Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * RequestId property
         *
         * Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * EndTime property
         *
         * Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * AutoScalingGroupName property
         *
         * Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the AutoScalingGroup reference
         */
        readonly autoScalingGroupName?: Array<string>;
        /**
         * ActivityId property
         *
         * Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly activityId?: Array<string>;
        /**
         * Cause property
         *
         * Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cause?: Array<string>;
        /**
         * StartTime property
         *
         * Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * EC2InstanceId property
         *
         * Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ec2InstanceId?: Array<string>;
        /**
         * StatusCode property
         *
         * Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * StatusMessage property
         *
         * Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusMessage?: Array<string>;
        /**
         * Origin property
         *
         * Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly origin?: Array<string>;
        /**
         * Destination property
         *
         * Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destination?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Details
     *
     * @struct
     */
    interface Details {
        /**
         * Subnet ID property
         *
         * Specify an array of string values to match this event if the actual value of Subnet ID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
        /**
         * Availability Zone property
         *
         * Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly availabilityZone?: Array<string>;
    }
}
