import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.emr@EMRAutoScalingPolicyStateChange
 */
export declare class EMRAutoScalingPolicyStateChange {
    /**
     * EventBridge event pattern for EMR Auto Scaling Policy State Change
     */
    static eventPattern(options?: EMRAutoScalingPolicyStateChange.EMRAutoScalingPolicyStateChangeProps): events.EventPattern;
}
export declare namespace EMRAutoScalingPolicyStateChange {
    /**
     * Props type for aws.emr@EMRAutoScalingPolicyStateChange event
     */
    interface EMRAutoScalingPolicyStateChangeProps {
        /**
         * resourceId property
         *
         * Specify an array of string values to match this event if the actual value of resourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceId?: Array<string>;
        /**
         * clusterId property
         *
         * Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clusterId?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * scalingResourceType property
         *
         * Specify an array of string values to match this event if the actual value of scalingResourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scalingResourceType?: Array<string>;
        /**
         * severity property
         *
         * Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly severity?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.emr@EMRClusterStateChange
 */
export declare class EMRClusterStateChange {
    /**
     * EventBridge event pattern for EMR Cluster State Change
     */
    static eventPattern(options?: EMRClusterStateChange.EMRClusterStateChangeProps): events.EventPattern;
}
export declare namespace EMRClusterStateChange {
    /**
     * Props type for aws.emr@EMRClusterStateChange event
     */
    interface EMRClusterStateChangeProps {
        /**
         * severity property
         *
         * Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly severity?: Array<string>;
        /**
         * stateChangeReason property
         *
         * Specify an array of string values to match this event if the actual value of stateChangeReason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stateChangeReason?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * clusterId property
         *
         * Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clusterId?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.emr@EMRConfigurationError
 */
export declare class EMRConfigurationError {
    /**
     * EventBridge event pattern for EMR Configuration Error
     */
    static eventPattern(options?: EMRConfigurationError.EMRConfigurationErrorProps): events.EventPattern;
}
export declare namespace EMRConfigurationError {
    /**
     * Props type for aws.emr@EMRConfigurationError event
     */
    interface EMRConfigurationErrorProps {
        /**
         * severity property
         *
         * Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly severity?: Array<string>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * clusterId property
         *
         * Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clusterId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.emr@EMRInstanceFleetStateChange
 */
export declare class EMRInstanceFleetStateChange {
    /**
     * EventBridge event pattern for EMR Instance Fleet State Change
     */
    static eventPattern(options?: EMRInstanceFleetStateChange.EMRInstanceFleetStateChangeProps): events.EventPattern;
}
export declare namespace EMRInstanceFleetStateChange {
    /**
     * Props type for aws.emr@EMRInstanceFleetStateChange event
     */
    interface EMRInstanceFleetStateChangeProps {
        /**
         * severity property
         *
         * Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly severity?: Array<string>;
        /**
         * provisionedSpotCapacity property
         *
         * Specify an array of string values to match this event if the actual value of provisionedSpotCapacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly provisionedSpotCapacity?: Array<string>;
        /**
         * targetSpotCapacity property
         *
         * Specify an array of string values to match this event if the actual value of targetSpotCapacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetSpotCapacity?: Array<string>;
        /**
         * clusterId property
         *
         * Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clusterId?: Array<string>;
        /**
         * targetOnDemandCapacity property
         *
         * Specify an array of string values to match this event if the actual value of targetOnDemandCapacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetOnDemandCapacity?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * instanceFleetId property
         *
         * Specify an array of string values to match this event if the actual value of instanceFleetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceFleetId?: Array<string>;
        /**
         * provisionedOnDemandCapacity property
         *
         * Specify an array of string values to match this event if the actual value of provisionedOnDemandCapacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly provisionedOnDemandCapacity?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * instanceFleetType property
         *
         * Specify an array of string values to match this event if the actual value of instanceFleetType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceFleetType?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.emr@EMRInstanceGroupStateChange
 */
export declare class EMRInstanceGroupStateChange {
    /**
     * EventBridge event pattern for EMR Instance Group State Change
     */
    static eventPattern(options?: EMRInstanceGroupStateChange.EMRInstanceGroupStateChangeProps): events.EventPattern;
}
export declare namespace EMRInstanceGroupStateChange {
    /**
     * Props type for aws.emr@EMRInstanceGroupStateChange event
     */
    interface EMRInstanceGroupStateChangeProps {
        /**
         * market property
         *
         * Specify an array of string values to match this event if the actual value of market is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly market?: Array<string>;
        /**
         * severity property
         *
         * Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly severity?: Array<string>;
        /**
         * requestedInstanceCount property
         *
         * Specify an array of string values to match this event if the actual value of requestedInstanceCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestedInstanceCount?: Array<string>;
        /**
         * instanceType property
         *
         * Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
        /**
         * instanceGroupType property
         *
         * Specify an array of string values to match this event if the actual value of instanceGroupType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceGroupType?: Array<string>;
        /**
         * instanceGroupId property
         *
         * Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceGroupId?: Array<string>;
        /**
         * clusterId property
         *
         * Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clusterId?: Array<string>;
        /**
         * runningInstanceCount property
         *
         * Specify an array of string values to match this event if the actual value of runningInstanceCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly runningInstanceCount?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * bidPrice property
         *
         * Specify an array of string values to match this event if the actual value of bidPrice is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bidPrice?: Array<string>;
        /**
         * bidPriceAsPercentageOfOnDemandPrice property
         *
         * Specify an array of string values to match this event if the actual value of bidPriceAsPercentageOfOnDemandPrice is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bidPriceAsPercentageOfOnDemandPrice?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.emr@EMRInstanceGroupStatusNotification
 */
export declare class EMRInstanceGroupStatusNotification {
    /**
     * EventBridge event pattern for EMR Instance Group Status Notification
     */
    static eventPattern(options?: EMRInstanceGroupStatusNotification.EMRInstanceGroupStatusNotificationProps): events.EventPattern;
}
export declare namespace EMRInstanceGroupStatusNotification {
    /**
     * Props type for aws.emr@EMRInstanceGroupStatusNotification event
     */
    interface EMRInstanceGroupStatusNotificationProps {
        /**
         * market property
         *
         * Specify an array of string values to match this event if the actual value of market is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly market?: Array<string>;
        /**
         * severity property
         *
         * Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly severity?: Array<string>;
        /**
         * requestedInstanceCount property
         *
         * Specify an array of string values to match this event if the actual value of requestedInstanceCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestedInstanceCount?: Array<string>;
        /**
         * instanceType property
         *
         * Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
        /**
         * instanceGroupType property
         *
         * Specify an array of string values to match this event if the actual value of instanceGroupType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceGroupType?: Array<string>;
        /**
         * instanceGroupId property
         *
         * Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceGroupId?: Array<string>;
        /**
         * clusterId property
         *
         * Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clusterId?: Array<string>;
        /**
         * runningInstanceCount property
         *
         * Specify an array of string values to match this event if the actual value of runningInstanceCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly runningInstanceCount?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * bidPrice property
         *
         * Specify an array of string values to match this event if the actual value of bidPrice is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bidPrice?: Array<string>;
        /**
         * bidPriceAsPercentageOfOnDemandPrice property
         *
         * Specify an array of string values to match this event if the actual value of bidPriceAsPercentageOfOnDemandPrice is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bidPriceAsPercentageOfOnDemandPrice?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.emr@EMRStepStatusChange
 */
export declare class EMRStepStatusChange {
    /**
     * EventBridge event pattern for EMR Step Status Change
     */
    static eventPattern(options?: EMRStepStatusChange.EMRStepStatusChangeProps): events.EventPattern;
}
export declare namespace EMRStepStatusChange {
    /**
     * Props type for aws.emr@EMRStepStatusChange event
     */
    interface EMRStepStatusChangeProps {
        /**
         * severity property
         *
         * Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly severity?: Array<string>;
        /**
         * actionOnFailure property
         *
         * Specify an array of string values to match this event if the actual value of actionOnFailure is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionOnFailure?: Array<string>;
        /**
         * stepId property
         *
         * Specify an array of string values to match this event if the actual value of stepId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stepId?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * clusterId property
         *
         * Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clusterId?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
