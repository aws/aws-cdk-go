import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.elasticache@CacheCreated
 */
export declare class CacheCreated {
    /**
     * EventBridge event pattern for Cache Created
     */
    static eventPattern(options?: CacheCreated.CacheCreatedProps): events.EventPattern;
}
export declare namespace CacheCreated {
    /**
     * Props type for aws.elasticache@CacheCreated event
     */
    interface CacheCreatedProps {
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * EventID property
         *
         * Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.elasticache@CacheCreationFailed
 */
export declare class CacheCreationFailed {
    /**
     * EventBridge event pattern for Cache Creation Failed
     */
    static eventPattern(options?: CacheCreationFailed.CacheCreationFailedProps): events.EventPattern;
}
export declare namespace CacheCreationFailed {
    /**
     * Props type for aws.elasticache@CacheCreationFailed event
     */
    interface CacheCreationFailedProps {
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * EventID property
         *
         * Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.elasticache@CacheDeleted
 */
export declare class CacheDeleted {
    /**
     * EventBridge event pattern for Cache Deleted
     */
    static eventPattern(options?: CacheDeleted.CacheDeletedProps): events.EventPattern;
}
export declare namespace CacheDeleted {
    /**
     * Props type for aws.elasticache@CacheDeleted event
     */
    interface CacheDeletedProps {
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * EventID property
         *
         * Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.elasticache@CacheLimitApproaching
 */
export declare class CacheLimitApproaching {
    /**
     * EventBridge event pattern for Cache Limit Approaching
     */
    static eventPattern(options?: CacheLimitApproaching.CacheLimitApproachingProps): events.EventPattern;
}
export declare namespace CacheLimitApproaching {
    /**
     * Props type for aws.elasticache@CacheLimitApproaching event
     */
    interface CacheLimitApproachingProps {
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * EventID property
         *
         * Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.elasticache@CacheUpdated
 */
export declare class CacheUpdated {
    /**
     * EventBridge event pattern for Cache Updated
     */
    static eventPattern(options?: CacheUpdated.CacheUpdatedProps): events.EventPattern;
}
export declare namespace CacheUpdated {
    /**
     * Props type for aws.elasticache@CacheUpdated event
     */
    interface CacheUpdatedProps {
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * EventID property
         *
         * Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.elasticache@CacheUpdateFailed
 */
export declare class CacheUpdateFailed {
    /**
     * EventBridge event pattern for Cache Update Failed
     */
    static eventPattern(options?: CacheUpdateFailed.CacheUpdateFailedProps): events.EventPattern;
}
export declare namespace CacheUpdateFailed {
    /**
     * Props type for aws.elasticache@CacheUpdateFailed event
     */
    interface CacheUpdateFailedProps {
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * EventID property
         *
         * Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.elasticache@SnapshotCopyFailed
 */
export declare class SnapshotCopyFailed {
    /**
     * EventBridge event pattern for Snapshot Copy Failed
     */
    static eventPattern(options?: SnapshotCopyFailed.SnapshotCopyFailedProps): events.EventPattern;
}
export declare namespace SnapshotCopyFailed {
    /**
     * Props type for aws.elasticache@SnapshotCopyFailed event
     */
    interface SnapshotCopyFailedProps {
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * EventID property
         *
         * Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.elasticache@SnapshotCreated
 */
export declare class SnapshotCreated {
    /**
     * EventBridge event pattern for Snapshot Created
     */
    static eventPattern(options?: SnapshotCreated.SnapshotCreatedProps): events.EventPattern;
}
export declare namespace SnapshotCreated {
    /**
     * Props type for aws.elasticache@SnapshotCreated event
     */
    interface SnapshotCreatedProps {
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * EventID property
         *
         * Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.elasticache@SnapshotCreationFailed
 */
export declare class SnapshotCreationFailed {
    /**
     * EventBridge event pattern for Snapshot Creation Failed
     */
    static eventPattern(options?: SnapshotCreationFailed.SnapshotCreationFailedProps): events.EventPattern;
}
export declare namespace SnapshotCreationFailed {
    /**
     * Props type for aws.elasticache@SnapshotCreationFailed event
     */
    interface SnapshotCreationFailedProps {
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * EventID property
         *
         * Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.elasticache@SnapshotExportFailed
 */
export declare class SnapshotExportFailed {
    /**
     * EventBridge event pattern for Snapshot Export Failed
     */
    static eventPattern(options?: SnapshotExportFailed.SnapshotExportFailedProps): events.EventPattern;
}
export declare namespace SnapshotExportFailed {
    /**
     * Props type for aws.elasticache@SnapshotExportFailed event
     */
    interface SnapshotExportFailedProps {
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * EventID property
         *
         * Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
