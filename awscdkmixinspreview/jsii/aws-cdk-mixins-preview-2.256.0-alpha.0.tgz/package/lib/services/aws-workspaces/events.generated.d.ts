import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-workspaces";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.workspaces@WorkSpacesAccess
 */
export declare class WorkSpacesAccess {
    /**
     * EventBridge event pattern for WorkSpaces Access
     */
    static eventPattern(options?: WorkSpacesAccess.WorkSpacesAccessProps): events.EventPattern;
}
export declare namespace WorkSpacesAccess {
    /**
     * Props type for aws.workspaces@WorkSpacesAccess event
     */
    interface WorkSpacesAccessProps {
        /**
         * clientIpAddress property
         *
         * Specify an array of string values to match this event if the actual value of clientIpAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIpAddress?: Array<string>;
        /**
         * actionType property
         *
         * Specify an array of string values to match this event if the actual value of actionType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionType?: Array<string>;
        /**
         * workspacesClientProductName property
         *
         * Specify an array of string values to match this event if the actual value of workspacesClientProductName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly workspacesClientProductName?: Array<string>;
        /**
         * loginTime property
         *
         * Specify an array of string values to match this event if the actual value of loginTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly loginTime?: Array<string>;
        /**
         * clientPlatform property
         *
         * Specify an array of string values to match this event if the actual value of clientPlatform is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientPlatform?: Array<string>;
        /**
         * directoryId property
         *
         * Specify an array of string values to match this event if the actual value of directoryId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly directoryId?: Array<string>;
        /**
         * workspaceId property
         *
         * Specify an array of string values to match this event if the actual value of workspaceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Workspace reference
         */
        readonly workspaceId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event patterns for Workspace
 */
export declare class WorkspaceEvents {
    /**
     * Create WorkspaceEvents from a Workspace reference
     */
    static fromWorkspace(workspaceRef: service.IWorkspaceRef): WorkspaceEvents;
    /**
     * Reference to the Workspace construct
     */
    private readonly workspaceRef;
    private constructor();
    /**
     * EventBridge event pattern for Workspace WorkSpaces Access
     */
    workSpacesAccessPattern(options?: WorkSpacesAccess.WorkSpacesAccessProps): events.EventPattern;
}
