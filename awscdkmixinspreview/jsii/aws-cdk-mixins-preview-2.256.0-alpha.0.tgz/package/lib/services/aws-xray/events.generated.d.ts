import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.xray@AWSXRayInsightUpdate
 */
export declare class AWSXRayInsightUpdate {
    /**
     * EventBridge event pattern for AWS X-Ray Insight Update
     */
    static eventPattern(options?: AWSXRayInsightUpdate.AWSXRayInsightUpdateProps): events.EventPattern;
}
export declare namespace AWSXRayInsightUpdate {
    /**
     * Props type for aws.xray@AWSXRayInsightUpdate event
     */
    interface AWSXRayInsightUpdateProps {
        /**
         * ClientRequestImpactStatistics property
         *
         * Specify an array of string values to match this event if the actual value of ClientRequestImpactStatistics is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientRequestImpactStatistics?: AWSXRayInsightUpdate.ClientRequestImpactStatistics;
        /**
         * Event property
         *
         * Specify an array of string values to match this event if the actual value of Event is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly event?: AWSXRayInsightUpdate.Event;
        /**
         * RootCauseServiceId property
         *
         * Specify an array of string values to match this event if the actual value of RootCauseServiceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rootCauseServiceId?: AWSXRayInsightUpdate.RootCauseServiceId;
        /**
         * RootCauseServiceRequestImpactStatistics property
         *
         * Specify an array of string values to match this event if the actual value of RootCauseServiceRequestImpactStatistics is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rootCauseServiceRequestImpactStatistics?: AWSXRayInsightUpdate.ClientRequestImpactStatistics;
        /**
         * Categories property
         *
         * Specify an array of string values to match this event if the actual value of Categories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly categories?: Array<string>;
        /**
         * EndTime property
         *
         * Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * GroupName property
         *
         * Specify an array of string values to match this event if the actual value of GroupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupName?: Array<string>;
        /**
         * InsightId property
         *
         * Specify an array of string values to match this event if the actual value of InsightId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightId?: Array<string>;
        /**
         * StartTime property
         *
         * Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * State property
         *
         * Specify an array of string values to match this event if the actual value of State is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * Summary property
         *
         * Specify an array of string values to match this event if the actual value of Summary is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly summary?: Array<string>;
        /**
         * TopAnomalousServices property
         *
         * Specify an array of string values to match this event if the actual value of TopAnomalousServices is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly topAnomalousServices?: Array<AWSXRayInsightUpdate.AwsxRayInsightUpdateItem>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ClientRequestImpactStatistics
     *
     * @struct
     */
    interface ClientRequestImpactStatistics {
        /**
         * FaultCount property
         *
         * Specify an array of string values to match this event if the actual value of FaultCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly faultCount?: Array<string>;
        /**
         * OkCount property
         *
         * Specify an array of string values to match this event if the actual value of OkCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly okCount?: Array<string>;
        /**
         * TotalCount property
         *
         * Specify an array of string values to match this event if the actual value of TotalCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly totalCount?: Array<string>;
    }
    /**
     * Type definition for Event
     *
     * @struct
     */
    interface Event {
        /**
         * ClientRequestImpactStatistics property
         *
         * Specify an array of string values to match this event if the actual value of ClientRequestImpactStatistics is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientRequestImpactStatistics?: AWSXRayInsightUpdate.ClientRequestImpactStatistics;
        /**
         * RootCauseServiceRequestImpactStatistics property
         *
         * Specify an array of string values to match this event if the actual value of RootCauseServiceRequestImpactStatistics is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rootCauseServiceRequestImpactStatistics?: AWSXRayInsightUpdate.ClientRequestImpactStatistics;
        /**
         * EventTime property
         *
         * Specify an array of string values to match this event if the actual value of EventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * Summary property
         *
         * Specify an array of string values to match this event if the actual value of Summary is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly summary?: Array<string>;
        /**
         * TopAnomalousServices property
         *
         * Specify an array of string values to match this event if the actual value of TopAnomalousServices is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly topAnomalousServices?: Array<AWSXRayInsightUpdate.AwsxRayInsightUpdateItem>;
    }
    /**
     * Type definition for AWSXRayInsightUpdateItem
     *
     * @struct
     */
    interface AwsxRayInsightUpdateItem {
        /**
         * ServiceId property
         *
         * Specify an array of string values to match this event if the actual value of ServiceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serviceId?: AWSXRayInsightUpdate.ServiceId;
    }
    /**
     * Type definition for ServiceId
     *
     * @struct
     */
    interface ServiceId {
        /**
         * AccountId property
         *
         * Specify an array of string values to match this event if the actual value of AccountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * Name property
         *
         * Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * Names property
         *
         * Specify an array of string values to match this event if the actual value of Names is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly names?: Array<any>;
        /**
         * Type property
         *
         * Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for RootCauseServiceId
     *
     * @struct
     */
    interface RootCauseServiceId {
        /**
         * AccountId property
         *
         * Specify an array of string values to match this event if the actual value of AccountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * Name property
         *
         * Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * Names property
         *
         * Specify an array of string values to match this event if the actual value of Names is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly names?: Array<any>;
        /**
         * Type property
         *
         * Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
}
