import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-mediapackage";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.mediapackage@MediaPackageInputNotification
 */
export declare class MediaPackageInputNotification {
    /**
     * EventBridge event pattern for MediaPackage Input Notification
     */
    static eventPattern(options?: MediaPackageInputNotification.MediaPackageInputNotificationProps): events.EventPattern;
}
export declare namespace MediaPackageInputNotification {
    /**
     * Props type for aws.mediapackage@MediaPackageInputNotification event
     */
    interface MediaPackageInputNotificationProps {
        /**
         * event property
         *
         * Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly event?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * packaging_configuration_id property
         *
         * Specify an array of string values to match this event if the actual value of packaging_configuration_id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly packagingConfigurationId?: Array<string>;
        /**
         * manifest_urls property
         *
         * Specify an array of string values to match this event if the actual value of manifest_urls is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly manifestUrls?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.mediapackage@MediaPackageKeyProviderNotification
 */
export declare class MediaPackageKeyProviderNotification {
    /**
     * EventBridge event pattern for MediaPackage Key Provider Notification
     */
    static eventPattern(options?: MediaPackageKeyProviderNotification.MediaPackageKeyProviderNotificationProps): events.EventPattern;
}
export declare namespace MediaPackageKeyProviderNotification {
    /**
     * Props type for aws.mediapackage@MediaPackageKeyProviderNotification event
     */
    interface MediaPackageKeyProviderNotificationProps {
        /**
         * event property
         *
         * Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly event?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.mediapackage@MediaPackageHarvestJobNotification
 */
export declare class MediaPackageHarvestJobNotification {
    /**
     * EventBridge event pattern for MediaPackage HarvestJob Notification
     */
    static eventPattern(options?: MediaPackageHarvestJobNotification.MediaPackageHarvestJobNotificationProps): events.EventPattern;
}
export declare namespace MediaPackageHarvestJobNotification {
    /**
     * Props type for aws.mediapackage@MediaPackageHarvestJobNotification event
     */
    interface MediaPackageHarvestJobNotificationProps {
        /**
         * harvest_job property
         *
         * Specify an array of string values to match this event if the actual value of harvest_job is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly harvestJob?: MediaPackageHarvestJobNotification.HarvestJob;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Harvest_job
     *
     * @struct
     */
    interface HarvestJob {
        /**
         * s3_destination property
         *
         * Specify an array of string values to match this event if the actual value of s3_destination is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Destination?: MediaPackageHarvestJobNotification.S3Destination;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * created_at property
         *
         * Specify an array of string values to match this event if the actual value of created_at is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createdAt?: Array<string>;
        /**
         * end_time property
         *
         * Specify an array of string values to match this event if the actual value of end_time is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * origin_endpoint_id property
         *
         * Specify an array of string values to match this event if the actual value of origin_endpoint_id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the OriginEndpoint reference
         */
        readonly originEndpointId?: Array<string>;
        /**
         * start_time property
         *
         * Specify an array of string values to match this event if the actual value of start_time is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
    }
    /**
     * Type definition for S3_destination
     *
     * @struct
     */
    interface S3Destination {
        /**
         * bucket_name property
         *
         * Specify an array of string values to match this event if the actual value of bucket_name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucketName?: Array<string>;
        /**
         * manifest_key property
         *
         * Specify an array of string values to match this event if the actual value of manifest_key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly manifestKey?: Array<string>;
        /**
         * role_arn property
         *
         * Specify an array of string values to match this event if the actual value of role_arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly roleArn?: Array<string>;
    }
}
/**
 * EventBridge event patterns for OriginEndpoint
 */
export declare class OriginEndpointEvents {
    /**
     * Create OriginEndpointEvents from a OriginEndpoint reference
     */
    static fromOriginEndpoint(originEndpointRef: service.IOriginEndpointRef): OriginEndpointEvents;
    /**
     * Reference to the OriginEndpoint construct
     */
    private readonly originEndpointRef;
    private constructor();
    /**
     * EventBridge event pattern for OriginEndpoint MediaPackage HarvestJob Notification
     */
    mediaPackageHarvestJobNotificationPattern(options?: MediaPackageHarvestJobNotification.MediaPackageHarvestJobNotificationProps): events.EventPattern;
}
