import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.events@ScheduledJson
 */
export declare class ScheduledJson {
    /**
     * EventBridge event pattern for Scheduled Event
     */
    static eventPattern(options?: ScheduledJson.ScheduledJsonProps): events.EventPattern;
}
export declare namespace ScheduledJson {
    /**
     * Props type for aws.events@ScheduledJson event
     */
    interface ScheduledJsonProps {
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
