import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-cloudwatch";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.cloudwatch@CloudWatchAlarmConfigurationChange
 */
export declare class CloudWatchAlarmConfigurationChange {
    /**
     * EventBridge event pattern for CloudWatch Alarm Configuration Change
     */
    static eventPattern(options?: CloudWatchAlarmConfigurationChange.CloudWatchAlarmConfigurationChangeProps): events.EventPattern;
}
export declare namespace CloudWatchAlarmConfigurationChange {
    /**
     * Props type for aws.cloudwatch@CloudWatchAlarmConfigurationChange event
     */
    interface CloudWatchAlarmConfigurationChangeProps {
        /**
         * alarmName property
         *
         * Specify an array of string values to match this event if the actual value of alarmName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alarmName?: Array<string>;
        /**
         * operation property
         *
         * Specify an array of string values to match this event if the actual value of operation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly operation?: Array<string>;
        /**
         * configuration property
         *
         * Specify an array of string values to match this event if the actual value of configuration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly configuration?: CloudWatchAlarmConfigurationChange.Configuration;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: CloudWatchAlarmConfigurationChange.State;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Configuration
     *
     * @struct
     */
    interface Configuration {
        /**
         * alarmName property
         *
         * Specify an array of string values to match this event if the actual value of alarmName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Alarm reference
         */
        readonly alarmName?: Array<string>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * actionsEnabled property
         *
         * Specify an array of string values to match this event if the actual value of actionsEnabled is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionsEnabled?: Array<string>;
        /**
         * timestamp property
         *
         * Specify an array of string values to match this event if the actual value of timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly timestamp?: Array<string>;
        /**
         * evaluationPeriods property
         *
         * Specify an array of string values to match this event if the actual value of evaluationPeriods is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly evaluationPeriods?: Array<string>;
        /**
         * datapointsToAlarm property
         *
         * Specify an array of string values to match this event if the actual value of datapointsToAlarm is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datapointsToAlarm?: Array<string>;
        /**
         * threshold property
         *
         * Specify an array of string values to match this event if the actual value of threshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threshold?: Array<string>;
        /**
         * comparisonOperator property
         *
         * Specify an array of string values to match this event if the actual value of comparisonOperator is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly comparisonOperator?: Array<string>;
        /**
         * treatMissingData property
         *
         * Specify an array of string values to match this event if the actual value of treatMissingData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly treatMissingData?: Array<string>;
        /**
         * evaluateLowSampleCountPercentile property
         *
         * Specify an array of string values to match this event if the actual value of evaluateLowSampleCountPercentile is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly evaluateLowSampleCountPercentile?: Array<string>;
        /**
         * metrics property
         *
         * Specify an array of string values to match this event if the actual value of metrics is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metrics?: Array<CloudWatchAlarmConfigurationChange.ConfigurationItem>;
        /**
         * alarmRule property
         *
         * Specify an array of string values to match this event if the actual value of alarmRule is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alarmRule?: Array<string>;
        /**
         * okActions property
         *
         * Specify an array of string values to match this event if the actual value of okActions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly okActions?: Array<string>;
        /**
         * alarmActions property
         *
         * Specify an array of string values to match this event if the actual value of alarmActions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alarmActions?: Array<string>;
        /**
         * insufficientDataActions property
         *
         * Specify an array of string values to match this event if the actual value of insufficientDataActions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insufficientDataActions?: Array<string>;
        /**
         * actionsSuppressor property
         *
         * Specify an array of string values to match this event if the actual value of actionsSuppressor is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionsSuppressor?: Array<string>;
        /**
         * actionsSuppressorWaitPeriod property
         *
         * Specify an array of string values to match this event if the actual value of actionsSuppressorWaitPeriod is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionsSuppressorWaitPeriod?: Array<string>;
        /**
         * actionsSuppressorExtensionPeriod property
         *
         * Specify an array of string values to match this event if the actual value of actionsSuppressorExtensionPeriod is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionsSuppressorExtensionPeriod?: Array<string>;
    }
    /**
     * Type definition for ConfigurationItem
     *
     * @struct
     */
    interface ConfigurationItem {
        /**
         * metricStat property
         *
         * Specify an array of string values to match this event if the actual value of metricStat is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricStat?: CloudWatchAlarmConfigurationChange.MetricStat;
        /**
         * returnData property
         *
         * Specify an array of string values to match this event if the actual value of returnData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly returnData?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
    }
    /**
     * Type definition for MetricStat
     *
     * @struct
     */
    interface MetricStat {
        /**
         * metric property
         *
         * Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metric?: CloudWatchAlarmConfigurationChange.Metric;
        /**
         * period property
         *
         * Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly period?: Array<string>;
        /**
         * stat property
         *
         * Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stat?: Array<string>;
    }
    /**
     * Type definition for Metric
     *
     * @struct
     */
    interface Metric {
        /**
         * dimensions property
         *
         * Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dimensions?: Array<string>;
        /**
         * namespace property
         *
         * Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly namespace?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for State
     *
     * @struct
     */
    interface State {
        /**
         * reason property
         *
         * Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reason?: Array<string>;
        /**
         * reasonData property
         *
         * Specify an array of string values to match this event if the actual value of reasonData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reasonData?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
        /**
         * timestamp property
         *
         * Specify an array of string values to match this event if the actual value of timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly timestamp?: Array<string>;
        /**
         * actionsSuppressedBy property
         *
         * Specify an array of string values to match this event if the actual value of actionsSuppressedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionsSuppressedBy?: Array<string>;
        /**
         * evaluationState property
         *
         * Specify an array of string values to match this event if the actual value of evaluationState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly evaluationState?: Array<string>;
    }
}
/**
 * EventBridge event patterns for Alarm
 */
export declare class AlarmEvents {
    /**
     * Create AlarmEvents from a Alarm reference
     */
    static fromAlarm(alarmRef: service.IAlarmRef): AlarmEvents;
    /**
     * Reference to the Alarm construct
     */
    private readonly alarmRef;
    private constructor();
    /**
     * EventBridge event pattern for Alarm CloudWatch Alarm Configuration Change
     */
    cloudWatchAlarmConfigurationChangePattern(options?: CloudWatchAlarmConfigurationChange.CloudWatchAlarmConfigurationChangeProps): events.EventPattern;
    /**
     * EventBridge event pattern for Alarm CloudWatch Alarm State Change
     */
    cloudWatchAlarmStateChangePattern(options?: CloudWatchAlarmStateChange.CloudWatchAlarmStateChangeProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.cloudwatch@CloudWatchAlarmStateChange
 */
export declare class CloudWatchAlarmStateChange {
    /**
     * EventBridge event pattern for CloudWatch Alarm State Change
     */
    static eventPattern(options?: CloudWatchAlarmStateChange.CloudWatchAlarmStateChangeProps): events.EventPattern;
}
export declare namespace CloudWatchAlarmStateChange {
    /**
     * Props type for aws.cloudwatch@CloudWatchAlarmStateChange event
     */
    interface CloudWatchAlarmStateChangeProps {
        /**
         * configuration property
         *
         * Specify an array of string values to match this event if the actual value of configuration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly configuration?: CloudWatchAlarmStateChange.Configuration;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: CloudWatchAlarmStateChange.State;
        /**
         * previousState property
         *
         * Specify an array of string values to match this event if the actual value of previousState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousState?: CloudWatchAlarmStateChange.State;
        /**
         * alarmName property
         *
         * Specify an array of string values to match this event if the actual value of alarmName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Alarm reference
         */
        readonly alarmName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Configuration
     *
     * @struct
     */
    interface Configuration {
        /**
         * metrics property
         *
         * Specify an array of string values to match this event if the actual value of metrics is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metrics?: Array<CloudWatchAlarmStateChange.ConfigurationItem>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * alarmRule property
         *
         * Specify an array of string values to match this event if the actual value of alarmRule is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alarmRule?: Array<string>;
        /**
         * actionsSuppressor property
         *
         * Specify an array of string values to match this event if the actual value of actionsSuppressor is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionsSuppressor?: Array<string>;
        /**
         * actionsSuppressorWaitPeriod property
         *
         * Specify an array of string values to match this event if the actual value of actionsSuppressorWaitPeriod is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionsSuppressorWaitPeriod?: Array<string>;
        /**
         * actionsSuppressorExtensionPeriod property
         *
         * Specify an array of string values to match this event if the actual value of actionsSuppressorExtensionPeriod is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionsSuppressorExtensionPeriod?: Array<string>;
    }
    /**
     * Type definition for ConfigurationItem
     *
     * @struct
     */
    interface ConfigurationItem {
        /**
         * metricStat property
         *
         * Specify an array of string values to match this event if the actual value of metricStat is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricStat?: CloudWatchAlarmStateChange.MetricStat;
        /**
         * returnData property
         *
         * Specify an array of string values to match this event if the actual value of returnData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly returnData?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
    }
    /**
     * Type definition for MetricStat
     *
     * @struct
     */
    interface MetricStat {
        /**
         * metric property
         *
         * Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metric?: CloudWatchAlarmStateChange.Metric;
        /**
         * period property
         *
         * Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly period?: Array<string>;
        /**
         * stat property
         *
         * Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stat?: Array<string>;
    }
    /**
     * Type definition for Metric
     *
     * @struct
     */
    interface Metric {
        /**
         * dimensions property
         *
         * Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dimensions?: Array<string>;
        /**
         * namespace property
         *
         * Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly namespace?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for State
     *
     * @struct
     */
    interface State {
        /**
         * reason property
         *
         * Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reason?: Array<string>;
        /**
         * reasonData property
         *
         * Specify an array of string values to match this event if the actual value of reasonData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reasonData?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
        /**
         * timestamp property
         *
         * Specify an array of string values to match this event if the actual value of timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly timestamp?: Array<string>;
        /**
         * actionsSuppressedBy property
         *
         * Specify an array of string values to match this event if the actual value of actionsSuppressedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionsSuppressedBy?: Array<string>;
        /**
         * actionsSuppressedReason property
         *
         * Specify an array of string values to match this event if the actual value of actionsSuppressedReason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionsSuppressedReason?: Array<string>;
        /**
         * evaluationState property
         *
         * Specify an array of string values to match this event if the actual value of evaluationState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly evaluationState?: Array<string>;
    }
}
