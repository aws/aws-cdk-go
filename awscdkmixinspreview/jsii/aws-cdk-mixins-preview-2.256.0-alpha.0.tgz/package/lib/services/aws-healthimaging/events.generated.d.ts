import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-healthimaging";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.healthimaging@DataStoreCreated
 */
export declare class DataStoreCreated {
    /**
     * EventBridge event pattern for Data Store Created
     */
    static eventPattern(options?: DataStoreCreated.DataStoreCreatedProps): events.EventPattern;
}
export declare namespace DataStoreCreated {
    /**
     * Props type for aws.healthimaging@DataStoreCreated event
     */
    interface DataStoreCreatedProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * datastoreName property
         *
         * Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreName?: Array<string>;
        /**
         * datastoreStatus property
         *
         * Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event patterns for Datastore
 */
export declare class DatastoreEvents {
    /**
     * Create DatastoreEvents from a Datastore reference
     */
    static fromDatastore(datastoreRef: service.IDatastoreRef): DatastoreEvents;
    /**
     * Reference to the Datastore construct
     */
    private readonly datastoreRef;
    private constructor();
    /**
     * EventBridge event pattern for Datastore Data Store Created
     */
    dataStoreCreatedPattern(options?: DataStoreCreated.DataStoreCreatedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Data Store Creating
     */
    dataStoreCreatingPattern(options?: DataStoreCreating.DataStoreCreatingProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Data Store Creation Failed
     */
    dataStoreCreationFailedPattern(options?: DataStoreCreationFailed.DataStoreCreationFailedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Data Store Deleted
     */
    dataStoreDeletedPattern(options?: DataStoreDeleted.DataStoreDeletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Data Store Deleting
     */
    dataStoreDeletingPattern(options?: DataStoreDeleting.DataStoreDeletingProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Image Set Copied
     */
    imageSetCopiedPattern(options?: ImageSetCopied.ImageSetCopiedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Image Set Copy Failed
     */
    imageSetCopyFailedPattern(options?: ImageSetCopyFailed.ImageSetCopyFailedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Image Set Copying
     */
    imageSetCopyingPattern(options?: ImageSetCopying.ImageSetCopyingProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Image Set Copying With Read Only Access
     */
    imageSetCopyingWithReadOnlyAccessPattern(options?: ImageSetCopyingWithReadOnlyAccess.ImageSetCopyingWithReadOnlyAccessProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Image Set Created
     */
    imageSetCreatedPattern(options?: ImageSetCreated.ImageSetCreatedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Image Set Deleted
     */
    imageSetDeletedPattern(options?: ImageSetDeleted.ImageSetDeletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Image Set Deleting
     */
    imageSetDeletingPattern(options?: ImageSetDeleting.ImageSetDeletingProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Image Set Updated
     */
    imageSetUpdatedPattern(options?: ImageSetUpdated.ImageSetUpdatedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Image Set Update Failed
     */
    imageSetUpdateFailedPattern(options?: ImageSetUpdateFailed.ImageSetUpdateFailedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Image Set Updating
     */
    imageSetUpdatingPattern(options?: ImageSetUpdating.ImageSetUpdatingProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Import Job Completed
     */
    importJobCompletedPattern(options?: ImportJobCompleted.ImportJobCompletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Import Job Failed
     */
    importJobFailedPattern(options?: ImportJobFailed.ImportJobFailedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Import Job In Progress
     */
    importJobInProgressPattern(options?: ImportJobInProgress.ImportJobInProgressProps): events.EventPattern;
    /**
     * EventBridge event pattern for Datastore Import Job Submitted
     */
    importJobSubmittedPattern(options?: ImportJobSubmitted.ImportJobSubmittedProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.healthimaging@DataStoreCreating
 */
export declare class DataStoreCreating {
    /**
     * EventBridge event pattern for Data Store Creating
     */
    static eventPattern(options?: DataStoreCreating.DataStoreCreatingProps): events.EventPattern;
}
export declare namespace DataStoreCreating {
    /**
     * Props type for aws.healthimaging@DataStoreCreating event
     */
    interface DataStoreCreatingProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * datastoreName property
         *
         * Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreName?: Array<string>;
        /**
         * datastoreStatus property
         *
         * Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@DataStoreCreationFailed
 */
export declare class DataStoreCreationFailed {
    /**
     * EventBridge event pattern for Data Store Creation Failed
     */
    static eventPattern(options?: DataStoreCreationFailed.DataStoreCreationFailedProps): events.EventPattern;
}
export declare namespace DataStoreCreationFailed {
    /**
     * Props type for aws.healthimaging@DataStoreCreationFailed event
     */
    interface DataStoreCreationFailedProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * datastoreName property
         *
         * Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreName?: Array<string>;
        /**
         * datastoreStatus property
         *
         * Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@DataStoreDeleted
 */
export declare class DataStoreDeleted {
    /**
     * EventBridge event pattern for Data Store Deleted
     */
    static eventPattern(options?: DataStoreDeleted.DataStoreDeletedProps): events.EventPattern;
}
export declare namespace DataStoreDeleted {
    /**
     * Props type for aws.healthimaging@DataStoreDeleted event
     */
    interface DataStoreDeletedProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * datastoreName property
         *
         * Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreName?: Array<string>;
        /**
         * datastoreStatus property
         *
         * Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@DataStoreDeleting
 */
export declare class DataStoreDeleting {
    /**
     * EventBridge event pattern for Data Store Deleting
     */
    static eventPattern(options?: DataStoreDeleting.DataStoreDeletingProps): events.EventPattern;
}
export declare namespace DataStoreDeleting {
    /**
     * Props type for aws.healthimaging@DataStoreDeleting event
     */
    interface DataStoreDeletingProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * datastoreName property
         *
         * Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreName?: Array<string>;
        /**
         * datastoreStatus property
         *
         * Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImageSetCopied
 */
export declare class ImageSetCopied {
    /**
     * EventBridge event pattern for Image Set Copied
     */
    static eventPattern(options?: ImageSetCopied.ImageSetCopiedProps): events.EventPattern;
}
export declare namespace ImageSetCopied {
    /**
     * Props type for aws.healthimaging@ImageSetCopied event
     */
    interface ImageSetCopiedProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imageSetId property
         *
         * Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetId?: Array<string>;
        /**
         * imageSetState property
         *
         * Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetState?: Array<string>;
        /**
         * imageSetWorkflowStatus property
         *
         * Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetWorkflowStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImageSetCopyFailed
 */
export declare class ImageSetCopyFailed {
    /**
     * EventBridge event pattern for Image Set Copy Failed
     */
    static eventPattern(options?: ImageSetCopyFailed.ImageSetCopyFailedProps): events.EventPattern;
}
export declare namespace ImageSetCopyFailed {
    /**
     * Props type for aws.healthimaging@ImageSetCopyFailed event
     */
    interface ImageSetCopyFailedProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imageSetId property
         *
         * Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetId?: Array<string>;
        /**
         * imageSetState property
         *
         * Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetState?: Array<string>;
        /**
         * imageSetWorkflowStatus property
         *
         * Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetWorkflowStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImageSetCopying
 */
export declare class ImageSetCopying {
    /**
     * EventBridge event pattern for Image Set Copying
     */
    static eventPattern(options?: ImageSetCopying.ImageSetCopyingProps): events.EventPattern;
}
export declare namespace ImageSetCopying {
    /**
     * Props type for aws.healthimaging@ImageSetCopying event
     */
    interface ImageSetCopyingProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imageSetId property
         *
         * Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetId?: Array<string>;
        /**
         * imageSetState property
         *
         * Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetState?: Array<string>;
        /**
         * imageSetWorkflowStatus property
         *
         * Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetWorkflowStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImageSetCopyingWithReadOnlyAccess
 */
export declare class ImageSetCopyingWithReadOnlyAccess {
    /**
     * EventBridge event pattern for Image Set Copying With Read Only Access
     */
    static eventPattern(options?: ImageSetCopyingWithReadOnlyAccess.ImageSetCopyingWithReadOnlyAccessProps): events.EventPattern;
}
export declare namespace ImageSetCopyingWithReadOnlyAccess {
    /**
     * Props type for aws.healthimaging@ImageSetCopyingWithReadOnlyAccess event
     */
    interface ImageSetCopyingWithReadOnlyAccessProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imageSetId property
         *
         * Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetId?: Array<string>;
        /**
         * imageSetState property
         *
         * Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetState?: Array<string>;
        /**
         * imageSetWorkflowStatus property
         *
         * Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetWorkflowStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImageSetCreated
 */
export declare class ImageSetCreated {
    /**
     * EventBridge event pattern for Image Set Created
     */
    static eventPattern(options?: ImageSetCreated.ImageSetCreatedProps): events.EventPattern;
}
export declare namespace ImageSetCreated {
    /**
     * Props type for aws.healthimaging@ImageSetCreated event
     */
    interface ImageSetCreatedProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imageSetId property
         *
         * Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetId?: Array<string>;
        /**
         * imageSetState property
         *
         * Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetState?: Array<string>;
        /**
         * imageSetWorkflowStatus property
         *
         * Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetWorkflowStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImageSetDeleted
 */
export declare class ImageSetDeleted {
    /**
     * EventBridge event pattern for Image Set Deleted
     */
    static eventPattern(options?: ImageSetDeleted.ImageSetDeletedProps): events.EventPattern;
}
export declare namespace ImageSetDeleted {
    /**
     * Props type for aws.healthimaging@ImageSetDeleted event
     */
    interface ImageSetDeletedProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imageSetId property
         *
         * Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetId?: Array<string>;
        /**
         * imageSetState property
         *
         * Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetState?: Array<string>;
        /**
         * imageSetWorkflowStatus property
         *
         * Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetWorkflowStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImageSetDeleting
 */
export declare class ImageSetDeleting {
    /**
     * EventBridge event pattern for Image Set Deleting
     */
    static eventPattern(options?: ImageSetDeleting.ImageSetDeletingProps): events.EventPattern;
}
export declare namespace ImageSetDeleting {
    /**
     * Props type for aws.healthimaging@ImageSetDeleting event
     */
    interface ImageSetDeletingProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imageSetId property
         *
         * Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetId?: Array<string>;
        /**
         * imageSetState property
         *
         * Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetState?: Array<string>;
        /**
         * imageSetWorkflowStatus property
         *
         * Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetWorkflowStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImageSetUpdated
 */
export declare class ImageSetUpdated {
    /**
     * EventBridge event pattern for Image Set Updated
     */
    static eventPattern(options?: ImageSetUpdated.ImageSetUpdatedProps): events.EventPattern;
}
export declare namespace ImageSetUpdated {
    /**
     * Props type for aws.healthimaging@ImageSetUpdated event
     */
    interface ImageSetUpdatedProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imageSetId property
         *
         * Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetId?: Array<string>;
        /**
         * imageSetState property
         *
         * Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetState?: Array<string>;
        /**
         * imageSetWorkflowStatus property
         *
         * Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetWorkflowStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImageSetUpdateFailed
 */
export declare class ImageSetUpdateFailed {
    /**
     * EventBridge event pattern for Image Set Update Failed
     */
    static eventPattern(options?: ImageSetUpdateFailed.ImageSetUpdateFailedProps): events.EventPattern;
}
export declare namespace ImageSetUpdateFailed {
    /**
     * Props type for aws.healthimaging@ImageSetUpdateFailed event
     */
    interface ImageSetUpdateFailedProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imageSetId property
         *
         * Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetId?: Array<string>;
        /**
         * imageSetState property
         *
         * Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetState?: Array<string>;
        /**
         * imageSetWorkflowStatus property
         *
         * Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetWorkflowStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImageSetUpdating
 */
export declare class ImageSetUpdating {
    /**
     * EventBridge event pattern for Image Set Updating
     */
    static eventPattern(options?: ImageSetUpdating.ImageSetUpdatingProps): events.EventPattern;
}
export declare namespace ImageSetUpdating {
    /**
     * Props type for aws.healthimaging@ImageSetUpdating event
     */
    interface ImageSetUpdatingProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imageSetId property
         *
         * Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetId?: Array<string>;
        /**
         * imageSetState property
         *
         * Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetState?: Array<string>;
        /**
         * imageSetWorkflowStatus property
         *
         * Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageSetWorkflowStatus?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImportJobCompleted
 */
export declare class ImportJobCompleted {
    /**
     * EventBridge event pattern for Import Job Completed
     */
    static eventPattern(options?: ImportJobCompleted.ImportJobCompletedProps): events.EventPattern;
}
export declare namespace ImportJobCompleted {
    /**
     * Props type for aws.healthimaging@ImportJobCompleted event
     */
    interface ImportJobCompletedProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * inputS3Uri property
         *
         * Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputS3Uri?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * jobName property
         *
         * Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobName?: Array<string>;
        /**
         * jobStatus property
         *
         * Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobStatus?: Array<string>;
        /**
         * outputS3Uri property
         *
         * Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputS3Uri?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImportJobFailed
 */
export declare class ImportJobFailed {
    /**
     * EventBridge event pattern for Import Job Failed
     */
    static eventPattern(options?: ImportJobFailed.ImportJobFailedProps): events.EventPattern;
}
export declare namespace ImportJobFailed {
    /**
     * Props type for aws.healthimaging@ImportJobFailed event
     */
    interface ImportJobFailedProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * inputS3Uri property
         *
         * Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputS3Uri?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * jobName property
         *
         * Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobName?: Array<string>;
        /**
         * jobStatus property
         *
         * Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobStatus?: Array<string>;
        /**
         * outputS3Uri property
         *
         * Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputS3Uri?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImportJobInProgress
 */
export declare class ImportJobInProgress {
    /**
     * EventBridge event pattern for Import Job In Progress
     */
    static eventPattern(options?: ImportJobInProgress.ImportJobInProgressProps): events.EventPattern;
}
export declare namespace ImportJobInProgress {
    /**
     * Props type for aws.healthimaging@ImportJobInProgress event
     */
    interface ImportJobInProgressProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * inputS3Uri property
         *
         * Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputS3Uri?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * jobName property
         *
         * Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobName?: Array<string>;
        /**
         * jobStatus property
         *
         * Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobStatus?: Array<string>;
        /**
         * outputS3Uri property
         *
         * Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputS3Uri?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.healthimaging@ImportJobSubmitted
 */
export declare class ImportJobSubmitted {
    /**
     * EventBridge event pattern for Import Job Submitted
     */
    static eventPattern(options?: ImportJobSubmitted.ImportJobSubmittedProps): events.EventPattern;
}
export declare namespace ImportJobSubmitted {
    /**
     * Props type for aws.healthimaging@ImportJobSubmitted event
     */
    interface ImportJobSubmittedProps {
        /**
         * datastoreId property
         *
         * Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Datastore reference
         */
        readonly datastoreId?: Array<string>;
        /**
         * imagingVersion property
         *
         * Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagingVersion?: Array<string>;
        /**
         * inputS3Uri property
         *
         * Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputS3Uri?: Array<string>;
        /**
         * jobId property
         *
         * Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobId?: Array<string>;
        /**
         * jobName property
         *
         * Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobName?: Array<string>;
        /**
         * jobStatus property
         *
         * Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobStatus?: Array<string>;
        /**
         * outputS3Uri property
         *
         * Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputS3Uri?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
