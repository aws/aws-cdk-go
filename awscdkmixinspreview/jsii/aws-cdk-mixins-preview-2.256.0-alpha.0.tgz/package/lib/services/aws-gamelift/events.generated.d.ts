import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.gamelift@GameLiftMatchmakingEvent
 */
export declare class GameLiftMatchmakingEvent {
    /**
     * EventBridge event pattern for GameLift Matchmaking Event
     */
    static eventPattern(options?: GameLiftMatchmakingEvent.GameLiftMatchmakingEventProps): events.EventPattern;
}
export declare namespace GameLiftMatchmakingEvent {
    /**
     * Props type for aws.gamelift@GameLiftMatchmakingEvent event
     */
    interface GameLiftMatchmakingEventProps {
        /**
         * gameSessionInfo property
         *
         * Specify an array of string values to match this event if the actual value of gameSessionInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly gameSessionInfo?: GameLiftMatchmakingEvent.GameSessionInfo;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * reason property
         *
         * Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reason?: Array<string>;
        /**
         * ruleEvaluationMetrics property
         *
         * Specify an array of string values to match this event if the actual value of ruleEvaluationMetrics is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ruleEvaluationMetrics?: Array<GameLiftMatchmakingEvent.RuleEvaluationMetrics>;
        /**
         * tickets property
         *
         * Specify an array of string values to match this event if the actual value of tickets is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tickets?: Array<GameLiftMatchmakingEvent.Ticket>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * estimatedWaitMillis property
         *
         * Specify an array of string values to match this event if the actual value of estimatedWaitMillis is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly estimatedWaitMillis?: Array<string>;
        /**
         * acceptanceTimeout property
         *
         * Specify an array of string values to match this event if the actual value of acceptanceTimeout is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly acceptanceTimeout?: Array<string>;
        /**
         * acceptanceRequired property
         *
         * Specify an array of string values to match this event if the actual value of acceptanceRequired is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly acceptanceRequired?: Array<string>;
        /**
         * matchId property
         *
         * Specify an array of string values to match this event if the actual value of matchId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly matchId?: Array<string>;
        /**
         * customEventData property
         *
         * Specify an array of string values to match this event if the actual value of customEventData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly customEventData?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for GameSessionInfo
     *
     * @struct
     */
    interface GameSessionInfo {
        /**
         * players property
         *
         * Specify an array of string values to match this event if the actual value of players is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly players?: Array<GameLiftMatchmakingEvent.GameSessionInfoItem>;
        /**
         * gameSessionArn property
         *
         * Specify an array of string values to match this event if the actual value of gameSessionArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly gameSessionArn?: Array<string>;
        /**
         * ipAddress property
         *
         * Specify an array of string values to match this event if the actual value of ipAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipAddress?: Array<string>;
        /**
         * port property
         *
         * Specify an array of string values to match this event if the actual value of port is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly port?: Array<string>;
    }
    /**
     * Type definition for GameSessionInfoItem
     *
     * @struct
     */
    interface GameSessionInfoItem {
        /**
         * playerId property
         *
         * Specify an array of string values to match this event if the actual value of playerId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly playerId?: Array<string>;
        /**
         * team property
         *
         * Specify an array of string values to match this event if the actual value of team is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly team?: Array<string>;
    }
    /**
     * Type definition for RuleEvaluationMetrics
     *
     * @struct
     */
    interface RuleEvaluationMetrics {
        /**
         * failedCount property
         *
         * Specify an array of string values to match this event if the actual value of failedCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failedCount?: Array<string>;
        /**
         * passedCount property
         *
         * Specify an array of string values to match this event if the actual value of passedCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly passedCount?: Array<string>;
        /**
         * ruleName property
         *
         * Specify an array of string values to match this event if the actual value of ruleName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ruleName?: Array<string>;
    }
    /**
     * Type definition for Ticket
     *
     * @struct
     */
    interface Ticket {
        /**
         * players property
         *
         * Specify an array of string values to match this event if the actual value of players is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly players?: Array<GameLiftMatchmakingEvent.GameSessionInfoItem>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * ticketId property
         *
         * Specify an array of string values to match this event if the actual value of ticketId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ticketId?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.gamelift@GameLiftQueuePlacementEvent
 */
export declare class GameLiftQueuePlacementEvent {
    /**
     * EventBridge event pattern for GameLift Queue Placement Event
     */
    static eventPattern(options?: GameLiftQueuePlacementEvent.GameLiftQueuePlacementEventProps): events.EventPattern;
}
export declare namespace GameLiftQueuePlacementEvent {
    /**
     * Props type for aws.gamelift@GameLiftQueuePlacementEvent event
     */
    interface GameLiftQueuePlacementEventProps {
        /**
         * dnsName property
         *
         * Specify an array of string values to match this event if the actual value of dnsName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dnsName?: Array<string>;
        /**
         * endTime property
         *
         * Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * gameSessionArn property
         *
         * Specify an array of string values to match this event if the actual value of gameSessionArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly gameSessionArn?: Array<string>;
        /**
         * gameSessionRegion property
         *
         * Specify an array of string values to match this event if the actual value of gameSessionRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly gameSessionRegion?: Array<string>;
        /**
         * ipAddress property
         *
         * Specify an array of string values to match this event if the actual value of ipAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipAddress?: Array<string>;
        /**
         * placedPlayerSessions property
         *
         * Specify an array of string values to match this event if the actual value of placedPlayerSessions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly placedPlayerSessions?: Array<GameLiftQueuePlacementEvent.GameLiftQueuePlacementEventItem>;
        /**
         * placementId property
         *
         * Specify an array of string values to match this event if the actual value of placementId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly placementId?: Array<string>;
        /**
         * port property
         *
         * Specify an array of string values to match this event if the actual value of port is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly port?: Array<string>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for GameLiftQueuePlacementEventItem
     *
     * @struct
     */
    interface GameLiftQueuePlacementEventItem {
        /**
         * playerId property
         *
         * Specify an array of string values to match this event if the actual value of playerId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly playerId?: Array<string>;
        /**
         * playerSessionId property
         *
         * Specify an array of string values to match this event if the actual value of playerSessionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly playerSessionId?: Array<string>;
    }
}
