import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-codebuild";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.codebuild@AWSAPICallViaCloudTrail
 */
export declare class AWSAPICallViaCloudTrail {
    /**
     * EventBridge event pattern for AWS API Call via CloudTrail
     */
    static eventPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
}
export declare namespace AWSAPICallViaCloudTrail {
    /**
     * Props type for aws.codebuild@AWSAPICallViaCloudTrail event
     */
    interface AWSAPICallViaCloudTrailProps {
        /**
         * requestParameters property
         *
         * Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestParameters?: AWSAPICallViaCloudTrail.RequestParameters;
        /**
         * responseElements property
         *
         * Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly responseElements?: AWSAPICallViaCloudTrail.ResponseElements;
        /**
         * userIdentity property
         *
         * Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userIdentity?: AWSAPICallViaCloudTrail.UserIdentity;
        /**
         * awsRegion property
         *
         * Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsRegion?: Array<string>;
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * eventID property
         *
         * Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * eventSource property
         *
         * Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventSource?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * eventVersion property
         *
         * Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventVersion?: Array<string>;
        /**
         * requestID property
         *
         * Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * sourceIPAddress property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for RequestParameters
     *
     * @struct
     */
    interface RequestParameters {
        /**
         * awsActId property
         *
         * Specify an array of string values to match this event if the actual value of awsActId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsActId?: Array<string>;
        /**
         * invokedBy property
         *
         * Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly invokedBy?: Array<string>;
        /**
         * payerId property
         *
         * Specify an array of string values to match this event if the actual value of payerId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly payerId?: Array<string>;
        /**
         * userArn property
         *
         * Specify an array of string values to match this event if the actual value of userArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userArn?: Array<string>;
    }
    /**
     * Type definition for ResponseElements
     *
     * @struct
     */
    interface ResponseElements {
        /**
         * build property
         *
         * Specify an array of string values to match this event if the actual value of build is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildProperty?: AWSAPICallViaCloudTrail.Build;
        /**
         * project property
         *
         * Specify an array of string values to match this event if the actual value of project is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly project?: AWSAPICallViaCloudTrail.Project;
        /**
         * webhook property
         *
         * Specify an array of string values to match this event if the actual value of webhook is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly webhook?: AWSAPICallViaCloudTrail.Webhook;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * webhookDeletedStatus property
         *
         * Specify an array of string values to match this event if the actual value of webhookDeletedStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly webhookDeletedStatus?: Array<string>;
    }
    /**
     * Type definition for Build
     *
     * @struct
     */
    interface Build {
        /**
         * artifacts property
         *
         * Specify an array of string values to match this event if the actual value of artifacts is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly artifacts?: AWSAPICallViaCloudTrail.Artifacts;
        /**
         * cache property
         *
         * Specify an array of string values to match this event if the actual value of cache is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cache?: AWSAPICallViaCloudTrail.Cache;
        /**
         * environment property
         *
         * Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly environment?: AWSAPICallViaCloudTrail.Environment;
        /**
         * logs property
         *
         * Specify an array of string values to match this event if the actual value of logs is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly logs?: AWSAPICallViaCloudTrail.Logs;
        /**
         * source property
         *
         * Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly source?: AWSAPICallViaCloudTrail.Source;
        /**
         * vpcConfig property
         *
         * Specify an array of string values to match this event if the actual value of vpcConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcConfig?: AWSAPICallViaCloudTrail.VpcConfig;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * buildComplete property
         *
         * Specify an array of string values to match this event if the actual value of buildComplete is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildComplete?: Array<string>;
        /**
         * buildStatus property
         *
         * Specify an array of string values to match this event if the actual value of buildStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildStatus?: Array<string>;
        /**
         * currentPhase property
         *
         * Specify an array of string values to match this event if the actual value of currentPhase is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentPhase?: Array<string>;
        /**
         * encryptionKey property
         *
         * Specify an array of string values to match this event if the actual value of encryptionKey is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly encryptionKey?: Array<string>;
        /**
         * endTime property
         *
         * Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * initiator property
         *
         * Specify an array of string values to match this event if the actual value of initiator is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly initiator?: Array<string>;
        /**
         * phases property
         *
         * Specify an array of string values to match this event if the actual value of phases is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly phases?: Array<AWSAPICallViaCloudTrail.BuildPhase>;
        /**
         * projectName property
         *
         * Specify an array of string values to match this event if the actual value of projectName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly projectName?: Array<string>;
        /**
         * queuedTimeoutInMinutes property
         *
         * Specify an array of string values to match this event if the actual value of queuedTimeoutInMinutes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queuedTimeoutInMinutes?: Array<string>;
        /**
         * resolvedSourceVersion property
         *
         * Specify an array of string values to match this event if the actual value of resolvedSourceVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resolvedSourceVersion?: Array<string>;
        /**
         * serviceRole property
         *
         * Specify an array of string values to match this event if the actual value of serviceRole is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serviceRole?: Array<string>;
        /**
         * sourceVersion property
         *
         * Specify an array of string values to match this event if the actual value of sourceVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceVersion?: Array<string>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * timeoutInMinutes property
         *
         * Specify an array of string values to match this event if the actual value of timeoutInMinutes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly timeoutInMinutes?: Array<string>;
    }
    /**
     * Type definition for Artifacts
     *
     * @struct
     */
    interface Artifacts {
        /**
         * encryptionDisabled property
         *
         * Specify an array of string values to match this event if the actual value of encryptionDisabled is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly encryptionDisabled?: Array<string>;
        /**
         * location property
         *
         * Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly location?: Array<string>;
    }
    /**
     * Type definition for Cache
     *
     * @struct
     */
    interface Cache {
        /**
         * location property
         *
         * Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly location?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Environment
     *
     * @struct
     */
    interface Environment {
        /**
         * certificate property
         *
         * Specify an array of string values to match this event if the actual value of certificate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly certificate?: Array<string>;
        /**
         * computeType property
         *
         * Specify an array of string values to match this event if the actual value of computeType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly computeType?: Array<string>;
        /**
         * environmentVariables property
         *
         * Specify an array of string values to match this event if the actual value of environmentVariables is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly environmentVariables?: Array<AWSAPICallViaCloudTrail.EnvironmentItem>;
        /**
         * image property
         *
         * Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly image?: Array<string>;
        /**
         * imagePullCredentialsType property
         *
         * Specify an array of string values to match this event if the actual value of imagePullCredentialsType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagePullCredentialsType?: Array<string>;
        /**
         * privilegedMode property
         *
         * Specify an array of string values to match this event if the actual value of privilegedMode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privilegedMode?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for EnvironmentItem
     *
     * @struct
     */
    interface EnvironmentItem {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for Logs
     *
     * @struct
     */
    interface Logs {
        /**
         * deepLink property
         *
         * Specify an array of string values to match this event if the actual value of deepLink is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deepLink?: Array<string>;
        /**
         * groupName property
         *
         * Specify an array of string values to match this event if the actual value of groupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupName?: Array<string>;
        /**
         * streamName property
         *
         * Specify an array of string values to match this event if the actual value of streamName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly streamName?: Array<string>;
    }
    /**
     * Type definition for Source
     *
     * @struct
     */
    interface Source {
        /**
         * auth property
         *
         * Specify an array of string values to match this event if the actual value of auth is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly auth?: AWSAPICallViaCloudTrail.Auth;
        /**
         * buildspec property
         *
         * Specify an array of string values to match this event if the actual value of buildspec is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildspec?: Array<string>;
        /**
         * insecureSsl property
         *
         * Specify an array of string values to match this event if the actual value of insecureSsl is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insecureSsl?: Array<string>;
        /**
         * location property
         *
         * Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly location?: Array<string>;
        /**
         * reportBuildStatus property
         *
         * Specify an array of string values to match this event if the actual value of reportBuildStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reportBuildStatus?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Auth
     *
     * @struct
     */
    interface Auth {
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for VpcConfig
     *
     * @struct
     */
    interface VpcConfig {
        /**
         * securityGroupIds property
         *
         * Specify an array of string values to match this event if the actual value of securityGroupIds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly securityGroupIds?: Array<string>;
        /**
         * subnets property
         *
         * Specify an array of string values to match this event if the actual value of subnets is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnets?: Array<string>;
        /**
         * vpcId property
         *
         * Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcId?: Array<string>;
    }
    /**
     * Type definition for BuildPhase
     *
     * @struct
     */
    interface BuildPhase {
        /**
         * durationInSeconds property
         *
         * Specify an array of string values to match this event if the actual value of durationInSeconds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly durationInSeconds?: Array<string>;
        /**
         * endTime property
         *
         * Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * phaseContext property
         *
         * Specify an array of string values to match this event if the actual value of phaseContext is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly phaseContext?: Array<string>;
        /**
         * phaseStatus property
         *
         * Specify an array of string values to match this event if the actual value of phaseStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly phaseStatus?: Array<string>;
        /**
         * phaseType property
         *
         * Specify an array of string values to match this event if the actual value of phaseType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly phaseType?: Array<string>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
    }
    /**
     * Type definition for Project
     *
     * @struct
     */
    interface Project {
        /**
         * artifacts property
         *
         * Specify an array of string values to match this event if the actual value of artifacts is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly artifacts?: AWSAPICallViaCloudTrail.Artifacts1;
        /**
         * badge property
         *
         * Specify an array of string values to match this event if the actual value of badge is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly badge?: AWSAPICallViaCloudTrail.Badge;
        /**
         * cache property
         *
         * Specify an array of string values to match this event if the actual value of cache is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cache?: AWSAPICallViaCloudTrail.Cache;
        /**
         * environment property
         *
         * Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly environment?: AWSAPICallViaCloudTrail.Environment1;
        /**
         * source property
         *
         * Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly source?: AWSAPICallViaCloudTrail.Source1;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * created property
         *
         * Specify an array of string values to match this event if the actual value of created is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly created?: Array<string>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * encryptionKey property
         *
         * Specify an array of string values to match this event if the actual value of encryptionKey is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly encryptionKey?: Array<string>;
        /**
         * lastModified property
         *
         * Specify an array of string values to match this event if the actual value of lastModified is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastModified?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * queuedTimeoutInMinutes property
         *
         * Specify an array of string values to match this event if the actual value of queuedTimeoutInMinutes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queuedTimeoutInMinutes?: Array<string>;
        /**
         * serviceRole property
         *
         * Specify an array of string values to match this event if the actual value of serviceRole is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serviceRole?: Array<string>;
        /**
         * sourceVersion property
         *
         * Specify an array of string values to match this event if the actual value of sourceVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceVersion?: Array<string>;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<AWSAPICallViaCloudTrail.ProjectItem>;
        /**
         * timeoutInMinutes property
         *
         * Specify an array of string values to match this event if the actual value of timeoutInMinutes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly timeoutInMinutes?: Array<string>;
    }
    /**
     * Type definition for Artifacts_1
     *
     * @struct
     */
    interface Artifacts1 {
        /**
         * encryptionDisabled property
         *
         * Specify an array of string values to match this event if the actual value of encryptionDisabled is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly encryptionDisabled?: Array<string>;
        /**
         * location property
         *
         * Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly location?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * namespaceType property
         *
         * Specify an array of string values to match this event if the actual value of namespaceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly namespaceType?: Array<string>;
        /**
         * packaging property
         *
         * Specify an array of string values to match this event if the actual value of packaging is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly packaging?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Badge
     *
     * @struct
     */
    interface Badge {
        /**
         * badgeEnabled property
         *
         * Specify an array of string values to match this event if the actual value of badgeEnabled is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly badgeEnabled?: Array<string>;
        /**
         * badgeRequestUrl property
         *
         * Specify an array of string values to match this event if the actual value of badgeRequestUrl is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly badgeRequestUrl?: Array<string>;
    }
    /**
     * Type definition for Environment_1
     *
     * @struct
     */
    interface Environment1 {
        /**
         * computeType property
         *
         * Specify an array of string values to match this event if the actual value of computeType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly computeType?: Array<string>;
        /**
         * environmentVariables property
         *
         * Specify an array of string values to match this event if the actual value of environmentVariables is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly environmentVariables?: Array<AWSAPICallViaCloudTrail.EnvironmentItem>;
        /**
         * image property
         *
         * Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly image?: Array<string>;
        /**
         * imagePullCredentialsType property
         *
         * Specify an array of string values to match this event if the actual value of imagePullCredentialsType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagePullCredentialsType?: Array<string>;
        /**
         * privilegedMode property
         *
         * Specify an array of string values to match this event if the actual value of privilegedMode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privilegedMode?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Source_1
     *
     * @struct
     */
    interface Source1 {
        /**
         * auth property
         *
         * Specify an array of string values to match this event if the actual value of auth is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly auth?: AWSAPICallViaCloudTrail.Auth;
        /**
         * gitSubmodulesConfig property
         *
         * Specify an array of string values to match this event if the actual value of gitSubmodulesConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly gitSubmodulesConfig?: AWSAPICallViaCloudTrail.GitSubmodulesConfig;
        /**
         * buildspec property
         *
         * Specify an array of string values to match this event if the actual value of buildspec is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildspec?: Array<string>;
        /**
         * gitCloneDepth property
         *
         * Specify an array of string values to match this event if the actual value of gitCloneDepth is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly gitCloneDepth?: Array<string>;
        /**
         * insecureSsl property
         *
         * Specify an array of string values to match this event if the actual value of insecureSsl is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insecureSsl?: Array<string>;
        /**
         * location property
         *
         * Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly location?: Array<string>;
        /**
         * reportBuildStatus property
         *
         * Specify an array of string values to match this event if the actual value of reportBuildStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reportBuildStatus?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for GitSubmodulesConfig
     *
     * @struct
     */
    interface GitSubmodulesConfig {
        /**
         * fetchSubmodules property
         *
         * Specify an array of string values to match this event if the actual value of fetchSubmodules is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fetchSubmodules?: Array<string>;
    }
    /**
     * Type definition for ProjectItem
     *
     * @struct
     */
    interface ProjectItem {
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for Webhook
     *
     * @struct
     */
    interface Webhook {
        /**
         * branchFilter property
         *
         * Specify an array of string values to match this event if the actual value of branchFilter is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly branchFilter?: Array<string>;
        /**
         * lastModifiedSecret property
         *
         * Specify an array of string values to match this event if the actual value of lastModifiedSecret is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastModifiedSecret?: Array<string>;
        /**
         * payloadUrl property
         *
         * Specify an array of string values to match this event if the actual value of payloadUrl is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly payloadUrl?: Array<string>;
        /**
         * url property
         *
         * Specify an array of string values to match this event if the actual value of url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly url?: Array<string>;
    }
    /**
     * Type definition for UserIdentity
     *
     * @struct
     */
    interface UserIdentity {
        /**
         * sessionContext property
         *
         * Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionContext?: AWSAPICallViaCloudTrail.SessionContext;
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * invokedBy property
         *
         * Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly invokedBy?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for SessionContext
     *
     * @struct
     */
    interface SessionContext {
        /**
         * attributes property
         *
         * Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attributes?: AWSAPICallViaCloudTrail.Attributes;
        /**
         * sessionIssuer property
         *
         * Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionIssuer?: AWSAPICallViaCloudTrail.SessionIssuer;
    }
    /**
     * Type definition for Attributes
     *
     * @struct
     */
    interface Attributes {
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
        /**
         * mfaAuthenticated property
         *
         * Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mfaAuthenticated?: Array<string>;
    }
    /**
     * Type definition for SessionIssuer
     *
     * @struct
     */
    interface SessionIssuer {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * userName property
         *
         * Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userName?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.codebuild@AWSServiceEventViaCloudTrail
 */
export declare class AWSServiceEventViaCloudTrail {
    /**
     * EventBridge event pattern for AWS Service Event via CloudTrail
     */
    static eventPattern(options?: AWSServiceEventViaCloudTrail.AWSServiceEventViaCloudTrailProps): events.EventPattern;
}
export declare namespace AWSServiceEventViaCloudTrail {
    /**
     * Props type for aws.codebuild@AWSServiceEventViaCloudTrail event
     */
    interface AWSServiceEventViaCloudTrailProps {
        /**
         * serviceEventDetails property
         *
         * Specify an array of string values to match this event if the actual value of serviceEventDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serviceEventDetails?: AWSServiceEventViaCloudTrail.ServiceEventDetails;
        /**
         * userIdentity property
         *
         * Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userIdentity?: AWSServiceEventViaCloudTrail.UserIdentity;
        /**
         * awsRegion property
         *
         * Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsRegion?: Array<string>;
        /**
         * eventID property
         *
         * Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * eventSource property
         *
         * Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventSource?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * eventVersion property
         *
         * Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventVersion?: Array<string>;
        /**
         * readOnly property
         *
         * Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly readOnly?: Array<string>;
        /**
         * sourceIPAddress property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ServiceEventDetails
     *
     * @struct
     */
    interface ServiceEventDetails {
        /**
         * response property
         *
         * Specify an array of string values to match this event if the actual value of response is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly response?: Array<string>;
    }
    /**
     * Type definition for UserIdentity
     *
     * @struct
     */
    interface UserIdentity {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * invokedBy property
         *
         * Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly invokedBy?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.codebuild@CodeBuildBuildPhaseChange
 */
export declare class CodeBuildBuildPhaseChange {
    /**
     * EventBridge event pattern for CodeBuild Build Phase Change
     */
    static eventPattern(options?: CodeBuildBuildPhaseChange.CodeBuildBuildPhaseChangeProps): events.EventPattern;
}
export declare namespace CodeBuildBuildPhaseChange {
    /**
     * Props type for aws.codebuild@CodeBuildBuildPhaseChange event
     */
    interface CodeBuildBuildPhaseChangeProps {
        /**
         * additional-information property
         *
         * Specify an array of string values to match this event if the actual value of additional-information is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly additionalInformation?: CodeBuildBuildPhaseChange.AdditionalInformation;
        /**
         * build-id property
         *
         * Specify an array of string values to match this event if the actual value of build-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildId?: Array<string>;
        /**
         * completed-phase property
         *
         * Specify an array of string values to match this event if the actual value of completed-phase is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly completedPhase?: Array<string>;
        /**
         * completed-phase-context property
         *
         * Specify an array of string values to match this event if the actual value of completed-phase-context is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly completedPhaseContext?: Array<string>;
        /**
         * completed-phase-duration-seconds property
         *
         * Specify an array of string values to match this event if the actual value of completed-phase-duration-seconds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly completedPhaseDurationSeconds?: Array<string>;
        /**
         * completed-phase-end property
         *
         * Specify an array of string values to match this event if the actual value of completed-phase-end is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly completedPhaseEnd?: Array<string>;
        /**
         * completed-phase-start property
         *
         * Specify an array of string values to match this event if the actual value of completed-phase-start is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly completedPhaseStart?: Array<string>;
        /**
         * completed-phase-status property
         *
         * Specify an array of string values to match this event if the actual value of completed-phase-status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly completedPhaseStatus?: Array<string>;
        /**
         * project-name property
         *
         * Specify an array of string values to match this event if the actual value of project-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Project reference
         */
        readonly projectName?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Additional-information
     *
     * @struct
     */
    interface AdditionalInformation {
        /**
         * artifact property
         *
         * Specify an array of string values to match this event if the actual value of artifact is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly artifact?: CodeBuildBuildPhaseChange.Artifact;
        /**
         * cache property
         *
         * Specify an array of string values to match this event if the actual value of cache is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cache?: CodeBuildBuildPhaseChange.Cache;
        /**
         * environment property
         *
         * Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly environment?: CodeBuildBuildPhaseChange.Environment;
        /**
         * logs property
         *
         * Specify an array of string values to match this event if the actual value of logs is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly logs?: CodeBuildBuildPhaseChange.Logs;
        /**
         * network-interface property
         *
         * Specify an array of string values to match this event if the actual value of network-interface is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterface?: CodeBuildBuildPhaseChange.NetworkInterface;
        /**
         * source property
         *
         * Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly source?: CodeBuildBuildPhaseChange.Source;
        /**
         * vpc-config property
         *
         * Specify an array of string values to match this event if the actual value of vpc-config is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcConfig?: CodeBuildBuildPhaseChange.VpcConfig;
        /**
         * build-complete property
         *
         * Specify an array of string values to match this event if the actual value of build-complete is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildComplete?: Array<string>;
        /**
         * build-start-time property
         *
         * Specify an array of string values to match this event if the actual value of build-start-time is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildStartTime?: Array<string>;
        /**
         * initiator property
         *
         * Specify an array of string values to match this event if the actual value of initiator is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly initiator?: Array<string>;
        /**
         * phases property
         *
         * Specify an array of string values to match this event if the actual value of phases is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly phases?: Array<CodeBuildBuildPhaseChange.AdditionalInformationItem>;
        /**
         * queued-timeout-in-minutes property
         *
         * Specify an array of string values to match this event if the actual value of queued-timeout-in-minutes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queuedTimeoutInMinutes?: Array<string>;
        /**
         * source-version property
         *
         * Specify an array of string values to match this event if the actual value of source-version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceVersion?: Array<string>;
        /**
         * timeout-in-minutes property
         *
         * Specify an array of string values to match this event if the actual value of timeout-in-minutes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly timeoutInMinutes?: Array<string>;
    }
    /**
     * Type definition for Artifact
     *
     * @struct
     */
    interface Artifact {
        /**
         * location property
         *
         * Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly location?: Array<string>;
        /**
         * md5sum property
         *
         * Specify an array of string values to match this event if the actual value of md5sum is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly md5Sum?: Array<string>;
        /**
         * sha256sum property
         *
         * Specify an array of string values to match this event if the actual value of sha256sum is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sha256Sum?: Array<string>;
    }
    /**
     * Type definition for Cache
     *
     * @struct
     */
    interface Cache {
        /**
         * location property
         *
         * Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly location?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Environment
     *
     * @struct
     */
    interface Environment {
        /**
         * compute-type property
         *
         * Specify an array of string values to match this event if the actual value of compute-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly computeType?: Array<string>;
        /**
         * environment-variables property
         *
         * Specify an array of string values to match this event if the actual value of environment-variables is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly environmentVariables?: Array<CodeBuildBuildPhaseChange.EnvironmentItem>;
        /**
         * image property
         *
         * Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly image?: Array<string>;
        /**
         * image-pull-credentials-type property
         *
         * Specify an array of string values to match this event if the actual value of image-pull-credentials-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagePullCredentialsType?: Array<string>;
        /**
         * privileged-mode property
         *
         * Specify an array of string values to match this event if the actual value of privileged-mode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privilegedMode?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for EnvironmentItem
     *
     * @struct
     */
    interface EnvironmentItem {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for Logs
     *
     * @struct
     */
    interface Logs {
        /**
         * deep-link property
         *
         * Specify an array of string values to match this event if the actual value of deep-link is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deepLink?: Array<string>;
        /**
         * group-name property
         *
         * Specify an array of string values to match this event if the actual value of group-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupName?: Array<string>;
        /**
         * stream-name property
         *
         * Specify an array of string values to match this event if the actual value of stream-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly streamName?: Array<string>;
    }
    /**
     * Type definition for Network-interface
     *
     * @struct
     */
    interface NetworkInterface {
        /**
         * eni-id property
         *
         * Specify an array of string values to match this event if the actual value of eni-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eniId?: Array<string>;
        /**
         * subnet-id property
         *
         * Specify an array of string values to match this event if the actual value of subnet-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
    }
    /**
     * Type definition for Source
     *
     * @struct
     */
    interface Source {
        /**
         * auth property
         *
         * Specify an array of string values to match this event if the actual value of auth is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly auth?: CodeBuildBuildPhaseChange.Auth;
        /**
         * buildspec property
         *
         * Specify an array of string values to match this event if the actual value of buildspec is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildspec?: Array<string>;
        /**
         * location property
         *
         * Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly location?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Auth
     *
     * @struct
     */
    interface Auth {
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Vpc-config
     *
     * @struct
     */
    interface VpcConfig {
        /**
         * security-group-ids property
         *
         * Specify an array of string values to match this event if the actual value of security-group-ids is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly securityGroupIds?: Array<string>;
        /**
         * subnets property
         *
         * Specify an array of string values to match this event if the actual value of subnets is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnets?: Array<CodeBuildBuildPhaseChange.VpcConfigItem>;
        /**
         * vpc-id property
         *
         * Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcId?: Array<string>;
    }
    /**
     * Type definition for Vpc-configItem
     *
     * @struct
     */
    interface VpcConfigItem {
        /**
         * build-fleet-az property
         *
         * Specify an array of string values to match this event if the actual value of build-fleet-az is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildFleetAz?: Array<string>;
        /**
         * customer-az property
         *
         * Specify an array of string values to match this event if the actual value of customer-az is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly customerAz?: Array<string>;
        /**
         * subnet-id property
         *
         * Specify an array of string values to match this event if the actual value of subnet-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
    }
    /**
     * Type definition for Additional-informationItem
     *
     * @struct
     */
    interface AdditionalInformationItem {
        /**
         * duration-in-seconds property
         *
         * Specify an array of string values to match this event if the actual value of duration-in-seconds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly durationInSeconds?: Array<string>;
        /**
         * end-time property
         *
         * Specify an array of string values to match this event if the actual value of end-time is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * phase-context property
         *
         * Specify an array of string values to match this event if the actual value of phase-context is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly phaseContext?: Array<string>;
        /**
         * phase-status property
         *
         * Specify an array of string values to match this event if the actual value of phase-status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly phaseStatus?: Array<string>;
        /**
         * phase-type property
         *
         * Specify an array of string values to match this event if the actual value of phase-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly phaseType?: Array<string>;
        /**
         * start-time property
         *
         * Specify an array of string values to match this event if the actual value of start-time is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
    }
}
/**
 * EventBridge event patterns for Project
 */
export declare class ProjectEvents {
    /**
     * Create ProjectEvents from a Project reference
     */
    static fromProject(projectRef: service.IProjectRef): ProjectEvents;
    /**
     * Reference to the Project construct
     */
    private readonly projectRef;
    private constructor();
    /**
     * EventBridge event pattern for Project CodeBuild Build Phase Change
     */
    codeBuildBuildPhaseChangePattern(options?: CodeBuildBuildPhaseChange.CodeBuildBuildPhaseChangeProps): events.EventPattern;
    /**
     * EventBridge event pattern for Project CodeBuild Build State Change
     */
    codeBuildBuildStateChangePattern(options?: CodeBuildBuildStateChange.CodeBuildBuildStateChangeProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.codebuild@CodeBuildBuildStateChange
 */
export declare class CodeBuildBuildStateChange {
    /**
     * EventBridge event pattern for CodeBuild Build State Change
     */
    static eventPattern(options?: CodeBuildBuildStateChange.CodeBuildBuildStateChangeProps): events.EventPattern;
}
export declare namespace CodeBuildBuildStateChange {
    /**
     * Props type for aws.codebuild@CodeBuildBuildStateChange event
     */
    interface CodeBuildBuildStateChangeProps {
        /**
         * additional-information property
         *
         * Specify an array of string values to match this event if the actual value of additional-information is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly additionalInformation?: CodeBuildBuildStateChange.AdditionalInformation;
        /**
         * build-id property
         *
         * Specify an array of string values to match this event if the actual value of build-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildId?: Array<string>;
        /**
         * build-status property
         *
         * Specify an array of string values to match this event if the actual value of build-status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildStatus?: Array<string>;
        /**
         * current-phase property
         *
         * Specify an array of string values to match this event if the actual value of current-phase is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentPhase?: Array<string>;
        /**
         * current-phase-context property
         *
         * Specify an array of string values to match this event if the actual value of current-phase-context is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentPhaseContext?: Array<string>;
        /**
         * project-name property
         *
         * Specify an array of string values to match this event if the actual value of project-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Project reference
         */
        readonly projectName?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Additional-information
     *
     * @struct
     */
    interface AdditionalInformation {
        /**
         * artifact property
         *
         * Specify an array of string values to match this event if the actual value of artifact is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly artifact?: CodeBuildBuildStateChange.Artifact;
        /**
         * cache property
         *
         * Specify an array of string values to match this event if the actual value of cache is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cache?: CodeBuildBuildStateChange.Cache;
        /**
         * environment property
         *
         * Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly environment?: CodeBuildBuildStateChange.Environment;
        /**
         * logs property
         *
         * Specify an array of string values to match this event if the actual value of logs is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly logs?: CodeBuildBuildStateChange.Logs;
        /**
         * network-interface property
         *
         * Specify an array of string values to match this event if the actual value of network-interface is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterface?: CodeBuildBuildStateChange.NetworkInterface;
        /**
         * source property
         *
         * Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly source?: CodeBuildBuildStateChange.Source;
        /**
         * vpc-config property
         *
         * Specify an array of string values to match this event if the actual value of vpc-config is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcConfig?: CodeBuildBuildStateChange.VpcConfig;
        /**
         * build-complete property
         *
         * Specify an array of string values to match this event if the actual value of build-complete is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildComplete?: Array<string>;
        /**
         * build-start-time property
         *
         * Specify an array of string values to match this event if the actual value of build-start-time is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildStartTime?: Array<string>;
        /**
         * initiator property
         *
         * Specify an array of string values to match this event if the actual value of initiator is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly initiator?: Array<string>;
        /**
         * phases property
         *
         * Specify an array of string values to match this event if the actual value of phases is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly phases?: Array<CodeBuildBuildStateChange.AdditionalInformationItem>;
        /**
         * queued-timeout-in-minutes property
         *
         * Specify an array of string values to match this event if the actual value of queued-timeout-in-minutes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queuedTimeoutInMinutes?: Array<string>;
        /**
         * source-version property
         *
         * Specify an array of string values to match this event if the actual value of source-version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceVersion?: Array<string>;
        /**
         * timeout-in-minutes property
         *
         * Specify an array of string values to match this event if the actual value of timeout-in-minutes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly timeoutInMinutes?: Array<string>;
    }
    /**
     * Type definition for Artifact
     *
     * @struct
     */
    interface Artifact {
        /**
         * location property
         *
         * Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly location?: Array<string>;
        /**
         * md5sum property
         *
         * Specify an array of string values to match this event if the actual value of md5sum is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly md5Sum?: Array<string>;
        /**
         * sha256sum property
         *
         * Specify an array of string values to match this event if the actual value of sha256sum is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sha256Sum?: Array<string>;
    }
    /**
     * Type definition for Cache
     *
     * @struct
     */
    interface Cache {
        /**
         * location property
         *
         * Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly location?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Environment
     *
     * @struct
     */
    interface Environment {
        /**
         * compute-type property
         *
         * Specify an array of string values to match this event if the actual value of compute-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly computeType?: Array<string>;
        /**
         * environment-variables property
         *
         * Specify an array of string values to match this event if the actual value of environment-variables is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly environmentVariables?: Array<CodeBuildBuildStateChange.EnvironmentItem>;
        /**
         * image property
         *
         * Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly image?: Array<string>;
        /**
         * image-pull-credentials-type property
         *
         * Specify an array of string values to match this event if the actual value of image-pull-credentials-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagePullCredentialsType?: Array<string>;
        /**
         * privileged-mode property
         *
         * Specify an array of string values to match this event if the actual value of privileged-mode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privilegedMode?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for EnvironmentItem
     *
     * @struct
     */
    interface EnvironmentItem {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for Logs
     *
     * @struct
     */
    interface Logs {
        /**
         * deep-link property
         *
         * Specify an array of string values to match this event if the actual value of deep-link is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deepLink?: Array<string>;
        /**
         * group-name property
         *
         * Specify an array of string values to match this event if the actual value of group-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupName?: Array<string>;
        /**
         * stream-name property
         *
         * Specify an array of string values to match this event if the actual value of stream-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly streamName?: Array<string>;
    }
    /**
     * Type definition for Network-interface
     *
     * @struct
     */
    interface NetworkInterface {
        /**
         * eni-id property
         *
         * Specify an array of string values to match this event if the actual value of eni-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eniId?: Array<string>;
        /**
         * subnet-id property
         *
         * Specify an array of string values to match this event if the actual value of subnet-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
    }
    /**
     * Type definition for Source
     *
     * @struct
     */
    interface Source {
        /**
         * auth property
         *
         * Specify an array of string values to match this event if the actual value of auth is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly auth?: CodeBuildBuildStateChange.Auth;
        /**
         * buildspec property
         *
         * Specify an array of string values to match this event if the actual value of buildspec is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildspec?: Array<string>;
        /**
         * location property
         *
         * Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly location?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for Auth
     *
     * @struct
     */
    interface Auth {
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * resource property
         *
         * Specify an array of string values to match this event if the actual value of resource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resource?: Array<string>;
    }
    /**
     * Type definition for Vpc-config
     *
     * @struct
     */
    interface VpcConfig {
        /**
         * security-group-ids property
         *
         * Specify an array of string values to match this event if the actual value of security-group-ids is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly securityGroupIds?: Array<string>;
        /**
         * subnets property
         *
         * Specify an array of string values to match this event if the actual value of subnets is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnets?: Array<CodeBuildBuildStateChange.VpcConfigItem>;
        /**
         * vpc-id property
         *
         * Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcId?: Array<string>;
    }
    /**
     * Type definition for Vpc-configItem
     *
     * @struct
     */
    interface VpcConfigItem {
        /**
         * build-fleet-az property
         *
         * Specify an array of string values to match this event if the actual value of build-fleet-az is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly buildFleetAz?: Array<string>;
        /**
         * customer-az property
         *
         * Specify an array of string values to match this event if the actual value of customer-az is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly customerAz?: Array<string>;
        /**
         * subnet-id property
         *
         * Specify an array of string values to match this event if the actual value of subnet-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
    }
    /**
     * Type definition for Additional-informationItem
     *
     * @struct
     */
    interface AdditionalInformationItem {
        /**
         * duration-in-seconds property
         *
         * Specify an array of string values to match this event if the actual value of duration-in-seconds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly durationInSeconds?: Array<string>;
        /**
         * end-time property
         *
         * Specify an array of string values to match this event if the actual value of end-time is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * phase-context property
         *
         * Specify an array of string values to match this event if the actual value of phase-context is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly phaseContext?: Array<string>;
        /**
         * phase-status property
         *
         * Specify an array of string values to match this event if the actual value of phase-status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly phaseStatus?: Array<string>;
        /**
         * phase-type property
         *
         * Specify an array of string values to match this event if the actual value of phase-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly phaseType?: Array<string>;
        /**
         * start-time property
         *
         * Specify an array of string values to match this event if the actual value of start-time is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
    }
}
