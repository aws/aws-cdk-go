import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.codepipeline@CodePipelineActionExecutionStateChange
 */
export declare class CodePipelineActionExecutionStateChange {
    /**
     * EventBridge event pattern for CodePipeline Action Execution State Change
     */
    static eventPattern(options?: CodePipelineActionExecutionStateChange.CodePipelineActionExecutionStateChangeProps): events.EventPattern;
}
export declare namespace CodePipelineActionExecutionStateChange {
    /**
     * Props type for aws.codepipeline@CodePipelineActionExecutionStateChange event
     */
    interface CodePipelineActionExecutionStateChangeProps {
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: CodePipelineActionExecutionStateChange.Type;
        /**
         * pipeline property
         *
         * Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipeline?: Array<string>;
        /**
         * execution-id property
         *
         * Specify an array of string values to match this event if the actual value of execution-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly executionId?: Array<string>;
        /**
         * stage property
         *
         * Specify an array of string values to match this event if the actual value of stage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stage?: Array<string>;
        /**
         * action property
         *
         * Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly action?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * region property
         *
         * Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly region?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * execution-result property
         *
         * Specify an array of string values to match this event if the actual value of execution-result is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly executionResult?: CodePipelineActionExecutionStateChange.ExecutionResult;
        /**
         * input-artifacts property
         *
         * Specify an array of string values to match this event if the actual value of input-artifacts is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputArtifacts?: CodePipelineActionExecutionStateChange.InputArtifacts;
        /**
         * output-artifacts property
         *
         * Specify an array of string values to match this event if the actual value of output-artifacts is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputArtifacts?: CodePipelineActionExecutionStateChange.OutputArtifacts;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Type
     *
     * @struct
     */
    interface Type {
        /**
         * owner property
         *
         * Specify an array of string values to match this event if the actual value of owner is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly owner?: Array<string>;
        /**
         * provider property
         *
         * Specify an array of string values to match this event if the actual value of provider is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly provider?: Array<string>;
        /**
         * category property
         *
         * Specify an array of string values to match this event if the actual value of category is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly category?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
    }
    /**
     * Type definition for ExecutionResult
     *
     * @struct
     */
    interface ExecutionResult {
        /**
         * external-execution-id property
         *
         * Specify an array of string values to match this event if the actual value of external-execution-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly externalExecutionId?: Array<string>;
        /**
         * external-execution-url property
         *
         * Specify an array of string values to match this event if the actual value of external-execution-url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly externalExecutionUrl?: Array<string>;
        /**
         * external-execution-summary property
         *
         * Specify an array of string values to match this event if the actual value of external-execution-summary is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly externalExecutionSummary?: Array<string>;
    }
    /**
     * Type definition for InputArtifacts
     *
     * @struct
     */
    interface InputArtifacts {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * s3location property
         *
         * Specify an array of string values to match this event if the actual value of s3location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Location?: CodePipelineActionExecutionStateChange.S3Location;
    }
    /**
     * Type definition for S3Location
     *
     * @struct
     */
    interface S3Location {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
    }
    /**
     * Type definition for OutputArtifacts
     *
     * @struct
     */
    interface OutputArtifacts {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * s3location property
         *
         * Specify an array of string values to match this event if the actual value of s3location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Location?: CodePipelineActionExecutionStateChange.S3Location;
    }
}
/**
 * EventBridge event pattern for aws.codepipeline@CodePipelinePipelineExecutionStateChange
 */
export declare class CodePipelinePipelineExecutionStateChange {
    /**
     * EventBridge event pattern for CodePipeline Pipeline Execution State Change
     */
    static eventPattern(options?: CodePipelinePipelineExecutionStateChange.CodePipelinePipelineExecutionStateChangeProps): events.EventPattern;
}
export declare namespace CodePipelinePipelineExecutionStateChange {
    /**
     * Props type for aws.codepipeline@CodePipelinePipelineExecutionStateChange event
     */
    interface CodePipelinePipelineExecutionStateChangeProps {
        /**
         * pipeline property
         *
         * Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipeline?: Array<string>;
        /**
         * execution-id property
         *
         * Specify an array of string values to match this event if the actual value of execution-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly executionId?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * execution-trigger property
         *
         * Specify an array of string values to match this event if the actual value of execution-trigger is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly executionTrigger?: CodePipelinePipelineExecutionStateChange.ExecutionTrigger;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for execution-trigger
     *
     * @struct
     */
    interface ExecutionTrigger {
        /**
         * trigger-type property
         *
         * Specify an array of string values to match this event if the actual value of trigger-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly triggerType?: Array<string>;
        /**
         * trigger-detail property
         *
         * Specify an array of string values to match this event if the actual value of trigger-detail is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly triggerDetail?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.codepipeline@CodePipelineStageExecutionStateChange
 */
export declare class CodePipelineStageExecutionStateChange {
    /**
     * EventBridge event pattern for CodePipeline Stage Execution State Change
     */
    static eventPattern(options?: CodePipelineStageExecutionStateChange.CodePipelineStageExecutionStateChangeProps): events.EventPattern;
}
export declare namespace CodePipelineStageExecutionStateChange {
    /**
     * Props type for aws.codepipeline@CodePipelineStageExecutionStateChange event
     */
    interface CodePipelineStageExecutionStateChangeProps {
        /**
         * pipeline property
         *
         * Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipeline?: Array<string>;
        /**
         * execution-id property
         *
         * Specify an array of string values to match this event if the actual value of execution-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly executionId?: Array<string>;
        /**
         * stage property
         *
         * Specify an array of string values to match this event if the actual value of stage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stage?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
