import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.rds@RDSDBClusterEvent
 */
export declare class RDSDBClusterEvent {
    /**
     * EventBridge event pattern for RDS DB Cluster Event
     */
    static eventPattern(options?: RDSDBClusterEvent.RDSDBClusterEventProps): events.EventPattern;
}
export declare namespace RDSDBClusterEvent {
    /**
     * Props type for aws.rds@RDSDBClusterEvent event
     */
    interface RDSDBClusterEventProps {
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * Date property
         *
         * Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly date?: Array<string>;
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Record<string, string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.rds@RDSDBClusterSnapshotEvent
 */
export declare class RDSDBClusterSnapshotEvent {
    /**
     * EventBridge event pattern for RDS DB Cluster Snapshot Event
     */
    static eventPattern(options?: RDSDBClusterSnapshotEvent.RDSDBClusterSnapshotEventProps): events.EventPattern;
}
export declare namespace RDSDBClusterSnapshotEvent {
    /**
     * Props type for aws.rds@RDSDBClusterSnapshotEvent event
     */
    interface RDSDBClusterSnapshotEventProps {
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * Date property
         *
         * Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly date?: Array<string>;
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Record<string, string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.rds@RDSDBInstanceEvent
 */
export declare class RDSDBInstanceEvent {
    /**
     * EventBridge event pattern for RDS DB Instance Event
     */
    static eventPattern(options?: RDSDBInstanceEvent.RDSDBInstanceEventProps): events.EventPattern;
}
export declare namespace RDSDBInstanceEvent {
    /**
     * Props type for aws.rds@RDSDBInstanceEvent event
     */
    interface RDSDBInstanceEventProps {
        /**
         * Date property
         *
         * Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly date?: Array<string>;
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * EventID property
         *
         * Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Record<string, string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.rds@RDSDBParameterGroupEvent
 */
export declare class RDSDBParameterGroupEvent {
    /**
     * EventBridge event pattern for RDS DB Parameter Group Event
     */
    static eventPattern(options?: RDSDBParameterGroupEvent.RDSDBParameterGroupEventProps): events.EventPattern;
}
export declare namespace RDSDBParameterGroupEvent {
    /**
     * Props type for aws.rds@RDSDBParameterGroupEvent event
     */
    interface RDSDBParameterGroupEventProps {
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * Date property
         *
         * Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly date?: Array<string>;
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Record<string, string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.rds@RDSDBProxyEvent
 */
export declare class RDSDBProxyEvent {
    /**
     * EventBridge event pattern for RDS DB Proxy Event
     */
    static eventPattern(options?: RDSDBProxyEvent.RDSDBProxyEventProps): events.EventPattern;
}
export declare namespace RDSDBProxyEvent {
    /**
     * Props type for aws.rds@RDSDBProxyEvent event
     */
    interface RDSDBProxyEventProps {
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * Date property
         *
         * Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly date?: Array<string>;
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Record<string, string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.rds@RDSDBSecurityGroupEvent
 */
export declare class RDSDBSecurityGroupEvent {
    /**
     * EventBridge event pattern for RDS DB Security Group Event
     */
    static eventPattern(options?: RDSDBSecurityGroupEvent.RDSDBSecurityGroupEventProps): events.EventPattern;
}
export declare namespace RDSDBSecurityGroupEvent {
    /**
     * Props type for aws.rds@RDSDBSecurityGroupEvent event
     */
    interface RDSDBSecurityGroupEventProps {
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * Date property
         *
         * Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly date?: Array<string>;
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Record<string, string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.rds@RDSDBSnapshotEvent
 */
export declare class RDSDBSnapshotEvent {
    /**
     * EventBridge event pattern for RDS DB Snapshot Event
     */
    static eventPattern(options?: RDSDBSnapshotEvent.RDSDBSnapshotEventProps): events.EventPattern;
}
export declare namespace RDSDBSnapshotEvent {
    /**
     * Props type for aws.rds@RDSDBSnapshotEvent event
     */
    interface RDSDBSnapshotEventProps {
        /**
         * SourceArn property
         *
         * Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceArn?: Array<string>;
        /**
         * Message property
         *
         * Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * SourceType property
         *
         * Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceType?: Array<string>;
        /**
         * SourceIdentifier property
         *
         * Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIdentifier?: Array<string>;
        /**
         * EventCategories property
         *
         * Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventCategories?: Array<string>;
        /**
         * Date property
         *
         * Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly date?: Array<string>;
        /**
         * Tags property
         *
         * Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Record<string, string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
