import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.cloudformation@CloudFormationHookInvocationProgress
 */
export declare class CloudFormationHookInvocationProgress {
    /**
     * EventBridge event pattern for CloudFormation Hook Invocation Progress
     */
    static eventPattern(options?: CloudFormationHookInvocationProgress.CloudFormationHookInvocationProgressProps): events.EventPattern;
}
export declare namespace CloudFormationHookInvocationProgress {
    /**
     * Props type for aws.cloudformation@CloudFormationHookInvocationProgress event
     */
    interface CloudFormationHookInvocationProgressProps {
        /**
         * hook-detail property
         *
         * Specify an array of string values to match this event if the actual value of hook-detail is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hookDetail?: CloudFormationHookInvocationProgress.HookDetail;
        /**
         * result property
         *
         * Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly result?: CloudFormationHookInvocationProgress.Result;
        /**
         * target-detail property
         *
         * Specify an array of string values to match this event if the actual value of target-detail is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetDetail?: CloudFormationHookInvocationProgress.TargetDetail;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * status-reason property
         *
         * Specify an array of string values to match this event if the actual value of status-reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusReason?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Hook-detail
     *
     * @struct
     */
    interface HookDetail {
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * documentation-url property
         *
         * Specify an array of string values to match this event if the actual value of documentation-url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly documentationUrl?: Array<string>;
        /**
         * failure-mode property
         *
         * Specify an array of string values to match this event if the actual value of failure-mode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMode?: Array<string>;
        /**
         * hook-type-arn property
         *
         * Specify an array of string values to match this event if the actual value of hook-type-arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hookTypeArn?: Array<string>;
        /**
         * hook-type-name property
         *
         * Specify an array of string values to match this event if the actual value of hook-type-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hookTypeName?: Array<string>;
        /**
         * hook-version property
         *
         * Specify an array of string values to match this event if the actual value of hook-version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hookVersion?: Array<string>;
        /**
         * source-url property
         *
         * Specify an array of string values to match this event if the actual value of source-url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceUrl?: Array<string>;
    }
    /**
     * Type definition for Result
     *
     * @struct
     */
    interface Result {
        /**
         * data property
         *
         * Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly data?: Array<string>;
    }
    /**
     * Type definition for Target-detail
     *
     * @struct
     */
    interface TargetDetail {
        /**
         * target-action property
         *
         * Specify an array of string values to match this event if the actual value of target-action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetAction?: Array<string>;
        /**
         * target-id property
         *
         * Specify an array of string values to match this event if the actual value of target-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetId?: Array<string>;
        /**
         * target-invocation-point property
         *
         * Specify an array of string values to match this event if the actual value of target-invocation-point is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetInvocationPoint?: Array<string>;
        /**
         * target-name property
         *
         * Specify an array of string values to match this event if the actual value of target-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetName?: Array<string>;
        /**
         * target-type property
         *
         * Specify an array of string values to match this event if the actual value of target-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetType?: Array<string>;
    }
}
