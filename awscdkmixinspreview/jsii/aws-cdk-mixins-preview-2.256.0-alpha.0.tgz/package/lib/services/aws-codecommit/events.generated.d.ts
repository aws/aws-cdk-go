import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-codecommit";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.codecommit@AWSAPICallViaCloudTrail
 */
export declare class AWSAPICallViaCloudTrail {
    /**
     * EventBridge event pattern for AWS API Call via CloudTrail
     */
    static eventPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
}
export declare namespace AWSAPICallViaCloudTrail {
    /**
     * Props type for aws.codecommit@AWSAPICallViaCloudTrail event
     */
    interface AWSAPICallViaCloudTrailProps {
        /**
         * additionalEventData property
         *
         * Specify an array of string values to match this event if the actual value of additionalEventData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly additionalEventData?: AWSAPICallViaCloudTrail.AdditionalEventData;
        /**
         * requestParameters property
         *
         * Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestParameters?: AWSAPICallViaCloudTrail.RequestParameters;
        /**
         * responseElements property
         *
         * Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly responseElements?: AWSAPICallViaCloudTrail.ResponseElements;
        /**
         * userIdentity property
         *
         * Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userIdentity?: AWSAPICallViaCloudTrail.UserIdentity;
        /**
         * apiVersion property
         *
         * Specify an array of string values to match this event if the actual value of apiVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly apiVersion?: Array<string>;
        /**
         * awsRegion property
         *
         * Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsRegion?: Array<string>;
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * eventID property
         *
         * Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * eventSource property
         *
         * Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventSource?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * eventVersion property
         *
         * Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventVersion?: Array<string>;
        /**
         * readOnly property
         *
         * Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly readOnly?: Array<string>;
        /**
         * requestID property
         *
         * Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * resources property
         *
         * Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resources?: Array<AWSAPICallViaCloudTrail.AwsapiCallViaCloudTrailItem>;
        /**
         * sourceIPAddress property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for AdditionalEventData
     *
     * @struct
     */
    interface AdditionalEventData {
        /**
         * capabilities property
         *
         * Specify an array of string values to match this event if the actual value of capabilities is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly capabilities?: Array<string>;
        /**
         * clone property
         *
         * Specify an array of string values to match this event if the actual value of clone is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clone?: Array<string>;
        /**
         * dataTransferred property
         *
         * Specify an array of string values to match this event if the actual value of dataTransferred is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataTransferred?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * repositoryId property
         *
         * Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryId?: Array<string>;
        /**
         * repositoryName property
         *
         * Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryName?: Array<string>;
        /**
         * shallow property
         *
         * Specify an array of string values to match this event if the actual value of shallow is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly shallow?: Array<string>;
    }
    /**
     * Type definition for RequestParameters
     *
     * @struct
     */
    interface RequestParameters {
        /**
         * location property
         *
         * Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly location?: AWSAPICallViaCloudTrail.Location;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Record<string, string>;
        /**
         * afterCommitId property
         *
         * Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly afterCommitId?: Array<string>;
        /**
         * approvalRuleTemplateContent property
         *
         * Specify an array of string values to match this event if the actual value of approvalRuleTemplateContent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly approvalRuleTemplateContent?: Array<string>;
        /**
         * approvalRuleTemplateDescription property
         *
         * Specify an array of string values to match this event if the actual value of approvalRuleTemplateDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly approvalRuleTemplateDescription?: Array<string>;
        /**
         * approvalRuleTemplateName property
         *
         * Specify an array of string values to match this event if the actual value of approvalRuleTemplateName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly approvalRuleTemplateName?: Array<string>;
        /**
         * approvalState property
         *
         * Specify an array of string values to match this event if the actual value of approvalState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly approvalState?: Array<string>;
        /**
         * archiveType property
         *
         * Specify an array of string values to match this event if the actual value of archiveType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly archiveType?: Array<string>;
        /**
         * beforeCommitId property
         *
         * Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly beforeCommitId?: Array<string>;
        /**
         * branchName property
         *
         * Specify an array of string values to match this event if the actual value of branchName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly branchName?: Array<string>;
        /**
         * clientRequestToken property
         *
         * Specify an array of string values to match this event if the actual value of clientRequestToken is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientRequestToken?: Array<string>;
        /**
         * commentId property
         *
         * Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly commentId?: Array<string>;
        /**
         * commitId property
         *
         * Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly commitId?: Array<string>;
        /**
         * commitIds property
         *
         * Specify an array of string values to match this event if the actual value of commitIds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly commitIds?: Array<string>;
        /**
         * commitMessage property
         *
         * Specify an array of string values to match this event if the actual value of commitMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly commitMessage?: Array<string>;
        /**
         * conflictDetailLevel property
         *
         * Specify an array of string values to match this event if the actual value of conflictDetailLevel is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly conflictDetailLevel?: Array<string>;
        /**
         * conflictResolutionStrategy property
         *
         * Specify an array of string values to match this event if the actual value of conflictResolutionStrategy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly conflictResolutionStrategy?: Array<string>;
        /**
         * content property
         *
         * Specify an array of string values to match this event if the actual value of content is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly content?: Array<string>;
        /**
         * defaultBranchName property
         *
         * Specify an array of string values to match this event if the actual value of defaultBranchName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly defaultBranchName?: Array<string>;
        /**
         * deleteFiles property
         *
         * Specify an array of string values to match this event if the actual value of deleteFiles is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deleteFiles?: Array<AWSAPICallViaCloudTrail.RequestParametersItem>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * destinationCommitSpecifier property
         *
         * Specify an array of string values to match this event if the actual value of destinationCommitSpecifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destinationCommitSpecifier?: Array<string>;
        /**
         * fileMode property
         *
         * Specify an array of string values to match this event if the actual value of fileMode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileMode?: Array<string>;
        /**
         * filePath property
         *
         * Specify an array of string values to match this event if the actual value of filePath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * filePaths property
         *
         * Specify an array of string values to match this event if the actual value of filePaths is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePaths?: Array<string>;
        /**
         * inReplyTo property
         *
         * Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inReplyTo?: Array<string>;
        /**
         * keepEmptyFolders property
         *
         * Specify an array of string values to match this event if the actual value of keepEmptyFolders is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly keepEmptyFolders?: Array<string>;
        /**
         * maxConflictFiles property
         *
         * Specify an array of string values to match this event if the actual value of maxConflictFiles is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxConflictFiles?: Array<string>;
        /**
         * maxMergeHunks property
         *
         * Specify an array of string values to match this event if the actual value of maxMergeHunks is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxMergeHunks?: Array<string>;
        /**
         * mergeOption property
         *
         * Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mergeOption?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * newName property
         *
         * Specify an array of string values to match this event if the actual value of newName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly newName?: Array<string>;
        /**
         * oldName property
         *
         * Specify an array of string values to match this event if the actual value of oldName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly oldName?: Array<string>;
        /**
         * parentCommitId property
         *
         * Specify an array of string values to match this event if the actual value of parentCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly parentCommitId?: Array<string>;
        /**
         * pullRequestId property
         *
         * Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullRequestId?: Array<string>;
        /**
         * pullRequestIds property
         *
         * Specify an array of string values to match this event if the actual value of pullRequestIds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullRequestIds?: Array<string>;
        /**
         * pullRequestStatus property
         *
         * Specify an array of string values to match this event if the actual value of pullRequestStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullRequestStatus?: Array<string>;
        /**
         * putFiles property
         *
         * Specify an array of string values to match this event if the actual value of putFiles is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly putFiles?: Array<AWSAPICallViaCloudTrail.RequestParametersItem>;
        /**
         * references property
         *
         * Specify an array of string values to match this event if the actual value of references is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly references?: Array<AWSAPICallViaCloudTrail.RequestParametersItem1>;
        /**
         * repositoryDescription property
         *
         * Specify an array of string values to match this event if the actual value of repositoryDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryDescription?: Array<string>;
        /**
         * repositoryName property
         *
         * Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryName?: Array<string>;
        /**
         * resourceArn property
         *
         * Specify an array of string values to match this event if the actual value of resourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceArn?: Array<string>;
        /**
         * revisionId property
         *
         * Specify an array of string values to match this event if the actual value of revisionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly revisionId?: Array<string>;
        /**
         * s3Bucket property
         *
         * Specify an array of string values to match this event if the actual value of s3Bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Bucket?: Array<string>;
        /**
         * s3Key property
         *
         * Specify an array of string values to match this event if the actual value of s3Key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Key?: Array<string>;
        /**
         * sourceCommitSpecifier property
         *
         * Specify an array of string values to match this event if the actual value of sourceCommitSpecifier is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceCommitSpecifier?: Array<string>;
        /**
         * tagKeys property
         *
         * Specify an array of string values to match this event if the actual value of tagKeys is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tagKeys?: Array<string>;
        /**
         * targetBranch property
         *
         * Specify an array of string values to match this event if the actual value of targetBranch is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetBranch?: Array<string>;
        /**
         * targets property
         *
         * Specify an array of string values to match this event if the actual value of targets is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targets?: Array<AWSAPICallViaCloudTrail.RequestParametersItem2>;
        /**
         * throwIfClosed property
         *
         * Specify an array of string values to match this event if the actual value of throwIfClosed is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly throwIfClosed?: Array<string>;
        /**
         * title property
         *
         * Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly title?: Array<string>;
        /**
         * uploadId property
         *
         * Specify an array of string values to match this event if the actual value of uploadId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly uploadId?: Array<string>;
    }
    /**
     * Type definition for Location
     *
     * @struct
     */
    interface Location {
        /**
         * filePath property
         *
         * Specify an array of string values to match this event if the actual value of filePath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * filePosition property
         *
         * Specify an array of string values to match this event if the actual value of filePosition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePosition?: Array<string>;
        /**
         * relativeFileVersion property
         *
         * Specify an array of string values to match this event if the actual value of relativeFileVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly relativeFileVersion?: Array<string>;
    }
    /**
     * Type definition for RequestParametersItem
     *
     * @struct
     */
    interface RequestParametersItem {
        /**
         * filePath property
         *
         * Specify an array of string values to match this event if the actual value of filePath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
    }
    /**
     * Type definition for RequestParametersItem_1
     *
     * @struct
     */
    interface RequestParametersItem1 {
        /**
         * commit property
         *
         * Specify an array of string values to match this event if the actual value of commit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly commit?: Array<string>;
        /**
         * ref property
         *
         * Specify an array of string values to match this event if the actual value of ref is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ref?: Array<string>;
    }
    /**
     * Type definition for RequestParametersItem_2
     *
     * @struct
     */
    interface RequestParametersItem2 {
        /**
         * destinationReference property
         *
         * Specify an array of string values to match this event if the actual value of destinationReference is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destinationReference?: Array<string>;
        /**
         * repositoryName property
         *
         * Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryName?: Array<string>;
        /**
         * sourceReference property
         *
         * Specify an array of string values to match this event if the actual value of sourceReference is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceReference?: Array<string>;
    }
    /**
     * Type definition for ResponseElements
     *
     * @struct
     */
    interface ResponseElements {
        /**
         * comment property
         *
         * Specify an array of string values to match this event if the actual value of comment is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly comment?: AWSAPICallViaCloudTrail.Comment;
        /**
         * deletedBranch property
         *
         * Specify an array of string values to match this event if the actual value of deletedBranch is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deletedBranch?: AWSAPICallViaCloudTrail.DeletedBranch;
        /**
         * location property
         *
         * Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly location?: AWSAPICallViaCloudTrail.Location;
        /**
         * pullRequest property
         *
         * Specify an array of string values to match this event if the actual value of pullRequest is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullRequest?: AWSAPICallViaCloudTrail.PullRequest;
        /**
         * repositoryMetadata property
         *
         * Specify an array of string values to match this event if the actual value of repositoryMetadata is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryMetadata?: AWSAPICallViaCloudTrail.RepositoryMetadata;
        /**
         * afterBlobId property
         *
         * Specify an array of string values to match this event if the actual value of afterBlobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly afterBlobId?: Array<string>;
        /**
         * afterCommitId property
         *
         * Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly afterCommitId?: Array<string>;
        /**
         * beforeBlobId property
         *
         * Specify an array of string values to match this event if the actual value of beforeBlobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly beforeBlobId?: Array<string>;
        /**
         * beforeCommitId property
         *
         * Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly beforeCommitId?: Array<string>;
        /**
         * blobId property
         *
         * Specify an array of string values to match this event if the actual value of blobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly blobId?: Array<string>;
        /**
         * commitId property
         *
         * Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly commitId?: Array<string>;
        /**
         * filePath property
         *
         * Specify an array of string values to match this event if the actual value of filePath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * filesAdded property
         *
         * Specify an array of string values to match this event if the actual value of filesAdded is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filesAdded?: Array<AWSAPICallViaCloudTrail.ResponseElementsItem>;
        /**
         * filesDeleted property
         *
         * Specify an array of string values to match this event if the actual value of filesDeleted is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filesDeleted?: Array<AWSAPICallViaCloudTrail.ResponseElementsItem>;
        /**
         * filesUpdated property
         *
         * Specify an array of string values to match this event if the actual value of filesUpdated is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filesUpdated?: Array<AWSAPICallViaCloudTrail.ResponseElementsItem>;
        /**
         * pullRequestId property
         *
         * Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullRequestId?: Array<string>;
        /**
         * repositoryId property
         *
         * Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryId?: Array<string>;
        /**
         * repositoryName property
         *
         * Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryName?: Array<string>;
        /**
         * treeId property
         *
         * Specify an array of string values to match this event if the actual value of treeId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly treeId?: Array<string>;
        /**
         * uploadId property
         *
         * Specify an array of string values to match this event if the actual value of uploadId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly uploadId?: Array<string>;
    }
    /**
     * Type definition for Comment
     *
     * @struct
     */
    interface Comment {
        /**
         * authorArn property
         *
         * Specify an array of string values to match this event if the actual value of authorArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly authorArn?: Array<string>;
        /**
         * clientRequestToken property
         *
         * Specify an array of string values to match this event if the actual value of clientRequestToken is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientRequestToken?: Array<string>;
        /**
         * commentId property
         *
         * Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly commentId?: Array<string>;
        /**
         * content property
         *
         * Specify an array of string values to match this event if the actual value of content is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly content?: Array<string>;
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
        /**
         * deleted property
         *
         * Specify an array of string values to match this event if the actual value of deleted is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deleted?: Array<string>;
        /**
         * inReplyTo property
         *
         * Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inReplyTo?: Array<string>;
        /**
         * lastModifiedDate property
         *
         * Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastModifiedDate?: Array<string>;
    }
    /**
     * Type definition for DeletedBranch
     *
     * @struct
     */
    interface DeletedBranch {
        /**
         * branchName property
         *
         * Specify an array of string values to match this event if the actual value of branchName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly branchName?: Array<string>;
        /**
         * commitId property
         *
         * Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly commitId?: Array<string>;
    }
    /**
     * Type definition for PullRequest
     *
     * @struct
     */
    interface PullRequest {
        /**
         * approvalRules property
         *
         * Specify an array of string values to match this event if the actual value of approvalRules is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly approvalRules?: Array<any>;
        /**
         * authorArn property
         *
         * Specify an array of string values to match this event if the actual value of authorArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly authorArn?: Array<string>;
        /**
         * clientRequestToken property
         *
         * Specify an array of string values to match this event if the actual value of clientRequestToken is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientRequestToken?: Array<string>;
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * lastActivityDate property
         *
         * Specify an array of string values to match this event if the actual value of lastActivityDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastActivityDate?: Array<string>;
        /**
         * pullRequestId property
         *
         * Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullRequestId?: Array<string>;
        /**
         * pullRequestStatus property
         *
         * Specify an array of string values to match this event if the actual value of pullRequestStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullRequestStatus?: Array<string>;
        /**
         * pullRequestTargets property
         *
         * Specify an array of string values to match this event if the actual value of pullRequestTargets is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullRequestTargets?: Array<AWSAPICallViaCloudTrail.PullRequestItem>;
        /**
         * revisionId property
         *
         * Specify an array of string values to match this event if the actual value of revisionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly revisionId?: Array<string>;
        /**
         * title property
         *
         * Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly title?: Array<string>;
    }
    /**
     * Type definition for PullRequestItem
     *
     * @struct
     */
    interface PullRequestItem {
        /**
         * mergeMetadata property
         *
         * Specify an array of string values to match this event if the actual value of mergeMetadata is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mergeMetadata?: AWSAPICallViaCloudTrail.MergeMetadata;
        /**
         * destinationCommit property
         *
         * Specify an array of string values to match this event if the actual value of destinationCommit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destinationCommit?: Array<string>;
        /**
         * destinationReference property
         *
         * Specify an array of string values to match this event if the actual value of destinationReference is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destinationReference?: Array<string>;
        /**
         * mergeBase property
         *
         * Specify an array of string values to match this event if the actual value of mergeBase is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mergeBase?: Array<string>;
        /**
         * repositoryName property
         *
         * Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryName?: Array<string>;
        /**
         * sourceCommit property
         *
         * Specify an array of string values to match this event if the actual value of sourceCommit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceCommit?: Array<string>;
        /**
         * sourceReference property
         *
         * Specify an array of string values to match this event if the actual value of sourceReference is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceReference?: Array<string>;
    }
    /**
     * Type definition for MergeMetadata
     *
     * @struct
     */
    interface MergeMetadata {
        /**
         * isMerged property
         *
         * Specify an array of string values to match this event if the actual value of isMerged is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly isMerged?: Array<string>;
        /**
         * mergeCommitId property
         *
         * Specify an array of string values to match this event if the actual value of mergeCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mergeCommitId?: Array<string>;
        /**
         * mergeOption property
         *
         * Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mergeOption?: Array<string>;
        /**
         * mergedBy property
         *
         * Specify an array of string values to match this event if the actual value of mergedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mergedBy?: Array<string>;
    }
    /**
     * Type definition for RepositoryMetadata
     *
     * @struct
     */
    interface RepositoryMetadata {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * cloneUrlHttp property
         *
         * Specify an array of string values to match this event if the actual value of cloneUrlHttp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cloneUrlHttp?: Array<string>;
        /**
         * cloneUrlSsh property
         *
         * Specify an array of string values to match this event if the actual value of cloneUrlSsh is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cloneUrlSsh?: Array<string>;
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
        /**
         * lastModifiedDate property
         *
         * Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastModifiedDate?: Array<string>;
        /**
         * repositoryDescription property
         *
         * Specify an array of string values to match this event if the actual value of repositoryDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryDescription?: Array<string>;
        /**
         * repositoryId property
         *
         * Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryId?: Array<string>;
        /**
         * repositoryName property
         *
         * Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryName?: Array<string>;
    }
    /**
     * Type definition for ResponseElementsItem
     *
     * @struct
     */
    interface ResponseElementsItem {
        /**
         * absolutePath property
         *
         * Specify an array of string values to match this event if the actual value of absolutePath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly absolutePath?: Array<string>;
        /**
         * blobId property
         *
         * Specify an array of string values to match this event if the actual value of blobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly blobId?: Array<string>;
        /**
         * fileMode property
         *
         * Specify an array of string values to match this event if the actual value of fileMode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileMode?: Array<string>;
    }
    /**
     * Type definition for UserIdentity
     *
     * @struct
     */
    interface UserIdentity {
        /**
         * sessionContext property
         *
         * Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionContext?: AWSAPICallViaCloudTrail.SessionContext;
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * userName property
         *
         * Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userName?: Array<string>;
    }
    /**
     * Type definition for SessionContext
     *
     * @struct
     */
    interface SessionContext {
        /**
         * attributes property
         *
         * Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attributes?: AWSAPICallViaCloudTrail.Attributes;
        /**
         * sessionIssuer property
         *
         * Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionIssuer?: AWSAPICallViaCloudTrail.SessionIssuer;
        /**
         * webIdFederationData property
         *
         * Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly webIdFederationData?: Array<string>;
    }
    /**
     * Type definition for Attributes
     *
     * @struct
     */
    interface Attributes {
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
        /**
         * mfaAuthenticated property
         *
         * Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mfaAuthenticated?: Array<string>;
    }
    /**
     * Type definition for SessionIssuer
     *
     * @struct
     */
    interface SessionIssuer {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * userName property
         *
         * Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userName?: Array<string>;
    }
    /**
     * Type definition for AWSAPICallViaCloudTrailItem
     *
     * @struct
     */
    interface AwsapiCallViaCloudTrailItem {
        /**
         * ARN property
         *
         * Specify an array of string values to match this event if the actual value of ARN is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.codecommit@CodeCommitApprovalRuleTemplateChange
 */
export declare class CodeCommitApprovalRuleTemplateChange {
    /**
     * EventBridge event pattern for CodeCommit Approval Rule Template Change
     */
    static eventPattern(options?: CodeCommitApprovalRuleTemplateChange.CodeCommitApprovalRuleTemplateChangeProps): events.EventPattern;
}
export declare namespace CodeCommitApprovalRuleTemplateChange {
    /**
     * Props type for aws.codecommit@CodeCommitApprovalRuleTemplateChange event
     */
    interface CodeCommitApprovalRuleTemplateChangeProps {
        /**
         * repositories property
         *
         * Specify an array of string values to match this event if the actual value of repositories is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositories?: Record<string, string>;
        /**
         * approvalRuleTemplateContentSha256 property
         *
         * Specify an array of string values to match this event if the actual value of approvalRuleTemplateContentSha256 is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly approvalRuleTemplateContentSha256?: Array<string>;
        /**
         * approvalRuleTemplateId property
         *
         * Specify an array of string values to match this event if the actual value of approvalRuleTemplateId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly approvalRuleTemplateId?: Array<string>;
        /**
         * approvalRuleTemplateName property
         *
         * Specify an array of string values to match this event if the actual value of approvalRuleTemplateName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly approvalRuleTemplateName?: Array<string>;
        /**
         * callerUserArn property
         *
         * Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly callerUserArn?: Array<string>;
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
        /**
         * event property
         *
         * Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly event?: Array<string>;
        /**
         * lastModifiedDate property
         *
         * Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastModifiedDate?: Array<string>;
        /**
         * notificationBody property
         *
         * Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notificationBody?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.codecommit@CodeCommitPullRequestStateChange
 */
export declare class CodeCommitPullRequestStateChange {
    /**
     * EventBridge event pattern for CodeCommit Pull Request State Change
     */
    static eventPattern(options?: CodeCommitPullRequestStateChange.CodeCommitPullRequestStateChangeProps): events.EventPattern;
}
export declare namespace CodeCommitPullRequestStateChange {
    /**
     * Props type for aws.codecommit@CodeCommitPullRequestStateChange event
     */
    interface CodeCommitPullRequestStateChangeProps {
        /**
         * approvalStatus property
         *
         * Specify an array of string values to match this event if the actual value of approvalStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly approvalStatus?: Array<string>;
        /**
         * author property
         *
         * Specify an array of string values to match this event if the actual value of author is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly author?: Array<string>;
        /**
         * callerUserArn property
         *
         * Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly callerUserArn?: Array<string>;
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * destinationCommit property
         *
         * Specify an array of string values to match this event if the actual value of destinationCommit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destinationCommit?: Array<string>;
        /**
         * destinationReference property
         *
         * Specify an array of string values to match this event if the actual value of destinationReference is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destinationReference?: Array<string>;
        /**
         * event property
         *
         * Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly event?: Array<string>;
        /**
         * isMerged property
         *
         * Specify an array of string values to match this event if the actual value of isMerged is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly isMerged?: Array<string>;
        /**
         * lastModifiedDate property
         *
         * Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastModifiedDate?: Array<string>;
        /**
         * mergeOption property
         *
         * Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mergeOption?: Array<string>;
        /**
         * notificationBody property
         *
         * Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notificationBody?: Array<string>;
        /**
         * overrideStatus property
         *
         * Specify an array of string values to match this event if the actual value of overrideStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly overrideStatus?: Array<string>;
        /**
         * pullRequestId property
         *
         * Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullRequestId?: Array<string>;
        /**
         * pullRequestStatus property
         *
         * Specify an array of string values to match this event if the actual value of pullRequestStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullRequestStatus?: Array<string>;
        /**
         * repositoryNames property
         *
         * Specify an array of string values to match this event if the actual value of repositoryNames is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryNames?: Array<string>;
        /**
         * revisionId property
         *
         * Specify an array of string values to match this event if the actual value of revisionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly revisionId?: Array<string>;
        /**
         * sourceCommit property
         *
         * Specify an array of string values to match this event if the actual value of sourceCommit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceCommit?: Array<string>;
        /**
         * sourceReference property
         *
         * Specify an array of string values to match this event if the actual value of sourceReference is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceReference?: Array<string>;
        /**
         * title property
         *
         * Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly title?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.codecommit@CodeCommitCommentOnCommit
 */
export declare class CodeCommitCommentOnCommit {
    /**
     * EventBridge event pattern for CodeCommit Comment on Commit
     */
    static eventPattern(options?: CodeCommitCommentOnCommit.CodeCommitCommentOnCommitProps): events.EventPattern;
}
export declare namespace CodeCommitCommentOnCommit {
    /**
     * Props type for aws.codecommit@CodeCommitCommentOnCommit event
     */
    interface CodeCommitCommentOnCommitProps {
        /**
         * beforeCommitId property
         *
         * Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly beforeCommitId?: Array<string>;
        /**
         * repositoryId property
         *
         * Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Repository reference
         */
        readonly repositoryId?: Array<string>;
        /**
         * inReplyTo property
         *
         * Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inReplyTo?: Array<string>;
        /**
         * notificationBody property
         *
         * Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notificationBody?: Array<string>;
        /**
         * commentId property
         *
         * Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly commentId?: Array<string>;
        /**
         * afterCommitId property
         *
         * Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly afterCommitId?: Array<string>;
        /**
         * event property
         *
         * Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly event?: Array<string>;
        /**
         * repositoryName property
         *
         * Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryName?: Array<string>;
        /**
         * callerUserArn property
         *
         * Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly callerUserArn?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event patterns for Repository
 */
export declare class RepositoryEvents {
    /**
     * Create RepositoryEvents from a Repository reference
     */
    static fromRepository(repositoryRef: service.IRepositoryRef): RepositoryEvents;
    /**
     * Reference to the Repository construct
     */
    private readonly repositoryRef;
    private constructor();
    /**
     * EventBridge event pattern for Repository CodeCommit Comment on Commit
     */
    codeCommitCommentOnCommitPattern(options?: CodeCommitCommentOnCommit.CodeCommitCommentOnCommitProps): events.EventPattern;
    /**
     * EventBridge event pattern for Repository CodeCommit Comment on Pull Request
     */
    codeCommitCommentOnPullRequestPattern(options?: CodeCommitCommentOnPullRequest.CodeCommitCommentOnPullRequestProps): events.EventPattern;
    /**
     * EventBridge event pattern for Repository CodeCommit Repository State Change
     */
    codeCommitRepositoryStateChangePattern(options?: CodeCommitRepositoryStateChange.CodeCommitRepositoryStateChangeProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.codecommit@CodeCommitCommentOnPullRequest
 */
export declare class CodeCommitCommentOnPullRequest {
    /**
     * EventBridge event pattern for CodeCommit Comment on Pull Request
     */
    static eventPattern(options?: CodeCommitCommentOnPullRequest.CodeCommitCommentOnPullRequestProps): events.EventPattern;
}
export declare namespace CodeCommitCommentOnPullRequest {
    /**
     * Props type for aws.codecommit@CodeCommitCommentOnPullRequest event
     */
    interface CodeCommitCommentOnPullRequestProps {
        /**
         * beforeCommitId property
         *
         * Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly beforeCommitId?: Array<string>;
        /**
         * repositoryId property
         *
         * Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Repository reference
         */
        readonly repositoryId?: Array<string>;
        /**
         * inReplyTo property
         *
         * Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inReplyTo?: Array<string>;
        /**
         * notificationBody property
         *
         * Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notificationBody?: Array<string>;
        /**
         * commentId property
         *
         * Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly commentId?: Array<string>;
        /**
         * afterCommitId property
         *
         * Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly afterCommitId?: Array<string>;
        /**
         * event property
         *
         * Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly event?: Array<string>;
        /**
         * repositoryName property
         *
         * Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryName?: Array<string>;
        /**
         * callerUserArn property
         *
         * Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly callerUserArn?: Array<string>;
        /**
         * pullRequestId property
         *
         * Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pullRequestId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.codecommit@CodeCommitRepositoryStateChange
 */
export declare class CodeCommitRepositoryStateChange {
    /**
     * EventBridge event pattern for CodeCommit Repository State Change
     */
    static eventPattern(options?: CodeCommitRepositoryStateChange.CodeCommitRepositoryStateChangeProps): events.EventPattern;
}
export declare namespace CodeCommitRepositoryStateChange {
    /**
     * Props type for aws.codecommit@CodeCommitRepositoryStateChange event
     */
    interface CodeCommitRepositoryStateChangeProps {
        /**
         * baseCommitId property
         *
         * Specify an array of string values to match this event if the actual value of baseCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly baseCommitId?: Array<string>;
        /**
         * callerUserArn property
         *
         * Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly callerUserArn?: Array<string>;
        /**
         * commitId property
         *
         * Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly commitId?: Array<string>;
        /**
         * conflictDetailLevel property
         *
         * Specify an array of string values to match this event if the actual value of conflictDetailLevel is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly conflictDetailLevel?: Array<string>;
        /**
         * conflictResolutionStrategy property
         *
         * Specify an array of string values to match this event if the actual value of conflictResolutionStrategy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly conflictResolutionStrategy?: Array<string>;
        /**
         * destinationCommitId property
         *
         * Specify an array of string values to match this event if the actual value of destinationCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly destinationCommitId?: Array<string>;
        /**
         * event property
         *
         * Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly event?: Array<string>;
        /**
         * mergeOption property
         *
         * Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mergeOption?: Array<string>;
        /**
         * oldCommitId property
         *
         * Specify an array of string values to match this event if the actual value of oldCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly oldCommitId?: Array<string>;
        /**
         * referenceFullName property
         *
         * Specify an array of string values to match this event if the actual value of referenceFullName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly referenceFullName?: Array<string>;
        /**
         * referenceName property
         *
         * Specify an array of string values to match this event if the actual value of referenceName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly referenceName?: Array<string>;
        /**
         * referenceType property
         *
         * Specify an array of string values to match this event if the actual value of referenceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly referenceType?: Array<string>;
        /**
         * repositoryId property
         *
         * Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Repository reference
         */
        readonly repositoryId?: Array<string>;
        /**
         * repositoryName property
         *
         * Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly repositoryName?: Array<string>;
        /**
         * sourceCommitId property
         *
         * Specify an array of string values to match this event if the actual value of sourceCommitId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceCommitId?: Array<string>;
        /**
         * conflictDetailsLevel property
         *
         * Specify an array of string values to match this event if the actual value of conflictDetailsLevel is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly conflictDetailsLevel?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
