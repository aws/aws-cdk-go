"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MIXINS_PREVIEW_BASE_NAMES = void 0;
exports.MIXINS_PREVIEW_BASE_NAMES = {
    javascript: '@aws-cdk/mixins-preview',
    dotnet: 'Amazon.CDK.Mixins.Preview',
    java: 'software.amazon.awscdk.mixins.preview',
    python: 'aws-cdk.mixins-preview',
};
