import type { Resource, Service, Event } from '@aws-cdk/service-spec-types';
import { ExternalModule } from '@cdklabs/typewriter';
import type { AddServiceProps, LibraryBuilderProps } from '@aws-cdk/spec2cdk/lib/cdk/library-builder';
import { LibraryBuilder } from '@aws-cdk/spec2cdk/lib/cdk/library-builder';
import type { ServiceSubmoduleProps } from '@aws-cdk/spec2cdk/lib/cdk/service-submodule';
import { BaseServiceSubmodule } from '@aws-cdk/spec2cdk/lib/cdk/service-submodule';
declare class EventBridgeServiceModule extends BaseServiceSubmodule {
    readonly constructLibModule: ExternalModule;
    constructor(props: ServiceSubmoduleProps);
}
export interface EventBridgeBuilderProps extends LibraryBuilderProps {
    filePattern?: string;
}
export declare class EventBridgeBuilder extends LibraryBuilder<EventBridgeServiceModule> {
    private readonly filePattern;
    constructor(props: EventBridgeBuilderProps);
    canBindToResource(event: Event, resource: Resource): boolean;
    protected createServiceSubmodule(service: Service, submoduleName: string): EventBridgeServiceModule;
    protected addResourceToSubmodule(submodule: EventBridgeServiceModule, resource: Resource, _props?: AddServiceProps): void;
    private generateStandaloneEvents;
    private createEventsModule;
    private obtainEventsModule;
}
export {};
