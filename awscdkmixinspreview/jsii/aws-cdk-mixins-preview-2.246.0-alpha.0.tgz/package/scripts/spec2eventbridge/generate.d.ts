import type { GenerateOptions as Spec2CdkOptions } from '@aws-cdk/spec2cdk';
import { EventBridgeBuilder } from './builder';
import type { GeneratorResult } from '@aws-cdk/spec2cdk/lib/module-topology';
type GenerateOptions = Pick<Spec2CdkOptions<typeof EventBridgeBuilder>, 'outputPath' | 'clearOutput' | 'debug'>;
export declare function generateAll(options: GenerateOptions): Promise<GeneratorResult>;
export {};
