export declare const MIXINS_PREVIEW_BASE_NAMES: {
    javascript: string;
    dotnet: string;
    java: string;
    python: string;
};
