import { Type, ExternalModule } from '@cdklabs/typewriter';
declare class MixinsLogsDelivery extends ExternalModule {
    readonly S3LogsDelivery: Type;
    readonly LogGroupLogsDelivery: Type;
    readonly FirehoseLogsDelivery: Type;
    readonly XRayLogsDelivery: Type;
    readonly DestLogsDelivery: Type;
    readonly ILogsDelivery: Type;
    readonly S3LogsDeliveryPermissionsVersion: import("@cdklabs/typewriter").TypeExpressionProxy<Type>;
}
export declare const MIXINS_LOGS_DELIVERY: MixinsLogsDelivery;
export {};
