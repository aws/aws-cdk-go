import type { Resource, Service } from '@aws-cdk/service-spec-types';
import { ExternalModule } from '@cdklabs/typewriter';
import type { ServiceSubmoduleProps } from '@aws-cdk/spec2cdk/lib/cdk/service-submodule';
import { BaseServiceSubmodule } from '@aws-cdk/spec2cdk/lib/cdk/service-submodule';
import type { AddServiceProps, LibraryBuilderProps } from '@aws-cdk/spec2cdk/lib/cdk/library-builder';
import { LibraryBuilder } from '@aws-cdk/spec2cdk/lib/cdk/library-builder';
declare class LogsDeliveryBuilderServiceModule extends BaseServiceSubmodule {
    readonly constructLibModule: ExternalModule;
    constructor(props: ServiceSubmoduleProps);
}
export interface LogsDeliveryBuilderProps extends LibraryBuilderProps {
}
export declare class LogsDeliveryBuilder extends LibraryBuilder<LogsDeliveryBuilderServiceModule> {
    private readonly filePattern;
    constructor(props: LogsDeliveryBuilderProps);
    protected createServiceSubmodule(service: Service, submoduleName: string): LogsDeliveryBuilderServiceModule;
    protected addResourceToSubmodule(submodule: LogsDeliveryBuilderServiceModule, resource: Resource, _props?: AddServiceProps): void;
    private obtainLogsDeliveryModule;
    private createLogsDeliveryModule;
}
export {};
