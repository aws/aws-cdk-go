"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogsDeliveryBuilder = void 0;
const spec2cdk_1 = require("@aws-cdk/spec2cdk");
const cdk_1 = require("@aws-cdk/spec2cdk/lib/cdk/cdk");
const typewriter_1 = require("@cdklabs/typewriter");
const helpers_1 = require("./helpers");
const service_submodule_1 = require("@aws-cdk/spec2cdk/lib/cdk/service-submodule");
const library_builder_1 = require("@aws-cdk/spec2cdk/lib/cdk/library-builder");
const reference_props_1 = require("@aws-cdk/spec2cdk/lib/cdk/reference-props");
class LogsDeliveryBuilderServiceModule extends service_submodule_1.BaseServiceSubmodule {
    constructLibModule;
    constructor(props) {
        super(props);
        this.constructLibModule = new typewriter_1.ExternalModule(`aws-cdk-lib/${props.submoduleName}`);
    }
}
class LogsDeliveryBuilder extends library_builder_1.LibraryBuilder {
    filePattern;
    constructor(props) {
        super(props);
        this.filePattern = '%moduleName%/logs-delivery-mixins.generated.ts';
    }
    createServiceSubmodule(service, submoduleName) {
        return new LogsDeliveryBuilderServiceModule({
            submoduleName,
            service,
        });
    }
    addResourceToSubmodule(submodule, resource, _props) {
        const resourceReference = new reference_props_1.ResourceReference(resource);
        if (resource.vendedLogs && resourceReference.hasArnGetter) {
            const service = this.db.incoming('hasResource', resource).only().entity;
            const logsModule = this.obtainLogsDeliveryModule(submodule, service);
            const vendedLogsMixin = new LogsDelivery(logsModule.module, this.db, resource, submodule.constructLibModule);
            submodule.registerResource(`${resource.cloudFormationType}VendedLogs`, vendedLogsMixin.mixin);
            vendedLogsMixin.build();
        }
    }
    obtainLogsDeliveryModule(submodule, service) {
        const mod = this.createLogsDeliveryModule(submodule, service);
        if (this.modules.has(mod.filePath)) {
            return {
                module: this.modules.get(mod.filePath),
                filePath: mod.filePath,
            };
        }
        return this.rememberModule(mod);
    }
    createLogsDeliveryModule(submodule, service) {
        const module = new typewriter_1.Module(`@aws-cdk/mixins-preview/${submodule.submoduleName}/logs`);
        const filePath = this.pathFor(this.filePattern, submodule.submoduleName, service);
        submodule.registerModule({ module, filePath });
        cdk_1.CDK_CORE.import(module, 'cdk');
        cdk_1.CDK_INTERFACES.import(module, 'interfaces');
        cdk_1.CONSTRUCTS.import(module, 'constructs');
        helpers_1.MIXINS_LOGS_DELIVERY.import(module, 'logsDelivery', { fromLocation: '../aws-logs/logs-delivery' });
        submodule.constructLibModule.import(module, 'service');
        return { module, filePath };
    }
}
exports.LogsDeliveryBuilder = LogsDeliveryBuilder;
class LogsDelivery {
    db;
    resource;
    scope;
    mixin;
    helpers = [];
    constructor(scope, db, resource, constructLibModule) {
        this.db = db;
        this.resource = resource;
        this.scope = scope;
        for (const log of this.resource.vendedLogs || []) {
            const logClass = new LogsHelper(this.scope, `${spec2cdk_1.naming.classNameFromResource(this.resource)}${log.logType.split('_').map(word => word.charAt(0) + word.slice(1).toLowerCase()).join('')}`, this.resource, log);
            this.helpers.push(logClass);
        }
        this.mixin = new LogsMixin(scope, db, resource, constructLibModule);
    }
    build() {
        this.mixin.build();
        for (const helper of this.helpers) {
            helper.build(this.mixin);
        }
    }
}
class LogsHelper extends typewriter_1.ClassType {
    log;
    constructor(scope, name, resource, log) {
        super(scope, {
            export: true,
            name: name,
            docs: {
                summary: `Builder for ${spec2cdk_1.naming.classNameFromResource(resource)}LogsMixin to generate ${log.logType} for ${spec2cdk_1.naming.classNameFromResource(resource)}`,
                stability: typewriter_1.Stability.External,
                docTags: {
                    cloudformationResource: resource.cloudFormationType,
                    logType: log.logType,
                },
            },
        });
        this.log = log;
    }
    build(mixin) {
        const logsNamespace = new typewriter_1.ClassType(this.scope, {
            name: `${this.name}OutputFormat`,
            export: true,
            docs: {
                summary: `Output Format options for each destination of ${this.name}.`,
            },
        });
        let recordFields;
        if (this.log.optionalFields || this.log.mandatoryFields) {
            recordFields = new typewriter_1.EnumType(this.scope, {
                name: `${this.name}RecordFields`,
                export: true,
            });
            if (this.log.optionalFields && this.log.optionalFields.length > 0) {
                populateRecordFieldsEnum(this.log.optionalFields, recordFields);
            }
            if (this.log.mandatoryFields && this.log.mandatoryFields.length > 0) {
                populateRecordFieldsEnum(this.log.mandatoryFields, recordFields);
            }
        }
        for (const dest of this.log.destinations) {
            switch (dest.destinationType) {
                case 'S3':
                    const toS3 = this.addMethod({
                        name: `to${dest.destinationType}`,
                        returnType: mixin.type,
                        docs: {
                            summary: 'Send logs to an S3 Bucket',
                        },
                    });
                    const paramS3 = toS3.addParameter({
                        name: 'bucket',
                        type: cdk_1.CDK_INTERFACES.IBucketRef,
                    });
                    const s3Props = new typewriter_1.InterfaceType(this.scope, {
                        name: `${this.name}S3Props`,
                        export: true,
                        properties: [{
                                name: 'encryptionKey',
                                type: cdk_1.CDK_INTERFACES.IKeyRef,
                                optional: true,
                                immutable: true,
                                docs: {
                                    summary: 'Encrpytion key for your delivery bucket',
                                },
                            }],
                    });
                    if (dest.outputFormats && dest.outputFormats.length > 0) {
                        const s3OutputFormat = new typewriter_1.EnumType(logsNamespace, {
                            name: 'S3',
                            export: true,
                        });
                        for (const format of dest.outputFormats) {
                            s3OutputFormat.addMember({ name: format.toUpperCase(), value: format });
                        }
                        s3Props.addProperty({
                            name: 'outputFormat',
                            type: s3OutputFormat.type,
                            optional: true,
                            immutable: true,
                            docs: {
                                summary: `Format for log output, options are ${dest.outputFormats.join(',')}`,
                            },
                        });
                    }
                    if (recordFields) {
                        s3Props.addProperty({
                            name: 'recordFields',
                            type: typewriter_1.Type.arrayOf(recordFields.type),
                            optional: true,
                            immutable: true,
                            docs: {
                                summary: 'Record fields that can be provided to a log delivery',
                            },
                        });
                    }
                    toS3.addParameter({
                        name: 'props',
                        type: s3Props.type,
                        optional: true,
                        documentation: 'Additional properties that are optionally used in log delivery for S3 destinations',
                    });
                    const permissions = this.log.permissionsVersion === 'V2' ? helpers_1.MIXINS_LOGS_DELIVERY.S3LogsDeliveryPermissionsVersion.V2 : helpers_1.MIXINS_LOGS_DELIVERY.S3LogsDeliveryPermissionsVersion.V1;
                    toS3.addBody(typewriter_1.stmt.block(typewriter_1.stmt.ret(mixin.newInstance(typewriter_1.expr.str(this.log.logType), new typewriter_1.NewExpression(helpers_1.MIXINS_LOGS_DELIVERY.S3LogsDelivery, paramS3, typewriter_1.expr.object({
                        permissionsVersion: permissions,
                        kmsKey: typewriter_1.expr.directCode('props?.encryptionKey'),
                        outputFormat: typewriter_1.expr.directCode('props?.outputFormat'),
                        providedFields: recordFields ? typewriter_1.expr.directCode('props?.recordFields') : typewriter_1.expr.UNDEFINED,
                        mandatoryFields: this.log.mandatoryFields ? typewriter_1.expr.directCode(JSON.stringify(this.log.mandatoryFields)) : typewriter_1.expr.UNDEFINED,
                    }))))));
                    break;
                case 'CWL':
                    const toCWL = this.addMethod({
                        name: 'toLogGroup',
                        returnType: mixin.type,
                        docs: {
                            summary: 'Send logs to a CloudWatch Log Group',
                        },
                    });
                    const paramCWL = toCWL.addParameter({
                        name: 'logGroup',
                        type: cdk_1.CDK_INTERFACES.ILogGroupRef,
                    });
                    const hasLogGroupOutputFormats = dest.outputFormats && dest.outputFormats.length > 0;
                    const hasLogGroupProps = hasLogGroupOutputFormats || recordFields;
                    if (hasLogGroupProps) {
                        const logGroupProps = new typewriter_1.InterfaceType(this.scope, {
                            name: `${this.name}LogGroupProps`,
                            export: true,
                        });
                        if (hasLogGroupOutputFormats) {
                            const lgOutputFormat = new typewriter_1.EnumType(logsNamespace, {
                                name: 'LogGroup',
                                export: true,
                            });
                            for (const format of dest.outputFormats) {
                                lgOutputFormat.addMember({ name: format.toUpperCase(), value: format });
                            }
                            logGroupProps.addProperty({
                                name: 'outputFormat',
                                type: lgOutputFormat.type,
                                optional: true,
                                immutable: true,
                                docs: {
                                    summary: `Format for log output, options are ${dest.outputFormats.join(',')}`,
                                },
                            });
                        }
                        if (recordFields) {
                            logGroupProps.addProperty({
                                name: 'recordFields',
                                type: typewriter_1.Type.arrayOf(recordFields.type),
                                optional: true,
                                immutable: true,
                                docs: {
                                    summary: 'Record fields that can be provided to a log delivery',
                                },
                            });
                        }
                        toCWL.addParameter({
                            name: 'props',
                            type: logGroupProps.type,
                            optional: true,
                            documentation: 'Additional properties that are optionally used in log delivery for Log Group destinations',
                        });
                    }
                    toCWL.addBody(typewriter_1.stmt.block(typewriter_1.stmt.ret(mixin.newInstance(typewriter_1.expr.str(this.log.logType), new typewriter_1.NewExpression(helpers_1.MIXINS_LOGS_DELIVERY.LogGroupLogsDelivery, paramCWL, typewriter_1.expr.object({
                        outputFormat: typewriter_1.expr.directCode('props?.outputFormat'),
                        providedFields: recordFields ? typewriter_1.expr.directCode('props?.recordFields') : typewriter_1.expr.UNDEFINED,
                        mandatoryFields: this.log.mandatoryFields ? typewriter_1.expr.directCode(JSON.stringify(this.log.mandatoryFields)) : typewriter_1.expr.UNDEFINED,
                    }))))));
                    break;
                case 'FH':
                    const toFH = this.addMethod({
                        name: 'toFirehose',
                        returnType: mixin.type,
                        docs: {
                            summary: 'Send logs to a Firehose Delivery Stream',
                        },
                    });
                    const paramFH = toFH.addParameter({
                        name: 'deliveryStream',
                        type: cdk_1.CDK_INTERFACES.IDeliveryStreamRef,
                    });
                    const hasFirehoseOutputFormats = dest.outputFormats && dest.outputFormats.length > 0;
                    const hasFirehoseProps = hasFirehoseOutputFormats || recordFields;
                    if (hasFirehoseProps) {
                        const firehoseProps = new typewriter_1.InterfaceType(this.scope, {
                            name: `${this.name}FirehoseProps`,
                            export: true,
                        });
                        if (hasFirehoseOutputFormats) {
                            const fhOutputFormat = new typewriter_1.EnumType(logsNamespace, {
                                name: 'Firehose',
                                export: true,
                            });
                            for (const format of dest.outputFormats) {
                                fhOutputFormat.addMember({ name: format.toUpperCase(), value: format });
                            }
                            firehoseProps.addProperty({
                                name: 'outputFormat',
                                type: fhOutputFormat.type,
                                optional: true,
                                immutable: true,
                                docs: {
                                    summary: `Format for log output, options are ${dest.outputFormats.join(',')}`,
                                },
                            });
                        }
                        if (recordFields) {
                            firehoseProps.addProperty({
                                name: 'recordFields',
                                type: typewriter_1.Type.arrayOf(recordFields.type),
                                optional: true,
                                immutable: true,
                                docs: {
                                    summary: 'Record fields that can be provided to a log delivery',
                                },
                            });
                        }
                        toFH.addParameter({
                            name: 'props',
                            type: firehoseProps.type,
                            optional: true,
                            documentation: 'Additional properties that are optionally used in log delivery for Firehose destinations',
                        });
                    }
                    toFH.addBody(typewriter_1.stmt.block(typewriter_1.stmt.ret(mixin.newInstance(typewriter_1.expr.str(this.log.logType), new typewriter_1.NewExpression(helpers_1.MIXINS_LOGS_DELIVERY.FirehoseLogsDelivery, paramFH, typewriter_1.expr.object({
                        outputFormat: typewriter_1.expr.directCode('props?.outputFormat'),
                        providedFields: recordFields ? typewriter_1.expr.directCode('props?.recordFields') : typewriter_1.expr.UNDEFINED,
                        mandatoryFields: this.log.mandatoryFields ? typewriter_1.expr.directCode(JSON.stringify(this.log.mandatoryFields)) : typewriter_1.expr.UNDEFINED,
                    }))))));
                    break;
                default:
                    const toXRAY = this.addMethod({
                        name: 'toXRay',
                        returnType: mixin.type,
                        docs: {
                            summary: 'Send traces to X-Ray',
                        },
                    });
                    if (recordFields) {
                        const xrayProps = new typewriter_1.InterfaceType(this.scope, {
                            name: `${this.name}XRayProps`,
                            export: true,
                        });
                        xrayProps.addProperty({
                            name: 'recordFields',
                            type: typewriter_1.Type.arrayOf(recordFields.type),
                            optional: true,
                            immutable: true,
                            docs: {
                                summary: 'Record fields that can be provided to a log delivery',
                            },
                        });
                        toXRAY.addParameter({
                            name: 'props',
                            type: xrayProps.type,
                            optional: true,
                            documentation: 'Additional properties that are optionally used in log delivery for XRay destinations',
                        });
                    }
                    toXRAY.addBody(typewriter_1.stmt.block(typewriter_1.stmt.ret(mixin.newInstance(typewriter_1.expr.str(this.log.logType), new typewriter_1.NewExpression(helpers_1.MIXINS_LOGS_DELIVERY.XRayLogsDelivery, typewriter_1.expr.object({
                        providedFields: recordFields ? typewriter_1.expr.directCode('props?.recordFields') : typewriter_1.expr.UNDEFINED,
                        mandatoryFields: this.log.mandatoryFields ? typewriter_1.expr.directCode(JSON.stringify(this.log.mandatoryFields)) : typewriter_1.expr.UNDEFINED,
                    }))))));
                    break;
            }
        }
        const toDest = this.addMethod({
            name: 'toDestination',
            returnType: mixin.type,
            docs: {
                summary: 'Delivers logs to a pre-created delivery destination',
                remarks: `Supported destinations are ${this.log.destinations.map(d => d.destinationType).join(', ')}\n` +
                    'You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.\n' +
                    'Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().',
            },
        });
        const paramDest = toDest.addParameter({
            name: 'destination',
            type: cdk_1.CDK_INTERFACES.IDeliveryDestinationRef,
        });
        if (recordFields) {
            const destProps = new typewriter_1.InterfaceType(this.scope, {
                name: `${this.name}DestProps`,
                export: true,
            });
            destProps.addProperty({
                name: 'recordFields',
                type: typewriter_1.Type.arrayOf(recordFields.type),
                optional: true,
                immutable: true,
                docs: {
                    summary: 'Record fields that can be provided to a log delivery',
                },
            });
            toDest.addParameter({
                name: 'props',
                type: destProps.type,
                optional: true,
                documentation: 'Additional properties that are optionally used in log delivery for destinations',
            });
        }
        toDest.addBody(typewriter_1.stmt.block(typewriter_1.stmt.ret(mixin.newInstance(typewriter_1.expr.str(this.log.logType), new typewriter_1.NewExpression(helpers_1.MIXINS_LOGS_DELIVERY.DestLogsDelivery, paramDest, typewriter_1.expr.object({
            providedFields: recordFields ? typewriter_1.expr.directCode('props?.recordFields') : typewriter_1.expr.UNDEFINED,
            mandatoryFields: this.log.mandatoryFields ? typewriter_1.expr.directCode(JSON.stringify(this.log.mandatoryFields)) : typewriter_1.expr.UNDEFINED,
        }))))));
        mixin.addProperty({
            name: this.log.logType,
            type: this.type,
            static: true,
            immutable: true,
            initializer: typewriter_1.expr.directCode(`new ${this.name}()`),
        });
    }
}
class LogsMixin extends typewriter_1.ClassType {
    db;
    resource;
    resourceType;
    constructor(scope, db, resource, constructLibModule) {
        super(scope, {
            export: true,
            name: `${spec2cdk_1.naming.classNameFromResource(resource)}LogsMixin`,
            implements: [cdk_1.CONSTRUCTS.IMixin],
            extends: cdk_1.CDK_CORE.Mixin,
            docs: {
                summary: `Mixin to implement vended logs for ${resource.cloudFormationType}`,
                ...spec2cdk_1.util.splitDocumentation(resource.documentation),
                stability: typewriter_1.Stability.External,
                docTags: {
                    cloudformationResource: resource.cloudFormationType,
                    mixin: 'true',
                },
                see: spec2cdk_1.naming.cloudFormationDocLink({
                    resourceType: resource.cloudFormationType,
                }),
            },
        });
        this.db = db;
        this.resource = resource;
        this.resourceType = typewriter_1.Type.fromName(constructLibModule, spec2cdk_1.naming.classNameFromResource(this.resource));
    }
    /**
     * Build the elements of the VendedLogsMixin Class
     */
    build() {
        this.makeConstructor();
        const supports = this.makeSupportsMethod();
        this.makeApplyToMethod(supports);
    }
    makeConstructor() {
        this.addProperty({
            name: 'logType',
            type: typewriter_1.Type.STRING,
            protected: true,
            immutable: true,
        });
        this.addProperty({
            name: 'logDelivery',
            type: helpers_1.MIXINS_LOGS_DELIVERY.ILogsDelivery,
            protected: true,
            immutable: true,
        });
        const init = this.addInitializer({
            docs: {
                summary: `Create a mixin to enable vended logs for \`${this.resource.cloudFormationType}\`.`,
            },
        });
        const logType = init.addParameter({
            name: 'logType',
            type: typewriter_1.Type.STRING,
            documentation: 'Type of logs that are getting vended',
        });
        const delivery = init.addParameter({
            name: 'logDelivery',
            type: helpers_1.MIXINS_LOGS_DELIVERY.ILogsDelivery,
            documentation: 'Object in charge of setting up the delivery source, delivery destination, and delivery connection',
        });
        init.addBody(typewriter_1.expr.sym(new typewriter_1.ThingSymbol('super', this.scope)).call(), typewriter_1.stmt.assign(typewriter_1.$this.logType, logType), typewriter_1.stmt.assign(typewriter_1.$this.logDelivery, delivery));
    }
    makeSupportsMethod() {
        const method = this.addMethod({
            name: 'supports',
            returnType: typewriter_1.Type.ambient(`construct is service.${this.resourceType.symbol}`),
            docs: {
                summary: 'Check if this mixin supports the given construct (has vendedLogs property)',
            },
        });
        const construct = method.addParameter({
            name: 'construct',
            type: cdk_1.CONSTRUCTS.IConstruct,
        });
        method.addBody(typewriter_1.stmt.ret(typewriter_1.expr.binOp(typewriter_1.CallableProxy.fromName('CfnResource.isCfnResource', cdk_1.CDK_CORE).invoke(construct), '&&', (0, typewriter_1.$T)(this.resourceType)[`is${this.resourceType.symbol}`](construct))));
        return method;
    }
    makeApplyToMethod(supports) {
        const method = this.addMethod({
            name: 'applyTo',
            returnType: typewriter_1.Type.VOID,
            docs: {
                summary: 'Apply vended logs configuration to the construct',
            },
        });
        const resource = method.addParameter({
            name: 'resource',
            type: cdk_1.CONSTRUCTS.IConstruct,
        });
        const sourceArn = typewriter_1.expr.ident('sourceArn');
        const arnBuilder = (0, typewriter_1.$E)(typewriter_1.expr.sym(this.resourceType.symbol)).callMethod(`arnFor${this.resource.name}`, resource);
        method.addBody(typewriter_1.stmt
            .if_(typewriter_1.expr.not(typewriter_1.CallableProxy.fromMethod(supports).invoke(resource)))
            .then(typewriter_1.stmt.block(typewriter_1.stmt.ret())), typewriter_1.stmt.constVar(sourceArn, arnBuilder), typewriter_1.$this.logDelivery.callMethod('bind', resource, typewriter_1.$this.logType, sourceArn));
    }
}
function populateRecordFieldsEnum(fieldArray, recordFields) {
    for (let field of fieldArray) {
        // field names must be valid typescript identifiers, which means they cannot have a number as their first character and the only special character they can have are $ or _
        const fieldName = field.match(/^(\d+)/) ? '_' + field : field;
        recordFields.addMember({ name: fieldName.split(/[^a-zA-Z0-9$_]+/).join('_').toUpperCase(), value: field });
    }
}
