"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MIXINS_LOGS_DELIVERY = void 0;
const typewriter_1 = require("@cdklabs/typewriter");
class MixinsLogsDelivery extends typewriter_1.ExternalModule {
    S3LogsDelivery = typewriter_1.Type.fromName(this, 'S3LogsDelivery');
    LogGroupLogsDelivery = typewriter_1.Type.fromName(this, 'LogGroupLogsDelivery');
    FirehoseLogsDelivery = typewriter_1.Type.fromName(this, 'FirehoseLogsDelivery');
    XRayLogsDelivery = typewriter_1.Type.fromName(this, 'XRayLogsDelivery');
    DestLogsDelivery = typewriter_1.Type.fromName(this, 'DestinationLogsDelivery');
    ILogsDelivery = typewriter_1.Type.fromName(this, 'ILogsDelivery');
    S3LogsDeliveryPermissionsVersion = (0, typewriter_1.$T)(typewriter_1.Type.fromName(this, 'S3LogsDeliveryPermissionsVersion'));
}
exports.MIXINS_LOGS_DELIVERY = new MixinsLogsDelivery('@aws-cdk/mixins-preview/services/aws-logs');
