import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.deadline@FleetSizeRecommendationChange
 */
export declare class FleetSizeRecommendationChange {
    /**
     * EventBridge event pattern for Fleet Size Recommendation Change
     */
    static fleetSizeRecommendationChangePattern(options?: FleetSizeRecommendationChange.FleetSizeRecommendationChangeProps): events.EventPattern;
}
export declare namespace FleetSizeRecommendationChange {
    /**
     * Props type for aws.deadline@FleetSizeRecommendationChange event
     */
    interface FleetSizeRecommendationChangeProps {
        /**
         * farmId property
         *
         * Specify an array of string values to match this event if the actual value of farmId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly farmId?: Array<string>;
        /**
         * fleetId property
         *
         * Specify an array of string values to match this event if the actual value of fleetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fleetId?: Array<string>;
        /**
         * newFleetSize property
         *
         * Specify an array of string values to match this event if the actual value of newFleetSize is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly newFleetSize?: Array<string>;
        /**
         * oldFleetSize property
         *
         * Specify an array of string values to match this event if the actual value of oldFleetSize is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly oldFleetSize?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
