import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-iotanalytics";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.iotanalytics@AWSAPICallViaCloudTrail
 */
export declare class AWSAPICallViaCloudTrail {
    /**
     * EventBridge event pattern for AWS API Call via CloudTrail
     */
    static awsAPICallViaCloudTrailPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
}
export declare namespace AWSAPICallViaCloudTrail {
    /**
     * Props type for aws.iotanalytics@AWSAPICallViaCloudTrail event
     */
    interface AWSAPICallViaCloudTrailProps {
        /**
         * requestParameters property
         *
         * Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestParameters?: AWSAPICallViaCloudTrail.RequestParameters;
        /**
         * responseElements property
         *
         * Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly responseElements?: AWSAPICallViaCloudTrail.ResponseElements;
        /**
         * userIdentity property
         *
         * Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userIdentity?: AWSAPICallViaCloudTrail.UserIdentity;
        /**
         * awsRegion property
         *
         * Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsRegion?: Array<string>;
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * eventID property
         *
         * Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * eventSource property
         *
         * Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventSource?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * eventVersion property
         *
         * Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventVersion?: Array<string>;
        /**
         * requestID property
         *
         * Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * sourceIPAddress property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for RequestParameters
     *
     * @struct
     */
    interface RequestParameters {
        /**
         * channelStorage property
         *
         * Specify an array of string values to match this event if the actual value of channelStorage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelStorage?: AWSAPICallViaCloudTrail.ChannelStorage;
        /**
         * datastoreStorage property
         *
         * Specify an array of string values to match this event if the actual value of datastoreStorage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreStorage?: AWSAPICallViaCloudTrail.ChannelStorage;
        /**
         * loggingOptions property
         *
         * Specify an array of string values to match this event if the actual value of loggingOptions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly loggingOptions?: AWSAPICallViaCloudTrail.LoggingOptions;
        /**
         * pipelineActivity property
         *
         * Specify an array of string values to match this event if the actual value of pipelineActivity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipelineActivity?: AWSAPICallViaCloudTrail.PipelineActivity;
        /**
         * queryAction property
         *
         * Specify an array of string values to match this event if the actual value of queryAction is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queryAction?: AWSAPICallViaCloudTrail.QueryAction;
        /**
         * retentionPeriod property
         *
         * Specify an array of string values to match this event if the actual value of retentionPeriod is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly retentionPeriod?: AWSAPICallViaCloudTrail.RetentionPeriod;
        /**
         * settings property
         *
         * Specify an array of string values to match this event if the actual value of settings is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly settings?: AWSAPICallViaCloudTrail.Settings;
        /**
         * channelName property
         *
         * Specify an array of string values to match this event if the actual value of channelName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelName?: Array<string>;
        /**
         * datasetName property
         *
         * Specify an array of string values to match this event if the actual value of datasetName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datasetName?: Array<string>;
        /**
         * datastoreIndexName property
         *
         * Specify an array of string values to match this event if the actual value of datastoreIndexName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreIndexName?: Array<string>;
        /**
         * datastoreName property
         *
         * Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreName?: Array<string>;
        /**
         * endTime property
         *
         * Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * maxMessages property
         *
         * Specify an array of string values to match this event if the actual value of maxMessages is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxMessages?: Array<string>;
        /**
         * payloads property
         *
         * Specify an array of string values to match this event if the actual value of payloads is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly payloads?: Array<AWSAPICallViaCloudTrail.RequestParametersItem>;
        /**
         * pipelineName property
         *
         * Specify an array of string values to match this event if the actual value of pipelineName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipelineName?: Array<string>;
        /**
         * reprocessingId property
         *
         * Specify an array of string values to match this event if the actual value of reprocessingId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reprocessingId?: Array<string>;
        /**
         * resourceArn property
         *
         * Specify an array of string values to match this event if the actual value of resourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceArn?: Array<string>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * tagKeys property
         *
         * Specify an array of string values to match this event if the actual value of tagKeys is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tagKeys?: Array<string>;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<AWSAPICallViaCloudTrail.RequestParametersItem1>;
        /**
         * versionId property
         *
         * Specify an array of string values to match this event if the actual value of versionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
    }
    /**
     * Type definition for ChannelStorage
     *
     * @struct
     */
    interface ChannelStorage {
        /**
         * customerManagedS3 property
         *
         * Specify an array of string values to match this event if the actual value of customerManagedS3 is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly customerManagedS3?: AWSAPICallViaCloudTrail.CustomerManagedS3;
    }
    /**
     * Type definition for CustomerManagedS3
     *
     * @struct
     */
    interface CustomerManagedS3 {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: Array<string>;
        /**
         * keyPrefix property
         *
         * Specify an array of string values to match this event if the actual value of keyPrefix is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly keyPrefix?: Array<string>;
        /**
         * roleArn property
         *
         * Specify an array of string values to match this event if the actual value of roleArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly roleArn?: Array<string>;
    }
    /**
     * Type definition for LoggingOptions
     *
     * @struct
     */
    interface LoggingOptions {
        /**
         * enabled property
         *
         * Specify an array of string values to match this event if the actual value of enabled is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly enabled?: Array<string>;
    }
    /**
     * Type definition for PipelineActivity
     *
     * @struct
     */
    interface PipelineActivity {
        /**
         * math property
         *
         * Specify an array of string values to match this event if the actual value of math is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly math?: AWSAPICallViaCloudTrail.MathType;
    }
    /**
     * Type definition for Math
     *
     * @struct
     */
    interface MathType {
        /**
         * attribute property
         *
         * Specify an array of string values to match this event if the actual value of attribute is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attribute?: Array<string>;
        /**
         * math property
         *
         * Specify an array of string values to match this event if the actual value of math is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly math?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for QueryAction
     *
     * @struct
     */
    interface QueryAction {
        /**
         * sqlQuery property
         *
         * Specify an array of string values to match this event if the actual value of sqlQuery is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sqlQuery?: Array<string>;
    }
    /**
     * Type definition for RetentionPeriod
     *
     * @struct
     */
    interface RetentionPeriod {
        /**
         * numberOfDays property
         *
         * Specify an array of string values to match this event if the actual value of numberOfDays is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly numberOfDays?: Array<string>;
        /**
         * unlimited property
         *
         * Specify an array of string values to match this event if the actual value of unlimited is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unlimited?: Array<string>;
    }
    /**
     * Type definition for Settings
     *
     * @struct
     */
    interface Settings {
        /**
         * timeseries property
         *
         * Specify an array of string values to match this event if the actual value of timeseries is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly timeseries?: AWSAPICallViaCloudTrail.Timeseries;
    }
    /**
     * Type definition for Timeseries
     *
     * @struct
     */
    interface Timeseries {
        /**
         * dimensionAttributes property
         *
         * Specify an array of string values to match this event if the actual value of dimensionAttributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dimensionAttributes?: Array<AWSAPICallViaCloudTrail.TimeseriesItem>;
        /**
         * measureAttributes property
         *
         * Specify an array of string values to match this event if the actual value of measureAttributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly measureAttributes?: Array<AWSAPICallViaCloudTrail.TimeseriesItem>;
        /**
         * timestampAttribute property
         *
         * Specify an array of string values to match this event if the actual value of timestampAttribute is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly timestampAttribute?: Array<string>;
    }
    /**
     * Type definition for TimeseriesItem
     *
     * @struct
     */
    interface TimeseriesItem {
        /**
         * attribute property
         *
         * Specify an array of string values to match this event if the actual value of attribute is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attribute?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for RequestParametersItem
     *
     * @struct
     */
    interface RequestParametersItem {
        /**
         * address property
         *
         * Specify an array of string values to match this event if the actual value of address is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly address?: Array<string>;
        /**
         * bigEndian property
         *
         * Specify an array of string values to match this event if the actual value of bigEndian is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bigEndian?: Array<string>;
        /**
         * capacity property
         *
         * Specify an array of string values to match this event if the actual value of capacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly capacity?: Array<string>;
        /**
         * hb property
         *
         * Specify an array of string values to match this event if the actual value of hb is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hb?: Array<number>;
        /**
         * isReadOnly property
         *
         * Specify an array of string values to match this event if the actual value of isReadOnly is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly isReadOnly?: Array<string>;
        /**
         * limit property
         *
         * Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly limit?: Array<string>;
        /**
         * mark property
         *
         * Specify an array of string values to match this event if the actual value of mark is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mark?: Array<string>;
        /**
         * nativeByteOrder property
         *
         * Specify an array of string values to match this event if the actual value of nativeByteOrder is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly nativeByteOrder?: Array<string>;
        /**
         * offset property
         *
         * Specify an array of string values to match this event if the actual value of offset is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly offset?: Array<string>;
        /**
         * position property
         *
         * Specify an array of string values to match this event if the actual value of position is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly position?: Array<string>;
    }
    /**
     * Type definition for RequestParametersItem_1
     *
     * @struct
     */
    interface RequestParametersItem1 {
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for ResponseElements
     *
     * @struct
     */
    interface ResponseElements {
        /**
         * retentionPeriod property
         *
         * Specify an array of string values to match this event if the actual value of retentionPeriod is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly retentionPeriod?: AWSAPICallViaCloudTrail.RetentionPeriod1;
        /**
         * channelArn property
         *
         * Specify an array of string values to match this event if the actual value of channelArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelArn?: Array<string>;
        /**
         * channelName property
         *
         * Specify an array of string values to match this event if the actual value of channelName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelName?: Array<string>;
        /**
         * datasetArn property
         *
         * Specify an array of string values to match this event if the actual value of datasetArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datasetArn?: Array<string>;
        /**
         * datasetName property
         *
         * Specify an array of string values to match this event if the actual value of datasetName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datasetName?: Array<string>;
        /**
         * datastoreArn property
         *
         * Specify an array of string values to match this event if the actual value of datastoreArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreArn?: Array<string>;
        /**
         * datastoreIndexArn property
         *
         * Specify an array of string values to match this event if the actual value of datastoreIndexArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreIndexArn?: Array<string>;
        /**
         * datastoreIndexName property
         *
         * Specify an array of string values to match this event if the actual value of datastoreIndexName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreIndexName?: Array<string>;
        /**
         * datastoreName property
         *
         * Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datastoreName?: Array<string>;
        /**
         * pipelineArn property
         *
         * Specify an array of string values to match this event if the actual value of pipelineArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipelineArn?: Array<string>;
        /**
         * pipelineName property
         *
         * Specify an array of string values to match this event if the actual value of pipelineName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipelineName?: Array<string>;
        /**
         * reprocessingId property
         *
         * Specify an array of string values to match this event if the actual value of reprocessingId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reprocessingId?: Array<string>;
        /**
         * versionId property
         *
         * Specify an array of string values to match this event if the actual value of versionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
    }
    /**
     * Type definition for RetentionPeriod_1
     *
     * @struct
     */
    interface RetentionPeriod1 {
        /**
         * numberOfDays property
         *
         * Specify an array of string values to match this event if the actual value of numberOfDays is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly numberOfDays?: Array<string>;
        /**
         * unlimited property
         *
         * Specify an array of string values to match this event if the actual value of unlimited is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unlimited?: Array<string>;
    }
    /**
     * Type definition for UserIdentity
     *
     * @struct
     */
    interface UserIdentity {
        /**
         * sessionContext property
         *
         * Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionContext?: AWSAPICallViaCloudTrail.SessionContext;
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for SessionContext
     *
     * @struct
     */
    interface SessionContext {
        /**
         * attributes property
         *
         * Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attributes?: AWSAPICallViaCloudTrail.Attributes;
        /**
         * sessionIssuer property
         *
         * Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionIssuer?: AWSAPICallViaCloudTrail.SessionIssuer;
        /**
         * webIdFederationData property
         *
         * Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly webIdFederationData?: AWSAPICallViaCloudTrail.WebIdFederationData;
    }
    /**
     * Type definition for Attributes
     *
     * @struct
     */
    interface Attributes {
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
        /**
         * mfaAuthenticated property
         *
         * Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mfaAuthenticated?: Array<string>;
    }
    /**
     * Type definition for SessionIssuer
     *
     * @struct
     */
    interface SessionIssuer {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * userName property
         *
         * Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userName?: Array<string>;
    }
    /**
     * Type definition for WebIdFederationData
     *
     * @struct
     */
    interface WebIdFederationData {
        /**
         * federatedProvider property
         *
         * Specify an array of string values to match this event if the actual value of federatedProvider is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly federatedProvider?: Array<string>;
        /**
         * attributes property
         *
         * Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attributes?: Record<string, string>;
    }
}
/**
 * EventBridge event pattern for aws.iotanalytics@IoTAnalyticsDataSetLifeCycleNotification
 */
export declare class IoTAnalyticsDataSetLifeCycleNotification {
    /**
     * EventBridge event pattern for IoT Analytics DataSet Lifecycle Notification
     */
    static ioTAnalyticsDataSetLifeCycleNotificationPattern(options?: IoTAnalyticsDataSetLifeCycleNotification.IoTAnalyticsDataSetLifeCycleNotificationProps): events.EventPattern;
}
export declare namespace IoTAnalyticsDataSetLifeCycleNotification {
    /**
     * Props type for aws.iotanalytics@IoTAnalyticsDataSetLifeCycleNotification event
     */
    interface IoTAnalyticsDataSetLifeCycleNotificationProps {
        /**
         * event-detail-version property
         *
         * Specify an array of string values to match this event if the actual value of event-detail-version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventDetailVersion?: Array<string>;
        /**
         * version-id property
         *
         * Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * dataset-name property
         *
         * Specify an array of string values to match this event if the actual value of dataset-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Dataset reference
         */
        readonly datasetName?: Array<string>;
        /**
         * content-delivery-rule-index property
         *
         * Specify an array of string values to match this event if the actual value of content-delivery-rule-index is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly contentDeliveryRuleIndex?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event patterns for Dataset
 */
export declare class DatasetEvents {
    /**
     * Create DatasetEvents from a Dataset reference
     */
    static fromDataset(datasetRef: service.IDatasetRef): DatasetEvents;
    /**
     * Reference to the Dataset construct
     */
    private readonly datasetRef;
    private constructor();
    /**
     * EventBridge event pattern for Dataset IoT Analytics DataSet Lifecycle Notification
     */
    ioTAnalyticsDataSetLifeCycleNotificationPattern(options?: IoTAnalyticsDataSetLifeCycleNotification.IoTAnalyticsDataSetLifeCycleNotificationProps): events.EventPattern;
}
