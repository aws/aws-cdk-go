import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.imagebuilder@EC2ImageBuilderCVEDetected
 */
export declare class EC2ImageBuilderCVEDetected {
    /**
     * EventBridge event pattern for EC2 Image Builder CVE Detected
     */
    static ec2ImageBuilderCVEDetectedPattern(options?: EC2ImageBuilderCVEDetected.EC2ImageBuilderCVEDetectedProps): events.EventPattern;
}
export declare namespace EC2ImageBuilderCVEDetected {
    /**
     * Props type for aws.imagebuilder@EC2ImageBuilderCVEDetected event
     */
    interface EC2ImageBuilderCVEDetectedProps {
        /**
         * finding-severity-counts property
         *
         * Specify an array of string values to match this event if the actual value of finding-severity-counts is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly findingSeverityCounts?: EC2ImageBuilderCVEDetected.FindingSeverityCounts;
        /**
         * resource-id property
         *
         * Specify an array of string values to match this event if the actual value of resource-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Finding-severity-counts
     *
     * @struct
     */
    interface FindingSeverityCounts {
        /**
         * all property
         *
         * Specify an array of string values to match this event if the actual value of all is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly all?: Array<string>;
        /**
         * critical property
         *
         * Specify an array of string values to match this event if the actual value of critical is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly critical?: Array<string>;
        /**
         * high property
         *
         * Specify an array of string values to match this event if the actual value of high is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly high?: Array<string>;
        /**
         * medium property
         *
         * Specify an array of string values to match this event if the actual value of medium is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly medium?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.imagebuilder@EC2ImageBuilderImageStateChange
 */
export declare class EC2ImageBuilderImageStateChange {
    /**
     * EventBridge event pattern for EC2 Image Builder Image State Change
     */
    static ec2ImageBuilderImageStateChangePattern(options?: EC2ImageBuilderImageStateChange.EC2ImageBuilderImageStateChangeProps): events.EventPattern;
}
export declare namespace EC2ImageBuilderImageStateChange {
    /**
     * Props type for aws.imagebuilder@EC2ImageBuilderImageStateChange event
     */
    interface EC2ImageBuilderImageStateChangeProps {
        /**
         * previous-state property
         *
         * Specify an array of string values to match this event if the actual value of previous-state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousState?: EC2ImageBuilderImageStateChange.ImageState;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: EC2ImageBuilderImageStateChange.ImageState;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ImageState
     *
     * @struct
     */
    interface ImageState {
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * reason property
         *
         * Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reason?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.imagebuilder@EC2ImageBuilderWorkflowStepWaiting
 */
export declare class EC2ImageBuilderWorkflowStepWaiting {
    /**
     * EventBridge event pattern for EC2 Image Builder Workflow Step Waiting
     */
    static ec2ImageBuilderWorkflowStepWaitingPattern(options?: EC2ImageBuilderWorkflowStepWaiting.EC2ImageBuilderWorkflowStepWaitingProps): events.EventPattern;
}
export declare namespace EC2ImageBuilderWorkflowStepWaiting {
    /**
     * Props type for aws.imagebuilder@EC2ImageBuilderWorkflowStepWaiting event
     */
    interface EC2ImageBuilderWorkflowStepWaitingProps {
        /**
         * workflow-execution-id property
         *
         * Specify an array of string values to match this event if the actual value of workflow-execution-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly workflowExecutionId?: Array<string>;
        /**
         * workflow-step-execution-id property
         *
         * Specify an array of string values to match this event if the actual value of workflow-step-execution-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly workflowStepExecutionId?: Array<string>;
        /**
         * workflow-step-name property
         *
         * Specify an array of string values to match this event if the actual value of workflow-step-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly workflowStepName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
