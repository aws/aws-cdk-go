import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.devopsguru@DevOpsGuruInsightClosed
 */
export declare class DevOpsGuruInsightClosed {
    /**
     * EventBridge event pattern for DevOps Guru Insight Closed
     */
    static devOpsGuruInsightClosedPattern(options?: DevOpsGuruInsightClosed.DevOpsGuruInsightClosedProps): events.EventPattern;
}
export declare namespace DevOpsGuruInsightClosed {
    /**
     * Props type for aws.devopsguru@DevOpsGuruInsightClosed event
     */
    interface DevOpsGuruInsightClosedProps {
        /**
         * resourceCollection property
         *
         * Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceCollection?: DevOpsGuruInsightClosed.ResourceCollection;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * anomalies property
         *
         * Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalies?: Array<DevOpsGuruInsightClosed.Anomaly>;
        /**
         * insightDescription property
         *
         * Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightDescription?: Array<string>;
        /**
         * insightName property
         *
         * Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightName?: Array<string>;
        /**
         * insightId property
         *
         * Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightId?: Array<string>;
        /**
         * insightSeverity property
         *
         * Specify an array of string values to match this event if the actual value of insightSeverity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightSeverity?: Array<string>;
        /**
         * insightType property
         *
         * Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightType?: Array<string>;
        /**
         * insightUrl property
         *
         * Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightUrl?: Array<string>;
        /**
         * messageType property
         *
         * Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly messageType?: Array<string>;
        /**
         * region property
         *
         * Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly region?: Array<string>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * startTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimeIso?: Array<string>;
        /**
         * endTime property
         *
         * Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * endTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of endTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimeIso?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ResourceCollection
     *
     * @struct
     */
    interface ResourceCollection {
        /**
         * cloudFormation property
         *
         * Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cloudFormation?: DevOpsGuruInsightClosed.CloudFormation;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<DevOpsGuruInsightClosed.TagType>;
    }
    /**
     * Type definition for CloudFormation
     *
     * @struct
     */
    interface CloudFormation {
        /**
         * stackNames property
         *
         * Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stackNames?: Array<string>;
    }
    /**
     * Type definition for Tag
     *
     * @struct
     */
    interface TagType {
        /**
         * appBoundaryKey property
         *
         * Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly appBoundaryKey?: Array<string>;
        /**
         * tagValues property
         *
         * Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tagValues?: Array<string>;
    }
    /**
     * Type definition for Anomaly
     *
     * @struct
     */
    interface Anomaly {
        /**
         * anomalyResources property
         *
         * Specify an array of string values to match this event if the actual value of anomalyResources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalyResources?: Array<DevOpsGuruInsightClosed.AnomalyResource>;
        /**
         * associatedResourceArns property
         *
         * Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly associatedResourceArns?: Array<string>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * endTime property
         *
         * Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * endTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of endTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimeIso?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * sourceDetails property
         *
         * Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceDetails?: Array<DevOpsGuruInsightClosed.SourceDetail>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * startTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimeIso?: Array<string>;
        /**
         * openTime property
         *
         * Specify an array of string values to match this event if the actual value of openTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly openTime?: Array<string>;
        /**
         * openTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of openTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly openTimeIso?: Array<string>;
        /**
         * closeTime property
         *
         * Specify an array of string values to match this event if the actual value of closeTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly closeTime?: Array<string>;
        /**
         * closeTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of closeTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly closeTimeIso?: Array<string>;
        /**
         * earliestImpactTime property
         *
         * Specify an array of string values to match this event if the actual value of earliestImpactTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly earliestImpactTime?: Array<string>;
        /**
         * earliestImpactTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of earliestImpactTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly earliestImpactTimeIso?: Array<string>;
        /**
         * latestImpactTime property
         *
         * Specify an array of string values to match this event if the actual value of latestImpactTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly latestImpactTime?: Array<string>;
        /**
         * latestImpactTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of latestImpactTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly latestImpactTimeIso?: Array<string>;
        /**
         * limit property
         *
         * Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly limit?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * anomalySeverity property
         *
         * Specify an array of string values to match this event if the actual value of anomalySeverity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalySeverity?: Array<string>;
        /**
         * sourceMetadata property
         *
         * Specify an array of string values to match this event if the actual value of sourceMetadata is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceMetadata?: DevOpsGuruInsightClosed.AnomalySourceMetadata;
    }
    /**
     * Type definition for AnomalyResource
     *
     * @struct
     */
    interface AnomalyResource {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for SourceDetail
     *
     * @struct
     */
    interface SourceDetail {
        /**
         * dataIdentifiers property
         *
         * Specify an array of string values to match this event if the actual value of dataIdentifiers is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataIdentifiers?: DevOpsGuruInsightClosed.DataIdentifiers;
        /**
         * dataSource property
         *
         * Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSource?: Array<string>;
        /**
         * dataSourceDetail property
         *
         * Specify an array of string values to match this event if the actual value of dataSourceDetail is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSourceDetail?: Array<string>;
    }
    /**
     * Type definition for DataIdentifiers
     *
     * @struct
     */
    interface DataIdentifiers {
        /**
         * metricQuery property
         *
         * Specify an array of string values to match this event if the actual value of metricQuery is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricQuery?: DevOpsGuruInsightClosed.MetricQuery;
        /**
         * ResourceId property
         *
         * Specify an array of string values to match this event if the actual value of ResourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceId?: Array<string>;
        /**
         * ResourceType property
         *
         * Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceType?: Array<string>;
        /**
         * dimensions property
         *
         * Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dimensions?: Array<DevOpsGuruInsightClosed.CloudWatchDimension>;
        /**
         * alarmCondition property
         *
         * Specify an array of string values to match this event if the actual value of alarmCondition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alarmCondition?: DevOpsGuruInsightClosed.AlarmCondition;
        /**
         * metricDisplayName property
         *
         * Specify an array of string values to match this event if the actual value of metricDisplayName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricDisplayName?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * namespace property
         *
         * Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly namespace?: Array<string>;
        /**
         * period property
         *
         * Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly period?: Array<string>;
        /**
         * stat property
         *
         * Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stat?: Array<string>;
        /**
         * unit property
         *
         * Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unit?: Array<string>;
    }
    /**
     * Type definition for MetricQuery
     *
     * @struct
     */
    interface MetricQuery {
        /**
         * groupBy property
         *
         * Specify an array of string values to match this event if the actual value of groupBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupBy?: DevOpsGuruInsightClosed.GroupBy;
        /**
         * metric property
         *
         * Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metric?: Array<string>;
    }
    /**
     * Type definition for GroupBy
     *
     * @struct
     */
    interface GroupBy {
        /**
         * dimensions property
         *
         * Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dimensions?: Array<string>;
        /**
         * group property
         *
         * Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly group?: Array<string>;
    }
    /**
     * Type definition for CloudWatchDimension
     *
     * @struct
     */
    interface CloudWatchDimension {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for AlarmCondition
     *
     * @struct
     */
    interface AlarmCondition {
        /**
         * detectionBand property
         *
         * Specify an array of string values to match this event if the actual value of detectionBand is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly detectionBand?: Array<string>;
        /**
         * referenceValue property
         *
         * Specify an array of string values to match this event if the actual value of referenceValue is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly referenceValue?: DevOpsGuruInsightClosed.ReferenceValue;
    }
    /**
     * Type definition for ReferenceValue
     *
     * @struct
     */
    interface ReferenceValue {
        /**
         * threshold property
         *
         * Specify an array of string values to match this event if the actual value of threshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threshold?: Array<string>;
        /**
         * comparisonOperator property
         *
         * Specify an array of string values to match this event if the actual value of comparisonOperator is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly comparisonOperator?: Array<string>;
        /**
         * datapointsToAlarm property
         *
         * Specify an array of string values to match this event if the actual value of datapointsToAlarm is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datapointsToAlarm?: Array<string>;
        /**
         * evaluationPeriod property
         *
         * Specify an array of string values to match this event if the actual value of evaluationPeriod is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly evaluationPeriod?: Array<string>;
    }
    /**
     * Type definition for AnomalySourceMetadata
     *
     * @struct
     */
    interface AnomalySourceMetadata {
        /**
         * source property
         *
         * Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly source?: Array<string>;
        /**
         * sourceResourceType property
         *
         * Specify an array of string values to match this event if the actual value of sourceResourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceResourceType?: Array<string>;
        /**
         * sourceResourceArn property
         *
         * Specify an array of string values to match this event if the actual value of sourceResourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceResourceArn?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.devopsguru@DevOpsGuruInsightSeverityUpgraded
 */
export declare class DevOpsGuruInsightSeverityUpgraded {
    /**
     * EventBridge event pattern for DevOps Guru Insight Severity Upgraded
     */
    static devOpsGuruInsightSeverityUpgradedPattern(options?: DevOpsGuruInsightSeverityUpgraded.DevOpsGuruInsightSeverityUpgradedProps): events.EventPattern;
}
export declare namespace DevOpsGuruInsightSeverityUpgraded {
    /**
     * Props type for aws.devopsguru@DevOpsGuruInsightSeverityUpgraded event
     */
    interface DevOpsGuruInsightSeverityUpgradedProps {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * anomalies property
         *
         * Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalies?: Array<DevOpsGuruInsightSeverityUpgraded.Anomaly>;
        /**
         * insightId property
         *
         * Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightId?: Array<string>;
        /**
         * insightName property
         *
         * Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightName?: Array<string>;
        /**
         * insightDescription property
         *
         * Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightDescription?: Array<string>;
        /**
         * insightSeverity property
         *
         * Specify an array of string values to match this event if the actual value of insightSeverity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightSeverity?: Array<string>;
        /**
         * insightType property
         *
         * Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightType?: Array<string>;
        /**
         * insightUrl property
         *
         * Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightUrl?: Array<string>;
        /**
         * messageType property
         *
         * Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly messageType?: Array<string>;
        /**
         * region property
         *
         * Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly region?: Array<string>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * startTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimeIso?: Array<string>;
        /**
         * resourceCollection property
         *
         * Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceCollection?: DevOpsGuruInsightSeverityUpgraded.ResourceCollection;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Anomaly
     *
     * @struct
     */
    interface Anomaly {
        /**
         * anomalyResources property
         *
         * Specify an array of string values to match this event if the actual value of anomalyResources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalyResources?: Array<DevOpsGuruInsightSeverityUpgraded.AnomalyResource>;
        /**
         * associatedResourceArns property
         *
         * Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly associatedResourceArns?: Array<string>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * endTime property
         *
         * Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * sourceDetails property
         *
         * Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceDetails?: Array<DevOpsGuruInsightSeverityUpgraded.SourceDetail>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * startTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimeIso?: Array<string>;
        /**
         * openTime property
         *
         * Specify an array of string values to match this event if the actual value of openTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly openTime?: Array<string>;
        /**
         * openTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of openTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly openTimeIso?: Array<string>;
        /**
         * earliestImpactTime property
         *
         * Specify an array of string values to match this event if the actual value of earliestImpactTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly earliestImpactTime?: Array<string>;
        /**
         * earliestImpactTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of earliestImpactTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly earliestImpactTimeIso?: Array<string>;
        /**
         * latestImpactTime property
         *
         * Specify an array of string values to match this event if the actual value of latestImpactTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly latestImpactTime?: Array<string>;
        /**
         * latestImpactTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of latestImpactTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly latestImpactTimeIso?: Array<string>;
        /**
         * limit property
         *
         * Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly limit?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * anomalySeverity property
         *
         * Specify an array of string values to match this event if the actual value of anomalySeverity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalySeverity?: Array<string>;
        /**
         * sourceMetadata property
         *
         * Specify an array of string values to match this event if the actual value of sourceMetadata is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceMetadata?: DevOpsGuruInsightSeverityUpgraded.AnomalySourceMetadata;
    }
    /**
     * Type definition for AnomalyResource
     *
     * @struct
     */
    interface AnomalyResource {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for SourceDetail
     *
     * @struct
     */
    interface SourceDetail {
        /**
         * dataIdentifiers property
         *
         * Specify an array of string values to match this event if the actual value of dataIdentifiers is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataIdentifiers?: DevOpsGuruInsightSeverityUpgraded.DataIdentifiers;
        /**
         * dataSource property
         *
         * Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSource?: Array<string>;
        /**
         * dataSourceDetail property
         *
         * Specify an array of string values to match this event if the actual value of dataSourceDetail is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSourceDetail?: Array<string>;
    }
    /**
     * Type definition for DataIdentifiers
     *
     * @struct
     */
    interface DataIdentifiers {
        /**
         * metricQuery property
         *
         * Specify an array of string values to match this event if the actual value of metricQuery is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricQuery?: DevOpsGuruInsightSeverityUpgraded.MetricQuery;
        /**
         * ResourceId property
         *
         * Specify an array of string values to match this event if the actual value of ResourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceId?: Array<string>;
        /**
         * ResourceType property
         *
         * Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceType?: Array<string>;
        /**
         * dimensions property
         *
         * Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dimensions?: Array<DevOpsGuruInsightSeverityUpgraded.CloudWatchDimension>;
        /**
         * alarmCondition property
         *
         * Specify an array of string values to match this event if the actual value of alarmCondition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alarmCondition?: DevOpsGuruInsightSeverityUpgraded.AlarmCondition;
        /**
         * metricDisplayName property
         *
         * Specify an array of string values to match this event if the actual value of metricDisplayName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricDisplayName?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * namespace property
         *
         * Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly namespace?: Array<string>;
        /**
         * period property
         *
         * Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly period?: Array<string>;
        /**
         * stat property
         *
         * Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stat?: Array<string>;
        /**
         * unit property
         *
         * Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unit?: Array<string>;
    }
    /**
     * Type definition for MetricQuery
     *
     * @struct
     */
    interface MetricQuery {
        /**
         * groupBy property
         *
         * Specify an array of string values to match this event if the actual value of groupBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupBy?: DevOpsGuruInsightSeverityUpgraded.GroupBy;
        /**
         * metric property
         *
         * Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metric?: Array<string>;
    }
    /**
     * Type definition for GroupBy
     *
     * @struct
     */
    interface GroupBy {
        /**
         * dimensions property
         *
         * Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dimensions?: Array<string>;
        /**
         * group property
         *
         * Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly group?: Array<string>;
    }
    /**
     * Type definition for CloudWatchDimension
     *
     * @struct
     */
    interface CloudWatchDimension {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for AlarmCondition
     *
     * @struct
     */
    interface AlarmCondition {
        /**
         * detectionBand property
         *
         * Specify an array of string values to match this event if the actual value of detectionBand is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly detectionBand?: Array<string>;
        /**
         * referenceValue property
         *
         * Specify an array of string values to match this event if the actual value of referenceValue is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly referenceValue?: DevOpsGuruInsightSeverityUpgraded.ReferenceValue;
    }
    /**
     * Type definition for ReferenceValue
     *
     * @struct
     */
    interface ReferenceValue {
        /**
         * threshold property
         *
         * Specify an array of string values to match this event if the actual value of threshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threshold?: Array<string>;
        /**
         * comparisonOperator property
         *
         * Specify an array of string values to match this event if the actual value of comparisonOperator is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly comparisonOperator?: Array<string>;
        /**
         * datapointsToAlarm property
         *
         * Specify an array of string values to match this event if the actual value of datapointsToAlarm is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datapointsToAlarm?: Array<string>;
        /**
         * evaluationPeriod property
         *
         * Specify an array of string values to match this event if the actual value of evaluationPeriod is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly evaluationPeriod?: Array<string>;
    }
    /**
     * Type definition for AnomalySourceMetadata
     *
     * @struct
     */
    interface AnomalySourceMetadata {
        /**
         * source property
         *
         * Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly source?: Array<string>;
        /**
         * sourceResourceType property
         *
         * Specify an array of string values to match this event if the actual value of sourceResourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceResourceType?: Array<string>;
        /**
         * sourceResourceArn property
         *
         * Specify an array of string values to match this event if the actual value of sourceResourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceResourceArn?: Array<string>;
    }
    /**
     * Type definition for ResourceCollection
     *
     * @struct
     */
    interface ResourceCollection {
        /**
         * cloudFormation property
         *
         * Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cloudFormation?: DevOpsGuruInsightSeverityUpgraded.CloudFormation;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<DevOpsGuruInsightSeverityUpgraded.TagType>;
    }
    /**
     * Type definition for CloudFormation
     *
     * @struct
     */
    interface CloudFormation {
        /**
         * stackNames property
         *
         * Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stackNames?: Array<string>;
    }
    /**
     * Type definition for Tag
     *
     * @struct
     */
    interface TagType {
        /**
         * appBoundaryKey property
         *
         * Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly appBoundaryKey?: Array<string>;
        /**
         * tagValues property
         *
         * Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tagValues?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.devopsguru@DevOpsGuruNewAnomalyAssociation
 */
export declare class DevOpsGuruNewAnomalyAssociation {
    /**
     * EventBridge event pattern for DevOps Guru New Anomaly Association
     */
    static devOpsGuruNewAnomalyAssociationPattern(options?: DevOpsGuruNewAnomalyAssociation.DevOpsGuruNewAnomalyAssociationProps): events.EventPattern;
}
export declare namespace DevOpsGuruNewAnomalyAssociation {
    /**
     * Props type for aws.devopsguru@DevOpsGuruNewAnomalyAssociation event
     */
    interface DevOpsGuruNewAnomalyAssociationProps {
        /**
         * resourceCollection property
         *
         * Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceCollection?: DevOpsGuruNewAnomalyAssociation.ResourceCollection;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * anomalies property
         *
         * Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalies?: Array<DevOpsGuruNewAnomalyAssociation.Anomaly>;
        /**
         * insightDescription property
         *
         * Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightDescription?: Array<string>;
        /**
         * insightName property
         *
         * Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightName?: Array<string>;
        /**
         * insightId property
         *
         * Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightId?: Array<string>;
        /**
         * insightType property
         *
         * Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightType?: Array<string>;
        /**
         * insightUrl property
         *
         * Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightUrl?: Array<string>;
        /**
         * messageType property
         *
         * Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly messageType?: Array<string>;
        /**
         * region property
         *
         * Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly region?: Array<string>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * startTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimeIso?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ResourceCollection
     *
     * @struct
     */
    interface ResourceCollection {
        /**
         * cloudFormation property
         *
         * Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cloudFormation?: DevOpsGuruNewAnomalyAssociation.CloudFormation;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<DevOpsGuruNewAnomalyAssociation.TagType>;
    }
    /**
     * Type definition for CloudFormation
     *
     * @struct
     */
    interface CloudFormation {
        /**
         * stackNames property
         *
         * Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stackNames?: Array<string>;
    }
    /**
     * Type definition for Tag
     *
     * @struct
     */
    interface TagType {
        /**
         * appBoundaryKey property
         *
         * Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly appBoundaryKey?: Array<string>;
        /**
         * tagValues property
         *
         * Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tagValues?: Array<string>;
    }
    /**
     * Type definition for Anomaly
     *
     * @struct
     */
    interface Anomaly {
        /**
         * anomalyResources property
         *
         * Specify an array of string values to match this event if the actual value of anomalyResources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalyResources?: Array<DevOpsGuruNewAnomalyAssociation.AnomalyResource>;
        /**
         * associatedResourceArns property
         *
         * Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly associatedResourceArns?: Array<string>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * endTime property
         *
         * Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * endTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of endTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimeIso?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * sourceDetails property
         *
         * Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceDetails?: Array<DevOpsGuruNewAnomalyAssociation.SourceDetail>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * startTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimeIso?: Array<string>;
        /**
         * openTime property
         *
         * Specify an array of string values to match this event if the actual value of openTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly openTime?: Array<string>;
        /**
         * openTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of openTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly openTimeIso?: Array<string>;
        /**
         * earliestImpactTime property
         *
         * Specify an array of string values to match this event if the actual value of earliestImpactTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly earliestImpactTime?: Array<string>;
        /**
         * earliestImpactTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of earliestImpactTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly earliestImpactTimeIso?: Array<string>;
        /**
         * latestImpactTime property
         *
         * Specify an array of string values to match this event if the actual value of latestImpactTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly latestImpactTime?: Array<string>;
        /**
         * latestImpactTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of latestImpactTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly latestImpactTimeIso?: Array<string>;
        /**
         * limit property
         *
         * Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly limit?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * anomalySeverity property
         *
         * Specify an array of string values to match this event if the actual value of anomalySeverity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalySeverity?: Array<string>;
        /**
         * sourceMetadata property
         *
         * Specify an array of string values to match this event if the actual value of sourceMetadata is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceMetadata?: DevOpsGuruNewAnomalyAssociation.AnomalySourceMetadata;
    }
    /**
     * Type definition for AnomalyResource
     *
     * @struct
     */
    interface AnomalyResource {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for SourceDetail
     *
     * @struct
     */
    interface SourceDetail {
        /**
         * dataIdentifiers property
         *
         * Specify an array of string values to match this event if the actual value of dataIdentifiers is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataIdentifiers?: DevOpsGuruNewAnomalyAssociation.DataIdentifiers;
        /**
         * dataSource property
         *
         * Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSource?: Array<string>;
        /**
         * dataSourceDetail property
         *
         * Specify an array of string values to match this event if the actual value of dataSourceDetail is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSourceDetail?: Array<string>;
    }
    /**
     * Type definition for DataIdentifiers
     *
     * @struct
     */
    interface DataIdentifiers {
        /**
         * metricQuery property
         *
         * Specify an array of string values to match this event if the actual value of metricQuery is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricQuery?: DevOpsGuruNewAnomalyAssociation.MetricQuery;
        /**
         * ResourceId property
         *
         * Specify an array of string values to match this event if the actual value of ResourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceId?: Array<string>;
        /**
         * ResourceType property
         *
         * Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceType?: Array<string>;
        /**
         * dimensions property
         *
         * Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dimensions?: Array<DevOpsGuruNewAnomalyAssociation.CloudWatchDimension>;
        /**
         * alarmCondition property
         *
         * Specify an array of string values to match this event if the actual value of alarmCondition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alarmCondition?: DevOpsGuruNewAnomalyAssociation.AlarmCondition;
        /**
         * metricDisplayName property
         *
         * Specify an array of string values to match this event if the actual value of metricDisplayName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricDisplayName?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * namespace property
         *
         * Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly namespace?: Array<string>;
        /**
         * period property
         *
         * Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly period?: Array<string>;
        /**
         * stat property
         *
         * Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stat?: Array<string>;
        /**
         * unit property
         *
         * Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unit?: Array<string>;
    }
    /**
     * Type definition for MetricQuery
     *
     * @struct
     */
    interface MetricQuery {
        /**
         * groupBy property
         *
         * Specify an array of string values to match this event if the actual value of groupBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupBy?: DevOpsGuruNewAnomalyAssociation.GroupBy;
        /**
         * metric property
         *
         * Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metric?: Array<string>;
    }
    /**
     * Type definition for GroupBy
     *
     * @struct
     */
    interface GroupBy {
        /**
         * dimensions property
         *
         * Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dimensions?: Array<string>;
        /**
         * group property
         *
         * Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly group?: Array<string>;
    }
    /**
     * Type definition for CloudWatchDimension
     *
     * @struct
     */
    interface CloudWatchDimension {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for AlarmCondition
     *
     * @struct
     */
    interface AlarmCondition {
        /**
         * detectionBand property
         *
         * Specify an array of string values to match this event if the actual value of detectionBand is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly detectionBand?: Array<string>;
        /**
         * referenceValue property
         *
         * Specify an array of string values to match this event if the actual value of referenceValue is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly referenceValue?: DevOpsGuruNewAnomalyAssociation.ReferenceValue;
    }
    /**
     * Type definition for ReferenceValue
     *
     * @struct
     */
    interface ReferenceValue {
        /**
         * threshold property
         *
         * Specify an array of string values to match this event if the actual value of threshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threshold?: Array<string>;
        /**
         * comparisonOperator property
         *
         * Specify an array of string values to match this event if the actual value of comparisonOperator is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly comparisonOperator?: Array<string>;
        /**
         * datapointsToAlarm property
         *
         * Specify an array of string values to match this event if the actual value of datapointsToAlarm is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datapointsToAlarm?: Array<string>;
        /**
         * evaluationPeriod property
         *
         * Specify an array of string values to match this event if the actual value of evaluationPeriod is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly evaluationPeriod?: Array<string>;
    }
    /**
     * Type definition for AnomalySourceMetadata
     *
     * @struct
     */
    interface AnomalySourceMetadata {
        /**
         * source property
         *
         * Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly source?: Array<string>;
        /**
         * sourceResourceType property
         *
         * Specify an array of string values to match this event if the actual value of sourceResourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceResourceType?: Array<string>;
        /**
         * sourceResourceArn property
         *
         * Specify an array of string values to match this event if the actual value of sourceResourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceResourceArn?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.devopsguru@DevOpsGuruNewInsightOpen
 */
export declare class DevOpsGuruNewInsightOpen {
    /**
     * EventBridge event pattern for DevOps Guru New Insight Open
     */
    static devOpsGuruNewInsightOpenPattern(options?: DevOpsGuruNewInsightOpen.DevOpsGuruNewInsightOpenProps): events.EventPattern;
}
export declare namespace DevOpsGuruNewInsightOpen {
    /**
     * Props type for aws.devopsguru@DevOpsGuruNewInsightOpen event
     */
    interface DevOpsGuruNewInsightOpenProps {
        /**
         * resourceCollection property
         *
         * Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceCollection?: DevOpsGuruNewInsightOpen.ResourceCollection;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * anomalies property
         *
         * Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalies?: Array<DevOpsGuruNewInsightOpen.Anomaly>;
        /**
         * insightDescription property
         *
         * Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightDescription?: Array<string>;
        /**
         * insightName property
         *
         * Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightName?: Array<string>;
        /**
         * insightId property
         *
         * Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightId?: Array<string>;
        /**
         * insightSeverity property
         *
         * Specify an array of string values to match this event if the actual value of insightSeverity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightSeverity?: Array<string>;
        /**
         * insightType property
         *
         * Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightType?: Array<string>;
        /**
         * insightUrl property
         *
         * Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightUrl?: Array<string>;
        /**
         * messageType property
         *
         * Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly messageType?: Array<string>;
        /**
         * region property
         *
         * Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly region?: Array<string>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * startTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimeIso?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ResourceCollection
     *
     * @struct
     */
    interface ResourceCollection {
        /**
         * cloudFormation property
         *
         * Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cloudFormation?: DevOpsGuruNewInsightOpen.CloudFormation;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<DevOpsGuruNewInsightOpen.TagType>;
    }
    /**
     * Type definition for CloudFormation
     *
     * @struct
     */
    interface CloudFormation {
        /**
         * stackNames property
         *
         * Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stackNames?: Array<string>;
    }
    /**
     * Type definition for Tag
     *
     * @struct
     */
    interface TagType {
        /**
         * appBoundaryKey property
         *
         * Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly appBoundaryKey?: Array<string>;
        /**
         * tagValues property
         *
         * Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tagValues?: Array<string>;
    }
    /**
     * Type definition for Anomaly
     *
     * @struct
     */
    interface Anomaly {
        /**
         * anomalyResources property
         *
         * Specify an array of string values to match this event if the actual value of anomalyResources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalyResources?: Array<DevOpsGuruNewInsightOpen.AnomalyResource>;
        /**
         * associatedResourceArns property
         *
         * Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly associatedResourceArns?: Array<string>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * endTime property
         *
         * Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTime?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * sourceDetails property
         *
         * Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceDetails?: Array<DevOpsGuruNewInsightOpen.SourceDetail>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * startTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimeIso?: Array<string>;
        /**
         * openTime property
         *
         * Specify an array of string values to match this event if the actual value of openTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly openTime?: Array<string>;
        /**
         * openTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of openTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly openTimeIso?: Array<string>;
        /**
         * earliestImpactTime property
         *
         * Specify an array of string values to match this event if the actual value of earliestImpactTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly earliestImpactTime?: Array<string>;
        /**
         * earliestImpactTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of earliestImpactTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly earliestImpactTimeIso?: Array<string>;
        /**
         * latestImpactTime property
         *
         * Specify an array of string values to match this event if the actual value of latestImpactTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly latestImpactTime?: Array<string>;
        /**
         * latestImpactTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of latestImpactTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly latestImpactTimeIso?: Array<string>;
        /**
         * limit property
         *
         * Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly limit?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * anomalySeverity property
         *
         * Specify an array of string values to match this event if the actual value of anomalySeverity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalySeverity?: Array<string>;
        /**
         * sourceMetadata property
         *
         * Specify an array of string values to match this event if the actual value of sourceMetadata is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceMetadata?: DevOpsGuruNewInsightOpen.AnomalySourceMetadata;
    }
    /**
     * Type definition for AnomalyResource
     *
     * @struct
     */
    interface AnomalyResource {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for SourceDetail
     *
     * @struct
     */
    interface SourceDetail {
        /**
         * dataIdentifiers property
         *
         * Specify an array of string values to match this event if the actual value of dataIdentifiers is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataIdentifiers?: DevOpsGuruNewInsightOpen.DataIdentifiers;
        /**
         * dataSource property
         *
         * Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSource?: Array<string>;
        /**
         * dataSourceDetail property
         *
         * Specify an array of string values to match this event if the actual value of dataSourceDetail is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataSourceDetail?: Array<string>;
    }
    /**
     * Type definition for DataIdentifiers
     *
     * @struct
     */
    interface DataIdentifiers {
        /**
         * metricQuery property
         *
         * Specify an array of string values to match this event if the actual value of metricQuery is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricQuery?: DevOpsGuruNewInsightOpen.MetricQuery;
        /**
         * ResourceId property
         *
         * Specify an array of string values to match this event if the actual value of ResourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceId?: Array<string>;
        /**
         * ResourceType property
         *
         * Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceType?: Array<string>;
        /**
         * dimensions property
         *
         * Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dimensions?: Array<DevOpsGuruNewInsightOpen.CloudWatchDimension>;
        /**
         * alarmCondition property
         *
         * Specify an array of string values to match this event if the actual value of alarmCondition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alarmCondition?: DevOpsGuruNewInsightOpen.AlarmCondition;
        /**
         * metricDisplayName property
         *
         * Specify an array of string values to match this event if the actual value of metricDisplayName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricDisplayName?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * namespace property
         *
         * Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly namespace?: Array<string>;
        /**
         * period property
         *
         * Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly period?: Array<string>;
        /**
         * stat property
         *
         * Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stat?: Array<string>;
        /**
         * unit property
         *
         * Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unit?: Array<string>;
    }
    /**
     * Type definition for MetricQuery
     *
     * @struct
     */
    interface MetricQuery {
        /**
         * groupBy property
         *
         * Specify an array of string values to match this event if the actual value of groupBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupBy?: DevOpsGuruNewInsightOpen.GroupBy;
        /**
         * metric property
         *
         * Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metric?: Array<string>;
    }
    /**
     * Type definition for GroupBy
     *
     * @struct
     */
    interface GroupBy {
        /**
         * dimensions property
         *
         * Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dimensions?: Array<string>;
        /**
         * group property
         *
         * Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly group?: Array<string>;
    }
    /**
     * Type definition for CloudWatchDimension
     *
     * @struct
     */
    interface CloudWatchDimension {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for AlarmCondition
     *
     * @struct
     */
    interface AlarmCondition {
        /**
         * detectionBand property
         *
         * Specify an array of string values to match this event if the actual value of detectionBand is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly detectionBand?: Array<string>;
        /**
         * referenceValue property
         *
         * Specify an array of string values to match this event if the actual value of referenceValue is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly referenceValue?: DevOpsGuruNewInsightOpen.ReferenceValue;
    }
    /**
     * Type definition for ReferenceValue
     *
     * @struct
     */
    interface ReferenceValue {
        /**
         * threshold property
         *
         * Specify an array of string values to match this event if the actual value of threshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threshold?: Array<string>;
        /**
         * comparisonOperator property
         *
         * Specify an array of string values to match this event if the actual value of comparisonOperator is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly comparisonOperator?: Array<string>;
        /**
         * datapointsToAlarm property
         *
         * Specify an array of string values to match this event if the actual value of datapointsToAlarm is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly datapointsToAlarm?: Array<string>;
        /**
         * evaluationPeriod property
         *
         * Specify an array of string values to match this event if the actual value of evaluationPeriod is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly evaluationPeriod?: Array<string>;
    }
    /**
     * Type definition for AnomalySourceMetadata
     *
     * @struct
     */
    interface AnomalySourceMetadata {
        /**
         * source property
         *
         * Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly source?: Array<string>;
        /**
         * sourceResourceType property
         *
         * Specify an array of string values to match this event if the actual value of sourceResourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceResourceType?: Array<string>;
        /**
         * sourceResourceArn property
         *
         * Specify an array of string values to match this event if the actual value of sourceResourceArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceResourceArn?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.devopsguru@DevOpsGuruNewRecommendationCreated
 */
export declare class DevOpsGuruNewRecommendationCreated {
    /**
     * EventBridge event pattern for DevOps Guru New Recommendation Created
     */
    static devOpsGuruNewRecommendationCreatedPattern(options?: DevOpsGuruNewRecommendationCreated.DevOpsGuruNewRecommendationCreatedProps): events.EventPattern;
}
export declare namespace DevOpsGuruNewRecommendationCreated {
    /**
     * Props type for aws.devopsguru@DevOpsGuruNewRecommendationCreated event
     */
    interface DevOpsGuruNewRecommendationCreatedProps {
        /**
         * resourceCollection property
         *
         * Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceCollection?: DevOpsGuruNewRecommendationCreated.ResourceCollection;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * insightName property
         *
         * Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightName?: Array<string>;
        /**
         * insightDescription property
         *
         * Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightDescription?: Array<string>;
        /**
         * insightId property
         *
         * Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightId?: Array<string>;
        /**
         * insightType property
         *
         * Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightType?: Array<string>;
        /**
         * insightUrl property
         *
         * Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightUrl?: Array<string>;
        /**
         * messageType property
         *
         * Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly messageType?: Array<string>;
        /**
         * recommendations property
         *
         * Specify an array of string values to match this event if the actual value of recommendations is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly recommendations?: Array<DevOpsGuruNewRecommendationCreated.Recommendation>;
        /**
         * region property
         *
         * Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly region?: Array<string>;
        /**
         * startTime property
         *
         * Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTime?: Array<string>;
        /**
         * startTimeISO property
         *
         * Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimeIso?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ResourceCollection
     *
     * @struct
     */
    interface ResourceCollection {
        /**
         * cloudFormation property
         *
         * Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cloudFormation?: DevOpsGuruNewRecommendationCreated.CloudFormation;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<DevOpsGuruNewRecommendationCreated.TagType>;
    }
    /**
     * Type definition for CloudFormation
     *
     * @struct
     */
    interface CloudFormation {
        /**
         * stackNames property
         *
         * Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stackNames?: Array<string>;
    }
    /**
     * Type definition for Tag
     *
     * @struct
     */
    interface TagType {
        /**
         * appBoundaryKey property
         *
         * Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly appBoundaryKey?: Array<string>;
        /**
         * tagValues property
         *
         * Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tagValues?: Array<string>;
    }
    /**
     * Type definition for Recommendation
     *
     * @struct
     */
    interface Recommendation {
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * link property
         *
         * Specify an array of string values to match this event if the actual value of link is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly link?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * reason property
         *
         * Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reason?: Array<string>;
        /**
         * relatedAnomalies property
         *
         * Specify an array of string values to match this event if the actual value of relatedAnomalies is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly relatedAnomalies?: Array<DevOpsGuruNewRecommendationCreated.RelatedAnomaly>;
        /**
         * relatedEvents property
         *
         * Specify an array of string values to match this event if the actual value of relatedEvents is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly relatedEvents?: Array<DevOpsGuruNewRecommendationCreated.RelatedEvent>;
    }
    /**
     * Type definition for RelatedAnomaly
     *
     * @struct
     */
    interface RelatedAnomaly {
        /**
         * sourceDetails property
         *
         * Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceDetails?: Array<DevOpsGuruNewRecommendationCreated.RelatedAnomalySourceDetail>;
        /**
         * resources property
         *
         * Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resources?: Array<DevOpsGuruNewRecommendationCreated.AnomalyResource>;
        /**
         * associatedResourceArns property
         *
         * Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly associatedResourceArns?: Array<string>;
    }
    /**
     * Type definition for RelatedAnomalySourceDetail
     *
     * @struct
     */
    interface RelatedAnomalySourceDetail {
        /**
         * cloudWatchMetrics property
         *
         * Specify an array of string values to match this event if the actual value of cloudWatchMetrics is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cloudWatchMetrics?: Array<DevOpsGuruNewRecommendationCreated.CloudWatchDimension>;
    }
    /**
     * Type definition for CloudWatchDimension
     *
     * @struct
     */
    interface CloudWatchDimension {
        /**
         * metricName property
         *
         * Specify an array of string values to match this event if the actual value of metricName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly metricName?: Array<string>;
        /**
         * namespace property
         *
         * Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly namespace?: Array<string>;
    }
    /**
     * Type definition for AnomalyResource
     *
     * @struct
     */
    interface AnomalyResource {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for RelatedEvent
     *
     * @struct
     */
    interface RelatedEvent {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * resources property
         *
         * Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resources?: Array<DevOpsGuruNewRecommendationCreated.EventResource>;
    }
    /**
     * Type definition for EventResource
     *
     * @struct
     */
    interface EventResource {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
}
