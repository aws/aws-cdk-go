import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.managedblockchain@ManagedBlockchainInvitationStatusChange
 */
export declare class ManagedBlockchainInvitationStatusChange {
    /**
     * EventBridge event pattern for Managed Blockchain Invitation Status Change
     */
    static managedBlockchainInvitationStatusChangePattern(options?: ManagedBlockchainInvitationStatusChange.ManagedBlockchainInvitationStatusChangeProps): events.EventPattern;
}
export declare namespace ManagedBlockchainInvitationStatusChange {
    /**
     * Props type for aws.managedblockchain@ManagedBlockchainInvitationStatusChange event
     */
    interface ManagedBlockchainInvitationStatusChangeProps {
        /**
         * createdAt property
         *
         * Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createdAt?: Array<string>;
        /**
         * networkId property
         *
         * Specify an array of string values to match this event if the actual value of networkId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkId?: Array<string>;
        /**
         * invitationId property
         *
         * Specify an array of string values to match this event if the actual value of invitationId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly invitationId?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * expiresAt property
         *
         * Specify an array of string values to match this event if the actual value of expiresAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly expiresAt?: Array<string>;
        /**
         * acceptedAt property
         *
         * Specify an array of string values to match this event if the actual value of acceptedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly acceptedAt?: Array<string>;
        /**
         * rejectedAt property
         *
         * Specify an array of string values to match this event if the actual value of rejectedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rejectedAt?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.managedblockchain@ManagedBlockchainProposalStatusChange
 */
export declare class ManagedBlockchainProposalStatusChange {
    /**
     * EventBridge event pattern for Managed Blockchain Proposal Status Change
     */
    static managedBlockchainProposalStatusChangePattern(options?: ManagedBlockchainProposalStatusChange.ManagedBlockchainProposalStatusChangeProps): events.EventPattern;
}
export declare namespace ManagedBlockchainProposalStatusChange {
    /**
     * Props type for aws.managedblockchain@ManagedBlockchainProposalStatusChange event
     */
    interface ManagedBlockchainProposalStatusChangeProps {
        /**
         * proposedByMemberName property
         *
         * Specify an array of string values to match this event if the actual value of proposedByMemberName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly proposedByMemberName?: Array<string>;
        /**
         * proposedByMemberId property
         *
         * Specify an array of string values to match this event if the actual value of proposedByMemberId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly proposedByMemberId?: Array<string>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * networkId property
         *
         * Specify an array of string values to match this event if the actual value of networkId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkId?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * proposalId property
         *
         * Specify an array of string values to match this event if the actual value of proposalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly proposalId?: Array<string>;
        /**
         * expirationDate property
         *
         * Specify an array of string values to match this event if the actual value of expirationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly expirationDate?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
