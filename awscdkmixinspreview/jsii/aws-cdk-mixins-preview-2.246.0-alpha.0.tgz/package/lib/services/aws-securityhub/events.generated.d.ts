import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.securityhub@SecurityHubFindingsCustomAction
 */
export declare class SecurityHubFindingsCustomAction {
    /**
     * EventBridge event pattern for Security Hub Findings - Custom Action
     */
    static securityHubFindingsCustomActionPattern(options?: SecurityHubFindingsCustomAction.SecurityHubFindingsCustomActionProps): events.EventPattern;
}
export declare namespace SecurityHubFindingsCustomAction {
    /**
     * Props type for aws.securityhub@SecurityHubFindingsCustomAction event
     */
    interface SecurityHubFindingsCustomActionProps {
        /**
         * findings property
         *
         * Specify an array of string values to match this event if the actual value of findings is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly findings?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.securityhub@SecurityHubFindingsImported
 */
export declare class SecurityHubFindingsImported {
    /**
     * EventBridge event pattern for Security Hub Findings - Imported
     */
    static securityHubFindingsImportedPattern(options?: SecurityHubFindingsImported.SecurityHubFindingsImportedProps): events.EventPattern;
}
export declare namespace SecurityHubFindingsImported {
    /**
     * Props type for aws.securityhub@SecurityHubFindingsImported event
     */
    interface SecurityHubFindingsImportedProps {
        /**
         * findings property
         *
         * Specify an array of string values to match this event if the actual value of findings is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly findings?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.securityhub@SecurityHubInsightResults
 */
export declare class SecurityHubInsightResults {
    /**
     * EventBridge event pattern for Security Hub Insight Results
     */
    static securityHubInsightResultsPattern(options?: SecurityHubInsightResults.SecurityHubInsightResultsProps): events.EventPattern;
}
export declare namespace SecurityHubInsightResults {
    /**
     * Props type for aws.securityhub@SecurityHubInsightResults event
     */
    interface SecurityHubInsightResultsProps {
        /**
         * insightName property
         *
         * Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightName?: Array<string>;
        /**
         * insightResults property
         *
         * Specify an array of string values to match this event if the actual value of insightResults is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightResults?: Array<Record<string, string>>;
        /**
         * actionDescription property
         *
         * Specify an array of string values to match this event if the actual value of actionDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionDescription?: Array<string>;
        /**
         * insightArn property
         *
         * Specify an array of string values to match this event if the actual value of insightArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly insightArn?: Array<string>;
        /**
         * resultType property
         *
         * Specify an array of string values to match this event if the actual value of resultType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resultType?: Array<string>;
        /**
         * actionName property
         *
         * Specify an array of string values to match this event if the actual value of actionName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
