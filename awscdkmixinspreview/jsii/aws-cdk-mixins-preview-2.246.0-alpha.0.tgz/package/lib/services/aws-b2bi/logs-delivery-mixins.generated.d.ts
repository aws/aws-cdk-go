import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-b2bi";
/**
 * Builder for CfnTransformerLogsMixin to generate B2BI_EXECUTION_LOGS for CfnTransformer
 *
 * @cloudformationResource AWS::B2BI::Transformer
 * @logType B2BI_EXECUTION_LOGS
 * @stability external
 */
export declare class CfnTransformerB2biExecutionLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnTransformerB2biExecutionLogsS3Props): CfnTransformerLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnTransformerB2biExecutionLogsLogGroupProps): CfnTransformerLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnTransformerB2biExecutionLogsFirehoseProps): CfnTransformerLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef): CfnTransformerLogsMixin;
}
/**
 * Creates a transformer. AWS B2B Data Interchange currently supports two scenarios:.
 *
 * - *Inbound EDI* : the AWS customer receives an EDI file from their trading partner. AWS B2B Data Interchange converts this EDI file into a JSON or XML file with a service-defined structure. A mapping template provided by the customer, in JSONata or XSLT format, is optionally applied to this file to produce a JSON or XML file with the structure the customer requires.
 * - *Outbound EDI* : the AWS customer has a JSON or XML file containing data that they wish to use in an EDI file. A mapping template, provided by the customer (in either JSONata or XSLT format) is applied to this file to generate a JSON or XML file in the service-defined structure. This file is then converted to an EDI file.
 *
 * > The following fields are provided for backwards compatibility only: `fileFormat` , `mappingTemplate` , `ediType` , and `sampleDocument` .
 * >
 * > - Use the `mapping` data type in place of `mappingTemplate` and `fileFormat`
 * > - Use the `sampleDocuments` data type in place of `sampleDocument`
 * > - Use either the `inputConversion` or `outputConversion` in place of `ediType`
 *
 * @cloudformationResource AWS::B2BI::Transformer
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html
 */
export declare class CfnTransformerLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly B2BI_EXECUTION_LOGS: CfnTransformerB2biExecutionLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::B2BI::Transformer`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTransformer;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnTransformerB2biExecutionLogs.
 */
export declare class CfnTransformerB2biExecutionLogsOutputFormat {
}
export declare namespace CfnTransformerB2biExecutionLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export interface CfnTransformerB2biExecutionLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnTransformerB2biExecutionLogsOutputFormat.S3;
}
export interface CfnTransformerB2biExecutionLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnTransformerB2biExecutionLogsOutputFormat.LogGroup;
}
export interface CfnTransformerB2biExecutionLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnTransformerB2biExecutionLogsOutputFormat.Firehose;
}
