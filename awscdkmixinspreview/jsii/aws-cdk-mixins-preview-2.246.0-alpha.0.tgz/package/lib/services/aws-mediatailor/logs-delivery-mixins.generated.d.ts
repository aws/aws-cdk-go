import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-mediatailor";
/**
 * Builder for CfnPlaybackConfigurationLogsMixin to generate AD_DECISION_SERVER_LOGS for CfnPlaybackConfiguration
 *
 * @cloudformationResource AWS::MediaTailor::PlaybackConfiguration
 * @logType AD_DECISION_SERVER_LOGS
 * @stability external
 */
export declare class CfnPlaybackConfigurationAdDecisionServerLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnPlaybackConfigurationAdDecisionServerLogsS3Props): CfnPlaybackConfigurationLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnPlaybackConfigurationAdDecisionServerLogsLogGroupProps): CfnPlaybackConfigurationLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnPlaybackConfigurationAdDecisionServerLogsFirehoseProps): CfnPlaybackConfigurationLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnPlaybackConfigurationAdDecisionServerLogsDestProps): CfnPlaybackConfigurationLogsMixin;
}
/**
 * Builder for CfnPlaybackConfigurationLogsMixin to generate MANIFEST_SERVICE_LOGS for CfnPlaybackConfiguration
 *
 * @cloudformationResource AWS::MediaTailor::PlaybackConfiguration
 * @logType MANIFEST_SERVICE_LOGS
 * @stability external
 */
export declare class CfnPlaybackConfigurationManifestServiceLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnPlaybackConfigurationManifestServiceLogsS3Props): CfnPlaybackConfigurationLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnPlaybackConfigurationManifestServiceLogsLogGroupProps): CfnPlaybackConfigurationLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnPlaybackConfigurationManifestServiceLogsFirehoseProps): CfnPlaybackConfigurationLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnPlaybackConfigurationManifestServiceLogsDestProps): CfnPlaybackConfigurationLogsMixin;
}
/**
 * Builder for CfnPlaybackConfigurationLogsMixin to generate TRANSCODE_LOGS for CfnPlaybackConfiguration
 *
 * @cloudformationResource AWS::MediaTailor::PlaybackConfiguration
 * @logType TRANSCODE_LOGS
 * @stability external
 */
export declare class CfnPlaybackConfigurationTranscodeLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnPlaybackConfigurationTranscodeLogsS3Props): CfnPlaybackConfigurationLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnPlaybackConfigurationTranscodeLogsLogGroupProps): CfnPlaybackConfigurationLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnPlaybackConfigurationTranscodeLogsFirehoseProps): CfnPlaybackConfigurationLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnPlaybackConfigurationTranscodeLogsDestProps): CfnPlaybackConfigurationLogsMixin;
}
/**
 * Adds a new playback configuration to AWS Elemental MediaTailor .
 *
 * @cloudformationResource AWS::MediaTailor::PlaybackConfiguration
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediatailor-playbackconfiguration.html
 */
export declare class CfnPlaybackConfigurationLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly AD_DECISION_SERVER_LOGS: CfnPlaybackConfigurationAdDecisionServerLogs;
    static readonly MANIFEST_SERVICE_LOGS: CfnPlaybackConfigurationManifestServiceLogs;
    static readonly TRANSCODE_LOGS: CfnPlaybackConfigurationTranscodeLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::MediaTailor::PlaybackConfiguration`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPlaybackConfiguration;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnPlaybackConfigurationAdDecisionServerLogs.
 */
export declare class CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat {
}
export declare namespace CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnPlaybackConfigurationAdDecisionServerLogsRecordFields {
    ORIGINID = "originId",
    CUSTOMERID = "customerId",
    EVENTTYPE = "eventType",
    SESSIONTYPE = "sessionType",
    REQUESTID = "requestId",
    EVENTDESCRIPTION = "eventDescription",
    SESSIONID = "sessionId",
    VODVASTRESPONSETIMEOFFSET = "vodVastResponseTimeOffset",
    ADSREQUESTURL = "adsRequestUrl",
    ADMARKERS = "adMarkers",
    SEGMENTATIONUPID = "segmentationUpid",
    SEGMENTATIONTYPEID = "segmentationTypeId",
    ORIGINALTARGETURL = "originalTargetUrl",
    UPDATEDTARGETURL = "updatedTargetUrl",
    RAWADSREQUEST = "rawAdsRequest",
    RAWADSREQUESTINDEX = "rawAdsRequestIndex",
    RAWADSRESPONSE = "rawAdsResponse",
    RAWADSRESPONSEINDEX = "rawAdsResponseIndex",
    AVAIL = "avail",
    VASTRESPONSE = "vastResponse",
    VASTAD = "vastAd",
    VODCREATIVEOFFSETS = "vodCreativeOffsets",
    REQUESTHEADERS = "requestHeaders",
    BEACONINFO = "beaconInfo",
    ADBREAKCORRELATIONID = "adBreakCorrelationId",
    PREFETCHSCHEDULENAME = "prefetchScheduleName",
    EVENTTIMESTAMP = "eventTimestamp",
    AWSACCOUNTID = "awsAccountId"
}
export interface CfnPlaybackConfigurationAdDecisionServerLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnPlaybackConfigurationAdDecisionServerLogsRecordFields>;
}
export interface CfnPlaybackConfigurationAdDecisionServerLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnPlaybackConfigurationAdDecisionServerLogsRecordFields>;
}
export interface CfnPlaybackConfigurationAdDecisionServerLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnPlaybackConfigurationAdDecisionServerLogsRecordFields>;
}
export interface CfnPlaybackConfigurationAdDecisionServerLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnPlaybackConfigurationAdDecisionServerLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnPlaybackConfigurationManifestServiceLogs.
 */
export declare class CfnPlaybackConfigurationManifestServiceLogsOutputFormat {
}
export declare namespace CfnPlaybackConfigurationManifestServiceLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnPlaybackConfigurationManifestServiceLogsRecordFields {
    CUSTOMERID = "customerId",
    EVENTTYPE = "eventType",
    SESSIONTYPE = "sessionType",
    REQUESTID = "requestId",
    EVENTDESCRIPTION = "eventDescription",
    SESSIONID = "sessionId",
    ORIGINREQUESTURL = "originRequestUrl",
    MEDIATAILORPATH = "mediaTailorPath",
    RESPONSEBODY = "responseBody",
    REQUESTNEXTTOKEN = "requestNextToken",
    ASSETPATH = "assetPath",
    ORIGINFULLURL = "originFullUrl",
    ORIGINPREFIXURL = "originPrefixUrl",
    ADDITIONALINFO = "additionalInfo",
    CAUSE = "cause",
    RESPONSE = "response",
    HTTPCODE = "httpCode",
    ERRORMESSAGE = "errorMessage",
    ADADSRESPONSE = "adAdsResponse",
    ADADSRAWRESPONSE = "adAdsRawResponse",
    ADADSREQUEST = "adAdsRequest",
    ADNUMNEWAVAILS = "adNumNewAvails",
    GENERATEDMEDIAPLAYLIST = "generatedMediaPlaylist",
    REQUESTSTARTTIME = "requestStartTime",
    REQUESTENDTIME = "requestEndTime",
    REQUESTSTARTTIMEEPOCHMILLIS = "requestStartTimeEpochMillis",
    REQUESTENDTIMEEPOCHMILLIS = "requestEndTimeEpochMillis",
    EVENTTIMESTAMP = "eventTimestamp",
    AWSACCOUNTID = "awsAccountId",
    ORIGINID = "originId"
}
export interface CfnPlaybackConfigurationManifestServiceLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnPlaybackConfigurationManifestServiceLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnPlaybackConfigurationManifestServiceLogsRecordFields>;
}
export interface CfnPlaybackConfigurationManifestServiceLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnPlaybackConfigurationManifestServiceLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnPlaybackConfigurationManifestServiceLogsRecordFields>;
}
export interface CfnPlaybackConfigurationManifestServiceLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnPlaybackConfigurationManifestServiceLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnPlaybackConfigurationManifestServiceLogsRecordFields>;
}
export interface CfnPlaybackConfigurationManifestServiceLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnPlaybackConfigurationManifestServiceLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnPlaybackConfigurationTranscodeLogs.
 */
export declare class CfnPlaybackConfigurationTranscodeLogsOutputFormat {
}
export declare namespace CfnPlaybackConfigurationTranscodeLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnPlaybackConfigurationTranscodeLogsRecordFields {
    EVENTTYPE = "eventType",
    EVENTDESCRIPTION = "eventDescription",
    SESSIONID = "sessionId",
    CREATIVEUNIQUEID = "creativeUniqueId",
    PROFILENAME = "profileName",
    ADURI = "adUri",
    TRANSCODEREQUESTID = "transcodeRequestId",
    CACHESTATUS = "cacheStatus",
    EVENTTIMESTAMP = "eventTimestamp",
    AWSACCOUNTID = "awsAccountId",
    ORIGINID = "originId"
}
export interface CfnPlaybackConfigurationTranscodeLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnPlaybackConfigurationTranscodeLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnPlaybackConfigurationTranscodeLogsRecordFields>;
}
export interface CfnPlaybackConfigurationTranscodeLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnPlaybackConfigurationTranscodeLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnPlaybackConfigurationTranscodeLogsRecordFields>;
}
export interface CfnPlaybackConfigurationTranscodeLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnPlaybackConfigurationTranscodeLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnPlaybackConfigurationTranscodeLogsRecordFields>;
}
export interface CfnPlaybackConfigurationTranscodeLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnPlaybackConfigurationTranscodeLogsRecordFields>;
}
