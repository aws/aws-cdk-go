import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-athena";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.athena@AthenaQueryStateChange
 */
export declare class AthenaQueryStateChange {
    /**
     * EventBridge event pattern for Athena Query State Change
     */
    static athenaQueryStateChangePattern(options?: AthenaQueryStateChange.AthenaQueryStateChangeProps): events.EventPattern;
}
export declare namespace AthenaQueryStateChange {
    /**
     * Props type for aws.athena@AthenaQueryStateChange event
     */
    interface AthenaQueryStateChangeProps {
        /**
         * currentState property
         *
         * Specify an array of string values to match this event if the actual value of currentState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentState?: Array<string>;
        /**
         * previousState property
         *
         * Specify an array of string values to match this event if the actual value of previousState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousState?: Array<string>;
        /**
         * queryExecutionId property
         *
         * Specify an array of string values to match this event if the actual value of queryExecutionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly queryExecutionId?: Array<string>;
        /**
         * sequenceNumber property
         *
         * Specify an array of string values to match this event if the actual value of sequenceNumber is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sequenceNumber?: Array<string>;
        /**
         * statementType property
         *
         * Specify an array of string values to match this event if the actual value of statementType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statementType?: Array<string>;
        /**
         * versionId property
         *
         * Specify an array of string values to match this event if the actual value of versionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
        /**
         * workgroupName property
         *
         * Specify an array of string values to match this event if the actual value of workgroupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the WorkGroup reference
         */
        readonly workgroupName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event patterns for WorkGroup
 */
export declare class WorkGroupEvents {
    /**
     * Create WorkGroupEvents from a WorkGroup reference
     */
    static fromWorkGroup(workGroupRef: service.IWorkGroupRef): WorkGroupEvents;
    /**
     * Reference to the WorkGroup construct
     */
    private readonly workGroupRef;
    private constructor();
    /**
     * EventBridge event pattern for WorkGroup Athena Query State Change
     */
    athenaQueryStateChangePattern(options?: AthenaQueryStateChange.AthenaQueryStateChangeProps): events.EventPattern;
}
