import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-bedrock";
/**
 * Builder for CfnAgentLogsMixin to generate APPLICATION_LOGS for CfnAgent
 *
 * @cloudformationResource AWS::Bedrock::Agent
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnAgentApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnAgentApplicationLogsS3Props): CfnAgentLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnAgentApplicationLogsLogGroupProps): CfnAgentLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnAgentApplicationLogsFirehoseProps): CfnAgentLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnAgentApplicationLogsDestProps): CfnAgentLogsMixin;
}
/**
 * Specifies an agent as a resource in a top-level template. Minimally, you must specify the following properties:.
 *
 * - AgentName – Specify a name for the agent.
 * - AgentResourceRoleArn – Specify the Amazon Resource Name (ARN) of the service role with permissions to invoke API operations on the agent. For more information, see [Create a service role for Agents for Amazon Bedrock](https://docs.aws.amazon.com/bedrock/latest/userguide/agents-permissions.html) .
 * - FoundationModel – Specify the model ID of a foundation model to use when invoking the agent. For more information, see [Supported regions and models for Agents for Amazon Bedrock](https://docs.aws.amazon.com//bedrock/latest/userguide/agents-supported.html) .
 *
 * For more information about using agents in Amazon Bedrock , see [Agents for Amazon Bedrock](https://docs.aws.amazon.com/bedrock/latest/userguide/agents.html) .
 *
 * See the *Properties* section below for descriptions of both the required and optional properties.
 *
 * @cloudformationResource AWS::Bedrock::Agent
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-agent.html
 */
export declare class CfnAgentLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnAgentApplicationLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::Bedrock::Agent`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAgent;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnAgentApplicationLogs.
 */
export declare class CfnAgentApplicationLogsOutputFormat {
}
export declare namespace CfnAgentApplicationLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnAgentApplicationLogsRecordFields {
    AGENT_ALIAS_ARN = "agent_alias_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    EVENT_VERSION = "event_version",
    OPERATION = "operation",
    EVENT_TYPE = "event_type",
    WORKFLOW = "workflow",
    LEVEL = "level",
    EVENT = "event",
    AGENT_ARN = "agent_arn"
}
export interface CfnAgentApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnAgentApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentApplicationLogsRecordFields>;
}
export interface CfnAgentApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnAgentApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentApplicationLogsRecordFields>;
}
export interface CfnAgentApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnAgentApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentApplicationLogsRecordFields>;
}
export interface CfnAgentApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentApplicationLogsRecordFields>;
}
/**
 * Builder for CfnAgentAliasLogsMixin to generate EVENT_LOGS for CfnAgentAlias
 *
 * @cloudformationResource AWS::Bedrock::AgentAlias
 * @logType EVENT_LOGS
 * @stability external
 */
export declare class CfnAgentAliasEventLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnAgentAliasEventLogsS3Props): CfnAgentAliasLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnAgentAliasEventLogsLogGroupProps): CfnAgentAliasLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnAgentAliasEventLogsFirehoseProps): CfnAgentAliasLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnAgentAliasEventLogsDestProps): CfnAgentAliasLogsMixin;
}
/**
 * Specifies an agent alias as a resource in a top-level template. Minimally, you must specify the following properties:.
 *
 * - AgentAliasName – Specify a name for the alias.
 *
 * For more information about creating aliases for an agent in Amazon Bedrock , see [Deploy an Amazon Bedrock agent](https://docs.aws.amazon.com/bedrock/latest/userguide/agents-deploy.html) .
 *
 * See the *Properties* section below for descriptions of both the required and optional properties.
 *
 * @cloudformationResource AWS::Bedrock::AgentAlias
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-agentalias.html
 */
export declare class CfnAgentAliasLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly EVENT_LOGS: CfnAgentAliasEventLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::Bedrock::AgentAlias`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAgentAlias;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnAgentAliasEventLogs.
 */
export declare class CfnAgentAliasEventLogsOutputFormat {
}
export declare namespace CfnAgentAliasEventLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnAgentAliasEventLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCEID = "resourceId",
    TRACEID = "traceId",
    SPANID = "spanId",
    SESSIONID = "sessionId",
    REQUESTID = "requestId",
    OPERATION = "operation",
    ATTRIBUTES = "attributes",
    BODY = "body",
    EVENTTYPE = "eventType",
    EVENTVERSION = "eventVersion",
    EVENTNAME = "eventName",
    LEVEL = "level"
}
export interface CfnAgentAliasEventLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnAgentAliasEventLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentAliasEventLogsRecordFields>;
}
export interface CfnAgentAliasEventLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnAgentAliasEventLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentAliasEventLogsRecordFields>;
}
export interface CfnAgentAliasEventLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnAgentAliasEventLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentAliasEventLogsRecordFields>;
}
export interface CfnAgentAliasEventLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentAliasEventLogsRecordFields>;
}
/**
 * Builder for CfnFlowLogsMixin to generate APPLICATION_LOGS for CfnFlow
 *
 * @cloudformationResource AWS::Bedrock::Flow
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnFlowApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnFlowApplicationLogsS3Props): CfnFlowLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnFlowApplicationLogsLogGroupProps): CfnFlowLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnFlowApplicationLogsFirehoseProps): CfnFlowLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnFlowApplicationLogsDestProps): CfnFlowLogsMixin;
}
/**
 * Creates a prompt flow that you can use to send an input through various steps to yield an output.
 *
 * You define a flow by configuring nodes, each of which corresponds to a step of the flow, and creating connections between the nodes to create paths to different outputs. You can define the flow in one of the following ways:
 *
 * - Define a [FlowDefinition](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bedrock-flow-flowdefinition.html) in the `Definition` property.
 * - Provide the definition in the `DefinitionString` property as a JSON-formatted string matching the [FlowDefinition](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bedrock-flow-flowdefinition.html) property.
 * - Provide an Amazon S3 location in the `DefinitionS3Location` property that matches the [FlowDefinition](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bedrock-flow-flowdefinition.html) .
 *
 * If you use the `DefinitionString` or `DefinitionS3Location` property, you can use the `DefinitionSubstitutions` property to define key-value pairs to replace at runtime.
 *
 * For more information, see [How it works](https://docs.aws.amazon.com/bedrock/latest/userguide/flows-how-it-works.html) and [Create a prompt flow in Amazon Bedrock](https://docs.aws.amazon.com/bedrock/latest/userguide/flows-create.html) in the Amazon Bedrock User Guide.
 *
 * @cloudformationResource AWS::Bedrock::Flow
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-flow.html
 */
export declare class CfnFlowLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnFlowApplicationLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::Bedrock::Flow`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnFlow;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnFlowApplicationLogs.
 */
export declare class CfnFlowApplicationLogsOutputFormat {
}
export declare namespace CfnFlowApplicationLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnFlowApplicationLogsRecordFields {
    EVENT_TIMESTAMP = "event_timestamp",
    RESOURCE_ARN = "resource_arn",
    SCHEMA_VERSION = "schema_version",
    FLOW_ID = "flow_id",
    FLOW_ALIAS_ID = "flow_alias_id",
    FLOW_VERSION = "flow_version",
    REQUEST_ID = "request_id",
    EXECUTION_ID = "execution_id",
    EVENT_TYPE = "event_type",
    EVENT = "event"
}
export interface CfnFlowApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnFlowApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFlowApplicationLogsRecordFields>;
}
export interface CfnFlowApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnFlowApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFlowApplicationLogsRecordFields>;
}
export interface CfnFlowApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnFlowApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFlowApplicationLogsRecordFields>;
}
export interface CfnFlowApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFlowApplicationLogsRecordFields>;
}
/**
 * Builder for CfnKnowledgeBaseLogsMixin to generate APPLICATION_LOGS for CfnKnowledgeBase
 *
 * @cloudformationResource AWS::Bedrock::KnowledgeBase
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnKnowledgeBaseApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnKnowledgeBaseApplicationLogsS3Props): CfnKnowledgeBaseLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnKnowledgeBaseApplicationLogsLogGroupProps): CfnKnowledgeBaseLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnKnowledgeBaseApplicationLogsFirehoseProps): CfnKnowledgeBaseLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnKnowledgeBaseApplicationLogsDestProps): CfnKnowledgeBaseLogsMixin;
}
/**
 * Builder for CfnKnowledgeBaseLogsMixin to generate RUNTIME_LOGS for CfnKnowledgeBase
 *
 * @cloudformationResource AWS::Bedrock::KnowledgeBase
 * @logType RUNTIME_LOGS
 * @stability external
 */
export declare class CfnKnowledgeBaseRuntimeLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnKnowledgeBaseRuntimeLogsS3Props): CfnKnowledgeBaseLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnKnowledgeBaseRuntimeLogsLogGroupProps): CfnKnowledgeBaseLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnKnowledgeBaseRuntimeLogsFirehoseProps): CfnKnowledgeBaseLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnKnowledgeBaseRuntimeLogsDestProps): CfnKnowledgeBaseLogsMixin;
}
/**
 * Builder for CfnKnowledgeBaseLogsMixin to generate TRACES for CfnKnowledgeBase
 *
 * @cloudformationResource AWS::Bedrock::KnowledgeBase
 * @logType TRACES
 * @stability external
 */
export declare class CfnKnowledgeBaseTraces {
    /**
     * Send traces to X-Ray
     *
     * @param props Additional properties that are optionally used in log delivery for XRay destinations
     */
    toXRay(props?: CfnKnowledgeBaseTracesXRayProps): CfnKnowledgeBaseLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are XRAY
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnKnowledgeBaseTracesDestProps): CfnKnowledgeBaseLogsMixin;
}
/**
 * Specifies a knowledge base as a resource in a top-level template. Minimally, you must specify the following properties:.
 *
 * - Name – Specify a name for the knowledge base.
 * - RoleArn – Specify the Amazon Resource Name (ARN) of the IAM role with permissions to invoke API operations on the knowledge base. For more information, see [Create a service role for Knowledge base for Amazon Bedrock](https://docs.aws.amazon.com/bedrock/latest/userguide/kb-permissions.html) .
 * - KnowledgeBaseConfiguration – Specify the embeddings configuration of the knowledge base. The following sub-properties are required:
 *
 * - Type – Specify the value `VECTOR` .
 * - StorageConfiguration – Specify information about the vector store in which the data source is stored. The following sub-properties are required:
 *
 * - Type – Specify the vector store service that you are using.
 *
 * > Redis Enterprise Cloud vector stores are currently unsupported in CloudFormation .
 *
 * For more information about using knowledge bases in Amazon Bedrock , see [Knowledge base for Amazon Bedrock](https://docs.aws.amazon.com/bedrock/latest/userguide/knowledge-base.html) .
 *
 * See the *Properties* section below for descriptions of both the required and optional properties.
 *
 * @cloudformationResource AWS::Bedrock::KnowledgeBase
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-knowledgebase.html
 */
export declare class CfnKnowledgeBaseLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnKnowledgeBaseApplicationLogs;
    static readonly RUNTIME_LOGS: CfnKnowledgeBaseRuntimeLogs;
    static readonly TRACES: CfnKnowledgeBaseTraces;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::Bedrock::KnowledgeBase`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnKnowledgeBase;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnKnowledgeBaseApplicationLogs.
 */
export declare class CfnKnowledgeBaseApplicationLogsOutputFormat {
}
export declare namespace CfnKnowledgeBaseApplicationLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnKnowledgeBaseApplicationLogsRecordFields {
    EVENT_TIMESTAMP = "event_timestamp",
    EVENT = "event",
    EVENT_VERSION = "event_version",
    EVENT_TYPE = "event_type",
    LEVEL = "level"
}
export interface CfnKnowledgeBaseApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c
     */
    readonly outputFormat?: CfnKnowledgeBaseApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseApplicationLogsRecordFields>;
}
export interface CfnKnowledgeBaseApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnKnowledgeBaseApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseApplicationLogsRecordFields>;
}
export interface CfnKnowledgeBaseApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnKnowledgeBaseApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseApplicationLogsRecordFields>;
}
export interface CfnKnowledgeBaseApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseApplicationLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnKnowledgeBaseRuntimeLogs.
 */
export declare class CfnKnowledgeBaseRuntimeLogsOutputFormat {
}
export declare namespace CfnKnowledgeBaseRuntimeLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnKnowledgeBaseRuntimeLogsRecordFields {
    EVENT_TIMESTAMP = "event_timestamp",
    EVENT = "event",
    EVENT_VERSION = "event_version",
    EVENT_TYPE = "event_type",
    LEVEL = "level"
}
export interface CfnKnowledgeBaseRuntimeLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c
     */
    readonly outputFormat?: CfnKnowledgeBaseRuntimeLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseRuntimeLogsRecordFields>;
}
export interface CfnKnowledgeBaseRuntimeLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnKnowledgeBaseRuntimeLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseRuntimeLogsRecordFields>;
}
export interface CfnKnowledgeBaseRuntimeLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnKnowledgeBaseRuntimeLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseRuntimeLogsRecordFields>;
}
export interface CfnKnowledgeBaseRuntimeLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseRuntimeLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnKnowledgeBaseTraces.
 */
export declare class CfnKnowledgeBaseTracesOutputFormat {
}
export declare enum CfnKnowledgeBaseTracesRecordFields {
    TRACE = "trace"
}
export interface CfnKnowledgeBaseTracesXRayProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseTracesRecordFields>;
}
export interface CfnKnowledgeBaseTracesDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnKnowledgeBaseTracesRecordFields>;
}
