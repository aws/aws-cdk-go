import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.datasync@DataSyncAgentStateChange
 */
export declare class DataSyncAgentStateChange {
    /**
     * EventBridge event pattern for DataSync Agent State Change
     */
    static dataSyncAgentStateChangePattern(options?: DataSyncAgentStateChange.DataSyncAgentStateChangeProps): events.EventPattern;
}
export declare namespace DataSyncAgentStateChange {
    /**
     * Props type for aws.datasync@DataSyncAgentStateChange event
     */
    interface DataSyncAgentStateChangeProps {
        /**
         * State property
         *
         * Specify an array of string values to match this event if the actual value of State is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.datasync@DataSyncLocationStateChange
 */
export declare class DataSyncLocationStateChange {
    /**
     * EventBridge event pattern for DataSync Location State Change
     */
    static dataSyncLocationStateChangePattern(options?: DataSyncLocationStateChange.DataSyncLocationStateChangeProps): events.EventPattern;
}
export declare namespace DataSyncLocationStateChange {
    /**
     * Props type for aws.datasync@DataSyncLocationStateChange event
     */
    interface DataSyncLocationStateChangeProps {
        /**
         * State property
         *
         * Specify an array of string values to match this event if the actual value of State is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.datasync@DataSyncTaskExecutionStateChange
 */
export declare class DataSyncTaskExecutionStateChange {
    /**
     * EventBridge event pattern for DataSync Task Execution State Change
     */
    static dataSyncTaskExecutionStateChangePattern(options?: DataSyncTaskExecutionStateChange.DataSyncTaskExecutionStateChangeProps): events.EventPattern;
}
export declare namespace DataSyncTaskExecutionStateChange {
    /**
     * Props type for aws.datasync@DataSyncTaskExecutionStateChange event
     */
    interface DataSyncTaskExecutionStateChangeProps {
        /**
         * State property
         *
         * Specify an array of string values to match this event if the actual value of State is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.datasync@DataSyncTaskStateChange
 */
export declare class DataSyncTaskStateChange {
    /**
     * EventBridge event pattern for DataSync Task State Change
     */
    static dataSyncTaskStateChangePattern(options?: DataSyncTaskStateChange.DataSyncTaskStateChangeProps): events.EventPattern;
}
export declare namespace DataSyncTaskStateChange {
    /**
     * Props type for aws.datasync@DataSyncTaskStateChange event
     */
    interface DataSyncTaskStateChangeProps {
        /**
         * State property
         *
         * Specify an array of string values to match this event if the actual value of State is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
