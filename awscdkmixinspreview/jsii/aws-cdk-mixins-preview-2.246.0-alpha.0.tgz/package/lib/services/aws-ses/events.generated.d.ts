import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.ses@AdvisorRecommendationStatusOpen
 */
export declare class AdvisorRecommendationStatusOpen {
    /**
     * EventBridge event pattern for Advisor Recommendation Status Open
     */
    static advisorRecommendationStatusOpenPattern(options?: AdvisorRecommendationStatusOpen.AdvisorRecommendationStatusOpenProps): events.EventPattern;
}
export declare namespace AdvisorRecommendationStatusOpen {
    /**
     * Props type for aws.ses@AdvisorRecommendationStatusOpen event
     */
    interface AdvisorRecommendationStatusOpenProps {
        /**
         * data property
         *
         * Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly data?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.ses@AdvisorRecommendationStatusResolved
 */
export declare class AdvisorRecommendationStatusResolved {
    /**
     * EventBridge event pattern for Advisor Recommendation Status Resolved
     */
    static advisorRecommendationStatusResolvedPattern(options?: AdvisorRecommendationStatusResolved.AdvisorRecommendationStatusResolvedProps): events.EventPattern;
}
export declare namespace AdvisorRecommendationStatusResolved {
    /**
     * Props type for aws.ses@AdvisorRecommendationStatusResolved event
     */
    interface AdvisorRecommendationStatusResolvedProps {
        /**
         * data property
         *
         * Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly data?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
