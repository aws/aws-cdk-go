import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-route53recoveryreadiness";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.route53recoveryreadiness@Route53ApplicationRecoveryControllerCellReadinessStatusChange
 */
export declare class Route53ApplicationRecoveryControllerCellReadinessStatusChange {
    /**
     * EventBridge event pattern for Route 53 Application Recovery Controller cell readiness status change
     */
    static route53ApplicationRecoveryControllerCellReadinessStatusChangePattern(options?: Route53ApplicationRecoveryControllerCellReadinessStatusChange.Route53ApplicationRecoveryControllerCellReadinessStatusChangeProps): events.EventPattern;
}
export declare namespace Route53ApplicationRecoveryControllerCellReadinessStatusChange {
    /**
     * Props type for aws.route53recoveryreadiness@Route53ApplicationRecoveryControllerCellReadinessStatusChange event
     */
    interface Route53ApplicationRecoveryControllerCellReadinessStatusChangeProps {
        /**
         * new-state property
         *
         * Specify an array of string values to match this event if the actual value of new-state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly newState?: Route53ApplicationRecoveryControllerCellReadinessStatusChange.State;
        /**
         * previous-state property
         *
         * Specify an array of string values to match this event if the actual value of previous-state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousState?: Route53ApplicationRecoveryControllerCellReadinessStatusChange.State;
        /**
         * cell-name property
         *
         * Specify an array of string values to match this event if the actual value of cell-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Cell reference
         */
        readonly cellName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for State
     *
     * @struct
     */
    interface State {
        /**
         * readiness-status property
         *
         * Specify an array of string values to match this event if the actual value of readiness-status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly readinessStatus?: Array<string>;
    }
}
/**
 * EventBridge event patterns for Cell
 */
export declare class CellEvents {
    /**
     * Create CellEvents from a Cell reference
     */
    static fromCell(cellRef: service.ICellRef): CellEvents;
    /**
     * Reference to the Cell construct
     */
    private readonly cellRef;
    private constructor();
    /**
     * EventBridge event pattern for Cell Route 53 Application Recovery Controller cell readiness status change
     */
    route53ApplicationRecoveryControllerCellReadinessStatusChangePattern(options?: Route53ApplicationRecoveryControllerCellReadinessStatusChange.Route53ApplicationRecoveryControllerCellReadinessStatusChangeProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.route53recoveryreadiness@Route53ApplicationRecoveryControllerReadinessCheckStatusChange
 */
export declare class Route53ApplicationRecoveryControllerReadinessCheckStatusChange {
    /**
     * EventBridge event pattern for Route 53 Application Recovery Controller readiness check status change
     */
    static route53ApplicationRecoveryControllerReadinessCheckStatusChangePattern(options?: Route53ApplicationRecoveryControllerReadinessCheckStatusChange.Route53ApplicationRecoveryControllerReadinessCheckStatusChangeProps): events.EventPattern;
}
export declare namespace Route53ApplicationRecoveryControllerReadinessCheckStatusChange {
    /**
     * Props type for aws.route53recoveryreadiness@Route53ApplicationRecoveryControllerReadinessCheckStatusChange event
     */
    interface Route53ApplicationRecoveryControllerReadinessCheckStatusChangeProps {
        /**
         * new-state property
         *
         * Specify an array of string values to match this event if the actual value of new-state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly newState?: Route53ApplicationRecoveryControllerReadinessCheckStatusChange.State;
        /**
         * previous-state property
         *
         * Specify an array of string values to match this event if the actual value of previous-state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousState?: Route53ApplicationRecoveryControllerReadinessCheckStatusChange.State;
        /**
         * readiness-check-name property
         *
         * Specify an array of string values to match this event if the actual value of readiness-check-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the ReadinessCheck reference
         */
        readonly readinessCheckName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for State
     *
     * @struct
     */
    interface State {
        /**
         * readiness-status property
         *
         * Specify an array of string values to match this event if the actual value of readiness-status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly readinessStatus?: Array<string>;
    }
}
/**
 * EventBridge event patterns for ReadinessCheck
 */
export declare class ReadinessCheckEvents {
    /**
     * Create ReadinessCheckEvents from a ReadinessCheck reference
     */
    static fromReadinessCheck(readinessCheckRef: service.IReadinessCheckRef): ReadinessCheckEvents;
    /**
     * Reference to the ReadinessCheck construct
     */
    private readonly readinessCheckRef;
    private constructor();
    /**
     * EventBridge event pattern for ReadinessCheck Route 53 Application Recovery Controller readiness check status change
     */
    route53ApplicationRecoveryControllerReadinessCheckStatusChangePattern(options?: Route53ApplicationRecoveryControllerReadinessCheckStatusChange.Route53ApplicationRecoveryControllerReadinessCheckStatusChangeProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.route53recoveryreadiness@Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange
 */
export declare class Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange {
    /**
     * EventBridge event pattern for Route 53 Application Recovery Controller recovery group readiness status change
     */
    static route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChangePattern(options?: Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange.Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChangeProps): events.EventPattern;
}
export declare namespace Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange {
    /**
     * Props type for aws.route53recoveryreadiness@Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange event
     */
    interface Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChangeProps {
        /**
         * new-state property
         *
         * Specify an array of string values to match this event if the actual value of new-state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly newState?: Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange.State;
        /**
         * previous-state property
         *
         * Specify an array of string values to match this event if the actual value of previous-state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousState?: Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange.State;
        /**
         * recovery-group-name property
         *
         * Specify an array of string values to match this event if the actual value of recovery-group-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the RecoveryGroup reference
         */
        readonly recoveryGroupName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for State
     *
     * @struct
     */
    interface State {
        /**
         * readiness-status property
         *
         * Specify an array of string values to match this event if the actual value of readiness-status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly readinessStatus?: Array<string>;
    }
}
/**
 * EventBridge event patterns for RecoveryGroup
 */
export declare class RecoveryGroupEvents {
    /**
     * Create RecoveryGroupEvents from a RecoveryGroup reference
     */
    static fromRecoveryGroup(recoveryGroupRef: service.IRecoveryGroupRef): RecoveryGroupEvents;
    /**
     * Reference to the RecoveryGroup construct
     */
    private readonly recoveryGroupRef;
    private constructor();
    /**
     * EventBridge event pattern for RecoveryGroup Route 53 Application Recovery Controller recovery group readiness status change
     */
    route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChangePattern(options?: Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange.Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChangeProps): events.EventPattern;
}
