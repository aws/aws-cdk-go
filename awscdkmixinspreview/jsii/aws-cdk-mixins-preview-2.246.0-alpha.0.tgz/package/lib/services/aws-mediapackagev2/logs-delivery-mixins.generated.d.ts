import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-mediapackagev2";
/**
 * Builder for CfnChannelGroupLogsMixin to generate EGRESS_ACCESS_LOGS for CfnChannelGroup
 *
 * @cloudformationResource AWS::MediaPackageV2::ChannelGroup
 * @logType EGRESS_ACCESS_LOGS
 * @stability external
 */
export declare class CfnChannelGroupEgressAccessLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnChannelGroupEgressAccessLogsS3Props): CfnChannelGroupLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnChannelGroupEgressAccessLogsLogGroupProps): CfnChannelGroupLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnChannelGroupEgressAccessLogsFirehoseProps): CfnChannelGroupLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnChannelGroupEgressAccessLogsDestProps): CfnChannelGroupLogsMixin;
}
/**
 * Builder for CfnChannelGroupLogsMixin to generate INGRESS_ACCESS_LOGS for CfnChannelGroup
 *
 * @cloudformationResource AWS::MediaPackageV2::ChannelGroup
 * @logType INGRESS_ACCESS_LOGS
 * @stability external
 */
export declare class CfnChannelGroupIngressAccessLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnChannelGroupIngressAccessLogsS3Props): CfnChannelGroupLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnChannelGroupIngressAccessLogsLogGroupProps): CfnChannelGroupLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnChannelGroupIngressAccessLogsFirehoseProps): CfnChannelGroupLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnChannelGroupIngressAccessLogsDestProps): CfnChannelGroupLogsMixin;
}
/**
 * Specifies the configuration for a MediaPackage V2 channel group.
 *
 * @cloudformationResource AWS::MediaPackageV2::ChannelGroup
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channelgroup.html
 */
export declare class CfnChannelGroupLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly EGRESS_ACCESS_LOGS: CfnChannelGroupEgressAccessLogs;
    static readonly INGRESS_ACCESS_LOGS: CfnChannelGroupIngressAccessLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::MediaPackageV2::ChannelGroup`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnChannelGroup;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnChannelGroupEgressAccessLogs.
 */
export declare class CfnChannelGroupEgressAccessLogsOutputFormat {
}
export declare namespace CfnChannelGroupEgressAccessLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnChannelGroupEgressAccessLogsRecordFields {
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    CLIENT_IP = "client_ip",
    TIME_TO_FIRST_BYTE = "time_to_first_byte",
    STATUS_CODE = "status_code",
    RECEIVED_BYTES = "received_bytes",
    SENT_BYTES = "sent_bytes",
    METHOD = "method",
    REQUEST_URI_BASE = "request_uri_base",
    REQUEST_QUERY_PARAMS = "request_query_params",
    PROTOCOL = "protocol",
    USER_AGENT = "user_agent",
    DOMAIN_NAME = "domain_name",
    REQUEST_ID = "request_id",
    ACCOUNT = "account",
    CHANNEL_ID = "channel_id",
    CHANNEL_ARN = "channel_arn",
    ENDPOINT_ID = "endpoint_id",
    ENDPOINT_ARN = "endpoint_arn",
    CHANNEL_GROUP_ID = "channel_group_id",
    MANIFEST_NAME = "manifest_name",
    MANIFEST_TYPE = "manifest_type"
}
export interface CfnChannelGroupEgressAccessLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnChannelGroupEgressAccessLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnChannelGroupEgressAccessLogsRecordFields>;
}
export interface CfnChannelGroupEgressAccessLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnChannelGroupEgressAccessLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnChannelGroupEgressAccessLogsRecordFields>;
}
export interface CfnChannelGroupEgressAccessLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnChannelGroupEgressAccessLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnChannelGroupEgressAccessLogsRecordFields>;
}
export interface CfnChannelGroupEgressAccessLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnChannelGroupEgressAccessLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnChannelGroupIngressAccessLogs.
 */
export declare class CfnChannelGroupIngressAccessLogsOutputFormat {
}
export declare namespace CfnChannelGroupIngressAccessLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnChannelGroupIngressAccessLogsRecordFields {
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    CLIENT_IP = "client_ip",
    TIME_TO_FIRST_BYTE = "time_to_first_byte",
    STATUS_CODE = "status_code",
    RECEIVED_BYTES = "received_bytes",
    SENT_BYTES = "sent_bytes",
    METHOD = "method",
    REQUEST = "request",
    PROTOCOL = "protocol",
    USER_AGENT = "user_agent",
    DOMAIN_NAME = "domain_name",
    REQUEST_ID = "request_id",
    ACCOUNT = "account",
    CHANNEL_ID = "channel_id",
    CHANNEL_ARN = "channel_arn",
    CHANNEL_GROUP_ID = "channel_group_id",
    INPUT_TYPE = "input_type",
    INPUT_INDEX = "input_index"
}
export interface CfnChannelGroupIngressAccessLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnChannelGroupIngressAccessLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnChannelGroupIngressAccessLogsRecordFields>;
}
export interface CfnChannelGroupIngressAccessLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnChannelGroupIngressAccessLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnChannelGroupIngressAccessLogsRecordFields>;
}
export interface CfnChannelGroupIngressAccessLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnChannelGroupIngressAccessLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnChannelGroupIngressAccessLogsRecordFields>;
}
export interface CfnChannelGroupIngressAccessLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnChannelGroupIngressAccessLogsRecordFields>;
}
