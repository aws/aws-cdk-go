import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-ec2";
/**
 * Builder for CfnVPCLogsMixin to generate ROUTE53_RESOLVER_QUERY_LOGS for CfnVPC
 *
 * @cloudformationResource AWS::EC2::VPC
 * @logType ROUTE53_RESOLVER_QUERY_LOGS
 * @stability external
 */
export declare class CfnVPCRoute53ResolverQueryLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnVPCRoute53ResolverQueryLogsS3Props): CfnVPCLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnVPCRoute53ResolverQueryLogsLogGroupProps): CfnVPCLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnVPCRoute53ResolverQueryLogsFirehoseProps): CfnVPCLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef): CfnVPCLogsMixin;
}
/**
 * Specifies a virtual private cloud (VPC).
 *
 * A VPC must have an associated IPv4 CIDR block. You can specify an IPv4 CIDR block or an IPAM-allocated IPv4 CIDR block. To associate an IPv6 CIDR block with the VPC, see [AWS::EC2::VPCCidrBlock](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-vpccidrblock.html) .
 *
 * For more information, see [Virtual private clouds (VPC)](https://docs.aws.amazon.com/vpc/latest/userguide/configure-your-vpc.html) in the *Amazon VPC User Guide* .
 *
 * @cloudformationResource AWS::EC2::VPC
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-vpc.html
 */
export declare class CfnVPCLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly ROUTE53_RESOLVER_QUERY_LOGS: CfnVPCRoute53ResolverQueryLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::EC2::VPC`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnVPC;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnVPCRoute53ResolverQueryLogs.
 */
export declare class CfnVPCRoute53ResolverQueryLogsOutputFormat {
}
export declare namespace CfnVPCRoute53ResolverQueryLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export interface CfnVPCRoute53ResolverQueryLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnVPCRoute53ResolverQueryLogsOutputFormat.S3;
}
export interface CfnVPCRoute53ResolverQueryLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnVPCRoute53ResolverQueryLogsOutputFormat.LogGroup;
}
export interface CfnVPCRoute53ResolverQueryLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnVPCRoute53ResolverQueryLogsOutputFormat.Firehose;
}
/**
 * Builder for CfnVPNConnectionLogsMixin to generate EVENT_LOGS for CfnVPNConnection
 *
 * @cloudformationResource AWS::EC2::VPNConnection
 * @logType EVENT_LOGS
 * @stability external
 */
export declare class CfnVPNConnectionEventLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnVPNConnectionEventLogsS3Props): CfnVPNConnectionLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnVPNConnectionEventLogsLogGroupProps): CfnVPNConnectionLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnVPNConnectionEventLogsFirehoseProps): CfnVPNConnectionLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnVPNConnectionEventLogsDestProps): CfnVPNConnectionLogsMixin;
}
/**
 * Builder for CfnVPNConnectionLogsMixin to generate CONNECTION_LOGS for CfnVPNConnection
 *
 * @cloudformationResource AWS::EC2::VPNConnection
 * @logType CONNECTION_LOGS
 * @stability external
 */
export declare class CfnVPNConnectionConnectionLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnVPNConnectionConnectionLogsS3Props): CfnVPNConnectionLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnVPNConnectionConnectionLogsLogGroupProps): CfnVPNConnectionLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnVPNConnectionConnectionLogsFirehoseProps): CfnVPNConnectionLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnVPNConnectionConnectionLogsDestProps): CfnVPNConnectionLogsMixin;
}
/**
 * Specifies a VPN connection between a virtual private gateway and a VPN customer gateway or a transit gateway and a VPN customer gateway.
 *
 * To specify a VPN connection between a transit gateway and customer gateway, use the `TransitGatewayId` and `CustomerGatewayId` properties.
 *
 * To specify a VPN connection between a virtual private gateway and customer gateway, use the `VpnGatewayId` and `CustomerGatewayId` properties.
 *
 * For more information, see [AWS Site-to-Site VPN](https://docs.aws.amazon.com/vpn/latest/s2svpn/VPC_VPN.html) in the *AWS Site-to-Site VPN User Guide* .
 *
 * @cloudformationResource AWS::EC2::VPNConnection
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-vpnconnection.html
 */
export declare class CfnVPNConnectionLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly EVENT_LOGS: CfnVPNConnectionEventLogs;
    static readonly CONNECTION_LOGS: CfnVPNConnectionConnectionLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::EC2::VPNConnection`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnVPNConnection;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnVPNConnectionEventLogs.
 */
export declare class CfnVPNConnectionEventLogsOutputFormat {
}
export declare namespace CfnVPNConnectionEventLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnVPNConnectionEventLogsRecordFields {
    TIMESTAMP = "timestamp",
    TYPE = "type",
    STATUS = "status",
    MESSAGE = "message",
    RESOURCE_ID = "resource_id",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnVPNConnectionEventLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnVPNConnectionEventLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnVPNConnectionEventLogsRecordFields>;
}
export interface CfnVPNConnectionEventLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnVPNConnectionEventLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnVPNConnectionEventLogsRecordFields>;
}
export interface CfnVPNConnectionEventLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnVPNConnectionEventLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnVPNConnectionEventLogsRecordFields>;
}
export interface CfnVPNConnectionEventLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnVPNConnectionEventLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnVPNConnectionConnectionLogs.
 */
export declare class CfnVPNConnectionConnectionLogsOutputFormat {
}
export declare namespace CfnVPNConnectionConnectionLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnVPNConnectionConnectionLogsRecordFields {
    TIMESTAMP = "timestamp",
    DPD_ENABLED = "dpd_enabled",
    NAT_T_DETECTED = "nat_t_detected",
    IKE_PHASE1_STATE = "ike_phase1_state",
    IKE_PHASE2_STATE = "ike_phase2_state",
    EVENT_TIMESTAMP = "event_timestamp",
    DETAILS = "details"
}
export interface CfnVPNConnectionConnectionLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnVPNConnectionConnectionLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnVPNConnectionConnectionLogsRecordFields>;
}
export interface CfnVPNConnectionConnectionLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnVPNConnectionConnectionLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnVPNConnectionConnectionLogsRecordFields>;
}
export interface CfnVPNConnectionConnectionLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnVPNConnectionConnectionLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnVPNConnectionConnectionLogsRecordFields>;
}
export interface CfnVPNConnectionConnectionLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnVPNConnectionConnectionLogsRecordFields>;
}
/**
 * Builder for CfnVerifiedAccessInstanceLogsMixin to generate VERIFIED_ACCESS_LOGS for CfnVerifiedAccessInstance
 *
 * @cloudformationResource AWS::EC2::VerifiedAccessInstance
 * @logType VERIFIED_ACCESS_LOGS
 * @stability external
 */
export declare class CfnVerifiedAccessInstanceVerifiedAccessLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnVerifiedAccessInstanceVerifiedAccessLogsS3Props): CfnVerifiedAccessInstanceLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnVerifiedAccessInstanceVerifiedAccessLogsLogGroupProps): CfnVerifiedAccessInstanceLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnVerifiedAccessInstanceVerifiedAccessLogsFirehoseProps): CfnVerifiedAccessInstanceLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef): CfnVerifiedAccessInstanceLogsMixin;
}
/**
 * An AWS Verified Access instance is a regional entity that evaluates application requests and grants access only when your security requirements are met.
 *
 * @cloudformationResource AWS::EC2::VerifiedAccessInstance
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-verifiedaccessinstance.html
 */
export declare class CfnVerifiedAccessInstanceLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly VERIFIED_ACCESS_LOGS: CfnVerifiedAccessInstanceVerifiedAccessLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::EC2::VerifiedAccessInstance`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnVerifiedAccessInstance;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnVerifiedAccessInstanceVerifiedAccessLogs.
 */
export declare class CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat {
}
export declare namespace CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export interface CfnVerifiedAccessInstanceVerifiedAccessLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.S3;
}
export interface CfnVerifiedAccessInstanceVerifiedAccessLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.LogGroup;
}
export interface CfnVerifiedAccessInstanceVerifiedAccessLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.Firehose;
}
/**
 * Builder for CfnRouteServerPeerLogsMixin to generate EVENT_LOGS for CfnRouteServerPeer
 *
 * @cloudformationResource AWS::EC2::RouteServerPeer
 * @logType EVENT_LOGS
 * @stability external
 */
export declare class CfnRouteServerPeerEventLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnRouteServerPeerEventLogsS3Props): CfnRouteServerPeerLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnRouteServerPeerEventLogsLogGroupProps): CfnRouteServerPeerLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnRouteServerPeerEventLogsFirehoseProps): CfnRouteServerPeerLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnRouteServerPeerEventLogsDestProps): CfnRouteServerPeerLogsMixin;
}
/**
 * Specifies a BGP peer configuration for a route server endpoint.
 *
 * A route server peer is a session between a route server endpoint and the device deployed in AWS (such as a firewall appliance or other network security function running on an EC2 instance).
 *
 * @cloudformationResource AWS::EC2::RouteServerPeer
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-routeserverpeer.html
 */
export declare class CfnRouteServerPeerLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly EVENT_LOGS: CfnRouteServerPeerEventLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::EC2::RouteServerPeer`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnRouteServerPeer;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnRouteServerPeerEventLogs.
 */
export declare class CfnRouteServerPeerEventLogsOutputFormat {
}
export declare namespace CfnRouteServerPeerEventLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnRouteServerPeerEventLogsRecordFields {
    STATUS = "status",
    MESSAGE = "message",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    TYPE = "type"
}
export interface CfnRouteServerPeerEventLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnRouteServerPeerEventLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRouteServerPeerEventLogsRecordFields>;
}
export interface CfnRouteServerPeerEventLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnRouteServerPeerEventLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRouteServerPeerEventLogsRecordFields>;
}
export interface CfnRouteServerPeerEventLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnRouteServerPeerEventLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRouteServerPeerEventLogsRecordFields>;
}
export interface CfnRouteServerPeerEventLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRouteServerPeerEventLogsRecordFields>;
}
