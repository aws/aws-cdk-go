import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-stepfunctions";
/**
 * Builder for CfnStateMachineLogsMixin to generate EXPRESS_LOGS for CfnStateMachine
 *
 * @cloudformationResource AWS::StepFunctions::StateMachine
 * @logType EXPRESS_LOGS
 * @stability external
 */
export declare class CfnStateMachineExpressLogs {
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnStateMachineExpressLogsLogGroupProps): CfnStateMachineLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are CWL
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnStateMachineExpressLogsDestProps): CfnStateMachineLogsMixin;
}
/**
 * Builder for CfnStateMachineLogsMixin to generate STANDARD_LOGS for CfnStateMachine
 *
 * @cloudformationResource AWS::StepFunctions::StateMachine
 * @logType STANDARD_LOGS
 * @stability external
 */
export declare class CfnStateMachineStandardLogs {
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnStateMachineStandardLogsLogGroupProps): CfnStateMachineLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are CWL
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnStateMachineStandardLogsDestProps): CfnStateMachineLogsMixin;
}
/**
 * Provisions a state machine.
 *
 * A state machine consists of a collection of states that can do work ( `Task` states), determine to which states to transition next ( `Choice` states), stop an execution with an error ( `Fail` states), and so on. State machines are specified using a JSON-based, structured language.
 *
 * @cloudformationResource AWS::StepFunctions::StateMachine
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-stepfunctions-statemachine.html
 */
export declare class CfnStateMachineLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly EXPRESS_LOGS: CfnStateMachineExpressLogs;
    static readonly STANDARD_LOGS: CfnStateMachineStandardLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::StepFunctions::StateMachine`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnStateMachine;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnStateMachineExpressLogs.
 */
export declare class CfnStateMachineExpressLogsOutputFormat {
}
export declare namespace CfnStateMachineExpressLogsOutputFormat {
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
}
export declare enum CfnStateMachineExpressLogsRecordFields {
    DETAILS = "details",
    MAP_RUN_ARN = "map_run_arn",
    PARENT_EXECUTION_ARN = "parent_execution_arn",
    REDRIVE_COUNT = "redrive_count",
    ID = "id",
    TYPE = "type",
    PREVIOUS_EVENT_ID = "previous_event_id",
    EVENT_TIMESTAMP = "event_timestamp",
    EXECUTION_ARN = "execution_arn"
}
export interface CfnStateMachineExpressLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnStateMachineExpressLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnStateMachineExpressLogsRecordFields>;
}
export interface CfnStateMachineExpressLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnStateMachineExpressLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnStateMachineStandardLogs.
 */
export declare class CfnStateMachineStandardLogsOutputFormat {
}
export declare namespace CfnStateMachineStandardLogsOutputFormat {
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
}
export declare enum CfnStateMachineStandardLogsRecordFields {
    DETAILS = "details",
    MAP_RUN_ARN = "map_run_arn",
    PARENT_EXECUTION_ARN = "parent_execution_arn",
    REDRIVE_COUNT = "redrive_count",
    ID = "id",
    TYPE = "type",
    PREVIOUS_EVENT_ID = "previous_event_id",
    EVENT_TIMESTAMP = "event_timestamp",
    EXECUTION_ARN = "execution_arn"
}
export interface CfnStateMachineStandardLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnStateMachineStandardLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnStateMachineStandardLogsRecordFields>;
}
export interface CfnStateMachineStandardLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnStateMachineStandardLogsRecordFields>;
}
