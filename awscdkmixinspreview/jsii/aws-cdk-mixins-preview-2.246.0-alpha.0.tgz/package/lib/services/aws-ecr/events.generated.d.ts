import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-ecr";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.ecr@AWSAPICallViaCloudTrail
 */
export declare class AWSAPICallViaCloudTrail {
    /**
     * EventBridge event pattern for AWS API Call via CloudTrail
     */
    static awsAPICallViaCloudTrailPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
}
export declare namespace AWSAPICallViaCloudTrail {
    /**
     * Props type for aws.ecr@AWSAPICallViaCloudTrail event
     */
    interface AWSAPICallViaCloudTrailProps {
        /**
         * requestParameters property
         *
         * Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestParameters?: AWSAPICallViaCloudTrail.RequestParameters;
        /**
         * userIdentity property
         *
         * Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userIdentity?: AWSAPICallViaCloudTrail.UserIdentity;
        /**
         * eventID property
         *
         * Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * awsRegion property
         *
         * Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsRegion?: Array<string>;
        /**
         * eventVersion property
         *
         * Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventVersion?: Array<string>;
        /**
         * responseElements property
         *
         * Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly responseElements?: Array<string>;
        /**
         * sourceIPAddress property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * eventSource property
         *
         * Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventSource?: Array<string>;
        /**
         * resources property
         *
         * Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resources?: Array<AWSAPICallViaCloudTrail.AwsapiCallViaCloudTrailItem>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * requestID property
         *
         * Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for RequestParameters
     *
     * @struct
     */
    interface RequestParameters {
        /**
         * acceptedMediaTypes property
         *
         * Specify an array of string values to match this event if the actual value of acceptedMediaTypes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly acceptedMediaTypes?: Array<string>;
        /**
         * registryId property
         *
         * Specify an array of string values to match this event if the actual value of registryId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly registryId?: Array<string>;
        /**
         * repositoryName property
         *
         * Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Repository reference
         */
        readonly repositoryName?: Array<string>;
        /**
         * imageIds property
         *
         * Specify an array of string values to match this event if the actual value of imageIds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageIds?: Array<AWSAPICallViaCloudTrail.RequestParametersItem>;
    }
    /**
     * Type definition for RequestParametersItem
     *
     * @struct
     */
    interface RequestParametersItem {
        /**
         * imageTag property
         *
         * Specify an array of string values to match this event if the actual value of imageTag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageTag?: Array<string>;
    }
    /**
     * Type definition for UserIdentity
     *
     * @struct
     */
    interface UserIdentity {
        /**
         * sessionContext property
         *
         * Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionContext?: AWSAPICallViaCloudTrail.SessionContext;
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * invokedBy property
         *
         * Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly invokedBy?: Array<string>;
    }
    /**
     * Type definition for SessionContext
     *
     * @struct
     */
    interface SessionContext {
        /**
         * webIdFederationData property
         *
         * Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly webIdFederationData?: Array<string>;
        /**
         * sessionIssuer property
         *
         * Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionIssuer?: AWSAPICallViaCloudTrail.SessionIssuer;
        /**
         * attributes property
         *
         * Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attributes?: AWSAPICallViaCloudTrail.Attributes;
    }
    /**
     * Type definition for SessionIssuer
     *
     * @struct
     */
    interface SessionIssuer {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * userName property
         *
         * Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userName?: Array<string>;
    }
    /**
     * Type definition for Attributes
     *
     * @struct
     */
    interface Attributes {
        /**
         * mfaAuthenticated property
         *
         * Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mfaAuthenticated?: Array<string>;
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
    }
    /**
     * Type definition for AWSAPICallViaCloudTrailItem
     *
     * @struct
     */
    interface AwsapiCallViaCloudTrailItem {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * ARN property
         *
         * Specify an array of string values to match this event if the actual value of ARN is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
    }
}
/**
 * EventBridge event patterns for Repository
 */
export declare class RepositoryEvents {
    /**
     * Create RepositoryEvents from a Repository reference
     */
    static fromRepository(repositoryRef: service.IRepositoryRef): RepositoryEvents;
    /**
     * Reference to the Repository construct
     */
    private readonly repositoryRef;
    private constructor();
    /**
     * EventBridge event pattern for Repository AWS API Call via CloudTrail
     */
    awsAPICallViaCloudTrailPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
    /**
     * EventBridge event pattern for Repository ECR Image Action
     */
    ecrImageActionPattern(options?: ECRImageAction.ECRImageActionProps): events.EventPattern;
    /**
     * EventBridge event pattern for Repository ECR Image Scan
     */
    ecrImageScanPattern(options?: ECRImageScan.ECRImageScanProps): events.EventPattern;
    /**
     * EventBridge event pattern for Repository ECR Pull Through Cache Action
     */
    ecrPullThroughCacheActionPattern(options?: ECRPullThroughCacheAction.ECRPullThroughCacheActionProps): events.EventPattern;
    /**
     * EventBridge event pattern for Repository ECR Referrer Action
     */
    ecrReferrerActionPattern(options?: ECRReferrerAction.ECRReferrerActionProps): events.EventPattern;
    /**
     * EventBridge event pattern for Repository ECR Replication Action
     */
    ecrReplicationActionPattern(options?: ECRReplicationAction.ECRReplicationActionProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.ecr@ECRImageAction
 */
export declare class ECRImageAction {
    /**
     * EventBridge event pattern for ECR Image Action
     */
    static ecrImageActionPattern(options?: ECRImageAction.ECRImageActionProps): events.EventPattern;
}
export declare namespace ECRImageAction {
    /**
     * Props type for aws.ecr@ECRImageAction event
     */
    interface ECRImageActionProps {
        /**
         * action-type property
         *
         * Specify an array of string values to match this event if the actual value of action-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionType?: Array<string>;
        /**
         * target-storage-class property
         *
         * Specify an array of string values to match this event if the actual value of target-storage-class is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetStorageClass?: Array<string>;
        /**
         * image-digest property
         *
         * Specify an array of string values to match this event if the actual value of image-digest is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageDigest?: Array<string>;
        /**
         * image-tag property
         *
         * Specify an array of string values to match this event if the actual value of image-tag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageTag?: Array<string>;
        /**
         * repository-name property
         *
         * Specify an array of string values to match this event if the actual value of repository-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Repository reference
         */
        readonly repositoryName?: Array<string>;
        /**
         * result property
         *
         * Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly result?: Array<string>;
        /**
         * manifest-media-type property
         *
         * Specify an array of string values to match this event if the actual value of manifest-media-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly manifestMediaType?: Array<string>;
        /**
         * artifact-media-type property
         *
         * Specify an array of string values to match this event if the actual value of artifact-media-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly artifactMediaType?: Array<string>;
        /**
         * last-activated-at property
         *
         * Specify an array of string values to match this event if the actual value of last-activated-at is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastActivatedAt?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.ecr@ECRImageScan
 */
export declare class ECRImageScan {
    /**
     * EventBridge event pattern for ECR Image Scan
     */
    static ecrImageScanPattern(options?: ECRImageScan.ECRImageScanProps): events.EventPattern;
}
export declare namespace ECRImageScan {
    /**
     * Props type for aws.ecr@ECRImageScan event
     */
    interface ECRImageScanProps {
        /**
         * image-digest property
         *
         * Specify an array of string values to match this event if the actual value of image-digest is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageDigest?: Array<string>;
        /**
         * image-tags property
         *
         * Specify an array of string values to match this event if the actual value of image-tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageTags?: Array<string>;
        /**
         * repository-name property
         *
         * Specify an array of string values to match this event if the actual value of repository-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Repository reference
         */
        readonly repositoryName?: Array<string>;
        /**
         * scan-status property
         *
         * Specify an array of string values to match this event if the actual value of scan-status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scanStatus?: Array<string>;
        /**
         * finding-severity-counts property
         *
         * Specify an array of string values to match this event if the actual value of finding-severity-counts is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly findingSeverityCounts?: ECRImageScan.FindingSeverityCounts;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for FindingSeverityCounts
     *
     * @struct
     */
    interface FindingSeverityCounts {
        /**
         * CRITICAL property
         *
         * Specify an array of string values to match this event if the actual value of CRITICAL is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly critical?: Array<string>;
        /**
         * HIGH property
         *
         * Specify an array of string values to match this event if the actual value of HIGH is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly high?: Array<string>;
        /**
         * INFORMATIONAL property
         *
         * Specify an array of string values to match this event if the actual value of INFORMATIONAL is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly informational?: Array<string>;
        /**
         * LOW property
         *
         * Specify an array of string values to match this event if the actual value of LOW is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly low?: Array<string>;
        /**
         * MEDIUM property
         *
         * Specify an array of string values to match this event if the actual value of MEDIUM is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly medium?: Array<string>;
        /**
         * UNDEFINED property
         *
         * Specify an array of string values to match this event if the actual value of UNDEFINED is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly undefined?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.ecr@ECRPullThroughCacheAction
 */
export declare class ECRPullThroughCacheAction {
    /**
     * EventBridge event pattern for ECR Pull Through Cache Action
     */
    static ecrPullThroughCacheActionPattern(options?: ECRPullThroughCacheAction.ECRPullThroughCacheActionProps): events.EventPattern;
}
export declare namespace ECRPullThroughCacheAction {
    /**
     * Props type for aws.ecr@ECRPullThroughCacheAction event
     */
    interface ECRPullThroughCacheActionProps {
        /**
         * sync-status property
         *
         * Specify an array of string values to match this event if the actual value of sync-status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly syncStatus?: Array<string>;
        /**
         * ecr-repository-prefix property
         *
         * Specify an array of string values to match this event if the actual value of ecr-repository-prefix is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ecrRepositoryPrefix?: Array<string>;
        /**
         * repository-name property
         *
         * Specify an array of string values to match this event if the actual value of repository-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Repository reference
         */
        readonly repositoryName?: Array<string>;
        /**
         * upstream-registry-url property
         *
         * Specify an array of string values to match this event if the actual value of upstream-registry-url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly upstreamRegistryUrl?: Array<string>;
        /**
         * image-tag property
         *
         * Specify an array of string values to match this event if the actual value of image-tag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageTag?: Array<string>;
        /**
         * image-digest property
         *
         * Specify an array of string values to match this event if the actual value of image-digest is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageDigest?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-reason property
         *
         * Specify an array of string values to match this event if the actual value of failure-reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureReason?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.ecr@ECRReferrerAction
 */
export declare class ECRReferrerAction {
    /**
     * EventBridge event pattern for ECR Referrer Action
     */
    static ecrReferrerActionPattern(options?: ECRReferrerAction.ECRReferrerActionProps): events.EventPattern;
}
export declare namespace ECRReferrerAction {
    /**
     * Props type for aws.ecr@ECRReferrerAction event
     */
    interface ECRReferrerActionProps {
        /**
         * action-type property
         *
         * Specify an array of string values to match this event if the actual value of action-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionType?: Array<string>;
        /**
         * target-storage-class property
         *
         * Specify an array of string values to match this event if the actual value of target-storage-class is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly targetStorageClass?: Array<string>;
        /**
         * image-digest property
         *
         * Specify an array of string values to match this event if the actual value of image-digest is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageDigest?: Array<string>;
        /**
         * image-tag property
         *
         * Specify an array of string values to match this event if the actual value of image-tag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageTag?: Array<string>;
        /**
         * repository-name property
         *
         * Specify an array of string values to match this event if the actual value of repository-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Repository reference
         */
        readonly repositoryName?: Array<string>;
        /**
         * result property
         *
         * Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly result?: Array<string>;
        /**
         * manifest-media-type property
         *
         * Specify an array of string values to match this event if the actual value of manifest-media-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly manifestMediaType?: Array<string>;
        /**
         * artifact-media-type property
         *
         * Specify an array of string values to match this event if the actual value of artifact-media-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly artifactMediaType?: Array<string>;
        /**
         * last-activated-at property
         *
         * Specify an array of string values to match this event if the actual value of last-activated-at is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastActivatedAt?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.ecr@ECRReplicationAction
 */
export declare class ECRReplicationAction {
    /**
     * EventBridge event pattern for ECR Replication Action
     */
    static ecrReplicationActionPattern(options?: ECRReplicationAction.ECRReplicationActionProps): events.EventPattern;
}
export declare namespace ECRReplicationAction {
    /**
     * Props type for aws.ecr@ECRReplicationAction event
     */
    interface ECRReplicationActionProps {
        /**
         * action-type property
         *
         * Specify an array of string values to match this event if the actual value of action-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionType?: Array<string>;
        /**
         * image-digest property
         *
         * Specify an array of string values to match this event if the actual value of image-digest is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageDigest?: Array<string>;
        /**
         * image-tag property
         *
         * Specify an array of string values to match this event if the actual value of image-tag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageTag?: Array<string>;
        /**
         * repository-name property
         *
         * Specify an array of string values to match this event if the actual value of repository-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Repository reference
         */
        readonly repositoryName?: Array<string>;
        /**
         * result property
         *
         * Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly result?: Array<string>;
        /**
         * source-account property
         *
         * Specify an array of string values to match this event if the actual value of source-account is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceAccount?: Array<string>;
        /**
         * source-region property
         *
         * Specify an array of string values to match this event if the actual value of source-region is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceRegion?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
