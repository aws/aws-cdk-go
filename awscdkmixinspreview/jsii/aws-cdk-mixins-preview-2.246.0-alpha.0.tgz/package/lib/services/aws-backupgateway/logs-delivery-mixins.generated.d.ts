import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-backupgateway";
/**
 * Builder for CfnHypervisorLogsMixin to generate BGW_HYPERVISOR_LOGS for CfnHypervisor
 *
 * @cloudformationResource AWS::BackupGateway::Hypervisor
 * @logType BGW_HYPERVISOR_LOGS
 * @stability external
 */
export declare class CfnHypervisorBgwHypervisorLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnHypervisorBgwHypervisorLogsS3Props): CfnHypervisorLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnHypervisorBgwHypervisorLogsLogGroupProps): CfnHypervisorLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnHypervisorBgwHypervisorLogsFirehoseProps): CfnHypervisorLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef): CfnHypervisorLogsMixin;
}
/**
 * Builder for CfnHypervisorLogsMixin to generate DATA_ACCESS_LOGS for CfnHypervisor
 *
 * @cloudformationResource AWS::BackupGateway::Hypervisor
 * @logType DATA_ACCESS_LOGS
 * @stability external
 */
export declare class CfnHypervisorDataAccessLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnHypervisorDataAccessLogsS3Props): CfnHypervisorLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnHypervisorDataAccessLogsLogGroupProps): CfnHypervisorLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnHypervisorDataAccessLogsFirehoseProps): CfnHypervisorLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef): CfnHypervisorLogsMixin;
}
/**
 * Represents the hypervisor's permissions to which the gateway will connect.
 *
 * A hypervisor is hardware, software, or firmware that creates and manages virtual machines, and allocates resources to them.
 *
 * @cloudformationResource AWS::BackupGateway::Hypervisor
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-backupgateway-hypervisor.html
 */
export declare class CfnHypervisorLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly BGW_HYPERVISOR_LOGS: CfnHypervisorBgwHypervisorLogs;
    static readonly DATA_ACCESS_LOGS: CfnHypervisorDataAccessLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::BackupGateway::Hypervisor`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnHypervisor;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnHypervisorBgwHypervisorLogs.
 */
export declare class CfnHypervisorBgwHypervisorLogsOutputFormat {
}
export declare namespace CfnHypervisorBgwHypervisorLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export interface CfnHypervisorBgwHypervisorLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnHypervisorBgwHypervisorLogsOutputFormat.S3;
}
export interface CfnHypervisorBgwHypervisorLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnHypervisorBgwHypervisorLogsOutputFormat.LogGroup;
}
export interface CfnHypervisorBgwHypervisorLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnHypervisorBgwHypervisorLogsOutputFormat.Firehose;
}
/**
 * Output Format options for each destination of CfnHypervisorDataAccessLogs.
 */
export declare class CfnHypervisorDataAccessLogsOutputFormat {
}
export declare namespace CfnHypervisorDataAccessLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export interface CfnHypervisorDataAccessLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnHypervisorDataAccessLogsOutputFormat.S3;
}
export interface CfnHypervisorDataAccessLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnHypervisorDataAccessLogsOutputFormat.LogGroup;
}
export interface CfnHypervisorDataAccessLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnHypervisorDataAccessLogsOutputFormat.Firehose;
}
