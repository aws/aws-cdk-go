import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-cognito";
/**
 * Builder for CfnUserPoolLogsMixin to generate APPLICATION_LOGS for CfnUserPool
 *
 * @cloudformationResource AWS::Cognito::UserPool
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnUserPoolApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnUserPoolApplicationLogsS3Props): CfnUserPoolLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnUserPoolApplicationLogsLogGroupProps): CfnUserPoolLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnUserPoolApplicationLogsFirehoseProps): CfnUserPoolLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef): CfnUserPoolLogsMixin;
}
/**
 * The `AWS::Cognito::UserPool` resource creates an Amazon Cognito user pool.
 *
 * For more information on working with Amazon Cognito user pools, see [Amazon Cognito User Pools](https://docs.aws.amazon.com/cognito/latest/developerguide/cognito-user-identity-pools.html) and [CreateUserPool](https://docs.aws.amazon.com/cognito-user-identity-pools/latest/APIReference/API_CreateUserPool.html) .
 *
 * > If you don't specify a value for a parameter, Amazon Cognito sets it to a default value.
 *
 * @cloudformationResource AWS::Cognito::UserPool
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cognito-userpool.html
 */
export declare class CfnUserPoolLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnUserPoolApplicationLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::Cognito::UserPool`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnUserPool;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnUserPoolApplicationLogs.
 */
export declare class CfnUserPoolApplicationLogsOutputFormat {
}
export declare namespace CfnUserPoolApplicationLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export interface CfnUserPoolApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnUserPoolApplicationLogsOutputFormat.S3;
}
export interface CfnUserPoolApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnUserPoolApplicationLogsOutputFormat.LogGroup;
}
export interface CfnUserPoolApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnUserPoolApplicationLogsOutputFormat.Firehose;
}
