import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-wisdom";
/**
 * Builder for CfnAssistantLogsMixin to generate EVENT_LOGS for CfnAssistant
 *
 * @cloudformationResource AWS::Wisdom::Assistant
 * @logType EVENT_LOGS
 * @stability external
 */
export declare class CfnAssistantEventLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnAssistantEventLogsS3Props): CfnAssistantLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnAssistantEventLogsLogGroupProps): CfnAssistantLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnAssistantEventLogsFirehoseProps): CfnAssistantLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnAssistantEventLogsDestProps): CfnAssistantLogsMixin;
}
/**
 * Specifies an Amazon Connect Wisdom assistant.
 *
 * @cloudformationResource AWS::Wisdom::Assistant
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-wisdom-assistant.html
 */
export declare class CfnAssistantLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly EVENT_LOGS: CfnAssistantEventLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::Wisdom::Assistant`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAssistant;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnAssistantEventLogs.
 */
export declare class CfnAssistantEventLogsOutputFormat {
}
export declare namespace CfnAssistantEventLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnAssistantEventLogsRecordFields {
    ASSISTANT_ID = "assistant_id",
    EVENT_TIMESTAMP = "event_timestamp",
    EVENT_TYPE = "event_type",
    SESSION_ID = "session_id",
    SESSION_NAME = "session_name",
    RECOMMENDATION_ID = "recommendation_id",
    RECOMMENDATION = "recommendation",
    IS_RECOMMENDATION_USEFUL = "is_recommendation_useful",
    RELEVANCE_SCORE = "relevance_score",
    RECOMMENDATION_TITLE = "recommendation_title",
    RECOMMENDATION_SOURCES = "recommendation_sources",
    INTENT_ID = "intent_id",
    INTENT = "intent",
    INTENT_CLICKED = "intent_clicked",
    UTTERANCE = "utterance",
    PROMPT = "prompt",
    RESPONSE = "response",
    SESSION_EVENT_ID = "session_event_id",
    SESSION_EVENT_IDS = "session_event_ids",
    ISSUE_PROBABILITY = "issue_probability",
    IS_VALID_TRIGGER = "is_valid_trigger",
    PROMPT_TYPE = "prompt_type",
    COMPLETION = "completion",
    MODEL_ID = "model_id",
    CONNECT_USER_ARN = "connect_user_arn",
    CONVERSATION_SESSION_DATA = "conversation_session_data",
    SESSION_MESSAGE_ID = "session_message_id",
    PARSED_RESPONSE = "parsed_response",
    ANSWER_ID = "answer_id",
    GENERATION_ID = "generation_id",
    AI_AGENT_ID = "ai_agent_id",
    AI_AGENT_NAME = "ai_agent_name",
    AI_GUARDRAIL_ID = "ai_guardrail_id",
    NAME = "name",
    AI_GUARDRAIL = "ai_guardrail",
    CONTENT = "content",
    ACTION = "action",
    ACTION_REASON = "action_reason",
    OUTPUTS = "outputs",
    ASSESSMENTS = "assessments",
    USAGE = "usage",
    GUARDRAIL_COVERAGE = "guardrail_coverage",
    AI_AGENT_VERSION = "ai_agent_version",
    GUARDRAIL_BLOCKED = "guardrail_blocked",
    PARTICIPANT = "participant",
    VALUES = "values",
    ORCHESTRATION_ID = "orchestration_id",
    AI_AGENT_ORCHESTRATION_USE_CASE = "ai_agent_orchestration_use_case",
    ORCHESTRATION_ITERATION = "orchestration_iteration",
    ORCHESTRATION_ERROR = "orchestration_error"
}
export interface CfnAssistantEventLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnAssistantEventLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAssistantEventLogsRecordFields>;
}
export interface CfnAssistantEventLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnAssistantEventLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAssistantEventLogsRecordFields>;
}
export interface CfnAssistantEventLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnAssistantEventLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAssistantEventLogsRecordFields>;
}
export interface CfnAssistantEventLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAssistantEventLogsRecordFields>;
}
