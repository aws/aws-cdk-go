import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-elasticloadbalancingv2";
/**
 * Builder for CfnLoadBalancerLogsMixin to generate ALB_ACCESS_LOGS for CfnLoadBalancer
 *
 * @cloudformationResource AWS::ElasticLoadBalancingV2::LoadBalancer
 * @logType ALB_ACCESS_LOGS
 * @stability external
 */
export declare class CfnLoadBalancerAlbAccessLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnLoadBalancerAlbAccessLogsS3Props): CfnLoadBalancerLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnLoadBalancerAlbAccessLogsLogGroupProps): CfnLoadBalancerLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnLoadBalancerAlbAccessLogsFirehoseProps): CfnLoadBalancerLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnLoadBalancerAlbAccessLogsDestProps): CfnLoadBalancerLogsMixin;
}
/**
 * Builder for CfnLoadBalancerLogsMixin to generate ALB_CONNECTION_LOGS for CfnLoadBalancer
 *
 * @cloudformationResource AWS::ElasticLoadBalancingV2::LoadBalancer
 * @logType ALB_CONNECTION_LOGS
 * @stability external
 */
export declare class CfnLoadBalancerAlbConnectionLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnLoadBalancerAlbConnectionLogsS3Props): CfnLoadBalancerLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnLoadBalancerAlbConnectionLogsLogGroupProps): CfnLoadBalancerLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnLoadBalancerAlbConnectionLogsFirehoseProps): CfnLoadBalancerLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnLoadBalancerAlbConnectionLogsDestProps): CfnLoadBalancerLogsMixin;
}
/**
 * Builder for CfnLoadBalancerLogsMixin to generate ALB_HEALTH_CHECK_LOGS for CfnLoadBalancer
 *
 * @cloudformationResource AWS::ElasticLoadBalancingV2::LoadBalancer
 * @logType ALB_HEALTH_CHECK_LOGS
 * @stability external
 */
export declare class CfnLoadBalancerAlbHealthCheckLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnLoadBalancerAlbHealthCheckLogsS3Props): CfnLoadBalancerLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnLoadBalancerAlbHealthCheckLogsLogGroupProps): CfnLoadBalancerLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnLoadBalancerAlbHealthCheckLogsFirehoseProps): CfnLoadBalancerLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnLoadBalancerAlbHealthCheckLogsDestProps): CfnLoadBalancerLogsMixin;
}
/**
 * Builder for CfnLoadBalancerLogsMixin to generate NLB_ACCESS_LOGS for CfnLoadBalancer
 *
 * @cloudformationResource AWS::ElasticLoadBalancingV2::LoadBalancer
 * @logType NLB_ACCESS_LOGS
 * @stability external
 */
export declare class CfnLoadBalancerNlbAccessLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnLoadBalancerNlbAccessLogsS3Props): CfnLoadBalancerLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnLoadBalancerNlbAccessLogsLogGroupProps): CfnLoadBalancerLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnLoadBalancerNlbAccessLogsFirehoseProps): CfnLoadBalancerLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnLoadBalancerNlbAccessLogsDestProps): CfnLoadBalancerLogsMixin;
}
/**
 * Specifies an Application Load Balancer, a Network Load Balancer, or a Gateway Load Balancer.
 *
 * @cloudformationResource AWS::ElasticLoadBalancingV2::LoadBalancer
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-elasticloadbalancingv2-loadbalancer.html
 */
export declare class CfnLoadBalancerLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly ALB_ACCESS_LOGS: CfnLoadBalancerAlbAccessLogs;
    static readonly ALB_CONNECTION_LOGS: CfnLoadBalancerAlbConnectionLogs;
    static readonly ALB_HEALTH_CHECK_LOGS: CfnLoadBalancerAlbHealthCheckLogs;
    static readonly NLB_ACCESS_LOGS: CfnLoadBalancerNlbAccessLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::ElasticLoadBalancingV2::LoadBalancer`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnLoadBalancer;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnLoadBalancerAlbAccessLogs.
 */
export declare class CfnLoadBalancerAlbAccessLogsOutputFormat {
}
export declare namespace CfnLoadBalancerAlbAccessLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnLoadBalancerAlbAccessLogsRecordFields {
    TYPE = "type",
    TIME = "time",
    ELB = "elb",
    CLIENT_PORT = "client_port",
    TARGET_PORT = "target_port",
    REQUEST_PROCESSING_TIME = "request_processing_time",
    TARGET_PROCESSING_TIME = "target_processing_time",
    RESPONSE_PROCESSING_TIME = "response_processing_time",
    ELB_STATUS_CODE = "elb_status_code",
    TARGET_STATUS_CODE = "target_status_code",
    RECEIVED_BYTES = "received_bytes",
    SENT_BYTES = "sent_bytes",
    REQUEST_LINE = "request_line",
    USER_AGENT = "user_agent",
    SSL_CIPHER = "ssl_cipher",
    SSL_PROTOCOL = "ssl_protocol",
    TARGET_GROUP_ARN = "target_group_arn",
    TRACE_ID = "trace_id",
    DOMAIN_NAME = "domain_name",
    CHOSEN_CERT_ARN = "chosen_cert_arn",
    MATCHED_RULE_PRIORITY = "matched_rule_priority",
    REQUEST_CREATION_TIME = "request_creation_time",
    ACTIONS_EXECUTED = "actions_executed",
    REDIRECT_URL = "redirect_url",
    ERROR_REASON = "error_reason",
    TARGET_PORT_LIST = "target_port_list",
    TARGET_STATUS_CODE_LIST = "target_status_code_list",
    CLASSIFICATION = "classification",
    CLASSIFICATION_REASON = "classification_reason",
    CONN_TRACE_ID = "conn_trace_id",
    TRANSFORMED_HOST = "transformed_host",
    TRANSFORMED_URI = "transformed_uri",
    REQUEST_TRANSFORM_STATUS = "request_transform_status",
    IP_ADDRESS = "ip_address"
}
export interface CfnLoadBalancerAlbAccessLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnLoadBalancerAlbAccessLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerAlbAccessLogsRecordFields>;
}
export interface CfnLoadBalancerAlbAccessLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnLoadBalancerAlbAccessLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerAlbAccessLogsRecordFields>;
}
export interface CfnLoadBalancerAlbAccessLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnLoadBalancerAlbAccessLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerAlbAccessLogsRecordFields>;
}
export interface CfnLoadBalancerAlbAccessLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerAlbAccessLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnLoadBalancerAlbConnectionLogs.
 */
export declare class CfnLoadBalancerAlbConnectionLogsOutputFormat {
}
export declare namespace CfnLoadBalancerAlbConnectionLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnLoadBalancerAlbConnectionLogsRecordFields {
    TIME = "time",
    CLIENT_IP = "client_ip",
    CLIENT_PORT = "client_port",
    LISTENER_PORT = "listener_port",
    TLS_PROTOCOL = "tls_protocol",
    TLS_CIPHER = "tls_cipher",
    TLS_HANDSHAKE_LATENCY = "tls_handshake_latency",
    LEAF_CLIENT_CERT_SUBJECT = "leaf_client_cert_subject",
    LEAF_CLIENT_CERT_VALIDITY = "leaf_client_cert_validity",
    LEAF_CLIENT_CERT_SERIAL_NUMBER = "leaf_client_cert_serial_number",
    TLS_VERIFY_STATUS = "tls_verify_status",
    CONN_TRACE_ID = "conn_trace_id",
    TLS_KEYEXCHANGE = "tls_keyexchange",
    ELB = "elb",
    IP_ADDRESS = "ip_address"
}
export interface CfnLoadBalancerAlbConnectionLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnLoadBalancerAlbConnectionLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerAlbConnectionLogsRecordFields>;
}
export interface CfnLoadBalancerAlbConnectionLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnLoadBalancerAlbConnectionLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerAlbConnectionLogsRecordFields>;
}
export interface CfnLoadBalancerAlbConnectionLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnLoadBalancerAlbConnectionLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerAlbConnectionLogsRecordFields>;
}
export interface CfnLoadBalancerAlbConnectionLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerAlbConnectionLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnLoadBalancerAlbHealthCheckLogs.
 */
export declare class CfnLoadBalancerAlbHealthCheckLogsOutputFormat {
}
export declare namespace CfnLoadBalancerAlbHealthCheckLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnLoadBalancerAlbHealthCheckLogsRecordFields {
    TYPE = "type",
    TIME = "time",
    LATENCY = "latency",
    TARGET_ADDR = "target_addr",
    TARGET_GROUP_ID = "target_group_id",
    STATUS = "status",
    STATUS_CODE = "status_code",
    REASON_CODE = "reason_code",
    ELB = "elb",
    IP_ADDRESS = "ip_address"
}
export interface CfnLoadBalancerAlbHealthCheckLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnLoadBalancerAlbHealthCheckLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerAlbHealthCheckLogsRecordFields>;
}
export interface CfnLoadBalancerAlbHealthCheckLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnLoadBalancerAlbHealthCheckLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerAlbHealthCheckLogsRecordFields>;
}
export interface CfnLoadBalancerAlbHealthCheckLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnLoadBalancerAlbHealthCheckLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerAlbHealthCheckLogsRecordFields>;
}
export interface CfnLoadBalancerAlbHealthCheckLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerAlbHealthCheckLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnLoadBalancerNlbAccessLogs.
 */
export declare class CfnLoadBalancerNlbAccessLogsOutputFormat {
}
export declare namespace CfnLoadBalancerNlbAccessLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnLoadBalancerNlbAccessLogsRecordFields {
    TYPE = "type",
    VERSION = "version",
    TIME = "time",
    ELB = "elb",
    LISTENER = "listener",
    CLIENT_PORT = "client_port",
    DESTINATION_PORT = "destination_port",
    CONNECTION_TIME = "connection_time",
    TLS_HANDSHAKE_TIME = "tls_handshake_time",
    RECEIVED_BYTES = "received_bytes",
    SENT_BYTES = "sent_bytes",
    INCOMING_TLS_ALERT = "incoming_tls_alert",
    CHOSEN_CERT_ARN = "chosen_cert_arn",
    CHOSEN_CERT_SERIAL = "chosen_cert_serial",
    TLS_CIPHER = "tls_cipher",
    TLS_PROTOCOL_VERSION = "tls_protocol_version",
    TLS_KEYEXCHANGE = "tls_keyexchange",
    DOMAIN_NAME = "domain_name",
    ALPN_FE_PROTOCOL = "alpn_fe_protocol",
    ALPN_BE_PROTOCOL = "alpn_be_protocol",
    ALPN_CLIENT_PREFERENCE_LIST = "alpn_client_preference_list",
    TLS_CONNECTION_CREATION_TIME = "tls_connection_creation_time"
}
export interface CfnLoadBalancerNlbAccessLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnLoadBalancerNlbAccessLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerNlbAccessLogsRecordFields>;
}
export interface CfnLoadBalancerNlbAccessLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnLoadBalancerNlbAccessLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerNlbAccessLogsRecordFields>;
}
export interface CfnLoadBalancerNlbAccessLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnLoadBalancerNlbAccessLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerNlbAccessLogsRecordFields>;
}
export interface CfnLoadBalancerNlbAccessLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLoadBalancerNlbAccessLogsRecordFields>;
}
