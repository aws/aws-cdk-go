import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.codedeploy@CodeDeployDeploymentStateChangeNotification
 */
export declare class CodeDeployDeploymentStateChangeNotification {
    /**
     * EventBridge event pattern for CodeDeploy Deployment State-change Notification
     */
    static codeDeployDeploymentStateChangeNotificationPattern(options?: CodeDeployDeploymentStateChangeNotification.CodeDeployDeploymentStateChangeNotificationProps): events.EventPattern;
}
export declare namespace CodeDeployDeploymentStateChangeNotification {
    /**
     * Props type for aws.codedeploy@CodeDeployDeploymentStateChangeNotification event
     */
    interface CodeDeployDeploymentStateChangeNotificationProps {
        /**
         * application property
         *
         * Specify an array of string values to match this event if the actual value of application is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly application?: Array<string>;
        /**
         * deploymentId property
         *
         * Specify an array of string values to match this event if the actual value of deploymentId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deploymentId?: Array<string>;
        /**
         * deploymentGroup property
         *
         * Specify an array of string values to match this event if the actual value of deploymentGroup is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deploymentGroup?: Array<string>;
        /**
         * instanceGroupId property
         *
         * Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceGroupId?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * region property
         *
         * Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly region?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.codedeploy@CodeDeployInstanceStateChangeNotification
 */
export declare class CodeDeployInstanceStateChangeNotification {
    /**
     * EventBridge event pattern for CodeDeploy Instance State-change Notification
     */
    static codeDeployInstanceStateChangeNotificationPattern(options?: CodeDeployInstanceStateChangeNotification.CodeDeployInstanceStateChangeNotificationProps): events.EventPattern;
}
export declare namespace CodeDeployInstanceStateChangeNotification {
    /**
     * Props type for aws.codedeploy@CodeDeployInstanceStateChangeNotification event
     */
    interface CodeDeployInstanceStateChangeNotificationProps {
        /**
         * instanceId property
         *
         * Specify an array of string values to match this event if the actual value of instanceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceId?: Array<string>;
        /**
         * application property
         *
         * Specify an array of string values to match this event if the actual value of application is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly application?: Array<string>;
        /**
         * deploymentId property
         *
         * Specify an array of string values to match this event if the actual value of deploymentId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deploymentId?: Array<string>;
        /**
         * deploymentGroup property
         *
         * Specify an array of string values to match this event if the actual value of deploymentGroup is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deploymentGroup?: Array<string>;
        /**
         * instanceGroupId property
         *
         * Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceGroupId?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * region property
         *
         * Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly region?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
