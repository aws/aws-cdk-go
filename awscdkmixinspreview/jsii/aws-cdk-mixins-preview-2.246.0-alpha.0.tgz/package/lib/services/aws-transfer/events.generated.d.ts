import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-transfer";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.transfer@FTPServerDirectoryCreateCompleted
 */
export declare class FTPServerDirectoryCreateCompleted {
    /**
     * EventBridge event pattern for FTP Server Directory Create Completed
     */
    static ftpServerDirectoryCreateCompletedPattern(options?: FTPServerDirectoryCreateCompleted.FTPServerDirectoryCreateCompletedProps): events.EventPattern;
}
export declare namespace FTPServerDirectoryCreateCompleted {
    /**
     * Props type for aws.transfer@FTPServerDirectoryCreateCompleted event
     */
    interface FTPServerDirectoryCreateCompletedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * directory-path property
         *
         * Specify an array of string values to match this event if the actual value of directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly directoryPath?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPServerDirectoryCreateFailed
 */
export declare class FTPServerDirectoryCreateFailed {
    /**
     * EventBridge event pattern for FTP Server Directory Create Failed
     */
    static ftpServerDirectoryCreateFailedPattern(options?: FTPServerDirectoryCreateFailed.FTPServerDirectoryCreateFailedProps): events.EventPattern;
}
export declare namespace FTPServerDirectoryCreateFailed {
    /**
     * Props type for aws.transfer@FTPServerDirectoryCreateFailed event
     */
    interface FTPServerDirectoryCreateFailedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * directory-path property
         *
         * Specify an array of string values to match this event if the actual value of directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly directoryPath?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPServerDirectoryDeleteCompleted
 */
export declare class FTPServerDirectoryDeleteCompleted {
    /**
     * EventBridge event pattern for FTP Server Directory Delete Completed
     */
    static ftpServerDirectoryDeleteCompletedPattern(options?: FTPServerDirectoryDeleteCompleted.FTPServerDirectoryDeleteCompletedProps): events.EventPattern;
}
export declare namespace FTPServerDirectoryDeleteCompleted {
    /**
     * Props type for aws.transfer@FTPServerDirectoryDeleteCompleted event
     */
    interface FTPServerDirectoryDeleteCompletedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * directory-path property
         *
         * Specify an array of string values to match this event if the actual value of directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly directoryPath?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPServerDirectoryDeleteFailed
 */
export declare class FTPServerDirectoryDeleteFailed {
    /**
     * EventBridge event pattern for FTP Server Directory Delete Failed
     */
    static ftpServerDirectoryDeleteFailedPattern(options?: FTPServerDirectoryDeleteFailed.FTPServerDirectoryDeleteFailedProps): events.EventPattern;
}
export declare namespace FTPServerDirectoryDeleteFailed {
    /**
     * Props type for aws.transfer@FTPServerDirectoryDeleteFailed event
     */
    interface FTPServerDirectoryDeleteFailedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * directory-path property
         *
         * Specify an array of string values to match this event if the actual value of directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly directoryPath?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPServerFileDeleteCompleted
 */
export declare class FTPServerFileDeleteCompleted {
    /**
     * EventBridge event pattern for FTP Server File Delete Completed
     */
    static ftpServerFileDeleteCompletedPattern(options?: FTPServerFileDeleteCompleted.FTPServerFileDeleteCompletedProps): events.EventPattern;
}
export declare namespace FTPServerFileDeleteCompleted {
    /**
     * Props type for aws.transfer@FTPServerFileDeleteCompleted event
     */
    interface FTPServerFileDeleteCompletedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPServerFileDeleteFailed
 */
export declare class FTPServerFileDeleteFailed {
    /**
     * EventBridge event pattern for FTP Server File Delete Failed
     */
    static ftpServerFileDeleteFailedPattern(options?: FTPServerFileDeleteFailed.FTPServerFileDeleteFailedProps): events.EventPattern;
}
export declare namespace FTPServerFileDeleteFailed {
    /**
     * Props type for aws.transfer@FTPServerFileDeleteFailed event
     */
    interface FTPServerFileDeleteFailedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPServerFileDownloadCompleted
 */
export declare class FTPServerFileDownloadCompleted {
    /**
     * EventBridge event pattern for FTP Server File Download Completed
     */
    static ftpServerFileDownloadCompletedPattern(options?: FTPServerFileDownloadCompleted.FTPServerFileDownloadCompletedProps): events.EventPattern;
}
export declare namespace FTPServerFileDownloadCompleted {
    /**
     * Props type for aws.transfer@FTPServerFileDownloadCompleted event
     */
    interface FTPServerFileDownloadCompletedProps {
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPServerFileDownloadFailed
 */
export declare class FTPServerFileDownloadFailed {
    /**
     * EventBridge event pattern for FTP Server File Download Failed
     */
    static ftpServerFileDownloadFailedPattern(options?: FTPServerFileDownloadFailed.FTPServerFileDownloadFailedProps): events.EventPattern;
}
export declare namespace FTPServerFileDownloadFailed {
    /**
     * Props type for aws.transfer@FTPServerFileDownloadFailed event
     */
    interface FTPServerFileDownloadFailedProps {
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPServerFileRenameCompleted
 */
export declare class FTPServerFileRenameCompleted {
    /**
     * EventBridge event pattern for FTP Server File Rename Completed
     */
    static ftpServerFileRenameCompletedPattern(options?: FTPServerFileRenameCompleted.FTPServerFileRenameCompletedProps): events.EventPattern;
}
export declare namespace FTPServerFileRenameCompleted {
    /**
     * Props type for aws.transfer@FTPServerFileRenameCompleted event
     */
    interface FTPServerFileRenameCompletedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * original-file-path property
         *
         * Specify an array of string values to match this event if the actual value of original-file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly originalFilePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * renamed-file-path property
         *
         * Specify an array of string values to match this event if the actual value of renamed-file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly renamedFilePath?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPServerFileRenameFailed
 */
export declare class FTPServerFileRenameFailed {
    /**
     * EventBridge event pattern for FTP Server File Rename Failed
     */
    static ftpServerFileRenameFailedPattern(options?: FTPServerFileRenameFailed.FTPServerFileRenameFailedProps): events.EventPattern;
}
export declare namespace FTPServerFileRenameFailed {
    /**
     * Props type for aws.transfer@FTPServerFileRenameFailed event
     */
    interface FTPServerFileRenameFailedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * original-file-path property
         *
         * Specify an array of string values to match this event if the actual value of original-file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly originalFilePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * renamed-file-path property
         *
         * Specify an array of string values to match this event if the actual value of renamed-file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly renamedFilePath?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPServerFileUploadCompleted
 */
export declare class FTPServerFileUploadCompleted {
    /**
     * EventBridge event pattern for FTP Server File Upload Completed
     */
    static ftpServerFileUploadCompletedPattern(options?: FTPServerFileUploadCompleted.FTPServerFileUploadCompletedProps): events.EventPattern;
}
export declare namespace FTPServerFileUploadCompleted {
    /**
     * Props type for aws.transfer@FTPServerFileUploadCompleted event
     */
    interface FTPServerFileUploadCompletedProps {
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPServerFileUploadFailed
 */
export declare class FTPServerFileUploadFailed {
    /**
     * EventBridge event pattern for FTP Server File Upload Failed
     */
    static ftpServerFileUploadFailedPattern(options?: FTPServerFileUploadFailed.FTPServerFileUploadFailedProps): events.EventPattern;
}
export declare namespace FTPServerFileUploadFailed {
    /**
     * Props type for aws.transfer@FTPServerFileUploadFailed event
     */
    interface FTPServerFileUploadFailedProps {
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPSServerDirectoryCreateCompleted
 */
export declare class FTPSServerDirectoryCreateCompleted {
    /**
     * EventBridge event pattern for FTPS Server Directory Create Completed
     */
    static ftpSServerDirectoryCreateCompletedPattern(options?: FTPSServerDirectoryCreateCompleted.FTPSServerDirectoryCreateCompletedProps): events.EventPattern;
}
export declare namespace FTPSServerDirectoryCreateCompleted {
    /**
     * Props type for aws.transfer@FTPSServerDirectoryCreateCompleted event
     */
    interface FTPSServerDirectoryCreateCompletedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * directory-path property
         *
         * Specify an array of string values to match this event if the actual value of directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly directoryPath?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPSServerDirectoryCreateFailed
 */
export declare class FTPSServerDirectoryCreateFailed {
    /**
     * EventBridge event pattern for FTPS Server Directory Create Failed
     */
    static ftpSServerDirectoryCreateFailedPattern(options?: FTPSServerDirectoryCreateFailed.FTPSServerDirectoryCreateFailedProps): events.EventPattern;
}
export declare namespace FTPSServerDirectoryCreateFailed {
    /**
     * Props type for aws.transfer@FTPSServerDirectoryCreateFailed event
     */
    interface FTPSServerDirectoryCreateFailedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * directory-path property
         *
         * Specify an array of string values to match this event if the actual value of directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly directoryPath?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPSServerDirectoryDeleteCompleted
 */
export declare class FTPSServerDirectoryDeleteCompleted {
    /**
     * EventBridge event pattern for FTPS Server Directory Delete Completed
     */
    static ftpSServerDirectoryDeleteCompletedPattern(options?: FTPSServerDirectoryDeleteCompleted.FTPSServerDirectoryDeleteCompletedProps): events.EventPattern;
}
export declare namespace FTPSServerDirectoryDeleteCompleted {
    /**
     * Props type for aws.transfer@FTPSServerDirectoryDeleteCompleted event
     */
    interface FTPSServerDirectoryDeleteCompletedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * directory-path property
         *
         * Specify an array of string values to match this event if the actual value of directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly directoryPath?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPSServerDirectoryDeleteFailed
 */
export declare class FTPSServerDirectoryDeleteFailed {
    /**
     * EventBridge event pattern for FTPS Server Directory Delete Failed
     */
    static ftpSServerDirectoryDeleteFailedPattern(options?: FTPSServerDirectoryDeleteFailed.FTPSServerDirectoryDeleteFailedProps): events.EventPattern;
}
export declare namespace FTPSServerDirectoryDeleteFailed {
    /**
     * Props type for aws.transfer@FTPSServerDirectoryDeleteFailed event
     */
    interface FTPSServerDirectoryDeleteFailedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * directory-path property
         *
         * Specify an array of string values to match this event if the actual value of directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly directoryPath?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPSServerFileDeleteCompleted
 */
export declare class FTPSServerFileDeleteCompleted {
    /**
     * EventBridge event pattern for FTPS Server File Delete Completed
     */
    static ftpSServerFileDeleteCompletedPattern(options?: FTPSServerFileDeleteCompleted.FTPSServerFileDeleteCompletedProps): events.EventPattern;
}
export declare namespace FTPSServerFileDeleteCompleted {
    /**
     * Props type for aws.transfer@FTPSServerFileDeleteCompleted event
     */
    interface FTPSServerFileDeleteCompletedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPSServerFileDeleteFailed
 */
export declare class FTPSServerFileDeleteFailed {
    /**
     * EventBridge event pattern for FTPS Server File Delete Failed
     */
    static ftpSServerFileDeleteFailedPattern(options?: FTPSServerFileDeleteFailed.FTPSServerFileDeleteFailedProps): events.EventPattern;
}
export declare namespace FTPSServerFileDeleteFailed {
    /**
     * Props type for aws.transfer@FTPSServerFileDeleteFailed event
     */
    interface FTPSServerFileDeleteFailedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPSServerFileDownloadCompleted
 */
export declare class FTPSServerFileDownloadCompleted {
    /**
     * EventBridge event pattern for FTPS Server File Download Completed
     */
    static ftpSServerFileDownloadCompletedPattern(options?: FTPSServerFileDownloadCompleted.FTPSServerFileDownloadCompletedProps): events.EventPattern;
}
export declare namespace FTPSServerFileDownloadCompleted {
    /**
     * Props type for aws.transfer@FTPSServerFileDownloadCompleted event
     */
    interface FTPSServerFileDownloadCompletedProps {
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPSServerFileDownloadFailed
 */
export declare class FTPSServerFileDownloadFailed {
    /**
     * EventBridge event pattern for FTPS Server File Download Failed
     */
    static ftpSServerFileDownloadFailedPattern(options?: FTPSServerFileDownloadFailed.FTPSServerFileDownloadFailedProps): events.EventPattern;
}
export declare namespace FTPSServerFileDownloadFailed {
    /**
     * Props type for aws.transfer@FTPSServerFileDownloadFailed event
     */
    interface FTPSServerFileDownloadFailedProps {
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPSServerFileRenameCompleted
 */
export declare class FTPSServerFileRenameCompleted {
    /**
     * EventBridge event pattern for FTPS Server File Rename Completed
     */
    static ftpSServerFileRenameCompletedPattern(options?: FTPSServerFileRenameCompleted.FTPSServerFileRenameCompletedProps): events.EventPattern;
}
export declare namespace FTPSServerFileRenameCompleted {
    /**
     * Props type for aws.transfer@FTPSServerFileRenameCompleted event
     */
    interface FTPSServerFileRenameCompletedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * original-file-path property
         *
         * Specify an array of string values to match this event if the actual value of original-file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly originalFilePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * renamed-file-path property
         *
         * Specify an array of string values to match this event if the actual value of renamed-file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly renamedFilePath?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPSServerFileRenameFailed
 */
export declare class FTPSServerFileRenameFailed {
    /**
     * EventBridge event pattern for FTPS Server File Rename Failed
     */
    static ftpSServerFileRenameFailedPattern(options?: FTPSServerFileRenameFailed.FTPSServerFileRenameFailedProps): events.EventPattern;
}
export declare namespace FTPSServerFileRenameFailed {
    /**
     * Props type for aws.transfer@FTPSServerFileRenameFailed event
     */
    interface FTPSServerFileRenameFailedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * original-file-path property
         *
         * Specify an array of string values to match this event if the actual value of original-file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly originalFilePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * renamed-file-path property
         *
         * Specify an array of string values to match this event if the actual value of renamed-file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly renamedFilePath?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPSServerFileUploadCompleted
 */
export declare class FTPSServerFileUploadCompleted {
    /**
     * EventBridge event pattern for FTPS Server File Upload Completed
     */
    static ftpSServerFileUploadCompletedPattern(options?: FTPSServerFileUploadCompleted.FTPSServerFileUploadCompletedProps): events.EventPattern;
}
export declare namespace FTPSServerFileUploadCompleted {
    /**
     * Props type for aws.transfer@FTPSServerFileUploadCompleted event
     */
    interface FTPSServerFileUploadCompletedProps {
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@FTPSServerFileUploadFailed
 */
export declare class FTPSServerFileUploadFailed {
    /**
     * EventBridge event pattern for FTPS Server File Upload Failed
     */
    static ftpSServerFileUploadFailedPattern(options?: FTPSServerFileUploadFailed.FTPSServerFileUploadFailedProps): events.EventPattern;
}
export declare namespace FTPSServerFileUploadFailed {
    /**
     * Props type for aws.transfer@FTPSServerFileUploadFailed event
     */
    interface FTPSServerFileUploadFailedProps {
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPServerDirectoryCreateCompleted
 */
export declare class SFTPServerDirectoryCreateCompleted {
    /**
     * EventBridge event pattern for SFTP Server Directory Create Completed
     */
    static sftPServerDirectoryCreateCompletedPattern(options?: SFTPServerDirectoryCreateCompleted.SFTPServerDirectoryCreateCompletedProps): events.EventPattern;
}
export declare namespace SFTPServerDirectoryCreateCompleted {
    /**
     * Props type for aws.transfer@SFTPServerDirectoryCreateCompleted event
     */
    interface SFTPServerDirectoryCreateCompletedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * directory-path property
         *
         * Specify an array of string values to match this event if the actual value of directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly directoryPath?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPServerDirectoryCreateFailed
 */
export declare class SFTPServerDirectoryCreateFailed {
    /**
     * EventBridge event pattern for SFTP Server Directory Create Failed
     */
    static sftPServerDirectoryCreateFailedPattern(options?: SFTPServerDirectoryCreateFailed.SFTPServerDirectoryCreateFailedProps): events.EventPattern;
}
export declare namespace SFTPServerDirectoryCreateFailed {
    /**
     * Props type for aws.transfer@SFTPServerDirectoryCreateFailed event
     */
    interface SFTPServerDirectoryCreateFailedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * directory-path property
         *
         * Specify an array of string values to match this event if the actual value of directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly directoryPath?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPServerDirectoryDeleteCompleted
 */
export declare class SFTPServerDirectoryDeleteCompleted {
    /**
     * EventBridge event pattern for SFTP Server Directory Delete Completed
     */
    static sftPServerDirectoryDeleteCompletedPattern(options?: SFTPServerDirectoryDeleteCompleted.SFTPServerDirectoryDeleteCompletedProps): events.EventPattern;
}
export declare namespace SFTPServerDirectoryDeleteCompleted {
    /**
     * Props type for aws.transfer@SFTPServerDirectoryDeleteCompleted event
     */
    interface SFTPServerDirectoryDeleteCompletedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * directory-path property
         *
         * Specify an array of string values to match this event if the actual value of directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly directoryPath?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPServerDirectoryDeleteFailed
 */
export declare class SFTPServerDirectoryDeleteFailed {
    /**
     * EventBridge event pattern for SFTP Server Directory Delete Failed
     */
    static sftPServerDirectoryDeleteFailedPattern(options?: SFTPServerDirectoryDeleteFailed.SFTPServerDirectoryDeleteFailedProps): events.EventPattern;
}
export declare namespace SFTPServerDirectoryDeleteFailed {
    /**
     * Props type for aws.transfer@SFTPServerDirectoryDeleteFailed event
     */
    interface SFTPServerDirectoryDeleteFailedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * directory-path property
         *
         * Specify an array of string values to match this event if the actual value of directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly directoryPath?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPServerFileDeleteCompleted
 */
export declare class SFTPServerFileDeleteCompleted {
    /**
     * EventBridge event pattern for SFTP Server File Delete Completed
     */
    static sftPServerFileDeleteCompletedPattern(options?: SFTPServerFileDeleteCompleted.SFTPServerFileDeleteCompletedProps): events.EventPattern;
}
export declare namespace SFTPServerFileDeleteCompleted {
    /**
     * Props type for aws.transfer@SFTPServerFileDeleteCompleted event
     */
    interface SFTPServerFileDeleteCompletedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPServerFileDeleteFailed
 */
export declare class SFTPServerFileDeleteFailed {
    /**
     * EventBridge event pattern for SFTP Server File Delete Failed
     */
    static sftPServerFileDeleteFailedPattern(options?: SFTPServerFileDeleteFailed.SFTPServerFileDeleteFailedProps): events.EventPattern;
}
export declare namespace SFTPServerFileDeleteFailed {
    /**
     * Props type for aws.transfer@SFTPServerFileDeleteFailed event
     */
    interface SFTPServerFileDeleteFailedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPServerFileDownloadCompleted
 */
export declare class SFTPServerFileDownloadCompleted {
    /**
     * EventBridge event pattern for SFTP Server File Download Completed
     */
    static sftPServerFileDownloadCompletedPattern(options?: SFTPServerFileDownloadCompleted.SFTPServerFileDownloadCompletedProps): events.EventPattern;
}
export declare namespace SFTPServerFileDownloadCompleted {
    /**
     * Props type for aws.transfer@SFTPServerFileDownloadCompleted event
     */
    interface SFTPServerFileDownloadCompletedProps {
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPServerFileDownloadFailed
 */
export declare class SFTPServerFileDownloadFailed {
    /**
     * EventBridge event pattern for SFTP Server File Download Failed
     */
    static sftPServerFileDownloadFailedPattern(options?: SFTPServerFileDownloadFailed.SFTPServerFileDownloadFailedProps): events.EventPattern;
}
export declare namespace SFTPServerFileDownloadFailed {
    /**
     * Props type for aws.transfer@SFTPServerFileDownloadFailed event
     */
    interface SFTPServerFileDownloadFailedProps {
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPServerFileRenameCompleted
 */
export declare class SFTPServerFileRenameCompleted {
    /**
     * EventBridge event pattern for SFTP Server File Rename Completed
     */
    static sftPServerFileRenameCompletedPattern(options?: SFTPServerFileRenameCompleted.SFTPServerFileRenameCompletedProps): events.EventPattern;
}
export declare namespace SFTPServerFileRenameCompleted {
    /**
     * Props type for aws.transfer@SFTPServerFileRenameCompleted event
     */
    interface SFTPServerFileRenameCompletedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * original-file-path property
         *
         * Specify an array of string values to match this event if the actual value of original-file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly originalFilePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * renamed-file-path property
         *
         * Specify an array of string values to match this event if the actual value of renamed-file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly renamedFilePath?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPServerFileRenameFailed
 */
export declare class SFTPServerFileRenameFailed {
    /**
     * EventBridge event pattern for SFTP Server File Rename Failed
     */
    static sftPServerFileRenameFailedPattern(options?: SFTPServerFileRenameFailed.SFTPServerFileRenameFailedProps): events.EventPattern;
}
export declare namespace SFTPServerFileRenameFailed {
    /**
     * Props type for aws.transfer@SFTPServerFileRenameFailed event
     */
    interface SFTPServerFileRenameFailedProps {
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * original-file-path property
         *
         * Specify an array of string values to match this event if the actual value of original-file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly originalFilePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * renamed-file-path property
         *
         * Specify an array of string values to match this event if the actual value of renamed-file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly renamedFilePath?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPServerFileUploadCompleted
 */
export declare class SFTPServerFileUploadCompleted {
    /**
     * EventBridge event pattern for SFTP Server File Upload Completed
     */
    static sftPServerFileUploadCompletedPattern(options?: SFTPServerFileUploadCompleted.SFTPServerFileUploadCompletedProps): events.EventPattern;
}
export declare namespace SFTPServerFileUploadCompleted {
    /**
     * Props type for aws.transfer@SFTPServerFileUploadCompleted event
     */
    interface SFTPServerFileUploadCompletedProps {
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPServerFileUploadFailed
 */
export declare class SFTPServerFileUploadFailed {
    /**
     * EventBridge event pattern for SFTP Server File Upload Failed
     */
    static sftPServerFileUploadFailedPattern(options?: SFTPServerFileUploadFailed.SFTPServerFileUploadFailedProps): events.EventPattern;
}
export declare namespace SFTPServerFileUploadFailed {
    /**
     * Props type for aws.transfer@SFTPServerFileUploadFailed event
     */
    interface SFTPServerFileUploadFailedProps {
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * etag property
         *
         * Specify an array of string values to match this event if the actual value of etag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly etag?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * session-id property
         *
         * Specify an array of string values to match this event if the actual value of session-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@AS2MDNSendCompleted
 */
export declare class AS2MDNSendCompleted {
    /**
     * EventBridge event pattern for AS2 MDN Send Completed
     */
    static as2MDNSendCompletedPattern(options?: AS2MDNSendCompleted.AS2MDNSendCompletedProps): events.EventPattern;
}
export declare namespace AS2MDNSendCompleted {
    /**
     * Props type for aws.transfer@AS2MDNSendCompleted event
     */
    interface AS2MDNSendCompletedProps {
        /**
         * s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Attributes?: AS2MDNSendCompleted.S3Attributes;
        /**
         * agreement-id property
         *
         * Specify an array of string values to match this event if the actual value of agreement-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Agreement reference
         */
        readonly agreementId?: Array<string>;
        /**
         * as2-from property
         *
         * Specify an array of string values to match this event if the actual value of as2-from is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2From?: Array<string>;
        /**
         * as2-message-id property
         *
         * Specify an array of string values to match this event if the actual value of as2-message-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2MessageId?: Array<string>;
        /**
         * as2-to property
         *
         * Specify an array of string values to match this event if the actual value of as2-to is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2To?: Array<string>;
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * disposition property
         *
         * Specify an array of string values to match this event if the actual value of disposition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly disposition?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * mdn-message-id property
         *
         * Specify an array of string values to match this event if the actual value of mdn-message-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnMessageId?: Array<string>;
        /**
         * mdn-subject property
         *
         * Specify an array of string values to match this event if the actual value of mdn-subject is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnSubject?: Array<string>;
        /**
         * mdn-type property
         *
         * Specify an array of string values to match this event if the actual value of mdn-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnType?: Array<string>;
        /**
         * message-subject property
         *
         * Specify an array of string values to match this event if the actual value of message-subject is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly messageSubject?: Array<string>;
        /**
         * request-path property
         *
         * Specify an array of string values to match this event if the actual value of request-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestPath?: Array<string>;
        /**
         * requester-file-name property
         *
         * Specify an array of string values to match this event if the actual value of requester-file-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requesterFileName?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for S3-attributes
     *
     * @struct
     */
    interface S3Attributes {
        /**
         * file-bucket property
         *
         * Specify an array of string values to match this event if the actual value of file-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileBucket?: Array<string>;
        /**
         * file-key property
         *
         * Specify an array of string values to match this event if the actual value of file-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileKey?: Array<string>;
        /**
         * json-bucket property
         *
         * Specify an array of string values to match this event if the actual value of json-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonBucket?: Array<string>;
        /**
         * json-key property
         *
         * Specify an array of string values to match this event if the actual value of json-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonKey?: Array<string>;
        /**
         * mdn-bucket property
         *
         * Specify an array of string values to match this event if the actual value of mdn-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnBucket?: Array<string>;
        /**
         * mdn-key property
         *
         * Specify an array of string values to match this event if the actual value of mdn-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnKey?: Array<string>;
    }
}
/**
 * EventBridge event patterns for Agreement
 */
export declare class AgreementEvents {
    /**
     * Create AgreementEvents from a Agreement reference
     */
    static fromAgreement(agreementRef: service.IAgreementRef): AgreementEvents;
    /**
     * Reference to the Agreement construct
     */
    private readonly agreementRef;
    private constructor();
    /**
     * EventBridge event pattern for Agreement AS2 MDN Send Completed
     */
    as2MDNSendCompletedPattern(options?: AS2MDNSendCompleted.AS2MDNSendCompletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Agreement AS2 MDN Send Failed
     */
    as2MDNSendFailedPattern(options?: AS2MDNSendFailed.AS2MDNSendFailedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Agreement AS2 Payload Receive Completed
     */
    as2PayloadReceiveCompletedPattern(options?: AS2PayloadReceiveCompleted.AS2PayloadReceiveCompletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Agreement AS2 Payload Receive Failed
     */
    as2PayloadReceiveFailedPattern(options?: AS2PayloadReceiveFailed.AS2PayloadReceiveFailedProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.transfer@AS2MDNSendFailed
 */
export declare class AS2MDNSendFailed {
    /**
     * EventBridge event pattern for AS2 MDN Send Failed
     */
    static as2MDNSendFailedPattern(options?: AS2MDNSendFailed.AS2MDNSendFailedProps): events.EventPattern;
}
export declare namespace AS2MDNSendFailed {
    /**
     * Props type for aws.transfer@AS2MDNSendFailed event
     */
    interface AS2MDNSendFailedProps {
        /**
         * s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Attributes?: AS2MDNSendFailed.S3Attributes;
        /**
         * agreement-id property
         *
         * Specify an array of string values to match this event if the actual value of agreement-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Agreement reference
         */
        readonly agreementId?: Array<string>;
        /**
         * as2-from property
         *
         * Specify an array of string values to match this event if the actual value of as2-from is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2From?: Array<string>;
        /**
         * as2-message-id property
         *
         * Specify an array of string values to match this event if the actual value of as2-message-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2MessageId?: Array<string>;
        /**
         * as2-to property
         *
         * Specify an array of string values to match this event if the actual value of as2-to is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2To?: Array<string>;
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * disposition property
         *
         * Specify an array of string values to match this event if the actual value of disposition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly disposition?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * mdn-message-id property
         *
         * Specify an array of string values to match this event if the actual value of mdn-message-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnMessageId?: Array<string>;
        /**
         * mdn-subject property
         *
         * Specify an array of string values to match this event if the actual value of mdn-subject is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnSubject?: Array<string>;
        /**
         * mdn-type property
         *
         * Specify an array of string values to match this event if the actual value of mdn-type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnType?: Array<string>;
        /**
         * requester-file-name property
         *
         * Specify an array of string values to match this event if the actual value of requester-file-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requesterFileName?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for S3-attributes
     *
     * @struct
     */
    interface S3Attributes {
        /**
         * file-bucket property
         *
         * Specify an array of string values to match this event if the actual value of file-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileBucket?: Array<string>;
        /**
         * file-key property
         *
         * Specify an array of string values to match this event if the actual value of file-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileKey?: Array<string>;
        /**
         * json-bucket property
         *
         * Specify an array of string values to match this event if the actual value of json-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonBucket?: Array<string>;
        /**
         * json-key property
         *
         * Specify an array of string values to match this event if the actual value of json-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonKey?: Array<string>;
        /**
         * mdn-bucket property
         *
         * Specify an array of string values to match this event if the actual value of mdn-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnBucket?: Array<string>;
        /**
         * mdn-key property
         *
         * Specify an array of string values to match this event if the actual value of mdn-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnKey?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.transfer@AS2PayloadReceiveCompleted
 */
export declare class AS2PayloadReceiveCompleted {
    /**
     * EventBridge event pattern for AS2 Payload Receive Completed
     */
    static as2PayloadReceiveCompletedPattern(options?: AS2PayloadReceiveCompleted.AS2PayloadReceiveCompletedProps): events.EventPattern;
}
export declare namespace AS2PayloadReceiveCompleted {
    /**
     * Props type for aws.transfer@AS2PayloadReceiveCompleted event
     */
    interface AS2PayloadReceiveCompletedProps {
        /**
         * s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Attributes?: AS2PayloadReceiveCompleted.S3Attributes;
        /**
         * agreement-id property
         *
         * Specify an array of string values to match this event if the actual value of agreement-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Agreement reference
         */
        readonly agreementId?: Array<string>;
        /**
         * as2-from property
         *
         * Specify an array of string values to match this event if the actual value of as2-from is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2From?: Array<string>;
        /**
         * as2-message-id property
         *
         * Specify an array of string values to match this event if the actual value of as2-message-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2MessageId?: Array<string>;
        /**
         * as2-to property
         *
         * Specify an array of string values to match this event if the actual value of as2-to is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2To?: Array<string>;
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * message-subject property
         *
         * Specify an array of string values to match this event if the actual value of message-subject is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly messageSubject?: Array<string>;
        /**
         * request-path property
         *
         * Specify an array of string values to match this event if the actual value of request-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestPath?: Array<string>;
        /**
         * requester-file-name property
         *
         * Specify an array of string values to match this event if the actual value of requester-file-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requesterFileName?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for S3-attributes
     *
     * @struct
     */
    interface S3Attributes {
        /**
         * file-bucket property
         *
         * Specify an array of string values to match this event if the actual value of file-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileBucket?: Array<string>;
        /**
         * file-key property
         *
         * Specify an array of string values to match this event if the actual value of file-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileKey?: Array<string>;
        /**
         * json-bucket property
         *
         * Specify an array of string values to match this event if the actual value of json-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonBucket?: Array<string>;
        /**
         * json-key property
         *
         * Specify an array of string values to match this event if the actual value of json-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonKey?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.transfer@AS2PayloadReceiveFailed
 */
export declare class AS2PayloadReceiveFailed {
    /**
     * EventBridge event pattern for AS2 Payload Receive Failed
     */
    static as2PayloadReceiveFailedPattern(options?: AS2PayloadReceiveFailed.AS2PayloadReceiveFailedProps): events.EventPattern;
}
export declare namespace AS2PayloadReceiveFailed {
    /**
     * Props type for aws.transfer@AS2PayloadReceiveFailed event
     */
    interface AS2PayloadReceiveFailedProps {
        /**
         * s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Attributes?: AS2PayloadReceiveFailed.S3Attributes;
        /**
         * agreement-id property
         *
         * Specify an array of string values to match this event if the actual value of agreement-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Agreement reference
         */
        readonly agreementId?: Array<string>;
        /**
         * as2-from property
         *
         * Specify an array of string values to match this event if the actual value of as2-from is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2From?: Array<string>;
        /**
         * as2-message-id property
         *
         * Specify an array of string values to match this event if the actual value of as2-message-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2MessageId?: Array<string>;
        /**
         * as2-to property
         *
         * Specify an array of string values to match this event if the actual value of as2-to is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2To?: Array<string>;
        /**
         * client-ip property
         *
         * Specify an array of string values to match this event if the actual value of client-ip is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly clientIp?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * message-subject property
         *
         * Specify an array of string values to match this event if the actual value of message-subject is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly messageSubject?: Array<string>;
        /**
         * server-id property
         *
         * Specify an array of string values to match this event if the actual value of server-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serverId?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for S3-attributes
     *
     * @struct
     */
    interface S3Attributes {
        /**
         * file-bucket property
         *
         * Specify an array of string values to match this event if the actual value of file-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileBucket?: Array<string>;
        /**
         * file-key property
         *
         * Specify an array of string values to match this event if the actual value of file-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileKey?: Array<string>;
        /**
         * json-bucket property
         *
         * Specify an array of string values to match this event if the actual value of json-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonBucket?: Array<string>;
        /**
         * json-key property
         *
         * Specify an array of string values to match this event if the actual value of json-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonKey?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.transfer@AS2MDNReceiveCompleted
 */
export declare class AS2MDNReceiveCompleted {
    /**
     * EventBridge event pattern for AS2 MDN Receive Completed
     */
    static as2MDNReceiveCompletedPattern(options?: AS2MDNReceiveCompleted.AS2MDNReceiveCompletedProps): events.EventPattern;
}
export declare namespace AS2MDNReceiveCompleted {
    /**
     * Props type for aws.transfer@AS2MDNReceiveCompleted event
     */
    interface AS2MDNReceiveCompletedProps {
        /**
         * s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Attributes?: AS2MDNReceiveCompleted.S3Attributes;
        /**
         * as2-from property
         *
         * Specify an array of string values to match this event if the actual value of as2-from is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2From?: Array<string>;
        /**
         * as2-message-id property
         *
         * Specify an array of string values to match this event if the actual value of as2-message-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2MessageId?: Array<string>;
        /**
         * as2-to property
         *
         * Specify an array of string values to match this event if the actual value of as2-to is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2To?: Array<string>;
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * disposition property
         *
         * Specify an array of string values to match this event if the actual value of disposition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly disposition?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * mdn-message-id property
         *
         * Specify an array of string values to match this event if the actual value of mdn-message-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnMessageId?: Array<string>;
        /**
         * mdn-subject property
         *
         * Specify an array of string values to match this event if the actual value of mdn-subject is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnSubject?: Array<string>;
        /**
         * message-subject property
         *
         * Specify an array of string values to match this event if the actual value of message-subject is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly messageSubject?: Array<string>;
        /**
         * requester-file-name property
         *
         * Specify an array of string values to match this event if the actual value of requester-file-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requesterFileName?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * transfer-id property
         *
         * Specify an array of string values to match this event if the actual value of transfer-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transferId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for S3-attributes
     *
     * @struct
     */
    interface S3Attributes {
        /**
         * file-bucket property
         *
         * Specify an array of string values to match this event if the actual value of file-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileBucket?: Array<string>;
        /**
         * file-key property
         *
         * Specify an array of string values to match this event if the actual value of file-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileKey?: Array<string>;
        /**
         * json-bucket property
         *
         * Specify an array of string values to match this event if the actual value of json-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonBucket?: Array<string>;
        /**
         * json-key property
         *
         * Specify an array of string values to match this event if the actual value of json-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonKey?: Array<string>;
        /**
         * mdn-bucket property
         *
         * Specify an array of string values to match this event if the actual value of mdn-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnBucket?: Array<string>;
        /**
         * mdn-key property
         *
         * Specify an array of string values to match this event if the actual value of mdn-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnKey?: Array<string>;
    }
}
/**
 * EventBridge event patterns for Connector
 */
export declare class ConnectorEvents {
    /**
     * Create ConnectorEvents from a Connector reference
     */
    static fromConnector(connectorRef: service.IConnectorRef): ConnectorEvents;
    /**
     * Reference to the Connector construct
     */
    private readonly connectorRef;
    private constructor();
    /**
     * EventBridge event pattern for Connector AS2 MDN Receive Completed
     */
    as2MDNReceiveCompletedPattern(options?: AS2MDNReceiveCompleted.AS2MDNReceiveCompletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Connector AS2 MDN Receive Failed
     */
    as2MDNReceiveFailedPattern(options?: AS2MDNReceiveFailed.AS2MDNReceiveFailedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Connector AS2 Payload Send Completed
     */
    as2PayloadSendCompletedPattern(options?: AS2PayloadSendCompleted.AS2PayloadSendCompletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Connector AS2 Payload Send Failed
     */
    as2PayloadSendFailedPattern(options?: AS2PayloadSendFailed.AS2PayloadSendFailedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Connector SFTP Connector Directory Listing Completed
     */
    sftPConnectorDirectoryListingCompletedPattern(options?: SFTPConnectorDirectoryListingCompleted.SFTPConnectorDirectoryListingCompletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Connector SFTP Connector Directory Listing Failed
     */
    sftPConnectorDirectoryListingFailedPattern(options?: SFTPConnectorDirectoryListingFailed.SFTPConnectorDirectoryListingFailedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Connector SFTP Connector File Retrieve Completed
     */
    sftPConnectorFileRetrieveCompletedPattern(options?: SFTPConnectorFileRetrieveCompleted.SFTPConnectorFileRetrieveCompletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Connector SFTP Connector File Retrieve Failed
     */
    sftPConnectorFileRetrieveFailedPattern(options?: SFTPConnectorFileRetrieveFailed.SFTPConnectorFileRetrieveFailedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Connector SFTP Connector File Send Completed
     */
    sftPConnectorFileSendCompletedPattern(options?: SFTPConnectorFileSendCompleted.SFTPConnectorFileSendCompletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Connector SFTP Connector File Send Failed
     */
    sftPConnectorFileSendFailedPattern(options?: SFTPConnectorFileSendFailed.SFTPConnectorFileSendFailedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Connector SFTP Connector Remote Delete Completed
     */
    sftPConnectorRemoteDeleteCompletedPattern(options?: SFTPConnectorRemoteDeleteCompleted.SFTPConnectorRemoteDeleteCompletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Connector SFTP Connector Remote Delete Failed
     */
    sftPConnectorRemoteDeleteFailedPattern(options?: SFTPConnectorRemoteDeleteFailed.SFTPConnectorRemoteDeleteFailedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Connector SFTP Connector Remote Move Completed
     */
    sftPConnectorRemoteMoveCompletedPattern(options?: SFTPConnectorRemoteMoveCompleted.SFTPConnectorRemoteMoveCompletedProps): events.EventPattern;
    /**
     * EventBridge event pattern for Connector SFTP Connector Remote Move Failed
     */
    sftPConnectorRemoteMoveFailedPattern(options?: SFTPConnectorRemoteMoveFailed.SFTPConnectorRemoteMoveFailedProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.transfer@AS2MDNReceiveFailed
 */
export declare class AS2MDNReceiveFailed {
    /**
     * EventBridge event pattern for AS2 MDN Receive Failed
     */
    static as2MDNReceiveFailedPattern(options?: AS2MDNReceiveFailed.AS2MDNReceiveFailedProps): events.EventPattern;
}
export declare namespace AS2MDNReceiveFailed {
    /**
     * Props type for aws.transfer@AS2MDNReceiveFailed event
     */
    interface AS2MDNReceiveFailedProps {
        /**
         * s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Attributes?: AS2MDNReceiveFailed.S3Attributes;
        /**
         * as2-from property
         *
         * Specify an array of string values to match this event if the actual value of as2-from is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2From?: Array<string>;
        /**
         * as2-message-id property
         *
         * Specify an array of string values to match this event if the actual value of as2-message-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2MessageId?: Array<string>;
        /**
         * as2-to property
         *
         * Specify an array of string values to match this event if the actual value of as2-to is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2To?: Array<string>;
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * mdn-message-id property
         *
         * Specify an array of string values to match this event if the actual value of mdn-message-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnMessageId?: Array<string>;
        /**
         * mdn-subject property
         *
         * Specify an array of string values to match this event if the actual value of mdn-subject is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnSubject?: Array<string>;
        /**
         * message-subject property
         *
         * Specify an array of string values to match this event if the actual value of message-subject is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly messageSubject?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * transfer-id property
         *
         * Specify an array of string values to match this event if the actual value of transfer-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transferId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for S3-attributes
     *
     * @struct
     */
    interface S3Attributes {
        /**
         * file-bucket property
         *
         * Specify an array of string values to match this event if the actual value of file-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileBucket?: Array<string>;
        /**
         * file-key property
         *
         * Specify an array of string values to match this event if the actual value of file-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileKey?: Array<string>;
        /**
         * json-bucket property
         *
         * Specify an array of string values to match this event if the actual value of json-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonBucket?: Array<string>;
        /**
         * json-key property
         *
         * Specify an array of string values to match this event if the actual value of json-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonKey?: Array<string>;
        /**
         * mdn-bucket property
         *
         * Specify an array of string values to match this event if the actual value of mdn-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnBucket?: Array<string>;
        /**
         * mdn-key property
         *
         * Specify an array of string values to match this event if the actual value of mdn-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnKey?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.transfer@AS2PayloadSendCompleted
 */
export declare class AS2PayloadSendCompleted {
    /**
     * EventBridge event pattern for AS2 Payload Send Completed
     */
    static as2PayloadSendCompletedPattern(options?: AS2PayloadSendCompleted.AS2PayloadSendCompletedProps): events.EventPattern;
}
export declare namespace AS2PayloadSendCompleted {
    /**
     * Props type for aws.transfer@AS2PayloadSendCompleted event
     */
    interface AS2PayloadSendCompletedProps {
        /**
         * s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Attributes?: AS2PayloadSendCompleted.S3Attributes;
        /**
         * as2-from property
         *
         * Specify an array of string values to match this event if the actual value of as2-from is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2From?: Array<string>;
        /**
         * as2-message-id property
         *
         * Specify an array of string values to match this event if the actual value of as2-message-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2MessageId?: Array<string>;
        /**
         * as2-to property
         *
         * Specify an array of string values to match this event if the actual value of as2-to is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2To?: Array<string>;
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * mdn-subject property
         *
         * Specify an array of string values to match this event if the actual value of mdn-subject is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnSubject?: Array<string>;
        /**
         * message-subject property
         *
         * Specify an array of string values to match this event if the actual value of message-subject is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly messageSubject?: Array<string>;
        /**
         * requester-file-name property
         *
         * Specify an array of string values to match this event if the actual value of requester-file-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requesterFileName?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * transfer-id property
         *
         * Specify an array of string values to match this event if the actual value of transfer-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transferId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for S3-attributes
     *
     * @struct
     */
    interface S3Attributes {
        /**
         * file-bucket property
         *
         * Specify an array of string values to match this event if the actual value of file-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileBucket?: Array<string>;
        /**
         * file-key property
         *
         * Specify an array of string values to match this event if the actual value of file-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileKey?: Array<string>;
        /**
         * mdn-bucket property
         *
         * Specify an array of string values to match this event if the actual value of mdn-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnBucket?: Array<string>;
        /**
         * mdn-key property
         *
         * Specify an array of string values to match this event if the actual value of mdn-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mdnKey?: Array<string>;
        /**
         * json-bucket property
         *
         * Specify an array of string values to match this event if the actual value of json-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonBucket?: Array<string>;
        /**
         * json-key property
         *
         * Specify an array of string values to match this event if the actual value of json-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonKey?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.transfer@AS2PayloadSendFailed
 */
export declare class AS2PayloadSendFailed {
    /**
     * EventBridge event pattern for AS2 Payload Send Failed
     */
    static as2PayloadSendFailedPattern(options?: AS2PayloadSendFailed.AS2PayloadSendFailedProps): events.EventPattern;
}
export declare namespace AS2PayloadSendFailed {
    /**
     * Props type for aws.transfer@AS2PayloadSendFailed event
     */
    interface AS2PayloadSendFailedProps {
        /**
         * s3-attributes property
         *
         * Specify an array of string values to match this event if the actual value of s3-attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Attributes?: AS2PayloadSendFailed.S3Attributes;
        /**
         * as2-from property
         *
         * Specify an array of string values to match this event if the actual value of as2-from is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2From?: Array<string>;
        /**
         * as2-message-id property
         *
         * Specify an array of string values to match this event if the actual value of as2-message-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2MessageId?: Array<string>;
        /**
         * as2-to property
         *
         * Specify an array of string values to match this event if the actual value of as2-to is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly as2To?: Array<string>;
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * message-subject property
         *
         * Specify an array of string values to match this event if the actual value of message-subject is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly messageSubject?: Array<string>;
        /**
         * requester-file-name property
         *
         * Specify an array of string values to match this event if the actual value of requester-file-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requesterFileName?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * transfer-id property
         *
         * Specify an array of string values to match this event if the actual value of transfer-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transferId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for S3-attributes
     *
     * @struct
     */
    interface S3Attributes {
        /**
         * file-bucket property
         *
         * Specify an array of string values to match this event if the actual value of file-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileBucket?: Array<string>;
        /**
         * file-key property
         *
         * Specify an array of string values to match this event if the actual value of file-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileKey?: Array<string>;
        /**
         * json-bucket property
         *
         * Specify an array of string values to match this event if the actual value of json-bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonBucket?: Array<string>;
        /**
         * json-key property
         *
         * Specify an array of string values to match this event if the actual value of json-key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jsonKey?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPConnectorDirectoryListingCompleted
 */
export declare class SFTPConnectorDirectoryListingCompleted {
    /**
     * EventBridge event pattern for SFTP Connector Directory Listing Completed
     */
    static sftPConnectorDirectoryListingCompletedPattern(options?: SFTPConnectorDirectoryListingCompleted.SFTPConnectorDirectoryListingCompletedProps): events.EventPattern;
}
export declare namespace SFTPConnectorDirectoryListingCompleted {
    /**
     * Props type for aws.transfer@SFTPConnectorDirectoryListingCompleted event
     */
    interface SFTPConnectorDirectoryListingCompletedProps {
        /**
         * output-file-location property
         *
         * Specify an array of string values to match this event if the actual value of output-file-location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputFileLocation?: SFTPConnectorDirectoryListingCompleted.OutputFileLocation;
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * item-count property
         *
         * Specify an array of string values to match this event if the actual value of item-count is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly itemCount?: Array<string>;
        /**
         * listing-id property
         *
         * Specify an array of string values to match this event if the actual value of listing-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly listingId?: Array<string>;
        /**
         * max-items property
         *
         * Specify an array of string values to match this event if the actual value of max-items is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxItems?: Array<string>;
        /**
         * output-directory-path property
         *
         * Specify an array of string values to match this event if the actual value of output-directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputDirectoryPath?: Array<string>;
        /**
         * remote-directory-path property
         *
         * Specify an array of string values to match this event if the actual value of remote-directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly remoteDirectoryPath?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * truncated property
         *
         * Specify an array of string values to match this event if the actual value of truncated is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly truncated?: Array<string>;
        /**
         * url property
         *
         * Specify an array of string values to match this event if the actual value of url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly url?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Output-file-location
     *
     * @struct
     */
    interface OutputFileLocation {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: Array<string>;
        /**
         * domain property
         *
         * Specify an array of string values to match this event if the actual value of domain is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly domain?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPConnectorDirectoryListingFailed
 */
export declare class SFTPConnectorDirectoryListingFailed {
    /**
     * EventBridge event pattern for SFTP Connector Directory Listing Failed
     */
    static sftPConnectorDirectoryListingFailedPattern(options?: SFTPConnectorDirectoryListingFailed.SFTPConnectorDirectoryListingFailedProps): events.EventPattern;
}
export declare namespace SFTPConnectorDirectoryListingFailed {
    /**
     * Props type for aws.transfer@SFTPConnectorDirectoryListingFailed event
     */
    interface SFTPConnectorDirectoryListingFailedProps {
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * listing-id property
         *
         * Specify an array of string values to match this event if the actual value of listing-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly listingId?: Array<string>;
        /**
         * max-items property
         *
         * Specify an array of string values to match this event if the actual value of max-items is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxItems?: Array<string>;
        /**
         * output-directory-path property
         *
         * Specify an array of string values to match this event if the actual value of output-directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputDirectoryPath?: Array<string>;
        /**
         * remote-directory-path property
         *
         * Specify an array of string values to match this event if the actual value of remote-directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly remoteDirectoryPath?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * url property
         *
         * Specify an array of string values to match this event if the actual value of url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly url?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPConnectorFileRetrieveCompleted
 */
export declare class SFTPConnectorFileRetrieveCompleted {
    /**
     * EventBridge event pattern for SFTP Connector File Retrieve Completed
     */
    static sftPConnectorFileRetrieveCompletedPattern(options?: SFTPConnectorFileRetrieveCompleted.SFTPConnectorFileRetrieveCompletedProps): events.EventPattern;
}
export declare namespace SFTPConnectorFileRetrieveCompleted {
    /**
     * Props type for aws.transfer@SFTPConnectorFileRetrieveCompleted event
     */
    interface SFTPConnectorFileRetrieveCompletedProps {
        /**
         * local-file-location property
         *
         * Specify an array of string values to match this event if the actual value of local-file-location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly localFileLocation?: SFTPConnectorFileRetrieveCompleted.LocalFileLocation;
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * file-transfer-id property
         *
         * Specify an array of string values to match this event if the actual value of file-transfer-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileTransferId?: Array<string>;
        /**
         * local-directory-path property
         *
         * Specify an array of string values to match this event if the actual value of local-directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly localDirectoryPath?: Array<string>;
        /**
         * operation property
         *
         * Specify an array of string values to match this event if the actual value of operation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly operation?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * transfer-id property
         *
         * Specify an array of string values to match this event if the actual value of transfer-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transferId?: Array<string>;
        /**
         * url property
         *
         * Specify an array of string values to match this event if the actual value of url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly url?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Local-file-location
     *
     * @struct
     */
    interface LocalFileLocation {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: Array<string>;
        /**
         * domain property
         *
         * Specify an array of string values to match this event if the actual value of domain is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly domain?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPConnectorFileRetrieveFailed
 */
export declare class SFTPConnectorFileRetrieveFailed {
    /**
     * EventBridge event pattern for SFTP Connector File Retrieve Failed
     */
    static sftPConnectorFileRetrieveFailedPattern(options?: SFTPConnectorFileRetrieveFailed.SFTPConnectorFileRetrieveFailedProps): events.EventPattern;
}
export declare namespace SFTPConnectorFileRetrieveFailed {
    /**
     * Props type for aws.transfer@SFTPConnectorFileRetrieveFailed event
     */
    interface SFTPConnectorFileRetrieveFailedProps {
        /**
         * local-file-location property
         *
         * Specify an array of string values to match this event if the actual value of local-file-location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly localFileLocation?: SFTPConnectorFileRetrieveFailed.LocalFileLocation;
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * file-transfer-id property
         *
         * Specify an array of string values to match this event if the actual value of file-transfer-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileTransferId?: Array<string>;
        /**
         * local-directory-path property
         *
         * Specify an array of string values to match this event if the actual value of local-directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly localDirectoryPath?: Array<string>;
        /**
         * operation property
         *
         * Specify an array of string values to match this event if the actual value of operation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly operation?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * transfer-id property
         *
         * Specify an array of string values to match this event if the actual value of transfer-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transferId?: Array<string>;
        /**
         * url property
         *
         * Specify an array of string values to match this event if the actual value of url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly url?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Local-file-location
     *
     * @struct
     */
    interface LocalFileLocation {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: Array<string>;
        /**
         * domain property
         *
         * Specify an array of string values to match this event if the actual value of domain is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly domain?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPConnectorFileSendCompleted
 */
export declare class SFTPConnectorFileSendCompleted {
    /**
     * EventBridge event pattern for SFTP Connector File Send Completed
     */
    static sftPConnectorFileSendCompletedPattern(options?: SFTPConnectorFileSendCompleted.SFTPConnectorFileSendCompletedProps): events.EventPattern;
}
export declare namespace SFTPConnectorFileSendCompleted {
    /**
     * Props type for aws.transfer@SFTPConnectorFileSendCompleted event
     */
    interface SFTPConnectorFileSendCompletedProps {
        /**
         * local-file-location property
         *
         * Specify an array of string values to match this event if the actual value of local-file-location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly localFileLocation?: SFTPConnectorFileSendCompleted.LocalFileLocation;
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * file-transfer-id property
         *
         * Specify an array of string values to match this event if the actual value of file-transfer-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileTransferId?: Array<string>;
        /**
         * operation property
         *
         * Specify an array of string values to match this event if the actual value of operation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly operation?: Array<string>;
        /**
         * remote-directory-path property
         *
         * Specify an array of string values to match this event if the actual value of remote-directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly remoteDirectoryPath?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * transfer-id property
         *
         * Specify an array of string values to match this event if the actual value of transfer-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transferId?: Array<string>;
        /**
         * url property
         *
         * Specify an array of string values to match this event if the actual value of url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly url?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Local-file-location
     *
     * @struct
     */
    interface LocalFileLocation {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: Array<string>;
        /**
         * domain property
         *
         * Specify an array of string values to match this event if the actual value of domain is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly domain?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPConnectorFileSendFailed
 */
export declare class SFTPConnectorFileSendFailed {
    /**
     * EventBridge event pattern for SFTP Connector File Send Failed
     */
    static sftPConnectorFileSendFailedPattern(options?: SFTPConnectorFileSendFailed.SFTPConnectorFileSendFailedProps): events.EventPattern;
}
export declare namespace SFTPConnectorFileSendFailed {
    /**
     * Props type for aws.transfer@SFTPConnectorFileSendFailed event
     */
    interface SFTPConnectorFileSendFailedProps {
        /**
         * local-file-location property
         *
         * Specify an array of string values to match this event if the actual value of local-file-location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly localFileLocation?: SFTPConnectorFileSendFailed.LocalFileLocation;
        /**
         * bytes property
         *
         * Specify an array of string values to match this event if the actual value of bytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bytes?: Array<string>;
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * file-path property
         *
         * Specify an array of string values to match this event if the actual value of file-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * file-transfer-id property
         *
         * Specify an array of string values to match this event if the actual value of file-transfer-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileTransferId?: Array<string>;
        /**
         * operation property
         *
         * Specify an array of string values to match this event if the actual value of operation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly operation?: Array<string>;
        /**
         * remote-directory-path property
         *
         * Specify an array of string values to match this event if the actual value of remote-directory-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly remoteDirectoryPath?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * transfer-id property
         *
         * Specify an array of string values to match this event if the actual value of transfer-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly transferId?: Array<string>;
        /**
         * url property
         *
         * Specify an array of string values to match this event if the actual value of url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly url?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Local-file-location
     *
     * @struct
     */
    interface LocalFileLocation {
        /**
         * bucket property
         *
         * Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucket?: Array<string>;
        /**
         * domain property
         *
         * Specify an array of string values to match this event if the actual value of domain is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly domain?: Array<string>;
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPConnectorRemoteDeleteCompleted
 */
export declare class SFTPConnectorRemoteDeleteCompleted {
    /**
     * EventBridge event pattern for SFTP Connector Remote Delete Completed
     */
    static sftPConnectorRemoteDeleteCompletedPattern(options?: SFTPConnectorRemoteDeleteCompleted.SFTPConnectorRemoteDeleteCompletedProps): events.EventPattern;
}
export declare namespace SFTPConnectorRemoteDeleteCompleted {
    /**
     * Props type for aws.transfer@SFTPConnectorRemoteDeleteCompleted event
     */
    interface SFTPConnectorRemoteDeleteCompletedProps {
        /**
         * delete-id property
         *
         * Specify an array of string values to match this event if the actual value of delete-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deleteId?: Array<string>;
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * operation property
         *
         * Specify an array of string values to match this event if the actual value of operation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly operation?: Array<string>;
        /**
         * delete-path property
         *
         * Specify an array of string values to match this event if the actual value of delete-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deletePath?: Array<string>;
        /**
         * url property
         *
         * Specify an array of string values to match this event if the actual value of url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly url?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPConnectorRemoteDeleteFailed
 */
export declare class SFTPConnectorRemoteDeleteFailed {
    /**
     * EventBridge event pattern for SFTP Connector Remote Delete Failed
     */
    static sftPConnectorRemoteDeleteFailedPattern(options?: SFTPConnectorRemoteDeleteFailed.SFTPConnectorRemoteDeleteFailedProps): events.EventPattern;
}
export declare namespace SFTPConnectorRemoteDeleteFailed {
    /**
     * Props type for aws.transfer@SFTPConnectorRemoteDeleteFailed event
     */
    interface SFTPConnectorRemoteDeleteFailedProps {
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * operation property
         *
         * Specify an array of string values to match this event if the actual value of operation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly operation?: Array<string>;
        /**
         * delete-path property
         *
         * Specify an array of string values to match this event if the actual value of delete-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deletePath?: Array<string>;
        /**
         * delete-id property
         *
         * Specify an array of string values to match this event if the actual value of delete-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deleteId?: Array<string>;
        /**
         * url property
         *
         * Specify an array of string values to match this event if the actual value of url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly url?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPConnectorRemoteMoveCompleted
 */
export declare class SFTPConnectorRemoteMoveCompleted {
    /**
     * EventBridge event pattern for SFTP Connector Remote Move Completed
     */
    static sftPConnectorRemoteMoveCompletedPattern(options?: SFTPConnectorRemoteMoveCompleted.SFTPConnectorRemoteMoveCompletedProps): events.EventPattern;
}
export declare namespace SFTPConnectorRemoteMoveCompleted {
    /**
     * Props type for aws.transfer@SFTPConnectorRemoteMoveCompleted event
     */
    interface SFTPConnectorRemoteMoveCompletedProps {
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * move-source-path property
         *
         * Specify an array of string values to match this event if the actual value of move-source-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly moveSourcePath?: Array<string>;
        /**
         * move-target-path property
         *
         * Specify an array of string values to match this event if the actual value of move-target-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly moveTargetPath?: Array<string>;
        /**
         * operation property
         *
         * Specify an array of string values to match this event if the actual value of operation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly operation?: Array<string>;
        /**
         * move-id property
         *
         * Specify an array of string values to match this event if the actual value of move-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly moveId?: Array<string>;
        /**
         * url property
         *
         * Specify an array of string values to match this event if the actual value of url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly url?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.transfer@SFTPConnectorRemoteMoveFailed
 */
export declare class SFTPConnectorRemoteMoveFailed {
    /**
     * EventBridge event pattern for SFTP Connector Remote Move Failed
     */
    static sftPConnectorRemoteMoveFailedPattern(options?: SFTPConnectorRemoteMoveFailed.SFTPConnectorRemoteMoveFailedProps): events.EventPattern;
}
export declare namespace SFTPConnectorRemoteMoveFailed {
    /**
     * Props type for aws.transfer@SFTPConnectorRemoteMoveFailed event
     */
    interface SFTPConnectorRemoteMoveFailedProps {
        /**
         * connector-id property
         *
         * Specify an array of string values to match this event if the actual value of connector-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Connector reference
         */
        readonly connectorId?: Array<string>;
        /**
         * end-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly endTimestamp?: Array<string>;
        /**
         * move-source-path property
         *
         * Specify an array of string values to match this event if the actual value of move-source-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly moveSourcePath?: Array<string>;
        /**
         * move-target-path property
         *
         * Specify an array of string values to match this event if the actual value of move-target-path is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly moveTargetPath?: Array<string>;
        /**
         * operation property
         *
         * Specify an array of string values to match this event if the actual value of operation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly operation?: Array<string>;
        /**
         * move-id property
         *
         * Specify an array of string values to match this event if the actual value of move-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly moveId?: Array<string>;
        /**
         * url property
         *
         * Specify an array of string values to match this event if the actual value of url is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly url?: Array<string>;
        /**
         * start-timestamp property
         *
         * Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startTimestamp?: Array<string>;
        /**
         * status-code property
         *
         * Specify an array of string values to match this event if the actual value of status-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * failure-code property
         *
         * Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureCode?: Array<string>;
        /**
         * failure-message property
         *
         * Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureMessage?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
