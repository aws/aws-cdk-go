import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-guardduty";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.guardduty@GuardDutyMalwareProtectionObjectScanResult
 */
export declare class GuardDutyMalwareProtectionObjectScanResult {
    /**
     * EventBridge event pattern for GuardDuty Malware Protection Object Scan Result
     */
    static guardDutyMalwareProtectionObjectScanResultPattern(options?: GuardDutyMalwareProtectionObjectScanResult.GuardDutyMalwareProtectionObjectScanResultProps): events.EventPattern;
}
export declare namespace GuardDutyMalwareProtectionObjectScanResult {
    /**
     * Props type for aws.guardduty@GuardDutyMalwareProtectionObjectScanResult event
     */
    interface GuardDutyMalwareProtectionObjectScanResultProps {
        /**
         * schemaVersion property
         *
         * Specify an array of string values to match this event if the actual value of schemaVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly schemaVersion?: Array<string>;
        /**
         * scanStatus property
         *
         * Specify an array of string values to match this event if the actual value of scanStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scanStatus?: Array<string>;
        /**
         * resourceType property
         *
         * Specify an array of string values to match this event if the actual value of resourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceType?: Array<string>;
        /**
         * s3ObjectDetails property
         *
         * Specify an array of string values to match this event if the actual value of s3ObjectDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3ObjectDetails?: GuardDutyMalwareProtectionObjectScanResult.S3ObjectDetails;
        /**
         * scanResultDetails property
         *
         * Specify an array of string values to match this event if the actual value of scanResultDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scanResultDetails?: GuardDutyMalwareProtectionObjectScanResult.ScanResultDetails;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for S3ObjectDetails
     *
     * @struct
     */
    interface S3ObjectDetails {
        /**
         * bucketName property
         *
         * Specify an array of string values to match this event if the actual value of bucketName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucketName?: Array<string>;
        /**
         * objectKey property
         *
         * Specify an array of string values to match this event if the actual value of objectKey is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectKey?: Array<string>;
        /**
         * eTag property
         *
         * Specify an array of string values to match this event if the actual value of eTag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eTag?: Array<string>;
        /**
         * versionId property
         *
         * Specify an array of string values to match this event if the actual value of versionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
        /**
         * s3Throttled property
         *
         * Specify an array of string values to match this event if the actual value of s3Throttled is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Throttled?: Array<string>;
    }
    /**
     * Type definition for ScanResultDetails
     *
     * @struct
     */
    interface ScanResultDetails {
        /**
         * scanResultStatus property
         *
         * Specify an array of string values to match this event if the actual value of scanResultStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scanResultStatus?: Array<string>;
        /**
         * threats property
         *
         * Specify an array of string values to match this event if the actual value of threats is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threats?: Array<GuardDutyMalwareProtectionObjectScanResult.Threat>;
    }
    /**
     * Type definition for Threat
     *
     * @struct
     */
    interface Threat {
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.guardduty@GuardDutyMalwareProtectionPostScanActionFailed
 */
export declare class GuardDutyMalwareProtectionPostScanActionFailed {
    /**
     * EventBridge event pattern for GuardDuty Malware Protection Post Scan Action Failed
     */
    static guardDutyMalwareProtectionPostScanActionFailedPattern(options?: GuardDutyMalwareProtectionPostScanActionFailed.GuardDutyMalwareProtectionPostScanActionFailedProps): events.EventPattern;
}
export declare namespace GuardDutyMalwareProtectionPostScanActionFailed {
    /**
     * Props type for aws.guardduty@GuardDutyMalwareProtectionPostScanActionFailed event
     */
    interface GuardDutyMalwareProtectionPostScanActionFailedProps {
        /**
         * schemaVersion property
         *
         * Specify an array of string values to match this event if the actual value of schemaVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly schemaVersion?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * s3ObjectDetails property
         *
         * Specify an array of string values to match this event if the actual value of s3ObjectDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3ObjectDetails?: GuardDutyMalwareProtectionPostScanActionFailed.S3ObjectDetails;
        /**
         * postScanActions property
         *
         * Specify an array of string values to match this event if the actual value of postScanActions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly postScanActions?: Array<GuardDutyMalwareProtectionPostScanActionFailed.PostScanAction>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for S3ObjectDetails
     *
     * @struct
     */
    interface S3ObjectDetails {
        /**
         * bucketName property
         *
         * Specify an array of string values to match this event if the actual value of bucketName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucketName?: Array<string>;
        /**
         * objectKey property
         *
         * Specify an array of string values to match this event if the actual value of objectKey is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly objectKey?: Array<string>;
        /**
         * eTag property
         *
         * Specify an array of string values to match this event if the actual value of eTag is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eTag?: Array<string>;
        /**
         * versionId property
         *
         * Specify an array of string values to match this event if the actual value of versionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly versionId?: Array<string>;
    }
    /**
     * Type definition for PostScanAction
     *
     * @struct
     */
    interface PostScanAction {
        /**
         * actionType property
         *
         * Specify an array of string values to match this event if the actual value of actionType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionType?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * failureReason property
         *
         * Specify an array of string values to match this event if the actual value of failureReason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly failureReason?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.guardduty@GuardDutyMalwareProtectionResourceStatusActive
 */
export declare class GuardDutyMalwareProtectionResourceStatusActive {
    /**
     * EventBridge event pattern for GuardDuty Malware Protection Resource Status Active
     */
    static guardDutyMalwareProtectionResourceStatusActivePattern(options?: GuardDutyMalwareProtectionResourceStatusActive.GuardDutyMalwareProtectionResourceStatusActiveProps): events.EventPattern;
}
export declare namespace GuardDutyMalwareProtectionResourceStatusActive {
    /**
     * Props type for aws.guardduty@GuardDutyMalwareProtectionResourceStatusActive event
     */
    interface GuardDutyMalwareProtectionResourceStatusActiveProps {
        /**
         * schemaVersion property
         *
         * Specify an array of string values to match this event if the actual value of schemaVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly schemaVersion?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * s3BucketDetails property
         *
         * Specify an array of string values to match this event if the actual value of s3BucketDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3BucketDetails?: GuardDutyMalwareProtectionResourceStatusActive.S3BucketDetails;
        /**
         * resourceStatus property
         *
         * Specify an array of string values to match this event if the actual value of resourceStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceStatus?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for S3BucketDetails
     *
     * @struct
     */
    interface S3BucketDetails {
        /**
         * bucketName property
         *
         * Specify an array of string values to match this event if the actual value of bucketName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucketName?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.guardduty@GuardDutyMalwareProtectionResourceStatusError
 */
export declare class GuardDutyMalwareProtectionResourceStatusError {
    /**
     * EventBridge event pattern for GuardDuty Malware Protection Resource Status Error
     */
    static guardDutyMalwareProtectionResourceStatusErrorPattern(options?: GuardDutyMalwareProtectionResourceStatusError.GuardDutyMalwareProtectionResourceStatusErrorProps): events.EventPattern;
}
export declare namespace GuardDutyMalwareProtectionResourceStatusError {
    /**
     * Props type for aws.guardduty@GuardDutyMalwareProtectionResourceStatusError event
     */
    interface GuardDutyMalwareProtectionResourceStatusErrorProps {
        /**
         * schemaVersion property
         *
         * Specify an array of string values to match this event if the actual value of schemaVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly schemaVersion?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * s3BucketDetails property
         *
         * Specify an array of string values to match this event if the actual value of s3BucketDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3BucketDetails?: GuardDutyMalwareProtectionResourceStatusError.S3BucketDetails;
        /**
         * resourceStatus property
         *
         * Specify an array of string values to match this event if the actual value of resourceStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceStatus?: Array<string>;
        /**
         * statusReasons property
         *
         * Specify an array of string values to match this event if the actual value of statusReasons is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusReasons?: Array<GuardDutyMalwareProtectionResourceStatusError.StatusReason>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for S3BucketDetails
     *
     * @struct
     */
    interface S3BucketDetails {
        /**
         * bucketName property
         *
         * Specify an array of string values to match this event if the actual value of bucketName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucketName?: Array<string>;
    }
    /**
     * Type definition for StatusReason
     *
     * @struct
     */
    interface StatusReason {
        /**
         * code property
         *
         * Specify an array of string values to match this event if the actual value of code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly code?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.guardduty@GuardDutyMalwareProtectionResourceStatusWarning
 */
export declare class GuardDutyMalwareProtectionResourceStatusWarning {
    /**
     * EventBridge event pattern for GuardDuty Malware Protection Resource Status Warning
     */
    static guardDutyMalwareProtectionResourceStatusWarningPattern(options?: GuardDutyMalwareProtectionResourceStatusWarning.GuardDutyMalwareProtectionResourceStatusWarningProps): events.EventPattern;
}
export declare namespace GuardDutyMalwareProtectionResourceStatusWarning {
    /**
     * Props type for aws.guardduty@GuardDutyMalwareProtectionResourceStatusWarning event
     */
    interface GuardDutyMalwareProtectionResourceStatusWarningProps {
        /**
         * schemaVersion property
         *
         * Specify an array of string values to match this event if the actual value of schemaVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly schemaVersion?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * s3BucketDetails property
         *
         * Specify an array of string values to match this event if the actual value of s3BucketDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3BucketDetails?: GuardDutyMalwareProtectionResourceStatusWarning.S3BucketDetails;
        /**
         * resourceStatus property
         *
         * Specify an array of string values to match this event if the actual value of resourceStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceStatus?: Array<string>;
        /**
         * statusReasons property
         *
         * Specify an array of string values to match this event if the actual value of statusReasons is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusReasons?: Array<GuardDutyMalwareProtectionResourceStatusWarning.StatusReason>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for S3BucketDetails
     *
     * @struct
     */
    interface S3BucketDetails {
        /**
         * bucketName property
         *
         * Specify an array of string values to match this event if the actual value of bucketName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucketName?: Array<string>;
    }
    /**
     * Type definition for StatusReason
     *
     * @struct
     */
    interface StatusReason {
        /**
         * code property
         *
         * Specify an array of string values to match this event if the actual value of code is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly code?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.guardduty@GuardDutyFinding
 */
export declare class GuardDutyFinding {
    /**
     * EventBridge event pattern for GuardDuty Finding
     */
    static guardDutyFindingPattern(options?: GuardDutyFinding.GuardDutyFindingProps): events.EventPattern;
}
export declare namespace GuardDutyFinding {
    /**
     * Props type for aws.guardduty@GuardDutyFinding event
     */
    interface GuardDutyFindingProps {
        /**
         * resource property
         *
         * Specify an array of string values to match this event if the actual value of resource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resource?: GuardDutyFinding.Resource;
        /**
         * service property
         *
         * Specify an array of string values to match this event if the actual value of service is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly service?: GuardDutyFinding.Service;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * createdAt property
         *
         * Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createdAt?: Array<string>;
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * partition property
         *
         * Specify an array of string values to match this event if the actual value of partition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly partition?: Array<string>;
        /**
         * region property
         *
         * Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly region?: Array<string>;
        /**
         * schemaVersion property
         *
         * Specify an array of string values to match this event if the actual value of schemaVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly schemaVersion?: Array<string>;
        /**
         * severity property
         *
         * Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly severity?: Array<string>;
        /**
         * title property
         *
         * Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly title?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * updatedAt property
         *
         * Specify an array of string values to match this event if the actual value of updatedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly updatedAt?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Resource
     *
     * @struct
     */
    interface Resource {
        /**
         * accessKeyDetails property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyDetails?: GuardDutyFinding.AccessKeyDetails;
        /**
         * containerDetails property
         *
         * Specify an array of string values to match this event if the actual value of containerDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containerDetails?: GuardDutyFinding.ContainerDetails;
        /**
         * ebsVolumeDetails property
         *
         * Specify an array of string values to match this event if the actual value of ebsVolumeDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ebsVolumeDetails?: GuardDutyFinding.EbsVolumeDetails;
        /**
         * ecsClusterDetails property
         *
         * Specify an array of string values to match this event if the actual value of ecsClusterDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ecsClusterDetails?: GuardDutyFinding.EcsClusterDetails;
        /**
         * eksClusterDetails property
         *
         * Specify an array of string values to match this event if the actual value of eksClusterDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eksClusterDetails?: GuardDutyFinding.EksClusterDetails;
        /**
         * instanceDetails property
         *
         * Specify an array of string values to match this event if the actual value of instanceDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceDetails?: GuardDutyFinding.InstanceDetails;
        /**
         * kubernetesDetails property
         *
         * Specify an array of string values to match this event if the actual value of kubernetesDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly kubernetesDetails?: GuardDutyFinding.KubernetesDetails;
        /**
         * resourceType property
         *
         * Specify an array of string values to match this event if the actual value of resourceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceType?: Array<string>;
        /**
         * s3BucketDetails property
         *
         * Specify an array of string values to match this event if the actual value of s3BucketDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3BucketDetails?: Array<GuardDutyFinding.ResourceItem>;
    }
    /**
     * Type definition for AccessKeyDetails
     *
     * @struct
     */
    interface AccessKeyDetails {
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * userName property
         *
         * Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userName?: Array<string>;
        /**
         * userType property
         *
         * Specify an array of string values to match this event if the actual value of userType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userType?: Array<string>;
    }
    /**
     * Type definition for ContainerDetails
     *
     * @struct
     */
    interface ContainerDetails {
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
        /**
         * image property
         *
         * Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly image?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for EbsVolumeDetails
     *
     * @struct
     */
    interface EbsVolumeDetails {
        /**
         * scannedVolumeDetails property
         *
         * Specify an array of string values to match this event if the actual value of scannedVolumeDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scannedVolumeDetails?: Array<GuardDutyFinding.EbsVolumeDetailsItem>;
        /**
         * skippedVolumeDetails property
         *
         * Specify an array of string values to match this event if the actual value of skippedVolumeDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly skippedVolumeDetails?: Array<string>;
    }
    /**
     * Type definition for EbsVolumeDetailsItem
     *
     * @struct
     */
    interface EbsVolumeDetailsItem {
        /**
         * deviceName property
         *
         * Specify an array of string values to match this event if the actual value of deviceName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deviceName?: Array<string>;
        /**
         * encryptionType property
         *
         * Specify an array of string values to match this event if the actual value of encryptionType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly encryptionType?: Array<string>;
        /**
         * kmsKeyArn property
         *
         * Specify an array of string values to match this event if the actual value of kmsKeyArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly kmsKeyArn?: Array<string>;
        /**
         * snapshotArn property
         *
         * Specify an array of string values to match this event if the actual value of snapshotArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly snapshotArn?: Array<string>;
        /**
         * volumeArn property
         *
         * Specify an array of string values to match this event if the actual value of volumeArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly volumeArn?: Array<string>;
        /**
         * volumeSizeInGB property
         *
         * Specify an array of string values to match this event if the actual value of volumeSizeInGB is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly volumeSizeInGb?: Array<string>;
        /**
         * volumeType property
         *
         * Specify an array of string values to match this event if the actual value of volumeType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly volumeType?: Array<string>;
    }
    /**
     * Type definition for EcsClusterDetails
     *
     * @struct
     */
    interface EcsClusterDetails {
        /**
         * taskDetails property
         *
         * Specify an array of string values to match this event if the actual value of taskDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly taskDetails?: GuardDutyFinding.TaskDetails;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<GuardDutyFinding.EcsClusterDetailsItem>;
    }
    /**
     * Type definition for TaskDetails
     *
     * @struct
     */
    interface TaskDetails {
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * containers property
         *
         * Specify an array of string values to match this event if the actual value of containers is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containers?: Array<GuardDutyFinding.TaskDetailsItem>;
        /**
         * createdAt property
         *
         * Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createdAt?: Array<string>;
        /**
         * definitionArn property
         *
         * Specify an array of string values to match this event if the actual value of definitionArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly definitionArn?: Array<string>;
        /**
         * startedAt property
         *
         * Specify an array of string values to match this event if the actual value of startedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startedAt?: Array<string>;
        /**
         * startedBy property
         *
         * Specify an array of string values to match this event if the actual value of startedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startedBy?: Array<string>;
        /**
         * version property
         *
         * Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly version?: Array<string>;
    }
    /**
     * Type definition for TaskDetailsItem
     *
     * @struct
     */
    interface TaskDetailsItem {
        /**
         * image property
         *
         * Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly image?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for EcsClusterDetailsItem
     *
     * @struct
     */
    interface EcsClusterDetailsItem {
        /**
         * key property
         *
         * Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly key?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for EksClusterDetails
     *
     * @struct
     */
    interface EksClusterDetails {
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * createdAt property
         *
         * Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createdAt?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<GuardDutyFinding.EcsClusterDetailsItem>;
        /**
         * vpcId property
         *
         * Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcId?: Array<string>;
    }
    /**
     * Type definition for InstanceDetails
     *
     * @struct
     */
    interface InstanceDetails {
        /**
         * iamInstanceProfile property
         *
         * Specify an array of string values to match this event if the actual value of iamInstanceProfile is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly iamInstanceProfile?: GuardDutyFinding.IamInstanceProfile;
        /**
         * availabilityZone property
         *
         * Specify an array of string values to match this event if the actual value of availabilityZone is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly availabilityZone?: Array<string>;
        /**
         * imageDescription property
         *
         * Specify an array of string values to match this event if the actual value of imageDescription is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageDescription?: Array<string>;
        /**
         * imageId property
         *
         * Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imageId?: Array<string>;
        /**
         * instanceId property
         *
         * Specify an array of string values to match this event if the actual value of instanceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceId?: Array<string>;
        /**
         * instanceState property
         *
         * Specify an array of string values to match this event if the actual value of instanceState is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceState?: Array<string>;
        /**
         * instanceType property
         *
         * Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly instanceType?: Array<string>;
        /**
         * launchTime property
         *
         * Specify an array of string values to match this event if the actual value of launchTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly launchTime?: Array<string>;
        /**
         * networkInterfaces property
         *
         * Specify an array of string values to match this event if the actual value of networkInterfaces is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterfaces?: Array<GuardDutyFinding.InstanceDetailsItem>;
        /**
         * outpostArn property
         *
         * Specify an array of string values to match this event if the actual value of outpostArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outpostArn?: Array<string>;
        /**
         * platform property
         *
         * Specify an array of string values to match this event if the actual value of platform is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly platform?: Array<string>;
        /**
         * productCodes property
         *
         * Specify an array of string values to match this event if the actual value of productCodes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly productCodes?: Array<GuardDutyFinding.InstanceDetailsItem1>;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<GuardDutyFinding.EcsClusterDetailsItem>;
    }
    /**
     * Type definition for IamInstanceProfile
     *
     * @struct
     */
    interface IamInstanceProfile {
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
    }
    /**
     * Type definition for InstanceDetailsItem
     *
     * @struct
     */
    interface InstanceDetailsItem {
        /**
         * ipv6Addresses property
         *
         * Specify an array of string values to match this event if the actual value of ipv6Addresses is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipv6Addresses?: Array<any>;
        /**
         * networkInterfaceId property
         *
         * Specify an array of string values to match this event if the actual value of networkInterfaceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkInterfaceId?: Array<string>;
        /**
         * privateDnsName property
         *
         * Specify an array of string values to match this event if the actual value of privateDnsName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateDnsName?: Array<string>;
        /**
         * privateIpAddress property
         *
         * Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateIpAddress?: Array<string>;
        /**
         * privateIpAddresses property
         *
         * Specify an array of string values to match this event if the actual value of privateIpAddresses is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateIpAddresses?: Array<GuardDutyFinding.InstanceDetailsItemItem>;
        /**
         * publicDnsName property
         *
         * Specify an array of string values to match this event if the actual value of publicDnsName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly publicDnsName?: Array<string>;
        /**
         * publicIp property
         *
         * Specify an array of string values to match this event if the actual value of publicIp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly publicIp?: Array<string>;
        /**
         * securityGroups property
         *
         * Specify an array of string values to match this event if the actual value of securityGroups is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly securityGroups?: Array<GuardDutyFinding.InstanceDetailsItemItem1>;
        /**
         * subnetId property
         *
         * Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly subnetId?: Array<string>;
        /**
         * vpcId property
         *
         * Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly vpcId?: Array<string>;
    }
    /**
     * Type definition for InstanceDetailsItemItem
     *
     * @struct
     */
    interface InstanceDetailsItemItem {
        /**
         * privateDnsName property
         *
         * Specify an array of string values to match this event if the actual value of privateDnsName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateDnsName?: Array<string>;
        /**
         * privateIpAddress property
         *
         * Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privateIpAddress?: Array<string>;
    }
    /**
     * Type definition for InstanceDetailsItemItem_1
     *
     * @struct
     */
    interface InstanceDetailsItemItem1 {
        /**
         * groupId property
         *
         * Specify an array of string values to match this event if the actual value of groupId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupId?: Array<string>;
        /**
         * groupName property
         *
         * Specify an array of string values to match this event if the actual value of groupName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groupName?: Array<string>;
    }
    /**
     * Type definition for InstanceDetailsItem_1
     *
     * @struct
     */
    interface InstanceDetailsItem1 {
        /**
         * productCodeId property
         *
         * Specify an array of string values to match this event if the actual value of productCodeId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly productCodeId?: Array<string>;
        /**
         * productCodeType property
         *
         * Specify an array of string values to match this event if the actual value of productCodeType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly productCodeType?: Array<string>;
    }
    /**
     * Type definition for KubernetesDetails
     *
     * @struct
     */
    interface KubernetesDetails {
        /**
         * kubernetesUserDetails property
         *
         * Specify an array of string values to match this event if the actual value of kubernetesUserDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly kubernetesUserDetails?: GuardDutyFinding.KubernetesUserDetails;
        /**
         * kubernetesWorkloadDetails property
         *
         * Specify an array of string values to match this event if the actual value of kubernetesWorkloadDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly kubernetesWorkloadDetails?: GuardDutyFinding.KubernetesWorkloadDetails;
    }
    /**
     * Type definition for KubernetesUserDetails
     *
     * @struct
     */
    interface KubernetesUserDetails {
        /**
         * groups property
         *
         * Specify an array of string values to match this event if the actual value of groups is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly groups?: Array<string>;
        /**
         * uid property
         *
         * Specify an array of string values to match this event if the actual value of uid is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly uid?: Array<string>;
        /**
         * username property
         *
         * Specify an array of string values to match this event if the actual value of username is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly username?: Array<string>;
    }
    /**
     * Type definition for KubernetesWorkloadDetails
     *
     * @struct
     */
    interface KubernetesWorkloadDetails {
        /**
         * containers property
         *
         * Specify an array of string values to match this event if the actual value of containers is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly containers?: Array<GuardDutyFinding.KubernetesWorkloadDetailsItem>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * namespace property
         *
         * Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly namespace?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * uid property
         *
         * Specify an array of string values to match this event if the actual value of uid is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly uid?: Array<string>;
    }
    /**
     * Type definition for KubernetesWorkloadDetailsItem
     *
     * @struct
     */
    interface KubernetesWorkloadDetailsItem {
        /**
         * securityContext property
         *
         * Specify an array of string values to match this event if the actual value of securityContext is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly securityContext?: GuardDutyFinding.SecurityContext;
        /**
         * image property
         *
         * Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly image?: Array<string>;
        /**
         * imagePrefix property
         *
         * Specify an array of string values to match this event if the actual value of imagePrefix is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly imagePrefix?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for SecurityContext
     *
     * @struct
     */
    interface SecurityContext {
        /**
         * privileged property
         *
         * Specify an array of string values to match this event if the actual value of privileged is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly privileged?: Array<string>;
    }
    /**
     * Type definition for ResourceItem
     *
     * @struct
     */
    interface ResourceItem {
        /**
         * defaultServerSideEncryption property
         *
         * Specify an array of string values to match this event if the actual value of defaultServerSideEncryption is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly defaultServerSideEncryption?: GuardDutyFinding.DefaultServerSideEncryption;
        /**
         * owner property
         *
         * Specify an array of string values to match this event if the actual value of owner is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly owner?: GuardDutyFinding.Owner;
        /**
         * publicAccess property
         *
         * Specify an array of string values to match this event if the actual value of publicAccess is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly publicAccess?: GuardDutyFinding.PublicAccess;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * createdAt property
         *
         * Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly createdAt?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * tags property
         *
         * Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tags?: Array<GuardDutyFinding.EcsClusterDetailsItem>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
    }
    /**
     * Type definition for DefaultServerSideEncryption
     *
     * @struct
     */
    interface DefaultServerSideEncryption {
        /**
         * encryptionType property
         *
         * Specify an array of string values to match this event if the actual value of encryptionType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly encryptionType?: Array<string>;
        /**
         * kmsMasterKeyArn property
         *
         * Specify an array of string values to match this event if the actual value of kmsMasterKeyArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly kmsMasterKeyArn?: Array<string>;
    }
    /**
     * Type definition for Owner
     *
     * @struct
     */
    interface Owner {
        /**
         * id property
         *
         * Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly id?: Array<string>;
    }
    /**
     * Type definition for PublicAccess
     *
     * @struct
     */
    interface PublicAccess {
        /**
         * permissionConfiguration property
         *
         * Specify an array of string values to match this event if the actual value of permissionConfiguration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly permissionConfiguration?: GuardDutyFinding.PermissionConfiguration;
        /**
         * effectivePermission property
         *
         * Specify an array of string values to match this event if the actual value of effectivePermission is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly effectivePermission?: Array<string>;
    }
    /**
     * Type definition for PermissionConfiguration
     *
     * @struct
     */
    interface PermissionConfiguration {
        /**
         * accountLevelPermissions property
         *
         * Specify an array of string values to match this event if the actual value of accountLevelPermissions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountLevelPermissions?: GuardDutyFinding.AccountLevelPermissions;
        /**
         * bucketLevelPermissions property
         *
         * Specify an array of string values to match this event if the actual value of bucketLevelPermissions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucketLevelPermissions?: GuardDutyFinding.BucketLevelPermissions;
    }
    /**
     * Type definition for AccountLevelPermissions
     *
     * @struct
     */
    interface AccountLevelPermissions {
        /**
         * blockPublicAccess property
         *
         * Specify an array of string values to match this event if the actual value of blockPublicAccess is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly blockPublicAccess?: GuardDutyFinding.BlockPublicAccess;
    }
    /**
     * Type definition for BlockPublicAccess
     *
     * @struct
     */
    interface BlockPublicAccess {
        /**
         * blockPublicAcls property
         *
         * Specify an array of string values to match this event if the actual value of blockPublicAcls is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly blockPublicAcls?: Array<string>;
        /**
         * blockPublicPolicy property
         *
         * Specify an array of string values to match this event if the actual value of blockPublicPolicy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly blockPublicPolicy?: Array<string>;
        /**
         * ignorePublicAcls property
         *
         * Specify an array of string values to match this event if the actual value of ignorePublicAcls is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ignorePublicAcls?: Array<string>;
        /**
         * restrictPublicBuckets property
         *
         * Specify an array of string values to match this event if the actual value of restrictPublicBuckets is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly restrictPublicBuckets?: Array<string>;
    }
    /**
     * Type definition for BucketLevelPermissions
     *
     * @struct
     */
    interface BucketLevelPermissions {
        /**
         * accessControlList property
         *
         * Specify an array of string values to match this event if the actual value of accessControlList is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessControlList?: GuardDutyFinding.AccessControlList;
        /**
         * blockPublicAccess property
         *
         * Specify an array of string values to match this event if the actual value of blockPublicAccess is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly blockPublicAccess?: GuardDutyFinding.BlockPublicAccess;
        /**
         * bucketPolicy property
         *
         * Specify an array of string values to match this event if the actual value of bucketPolicy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly bucketPolicy?: GuardDutyFinding.AccessControlList;
    }
    /**
     * Type definition for AccessControlList
     *
     * @struct
     */
    interface AccessControlList {
        /**
         * allowsPublicReadAccess property
         *
         * Specify an array of string values to match this event if the actual value of allowsPublicReadAccess is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly allowsPublicReadAccess?: Array<string>;
        /**
         * allowsPublicWriteAccess property
         *
         * Specify an array of string values to match this event if the actual value of allowsPublicWriteAccess is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly allowsPublicWriteAccess?: Array<string>;
    }
    /**
     * Type definition for Service
     *
     * @struct
     */
    interface Service {
        /**
         * action property
         *
         * Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly action?: GuardDutyFinding.Action;
        /**
         * additionalInfo property
         *
         * Specify an array of string values to match this event if the actual value of additionalInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly additionalInfo?: GuardDutyFinding.AdditionalInfo;
        /**
         * awsApiCallAction property
         *
         * Specify an array of string values to match this event if the actual value of awsApiCallAction is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsApiCallAction?: GuardDutyFinding.AwsApiCallAction;
        /**
         * ebsVolumeScanDetails property
         *
         * Specify an array of string values to match this event if the actual value of ebsVolumeScanDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ebsVolumeScanDetails?: GuardDutyFinding.EbsVolumeScanDetails;
        /**
         * evidence property
         *
         * Specify an array of string values to match this event if the actual value of evidence is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly evidence?: GuardDutyFinding.Evidence;
        /**
         * archived property
         *
         * Specify an array of string values to match this event if the actual value of archived is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly archived?: Array<string>;
        /**
         * count property
         *
         * Specify an array of string values to match this event if the actual value of count is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly count?: Array<string>;
        /**
         * detectorId property
         *
         * Specify an array of string values to match this event if the actual value of detectorId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Detector reference
         */
        readonly detectorId?: Array<string>;
        /**
         * eventFirstSeen property
         *
         * Specify an array of string values to match this event if the actual value of eventFirstSeen is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventFirstSeen?: Array<string>;
        /**
         * eventLastSeen property
         *
         * Specify an array of string values to match this event if the actual value of eventLastSeen is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventLastSeen?: Array<string>;
        /**
         * featureName property
         *
         * Specify an array of string values to match this event if the actual value of featureName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly featureName?: Array<string>;
        /**
         * resourceRole property
         *
         * Specify an array of string values to match this event if the actual value of resourceRole is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resourceRole?: Array<string>;
        /**
         * serviceName property
         *
         * Specify an array of string values to match this event if the actual value of serviceName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serviceName?: Array<string>;
    }
    /**
     * Type definition for Action
     *
     * @struct
     */
    interface Action {
        /**
         * awsApiCallAction property
         *
         * Specify an array of string values to match this event if the actual value of awsApiCallAction is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsApiCallAction?: GuardDutyFinding.AwsApiCallAction1;
        /**
         * dnsRequestAction property
         *
         * Specify an array of string values to match this event if the actual value of dnsRequestAction is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dnsRequestAction?: GuardDutyFinding.DnsRequestAction;
        /**
         * kubernetesApiCallAction property
         *
         * Specify an array of string values to match this event if the actual value of kubernetesApiCallAction is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly kubernetesApiCallAction?: GuardDutyFinding.KubernetesApiCallAction;
        /**
         * networkConnectionAction property
         *
         * Specify an array of string values to match this event if the actual value of networkConnectionAction is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly networkConnectionAction?: GuardDutyFinding.NetworkConnectionAction;
        /**
         * portProbeAction property
         *
         * Specify an array of string values to match this event if the actual value of portProbeAction is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly portProbeAction?: GuardDutyFinding.PortProbeAction;
        /**
         * actionType property
         *
         * Specify an array of string values to match this event if the actual value of actionType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly actionType?: Array<string>;
    }
    /**
     * Type definition for AwsApiCallAction_1
     *
     * @struct
     */
    interface AwsApiCallAction1 {
        /**
         * affectedResources property
         *
         * Specify an array of string values to match this event if the actual value of affectedResources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly affectedResources?: GuardDutyFinding.AffectedResources1;
        /**
         * remoteAccountDetails property
         *
         * Specify an array of string values to match this event if the actual value of remoteAccountDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly remoteAccountDetails?: GuardDutyFinding.RemoteAccountDetails;
        /**
         * remoteIpDetails property
         *
         * Specify an array of string values to match this event if the actual value of remoteIpDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly remoteIpDetails?: GuardDutyFinding.RemoteIpDetails1;
        /**
         * api property
         *
         * Specify an array of string values to match this event if the actual value of api is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly api?: Array<string>;
        /**
         * callerType property
         *
         * Specify an array of string values to match this event if the actual value of callerType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly callerType?: Array<string>;
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * serviceName property
         *
         * Specify an array of string values to match this event if the actual value of serviceName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serviceName?: Array<string>;
    }
    /**
     * Type definition for AffectedResources_1
     *
     * @struct
     */
    interface AffectedResources1 {
        /**
         * AWS-CloudTrail-Trail property
         *
         * Specify an array of string values to match this event if the actual value of AWS-CloudTrail-Trail is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsCloudTrailTrail?: Array<string>;
        /**
         * AWS-EC2-Instance property
         *
         * Specify an array of string values to match this event if the actual value of AWS-EC2-Instance is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsEc2Instance?: Array<string>;
        /**
         * AWS-S3-Bucket property
         *
         * Specify an array of string values to match this event if the actual value of AWS-S3-Bucket is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsS3Bucket?: Array<string>;
    }
    /**
     * Type definition for RemoteAccountDetails
     *
     * @struct
     */
    interface RemoteAccountDetails {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * affiliated property
         *
         * Specify an array of string values to match this event if the actual value of affiliated is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly affiliated?: Array<string>;
    }
    /**
     * Type definition for RemoteIpDetails_1
     *
     * @struct
     */
    interface RemoteIpDetails1 {
        /**
         * city property
         *
         * Specify an array of string values to match this event if the actual value of city is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly city?: GuardDutyFinding.City1;
        /**
         * country property
         *
         * Specify an array of string values to match this event if the actual value of country is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly country?: GuardDutyFinding.Country1;
        /**
         * geoLocation property
         *
         * Specify an array of string values to match this event if the actual value of geoLocation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly geoLocation?: GuardDutyFinding.GeoLocation;
        /**
         * organization property
         *
         * Specify an array of string values to match this event if the actual value of organization is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly organization?: GuardDutyFinding.Organization1;
        /**
         * ipAddressV4 property
         *
         * Specify an array of string values to match this event if the actual value of ipAddressV4 is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipAddressV4?: Array<string>;
    }
    /**
     * Type definition for City_1
     *
     * @struct
     */
    interface City1 {
        /**
         * cityName property
         *
         * Specify an array of string values to match this event if the actual value of cityName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cityName?: Array<string>;
    }
    /**
     * Type definition for Country_1
     *
     * @struct
     */
    interface Country1 {
        /**
         * countryName property
         *
         * Specify an array of string values to match this event if the actual value of countryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly countryName?: Array<string>;
    }
    /**
     * Type definition for GeoLocation
     *
     * @struct
     */
    interface GeoLocation {
        /**
         * lat property
         *
         * Specify an array of string values to match this event if the actual value of lat is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lat?: Array<string>;
        /**
         * lon property
         *
         * Specify an array of string values to match this event if the actual value of lon is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lon?: Array<string>;
    }
    /**
     * Type definition for Organization_1
     *
     * @struct
     */
    interface Organization1 {
        /**
         * asn property
         *
         * Specify an array of string values to match this event if the actual value of asn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly asn?: Array<string>;
        /**
         * asnOrg property
         *
         * Specify an array of string values to match this event if the actual value of asnOrg is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly asnOrg?: Array<string>;
        /**
         * isp property
         *
         * Specify an array of string values to match this event if the actual value of isp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly isp?: Array<string>;
        /**
         * org property
         *
         * Specify an array of string values to match this event if the actual value of org is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly org?: Array<string>;
    }
    /**
     * Type definition for DnsRequestAction
     *
     * @struct
     */
    interface DnsRequestAction {
        /**
         * blocked property
         *
         * Specify an array of string values to match this event if the actual value of blocked is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly blocked?: Array<string>;
        /**
         * domain property
         *
         * Specify an array of string values to match this event if the actual value of domain is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly domain?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
    }
    /**
     * Type definition for KubernetesApiCallAction
     *
     * @struct
     */
    interface KubernetesApiCallAction {
        /**
         * remoteIpDetails property
         *
         * Specify an array of string values to match this event if the actual value of remoteIpDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly remoteIpDetails?: GuardDutyFinding.RemoteIpDetails2;
        /**
         * parameters property
         *
         * Specify an array of string values to match this event if the actual value of parameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly parameters?: Array<string>;
        /**
         * requestUri property
         *
         * Specify an array of string values to match this event if the actual value of requestUri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestUri?: Array<string>;
        /**
         * sourceIPs property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPs is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIPs?: Array<string>;
        /**
         * statusCode property
         *
         * Specify an array of string values to match this event if the actual value of statusCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly statusCode?: Array<string>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * verb property
         *
         * Specify an array of string values to match this event if the actual value of verb is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly verb?: Array<string>;
    }
    /**
     * Type definition for RemoteIpDetails_2
     *
     * @struct
     */
    interface RemoteIpDetails2 {
        /**
         * city property
         *
         * Specify an array of string values to match this event if the actual value of city is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly city?: GuardDutyFinding.City2;
        /**
         * country property
         *
         * Specify an array of string values to match this event if the actual value of country is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly country?: GuardDutyFinding.Country2;
        /**
         * geoLocation property
         *
         * Specify an array of string values to match this event if the actual value of geoLocation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly geoLocation?: GuardDutyFinding.GeoLocation;
        /**
         * organization property
         *
         * Specify an array of string values to match this event if the actual value of organization is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly organization?: GuardDutyFinding.Organization2;
        /**
         * ipAddressV4 property
         *
         * Specify an array of string values to match this event if the actual value of ipAddressV4 is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipAddressV4?: Array<string>;
    }
    /**
     * Type definition for City_2
     *
     * @struct
     */
    interface City2 {
        /**
         * cityName property
         *
         * Specify an array of string values to match this event if the actual value of cityName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cityName?: Array<string>;
    }
    /**
     * Type definition for Country_2
     *
     * @struct
     */
    interface Country2 {
        /**
         * countryName property
         *
         * Specify an array of string values to match this event if the actual value of countryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly countryName?: Array<string>;
    }
    /**
     * Type definition for Organization_2
     *
     * @struct
     */
    interface Organization2 {
        /**
         * asn property
         *
         * Specify an array of string values to match this event if the actual value of asn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly asn?: Array<string>;
        /**
         * asnOrg property
         *
         * Specify an array of string values to match this event if the actual value of asnOrg is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly asnOrg?: Array<string>;
        /**
         * isp property
         *
         * Specify an array of string values to match this event if the actual value of isp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly isp?: Array<string>;
        /**
         * org property
         *
         * Specify an array of string values to match this event if the actual value of org is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly org?: Array<string>;
    }
    /**
     * Type definition for NetworkConnectionAction
     *
     * @struct
     */
    interface NetworkConnectionAction {
        /**
         * localIpDetails property
         *
         * Specify an array of string values to match this event if the actual value of localIpDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly localIpDetails?: GuardDutyFinding.LocalIpDetails;
        /**
         * localPortDetails property
         *
         * Specify an array of string values to match this event if the actual value of localPortDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly localPortDetails?: GuardDutyFinding.LocalPortDetails;
        /**
         * remoteIpDetails property
         *
         * Specify an array of string values to match this event if the actual value of remoteIpDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly remoteIpDetails?: GuardDutyFinding.RemoteIpDetails3;
        /**
         * remotePortDetails property
         *
         * Specify an array of string values to match this event if the actual value of remotePortDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly remotePortDetails?: GuardDutyFinding.RemotePortDetails;
        /**
         * blocked property
         *
         * Specify an array of string values to match this event if the actual value of blocked is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly blocked?: Array<string>;
        /**
         * connectionDirection property
         *
         * Specify an array of string values to match this event if the actual value of connectionDirection is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly connectionDirection?: Array<string>;
        /**
         * protocol property
         *
         * Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly protocol?: Array<string>;
    }
    /**
     * Type definition for LocalIpDetails
     *
     * @struct
     */
    interface LocalIpDetails {
        /**
         * ipAddressV4 property
         *
         * Specify an array of string values to match this event if the actual value of ipAddressV4 is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipAddressV4?: Array<string>;
    }
    /**
     * Type definition for LocalPortDetails
     *
     * @struct
     */
    interface LocalPortDetails {
        /**
         * port property
         *
         * Specify an array of string values to match this event if the actual value of port is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly port?: Array<string>;
        /**
         * portName property
         *
         * Specify an array of string values to match this event if the actual value of portName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly portName?: Array<string>;
    }
    /**
     * Type definition for RemoteIpDetails_3
     *
     * @struct
     */
    interface RemoteIpDetails3 {
        /**
         * city property
         *
         * Specify an array of string values to match this event if the actual value of city is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly city?: GuardDutyFinding.City3;
        /**
         * country property
         *
         * Specify an array of string values to match this event if the actual value of country is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly country?: GuardDutyFinding.Country3;
        /**
         * geoLocation property
         *
         * Specify an array of string values to match this event if the actual value of geoLocation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly geoLocation?: GuardDutyFinding.GeoLocation;
        /**
         * organization property
         *
         * Specify an array of string values to match this event if the actual value of organization is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly organization?: GuardDutyFinding.Organization3;
        /**
         * ipAddressV4 property
         *
         * Specify an array of string values to match this event if the actual value of ipAddressV4 is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipAddressV4?: Array<string>;
    }
    /**
     * Type definition for City_3
     *
     * @struct
     */
    interface City3 {
        /**
         * cityName property
         *
         * Specify an array of string values to match this event if the actual value of cityName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cityName?: Array<string>;
    }
    /**
     * Type definition for Country_3
     *
     * @struct
     */
    interface Country3 {
        /**
         * countryName property
         *
         * Specify an array of string values to match this event if the actual value of countryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly countryName?: Array<string>;
    }
    /**
     * Type definition for Organization_3
     *
     * @struct
     */
    interface Organization3 {
        /**
         * asn property
         *
         * Specify an array of string values to match this event if the actual value of asn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly asn?: Array<string>;
        /**
         * asnOrg property
         *
         * Specify an array of string values to match this event if the actual value of asnOrg is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly asnOrg?: Array<string>;
        /**
         * isp property
         *
         * Specify an array of string values to match this event if the actual value of isp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly isp?: Array<string>;
        /**
         * org property
         *
         * Specify an array of string values to match this event if the actual value of org is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly org?: Array<string>;
    }
    /**
     * Type definition for RemotePortDetails
     *
     * @struct
     */
    interface RemotePortDetails {
        /**
         * port property
         *
         * Specify an array of string values to match this event if the actual value of port is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly port?: Array<string>;
        /**
         * portName property
         *
         * Specify an array of string values to match this event if the actual value of portName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly portName?: Array<string>;
    }
    /**
     * Type definition for PortProbeAction
     *
     * @struct
     */
    interface PortProbeAction {
        /**
         * blocked property
         *
         * Specify an array of string values to match this event if the actual value of blocked is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly blocked?: Array<string>;
        /**
         * portProbeDetails property
         *
         * Specify an array of string values to match this event if the actual value of portProbeDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly portProbeDetails?: Array<GuardDutyFinding.PortProbeActionItem>;
    }
    /**
     * Type definition for PortProbeActionItem
     *
     * @struct
     */
    interface PortProbeActionItem {
        /**
         * localIpDetails property
         *
         * Specify an array of string values to match this event if the actual value of localIpDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly localIpDetails?: GuardDutyFinding.LocalIpDetails1;
        /**
         * localPortDetails property
         *
         * Specify an array of string values to match this event if the actual value of localPortDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly localPortDetails?: GuardDutyFinding.LocalPortDetails1;
        /**
         * remoteIpDetails property
         *
         * Specify an array of string values to match this event if the actual value of remoteIpDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly remoteIpDetails?: GuardDutyFinding.RemoteIpDetails4;
    }
    /**
     * Type definition for LocalIpDetails_1
     *
     * @struct
     */
    interface LocalIpDetails1 {
        /**
         * ipAddressV4 property
         *
         * Specify an array of string values to match this event if the actual value of ipAddressV4 is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipAddressV4?: Array<string>;
    }
    /**
     * Type definition for LocalPortDetails_1
     *
     * @struct
     */
    interface LocalPortDetails1 {
        /**
         * port property
         *
         * Specify an array of string values to match this event if the actual value of port is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly port?: Array<string>;
        /**
         * portName property
         *
         * Specify an array of string values to match this event if the actual value of portName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly portName?: Array<string>;
    }
    /**
     * Type definition for RemoteIpDetails_4
     *
     * @struct
     */
    interface RemoteIpDetails4 {
        /**
         * city property
         *
         * Specify an array of string values to match this event if the actual value of city is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly city?: GuardDutyFinding.City4;
        /**
         * country property
         *
         * Specify an array of string values to match this event if the actual value of country is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly country?: GuardDutyFinding.Country4;
        /**
         * geoLocation property
         *
         * Specify an array of string values to match this event if the actual value of geoLocation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly geoLocation?: GuardDutyFinding.GeoLocation1;
        /**
         * organization property
         *
         * Specify an array of string values to match this event if the actual value of organization is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly organization?: GuardDutyFinding.Organization4;
        /**
         * ipAddressV4 property
         *
         * Specify an array of string values to match this event if the actual value of ipAddressV4 is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipAddressV4?: Array<string>;
    }
    /**
     * Type definition for City_4
     *
     * @struct
     */
    interface City4 {
        /**
         * cityName property
         *
         * Specify an array of string values to match this event if the actual value of cityName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cityName?: Array<string>;
    }
    /**
     * Type definition for Country_4
     *
     * @struct
     */
    interface Country4 {
        /**
         * countryName property
         *
         * Specify an array of string values to match this event if the actual value of countryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly countryName?: Array<string>;
    }
    /**
     * Type definition for GeoLocation_1
     *
     * @struct
     */
    interface GeoLocation1 {
        /**
         * lat property
         *
         * Specify an array of string values to match this event if the actual value of lat is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lat?: Array<string>;
        /**
         * lon property
         *
         * Specify an array of string values to match this event if the actual value of lon is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lon?: Array<string>;
    }
    /**
     * Type definition for Organization_4
     *
     * @struct
     */
    interface Organization4 {
        /**
         * asn property
         *
         * Specify an array of string values to match this event if the actual value of asn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly asn?: Array<string>;
        /**
         * asnOrg property
         *
         * Specify an array of string values to match this event if the actual value of asnOrg is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly asnOrg?: Array<string>;
        /**
         * isp property
         *
         * Specify an array of string values to match this event if the actual value of isp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly isp?: Array<string>;
        /**
         * org property
         *
         * Specify an array of string values to match this event if the actual value of org is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly org?: Array<string>;
    }
    /**
     * Type definition for AdditionalInfo
     *
     * @struct
     */
    interface AdditionalInfo {
        /**
         * anomalies property
         *
         * Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalies?: GuardDutyFinding.Anomalies;
        /**
         * newPolicy property
         *
         * Specify an array of string values to match this event if the actual value of newPolicy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly newPolicy?: GuardDutyFinding.NewPolicy;
        /**
         * oldPolicy property
         *
         * Specify an array of string values to match this event if the actual value of oldPolicy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly oldPolicy?: GuardDutyFinding.OldPolicy;
        /**
         * profiledBehavior property
         *
         * Specify an array of string values to match this event if the actual value of profiledBehavior is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly profiledBehavior?: GuardDutyFinding.ProfiledBehavior;
        /**
         * unusualBehavior property
         *
         * Specify an array of string values to match this event if the actual value of unusualBehavior is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualBehavior?: GuardDutyFinding.UnusualBehavior;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: GuardDutyFinding.UserAgent;
        /**
         * additionalScannedPorts property
         *
         * Specify an array of string values to match this event if the actual value of additionalScannedPorts is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly additionalScannedPorts?: Array<any>;
        /**
         * apiCalls property
         *
         * Specify an array of string values to match this event if the actual value of apiCalls is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly apiCalls?: Array<GuardDutyFinding.AdditionalInfoItem>;
        /**
         * domain property
         *
         * Specify an array of string values to match this event if the actual value of domain is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly domain?: Array<string>;
        /**
         * inBytes property
         *
         * Specify an array of string values to match this event if the actual value of inBytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inBytes?: Array<string>;
        /**
         * localPort property
         *
         * Specify an array of string values to match this event if the actual value of localPort is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly localPort?: Array<string>;
        /**
         * outBytes property
         *
         * Specify an array of string values to match this event if the actual value of outBytes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outBytes?: Array<string>;
        /**
         * portsScannedSample property
         *
         * Specify an array of string values to match this event if the actual value of portsScannedSample is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly portsScannedSample?: Array<number>;
        /**
         * recentCredentials property
         *
         * Specify an array of string values to match this event if the actual value of recentCredentials is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly recentCredentials?: Array<GuardDutyFinding.AdditionalInfoItem1>;
        /**
         * sample property
         *
         * Specify an array of string values to match this event if the actual value of sample is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sample?: Array<string>;
        /**
         * scannedPort property
         *
         * Specify an array of string values to match this event if the actual value of scannedPort is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scannedPort?: Array<string>;
        /**
         * threatListName property
         *
         * Specify an array of string values to match this event if the actual value of threatListName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threatListName?: Array<string>;
        /**
         * threatName property
         *
         * Specify an array of string values to match this event if the actual value of threatName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threatName?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * unusual property
         *
         * Specify an array of string values to match this event if the actual value of unusual is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusual?: any | number | string;
        /**
         * unusualProtocol property
         *
         * Specify an array of string values to match this event if the actual value of unusualProtocol is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualProtocol?: Array<string>;
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for Anomalies
     *
     * @struct
     */
    interface Anomalies {
        /**
         * anomalousAPIs property
         *
         * Specify an array of string values to match this event if the actual value of anomalousAPIs is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly anomalousApIs?: Array<string>;
    }
    /**
     * Type definition for NewPolicy
     *
     * @struct
     */
    interface NewPolicy {
        /**
         * allowUsersToChangePassword property
         *
         * Specify an array of string values to match this event if the actual value of allowUsersToChangePassword is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly allowUsersToChangePassword?: Array<string>;
        /**
         * hardExpiry property
         *
         * Specify an array of string values to match this event if the actual value of hardExpiry is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hardExpiry?: Array<string>;
        /**
         * maxPasswordAge property
         *
         * Specify an array of string values to match this event if the actual value of maxPasswordAge is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxPasswordAge?: Array<string>;
        /**
         * minimumPasswordLength property
         *
         * Specify an array of string values to match this event if the actual value of minimumPasswordLength is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly minimumPasswordLength?: Array<string>;
        /**
         * passwordReusePrevention property
         *
         * Specify an array of string values to match this event if the actual value of passwordReusePrevention is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly passwordReusePrevention?: Array<string>;
        /**
         * requireLowercaseCharacters property
         *
         * Specify an array of string values to match this event if the actual value of requireLowercaseCharacters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requireLowercaseCharacters?: Array<string>;
        /**
         * requireNumbers property
         *
         * Specify an array of string values to match this event if the actual value of requireNumbers is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requireNumbers?: Array<string>;
        /**
         * requireSymbols property
         *
         * Specify an array of string values to match this event if the actual value of requireSymbols is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requireSymbols?: Array<string>;
        /**
         * requireUppercaseCharacters property
         *
         * Specify an array of string values to match this event if the actual value of requireUppercaseCharacters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requireUppercaseCharacters?: Array<string>;
    }
    /**
     * Type definition for OldPolicy
     *
     * @struct
     */
    interface OldPolicy {
        /**
         * allowUsersToChangePassword property
         *
         * Specify an array of string values to match this event if the actual value of allowUsersToChangePassword is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly allowUsersToChangePassword?: Array<string>;
        /**
         * hardExpiry property
         *
         * Specify an array of string values to match this event if the actual value of hardExpiry is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hardExpiry?: Array<string>;
        /**
         * maxPasswordAge property
         *
         * Specify an array of string values to match this event if the actual value of maxPasswordAge is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly maxPasswordAge?: Array<string>;
        /**
         * minimumPasswordLength property
         *
         * Specify an array of string values to match this event if the actual value of minimumPasswordLength is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly minimumPasswordLength?: Array<string>;
        /**
         * passwordReusePrevention property
         *
         * Specify an array of string values to match this event if the actual value of passwordReusePrevention is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly passwordReusePrevention?: Array<string>;
        /**
         * requireLowercaseCharacters property
         *
         * Specify an array of string values to match this event if the actual value of requireLowercaseCharacters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requireLowercaseCharacters?: Array<string>;
        /**
         * requireNumbers property
         *
         * Specify an array of string values to match this event if the actual value of requireNumbers is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requireNumbers?: Array<string>;
        /**
         * requireSymbols property
         *
         * Specify an array of string values to match this event if the actual value of requireSymbols is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requireSymbols?: Array<string>;
        /**
         * requireUppercaseCharacters property
         *
         * Specify an array of string values to match this event if the actual value of requireUppercaseCharacters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requireUppercaseCharacters?: Array<string>;
    }
    /**
     * Type definition for ProfiledBehavior
     *
     * @struct
     */
    interface ProfiledBehavior {
        /**
         * frequentProfiledAPIsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of frequentProfiledAPIsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly frequentProfiledApIsAccountProfiling?: Array<string>;
        /**
         * frequentProfiledAPIsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of frequentProfiledAPIsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly frequentProfiledApIsUserIdentityProfiling?: Array<string>;
        /**
         * frequentProfiledASNsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of frequentProfiledASNsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly frequentProfiledAsNsAccountProfiling?: Array<string>;
        /**
         * frequentProfiledASNsBucketProfiling property
         *
         * Specify an array of string values to match this event if the actual value of frequentProfiledASNsBucketProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly frequentProfiledAsNsBucketProfiling?: Array<string>;
        /**
         * frequentProfiledASNsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of frequentProfiledASNsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly frequentProfiledAsNsUserIdentityProfiling?: Array<string>;
        /**
         * frequentProfiledBucketsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of frequentProfiledBucketsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly frequentProfiledBucketsAccountProfiling?: Array<string>;
        /**
         * frequentProfiledBucketsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of frequentProfiledBucketsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly frequentProfiledBucketsUserIdentityProfiling?: Array<string>;
        /**
         * frequentProfiledUserAgentsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of frequentProfiledUserAgentsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly frequentProfiledUserAgentsAccountProfiling?: Array<string>;
        /**
         * frequentProfiledUserAgentsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of frequentProfiledUserAgentsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly frequentProfiledUserAgentsUserIdentityProfiling?: Array<string>;
        /**
         * frequentProfiledUserNamesAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of frequentProfiledUserNamesAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly frequentProfiledUserNamesAccountProfiling?: Array<string>;
        /**
         * frequentProfiledUserNamesBucketProfiling property
         *
         * Specify an array of string values to match this event if the actual value of frequentProfiledUserNamesBucketProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly frequentProfiledUserNamesBucketProfiling?: Array<string>;
        /**
         * frequentProfiledUserTypesAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of frequentProfiledUserTypesAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly frequentProfiledUserTypesAccountProfiling?: Array<string>;
        /**
         * infrequentProfiledAPIsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of infrequentProfiledAPIsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly infrequentProfiledApIsAccountProfiling?: Array<string>;
        /**
         * infrequentProfiledAPIsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of infrequentProfiledAPIsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly infrequentProfiledApIsUserIdentityProfiling?: Array<string>;
        /**
         * infrequentProfiledASNsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of infrequentProfiledASNsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly infrequentProfiledAsNsAccountProfiling?: Array<string>;
        /**
         * infrequentProfiledASNsBucketProfiling property
         *
         * Specify an array of string values to match this event if the actual value of infrequentProfiledASNsBucketProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly infrequentProfiledAsNsBucketProfiling?: Array<string>;
        /**
         * infrequentProfiledASNsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of infrequentProfiledASNsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly infrequentProfiledAsNsUserIdentityProfiling?: Array<string>;
        /**
         * infrequentProfiledBucketsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of infrequentProfiledBucketsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly infrequentProfiledBucketsAccountProfiling?: Array<string>;
        /**
         * infrequentProfiledBucketsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of infrequentProfiledBucketsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly infrequentProfiledBucketsUserIdentityProfiling?: Array<string>;
        /**
         * infrequentProfiledUserAgentsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of infrequentProfiledUserAgentsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly infrequentProfiledUserAgentsAccountProfiling?: Array<string>;
        /**
         * infrequentProfiledUserAgentsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of infrequentProfiledUserAgentsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly infrequentProfiledUserAgentsUserIdentityProfiling?: Array<string>;
        /**
         * infrequentProfiledUserNamesAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of infrequentProfiledUserNamesAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly infrequentProfiledUserNamesAccountProfiling?: Array<string>;
        /**
         * infrequentProfiledUserNamesBucketProfiling property
         *
         * Specify an array of string values to match this event if the actual value of infrequentProfiledUserNamesBucketProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly infrequentProfiledUserNamesBucketProfiling?: Array<string>;
        /**
         * infrequentProfiledUserTypesAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of infrequentProfiledUserTypesAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly infrequentProfiledUserTypesAccountProfiling?: Array<string>;
        /**
         * numberOfHistoricalDailyAvgAPIsBucketProfiling property
         *
         * Specify an array of string values to match this event if the actual value of numberOfHistoricalDailyAvgAPIsBucketProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly numberOfHistoricalDailyAvgApIsBucketProfiling?: Array<string>;
        /**
         * numberOfHistoricalDailyAvgAPIsBucketUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of numberOfHistoricalDailyAvgAPIsBucketUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly numberOfHistoricalDailyAvgApIsBucketUserIdentityProfiling?: Array<string>;
        /**
         * numberOfHistoricalDailyAvgAPIsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of numberOfHistoricalDailyAvgAPIsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly numberOfHistoricalDailyAvgApIsUserIdentityProfiling?: Array<string>;
        /**
         * numberOfHistoricalDailyMaxAPIsBucketProfiling property
         *
         * Specify an array of string values to match this event if the actual value of numberOfHistoricalDailyMaxAPIsBucketProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly numberOfHistoricalDailyMaxApIsBucketProfiling?: Array<string>;
        /**
         * numberOfHistoricalDailyMaxAPIsBucketUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of numberOfHistoricalDailyMaxAPIsBucketUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly numberOfHistoricalDailyMaxApIsBucketUserIdentityProfiling?: Array<string>;
        /**
         * numberOfHistoricalDailyMaxAPIsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of numberOfHistoricalDailyMaxAPIsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly numberOfHistoricalDailyMaxApIsUserIdentityProfiling?: Array<string>;
        /**
         * rareProfiledAPIsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of rareProfiledAPIsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rareProfiledApIsAccountProfiling?: Array<string>;
        /**
         * rareProfiledAPIsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of rareProfiledAPIsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rareProfiledApIsUserIdentityProfiling?: Array<string>;
        /**
         * rareProfiledASNsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of rareProfiledASNsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rareProfiledAsNsAccountProfiling?: Array<string>;
        /**
         * rareProfiledASNsBucketProfiling property
         *
         * Specify an array of string values to match this event if the actual value of rareProfiledASNsBucketProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rareProfiledAsNsBucketProfiling?: Array<string>;
        /**
         * rareProfiledASNsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of rareProfiledASNsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rareProfiledAsNsUserIdentityProfiling?: Array<string>;
        /**
         * rareProfiledBucketsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of rareProfiledBucketsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rareProfiledBucketsAccountProfiling?: Array<string>;
        /**
         * rareProfiledBucketsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of rareProfiledBucketsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rareProfiledBucketsUserIdentityProfiling?: Array<string>;
        /**
         * rareProfiledUserAgentsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of rareProfiledUserAgentsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rareProfiledUserAgentsAccountProfiling?: Array<string>;
        /**
         * rareProfiledUserAgentsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of rareProfiledUserAgentsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rareProfiledUserAgentsUserIdentityProfiling?: Array<string>;
        /**
         * rareProfiledUserNamesAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of rareProfiledUserNamesAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rareProfiledUserNamesAccountProfiling?: Array<string>;
        /**
         * rareProfiledUserNamesBucketProfiling property
         *
         * Specify an array of string values to match this event if the actual value of rareProfiledUserNamesBucketProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rareProfiledUserNamesBucketProfiling?: Array<string>;
        /**
         * rareProfiledUserTypesAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of rareProfiledUserTypesAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly rareProfiledUserTypesAccountProfiling?: Array<string>;
    }
    /**
     * Type definition for UnusualBehavior
     *
     * @struct
     */
    interface UnusualBehavior {
        /**
         * isUnusualUserIdentity property
         *
         * Specify an array of string values to match this event if the actual value of isUnusualUserIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly isUnusualUserIdentity?: Array<string>;
        /**
         * numberOfPast24HoursAPIsBucketProfiling property
         *
         * Specify an array of string values to match this event if the actual value of numberOfPast24HoursAPIsBucketProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly numberOfPast24HoursApIsBucketProfiling?: Array<string>;
        /**
         * numberOfPast24HoursAPIsBucketUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of numberOfPast24HoursAPIsBucketUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly numberOfPast24HoursApIsBucketUserIdentityProfiling?: Array<string>;
        /**
         * numberOfPast24HoursAPIsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of numberOfPast24HoursAPIsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly numberOfPast24HoursApIsUserIdentityProfiling?: Array<string>;
        /**
         * unusualAPIsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of unusualAPIsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualApIsAccountProfiling?: Array<string>;
        /**
         * unusualAPIsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of unusualAPIsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualApIsUserIdentityProfiling?: Array<string>;
        /**
         * unusualASNsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of unusualASNsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualAsNsAccountProfiling?: Array<string>;
        /**
         * unusualASNsBucketProfiling property
         *
         * Specify an array of string values to match this event if the actual value of unusualASNsBucketProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualAsNsBucketProfiling?: Array<string>;
        /**
         * unusualASNsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of unusualASNsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualAsNsUserIdentityProfiling?: Array<string>;
        /**
         * unusualBucketsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of unusualBucketsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualBucketsAccountProfiling?: Array<string>;
        /**
         * unusualBucketsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of unusualBucketsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualBucketsUserIdentityProfiling?: Array<string>;
        /**
         * unusualUserAgentsAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of unusualUserAgentsAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualUserAgentsAccountProfiling?: Array<string>;
        /**
         * unusualUserAgentsUserIdentityProfiling property
         *
         * Specify an array of string values to match this event if the actual value of unusualUserAgentsUserIdentityProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualUserAgentsUserIdentityProfiling?: Array<string>;
        /**
         * unusualUserNamesAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of unusualUserNamesAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualUserNamesAccountProfiling?: Array<string>;
        /**
         * unusualUserNamesBucketProfiling property
         *
         * Specify an array of string values to match this event if the actual value of unusualUserNamesBucketProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualUserNamesBucketProfiling?: Array<string>;
        /**
         * unusualUserTypesAccountProfiling property
         *
         * Specify an array of string values to match this event if the actual value of unusualUserTypesAccountProfiling is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly unusualUserTypesAccountProfiling?: Array<string>;
    }
    /**
     * Type definition for UserAgent
     *
     * @struct
     */
    interface UserAgent {
        /**
         * fullUserAgent property
         *
         * Specify an array of string values to match this event if the actual value of fullUserAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fullUserAgent?: Array<string>;
        /**
         * userAgentCategory property
         *
         * Specify an array of string values to match this event if the actual value of userAgentCategory is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgentCategory?: Array<string>;
    }
    /**
     * Type definition for AdditionalInfoItem
     *
     * @struct
     */
    interface AdditionalInfoItem {
        /**
         * count property
         *
         * Specify an array of string values to match this event if the actual value of count is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly count?: Array<string>;
        /**
         * firstSeen property
         *
         * Specify an array of string values to match this event if the actual value of firstSeen is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly firstSeen?: Array<string>;
        /**
         * lastSeen property
         *
         * Specify an array of string values to match this event if the actual value of lastSeen is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly lastSeen?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
    }
    /**
     * Type definition for AdditionalInfoItem_1
     *
     * @struct
     */
    interface AdditionalInfoItem1 {
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * ipAddressV4 property
         *
         * Specify an array of string values to match this event if the actual value of ipAddressV4 is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipAddressV4?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
    }
    /**
     * Type definition for AwsApiCallAction
     *
     * @struct
     */
    interface AwsApiCallAction {
        /**
         * affectedResources property
         *
         * Specify an array of string values to match this event if the actual value of affectedResources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly affectedResources?: Array<string>;
        /**
         * remoteIpDetails property
         *
         * Specify an array of string values to match this event if the actual value of remoteIpDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly remoteIpDetails?: GuardDutyFinding.RemoteIpDetails;
        /**
         * api property
         *
         * Specify an array of string values to match this event if the actual value of api is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly api?: Array<string>;
        /**
         * callerType property
         *
         * Specify an array of string values to match this event if the actual value of callerType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly callerType?: Array<string>;
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * serviceName property
         *
         * Specify an array of string values to match this event if the actual value of serviceName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly serviceName?: Array<string>;
    }
    /**
     * Type definition for RemoteIpDetails
     *
     * @struct
     */
    interface RemoteIpDetails {
        /**
         * city property
         *
         * Specify an array of string values to match this event if the actual value of city is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly city?: GuardDutyFinding.City;
        /**
         * country property
         *
         * Specify an array of string values to match this event if the actual value of country is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly country?: GuardDutyFinding.Country;
        /**
         * geoLocation property
         *
         * Specify an array of string values to match this event if the actual value of geoLocation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly geoLocation?: GuardDutyFinding.GeoLocation;
        /**
         * organization property
         *
         * Specify an array of string values to match this event if the actual value of organization is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly organization?: GuardDutyFinding.Organization;
        /**
         * ipAddressV4 property
         *
         * Specify an array of string values to match this event if the actual value of ipAddressV4 is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ipAddressV4?: Array<string>;
    }
    /**
     * Type definition for City
     *
     * @struct
     */
    interface City {
        /**
         * cityName property
         *
         * Specify an array of string values to match this event if the actual value of cityName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly cityName?: Array<string>;
    }
    /**
     * Type definition for Country
     *
     * @struct
     */
    interface Country {
        /**
         * countryName property
         *
         * Specify an array of string values to match this event if the actual value of countryName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly countryName?: Array<string>;
    }
    /**
     * Type definition for Organization
     *
     * @struct
     */
    interface Organization {
        /**
         * asn property
         *
         * Specify an array of string values to match this event if the actual value of asn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly asn?: Array<string>;
        /**
         * asnOrg property
         *
         * Specify an array of string values to match this event if the actual value of asnOrg is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly asnOrg?: Array<string>;
        /**
         * isp property
         *
         * Specify an array of string values to match this event if the actual value of isp is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly isp?: Array<string>;
        /**
         * org property
         *
         * Specify an array of string values to match this event if the actual value of org is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly org?: Array<string>;
    }
    /**
     * Type definition for EbsVolumeScanDetails
     *
     * @struct
     */
    interface EbsVolumeScanDetails {
        /**
         * scanDetections property
         *
         * Specify an array of string values to match this event if the actual value of scanDetections is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scanDetections?: GuardDutyFinding.ScanDetections;
        /**
         * scanCompletedAt property
         *
         * Specify an array of string values to match this event if the actual value of scanCompletedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scanCompletedAt?: Array<string>;
        /**
         * scanId property
         *
         * Specify an array of string values to match this event if the actual value of scanId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scanId?: Array<string>;
        /**
         * scanStartedAt property
         *
         * Specify an array of string values to match this event if the actual value of scanStartedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scanStartedAt?: Array<string>;
        /**
         * sources property
         *
         * Specify an array of string values to match this event if the actual value of sources is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sources?: Array<string>;
        /**
         * triggerFindingId property
         *
         * Specify an array of string values to match this event if the actual value of triggerFindingId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly triggerFindingId?: Array<string>;
    }
    /**
     * Type definition for ScanDetections
     *
     * @struct
     */
    interface ScanDetections {
        /**
         * highestSeverityThreatDetails property
         *
         * Specify an array of string values to match this event if the actual value of highestSeverityThreatDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly highestSeverityThreatDetails?: GuardDutyFinding.HighestSeverityThreatDetails;
        /**
         * scannedItemCount property
         *
         * Specify an array of string values to match this event if the actual value of scannedItemCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly scannedItemCount?: GuardDutyFinding.ScannedItemCount;
        /**
         * threatDetectedByName property
         *
         * Specify an array of string values to match this event if the actual value of threatDetectedByName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threatDetectedByName?: GuardDutyFinding.ThreatDetectedByName;
        /**
         * threatsDetectedItemCount property
         *
         * Specify an array of string values to match this event if the actual value of threatsDetectedItemCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threatsDetectedItemCount?: GuardDutyFinding.ThreatsDetectedItemCount;
    }
    /**
     * Type definition for HighestSeverityThreatDetails
     *
     * @struct
     */
    interface HighestSeverityThreatDetails {
        /**
         * count property
         *
         * Specify an array of string values to match this event if the actual value of count is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly count?: Array<string>;
        /**
         * severity property
         *
         * Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly severity?: Array<string>;
        /**
         * threatName property
         *
         * Specify an array of string values to match this event if the actual value of threatName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threatName?: Array<string>;
    }
    /**
     * Type definition for ScannedItemCount
     *
     * @struct
     */
    interface ScannedItemCount {
        /**
         * files property
         *
         * Specify an array of string values to match this event if the actual value of files is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly files?: Array<string>;
        /**
         * totalGb property
         *
         * Specify an array of string values to match this event if the actual value of totalGb is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly totalGb?: Array<string>;
        /**
         * volumes property
         *
         * Specify an array of string values to match this event if the actual value of volumes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly volumes?: Array<string>;
    }
    /**
     * Type definition for ThreatDetectedByName
     *
     * @struct
     */
    interface ThreatDetectedByName {
        /**
         * itemCount property
         *
         * Specify an array of string values to match this event if the actual value of itemCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly itemCount?: Array<string>;
        /**
         * shortened property
         *
         * Specify an array of string values to match this event if the actual value of shortened is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly shortened?: Array<string>;
        /**
         * threatNames property
         *
         * Specify an array of string values to match this event if the actual value of threatNames is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threatNames?: Array<GuardDutyFinding.ThreatDetectedByNameItem>;
        /**
         * uniqueThreatNameCount property
         *
         * Specify an array of string values to match this event if the actual value of uniqueThreatNameCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly uniqueThreatNameCount?: Array<string>;
    }
    /**
     * Type definition for ThreatDetectedByNameItem
     *
     * @struct
     */
    interface ThreatDetectedByNameItem {
        /**
         * filePaths property
         *
         * Specify an array of string values to match this event if the actual value of filePaths is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePaths?: Array<GuardDutyFinding.ThreatDetectedByNameItemItem>;
        /**
         * itemCount property
         *
         * Specify an array of string values to match this event if the actual value of itemCount is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly itemCount?: Array<string>;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: Array<string>;
        /**
         * severity property
         *
         * Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly severity?: Array<string>;
    }
    /**
     * Type definition for ThreatDetectedByNameItemItem
     *
     * @struct
     */
    interface ThreatDetectedByNameItemItem {
        /**
         * fileName property
         *
         * Specify an array of string values to match this event if the actual value of fileName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fileName?: Array<string>;
        /**
         * filePath property
         *
         * Specify an array of string values to match this event if the actual value of filePath is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly filePath?: Array<string>;
        /**
         * hash property
         *
         * Specify an array of string values to match this event if the actual value of hash is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly hash?: Array<string>;
        /**
         * volumeArn property
         *
         * Specify an array of string values to match this event if the actual value of volumeArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly volumeArn?: Array<string>;
    }
    /**
     * Type definition for ThreatsDetectedItemCount
     *
     * @struct
     */
    interface ThreatsDetectedItemCount {
        /**
         * files property
         *
         * Specify an array of string values to match this event if the actual value of files is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly files?: Array<string>;
    }
    /**
     * Type definition for Evidence
     *
     * @struct
     */
    interface Evidence {
        /**
         * threatIntelligenceDetails property
         *
         * Specify an array of string values to match this event if the actual value of threatIntelligenceDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threatIntelligenceDetails?: Array<GuardDutyFinding.EvidenceItem>;
    }
    /**
     * Type definition for EvidenceItem
     *
     * @struct
     */
    interface EvidenceItem {
        /**
         * threatListName property
         *
         * Specify an array of string values to match this event if the actual value of threatListName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threatListName?: Array<string>;
        /**
         * threatNames property
         *
         * Specify an array of string values to match this event if the actual value of threatNames is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly threatNames?: Array<string>;
    }
}
/**
 * EventBridge event patterns for Detector
 */
export declare class DetectorEvents {
    /**
     * Create DetectorEvents from a Detector reference
     */
    static fromDetector(detectorRef: service.IDetectorRef): DetectorEvents;
    /**
     * Reference to the Detector construct
     */
    private readonly detectorRef;
    private constructor();
    /**
     * EventBridge event pattern for Detector GuardDuty Finding
     */
    guardDutyFindingPattern(options?: GuardDutyFinding.GuardDutyFindingProps): events.EventPattern;
}
