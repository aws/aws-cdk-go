import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-route53profiles";
/**
 * Builder for CfnProfileLogsMixin to generate ROUTE53_PROFILES_RESOLVER_QUERY_LOGS for CfnProfile
 *
 * @cloudformationResource AWS::Route53Profiles::Profile
 * @logType ROUTE53_PROFILES_RESOLVER_QUERY_LOGS
 * @stability external
 */
export declare class CfnProfileRoute53ProfilesResolverQueryLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnProfileRoute53ProfilesResolverQueryLogsS3Props): CfnProfileLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnProfileRoute53ProfilesResolverQueryLogsLogGroupProps): CfnProfileLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnProfileRoute53ProfilesResolverQueryLogsFirehoseProps): CfnProfileLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef): CfnProfileLogsMixin;
}
/**
 * A complex type that includes settings for a Route 53 Profile.
 *
 * @cloudformationResource AWS::Route53Profiles::Profile
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-route53profiles-profile.html
 */
export declare class CfnProfileLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly ROUTE53_PROFILES_RESOLVER_QUERY_LOGS: CfnProfileRoute53ProfilesResolverQueryLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::Route53Profiles::Profile`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnProfile;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnProfileRoute53ProfilesResolverQueryLogs.
 */
export declare class CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat {
}
export declare namespace CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export interface CfnProfileRoute53ProfilesResolverQueryLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.S3;
}
export interface CfnProfileRoute53ProfilesResolverQueryLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.LogGroup;
}
export interface CfnProfileRoute53ProfilesResolverQueryLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.Firehose;
}
