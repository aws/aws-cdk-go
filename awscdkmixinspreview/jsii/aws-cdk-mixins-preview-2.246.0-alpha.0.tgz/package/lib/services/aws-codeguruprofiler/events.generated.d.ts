import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.codeguruprofiler@CodeGuruProfilerRecommendationStateChange
 */
export declare class CodeGuruProfilerRecommendationStateChange {
    /**
     * EventBridge event pattern for CodeGuru Profiler Recommendations State Change
     */
    static codeGuruProfilerRecommendationStateChangePattern(options?: CodeGuruProfilerRecommendationStateChange.CodeGuruProfilerRecommendationStateChangeProps): events.EventPattern;
}
export declare namespace CodeGuruProfilerRecommendationStateChange {
    /**
     * Props type for aws.codeguruprofiler@CodeGuruProfilerRecommendationStateChange event
     */
    interface CodeGuruProfilerRecommendationStateChangeProps {
        /**
         * recommendation property
         *
         * Specify an array of string values to match this event if the actual value of recommendation is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly recommendation?: CodeGuruProfilerRecommendationStateChange.Recommendation;
        /**
         * title property
         *
         * Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly title?: CodeGuruProfilerRecommendationStateChange.Title;
        /**
         * computeInstanceArns property
         *
         * Specify an array of string values to match this event if the actual value of computeInstanceArns is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly computeInstanceArns?: Array<string>;
        /**
         * deduplicationId property
         *
         * Specify an array of string values to match this event if the actual value of deduplicationId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly deduplicationId?: Array<string>;
        /**
         * eventEndTime property
         *
         * Specify an array of string values to match this event if the actual value of eventEndTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventEndTime?: Array<string>;
        /**
         * eventStartTime property
         *
         * Specify an array of string values to match this event if the actual value of eventStartTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventStartTime?: Array<string>;
        /**
         * expiresOn property
         *
         * Specify an array of string values to match this event if the actual value of expiresOn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly expiresOn?: Array<string>;
        /**
         * schema property
         *
         * Specify an array of string values to match this event if the actual value of schema is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly schema?: Array<string>;
        /**
         * severity property
         *
         * Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly severity?: Array<string>;
        /**
         * sourceUrl property
         *
         * Specify an array of string values to match this event if the actual value of sourceUrl is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceUrl?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Recommendation
     *
     * @struct
     */
    interface Recommendation {
        /**
         * description property
         *
         * Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly description?: CodeGuruProfilerRecommendationStateChange.Description;
        /**
         * name property
         *
         * Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly name?: CodeGuruProfilerRecommendationStateChange.Name;
        /**
         * reason property
         *
         * Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reason?: CodeGuruProfilerRecommendationStateChange.Reason;
        /**
         * resolutionSteps property
         *
         * Specify an array of string values to match this event if the actual value of resolutionSteps is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly resolutionSteps?: CodeGuruProfilerRecommendationStateChange.ResolutionSteps;
    }
    /**
     * Type definition for Description
     *
     * @struct
     */
    interface Description {
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for Name
     *
     * @struct
     */
    interface Name {
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for Reason
     *
     * @struct
     */
    interface Reason {
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for ResolutionSteps
     *
     * @struct
     */
    interface ResolutionSteps {
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
    /**
     * Type definition for Title
     *
     * @struct
     */
    interface Title {
        /**
         * value property
         *
         * Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly value?: Array<string>;
    }
}
