import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.qldb@QLDBLedgerStateChange
 */
export declare class QLDBLedgerStateChange {
    /**
     * EventBridge event pattern for QLDB Ledger State Change
     */
    static qldbLedgerStateChangePattern(options?: QLDBLedgerStateChange.QLDBLedgerStateChangeProps): events.EventPattern;
}
export declare namespace QLDBLedgerStateChange {
    /**
     * Props type for aws.qldb@QLDBLedgerStateChange event
     */
    interface QLDBLedgerStateChangeProps {
        /**
         * ledgerName property
         *
         * Specify an array of string values to match this event if the actual value of ledgerName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly ledgerName?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
