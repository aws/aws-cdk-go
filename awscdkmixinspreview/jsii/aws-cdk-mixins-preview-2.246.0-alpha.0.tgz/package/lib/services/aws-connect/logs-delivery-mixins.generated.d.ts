import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-connect";
/**
 * Builder for CfnInstanceLogsMixin to generate AMAZON_CONNECT_FLOW_LOGS for CfnInstance
 *
 * @cloudformationResource AWS::Connect::Instance
 * @logType AMAZON_CONNECT_FLOW_LOGS
 * @stability external
 */
export declare class CfnInstanceAmazonConnectFlowLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnInstanceAmazonConnectFlowLogsS3Props): CfnInstanceLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnInstanceAmazonConnectFlowLogsLogGroupProps): CfnInstanceLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnInstanceAmazonConnectFlowLogsFirehoseProps): CfnInstanceLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnInstanceAmazonConnectFlowLogsDestProps): CfnInstanceLogsMixin;
}
/**
 * *This is a preview release for Amazon Connect . It is subject to change.*.
 *
 * Initiates an Amazon Connect instance with all the supported channels enabled. It does not attach any storage, such as Amazon Simple Storage Service (Amazon S3) or Amazon Kinesis.
 *
 * Amazon Connect enforces a limit on the total number of instances that you can create or delete in 30 days. If you exceed this limit, you will get an error message indicating there has been an excessive number of attempts at creating or deleting instances. You must wait 30 days before you can restart creating and deleting instances in your account.
 *
 * @cloudformationResource AWS::Connect::Instance
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-connect-instance.html
 */
export declare class CfnInstanceLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly AMAZON_CONNECT_FLOW_LOGS: CfnInstanceAmazonConnectFlowLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::Connect::Instance`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnInstance;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnInstanceAmazonConnectFlowLogs.
 */
export declare class CfnInstanceAmazonConnectFlowLogsOutputFormat {
}
export declare namespace CfnInstanceAmazonConnectFlowLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnInstanceAmazonConnectFlowLogsRecordFields {
    INSTANCEARN = "InstanceArn",
    TIMESTAMP = "Timestamp",
    ACCOUNTID = "AccountId",
    RESOURCEARN = "ResourceArn",
    RESOURCETYPE = "ResourceType",
    RESOURCENAME = "ResourceName",
    RESOURCEEXECUTIONSTARTTIME = "ResourceExecutionStartTime",
    RESOURCEPUBLISHTIMESTAMP = "ResourcePublishTimestamp",
    FLOWTYPE = "FlowType",
    CONTACTID = "ContactId",
    INITIATIONMETHOD = "InitiationMethod",
    CHANNEL = "Channel",
    SUBTYPE = "SubType",
    LOGVERSION = "LogVersion",
    LOGTYPE = "LogType",
    ACTIONLOGDATA = "ActionLogData",
    MODULECALLSTACK = "ModuleCallstack",
    ACTIONCOUNTER = "ActionCounter"
}
export interface CfnInstanceAmazonConnectFlowLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnInstanceAmazonConnectFlowLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnInstanceAmazonConnectFlowLogsRecordFields>;
}
export interface CfnInstanceAmazonConnectFlowLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnInstanceAmazonConnectFlowLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnInstanceAmazonConnectFlowLogsRecordFields>;
}
export interface CfnInstanceAmazonConnectFlowLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnInstanceAmazonConnectFlowLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnInstanceAmazonConnectFlowLogsRecordFields>;
}
export interface CfnInstanceAmazonConnectFlowLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnInstanceAmazonConnectFlowLogsRecordFields>;
}
