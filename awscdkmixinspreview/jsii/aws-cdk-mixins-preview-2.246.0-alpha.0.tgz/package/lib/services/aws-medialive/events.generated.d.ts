import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-medialive";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.medialive@MediaLiveChannelAlert
 */
export declare class MediaLiveChannelAlert {
    /**
     * EventBridge event pattern for MediaLive Channel Alert
     */
    static mediaLiveChannelAlertPattern(options?: MediaLiveChannelAlert.MediaLiveChannelAlertProps): events.EventPattern;
}
export declare namespace MediaLiveChannelAlert {
    /**
     * Props type for aws.medialive@MediaLiveChannelAlert event
     */
    interface MediaLiveChannelAlertProps {
        /**
         * alarm_id property
         *
         * Specify an array of string values to match this event if the actual value of alarm_id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alarmId?: Array<string>;
        /**
         * alarm_state property
         *
         * Specify an array of string values to match this event if the actual value of alarm_state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alarmState?: Array<string>;
        /**
         * alert_type property
         *
         * Specify an array of string values to match this event if the actual value of alert_type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alertType?: Array<string>;
        /**
         * channel_arn property
         *
         * Specify an array of string values to match this event if the actual value of channel_arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelArn?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * pipeline property
         *
         * Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipeline?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.medialive@MediaLiveChannelStateChange
 */
export declare class MediaLiveChannelStateChange {
    /**
     * EventBridge event pattern for MediaLive Channel State Change
     */
    static mediaLiveChannelStateChangePattern(options?: MediaLiveChannelStateChange.MediaLiveChannelStateChangeProps): events.EventPattern;
}
export declare namespace MediaLiveChannelStateChange {
    /**
     * Props type for aws.medialive@MediaLiveChannelStateChange event
     */
    interface MediaLiveChannelStateChangeProps {
        /**
         * pipeline property
         *
         * Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipeline?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * channel_arn property
         *
         * Specify an array of string values to match this event if the actual value of channel_arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelArn?: Array<string>;
        /**
         * pipelines_running_count property
         *
         * Specify an array of string values to match this event if the actual value of pipelines_running_count is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipelinesRunningCount?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.medialive@MediaLiveMultiplexAlert
 */
export declare class MediaLiveMultiplexAlert {
    /**
     * EventBridge event pattern for MediaLive Multiplex Alert
     */
    static mediaLiveMultiplexAlertPattern(options?: MediaLiveMultiplexAlert.MediaLiveMultiplexAlertProps): events.EventPattern;
}
export declare namespace MediaLiveMultiplexAlert {
    /**
     * Props type for aws.medialive@MediaLiveMultiplexAlert event
     */
    interface MediaLiveMultiplexAlertProps {
        /**
         * alarm_state property
         *
         * Specify an array of string values to match this event if the actual value of alarm_state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alarmState?: Array<string>;
        /**
         * alert_type property
         *
         * Specify an array of string values to match this event if the actual value of alert_type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly alertType?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * pipeline property
         *
         * Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipeline?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.medialive@MediaLiveMultiplexStateChange
 */
export declare class MediaLiveMultiplexStateChange {
    /**
     * EventBridge event pattern for MediaLive Multiplex State Change
     */
    static mediaLiveMultiplexStateChangePattern(options?: MediaLiveMultiplexStateChange.MediaLiveMultiplexStateChangeProps): events.EventPattern;
}
export declare namespace MediaLiveMultiplexStateChange {
    /**
     * Props type for aws.medialive@MediaLiveMultiplexStateChange event
     */
    interface MediaLiveMultiplexStateChangeProps {
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * pipeline property
         *
         * Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipeline?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.medialive@MediaLiveChannelInputChange
 */
export declare class MediaLiveChannelInputChange {
    /**
     * EventBridge event pattern for MediaLive Channel Input Change
     */
    static mediaLiveChannelInputChangePattern(options?: MediaLiveChannelInputChange.MediaLiveChannelInputChangeProps): events.EventPattern;
}
export declare namespace MediaLiveChannelInputChange {
    /**
     * Props type for aws.medialive@MediaLiveChannelInputChange event
     */
    interface MediaLiveChannelInputChangeProps {
        /**
         * active_input_attachment_name property
         *
         * Specify an array of string values to match this event if the actual value of active_input_attachment_name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly activeInputAttachmentName?: Array<string>;
        /**
         * active_input_switch_action_name property
         *
         * Specify an array of string values to match this event if the actual value of active_input_switch_action_name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly activeInputSwitchActionName?: Array<string>;
        /**
         * channel_arn property
         *
         * Specify an array of string values to match this event if the actual value of channel_arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Channel reference
         */
        readonly channelArn?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * pipeline property
         *
         * Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly pipeline?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event patterns for Channel
 */
export declare class ChannelEvents {
    /**
     * Create ChannelEvents from a Channel reference
     */
    static fromChannel(channelRef: service.IChannelRef): ChannelEvents;
    /**
     * Reference to the Channel construct
     */
    private readonly channelRef;
    private constructor();
    /**
     * EventBridge event pattern for Channel MediaLive Channel Input Change
     */
    mediaLiveChannelInputChangePattern(options?: MediaLiveChannelInputChange.MediaLiveChannelInputChangeProps): events.EventPattern;
}
