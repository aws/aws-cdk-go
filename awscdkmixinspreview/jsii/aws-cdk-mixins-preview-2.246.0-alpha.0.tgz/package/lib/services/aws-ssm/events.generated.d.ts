import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.ssm@CalendarStateChange
 */
export declare class CalendarStateChange {
    /**
     * EventBridge event pattern for Calendar State Change
     */
    static calendarStateChangePattern(options?: CalendarStateChange.CalendarStateChangeProps): events.EventPattern;
}
export declare namespace CalendarStateChange {
    /**
     * Props type for aws.ssm@CalendarStateChange event
     */
    interface CalendarStateChangeProps {
        /**
         * atTime property
         *
         * Specify an array of string values to match this event if the actual value of atTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly atTime?: Array<string>;
        /**
         * nextTransitionTime property
         *
         * Specify an array of string values to match this event if the actual value of nextTransitionTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly nextTransitionTime?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
