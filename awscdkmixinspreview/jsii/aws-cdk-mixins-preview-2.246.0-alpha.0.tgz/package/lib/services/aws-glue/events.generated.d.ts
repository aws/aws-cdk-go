import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-glue";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.glue@GlueDataCatalogDatabaseStateChange
 */
export declare class GlueDataCatalogDatabaseStateChange {
    /**
     * EventBridge event pattern for Glue Data Catalog Database State Change
     */
    static glueDataCatalogDatabaseStateChangePattern(options?: GlueDataCatalogDatabaseStateChange.GlueDataCatalogDatabaseStateChangeProps): events.EventPattern;
}
export declare namespace GlueDataCatalogDatabaseStateChange {
    /**
     * Props type for aws.glue@GlueDataCatalogDatabaseStateChange event
     */
    interface GlueDataCatalogDatabaseStateChangeProps {
        /**
         * databaseName property
         *
         * Specify an array of string values to match this event if the actual value of databaseName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Database reference
         */
        readonly databaseName?: Array<string>;
        /**
         * typeOfChange property
         *
         * Specify an array of string values to match this event if the actual value of typeOfChange is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly typeOfChange?: Array<string>;
        /**
         * changedTables property
         *
         * Specify an array of string values to match this event if the actual value of changedTables is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly changedTables?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event patterns for Database
 */
export declare class DatabaseEvents {
    /**
     * Create DatabaseEvents from a Database reference
     */
    static fromDatabase(databaseRef: service.IDatabaseRef): DatabaseEvents;
    /**
     * Reference to the Database construct
     */
    private readonly databaseRef;
    private constructor();
    /**
     * EventBridge event pattern for Database Glue Data Catalog Database State Change
     */
    glueDataCatalogDatabaseStateChangePattern(options?: GlueDataCatalogDatabaseStateChange.GlueDataCatalogDatabaseStateChangeProps): events.EventPattern;
    /**
     * EventBridge event pattern for Database Glue Data Catalog Table State Change
     */
    glueDataCatalogTableStateChangePattern(options?: GlueDataCatalogTableStateChange.GlueDataCatalogTableStateChangeProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.glue@GlueDataCatalogTableStateChange
 */
export declare class GlueDataCatalogTableStateChange {
    /**
     * EventBridge event pattern for Glue Data Catalog Table State Change
     */
    static glueDataCatalogTableStateChangePattern(options?: GlueDataCatalogTableStateChange.GlueDataCatalogTableStateChangeProps): events.EventPattern;
}
export declare namespace GlueDataCatalogTableStateChange {
    /**
     * Props type for aws.glue@GlueDataCatalogTableStateChange event
     */
    interface GlueDataCatalogTableStateChangeProps {
        /**
         * databaseName property
         *
         * Specify an array of string values to match this event if the actual value of databaseName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Database reference
         */
        readonly databaseName?: Array<string>;
        /**
         * changedPartitions property
         *
         * Specify an array of string values to match this event if the actual value of changedPartitions is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly changedPartitions?: Array<string>;
        /**
         * typeOfChange property
         *
         * Specify an array of string values to match this event if the actual value of typeOfChange is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly typeOfChange?: Array<string>;
        /**
         * tableName property
         *
         * Specify an array of string values to match this event if the actual value of tableName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly tableName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.glue@AWSAPICallViaCloudTrail
 */
export declare class AWSAPICallViaCloudTrail {
    /**
     * EventBridge event pattern for AWS API Call via CloudTrail
     */
    static awsAPICallViaCloudTrailPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
}
export declare namespace AWSAPICallViaCloudTrail {
    /**
     * Props type for aws.glue@AWSAPICallViaCloudTrail event
     */
    interface AWSAPICallViaCloudTrailProps {
        /**
         * responseElements property
         *
         * Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly responseElements?: AWSAPICallViaCloudTrail.ResponseElements;
        /**
         * requestParameters property
         *
         * Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestParameters?: AWSAPICallViaCloudTrail.RequestParameters;
        /**
         * userIdentity property
         *
         * Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userIdentity?: AWSAPICallViaCloudTrail.UserIdentity;
        /**
         * eventID property
         *
         * Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventId?: Array<string>;
        /**
         * awsRegion property
         *
         * Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsRegion?: Array<string>;
        /**
         * eventVersion property
         *
         * Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventVersion?: Array<string>;
        /**
         * sourceIPAddress property
         *
         * Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceIpAddress?: Array<string>;
        /**
         * eventSource property
         *
         * Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventSource?: Array<string>;
        /**
         * userAgent property
         *
         * Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userAgent?: Array<string>;
        /**
         * eventType property
         *
         * Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventType?: Array<string>;
        /**
         * requestID property
         *
         * Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly requestId?: Array<string>;
        /**
         * eventTime property
         *
         * Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventTime?: Array<string>;
        /**
         * eventName property
         *
         * Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ResponseElements
     *
     * @struct
     */
    interface ResponseElements {
        /**
         * jobRunId property
         *
         * Specify an array of string values to match this event if the actual value of jobRunId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobRunId?: Array<string>;
    }
    /**
     * Type definition for RequestParameters
     *
     * @struct
     */
    interface RequestParameters {
        /**
         * jobName property
         *
         * Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Job reference
         */
        readonly jobName?: Array<string>;
        /**
         * allocatedCapacity property
         *
         * Specify an array of string values to match this event if the actual value of allocatedCapacity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly allocatedCapacity?: Array<string>;
    }
    /**
     * Type definition for UserIdentity
     *
     * @struct
     */
    interface UserIdentity {
        /**
         * sessionContext property
         *
         * Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionContext?: AWSAPICallViaCloudTrail.SessionContext;
        /**
         * accessKeyId property
         *
         * Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accessKeyId?: Array<string>;
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * invokedBy property
         *
         * Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly invokedBy?: Array<string>;
    }
    /**
     * Type definition for SessionContext
     *
     * @struct
     */
    interface SessionContext {
        /**
         * sessionIssuer property
         *
         * Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionIssuer?: AWSAPICallViaCloudTrail.SessionIssuer;
        /**
         * attributes property
         *
         * Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly attributes?: AWSAPICallViaCloudTrail.Attributes;
    }
    /**
     * Type definition for SessionIssuer
     *
     * @struct
     */
    interface SessionIssuer {
        /**
         * accountId property
         *
         * Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * principalId property
         *
         * Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly principalId?: Array<string>;
        /**
         * type property
         *
         * Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly type?: Array<string>;
        /**
         * arn property
         *
         * Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly arn?: Array<string>;
        /**
         * userName property
         *
         * Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly userName?: Array<string>;
    }
    /**
     * Type definition for Attributes
     *
     * @struct
     */
    interface Attributes {
        /**
         * mfaAuthenticated property
         *
         * Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly mfaAuthenticated?: Array<string>;
        /**
         * creationDate property
         *
         * Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly creationDate?: Array<string>;
    }
}
/**
 * EventBridge event patterns for Job
 */
export declare class JobEvents {
    /**
     * Create JobEvents from a Job reference
     */
    static fromJob(jobRef: service.IJobRef): JobEvents;
    /**
     * Reference to the Job construct
     */
    private readonly jobRef;
    private constructor();
    /**
     * EventBridge event pattern for Job AWS API Call via CloudTrail
     */
    awsAPICallViaCloudTrailPattern(options?: AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps): events.EventPattern;
    /**
     * EventBridge event pattern for Job Glue Job Run Status
     */
    glueJobRunStatusPattern(options?: GlueJobRunStatus.GlueJobRunStatusProps): events.EventPattern;
    /**
     * EventBridge event pattern for Job Glue Job State Change
     */
    glueJobStateChangePattern(options?: GlueJobStateChange.GlueJobStateChangeProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.glue@GlueJobRunStatus
 */
export declare class GlueJobRunStatus {
    /**
     * EventBridge event pattern for Glue Job Run Status
     */
    static glueJobRunStatusPattern(options?: GlueJobRunStatus.GlueJobRunStatusProps): events.EventPattern;
}
export declare namespace GlueJobRunStatus {
    /**
     * Props type for aws.glue@GlueJobRunStatus event
     */
    interface GlueJobRunStatusProps {
        /**
         * notificationCondition property
         *
         * Specify an array of string values to match this event if the actual value of notificationCondition is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notificationCondition?: GlueJobRunStatus.NotificationCondition;
        /**
         * jobName property
         *
         * Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Job reference
         */
        readonly jobName?: Array<string>;
        /**
         * severity property
         *
         * Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly severity?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * jobRunId property
         *
         * Specify an array of string values to match this event if the actual value of jobRunId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobRunId?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * startedOn property
         *
         * Specify an array of string values to match this event if the actual value of startedOn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly startedOn?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for NotificationCondition
     *
     * @struct
     */
    interface NotificationCondition {
        /**
         * NotifyDelayAfter property
         *
         * Specify an array of string values to match this event if the actual value of NotifyDelayAfter is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly notifyDelayAfter?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.glue@GlueJobStateChange
 */
export declare class GlueJobStateChange {
    /**
     * EventBridge event pattern for Glue Job State Change
     */
    static glueJobStateChangePattern(options?: GlueJobStateChange.GlueJobStateChangeProps): events.EventPattern;
}
export declare namespace GlueJobStateChange {
    /**
     * Props type for aws.glue@GlueJobStateChange event
     */
    interface GlueJobStateChangeProps {
        /**
         * jobName property
         *
         * Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Job reference
         */
        readonly jobName?: Array<string>;
        /**
         * severity property
         *
         * Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly severity?: Array<string>;
        /**
         * state property
         *
         * Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly state?: Array<string>;
        /**
         * jobRunId property
         *
         * Specify an array of string values to match this event if the actual value of jobRunId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly jobRunId?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
