import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-rum";
/**
 * Builder for CfnAppMonitorLogsMixin to generate RUM_TELEMETRY_LOGS for CfnAppMonitor
 *
 * @cloudformationResource AWS::RUM::AppMonitor
 * @logType RUM_TELEMETRY_LOGS
 * @stability external
 */
export declare class CfnAppMonitorRumTelemetryLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnAppMonitorRumTelemetryLogsS3Props): CfnAppMonitorLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnAppMonitorRumTelemetryLogsLogGroupProps): CfnAppMonitorLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnAppMonitorRumTelemetryLogsFirehoseProps): CfnAppMonitorLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef): CfnAppMonitorLogsMixin;
}
/**
 * Builder for CfnAppMonitorLogsMixin to generate RUM_OTEL_LOGS for CfnAppMonitor
 *
 * @cloudformationResource AWS::RUM::AppMonitor
 * @logType RUM_OTEL_LOGS
 * @stability external
 */
export declare class CfnAppMonitorRumOtelLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnAppMonitorRumOtelLogsS3Props): CfnAppMonitorLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnAppMonitorRumOtelLogsLogGroupProps): CfnAppMonitorLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnAppMonitorRumOtelLogsFirehoseProps): CfnAppMonitorLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef): CfnAppMonitorLogsMixin;
}
/**
 * Builder for CfnAppMonitorLogsMixin to generate RUM_OTEL_SPANS for CfnAppMonitor
 *
 * @cloudformationResource AWS::RUM::AppMonitor
 * @logType RUM_OTEL_SPANS
 * @stability external
 */
export declare class CfnAppMonitorRumOtelSpans {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnAppMonitorRumOtelSpansS3Props): CfnAppMonitorLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnAppMonitorRumOtelSpansLogGroupProps): CfnAppMonitorLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnAppMonitorRumOtelSpansFirehoseProps): CfnAppMonitorLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef): CfnAppMonitorLogsMixin;
}
/**
 * Creates a CloudWatch RUM app monitor, which you can use to collect telemetry data from your application and send it to CloudWatch RUM.
 *
 * The data includes performance and reliability information such as page load time, client-side errors, and user behavior.
 *
 * After you create an app monitor, sign in to the CloudWatch RUM console to get the JavaScript code snippet to add to your web application. For more information, see [How do I find a code snippet that I've already generated?](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/CloudWatch-RUM-find-code-snippet.html)
 *
 * @cloudformationResource AWS::RUM::AppMonitor
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rum-appmonitor.html
 */
export declare class CfnAppMonitorLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly RUM_TELEMETRY_LOGS: CfnAppMonitorRumTelemetryLogs;
    static readonly RUM_OTEL_LOGS: CfnAppMonitorRumOtelLogs;
    static readonly RUM_OTEL_SPANS: CfnAppMonitorRumOtelSpans;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::RUM::AppMonitor`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAppMonitor;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnAppMonitorRumTelemetryLogs.
 */
export declare class CfnAppMonitorRumTelemetryLogsOutputFormat {
}
export declare namespace CfnAppMonitorRumTelemetryLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export interface CfnAppMonitorRumTelemetryLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnAppMonitorRumTelemetryLogsOutputFormat.S3;
}
export interface CfnAppMonitorRumTelemetryLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnAppMonitorRumTelemetryLogsOutputFormat.LogGroup;
}
export interface CfnAppMonitorRumTelemetryLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnAppMonitorRumTelemetryLogsOutputFormat.Firehose;
}
/**
 * Output Format options for each destination of CfnAppMonitorRumOtelLogs.
 */
export declare class CfnAppMonitorRumOtelLogsOutputFormat {
}
export declare namespace CfnAppMonitorRumOtelLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export interface CfnAppMonitorRumOtelLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnAppMonitorRumOtelLogsOutputFormat.S3;
}
export interface CfnAppMonitorRumOtelLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnAppMonitorRumOtelLogsOutputFormat.LogGroup;
}
export interface CfnAppMonitorRumOtelLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnAppMonitorRumOtelLogsOutputFormat.Firehose;
}
/**
 * Output Format options for each destination of CfnAppMonitorRumOtelSpans.
 */
export declare class CfnAppMonitorRumOtelSpansOutputFormat {
}
export declare namespace CfnAppMonitorRumOtelSpansOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export interface CfnAppMonitorRumOtelSpansS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnAppMonitorRumOtelSpansOutputFormat.S3;
}
export interface CfnAppMonitorRumOtelSpansLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnAppMonitorRumOtelSpansOutputFormat.LogGroup;
}
export interface CfnAppMonitorRumOtelSpansFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnAppMonitorRumOtelSpansOutputFormat.Firehose;
}
