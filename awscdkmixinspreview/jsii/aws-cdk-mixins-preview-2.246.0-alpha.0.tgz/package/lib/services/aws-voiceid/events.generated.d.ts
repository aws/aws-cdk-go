import * as cdk from "aws-cdk-lib/core";
import * as service from "aws-cdk-lib/aws-voiceid";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.voiceid@VoiceIdBatchFraudsterRegistrationAction
 */
export declare class VoiceIdBatchFraudsterRegistrationAction {
    /**
     * EventBridge event pattern for VoiceId Batch Fraudster Registration Action
     */
    static voiceIdBatchFraudsterRegistrationActionPattern(options?: VoiceIdBatchFraudsterRegistrationAction.VoiceIdBatchFraudsterRegistrationActionProps): events.EventPattern;
}
export declare namespace VoiceIdBatchFraudsterRegistrationAction {
    /**
     * Props type for aws.voiceid@VoiceIdBatchFraudsterRegistrationAction event
     */
    interface VoiceIdBatchFraudsterRegistrationActionProps {
        /**
         * data property
         *
         * Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly data?: VoiceIdBatchFraudsterRegistrationAction.Data;
        /**
         * errorInfo property
         *
         * Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorInfo?: VoiceIdBatchFraudsterRegistrationAction.ErrorInfo;
        /**
         * action property
         *
         * Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly action?: Array<string>;
        /**
         * batchJobId property
         *
         * Specify an array of string values to match this event if the actual value of batchJobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly batchJobId?: Array<string>;
        /**
         * domainId property
         *
         * Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Domain reference
         */
        readonly domainId?: Array<string>;
        /**
         * sourceId property
         *
         * Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Data
     *
     * @struct
     */
    interface Data {
        /**
         * inputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputDataConfig?: VoiceIdBatchFraudsterRegistrationAction.InputDataConfig;
        /**
         * outputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputDataConfig?: VoiceIdBatchFraudsterRegistrationAction.OutputDataConfig;
        /**
         * registrationConfig property
         *
         * Specify an array of string values to match this event if the actual value of registrationConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly registrationConfig?: VoiceIdBatchFraudsterRegistrationAction.RegistrationConfig;
        /**
         * dataAccessRoleArn property
         *
         * Specify an array of string values to match this event if the actual value of dataAccessRoleArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataAccessRoleArn?: Array<string>;
    }
    /**
     * Type definition for InputDataConfig
     *
     * @struct
     */
    interface InputDataConfig {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
    /**
     * Type definition for OutputDataConfig
     *
     * @struct
     */
    interface OutputDataConfig {
        /**
         * kmsKeyId property
         *
         * Specify an array of string values to match this event if the actual value of kmsKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly kmsKeyId?: Array<string>;
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
    /**
     * Type definition for RegistrationConfig
     *
     * @struct
     */
    interface RegistrationConfig {
        /**
         * duplicateRegistrationAction property
         *
         * Specify an array of string values to match this event if the actual value of duplicateRegistrationAction is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly duplicateRegistrationAction?: Array<string>;
        /**
         * fraudsterSimilarityThreshold property
         *
         * Specify an array of string values to match this event if the actual value of fraudsterSimilarityThreshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fraudsterSimilarityThreshold?: Array<string>;
        /**
         * watchlistIds property
         *
         * Specify an array of string values to match this event if the actual value of watchlistIds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly watchlistIds?: Array<string>;
    }
    /**
     * Type definition for ErrorInfo
     *
     * @struct
     */
    interface ErrorInfo {
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * errorType property
         *
         * Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorType?: Array<string>;
    }
}
/**
 * EventBridge event patterns for Domain
 */
export declare class DomainEvents {
    /**
     * Create DomainEvents from a Domain reference
     */
    static fromDomain(domainRef: service.IDomainRef): DomainEvents;
    /**
     * Reference to the Domain construct
     */
    private readonly domainRef;
    private constructor();
    /**
     * EventBridge event pattern for Domain VoiceId Batch Fraudster Registration Action
     */
    voiceIdBatchFraudsterRegistrationActionPattern(options?: VoiceIdBatchFraudsterRegistrationAction.VoiceIdBatchFraudsterRegistrationActionProps): events.EventPattern;
    /**
     * EventBridge event pattern for Domain VoiceId Batch Speaker Enrollment Action
     */
    voiceIdBatchSpeakerEnrollmentActionPattern(options?: VoiceIdBatchSpeakerEnrollmentAction.VoiceIdBatchSpeakerEnrollmentActionProps): events.EventPattern;
    /**
     * EventBridge event pattern for Domain VoiceId Evaluate Session Action
     */
    voiceIdEvaluateSessionActionPattern(options?: VoiceIdEvaluateSessionAction.VoiceIdEvaluateSessionActionProps): events.EventPattern;
    /**
     * EventBridge event pattern for Domain VoiceId Fraudster Action
     */
    voiceIdFraudsterActionPattern(options?: VoiceIdFraudsterAction.VoiceIdFraudsterActionProps): events.EventPattern;
    /**
     * EventBridge event pattern for Domain VoiceId Session Speaker Enrollment Action
     */
    voiceIdSessionSpeakerEnrollmentActionPattern(options?: VoiceIdSessionSpeakerEnrollmentAction.VoiceIdSessionSpeakerEnrollmentActionProps): events.EventPattern;
    /**
     * EventBridge event pattern for Domain VoiceId Speaker Action
     */
    voiceIdSpeakerActionPattern(options?: VoiceIdSpeakerAction.VoiceIdSpeakerActionProps): events.EventPattern;
    /**
     * EventBridge event pattern for Domain VoiceId Start Session Action
     */
    voiceIdStartSessionActionPattern(options?: VoiceIdStartSessionAction.VoiceIdStartSessionActionProps): events.EventPattern;
    /**
     * EventBridge event pattern for Domain VoiceId Update Session Action
     */
    voiceIdUpdateSessionActionPattern(options?: VoiceIdUpdateSessionAction.VoiceIdUpdateSessionActionProps): events.EventPattern;
}
/**
 * EventBridge event pattern for aws.voiceid@VoiceIdBatchSpeakerEnrollmentAction
 */
export declare class VoiceIdBatchSpeakerEnrollmentAction {
    /**
     * EventBridge event pattern for VoiceId Batch Speaker Enrollment Action
     */
    static voiceIdBatchSpeakerEnrollmentActionPattern(options?: VoiceIdBatchSpeakerEnrollmentAction.VoiceIdBatchSpeakerEnrollmentActionProps): events.EventPattern;
}
export declare namespace VoiceIdBatchSpeakerEnrollmentAction {
    /**
     * Props type for aws.voiceid@VoiceIdBatchSpeakerEnrollmentAction event
     */
    interface VoiceIdBatchSpeakerEnrollmentActionProps {
        /**
         * data property
         *
         * Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly data?: VoiceIdBatchSpeakerEnrollmentAction.Data;
        /**
         * errorInfo property
         *
         * Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorInfo?: VoiceIdBatchSpeakerEnrollmentAction.ErrorInfo;
        /**
         * action property
         *
         * Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly action?: Array<string>;
        /**
         * batchJobId property
         *
         * Specify an array of string values to match this event if the actual value of batchJobId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly batchJobId?: Array<string>;
        /**
         * domainId property
         *
         * Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Domain reference
         */
        readonly domainId?: Array<string>;
        /**
         * sourceId property
         *
         * Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Data
     *
     * @struct
     */
    interface Data {
        /**
         * enrollmentConfig property
         *
         * Specify an array of string values to match this event if the actual value of enrollmentConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly enrollmentConfig?: VoiceIdBatchSpeakerEnrollmentAction.EnrollmentConfig;
        /**
         * inputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly inputDataConfig?: VoiceIdBatchSpeakerEnrollmentAction.InputDataConfig;
        /**
         * outputDataConfig property
         *
         * Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly outputDataConfig?: VoiceIdBatchSpeakerEnrollmentAction.OutputDataConfig;
        /**
         * dataAccessRoleArn property
         *
         * Specify an array of string values to match this event if the actual value of dataAccessRoleArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly dataAccessRoleArn?: Array<string>;
    }
    /**
     * Type definition for EnrollmentConfig
     *
     * @struct
     */
    interface EnrollmentConfig {
        /**
         * fraudDetectionConfig property
         *
         * Specify an array of string values to match this event if the actual value of fraudDetectionConfig is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fraudDetectionConfig?: VoiceIdBatchSpeakerEnrollmentAction.FraudDetectionConfig;
        /**
         * existingEnrollmentAction property
         *
         * Specify an array of string values to match this event if the actual value of existingEnrollmentAction is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly existingEnrollmentAction?: Array<string>;
    }
    /**
     * Type definition for FraudDetectionConfig
     *
     * @struct
     */
    interface FraudDetectionConfig {
        /**
         * fraudDetectionAction property
         *
         * Specify an array of string values to match this event if the actual value of fraudDetectionAction is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fraudDetectionAction?: Array<string>;
        /**
         * fraudDetectionThreshold property
         *
         * Specify an array of string values to match this event if the actual value of fraudDetectionThreshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fraudDetectionThreshold?: Array<string>;
        /**
         * watchlistIds property
         *
         * Specify an array of string values to match this event if the actual value of watchlistIds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly watchlistIds?: Array<string>;
    }
    /**
     * Type definition for InputDataConfig
     *
     * @struct
     */
    interface InputDataConfig {
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
    /**
     * Type definition for OutputDataConfig
     *
     * @struct
     */
    interface OutputDataConfig {
        /**
         * kmsKeyId property
         *
         * Specify an array of string values to match this event if the actual value of kmsKeyId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly kmsKeyId?: Array<string>;
        /**
         * s3Uri property
         *
         * Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly s3Uri?: Array<string>;
    }
    /**
     * Type definition for ErrorInfo
     *
     * @struct
     */
    interface ErrorInfo {
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * errorType property
         *
         * Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorType?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.voiceid@VoiceIdEvaluateSessionAction
 */
export declare class VoiceIdEvaluateSessionAction {
    /**
     * EventBridge event pattern for VoiceId Evaluate Session Action
     */
    static voiceIdEvaluateSessionActionPattern(options?: VoiceIdEvaluateSessionAction.VoiceIdEvaluateSessionActionProps): events.EventPattern;
}
export declare namespace VoiceIdEvaluateSessionAction {
    /**
     * Props type for aws.voiceid@VoiceIdEvaluateSessionAction event
     */
    interface VoiceIdEvaluateSessionActionProps {
        /**
         * errorInfo property
         *
         * Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorInfo?: VoiceIdEvaluateSessionAction.ErrorInfo;
        /**
         * session property
         *
         * Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly session?: VoiceIdEvaluateSessionAction.Session;
        /**
         * systemAttributes property
         *
         * Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly systemAttributes?: VoiceIdEvaluateSessionAction.SystemAttributes;
        /**
         * action property
         *
         * Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly action?: Array<string>;
        /**
         * domainId property
         *
         * Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Domain reference
         */
        readonly domainId?: Array<string>;
        /**
         * sourceId property
         *
         * Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ErrorInfo
     *
     * @struct
     */
    interface ErrorInfo {
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * errorType property
         *
         * Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorType?: Array<string>;
    }
    /**
     * Type definition for Session
     *
     * @struct
     */
    interface Session {
        /**
         * authenticationResult property
         *
         * Specify an array of string values to match this event if the actual value of authenticationResult is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly authenticationResult?: VoiceIdEvaluateSessionAction.AuthenticationResult;
        /**
         * fraudDetectionResult property
         *
         * Specify an array of string values to match this event if the actual value of fraudDetectionResult is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fraudDetectionResult?: VoiceIdEvaluateSessionAction.FraudDetectionResult;
        /**
         * generatedSpeakerId property
         *
         * Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly generatedSpeakerId?: Array<string>;
        /**
         * sessionId property
         *
         * Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * sessionName property
         *
         * Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionName?: Array<string>;
        /**
         * streamingStatus property
         *
         * Specify an array of string values to match this event if the actual value of streamingStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly streamingStatus?: Array<string>;
    }
    /**
     * Type definition for AuthenticationResult
     *
     * @struct
     */
    interface AuthenticationResult {
        /**
         * configuration property
         *
         * Specify an array of string values to match this event if the actual value of configuration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly configuration?: VoiceIdEvaluateSessionAction.ConfigurationAuthentication;
        /**
         * audioAggregationEndedAt property
         *
         * Specify an array of string values to match this event if the actual value of audioAggregationEndedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly audioAggregationEndedAt?: Array<string>;
        /**
         * audioAggregationStartedAt property
         *
         * Specify an array of string values to match this event if the actual value of audioAggregationStartedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly audioAggregationStartedAt?: Array<string>;
        /**
         * authenticationResultId property
         *
         * Specify an array of string values to match this event if the actual value of authenticationResultId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly authenticationResultId?: Array<string>;
        /**
         * decision property
         *
         * Specify an array of string values to match this event if the actual value of decision is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly decision?: Array<string>;
        /**
         * score property
         *
         * Specify an array of string values to match this event if the actual value of score is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly score?: Array<string>;
    }
    /**
     * Type definition for Configuration_Authentication
     *
     * @struct
     */
    interface ConfigurationAuthentication {
        /**
         * acceptanceThreshold property
         *
         * Specify an array of string values to match this event if the actual value of acceptanceThreshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly acceptanceThreshold?: Array<string>;
    }
    /**
     * Type definition for FraudDetectionResult
     *
     * @struct
     */
    interface FraudDetectionResult {
        /**
         * configuration property
         *
         * Specify an array of string values to match this event if the actual value of configuration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly configuration?: VoiceIdEvaluateSessionAction.ConfigurationFraud;
        /**
         * riskDetails property
         *
         * Specify an array of string values to match this event if the actual value of riskDetails is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly riskDetails?: VoiceIdEvaluateSessionAction.RiskDetails;
        /**
         * audioAggregationEndedAt property
         *
         * Specify an array of string values to match this event if the actual value of audioAggregationEndedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly audioAggregationEndedAt?: Array<string>;
        /**
         * audioAggregationStartedAt property
         *
         * Specify an array of string values to match this event if the actual value of audioAggregationStartedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly audioAggregationStartedAt?: Array<string>;
        /**
         * decision property
         *
         * Specify an array of string values to match this event if the actual value of decision is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly decision?: Array<string>;
        /**
         * fraudDetectionResultId property
         *
         * Specify an array of string values to match this event if the actual value of fraudDetectionResultId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fraudDetectionResultId?: Array<string>;
        /**
         * reasons property
         *
         * Specify an array of string values to match this event if the actual value of reasons is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reasons?: Array<string>;
    }
    /**
     * Type definition for Configuration_Fraud
     *
     * @struct
     */
    interface ConfigurationFraud {
        /**
         * riskThreshold property
         *
         * Specify an array of string values to match this event if the actual value of riskThreshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly riskThreshold?: Array<string>;
        /**
         * watchlistId property
         *
         * Specify an array of string values to match this event if the actual value of watchlistId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly watchlistId?: Array<string>;
    }
    /**
     * Type definition for RiskDetails
     *
     * @struct
     */
    interface RiskDetails {
        /**
         * knownFraudsterRisk property
         *
         * Specify an array of string values to match this event if the actual value of knownFraudsterRisk is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly knownFraudsterRisk?: VoiceIdEvaluateSessionAction.KnownFraudsterRisk;
        /**
         * voiceSpoofingRisk property
         *
         * Specify an array of string values to match this event if the actual value of voiceSpoofingRisk is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly voiceSpoofingRisk?: VoiceIdEvaluateSessionAction.VoiceSpoofingRisk;
    }
    /**
     * Type definition for KnownFraudsterRisk
     *
     * @struct
     */
    interface KnownFraudsterRisk {
        /**
         * generatedFraudsterId property
         *
         * Specify an array of string values to match this event if the actual value of generatedFraudsterId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly generatedFraudsterId?: Array<string>;
        /**
         * riskScore property
         *
         * Specify an array of string values to match this event if the actual value of riskScore is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly riskScore?: Array<string>;
    }
    /**
     * Type definition for VoiceSpoofingRisk
     *
     * @struct
     */
    interface VoiceSpoofingRisk {
        /**
         * riskScore property
         *
         * Specify an array of string values to match this event if the actual value of riskScore is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly riskScore?: Array<string>;
    }
    /**
     * Type definition for SystemAttributes
     *
     * @struct
     */
    interface SystemAttributes {
        /**
         * aws-connect-OriginalContactArn property
         *
         * Specify an array of string values to match this event if the actual value of aws-connect-OriginalContactArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsConnectOriginalContactArn?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.voiceid@VoiceIdFraudsterAction
 */
export declare class VoiceIdFraudsterAction {
    /**
     * EventBridge event pattern for VoiceId Fraudster Action
     */
    static voiceIdFraudsterActionPattern(options?: VoiceIdFraudsterAction.VoiceIdFraudsterActionProps): events.EventPattern;
}
export declare namespace VoiceIdFraudsterAction {
    /**
     * Props type for aws.voiceid@VoiceIdFraudsterAction event
     */
    interface VoiceIdFraudsterActionProps {
        /**
         * data property
         *
         * Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly data?: VoiceIdFraudsterAction.Data;
        /**
         * errorInfo property
         *
         * Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorInfo?: VoiceIdFraudsterAction.ErrorInfo;
        /**
         * action property
         *
         * Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly action?: Array<string>;
        /**
         * domainId property
         *
         * Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Domain reference
         */
        readonly domainId?: Array<string>;
        /**
         * generatedFraudsterId property
         *
         * Specify an array of string values to match this event if the actual value of generatedFraudsterId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly generatedFraudsterId?: Array<string>;
        /**
         * sourceId property
         *
         * Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * watchlistIds property
         *
         * Specify an array of string values to match this event if the actual value of watchlistIds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly watchlistIds?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Data
     *
     * @struct
     */
    interface Data {
        /**
         * registrationSource property
         *
         * Specify an array of string values to match this event if the actual value of registrationSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly registrationSource?: Array<string>;
        /**
         * registrationSourceId property
         *
         * Specify an array of string values to match this event if the actual value of registrationSourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly registrationSourceId?: Array<string>;
        /**
         * registrationStatus property
         *
         * Specify an array of string values to match this event if the actual value of registrationStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly registrationStatus?: Array<string>;
    }
    /**
     * Type definition for ErrorInfo
     *
     * @struct
     */
    interface ErrorInfo {
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * errorType property
         *
         * Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorType?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.voiceid@VoiceIdSessionSpeakerEnrollmentAction
 */
export declare class VoiceIdSessionSpeakerEnrollmentAction {
    /**
     * EventBridge event pattern for VoiceId Session Speaker Enrollment Action
     */
    static voiceIdSessionSpeakerEnrollmentActionPattern(options?: VoiceIdSessionSpeakerEnrollmentAction.VoiceIdSessionSpeakerEnrollmentActionProps): events.EventPattern;
}
export declare namespace VoiceIdSessionSpeakerEnrollmentAction {
    /**
     * Props type for aws.voiceid@VoiceIdSessionSpeakerEnrollmentAction event
     */
    interface VoiceIdSessionSpeakerEnrollmentActionProps {
        /**
         * errorInfo property
         *
         * Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorInfo?: VoiceIdSessionSpeakerEnrollmentAction.ErrorInfo;
        /**
         * systemAttributes property
         *
         * Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly systemAttributes?: VoiceIdSessionSpeakerEnrollmentAction.SystemAttributes;
        /**
         * action property
         *
         * Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly action?: Array<string>;
        /**
         * domainId property
         *
         * Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Domain reference
         */
        readonly domainId?: Array<string>;
        /**
         * sessionId property
         *
         * Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * sessionName property
         *
         * Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionName?: Array<string>;
        /**
         * sourceId property
         *
         * Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ErrorInfo
     *
     * @struct
     */
    interface ErrorInfo {
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * errorType property
         *
         * Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorType?: Array<string>;
    }
    /**
     * Type definition for SystemAttributes
     *
     * @struct
     */
    interface SystemAttributes {
        /**
         * aws-connect-OriginalContactArn property
         *
         * Specify an array of string values to match this event if the actual value of aws-connect-OriginalContactArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsConnectOriginalContactArn?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.voiceid@VoiceIdSpeakerAction
 */
export declare class VoiceIdSpeakerAction {
    /**
     * EventBridge event pattern for VoiceId Speaker Action
     */
    static voiceIdSpeakerActionPattern(options?: VoiceIdSpeakerAction.VoiceIdSpeakerActionProps): events.EventPattern;
}
export declare namespace VoiceIdSpeakerAction {
    /**
     * Props type for aws.voiceid@VoiceIdSpeakerAction event
     */
    interface VoiceIdSpeakerActionProps {
        /**
         * data property
         *
         * Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly data?: VoiceIdSpeakerAction.Data;
        /**
         * errorInfo property
         *
         * Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorInfo?: VoiceIdSpeakerAction.ErrorInfo;
        /**
         * systemAttributes property
         *
         * Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly systemAttributes?: VoiceIdSpeakerAction.SystemAttributes;
        /**
         * action property
         *
         * Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly action?: Array<string>;
        /**
         * domainId property
         *
         * Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Domain reference
         */
        readonly domainId?: Array<string>;
        /**
         * generatedSpeakerId property
         *
         * Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly generatedSpeakerId?: Array<string>;
        /**
         * sourceId property
         *
         * Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Data
     *
     * @struct
     */
    interface Data {
        /**
         * enrollmentSource property
         *
         * Specify an array of string values to match this event if the actual value of enrollmentSource is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly enrollmentSource?: Array<string>;
        /**
         * enrollmentSourceId property
         *
         * Specify an array of string values to match this event if the actual value of enrollmentSourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly enrollmentSourceId?: Array<string>;
        /**
         * enrollmentStatus property
         *
         * Specify an array of string values to match this event if the actual value of enrollmentStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly enrollmentStatus?: Array<string>;
    }
    /**
     * Type definition for ErrorInfo
     *
     * @struct
     */
    interface ErrorInfo {
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * errorType property
         *
         * Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorType?: Array<string>;
    }
    /**
     * Type definition for SystemAttributes
     *
     * @struct
     */
    interface SystemAttributes {
        /**
         * aws-connect-OriginalContactArn property
         *
         * Specify an array of string values to match this event if the actual value of aws-connect-OriginalContactArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsConnectOriginalContactArn?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.voiceid@VoiceIdStartSessionAction
 */
export declare class VoiceIdStartSessionAction {
    /**
     * EventBridge event pattern for VoiceId Start Session Action
     */
    static voiceIdStartSessionActionPattern(options?: VoiceIdStartSessionAction.VoiceIdStartSessionActionProps): events.EventPattern;
}
export declare namespace VoiceIdStartSessionAction {
    /**
     * Props type for aws.voiceid@VoiceIdStartSessionAction event
     */
    interface VoiceIdStartSessionActionProps {
        /**
         * errorInfo property
         *
         * Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorInfo?: VoiceIdStartSessionAction.ErrorInfo;
        /**
         * session property
         *
         * Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly session?: VoiceIdStartSessionAction.Session;
        /**
         * systemAttributes property
         *
         * Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly systemAttributes?: VoiceIdStartSessionAction.SystemAttributes;
        /**
         * action property
         *
         * Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly action?: Array<string>;
        /**
         * domainId property
         *
         * Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Domain reference
         */
        readonly domainId?: Array<string>;
        /**
         * sourceId property
         *
         * Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ErrorInfo
     *
     * @struct
     */
    interface ErrorInfo {
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * errorType property
         *
         * Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorType?: Array<string>;
    }
    /**
     * Type definition for Session
     *
     * @struct
     */
    interface Session {
        /**
         * authenticationAudioProgress property
         *
         * Specify an array of string values to match this event if the actual value of authenticationAudioProgress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly authenticationAudioProgress?: VoiceIdStartSessionAction.AuthenticationAudioProgress;
        /**
         * authenticationConfiguration property
         *
         * Specify an array of string values to match this event if the actual value of authenticationConfiguration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly authenticationConfiguration?: VoiceIdStartSessionAction.AuthenticationConfiguration;
        /**
         * enrollmentAudioProgress property
         *
         * Specify an array of string values to match this event if the actual value of enrollmentAudioProgress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly enrollmentAudioProgress?: VoiceIdStartSessionAction.EnrollmentAudioProgress;
        /**
         * fraudDetectionAudioProgress property
         *
         * Specify an array of string values to match this event if the actual value of fraudDetectionAudioProgress is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fraudDetectionAudioProgress?: VoiceIdStartSessionAction.AuthenticationAudioProgress;
        /**
         * fraudDetectionConfiguration property
         *
         * Specify an array of string values to match this event if the actual value of fraudDetectionConfiguration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fraudDetectionConfiguration?: VoiceIdStartSessionAction.FraudDetectionConfiguration;
        /**
         * streamingConfiguration property
         *
         * Specify an array of string values to match this event if the actual value of streamingConfiguration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly streamingConfiguration?: VoiceIdStartSessionAction.StreamingConfiguration;
        /**
         * generatedSpeakerId property
         *
         * Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly generatedSpeakerId?: Array<string>;
        /**
         * sessionId property
         *
         * Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * sessionName property
         *
         * Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionName?: Array<string>;
    }
    /**
     * Type definition for AuthenticationAudioProgress
     *
     * @struct
     */
    interface AuthenticationAudioProgress {
        /**
         * audioAggregationEndedAt property
         *
         * Specify an array of string values to match this event if the actual value of audioAggregationEndedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly audioAggregationEndedAt?: Array<string>;
        /**
         * audioAggregationStartedAt property
         *
         * Specify an array of string values to match this event if the actual value of audioAggregationStartedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly audioAggregationStartedAt?: Array<string>;
    }
    /**
     * Type definition for AuthenticationConfiguration
     *
     * @struct
     */
    interface AuthenticationConfiguration {
        /**
         * acceptanceThreshold property
         *
         * Specify an array of string values to match this event if the actual value of acceptanceThreshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly acceptanceThreshold?: Array<string>;
    }
    /**
     * Type definition for EnrollmentAudioProgress
     *
     * @struct
     */
    interface EnrollmentAudioProgress {
        /**
         * audioAggregationEndedAt property
         *
         * Specify an array of string values to match this event if the actual value of audioAggregationEndedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly audioAggregationEndedAt?: Array<string>;
        /**
         * audioAggregationStartedAt property
         *
         * Specify an array of string values to match this event if the actual value of audioAggregationStartedAt is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly audioAggregationStartedAt?: Array<string>;
        /**
         * audioAggregationStatus property
         *
         * Specify an array of string values to match this event if the actual value of audioAggregationStatus is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly audioAggregationStatus?: Array<string>;
    }
    /**
     * Type definition for FraudDetectionConfiguration
     *
     * @struct
     */
    interface FraudDetectionConfiguration {
        /**
         * riskThreshold property
         *
         * Specify an array of string values to match this event if the actual value of riskThreshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly riskThreshold?: Array<string>;
        /**
         * watchlistId property
         *
         * Specify an array of string values to match this event if the actual value of watchlistId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly watchlistId?: Array<string>;
    }
    /**
     * Type definition for StreamingConfiguration
     *
     * @struct
     */
    interface StreamingConfiguration {
        /**
         * authenticationMinimumSpeechInSeconds property
         *
         * Specify an array of string values to match this event if the actual value of authenticationMinimumSpeechInSeconds is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly authenticationMinimumSpeechInSeconds?: Array<string>;
    }
    /**
     * Type definition for SystemAttributes
     *
     * @struct
     */
    interface SystemAttributes {
        /**
         * aws-connect-OriginalContactArn property
         *
         * Specify an array of string values to match this event if the actual value of aws-connect-OriginalContactArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly awsConnectOriginalContactArn?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.voiceid@VoiceIdUpdateSessionAction
 */
export declare class VoiceIdUpdateSessionAction {
    /**
     * EventBridge event pattern for VoiceId Update Session Action
     */
    static voiceIdUpdateSessionActionPattern(options?: VoiceIdUpdateSessionAction.VoiceIdUpdateSessionActionProps): events.EventPattern;
}
export declare namespace VoiceIdUpdateSessionAction {
    /**
     * Props type for aws.voiceid@VoiceIdUpdateSessionAction event
     */
    interface VoiceIdUpdateSessionActionProps {
        /**
         * errorInfo property
         *
         * Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorInfo?: VoiceIdUpdateSessionAction.ErrorInfo;
        /**
         * session property
         *
         * Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly session?: VoiceIdUpdateSessionAction.Session;
        /**
         * action property
         *
         * Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly action?: Array<string>;
        /**
         * domainId property
         *
         * Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Filter with the Domain reference
         */
        readonly domainId?: Array<string>;
        /**
         * sourceId property
         *
         * Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceId?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for ErrorInfo
     *
     * @struct
     */
    interface ErrorInfo {
        /**
         * errorCode property
         *
         * Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorCode?: Array<string>;
        /**
         * errorMessage property
         *
         * Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorMessage?: Array<string>;
        /**
         * errorType property
         *
         * Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly errorType?: Array<string>;
    }
    /**
     * Type definition for Session
     *
     * @struct
     */
    interface Session {
        /**
         * authenticationConfiguration property
         *
         * Specify an array of string values to match this event if the actual value of authenticationConfiguration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly authenticationConfiguration?: VoiceIdUpdateSessionAction.AuthenticationConfiguration;
        /**
         * fraudDetectionConfiguration property
         *
         * Specify an array of string values to match this event if the actual value of fraudDetectionConfiguration is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly fraudDetectionConfiguration?: VoiceIdUpdateSessionAction.FraudDetectionConfiguration;
        /**
         * generatedSpeakerId property
         *
         * Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly generatedSpeakerId?: Array<string>;
        /**
         * sessionId property
         *
         * Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionId?: Array<string>;
        /**
         * sessionName property
         *
         * Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sessionName?: Array<string>;
    }
    /**
     * Type definition for AuthenticationConfiguration
     *
     * @struct
     */
    interface AuthenticationConfiguration {
        /**
         * acceptanceThreshold property
         *
         * Specify an array of string values to match this event if the actual value of acceptanceThreshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly acceptanceThreshold?: Array<string>;
    }
    /**
     * Type definition for FraudDetectionConfiguration
     *
     * @struct
     */
    interface FraudDetectionConfiguration {
        /**
         * riskThreshold property
         *
         * Specify an array of string values to match this event if the actual value of riskThreshold is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly riskThreshold?: Array<string>;
        /**
         * watchlistId property
         *
         * Specify an array of string values to match this event if the actual value of watchlistId is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly watchlistId?: Array<string>;
    }
}
