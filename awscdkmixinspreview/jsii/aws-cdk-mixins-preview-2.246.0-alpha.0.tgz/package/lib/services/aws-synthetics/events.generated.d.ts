import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.synthetics@SyntheticsCanaryStatusChange
 */
export declare class SyntheticsCanaryStatusChange {
    /**
     * EventBridge event pattern for Synthetics Canary Status Change
     */
    static syntheticsCanaryStatusChangePattern(options?: SyntheticsCanaryStatusChange.SyntheticsCanaryStatusChangeProps): events.EventPattern;
}
export declare namespace SyntheticsCanaryStatusChange {
    /**
     * Props type for aws.synthetics@SyntheticsCanaryStatusChange event
     */
    interface SyntheticsCanaryStatusChangeProps {
        /**
         * changed-config property
         *
         * Specify an array of string values to match this event if the actual value of changed-config is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly changedConfig?: SyntheticsCanaryStatusChange.ChangedConfig;
        /**
         * account-id property
         *
         * Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * canary-id property
         *
         * Specify an array of string values to match this event if the actual value of canary-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly canaryId?: Array<string>;
        /**
         * canary-name property
         *
         * Specify an array of string values to match this event if the actual value of canary-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly canaryName?: Array<string>;
        /**
         * current-state property
         *
         * Specify an array of string values to match this event if the actual value of current-state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentState?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * previous-state property
         *
         * Specify an array of string values to match this event if the actual value of previous-state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousState?: Array<string>;
        /**
         * source-location property
         *
         * Specify an array of string values to match this event if the actual value of source-location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly sourceLocation?: Array<string>;
        /**
         * updated-on property
         *
         * Specify an array of string values to match this event if the actual value of updated-on is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly updatedOn?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Changed-config
     *
     * @struct
     */
    interface ChangedConfig {
        /**
         * executionArn property
         *
         * Specify an array of string values to match this event if the actual value of executionArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly executionArn?: SyntheticsCanaryStatusChange.ExecutionArn;
        /**
         * testCodeLayerVersionArn property
         *
         * Specify an array of string values to match this event if the actual value of testCodeLayerVersionArn is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly testCodeLayerVersionArn?: SyntheticsCanaryStatusChange.TestCodeLayerVersionArn;
    }
    /**
     * Type definition for ExecutionArn
     *
     * @struct
     */
    interface ExecutionArn {
        /**
         * current-value property
         *
         * Specify an array of string values to match this event if the actual value of current-value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentValue?: Array<string>;
        /**
         * previous-value property
         *
         * Specify an array of string values to match this event if the actual value of previous-value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousValue?: Array<string>;
    }
    /**
     * Type definition for TestCodeLayerVersionArn
     *
     * @struct
     */
    interface TestCodeLayerVersionArn {
        /**
         * current-value property
         *
         * Specify an array of string values to match this event if the actual value of current-value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly currentValue?: Array<string>;
        /**
         * previous-value property
         *
         * Specify an array of string values to match this event if the actual value of previous-value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly previousValue?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.synthetics@SyntheticsCanaryTestRunFailure
 */
export declare class SyntheticsCanaryTestRunFailure {
    /**
     * EventBridge event pattern for Synthetics Canary TestRun Failure
     */
    static syntheticsCanaryTestRunFailurePattern(options?: SyntheticsCanaryTestRunFailure.SyntheticsCanaryTestRunFailureProps): events.EventPattern;
}
export declare namespace SyntheticsCanaryTestRunFailure {
    /**
     * Props type for aws.synthetics@SyntheticsCanaryTestRunFailure event
     */
    interface SyntheticsCanaryTestRunFailureProps {
        /**
         * canary-run-timeline property
         *
         * Specify an array of string values to match this event if the actual value of canary-run-timeline is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly canaryRunTimeline?: SyntheticsCanaryTestRunFailure.CanaryRunTimeline;
        /**
         * account-id property
         *
         * Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * artifact-location property
         *
         * Specify an array of string values to match this event if the actual value of artifact-location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly artifactLocation?: Array<string>;
        /**
         * canary-id property
         *
         * Specify an array of string values to match this event if the actual value of canary-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly canaryId?: Array<string>;
        /**
         * canary-name property
         *
         * Specify an array of string values to match this event if the actual value of canary-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly canaryName?: Array<string>;
        /**
         * canary-run-id property
         *
         * Specify an array of string values to match this event if the actual value of canary-run-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly canaryRunId?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * state-reason property
         *
         * Specify an array of string values to match this event if the actual value of state-reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stateReason?: Array<string>;
        /**
         * test-run-status property
         *
         * Specify an array of string values to match this event if the actual value of test-run-status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly testRunStatus?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Canary-run-timeline
     *
     * @struct
     */
    interface CanaryRunTimeline {
        /**
         * completed property
         *
         * Specify an array of string values to match this event if the actual value of completed is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly completed?: Array<string>;
        /**
         * started property
         *
         * Specify an array of string values to match this event if the actual value of started is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly started?: Array<string>;
    }
}
/**
 * EventBridge event pattern for aws.synthetics@SyntheticsCanaryTestRunSuccessful
 */
export declare class SyntheticsCanaryTestRunSuccessful {
    /**
     * EventBridge event pattern for Synthetics Canary TestRun Successful
     */
    static syntheticsCanaryTestRunSuccessfulPattern(options?: SyntheticsCanaryTestRunSuccessful.SyntheticsCanaryTestRunSuccessfulProps): events.EventPattern;
}
export declare namespace SyntheticsCanaryTestRunSuccessful {
    /**
     * Props type for aws.synthetics@SyntheticsCanaryTestRunSuccessful event
     */
    interface SyntheticsCanaryTestRunSuccessfulProps {
        /**
         * canary-run-timeline property
         *
         * Specify an array of string values to match this event if the actual value of canary-run-timeline is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly canaryRunTimeline?: SyntheticsCanaryTestRunSuccessful.CanaryRunTimeline;
        /**
         * account-id property
         *
         * Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly accountId?: Array<string>;
        /**
         * artifact-location property
         *
         * Specify an array of string values to match this event if the actual value of artifact-location is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly artifactLocation?: Array<string>;
        /**
         * canary-id property
         *
         * Specify an array of string values to match this event if the actual value of canary-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly canaryId?: Array<string>;
        /**
         * canary-name property
         *
         * Specify an array of string values to match this event if the actual value of canary-name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly canaryName?: Array<string>;
        /**
         * canary-run-id property
         *
         * Specify an array of string values to match this event if the actual value of canary-run-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly canaryRunId?: Array<string>;
        /**
         * message property
         *
         * Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly message?: Array<string>;
        /**
         * state-reason property
         *
         * Specify an array of string values to match this event if the actual value of state-reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly stateReason?: Array<string>;
        /**
         * test-run-status property
         *
         * Specify an array of string values to match this event if the actual value of test-run-status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly testRunStatus?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for Canary-run-timeline
     *
     * @struct
     */
    interface CanaryRunTimeline {
        /**
         * completed property
         *
         * Specify an array of string values to match this event if the actual value of completed is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly completed?: Array<string>;
        /**
         * started property
         *
         * Specify an array of string values to match this event if the actual value of started is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly started?: Array<string>;
    }
}
