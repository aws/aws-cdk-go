import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-wafv2";
/**
 * Builder for CfnWebACLLogsMixin to generate ACCESS_LOGS for CfnWebACL
 *
 * @cloudformationResource AWS::WAFv2::WebACL
 * @logType ACCESS_LOGS
 * @stability external
 */
export declare class CfnWebACLAccessLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnWebACLAccessLogsS3Props): CfnWebACLLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnWebACLAccessLogsLogGroupProps): CfnWebACLLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnWebACLAccessLogsFirehoseProps): CfnWebACLLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef): CfnWebACLLogsMixin;
}
/**
 * Builder for CfnWebACLLogsMixin to generate TOKEN_LOGS for CfnWebACL
 *
 * @cloudformationResource AWS::WAFv2::WebACL
 * @logType TOKEN_LOGS
 * @stability external
 */
export declare class CfnWebACLTokenLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnWebACLTokenLogsS3Props): CfnWebACLLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnWebACLTokenLogsLogGroupProps): CfnWebACLLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnWebACLTokenLogsFirehoseProps): CfnWebACLLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef): CfnWebACLLogsMixin;
}
/**
 * > This is the latest version of *AWS WAF* , named AWS WAF V2, released in November, 2019.
 *
 * For information, including how to migrate your AWS WAF resources from the prior release, see the [AWS WAF developer guide](https://docs.aws.amazon.com/waf/latest/developerguide/waf-chapter.html) .
 *
 * Use an `WebACL` to define a collection of rules to use to inspect and control web requests. Each rule in a web ACL has a statement that defines what to look for in web requests and an action that AWS WAF applies to requests that match the statement. In the web ACL, you assign a default action to take (allow, block) for any request that doesn't match any of the rules.
 *
 * The rules in a web ACL can be a combination of explicitly defined rules and rule groups that you reference from the web ACL. The rule groups can be rule groups that you manage or rule groups that are managed by others.
 *
 * You can associate a web ACL with one or more AWS resources to protect. The resources can be an Amazon CloudFront distribution, an  REST API, an Application Load Balancer , an AWS AppSync GraphQL API , an Amazon Cognito user pool, an AWS App Runner service, an AWS Amplify application, or an AWS Verified Access instance.
 *
 * For more information, see [Web access control lists (web ACLs)](https://docs.aws.amazon.com/waf/latest/developerguide/web-acl.html) in the *AWS WAF developer guide* .
 *
 * *Web ACLs used in AWS Shield Advanced automatic application layer DDoS mitigation*
 *
 * If you use Shield Advanced automatic application layer DDoS mitigation, the web ACLs that you use with automatic mitigation have a rule group rule whose name starts with `ShieldMitigationRuleGroup` . This rule is used for automatic mitigations and it's managed for you in the web ACL by Shield Advanced and AWS WAF . You'll see the rule listed among the web ACL rules when you view the web ACL through the AWS WAF interfaces.
 *
 * When you manage the web ACL through CloudFormation interfaces, you won't see the Shield Advanced rule. CloudFormation doesn't include this type of rule in the stack drift status between the actual configuration of the web ACL and your web ACL template.
 *
 * Don't add the Shield Advanced rule group rule to your web ACL template. The rule shouldn't be in your template. When you update the web ACL template in a stack, the Shield Advanced rule is maintained for you by AWS WAF in the resulting web ACL.
 *
 * For more information, see [Shield Advanced automatic application layer DDoS mitigation](https://docs.aws.amazon.com/waf/latest/developerguide/ddos-automatic-app-layer-response.html) in the *AWS Shield Advanced developer guide* .
 *
 * @cloudformationResource AWS::WAFv2::WebACL
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-wafv2-webacl.html
 */
export declare class CfnWebACLLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly ACCESS_LOGS: CfnWebACLAccessLogs;
    static readonly TOKEN_LOGS: CfnWebACLTokenLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::WAFv2::WebACL`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnWebACL;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnWebACLAccessLogs.
 */
export declare class CfnWebACLAccessLogsOutputFormat {
}
export declare namespace CfnWebACLAccessLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export interface CfnWebACLAccessLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnWebACLAccessLogsOutputFormat.S3;
}
export interface CfnWebACLAccessLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnWebACLAccessLogsOutputFormat.LogGroup;
}
export interface CfnWebACLAccessLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnWebACLAccessLogsOutputFormat.Firehose;
}
/**
 * Output Format options for each destination of CfnWebACLTokenLogs.
 */
export declare class CfnWebACLTokenLogsOutputFormat {
}
export declare namespace CfnWebACLTokenLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export interface CfnWebACLTokenLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnWebACLTokenLogsOutputFormat.S3;
}
export interface CfnWebACLTokenLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnWebACLTokenLogsOutputFormat.LogGroup;
}
export interface CfnWebACLTokenLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnWebACLTokenLogsOutputFormat.Firehose;
}
