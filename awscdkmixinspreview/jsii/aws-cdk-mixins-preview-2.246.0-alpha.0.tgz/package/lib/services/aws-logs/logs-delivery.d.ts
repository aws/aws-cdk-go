import * as logs from 'aws-cdk-lib/aws-logs';
import type * as s3 from 'aws-cdk-lib/aws-s3';
import { type IConstruct } from 'constructs';
import type { IDeliveryStreamRef } from 'aws-cdk-lib/aws-kinesisfirehose';
import type { IKeyRef } from 'aws-cdk-lib/aws-kms';
/**
 * The individual elements of a logs delivery integration.
 */
export interface ILogsDeliveryConfig {
    /**
     * The logs delivery source.
     */
    readonly deliverySource: logs.IDeliverySourceRef;
    /**
     *  The logs delivery destination.
     */
    readonly deliveryDestination: logs.IDeliveryDestinationRef;
    /**
     *  The logs delivery
     */
    readonly delivery: logs.IDeliveryRef;
}
/**
 * Represents the delivery of vended logs to a destination.
 */
export interface ILogsDelivery {
    /**
     * Binds the log delivery to a source resource and creates a delivery connection between the source and destination.
     * @param scope - The construct scope
     * @param logType - The type of logs that the delivery source will produce
     * @param sourceResourceArn - The Arn of the source resource
     * @returns The delivery reference
     */
    bind(scope: IConstruct, logType: string, sourceResourceArn: string): ILogsDeliveryConfig;
}
/**
 * Props for RecordFields involved in log delivery
 */
export interface RecordFieldDeliveryProps {
    /**
     * RecordFields the user has defined to be used in log delivery
     *
     * @defualt - no fields were provided
     */
    readonly providedFields?: string[];
    /**
     * Any recordFields that a mandatory to be included in a log delivery of a certain log type
     *
     * @default - log type has no mandatory fields
     */
    readonly mandatoryFields?: string[];
}
/**
 * Props for Log Deliveries
 */
export interface DeliveryProps extends RecordFieldDeliveryProps {
    /**
     * Format of the logs that are sent to the delivery destination specified
     *
     * @defualt - undefined, use whatever default the delivery destination specifies
     */
    readonly outputFormat?: string;
}
/**
 * S3 Vended Logs Permissions version.
 */
export declare enum S3LogsDeliveryPermissionsVersion {
    /**
     * V1
     */
    V1 = "V1",
    /**
     * V2
     */
    V2 = "V2"
}
/**
 * Props for S3LogsDelivery
 */
export interface S3LogsDeliveryProps extends DeliveryProps {
    /**
     * The permissions version ('V1' or 'V2') to be used for this delivery.
     * Depending on the source of the logs, different permissions are required.
     *
     * @default "V2"
     */
    readonly permissionsVersion?: S3LogsDeliveryPermissionsVersion;
    /**
     * KMS key to use for encrypting logs in the S3 bucket.
     * When provided, grants the logs delivery service permissions to use the key.
     *
     * @default - No encryption key is configured
     */
    readonly kmsKey?: IKeyRef;
}
/**
 * Delivers vended logs to an S3 Bucket.
 */
export declare class S3LogsDelivery implements ILogsDelivery {
    private readonly bucket;
    private readonly permissions;
    private readonly kmsKey;
    private readonly outputFormat;
    private readonly providedFields;
    private readonly mandatoryFields;
    /**
     * Creates a new S3 Bucket delivery.
     */
    constructor(bucket: s3.IBucketRef, props?: S3LogsDeliveryProps);
    /**
     * Binds S3 Bucket to a source resource for the purposes of log delivery and creates a delivery source, a delivery destination, and a connection between them.
     */
    bind(scope: IConstruct, logType: string, sourceResourceArn: string): ILogsDeliveryConfig;
}
/**
 * Delivers vended logs to a Firehose Delivery Stream.
 */
export declare class FirehoseLogsDelivery implements ILogsDelivery {
    private readonly deliveryStream;
    private readonly outputFormat;
    private readonly providedFields;
    private readonly mandatoryFields;
    /**
     * Creates a new Firehose delivery.
     * @param stream - The Kinesis Data Firehose delivery stream
     */
    constructor(stream: IDeliveryStreamRef, props?: DeliveryProps);
    /**
     * Binds Firehose Delivery Stream to a source resource for the purposes of log delivery and creates a delivery source, a delivery destination, and a connection between them.
     */
    bind(scope: IConstruct, logType: string, sourceResourceArn: string): ILogsDeliveryConfig;
}
/**
 * Delivers vended logs to a CloudWatch Log Group.
 */
export declare class LogGroupLogsDelivery implements ILogsDelivery {
    private readonly logGroup;
    private readonly outputFormat;
    private readonly providedFields;
    private readonly mandatoryFields;
    /**
     * Creates a new log group delivery.
     * @param logGroup - The CloudWatch Logs log group reference
     */
    constructor(logGroup: logs.ILogGroupRef, props?: DeliveryProps);
    /**
     * Binds Log Group to a source resource for the purposes of log delivery and creates a delivery source, a delivery destination, and a connection between them.
     */
    bind(scope: IConstruct, logType: string, sourceResourceArn: string): ILogsDeliveryConfig;
}
/**
 * Delivers vended logs to AWS X-Ray.
 */
export declare class XRayLogsDelivery implements ILogsDelivery {
    private readonly providedFields;
    private readonly mandatoryFields;
    /**
     * Creates a new X-Ray delivery.
     */
    constructor(props?: RecordFieldDeliveryProps);
    /**
     * Binds X-Ray Destination to a source resource for the purposes of log delivery and creates a delivery source, a delivery destination, and a connection between them.
     */
    bind(scope: IConstruct, logType: string, sourceResourceArn: string): ILogsDeliveryConfig;
}
/**
 * Delivers vended logs to a CfnDeliveryDestination specified by an arn.
 */
export declare class DestinationLogsDelivery implements ILogsDelivery {
    private readonly providedFields;
    private readonly mandatoryFields;
    /**
     * Creates a new Destination delivery.
     */
    private readonly destination;
    constructor(destination: logs.IDeliveryDestinationRef, props?: RecordFieldDeliveryProps);
    /**
     * Binds Delivery Destination to a source resource for the purposes of log delivery and creates a delivery source and a connection between the source and the destination.
     */
    bind(scope: IConstruct, logType: string, sourceResourceArn: string): ILogsDeliveryConfig;
}
