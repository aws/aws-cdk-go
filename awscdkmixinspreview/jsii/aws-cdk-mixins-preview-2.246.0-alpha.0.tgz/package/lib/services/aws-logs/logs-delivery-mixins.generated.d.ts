import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-logs";
/**
 * Builder for CfnLogGroupLogsMixin to generate AUDIT_LOGS for CfnLogGroup
 *
 * @cloudformationResource AWS::Logs::LogGroup
 * @logType AUDIT_LOGS
 * @stability external
 */
export declare class CfnLogGroupAuditLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnLogGroupAuditLogsS3Props): CfnLogGroupLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnLogGroupAuditLogsLogGroupProps): CfnLogGroupLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnLogGroupAuditLogsFirehoseProps): CfnLogGroupLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnLogGroupAuditLogsDestProps): CfnLogGroupLogsMixin;
}
/**
 * The `AWS::Logs::LogGroup` resource specifies a log group.
 *
 * A log group defines common properties for log streams, such as their retention and access control rules. Each log stream must belong to one log group.
 *
 * You can create up to 1,000,000 log groups per Region per account. You must use the following guidelines when naming a log group:
 *
 * - Log group names must be unique within a Region for an AWS account.
 * - Log group names can be between 1 and 512 characters long.
 * - Log group names consist of the following characters: a-z, A-Z, 0-9, '_' (underscore), '-' (hyphen), '/' (forward slash), and '.' (period).
 *
 * @cloudformationResource AWS::Logs::LogGroup
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-logs-loggroup.html
 */
export declare class CfnLogGroupLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly AUDIT_LOGS: CfnLogGroupAuditLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::Logs::LogGroup`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnLogGroup;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnLogGroupAuditLogs.
 */
export declare class CfnLogGroupAuditLogsOutputFormat {
}
export declare namespace CfnLogGroupAuditLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnLogGroupAuditLogsRecordFields {
    POLICYNAME = "policyName",
    CLOUDWATCHLOGS_EVENTTIMESTAMP = "cloudWatchLogs.EventTimestamp",
    CLOUDWATCHLOGS_LOGSTREAM = "cloudWatchLogs.LogStream",
    AUDITTIMESTAMP = "auditTimestamp",
    RESOURCEARN = "resourceArn",
    RESOURCENAME = "resourceName",
    DATAIDENTIFIERS = "dataIdentifiers"
}
export interface CfnLogGroupAuditLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnLogGroupAuditLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLogGroupAuditLogsRecordFields>;
}
export interface CfnLogGroupAuditLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnLogGroupAuditLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLogGroupAuditLogsRecordFields>;
}
export interface CfnLogGroupAuditLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnLogGroupAuditLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLogGroupAuditLogsRecordFields>;
}
export interface CfnLogGroupAuditLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnLogGroupAuditLogsRecordFields>;
}
