import type { IConstruct } from 'constructs';
import type { CfnDeliverySource } from 'aws-cdk-lib/aws-logs';
export declare function tryFindDeliverySourceForResource(source: IConstruct, sourceArn: string, logType: string): CfnDeliverySource | undefined;
