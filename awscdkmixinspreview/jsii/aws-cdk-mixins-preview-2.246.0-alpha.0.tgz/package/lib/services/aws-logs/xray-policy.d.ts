import type { Construct } from 'constructs';
import type { PolicyStatement } from 'aws-cdk-lib/aws-iam';
import { PolicyDocument } from 'aws-cdk-lib/aws-iam';
import { Resource } from 'aws-cdk-lib/core';
/**
 * Properties to define X-Ray resource policy
 */
export interface ResourcePolicyProps {
    /**
     * Name of the log group resource policy
     * @default - Uses a unique id based on the construct path
     */
    readonly resourcePolicyName?: string;
    /**
     * Initial statements to add to the resource policy
     *
     * @default - No statements
     */
    readonly policyStatements?: PolicyStatement[];
}
/**
 * Resource Policy for X-Ray
 *
 * Policies define the operations that are allowed on this resource.
 *
 * @resource AWS::XRay::ResourcePolicy
 */
export declare class ResourcePolicy extends Resource {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * The IAM policy document for this resource policy.
     */
    readonly document: PolicyDocument;
    constructor(scope: Construct, id: string, props?: ResourcePolicyProps);
}
