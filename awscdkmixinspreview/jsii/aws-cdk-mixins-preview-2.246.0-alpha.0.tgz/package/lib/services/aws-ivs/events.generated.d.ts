import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.ivs@LimitBreach
 */
export declare class LimitBreach {
    /**
     * EventBridge event pattern for IVS Limit Breach
     */
    static limitBreachPattern(options?: LimitBreach.LimitBreachProps): events.EventPattern;
}
export declare namespace LimitBreach {
    /**
     * Props type for aws.ivs@LimitBreach event
     */
    interface LimitBreachProps {
        /**
         * exceeded_by property
         *
         * Specify an array of string values to match this event if the actual value of exceeded_by is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly exceededBy?: Array<string>;
        /**
         * limit property
         *
         * Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly limit?: Array<string>;
        /**
         * limit_unit property
         *
         * Specify an array of string values to match this event if the actual value of limit_unit is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly limitUnit?: Array<string>;
        /**
         * limit_value property
         *
         * Specify an array of string values to match this event if the actual value of limit_value is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly limitValue?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.ivs@RecordingStateChange
 */
export declare class RecordingStateChange {
    /**
     * EventBridge event pattern for IVS Recording State Change
     */
    static recordingStateChangePattern(options?: RecordingStateChange.RecordingStateChangeProps): events.EventPattern;
}
export declare namespace RecordingStateChange {
    /**
     * Props type for aws.ivs@RecordingStateChange event
     */
    interface RecordingStateChangeProps {
        /**
         * channel_name property
         *
         * Specify an array of string values to match this event if the actual value of channel_name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelName?: Array<string>;
        /**
         * stream_id property
         *
         * Specify an array of string values to match this event if the actual value of stream_id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly streamId?: Array<string>;
        /**
         * recording_status property
         *
         * Specify an array of string values to match this event if the actual value of recording_status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly recordingStatus?: Array<string>;
        /**
         * recording_status_reason property
         *
         * Specify an array of string values to match this event if the actual value of recording_status_reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly recordingStatusReason?: Array<string>;
        /**
         * recording_s3_bucket_name property
         *
         * Specify an array of string values to match this event if the actual value of recording_s3_bucket_name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly recordingS3BucketName?: Array<string>;
        /**
         * recording_s3_key_prefix property
         *
         * Specify an array of string values to match this event if the actual value of recording_s3_key_prefix is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly recordingS3KeyPrefix?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.ivs@StreamHealthChange
 */
export declare class StreamHealthChange {
    /**
     * EventBridge event pattern for IVS Stream Health Change
     */
    static streamHealthChangePattern(options?: StreamHealthChange.StreamHealthChangeProps): events.EventPattern;
}
export declare namespace StreamHealthChange {
    /**
     * Props type for aws.ivs@StreamHealthChange event
     */
    interface StreamHealthChangeProps {
        /**
         * channel_name property
         *
         * Specify an array of string values to match this event if the actual value of channel_name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelName?: Array<string>;
        /**
         * event_name property
         *
         * Specify an array of string values to match this event if the actual value of event_name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * stream_id property
         *
         * Specify an array of string values to match this event if the actual value of stream_id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly streamId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
/**
 * EventBridge event pattern for aws.ivs@StreamStateChange
 */
export declare class StreamStateChange {
    /**
     * EventBridge event pattern for IVS Stream State Change
     */
    static streamStateChangePattern(options?: StreamStateChange.StreamStateChangeProps): events.EventPattern;
}
export declare namespace StreamStateChange {
    /**
     * Props type for aws.ivs@StreamStateChange event
     */
    interface StreamStateChangeProps {
        /**
         * channel_name property
         *
         * Specify an array of string values to match this event if the actual value of channel_name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly channelName?: Array<string>;
        /**
         * event_name property
         *
         * Specify an array of string values to match this event if the actual value of event_name is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly eventName?: Array<string>;
        /**
         * stream_id property
         *
         * Specify an array of string values to match this event if the actual value of stream_id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly streamId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
}
