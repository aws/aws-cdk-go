import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-apigateway";
/**
 * Builder for CfnRestApiLogsMixin to generate EXECUTION_LOGS for CfnRestApi
 *
 * @cloudformationResource AWS::ApiGateway::RestApi
 * @logType EXECUTION_LOGS
 * @stability external
 */
export declare class CfnRestApiExecutionLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnRestApiExecutionLogsS3Props): CfnRestApiLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnRestApiExecutionLogsLogGroupProps): CfnRestApiLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnRestApiExecutionLogsFirehoseProps): CfnRestApiLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnRestApiExecutionLogsDestProps): CfnRestApiLogsMixin;
}
/**
 * Builder for CfnRestApiLogsMixin to generate ACCESS_LOGS for CfnRestApi
 *
 * @cloudformationResource AWS::ApiGateway::RestApi
 * @logType ACCESS_LOGS
 * @stability external
 */
export declare class CfnRestApiAccessLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnRestApiAccessLogsS3Props): CfnRestApiLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnRestApiAccessLogsLogGroupProps): CfnRestApiLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnRestApiAccessLogsFirehoseProps): CfnRestApiLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnRestApiAccessLogsDestProps): CfnRestApiLogsMixin;
}
/**
 * The `AWS::ApiGateway::RestApi` resource creates a REST API.
 *
 * For more information, see [restapi:create](https://docs.aws.amazon.com/apigateway/latest/api/API_CreateRestApi.html) in the *Amazon API Gateway REST API Reference* .
 *
 * > On January 1, 2016, the Swagger Specification was donated to the [OpenAPI initiative](https://docs.aws.amazon.com/https://www.openapis.org/) , becoming the foundation of the OpenAPI Specification.
 *
 * @cloudformationResource AWS::ApiGateway::RestApi
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-restapi.html
 */
export declare class CfnRestApiLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly EXECUTION_LOGS: CfnRestApiExecutionLogs;
    static readonly ACCESS_LOGS: CfnRestApiAccessLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::ApiGateway::RestApi`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnRestApi;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnRestApiExecutionLogs.
 */
export declare class CfnRestApiExecutionLogsOutputFormat {
}
export declare namespace CfnRestApiExecutionLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnRestApiExecutionLogsRecordFields {
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    STAGE = "stage",
    PAYLOAD = "payload"
}
export interface CfnRestApiExecutionLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnRestApiExecutionLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRestApiExecutionLogsRecordFields>;
}
export interface CfnRestApiExecutionLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnRestApiExecutionLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRestApiExecutionLogsRecordFields>;
}
export interface CfnRestApiExecutionLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnRestApiExecutionLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRestApiExecutionLogsRecordFields>;
}
export interface CfnRestApiExecutionLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRestApiExecutionLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnRestApiAccessLogs.
 */
export declare class CfnRestApiAccessLogsOutputFormat {
}
export declare namespace CfnRestApiAccessLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnRestApiAccessLogsRecordFields {
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    STAGE = "stage",
    PAYLOAD = "payload"
}
export interface CfnRestApiAccessLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnRestApiAccessLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRestApiAccessLogsRecordFields>;
}
export interface CfnRestApiAccessLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnRestApiAccessLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRestApiAccessLogsRecordFields>;
}
export interface CfnRestApiAccessLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnRestApiAccessLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRestApiAccessLogsRecordFields>;
}
export interface CfnRestApiAccessLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRestApiAccessLogsRecordFields>;
}
