import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-devopsagent";
/**
 * Builder for CfnAgentSpaceLogsMixin to generate APPLICATION_LOGS for CfnAgentSpace
 *
 * @cloudformationResource AWS::DevOpsAgent::AgentSpace
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnAgentSpaceApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnAgentSpaceApplicationLogsS3Props): CfnAgentSpaceLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnAgentSpaceApplicationLogsLogGroupProps): CfnAgentSpaceLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnAgentSpaceApplicationLogsFirehoseProps): CfnAgentSpaceLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnAgentSpaceApplicationLogsDestProps): CfnAgentSpaceLogsMixin;
}
/**
 * The `AWS::DevOpsAgent::AgentSpace` resource specifies an Agent Space for the AWS DevOps Agent Service.
 *
 * @cloudformationResource AWS::DevOpsAgent::AgentSpace
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-agentspace.html
 */
export declare class CfnAgentSpaceLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnAgentSpaceApplicationLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::DevOpsAgent::AgentSpace`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAgentSpace;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnAgentSpaceApplicationLogs.
 */
export declare class CfnAgentSpaceApplicationLogsOutputFormat {
}
export declare namespace CfnAgentSpaceApplicationLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnAgentSpaceApplicationLogsRecordFields {
    OPTIONAL_ACCOUNT_ID = "optional_account_id",
    OPTIONAL_AGENT_SPACE_ID = "optional_agent_space_id",
    OPTIONAL_LEVEL = "optional_level",
    OPTIONAL_ASSOCIATION_ID = "optional_association_id",
    OPTIONAL_STATUS = "optional_status",
    OPTIONAL_WEBHOOK_ID = "optional_webhook_id",
    OPTIONAL_MCP_ENDPOINT_URL = "optional_mcp_endpoint_url",
    OPTIONAL_SERVICE_TYPE = "optional_service_type",
    OPTIONAL_SERVICE_ENDPOINT_URL = "optional_service_endpoint_url",
    OPTIONAL_SERVICE_ID = "optional_service_id",
    OPTIONAL_REQUEST_ID = "optional_request_id",
    OPTIONAL_OPERATION = "optional_operation",
    OPTIONAL_TASK_TYPE = "optional_task_type",
    OPTIONAL_TASK_ID = "optional_task_id",
    OPTIONAL_REFERENCE = "optional_reference",
    OPTIONAL_ERROR_TYPE = "optional_error_type",
    OPTIONAL_ERROR_MESSAGE = "optional_error_message",
    OPTIONAL_DETAILS = "optional_details",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnAgentSpaceApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnAgentSpaceApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentSpaceApplicationLogsRecordFields>;
}
export interface CfnAgentSpaceApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnAgentSpaceApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentSpaceApplicationLogsRecordFields>;
}
export interface CfnAgentSpaceApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnAgentSpaceApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentSpaceApplicationLogsRecordFields>;
}
export interface CfnAgentSpaceApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnAgentSpaceApplicationLogsRecordFields>;
}
