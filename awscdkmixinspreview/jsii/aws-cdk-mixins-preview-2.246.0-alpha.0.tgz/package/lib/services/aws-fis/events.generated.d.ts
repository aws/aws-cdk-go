import * as cdk from "aws-cdk-lib/core";
import * as events from "aws-cdk-lib/aws-events";
/**
 * EventBridge event pattern for aws.fis@FISExperimentStateChange
 */
export declare class FISExperimentStateChange {
    /**
     * EventBridge event pattern for FIS Experiment State Change
     */
    static fisExperimentStateChangePattern(options?: FISExperimentStateChange.FISExperimentStateChangeProps): events.EventPattern;
}
export declare namespace FISExperimentStateChange {
    /**
     * Props type for aws.fis@FISExperimentStateChange event
     */
    interface FISExperimentStateChangeProps {
        /**
         * new-state property
         *
         * Specify an array of string values to match this event if the actual value of new-state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly newState?: FISExperimentStateChange.NewState;
        /**
         * old-state property
         *
         * Specify an array of string values to match this event if the actual value of old-state is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly oldState?: FISExperimentStateChange.OldState;
        /**
         * experiment-id property
         *
         * Specify an array of string values to match this event if the actual value of experiment-id is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly experimentId?: Array<string>;
        /**
         * EventBridge event metadata
         *
         * @default - -
         */
        readonly eventMetadata?: cdk.AWSEventMetadataProps;
    }
    /**
     * Type definition for New-state
     *
     * @struct
     */
    interface NewState {
        /**
         * reason property
         *
         * Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reason?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
    }
    /**
     * Type definition for Old-state
     *
     * @struct
     */
    interface OldState {
        /**
         * reason property
         *
         * Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly reason?: Array<string>;
        /**
         * status property
         *
         * Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the `aws_events.Match`  for more advanced matching options.
         *
         * @default - Do not filter on this field
         */
        readonly status?: Array<string>;
    }
}
