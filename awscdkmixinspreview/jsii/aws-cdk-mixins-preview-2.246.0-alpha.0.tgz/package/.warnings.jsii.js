function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogs(p) {
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogs(p) {
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_appmesh_events_AWSServiceEventViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_appmesh_events_AWSServiceEventViaCloudTrail_AWSServiceEventViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.serviceEventDetails))
            _aws_cdk_mixins_preview_aws_appmesh_events_AWSServiceEventViaCloudTrail_ServiceEventDetails(p.serviceEventDetails);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_appmesh_events_AWSServiceEventViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_appmesh_events_AWSServiceEventViaCloudTrail_ServiceEventDetails(p) {
}
function _aws_cdk_mixins_preview_aws_appmesh_events_AWSServiceEventViaCloudTrail_UserIdentity(p) {
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogs(p) {
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_athena_events_AthenaQueryStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_athena_events_AthenaQueryStateChange_AthenaQueryStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_athena_events_WorkGroupEvents(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (!visitedObjects.has(p.responseElements))
            _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_ResponseElements(p.responseElements);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_ResponseElements(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.launchTemplate))
            _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_LaunchTemplate(p.launchTemplate);
        if (!visitedObjects.has(p.mixedInstancesPolicy))
            _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_MixedInstancesPolicy(p.mixedInstancesPolicy);
        if (p.stepAdjustments != null)
            for (const o of p.stepAdjustments)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_RequestParametersItem1(o);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_RequestParametersItem(o);
        if (!visitedObjects.has(p.targetTrackingConfiguration))
            _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_TargetTrackingConfiguration(p.targetTrackingConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_TargetTrackingConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.customizedMetricSpecification))
            _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_CustomizedMetricSpecification(p.customizedMetricSpecification);
        if (!visitedObjects.has(p.predefinedMetricSpecification))
            _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_PredefinedMetricSpecification(p.predefinedMetricSpecification);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_PredefinedMetricSpecification(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_CustomizedMetricSpecification(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.dimensions != null)
            for (const o of p.dimensions)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_CustomizedMetricSpecificationItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_CustomizedMetricSpecificationItem(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_MixedInstancesPolicy(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.instancesDistribution))
            _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_InstancesDistribution(p.instancesDistribution);
        if (!visitedObjects.has(p.launchTemplate))
            _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_LaunchTemplate1(p.launchTemplate);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_LaunchTemplate1(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.launchTemplateSpecification))
            _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_LaunchTemplateSpecification(p.launchTemplateSpecification);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_LaunchTemplateSpecification(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_InstancesDistribution(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_LaunchTemplate(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_RequestParametersItem(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_RequestParametersItem1(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchLifecycleAction(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchLifecycleAction_EC2InstanceLaunchLifecycleActionProps(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_AutoScalingGroupEvents(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchSuccessful(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchSuccessful_EC2InstanceLaunchSuccessfulProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.details))
            _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchSuccessful_Details(p.details);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchSuccessful_Details(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchUnsuccessful(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchUnsuccessful_EC2InstanceLaunchUnsuccessfulProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.details))
            _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchUnsuccessful_Details(p.details);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchUnsuccessful_Details(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateLifecycleAction(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateLifecycleAction_EC2InstanceTerminateLifecycleActionProps(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateSuccessful(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateSuccessful_EC2InstanceTerminateSuccessfulProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.details))
            _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateSuccessful_Details(p.details);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateSuccessful_Details(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateUnsuccessful(p) {
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateUnsuccessful_EC2InstanceTerminateUnsuccessfulProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.details))
            _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateUnsuccessful_Details(p.details);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateUnsuccessful_Details(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementCompleted_AcknowledgementCompletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.ackFileS3Attributes))
            _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementCompleted_AckFileS3Attributes(p.ackFileS3Attributes);
        if (!visitedObjects.has(p.inputFileS3Attributes))
            _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementCompleted_InputFileS3Attributes(p.inputFileS3Attributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementCompleted_AckFileS3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementCompleted_InputFileS3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementFailed(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementFailed_AcknowledgementFailedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputFileS3Attributes))
            _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementFailed_InputFileS3Attributes(p.inputFileS3Attributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementFailed_InputFileS3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_events_TransformationCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_events_TransformationCompleted_TransformationCompletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputFileS3Attributes))
            _aws_cdk_mixins_preview_aws_b2bi_events_TransformationCompleted_InputFileS3Attributes(p.inputFileS3Attributes);
        if (!visitedObjects.has(p.outputFileS3Attributes))
            _aws_cdk_mixins_preview_aws_b2bi_events_TransformationCompleted_OutputFileS3Attributes(p.outputFileS3Attributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_b2bi_events_TransformationCompleted_InputFileS3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_events_TransformationCompleted_OutputFileS3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_events_TransformationFailed(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_events_TransformationFailed_TransformationFailedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputFileS3Attributes))
            _aws_cdk_mixins_preview_aws_b2bi_events_TransformationFailed_InputFileS3Attributes(p.inputFileS3Attributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_b2bi_events_TransformationFailed_InputFileS3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogs(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogs(p) {
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogs(p) {
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (!visitedObjects.has(p.responseElements))
            _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_ResponseElements(p.responseElements);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_ResponseElements(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.containerOverrides))
            _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_ContainerOverrides(p.containerOverrides);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_ContainerOverrides(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.environment != null)
            for (const o of p.environment)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_ContainerOverridesItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_ContainerOverridesItem(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sessionContext))
            _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_SessionContext(p.sessionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_SessionContext(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attributes))
            _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_Attributes(p.attributes);
        if (!visitedObjects.has(p.sessionIssuer))
            _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_SessionIssuer(p.sessionIssuer);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_SessionIssuer(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_BatchJobStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.attempts != null)
            for (const o of p.attempts)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_BatchJobStateChangeItem(o);
        if (!visitedObjects.has(p.container))
            _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_Container(p.container);
        if (p.dependsOn != null)
            for (const o of p.dependsOn)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_JobDependency(o);
        if (!visitedObjects.has(p.retryStrategy))
            _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_RetryStrategy(p.retryStrategy);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_Container(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.environment != null)
            for (const o of p.environment)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_ContainerItem(o);
        if (p.mountPoints != null)
            for (const o of p.mountPoints)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_MountPoint(o);
        if (p.networkInterfaces != null)
            for (const o of p.networkInterfaces)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_NetworkInterface(o);
        if (p.resourceRequirements != null)
            for (const o of p.resourceRequirements)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_ResourceRequirement(o);
        if (p.ulimits != null)
            for (const o of p.ulimits)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_ULimit(o);
        if (p.volumes != null)
            for (const o of p.volumes)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_Volumes(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_Volumes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.host))
            _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_Host(p.host);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_Host(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_ResourceRequirement(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_ContainerItem(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_ULimit(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_NetworkInterface(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_MountPoint(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_RetryStrategy(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_JobDependency(p) {
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_BatchJobStateChangeItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.container))
            _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_Container1(p.container);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_Container1(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogs(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogs(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseTraces(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseTracesOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseTracesRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseTracesXRayProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseTracesRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseTracesDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseTracesRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogs(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogs(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayTraces(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayTracesOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayTracesRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayTracesXRayProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayTracesRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayTracesDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayTracesRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryTraces(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryTracesOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryTracesRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryTracesXRayProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryTracesRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryTracesDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryTracesRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeTraces(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogs(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeTracesOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeTracesRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeTracesXRayProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeTracesRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeTracesDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeTracesRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogs(p) {
}
function _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress(p) {
}
function _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress_CloudFormationHookInvocationProgressProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.hookDetail))
            _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress_HookDetail(p.hookDetail);
        if (!visitedObjects.has(p.result))
            _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress_Result(p.result);
        if (!visitedObjects.has(p.targetDetail))
            _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress_TargetDetail(p.targetDetail);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress_HookDetail(p) {
}
function _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress_Result(p) {
}
function _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress_TargetDetail(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogs(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogs(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange(p) {
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_CloudWatchAlarmConfigurationChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.configuration))
            _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_Configuration(p.configuration);
        if (!visitedObjects.has(p.state))
            _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_State(p.state);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_Configuration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.metrics != null)
            for (const o of p.metrics)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_ConfigurationItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_ConfigurationItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.metricStat))
            _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_MetricStat(p.metricStat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_MetricStat(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.metric))
            _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_Metric(p.metric);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_Metric(p) {
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_State(p) {
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_AlarmEvents(p) {
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_CloudWatchAlarmStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.configuration))
            _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_Configuration(p.configuration);
        if (!visitedObjects.has(p.previousState))
            _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_State(p.previousState);
        if (!visitedObjects.has(p.state))
            _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_State(p.state);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_Configuration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.metrics != null)
            for (const o of p.metrics)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_ConfigurationItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_ConfigurationItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.metricStat))
            _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_MetricStat(p.metricStat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_MetricStat(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.metric))
            _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_Metric(p.metric);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_Metric(p) {
}
function _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_State(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (!visitedObjects.has(p.responseElements))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_ResponseElements(p.responseElements);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_ResponseElements(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.buildProperty))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Build(p.buildProperty);
        if (!visitedObjects.has(p.project))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Project(p.project);
        if (!visitedObjects.has(p.webhook))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Webhook(p.webhook);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Build(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.artifacts))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Artifacts(p.artifacts);
        if (!visitedObjects.has(p.cache))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Cache(p.cache);
        if (!visitedObjects.has(p.environment))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Environment(p.environment);
        if (!visitedObjects.has(p.logs))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Logs(p.logs);
        if (p.phases != null)
            for (const o of p.phases)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_BuildPhase(o);
        if (!visitedObjects.has(p.source))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Source(p.source);
        if (!visitedObjects.has(p.vpcConfig))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_VpcConfig(p.vpcConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Artifacts(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Cache(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Environment(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.environmentVariables != null)
            for (const o of p.environmentVariables)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_EnvironmentItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_EnvironmentItem(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Logs(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Source(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.auth))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Auth(p.auth);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Auth(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_VpcConfig(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_BuildPhase(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Project(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.artifacts))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Artifacts1(p.artifacts);
        if (!visitedObjects.has(p.badge))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Badge(p.badge);
        if (!visitedObjects.has(p.cache))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Cache(p.cache);
        if (!visitedObjects.has(p.environment))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Environment1(p.environment);
        if (!visitedObjects.has(p.source))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Source1(p.source);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_ProjectItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Artifacts1(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Badge(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Environment1(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.environmentVariables != null)
            for (const o of p.environmentVariables)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_EnvironmentItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Source1(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.auth))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Auth(p.auth);
        if (!visitedObjects.has(p.gitSubmodulesConfig))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_GitSubmodulesConfig(p.gitSubmodulesConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_GitSubmodulesConfig(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_ProjectItem(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Webhook(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sessionContext))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_SessionContext(p.sessionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_SessionContext(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attributes))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Attributes(p.attributes);
        if (!visitedObjects.has(p.sessionIssuer))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_SessionIssuer(p.sessionIssuer);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_SessionIssuer(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSServiceEventViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSServiceEventViaCloudTrail_AWSServiceEventViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.serviceEventDetails))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSServiceEventViaCloudTrail_ServiceEventDetails(p.serviceEventDetails);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_codebuild_events_AWSServiceEventViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSServiceEventViaCloudTrail_ServiceEventDetails(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_AWSServiceEventViaCloudTrail_UserIdentity(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_CodeBuildBuildPhaseChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.additionalInformation))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_AdditionalInformation(p.additionalInformation);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_AdditionalInformation(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.artifact))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Artifact(p.artifact);
        if (!visitedObjects.has(p.cache))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Cache(p.cache);
        if (!visitedObjects.has(p.environment))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Environment(p.environment);
        if (!visitedObjects.has(p.logs))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Logs(p.logs);
        if (!visitedObjects.has(p.networkInterface))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_NetworkInterface(p.networkInterface);
        if (p.phases != null)
            for (const o of p.phases)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_AdditionalInformationItem(o);
        if (!visitedObjects.has(p.source))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Source(p.source);
        if (!visitedObjects.has(p.vpcConfig))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_VpcConfig(p.vpcConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Artifact(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Cache(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Environment(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.environmentVariables != null)
            for (const o of p.environmentVariables)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_EnvironmentItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_EnvironmentItem(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Logs(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_NetworkInterface(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Source(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.auth))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Auth(p.auth);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Auth(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_VpcConfig(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.subnets != null)
            for (const o of p.subnets)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_VpcConfigItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_VpcConfigItem(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_AdditionalInformationItem(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_ProjectEvents(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_CodeBuildBuildStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.additionalInformation))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_AdditionalInformation(p.additionalInformation);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_AdditionalInformation(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.artifact))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Artifact(p.artifact);
        if (!visitedObjects.has(p.cache))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Cache(p.cache);
        if (!visitedObjects.has(p.environment))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Environment(p.environment);
        if (!visitedObjects.has(p.logs))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Logs(p.logs);
        if (!visitedObjects.has(p.networkInterface))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_NetworkInterface(p.networkInterface);
        if (p.phases != null)
            for (const o of p.phases)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_AdditionalInformationItem(o);
        if (!visitedObjects.has(p.source))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Source(p.source);
        if (!visitedObjects.has(p.vpcConfig))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_VpcConfig(p.vpcConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Artifact(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Cache(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Environment(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.environmentVariables != null)
            for (const o of p.environmentVariables)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_EnvironmentItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_EnvironmentItem(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Logs(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_NetworkInterface(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Source(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.auth))
            _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Auth(p.auth);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Auth(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_VpcConfig(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.subnets != null)
            for (const o of p.subnets)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_VpcConfigItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_VpcConfigItem(p) {
}
function _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_AdditionalInformationItem(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.additionalEventData))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AdditionalEventData(p.additionalEventData);
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (p.resources != null)
            for (const o of p.resources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(o);
        if (!visitedObjects.has(p.responseElements))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_ResponseElements(p.responseElements);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AdditionalEventData(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.deleteFiles != null)
            for (const o of p.deleteFiles)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RequestParametersItem(o);
        if (!visitedObjects.has(p.location))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_Location(p.location);
        if (p.putFiles != null)
            for (const o of p.putFiles)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RequestParametersItem(o);
        if (p.references != null)
            for (const o of p.references)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RequestParametersItem1(o);
        if (p.targets != null)
            for (const o of p.targets)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RequestParametersItem2(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_Location(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RequestParametersItem(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RequestParametersItem1(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RequestParametersItem2(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_ResponseElements(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.comment))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_Comment(p.comment);
        if (!visitedObjects.has(p.deletedBranch))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_DeletedBranch(p.deletedBranch);
        if (p.filesAdded != null)
            for (const o of p.filesAdded)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_ResponseElementsItem(o);
        if (p.filesDeleted != null)
            for (const o of p.filesDeleted)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_ResponseElementsItem(o);
        if (p.filesUpdated != null)
            for (const o of p.filesUpdated)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_ResponseElementsItem(o);
        if (!visitedObjects.has(p.location))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_Location(p.location);
        if (!visitedObjects.has(p.pullRequest))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_PullRequest(p.pullRequest);
        if (!visitedObjects.has(p.repositoryMetadata))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RepositoryMetadata(p.repositoryMetadata);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_Comment(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_DeletedBranch(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_PullRequest(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.pullRequestTargets != null)
            for (const o of p.pullRequestTargets)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_PullRequestItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_PullRequestItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.mergeMetadata))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_MergeMetadata(p.mergeMetadata);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_MergeMetadata(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RepositoryMetadata(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_ResponseElementsItem(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sessionContext))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_SessionContext(p.sessionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_SessionContext(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attributes))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_Attributes(p.attributes);
        if (!visitedObjects.has(p.sessionIssuer))
            _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_SessionIssuer(p.sessionIssuer);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_SessionIssuer(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitApprovalRuleTemplateChange(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitApprovalRuleTemplateChange_CodeCommitApprovalRuleTemplateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitPullRequestStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitPullRequestStateChange_CodeCommitPullRequestStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitCommentOnCommit(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitCommentOnCommit_CodeCommitCommentOnCommitProps(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_RepositoryEvents(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitCommentOnPullRequest(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitCommentOnPullRequest_CodeCommitCommentOnPullRequestProps(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitRepositoryStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitRepositoryStateChange_CodeCommitRepositoryStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_codedeploy_events_CodeDeployDeploymentStateChangeNotification(p) {
}
function _aws_cdk_mixins_preview_aws_codedeploy_events_CodeDeployDeploymentStateChangeNotification_CodeDeployDeploymentStateChangeNotificationProps(p) {
}
function _aws_cdk_mixins_preview_aws_codedeploy_events_CodeDeployInstanceStateChangeNotification(p) {
}
function _aws_cdk_mixins_preview_aws_codedeploy_events_CodeDeployInstanceStateChangeNotification_CodeDeployInstanceStateChangeNotificationProps(p) {
}
function _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_CodeGuruProfilerRecommendationStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.recommendation))
            _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Recommendation(p.recommendation);
        if (!visitedObjects.has(p.title))
            _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Title(p.title);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Recommendation(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.description))
            _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Description(p.description);
        if (!visitedObjects.has(p.name))
            _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Name(p.name);
        if (!visitedObjects.has(p.reason))
            _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Reason(p.reason);
        if (!visitedObjects.has(p.resolutionSteps))
            _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_ResolutionSteps(p.resolutionSteps);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Description(p) {
}
function _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Name(p) {
}
function _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Reason(p) {
}
function _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_ResolutionSteps(p) {
}
function _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Title(p) {
}
function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_CodePipelineActionExecutionStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.executionResult))
            _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_ExecutionResult(p.executionResult);
        if (!visitedObjects.has(p.inputArtifacts))
            _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_InputArtifacts(p.inputArtifacts);
        if (!visitedObjects.has(p.outputArtifacts))
            _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_OutputArtifacts(p.outputArtifacts);
        if (!visitedObjects.has(p.type))
            _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_Type(p.type);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_Type(p) {
}
function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_ExecutionResult(p) {
}
function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_InputArtifacts(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3Location))
            _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_S3Location(p.s3Location);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_S3Location(p) {
}
function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_OutputArtifacts(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3Location))
            _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_S3Location(p.s3Location);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelinePipelineExecutionStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelinePipelineExecutionStateChange_CodePipelinePipelineExecutionStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.executionTrigger))
            _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelinePipelineExecutionStateChange_ExecutionTrigger(p.executionTrigger);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelinePipelineExecutionStateChange_ExecutionTrigger(p) {
}
function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineStageExecutionStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineStageExecutionStateChange_CodePipelineStageExecutionStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_connect_events_CodeConnectContact(p) {
}
function _aws_cdk_mixins_preview_aws_connect_events_CodeConnectContact_CodeConnectContactProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.agentInfo))
            _aws_cdk_mixins_preview_aws_connect_events_CodeConnectContact_AgentInfo(p.agentInfo);
        if (!visitedObjects.has(p.queueInfo))
            _aws_cdk_mixins_preview_aws_connect_events_CodeConnectContact_QueueInfo(p.queueInfo);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_connect_events_CodeConnectContact_AgentInfo(p) {
}
function _aws_cdk_mixins_preview_aws_connect_events_CodeConnectContact_QueueInfo(p) {
}
function _aws_cdk_mixins_preview_aws_connect_events_InstanceEvents(p) {
}
function _aws_cdk_mixins_preview_aws_connect_events_ContactLensPostCallRulesMatched(p) {
}
function _aws_cdk_mixins_preview_aws_connect_events_ContactLensPostCallRulesMatched_ContactLensPostCallRulesMatchedProps(p) {
}
function _aws_cdk_mixins_preview_aws_connect_events_ContactLensRealtimeRulesMatched(p) {
}
function _aws_cdk_mixins_preview_aws_connect_events_ContactLensRealtimeRulesMatched_ContactLensRealtimeRulesMatchedProps(p) {
}
function _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogs(p) {
}
function _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_datasync_events_DataSyncAgentStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_datasync_events_DataSyncAgentStateChange_DataSyncAgentStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_datasync_events_DataSyncLocationStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_datasync_events_DataSyncLocationStateChange_DataSyncLocationStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_datasync_events_DataSyncTaskExecutionStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_datasync_events_DataSyncTaskExecutionStateChange_DataSyncTaskExecutionStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_datasync_events_DataSyncTaskStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_datasync_events_DataSyncTaskStateChange_DataSyncTaskStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_deadline_events_FleetSizeRecommendationChange(p) {
}
function _aws_cdk_mixins_preview_aws_deadline_events_FleetSizeRecommendationChange_FleetSizeRecommendationChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_DevOpsGuruInsightClosedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.anomalies != null)
            for (const o of p.anomalies)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_Anomaly(o);
        if (!visitedObjects.has(p.resourceCollection))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_ResourceCollection(p.resourceCollection);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_ResourceCollection(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.cloudFormation))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_CloudFormation(p.cloudFormation);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_TagType(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_CloudFormation(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_TagType(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_Anomaly(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.anomalyResources != null)
            for (const o of p.anomalyResources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_AnomalyResource(o);
        if (p.sourceDetails != null)
            for (const o of p.sourceDetails)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_SourceDetail(o);
        if (!visitedObjects.has(p.sourceMetadata))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_AnomalySourceMetadata(p.sourceMetadata);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_AnomalyResource(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_SourceDetail(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.dataIdentifiers))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_DataIdentifiers(p.dataIdentifiers);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_DataIdentifiers(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.alarmCondition))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_AlarmCondition(p.alarmCondition);
        if (p.dimensions != null)
            for (const o of p.dimensions)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_CloudWatchDimension(o);
        if (!visitedObjects.has(p.metricQuery))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_MetricQuery(p.metricQuery);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_MetricQuery(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.groupBy))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_GroupBy(p.groupBy);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_GroupBy(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_CloudWatchDimension(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_AlarmCondition(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.referenceValue))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_ReferenceValue(p.referenceValue);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_ReferenceValue(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_AnomalySourceMetadata(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_DevOpsGuruInsightSeverityUpgradedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.anomalies != null)
            for (const o of p.anomalies)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_Anomaly(o);
        if (!visitedObjects.has(p.resourceCollection))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_ResourceCollection(p.resourceCollection);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_Anomaly(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.anomalyResources != null)
            for (const o of p.anomalyResources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_AnomalyResource(o);
        if (p.sourceDetails != null)
            for (const o of p.sourceDetails)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_SourceDetail(o);
        if (!visitedObjects.has(p.sourceMetadata))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_AnomalySourceMetadata(p.sourceMetadata);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_AnomalyResource(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_SourceDetail(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.dataIdentifiers))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_DataIdentifiers(p.dataIdentifiers);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_DataIdentifiers(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.alarmCondition))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_AlarmCondition(p.alarmCondition);
        if (p.dimensions != null)
            for (const o of p.dimensions)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_CloudWatchDimension(o);
        if (!visitedObjects.has(p.metricQuery))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_MetricQuery(p.metricQuery);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_MetricQuery(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.groupBy))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_GroupBy(p.groupBy);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_GroupBy(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_CloudWatchDimension(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_AlarmCondition(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.referenceValue))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_ReferenceValue(p.referenceValue);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_ReferenceValue(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_AnomalySourceMetadata(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_ResourceCollection(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.cloudFormation))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_CloudFormation(p.cloudFormation);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_TagType(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_CloudFormation(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_TagType(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_DevOpsGuruNewAnomalyAssociationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.anomalies != null)
            for (const o of p.anomalies)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_Anomaly(o);
        if (!visitedObjects.has(p.resourceCollection))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_ResourceCollection(p.resourceCollection);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_ResourceCollection(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.cloudFormation))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_CloudFormation(p.cloudFormation);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_TagType(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_CloudFormation(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_TagType(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_Anomaly(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.anomalyResources != null)
            for (const o of p.anomalyResources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_AnomalyResource(o);
        if (p.sourceDetails != null)
            for (const o of p.sourceDetails)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_SourceDetail(o);
        if (!visitedObjects.has(p.sourceMetadata))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_AnomalySourceMetadata(p.sourceMetadata);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_AnomalyResource(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_SourceDetail(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.dataIdentifiers))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_DataIdentifiers(p.dataIdentifiers);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_DataIdentifiers(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.alarmCondition))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_AlarmCondition(p.alarmCondition);
        if (p.dimensions != null)
            for (const o of p.dimensions)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_CloudWatchDimension(o);
        if (!visitedObjects.has(p.metricQuery))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_MetricQuery(p.metricQuery);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_MetricQuery(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.groupBy))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_GroupBy(p.groupBy);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_GroupBy(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_CloudWatchDimension(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_AlarmCondition(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.referenceValue))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_ReferenceValue(p.referenceValue);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_ReferenceValue(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_AnomalySourceMetadata(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_DevOpsGuruNewInsightOpenProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.anomalies != null)
            for (const o of p.anomalies)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_Anomaly(o);
        if (!visitedObjects.has(p.resourceCollection))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_ResourceCollection(p.resourceCollection);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_ResourceCollection(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.cloudFormation))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_CloudFormation(p.cloudFormation);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_TagType(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_CloudFormation(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_TagType(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_Anomaly(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.anomalyResources != null)
            for (const o of p.anomalyResources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_AnomalyResource(o);
        if (p.sourceDetails != null)
            for (const o of p.sourceDetails)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_SourceDetail(o);
        if (!visitedObjects.has(p.sourceMetadata))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_AnomalySourceMetadata(p.sourceMetadata);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_AnomalyResource(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_SourceDetail(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.dataIdentifiers))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_DataIdentifiers(p.dataIdentifiers);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_DataIdentifiers(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.alarmCondition))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_AlarmCondition(p.alarmCondition);
        if (p.dimensions != null)
            for (const o of p.dimensions)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_CloudWatchDimension(o);
        if (!visitedObjects.has(p.metricQuery))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_MetricQuery(p.metricQuery);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_MetricQuery(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.groupBy))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_GroupBy(p.groupBy);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_GroupBy(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_CloudWatchDimension(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_AlarmCondition(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.referenceValue))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_ReferenceValue(p.referenceValue);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_ReferenceValue(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_AnomalySourceMetadata(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_DevOpsGuruNewRecommendationCreatedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recommendations != null)
            for (const o of p.recommendations)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_Recommendation(o);
        if (!visitedObjects.has(p.resourceCollection))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_ResourceCollection(p.resourceCollection);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_ResourceCollection(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.cloudFormation))
            _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_CloudFormation(p.cloudFormation);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_TagType(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_CloudFormation(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_TagType(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_Recommendation(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.relatedAnomalies != null)
            for (const o of p.relatedAnomalies)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_RelatedAnomaly(o);
        if (p.relatedEvents != null)
            for (const o of p.relatedEvents)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_RelatedEvent(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_RelatedAnomaly(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.resources != null)
            for (const o of p.resources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_AnomalyResource(o);
        if (p.sourceDetails != null)
            for (const o of p.sourceDetails)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_RelatedAnomalySourceDetail(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_RelatedAnomalySourceDetail(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.cloudWatchMetrics != null)
            for (const o of p.cloudWatchMetrics)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_CloudWatchDimension(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_CloudWatchDimension(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_AnomalyResource(p) {
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_RelatedEvent(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.resources != null)
            for (const o of p.resources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_EventResource(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_EventResource(p) {
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (!visitedObjects.has(p.responseElements))
            _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_ResponseElements(p.responseElements);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.policyDetails))
            _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_PolicyDetails(p.policyDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_PolicyDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.schedules != null)
            for (const o of p.schedules)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_PolicyDetailsItem(o);
        if (p.targetTags != null)
            for (const o of p.targetTags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_PolicyDetailsItem1(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_PolicyDetailsItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.createRule))
            _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_CreateRule(p.createRule);
        if (!visitedObjects.has(p.fastRestoreRule))
            _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_FastRestoreRule(p.fastRestoreRule);
        if (!visitedObjects.has(p.retainRule))
            _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_RetainRule(p.retainRule);
        if (p.tagsToAdd != null)
            for (const o of p.tagsToAdd)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_PolicyDetailsItemItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_CreateRule(p) {
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_FastRestoreRule(p) {
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_RetainRule(p) {
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_PolicyDetailsItemItem(p) {
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_PolicyDetailsItem1(p) {
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_ResponseElements(p) {
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sessionContext))
            _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_SessionContext(p.sessionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_SessionContext(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attributes))
            _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_Attributes(p.attributes);
        if (!visitedObjects.has(p.sessionIssuer))
            _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_SessionIssuer(p.sessionIssuer);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_SessionIssuer(p) {
}
function _aws_cdk_mixins_preview_aws_dlm_events_DLMPolicyStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_dlm_events_DLMPolicyStateChange_DLMPolicyStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_EBSMultiVolumeSnapshotsCompletionStatus(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_EBSMultiVolumeSnapshotsCompletionStatus_EBSMultiVolumeSnapshotsCompletionStatusProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.snapshots != null)
            for (const o of p.snapshots)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_events_EBSMultiVolumeSnapshotsCompletionStatus_Snapshot(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_EBSMultiVolumeSnapshotsCompletionStatus_Snapshot(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_EBSSnapshotNotification(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_EBSSnapshotNotification_EBSSnapshotNotificationProps(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_EBSVolumeNotification(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_EBSVolumeNotification_EBSVolumeNotificationProps(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_EC2FastLaunchStateChangeNotification(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_EC2FastLaunchStateChangeNotification_EC2FastLaunchStateChangeNotificationProps(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (!visitedObjects.has(p.responseElements))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_ResponseElements(p.responseElements);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_ResponseElements(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.createFleetResponse))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CreateFleetResponse(p.createFleetResponse);
        if (!visitedObjects.has(p.createLaunchTemplateResponse))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_DeleteLaunchTemplateResponse(p.createLaunchTemplateResponse);
        if (!visitedObjects.has(p.deleteLaunchTemplateResponse))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_DeleteLaunchTemplateResponse(p.deleteLaunchTemplateResponse);
        if (!visitedObjects.has(p.instancesSet))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstancesSet(p.instancesSet);
        if (!visitedObjects.has(p.networkInterface))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterface(p.networkInterface);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstancesSet(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.items != null)
            for (const o of p.items)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstancesSetItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstancesSetItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.capacityReservationSpecification))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CapacityReservationSpecification(p.capacityReservationSpecification);
        if (!visitedObjects.has(p.cpuOptions))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CpuOptions(p.cpuOptions);
        if (!visitedObjects.has(p.currentState))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstanceState(p.currentState);
        if (!visitedObjects.has(p.enclaveOptions))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_EnclaveOptions(p.enclaveOptions);
        if (!visitedObjects.has(p.groupSet))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet2(p.groupSet);
        if (!visitedObjects.has(p.instanceState))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstanceState(p.instanceState);
        if (!visitedObjects.has(p.monitoring))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Monitoring1(p.monitoring);
        if (!visitedObjects.has(p.networkInterfaceSet))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterfaceSet1(p.networkInterfaceSet);
        if (!visitedObjects.has(p.placement))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Placement(p.placement);
        if (!visitedObjects.has(p.previousState))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstanceState(p.previousState);
        if (!visitedObjects.has(p.stateReason))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_StateReason(p.stateReason);
        if (!visitedObjects.has(p.tagSet))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSet(p.tagSet);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CapacityReservationSpecification(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_StateReason(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet2(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.items != null)
            for (const o of p.items)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet2Item(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet2Item(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSet(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.items != null)
            for (const o of p.items)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSpecificationSetItemItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSpecificationSetItemItem(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstanceState(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterfaceSet1(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.items != null)
            for (const o of p.items)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterfaceSet1Item(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterfaceSet1Item(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attachment))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Attachment(p.attachment);
        if (!visitedObjects.has(p.groupSet))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet3(p.groupSet);
        if (!visitedObjects.has(p.privateIpAddressesSet))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_PrivateIpAddressesSet2(p.privateIpAddressesSet);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet3(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.items != null)
            for (const o of p.items)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet2Item(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Attachment(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_PrivateIpAddressesSet2(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.item != null)
            for (const o of p.item)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_PrivateIpAddressesSet1Item(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_PrivateIpAddressesSet1Item(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CpuOptions(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Monitoring1(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_EnclaveOptions(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Placement(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CreateFleetResponse(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_DeleteLaunchTemplateResponse(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.launchTemplate))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplate1(p.launchTemplate);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplate1(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterface(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.groupSet))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet2(p.groupSet);
        if (!visitedObjects.has(p.privateIpAddressesSet))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_PrivateIpAddressesSet1(p.privateIpAddressesSet);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_PrivateIpAddressesSet1(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.item != null)
            for (const o of p.item)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_PrivateIpAddressesSet1Item(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.createFleetRequest))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CreateFleetRequest(p.createFleetRequest);
        if (!visitedObjects.has(p.createLaunchTemplateRequest))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CreateLaunchTemplateRequest(p.createLaunchTemplateRequest);
        if (!visitedObjects.has(p.deleteLaunchTemplateRequest))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_DeleteLaunchTemplateRequest(p.deleteLaunchTemplateRequest);
        if (!visitedObjects.has(p.groupSet))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet1(p.groupSet);
        if (!visitedObjects.has(p.instanceMarketOptions))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstanceMarketOptions(p.instanceMarketOptions);
        if (!visitedObjects.has(p.instancesSet))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstancesSet1(p.instancesSet);
        if (!visitedObjects.has(p.launchTemplate))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplate(p.launchTemplate);
        if (!visitedObjects.has(p.monitoring))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Monitoring(p.monitoring);
        if (!visitedObjects.has(p.networkInterfaceSet))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterfaceSet(p.networkInterfaceSet);
        if (!visitedObjects.has(p.tagSpecificationSet))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSpecificationSet(p.tagSpecificationSet);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CreateLaunchTemplateRequest(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.launchTemplateData))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplateData(p.launchTemplateData);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplateData(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.instanceMarketOptions))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstanceMarketOptions1(p.instanceMarketOptions);
        if (!visitedObjects.has(p.networkInterface))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterface1(p.networkInterface);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstanceMarketOptions1(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.spotOptions))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SpotOptions2(p.spotOptions);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SpotOptions2(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterface1(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.securityGroupId))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SecurityGroupId(p.securityGroupId);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SecurityGroupId(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet1(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.items != null)
            for (const o of p.items)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet1Item(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet1Item(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstancesSet1(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.items != null)
            for (const o of p.items)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstancesSet1Item(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstancesSet1Item(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CreateFleetRequest(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.existingInstances))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_ExistingInstances(p.existingInstances);
        if (!visitedObjects.has(p.launchTemplateConfigs))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplateConfigs(p.launchTemplateConfigs);
        if (!visitedObjects.has(p.onDemandOptions))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_OnDemandOptions(p.onDemandOptions);
        if (!visitedObjects.has(p.spotOptions))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SpotOptions(p.spotOptions);
        if (!visitedObjects.has(p.tagSpecification))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSpecification(p.tagSpecification);
        if (!visitedObjects.has(p.targetCapacitySpecification))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TargetCapacitySpecification(p.targetCapacitySpecification);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TargetCapacitySpecification(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_OnDemandOptions(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SpotOptions(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_ExistingInstances(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplateConfigs(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.launchTemplateSpecification))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplateSpecification(p.launchTemplateSpecification);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplateSpecification(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSpecification(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.tag))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagType(p.tag);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagType(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_DeleteLaunchTemplateRequest(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterfaceSet(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.items != null)
            for (const o of p.items)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterfaceSetItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterfaceSetItem(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSpecificationSet(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.items != null)
            for (const o of p.items)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSpecificationSetItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSpecificationSetItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSpecificationSetItemItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Monitoring(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstanceMarketOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.spotOptions))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SpotOptions1(p.spotOptions);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SpotOptions1(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplate(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sessionContext))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SessionContext(p.sessionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SessionContext(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attributes))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Attributes(p.attributes);
        if (!visitedObjects.has(p.sessionIssuer))
            _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SessionIssuer(p.sessionIssuer);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SessionIssuer(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_InstanceEvents(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_EC2InstanceStateChangeNotification(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_EC2InstanceStateChangeNotification_EC2InstanceStateChangeNotificationProps(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_EC2SpotInstanceInterruptionWarning(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_events_EC2SpotInstanceInterruptionWarning_EC2SpotInstanceInterruptionWarningProps(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogs(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogs(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogs(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogs(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogs(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (p.resources != null)
            for (const o of p.resources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(o);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.imageIds != null)
            for (const o of p.imageIds)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_RequestParametersItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_RequestParametersItem(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sessionContext))
            _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_SessionContext(p.sessionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_SessionContext(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attributes))
            _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_Attributes(p.attributes);
        if (!visitedObjects.has(p.sessionIssuer))
            _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_SessionIssuer(p.sessionIssuer);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_SessionIssuer(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_RepositoryEvents(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_ECRImageAction(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_ECRImageAction_ECRImageActionProps(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_ECRImageScan(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_ECRImageScan_ECRImageScanProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.findingSeverityCounts))
            _aws_cdk_mixins_preview_aws_ecr_events_ECRImageScan_FindingSeverityCounts(p.findingSeverityCounts);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecr_events_ECRImageScan_FindingSeverityCounts(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_ECRPullThroughCacheAction(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_ECRPullThroughCacheAction_ECRPullThroughCacheActionProps(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_ECRReferrerAction(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_ECRReferrerAction_ECRReferrerActionProps(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_ECRReplicationAction(p) {
}
function _aws_cdk_mixins_preview_aws_ecr_events_ECRReplicationAction_ECRReplicationActionProps(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (!visitedObjects.has(p.responseElements))
            _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElements(p.responseElements);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElements(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.tasks != null)
            for (const o of p.tasks)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElementsItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElementsItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.attachments != null)
            for (const o of p.attachments)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElementsItemItem(o);
        if (p.containers != null)
            for (const o of p.containers)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElementsItemItem1(o);
        if (!visitedObjects.has(p.overrides))
            _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_Overrides1(p.overrides);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_Overrides1(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.containerOverrides != null)
            for (const o of p.containerOverrides)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_Overrides1Item(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_Overrides1Item(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElementsItemItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.details != null)
            for (const o of p.details)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElementsItemItemItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElementsItemItemItem(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElementsItemItem1(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.containers != null)
            for (const o of p.containers)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_RequestParametersItem1(o);
        if (!visitedObjects.has(p.networkConfiguration))
            _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_NetworkConfiguration(p.networkConfiguration);
        if (!visitedObjects.has(p.overrides))
            _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_Overrides(p.overrides);
        if (p.placementConstraints != null)
            for (const o of p.placementConstraints)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_RequestParametersItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_NetworkConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.awsvpcConfiguration))
            _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_AwsvpcConfiguration(p.awsvpcConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_AwsvpcConfiguration(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_Overrides(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.containerOverrides != null)
            for (const o of p.containerOverrides)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_OverridesItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_OverridesItem(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_RequestParametersItem(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_RequestParametersItem1(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sessionContext))
            _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_SessionContext(p.sessionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_SessionContext(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attributes))
            _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_Attributes(p.attributes);
        if (!visitedObjects.has(p.sessionIssuer))
            _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_SessionIssuer(p.sessionIssuer);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_SessionIssuer(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ClusterEvents(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ECSContainerInstanceStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.attachments != null)
            for (const o of p.attachments)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_AttachmentDetails(o);
        if (p.attributes != null)
            for (const o of p.attributes)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_AttributesDetails(o);
        if (p.registeredResources != null)
            for (const o of p.registeredResources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ResourceDetails(o);
        if (p.remainingResources != null)
            for (const o of p.remainingResources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ResourceDetails(o);
        if (!visitedObjects.has(p.versionInfo))
            _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_VersionInfo(p.versionInfo);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_VersionInfo(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_AttachmentDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.details != null)
            for (const o of p.details)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_DetailsItems(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_DetailsItems(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ResourceDetails(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_AttributesDetails(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSServiceAction(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSServiceAction_ECSServiceActionProps(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_ECSTaskStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.attachments != null)
            for (const o of p.attachments)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_AttachmentDetails(o);
        if (p.attributes != null)
            for (const o of p.attributes)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_AttributesDetails(o);
        if (p.containers != null)
            for (const o of p.containers)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_ContainerDetails(o);
        if (!visitedObjects.has(p.overrides))
            _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_Overrides(p.overrides);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_Overrides(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.containerOverrides != null)
            for (const o of p.containerOverrides)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_OverridesItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_OverridesItem(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_AttachmentDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.details))
            _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_Details(p.details);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_Details(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_AttributesDetails(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_ContainerDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.networkBindings != null)
            for (const o of p.networkBindings)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_NetworkBindingDetails(o);
        if (p.networkInterfaces != null)
            for (const o of p.networkInterfaces)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_NetworkInterfaceDetails(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_NetworkInterfaceDetails(p) {
}
function _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_NetworkBindingDetails(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogs(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogs(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogs(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogs(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3Logs(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogs(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticache_events_CacheCreated(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_CacheCreated_CacheCreatedProps(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_CacheCreationFailed(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_CacheCreationFailed_CacheCreationFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_CacheDeleted(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_CacheDeleted_CacheDeletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_CacheLimitApproaching(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_CacheLimitApproaching_CacheLimitApproachingProps(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_CacheUpdated(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_CacheUpdated_CacheUpdatedProps(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_CacheUpdateFailed(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_CacheUpdateFailed_CacheUpdateFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCopyFailed(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCopyFailed_SnapshotCopyFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCreated(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCreated_SnapshotCreatedProps(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCreationFailed(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCreationFailed_SnapshotCreationFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotExportFailed(p) {
}
function _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotExportFailed_SnapshotExportFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogs(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogs(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogs(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogs(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRAutoScalingPolicyStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRAutoScalingPolicyStateChange_EMRAutoScalingPolicyStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRClusterStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRClusterStateChange_EMRClusterStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRConfigurationError(p) {
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRConfigurationError_EMRConfigurationErrorProps(p) {
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceFleetStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceFleetStateChange_EMRInstanceFleetStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceGroupStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceGroupStateChange_EMRInstanceGroupStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceGroupStatusNotification(p) {
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceGroupStatusNotification_EMRInstanceGroupStatusNotificationProps(p) {
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRStepStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_emr_events_EMRStepStatusChange_EMRStepStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogs(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogs(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_events_events_ScheduledJson(p) {
}
function _aws_cdk_mixins_preview_aws_events_events_ScheduledJson_ScheduledJsonProps(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogs(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogs(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogs(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_fis_events_FISExperimentStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_fis_events_FISExperimentStateChange_FISExperimentStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.newState))
            _aws_cdk_mixins_preview_aws_fis_events_FISExperimentStateChange_NewState(p.newState);
        if (!visitedObjects.has(p.oldState))
            _aws_cdk_mixins_preview_aws_fis_events_FISExperimentStateChange_OldState(p.oldState);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_fis_events_FISExperimentStateChange_NewState(p) {
}
function _aws_cdk_mixins_preview_aws_fis_events_FISExperimentStateChange_OldState(p) {
}
function _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent(p) {
}
function _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_GameLiftMatchmakingEventProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.gameSessionInfo))
            _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_GameSessionInfo(p.gameSessionInfo);
        if (p.ruleEvaluationMetrics != null)
            for (const o of p.ruleEvaluationMetrics)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_RuleEvaluationMetrics(o);
        if (p.tickets != null)
            for (const o of p.tickets)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_Ticket(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_GameSessionInfo(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.players != null)
            for (const o of p.players)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_GameSessionInfoItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_GameSessionInfoItem(p) {
}
function _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_RuleEvaluationMetrics(p) {
}
function _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_Ticket(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.players != null)
            for (const o of p.players)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_GameSessionInfoItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftQueuePlacementEvent(p) {
}
function _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftQueuePlacementEvent_GameLiftQueuePlacementEventProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.placedPlayerSessions != null)
            for (const o of p.placedPlayerSessions)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftQueuePlacementEvent_GameLiftQueuePlacementEventItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftQueuePlacementEvent_GameLiftQueuePlacementEventItem(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_GlueDataCatalogDatabaseStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_GlueDataCatalogDatabaseStateChange_GlueDataCatalogDatabaseStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_DatabaseEvents(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_GlueDataCatalogTableStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_GlueDataCatalogTableStateChange_GlueDataCatalogTableStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (!visitedObjects.has(p.responseElements))
            _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_ResponseElements(p.responseElements);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_ResponseElements(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sessionContext))
            _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_SessionContext(p.sessionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_SessionContext(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attributes))
            _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_Attributes(p.attributes);
        if (!visitedObjects.has(p.sessionIssuer))
            _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_SessionIssuer(p.sessionIssuer);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_SessionIssuer(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_JobEvents(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_GlueJobRunStatus(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_GlueJobRunStatus_GlueJobRunStatusProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.notificationCondition))
            _aws_cdk_mixins_preview_aws_glue_events_GlueJobRunStatus_NotificationCondition(p.notificationCondition);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_glue_events_GlueJobRunStatus_NotificationCondition(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_GlueJobStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_glue_events_GlueJobStateChange_GlueJobStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult_GuardDutyMalwareProtectionObjectScanResultProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3ObjectDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult_S3ObjectDetails(p.s3ObjectDetails);
        if (!visitedObjects.has(p.scanResultDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult_ScanResultDetails(p.scanResultDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult_S3ObjectDetails(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult_ScanResultDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.threats != null)
            for (const o of p.threats)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult_Threat(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult_Threat(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_GuardDutyMalwareProtectionPostScanActionFailedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.postScanActions != null)
            for (const o of p.postScanActions)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_PostScanAction(o);
        if (!visitedObjects.has(p.s3ObjectDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_S3ObjectDetails(p.s3ObjectDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_S3ObjectDetails(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_PostScanAction(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusActive(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusActive_GuardDutyMalwareProtectionResourceStatusActiveProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3BucketDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusActive_S3BucketDetails(p.s3BucketDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusActive_S3BucketDetails(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_GuardDutyMalwareProtectionResourceStatusErrorProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3BucketDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_S3BucketDetails(p.s3BucketDetails);
        if (p.statusReasons != null)
            for (const o of p.statusReasons)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_StatusReason(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_S3BucketDetails(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_StatusReason(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_GuardDutyMalwareProtectionResourceStatusWarningProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3BucketDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_S3BucketDetails(p.s3BucketDetails);
        if (p.statusReasons != null)
            for (const o of p.statusReasons)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_StatusReason(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_S3BucketDetails(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_StatusReason(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_GuardDutyFindingProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.resource))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Resource(p.resource);
        if (!visitedObjects.has(p.service))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Service(p.service);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Resource(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.accessKeyDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AccessKeyDetails(p.accessKeyDetails);
        if (!visitedObjects.has(p.containerDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ContainerDetails(p.containerDetails);
        if (!visitedObjects.has(p.ebsVolumeDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EbsVolumeDetails(p.ebsVolumeDetails);
        if (!visitedObjects.has(p.ecsClusterDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EcsClusterDetails(p.ecsClusterDetails);
        if (!visitedObjects.has(p.eksClusterDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EksClusterDetails(p.eksClusterDetails);
        if (!visitedObjects.has(p.instanceDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetails(p.instanceDetails);
        if (!visitedObjects.has(p.kubernetesDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesDetails(p.kubernetesDetails);
        if (p.s3BucketDetails != null)
            for (const o of p.s3BucketDetails)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ResourceItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AccessKeyDetails(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ContainerDetails(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EbsVolumeDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.scannedVolumeDetails != null)
            for (const o of p.scannedVolumeDetails)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EbsVolumeDetailsItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EbsVolumeDetailsItem(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EcsClusterDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EcsClusterDetailsItem(o);
        if (!visitedObjects.has(p.taskDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_TaskDetails(p.taskDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_TaskDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.containers != null)
            for (const o of p.containers)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_TaskDetailsItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_TaskDetailsItem(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EcsClusterDetailsItem(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EksClusterDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EcsClusterDetailsItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.iamInstanceProfile))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_IamInstanceProfile(p.iamInstanceProfile);
        if (p.networkInterfaces != null)
            for (const o of p.networkInterfaces)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetailsItem(o);
        if (p.productCodes != null)
            for (const o of p.productCodes)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetailsItem1(o);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EcsClusterDetailsItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_IamInstanceProfile(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetailsItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.privateIpAddresses != null)
            for (const o of p.privateIpAddresses)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetailsItemItem(o);
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetailsItemItem1(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetailsItemItem(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetailsItemItem1(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetailsItem1(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.kubernetesUserDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesUserDetails(p.kubernetesUserDetails);
        if (!visitedObjects.has(p.kubernetesWorkloadDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesWorkloadDetails(p.kubernetesWorkloadDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesUserDetails(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesWorkloadDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.containers != null)
            for (const o of p.containers)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesWorkloadDetailsItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesWorkloadDetailsItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.securityContext))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_SecurityContext(p.securityContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_SecurityContext(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ResourceItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.defaultServerSideEncryption))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_DefaultServerSideEncryption(p.defaultServerSideEncryption);
        if (!visitedObjects.has(p.owner))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Owner(p.owner);
        if (!visitedObjects.has(p.publicAccess))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_PublicAccess(p.publicAccess);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EcsClusterDetailsItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_DefaultServerSideEncryption(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Owner(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_PublicAccess(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.permissionConfiguration))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_PermissionConfiguration(p.permissionConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_PermissionConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.accountLevelPermissions))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AccountLevelPermissions(p.accountLevelPermissions);
        if (!visitedObjects.has(p.bucketLevelPermissions))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_BucketLevelPermissions(p.bucketLevelPermissions);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AccountLevelPermissions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.blockPublicAccess))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_BlockPublicAccess(p.blockPublicAccess);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_BlockPublicAccess(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_BucketLevelPermissions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.accessControlList))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AccessControlList(p.accessControlList);
        if (!visitedObjects.has(p.blockPublicAccess))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_BlockPublicAccess(p.blockPublicAccess);
        if (!visitedObjects.has(p.bucketPolicy))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AccessControlList(p.bucketPolicy);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AccessControlList(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Service(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.action))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Action(p.action);
        if (!visitedObjects.has(p.additionalInfo))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AdditionalInfo(p.additionalInfo);
        if (!visitedObjects.has(p.awsApiCallAction))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AwsApiCallAction(p.awsApiCallAction);
        if (!visitedObjects.has(p.ebsVolumeScanDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EbsVolumeScanDetails(p.ebsVolumeScanDetails);
        if (!visitedObjects.has(p.evidence))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Evidence(p.evidence);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Action(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.awsApiCallAction))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AwsApiCallAction1(p.awsApiCallAction);
        if (!visitedObjects.has(p.dnsRequestAction))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_DnsRequestAction(p.dnsRequestAction);
        if (!visitedObjects.has(p.kubernetesApiCallAction))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesApiCallAction(p.kubernetesApiCallAction);
        if (!visitedObjects.has(p.networkConnectionAction))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_NetworkConnectionAction(p.networkConnectionAction);
        if (!visitedObjects.has(p.portProbeAction))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_PortProbeAction(p.portProbeAction);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AwsApiCallAction1(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.affectedResources))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AffectedResources1(p.affectedResources);
        if (!visitedObjects.has(p.remoteAccountDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteAccountDetails(p.remoteAccountDetails);
        if (!visitedObjects.has(p.remoteIpDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails1(p.remoteIpDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AffectedResources1(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteAccountDetails(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails1(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.city))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City1(p.city);
        if (!visitedObjects.has(p.country))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country1(p.country);
        if (!visitedObjects.has(p.geoLocation))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_GeoLocation(p.geoLocation);
        if (!visitedObjects.has(p.organization))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization1(p.organization);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City1(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country1(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_GeoLocation(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization1(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_DnsRequestAction(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesApiCallAction(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.remoteIpDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails2(p.remoteIpDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails2(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.city))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City2(p.city);
        if (!visitedObjects.has(p.country))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country2(p.country);
        if (!visitedObjects.has(p.geoLocation))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_GeoLocation(p.geoLocation);
        if (!visitedObjects.has(p.organization))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization2(p.organization);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City2(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country2(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization2(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_NetworkConnectionAction(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.localIpDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_LocalIpDetails(p.localIpDetails);
        if (!visitedObjects.has(p.localPortDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_LocalPortDetails(p.localPortDetails);
        if (!visitedObjects.has(p.remoteIpDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails3(p.remoteIpDetails);
        if (!visitedObjects.has(p.remotePortDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemotePortDetails(p.remotePortDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_LocalIpDetails(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_LocalPortDetails(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails3(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.city))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City3(p.city);
        if (!visitedObjects.has(p.country))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country3(p.country);
        if (!visitedObjects.has(p.geoLocation))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_GeoLocation(p.geoLocation);
        if (!visitedObjects.has(p.organization))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization3(p.organization);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City3(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country3(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization3(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemotePortDetails(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_PortProbeAction(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.portProbeDetails != null)
            for (const o of p.portProbeDetails)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_PortProbeActionItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_PortProbeActionItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.localIpDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_LocalIpDetails1(p.localIpDetails);
        if (!visitedObjects.has(p.localPortDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_LocalPortDetails1(p.localPortDetails);
        if (!visitedObjects.has(p.remoteIpDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails4(p.remoteIpDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_LocalIpDetails1(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_LocalPortDetails1(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails4(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.city))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City4(p.city);
        if (!visitedObjects.has(p.country))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country4(p.country);
        if (!visitedObjects.has(p.geoLocation))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_GeoLocation1(p.geoLocation);
        if (!visitedObjects.has(p.organization))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization4(p.organization);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City4(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country4(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_GeoLocation1(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization4(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AdditionalInfo(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.anomalies))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Anomalies(p.anomalies);
        if (p.apiCalls != null)
            for (const o of p.apiCalls)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AdditionalInfoItem(o);
        if (!visitedObjects.has(p.newPolicy))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_NewPolicy(p.newPolicy);
        if (!visitedObjects.has(p.oldPolicy))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_OldPolicy(p.oldPolicy);
        if (!visitedObjects.has(p.profiledBehavior))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ProfiledBehavior(p.profiledBehavior);
        if (p.recentCredentials != null)
            for (const o of p.recentCredentials)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AdditionalInfoItem1(o);
        if (!visitedObjects.has(p.unusualBehavior))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_UnusualBehavior(p.unusualBehavior);
        if (!visitedObjects.has(p.userAgent))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_UserAgent(p.userAgent);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Anomalies(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_NewPolicy(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_OldPolicy(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ProfiledBehavior(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_UnusualBehavior(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_UserAgent(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AdditionalInfoItem(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AdditionalInfoItem1(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AwsApiCallAction(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.remoteIpDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails(p.remoteIpDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.city))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City(p.city);
        if (!visitedObjects.has(p.country))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country(p.country);
        if (!visitedObjects.has(p.geoLocation))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_GeoLocation(p.geoLocation);
        if (!visitedObjects.has(p.organization))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization(p.organization);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EbsVolumeScanDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.scanDetections))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ScanDetections(p.scanDetections);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ScanDetections(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.highestSeverityThreatDetails))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_HighestSeverityThreatDetails(p.highestSeverityThreatDetails);
        if (!visitedObjects.has(p.scannedItemCount))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ScannedItemCount(p.scannedItemCount);
        if (!visitedObjects.has(p.threatDetectedByName))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ThreatDetectedByName(p.threatDetectedByName);
        if (!visitedObjects.has(p.threatsDetectedItemCount))
            _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ThreatsDetectedItemCount(p.threatsDetectedItemCount);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_HighestSeverityThreatDetails(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ScannedItemCount(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ThreatDetectedByName(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.threatNames != null)
            for (const o of p.threatNames)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ThreatDetectedByNameItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ThreatDetectedByNameItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.filePaths != null)
            for (const o of p.filePaths)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ThreatDetectedByNameItemItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ThreatDetectedByNameItemItem(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ThreatsDetectedItemCount(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Evidence(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.threatIntelligenceDetails != null)
            for (const o of p.threatIntelligenceDetails)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EvidenceItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EvidenceItem(p) {
}
function _aws_cdk_mixins_preview_aws_guardduty_events_DetectorEvents(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreated(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreated_DataStoreCreatedProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_DatastoreEvents(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreating(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreating_DataStoreCreatingProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreationFailed(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreationFailed_DataStoreCreationFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreDeleted(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreDeleted_DataStoreDeletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreDeleting(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreDeleting_DataStoreDeletingProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopied(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopied_ImageSetCopiedProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopyFailed(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopyFailed_ImageSetCopyFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopying(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopying_ImageSetCopyingProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopyingWithReadOnlyAccess(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopyingWithReadOnlyAccess_ImageSetCopyingWithReadOnlyAccessProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCreated(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCreated_ImageSetCreatedProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetDeleted(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetDeleted_ImageSetDeletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetDeleting(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetDeleting_ImageSetDeletingProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdated(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdated_ImageSetUpdatedProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdateFailed(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdateFailed_ImageSetUpdateFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdating(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdating_ImageSetUpdatingProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobCompleted_ImportJobCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobFailed(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobFailed_ImportJobFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobInProgress(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobInProgress_ImportJobInProgressProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobSubmitted(p) {
}
function _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobSubmitted_ImportJobSubmittedProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreActive(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreActive_DataStoreActiveProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreCreating(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreCreating_DataStoreCreatingProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreDeleted(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreDeleted_DataStoreDeletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreDeleting(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreDeleting_DataStoreDeletingProps(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompleted_ExportJobCompletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputDataConfig))
            _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompleted_OutputDataConfig(p.outputDataConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompleted_OutputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompletedWithErrors(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompletedWithErrors_ExportJobCompletedWithErrorsProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputDataConfig))
            _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompletedWithErrors_OutputDataConfig(p.outputDataConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompletedWithErrors_OutputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobFailed(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobFailed_ExportJobFailedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputDataConfig))
            _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobFailed_OutputDataConfig(p.outputDataConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobFailed_OutputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobInProgress(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobInProgress_ExportJobInProgressProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputDataConfig))
            _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobInProgress_OutputDataConfig(p.outputDataConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobInProgress_OutputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobSubmitted(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobSubmitted_ExportJobSubmittedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputDataConfig))
            _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobSubmitted_OutputDataConfig(p.outputDataConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobSubmitted_OutputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompleted_ImportJobCompletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputDataConfig))
            _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompleted_InputDataConfig(p.inputDataConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompleted_InputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompletedWithErrors(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompletedWithErrors_ImportJobCompletedWithErrorsProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputDataConfig))
            _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompletedWithErrors_InputDataConfig(p.inputDataConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompletedWithErrors_InputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobFailed(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobFailed_ImportJobFailedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputDataConfig))
            _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobFailed_InputDataConfig(p.inputDataConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobFailed_InputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobInProgress(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobInProgress_ImportJobInProgressProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputDataConfig))
            _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobInProgress_InputDataConfig(p.inputDataConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobInProgress_InputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobSubmitted(p) {
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobSubmitted_ImportJobSubmittedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputDataConfig))
            _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobSubmitted_InputDataConfig(p.inputDataConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobSubmitted_InputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderCVEDetected(p) {
}
function _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderCVEDetected_EC2ImageBuilderCVEDetectedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.findingSeverityCounts))
            _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderCVEDetected_FindingSeverityCounts(p.findingSeverityCounts);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderCVEDetected_FindingSeverityCounts(p) {
}
function _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderImageStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderImageStateChange_EC2ImageBuilderImageStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.previousState))
            _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderImageStateChange_ImageState(p.previousState);
        if (!visitedObjects.has(p.state))
            _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderImageStateChange_ImageState(p.state);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderImageStateChange_ImageState(p) {
}
function _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderWorkflowStepWaiting(p) {
}
function _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderWorkflowStepWaiting_EC2ImageBuilderWorkflowStepWaitingProps(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (!visitedObjects.has(p.responseElements))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_ResponseElements(p.responseElements);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.channelStorage))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_ChannelStorage(p.channelStorage);
        if (!visitedObjects.has(p.datastoreStorage))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_ChannelStorage(p.datastoreStorage);
        if (!visitedObjects.has(p.loggingOptions))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_LoggingOptions(p.loggingOptions);
        if (p.payloads != null)
            for (const o of p.payloads)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RequestParametersItem(o);
        if (!visitedObjects.has(p.pipelineActivity))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_PipelineActivity(p.pipelineActivity);
        if (!visitedObjects.has(p.queryAction))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_QueryAction(p.queryAction);
        if (!visitedObjects.has(p.retentionPeriod))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RetentionPeriod(p.retentionPeriod);
        if (!visitedObjects.has(p.settings))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_Settings(p.settings);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RequestParametersItem1(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_ChannelStorage(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.customerManagedS3))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_CustomerManagedS3(p.customerManagedS3);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_CustomerManagedS3(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_LoggingOptions(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_PipelineActivity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.math))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_MathType(p.math);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_MathType(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_QueryAction(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RetentionPeriod(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_Settings(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.timeseries))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_Timeseries(p.timeseries);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_Timeseries(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.dimensionAttributes != null)
            for (const o of p.dimensionAttributes)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_TimeseriesItem(o);
        if (p.measureAttributes != null)
            for (const o of p.measureAttributes)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_TimeseriesItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_TimeseriesItem(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RequestParametersItem(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RequestParametersItem1(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_ResponseElements(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.retentionPeriod))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RetentionPeriod1(p.retentionPeriod);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RetentionPeriod1(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sessionContext))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_SessionContext(p.sessionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_SessionContext(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attributes))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_Attributes(p.attributes);
        if (!visitedObjects.has(p.sessionIssuer))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_SessionIssuer(p.sessionIssuer);
        if (!visitedObjects.has(p.webIdFederationData))
            _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_WebIdFederationData(p.webIdFederationData);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_SessionIssuer(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_WebIdFederationData(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_IoTAnalyticsDataSetLifeCycleNotification(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_IoTAnalyticsDataSetLifeCycleNotification_IoTAnalyticsDataSetLifeCycleNotificationProps(p) {
}
function _aws_cdk_mixins_preview_aws_iotanalytics_events_DatasetEvents(p) {
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogs(p) {
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogs(p) {
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogs(p) {
}
function _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (p.resources != null)
            for (const o of p.resources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(o);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.encryptionContext))
            _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_EncryptionContext(p.encryptionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_EncryptionContext(p) {
}
function _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sessionContext))
            _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_SessionContext(p.sessionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_SessionContext(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attributes))
            _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_Attributes(p.attributes);
        if (!visitedObjects.has(p.sessionIssuer))
            _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_SessionIssuer(p.sessionIssuer);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_SessionIssuer(p) {
}
function _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(p) {
}
function _aws_cdk_mixins_preview_aws_kms_events_KeyEvents(p) {
}
function _aws_cdk_mixins_preview_aws_kms_events_KMSCMKDeletion(p) {
}
function _aws_cdk_mixins_preview_aws_kms_events_KMSCMKDeletion_KMSCMKDeletionProps(p) {
}
function _aws_cdk_mixins_preview_aws_kms_events_KMSCMKRotation(p) {
}
function _aws_cdk_mixins_preview_aws_kms_events_KMSCMKRotation_KMSCMKRotationProps(p) {
}
function _aws_cdk_mixins_preview_aws_kms_events_KMSImportedKeyMaterialExpiration(p) {
}
function _aws_cdk_mixins_preview_aws_kms_events_KMSImportedKeyMaterialExpiration_KMSImportedKeyMaterialExpirationProps(p) {
}
function _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
}
function _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sessionContext))
            _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_SessionContext(p.sessionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_SessionContext(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attributes))
            _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_Attributes(p.attributes);
        if (!visitedObjects.has(p.sessionIssuer))
            _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_SessionIssuer(p.sessionIssuer);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_SessionIssuer(p) {
}
function _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_logs_events_LogGroupEvents(p) {
}
function _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogs(p) {
}
function _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_logs_ILogsDeliveryConfig(p) {
}
function _aws_cdk_mixins_preview_aws_logs_ILogsDelivery(p) {
}
function _aws_cdk_mixins_preview_aws_logs_RecordFieldDeliveryProps(p) {
}
function _aws_cdk_mixins_preview_aws_logs_DeliveryProps(p) {
}
function _aws_cdk_mixins_preview_aws_logs_S3LogsDeliveryPermissionsVersion(p) {
}
function _aws_cdk_mixins_preview_aws_logs_S3LogsDeliveryProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.permissionsVersion))
            _aws_cdk_mixins_preview_aws_logs_S3LogsDeliveryPermissionsVersion(p.permissionsVersion);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_logs_S3LogsDelivery(p) {
}
function _aws_cdk_mixins_preview_aws_logs_FirehoseLogsDelivery(p) {
}
function _aws_cdk_mixins_preview_aws_logs_LogGroupLogsDelivery(p) {
}
function _aws_cdk_mixins_preview_aws_logs_XRayLogsDelivery(p) {
}
function _aws_cdk_mixins_preview_aws_logs_DestinationLogsDelivery(p) {
}
function _aws_cdk_mixins_preview_aws_logs_S3DeliveryDestinationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.permissionsVersion))
            _aws_cdk_mixins_preview_aws_logs_S3LogsDeliveryPermissionsVersion(p.permissionsVersion);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_logs_FirehoseDeliveryDestinationProps(p) {
}
function _aws_cdk_mixins_preview_aws_logs_CloudwatchDeliveryDestinationProps(p) {
}
function _aws_cdk_mixins_preview_aws_logs_XRayDeliveryDestinationProps(p) {
}
function _aws_cdk_mixins_preview_aws_logs_S3DeliveryDestination(p) {
}
function _aws_cdk_mixins_preview_aws_logs_FirehoseDeliveryDestination(p) {
}
function _aws_cdk_mixins_preview_aws_logs_CloudwatchDeliveryDestination(p) {
}
function _aws_cdk_mixins_preview_aws_logs_XRayDeliveryDestination(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogs(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogs(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogs(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogs(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_managedblockchain_events_ManagedBlockchainInvitationStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_managedblockchain_events_ManagedBlockchainInvitationStatusChange_ManagedBlockchainInvitationStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_managedblockchain_events_ManagedBlockchainProposalStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_managedblockchain_events_ManagedBlockchainProposalStatusChange_ManagedBlockchainProposalStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelAlert(p) {
}
function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelAlert_MediaLiveChannelAlertProps(p) {
}
function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelStateChange_MediaLiveChannelStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveMultiplexAlert(p) {
}
function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveMultiplexAlert_MediaLiveMultiplexAlertProps(p) {
}
function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveMultiplexStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveMultiplexStateChange_MediaLiveMultiplexStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelInputChange(p) {
}
function _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelInputChange_MediaLiveChannelInputChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_medialive_events_ChannelEvents(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogs(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogs(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogs(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogs(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogs(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogs(p) {
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_FirewallAttachmentStatusChangedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.data != null)
            for (const o of p.data)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_DataItem(o);
        if (!visitedObjects.has(p.metadata))
            _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_Metadata(p.metadata);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_DataItem(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_Metadata(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_FirewallConfigurationChangedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.data != null)
            for (const o of p.data)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_DataItem(o);
        if (!visitedObjects.has(p.metadata))
            _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_Metadata(p.metadata);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_DataItem(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_Metadata(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallTransitGatewayAttachmentStatusChanged(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallTransitGatewayAttachmentStatusChanged_FirewallTransitGatewayAttachmentStatusChangedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.data))
            _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallTransitGatewayAttachmentStatusChanged_Data(p.data);
        if (!visitedObjects.has(p.metadata))
            _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallTransitGatewayAttachmentStatusChanged_Metadata(p.metadata);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallTransitGatewayAttachmentStatusChanged_Data(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallTransitGatewayAttachmentStatusChanged_Metadata(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogs(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogs(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogs(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_networkmanager_events_NetworkManagerPolicyUpdate(p) {
}
function _aws_cdk_mixins_preview_aws_networkmanager_events_NetworkManagerPolicyUpdate_NetworkManagerPolicyUpdateProps(p) {
}
function _aws_cdk_mixins_preview_aws_networkmanager_events_CoreNetworkEvents(p) {
}
function _aws_cdk_mixins_preview_aws_networkmanager_events_NetworkManagerSegmentUpdate(p) {
}
function _aws_cdk_mixins_preview_aws_networkmanager_events_NetworkManagerSegmentUpdate_NetworkManagerSegmentUpdateProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_AnnotationImportJobStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_AnnotationImportJobStatusChange_AnnotationImportJobStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_AnnotationStoreStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_AnnotationStoreStatusChange_AnnotationStoreStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReferenceStoreStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReferenceStoreStatusChange_ReferenceStoreStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_RunStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_RunStatusChange_RunStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_S3AccessPolicyStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_S3AccessPolicyStatusChange_S3AccessPolicyStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_SequenceStoreStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_SequenceStoreStatusChange_SequenceStoreStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_TaskStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_TaskStatusChange_TaskStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_VariantImportJobStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_VariantImportJobStatusChange_VariantImportJobStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_VariantStoreStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_VariantStoreStatusChange_VariantStoreStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_WorkflowStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_WorkflowStatusChange_WorkflowStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReferenceImportJobStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReferenceImportJobStatusChange_ReferenceImportJobStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReferenceStoreEvents(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReferenceStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReferenceStatusChange_ReferenceStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReadSetActivationJobStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReadSetActivationJobStatusChange_ReadSetActivationJobStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_SequenceStoreEvents(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReadSetExportJobStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReadSetExportJobStatusChange_ReadSetExportJobStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReadSetImportJobStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReadSetImportJobStatusChange_ReadSetImportJobStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReadSetStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_omics_events_ReadSetStatusChange_ReadSetStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksAlert(p) {
}
function _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksAlert_OpsWorksAlertProps(p) {
}
function _aws_cdk_mixins_preview_aws_opsworks_events_InstanceEvents(p) {
}
function _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksCommandStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksCommandStateChange_OpsWorksCommandStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksInstanceStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksInstanceStateChange_OpsWorksInstanceStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksDeploymentStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksDeploymentStateChange_OpsWorksDeploymentStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_opsworks_events_StackEvents(p) {
}
function _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail_AWSServiceEventViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.serviceEventDetails))
            _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail_ServiceEventDetails(p.serviceEventDetails);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail_ServiceEventDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.createAccountStatus))
            _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail_CreateAccountStatus(p.createAccountStatus);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail_CreateAccountStatus(p) {
}
function _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail_UserIdentity(p) {
}
function _aws_cdk_mixins_preview_aws_organizations_events_AccountEvents(p) {
}
function _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogs(p) {
}
function _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelineLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogs(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogs(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogs(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogs(p) {
}
function _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogs(p) {
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogs(p) {
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_qldb_events_QLDBLedgerStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_qldb_events_QLDBLedgerStateChange_QLDBLedgerStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBClusterEvent(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBClusterEvent_RDSDBClusterEventProps(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBClusterSnapshotEvent(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBClusterSnapshotEvent_RDSDBClusterSnapshotEventProps(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBInstanceEvent(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBInstanceEvent_RDSDBInstanceEventProps(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBParameterGroupEvent(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBParameterGroupEvent_RDSDBParameterGroupEventProps(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBProxyEvent(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBProxyEvent_RDSDBProxyEventProps(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBSecurityGroupEvent(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBSecurityGroupEvent_RDSDBSecurityGroupEventProps(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBSnapshotEvent(p) {
}
function _aws_cdk_mixins_preview_aws_rds_events_RDSDBSnapshotEvent_RDSDBSnapshotEventProps(p) {
}
function _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogs(p) {
}
function _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogs(p) {
}
function _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerCellReadinessStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerCellReadinessStatusChange_Route53ApplicationRecoveryControllerCellReadinessStatusChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.newState))
            _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerCellReadinessStatusChange_State(p.newState);
        if (!visitedObjects.has(p.previousState))
            _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerCellReadinessStatusChange_State(p.previousState);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerCellReadinessStatusChange_State(p) {
}
function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_CellEvents(p) {
}
function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerReadinessCheckStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerReadinessCheckStatusChange_Route53ApplicationRecoveryControllerReadinessCheckStatusChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.newState))
            _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerReadinessCheckStatusChange_State(p.newState);
        if (!visitedObjects.has(p.previousState))
            _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerReadinessCheckStatusChange_State(p.previousState);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerReadinessCheckStatusChange_State(p) {
}
function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_ReadinessCheckEvents(p) {
}
function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.newState))
            _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange_State(p.newState);
        if (!visitedObjects.has(p.previousState))
            _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange_State(p.previousState);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange_State(p) {
}
function _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_RecoveryGroupEvents(p) {
}
function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert(p) {
}
function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_DNSFirewallAlertProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.resources != null)
            for (const o of p.resources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_DnsFirewallAlertItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_DnsFirewallAlertItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.resolverEndpointDetails))
            _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_ResolverEndpointDetails(p.resolverEndpointDetails);
        if (!visitedObjects.has(p.resolverNetworkInterfaceDetails))
            _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_ResolverNetworkInterfaceDetails(p.resolverNetworkInterfaceDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_ResolverEndpointDetails(p) {
}
function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_ResolverNetworkInterfaceDetails(p) {
}
function _aws_cdk_mixins_preview_aws_route53resolver_events_FirewallDomainListEvents(p) {
}
function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock(p) {
}
function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_DNSFirewallBlockProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.resources != null)
            for (const o of p.resources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_DnsFirewallBlockItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_DnsFirewallBlockItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.resolverEndpointDetails))
            _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_ResolverEndpointDetails(p.resolverEndpointDetails);
        if (!visitedObjects.has(p.resolverNetworkInterfaceDetails))
            _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_ResolverNetworkInterfaceDetails(p.resolverNetworkInterfaceDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_ResolverEndpointDetails(p) {
}
function _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_ResolverNetworkInterfaceDetails(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogs(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogs(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpans(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.additionalEventData))
            _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AdditionalEventData(p.additionalEventData);
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (p.resources != null)
            for (const o of p.resources)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(o);
        if (!visitedObjects.has(p.tlsDetails))
            _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_TlsDetails(p.tlsDetails);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_TlsDetails(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sessionContext))
            _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_SessionContext(p.sessionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_SessionContext(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attributes))
            _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_Attributes(p.attributes);
        if (!visitedObjects.has(p.sessionIssuer))
            _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_SessionIssuer(p.sessionIssuer);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_SessionIssuer(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AdditionalEventData(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.objectRetentionInfo))
            _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_ObjectRetentionInfo(p.objectRetentionInfo);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_ObjectRetentionInfo(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.legalHoldInfo))
            _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_LegalHoldInfo(p.legalHoldInfo);
        if (!visitedObjects.has(p.retentionInfo))
            _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_RetentionInfo(p.retentionInfo);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_LegalHoldInfo(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_RetentionInfo(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_BucketEvents(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectAccessTierChanged(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectAccessTierChanged_ObjectAccessTierChangedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.bucket))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectAccessTierChanged_Bucket(p.bucket);
        if (!visitedObjects.has(p.object))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectAccessTierChanged_ObjectType(p.object);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectAccessTierChanged_Bucket(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectAccessTierChanged_ObjectType(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectACLUpdated(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectACLUpdated_ObjectACLUpdatedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.bucket))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectACLUpdated_Bucket(p.bucket);
        if (!visitedObjects.has(p.object))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectACLUpdated_ObjectType(p.object);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectACLUpdated_Bucket(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectACLUpdated_ObjectType(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectCreated(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectCreated_ObjectCreatedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.bucket))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectCreated_Bucket(p.bucket);
        if (!visitedObjects.has(p.object))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectCreated_ObjectType(p.object);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectCreated_Bucket(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectCreated_ObjectType(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectDeleted(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectDeleted_ObjectDeletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.bucket))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectDeleted_Bucket(p.bucket);
        if (!visitedObjects.has(p.object))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectDeleted_ObjectType(p.object);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectDeleted_Bucket(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectDeleted_ObjectType(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreCompleted_ObjectRestoreCompletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.bucket))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreCompleted_Bucket(p.bucket);
        if (!visitedObjects.has(p.object))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreCompleted_ObjectType(p.object);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreCompleted_Bucket(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreCompleted_ObjectType(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreExpired(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreExpired_ObjectRestoreExpiredProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.bucket))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreExpired_Bucket(p.bucket);
        if (!visitedObjects.has(p.object))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreExpired_ObjectType(p.object);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreExpired_Bucket(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreExpired_ObjectType(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreInitiated(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreInitiated_ObjectRestoreInitiatedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.bucket))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreInitiated_Bucket(p.bucket);
        if (!visitedObjects.has(p.object))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreInitiated_ObjectType(p.object);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreInitiated_Bucket(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreInitiated_ObjectType(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectStorageClassChanged(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectStorageClassChanged_ObjectStorageClassChangedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.bucket))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectStorageClassChanged_Bucket(p.bucket);
        if (!visitedObjects.has(p.object))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectStorageClassChanged_ObjectType(p.object);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectStorageClassChanged_Bucket(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectStorageClassChanged_ObjectType(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsAdded(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsAdded_ObjectTagsAddedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.bucket))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsAdded_Bucket(p.bucket);
        if (!visitedObjects.has(p.object))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsAdded_ObjectType(p.object);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsAdded_Bucket(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsAdded_ObjectType(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsDeleted(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsDeleted_ObjectTagsDeletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.bucket))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsDeleted_Bucket(p.bucket);
        if (!visitedObjects.has(p.object))
            _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsDeleted_ObjectType(p.object);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsDeleted_Bucket(p) {
}
function _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsDeleted_ObjectType(p) {
}
function _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogs(p) {
}
function _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerAlgorithmStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerAlgorithmStateChange_SageMakerAlgorithmStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerAlgorithmStateChange_Tags(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerAlgorithmStateChange_Tags(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointStateChange_SageMakerEndpointStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointStateChange_Tags(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointStateChange_Tags(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerGroundTruthLabelingJobTaskStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerGroundTruthLabelingJobTaskStatusChange_SageMakerGroundTruthLabelingJobTaskStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_SageMakerHyperParameterTuningJobStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.objectiveStatusCounters))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_ObjectiveStatusCounters(p.objectiveStatusCounters);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_Tags(o);
        if (!visitedObjects.has(p.trainingJobDefinition))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_TrainingJobDefinition(p.trainingJobDefinition);
        if (!visitedObjects.has(p.trainingJobStatusCounters))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_TrainingJobStatusCounters(p.trainingJobStatusCounters);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_TrainingJobStatusCounters(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_ObjectiveStatusCounters(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_TrainingJobDefinition(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.algorithmSpecification))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_AlgorithmSpecification(p.algorithmSpecification);
        if (p.inputDataConfig != null)
            for (const o of p.inputDataConfig)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_TrainingJobDefinitionItem(o);
        if (!visitedObjects.has(p.outputDataConfig))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_OutputDataConfig(p.outputDataConfig);
        if (!visitedObjects.has(p.resourceConfig))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_ResourceConfig(p.resourceConfig);
        if (!visitedObjects.has(p.staticHyperParameters))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_Tags(p.staticHyperParameters);
        if (!visitedObjects.has(p.stoppingCondition))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_StoppingCondition(p.stoppingCondition);
        if (!visitedObjects.has(p.vpcConfig))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_VpcConfig(p.vpcConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_AlgorithmSpecification(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.metricDefinitions != null)
            for (const o of p.metricDefinitions)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_AlgorithmSpecificationItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_AlgorithmSpecificationItem(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_StoppingCondition(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_VpcConfig(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_OutputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_Tags(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_ResourceConfig(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_TrainingJobDefinitionItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.dataSource))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_DataSource(p.dataSource);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_DataSource(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3DataSource))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_S3DataSource(p.s3DataSource);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_S3DataSource(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStatusChange_SageMakerModelBuildingPipelineExecutionStatusChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange_SageMakerModelBuildingPipelineExecutionStepStatusChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.cacheHitResult))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange_CacheHitResult(p.cacheHitResult);
        if (!visitedObjects.has(p.metadata))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange_Metadata(p.metadata);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange_CacheHitResult(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange_Metadata(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.processingJob))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange_ProcessingJob(p.processingJob);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange_ProcessingJob(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelPackageStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelPackageStateChange_SageMakerModelPackageStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelPackageStateChange_Tags(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelPackageStateChange_Tags(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_SageMakerModelStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.primaryContainer))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_PrimaryContainer(p.primaryContainer);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_Tags(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_PrimaryContainer(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_Tags(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookInstanceStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookInstanceStateChange_SageMakerNotebookInstanceStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookInstanceStateChange_Tags(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookInstanceStateChange_Tags(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookLifecycleConfigStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookLifecycleConfigStateChange_SageMakerNotebookLifecycleConfigStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookLifecycleConfigStateChange_Tags(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookLifecycleConfigStateChange_Tags(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.algorithmSpecification))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_AlgorithmSpecification(p.algorithmSpecification);
        if (p.inputDataConfig != null)
            for (const o of p.inputDataConfig)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeItem(o);
        if (!visitedObjects.has(p.modelArtifacts))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_ModelArtifacts(p.modelArtifacts);
        if (!visitedObjects.has(p.outputDataConfig))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_OutputDataConfig(p.outputDataConfig);
        if (!visitedObjects.has(p.resourceConfig))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_ResourceConfig(p.resourceConfig);
        if (p.secondaryStatusTransitions != null)
            for (const o of p.secondaryStatusTransitions)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeItem1(o);
        if (!visitedObjects.has(p.stoppingCondition))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_StoppingCondition(p.stoppingCondition);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_Tags(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_AlgorithmSpecification(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_OutputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_ModelArtifacts(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_StoppingCondition(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_ResourceConfig(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_Tags(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.dataSource))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_DataSource(p.dataSource);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_DataSource(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3DataSource))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_S3DataSource(p.s3DataSource);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_S3DataSource(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeItem1(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_SageMakerEndpointConfigStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.productionVariants != null)
            for (const o of p.productionVariants)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_SageMakerEndpointConfigStateChangeItem(o);
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_Tags(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_Tags(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_SageMakerEndpointConfigStateChangeItem(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_EndpointConfigEvents(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.requestParameters))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_RequestParameters(p.requestParameters);
        if (!visitedObjects.has(p.responseElements))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_ResponseElements(p.responseElements);
        if (!visitedObjects.has(p.userIdentity))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_UserIdentity(p.userIdentity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_ResponseElements(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_RequestParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.algorithmSpecification))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_AlgorithmSpecification(p.algorithmSpecification);
        if (!visitedObjects.has(p.hyperParameters))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_HyperParameters(p.hyperParameters);
        if (p.inputDataConfig != null)
            for (const o of p.inputDataConfig)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_RequestParametersItem2(o);
        if (!visitedObjects.has(p.outputDataConfig))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_OutputDataConfig(p.outputDataConfig);
        if (!visitedObjects.has(p.primaryContainer))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_PrimaryContainer(p.primaryContainer);
        if (p.productionVariants != null)
            for (const o of p.productionVariants)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_RequestParametersItem(o);
        if (!visitedObjects.has(p.resourceConfig))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_ResourceConfig(p.resourceConfig);
        if (!visitedObjects.has(p.stoppingCondition))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_StoppingCondition(p.stoppingCondition);
        if (!visitedObjects.has(p.transformInput))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_TransformInput(p.transformInput);
        if (!visitedObjects.has(p.transformOutput))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_TransformOutput(p.transformOutput);
        if (!visitedObjects.has(p.transformResources))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_TransformResources(p.transformResources);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_PrimaryContainer(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_StoppingCondition(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_OutputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_TransformInput(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.dataSource))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_DataSource(p.dataSource);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_DataSource(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3DataSource))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_S3DataSource(p.s3DataSource);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_S3DataSource(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_AlgorithmSpecification(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_ResourceConfig(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_TransformOutput(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_HyperParameters(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_TransformResources(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_RequestParametersItem(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_RequestParametersItem2(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.dataSource))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_DataSource1(p.dataSource);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_DataSource1(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3DataSource))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_S3DataSource1(p.s3DataSource);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_S3DataSource1(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_UserIdentity(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sessionContext))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_SessionContext(p.sessionContext);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_SessionContext(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.attributes))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_Attributes(p.attributes);
        if (!visitedObjects.has(p.sessionIssuer))
            _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_SessionIssuer(p.sessionIssuer);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_SessionIssuer(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_ModelEvents(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_SageMakerTransformJobStateChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.tags != null)
            for (const o of p.tags)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_Tags(o);
        if (!visitedObjects.has(p.transformInput))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_TransformInput(p.transformInput);
        if (!visitedObjects.has(p.transformOutput))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_TransformOutput(p.transformOutput);
        if (!visitedObjects.has(p.transformResources))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_TransformResources(p.transformResources);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_TransformResources(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_TransformOutput(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_TransformInput(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.dataSource))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_DataSource(p.dataSource);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_DataSource(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3DataSource))
            _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_S3DataSource(p.s3DataSource);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_S3DataSource(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_Tags(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogs(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubFindingsCustomAction(p) {
}
function _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubFindingsCustomAction_SecurityHubFindingsCustomActionProps(p) {
}
function _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubFindingsImported(p) {
}
function _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubFindingsImported_SecurityHubFindingsImportedProps(p) {
}
function _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubInsightResults(p) {
}
function _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubInsightResults_SecurityHubInsightResultsProps(p) {
}
function _aws_cdk_mixins_preview_aws_ses_events_AdvisorRecommendationStatusOpen(p) {
}
function _aws_cdk_mixins_preview_aws_ses_events_AdvisorRecommendationStatusOpen_AdvisorRecommendationStatusOpenProps(p) {
}
function _aws_cdk_mixins_preview_aws_ses_events_AdvisorRecommendationStatusResolved(p) {
}
function _aws_cdk_mixins_preview_aws_ses_events_AdvisorRecommendationStatusResolved_AdvisorRecommendationStatusResolvedProps(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogs(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogs(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogs(p) {
}
function _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_ssm_events_CalendarStateChange(p) {
}
function _aws_cdk_mixins_preview_aws_ssm_events_CalendarStateChange_CalendarStateChangeProps(p) {
}
function _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogs(p) {
}
function _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogs(p) {
}
function _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange(p) {
}
function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange_SyntheticsCanaryStatusChangeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.changedConfig))
            _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange_ChangedConfig(p.changedConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange_ChangedConfig(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.executionArn))
            _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange_ExecutionArn(p.executionArn);
        if (!visitedObjects.has(p.testCodeLayerVersionArn))
            _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange_TestCodeLayerVersionArn(p.testCodeLayerVersionArn);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange_ExecutionArn(p) {
}
function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange_TestCodeLayerVersionArn(p) {
}
function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunFailure(p) {
}
function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunFailure_SyntheticsCanaryTestRunFailureProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.canaryRunTimeline))
            _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunFailure_CanaryRunTimeline(p.canaryRunTimeline);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunFailure_CanaryRunTimeline(p) {
}
function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunSuccessful(p) {
}
function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunSuccessful_SyntheticsCanaryTestRunSuccessfulProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.canaryRunTimeline))
            _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunSuccessful_CanaryRunTimeline(p.canaryRunTimeline);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunSuccessful_CanaryRunTimeline(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryCreateCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryCreateCompleted_FTPServerDirectoryCreateCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryCreateFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryCreateFailed_FTPServerDirectoryCreateFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryDeleteCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryDeleteCompleted_FTPServerDirectoryDeleteCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryDeleteFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryDeleteFailed_FTPServerDirectoryDeleteFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDeleteCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDeleteCompleted_FTPServerFileDeleteCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDeleteFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDeleteFailed_FTPServerFileDeleteFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDownloadCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDownloadCompleted_FTPServerFileDownloadCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDownloadFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDownloadFailed_FTPServerFileDownloadFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileRenameCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileRenameCompleted_FTPServerFileRenameCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileRenameFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileRenameFailed_FTPServerFileRenameFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileUploadCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileUploadCompleted_FTPServerFileUploadCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileUploadFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileUploadFailed_FTPServerFileUploadFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryCreateCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryCreateCompleted_FTPSServerDirectoryCreateCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryCreateFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryCreateFailed_FTPSServerDirectoryCreateFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryDeleteCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryDeleteCompleted_FTPSServerDirectoryDeleteCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryDeleteFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryDeleteFailed_FTPSServerDirectoryDeleteFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDeleteCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDeleteCompleted_FTPSServerFileDeleteCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDeleteFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDeleteFailed_FTPSServerFileDeleteFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDownloadCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDownloadCompleted_FTPSServerFileDownloadCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDownloadFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDownloadFailed_FTPSServerFileDownloadFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileRenameCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileRenameCompleted_FTPSServerFileRenameCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileRenameFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileRenameFailed_FTPSServerFileRenameFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileUploadCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileUploadCompleted_FTPSServerFileUploadCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileUploadFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileUploadFailed_FTPSServerFileUploadFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryCreateCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryCreateCompleted_SFTPServerDirectoryCreateCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryCreateFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryCreateFailed_SFTPServerDirectoryCreateFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryDeleteCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryDeleteCompleted_SFTPServerDirectoryDeleteCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryDeleteFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryDeleteFailed_SFTPServerDirectoryDeleteFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDeleteCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDeleteCompleted_SFTPServerFileDeleteCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDeleteFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDeleteFailed_SFTPServerFileDeleteFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDownloadCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDownloadCompleted_SFTPServerFileDownloadCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDownloadFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDownloadFailed_SFTPServerFileDownloadFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileRenameCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileRenameCompleted_SFTPServerFileRenameCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileRenameFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileRenameFailed_SFTPServerFileRenameFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileUploadCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileUploadCompleted_SFTPServerFileUploadCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileUploadFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileUploadFailed_SFTPServerFileUploadFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendCompleted_AS2MDNSendCompletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3Attributes))
            _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendCompleted_S3Attributes(p.s3Attributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendCompleted_S3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AgreementEvents(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendFailed_AS2MDNSendFailedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3Attributes))
            _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendFailed_S3Attributes(p.s3Attributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendFailed_S3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveCompleted_AS2PayloadReceiveCompletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3Attributes))
            _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveCompleted_S3Attributes(p.s3Attributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveCompleted_S3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveFailed_AS2PayloadReceiveFailedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3Attributes))
            _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveFailed_S3Attributes(p.s3Attributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveFailed_S3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveCompleted_AS2MDNReceiveCompletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3Attributes))
            _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveCompleted_S3Attributes(p.s3Attributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveCompleted_S3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_ConnectorEvents(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveFailed_AS2MDNReceiveFailedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3Attributes))
            _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveFailed_S3Attributes(p.s3Attributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveFailed_S3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendCompleted_AS2PayloadSendCompletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3Attributes))
            _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendCompleted_S3Attributes(p.s3Attributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendCompleted_S3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendFailed_AS2PayloadSendFailedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3Attributes))
            _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendFailed_S3Attributes(p.s3Attributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendFailed_S3Attributes(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingCompleted_SFTPConnectorDirectoryListingCompletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFileLocation))
            _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingCompleted_OutputFileLocation(p.outputFileLocation);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingCompleted_OutputFileLocation(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingFailed_SFTPConnectorDirectoryListingFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveCompleted_SFTPConnectorFileRetrieveCompletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.localFileLocation))
            _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveCompleted_LocalFileLocation(p.localFileLocation);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveCompleted_LocalFileLocation(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveFailed_SFTPConnectorFileRetrieveFailedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.localFileLocation))
            _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveFailed_LocalFileLocation(p.localFileLocation);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveFailed_LocalFileLocation(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendCompleted_SFTPConnectorFileSendCompletedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.localFileLocation))
            _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendCompleted_LocalFileLocation(p.localFileLocation);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendCompleted_LocalFileLocation(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendFailed_SFTPConnectorFileSendFailedProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.localFileLocation))
            _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendFailed_LocalFileLocation(p.localFileLocation);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendFailed_LocalFileLocation(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteDeleteCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteDeleteCompleted_SFTPConnectorRemoteDeleteCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteDeleteFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteDeleteFailed_SFTPConnectorRemoteDeleteFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteMoveCompleted(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteMoveCompleted_SFTPConnectorRemoteMoveCompletedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteMoveFailed(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteMoveFailed_SFTPConnectorRemoteMoveFailedProps(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogs(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_VoiceIdBatchFraudsterRegistrationActionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.data))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_Data(p.data);
        if (!visitedObjects.has(p.errorInfo))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_ErrorInfo(p.errorInfo);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_Data(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputDataConfig))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_InputDataConfig(p.inputDataConfig);
        if (!visitedObjects.has(p.outputDataConfig))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_OutputDataConfig(p.outputDataConfig);
        if (!visitedObjects.has(p.registrationConfig))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_RegistrationConfig(p.registrationConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_InputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_OutputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_RegistrationConfig(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_ErrorInfo(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_DomainEvents(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_VoiceIdBatchSpeakerEnrollmentActionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.data))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_Data(p.data);
        if (!visitedObjects.has(p.errorInfo))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_ErrorInfo(p.errorInfo);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_Data(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.enrollmentConfig))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_EnrollmentConfig(p.enrollmentConfig);
        if (!visitedObjects.has(p.inputDataConfig))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_InputDataConfig(p.inputDataConfig);
        if (!visitedObjects.has(p.outputDataConfig))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_OutputDataConfig(p.outputDataConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_EnrollmentConfig(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.fraudDetectionConfig))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_FraudDetectionConfig(p.fraudDetectionConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_FraudDetectionConfig(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_InputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_OutputDataConfig(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_ErrorInfo(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_VoiceIdEvaluateSessionActionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.errorInfo))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_ErrorInfo(p.errorInfo);
        if (!visitedObjects.has(p.session))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_Session(p.session);
        if (!visitedObjects.has(p.systemAttributes))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_SystemAttributes(p.systemAttributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_ErrorInfo(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_Session(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.authenticationResult))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_AuthenticationResult(p.authenticationResult);
        if (!visitedObjects.has(p.fraudDetectionResult))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_FraudDetectionResult(p.fraudDetectionResult);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_AuthenticationResult(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.configuration))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_ConfigurationAuthentication(p.configuration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_ConfigurationAuthentication(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_FraudDetectionResult(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.configuration))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_ConfigurationFraud(p.configuration);
        if (!visitedObjects.has(p.riskDetails))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_RiskDetails(p.riskDetails);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_ConfigurationFraud(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_RiskDetails(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.knownFraudsterRisk))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_KnownFraudsterRisk(p.knownFraudsterRisk);
        if (!visitedObjects.has(p.voiceSpoofingRisk))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_VoiceSpoofingRisk(p.voiceSpoofingRisk);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_KnownFraudsterRisk(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_VoiceSpoofingRisk(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_SystemAttributes(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdFraudsterAction(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdFraudsterAction_VoiceIdFraudsterActionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.data))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdFraudsterAction_Data(p.data);
        if (!visitedObjects.has(p.errorInfo))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdFraudsterAction_ErrorInfo(p.errorInfo);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdFraudsterAction_Data(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdFraudsterAction_ErrorInfo(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSessionSpeakerEnrollmentAction(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSessionSpeakerEnrollmentAction_VoiceIdSessionSpeakerEnrollmentActionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.errorInfo))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSessionSpeakerEnrollmentAction_ErrorInfo(p.errorInfo);
        if (!visitedObjects.has(p.systemAttributes))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSessionSpeakerEnrollmentAction_SystemAttributes(p.systemAttributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSessionSpeakerEnrollmentAction_ErrorInfo(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSessionSpeakerEnrollmentAction_SystemAttributes(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction_VoiceIdSpeakerActionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.data))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction_Data(p.data);
        if (!visitedObjects.has(p.errorInfo))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction_ErrorInfo(p.errorInfo);
        if (!visitedObjects.has(p.systemAttributes))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction_SystemAttributes(p.systemAttributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction_Data(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction_ErrorInfo(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction_SystemAttributes(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_VoiceIdStartSessionActionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.errorInfo))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_ErrorInfo(p.errorInfo);
        if (!visitedObjects.has(p.session))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_Session(p.session);
        if (!visitedObjects.has(p.systemAttributes))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_SystemAttributes(p.systemAttributes);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_ErrorInfo(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_Session(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.authenticationAudioProgress))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_AuthenticationAudioProgress(p.authenticationAudioProgress);
        if (!visitedObjects.has(p.authenticationConfiguration))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_AuthenticationConfiguration(p.authenticationConfiguration);
        if (!visitedObjects.has(p.enrollmentAudioProgress))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_EnrollmentAudioProgress(p.enrollmentAudioProgress);
        if (!visitedObjects.has(p.fraudDetectionAudioProgress))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_AuthenticationAudioProgress(p.fraudDetectionAudioProgress);
        if (!visitedObjects.has(p.fraudDetectionConfiguration))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_FraudDetectionConfiguration(p.fraudDetectionConfiguration);
        if (!visitedObjects.has(p.streamingConfiguration))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_StreamingConfiguration(p.streamingConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_AuthenticationAudioProgress(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_AuthenticationConfiguration(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_EnrollmentAudioProgress(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_FraudDetectionConfiguration(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_StreamingConfiguration(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_SystemAttributes(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_VoiceIdUpdateSessionActionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.errorInfo))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_ErrorInfo(p.errorInfo);
        if (!visitedObjects.has(p.session))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_Session(p.session);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_ErrorInfo(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_Session(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.authenticationConfiguration))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_AuthenticationConfiguration(p.authenticationConfiguration);
        if (!visitedObjects.has(p.fraudDetectionConfiguration))
            _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_FraudDetectionConfiguration(p.fraudDetectionConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_AuthenticationConfiguration(p) {
}
function _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_FraudDetectionConfiguration(p) {
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogs(p) {
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogs(p) {
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogs(p) {
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogs(p) {
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsOutputFormat_S3(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsOutputFormat_LogGroup(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsOutputFormat_Firehose(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogs(p) {
}
function _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantLogsMixin(p) {
}
function _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsOutputFormat(p) {
}
function _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsOutputFormat_S3(p) {
}
function _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsOutputFormat_LogGroup(p) {
}
function _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsOutputFormat_Firehose(p) {
}
function _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsRecordFields(p) {
}
function _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsS3Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsOutputFormat_S3(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsLogGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsOutputFormat_LogGroup(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsFirehoseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsOutputFormat_Firehose(p.outputFormat);
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsDestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.recordFields != null)
            for (const o of p.recordFields)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsRecordFields(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_workspaces_events_WorkSpacesAccess(p) {
}
function _aws_cdk_mixins_preview_aws_workspaces_events_WorkSpacesAccess_WorkSpacesAccessProps(p) {
}
function _aws_cdk_mixins_preview_aws_workspaces_events_WorkspaceEvents(p) {
}
function _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate(p) {
}
function _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_AWSXRayInsightUpdateProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.clientRequestImpactStatistics))
            _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_ClientRequestImpactStatistics(p.clientRequestImpactStatistics);
        if (!visitedObjects.has(p.event))
            _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_Event(p.event);
        if (!visitedObjects.has(p.rootCauseServiceId))
            _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_RootCauseServiceId(p.rootCauseServiceId);
        if (!visitedObjects.has(p.rootCauseServiceRequestImpactStatistics))
            _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_ClientRequestImpactStatistics(p.rootCauseServiceRequestImpactStatistics);
        if (p.topAnomalousServices != null)
            for (const o of p.topAnomalousServices)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_AwsxRayInsightUpdateItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_ClientRequestImpactStatistics(p) {
}
function _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_Event(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.clientRequestImpactStatistics))
            _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_ClientRequestImpactStatistics(p.clientRequestImpactStatistics);
        if (!visitedObjects.has(p.rootCauseServiceRequestImpactStatistics))
            _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_ClientRequestImpactStatistics(p.rootCauseServiceRequestImpactStatistics);
        if (p.topAnomalousServices != null)
            for (const o of p.topAnomalousServices)
                if (!visitedObjects.has(o))
                    _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_AwsxRayInsightUpdateItem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_AwsxRayInsightUpdateItem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.serviceId))
            _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_ServiceId(p.serviceId);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_ServiceId(p) {
}
function _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_RootCauseServiceId(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogs, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogs, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiLogsMixin, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsOutputFormat, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsRecordFields, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsS3Props, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsLogGroupProps, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsFirehoseProps, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiExecutionLogsDestProps, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsOutputFormat, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsRecordFields, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsS3Props, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsLogGroupProps, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsFirehoseProps, _aws_cdk_mixins_preview_aws_apigateway_mixins_CfnRestApiAccessLogsDestProps, _aws_cdk_mixins_preview_aws_appmesh_events_AWSServiceEventViaCloudTrail, _aws_cdk_mixins_preview_aws_appmesh_events_AWSServiceEventViaCloudTrail_AWSServiceEventViaCloudTrailProps, _aws_cdk_mixins_preview_aws_appmesh_events_AWSServiceEventViaCloudTrail_ServiceEventDetails, _aws_cdk_mixins_preview_aws_appmesh_events_AWSServiceEventViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogs, _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceLogsMixin, _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsOutputFormat, _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsS3Props, _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsLogGroupProps, _aws_cdk_mixins_preview_aws_aps_mixins_CfnWorkspaceManagedPrometheusLogsFirehoseProps, _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogs, _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperLogsMixin, _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_aps_mixins_CfnScraperApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_athena_events_AthenaQueryStateChange, _aws_cdk_mixins_preview_aws_athena_events_AthenaQueryStateChange_AthenaQueryStateChangeProps, _aws_cdk_mixins_preview_aws_athena_events_WorkGroupEvents, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_ResponseElements, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_TargetTrackingConfiguration, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_PredefinedMetricSpecification, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_CustomizedMetricSpecification, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_CustomizedMetricSpecificationItem, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_MixedInstancesPolicy, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_LaunchTemplate1, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_LaunchTemplateSpecification, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_InstancesDistribution, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_LaunchTemplate, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_RequestParametersItem, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_RequestParametersItem1, _aws_cdk_mixins_preview_aws_autoscaling_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchLifecycleAction, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchLifecycleAction_EC2InstanceLaunchLifecycleActionProps, _aws_cdk_mixins_preview_aws_autoscaling_events_AutoScalingGroupEvents, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchSuccessful, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchSuccessful_EC2InstanceLaunchSuccessfulProps, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchSuccessful_Details, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchUnsuccessful, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchUnsuccessful_EC2InstanceLaunchUnsuccessfulProps, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceLaunchUnsuccessful_Details, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateLifecycleAction, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateLifecycleAction_EC2InstanceTerminateLifecycleActionProps, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateSuccessful, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateSuccessful_EC2InstanceTerminateSuccessfulProps, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateSuccessful_Details, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateUnsuccessful, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateUnsuccessful_EC2InstanceTerminateUnsuccessfulProps, _aws_cdk_mixins_preview_aws_autoscaling_events_EC2InstanceTerminateUnsuccessful_Details, _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementCompleted, _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementCompleted_AcknowledgementCompletedProps, _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementCompleted_AckFileS3Attributes, _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementCompleted_InputFileS3Attributes, _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementFailed, _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementFailed_AcknowledgementFailedProps, _aws_cdk_mixins_preview_aws_b2bi_events_AcknowledgementFailed_InputFileS3Attributes, _aws_cdk_mixins_preview_aws_b2bi_events_TransformationCompleted, _aws_cdk_mixins_preview_aws_b2bi_events_TransformationCompleted_TransformationCompletedProps, _aws_cdk_mixins_preview_aws_b2bi_events_TransformationCompleted_InputFileS3Attributes, _aws_cdk_mixins_preview_aws_b2bi_events_TransformationCompleted_OutputFileS3Attributes, _aws_cdk_mixins_preview_aws_b2bi_events_TransformationFailed, _aws_cdk_mixins_preview_aws_b2bi_events_TransformationFailed_TransformationFailedProps, _aws_cdk_mixins_preview_aws_b2bi_events_TransformationFailed_InputFileS3Attributes, _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogs, _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerLogsMixin, _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsOutputFormat, _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsS3Props, _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsLogGroupProps, _aws_cdk_mixins_preview_aws_b2bi_mixins_CfnTransformerB2biExecutionLogsFirehoseProps, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogs, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogs, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorLogsMixin, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsOutputFormat, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsS3Props, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsLogGroupProps, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorBgwHypervisorLogsFirehoseProps, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsOutputFormat, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsS3Props, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsLogGroupProps, _aws_cdk_mixins_preview_aws_backupgateway_mixins_CfnHypervisorDataAccessLogsFirehoseProps, _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_ResponseElements, _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_ContainerOverrides, _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_ContainerOverridesItem, _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_SessionContext, _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_SessionIssuer, _aws_cdk_mixins_preview_aws_batch_events_AWSAPICallViaCloudTrail_Attributes, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_BatchJobStateChangeProps, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_Container, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_Volumes, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_Host, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_ResourceRequirement, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_ContainerItem, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_ULimit, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_NetworkInterface, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_MountPoint, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_RetryStrategy, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_JobDependency, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_BatchJobStateChangeItem, _aws_cdk_mixins_preview_aws_batch_events_BatchJobStateChange_Container1, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogs, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentLogsMixin, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsRecordFields, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentApplicationLogsDestProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogs, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasLogsMixin, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsOutputFormat, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsRecordFields, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsS3Props, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsLogGroupProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsFirehoseProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnAgentAliasEventLogsDestProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogs, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowLogsMixin, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsRecordFields, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnFlowApplicationLogsDestProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogs, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogs, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseTraces, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseLogsMixin, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsRecordFields, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseApplicationLogsDestProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsOutputFormat, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsRecordFields, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsS3Props, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsLogGroupProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsFirehoseProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseRuntimeLogsDestProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseTracesOutputFormat, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseTracesRecordFields, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseTracesXRayProps, _aws_cdk_mixins_preview_aws_bedrock_mixins_CfnKnowledgeBaseTracesDestProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogs, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomLogsMixin, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsOutputFormat, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsRecordFields, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsS3Props, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsLogGroupProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsFirehoseProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnBrowserCustomUsageLogsDestProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogs, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogs, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomLogsMixin, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsRecordFields, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomApplicationLogsDestProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsOutputFormat, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsRecordFields, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsS3Props, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsLogGroupProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsFirehoseProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnCodeInterpreterCustomUsageLogsDestProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogs, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayTraces, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayLogsMixin, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsRecordFields, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayApplicationLogsDestProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayTracesOutputFormat, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayTracesRecordFields, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayTracesXRayProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnGatewayTracesDestProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogs, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryTraces, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryLogsMixin, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsRecordFields, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryApplicationLogsDestProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryTracesOutputFormat, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryTracesRecordFields, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryTracesXRayProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnMemoryTracesDestProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogs, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeTraces, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogs, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeLogsMixin, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsRecordFields, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeApplicationLogsDestProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeTracesOutputFormat, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeTracesRecordFields, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeTracesXRayProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeTracesDestProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsOutputFormat, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsRecordFields, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsS3Props, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsLogGroupProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsFirehoseProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnRuntimeUsageLogsDestProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogs, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityLogsMixin, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsRecordFields, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_bedrockagentcore_mixins_CfnWorkloadIdentityApplicationLogsDestProps, _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogs, _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipLogsMixin, _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsOutputFormat, _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsS3Props, _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsLogGroupProps, _aws_cdk_mixins_preview_aws_cleanrooms_mixins_CfnMembershipAnalysisLogsFirehoseProps, _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress, _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress_CloudFormationHookInvocationProgressProps, _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress_HookDetail, _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress_Result, _aws_cdk_mixins_preview_aws_cloudformation_events_CloudFormationHookInvocationProgress_TargetDetail, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogs, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogs, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionLogsMixin, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsOutputFormat, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsRecordFields, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsS3Props, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsLogGroupProps, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsFirehoseProps, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionConnectionLogsDestProps, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsOutputFormat, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsRecordFields, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsS3Props, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsLogGroupProps, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsFirehoseProps, _aws_cdk_mixins_preview_aws_cloudfront_mixins_CfnDistributionAccessLogsDestProps, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_CloudWatchAlarmConfigurationChangeProps, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_Configuration, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_ConfigurationItem, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_MetricStat, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_Metric, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmConfigurationChange_State, _aws_cdk_mixins_preview_aws_cloudwatch_events_AlarmEvents, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_CloudWatchAlarmStateChangeProps, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_Configuration, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_ConfigurationItem, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_MetricStat, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_Metric, _aws_cdk_mixins_preview_aws_cloudwatch_events_CloudWatchAlarmStateChange_State, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_ResponseElements, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Build, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Artifacts, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Cache, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Environment, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_EnvironmentItem, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Logs, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Source, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Auth, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_VpcConfig, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_BuildPhase, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Project, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Artifacts1, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Badge, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Environment1, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Source1, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_GitSubmodulesConfig, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_ProjectItem, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Webhook, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_SessionContext, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_Attributes, _aws_cdk_mixins_preview_aws_codebuild_events_AWSAPICallViaCloudTrail_SessionIssuer, _aws_cdk_mixins_preview_aws_codebuild_events_AWSServiceEventViaCloudTrail, _aws_cdk_mixins_preview_aws_codebuild_events_AWSServiceEventViaCloudTrail_AWSServiceEventViaCloudTrailProps, _aws_cdk_mixins_preview_aws_codebuild_events_AWSServiceEventViaCloudTrail_ServiceEventDetails, _aws_cdk_mixins_preview_aws_codebuild_events_AWSServiceEventViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_CodeBuildBuildPhaseChangeProps, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_AdditionalInformation, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Artifact, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Cache, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Environment, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_EnvironmentItem, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Logs, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_NetworkInterface, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Source, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_Auth, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_VpcConfig, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_VpcConfigItem, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildPhaseChange_AdditionalInformationItem, _aws_cdk_mixins_preview_aws_codebuild_events_ProjectEvents, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_CodeBuildBuildStateChangeProps, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_AdditionalInformation, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Artifact, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Cache, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Environment, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_EnvironmentItem, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Logs, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_NetworkInterface, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Source, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_Auth, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_VpcConfig, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_VpcConfigItem, _aws_cdk_mixins_preview_aws_codebuild_events_CodeBuildBuildStateChange_AdditionalInformationItem, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AdditionalEventData, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_Location, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RequestParametersItem, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RequestParametersItem1, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RequestParametersItem2, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_ResponseElements, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_Comment, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_DeletedBranch, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_PullRequest, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_PullRequestItem, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_MergeMetadata, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_RepositoryMetadata, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_ResponseElementsItem, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_SessionContext, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_Attributes, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_SessionIssuer, _aws_cdk_mixins_preview_aws_codecommit_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitApprovalRuleTemplateChange, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitApprovalRuleTemplateChange_CodeCommitApprovalRuleTemplateChangeProps, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitPullRequestStateChange, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitPullRequestStateChange_CodeCommitPullRequestStateChangeProps, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitCommentOnCommit, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitCommentOnCommit_CodeCommitCommentOnCommitProps, _aws_cdk_mixins_preview_aws_codecommit_events_RepositoryEvents, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitCommentOnPullRequest, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitCommentOnPullRequest_CodeCommitCommentOnPullRequestProps, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitRepositoryStateChange, _aws_cdk_mixins_preview_aws_codecommit_events_CodeCommitRepositoryStateChange_CodeCommitRepositoryStateChangeProps, _aws_cdk_mixins_preview_aws_codedeploy_events_CodeDeployDeploymentStateChangeNotification, _aws_cdk_mixins_preview_aws_codedeploy_events_CodeDeployDeploymentStateChangeNotification_CodeDeployDeploymentStateChangeNotificationProps, _aws_cdk_mixins_preview_aws_codedeploy_events_CodeDeployInstanceStateChangeNotification, _aws_cdk_mixins_preview_aws_codedeploy_events_CodeDeployInstanceStateChangeNotification_CodeDeployInstanceStateChangeNotificationProps, _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange, _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_CodeGuruProfilerRecommendationStateChangeProps, _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Recommendation, _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Description, _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Name, _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Reason, _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_ResolutionSteps, _aws_cdk_mixins_preview_aws_codeguruprofiler_events_CodeGuruProfilerRecommendationStateChange_Title, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_CodePipelineActionExecutionStateChangeProps, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_Type, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_ExecutionResult, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_InputArtifacts, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_S3Location, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineActionExecutionStateChange_OutputArtifacts, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelinePipelineExecutionStateChange, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelinePipelineExecutionStateChange_CodePipelinePipelineExecutionStateChangeProps, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelinePipelineExecutionStateChange_ExecutionTrigger, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineStageExecutionStateChange, _aws_cdk_mixins_preview_aws_codepipeline_events_CodePipelineStageExecutionStateChange_CodePipelineStageExecutionStateChangeProps, _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogs, _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolLogsMixin, _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_cognito_mixins_CfnUserPoolApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_connect_events_CodeConnectContact, _aws_cdk_mixins_preview_aws_connect_events_CodeConnectContact_CodeConnectContactProps, _aws_cdk_mixins_preview_aws_connect_events_CodeConnectContact_AgentInfo, _aws_cdk_mixins_preview_aws_connect_events_CodeConnectContact_QueueInfo, _aws_cdk_mixins_preview_aws_connect_events_InstanceEvents, _aws_cdk_mixins_preview_aws_connect_events_ContactLensPostCallRulesMatched, _aws_cdk_mixins_preview_aws_connect_events_ContactLensPostCallRulesMatched_ContactLensPostCallRulesMatchedProps, _aws_cdk_mixins_preview_aws_connect_events_ContactLensRealtimeRulesMatched, _aws_cdk_mixins_preview_aws_connect_events_ContactLensRealtimeRulesMatched_ContactLensRealtimeRulesMatchedProps, _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogs, _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceLogsMixin, _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsOutputFormat, _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsRecordFields, _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsS3Props, _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsLogGroupProps, _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsFirehoseProps, _aws_cdk_mixins_preview_aws_connect_mixins_CfnInstanceAmazonConnectFlowLogsDestProps, _aws_cdk_mixins_preview_aws_datasync_events_DataSyncAgentStateChange, _aws_cdk_mixins_preview_aws_datasync_events_DataSyncAgentStateChange_DataSyncAgentStateChangeProps, _aws_cdk_mixins_preview_aws_datasync_events_DataSyncLocationStateChange, _aws_cdk_mixins_preview_aws_datasync_events_DataSyncLocationStateChange_DataSyncLocationStateChangeProps, _aws_cdk_mixins_preview_aws_datasync_events_DataSyncTaskExecutionStateChange, _aws_cdk_mixins_preview_aws_datasync_events_DataSyncTaskExecutionStateChange_DataSyncTaskExecutionStateChangeProps, _aws_cdk_mixins_preview_aws_datasync_events_DataSyncTaskStateChange, _aws_cdk_mixins_preview_aws_datasync_events_DataSyncTaskStateChange_DataSyncTaskStateChangeProps, _aws_cdk_mixins_preview_aws_deadline_events_FleetSizeRecommendationChange, _aws_cdk_mixins_preview_aws_deadline_events_FleetSizeRecommendationChange_FleetSizeRecommendationChangeProps, _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogs, _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceLogsMixin, _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsRecordFields, _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_devopsagent_mixins_CfnAgentSpaceApplicationLogsDestProps, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_DevOpsGuruInsightClosedProps, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_ResourceCollection, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_CloudFormation, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_TagType, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_Anomaly, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_AnomalyResource, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_SourceDetail, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_DataIdentifiers, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_MetricQuery, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_GroupBy, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_CloudWatchDimension, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_AlarmCondition, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_ReferenceValue, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightClosed_AnomalySourceMetadata, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_DevOpsGuruInsightSeverityUpgradedProps, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_Anomaly, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_AnomalyResource, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_SourceDetail, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_DataIdentifiers, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_MetricQuery, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_GroupBy, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_CloudWatchDimension, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_AlarmCondition, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_ReferenceValue, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_AnomalySourceMetadata, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_ResourceCollection, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_CloudFormation, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruInsightSeverityUpgraded_TagType, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_DevOpsGuruNewAnomalyAssociationProps, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_ResourceCollection, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_CloudFormation, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_TagType, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_Anomaly, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_AnomalyResource, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_SourceDetail, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_DataIdentifiers, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_MetricQuery, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_GroupBy, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_CloudWatchDimension, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_AlarmCondition, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_ReferenceValue, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewAnomalyAssociation_AnomalySourceMetadata, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_DevOpsGuruNewInsightOpenProps, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_ResourceCollection, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_CloudFormation, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_TagType, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_Anomaly, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_AnomalyResource, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_SourceDetail, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_DataIdentifiers, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_MetricQuery, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_GroupBy, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_CloudWatchDimension, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_AlarmCondition, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_ReferenceValue, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewInsightOpen_AnomalySourceMetadata, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_DevOpsGuruNewRecommendationCreatedProps, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_ResourceCollection, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_CloudFormation, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_TagType, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_Recommendation, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_RelatedAnomaly, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_RelatedAnomalySourceDetail, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_CloudWatchDimension, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_AnomalyResource, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_RelatedEvent, _aws_cdk_mixins_preview_aws_devopsguru_events_DevOpsGuruNewRecommendationCreated_EventResource, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_PolicyDetails, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_PolicyDetailsItem, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_CreateRule, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_FastRestoreRule, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_RetainRule, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_PolicyDetailsItemItem, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_PolicyDetailsItem1, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_ResponseElements, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_SessionContext, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_Attributes, _aws_cdk_mixins_preview_aws_dlm_events_AWSAPICallViaCloudTrail_SessionIssuer, _aws_cdk_mixins_preview_aws_dlm_events_DLMPolicyStateChange, _aws_cdk_mixins_preview_aws_dlm_events_DLMPolicyStateChange_DLMPolicyStateChangeProps, _aws_cdk_mixins_preview_aws_ec2_events_EBSMultiVolumeSnapshotsCompletionStatus, _aws_cdk_mixins_preview_aws_ec2_events_EBSMultiVolumeSnapshotsCompletionStatus_EBSMultiVolumeSnapshotsCompletionStatusProps, _aws_cdk_mixins_preview_aws_ec2_events_EBSMultiVolumeSnapshotsCompletionStatus_Snapshot, _aws_cdk_mixins_preview_aws_ec2_events_EBSSnapshotNotification, _aws_cdk_mixins_preview_aws_ec2_events_EBSSnapshotNotification_EBSSnapshotNotificationProps, _aws_cdk_mixins_preview_aws_ec2_events_EBSVolumeNotification, _aws_cdk_mixins_preview_aws_ec2_events_EBSVolumeNotification_EBSVolumeNotificationProps, _aws_cdk_mixins_preview_aws_ec2_events_EC2FastLaunchStateChangeNotification, _aws_cdk_mixins_preview_aws_ec2_events_EC2FastLaunchStateChangeNotification_EC2FastLaunchStateChangeNotificationProps, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_ResponseElements, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstancesSet, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstancesSetItem, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CapacityReservationSpecification, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_StateReason, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet2, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet2Item, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSet, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSpecificationSetItemItem, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstanceState, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterfaceSet1, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterfaceSet1Item, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet3, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Attachment, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_PrivateIpAddressesSet2, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_PrivateIpAddressesSet1Item, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CpuOptions, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Monitoring1, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_EnclaveOptions, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Placement, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CreateFleetResponse, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_DeleteLaunchTemplateResponse, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplate1, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterface, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_PrivateIpAddressesSet1, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CreateLaunchTemplateRequest, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplateData, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstanceMarketOptions1, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SpotOptions2, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterface1, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SecurityGroupId, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet1, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_GroupSet1Item, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstancesSet1, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstancesSet1Item, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_CreateFleetRequest, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TargetCapacitySpecification, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_OnDemandOptions, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SpotOptions, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_ExistingInstances, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplateConfigs, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplateSpecification, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSpecification, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagType, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_DeleteLaunchTemplateRequest, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterfaceSet, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_NetworkInterfaceSetItem, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSpecificationSet, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_TagSpecificationSetItem, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Monitoring, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_InstanceMarketOptions, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SpotOptions1, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_LaunchTemplate, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SessionContext, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_SessionIssuer, _aws_cdk_mixins_preview_aws_ec2_events_AWSAPICallViaCloudTrail_Attributes, _aws_cdk_mixins_preview_aws_ec2_events_InstanceEvents, _aws_cdk_mixins_preview_aws_ec2_events_EC2InstanceStateChangeNotification, _aws_cdk_mixins_preview_aws_ec2_events_EC2InstanceStateChangeNotification_EC2InstanceStateChangeNotificationProps, _aws_cdk_mixins_preview_aws_ec2_events_EC2SpotInstanceInterruptionWarning, _aws_cdk_mixins_preview_aws_ec2_events_EC2SpotInstanceInterruptionWarning_EC2SpotInstanceInterruptionWarningProps, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogs, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCLogsMixin, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsOutputFormat, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsS3Props, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsLogGroupProps, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPCRoute53ResolverQueryLogsFirehoseProps, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogs, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogs, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionLogsMixin, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsOutputFormat, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsRecordFields, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsS3Props, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsLogGroupProps, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsFirehoseProps, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionEventLogsDestProps, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsOutputFormat, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsRecordFields, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsS3Props, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsLogGroupProps, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsFirehoseProps, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVPNConnectionConnectionLogsDestProps, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogs, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceLogsMixin, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsS3Props, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsLogGroupProps, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnVerifiedAccessInstanceVerifiedAccessLogsFirehoseProps, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogs, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerLogsMixin, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsOutputFormat, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsRecordFields, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsS3Props, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsLogGroupProps, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsFirehoseProps, _aws_cdk_mixins_preview_aws_ec2_mixins_CfnRouteServerPeerEventLogsDestProps, _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_RequestParametersItem, _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_SessionContext, _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_SessionIssuer, _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_Attributes, _aws_cdk_mixins_preview_aws_ecr_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem, _aws_cdk_mixins_preview_aws_ecr_events_RepositoryEvents, _aws_cdk_mixins_preview_aws_ecr_events_ECRImageAction, _aws_cdk_mixins_preview_aws_ecr_events_ECRImageAction_ECRImageActionProps, _aws_cdk_mixins_preview_aws_ecr_events_ECRImageScan, _aws_cdk_mixins_preview_aws_ecr_events_ECRImageScan_ECRImageScanProps, _aws_cdk_mixins_preview_aws_ecr_events_ECRImageScan_FindingSeverityCounts, _aws_cdk_mixins_preview_aws_ecr_events_ECRPullThroughCacheAction, _aws_cdk_mixins_preview_aws_ecr_events_ECRPullThroughCacheAction_ECRPullThroughCacheActionProps, _aws_cdk_mixins_preview_aws_ecr_events_ECRReferrerAction, _aws_cdk_mixins_preview_aws_ecr_events_ECRReferrerAction_ECRReferrerActionProps, _aws_cdk_mixins_preview_aws_ecr_events_ECRReplicationAction, _aws_cdk_mixins_preview_aws_ecr_events_ECRReplicationAction_ECRReplicationActionProps, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElements, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElementsItem, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_Overrides1, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_Overrides1Item, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElementsItemItem, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElementsItemItemItem, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_ResponseElementsItemItem1, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_NetworkConfiguration, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_AwsvpcConfiguration, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_Overrides, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_OverridesItem, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_RequestParametersItem, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_RequestParametersItem1, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_SessionContext, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_SessionIssuer, _aws_cdk_mixins_preview_aws_ecs_events_AWSAPICallViaCloudTrail_Attributes, _aws_cdk_mixins_preview_aws_ecs_events_ClusterEvents, _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange, _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ECSContainerInstanceStateChangeProps, _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_VersionInfo, _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_AttachmentDetails, _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_DetailsItems, _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_ResourceDetails, _aws_cdk_mixins_preview_aws_ecs_events_ECSContainerInstanceStateChange_AttributesDetails, _aws_cdk_mixins_preview_aws_ecs_events_ECSServiceAction, _aws_cdk_mixins_preview_aws_ecs_events_ECSServiceAction_ECSServiceActionProps, _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange, _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_ECSTaskStateChangeProps, _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_Overrides, _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_OverridesItem, _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_AttachmentDetails, _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_Details, _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_AttributesDetails, _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_ContainerDetails, _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_NetworkInterfaceDetails, _aws_cdk_mixins_preview_aws_ecs_events_ECSTaskStateChange_NetworkBindingDetails, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogs, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogs, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogs, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogs, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterLogsMixin, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsOutputFormat, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsRecordFields, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsS3Props, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsLogGroupProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsFirehoseProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeBlockStorageLogsDestProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsOutputFormat, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsRecordFields, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsS3Props, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsLogGroupProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsFirehoseProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeComputeLogsDestProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsOutputFormat, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsRecordFields, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsS3Props, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsLogGroupProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsFirehoseProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeIpamLogsDestProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsOutputFormat, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsRecordFields, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsS3Props, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsLogGroupProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsFirehoseProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnClusterAutoModeLoadBalancingLogsDestProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3Logs, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogs, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogs, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityLogsMixin, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsOutputFormat, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsRecordFields, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsS3Props, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsLogGroupProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsFirehoseProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityAckS3LogsDestProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityArgocdApplicationLogsDestProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsOutputFormat, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsRecordFields, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsS3Props, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsLogGroupProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsFirehoseProps, _aws_cdk_mixins_preview_aws_eks_mixins_CfnCapabilityEksCapabilityKroLogsDestProps, _aws_cdk_mixins_preview_aws_elasticache_events_CacheCreated, _aws_cdk_mixins_preview_aws_elasticache_events_CacheCreated_CacheCreatedProps, _aws_cdk_mixins_preview_aws_elasticache_events_CacheCreationFailed, _aws_cdk_mixins_preview_aws_elasticache_events_CacheCreationFailed_CacheCreationFailedProps, _aws_cdk_mixins_preview_aws_elasticache_events_CacheDeleted, _aws_cdk_mixins_preview_aws_elasticache_events_CacheDeleted_CacheDeletedProps, _aws_cdk_mixins_preview_aws_elasticache_events_CacheLimitApproaching, _aws_cdk_mixins_preview_aws_elasticache_events_CacheLimitApproaching_CacheLimitApproachingProps, _aws_cdk_mixins_preview_aws_elasticache_events_CacheUpdated, _aws_cdk_mixins_preview_aws_elasticache_events_CacheUpdated_CacheUpdatedProps, _aws_cdk_mixins_preview_aws_elasticache_events_CacheUpdateFailed, _aws_cdk_mixins_preview_aws_elasticache_events_CacheUpdateFailed_CacheUpdateFailedProps, _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCopyFailed, _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCopyFailed_SnapshotCopyFailedProps, _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCreated, _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCreated_SnapshotCreatedProps, _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCreationFailed, _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotCreationFailed_SnapshotCreationFailedProps, _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotExportFailed, _aws_cdk_mixins_preview_aws_elasticache_events_SnapshotExportFailed_SnapshotExportFailedProps, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogs, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogs, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogs, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogs, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerLogsMixin, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsOutputFormat, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsRecordFields, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsS3Props, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsLogGroupProps, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsFirehoseProps, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbAccessLogsDestProps, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsOutputFormat, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsRecordFields, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsS3Props, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsLogGroupProps, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsFirehoseProps, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbConnectionLogsDestProps, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsOutputFormat, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsRecordFields, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsS3Props, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsLogGroupProps, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsFirehoseProps, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerAlbHealthCheckLogsDestProps, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsOutputFormat, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsRecordFields, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsS3Props, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsLogGroupProps, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsFirehoseProps, _aws_cdk_mixins_preview_aws_elasticloadbalancingv2_mixins_CfnLoadBalancerNlbAccessLogsDestProps, _aws_cdk_mixins_preview_aws_emr_events_EMRAutoScalingPolicyStateChange, _aws_cdk_mixins_preview_aws_emr_events_EMRAutoScalingPolicyStateChange_EMRAutoScalingPolicyStateChangeProps, _aws_cdk_mixins_preview_aws_emr_events_EMRClusterStateChange, _aws_cdk_mixins_preview_aws_emr_events_EMRClusterStateChange_EMRClusterStateChangeProps, _aws_cdk_mixins_preview_aws_emr_events_EMRConfigurationError, _aws_cdk_mixins_preview_aws_emr_events_EMRConfigurationError_EMRConfigurationErrorProps, _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceFleetStateChange, _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceFleetStateChange_EMRInstanceFleetStateChangeProps, _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceGroupStateChange, _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceGroupStateChange_EMRInstanceGroupStateChangeProps, _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceGroupStatusNotification, _aws_cdk_mixins_preview_aws_emr_events_EMRInstanceGroupStatusNotification_EMRInstanceGroupStatusNotificationProps, _aws_cdk_mixins_preview_aws_emr_events_EMRStepStatusChange, _aws_cdk_mixins_preview_aws_emr_events_EMRStepStatusChange_EMRStepStatusChangeProps, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogs, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowLogsMixin, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsOutputFormat, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsRecordFields, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsS3Props, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsLogGroupProps, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsFirehoseProps, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnMatchingWorkflowWorkflowLogsDestProps, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogs, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowLogsMixin, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsOutputFormat, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsRecordFields, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsS3Props, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsLogGroupProps, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsFirehoseProps, _aws_cdk_mixins_preview_aws_entityresolution_mixins_CfnIdMappingWorkflowWorkflowLogsDestProps, _aws_cdk_mixins_preview_aws_events_events_ScheduledJson, _aws_cdk_mixins_preview_aws_events_events_ScheduledJson_ScheduledJsonProps, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogs, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogs, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogs, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusLogsMixin, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsOutputFormat, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsRecordFields, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsS3Props, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsLogGroupProps, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsFirehoseProps, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusErrorLogsDestProps, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsOutputFormat, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsRecordFields, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsS3Props, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsLogGroupProps, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsFirehoseProps, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusInfoLogsDestProps, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsOutputFormat, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsRecordFields, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsS3Props, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsLogGroupProps, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsFirehoseProps, _aws_cdk_mixins_preview_aws_events_mixins_CfnEventBusTraceLogsDestProps, _aws_cdk_mixins_preview_aws_fis_events_FISExperimentStateChange, _aws_cdk_mixins_preview_aws_fis_events_FISExperimentStateChange_FISExperimentStateChangeProps, _aws_cdk_mixins_preview_aws_fis_events_FISExperimentStateChange_NewState, _aws_cdk_mixins_preview_aws_fis_events_FISExperimentStateChange_OldState, _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent, _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_GameLiftMatchmakingEventProps, _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_GameSessionInfo, _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_GameSessionInfoItem, _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_RuleEvaluationMetrics, _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftMatchmakingEvent_Ticket, _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftQueuePlacementEvent, _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftQueuePlacementEvent_GameLiftQueuePlacementEventProps, _aws_cdk_mixins_preview_aws_gamelift_events_GameLiftQueuePlacementEvent_GameLiftQueuePlacementEventItem, _aws_cdk_mixins_preview_aws_glue_events_GlueDataCatalogDatabaseStateChange, _aws_cdk_mixins_preview_aws_glue_events_GlueDataCatalogDatabaseStateChange_GlueDataCatalogDatabaseStateChangeProps, _aws_cdk_mixins_preview_aws_glue_events_DatabaseEvents, _aws_cdk_mixins_preview_aws_glue_events_GlueDataCatalogTableStateChange, _aws_cdk_mixins_preview_aws_glue_events_GlueDataCatalogTableStateChange_GlueDataCatalogTableStateChangeProps, _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_ResponseElements, _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_SessionContext, _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_SessionIssuer, _aws_cdk_mixins_preview_aws_glue_events_AWSAPICallViaCloudTrail_Attributes, _aws_cdk_mixins_preview_aws_glue_events_JobEvents, _aws_cdk_mixins_preview_aws_glue_events_GlueJobRunStatus, _aws_cdk_mixins_preview_aws_glue_events_GlueJobRunStatus_GlueJobRunStatusProps, _aws_cdk_mixins_preview_aws_glue_events_GlueJobRunStatus_NotificationCondition, _aws_cdk_mixins_preview_aws_glue_events_GlueJobStateChange, _aws_cdk_mixins_preview_aws_glue_events_GlueJobStateChange_GlueJobStateChangeProps, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult_GuardDutyMalwareProtectionObjectScanResultProps, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult_S3ObjectDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult_ScanResultDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionObjectScanResult_Threat, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_GuardDutyMalwareProtectionPostScanActionFailedProps, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_S3ObjectDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionPostScanActionFailed_PostScanAction, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusActive, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusActive_GuardDutyMalwareProtectionResourceStatusActiveProps, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusActive_S3BucketDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_GuardDutyMalwareProtectionResourceStatusErrorProps, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_S3BucketDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusError_StatusReason, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_GuardDutyMalwareProtectionResourceStatusWarningProps, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_S3BucketDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyMalwareProtectionResourceStatusWarning_StatusReason, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_GuardDutyFindingProps, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Resource, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AccessKeyDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ContainerDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EbsVolumeDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EbsVolumeDetailsItem, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EcsClusterDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_TaskDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_TaskDetailsItem, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EcsClusterDetailsItem, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EksClusterDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_IamInstanceProfile, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetailsItem, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetailsItemItem, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetailsItemItem1, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_InstanceDetailsItem1, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesUserDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesWorkloadDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesWorkloadDetailsItem, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_SecurityContext, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ResourceItem, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_DefaultServerSideEncryption, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Owner, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_PublicAccess, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_PermissionConfiguration, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AccountLevelPermissions, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_BlockPublicAccess, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_BucketLevelPermissions, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AccessControlList, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Service, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Action, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AwsApiCallAction1, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AffectedResources1, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteAccountDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails1, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City1, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country1, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_GeoLocation, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization1, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_DnsRequestAction, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_KubernetesApiCallAction, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails2, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City2, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country2, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization2, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_NetworkConnectionAction, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_LocalIpDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_LocalPortDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails3, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City3, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country3, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization3, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemotePortDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_PortProbeAction, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_PortProbeActionItem, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_LocalIpDetails1, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_LocalPortDetails1, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails4, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City4, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country4, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_GeoLocation1, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization4, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AdditionalInfo, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Anomalies, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_NewPolicy, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_OldPolicy, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ProfiledBehavior, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_UnusualBehavior, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_UserAgent, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AdditionalInfoItem, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AdditionalInfoItem1, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_AwsApiCallAction, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_RemoteIpDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_City, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Country, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Organization, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EbsVolumeScanDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ScanDetections, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_HighestSeverityThreatDetails, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ScannedItemCount, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ThreatDetectedByName, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ThreatDetectedByNameItem, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ThreatDetectedByNameItemItem, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_ThreatsDetectedItemCount, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_Evidence, _aws_cdk_mixins_preview_aws_guardduty_events_GuardDutyFinding_EvidenceItem, _aws_cdk_mixins_preview_aws_guardduty_events_DetectorEvents, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreated, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreated_DataStoreCreatedProps, _aws_cdk_mixins_preview_aws_healthimaging_events_DatastoreEvents, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreating, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreating_DataStoreCreatingProps, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreationFailed, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreCreationFailed_DataStoreCreationFailedProps, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreDeleted, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreDeleted_DataStoreDeletedProps, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreDeleting, _aws_cdk_mixins_preview_aws_healthimaging_events_DataStoreDeleting_DataStoreDeletingProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopied, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopied_ImageSetCopiedProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopyFailed, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopyFailed_ImageSetCopyFailedProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopying, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopying_ImageSetCopyingProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopyingWithReadOnlyAccess, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCopyingWithReadOnlyAccess_ImageSetCopyingWithReadOnlyAccessProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCreated, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetCreated_ImageSetCreatedProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetDeleted, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetDeleted_ImageSetDeletedProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetDeleting, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetDeleting_ImageSetDeletingProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdated, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdated_ImageSetUpdatedProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdateFailed, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdateFailed_ImageSetUpdateFailedProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdating, _aws_cdk_mixins_preview_aws_healthimaging_events_ImageSetUpdating_ImageSetUpdatingProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobCompleted, _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobCompleted_ImportJobCompletedProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobFailed, _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobFailed_ImportJobFailedProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobInProgress, _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobInProgress_ImportJobInProgressProps, _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobSubmitted, _aws_cdk_mixins_preview_aws_healthimaging_events_ImportJobSubmitted_ImportJobSubmittedProps, _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreActive, _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreActive_DataStoreActiveProps, _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreCreating, _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreCreating_DataStoreCreatingProps, _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreDeleted, _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreDeleted_DataStoreDeletedProps, _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreDeleting, _aws_cdk_mixins_preview_aws_healthlake_events_DataStoreDeleting_DataStoreDeletingProps, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompleted, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompleted_ExportJobCompletedProps, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompleted_OutputDataConfig, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompletedWithErrors, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompletedWithErrors_ExportJobCompletedWithErrorsProps, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobCompletedWithErrors_OutputDataConfig, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobFailed, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobFailed_ExportJobFailedProps, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobFailed_OutputDataConfig, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobInProgress, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobInProgress_ExportJobInProgressProps, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobInProgress_OutputDataConfig, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobSubmitted, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobSubmitted_ExportJobSubmittedProps, _aws_cdk_mixins_preview_aws_healthlake_events_ExportJobSubmitted_OutputDataConfig, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompleted, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompleted_ImportJobCompletedProps, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompleted_InputDataConfig, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompletedWithErrors, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompletedWithErrors_ImportJobCompletedWithErrorsProps, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobCompletedWithErrors_InputDataConfig, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobFailed, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobFailed_ImportJobFailedProps, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobFailed_InputDataConfig, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobInProgress, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobInProgress_ImportJobInProgressProps, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobInProgress_InputDataConfig, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobSubmitted, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobSubmitted_ImportJobSubmittedProps, _aws_cdk_mixins_preview_aws_healthlake_events_ImportJobSubmitted_InputDataConfig, _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderCVEDetected, _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderCVEDetected_EC2ImageBuilderCVEDetectedProps, _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderCVEDetected_FindingSeverityCounts, _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderImageStateChange, _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderImageStateChange_EC2ImageBuilderImageStateChangeProps, _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderImageStateChange_ImageState, _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderWorkflowStepWaiting, _aws_cdk_mixins_preview_aws_imagebuilder_events_EC2ImageBuilderWorkflowStepWaiting_EC2ImageBuilderWorkflowStepWaitingProps, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_ChannelStorage, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_CustomerManagedS3, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_LoggingOptions, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_PipelineActivity, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_MathType, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_QueryAction, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RetentionPeriod, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_Settings, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_Timeseries, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_TimeseriesItem, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RequestParametersItem, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RequestParametersItem1, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_ResponseElements, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_RetentionPeriod1, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_SessionContext, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_Attributes, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_SessionIssuer, _aws_cdk_mixins_preview_aws_iotanalytics_events_AWSAPICallViaCloudTrail_WebIdFederationData, _aws_cdk_mixins_preview_aws_iotanalytics_events_IoTAnalyticsDataSetLifeCycleNotification, _aws_cdk_mixins_preview_aws_iotanalytics_events_IoTAnalyticsDataSetLifeCycleNotification_IoTAnalyticsDataSetLifeCycleNotificationProps, _aws_cdk_mixins_preview_aws_iotanalytics_events_DatasetEvents, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogs, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignLogsMixin, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsOutputFormat, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsS3Props, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsLogGroupProps, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnCampaignIotFleetwiseLogsFirehoseProps, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogs, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleLogsMixin, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsOutputFormat, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsS3Props, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsLogGroupProps, _aws_cdk_mixins_preview_aws_iotfleetwise_mixins_CfnVehicleIotFleetwiseLogsFirehoseProps, _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogs, _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomLogsMixin, _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsOutputFormat, _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsS3Props, _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsLogGroupProps, _aws_cdk_mixins_preview_aws_ivschat_mixins_CfnRoomIvsChatLogsFirehoseProps, _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogs, _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorLogsMixin, _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_kafkaconnect_mixins_CfnConnectorApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_EncryptionContext, _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_SessionContext, _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_SessionIssuer, _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_Attributes, _aws_cdk_mixins_preview_aws_kms_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem, _aws_cdk_mixins_preview_aws_kms_events_KeyEvents, _aws_cdk_mixins_preview_aws_kms_events_KMSCMKDeletion, _aws_cdk_mixins_preview_aws_kms_events_KMSCMKDeletion_KMSCMKDeletionProps, _aws_cdk_mixins_preview_aws_kms_events_KMSCMKRotation, _aws_cdk_mixins_preview_aws_kms_events_KMSCMKRotation_KMSCMKRotationProps, _aws_cdk_mixins_preview_aws_kms_events_KMSImportedKeyMaterialExpiration, _aws_cdk_mixins_preview_aws_kms_events_KMSImportedKeyMaterialExpiration_KMSImportedKeyMaterialExpirationProps, _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_SessionContext, _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_SessionIssuer, _aws_cdk_mixins_preview_aws_logs_events_AWSAPICallViaCloudTrail_Attributes, _aws_cdk_mixins_preview_aws_logs_events_LogGroupEvents, _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogs, _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupLogsMixin, _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsOutputFormat, _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsRecordFields, _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsS3Props, _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsLogGroupProps, _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsFirehoseProps, _aws_cdk_mixins_preview_aws_logs_mixins_CfnLogGroupAuditLogsDestProps, _aws_cdk_mixins_preview_aws_logs_ILogsDeliveryConfig, _aws_cdk_mixins_preview_aws_logs_ILogsDelivery, _aws_cdk_mixins_preview_aws_logs_RecordFieldDeliveryProps, _aws_cdk_mixins_preview_aws_logs_DeliveryProps, _aws_cdk_mixins_preview_aws_logs_S3LogsDeliveryPermissionsVersion, _aws_cdk_mixins_preview_aws_logs_S3LogsDeliveryProps, _aws_cdk_mixins_preview_aws_logs_S3LogsDelivery, _aws_cdk_mixins_preview_aws_logs_FirehoseLogsDelivery, _aws_cdk_mixins_preview_aws_logs_LogGroupLogsDelivery, _aws_cdk_mixins_preview_aws_logs_XRayLogsDelivery, _aws_cdk_mixins_preview_aws_logs_DestinationLogsDelivery, _aws_cdk_mixins_preview_aws_logs_S3DeliveryDestinationProps, _aws_cdk_mixins_preview_aws_logs_FirehoseDeliveryDestinationProps, _aws_cdk_mixins_preview_aws_logs_CloudwatchDeliveryDestinationProps, _aws_cdk_mixins_preview_aws_logs_XRayDeliveryDestinationProps, _aws_cdk_mixins_preview_aws_logs_S3DeliveryDestination, _aws_cdk_mixins_preview_aws_logs_FirehoseDeliveryDestination, _aws_cdk_mixins_preview_aws_logs_CloudwatchDeliveryDestination, _aws_cdk_mixins_preview_aws_logs_XRayDeliveryDestination, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogs, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogs, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogs, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogs, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationLogsMixin, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsOutputFormat, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsS3Props, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsLogGroupProps, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConfigLogsFirehoseProps, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsOutputFormat, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsS3Props, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsLogGroupProps, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationBatchJobLogsFirehoseProps, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsOutputFormat, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsS3Props, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsLogGroupProps, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationConsoleLogsFirehoseProps, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsOutputFormat, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsS3Props, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsLogGroupProps, _aws_cdk_mixins_preview_aws_m2_mixins_CfnApplicationDatasetImportLogsFirehoseProps, _aws_cdk_mixins_preview_aws_managedblockchain_events_ManagedBlockchainInvitationStatusChange, _aws_cdk_mixins_preview_aws_managedblockchain_events_ManagedBlockchainInvitationStatusChange_ManagedBlockchainInvitationStatusChangeProps, _aws_cdk_mixins_preview_aws_managedblockchain_events_ManagedBlockchainProposalStatusChange, _aws_cdk_mixins_preview_aws_managedblockchain_events_ManagedBlockchainProposalStatusChange_ManagedBlockchainProposalStatusChangeProps, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelAlert, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelAlert_MediaLiveChannelAlertProps, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelStateChange, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelStateChange_MediaLiveChannelStateChangeProps, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveMultiplexAlert, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveMultiplexAlert_MediaLiveMultiplexAlertProps, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveMultiplexStateChange, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveMultiplexStateChange_MediaLiveMultiplexStateChangeProps, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelInputChange, _aws_cdk_mixins_preview_aws_medialive_events_MediaLiveChannelInputChange_MediaLiveChannelInputChangeProps, _aws_cdk_mixins_preview_aws_medialive_events_ChannelEvents, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogs, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogs, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupLogsMixin, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsOutputFormat, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsRecordFields, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsS3Props, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsLogGroupProps, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsFirehoseProps, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupEgressAccessLogsDestProps, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsOutputFormat, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsRecordFields, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsS3Props, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsLogGroupProps, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsFirehoseProps, _aws_cdk_mixins_preview_aws_mediapackagev2_mixins_CfnChannelGroupIngressAccessLogsDestProps, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogs, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogs, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogs, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationLogsMixin, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsRecordFields, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsS3Props, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsLogGroupProps, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsFirehoseProps, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationAdDecisionServerLogsDestProps, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsOutputFormat, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsRecordFields, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsS3Props, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsLogGroupProps, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsFirehoseProps, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationManifestServiceLogsDestProps, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsOutputFormat, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsRecordFields, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsS3Props, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsLogGroupProps, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsFirehoseProps, _aws_cdk_mixins_preview_aws_mediatailor_mixins_CfnPlaybackConfigurationTranscodeLogsDestProps, _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogs, _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterLogsMixin, _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsOutputFormat, _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsS3Props, _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsLogGroupProps, _aws_cdk_mixins_preview_aws_msk_mixins_CfnClusterBrokerLogsFirehoseProps, _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogs, _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorLogsMixin, _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsRecordFields, _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_msk_mixins_CfnReplicatorApplicationLogsDestProps, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_FirewallAttachmentStatusChangedProps, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_DataItem, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallAttachmentStatusChanged_Metadata, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_FirewallConfigurationChangedProps, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_DataItem, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallConfigurationChanged_Metadata, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallTransitGatewayAttachmentStatusChanged, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallTransitGatewayAttachmentStatusChanged_FirewallTransitGatewayAttachmentStatusChangedProps, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallTransitGatewayAttachmentStatusChanged_Data, _aws_cdk_mixins_preview_aws_networkfirewall_events_FirewallTransitGatewayAttachmentStatusChanged_Metadata, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogs, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogs, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogs, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallLogsMixin, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsOutputFormat, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsS3Props, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsLogGroupProps, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallAlertLogsFirehoseProps, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsOutputFormat, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsS3Props, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsLogGroupProps, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallFlowLogsFirehoseProps, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsOutputFormat, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsS3Props, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsLogGroupProps, _aws_cdk_mixins_preview_aws_networkfirewall_mixins_CfnFirewallTlsLogsFirehoseProps, _aws_cdk_mixins_preview_aws_networkmanager_events_NetworkManagerPolicyUpdate, _aws_cdk_mixins_preview_aws_networkmanager_events_NetworkManagerPolicyUpdate_NetworkManagerPolicyUpdateProps, _aws_cdk_mixins_preview_aws_networkmanager_events_CoreNetworkEvents, _aws_cdk_mixins_preview_aws_networkmanager_events_NetworkManagerSegmentUpdate, _aws_cdk_mixins_preview_aws_networkmanager_events_NetworkManagerSegmentUpdate_NetworkManagerSegmentUpdateProps, _aws_cdk_mixins_preview_aws_omics_events_AnnotationImportJobStatusChange, _aws_cdk_mixins_preview_aws_omics_events_AnnotationImportJobStatusChange_AnnotationImportJobStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_AnnotationStoreStatusChange, _aws_cdk_mixins_preview_aws_omics_events_AnnotationStoreStatusChange_AnnotationStoreStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_ReferenceStoreStatusChange, _aws_cdk_mixins_preview_aws_omics_events_ReferenceStoreStatusChange_ReferenceStoreStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_RunStatusChange, _aws_cdk_mixins_preview_aws_omics_events_RunStatusChange_RunStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_S3AccessPolicyStatusChange, _aws_cdk_mixins_preview_aws_omics_events_S3AccessPolicyStatusChange_S3AccessPolicyStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_SequenceStoreStatusChange, _aws_cdk_mixins_preview_aws_omics_events_SequenceStoreStatusChange_SequenceStoreStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_TaskStatusChange, _aws_cdk_mixins_preview_aws_omics_events_TaskStatusChange_TaskStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_VariantImportJobStatusChange, _aws_cdk_mixins_preview_aws_omics_events_VariantImportJobStatusChange_VariantImportJobStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_VariantStoreStatusChange, _aws_cdk_mixins_preview_aws_omics_events_VariantStoreStatusChange_VariantStoreStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_WorkflowStatusChange, _aws_cdk_mixins_preview_aws_omics_events_WorkflowStatusChange_WorkflowStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_ReferenceImportJobStatusChange, _aws_cdk_mixins_preview_aws_omics_events_ReferenceImportJobStatusChange_ReferenceImportJobStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_ReferenceStoreEvents, _aws_cdk_mixins_preview_aws_omics_events_ReferenceStatusChange, _aws_cdk_mixins_preview_aws_omics_events_ReferenceStatusChange_ReferenceStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_ReadSetActivationJobStatusChange, _aws_cdk_mixins_preview_aws_omics_events_ReadSetActivationJobStatusChange_ReadSetActivationJobStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_SequenceStoreEvents, _aws_cdk_mixins_preview_aws_omics_events_ReadSetExportJobStatusChange, _aws_cdk_mixins_preview_aws_omics_events_ReadSetExportJobStatusChange_ReadSetExportJobStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_ReadSetImportJobStatusChange, _aws_cdk_mixins_preview_aws_omics_events_ReadSetImportJobStatusChange_ReadSetImportJobStatusChangeProps, _aws_cdk_mixins_preview_aws_omics_events_ReadSetStatusChange, _aws_cdk_mixins_preview_aws_omics_events_ReadSetStatusChange_ReadSetStatusChangeProps, _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksAlert, _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksAlert_OpsWorksAlertProps, _aws_cdk_mixins_preview_aws_opsworks_events_InstanceEvents, _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksCommandStateChange, _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksCommandStateChange_OpsWorksCommandStateChangeProps, _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksInstanceStateChange, _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksInstanceStateChange_OpsWorksInstanceStateChangeProps, _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksDeploymentStateChange, _aws_cdk_mixins_preview_aws_opsworks_events_OpsWorksDeploymentStateChange_OpsWorksDeploymentStateChangeProps, _aws_cdk_mixins_preview_aws_opsworks_events_StackEvents, _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail, _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail_AWSServiceEventViaCloudTrailProps, _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail_ServiceEventDetails, _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail_CreateAccountStatus, _aws_cdk_mixins_preview_aws_organizations_events_AWSServiceEventViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_organizations_events_AccountEvents, _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogs, _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelineLogsMixin, _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsOutputFormat, _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsS3Props, _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsLogGroupProps, _aws_cdk_mixins_preview_aws_osis_mixins_CfnPipelinePipelineLogsFirehoseProps, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogs, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogs, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogs, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterLogsMixin, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsOutputFormat, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsRecordFields, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsS3Props, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsLogGroupProps, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsFirehoseProps, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsJobcompLogsDestProps, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsOutputFormat, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsRecordFields, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsS3Props, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsLogGroupProps, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsFirehoseProps, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerLogsDestProps, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsOutputFormat, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsRecordFields, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsS3Props, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsLogGroupProps, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsFirehoseProps, _aws_cdk_mixins_preview_aws_pcs_mixins_CfnClusterPcsSchedulerAuditLogsDestProps, _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogs, _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeLogsMixin, _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsOutputFormat, _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsS3Props, _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsLogGroupProps, _aws_cdk_mixins_preview_aws_pipes_mixins_CfnPipeExecutionLogsFirehoseProps, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogs, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogs, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationLogsMixin, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsOutputFormat, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsRecordFields, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsS3Props, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsLogGroupProps, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsFirehoseProps, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationSyncJobLogsDestProps, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsOutputFormat, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsRecordFields, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsS3Props, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsLogGroupProps, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsFirehoseProps, _aws_cdk_mixins_preview_aws_qbusiness_mixins_CfnApplicationEventLogsDestProps, _aws_cdk_mixins_preview_aws_qldb_events_QLDBLedgerStateChange, _aws_cdk_mixins_preview_aws_qldb_events_QLDBLedgerStateChange_QLDBLedgerStateChangeProps, _aws_cdk_mixins_preview_aws_rds_events_RDSDBClusterEvent, _aws_cdk_mixins_preview_aws_rds_events_RDSDBClusterEvent_RDSDBClusterEventProps, _aws_cdk_mixins_preview_aws_rds_events_RDSDBClusterSnapshotEvent, _aws_cdk_mixins_preview_aws_rds_events_RDSDBClusterSnapshotEvent_RDSDBClusterSnapshotEventProps, _aws_cdk_mixins_preview_aws_rds_events_RDSDBInstanceEvent, _aws_cdk_mixins_preview_aws_rds_events_RDSDBInstanceEvent_RDSDBInstanceEventProps, _aws_cdk_mixins_preview_aws_rds_events_RDSDBParameterGroupEvent, _aws_cdk_mixins_preview_aws_rds_events_RDSDBParameterGroupEvent_RDSDBParameterGroupEventProps, _aws_cdk_mixins_preview_aws_rds_events_RDSDBProxyEvent, _aws_cdk_mixins_preview_aws_rds_events_RDSDBProxyEvent_RDSDBProxyEventProps, _aws_cdk_mixins_preview_aws_rds_events_RDSDBSecurityGroupEvent, _aws_cdk_mixins_preview_aws_rds_events_RDSDBSecurityGroupEvent_RDSDBSecurityGroupEventProps, _aws_cdk_mixins_preview_aws_rds_events_RDSDBSnapshotEvent, _aws_cdk_mixins_preview_aws_rds_events_RDSDBSnapshotEvent_RDSDBSnapshotEventProps, _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogs, _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverLogsMixin, _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsOutputFormat, _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsRecordFields, _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsS3Props, _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsLogGroupProps, _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsFirehoseProps, _aws_cdk_mixins_preview_aws_route53globalresolver_mixins_CfnGlobalResolverGlobalResolverLogsDestProps, _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogs, _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileLogsMixin, _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat, _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsS3Props, _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsLogGroupProps, _aws_cdk_mixins_preview_aws_route53profiles_mixins_CfnProfileRoute53ProfilesResolverQueryLogsFirehoseProps, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerCellReadinessStatusChange, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerCellReadinessStatusChange_Route53ApplicationRecoveryControllerCellReadinessStatusChangeProps, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerCellReadinessStatusChange_State, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_CellEvents, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerReadinessCheckStatusChange, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerReadinessCheckStatusChange_Route53ApplicationRecoveryControllerReadinessCheckStatusChangeProps, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerReadinessCheckStatusChange_State, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_ReadinessCheckEvents, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChangeProps, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_Route53ApplicationRecoveryControllerRecoveryGroupReadinessStatusChange_State, _aws_cdk_mixins_preview_aws_route53recoveryreadiness_events_RecoveryGroupEvents, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_DNSFirewallAlertProps, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_DnsFirewallAlertItem, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_ResolverEndpointDetails, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallAlert_ResolverNetworkInterfaceDetails, _aws_cdk_mixins_preview_aws_route53resolver_events_FirewallDomainListEvents, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_DNSFirewallBlockProps, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_DnsFirewallBlockItem, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_ResolverEndpointDetails, _aws_cdk_mixins_preview_aws_route53resolver_events_DNSFirewallBlock_ResolverNetworkInterfaceDetails, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogs, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogs, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpans, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorLogsMixin, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsOutputFormat, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsS3Props, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsLogGroupProps, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumTelemetryLogsFirehoseProps, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsOutputFormat, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsS3Props, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsLogGroupProps, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelLogsFirehoseProps, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansOutputFormat, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansOutputFormat_S3, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansS3Props, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansLogGroupProps, _aws_cdk_mixins_preview_aws_rum_mixins_CfnAppMonitorRumOtelSpansFirehoseProps, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_TlsDetails, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_SessionContext, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_Attributes, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_SessionIssuer, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AdditionalEventData, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_ObjectRetentionInfo, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_LegalHoldInfo, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_RetentionInfo, _aws_cdk_mixins_preview_aws_s3_events_AWSAPICallViaCloudTrail_AwsapiCallViaCloudTrailItem, _aws_cdk_mixins_preview_aws_s3_events_BucketEvents, _aws_cdk_mixins_preview_aws_s3_events_ObjectAccessTierChanged, _aws_cdk_mixins_preview_aws_s3_events_ObjectAccessTierChanged_ObjectAccessTierChangedProps, _aws_cdk_mixins_preview_aws_s3_events_ObjectAccessTierChanged_Bucket, _aws_cdk_mixins_preview_aws_s3_events_ObjectAccessTierChanged_ObjectType, _aws_cdk_mixins_preview_aws_s3_events_ObjectACLUpdated, _aws_cdk_mixins_preview_aws_s3_events_ObjectACLUpdated_ObjectACLUpdatedProps, _aws_cdk_mixins_preview_aws_s3_events_ObjectACLUpdated_Bucket, _aws_cdk_mixins_preview_aws_s3_events_ObjectACLUpdated_ObjectType, _aws_cdk_mixins_preview_aws_s3_events_ObjectCreated, _aws_cdk_mixins_preview_aws_s3_events_ObjectCreated_ObjectCreatedProps, _aws_cdk_mixins_preview_aws_s3_events_ObjectCreated_Bucket, _aws_cdk_mixins_preview_aws_s3_events_ObjectCreated_ObjectType, _aws_cdk_mixins_preview_aws_s3_events_ObjectDeleted, _aws_cdk_mixins_preview_aws_s3_events_ObjectDeleted_ObjectDeletedProps, _aws_cdk_mixins_preview_aws_s3_events_ObjectDeleted_Bucket, _aws_cdk_mixins_preview_aws_s3_events_ObjectDeleted_ObjectType, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreCompleted, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreCompleted_ObjectRestoreCompletedProps, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreCompleted_Bucket, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreCompleted_ObjectType, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreExpired, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreExpired_ObjectRestoreExpiredProps, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreExpired_Bucket, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreExpired_ObjectType, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreInitiated, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreInitiated_ObjectRestoreInitiatedProps, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreInitiated_Bucket, _aws_cdk_mixins_preview_aws_s3_events_ObjectRestoreInitiated_ObjectType, _aws_cdk_mixins_preview_aws_s3_events_ObjectStorageClassChanged, _aws_cdk_mixins_preview_aws_s3_events_ObjectStorageClassChanged_ObjectStorageClassChangedProps, _aws_cdk_mixins_preview_aws_s3_events_ObjectStorageClassChanged_Bucket, _aws_cdk_mixins_preview_aws_s3_events_ObjectStorageClassChanged_ObjectType, _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsAdded, _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsAdded_ObjectTagsAddedProps, _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsAdded_Bucket, _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsAdded_ObjectType, _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsDeleted, _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsDeleted_ObjectTagsDeletedProps, _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsDeleted_Bucket, _aws_cdk_mixins_preview_aws_s3_events_ObjectTagsDeleted_ObjectType, _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogs, _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketLogsMixin, _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsOutputFormat, _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsRecordFields, _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsS3Props, _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsLogGroupProps, _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsFirehoseProps, _aws_cdk_mixins_preview_aws_s3_mixins_CfnBucketS3ServerAccessLogsDestProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerAlgorithmStateChange, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerAlgorithmStateChange_SageMakerAlgorithmStateChangeProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerAlgorithmStateChange_Tags, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointStateChange, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointStateChange_SageMakerEndpointStateChangeProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointStateChange_Tags, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerGroundTruthLabelingJobTaskStatusChange, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerGroundTruthLabelingJobTaskStatusChange_SageMakerGroundTruthLabelingJobTaskStatusChangeProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_SageMakerHyperParameterTuningJobStateChangeProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_TrainingJobStatusCounters, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_ObjectiveStatusCounters, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_TrainingJobDefinition, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_AlgorithmSpecification, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_AlgorithmSpecificationItem, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_StoppingCondition, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_VpcConfig, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_OutputDataConfig, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_Tags, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_ResourceConfig, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_TrainingJobDefinitionItem, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_DataSource, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerHyperParameterTuningJobStateChange_S3DataSource, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStatusChange, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStatusChange_SageMakerModelBuildingPipelineExecutionStatusChangeProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange_SageMakerModelBuildingPipelineExecutionStepStatusChangeProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange_CacheHitResult, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange_Metadata, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelBuildingPipelineExecutionStepStatusChange_ProcessingJob, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelPackageStateChange, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelPackageStateChange_SageMakerModelPackageStateChangeProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelPackageStateChange_Tags, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_SageMakerModelStateChangeProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_PrimaryContainer, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerModelStateChange_Tags, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookInstanceStateChange, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookInstanceStateChange_SageMakerNotebookInstanceStateChangeProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookInstanceStateChange_Tags, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookLifecycleConfigStateChange, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookLifecycleConfigStateChange_SageMakerNotebookLifecycleConfigStateChangeProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerNotebookLifecycleConfigStateChange_Tags, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_AlgorithmSpecification, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_OutputDataConfig, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_ModelArtifacts, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_StoppingCondition, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_ResourceConfig, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_Tags, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeItem, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_DataSource, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_S3DataSource, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTrainingJobStateChange_SageMakerTrainingJobStateChangeItem1, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_SageMakerEndpointConfigStateChangeProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_Tags, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerEndpointConfigStateChange_SageMakerEndpointConfigStateChangeItem, _aws_cdk_mixins_preview_aws_sagemaker_events_EndpointConfigEvents, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_AWSAPICallViaCloudTrailProps, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_ResponseElements, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_RequestParameters, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_PrimaryContainer, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_StoppingCondition, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_OutputDataConfig, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_TransformInput, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_DataSource, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_S3DataSource, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_AlgorithmSpecification, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_ResourceConfig, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_TransformOutput, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_HyperParameters, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_TransformResources, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_RequestParametersItem, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_RequestParametersItem2, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_DataSource1, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_S3DataSource1, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_UserIdentity, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_SessionContext, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_SessionIssuer, _aws_cdk_mixins_preview_aws_sagemaker_events_AWSAPICallViaCloudTrail_Attributes, _aws_cdk_mixins_preview_aws_sagemaker_events_ModelEvents, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_SageMakerTransformJobStateChangeProps, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_TransformResources, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_TransformOutput, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_TransformInput, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_DataSource, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_S3DataSource, _aws_cdk_mixins_preview_aws_sagemaker_events_SageMakerTransformJobStateChange_Tags, _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogs, _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamLogsMixin, _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogsOutputFormat, _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogsS3Props, _aws_cdk_mixins_preview_aws_sagemaker_mixins_CfnWorkteamActivityLogsLogGroupProps, _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubFindingsCustomAction, _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubFindingsCustomAction_SecurityHubFindingsCustomActionProps, _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubFindingsImported, _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubFindingsImported_SecurityHubFindingsImportedProps, _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubInsightResults, _aws_cdk_mixins_preview_aws_securityhub_events_SecurityHubInsightResults_SecurityHubInsightResultsProps, _aws_cdk_mixins_preview_aws_ses_events_AdvisorRecommendationStatusOpen, _aws_cdk_mixins_preview_aws_ses_events_AdvisorRecommendationStatusOpen_AdvisorRecommendationStatusOpenProps, _aws_cdk_mixins_preview_aws_ses_events_AdvisorRecommendationStatusResolved, _aws_cdk_mixins_preview_aws_ses_events_AdvisorRecommendationStatusResolved_AdvisorRecommendationStatusResolvedProps, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogs, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogs, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointLogsMixin, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsRecordFields, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointApplicationLogsDestProps, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsLogGroupProps, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsFirehoseProps, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerIngressPointTrafficPolicyDebugLogsDestProps, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogs, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetLogsMixin, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsOutputFormat, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsRecordFields, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsS3Props, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsLogGroupProps, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsFirehoseProps, _aws_cdk_mixins_preview_aws_ses_mixins_CfnMailManagerRuleSetApplicationLogsDestProps, _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogs, _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionLogsMixin, _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsOutputFormat, _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsRecordFields, _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsS3Props, _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsLogGroupProps, _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsFirehoseProps, _aws_cdk_mixins_preview_aws_shield_mixins_CfnProtectionFlowLogsDestProps, _aws_cdk_mixins_preview_aws_ssm_events_CalendarStateChange, _aws_cdk_mixins_preview_aws_ssm_events_CalendarStateChange_CalendarStateChangeProps, _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogs, _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogs, _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineLogsMixin, _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogsOutputFormat, _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogsRecordFields, _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogsLogGroupProps, _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineExpressLogsDestProps, _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogsOutputFormat, _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogsRecordFields, _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogsLogGroupProps, _aws_cdk_mixins_preview_aws_stepfunctions_mixins_CfnStateMachineStandardLogsDestProps, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange_SyntheticsCanaryStatusChangeProps, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange_ChangedConfig, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange_ExecutionArn, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryStatusChange_TestCodeLayerVersionArn, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunFailure, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunFailure_SyntheticsCanaryTestRunFailureProps, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunFailure_CanaryRunTimeline, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunSuccessful, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunSuccessful_SyntheticsCanaryTestRunSuccessfulProps, _aws_cdk_mixins_preview_aws_synthetics_events_SyntheticsCanaryTestRunSuccessful_CanaryRunTimeline, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryCreateCompleted, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryCreateCompleted_FTPServerDirectoryCreateCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryCreateFailed, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryCreateFailed_FTPServerDirectoryCreateFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryDeleteCompleted, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryDeleteCompleted_FTPServerDirectoryDeleteCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryDeleteFailed, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerDirectoryDeleteFailed_FTPServerDirectoryDeleteFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDeleteCompleted, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDeleteCompleted_FTPServerFileDeleteCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDeleteFailed, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDeleteFailed_FTPServerFileDeleteFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDownloadCompleted, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDownloadCompleted_FTPServerFileDownloadCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDownloadFailed, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileDownloadFailed_FTPServerFileDownloadFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileRenameCompleted, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileRenameCompleted_FTPServerFileRenameCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileRenameFailed, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileRenameFailed_FTPServerFileRenameFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileUploadCompleted, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileUploadCompleted_FTPServerFileUploadCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileUploadFailed, _aws_cdk_mixins_preview_aws_transfer_events_FTPServerFileUploadFailed_FTPServerFileUploadFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryCreateCompleted, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryCreateCompleted_FTPSServerDirectoryCreateCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryCreateFailed, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryCreateFailed_FTPSServerDirectoryCreateFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryDeleteCompleted, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryDeleteCompleted_FTPSServerDirectoryDeleteCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryDeleteFailed, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerDirectoryDeleteFailed_FTPSServerDirectoryDeleteFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDeleteCompleted, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDeleteCompleted_FTPSServerFileDeleteCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDeleteFailed, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDeleteFailed_FTPSServerFileDeleteFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDownloadCompleted, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDownloadCompleted_FTPSServerFileDownloadCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDownloadFailed, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileDownloadFailed_FTPSServerFileDownloadFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileRenameCompleted, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileRenameCompleted_FTPSServerFileRenameCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileRenameFailed, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileRenameFailed_FTPSServerFileRenameFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileUploadCompleted, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileUploadCompleted_FTPSServerFileUploadCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileUploadFailed, _aws_cdk_mixins_preview_aws_transfer_events_FTPSServerFileUploadFailed_FTPSServerFileUploadFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryCreateCompleted, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryCreateCompleted_SFTPServerDirectoryCreateCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryCreateFailed, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryCreateFailed_SFTPServerDirectoryCreateFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryDeleteCompleted, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryDeleteCompleted_SFTPServerDirectoryDeleteCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryDeleteFailed, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerDirectoryDeleteFailed_SFTPServerDirectoryDeleteFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDeleteCompleted, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDeleteCompleted_SFTPServerFileDeleteCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDeleteFailed, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDeleteFailed_SFTPServerFileDeleteFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDownloadCompleted, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDownloadCompleted_SFTPServerFileDownloadCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDownloadFailed, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileDownloadFailed_SFTPServerFileDownloadFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileRenameCompleted, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileRenameCompleted_SFTPServerFileRenameCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileRenameFailed, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileRenameFailed_SFTPServerFileRenameFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileUploadCompleted, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileUploadCompleted_SFTPServerFileUploadCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileUploadFailed, _aws_cdk_mixins_preview_aws_transfer_events_SFTPServerFileUploadFailed_SFTPServerFileUploadFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendCompleted, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendCompleted_AS2MDNSendCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendCompleted_S3Attributes, _aws_cdk_mixins_preview_aws_transfer_events_AgreementEvents, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendFailed, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendFailed_AS2MDNSendFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNSendFailed_S3Attributes, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveCompleted, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveCompleted_AS2PayloadReceiveCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveCompleted_S3Attributes, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveFailed, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveFailed_AS2PayloadReceiveFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadReceiveFailed_S3Attributes, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveCompleted, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveCompleted_AS2MDNReceiveCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveCompleted_S3Attributes, _aws_cdk_mixins_preview_aws_transfer_events_ConnectorEvents, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveFailed, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveFailed_AS2MDNReceiveFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_AS2MDNReceiveFailed_S3Attributes, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendCompleted, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendCompleted_AS2PayloadSendCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendCompleted_S3Attributes, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendFailed, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendFailed_AS2PayloadSendFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_AS2PayloadSendFailed_S3Attributes, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingCompleted, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingCompleted_SFTPConnectorDirectoryListingCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingCompleted_OutputFileLocation, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingFailed, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorDirectoryListingFailed_SFTPConnectorDirectoryListingFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveCompleted, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveCompleted_SFTPConnectorFileRetrieveCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveCompleted_LocalFileLocation, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveFailed, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveFailed_SFTPConnectorFileRetrieveFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileRetrieveFailed_LocalFileLocation, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendCompleted, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendCompleted_SFTPConnectorFileSendCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendCompleted_LocalFileLocation, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendFailed, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendFailed_SFTPConnectorFileSendFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorFileSendFailed_LocalFileLocation, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteDeleteCompleted, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteDeleteCompleted_SFTPConnectorRemoteDeleteCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteDeleteFailed, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteDeleteFailed_SFTPConnectorRemoteDeleteFailedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteMoveCompleted, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteMoveCompleted_SFTPConnectorRemoteMoveCompletedProps, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteMoveFailed, _aws_cdk_mixins_preview_aws_transfer_events_SFTPConnectorRemoteMoveFailed_SFTPConnectorRemoteMoveFailedProps, _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogs, _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerLogsMixin, _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsOutputFormat, _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsS3Props, _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsLogGroupProps, _aws_cdk_mixins_preview_aws_transfer_mixins_CfnServerTransferLogsFirehoseProps, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_VoiceIdBatchFraudsterRegistrationActionProps, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_Data, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_InputDataConfig, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_OutputDataConfig, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_RegistrationConfig, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchFraudsterRegistrationAction_ErrorInfo, _aws_cdk_mixins_preview_aws_voiceid_events_DomainEvents, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_VoiceIdBatchSpeakerEnrollmentActionProps, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_Data, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_EnrollmentConfig, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_FraudDetectionConfig, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_InputDataConfig, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_OutputDataConfig, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdBatchSpeakerEnrollmentAction_ErrorInfo, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_VoiceIdEvaluateSessionActionProps, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_ErrorInfo, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_Session, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_AuthenticationResult, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_ConfigurationAuthentication, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_FraudDetectionResult, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_ConfigurationFraud, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_RiskDetails, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_KnownFraudsterRisk, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_VoiceSpoofingRisk, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdEvaluateSessionAction_SystemAttributes, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdFraudsterAction, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdFraudsterAction_VoiceIdFraudsterActionProps, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdFraudsterAction_Data, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdFraudsterAction_ErrorInfo, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSessionSpeakerEnrollmentAction, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSessionSpeakerEnrollmentAction_VoiceIdSessionSpeakerEnrollmentActionProps, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSessionSpeakerEnrollmentAction_ErrorInfo, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSessionSpeakerEnrollmentAction_SystemAttributes, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction_VoiceIdSpeakerActionProps, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction_Data, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction_ErrorInfo, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdSpeakerAction_SystemAttributes, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_VoiceIdStartSessionActionProps, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_ErrorInfo, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_Session, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_AuthenticationAudioProgress, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_AuthenticationConfiguration, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_EnrollmentAudioProgress, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_FraudDetectionConfiguration, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_StreamingConfiguration, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdStartSessionAction_SystemAttributes, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_VoiceIdUpdateSessionActionProps, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_ErrorInfo, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_Session, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_AuthenticationConfiguration, _aws_cdk_mixins_preview_aws_voiceid_events_VoiceIdUpdateSessionAction_FraudDetectionConfiguration, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogs, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceLogsMixin, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsOutputFormat, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsS3Props, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsLogGroupProps, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnServiceAccessLogsFirehoseProps, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogs, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationLogsMixin, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsOutputFormat, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsS3Props, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsLogGroupProps, _aws_cdk_mixins_preview_aws_vpclattice_mixins_CfnResourceConfigurationResourceAccessLogsFirehoseProps, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogs, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogs, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLLogsMixin, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsOutputFormat, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsS3Props, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsLogGroupProps, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLAccessLogsFirehoseProps, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsOutputFormat, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsS3Props, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsLogGroupProps, _aws_cdk_mixins_preview_aws_wafv2_mixins_CfnWebACLTokenLogsFirehoseProps, _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogs, _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantLogsMixin, _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsOutputFormat, _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsOutputFormat_S3, _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsOutputFormat_LogGroup, _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsOutputFormat_Firehose, _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsRecordFields, _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsS3Props, _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsLogGroupProps, _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsFirehoseProps, _aws_cdk_mixins_preview_aws_wisdom_mixins_CfnAssistantEventLogsDestProps, _aws_cdk_mixins_preview_aws_workspaces_events_WorkSpacesAccess, _aws_cdk_mixins_preview_aws_workspaces_events_WorkSpacesAccess_WorkSpacesAccessProps, _aws_cdk_mixins_preview_aws_workspaces_events_WorkspaceEvents, _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate, _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_AWSXRayInsightUpdateProps, _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_ClientRequestImpactStatistics, _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_Event, _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_AwsxRayInsightUpdateItem, _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_ServiceId, _aws_cdk_mixins_preview_aws_xray_events_AWSXRayInsightUpdate_RootCauseServiceId };
