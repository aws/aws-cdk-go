import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-elementalinference";
/**
 * Builder for CfnFeedLogsMixin to generate APPLICATION_LOGS for CfnFeed
 *
 * @cloudformationResource AWS::ElementalInference::Feed
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnFeedApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnFeedApplicationLogsS3Props): CfnFeedLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnFeedApplicationLogsLogGroupProps): CfnFeedLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnFeedApplicationLogsFirehoseProps): CfnFeedLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnFeedApplicationLogsDestProps): CfnFeedLogsMixin;
}
/**
 * Represents a feed that receives media for inference processing.
 *
 * @cloudformationResource AWS::ElementalInference::Feed
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-elementalinference-feed.html
 */
export declare class CfnFeedLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnFeedApplicationLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::ElementalInference::Feed`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnFeed;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnFeedApplicationLogs.
 */
export declare class CfnFeedApplicationLogsOutputFormat {
}
export declare namespace CfnFeedApplicationLogsOutputFormat {
    enum S3 {
        PLAIN = "plain",
        JSON = "json",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        PLAIN = "plain",
        JSON = "json",
        RAW = "raw"
    }
}
export declare enum CfnFeedApplicationLogsRecordFields {
    TIMESTAMP = "timestamp",
    RESOURCE_ID = "resource_id",
    RESOURCE_TYPE = "resource_type",
    DETAIL = "detail",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    LOG_LEVEL = "log_level",
    MESSAGE = "message"
}
export interface CfnFeedApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are plain,json,w3c,parquet
     */
    readonly outputFormat?: CfnFeedApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFeedApplicationLogsRecordFields>;
}
export interface CfnFeedApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnFeedApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFeedApplicationLogsRecordFields>;
}
export interface CfnFeedApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are plain,json,raw
     */
    readonly outputFormat?: CfnFeedApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFeedApplicationLogsRecordFields>;
}
export interface CfnFeedApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnFeedApplicationLogsRecordFields>;
}
