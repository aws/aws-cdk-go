import * as cdk from "aws-cdk-lib/core";
import * as interfaces from "aws-cdk-lib/interfaces";
import * as constructs from "constructs";
import * as logsDelivery from "../aws-logs/logs-delivery";
import * as service from "aws-cdk-lib/aws-bedrockagentcore";
/**
 * Builder for CfnBrowserLogsMixin to generate USAGE_LOGS for CfnBrowser
 *
 * @cloudformationResource AWS::BedrockAgentCore::Browser
 * @logType USAGE_LOGS
 * @stability external
 */
export declare class CfnBrowserUsageLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnBrowserUsageLogsS3Props): CfnBrowserLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnBrowserUsageLogsLogGroupProps): CfnBrowserLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnBrowserUsageLogsFirehoseProps): CfnBrowserLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnBrowserUsageLogsDestProps): CfnBrowserLogsMixin;
}
/**
 * Definition of AWS::BedrockAgentCore::Browser Resource Type.
 *
 * This is a read-only resource representing the default service-managed browser.
 *
 * @cloudformationResource AWS::BedrockAgentCore::Browser
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-browser.html
 */
export declare class CfnBrowserLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly USAGE_LOGS: CfnBrowserUsageLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::BedrockAgentCore::Browser`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnBrowser;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnBrowserUsageLogs.
 */
export declare class CfnBrowserUsageLogsOutputFormat {
}
export declare namespace CfnBrowserUsageLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnBrowserUsageLogsRecordFields {
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    RESOURCE = "resource",
    ATTRIBUTES = "attributes",
    METRICS = "metrics"
}
export interface CfnBrowserUsageLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnBrowserUsageLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnBrowserUsageLogsRecordFields>;
}
export interface CfnBrowserUsageLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnBrowserUsageLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnBrowserUsageLogsRecordFields>;
}
export interface CfnBrowserUsageLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnBrowserUsageLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnBrowserUsageLogsRecordFields>;
}
export interface CfnBrowserUsageLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnBrowserUsageLogsRecordFields>;
}
/**
 * Builder for CfnBrowserCustomLogsMixin to generate USAGE_LOGS for CfnBrowserCustom
 *
 * @cloudformationResource AWS::BedrockAgentCore::BrowserCustom
 * @logType USAGE_LOGS
 * @stability external
 */
export declare class CfnBrowserCustomUsageLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnBrowserCustomUsageLogsS3Props): CfnBrowserCustomLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnBrowserCustomUsageLogsLogGroupProps): CfnBrowserCustomLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnBrowserCustomUsageLogsFirehoseProps): CfnBrowserCustomLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnBrowserCustomUsageLogsDestProps): CfnBrowserCustomLogsMixin;
}
/**
 * AgentCore Browser tool provides a fast, secure, cloud-based browser runtime to enable AI agents to interact with websites at scale.
 *
 * For more information about using the custom browser, see [Interact with web applications using Amazon Bedrock AgentCore Browser](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/browser-tool.html) .
 *
 * See the *Properties* section below for descriptions of both the required and optional properties.
 *
 * @cloudformationResource AWS::BedrockAgentCore::BrowserCustom
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-browsercustom.html
 */
export declare class CfnBrowserCustomLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly USAGE_LOGS: CfnBrowserCustomUsageLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::BedrockAgentCore::BrowserCustom`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnBrowserCustom;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnBrowserCustomUsageLogs.
 */
export declare class CfnBrowserCustomUsageLogsOutputFormat {
}
export declare namespace CfnBrowserCustomUsageLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnBrowserCustomUsageLogsRecordFields {
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    RESOURCE = "resource",
    ATTRIBUTES = "attributes",
    METRICS = "metrics"
}
export interface CfnBrowserCustomUsageLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnBrowserCustomUsageLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnBrowserCustomUsageLogsRecordFields>;
}
export interface CfnBrowserCustomUsageLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnBrowserCustomUsageLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnBrowserCustomUsageLogsRecordFields>;
}
export interface CfnBrowserCustomUsageLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnBrowserCustomUsageLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnBrowserCustomUsageLogsRecordFields>;
}
export interface CfnBrowserCustomUsageLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnBrowserCustomUsageLogsRecordFields>;
}
/**
 * Builder for CfnCodeInterpreterCustomLogsMixin to generate APPLICATION_LOGS for CfnCodeInterpreterCustom
 *
 * @cloudformationResource AWS::BedrockAgentCore::CodeInterpreterCustom
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnCodeInterpreterCustomApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnCodeInterpreterCustomApplicationLogsS3Props): CfnCodeInterpreterCustomLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnCodeInterpreterCustomApplicationLogsLogGroupProps): CfnCodeInterpreterCustomLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnCodeInterpreterCustomApplicationLogsFirehoseProps): CfnCodeInterpreterCustomLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnCodeInterpreterCustomApplicationLogsDestProps): CfnCodeInterpreterCustomLogsMixin;
}
/**
 * Builder for CfnCodeInterpreterCustomLogsMixin to generate USAGE_LOGS for CfnCodeInterpreterCustom
 *
 * @cloudformationResource AWS::BedrockAgentCore::CodeInterpreterCustom
 * @logType USAGE_LOGS
 * @stability external
 */
export declare class CfnCodeInterpreterCustomUsageLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnCodeInterpreterCustomUsageLogsS3Props): CfnCodeInterpreterCustomLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnCodeInterpreterCustomUsageLogsLogGroupProps): CfnCodeInterpreterCustomLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnCodeInterpreterCustomUsageLogsFirehoseProps): CfnCodeInterpreterCustomLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnCodeInterpreterCustomUsageLogsDestProps): CfnCodeInterpreterCustomLogsMixin;
}
/**
 * The AgentCore Code Interpreter tool enables agents to securely execute code in isolated sandbox environments.
 *
 * It offers advanced configuration support and seamless integration with popular frameworks.
 *
 * For more information about using the custom code interpreter, see [Execute code and analyze data using Amazon Bedrock AgentCore Code Interpreter](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/code-interpreter-tool.html) .
 *
 * See the *Properties* section below for descriptions of both the required and optional properties.
 *
 * @cloudformationResource AWS::BedrockAgentCore::CodeInterpreterCustom
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-codeinterpretercustom.html
 */
export declare class CfnCodeInterpreterCustomLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnCodeInterpreterCustomApplicationLogs;
    static readonly USAGE_LOGS: CfnCodeInterpreterCustomUsageLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::BedrockAgentCore::CodeInterpreterCustom`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCodeInterpreterCustom;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnCodeInterpreterCustomApplicationLogs.
 */
export declare class CfnCodeInterpreterCustomApplicationLogsOutputFormat {
}
export declare namespace CfnCodeInterpreterCustomApplicationLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnCodeInterpreterCustomApplicationLogsRecordFields {
    ACCOUNT_ID = "account_id",
    REQUEST_ID = "request_id",
    TOOL_SESSION_ID = "tool_session_id",
    SPAN_ID = "span_id",
    TRACE_ID = "trace_id",
    SERVICE_NAME = "service_name",
    OPERATION = "operation",
    REQUEST_PAYLOAD = "request_payload",
    RESPONSE_PAYLOAD = "response_payload",
    RESOURCE = "resource",
    ATTRIBUTES = "attributes",
    TIMEUNIXNANO = "timeUnixNano",
    SEVERITYNUMBER = "severityNumber",
    SEVERITYTEXT = "severityText",
    BODY = "body",
    TRACEID = "traceId",
    SPANID = "spanId",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnCodeInterpreterCustomApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnCodeInterpreterCustomApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCodeInterpreterCustomApplicationLogsRecordFields>;
}
export interface CfnCodeInterpreterCustomApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnCodeInterpreterCustomApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCodeInterpreterCustomApplicationLogsRecordFields>;
}
export interface CfnCodeInterpreterCustomApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnCodeInterpreterCustomApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCodeInterpreterCustomApplicationLogsRecordFields>;
}
export interface CfnCodeInterpreterCustomApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCodeInterpreterCustomApplicationLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnCodeInterpreterCustomUsageLogs.
 */
export declare class CfnCodeInterpreterCustomUsageLogsOutputFormat {
}
export declare namespace CfnCodeInterpreterCustomUsageLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnCodeInterpreterCustomUsageLogsRecordFields {
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    RESOURCE = "resource",
    ATTRIBUTES = "attributes",
    METRICS = "metrics"
}
export interface CfnCodeInterpreterCustomUsageLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnCodeInterpreterCustomUsageLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCodeInterpreterCustomUsageLogsRecordFields>;
}
export interface CfnCodeInterpreterCustomUsageLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnCodeInterpreterCustomUsageLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCodeInterpreterCustomUsageLogsRecordFields>;
}
export interface CfnCodeInterpreterCustomUsageLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnCodeInterpreterCustomUsageLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCodeInterpreterCustomUsageLogsRecordFields>;
}
export interface CfnCodeInterpreterCustomUsageLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnCodeInterpreterCustomUsageLogsRecordFields>;
}
/**
 * Builder for CfnGatewayLogsMixin to generate APPLICATION_LOGS for CfnGateway
 *
 * @cloudformationResource AWS::BedrockAgentCore::Gateway
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnGatewayApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnGatewayApplicationLogsS3Props): CfnGatewayLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnGatewayApplicationLogsLogGroupProps): CfnGatewayLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnGatewayApplicationLogsFirehoseProps): CfnGatewayLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnGatewayApplicationLogsDestProps): CfnGatewayLogsMixin;
}
/**
 * Builder for CfnGatewayLogsMixin to generate TRACES for CfnGateway
 *
 * @cloudformationResource AWS::BedrockAgentCore::Gateway
 * @logType TRACES
 * @stability external
 */
export declare class CfnGatewayTraces {
    /**
     * Send traces to X-Ray
     *
     * @param props Additional properties that are optionally used in log delivery for XRay destinations
     */
    toXRay(props?: CfnGatewayTracesXRayProps): CfnGatewayLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are XRAY
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnGatewayTracesDestProps): CfnGatewayLogsMixin;
}
/**
 * Amazon Bedrock AgentCore Gateway provides a unified connectivity layer between agents and the tools and resources they need to interact with.
 *
 * For more information about creating a gateway, see [Set up an Amazon Bedrock AgentCore gateway](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-building.html) .
 *
 * See the *Properties* section below for descriptions of both the required and optional properties.
 *
 * @cloudformationResource AWS::BedrockAgentCore::Gateway
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-gateway.html
 */
export declare class CfnGatewayLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnGatewayApplicationLogs;
    static readonly TRACES: CfnGatewayTraces;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::BedrockAgentCore::Gateway`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnGateway;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnGatewayApplicationLogs.
 */
export declare class CfnGatewayApplicationLogsOutputFormat {
}
export declare namespace CfnGatewayApplicationLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnGatewayApplicationLogsRecordFields {
    BODY = "body",
    ACCOUNT_ID = "account_id",
    REQUEST_ID = "request_id",
    TRACE_ID = "trace_id",
    SPAN_ID = "span_id",
    RESOURCE = "resource",
    ATTRIBUTES = "attributes",
    TIMEUNIXNANO = "timeUnixNano",
    SEVERITYNUMBER = "severityNumber",
    SEVERITYTEXT = "severityText",
    TRACEID = "traceId",
    SPANID = "spanId",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnGatewayApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnGatewayApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGatewayApplicationLogsRecordFields>;
}
export interface CfnGatewayApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnGatewayApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGatewayApplicationLogsRecordFields>;
}
export interface CfnGatewayApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnGatewayApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGatewayApplicationLogsRecordFields>;
}
export interface CfnGatewayApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGatewayApplicationLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnGatewayTraces.
 */
export declare class CfnGatewayTracesOutputFormat {
}
export declare enum CfnGatewayTracesRecordFields {
    TRACE = "trace"
}
export interface CfnGatewayTracesXRayProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGatewayTracesRecordFields>;
}
export interface CfnGatewayTracesDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnGatewayTracesRecordFields>;
}
/**
 * Builder for CfnMemoryLogsMixin to generate APPLICATION_LOGS for CfnMemory
 *
 * @cloudformationResource AWS::BedrockAgentCore::Memory
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnMemoryApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnMemoryApplicationLogsS3Props): CfnMemoryLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnMemoryApplicationLogsLogGroupProps): CfnMemoryLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnMemoryApplicationLogsFirehoseProps): CfnMemoryLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnMemoryApplicationLogsDestProps): CfnMemoryLogsMixin;
}
/**
 * Builder for CfnMemoryLogsMixin to generate TRACES for CfnMemory
 *
 * @cloudformationResource AWS::BedrockAgentCore::Memory
 * @logType TRACES
 * @stability external
 */
export declare class CfnMemoryTraces {
    /**
     * Send traces to X-Ray
     *
     * @param props Additional properties that are optionally used in log delivery for XRay destinations
     */
    toXRay(props?: CfnMemoryTracesXRayProps): CfnMemoryLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are XRAY
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnMemoryTracesDestProps): CfnMemoryLogsMixin;
}
/**
 * Memory allows AI agents to maintain both immediate and long-term knowledge, enabling context-aware and personalized interactions.
 *
 * For more information about using Memory in Amazon Bedrock AgentCore, see [Host agent or tools with Amazon Bedrock AgentCore Memory](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/memory-getting-started.html) .
 *
 * See the *Properties* section below for descriptions of both the required and optional properties.
 *
 * @cloudformationResource AWS::BedrockAgentCore::Memory
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-memory.html
 */
export declare class CfnMemoryLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnMemoryApplicationLogs;
    static readonly TRACES: CfnMemoryTraces;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::BedrockAgentCore::Memory`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnMemory;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnMemoryApplicationLogs.
 */
export declare class CfnMemoryApplicationLogsOutputFormat {
}
export declare namespace CfnMemoryApplicationLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnMemoryApplicationLogsRecordFields {
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    MEMORY_STRATEGY_ID = "memory_strategy_id",
    NAMESPACE = "namespace",
    ACTOR_ID = "actor_id",
    SESSION_ID = "session_id",
    EVENT_ID = "event_id",
    BODY = "body",
    RESOURCE = "resource",
    ATTRIBUTES = "attributes",
    TIMEUNIXNANO = "timeUnixNano",
    SEVERITYNUMBER = "severityNumber",
    SEVERITYTEXT = "severityText",
    TRACEID = "traceId",
    SPANID = "spanId"
}
export interface CfnMemoryApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnMemoryApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMemoryApplicationLogsRecordFields>;
}
export interface CfnMemoryApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnMemoryApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMemoryApplicationLogsRecordFields>;
}
export interface CfnMemoryApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnMemoryApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMemoryApplicationLogsRecordFields>;
}
export interface CfnMemoryApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMemoryApplicationLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnMemoryTraces.
 */
export declare class CfnMemoryTracesOutputFormat {
}
export declare enum CfnMemoryTracesRecordFields {
    TRACE = "trace"
}
export interface CfnMemoryTracesXRayProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMemoryTracesRecordFields>;
}
export interface CfnMemoryTracesDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnMemoryTracesRecordFields>;
}
/**
 * Builder for CfnRuntimeLogsMixin to generate APPLICATION_LOGS for CfnRuntime
 *
 * @cloudformationResource AWS::BedrockAgentCore::Runtime
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnRuntimeApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnRuntimeApplicationLogsS3Props): CfnRuntimeLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnRuntimeApplicationLogsLogGroupProps): CfnRuntimeLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnRuntimeApplicationLogsFirehoseProps): CfnRuntimeLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnRuntimeApplicationLogsDestProps): CfnRuntimeLogsMixin;
}
/**
 * Builder for CfnRuntimeLogsMixin to generate TRACES for CfnRuntime
 *
 * @cloudformationResource AWS::BedrockAgentCore::Runtime
 * @logType TRACES
 * @stability external
 */
export declare class CfnRuntimeTraces {
    /**
     * Send traces to X-Ray
     *
     * @param props Additional properties that are optionally used in log delivery for XRay destinations
     */
    toXRay(props?: CfnRuntimeTracesXRayProps): CfnRuntimeLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are XRAY
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnRuntimeTracesDestProps): CfnRuntimeLogsMixin;
}
/**
 * Builder for CfnRuntimeLogsMixin to generate USAGE_LOGS for CfnRuntime
 *
 * @cloudformationResource AWS::BedrockAgentCore::Runtime
 * @logType USAGE_LOGS
 * @stability external
 */
export declare class CfnRuntimeUsageLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnRuntimeUsageLogsS3Props): CfnRuntimeLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnRuntimeUsageLogsLogGroupProps): CfnRuntimeLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnRuntimeUsageLogsFirehoseProps): CfnRuntimeLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnRuntimeUsageLogsDestProps): CfnRuntimeLogsMixin;
}
/**
 * Contains information about an agent runtime. An agent runtime is the execution environment for a Amazon Bedrock Agent.
 *
 * AgentCore Runtime is a secure, serverless runtime purpose-built for deploying and scaling dynamic AI agents and tools using any open-source framework including LangGraph, CrewAI, and Strands Agents, any protocol, and any model.
 *
 * For more information about using agent runtime in Amazon Bedrock AgentCore, see [Host agent or tools with Amazon Bedrock AgentCore Runtime](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/agents-tools-runtime.html) .
 *
 * See the *Properties* section below for descriptions of both the required and optional properties.
 *
 * @cloudformationResource AWS::BedrockAgentCore::Runtime
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-runtime.html
 */
export declare class CfnRuntimeLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnRuntimeApplicationLogs;
    static readonly TRACES: CfnRuntimeTraces;
    static readonly USAGE_LOGS: CfnRuntimeUsageLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::BedrockAgentCore::Runtime`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnRuntime;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnRuntimeApplicationLogs.
 */
export declare class CfnRuntimeApplicationLogsOutputFormat {
}
export declare namespace CfnRuntimeApplicationLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnRuntimeApplicationLogsRecordFields {
    ACCOUNT_ID = "account_id",
    REQUEST_ID = "request_id",
    SESSION_ID = "session_id",
    SPAN_ID = "span_id",
    TRACE_ID = "trace_id",
    SERVICE_NAME = "service_name",
    OPERATION = "operation",
    REQUEST_PAYLOAD = "request_payload",
    RESPONSE_PAYLOAD = "response_payload",
    RESOURCE = "resource",
    ATTRIBUTES = "attributes",
    TIMEUNIXNANO = "timeUnixNano",
    SEVERITYNUMBER = "severityNumber",
    SEVERITYTEXT = "severityText",
    BODY = "body",
    TRACEID = "traceId",
    SPANID = "spanId",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnRuntimeApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnRuntimeApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRuntimeApplicationLogsRecordFields>;
}
export interface CfnRuntimeApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnRuntimeApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRuntimeApplicationLogsRecordFields>;
}
export interface CfnRuntimeApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnRuntimeApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRuntimeApplicationLogsRecordFields>;
}
export interface CfnRuntimeApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRuntimeApplicationLogsRecordFields>;
}
/**
 * Output Format options for each destination of CfnRuntimeTraces.
 */
export declare class CfnRuntimeTracesOutputFormat {
}
export declare enum CfnRuntimeTracesRecordFields {
    TRACE = "trace"
}
export interface CfnRuntimeTracesXRayProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRuntimeTracesRecordFields>;
}
export interface CfnRuntimeTracesDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRuntimeTracesRecordFields>;
}
/**
 * Output Format options for each destination of CfnRuntimeUsageLogs.
 */
export declare class CfnRuntimeUsageLogsOutputFormat {
}
export declare namespace CfnRuntimeUsageLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnRuntimeUsageLogsRecordFields {
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp",
    RESOURCE = "resource",
    ATTRIBUTES = "attributes",
    METRICS = "metrics"
}
export interface CfnRuntimeUsageLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnRuntimeUsageLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRuntimeUsageLogsRecordFields>;
}
export interface CfnRuntimeUsageLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnRuntimeUsageLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRuntimeUsageLogsRecordFields>;
}
export interface CfnRuntimeUsageLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnRuntimeUsageLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRuntimeUsageLogsRecordFields>;
}
export interface CfnRuntimeUsageLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnRuntimeUsageLogsRecordFields>;
}
/**
 * Builder for CfnWorkloadIdentityLogsMixin to generate APPLICATION_LOGS for CfnWorkloadIdentity
 *
 * @cloudformationResource AWS::BedrockAgentCore::WorkloadIdentity
 * @logType APPLICATION_LOGS
 * @stability external
 */
export declare class CfnWorkloadIdentityApplicationLogs {
    /**
     * Send logs to an S3 Bucket
     *
     * @param props Additional properties that are optionally used in log delivery for S3 destinations
     */
    toS3(bucket: interfaces.aws_s3.IBucketRef, props?: CfnWorkloadIdentityApplicationLogsS3Props): CfnWorkloadIdentityLogsMixin;
    /**
     * Send logs to a CloudWatch Log Group
     *
     * @param props Additional properties that are optionally used in log delivery for Log Group destinations
     */
    toLogGroup(logGroup: interfaces.aws_logs.ILogGroupRef, props?: CfnWorkloadIdentityApplicationLogsLogGroupProps): CfnWorkloadIdentityLogsMixin;
    /**
     * Send logs to a Firehose Delivery Stream
     *
     * @param props Additional properties that are optionally used in log delivery for Firehose destinations
     */
    toFirehose(deliveryStream: interfaces.aws_kinesisfirehose.IDeliveryStreamRef, props?: CfnWorkloadIdentityApplicationLogsFirehoseProps): CfnWorkloadIdentityLogsMixin;
    /**
     * Delivers logs to a pre-created delivery destination
     *
     * Supported destinations are S3, CWL, FH
     * You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
     * Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().
     *
     * @param props Additional properties that are optionally used in log delivery for destinations
     */
    toDestination(destination: interfaces.aws_logs.IDeliveryDestinationRef, props?: CfnWorkloadIdentityApplicationLogsDestProps): CfnWorkloadIdentityLogsMixin;
}
/**
 * Creates a workload identity for Amazon Bedrock AgentCore.
 *
 * A workload identity provides OAuth2-based authentication for resources associated with agent runtimes.
 *
 * For more information about using workload identities in Amazon Bedrock AgentCore, see [Managing workload identities](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/workload-identity.html) .
 *
 * See the *Properties* section below for descriptions of both the required and optional properties.
 *
 * @cloudformationResource AWS::BedrockAgentCore::WorkloadIdentity
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-workloadidentity.html
 */
export declare class CfnWorkloadIdentityLogsMixin extends cdk.Mixin implements constructs.IMixin {
    static readonly APPLICATION_LOGS: CfnWorkloadIdentityApplicationLogs;
    protected readonly logType: string;
    protected readonly logDelivery: logsDelivery.ILogsDelivery;
    /**
     * Create a mixin to enable vended logs for `AWS::BedrockAgentCore::WorkloadIdentity`.
     *
     * @param logType Type of logs that are getting vended
     * @param logDelivery Object in charge of setting up the delivery source, delivery destination, and delivery connection
     */
    constructor(logType: string, logDelivery: logsDelivery.ILogsDelivery);
    /**
     * Check if this mixin supports the given construct (has vendedLogs property)
     */
    supports(construct: constructs.IConstruct): construct is service.CfnWorkloadIdentity;
    /**
     * Apply vended logs configuration to the construct
     */
    applyTo(resource: constructs.IConstruct): void;
}
/**
 * Output Format options for each destination of CfnWorkloadIdentityApplicationLogs.
 */
export declare class CfnWorkloadIdentityApplicationLogsOutputFormat {
}
export declare namespace CfnWorkloadIdentityApplicationLogsOutputFormat {
    enum S3 {
        JSON = "json",
        PLAIN = "plain",
        W3C = "w3c",
        PARQUET = "parquet"
    }
    enum LogGroup {
        PLAIN = "plain",
        JSON = "json"
    }
    enum Firehose {
        JSON = "json",
        PLAIN = "plain",
        RAW = "raw"
    }
}
export declare enum CfnWorkloadIdentityApplicationLogsRecordFields {
    REQUEST_ID = "request_id",
    OPERATION_NAME = "operation_name",
    OPERATION_TYPE = "operation_type",
    START_TIME = "start_time",
    END_TIME = "end_time",
    DURATION_MS = "duration_ms",
    ACCOUNT_ID = "account_id",
    REQUEST = "request",
    RESPONSE = "response",
    TRACE_ID = "trace_id",
    SPAN_ID = "span_id",
    RESOURCE = "resource",
    ATTRIBUTES = "attributes",
    TIMEUNIXNANO = "timeUnixNano",
    SEVERITYNUMBER = "severityNumber",
    SEVERITYTEXT = "severityText",
    BODY = "body",
    TRACEID = "traceId",
    SPANID = "spanId",
    RESOURCE_ARN = "resource_arn",
    EVENT_TIMESTAMP = "event_timestamp"
}
export interface CfnWorkloadIdentityApplicationLogsS3Props {
    /**
     * Encrpytion key for your delivery bucket
     */
    readonly encryptionKey?: interfaces.aws_kms.IKeyRef;
    /**
     * Format for log output, options are json,plain,w3c,parquet
     */
    readonly outputFormat?: CfnWorkloadIdentityApplicationLogsOutputFormat.S3;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnWorkloadIdentityApplicationLogsRecordFields>;
}
export interface CfnWorkloadIdentityApplicationLogsLogGroupProps {
    /**
     * Format for log output, options are plain,json
     */
    readonly outputFormat?: CfnWorkloadIdentityApplicationLogsOutputFormat.LogGroup;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnWorkloadIdentityApplicationLogsRecordFields>;
}
export interface CfnWorkloadIdentityApplicationLogsFirehoseProps {
    /**
     * Format for log output, options are json,plain,raw
     */
    readonly outputFormat?: CfnWorkloadIdentityApplicationLogsOutputFormat.Firehose;
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnWorkloadIdentityApplicationLogsRecordFields>;
}
export interface CfnWorkloadIdentityApplicationLogsDestProps {
    /**
     * Record fields that can be provided to a log delivery
     */
    readonly recordFields?: Array<CfnWorkloadIdentityApplicationLogsRecordFields>;
}
