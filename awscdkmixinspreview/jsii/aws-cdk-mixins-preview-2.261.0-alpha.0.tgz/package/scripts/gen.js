"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const node_fs_1 = require("node:fs");
const fs = __importStar(require("node:fs/promises"));
const path = __importStar(require("node:path"));
const module_topology_1 = require("@aws-cdk/spec2cdk/lib/module-topology");
const submodule_files_1 = require("@aws-cdk/spec2cdk/lib/util/submodule-files");
const spec2eventbridge_1 = require("./spec2eventbridge");
const log_delivery_mixins_1 = require("@aws-cdk/spec2cdk/lib/log-delivery-mixins");
const config_1 = require("./config");
const GO_PREFIX = 'preview';
main().catch(e => {
    console.error(e);
    process.exitCode = 1;
});
async function main() {
    const pkgPath = path.join(__dirname, '..');
    const outputPath = path.join(pkgPath, 'lib', 'services');
    const results = [
        await (0, spec2eventbridge_1.generateAll)({ outputPath }),
        await (0, log_delivery_mixins_1.generateAll)({ outputPath, packageBases: config_1.MIXINS_PREVIEW_BASE_NAMES }),
    ];
    const moduleMap = (0, module_topology_1.mergeModuleMaps)(...results.map(r => r.moduleMap));
    const contributions = results.flatMap(r => r.contributions);
    await setupSubmodules(moduleMap, contributions, outputPath);
    await updateExportsAndEntryPoints(moduleMap, pkgPath);
}
async function setupSubmodules(modules, contributions, outPath) {
    for (const submodule of Object.values(modules)) {
        await ensureSubmodule(submodule, contributions, outPath);
    }
}
async function ensureSubmodule(submodule, contributions, outPath) {
    const modulePath = path.join(outPath, submodule.name);
    if (!submodule.definition) {
        throw new Error(`Cannot infer path or namespace for submodule named "${submodule.name}". Manually create ${modulePath}/.jsiirc.json files.`);
    }
    // Collect which barrel files this submodule needs, based on contributions
    // that have matching generated files
    const barrels = new Map();
    for (const c of contributions) {
        // Only add contribution if the submodule has a matching generated file
        const hasFile = c.exportLines.some(line => {
            const match = line.match(/from\s+'\.\/(.+)'/);
            return match && submodule.files.some(f => f.includes(match[1]));
        });
        if (!hasFile)
            continue;
        const existing = barrels.get(c.barrelFile);
        if (existing) {
            existing.lines.push(...c.exportLines);
        }
        else {
            barrels.set(c.barrelFile, { lines: [...c.exportLines], jsiircNamespace: c.jsiircNamespace });
        }
    }
    // services/<mod>/index.ts — re-exports each barrel as a namespace
    const subModuleIndex = path.join(modulePath, 'index.ts');
    const indexLines = [...barrels.keys()].map(barrel => {
        const ns = path.basename(barrel, '.ts');
        return `export * as ${ns} from './${ns}';`;
    });
    await (0, submodule_files_1.ensureFileContains)(subModuleIndex, indexLines);
    await (0, submodule_files_1.writeJsiiRc)((0, submodule_files_1.jsiiRcPathFor)(subModuleIndex), submodule.definition, { goPrefix: GO_PREFIX });
    // Write each barrel file
    for (const [barrelFile, { lines, jsiircNamespace }] of barrels) {
        const barrelPath = path.join(modulePath, barrelFile);
        await (0, submodule_files_1.ensureFileContains)(barrelPath, lines);
        await (0, submodule_files_1.writeJsiiRc)((0, submodule_files_1.jsiiRcPathFor)(barrelPath), submodule.definition, { goPrefix: GO_PREFIX, namespaceSuffix: jsiircNamespace });
    }
}
async function updateExportsAndEntryPoints(modules, pkgPath) {
    const servicesIndexFilePath = path.join(pkgPath, 'lib', 'services', 'index.ts');
    const serviceIndexExports = new Array();
    const pkgJsonPath = path.join(pkgPath, 'package.json');
    const pkgJson = JSON.parse((await fs.readFile(pkgJsonPath)).toString());
    // Clean up old service exports, keep only non-service exports
    const newExports = {};
    for (const [key, value] of Object.entries(pkgJson.exports)) {
        if (!key.startsWith('./aws-') && !key.startsWith('./alexa-')) {
            newExports[key] = value;
        }
    }
    for (const moduleName of Object.keys(modules)) {
        const moduleConfig = {
            name: moduleName,
            submodule: moduleName.replace(/-/g, '_'),
        };
        const indexExportName = `./${moduleConfig.name}`;
        newExports[indexExportName] = `./lib/services/${moduleConfig.name}/index.js`;
        if (!serviceIndexExports.find(e => e.includes(moduleConfig.name))) {
            serviceIndexExports.push(`export * as ${moduleConfig.submodule} from './${moduleConfig.name}';`);
        }
        const mixinsExportName = `./${moduleConfig.name}/mixins`;
        newExports[mixinsExportName] = `./lib/services/${moduleConfig.name}/mixins.js`;
        const eventsFilePath = path.join(pkgPath, 'lib', 'services', moduleConfig.name, 'events.ts');
        if ((0, node_fs_1.existsSync)(eventsFilePath)) {
            const eventsExportName = `./${moduleConfig.name}/events`;
            newExports[eventsExportName] = `./lib/services/${moduleConfig.name}/events.js`;
        }
    }
    pkgJson.exports = Object.fromEntries(Object.entries(newExports).sort(([e1], [e2]) => e1.localeCompare(e2)));
    await fs.writeFile(pkgJsonPath, JSON.stringify(pkgJson, null, 2) + '\n');
    await fs.writeFile(servicesIndexFilePath, serviceIndexExports.sort((l1, l2) => l1.localeCompare(l2)).join('\n') + '\n');
}
