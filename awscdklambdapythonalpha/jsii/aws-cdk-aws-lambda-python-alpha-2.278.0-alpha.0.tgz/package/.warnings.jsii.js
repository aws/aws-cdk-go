const VALIDATORS = { _aws_cdk_aws_lambda_python_alpha_PythonFunctionProps: function _aws_cdk_aws_lambda_python_alpha_PythonFunctionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.runtime))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_Runtime(p.runtime);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.bundling))
                module.exports._aws_cdk_aws_lambda_python_alpha_BundlingOptions(p.bundling);
            if (!visitedObjects.has(p.acceleratorConfig))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_AcceleratorConfig(p.acceleratorConfig);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.adotInstrumentation))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_AdotInstrumentationConfig(p.adotInstrumentation);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if ("applicationLogLevel" in p)
                print("aws-cdk-lib.aws_lambda.FunctionOptions#applicationLogLevel", "Use `applicationLogLevelV2` as a property instead.");
            if (!visitedObjects.has(p.applicationLogLevelV2))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ApplicationLogLevel(p.applicationLogLevelV2);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.architecture))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_Architecture(p.architecture);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.codeSigningConfig))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_lambda_ICodeSigningConfigRef(p.codeSigningConfig);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.currentVersionOptions))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_VersionOptions(p.currentVersionOptions);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.deadLetterQueue))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_sqs_IQueue(p.deadLetterQueue);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.deadLetterTopic))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_sns_ITopic(p.deadLetterTopic);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.durableConfig))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_DurableConfig(p.durableConfig);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.environmentEncryption))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.environmentEncryption);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.ephemeralStorageSize))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Size(p.ephemeralStorageSize);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.events != null)
                for (const o of p.events)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_IEventSource(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.filesystem))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_FileSystem(p.filesystem);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.initialPolicy != null)
                for (const o of p.initialPolicy)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_PolicyStatement(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.insightsVersion))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_LambdaInsightsVersion(p.insightsVersion);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.layers != null)
                for (const o of p.layers)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ILayerVersion(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if ("logFormat" in p)
                print("aws-cdk-lib.aws_lambda.FunctionOptions#logFormat", "Use `loggingFormat` as a property instead.");
            if (!visitedObjects.has(p.loggingFormat))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_LoggingFormat(p.loggingFormat);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.logGroup))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_logs_ILogGroupRef(p.logGroup);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if ("logRemovalPolicy" in p)
                print("aws-cdk-lib.aws_lambda.FunctionOptions#logRemovalPolicy", "use `logGroup` instead");
            if (!visitedObjects.has(p.logRemovalPolicy))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_RemovalPolicy(p.logRemovalPolicy);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if ("logRetention" in p)
                print("aws-cdk-lib.aws_lambda.FunctionOptions#logRetention", "use `logGroup` instead");
            if (!visitedObjects.has(p.logRetention))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_logs_RetentionDays(p.logRetention);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.logRetentionRetryOptions))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_LogRetentionRetryOptions(p.logRetentionRetryOptions);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.logRetentionRole))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.logRetentionRole);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.paramsAndSecrets))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ParamsAndSecretsLayerVersion(p.paramsAndSecrets);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.profilingGroup))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_codeguruprofiler_IProfilingGroup(p.profilingGroup);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.recursiveLoop))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_RecursiveLoop(p.recursiveLoop);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.runtimeManagementMode))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_RuntimeManagementMode(p.runtimeManagementMode);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.snapStart))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_SnapStartConf(p.snapStart);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if ("systemLogLevel" in p)
                print("aws-cdk-lib.aws_lambda.FunctionOptions#systemLogLevel", "Use `systemLogLevelV2` as a property instead.");
            if (!visitedObjects.has(p.systemLogLevelV2))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_SystemLogLevel(p.systemLogLevelV2);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.tenancyConfig))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_TenancyConfig(p.tenancyConfig);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.timeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.timeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.tracing))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_Tracing(p.tracing);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.vpc))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_IVpc(p.vpc);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.vpcSubnets))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(p.vpcSubnets);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.maxEventAge))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.maxEventAge);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.onFailure))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_IDestination(p.onFailure);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.onSuccess))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_IDestination(p.onSuccess);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_lambda_python_alpha_PythonLayerVersionProps: function _aws_cdk_aws_lambda_python_alpha_PythonLayerVersionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bundling))
                module.exports._aws_cdk_aws_lambda_python_alpha_BundlingOptions(p.bundling);
            if (p.compatibleArchitectures != null)
                for (const o of p.compatibleArchitectures)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_Architecture(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (p.compatibleRuntimes != null)
                for (const o of p.compatibleRuntimes)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_Runtime(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.removalPolicy))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_RemovalPolicy(p.removalPolicy);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_lambda_python_alpha_BundlingOptions: function _aws_cdk_aws_lambda_python_alpha_BundlingOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.assetHashType))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_AssetHashType(p.assetHashType);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.bundlingFileAccess))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_BundlingFileAccess(p.bundlingFileAccess);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.image))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_DockerImage(p.image);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.volumes != null)
                for (const o of p.volumes)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_DockerVolume(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
