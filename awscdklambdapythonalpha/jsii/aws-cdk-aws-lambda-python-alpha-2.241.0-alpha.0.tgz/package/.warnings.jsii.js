function _aws_cdk_aws_lambda_python_alpha_PythonFunctionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.bundling))
            _aws_cdk_aws_lambda_python_alpha_BundlingOptions(p.bundling);
        if ("applicationLogLevel" in p)
            print("aws-cdk-lib.aws_lambda.FunctionOptions#applicationLogLevel", "Use `applicationLogLevelV2` as a property instead.");
        if (p.events != null)
            for (const o of p.events)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_IEventSource(o);
        if (p.initialPolicy != null)
            for (const o of p.initialPolicy)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_PolicyStatement(o);
        if (p.layers != null)
            for (const o of p.layers)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ILayerVersion(o);
        if ("logFormat" in p)
            print("aws-cdk-lib.aws_lambda.FunctionOptions#logFormat", "Use `loggingFormat` as a property instead.");
        if ("logRemovalPolicy" in p)
            print("aws-cdk-lib.aws_lambda.FunctionOptions#logRemovalPolicy", "use `logGroup` instead");
        if ("logRetention" in p)
            print("aws-cdk-lib.aws_lambda.FunctionOptions#logRetention", "use `logGroup` instead");
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        if ("systemLogLevel" in p)
            print("aws-cdk-lib.aws_lambda.FunctionOptions#systemLogLevel", "Use `systemLogLevelV2` as a property instead.");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_lambda_python_alpha_PythonFunction(p) {
}
function _aws_cdk_aws_lambda_python_alpha_PythonLayerVersionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.bundling))
            _aws_cdk_aws_lambda_python_alpha_BundlingOptions(p.bundling);
        if (p.compatibleArchitectures != null)
            for (const o of p.compatibleArchitectures)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_Architecture(o);
        if (p.compatibleRuntimes != null)
            for (const o of p.compatibleRuntimes)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_Runtime(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_lambda_python_alpha_PythonLayerVersion(p) {
}
function _aws_cdk_aws_lambda_python_alpha_BundlingOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.commandHooks))
            _aws_cdk_aws_lambda_python_alpha_ICommandHooks(p.commandHooks);
        if (p.volumes != null)
            for (const o of p.volumes)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_DockerVolume(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_lambda_python_alpha_ICommandHooks(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_lambda_python_alpha_PythonFunctionProps, _aws_cdk_aws_lambda_python_alpha_PythonFunction, _aws_cdk_aws_lambda_python_alpha_PythonLayerVersionProps, _aws_cdk_aws_lambda_python_alpha_PythonLayerVersion, _aws_cdk_aws_lambda_python_alpha_BundlingOptions, _aws_cdk_aws_lambda_python_alpha_ICommandHooks };
