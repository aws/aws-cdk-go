import type { FunctionOptions, Runtime } from 'aws-cdk-lib/aws-lambda';
import { Function } from 'aws-cdk-lib/aws-lambda';
import type { Construct } from 'constructs';
import type { BundlingOptions } from './types';
/**
 * Properties for a PythonFunction
 */
export interface PythonFunctionProps extends FunctionOptions {
    /**
     * Path to the source of the function or the location for dependencies.
     */
    readonly entry: string;
    /**
     * The runtime environment. Only runtimes of the Python family are
     * supported.
     */
    readonly runtime: Runtime;
    /**
     * The path (relative to entry) to the index file containing the exported handler.
     *
     * @default index.py
     */
    readonly index?: string;
    /**
     * The name of the exported handler in the index file.
     *
     * @default handler
     */
    readonly handler?: string;
    /**
     * Bundling options to use for this function. Use this to specify custom bundling options like
     * the bundling Docker image, asset hash type, custom hash, architecture, etc.
     *
     * @default - Use the default bundling Docker image, with x86_64 architecture.
     */
    readonly bundling?: BundlingOptions;
}
/**
 * A Python Lambda function
 */
export declare class PythonFunction extends Function {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    constructor(scope: Construct, id: string, props: PythonFunctionProps);
}
