import * as iam from 'aws-cdk-lib/aws-iam';
import { RemovalPolicy, Resource } from 'aws-cdk-lib/core';
import type { IResource } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
/**
 * Properties for a new Aurora DSQL cluster
 */
export interface ClusterProps {
    /**
     * The name of the DSQL cluster.
     * This is applied via the `Name` tag.
     *
     * @default - No name specified.
     */
    readonly clusterName?: string;
    /**
     * The removal policy to apply when the cluster is removed or
     * replaced during a stack update, or when the stack is deleted.
     *
     * @default - Retain cluster.
     */
    readonly removalPolicy?: RemovalPolicy;
    /**
     * Specifies whether this cluster can be deleted. If deletionProtection is
     * enabled, the cluster cannot be deleted unless it is modified and
     * deletionProtection is disabled. deletionProtection protects clusters from
     * being accidentally deleted.
     *
     * @default - true if `removalPolicy` is RETAIN, undefined otherwise.
     */
    readonly deletionProtection?: boolean;
}
/**
 * Represents an Aurora DSQL cluster
 */
export interface ICluster extends IResource {
    /**
     * Identifier of the cluster
     * @attribute Identifier
     */
    readonly clusterIdentifier: string;
    /**
     * Arn of the cluster
     * @attribute ResourceArn
     */
    readonly clusterArn: string;
    /**
     * Connection endpoint for the cluster.
     * @attribute Endpoint
     */
    readonly clusterEndpoint: string;
    /**
     * VPC endpoint service name for the cluster
     * @attribute VpcEndpointServiceName
     */
    readonly vpcEndpointServiceName: string;
    /**
     * Grant the given identity the specified actions
     * @param grantee the identity to be granted the actions
     * @param actions the data-access actions
     *
     * @see https://docs.aws.amazon.com/aurora-dsql/latest/userguide/authentication-authorization.html
     *
     * [disable-awslint:no-grants]
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grant the given identity permission to connect to the database
     *
     * [disable-awslint:no-grants]
     */
    grantConnect(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant the given identity permission to connect to the database with admin role
     *
     * [disable-awslint:no-grants]
     */
    grantConnectAdmin(grantee: iam.IGrantable): iam.Grant;
}
/**
 * Properties that describe an existing Aurora DSQL cluster
 */
export interface ClusterAttributes {
    /**
     * Identifier of the cluster
     */
    readonly clusterIdentifier: string;
    /**
     * Connection endpoint for the cluster
     */
    readonly clusterEndpoint: string;
    /**
     * VPC endpoint service name for the cluster
     */
    readonly vpcEndpointServiceName: string;
}
/**
 * A new or imported Aurora DSQL cluster
 */
declare abstract class ClusterBase extends Resource implements ICluster {
    /**
     * Identifier of the cluster
     */
    abstract readonly clusterIdentifier: string;
    /**
     * Arn of the cluster
     */
    abstract readonly clusterArn: string;
    /**
     * Connection endpoint for the cluster
     */
    abstract readonly clusterEndpoint: string;
    /**
     * VPC endpoint service name for the cluster
     */
    abstract readonly vpcEndpointServiceName: string;
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    grantConnect(grantee: iam.IGrantable): iam.Grant;
    grantConnectAdmin(grantee: iam.IGrantable): iam.Grant;
}
/**
 * Create an Aurora DSQL cluster
 *
 * @resource AWS::DSQL::Cluster
 */
export declare class Cluster extends ClusterBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing Cluster from attributes
     */
    static fromClusterAttributes(scope: Construct, id: string, attrs: ClusterAttributes): ICluster;
    private readonly cluster;
    /**
     * Identifier of the cluster
     */
    readonly clusterIdentifier: string;
    /**
     * Arn of the cluster
     */
    readonly clusterArn: string;
    /**
     * Connection endpoint for the cluster
     */
    readonly clusterEndpoint: string;
    /**
     * VPC endpoint service name for the cluster
     */
    readonly vpcEndpointServiceName: string;
    constructor(scope: Construct, id: string, props?: ClusterProps);
}
export {};
