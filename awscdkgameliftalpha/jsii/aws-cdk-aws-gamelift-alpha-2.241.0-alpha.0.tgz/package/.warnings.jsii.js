function _aws_cdk_aws_gamelift_alpha_IAlias(p) {
}
function _aws_cdk_aws_gamelift_alpha_AliasOptions(p) {
}
function _aws_cdk_aws_gamelift_alpha_AliasAttributes(p) {
}
function _aws_cdk_aws_gamelift_alpha_AliasProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.fleet))
            _aws_cdk_aws_gamelift_alpha_IFleet(p.fleet);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_AliasBase(p) {
}
function _aws_cdk_aws_gamelift_alpha_Alias(p) {
}
function _aws_cdk_aws_gamelift_alpha_Content(p) {
}
function _aws_cdk_aws_gamelift_alpha_ContentConfig(p) {
}
function _aws_cdk_aws_gamelift_alpha_S3Content(p) {
}
function _aws_cdk_aws_gamelift_alpha_AssetContent(p) {
}
function _aws_cdk_aws_gamelift_alpha_IBuild(p) {
}
function _aws_cdk_aws_gamelift_alpha_BuildBase(p) {
}
function _aws_cdk_aws_gamelift_alpha_OperatingSystem(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        const ns = require("./lib/build.js");
        if (Object.values(ns.OperatingSystem).filter(x => x === p).length > 1)
            return;
        if (p === ns.OperatingSystem.WINDOWS_2012)
            print("@aws-cdk/aws-gamelift-alpha.OperatingSystem#WINDOWS_2012", "If you have active fleets using the Windows Server 2012 operating system,\nyou can continue to create new builds using this OS until October 10, 2023, when Microsoft ends its support.\nAll others must use Windows Server 2016 when creating new Windows-based builds.");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_BuildAttributes(p) {
}
function _aws_cdk_aws_gamelift_alpha_BuildProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.content))
            _aws_cdk_aws_gamelift_alpha_Content(p.content);
        if (!visitedObjects.has(p.operatingSystem))
            _aws_cdk_aws_gamelift_alpha_OperatingSystem(p.operatingSystem);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_Build(p) {
}
function _aws_cdk_aws_gamelift_alpha_IScript(p) {
}
function _aws_cdk_aws_gamelift_alpha_ScriptBase(p) {
}
function _aws_cdk_aws_gamelift_alpha_ScriptAttributes(p) {
}
function _aws_cdk_aws_gamelift_alpha_ScriptProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.content))
            _aws_cdk_aws_gamelift_alpha_Content(p.content);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_Script(p) {
}
function _aws_cdk_aws_gamelift_alpha_AutoScalingPolicy(p) {
}
function _aws_cdk_aws_gamelift_alpha_InstanceDefinition(p) {
}
function _aws_cdk_aws_gamelift_alpha_DeleteOption(p) {
}
function _aws_cdk_aws_gamelift_alpha_BalancingStrategy(p) {
}
function _aws_cdk_aws_gamelift_alpha_IGameServerGroup(p) {
}
function _aws_cdk_aws_gamelift_alpha_GameServerGroupBase(p) {
}
function _aws_cdk_aws_gamelift_alpha_GameServerGroupAttributes(p) {
}
function _aws_cdk_aws_gamelift_alpha_GameServerGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.instanceDefinitions != null)
            for (const o of p.instanceDefinitions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_gamelift_alpha_InstanceDefinition(o);
        if (!visitedObjects.has(p.autoScalingPolicy))
            _aws_cdk_aws_gamelift_alpha_AutoScalingPolicy(p.autoScalingPolicy);
        if (!visitedObjects.has(p.balancingStrategy))
            _aws_cdk_aws_gamelift_alpha_BalancingStrategy(p.balancingStrategy);
        if (!visitedObjects.has(p.deleteOption))
            _aws_cdk_aws_gamelift_alpha_DeleteOption(p.deleteOption);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_GameServerGroup(p) {
}
function _aws_cdk_aws_gamelift_alpha_Protocol(p) {
}
function _aws_cdk_aws_gamelift_alpha_PortProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.protocol))
            _aws_cdk_aws_gamelift_alpha_Protocol(p.protocol);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_Port(p) {
}
function _aws_cdk_aws_gamelift_alpha_IPeer(p) {
}
function _aws_cdk_aws_gamelift_alpha_Peer(p) {
}
function _aws_cdk_aws_gamelift_alpha_IngressRule(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.port))
            _aws_cdk_aws_gamelift_alpha_Port(p.port);
        if (!visitedObjects.has(p.source))
            _aws_cdk_aws_gamelift_alpha_IPeer(p.source);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_LocationCapacity(p) {
}
function _aws_cdk_aws_gamelift_alpha_Location(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.capacity))
            _aws_cdk_aws_gamelift_alpha_LocationCapacity(p.capacity);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_ServerProcess(p) {
}
function _aws_cdk_aws_gamelift_alpha_RuntimeConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.serverProcesses != null)
            for (const o of p.serverProcesses)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_gamelift_alpha_ServerProcess(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_ResourceCreationLimitPolicy(p) {
}
function _aws_cdk_aws_gamelift_alpha_IFleet(p) {
}
function _aws_cdk_aws_gamelift_alpha_FleetProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.runtimeConfiguration))
            _aws_cdk_aws_gamelift_alpha_RuntimeConfiguration(p.runtimeConfiguration);
        if (p.locations != null)
            for (const o of p.locations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_gamelift_alpha_Location(o);
        if (!visitedObjects.has(p.resourceCreationLimitPolicy))
            _aws_cdk_aws_gamelift_alpha_ResourceCreationLimitPolicy(p.resourceCreationLimitPolicy);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_FleetAttributes(p) {
}
function _aws_cdk_aws_gamelift_alpha_FleetBase(p) {
}
function _aws_cdk_aws_gamelift_alpha_IBuildFleet(p) {
}
function _aws_cdk_aws_gamelift_alpha_BuildFleetProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.content))
            _aws_cdk_aws_gamelift_alpha_IBuild(p.content);
        if (p.ingressRules != null)
            for (const o of p.ingressRules)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_gamelift_alpha_IngressRule(o);
        if (!visitedObjects.has(p.runtimeConfiguration))
            _aws_cdk_aws_gamelift_alpha_RuntimeConfiguration(p.runtimeConfiguration);
        if (p.locations != null)
            for (const o of p.locations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_gamelift_alpha_Location(o);
        if (!visitedObjects.has(p.resourceCreationLimitPolicy))
            _aws_cdk_aws_gamelift_alpha_ResourceCreationLimitPolicy(p.resourceCreationLimitPolicy);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_BuildFleet(p) {
}
function _aws_cdk_aws_gamelift_alpha_GameProperty(p) {
}
function _aws_cdk_aws_gamelift_alpha_IMatchmakingConfiguration(p) {
}
function _aws_cdk_aws_gamelift_alpha_MatchmakingConfigurationAttributes(p) {
}
function _aws_cdk_aws_gamelift_alpha_MatchmakingConfigurationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.ruleSet))
            _aws_cdk_aws_gamelift_alpha_IMatchmakingRuleSet(p.ruleSet);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_MatchmakingConfigurationBase(p) {
}
function _aws_cdk_aws_gamelift_alpha_QueuedMatchmakingConfigurationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.gameSessionQueues != null)
            for (const o of p.gameSessionQueues)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_gamelift_alpha_IGameSessionQueue(o);
        if (p.gameProperties != null)
            for (const o of p.gameProperties)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_gamelift_alpha_GameProperty(o);
        if (!visitedObjects.has(p.ruleSet))
            _aws_cdk_aws_gamelift_alpha_IMatchmakingRuleSet(p.ruleSet);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_QueuedMatchmakingConfiguration(p) {
}
function _aws_cdk_aws_gamelift_alpha_StandaloneMatchmakingConfigurationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.ruleSet))
            _aws_cdk_aws_gamelift_alpha_IMatchmakingRuleSet(p.ruleSet);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_StandaloneMatchmakingConfiguration(p) {
}
function _aws_cdk_aws_gamelift_alpha_IGameSessionQueueDestination(p) {
}
function _aws_cdk_aws_gamelift_alpha_PriorityType(p) {
}
function _aws_cdk_aws_gamelift_alpha_PriorityConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.priorityOrder != null)
            for (const o of p.priorityOrder)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_gamelift_alpha_PriorityType(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_PlayerLatencyPolicy(p) {
}
function _aws_cdk_aws_gamelift_alpha_IGameSessionQueue(p) {
}
function _aws_cdk_aws_gamelift_alpha_GameSessionQueueAttributes(p) {
}
function _aws_cdk_aws_gamelift_alpha_GameSessionQueueProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.destinations != null)
            for (const o of p.destinations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_gamelift_alpha_IGameSessionQueueDestination(o);
        if (p.playerLatencyPolicies != null)
            for (const o of p.playerLatencyPolicies)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_gamelift_alpha_PlayerLatencyPolicy(o);
        if (!visitedObjects.has(p.priorityConfiguration))
            _aws_cdk_aws_gamelift_alpha_PriorityConfiguration(p.priorityConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_GameSessionQueueBase(p) {
}
function _aws_cdk_aws_gamelift_alpha_GameSessionQueue(p) {
}
function _aws_cdk_aws_gamelift_alpha_IMatchmakingRuleSet(p) {
}
function _aws_cdk_aws_gamelift_alpha_MatchmakingRuleSetProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.content))
            _aws_cdk_aws_gamelift_alpha_RuleSetContent(p.content);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_MatchmakingRuleSetAttributes(p) {
}
function _aws_cdk_aws_gamelift_alpha_MatchmakingRuleSetBase(p) {
}
function _aws_cdk_aws_gamelift_alpha_MatchmakingRuleSet(p) {
}
function _aws_cdk_aws_gamelift_alpha_IRuleSetBody(p) {
}
function _aws_cdk_aws_gamelift_alpha_RuleSetBodyConfig(p) {
}
function _aws_cdk_aws_gamelift_alpha_IRuleSetContent(p) {
}
function _aws_cdk_aws_gamelift_alpha_RuleSetContentProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.content))
            _aws_cdk_aws_gamelift_alpha_IRuleSetBody(p.content);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_gamelift_alpha_RuleSetContent(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_gamelift_alpha_IAlias, _aws_cdk_aws_gamelift_alpha_AliasOptions, _aws_cdk_aws_gamelift_alpha_AliasAttributes, _aws_cdk_aws_gamelift_alpha_AliasProps, _aws_cdk_aws_gamelift_alpha_AliasBase, _aws_cdk_aws_gamelift_alpha_Alias, _aws_cdk_aws_gamelift_alpha_Content, _aws_cdk_aws_gamelift_alpha_ContentConfig, _aws_cdk_aws_gamelift_alpha_S3Content, _aws_cdk_aws_gamelift_alpha_AssetContent, _aws_cdk_aws_gamelift_alpha_IBuild, _aws_cdk_aws_gamelift_alpha_BuildBase, _aws_cdk_aws_gamelift_alpha_OperatingSystem, _aws_cdk_aws_gamelift_alpha_BuildAttributes, _aws_cdk_aws_gamelift_alpha_BuildProps, _aws_cdk_aws_gamelift_alpha_Build, _aws_cdk_aws_gamelift_alpha_IScript, _aws_cdk_aws_gamelift_alpha_ScriptBase, _aws_cdk_aws_gamelift_alpha_ScriptAttributes, _aws_cdk_aws_gamelift_alpha_ScriptProps, _aws_cdk_aws_gamelift_alpha_Script, _aws_cdk_aws_gamelift_alpha_AutoScalingPolicy, _aws_cdk_aws_gamelift_alpha_InstanceDefinition, _aws_cdk_aws_gamelift_alpha_DeleteOption, _aws_cdk_aws_gamelift_alpha_BalancingStrategy, _aws_cdk_aws_gamelift_alpha_IGameServerGroup, _aws_cdk_aws_gamelift_alpha_GameServerGroupBase, _aws_cdk_aws_gamelift_alpha_GameServerGroupAttributes, _aws_cdk_aws_gamelift_alpha_GameServerGroupProps, _aws_cdk_aws_gamelift_alpha_GameServerGroup, _aws_cdk_aws_gamelift_alpha_Protocol, _aws_cdk_aws_gamelift_alpha_PortProps, _aws_cdk_aws_gamelift_alpha_Port, _aws_cdk_aws_gamelift_alpha_IPeer, _aws_cdk_aws_gamelift_alpha_Peer, _aws_cdk_aws_gamelift_alpha_IngressRule, _aws_cdk_aws_gamelift_alpha_LocationCapacity, _aws_cdk_aws_gamelift_alpha_Location, _aws_cdk_aws_gamelift_alpha_ServerProcess, _aws_cdk_aws_gamelift_alpha_RuntimeConfiguration, _aws_cdk_aws_gamelift_alpha_ResourceCreationLimitPolicy, _aws_cdk_aws_gamelift_alpha_IFleet, _aws_cdk_aws_gamelift_alpha_FleetProps, _aws_cdk_aws_gamelift_alpha_FleetAttributes, _aws_cdk_aws_gamelift_alpha_FleetBase, _aws_cdk_aws_gamelift_alpha_IBuildFleet, _aws_cdk_aws_gamelift_alpha_BuildFleetProps, _aws_cdk_aws_gamelift_alpha_BuildFleet, _aws_cdk_aws_gamelift_alpha_GameProperty, _aws_cdk_aws_gamelift_alpha_IMatchmakingConfiguration, _aws_cdk_aws_gamelift_alpha_MatchmakingConfigurationAttributes, _aws_cdk_aws_gamelift_alpha_MatchmakingConfigurationProps, _aws_cdk_aws_gamelift_alpha_MatchmakingConfigurationBase, _aws_cdk_aws_gamelift_alpha_QueuedMatchmakingConfigurationProps, _aws_cdk_aws_gamelift_alpha_QueuedMatchmakingConfiguration, _aws_cdk_aws_gamelift_alpha_StandaloneMatchmakingConfigurationProps, _aws_cdk_aws_gamelift_alpha_StandaloneMatchmakingConfiguration, _aws_cdk_aws_gamelift_alpha_IGameSessionQueueDestination, _aws_cdk_aws_gamelift_alpha_PriorityType, _aws_cdk_aws_gamelift_alpha_PriorityConfiguration, _aws_cdk_aws_gamelift_alpha_PlayerLatencyPolicy, _aws_cdk_aws_gamelift_alpha_IGameSessionQueue, _aws_cdk_aws_gamelift_alpha_GameSessionQueueAttributes, _aws_cdk_aws_gamelift_alpha_GameSessionQueueProps, _aws_cdk_aws_gamelift_alpha_GameSessionQueueBase, _aws_cdk_aws_gamelift_alpha_GameSessionQueue, _aws_cdk_aws_gamelift_alpha_IMatchmakingRuleSet, _aws_cdk_aws_gamelift_alpha_MatchmakingRuleSetProps, _aws_cdk_aws_gamelift_alpha_MatchmakingRuleSetAttributes, _aws_cdk_aws_gamelift_alpha_MatchmakingRuleSetBase, _aws_cdk_aws_gamelift_alpha_MatchmakingRuleSet, _aws_cdk_aws_gamelift_alpha_IRuleSetBody, _aws_cdk_aws_gamelift_alpha_RuleSetBodyConfig, _aws_cdk_aws_gamelift_alpha_IRuleSetContent, _aws_cdk_aws_gamelift_alpha_RuleSetContentProps, _aws_cdk_aws_gamelift_alpha_RuleSetContent };
