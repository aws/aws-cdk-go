const VALIDATORS = { _aws_cdk_aws_gamelift_alpha_ContentConfig: function _aws_cdk_aws_gamelift_alpha_ContentConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.s3Location))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_s3_Location(p.s3Location);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_OperatingSystem: function _aws_cdk_aws_gamelift_alpha_OperatingSystem(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p === "WINDOWS_2012")
                print("@aws-cdk/aws-gamelift-alpha.OperatingSystem#WINDOWS_2012", "If you have active fleets using the Windows Server 2012 operating system,\nyou can continue to create new builds using this OS until October 10, 2023, when Microsoft ends its support.\nAll others must use Windows Server 2016 when creating new Windows-based builds.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_BuildAttributes: function _aws_cdk_aws_gamelift_alpha_BuildAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_BuildProps: function _aws_cdk_aws_gamelift_alpha_BuildProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.operatingSystem))
                module.exports._aws_cdk_aws_gamelift_alpha_OperatingSystem(p.operatingSystem);
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_ScriptAttributes: function _aws_cdk_aws_gamelift_alpha_ScriptAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_ScriptProps: function _aws_cdk_aws_gamelift_alpha_ScriptProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_AutoScalingPolicy: function _aws_cdk_aws_gamelift_alpha_AutoScalingPolicy(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.estimatedInstanceWarmup))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.estimatedInstanceWarmup);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_InstanceDefinition: function _aws_cdk_aws_gamelift_alpha_InstanceDefinition(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.instanceType))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_InstanceType(p.instanceType);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_GameServerGroupAttributes: function _aws_cdk_aws_gamelift_alpha_GameServerGroupAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_GameServerGroupProps: function _aws_cdk_aws_gamelift_alpha_GameServerGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.instanceDefinitions != null)
                for (const o of p.instanceDefinitions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_InstanceDefinition(o);
            if (!visitedObjects.has(p.launchTemplate))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ILaunchTemplate(p.launchTemplate);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.vpc))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_IVpc(p.vpc);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.autoScalingPolicy))
                module.exports._aws_cdk_aws_gamelift_alpha_AutoScalingPolicy(p.autoScalingPolicy);
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.vpcSubnets))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(p.vpcSubnets);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_RuntimeConfiguration: function _aws_cdk_aws_gamelift_alpha_RuntimeConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.serverProcesses != null)
                for (const o of p.serverProcesses)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_ServerProcess(o);
            if (!visitedObjects.has(p.gameSessionActivationTimeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.gameSessionActivationTimeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_ResourceCreationLimitPolicy: function _aws_cdk_aws_gamelift_alpha_ResourceCreationLimitPolicy(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.policyPeriod))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.policyPeriod);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_FleetProps: function _aws_cdk_aws_gamelift_alpha_FleetProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.instanceType))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_InstanceType(p.instanceType);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.runtimeConfiguration))
                module.exports._aws_cdk_aws_gamelift_alpha_RuntimeConfiguration(p.runtimeConfiguration);
            if (p.locations != null)
                for (const o of p.locations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_Location(o);
            if (!visitedObjects.has(p.peerVpc))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_IVpc(p.peerVpc);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.resourceCreationLimitPolicy))
                module.exports._aws_cdk_aws_gamelift_alpha_ResourceCreationLimitPolicy(p.resourceCreationLimitPolicy);
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_FleetAttributes: function _aws_cdk_aws_gamelift_alpha_FleetAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_BuildFleetProps: function _aws_cdk_aws_gamelift_alpha_BuildFleetProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.ingressRules != null)
                for (const o of p.ingressRules)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_IngressRule(o);
            if (!visitedObjects.has(p.instanceType))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_InstanceType(p.instanceType);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.runtimeConfiguration))
                module.exports._aws_cdk_aws_gamelift_alpha_RuntimeConfiguration(p.runtimeConfiguration);
            if (p.locations != null)
                for (const o of p.locations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_Location(o);
            if (!visitedObjects.has(p.peerVpc))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_IVpc(p.peerVpc);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.resourceCreationLimitPolicy))
                module.exports._aws_cdk_aws_gamelift_alpha_ResourceCreationLimitPolicy(p.resourceCreationLimitPolicy);
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_MatchmakingConfigurationAttributes: function _aws_cdk_aws_gamelift_alpha_MatchmakingConfigurationAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.notificationTarget))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_sns_ITopic(p.notificationTarget);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_MatchmakingConfigurationProps: function _aws_cdk_aws_gamelift_alpha_MatchmakingConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.acceptanceTimeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.acceptanceTimeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.notificationTarget))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_sns_ITopic(p.notificationTarget);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.requestTimeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.requestTimeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_QueuedMatchmakingConfigurationProps: function _aws_cdk_aws_gamelift_alpha_QueuedMatchmakingConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.gameSessionQueues != null)
                for (const o of p.gameSessionQueues)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_IGameSessionQueue(o);
            if (p.gameProperties != null)
                for (const o of p.gameProperties)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_GameProperty(o);
            if (!visitedObjects.has(p.acceptanceTimeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.acceptanceTimeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.notificationTarget))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_sns_ITopic(p.notificationTarget);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.requestTimeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.requestTimeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_StandaloneMatchmakingConfigurationProps: function _aws_cdk_aws_gamelift_alpha_StandaloneMatchmakingConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.acceptanceTimeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.acceptanceTimeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.notificationTarget))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_sns_ITopic(p.notificationTarget);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.requestTimeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.requestTimeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_PlayerLatencyPolicy: function _aws_cdk_aws_gamelift_alpha_PlayerLatencyPolicy(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.maximumIndividualPlayerLatency))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.maximumIndividualPlayerLatency);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.policyDuration))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.policyDuration);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_GameSessionQueueProps: function _aws_cdk_aws_gamelift_alpha_GameSessionQueueProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_IGameSessionQueueDestination(o);
            if (!visitedObjects.has(p.notificationTarget))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_sns_ITopic(p.notificationTarget);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.playerLatencyPolicies != null)
                for (const o of p.playerLatencyPolicies)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_PlayerLatencyPolicy(o);
            if (!visitedObjects.has(p.timeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.timeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
