const VALIDATORS = { _aws_cdk_aws_gamelift_alpha_OperatingSystem: function _aws_cdk_aws_gamelift_alpha_OperatingSystem(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p === "WINDOWS_2012")
                print("@aws-cdk/aws-gamelift-alpha.OperatingSystem#WINDOWS_2012", "If you have active fleets using the Windows Server 2012 operating system,\nyou can continue to create new builds using this OS until October 10, 2023, when Microsoft ends its support.\nAll others must use Windows Server 2016 when creating new Windows-based builds.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_BuildProps: function _aws_cdk_aws_gamelift_alpha_BuildProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.operatingSystem))
                module.exports._aws_cdk_aws_gamelift_alpha_OperatingSystem(p.operatingSystem);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_GameServerGroupProps: function _aws_cdk_aws_gamelift_alpha_GameServerGroupProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.instanceDefinitions != null)
                for (const o of p.instanceDefinitions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_InstanceDefinition(o);
            if (!visitedObjects.has(p.autoScalingPolicy))
                module.exports._aws_cdk_aws_gamelift_alpha_AutoScalingPolicy(p.autoScalingPolicy);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_RuntimeConfiguration: function _aws_cdk_aws_gamelift_alpha_RuntimeConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.serverProcesses != null)
                for (const o of p.serverProcesses)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_ServerProcess(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_FleetProps: function _aws_cdk_aws_gamelift_alpha_FleetProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.runtimeConfiguration))
                module.exports._aws_cdk_aws_gamelift_alpha_RuntimeConfiguration(p.runtimeConfiguration);
            if (p.locations != null)
                for (const o of p.locations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_Location(o);
            if (!visitedObjects.has(p.resourceCreationLimitPolicy))
                module.exports._aws_cdk_aws_gamelift_alpha_ResourceCreationLimitPolicy(p.resourceCreationLimitPolicy);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_BuildFleetProps: function _aws_cdk_aws_gamelift_alpha_BuildFleetProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.ingressRules != null)
                for (const o of p.ingressRules)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_IngressRule(o);
            if (!visitedObjects.has(p.runtimeConfiguration))
                module.exports._aws_cdk_aws_gamelift_alpha_RuntimeConfiguration(p.runtimeConfiguration);
            if (p.locations != null)
                for (const o of p.locations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_Location(o);
            if (!visitedObjects.has(p.resourceCreationLimitPolicy))
                module.exports._aws_cdk_aws_gamelift_alpha_ResourceCreationLimitPolicy(p.resourceCreationLimitPolicy);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_QueuedMatchmakingConfigurationProps: function _aws_cdk_aws_gamelift_alpha_QueuedMatchmakingConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.gameSessionQueues != null)
                for (const o of p.gameSessionQueues)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_IGameSessionQueue(o);
            if (p.gameProperties != null)
                for (const o of p.gameProperties)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_GameProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_gamelift_alpha_GameSessionQueueProps: function _aws_cdk_aws_gamelift_alpha_GameSessionQueueProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.destinations != null)
                for (const o of p.destinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_IGameSessionQueueDestination(o);
            if (p.playerLatencyPolicies != null)
                for (const o of p.playerLatencyPolicies)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_gamelift_alpha_PlayerLatencyPolicy(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
