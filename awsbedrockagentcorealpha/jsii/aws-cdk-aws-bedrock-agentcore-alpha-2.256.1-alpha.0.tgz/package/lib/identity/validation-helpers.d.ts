/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import type { IConstruct } from 'constructs';
import { throwIfInvalid } from '../memory/validation-helpers';
/** @internal */
export declare const CREDENTIAL_PROVIDER_NAME_MIN = 1;
/** @internal */
export declare const CREDENTIAL_PROVIDER_NAME_MAX = 128;
/** @internal */
export declare const CREDENTIAL_PROVIDER_NAME_PATTERN: RegExp;
/** @internal */
export declare const API_KEY_VALUE_MIN = 1;
/** @internal */
export declare const API_KEY_VALUE_MAX = 65536;
/** @internal */
export declare const CREDENTIAL_PROVIDER_TAG_MIN = 1;
/** @internal */
export declare const CREDENTIAL_PROVIDER_TAG_MAX = 256;
/** @internal */
export declare const WORKLOAD_IDENTITY_NAME_MIN = 3;
/** @internal */
export declare const WORKLOAD_IDENTITY_NAME_MAX = 255;
/** @internal */
export declare const WORKLOAD_IDENTITY_NAME_PATTERN: RegExp;
/** @internal */
export declare const ALLOWED_OAUTH2_RETURN_URL_MIN = 1;
/** @internal */
export declare const ALLOWED_OAUTH2_RETURN_URL_MAX = 2048;
/**
 * @internal
 */
export declare function validateWorkloadIdentityName(name: string, scope?: IConstruct): string[];
/**
 * @internal
 */
export declare function validateAllowedResourceOauth2ReturnUrls(urls: string[] | undefined, scope?: IConstruct): string[];
/**
 * @internal
 */
export declare function validateCredentialProviderName(name: string, scope?: IConstruct): string[];
/**
 * @internal
 */
export declare function validateApiKeyValue(apiKey: string | undefined, scope?: IConstruct): string[];
/**
 * @internal
 */
export declare function validateCredentialProviderTags(tags?: {
    [key: string]: string;
}, scope?: IConstruct): string[];
export { throwIfInvalid };
