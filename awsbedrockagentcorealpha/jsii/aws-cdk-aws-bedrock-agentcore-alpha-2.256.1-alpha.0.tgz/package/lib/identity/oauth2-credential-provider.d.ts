/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import type { IResource, ResourceProps, SecretValue } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { IOAuth2CredentialProviderRef, OAuth2CredentialProviderReference } from 'aws-cdk-lib/aws-bedrockagentcore';
import { CfnOAuth2CredentialProvider } from 'aws-cdk-lib/aws-bedrockagentcore';
import * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
/******************************************************************************
 *                                 Enums
 *****************************************************************************/
/**
 * Built-in OAuth2 vendors supported by `AWS::BedrockAgentCore::OAuth2CredentialProvider`.
 *
 * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-oauth2credentialprovider.html
 */
export declare enum OAuth2CredentialProviderVendor {
    /** Google OAuth2. */
    GOOGLE = "GoogleOauth2",
    /** GitHub OAuth2. */
    GITHUB = "GithubOauth2",
    /** Slack OAuth2. */
    SLACK = "SlackOauth2",
    /** Salesforce OAuth2. */
    SALESFORCE = "SalesforceOauth2",
    /** Microsoft OAuth2. */
    MICROSOFT = "MicrosoftOauth2",
    /** Custom OAuth2. */
    CUSTOM = "CustomOauth2",
    /** Atlassian OAuth2. */
    ATLASSIAN = "AtlassianOauth2",
    /** LinkedIn OAuth2. */
    LINKEDIN = "LinkedinOauth2",
    /** X (Twitter) OAuth2. */
    X = "XOauth2",
    /** Okta OAuth2. */
    OKTA = "OktaOauth2",
    /** OneLogin OAuth2. */
    ONE_LOGIN = "OneLoginOauth2",
    /** PingOne OAuth2. */
    PING_ONE = "PingOneOauth2",
    /** Facebook OAuth2. */
    FACEBOOK = "FacebookOauth2",
    /** Yandex OAuth2. */
    YANDEX = "YandexOauth2",
    /** Reddit OAuth2. */
    REDDIT = "RedditOauth2",
    /** Zoom OAuth2. */
    ZOOM = "ZoomOauth2",
    /** Twitch OAuth2. */
    TWITCH = "TwitchOauth2",
    /** Spotify OAuth2. */
    SPOTIFY = "SpotifyOauth2",
    /** Dropbox OAuth2. */
    DROPBOX = "DropboxOauth2",
    /** Notion OAuth2. */
    NOTION = "NotionOauth2",
    /** HubSpot OAuth2. */
    HUBSPOT = "HubspotOauth2",
    /** CyberArk OAuth2. */
    CYBER_ARK = "CyberArkOauth2",
    /** FusionAuth OAuth2. */
    FUSION_AUTH = "FusionAuthOauth2",
    /** Auth0 OAuth2. */
    AUTH0 = "Auth0Oauth2",
    /** Amazon Cognito OAuth2. */
    COGNITO = "CognitoOauth2"
}
/******************************************************************************
 *                                Interface
 *****************************************************************************/
/**
 * An OAuth2 credential provider registered in AgentCore Token Vault.
 */
export interface IOAuth2CredentialProvider extends IResource, iam.IGrantable, IOAuth2CredentialProviderRef {
    /**
     * The ARN of this credential provider.
     * @attribute
     */
    readonly credentialProviderArn: string;
    /**
     * OAuth2 vendor string passed to CloudFormation.
     */
    readonly credentialProviderVendor: string;
    /**
     * Callback URL for the OAuth2 authorization flow.
     * @attribute
     */
    readonly callbackUrl?: string;
    /**
     * The ARN of the Secrets Manager secret for the OAuth2 client credentials.
     *
     * May be undefined for resources imported without this attribute.
     *
     * @attribute
     */
    readonly clientSecretArn?: string;
    /**
     * Timestamp when the credential provider was created.
     * @attribute
     */
    readonly createdTime?: string;
    /**
     * Timestamp when the credential provider was last updated.
     * @attribute
     */
    readonly lastUpdatedTime?: string;
    /**
     * Grants IAM actions to the IAM principal.
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grant `GetOauth2CredentialProvider` and `ListOauth2CredentialProviders`, scoped to this
     * provider and parent resources required by the Bedrock AgentCore authorization model.
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant control plane permissions to manage this provider.
     */
    grantAdmin(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant permission to retrieve OAuth tokens (`GetResourceOauth2Token`, `CompleteResourceTokenAuth`).
     */
    grantUse(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant read, admin, and token retrieval permissions.
     */
    grantFullAccess(grantee: iam.IGrantable): iam.Grant;
    /**
     * ARNs and OAuth scopes for gateway targets (`GatewayCredentialProvider.fromOauthIdentity` or `fromOauthIdentityArn`).
     */
    bindForGatewayOAuthTarget(scopes: string[], customParameters?: {
        [key: string]: string;
    }): GatewayOAuth2IdentityBinding;
}
/**
 * Provider ARN, secret ARN, and OAuth scopes for wiring a Token Vault OAuth2 identity into a gateway target.
 */
export interface GatewayOAuth2IdentityBinding {
    /**
     * OAuth2 credential provider ARN.
     */
    readonly providerArn: string;
    /**
     * Secrets Manager secret ARN for OAuth2 client credentials.
     */
    readonly secretArn: string;
    /**
     * OAuth scopes to request when invoking through the gateway.
     */
    readonly scopes: string[];
    /**
     * Optional custom parameters for the OAuth flow.
     *
     * @default - no custom parameters
     */
    readonly customParameters?: {
        [key: string]: string;
    };
}
/**
 * Shared properties for OAuth2 credential providers created via {@link OAuth2CredentialProvider} factory methods.
 */
export interface OAuth2CredentialProviderBaseProps {
    /**
     * Name of the credential provider.
     *
     * @default a name generated by CDK
     */
    readonly oAuth2CredentialProviderName?: string;
    /**
     * Tags for this credential provider.
     *
     * @default - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * OAuth2 client identifier and secret registered with the identity provider (all vendors).
 */
export interface OAuth2ClientCredentials {
    /** OAuth2 client identifier. */
    readonly clientId: string;
    /**
     * OAuth2 client secret.
     *
     * **NOTE:** The client secret will be included in the CloudFormation template as part of synthesis.
     * The service stores the secret in Secrets Manager after creation, but the value is visible
     * in the template and deployment history. Use `SecretValue.unsafePlainText()` to explicitly
     * acknowledge plaintext, or pass a reference from another construct to avoid embedding the
     * literal value.
     */
    readonly clientSecret: SecretValue;
}
/**
 * Naming, tags, and client credentials shared by every {@link OAuth2CredentialProvider} factory.
 */
export interface OAuth2CredentialProviderFactoryBaseProps extends OAuth2CredentialProviderBaseProps, OAuth2ClientCredentials {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingSlack}.
 */
export interface SlackOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingGithub}.
 */
export interface GithubOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingGoogle}.
 */
export interface GoogleOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingSalesforce}.
 */
export interface SalesforceOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingMicrosoft}.
 */
export interface MicrosoftOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
    /**
     * Microsoft Entra ID tenant ID.
     *
     * @default - service default tenant resolution
     */
    readonly tenantId?: string;
}
/**
 * Props for {@link OAuth2CredentialProvider.usingAtlassian}.
 */
export interface AtlassianOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingLinkedin}.
 */
export interface LinkedinOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingFacebook}.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-facebook.html
 */
export interface FacebookOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingX}.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-x.html
 */
export interface XOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingYandex}.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-yandex.html
 */
export interface YandexOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingReddit}.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-reddit.html
 */
export interface RedditOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingZoom}.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-zoom.html
 */
export interface ZoomOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingTwitch}.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-twitch.html
 */
export interface TwitchOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingSpotify}.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-spotify.html
 */
export interface SpotifyOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingDropbox}.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-dropbox.html
 */
export interface DropboxOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingNotion}.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-notion.html
 */
export interface NotionOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Props for {@link OAuth2CredentialProvider.usingHubspot}.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-hubspot.html
 */
export interface HubspotOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
}
/**
 * Optional tenant OAuth endpoints for IdPs that use CloudFormation `IncludedOauth2ProviderConfig`
 * with issuer and/or endpoints per the IdP’s outbound documentation.
 */
export interface IncludedOauth2TenantEndpoints {
    /**
     * OAuth2 authorization endpoint for your tenant.
     *
     * @default - not specified; use when your IdP requires an explicit endpoint
     */
    readonly authorizationEndpoint?: string;
    /**
     * Token issuer URL for your tenant (often the IdP base or issuer URI).
     *
     * @default - not specified; use when your IdP requires an explicit issuer
     */
    readonly issuer?: string;
    /**
     * OAuth2 token endpoint for your tenant.
     *
     * @default - not specified; use when your IdP requires an explicit endpoint
     */
    readonly tokenEndpoint?: string;
}
/**
 * Props for `IncludedOauth2ProviderConfig` IdPs whose [outbound documentation](https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idps.html)
 * requires `issuer`, `authorizationEndpoint`, and/or `tokenEndpoint` (for example Okta, Auth0, Amazon Cognito, OneLogin,
 * PingOne, CyberArk, FusionAuth).
 */
export interface IncludedOauth2TenantCredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps, IncludedOauth2TenantEndpoints {
}
/**
 * Static OAuth2 authorization server metadata for custom credential providers.
 *
 * @see https://www.rfc-editor.org/rfc/rfc8414
 */
export interface OAuth2AuthorizationServerMetadata {
    /**
     * The authorization endpoint URL.
     */
    readonly authorizationEndpoint: string;
    /**
     * The issuer URL for the OAuth2 authorization server.
     */
    readonly issuer: string;
    /**
     * The token endpoint URL.
     */
    readonly tokenEndpoint: string;
    /**
     * The supported response types.
     *
     * @default - not specified
     */
    readonly responseTypes?: string[];
}
/**
 * Props for {@link OAuth2CredentialProvider.usingCustom}.
 *
 * Set exactly one of {@link discoveryUrl} (OIDC discovery document) or {@link authorizationServerMetadata}
 * (static OAuth2 server metadata). Do not pass both.
 */
export interface CustomOAuth2CredentialProviderProps extends OAuth2CredentialProviderFactoryBaseProps {
    /**
     * OIDC/OAuth2 discovery document URL for dynamic integration with the identity provider.
     *
     * @default - not used when {@link authorizationServerMetadata} is set
     */
    readonly discoveryUrl?: string;
    /**
     * Authorization server metadata (issuer, authorization and token endpoints) when not using a discovery URL.
     *
     * @default - not used when {@link discoveryUrl} is set
     */
    readonly authorizationServerMetadata?: OAuth2AuthorizationServerMetadata;
}
/**
 * Low-level properties when you need full control (prefer {@link OAuth2CredentialProvider.usingSlack} and other factories).
 */
export interface OAuth2CredentialProviderProps {
    /**
     * Name of the credential provider.
     *
     * @default a name generated by CDK
     */
    readonly oAuth2CredentialProviderName?: string;
    /**
     * OAuth2 vendor string for CloudFormation `CredentialProviderVendor`.
     */
    readonly credentialProviderVendor: string;
    /**
     * OAuth2 provider configuration passed through to `Oauth2ProviderConfigInput`.
     */
    readonly oauth2ProviderConfigInput: CfnOAuth2CredentialProvider.Oauth2ProviderConfigInputProperty;
    /**
     * Tags for this credential provider.
     *
     * @default - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Attributes for importing an existing OAuth2 credential provider.
 */
export interface OAuth2CredentialProviderAttributes {
    /**
     * ARN of the credential provider.
     */
    readonly credentialProviderArn: string;
    /**
     * Vendor string for this provider.
     */
    readonly credentialProviderVendor: string;
    /**
     * ARN of the Secrets Manager secret for OAuth2 client credentials, if known.
     *
     * @default - not set; required for {@link OAuth2CredentialProvider.bindForGatewayOAuthTarget} on imported providers
     */
    readonly clientSecretArn?: string;
    /**
     * Callback URL from the deployed provider, if known.
     *
     * @default - not set
     */
    readonly callbackUrl?: string;
    /**
     * Resource creation time.
     *
     * @default - not set
     */
    readonly createdTime?: string;
    /**
     * Resource last-updated time.
     *
     * @default - not set
     */
    readonly lastUpdatedTime?: string;
}
/******************************************************************************
 *                         Abstract base
 *****************************************************************************/
declare abstract class OAuth2CredentialProviderBase extends Resource implements IOAuth2CredentialProvider {
    abstract readonly credentialProviderArn: string;
    abstract readonly credentialProviderVendor: string;
    abstract readonly callbackUrl?: string;
    abstract readonly clientSecretArn?: string;
    abstract readonly createdTime?: string;
    abstract readonly lastUpdatedTime?: string;
    readonly grantPrincipal: iam.IPrincipal;
    get oAuth2CredentialProviderRef(): OAuth2CredentialProviderReference;
    constructor(scope: Construct, id: string, props?: ResourceProps);
    /**
     * [disable-awslint:no-grants]
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * [disable-awslint:no-grants]
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * [disable-awslint:no-grants]
     */
    grantAdmin(grantee: iam.IGrantable): iam.Grant;
    /**
     * [disable-awslint:no-grants]
     */
    grantUse(grantee: iam.IGrantable): iam.Grant;
    /**
     * [disable-awslint:no-grants]
     */
    grantFullAccess(grantee: iam.IGrantable): iam.Grant;
    abstract bindForGatewayOAuthTarget(scopes: string[], customParameters?: {
        [key: string]: string;
    }): GatewayOAuth2IdentityBinding;
}
/******************************************************************************
 *                                Class
 *****************************************************************************/
/**
 * L2 construct for `AWS::BedrockAgentCore::OAuth2CredentialProvider`.
 *
 * Prefer the static factories (for example {@link OAuth2CredentialProvider.usingSlack}) so you only pass
 * the OAuth2 settings that apply to that vendor. To attach the identity to a gateway target, use
 * {@link GatewayCredentialProvider.fromOauthIdentity} with this construct, or
 * {@link OAuth2CredentialProvider.bindForGatewayOAuthTarget} with {@link GatewayCredentialProvider.fromOauthIdentityArn}.
 *
 * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-oauth2credentialprovider.html
 * @resource AWS::BedrockAgentCore::OAuth2CredentialProvider
 */
export declare class OAuth2CredentialProvider extends OAuth2CredentialProviderBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Create a credential provider for Slack OAuth2.
     */
    static usingSlack(scope: Construct, id: string, props: SlackOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for GitHub OAuth2.
     */
    static usingGithub(scope: Construct, id: string, props: GithubOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Google OAuth2.
     */
    static usingGoogle(scope: Construct, id: string, props: GoogleOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Salesforce OAuth2.
     */
    static usingSalesforce(scope: Construct, id: string, props: SalesforceOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Microsoft (Entra ID) OAuth2.
     */
    static usingMicrosoft(scope: Construct, id: string, props: MicrosoftOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Atlassian OAuth2.
     */
    static usingAtlassian(scope: Construct, id: string, props: AtlassianOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for LinkedIn OAuth2.
     */
    static usingLinkedin(scope: Construct, id: string, props: LinkedinOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Okta OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-okta.html
     */
    static usingOkta(scope: Construct, id: string, props: IncludedOauth2TenantCredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for OneLogin OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-onelogin.html
     */
    static usingOneLogin(scope: Construct, id: string, props: IncludedOauth2TenantCredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for PingOne OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-pingidentity.html
     */
    static usingPingOne(scope: Construct, id: string, props: IncludedOauth2TenantCredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for X (Twitter) OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-x.html
     */
    static usingX(scope: Construct, id: string, props: XOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Facebook OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-facebook.html
     */
    static usingFacebook(scope: Construct, id: string, props: FacebookOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Yandex OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-yandex.html
     */
    static usingYandex(scope: Construct, id: string, props: YandexOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Reddit OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-reddit.html
     */
    static usingReddit(scope: Construct, id: string, props: RedditOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Zoom OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-zoom.html
     */
    static usingZoom(scope: Construct, id: string, props: ZoomOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Twitch OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-twitch.html
     */
    static usingTwitch(scope: Construct, id: string, props: TwitchOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Spotify OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-spotify.html
     */
    static usingSpotify(scope: Construct, id: string, props: SpotifyOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Dropbox OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-dropbox.html
     */
    static usingDropbox(scope: Construct, id: string, props: DropboxOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Notion OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-notion.html
     */
    static usingNotion(scope: Construct, id: string, props: NotionOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for HubSpot OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-hubspot.html
     */
    static usingHubspot(scope: Construct, id: string, props: HubspotOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for CyberArk OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-cyberark.html
     */
    static usingCyberArk(scope: Construct, id: string, props: IncludedOauth2TenantCredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for FusionAuth OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-fusionauth.html
     */
    static usingFusionAuth(scope: Construct, id: string, props: IncludedOauth2TenantCredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Auth0 OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-auth0.html
     */
    static usingAuth0(scope: Construct, id: string, props: IncludedOauth2TenantCredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for Amazon Cognito OAuth2 (`IncludedOauth2ProviderConfig`).
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/identity-idp-cognito.html
     */
    static usingCognito(scope: Construct, id: string, props: IncludedOauth2TenantCredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Create a credential provider for a custom OAuth2 authorization server (discovery document or metadata).
     */
    static usingCustom(scope: Construct, id: string, props: CustomOAuth2CredentialProviderProps): OAuth2CredentialProvider;
    /**
     * Import an existing OAuth2 credential provider.
     */
    static fromOAuth2CredentialProviderAttributes(scope: Construct, id: string, attrs: OAuth2CredentialProviderAttributes): IOAuth2CredentialProvider;
    readonly credentialProviderArn: string;
    readonly credentialProviderVendor: string;
    /**
     * The name of this OAuth2 credential provider.
     * @attribute
     */
    readonly oAuth2CredentialProviderName: string;
    readonly callbackUrl?: string;
    readonly createdTime?: string;
    readonly lastUpdatedTime?: string;
    private _clientSecretArn?;
    private readonly __resource;
    get clientSecretArn(): string | undefined;
    constructor(scope: Construct, id: string, props: OAuth2CredentialProviderProps);
    /**
     * ARNs and OAuth scopes for {@link GatewayCredentialProvider.fromOauthIdentity} / {@link GatewayCredentialProvider.fromOauthIdentityArn}.
     *
     * @param scopes OAuth scopes the gateway target should request (see vendor documentation).
     * @param customParameters Optional custom parameters for the OAuth flow.
     */
    bindForGatewayOAuthTarget(scopes: string[], customParameters?: {
        [key: string]: string;
    }): GatewayOAuth2IdentityBinding;
}
export {};
