/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import type { IConstruct } from 'constructs';
import type { CategoricalRatingOption, FilterConfig, NumericalRatingOption } from './types';
/**
 * Interface for evaluator references used in validation.
 * @internal
 */
interface IEvaluatorReference {
    readonly evaluatorId: string;
}
/******************************************************************************
 *                              TYPES
 *****************************************************************************/
export type ValidationFn<T> = (param: T, scope?: IConstruct) => string[];
/******************************************************************************
 *                         VALIDATION FUNCTIONS
 *****************************************************************************/
/**
 * Validates the online evaluation configuration name.
 * Must start with a letter and contain only alphanumeric characters and underscores.
 * @param name - The configuration name to validate
 * @param _scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateConfigName(name: string, _scope?: IConstruct): string[];
/**
 * Validates the description field.
 * @param description - The description to validate
 * @param _scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateDescription(description: string | undefined, _scope?: IConstruct): string[];
/**
 * Validates the evaluators array.
 * @param evaluators - The evaluators array to validate
 * @param _scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateEvaluators(evaluators: IEvaluatorReference[], _scope?: IConstruct): string[];
/**
 * Validates the sampling percentage.
 * @param percentage - The sampling percentage to validate
 * @param _scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateSamplingPercentage(percentage: number | undefined, _scope?: IConstruct): string[];
/**
 * Validates the filters array.
 * @param filters - The filters array to validate
 * @param _scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateFilters(filters: FilterConfig[] | undefined, _scope?: IConstruct): string[];
/**
 * Validates the session timeout in minutes.
 * @param minutes - The session timeout in minutes to validate
 * @param _scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateSessionTimeout(minutes: number | undefined, _scope?: IConstruct): string[];
/**
 * Validates the log group names array.
 * @param names - The log group names array to validate
 * @param _scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateLogGroupNames(names: string[], _scope?: IConstruct): string[];
/**
 * Validates the service names array.
 * @param names - The service names array to validate
 * @param _scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateServiceNames(names: string[], _scope?: IConstruct): string[];
/**
 * Validates the evaluator name.
 * Must start with a letter and contain only alphanumeric characters and underscores.
 * @param name - The evaluator name to validate
 * @param _scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateEvaluatorName(name: string, _scope?: IConstruct): string[];
/**
 * Validates that instructions are provided and non-empty.
 * @param instructions - The instructions to validate
 * @param _scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateInstructions(instructions: string, _scope?: IConstruct): string[];
/**
 * Validates a categorical rating scale.
 * @param options - The categorical rating options to validate
 * @param _scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateCategoricalRatingScale(options: CategoricalRatingOption[], _scope?: IConstruct): string[];
/**
 * Validates a numerical rating scale.
 * @param options - The numerical rating options to validate
 * @param _scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateNumericalRatingScale(options: NumericalRatingOption[], _scope?: IConstruct): string[];
/**
 * Validates the Lambda timeout in seconds.
 * @param seconds - The timeout in seconds to validate
 * @param _scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateLambdaTimeout(seconds: number | undefined, _scope?: IConstruct): string[];
/******************************************************************************
 *                              HELPER FUNCTIONS
 *****************************************************************************/
/**
 * Throws a validation error if the validation function returns any errors.
 * @param validationFn - The validation function to execute
 * @param param - The parameter to validate
 * @param scope - The construct scope for error reporting (optional)
 * @returns The validated parameter
 */
export declare function throwIfInvalid<T>(validationFn: ValidationFn<T>, param: T, scope?: IConstruct): T;
/** Validates tags for Evaluator resources (Unicode keys allowed per CFN docs) */
export declare function validateEvaluatorTags(tags?: {
    [key: string]: string;
}, scope?: IConstruct): string[];
/** Validates tags for OnlineEvaluationConfig resources (ASCII keys per CFN pattern) */
export declare function validateEvaluationTags(tags?: {
    [key: string]: string;
}, scope?: IConstruct): string[];
export {};
