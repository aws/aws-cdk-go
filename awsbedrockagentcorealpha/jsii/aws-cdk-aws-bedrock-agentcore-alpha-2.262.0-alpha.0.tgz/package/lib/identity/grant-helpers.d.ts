/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import * as iam from 'aws-cdk-lib/aws-iam';
import type { IConstruct } from 'constructs';
/**
 * Parent/collection resource ARN segments for Token Vault credential providers.
 *
 * Bedrock AgentCore uses a hierarchical authorization model where Get/List actions
 * require IAM permission on the parent and collection resources in addition to the
 * specific resource instance. For example, GetApiKeyCredentialProvider needs:
 *   - token-vault/default                             (vault)
 *   - token-vault/default/apikeycredentialprovider    (collection)
 *   - token-vault/default/apikeycredentialprovider/*  (instance)
 *
 * @internal
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const TOKEN_VAULT_API_KEY_PARENT_RESOURCES: readonly ["token-vault/default", "token-vault/default/apikeycredentialprovider"];
/**
 * @internal
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const TOKEN_VAULT_OAUTH2_PARENT_RESOURCES: readonly ["token-vault/default", "token-vault/default/oauth2credentialprovider"];
/**
 * @internal
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const WORKLOAD_IDENTITY_PARENT_RESOURCES: readonly ["workload-identity-directory/default", "workload-identity-directory/default/workload-identity"];
/**
 * Workload identity resource ARN segments required by data-plane actions
 * (GetResourceApiKey, GetResourceOauth2Token, CompleteResourceTokenAuth).
 *
 * These actions require both the workload identity directory and a wildcard
 * over workload identities because the specific identity is created dynamically
 * by the gateway/service at runtime.
 *
 * @internal
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const WORKLOAD_IDENTITY_USE_RESOURCES: readonly ["workload-identity-directory/default", "workload-identity-directory/default/workload-identity/*"];
/**
 * Build the full set of resource ARNs for an identity grant: the instance ARN
 * plus all parent/collection ARNs that the service's authorization model requires.
 *
 * @internal
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare function buildIdentityResourceArns(scope: IConstruct, instanceArn: string, parentResources: readonly string[]): string[];
/**
 * Grant read and list permissions on a specific identity resource, including
 * parent/collection ARNs required by the Bedrock AgentCore authorization model.
 *
 * @internal
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare function grantReadWithList(scope: IConstruct, grantee: iam.IGrantable, resourceArn: string, resourceReadActions: string[], listActions: string[], parentResources: readonly string[]): iam.Grant;
/**
 * Grants Secrets Manager actions on the credential secret when an ARN is available
 * (e.g. not omitted on import). Used for both read (GetSecretValue) and write
 * (PutSecretValue) grants.
 *
 * The CFN attribute for the secret ARN (e.g. `attrApiKeySecretArn`) resolves to an
 * object `{ SecretArn: string }` at deploy time, not a plain string, so the Token
 * cannot be placed directly in IAM Resource fields. When the secret ARN is unresolved
 * (Token), we fall back to a service-managed prefix wildcard. When a literal ARN is
 * supplied (e.g. via `fromApiKeyCredentialProviderAttributes`), we scope tightly.
 *
 * @internal
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare function grantCredentialSecret(scope: IConstruct, grantee: iam.IGrantable, secretArn: string | undefined, secretActions: string[]): iam.Grant | undefined;
