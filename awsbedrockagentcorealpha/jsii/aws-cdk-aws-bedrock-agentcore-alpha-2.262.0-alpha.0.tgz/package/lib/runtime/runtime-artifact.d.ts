/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import type { CfnRuntime } from 'aws-cdk-lib/aws-bedrockagentcore';
import type * as ecr from 'aws-cdk-lib/aws-ecr';
import * as assets from 'aws-cdk-lib/aws-ecr-assets';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as s3_assets from 'aws-cdk-lib/aws-s3-assets';
import type { Construct } from 'constructs';
import type { Runtime } from './runtime';
/**
 * Bedrock AgentCore runtime environment for code execution
 * Allowed values: PYTHON_3_10 | PYTHON_3_11 | PYTHON_3_12 | PYTHON_3_13 | PYTHON_3_14 | NODE_22
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare enum AgentCoreRuntime {
    /**
     * Python 3.10 runtime
     */
    PYTHON_3_10 = "PYTHON_3_10",
    /**
     * Python 3.11 runtime
     */
    PYTHON_3_11 = "PYTHON_3_11",
    /**
     * Python 3.12 runtime
     */
    PYTHON_3_12 = "PYTHON_3_12",
    /**
     * Python 3.13 runtime
     */
    PYTHON_3_13 = "PYTHON_3_13",
    /**
     * Python 3.14 runtime
     */
    PYTHON_3_14 = "PYTHON_3_14",
    /**
     * Node.js 22 runtime
     */
    NODE_22 = "NODE_22"
}
/**
 * Options for configuring an S3 code asset from local files for agent runtime artifact
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface CodeAssetOptions extends s3_assets.AssetOptions {
    /**
     * The file path to the code asset
     */
    readonly path: string;
    /**
     * The runtime environment for executing the code
     */
    readonly runtime: AgentCoreRuntime;
    /**
     * The entry point for the code execution, specifying the function or method that should be invoked when the code runs
     */
    readonly entrypoint: string[];
}
/**
 * Abstract base class for agent runtime artifacts.
 * Provides methods to reference container images from ECR repositories or local assets.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare abstract class AgentRuntimeArtifact {
    /**
     * Reference an image in an ECR repository
     */
    static fromEcrRepository(repository: ecr.IRepository, tag?: string): AgentRuntimeArtifact;
    /**
     * Reference an agent runtime artifact that's constructed directly from sources on disk
     * @param directory The directory where the Dockerfile is stored
     * @param options The options to further configure the selected image
     */
    static fromAsset(directory: string, options?: assets.DockerImageAssetOptions): AgentRuntimeArtifact;
    /**
     * Reference an agent runtime artifact that's constructed directly from an S3 object
     * @param s3Location The source code location and configuration details.
     * @param runtime The runtime environment for executing the code. Allowed values: PYTHON_3_10 | PYTHON_3_11 | PYTHON_3_12 | PYTHON_3_13 | PYTHON_3_14 | NODE_22
     * @param entrypoint The entry point for the code execution, specifying the function or method that should be invoked when the code runs.
     */
    static fromS3(s3Location: s3.Location, runtime: AgentCoreRuntime, entrypoint: string[]): AgentRuntimeArtifact;
    /**
     * Reference an agent runtime artifact that's constructed from local code assets uploaded to a CDK-managed S3 bucket
     * @param options The options for configuring the code asset
     */
    static fromCodeAsset(options: CodeAssetOptions): AgentRuntimeArtifact;
    /**
     * Reference an image using an ECR container URI
     *
     * Use this when referencing ECR images from CloudFormation parameters or cross-stack references.
     *
     * **Note:** No IAM permissions are automatically granted. You must ensure the runtime has
     * ECR pull permissions for the repository.
     *
     * @param containerUri The ECR container image URI (format: {account}.dkr.ecr.{region}.amazonaws.com/{repository}:{tag})
     */
    static fromImageUri(containerUri: string): AgentRuntimeArtifact;
    /**
     * Called when the image is used by a Runtime to handle side effects like permissions
     */
    abstract bind(scope: Construct, runtime: Runtime): void;
    /**
     * Render the artifact configuration for CloudFormation
     * @internal
     */
    abstract _render(): CfnRuntime.AgentRuntimeArtifactProperty;
}
