import type { Construct } from 'constructs';
import type { IRuntimeEndpoint, RuntimeEndpointAttributes } from './runtime-endpoint-base';
import { RuntimeEndpointBase } from './runtime-endpoint-base';
/******************************************************************************
 *                                Props
 *****************************************************************************/
/**
 * Properties for creating a Bedrock Agent Core Runtime Endpoint resource
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface RuntimeEndpointProps {
    /**
     * The name of the agent runtime endpoint
     * Valid characters are a-z, A-Z, 0-9, _ (underscore)
     * Must start with a letter and can be up to 48 characters long
     * Pattern: ^[a-zA-Z][a-zA-Z0-9_]{0,47}$
     * @default - auto generate
     */
    readonly endpointName?: string;
    /**
     * The ID of the agent runtime to associate with this endpoint
     * This is the unique identifier of the runtime resource
     * Pattern: ^[a-zA-Z][a-zA-Z0-9_]{0,99}-[a-zA-Z0-9]{10}$
     */
    readonly agentRuntimeId: string;
    /**
     * The version of the agent runtime to use for this endpoint
     * If not specified, the endpoint will point to version "1" of the runtime.
     * Pattern: ^([1-9][0-9]{0,4})$
     * @default "1"
     */
    readonly agentRuntimeVersion?: string;
    /**
     * Optional description for the agent runtime endpoint
     * Length Minimum: 1 ,  Maximum: 256
     * @default - No description
     */
    readonly description?: string;
    /**
     * Tags for the agent runtime endpoint
     * A list of key:value pairs of tags to apply to this RuntimeEndpoint resource
     * Pattern: ^[a-zA-Z0-9\s._:/=+@-]*$
     * @default {} - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/******************************************************************************
 *                                Class
 *****************************************************************************/
/**
 * Bedrock Agent Core Runtime Endpoint
 * Provides a stable endpoint for invoking agent runtimes with versioning support
 *
 * @resource AWS::BedrockAgentCore::RuntimeEndpoint
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/runtime-endpoint.html
 */
export declare class RuntimeEndpoint extends RuntimeEndpointBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing Agent Runtime Endpoint using attributes
     * This allows you to reference an Agent Runtime Endpoint that was created outside of CDK
     *
     * @param scope The construct scope
     * @param id The construct id
     * @param attrs The attributes of the existing Agent Runtime Endpoint
     * @returns An IRuntimeEndpoint instance representing the imported endpoint
     */
    static fromRuntimeEndpointAttributes(scope: Construct, id: string, attrs: RuntimeEndpointAttributes): IRuntimeEndpoint;
    /**
     * The ARN of the agent runtime endpoint
     * @attribute
     * @returns a token representing the ARN of this agent runtime endpoint
     */
    readonly agentRuntimeEndpointArn: string;
    /**
     * The name of the endpoint
     * @attribute
     * @returns a token representing the name of this endpoint
     */
    readonly endpointName: string;
    /**
     * The ARN of the agent runtime associated with this endpoint
     * @attribute
     * @returns a token representing the ARN of the agent runtime
     */
    readonly agentRuntimeArn: string;
    /**
     * The status of the endpoint
     * @attribute
     * @returns a token representing the status of this endpoint
     */
    readonly status?: string;
    /**
     * The live version of the endpoint
     * @attribute
     * @returns a token representing the live version of this endpoint
     */
    readonly liveVersion?: string;
    /**
     * The target version of the endpoint
     * @attribute
     * @returns a token representing the target version of this endpoint
     */
    readonly targetVersion?: string;
    /**
     * The timestamp when the endpoint was created
     * @attribute
     * @returns a token representing the creation timestamp of this endpoint
     */
    readonly createdAt?: string;
    /**
     * Optional description for the endpoint
     */
    readonly description?: string;
    /**
     * The unique identifier of the runtime endpoint
     * @attribute
     * @returns a token representing the ID of this endpoint
     */
    readonly endpointId: string;
    /**
     * The ID of the agent runtime associated with this endpoint
     */
    readonly agentRuntimeId: string;
    /**
     * The version of the agent runtime used by this endpoint
     */
    readonly agentRuntimeVersion: string;
    /**
     * When this endpoint was last updated
     * @attribute
     * @returns a token representing the last update timestamp of this endpoint
     */
    readonly lastUpdatedAt?: string;
    private readonly endpointResource;
    constructor(scope: Construct, id: string, props: RuntimeEndpointProps);
    /**
     * Renders the agent runtime ID for CloudFormation
     * @internal
     */
    private renderAgentRuntimeId;
    /**
     * Renders the agent runtime version for CloudFormation
     * @internal
     */
    private renderAgentRuntimeVersion;
    /**
     * Renders the description for CloudFormation
     * @internal
     */
    private renderDescription;
    /**
     * Validates the endpoint name format
     * Pattern: ^[a-zA-Z][a-zA-Z0-9_]{0,47}$
     * @throws Error if validation fails
     */
    private validateEndpointName;
    /**
     * Validates the description format
     * Must be between 1 and 256 characters (per CloudFormation specification)
     * @throws Error if validation fails
     */
    private validateDescription;
    /**
     * Validates the agent runtime ID format
     * Pattern: ^[a-zA-Z][a-zA-Z0-9_]{0,99}-[a-zA-Z0-9]{10}$
     * @throws Error if validation fails
     */
    private validateAgentRuntimeId;
    /**
     * Validates the agent runtime version format
     * Pattern: ^([1-9][0-9]{0,4})$
     * @throws Error if validation fails
     */
    private validateAgentRuntimeVersion;
    /**
     * Validates the tags format
     * @param tags The tags object to validate
     * @throws Error if validation fails
     */
    private validateTags;
}
