/******************************************************************************
 *                         Data Plane Permissions
 *****************************************************************************/
/**
 * Permissions to invoke the agent runtime
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const RUNTIME_INVOKE_PERMS: string[];
/**
 * Permissions to invoke the agent runtime on behalf of a user
 * Required when using the X-Amzn-Bedrock-AgentCore-Runtime-User-Id header
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const RUNTIME_INVOKE_USER_PERMS: string[];
/******************************************************************************
 *                         Control Plane Permissions
 *****************************************************************************/
/**
 * Grants control plane operations to manage the runtime (CRUD)
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const RUNTIME_ADMIN_PERMS: string[];
/******************************************************************************
 *                    Execution Role Permissions
 *****************************************************************************/
/**
 * ECR permissions for pulling container images
 * Used to download container images from ECR repositories
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const RUNTIME_ECR_IMAGE_ACTIONS: string[];
/**
 * ECR authorization token permissions
 * Required to authenticate with ECR (must use * resource)
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const RUNTIME_ECR_TOKEN_ACTIONS: string[];
/**
 * CloudWatch Logs permissions for log group operations
 * Used to create and describe log groups for runtime logs
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const RUNTIME_LOGS_GROUP_ACTIONS: string[];
/**
 * CloudWatch Logs describe permissions
 * Used to list and describe all log groups
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const RUNTIME_LOGS_DESCRIBE_ACTIONS: string[];
/**
 * CloudWatch Logs permissions for log stream operations
 * Used to create log streams and write log events
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const RUNTIME_LOGS_STREAM_ACTIONS: string[];
/**
 * X-Ray tracing permissions
 * Required for distributed tracing (must use * resource)
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const RUNTIME_XRAY_ACTIONS: string[];
/**
 * CloudWatch metrics permissions
 * Used to publish custom metrics
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const RUNTIME_CLOUDWATCH_METRICS_ACTIONS: string[];
/**
 * Bedrock AgentCore workload identity permissions
 * Used to obtain access tokens for workload identity
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const RUNTIME_WORKLOAD_IDENTITY_ACTIONS: string[];
/**
 * CloudWatch namespace for metrics
 * Used as a condition for CloudWatch metrics permissions
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const RUNTIME_CLOUDWATCH_NAMESPACE = "bedrock-agentcore";
