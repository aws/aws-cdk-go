import type { CfnBrowserCustom, CfnCodeInterpreterCustom, CfnRuntime } from 'aws-cdk-lib/aws-bedrockagentcore';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import type { Construct } from 'constructs';
/**
 * VPC configuration properties.
 * Only used when network mode is VPC.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface VpcConfigProps {
    /**
     * The VPC to deploy the resource to.
     */
    readonly vpc: ec2.IVpc;
    /**
     * Where to place the network interfaces within the VPC.
     *
     * This requires `vpc` to be specified in order for interfaces to actually be
     * placed in the subnets. If `vpc` is not specify, this will raise an error.
     *
     * @default - the Vpc default strategy if not specified
     */
    readonly vpcSubnets?: ec2.SubnetSelection;
    /**
     * The list of security groups to associate with the resource's network interfaces.
     *
     * Only used if 'vpc' is supplied.
     *
     * @default - If the resource is placed within a VPC and a security group is
     * not specified by this prop, a dedicated security
     * group will be created for this resource.
     */
    readonly securityGroups?: ec2.ISecurityGroup[];
    /**
     * Whether to allow the resource to send all network traffic (except ipv6)
     *
     * If set to false, you must individually add traffic rules to allow the
     * resource to connect to network targets.
     *
     * Do not specify this property if the `securityGroups` property is set.
     * Instead, configure `allowAllOutbound` directly on the security group.
     *
     * @default true
     */
    readonly allowAllOutbound?: boolean;
}
/**
 * Abstract base class for network configuration.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare abstract class NetworkConfiguration {
    /**
     * The network mode to use.
     * Configure the security level for agent
     * execution to control access, isolate resources, and protect sensitive data.
     */
    readonly networkMode: string;
    /**
     * The connections object to the network.
     */
    readonly connections: ec2.Connections | undefined;
    /**
     * The scope to create the resource in.
     */
    readonly scope?: Construct | undefined;
    /**
     * The VPC subnets to use.
     */
    readonly vpcSubnets?: ec2.SubnetSelection;
    /**
     * Creates a new network configuration.
     * @param mode - the network mode to use for the tool.
     */
    protected constructor(mode: string, scope?: Construct, vpcConfig?: VpcConfigProps);
    /**
     * Validates the vpc config.
     */
    private _validateAndConfigureVpcConfig;
}
/**
 * Network configuration for the Browser tool.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare class BrowserNetworkConfiguration extends NetworkConfiguration {
    /**
     * Creates a public network configuration. PUBLIC is the default network mode.
     * @returns A BrowserNetworkConfiguration.
     * Run this tool to operate in a public environment with internet access, suitable for less sensitive or open-use scenarios.
     */
    static usingPublicNetwork(): BrowserNetworkConfiguration;
    /**
     * Creates a network configuration from a VPC configuration.
     * @param vpcConfig - The VPC configuration.
     * @returns A BrowserNetworkConfiguration.
     */
    static usingVpc(scope: Construct, vpcConfig: VpcConfigProps): BrowserNetworkConfiguration;
    /**
     * Renders the network configuration as a CloudFormation property.
     * @param browserConnections - The connections object to the browser.
     * @internal This is an internal core function and should not be called directly.
     */
    _render(browserConnections?: ec2.Connections): CfnBrowserCustom.BrowserNetworkConfigurationProperty;
}
/**
 * Network configuration for the Code Interpreter tool.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare class CodeInterpreterNetworkConfiguration extends NetworkConfiguration {
    /**
     * Creates a public network configuration.
     * @returns A CodeInterpreterNetworkConfiguration.
     * Run this tool to operate in a public environment with internet access, suitable for less sensitive or open-use scenarios.
     */
    static usingPublicNetwork(): CodeInterpreterNetworkConfiguration;
    /**
     * Creates a sandbox network configuration.
     * @returns A CodeInterpreterNetworkConfiguration.
     * Run this tool in a restricted environment with limited Permissions and Encryption to enhance safety and reduce potential risks.
     */
    static usingSandboxNetwork(): CodeInterpreterNetworkConfiguration;
    /**
     * Creates a network configuration from a VPC configuration.
     * @param vpcConfig - The VPC configuration.
     * @returns A CodeInterpreterNetworkConfiguration.
     */
    static usingVpc(scope: Construct, vpcConfig: VpcConfigProps): CodeInterpreterNetworkConfiguration;
    /**
     * Renders the network configuration as a CloudFormation property.
     * @param codeInterpreterConnections - The connections object to the code interpreter.
     * @internal This is an internal core function and should not be called directly.
     */
    _render(codeInterpreterConnections?: ec2.Connections): CfnCodeInterpreterCustom.CodeInterpreterNetworkConfigurationProperty;
}
/**
 * Network configuration for the Runtime.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare class RuntimeNetworkConfiguration extends NetworkConfiguration {
    /**
     * Creates a public network configuration. PUBLIC is the default network mode.
     * @returns A RuntimeNetworkConfiguration.
     * Run the runtime in a public environment with internet access, suitable for less sensitive or open-use scenarios.
     */
    static usingPublicNetwork(): RuntimeNetworkConfiguration;
    /**
     * Creates a network configuration from a VPC configuration.
     * @param scope - The construct scope for creating resources.
     * @param vpcConfig - The VPC configuration.
     * @returns A RuntimeNetworkConfiguration.
     */
    static usingVpc(scope: Construct, vpcConfig: VpcConfigProps): RuntimeNetworkConfiguration;
    /**
     * Renders the network configuration as a CloudFormation property.
     * @param runtimeConnections - The connections object to the runtime.
     * @internal This is an internal core function and should not be called directly.
     */
    _render(_runtimeConnections?: ec2.Connections): CfnRuntime.NetworkConfigurationProperty;
}
