/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import * as cdk from 'aws-cdk-lib';
import type * as bedrockagentcore from 'aws-cdk-lib/aws-bedrockagentcore';
import * as iam from 'aws-cdk-lib/aws-iam';
import type { Location } from 'aws-cdk-lib/aws-s3';
import type * as sns from 'aws-cdk-lib/aws-sns';
import type { IMemoryStrategy, MemoryStrategyCommonProps, MemoryStrategyType } from '../memory-strategy';
/**
 * Trigger conditions for self managed memory strategy
 * When first condition is met, batched payloads are sent to specified S3 bucket.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface TriggerConditions {
    /**
     * Triggers memory processing when specified number of new messages is reached
     * @default 1
     */
    readonly messageBasedTrigger?: number;
    /**
     * Triggers memory processing when the session has been idle for the specified duration.
     * Value in seconds.
     * @default - 10 seconds
     */
    readonly timeBasedTrigger?: cdk.Duration;
    /**
     * Triggers memory processing when the token size reaches the specified threshold.
     * @default 100
     */
    readonly tokenBasedTrigger?: number;
}
/**
 * Invocation configuration for self managed memory strategy
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface InvocationConfiguration {
    /**
     * SNS Topic Configuration
     */
    readonly topic: sns.ITopic;
    /**
     * S3 Location Configuration
     */
    readonly s3Location: Location;
}
/**
 * Configuration parameters for a self managed memory strategy
 * existing built-in default prompts/models
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface SelfManagedStrategyProps extends MemoryStrategyCommonProps {
    /**
     * Define the number of previous events to be included when processing memory. A larger history window provides more context from past conversations.
     * @default 4
     */
    readonly historicalContextWindowSize?: number;
    /**
     * Invocation configuration for self managed memory strategy
     */
    readonly invocationConfiguration: InvocationConfiguration;
    /**
     * Trigger conditions for self managed memory strategy
     * @default - undefined
     */
    readonly triggerConditions?: TriggerConditions;
}
/**
 * Use AgentCore memory for event storage with custom triggers. Define memory processing logic in your own environment.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare class SelfManagedMemoryStrategy implements IMemoryStrategy {
    readonly name: string;
    readonly description?: string;
    readonly strategyType: MemoryStrategyType;
    /**
     * Invocation configuration for self managed memory strategy
     */
    readonly invocationConfiguration: InvocationConfiguration;
    /**
     * Trigger conditions for self managed memory strategy
     */
    readonly triggerConditions: TriggerConditions;
    /**
     * Historical context window size for self managed memory strategy
     */
    readonly historicalContextWindowSize: number;
    constructor(strategyType: MemoryStrategyType, props: SelfManagedStrategyProps);
    render(): bedrockagentcore.CfnMemory.MemoryStrategyProperty;
    /**
     * Grants the necessary permissions to the role
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee - The grantee to grant permissions to
     * @returns The Grant object for chaining
     */
    grant(grantee: iam.IGrantable): iam.Grant | undefined;
    /**
     * Validates the memory strategy name
     * @param name - The name to validate
     * @returns Array of validation error messages, empty if valid
     */
    private _validateMemoryStrategyName;
    /**
     * Validates the historical context window size
     * @param historicalContextWindowSize - The historical context window size to validate
     * @returns Array of validation error messages, empty if valid
     */
    private _validateHistoricalContextWindowSize;
    /**
     * Validates the trigger conditions
     * @param triggerConditions - The trigger conditions to validate
     * @returns Array of validation error messages, empty if valid
     */
    private _validateTriggerConditions;
}
