/******************************************************************************
   * Data Plane Permissions
   *****************************************************************************/
/**
 * Permissions to invoke the gateway
 * Used by agents or other services that need to call the gateway
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_INVOKE_PERMS: string[];
/******************************************************************************
   * Execution Role Permissions
   *****************************************************************************/
/**
 * KMS permissions for encryption
 * Required when using KMS keys for encryption
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_KMS_KEY_PERMS: string[];
/**
 * Assume role permission
 * Required for the gateway service to assume the execution role
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_ASSUME_ROLE: string[];
/**
 * Outbound auth - Workload identity permissions (API key targets)
 * Used to obtain access tokens for workload identity
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_WORKLOAD_IDENTITY_PERMS: string[];
/**
 * Outbound auth - Workload identity permissions (OAuth targets)
 * OAuth flows additionally require JWT-based and user-ID-based token exchange
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_WORKLOAD_IDENTITY_OAUTH_PERMS: string[];
/**
 * Outbound auth - OAuth permissions
 * Used to obtain OAuth tokens and complete token auth for target authentication
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_OAUTH_PERMS: string[];
/**
 * Outbound auth - OAuth complete token auth permissions
 * Used to complete the OAuth token authorization flow
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_OAUTH_COMPLETE_AUTH_PERMS: string[];
/**
 * Outbound auth - API Key permissions
 * Used to retrieve API keys for target authentication
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_API_KEY_PERMS: string[];
/**
 * Secrets Manager permissions
 * Required for reading credential secrets backing Token Vault providers.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-outbound-auth.html
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_SECRETS_PERMS: string[];
/******************************************************************************
   * Control Plane Permissions
   *****************************************************************************/
/**
 * Get permissions for gateway resources
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_GET_PERMS: string[];
/**
 * List permissions for gateway resources
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_LIST_PERMS: string[];
/**
 * Create permissions for gateway resources
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_CREATE_PERMS: string[];
/**
 * Update permissions for gateway resources
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_UPDATE_PERMS: string[];
/**
 * Delete permissions for gateway resources
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_DELETE_PERMS: string[];
/**
 * Combined manage permissions (create, update, delete)
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_MANAGE_PERMS: string[];
/**
 * Synchronization permissions for MCP server targets
 * Used to refresh tool catalogs when MCP server tools change
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const GATEWAY_SYNC_PERMS: string[];
