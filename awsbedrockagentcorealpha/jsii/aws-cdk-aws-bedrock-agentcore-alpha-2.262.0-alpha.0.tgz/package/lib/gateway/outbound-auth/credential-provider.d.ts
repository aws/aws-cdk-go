import type { IResolvable } from 'aws-cdk-lib';
import type { CfnGatewayTarget } from 'aws-cdk-lib/aws-bedrockagentcore';
import type { Grant } from 'aws-cdk-lib/aws-iam';
import type { ApiKeyCredentialLocation, ApiKeyCredentialProviderProps } from './api-key';
import type { OAuthConfiguration } from './oauth';
import type { IApiKeyCredentialProvider } from '../../identity/api-key-credential-provider';
import type { IOAuth2CredentialProvider } from '../../identity/oauth2-credential-provider';
import type { IGateway } from '../gateway-base';
/******************************************************************************
 *                                 Enums
 *****************************************************************************/
/**
 * Credential provider types supported by gateway target
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare enum CredentialProviderType {
    /**
     * API Key authentication
     */
    API_KEY = "API_KEY",
    /**
     * OAuth authentication
     */
    OAUTH = "OAUTH",
    /**
     * IAM role authentication
     */
    GATEWAY_IAM_ROLE = "GATEWAY_IAM_ROLE"
}
/******************************************************************************
 *                       Credential Provider
 *****************************************************************************/
/**
 * Abstract interface for gateway credential provider configuration
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface ICredentialProviderConfig {
    /**
     * The credential provider type
     */
    readonly credentialProviderType: CredentialProviderType;
    /**
     * Renders as CFN Property
     *  @internal
     */
    _render(): CfnGatewayTarget.CredentialProviderConfigurationProperty | IResolvable;
    /**
     * Grant the gateway's execution role the permissions needed for outbound authentication.
     * @param gateway The gateway whose role needs outbound auth permissions [disable-awslint:prefer-ref-interface]
     */
    grantNeededPermissionsToRole(gateway: IGateway): Grant | undefined;
}
/**
 * Optional gateway settings when binding an {@link IApiKeyCredentialProvider} to a target.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface FromApiKeyIdentityOptions {
    /**
     * Where to place the API key on outbound requests.
     *
     * @default header `Authorization` with `Bearer ` prefix
     */
    readonly credentialLocation?: ApiKeyCredentialLocation;
}
/**
 * OAuth scopes (and optional custom parameters) when binding an {@link IOAuth2CredentialProvider} to a gateway target.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface FromOauthIdentityOptions {
    /**
     * OAuth scopes the gateway should request for this target.
     */
    readonly scopes: string[];
    /**
     * Additional OAuth parameters for the provider.
     *
     * @default - none
     */
    readonly customParameters?: {
        [key: string]: string;
    };
}
/**
 * Factory class for creating different Gateway Credential Providers
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare abstract class GatewayCredentialProvider {
    /**
     * Create an API key outbound auth configuration from a Token Vault {@link IApiKeyCredentialProvider} construct.
     *
     * Prefer this over {@link GatewayCredentialProvider.fromApiKeyIdentityArn} when the provider is defined in CDK.
     */
    static fromApiKeyIdentity(provider: IApiKeyCredentialProvider, options?: FromApiKeyIdentityOptions): ICredentialProviderConfig;
    /**
     * Create an API key credential provider from Identity ARN
     * Use this method when you have the Identity ARN as a string
     * @param props - The configuration properties for the API key credential provider
     * @returns ICredentialProviderConfig configured for API key authentication
     */
    static fromApiKeyIdentityArn(props: ApiKeyCredentialProviderProps): ICredentialProviderConfig;
    /**
     * Create an OAuth outbound auth configuration from a Token Vault {@link IOAuth2CredentialProvider} construct.
     *
     * Prefer this over {@link GatewayCredentialProvider.fromOauthIdentityArn} when the provider is defined in CDK.
     */
    static fromOauthIdentity(provider: IOAuth2CredentialProvider, options: FromOauthIdentityOptions): ICredentialProviderConfig;
    /**
     * Create an OAuth credential provider from Identity ARN
     * Use this method when you have the Identity ARN as a string
     * @param props - The configuration properties for the OAuth credential provider
     * @returns ICredentialProviderConfig configured for OAuth authentication
     */
    static fromOauthIdentityArn(props: OAuthConfiguration): ICredentialProviderConfig;
    /**
     * Create an IAM role credential provider
     * @returns IIamRoleCredentialProvider configured for IAM role authentication
     */
    static fromIamRole(): ICredentialProviderConfig;
}
