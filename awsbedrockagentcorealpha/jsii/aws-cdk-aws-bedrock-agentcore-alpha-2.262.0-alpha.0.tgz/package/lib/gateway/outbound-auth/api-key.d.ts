import { Grant } from 'aws-cdk-lib/aws-iam';
import type { ICredentialProviderConfig } from './credential-provider';
import { CredentialProviderType } from './credential-provider';
import type { IGateway } from '../gateway-base';
/******************************************************************************
 *                                 API KEY
 *****************************************************************************/
/**
 * API Key additional configuration
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface ApiKeyAdditionalConfiguration {
    /**
     * The name of the credential parameter for the API key.
     * This parameter name is used when sending the API key to the target endpoint.
     *
     * Length Constraints: Minimum length of 1. Maximum length of 64.
     * @default - 'Authorization' for HEADER, 'api_key' for QUERY_PARAMETER
     */
    readonly credentialParameterName?: string;
    /**
     * The prefix for the API key credential.
     * This prefix is added to the API key when sending it to the target endpoint.
     *
     * Length Constraints: Minimum length of 1. Maximum length of 64.
     * @default - 'Bearer ' for HEADER, no prefix for QUERY_PARAMETER
     */
    readonly credentialPrefix?: string;
}
/**
 * API Key credential location type
 * @internal
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare enum ApiKeyCredentialLocationType {
    HEADER = "HEADER",
    QUERY_PARAMETER = "QUERY_PARAMETER"
}
/**
 * API Key location within the request
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare class ApiKeyCredentialLocation {
    /**
     * Create a header-based API key credential location
     * @param config - Optional configuration for the credential location
     * @returns ApiKeyCredentialLocation configured for header placement
     */
    static header(config?: ApiKeyAdditionalConfiguration): ApiKeyCredentialLocation;
    /**
     * Create a query parameter-based API key credential location
     * @param config - Optional configuration for the credential location
     * @returns ApiKeyCredentialLocation configured for query parameter placement
     */
    static queryParameter(config?: ApiKeyAdditionalConfiguration): ApiKeyCredentialLocation;
    /**
     * The name of the credential parameter
     */
    readonly credentialParameterName: string;
    /**
     * The prefix for the credential value
     */
    readonly credentialPrefix?: string;
    /**
     * The type of credential location (HEADER or QUERY_PARAMETER)
     */
    readonly credentialLocationType: string;
    private constructor();
}
/**
 * API key credential provider ARNs for gateway outbound auth (Token Vault identity).
 *
 * Pass this to {@link GatewayCredentialProvider.fromApiKeyIdentityArn} or to {@link ApiKeyCredentialProviderConfiguration}.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface ApiKeyCredentialProviderProps {
    /**
     * The API key credential provider ARN.
     * This is returned when creating the API key credential provider via Console or API.
     * Format: arn:aws:bedrock-agentcore:region:account:token-vault/id/apikeycredentialprovider/name
     */
    readonly providerArn: string;
    /**
     * The ARN of the Secrets Manager secret containing the API key.
     * This is returned when creating the API key credential provider via Console or API.
     * Format: arn:aws:secretsmanager:region:account:secret:name
     */
    readonly secretArn: string;
    /**
     * The location of the API key credential.
     * This field specifies where in the request the API key should be placed.
     *
     * @default - HEADER
     */
    readonly credentialLocation?: ApiKeyCredentialLocation;
}
/**
 * API Key credential provider configuration implementation
 * Can be used with OpenAPI targets
 * @internal
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare class ApiKeyCredentialProviderConfiguration implements ICredentialProviderConfig {
    readonly credentialProviderType = CredentialProviderType.API_KEY;
    /**
     * The ARN of the API key provider
     */
    readonly providerArn: string;
    /**
     * The ARN of the Secrets Manager secret
     */
    readonly secretArn: string;
    /**
     * The location configuration for the API key credential
     */
    readonly credentialLocation: ApiKeyCredentialLocation;
    constructor(configuration: ApiKeyCredentialProviderProps);
    /**
     * Grant the needed permissions to the gateway role for API key authentication.
     *
     * Produces three scoped IAM statements matching the console-generated policy:
     * 1. `GetWorkloadAccessToken` on the workload identity directory ARNs
     * 2. `GetResourceApiKey` on the token vault, credential provider, directory, and identity ARNs
     * 3. `secretsmanager:GetSecretValue` on the specific credential secret ARN
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-outbound-auth.html
     */
    grantNeededPermissionsToRole(gateway: IGateway): Grant | undefined;
    /**
     * @internal
     */
    _render(): any;
}
