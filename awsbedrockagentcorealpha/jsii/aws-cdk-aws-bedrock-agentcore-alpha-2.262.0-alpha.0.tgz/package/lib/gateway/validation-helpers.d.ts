/**
 * @internal
 */
interface IntervalValidation {
    fieldName: string;
    minLength: number;
    maxLength: number;
}
interface StringLengthValidation extends IntervalValidation {
    value: string;
}
/**
 * Validates the length of a string field against minimum and maximum constraints.
 * @param value - The string value to validate
 * @param fieldName - Name of the field being validated (for error messages)
 * @param minLength - Minimum allowed length (defaults to 0)
 * @param maxLength - Maximum allowed length
 * @returns true if validation passes
 * @throws Error if validation fails with current length information
 * @internal
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare function validateStringField(params: StringLengthValidation): string[];
/**
 * Validates a string field against a regex pattern.
 * @param value - The string value to validate
 * @param fieldName - Name of the field being validated (for error messages)
 * @param pattern - Regular expression pattern to test against
 * @param customMessage - Optional custom error message
 * @returns true if validation passes
 * @throws Error if validation fails with detailed message
 * @internal
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare function validateFieldPattern(value: string, fieldName: string, pattern: RegExp, customMessage?: string): string[];
/**
 * @internal
 */
export type ValidationFn<T> = (param: T) => string[];
/**
 * OpenAPI schema validation parameters
 * @internal
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface OpenApiSchemaValidationParams {
    /**
     * The OpenAPI schema to validate (as a string)
     */
    schema: string;
    /**
     * Optional name for the schema (for error messages)
     */
    schemaName?: string;
}
/**
 * Validates an OpenAPI schema against Gateway requirements
 * Based on AWS documentation: https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-schema-openapi.html
 *
 * @param params - The validation parameters
 * @returns Array of validation error messages (empty if valid)
 * @internal
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare function validateOpenApiSchema(params: OpenApiSchemaValidationParams): string[];
export {};
