import type { IUserPoolClient, IUserPool } from 'aws-cdk-lib/aws-cognito';
import type { GatewayCustomClaim } from './custom-claim';
/******************************************************************************
 *                                Authorizer Configuration
 *****************************************************************************/
/**
 * Gateway authorizer type
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare enum GatewayAuthorizerType {
    /** Custom JWT authorizer type */
    CUSTOM_JWT = "CUSTOM_JWT",
    /** AWS IAM authorizer type */
    AWS_IAM = "AWS_IAM",
    /** No authorization type */
    NONE = "NONE"
}
/**
 * Abstract interface for gateway authorizer configuration
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface IGatewayAuthorizerConfig {
    /**
     * The authorizer type
     */
    readonly authorizerType: GatewayAuthorizerType;
    /**
     * The authorizer configuration in CFN format
     * @internal
     */
    _render(): any;
}
/******************************************************************************
 *                                  Custom JWT
 *****************************************************************************/
/**
 * Custom JWT authorizer configuration
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface CustomJwtConfiguration {
    /**
     * This URL is used to fetch OpenID Connect configuration or authorization server metadata
     * for validating incoming tokens.
     *
     * Pattern: .+/\.well-known/openid-configuration
     * Required: Yes
     */
    readonly discoveryUrl: string;
    /**
     * Represents individual audience values that are validated in the incoming JWT token validation process.
     * @default - No audience validation
     */
    readonly allowedAudience?: string[];
    /**
     * Represents individual client IDs that are validated in the incoming JWT token validation process.
     * @default - No client ID validation
     */
    readonly allowedClients?: string[];
    /**
     * Represents individual scopes that are validated in the incoming JWT token validation process.
     * @default - No scope validation
     */
    readonly allowedScopes?: string[];
    /**
     * Custom claims for additional JWT token validation.
     * Allows you to validate additional fields in JWT tokens beyond the standard audience, client, and scope validations.
     * @default - No custom claim validation
     */
    readonly customClaims?: GatewayCustomClaim[];
}
/**
 * Custom JWT authorizer configuration implementation
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare class CustomJwtAuthorizer implements IGatewayAuthorizerConfig {
    readonly authorizerType = GatewayAuthorizerType.CUSTOM_JWT;
    private readonly discoveryUrl;
    private readonly allowedAudience?;
    private readonly allowedClients?;
    private readonly allowedScopes?;
    private readonly customClaims?;
    constructor(config: CustomJwtConfiguration);
    /**
     * @internal
     */
    _render(): any;
}
/******************************************************************************
 *                               AWS IAM
 *****************************************************************************/
/**
 * AWS IAM authorizer configuration implementation
 *
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare class IamAuthorizer implements IGatewayAuthorizerConfig {
    readonly authorizerType = GatewayAuthorizerType.AWS_IAM;
    /**
     * @internal
     */
    _render(): any;
}
/******************************************************************************
 *                               No Authorization
 *****************************************************************************/
/**
 * No authorization configuration implementation
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare class NoAuthAuthorizer implements IGatewayAuthorizerConfig {
    readonly authorizerType = GatewayAuthorizerType.NONE;
    /**
     * @internal
     */
    _render(): any;
}
/******************************************************************************
 *                               Factory
 *****************************************************************************/
/**
 * Properties for configuring a Cognito authorizer.
 *
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface CognitoAuthorizerProps {
    /**
     * The Cognito User Pool to use for authentication
     */
    readonly userPool: IUserPool;
    /**
     * The allowed User Pool clients
     * @default - All clients are allowed
     */
    readonly allowedClients?: IUserPoolClient[];
    /**
     * The allowed audiences for JWT validation
     * @default - No audience validation
     */
    readonly allowedAudiences?: string[];
    /**
     * The allowed scopes for JWT validation
     * @default - No scope validation
     */
    readonly allowedScopes?: string[];
    /**
     * Custom claims for additional JWT token validation.
     * Allows you to validate additional fields in JWT tokens beyond the standard audience, client, and scope validations.
     * @default - No custom claim validation
     */
    readonly customClaims?: GatewayCustomClaim[];
}
/**
 * Factory class for creating Gateway Authorizers
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare abstract class GatewayAuthorizer {
    /**
     * AWS IAM authorizer instance
     */
    static usingAwsIam(): IGatewayAuthorizerConfig;
    /**
     * Create a custom JWT authorizer
     * @param configuration - The JWT configuration
     * @returns IGatewayAuthorizerConfig configured for custom JWT
     */
    static usingCustomJwt(configuration: CustomJwtConfiguration): IGatewayAuthorizerConfig;
    /**
     * Create a JWT authorizer from Cognito User Pool
     * @param props - The Cognito configuration
     * @returns CustomJwtAuthorizer configured for Cognito
     */
    static usingCognito(props: CognitoAuthorizerProps): IGatewayAuthorizerConfig;
    /**
     * No authorization — the gateway will not perform any inbound authorization.
     *
     * The gateway endpoint will be publicly accessible without credentials.
     * Use this for testing/development, or for production gateways where you have
     * implemented compensating controls such as Gateway Interceptors.
     *
     * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-inbound-auth.html#gateway-inbound-auth-none
     * @returns IGatewayAuthorizerConfig configured for no authorization
     */
    static withNoAuth(): IGatewayAuthorizerConfig;
}
