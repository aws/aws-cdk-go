/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import type { CloudWatchLogsDataSourceConfig, DataSourceConfigBindResult } from './types';
import type { IBedrockAgentRuntime } from '../runtime/runtime-base';
import type { IRuntimeEndpoint } from '../runtime/runtime-endpoint-base';
/**
 * Configuration for the data source used in online evaluation.
 *
 * Use the static factory methods to create data source configurations:
 * - `DataSourceConfig.fromAgentRuntimeEndpoint()` for AgentCore Runtime (recommended)
 * - `DataSourceConfig.fromAgentRuntimeEndpointName()` for AgentCore Runtime using endpoint name string
 * - `DataSourceConfig.fromCloudWatchLogs()` for external agents or custom log groups
 *
 * @example
 * // AgentCore Runtime with default endpoint
 * declare const runtime: agentcore.Runtime;
 * const dataSource = agentcore.DataSourceConfig.fromAgentRuntimeEndpoint(runtime);
 *
 * @example
 * // AgentCore Runtime with specific endpoint
 * declare const runtime: agentcore.Runtime;
 * const endpoint = runtime.addEndpoint('PROD');
 * const dataSource = agentcore.DataSourceConfig.fromAgentRuntimeEndpoint(runtime, endpoint);
 *
 * @example
 * // CloudWatch Logs data source (for external agents)
 * const dataSource = agentcore.DataSourceConfig.fromCloudWatchLogs({
 *   logGroupNames: ['/aws/my-external-agent/logs'],
 *   serviceNames: ['my-external-agent'],
 * });
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare class DataSourceConfig {
    /**
     * Creates a CloudWatch Logs data source configuration.
     *
     * Use this when your agent traces are stored in CloudWatch Logs,
     * such as for external agents or when you need to specify log groups directly.
     *
     * @param config - The CloudWatch Logs data source configuration
     * @returns A DataSourceConfig instance
     *
     * @example
     * const dataSource = agentcore.DataSourceConfig.fromCloudWatchLogs({
     *   logGroupNames: ['/aws/bedrock-agentcore/runtimes/myRuntime-abc123-DEFAULT'],
     *   serviceNames: ['myRuntime.DEFAULT'],
     * });
     */
    static fromCloudWatchLogs(config: CloudWatchLogsDataSourceConfig): DataSourceConfig;
    /**
     * Creates a data source configuration from an AgentCore Runtime and optional endpoint.
     *
     * This is the recommended way to configure evaluation for AgentCore Runtime agents.
     * It automatically derives the CloudWatch log group and service name from the runtime and endpoint.
     *
     * @param runtime - The AgentCore Runtime construct
     * @param endpoint - The RuntimeEndpoint construct. Defaults to 'DEFAULT' endpoint if not provided.
     * @returns A DataSourceConfig instance
     *
     * @example
     * // Using default endpoint
     * declare const runtime: agentcore.Runtime;
     * const dataSource = agentcore.DataSourceConfig.fromAgentRuntimeEndpoint(runtime);
     *
     * @example
     * // Using a specific endpoint
     * declare const runtime: agentcore.Runtime;
     * const endpoint = runtime.addEndpoint('PROD');
     * const dataSource = agentcore.DataSourceConfig.fromAgentRuntimeEndpoint(runtime, endpoint);
     */
    static fromAgentRuntimeEndpoint(runtime: IBedrockAgentRuntime, endpoint?: IRuntimeEndpoint): DataSourceConfig;
    /**
     * Creates a data source configuration from an AgentCore Runtime and an endpoint name string.
     *
     * Use this method when you want to reference an endpoint by name without
     * having a construct reference. For construct references, prefer `fromAgentRuntimeEndpoint()`.
     *
     * @param runtime - The AgentCore Runtime construct
     * @param endpointName - The name of the runtime endpoint
     * @returns A DataSourceConfig instance
     *
     * @example
     * declare const runtime: agentcore.Runtime;
     * const dataSource = agentcore.DataSourceConfig.fromAgentRuntimeEndpointName(runtime, 'PROD');
     */
    static fromAgentRuntimeEndpointName(runtime: IBedrockAgentRuntime, endpointName: string): DataSourceConfig;
    private static buildFromRuntime;
    /**
     * The CloudWatch Logs configuration.
     */
    readonly cloudWatchLogsConfig: CloudWatchLogsDataSourceConfig;
    private constructor();
    /**
     * Binds the data source configuration to produce the L1 property.
     */
    bind(): DataSourceConfigBindResult;
}
