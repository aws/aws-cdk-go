/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import type { DataSourceConfig } from './data-source';
import type { EvaluatorReference } from './evaluator';
import { type IOnlineEvaluationConfig, OnlineEvaluationBase } from './online-evaluation-base';
import { type OnlineEvaluationBaseProps, type OnlineEvaluationConfigAttributes } from './types';
/**
 * Properties for creating an OnlineEvaluationConfig.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface OnlineEvaluationConfigProps extends OnlineEvaluationBaseProps {
    /**
     * The list of evaluators to apply during online evaluation.
     *
     * Can include both built-in evaluators and custom evaluators.
     *
     * @minimum 1
     * @maximum 10
     */
    readonly evaluators: EvaluatorReference[];
    /**
     * The data source configuration that specifies where to read agent traces from.
     */
    readonly dataSource: DataSourceConfig;
    /**
     * Tags for the online evaluation configuration.
     * A list of key:value pairs of tags to apply to this OnlineEvaluationConfig resource.
     *
     * @default - No tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Online evaluation configuration for Amazon Bedrock AgentCore.
 *
 * Enables continuous evaluation of agent performance using built-in or custom evaluators.
 * Supports CloudWatch Logs and Agent Endpoint data sources.
 *
 * @resource AWS::BedrockAgentCore::OnlineEvaluationConfig
 *
 * @example
 * // Basic usage with built-in evaluators
 * const evaluation = new agentcore.OnlineEvaluationConfig(this, 'MyEvaluation', {
 *   onlineEvaluationConfigName: 'my_evaluation',
 *   evaluators: [
 *     agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.HELPFULNESS),
 *     agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.CORRECTNESS),
 *   ],
 *   dataSource: agentcore.DataSourceConfig.fromCloudWatchLogs({
 *     logGroupNames: ['/aws/bedrock-agentcore/my-agent'],
 *     serviceNames: ['my-agent.default'],
 *   }),
 * });
 */
export declare class OnlineEvaluationConfig extends OnlineEvaluationBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing OnlineEvaluationConfig by its ID.
     *
     * @param scope - The construct scope
     * @param id - Construct identifier
     * @param onlineEvaluationConfigId - The configuration ID to import
     * @returns An IOnlineEvaluationConfig reference
     */
    static fromOnlineEvaluationConfigId(scope: Construct, id: string, onlineEvaluationConfigId: string): IOnlineEvaluationConfig;
    /**
     * Import an existing OnlineEvaluationConfig by its ARN.
     *
     * @param scope - The construct scope
     * @param id - Construct identifier
     * @param onlineEvaluationConfigArn - The configuration ARN to import
     * @returns An IOnlineEvaluationConfig reference
     */
    static fromOnlineEvaluationConfigArn(scope: Construct, id: string, onlineEvaluationConfigArn: string): IOnlineEvaluationConfig;
    /**
     * Import an existing OnlineEvaluationConfig from its attributes.
     *
     * @param scope - The construct scope
     * @param id - Construct identifier
     * @param attrs - The configuration attributes
     * @returns An IOnlineEvaluationConfig reference
     */
    static fromOnlineEvaluationConfigAttributes(scope: Construct, id: string, attrs: OnlineEvaluationConfigAttributes): IOnlineEvaluationConfig;
    /**
     * The ARN of the online evaluation configuration.
     * @attribute
     */
    readonly onlineEvaluationConfigArn: string;
    /**
     * The unique identifier of the online evaluation configuration.
     * @attribute
     */
    readonly onlineEvaluationConfigId: string;
    /**
     * The name of the online evaluation configuration.
     * @attribute
     */
    readonly onlineEvaluationConfigName: string;
    /**
     * The IAM execution role for the evaluation.
     */
    readonly executionRole?: iam.IRole;
    /**
     * The lifecycle status of the configuration.
     * @attribute
     */
    readonly status?: string;
    /**
     * The execution status of the evaluation (ENABLED or DISABLED).
     */
    readonly executionStatus?: string;
    /**
     * The timestamp when the configuration was created.
     * @attribute
     */
    readonly createdAt?: string;
    /**
     * The timestamp when the configuration was last updated.
     * @attribute
     */
    readonly updatedAt?: string;
    /**
     * The principal to grant permissions to.
     */
    readonly grantPrincipal: iam.IPrincipal;
    constructor(scope: Construct, id: string, props: OnlineEvaluationConfigProps);
    private createExecutionRole;
    private buildRuleConfig;
}
