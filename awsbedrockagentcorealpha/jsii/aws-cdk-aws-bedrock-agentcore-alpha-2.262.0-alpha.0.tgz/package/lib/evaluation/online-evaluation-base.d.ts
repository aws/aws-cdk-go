/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import { Resource, type IResource, type ResourceProps } from 'aws-cdk-lib';
import type { IOnlineEvaluationConfigRef, OnlineEvaluationConfigReference } from 'aws-cdk-lib/aws-bedrockagentcore';
import * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
/**
 * Interface for OnlineEvaluationConfig resources.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface IOnlineEvaluationConfig extends IResource, iam.IGrantable, IOnlineEvaluationConfigRef {
    /**
     * The ARN of the online evaluation configuration.
     * @attribute
     */
    readonly onlineEvaluationConfigArn: string;
    /**
     * The unique identifier of the online evaluation configuration.
     * @attribute
     */
    readonly onlineEvaluationConfigId: string;
    /**
     * The name of the online evaluation configuration.
     * @attribute
     */
    readonly onlineEvaluationConfigName: string;
    /**
     * The IAM execution role for the evaluation.
     */
    readonly executionRole?: iam.IRole;
    /**
     * The lifecycle status of the configuration (CREATING, ACTIVE, FAILED, DELETING).
     * @attribute
     */
    readonly status?: string;
    /**
     * The execution status of the evaluation (ENABLED or DISABLED).
     */
    readonly executionStatus?: string;
    /**
     * The timestamp when the configuration was created.
     * @attribute
     */
    readonly createdAt?: string;
    /**
     * The timestamp when the configuration was last updated.
     * @attribute
     */
    readonly updatedAt?: string;
    /**
     * Grant the given principal identity permissions to perform actions on this configuration.
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
}
/**
 * Abstract base class for OnlineEvaluationConfig.
 * Contains methods and attributes valid for configurations either created with CDK or imported.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare abstract class OnlineEvaluationBase extends Resource implements IOnlineEvaluationConfig {
    abstract readonly onlineEvaluationConfigArn: string;
    abstract readonly onlineEvaluationConfigId: string;
    abstract readonly onlineEvaluationConfigName: string;
    abstract readonly executionRole?: iam.IRole;
    abstract readonly status?: string;
    abstract readonly executionStatus?: string;
    abstract readonly createdAt?: string;
    abstract readonly updatedAt?: string;
    /**
     * The principal to grant permissions to.
     */
    abstract readonly grantPrincipal: iam.IPrincipal;
    constructor(scope: Construct, id: string, props?: ResourceProps);
    /**
     * A reference to this OnlineEvaluationConfig resource.
     */
    get onlineEvaluationConfigRef(): OnlineEvaluationConfigReference;
    /**
     * Grants IAM actions to the IAM Principal.
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @param actions - The actions to grant
     * @returns An IAM Grant object representing the granted permissions
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
}
