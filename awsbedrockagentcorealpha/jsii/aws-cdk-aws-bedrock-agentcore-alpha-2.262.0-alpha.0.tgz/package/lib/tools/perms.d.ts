/******************************************************************************
 *                               BROWSER
 *****************************************************************************/
/**
 * Permissions for the Browser tool
 * See https://docs.aws.amazon.com/service-authorization/latest/reference/list_amazonbedrockagentcore.html
 */
/******************************************************************************
   *                         Data Plane Permissions
   *****************************************************************************/
/**
 * Permissions to manage a specific browser session
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const BROWSER_SESSION_PERMS: string[];
/**
 * Permissions to connect to a browser live view or automation stream
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const BROWSER_STREAM_PERMS: string[];
/******************************************************************************
   *                         Control Plane Permissions
   *****************************************************************************/
/**
 * Grants control plane operations to manage the browser (CRUD)
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const BROWSER_ADMIN_PERMS: string[];
/**
 * Permissions for reading browser information
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const BROWSER_READ_PERMS: string[];
/**
 * Permissions for listing browser resources
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const BROWSER_LIST_PERMS: string[];
/**
 * Permissions for using browser functionality
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const BROWSER_USE_PERMS: string[];
/******************************************************************************
 *                               CODE INTERPRETER
 *****************************************************************************/
/**
 * Permissions for the Code Interpreter tool
 * See https://docs.aws.amazon.com/service-authorization/latest/reference/list_amazonbedrockagentcore.html
 */
/******************************************************************************
   *                         Data Plane Permissions
   *****************************************************************************/
/**
 * Permissions to manage a specific code interpreter session
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const CODE_INTERPRETER_SESSION_PERMS: string[];
/**
 * Permissions to invoke a code interpreter
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const CODE_INTERPRETER_INVOKE_PERMS: string[];
/******************************************************************************
   *                         Control Plane Permissions
   *****************************************************************************/
/**
 * Grants control plane operations to manage the code interpreter (CRUD)
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const CODE_INTERPRETER_ADMIN_PERMS: string[];
/**
 * Permissions for reading code interpreter information
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const CODE_INTERPRETER_READ_PERMS: string[];
/**
 * Permissions for listing code interpreter resources
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const CODE_INTERPRETER_LIST_PERMS: string[];
/**
 * Permissions for using code interpreter functionality
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare const CODE_INTERPRETER_USE_PERMS: string[];
