import type { IResource, ResourceProps } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { ICodeInterpreterCustomRef, CodeInterpreterCustomReference } from 'aws-cdk-lib/aws-bedrockagentcore';
import type { DimensionsMap, MetricOptions } from 'aws-cdk-lib/aws-cloudwatch';
import { Metric } from 'aws-cdk-lib/aws-cloudwatch';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import { CodeInterpreterNetworkConfiguration } from '../network/network-configuration';
/******************************************************************************
 *                                Interface
 *****************************************************************************/
/**
 * Interface for CodeInterpreterCustom resources
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface ICodeInterpreterCustom extends IResource, iam.IGrantable, ec2.IConnectable, ICodeInterpreterCustomRef {
    /**
     * The ARN of the code interpreter resource
     * @attribute
     */
    readonly codeInterpreterArn: string;
    /**
     * The id of the code interpreter
     * @attribute
     */
    readonly codeInterpreterId: string;
    /**
     * The status of the code interpreter
     * @attribute
     */
    readonly status?: string;
    /**
     * Timestamp when the code interpreter was created
     * @attribute
     */
    readonly createdAt?: string;
    /**
     * Timestamp when the code interpreter was last updated
     * @attribute
     */
    readonly lastUpdatedAt?: string;
    /**
     * The IAM role that provides permissions for the code interpreter to access AWS services.
     */
    readonly executionRole: iam.IRole;
    /**
     *  Grants IAM actions to the IAM Principal
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grants `Get` and `List` actions on the Code Interpreter
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grants `Invoke`, `Start`, and `Stop` actions on the Code Interpreter
     */
    grantUse(grantee: iam.IGrantable): iam.Grant;
    /**
     * Return the given named metric for this code interpreter.
     */
    metric(metricName: string, dimensions: DimensionsMap, props?: MetricOptions): Metric;
    /**
     * Return the given named metric related to the API operation performed on this code interpreter.
     */
    metricForApiOperation(metricName: string, operation: string, props?: MetricOptions): Metric;
    /**
     * Return a metric measuring the latency of a specific API operation performed on this code interpreter.
     */
    metricLatencyForApiOperation(operation: string, props?: MetricOptions): Metric;
    /**
     * Return a metric containing the total number of API requests made for a specific code interpreter operation.
     */
    metricInvocationsForApiOperation(operation: string, props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of errors for a specific API operation performed on this code interpreter.
     */
    metricErrorsForApiOperation(operation: string, props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of throttled requests for a specific API operation performed on this code interpreter.
     */
    metricThrottlesForApiOperation(operation: string, props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of system errors for a specific API operation performed on this code interpreter.
     */
    metricSystemErrorsForApiOperation(operation: string, props?: MetricOptions): Metric;
    /**
     * Return a metric containing the number of user errors for a specific API operation performed on this code interpreter.
     */
    metricUserErrorsForApiOperation(operation: string, props?: MetricOptions): Metric;
    /**
     * Return a metric measuring the duration of code interpreter sessions.
     */
    metricSessionDuration(props?: MetricOptions): Metric;
}
/******************************************************************************
 *                        ABSTRACT BASE CLASS
 *****************************************************************************/
/**
 * Abstract base class for a Code Interpreter.
 * Contains methods and attributes valid for Code Interpreters either created with CDK or imported.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export declare abstract class CodeInterpreterCustomBase extends Resource implements ICodeInterpreterCustom {
    abstract readonly codeInterpreterArn: string;
    abstract readonly codeInterpreterId: string;
    abstract readonly status?: string;
    abstract readonly createdAt?: string;
    abstract readonly lastUpdatedAt?: string;
    abstract readonly executionRole: iam.IRole;
    /**
     * The principal to grant permissions to
     */
    abstract readonly grantPrincipal: iam.IPrincipal;
    /**
     * A reference to a CodeInterpreterCustom resource.
     */
    get codeInterpreterCustomRef(): CodeInterpreterCustomReference;
    /**
     * An accessor for the Connections object that will fail if this Browser does not have a VPC
     * configured.
     */
    get connections(): ec2.Connections;
    /**
     * The actual Connections object for this Browser. This may be unset in the event that a VPC has not
     * been configured.
     * @internal
     */
    protected _connections: ec2.Connections | undefined;
    constructor(scope: Construct, id: string, props?: ResourceProps);
    /**
     * Grants IAM actions to the IAM Principal
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @param actions - The actions to grant
     * @returns An IAM Grant object representing the granted permissions
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grant read permissions on this code interpreter to an IAM principal.
     * This includes both read permissions on the specific code interpreter and list permissions on all code interpreters.
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant read permissions to
     * @default - Default grant configuration:
     * - actions: ['bedrock-agentcore:GetCodeInterpreter', 'bedrock-agentcore:GetCodeInterpreterSession'] on this.codeInterpreterArn
     * - actions: ['bedrock-agentcore:ListCodeInterpreters', 'bedrock-agentcore:ListCodeInterpreterSessions'] on all resources (*)
     * @returns An IAM Grant object representing the granted permissions
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant invoke permissions on this code interpreter to an IAM principal.
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant invoke permissions to
     * @default - Default grant configuration:
     * - actions: ['bedrock-agentcore:StartCodeInterpreterSession', 'bedrock-agentcore:InvokeCodeInterpreter', 'bedrock-agentcore:StopCodeInterpreterSession']
     * - resourceArns: [this.codeInterpreterArn]
     * @returns An IAM Grant object representing the granted permissions
     */
    grantUse(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant invoke permissions on this code interpreter to an IAM principal.
     *
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant invoke permissions to
     * @returns An IAM Grant object representing the granted permissions
     * @default - Default grant configuration:
     * - actions: ['bedrock-agentcore:InvokeCodeInterpreter']
     * - resourceArns: [this.codeInterpreterArn]
     */
    grantInvoke(grantee: iam.IGrantable): iam.Grant;
    /**
     * Return the given named metric for this code interpreter.
     *
     * By default, the metric will be calculated as a sum over a period of 5 minutes.
     * You can customize this by using the `statistic` and `period` properties.
     */
    metric(metricName: string, dimensions: DimensionsMap, props?: MetricOptions): Metric;
    /**
     * Creates a CloudWatch metric for tracking code interpreter api operations..
     *
     * @param props - Configuration options for the metric
     * @default - Default metric configuration:
     * - namespace: 'AWS/Bedrock-AgentCore'
     * - metricName: metricName
     * - dimensionsMap: { CodeInterpreterId: this.codeInterpreterId }
     * @returns A CloudWatch Metric configured for code interpreter api operations
     */
    metricForApiOperation(metricName: string, operation: string, props?: MetricOptions): Metric;
    /**
     * Creates a CloudWatch metric for tracking code interpreter latencies.
     *
     * @param props - Configuration options for the metric
     * @default - Default metric configuration:
     * - namespace: 'AWS/Bedrock-AgentCore'
     * - metricName: Latency
     * @returns A CloudWatch Metric configured for code interpreter latencies
     */
    metricLatencyForApiOperation(operation: string, props?: MetricOptions): Metric;
    /**
     * Creates a CloudWatch metric for tracking code interpreter invocations.
     *
     * @param props - Configuration options for the metric
     * @default - Default metric configuration:
     * - namespace: 'AWS/Bedrock-AgentCore'
     * - metricName: Invocations
     * @returns A CloudWatch Metric configured for code interpreter invocations
     */
    metricInvocationsForApiOperation(operation: string, props?: MetricOptions): Metric;
    /**
     * Creates a CloudWatch metric for tracking code interpreter errors.
     *
     * @param props - Configuration options for the metric
     * @default - Default metric configuration:
     * - namespace: 'AWS/Bedrock-AgentCore'
     * - metricName: Errors
     * @returns A CloudWatch Metric configured for code interpreter errors
     */
    metricErrorsForApiOperation(operation: string, props?: MetricOptions): Metric;
    /**
     * Creates a CloudWatch metric for tracking code interpreter throttles.
     *
     * @param props - Configuration options for the metric
     * @default - Default metric configuration:
     * - namespace: 'AWS/Bedrock-AgentCore'
     * - metricName: Throttles
     * @returns A CloudWatch Metric configured for code interpreter throttles
     */
    metricThrottlesForApiOperation(operation: string, props?: MetricOptions): Metric;
    /**
     * Creates a CloudWatch metric for tracking code interpreter system errors.
     *
     * @param props - Configuration options for the metric
     * @default - Default metric configuration:
     * - namespace: 'AWS/Bedrock-AgentCore'
     * - metricName: SystemErrors
     * @returns A CloudWatch Metric configured for code interpreter system errors
     */
    metricSystemErrorsForApiOperation(operation: string, props?: MetricOptions): Metric;
    /**
     * Creates a CloudWatch metric for tracking code interpreter user errors.
     *
     * @param props - Configuration options for the metric
     * @default - Default metric configuration:
     * - namespace: 'AWS/Bedrock-AgentCore'
     * - metricName: UserErrors
     * @returns A CloudWatch Metric configured for code interpreter user errors
     */
    metricUserErrorsForApiOperation(operation: string, props?: MetricOptions): Metric;
    /**
     * Creates a CloudWatch metric for tracking code interpreter session duration.
     *
     * @param props - Configuration options for the metric
     * @default - Default metric configuration:
     * - namespace: 'AWS/Bedrock-AgentCore'
     * - metricName: Duration
     * @returns A CloudWatch Metric configured for code interpreter session duration
     */
    metricSessionDuration(props?: MetricOptions): Metric;
    /**
     * Internal method to create a metric.
     *
     * @param props - Configuration options for the metric
     * @returns A CloudWatch Metric configured for code interpreter api operations
     */
    private configureMetric;
}
/******************************************************************************
 *                        PROPS FOR NEW CONSTRUCT
 *****************************************************************************/
/**
 * Properties for creating a CodeInterpreter resource
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface CodeInterpreterCustomProps {
    /**
     * The name of the code interpreter
     * Valid characters are a-z, A-Z, 0-9, _ (underscore)
     * The name must start with a letter and can be up to 48 characters long
     * Pattern: [a-zA-Z][a-zA-Z0-9_]{0,47}
     * @default - auto generate
     */
    readonly codeInterpreterCustomName?: string;
    /**
     * Optional description for the code interpreter
     * Valid characters are a-z, A-Z, 0-9, _ (underscore), - (hyphen) and spaces
     * The description can have up to 200 characters
     * @default - No description
     * @required - No
     */
    readonly description?: string;
    /**
     * The IAM role that provides permissions for the code interpreter to access AWS services.
     *
     * @default - A new role will be created.
     * @required - No
     */
    readonly executionRole?: iam.IRole;
    /**
     * Network configuration for code interpreter
     * @required - No
     * @default - PUBLIC network mode
     */
    readonly networkConfiguration?: CodeInterpreterNetworkConfiguration;
    /**
     * Tags (optional)
     * A list of key:value pairs of tags to apply to this Code Interpreter resource
     *
     * @default {} - no tags
     * @required - No
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/******************************************************************************
 *                      ATTRS FOR IMPORTED CONSTRUCT
 *****************************************************************************/
/**
 * Attributes for specifying an imported Code Interpreter Custom.
 * @deprecated Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.
 */
export interface CodeInterpreterCustomAttributes {
    /**
     * The ARN of the agent.
     * @attribute
     */
    readonly codeInterpreterArn: string;
    /**
     * The ARN of the IAM role associated to the code interpreter.
     * @attribute
     */
    readonly roleArn: string;
    /**
     * When this code interpreter was last updated.
     * @default undefined - No last updated timestamp is provided
     */
    readonly lastUpdatedAt?: string;
    /**
     * The status of the code interpreter.
     * @default undefined - No status is provided
     */
    readonly status?: string;
    /**
     * The created timestamp of the code interpreter.
     * @default undefined - No created timestamp is provided
     */
    readonly createdAt?: string;
    /**
     * The security groups for this code interpreter, if in a VPC.
     *
     * @default - By default, the code interpreter is not in a VPC.
     */
    readonly securityGroups?: ec2.ISecurityGroup[];
}
/******************************************************************************
 *                                Class
 *****************************************************************************/
/**
 * Custom code interpreter resource for AWS Bedrock Agent Core.
 * Provides a sandboxed environment for code execution with configurable network access.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/code-interpreter.html
 * @resource AWS::BedrockAgentCore::CodeInterpreterCustom
 */
export declare class CodeInterpreterCustom extends CodeInterpreterCustomBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Static Method for importing an existing Bedrock AgentCore Code Interpreter Custom.
     */
    /**
     * Creates an Code Interpreter Custom reference from an existing code interpreter's attributes.
     *
     * @param scope - The construct scope
     * @param id - Identifier of the construct
     * @param attrs - Attributes of the existing code interpreter custom
     * @returns An ICodeInterpreterCustom reference to the existing code interpreter
     */
    static fromCodeInterpreterCustomAttributes(scope: Construct, id: string, attrs: CodeInterpreterCustomAttributes): ICodeInterpreterCustom;
    /**
     * The ARN of the code interpreter resource
     * @attribute
     */
    readonly codeInterpreterArn: string;
    /**
     * The id of the code interpreter
     * @attribute
     */
    readonly codeInterpreterId: string;
    /**
     * The name of the code interpreter
     */
    readonly name: string;
    /**
     * The description of the code interpreter
     */
    readonly description?: string;
    /**
     * The network configuration of the code interpreter
     */
    readonly networkConfiguration: CodeInterpreterNetworkConfiguration;
    /**
     * The status of the code interpreter
     * @attribute
     */
    readonly status?: string;
    /**
     * The created timestamp of the code interpreter
     * @attribute
     */
    readonly createdAt?: string;
    /**
     * The last updated timestamp of the code interpreter
     * @attribute
     */
    readonly lastUpdatedAt?: string;
    /**
     * The failure reason of the code interpreter
     * @attribute
     */
    readonly failureReason?: string;
    /**
     * The IAM role that provides permissions for the code interpreter to access AWS services.
     */
    readonly executionRole: iam.IRole;
    /**
     * The principal to grant permissions to
     */
    readonly grantPrincipal: iam.IPrincipal;
    /**
     * Tags applied to this code interpreter resource
     * A map of key-value pairs for resource tagging
     * @default - No tags applied
     */
    readonly tags?: {
        [key: string]: string;
    };
    private readonly __resource;
    constructor(scope: Construct, id: string, props?: CodeInterpreterCustomProps);
    /**
     * Validates the code interpreter name format
     * @param name The code interpreter name to validate
     * @returns Array of validation error messages, empty if valid
     * @internal This is an internal core function and should not be called directly.
     */
    private _validateCodeInterpreterName;
    /**
     * Validates the code interpreter tags format
     * @param tags The tags object to validate
     * @returns Array of validation error messages, empty if valid
     * @internal This is an internal core function and should not be called directly.
     */
    private _validateCodeInterpreterTags;
    /**
     * Creates execution role needed for the code interpreter to access AWS services
     * @returns The created role
     * @internal This is an internal core function and should not be called directly.
     */
    private _createCodeInterpreterRole;
}
