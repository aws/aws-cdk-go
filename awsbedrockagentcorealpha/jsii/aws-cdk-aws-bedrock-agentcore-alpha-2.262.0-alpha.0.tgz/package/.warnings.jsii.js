const VALIDATORS = { _aws_cdk_aws_bedrock_agentcore_alpha_MemoryProps: function _aws_cdk_aws_bedrock_agentcore_alpha_MemoryProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("executionRole" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryProps#executionRole", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("expirationDuration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryProps#expirationDuration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("kmsKey" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryProps#kmsKey", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("memoryName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryProps#memoryName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("memoryStrategies" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryProps#memoryStrategies", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.memoryStrategies != null)
                for (const o of p.memoryStrategies)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_IMemoryStrategy(o);
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_MemoryAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_MemoryAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("memoryArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryAttributes#memoryArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("roleArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryAttributes#roleArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("createdAt" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryAttributes#createdAt", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("kmsKeyArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryAttributes#kmsKeyArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("status" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryAttributes#status", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("updatedAt" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryAttributes#updatedAt", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OverrideConfig: function _aws_cdk_aws_bedrock_agentcore_alpha_OverrideConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("appendToPrompt" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OverrideConfig#appendToPrompt", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("model" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OverrideConfig#model", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_EpisodicReflectionConfiguration: function _aws_cdk_aws_bedrock_agentcore_alpha_EpisodicReflectionConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("namespaces" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.EpisodicReflectionConfiguration#namespaces", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ManagedStrategyProps: function _aws_cdk_aws_bedrock_agentcore_alpha_ManagedStrategyProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("namespaces" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ManagedStrategyProps#namespaces", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("customConsolidation" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ManagedStrategyProps#customConsolidation", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.customConsolidation))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_OverrideConfig(p.customConsolidation);
            if ("customExtraction" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ManagedStrategyProps#customExtraction", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.customExtraction))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_OverrideConfig(p.customExtraction);
            if ("reflectionConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ManagedStrategyProps#reflectionConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.reflectionConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_EpisodicReflectionConfiguration(p.reflectionConfiguration);
            if ("name" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryStrategyCommonProps#name", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryStrategyCommonProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_TriggerConditions: function _aws_cdk_aws_bedrock_agentcore_alpha_TriggerConditions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("messageBasedTrigger" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.TriggerConditions#messageBasedTrigger", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("timeBasedTrigger" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.TriggerConditions#timeBasedTrigger", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tokenBasedTrigger" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.TriggerConditions#tokenBasedTrigger", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_InvocationConfiguration: function _aws_cdk_aws_bedrock_agentcore_alpha_InvocationConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("s3Location" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.InvocationConfiguration#s3Location", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("topic" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.InvocationConfiguration#topic", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_SelfManagedStrategyProps: function _aws_cdk_aws_bedrock_agentcore_alpha_SelfManagedStrategyProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("invocationConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SelfManagedStrategyProps#invocationConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.invocationConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_InvocationConfiguration(p.invocationConfiguration);
            if ("historicalContextWindowSize" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SelfManagedStrategyProps#historicalContextWindowSize", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("triggerConditions" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SelfManagedStrategyProps#triggerConditions", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.triggerConditions))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_TriggerConditions(p.triggerConditions);
            if ("name" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryStrategyCommonProps#name", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryStrategyCommonProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_MemoryStrategyType: function _aws_cdk_aws_bedrock_agentcore_alpha_MemoryStrategyType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryStrategyType", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "SUMMARIZATION")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryStrategyType#SUMMARIZATION", "");
            if (p === "SEMANTIC")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryStrategyType#SEMANTIC", "");
            if (p === "USER_PREFERENCE")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryStrategyType#USER_PREFERENCE", "");
            if (p === "EPISODIC")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryStrategyType#EPISODIC", "");
            if (p === "CUSTOM")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryStrategyType#CUSTOM", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_MemoryStrategyCommonProps: function _aws_cdk_aws_bedrock_agentcore_alpha_MemoryStrategyCommonProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("name" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryStrategyCommonProps#name", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MemoryStrategyCommonProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayApiKeyIdentityBinding: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayApiKeyIdentityBinding(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("providerArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayApiKeyIdentityBinding#providerArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("secretArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayApiKeyIdentityBinding#secretArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyCredentialProviderResourceProps: function _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyCredentialProviderResourceProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("apiKey" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiKeyCredentialProviderResourceProps#apiKey", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("apiKeyCredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiKeyCredentialProviderResourceProps#apiKeyCredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiKeyCredentialProviderResourceProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyCredentialProviderAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyCredentialProviderAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("credentialProviderArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiKeyCredentialProviderAttributes#credentialProviderArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("apiKeySecretArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiKeyCredentialProviderAttributes#apiKeySecretArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("createdTime" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiKeyCredentialProviderAttributes#createdTime", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("lastUpdatedTime" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiKeyCredentialProviderAttributes#lastUpdatedTime", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2CredentialProviderVendor: function _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2CredentialProviderVendor(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "GoogleOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#GOOGLE", "");
            if (p === "GithubOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#GITHUB", "");
            if (p === "SlackOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#SLACK", "");
            if (p === "SalesforceOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#SALESFORCE", "");
            if (p === "MicrosoftOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#MICROSOFT", "");
            if (p === "CustomOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#CUSTOM", "");
            if (p === "AtlassianOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#ATLASSIAN", "");
            if (p === "LinkedinOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#LINKEDIN", "");
            if (p === "XOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#X", "");
            if (p === "OktaOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#OKTA", "");
            if (p === "OneLoginOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#ONE_LOGIN", "");
            if (p === "PingOneOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#PING_ONE", "");
            if (p === "FacebookOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#FACEBOOK", "");
            if (p === "YandexOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#YANDEX", "");
            if (p === "RedditOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#REDDIT", "");
            if (p === "ZoomOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#ZOOM", "");
            if (p === "TwitchOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#TWITCH", "");
            if (p === "SpotifyOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#SPOTIFY", "");
            if (p === "DropboxOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#DROPBOX", "");
            if (p === "NotionOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#NOTION", "");
            if (p === "HubspotOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#HUBSPOT", "");
            if (p === "CyberArkOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#CYBER_ARK", "");
            if (p === "FusionAuthOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#FUSION_AUTH", "");
            if (p === "Auth0Oauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#AUTH0", "");
            if (p === "CognitoOauth2")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderVendor#COGNITO", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayOAuth2IdentityBinding: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayOAuth2IdentityBinding(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("providerArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayOAuth2IdentityBinding#providerArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("scopes" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayOAuth2IdentityBinding#scopes", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("secretArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayOAuth2IdentityBinding#secretArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("customParameters" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayOAuth2IdentityBinding#customParameters", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2CredentialProviderBaseProps: function _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2CredentialProviderBaseProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2ClientCredentials: function _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2ClientCredentials(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2CredentialProviderFactoryBaseProps: function _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2CredentialProviderFactoryBaseProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_SlackOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_SlackOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GithubOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_GithubOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GoogleOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_GoogleOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_SalesforceOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_SalesforceOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_MicrosoftOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_MicrosoftOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("tenantId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MicrosoftOAuth2CredentialProviderProps#tenantId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_AtlassianOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_AtlassianOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_LinkedinOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_LinkedinOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_FacebookOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_FacebookOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_XOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_XOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_YandexOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_YandexOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_RedditOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_RedditOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ZoomOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_ZoomOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_TwitchOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_TwitchOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_SpotifyOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_SpotifyOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_DropboxOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_DropboxOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_NotionOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_NotionOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_HubspotOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_HubspotOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_IncludedOauth2TenantEndpoints: function _aws_cdk_aws_bedrock_agentcore_alpha_IncludedOauth2TenantEndpoints(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("authorizationEndpoint" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.IncludedOauth2TenantEndpoints#authorizationEndpoint", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("issuer" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.IncludedOauth2TenantEndpoints#issuer", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tokenEndpoint" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.IncludedOauth2TenantEndpoints#tokenEndpoint", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_IncludedOauth2TenantCredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_IncludedOauth2TenantCredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("authorizationEndpoint" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.IncludedOauth2TenantEndpoints#authorizationEndpoint", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("issuer" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.IncludedOauth2TenantEndpoints#issuer", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tokenEndpoint" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.IncludedOauth2TenantEndpoints#tokenEndpoint", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2AuthorizationServerMetadata: function _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2AuthorizationServerMetadata(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("authorizationEndpoint" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2AuthorizationServerMetadata#authorizationEndpoint", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("issuer" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2AuthorizationServerMetadata#issuer", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tokenEndpoint" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2AuthorizationServerMetadata#tokenEndpoint", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("responseTypes" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2AuthorizationServerMetadata#responseTypes", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CustomOAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_CustomOAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("authorizationServerMetadata" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CustomOAuth2CredentialProviderProps#authorizationServerMetadata", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.authorizationServerMetadata))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_OAuth2AuthorizationServerMetadata(p.authorizationServerMetadata);
            if ("discoveryUrl" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CustomOAuth2CredentialProviderProps#discoveryUrl", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderBaseProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecret" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2ClientCredentials#clientSecret", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2CredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2CredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("credentialProviderVendor" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderProps#credentialProviderVendor", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("oauth2ProviderConfigInput" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderProps#oauth2ProviderConfigInput", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("oAuth2CredentialProviderName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderProps#oAuth2CredentialProviderName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2CredentialProviderAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_OAuth2CredentialProviderAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("credentialProviderArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderAttributes#credentialProviderArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("credentialProviderVendor" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderAttributes#credentialProviderVendor", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("callbackUrl" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderAttributes#callbackUrl", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("clientSecretArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderAttributes#clientSecretArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("createdTime" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderAttributes#createdTime", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("lastUpdatedTime" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuth2CredentialProviderAttributes#lastUpdatedTime", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_WorkloadIdentityProps: function _aws_cdk_aws_bedrock_agentcore_alpha_WorkloadIdentityProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("allowedResourceOauth2ReturnUrls" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.WorkloadIdentityProps#allowedResourceOauth2ReturnUrls", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.WorkloadIdentityProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("workloadIdentityName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.WorkloadIdentityProps#workloadIdentityName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_WorkloadIdentityAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_WorkloadIdentityAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("workloadIdentityArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.WorkloadIdentityAttributes#workloadIdentityArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("workloadIdentityName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.WorkloadIdentityAttributes#workloadIdentityName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("createdTime" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.WorkloadIdentityAttributes#createdTime", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("lastUpdatedTime" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.WorkloadIdentityAttributes#lastUpdatedTime", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_VpcConfigProps: function _aws_cdk_aws_bedrock_agentcore_alpha_VpcConfigProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("vpc" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.VpcConfigProps#vpc", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("allowAllOutbound" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.VpcConfigProps#allowAllOutbound", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("securityGroups" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.VpcConfigProps#securityGroups", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
            if ("vpcSubnets" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.VpcConfigProps#vpcSubnets", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CustomClaimOperator: function _aws_cdk_aws_bedrock_agentcore_alpha_CustomClaimOperator(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.CustomClaimOperator", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "EQUALS")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CustomClaimOperator#EQUALS", "");
            if (p === "CONTAINS")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CustomClaimOperator#CONTAINS", "");
            if (p === "CONTAINS_ANY")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CustomClaimOperator#CONTAINS_ANY", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ProtocolType: function _aws_cdk_aws_bedrock_agentcore_alpha_ProtocolType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.ProtocolType", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "MCP")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ProtocolType#MCP", "");
            if (p === "HTTP")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ProtocolType#HTTP", "");
            if (p === "A2A")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ProtocolType#A2A", "");
            if (p === "AGUI")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ProtocolType#AGUI", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_RequestHeaderConfiguration: function _aws_cdk_aws_bedrock_agentcore_alpha_RequestHeaderConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("allowlistedHeaders" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RequestHeaderConfiguration#allowlistedHeaders", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_LifecycleConfiguration: function _aws_cdk_aws_bedrock_agentcore_alpha_LifecycleConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("idleRuntimeSessionTimeout" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.LifecycleConfiguration#idleRuntimeSessionTimeout", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("maxLifetime" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.LifecycleConfiguration#maxLifetime", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_AgentRuntimeAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_AgentRuntimeAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("agentRuntimeArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentRuntimeAttributes#agentRuntimeArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("agentRuntimeId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentRuntimeAttributes#agentRuntimeId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("agentRuntimeName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentRuntimeAttributes#agentRuntimeName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("roleArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentRuntimeAttributes#roleArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("agentRuntimeVersion" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentRuntimeAttributes#agentRuntimeVersion", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("agentStatus" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentRuntimeAttributes#agentStatus", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("createdAt" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentRuntimeAttributes#createdAt", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentRuntimeAttributes#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("lastUpdatedAt" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentRuntimeAttributes#lastUpdatedAt", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("securityGroups" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentRuntimeAttributes#securityGroups", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_AgentCoreRuntime: function _aws_cdk_aws_bedrock_agentcore_alpha_AgentCoreRuntime(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentCoreRuntime", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "PYTHON_3_10")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentCoreRuntime#PYTHON_3_10", "");
            if (p === "PYTHON_3_11")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentCoreRuntime#PYTHON_3_11", "");
            if (p === "PYTHON_3_12")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentCoreRuntime#PYTHON_3_12", "");
            if (p === "PYTHON_3_13")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentCoreRuntime#PYTHON_3_13", "");
            if (p === "PYTHON_3_14")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentCoreRuntime#PYTHON_3_14", "");
            if (p === "NODE_22")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AgentCoreRuntime#NODE_22", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CodeAssetOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_CodeAssetOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("entrypoint" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeAssetOptions#entrypoint", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("path" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeAssetOptions#path", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("runtime" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeAssetOptions#runtime", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.runtime))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_AgentCoreRuntime(p.runtime);
            if (p.readers != null)
                for (const o of p.readers)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IGrantable(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeEndpointAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeEndpointAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("agentRuntimeArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointAttributes#agentRuntimeArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("agentRuntimeEndpointArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointAttributes#agentRuntimeEndpointArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("endpointName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointAttributes#endpointName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("createdAt" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointAttributes#createdAt", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointAttributes#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("endpointId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointAttributes#endpointId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("lastUpdatedAt" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointAttributes#lastUpdatedAt", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("liveVersion" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointAttributes#liveVersion", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("status" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointAttributes#status", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("targetVersion" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointAttributes#targetVersion", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeEndpointProps: function _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeEndpointProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("agentRuntimeId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointProps#agentRuntimeId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("agentRuntimeVersion" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointProps#agentRuntimeVersion", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("endpointName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointProps#endpointName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeEndpointProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeProps: function _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("agentRuntimeArtifact" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeProps#agentRuntimeArtifact", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.agentRuntimeArtifact))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_AgentRuntimeArtifact(p.agentRuntimeArtifact);
            if ("authorizerConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeProps#authorizerConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.authorizerConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_RuntimeAuthorizerConfiguration(p.authorizerConfiguration);
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("environmentVariables" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeProps#environmentVariables", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("executionRole" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeProps#executionRole", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("lifecycleConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeProps#lifecycleConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.lifecycleConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_LifecycleConfiguration(p.lifecycleConfiguration);
            if ("loggingConfigs" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeProps#loggingConfigs", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.loggingConfigs != null)
                for (const o of p.loggingConfigs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_LoggingConfig(o);
            if ("networkConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeProps#networkConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.networkConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_RuntimeNetworkConfiguration(p.networkConfiguration);
            if ("protocolConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeProps#protocolConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.protocolConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ProtocolType(p.protocolConfiguration);
            if ("requestHeaderConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeProps#requestHeaderConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.requestHeaderConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_RequestHeaderConfiguration(p.requestHeaderConfiguration);
            if ("runtimeName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeProps#runtimeName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tracingEnabled" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RuntimeProps#tracingEnabled", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_AddEndpointOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_AddEndpointOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddEndpointOptions#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("version" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddEndpointOptions#version", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_LoggingConfig: function _aws_cdk_aws_bedrock_agentcore_alpha_LoggingConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("destination" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.LoggingConfig#destination", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.destination))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_LoggingDestination(p.destination);
            if ("logType" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.LoggingConfig#logType", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.logType))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_LogType(p.logType);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustomProps: function _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustomProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("codeInterpreterCustomName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeInterpreterCustomProps#codeInterpreterCustomName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeInterpreterCustomProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("executionRole" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeInterpreterCustomProps#executionRole", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("networkConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeInterpreterCustomProps#networkConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.networkConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterNetworkConfiguration(p.networkConfiguration);
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeInterpreterCustomProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustomAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustomAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("codeInterpreterArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeInterpreterCustomAttributes#codeInterpreterArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("roleArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeInterpreterCustomAttributes#roleArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("createdAt" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeInterpreterCustomAttributes#createdAt", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("lastUpdatedAt" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeInterpreterCustomAttributes#lastUpdatedAt", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("securityGroups" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeInterpreterCustomAttributes#securityGroups", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
            if ("status" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeInterpreterCustomAttributes#status", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_BrowserSigning: function _aws_cdk_aws_bedrock_agentcore_alpha_BrowserSigning(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserSigning", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "ENABLED")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserSigning#ENABLED", "");
            if (p === "DISABLED")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserSigning#DISABLED", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_RecordingConfig: function _aws_cdk_aws_bedrock_agentcore_alpha_RecordingConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("enabled" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RecordingConfig#enabled", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("s3Location" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.RecordingConfig#s3Location", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomProps: function _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("browserCustomName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserCustomProps#browserCustomName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("browserSigning" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserCustomProps#browserSigning", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.browserSigning))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_BrowserSigning(p.browserSigning);
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserCustomProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("executionRole" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserCustomProps#executionRole", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("networkConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserCustomProps#networkConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.networkConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_BrowserNetworkConfiguration(p.networkConfiguration);
            if ("recordingConfig" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserCustomProps#recordingConfig", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.recordingConfig))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_RecordingConfig(p.recordingConfig);
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserCustomProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("browserArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserCustomAttributes#browserArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("roleArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserCustomAttributes#roleArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("createdAt" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserCustomAttributes#createdAt", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("lastUpdatedAt" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserCustomAttributes#lastUpdatedAt", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("securityGroups" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserCustomAttributes#securityGroups", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
            if ("status" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.BrowserCustomAttributes#status", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayExceptionLevel: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayExceptionLevel(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayExceptionLevel", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "DEBUG")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayExceptionLevel#DEBUG", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayPolicyEngineConfig: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayPolicyEngineConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("policyEngine" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayPolicyEngineConfig#policyEngine", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("mode" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayPolicyEngineConfig#mode", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.mode))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_PolicyEngineMode(p.mode);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_AddLambdaTargetOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_AddLambdaTargetOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("lambdaFunction" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddLambdaTargetOptions#lambdaFunction", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("toolSchema" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddLambdaTargetOptions#toolSchema", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.toolSchema))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ToolSchema(p.toolSchema);
            if ("credentialProviderConfigurations" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddLambdaTargetOptions#credentialProviderConfigurations", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddLambdaTargetOptions#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayTargetName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddLambdaTargetOptions#gatewayTargetName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_AddOpenApiTargetOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_AddOpenApiTargetOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("apiSchema" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddOpenApiTargetOptions#apiSchema", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.apiSchema))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ApiSchema(p.apiSchema);
            if ("credentialProviderConfigurations" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddOpenApiTargetOptions#credentialProviderConfigurations", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddOpenApiTargetOptions#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayTargetName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddOpenApiTargetOptions#gatewayTargetName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("validateOpenApiSchema" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddOpenApiTargetOptions#validateOpenApiSchema", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_AddSmithyTargetOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_AddSmithyTargetOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("smithyModel" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddSmithyTargetOptions#smithyModel", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.smithyModel))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ApiSchema(p.smithyModel);
            if ("credentialProviderConfigurations" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddSmithyTargetOptions#credentialProviderConfigurations", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddSmithyTargetOptions#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayTargetName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddSmithyTargetOptions#gatewayTargetName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_AddMcpServerTargetOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_AddMcpServerTargetOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("credentialProviderConfigurations" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddMcpServerTargetOptions#credentialProviderConfigurations", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
            if ("endpoint" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddMcpServerTargetOptions#endpoint", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddMcpServerTargetOptions#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayTargetName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddMcpServerTargetOptions#gatewayTargetName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_AddApiGatewayTargetOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_AddApiGatewayTargetOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("apiGatewayToolConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddApiGatewayTargetOptions#apiGatewayToolConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.apiGatewayToolConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolConfiguration(p.apiGatewayToolConfiguration);
            if ("restApi" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddApiGatewayTargetOptions#restApi", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("credentialProviderConfigurations" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddApiGatewayTargetOptions#credentialProviderConfigurations", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddApiGatewayTargetOptions#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayTargetName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddApiGatewayTargetOptions#gatewayTargetName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("metadataConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddApiGatewayTargetOptions#metadataConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.metadataConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_MetadataConfiguration(p.metadataConfiguration);
            if ("stage" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.AddApiGatewayTargetOptions#stage", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayProps: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("authorizerConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayProps#authorizerConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.authorizerConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_IGatewayAuthorizerConfig(p.authorizerConfiguration);
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("exceptionLevel" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayProps#exceptionLevel", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.exceptionLevel))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_GatewayExceptionLevel(p.exceptionLevel);
            if ("gatewayName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayProps#gatewayName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("interceptorConfigurations" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayProps#interceptorConfigurations", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.interceptorConfigurations != null)
                for (const o of p.interceptorConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_IInterceptor(o);
            if ("kmsKey" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayProps#kmsKey", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("policyEngineConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayProps#policyEngineConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.policyEngineConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_GatewayPolicyEngineConfig(p.policyEngineConfiguration);
            if ("protocolConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayProps#protocolConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.protocolConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_IGatewayProtocolConfig(p.protocolConfiguration);
            if ("role" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayProps#role", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("gatewayArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayAttributes#gatewayArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayAttributes#gatewayId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayAttributes#gatewayName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("role" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayAttributes#role", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_InterceptionPoint: function _aws_cdk_aws_bedrock_agentcore_alpha_InterceptionPoint(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.InterceptionPoint", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "REQUEST")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.InterceptionPoint#REQUEST", "");
            if (p === "RESPONSE")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.InterceptionPoint#RESPONSE", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_InterceptorOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_InterceptorOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("passRequestHeaders" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.InterceptorOptions#passRequestHeaders", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_InterceptorBindConfig: function _aws_cdk_aws_bedrock_agentcore_alpha_InterceptorBindConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("configuration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.InterceptorBindConfig#configuration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_MCPProtocolVersion: function _aws_cdk_aws_bedrock_agentcore_alpha_MCPProtocolVersion(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.MCPProtocolVersion", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "2025-06-18")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MCPProtocolVersion#MCP_2025_06_18", "");
            if (p === "2025-03-26")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MCPProtocolVersion#MCP_2025_03_26", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_McpGatewaySearchType: function _aws_cdk_aws_bedrock_agentcore_alpha_McpGatewaySearchType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.McpGatewaySearchType", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "SEMANTIC")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.McpGatewaySearchType#SEMANTIC", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_McpConfiguration: function _aws_cdk_aws_bedrock_agentcore_alpha_McpConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("instructions" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.McpConfiguration#instructions", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("searchType" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.McpConfiguration#searchType", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.searchType))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_McpGatewaySearchType(p.searchType);
            if ("supportedVersions" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.McpConfiguration#supportedVersions", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.supportedVersions != null)
                for (const o of p.supportedVersions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_MCPProtocolVersion(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayAuthorizerType: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayAuthorizerType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayAuthorizerType", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "CUSTOM_JWT")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayAuthorizerType#CUSTOM_JWT", "");
            if (p === "AWS_IAM")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayAuthorizerType#AWS_IAM", "");
            if (p === "NONE")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayAuthorizerType#NONE", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CustomJwtConfiguration: function _aws_cdk_aws_bedrock_agentcore_alpha_CustomJwtConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("discoveryUrl" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CustomJwtConfiguration#discoveryUrl", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("allowedAudience" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CustomJwtConfiguration#allowedAudience", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("allowedClients" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CustomJwtConfiguration#allowedClients", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("allowedScopes" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CustomJwtConfiguration#allowedScopes", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("customClaims" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CustomJwtConfiguration#customClaims", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.customClaims != null)
                for (const o of p.customClaims)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_GatewayCustomClaim(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CognitoAuthorizerProps: function _aws_cdk_aws_bedrock_agentcore_alpha_CognitoAuthorizerProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("userPool" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CognitoAuthorizerProps#userPool", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("allowedAudiences" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CognitoAuthorizerProps#allowedAudiences", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("allowedClients" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CognitoAuthorizerProps#allowedClients", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.allowedClients != null)
                for (const o of p.allowedClients)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_cognito_IUserPoolClient(o);
            if ("allowedScopes" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CognitoAuthorizerProps#allowedScopes", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("customClaims" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CognitoAuthorizerProps#customClaims", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.customClaims != null)
                for (const o of p.customClaims)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_GatewayCustomClaim(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CredentialProviderType: function _aws_cdk_aws_bedrock_agentcore_alpha_CredentialProviderType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.CredentialProviderType", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "API_KEY")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CredentialProviderType#API_KEY", "");
            if (p === "OAUTH")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CredentialProviderType#OAUTH", "");
            if (p === "GATEWAY_IAM_ROLE")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CredentialProviderType#GATEWAY_IAM_ROLE", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_FromApiKeyIdentityOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_FromApiKeyIdentityOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("credentialLocation" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.FromApiKeyIdentityOptions#credentialLocation", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.credentialLocation))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyCredentialLocation(p.credentialLocation);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_FromOauthIdentityOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_FromOauthIdentityOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("scopes" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.FromOauthIdentityOptions#scopes", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("customParameters" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.FromOauthIdentityOptions#customParameters", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyAdditionalConfiguration: function _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyAdditionalConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("credentialParameterName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiKeyAdditionalConfiguration#credentialParameterName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("credentialPrefix" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiKeyAdditionalConfiguration#credentialPrefix", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyCredentialProviderProps: function _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyCredentialProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("providerArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiKeyCredentialProviderProps#providerArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("secretArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiKeyCredentialProviderProps#secretArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("credentialLocation" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiKeyCredentialProviderProps#credentialLocation", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.credentialLocation))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyCredentialLocation(p.credentialLocation);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OAuthConfiguration: function _aws_cdk_aws_bedrock_agentcore_alpha_OAuthConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("providerArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuthConfiguration#providerArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("scopes" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuthConfiguration#scopes", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("secretArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuthConfiguration#secretArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("customParameters" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OAuthConfiguration#customParameters", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetProtocolType: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetProtocolType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetProtocolType", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "MCP")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetProtocolType#MCP", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_McpTargetType: function _aws_cdk_aws_bedrock_agentcore_alpha_McpTargetType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.McpTargetType", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "OPENAPI_SCHEMA")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.McpTargetType#OPENAPI_SCHEMA", "");
            if (p === "SMITHY_MODEL")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.McpTargetType#SMITHY_MODEL", "");
            if (p === "LAMBDA")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.McpTargetType#LAMBDA", "");
            if (p === "MCP_SERVER")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.McpTargetType#MCP_SERVER", "");
            if (p === "API_GATEWAY")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.McpTargetType#API_GATEWAY", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetCommonProps: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetCommonProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayTargetName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#gatewayTargetName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetProps: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("gateway" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetProps#gateway", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.gateway))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
            if ("targetConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetProps#targetConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.targetConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ITargetConfiguration(p.targetConfiguration);
            if ("credentialProviderConfigurations" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetProps#credentialProviderConfigurations", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayTargetName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#gatewayTargetName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetLambdaProps: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetLambdaProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("gateway" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetLambdaProps#gateway", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.gateway))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
            if ("lambdaFunction" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetLambdaProps#lambdaFunction", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("toolSchema" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetLambdaProps#toolSchema", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.toolSchema))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ToolSchema(p.toolSchema);
            if ("credentialProviderConfigurations" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetLambdaProps#credentialProviderConfigurations", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayTargetName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#gatewayTargetName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetOpenApiProps: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetOpenApiProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("apiSchema" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetOpenApiProps#apiSchema", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.apiSchema))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ApiSchema(p.apiSchema);
            if ("gateway" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetOpenApiProps#gateway", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.gateway))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
            if ("credentialProviderConfigurations" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetOpenApiProps#credentialProviderConfigurations", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
            if ("validateOpenApiSchema" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetOpenApiProps#validateOpenApiSchema", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayTargetName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#gatewayTargetName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetSmithyProps: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetSmithyProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("gateway" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetSmithyProps#gateway", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.gateway))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
            if ("smithyModel" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetSmithyProps#smithyModel", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.smithyModel))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ApiSchema(p.smithyModel);
            if ("credentialProviderConfigurations" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetSmithyProps#credentialProviderConfigurations", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayTargetName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#gatewayTargetName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetMcpServerProps: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetMcpServerProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("credentialProviderConfigurations" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetMcpServerProps#credentialProviderConfigurations", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
            if ("endpoint" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetMcpServerProps#endpoint", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gateway" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetMcpServerProps#gateway", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.gateway))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayTargetName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#gatewayTargetName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetApiGatewayProps: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetApiGatewayProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("apiGatewayToolConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetApiGatewayProps#apiGatewayToolConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.apiGatewayToolConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolConfiguration(p.apiGatewayToolConfiguration);
            if ("gateway" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetApiGatewayProps#gateway", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.gateway))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
            if ("restApi" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetApiGatewayProps#restApi", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("credentialProviderConfigurations" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetApiGatewayProps#credentialProviderConfigurations", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
            if ("metadataConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetApiGatewayProps#metadataConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.metadataConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_MetadataConfiguration(p.metadataConfiguration);
            if ("stage" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetApiGatewayProps#stage", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("gatewayTargetName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetCommonProps#gatewayTargetName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("gateway" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetAttributes#gateway", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.gateway))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
            if ("gatewayTargetName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetAttributes#gatewayTargetName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("targetArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetAttributes#targetArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("targetId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetAttributes#targetId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("createdAt" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetAttributes#createdAt", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("status" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetAttributes#status", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("updatedAt" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.GatewayTargetAttributes#updatedAt", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_TargetConfigurationConfig: function _aws_cdk_aws_bedrock_agentcore_alpha_TargetConfigurationConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("bound" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.TargetConfigurationConfig#bound", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayHttpMethod: function _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayHttpMethod(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayHttpMethod", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "GET")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayHttpMethod#GET", "");
            if (p === "POST")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayHttpMethod#POST", "");
            if (p === "PUT")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayHttpMethod#PUT", "");
            if (p === "DELETE")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayHttpMethod#DELETE", "");
            if (p === "PATCH")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayHttpMethod#PATCH", "");
            if (p === "HEAD")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayHttpMethod#HEAD", "");
            if (p === "OPTIONS")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayHttpMethod#OPTIONS", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolFilter: function _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolFilter(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("filterPath" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayToolFilter#filterPath", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("methods" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayToolFilter#methods", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.methods != null)
                for (const o of p.methods)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayHttpMethod(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolOverride: function _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolOverride(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("method" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayToolOverride#method", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.method))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayHttpMethod(p.method);
            if ("name" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayToolOverride#name", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("path" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayToolOverride#path", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayToolOverride#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_MetadataConfiguration: function _aws_cdk_aws_bedrock_agentcore_alpha_MetadataConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("allowedQueryParameters" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MetadataConfiguration#allowedQueryParameters", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("allowedRequestHeaders" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MetadataConfiguration#allowedRequestHeaders", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("allowedResponseHeaders" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.MetadataConfiguration#allowedResponseHeaders", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolConfiguration: function _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("toolFilters" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayToolConfiguration#toolFilters", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.toolFilters != null)
                for (const o of p.toolFilters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolFilter(o);
            if ("toolOverrides" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayToolConfiguration#toolOverrides", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.toolOverrides != null)
                for (const o of p.toolOverrides)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolOverride(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayTargetConfigurationProps: function _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayTargetConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("apiGatewayToolConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayTargetConfigurationProps#apiGatewayToolConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.apiGatewayToolConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolConfiguration(p.apiGatewayToolConfiguration);
            if ("restApi" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayTargetConfigurationProps#restApi", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("metadataConfiguration" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayTargetConfigurationProps#metadataConfiguration", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.metadataConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_MetadataConfiguration(p.metadataConfiguration);
            if ("stage" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ApiGatewayTargetConfigurationProps#stage", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinitionType: function _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinitionType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-bedrock-agentcore-alpha.SchemaDefinitionType", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p === "string")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SchemaDefinitionType#STRING", "");
            if (p === "number")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SchemaDefinitionType#NUMBER", "");
            if (p === "object")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SchemaDefinitionType#OBJECT", "");
            if (p === "array")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SchemaDefinitionType#ARRAY", "");
            if (p === "boolean")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SchemaDefinitionType#BOOLEAN", "");
            if (p === "integer")
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SchemaDefinitionType#INTEGER", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition: function _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("type" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SchemaDefinition#type", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.type))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinitionType(p.type);
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SchemaDefinition#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("items" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SchemaDefinition#items", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.items))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(p.items);
            if ("properties" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SchemaDefinition#properties", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.properties != null)
                for (const o of Object.values(p.properties))
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(o);
            if ("required" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.SchemaDefinition#required", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ToolDefinition: function _aws_cdk_aws_bedrock_agentcore_alpha_ToolDefinition(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ToolDefinition#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("inputSchema" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ToolDefinition#inputSchema", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.inputSchema))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(p.inputSchema);
            if ("name" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ToolDefinition#name", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("outputSchema" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.ToolDefinition#outputSchema", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.outputSchema))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(p.outputSchema);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_FilterConfig: function _aws_cdk_aws_bedrock_agentcore_alpha_FilterConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("key" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.FilterConfig#key", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("operator" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.FilterConfig#operator", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.operator))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_FilterOperator(p.operator);
            if ("value" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.FilterConfig#value", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.value))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_FilterValue(p.value);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CloudWatchLogsDataSourceConfig: function _aws_cdk_aws_bedrock_agentcore_alpha_CloudWatchLogsDataSourceConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("logGroupNames" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CloudWatchLogsDataSourceConfig#logGroupNames", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("serviceNames" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CloudWatchLogsDataSourceConfig#serviceNames", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OnlineEvaluationBaseProps: function _aws_cdk_aws_bedrock_agentcore_alpha_OnlineEvaluationBaseProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("onlineEvaluationConfigName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#onlineEvaluationConfigName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("executionRole" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#executionRole", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("executionStatus" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#executionStatus", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.executionStatus))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ExecutionStatus(p.executionStatus);
            if ("filters" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#filters", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.filters != null)
                for (const o of p.filters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_FilterConfig(o);
            if ("samplingPercentage" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#samplingPercentage", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("sessionTimeout" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#sessionTimeout", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_EvaluatorReferenceBindResult: function _aws_cdk_aws_bedrock_agentcore_alpha_EvaluatorReferenceBindResult(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("evaluatorId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.EvaluatorReferenceBindResult#evaluatorId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_DataSourceConfigBindResult: function _aws_cdk_aws_bedrock_agentcore_alpha_DataSourceConfigBindResult(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("cloudWatchLogs" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.DataSourceConfigBindResult#cloudWatchLogs", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.cloudWatchLogs))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_CloudWatchLogsDataSourceConfig(p.cloudWatchLogs);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CategoricalRatingOption: function _aws_cdk_aws_bedrock_agentcore_alpha_CategoricalRatingOption(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("definition" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CategoricalRatingOption#definition", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("label" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CategoricalRatingOption#label", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_NumericalRatingOption: function _aws_cdk_aws_bedrock_agentcore_alpha_NumericalRatingOption(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("definition" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.NumericalRatingOption#definition", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("label" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.NumericalRatingOption#label", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("value" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.NumericalRatingOption#value", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_EvaluatorInferenceConfig: function _aws_cdk_aws_bedrock_agentcore_alpha_EvaluatorInferenceConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("maxTokens" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.EvaluatorInferenceConfig#maxTokens", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("temperature" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.EvaluatorInferenceConfig#temperature", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("topP" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.EvaluatorInferenceConfig#topP", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_EvaluatorAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_EvaluatorAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("evaluatorArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.EvaluatorAttributes#evaluatorArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("evaluatorId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.EvaluatorAttributes#evaluatorId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("evaluatorName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.EvaluatorAttributes#evaluatorName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OnlineEvaluationConfigAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_OnlineEvaluationConfigAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("onlineEvaluationConfigArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationConfigAttributes#onlineEvaluationConfigArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("onlineEvaluationConfigId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationConfigAttributes#onlineEvaluationConfigId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("onlineEvaluationConfigName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationConfigAttributes#onlineEvaluationConfigName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("executionRoleArn" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationConfigAttributes#executionRoleArn", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_LlmAsAJudgeOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_LlmAsAJudgeOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("instructions" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.LlmAsAJudgeOptions#instructions", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("modelId" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.LlmAsAJudgeOptions#modelId", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("ratingScale" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.LlmAsAJudgeOptions#ratingScale", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.ratingScale))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_EvaluatorRatingScale(p.ratingScale);
            if ("additionalModelRequestFields" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.LlmAsAJudgeOptions#additionalModelRequestFields", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("inferenceConfig" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.LlmAsAJudgeOptions#inferenceConfig", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.inferenceConfig))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_EvaluatorInferenceConfig(p.inferenceConfig);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CodeBasedOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_CodeBasedOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("lambdaFunction" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeBasedOptions#lambdaFunction", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("timeout" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.CodeBasedOptions#timeout", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_EvaluatorProps: function _aws_cdk_aws_bedrock_agentcore_alpha_EvaluatorProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("evaluatorConfig" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.EvaluatorProps#evaluatorConfig", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.evaluatorConfig))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_EvaluatorConfig(p.evaluatorConfig);
            if ("evaluatorName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.EvaluatorProps#evaluatorName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("level" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.EvaluatorProps#level", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.level))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_EvaluationLevel(p.level);
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.EvaluatorProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.EvaluatorProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OnlineEvaluationConfigProps: function _aws_cdk_aws_bedrock_agentcore_alpha_OnlineEvaluationConfigProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("dataSource" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationConfigProps#dataSource", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.dataSource))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_DataSourceConfig(p.dataSource);
            if ("evaluators" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationConfigProps#evaluators", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.evaluators != null)
                for (const o of p.evaluators)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_EvaluatorReference(o);
            if ("tags" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationConfigProps#tags", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("onlineEvaluationConfigName" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#onlineEvaluationConfigName", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("description" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#description", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("executionRole" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#executionRole", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("executionStatus" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#executionStatus", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (!visitedObjects.has(p.executionStatus))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ExecutionStatus(p.executionStatus);
            if ("filters" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#filters", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if (p.filters != null)
                for (const o of p.filters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_FilterConfig(o);
            if ("samplingPercentage" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#samplingPercentage", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
            if ("sessionTimeout" in p)
                print("@aws-cdk/aws-bedrock-agentcore-alpha.OnlineEvaluationBaseProps#sessionTimeout", "Use the equivalent construct from `aws-cdk-lib/aws-bedrockagentcore` instead.");
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
