import type { IDeliveryStream } from 'aws-cdk-lib/aws-kinesisfirehose';
import * as logs from 'aws-cdk-lib/aws-logs';
import type * as s3 from 'aws-cdk-lib/aws-s3';
import { Construct } from 'constructs';
/**
 * Log types for AgentCore Runtime observability
 */
export declare class LogType {
    /**
     * The log type value
     */
    readonly value: string;
    /**
     * Application logs for agent runtime invocations
     */
    static readonly APPLICATION_LOGS: LogType;
    /**
     * Usage logs for session-level resource consumption
     */
    static readonly USAGE_LOGS: LogType;
    /**
     * A custom log type value
     *
     * @param value The log type value
     */
    static of(value: string): LogType;
    private constructor();
}
/**
 * Configuration for logging with log type and destination
 */
export interface LoggingConfig {
    /**
     * The type of logs to deliver
     */
    readonly logType: LogType;
    /**
     * The destination for logs
     */
    readonly destination: LoggingDestination;
}
/**
 * Configuration returned by LoggingDestination.bind()
 * @internal
 */
interface LoggingDestinationBindConfig {
    /**
     * The delivery destination construct
     */
    readonly deliveryDestination: logs.CfnDeliveryDestination;
}
/**
 * Represents a logging destination for AgentCore Runtime
 *
 * Use the static factory methods to create instances:
 * - `LoggingDestination.cloudWatchLogs(logGroup)` - Send logs to CloudWatch Logs
 * - `LoggingDestination.s3(bucket)` - Send logs to S3
 * - `LoggingDestination.firehose(stream)` - Send logs to Kinesis Data Firehose
 */
export declare abstract class LoggingDestination {
    /**
     * Create a logging destination that sends logs to a CloudWatch Log Group
     *
     * @param logGroup The CloudWatch Log Group to send logs to
     */
    static cloudWatchLogs(logGroup: logs.ILogGroup): LoggingDestination;
    /**
     * Create a logging destination that sends logs to an S3 bucket
     *
     * @param bucket The S3 bucket to send logs to
     */
    static s3(bucket: s3.IBucket): LoggingDestination;
    /**
     * Create a logging destination that sends logs to a Kinesis Data Firehose delivery stream
     *
     * @param stream The Firehose delivery stream to send logs to
     */
    static firehose(stream: IDeliveryStream): LoggingDestination;
    /**
     * Bind this destination to a scope and create the delivery destination resource
     *
     * @param scope The construct scope
     * @param id The construct id
     * @internal
     */
    abstract _bind(scope: Construct, id: string): LoggingDestinationBindConfig;
}
/**
 * Configure X-Ray tracing delivery for a runtime
 *
 * @param scope The construct scope
 * @param sourceArn The ARN of the source resource (runtime)
 * @internal
 */
export declare function configureTracingDelivery(scope: Construct, sourceArn: string): logs.CfnDelivery;
/**
 * Configure logging delivery for a runtime
 *
 * @param scope The construct scope
 * @param sourceArn The ARN of the source resource (runtime)
 * @param loggingConfigs Array of logging configurations
 * @internal
 */
export declare function configureLoggingDelivery(scope: Construct, sourceArn: string, loggingConfigs: LoggingConfig[]): logs.CfnDelivery[];
export {};
