import type { IConstruct } from 'constructs';
/**
 * Validation constants for PolicyEngine
 */
export declare const POLICY_ENGINE_NAME_MIN_LENGTH = 1;
export declare const POLICY_ENGINE_NAME_MAX_LENGTH = 48;
export declare const POLICY_ENGINE_NAME_PATTERN: RegExp;
/**
 * Validation constants for Policy
 */
export declare const POLICY_NAME_MIN_LENGTH = 1;
export declare const POLICY_NAME_MAX_LENGTH = 48;
export declare const POLICY_NAME_PATTERN: RegExp;
/**
 * Validation constants for Cedar policy definitions
 */
export declare const POLICY_DEFINITION_MIN_LENGTH = 35;
export declare const POLICY_DEFINITION_MAX_LENGTH = 153600;
/**
 * Validation constants for descriptions
 */
export declare const DESCRIPTION_MAX_LENGTH = 4096;
/**
 * Validation constants for tags
 */
export declare const MAX_TAGS = 50;
export declare const TAG_KEY_MIN_LENGTH = 1;
export declare const TAG_KEY_MAX_LENGTH = 128;
export declare const TAG_VALUE_MAX_LENGTH = 256;
export declare const TAG_KEY_PATTERN: RegExp;
export declare const TAG_VALUE_PATTERN: RegExp;
/**
 * Validates a policy engine name.
 * Names must:
 * - Start with a letter (a-z, A-Z)
 * - Contain only letters, numbers, and underscores
 * - Be between 1 and 48 characters
 *
 * @param name - The policy engine name to validate
 * @param scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validatePolicyEngineName(name: string, scope?: IConstruct): string[];
/**
 * Validates a policy name.
 * Names must:
 * - Start with a letter (a-z, A-Z)
 * - Contain only letters, numbers, and underscores
 * - Be between 1 and 48 characters
 *
 * @param name - The policy name to validate
 * @param scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validatePolicyName(name: string, scope?: IConstruct): string[];
/**
 * Validates a Cedar policy definition string.
 * Definitions must be between 35 and 153,600 characters.
 *
 * @param definition - The Cedar policy definition to validate
 * @param scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validatePolicyDefinition(definition: string, scope?: IConstruct): string[];
/**
 * Validates a description string.
 * Descriptions must not exceed 4,096 characters.
 *
 * @param description - The description to validate
 * @param scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateDescription(description: string, scope?: IConstruct): string[];
/**
 * Validates a policy engine name and throws if invalid.
 *
 * @param name - The policy engine name to validate
 * @param scope - The construct scope for error reporting (optional)
 * @returns The validated name
 * @throws ValidationError if validation fails
 */
export declare function throwIfInvalidPolicyEngineName(name: string, scope?: IConstruct): string;
/**
 * Validates a policy name and throws if invalid.
 *
 * @param name - The policy name to validate
 * @param scope - The construct scope for error reporting (optional)
 * @returns The validated name
 * @throws ValidationError if validation fails
 */
export declare function throwIfInvalidPolicyName(name: string, scope?: IConstruct): string;
/**
 * Validates a policy definition and throws if invalid.
 *
 * @param definition - The Cedar policy definition to validate
 * @param scope - The construct scope for error reporting (optional)
 * @returns The validated definition
 * @throws ValidationError if validation fails
 */
export declare function throwIfInvalidPolicyDefinition(definition: string, scope?: IConstruct): string;
/**
 * Validates a description and throws if invalid.
 *
 * @param description - The description to validate
 * @param scope - The construct scope for error reporting (optional)
 * @returns The validated description
 * @throws ValidationError if validation fails
 */
export declare function throwIfInvalidDescription(description: string, scope?: IConstruct): string;
/**
 * Validates tags for a PolicyEngine.
 * Tags must:
 * - Not exceed 50 tags
 * - Have keys between 1 and 128 characters
 * - Have values between 0 and 256 characters
 * - Match allowed character patterns
 *
 * @param tags - The tags object to validate
 * @param resourceName - The name of the resource being tagged (for error messages)
 * @param scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateTags(tags: {
    [key: string]: string;
}, resourceName: string, _scope?: IConstruct): string[];
/**
 * Validates tags and throws if invalid.
 *
 * @param tags - The tags object to validate
 * @param resourceName - The name of the resource being tagged (for error messages)
 * @param scope - The construct scope for error reporting (optional)
 * @returns The validated tags
 * @throws ValidationError if validation fails
 */
export declare function throwIfInvalidTags(tags: {
    [key: string]: string;
}, resourceName: string, scope?: IConstruct): {
    [key: string]: string;
};
