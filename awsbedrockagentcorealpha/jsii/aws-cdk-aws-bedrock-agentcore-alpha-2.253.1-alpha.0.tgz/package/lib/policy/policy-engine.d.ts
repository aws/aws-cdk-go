/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import * as iam from 'aws-cdk-lib/aws-iam';
import * as kms from 'aws-cdk-lib/aws-kms';
import type { Construct } from 'constructs';
import { Policy } from './policy';
import { PolicyEngineBase } from './policy-engine-base';
import type { IPolicyEngine, PolicyEngineAttributes } from './policy-engine-base';
import type { AddPolicyOptions } from './policy-types';
/**
 * Properties for creating a PolicyEngine resource
 */
export interface PolicyEngineProps {
    /**
     * The name of the policy engine.
     * Valid characters: a-z, A-Z, 0-9, _ (underscore)
     * Must start with a letter, 1-48 characters
     * Pattern: ^[A-Za-z][A-Za-z0-9_]*$
     *
     * @default - Auto-generated unique name
     */
    readonly policyEngineName?: string;
    /**
     * Optional description for the policy engine.
     * Maximum 4,096 characters.
     *
     * @default - No description
     */
    readonly description?: string;
    /**
     * Custom KMS key for encryption.
     * [disable-awslint:prefer-ref-interface]
     *
     * @default - AWS owned key
     */
    readonly kmsKey?: kms.IKey;
    /**
     * Tags for the policy engine.
     * Maximum 50 tags.
     *
     * @default - No tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Container that manages Cedar authorization policies associated with gateways.
 * PolicyEngine enables deterministic authorization control for Bedrock agents,
 * allowing fine-grained access control to tools and actions via Cedar policy language.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/policy-engine.html
 * @resource AWS::BedrockAgentCore::PolicyEngine
 */
export declare class PolicyEngine extends PolicyEngineBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Creates a PolicyEngine reference from an existing policy engine's attributes.
     *
     * @param scope - The construct scope
     * @param id - Identifier of the construct
     * @param attrs - Attributes of the existing policy engine
     * @returns An IPolicyEngine reference to the existing policy engine
     */
    static fromPolicyEngineAttributes(scope: Construct, id: string, attrs: PolicyEngineAttributes): IPolicyEngine;
    /**
     * The ARN of the policy engine resource.
     * @attribute
     */
    readonly policyEngineArn: string;
    /**
     * The name of the policy engine.
     *
     * [disable-awslint:attribute-tag]
     */
    readonly policyEngineName: string;
    /**
     * The ID of the policy engine.
     * @attribute
     */
    readonly policyEngineId: string;
    /**
     * The description of the policy engine.
     */
    readonly description?: string;
    /**
     * Tags applied to this policy engine resource.
     * @default - No tags applied
     */
    readonly tags?: {
        [key: string]: string;
    };
    /**
     * The principal to grant permissions to.
     */
    readonly grantPrincipal: iam.IPrincipal;
    /**
     * The KMS key used to encrypt the policy engine.
     */
    readonly kmsKey?: kms.IKey;
    /**
     * List of policies added to this policy engine via addPolicy().
     * @internal
     */
    private readonly _policies;
    /**
     * The last policy added to this engine, used for automatic sequential chaining.
     * @internal
     */
    private _lastPolicy?;
    /**
     * Get the list of policies added to this policy engine.
     *
     * Returns an array of Policy constructs that were added using addPolicy().
     * This allows you to iterate over all policies associated with this engine.
     *
     * @returns A copy of the policies array
     */
    get policies(): Policy[];
    private readonly __resource;
    constructor(scope: Construct, id: string, props?: PolicyEngineProps);
    /**
     * Add a policy to this policy engine.
     * Convenience method that creates a Policy construct with this engine as the parent.
     *
     * **Automatic Sequential Chaining**: By default, policies are automatically chained
     * sequentially to prevent concurrent creation issues with the AWS Bedrock AgentCore
     * service. Each new policy will depend on the previous policy added to this engine.
     *
     * This ensures policies are created one at a time, avoiding "Resource stabilization
     * failed" errors that occur with concurrent policy operations.
     *
     * @param id - Unique identifier for the policy construct
     * @param options - Options for creating the policy
     * @returns The created Policy construct
     *
     */
    addPolicy(id: string, options: AddPolicyOptions): Policy;
}
