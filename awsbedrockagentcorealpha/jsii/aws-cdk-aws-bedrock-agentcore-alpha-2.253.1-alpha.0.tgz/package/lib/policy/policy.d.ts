import * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import type { IPolicy, PolicyAttributes } from './policy-base';
import { PolicyBase } from './policy-base';
import type { IPolicyEngine } from './policy-engine-base';
import type { PolicyStatement } from './policy-statement';
import { PolicyValidationMode } from './policy-types';
/**
 * Properties for creating a Policy resource
 */
export interface PolicyProps {
    /**
     * The name of the policy.
     * Valid characters: a-z, A-Z, 0-9, _ (underscore)
     * Must start with a letter, 1-48 characters
     * Pattern: ^[A-Za-z][A-Za-z0-9_]*$
     *
     * @default - Auto-generated unique name
     */
    readonly policyName?: string;
    /**
     * The policy engine this policy belongs to.
     * [disable-awslint:prefer-ref-interface]
     */
    readonly policyEngine: IPolicyEngine;
    /**
     * Cedar policy statement.
     * The authorization policy written in Cedar policy language.
     *
     * Cedar supports permit and forbid rules with conditions.
     * The statement will be wrapped in a PolicyDefinition structure internally.
     *
     * Pass the raw Cedar statement as a string. For example:
     * - "permit(principal, action, resource);"
     * - "permit(principal in Group::\"Admins\", action == Action::\"InvokeModel\", resource) when { context.environment == \"production\" };"
     *
     * You must specify either `definition` or `statement`, but not both.
     *
     * @default - Must provide either definition or statement
     */
    readonly definition?: string;
    /**
     * Type-safe Cedar policy statement built using PolicyStatement builder.
     *
     * Use this for a type-safe, form-like API to build Cedar policies without
     * writing raw Cedar syntax. The builder validates at synthesis time.
     *
     * You must specify either `definition` or `statement`, but not both.
     *
     * @default - Must provide either definition or statement
     */
    readonly statement?: PolicyStatement;
    /**
     * Optional description for the policy.
     * Maximum length of 4096.
     * @default - No description
     */
    readonly description?: string;
    /**
     * Validation mode for the policy.
     * Controls how Cedar analyzer validation findings are handled.
     *
     * @default PolicyValidationMode.FAIL_ON_ANY_FINDINGS
     */
    readonly validationMode?: PolicyValidationMode;
}
/**
 * Individual Cedar policy defining what agents can access.
 * Policies use Cedar language to specify precise access control rules
 * that are evaluated deterministically by the PolicyEngine.
 *
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/policy.html
 * @resource AWS::BedrockAgentCore::Policy
 */
export declare class Policy extends PolicyBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Creates a Policy reference from an existing policy's attributes.
     *
     * @param scope - The construct scope
     * @param id - Identifier of the construct
     * @param attrs - Attributes of the existing policy
     * @returns An IPolicy reference to the existing policy
     */
    static fromPolicyAttributes(scope: Construct, id: string, attrs: PolicyAttributes): IPolicy;
    /**
     * The ARN of the policy resource.
     * @attribute
     */
    readonly policyArn: string;
    /**
     * The name of the policy.
     *
     * [disable-awslint:attribute-tag]
     */
    readonly policyName: string;
    /**
     * The ID of the policy.
     * @attribute
     */
    readonly policyId: string;
    /**
     * The policy engine this policy belongs to.
     *
     * [disable-awslint:attribute-tag]
     */
    readonly policyEngine: IPolicyEngine;
    /**
     * The Cedar policy definition.
     */
    readonly definition: string;
    /**
     * The description of the policy.
     */
    readonly description?: string;
    /**
     * The validation mode for the policy.
     */
    readonly validationMode?: PolicyValidationMode;
    /**
     * The principal to grant permissions to.
     */
    readonly grantPrincipal: iam.IPrincipal;
    private readonly __resource;
    constructor(scope: Construct, id: string, props: PolicyProps);
}
