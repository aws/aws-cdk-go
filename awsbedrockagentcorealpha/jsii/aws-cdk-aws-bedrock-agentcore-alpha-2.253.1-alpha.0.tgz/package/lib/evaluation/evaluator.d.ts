/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import type { IEvaluator } from './evaluator-base';
import type { BuiltinEvaluator, EvaluatorReferenceBindResult } from './types';
/**
 * Represents a reference to an evaluator for online evaluation.
 *
 * Use the static factory methods to create evaluator references:
 * - `EvaluatorReference.builtin()` for built-in evaluators
 * - `EvaluatorReference.custom()` for custom evaluators
 *
 * @example
 * // Using built-in evaluators
 * const helpfulness = agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.HELPFULNESS);
 *
 * // Using custom evaluators
 * declare const myCustomEvaluator: agentcore.IEvaluator;
 * const custom = agentcore.EvaluatorReference.custom(myCustomEvaluator);
 */
export declare class EvaluatorReference {
    /**
     * Creates a reference to a built-in evaluator.
     *
     * Built-in evaluators are provided by Amazon Bedrock AgentCore and assess
     * different aspects of agent performance at various levels (session, trace, or tool call).
     *
     * @param evaluator - The built-in evaluator to reference
     * @returns An EvaluatorReference instance
     *
     * @example
     * const helpfulness = agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.HELPFULNESS);
     * const goalSuccess = agentcore.EvaluatorReference.builtin(agentcore.BuiltinEvaluator.GOAL_SUCCESS_RATE);
     */
    static builtin(evaluator: BuiltinEvaluator): EvaluatorReference;
    /**
     * Creates a reference to a custom evaluator.
     *
     * Custom evaluators are created using the `Evaluator` construct and can be
     * LLM-as-a-Judge or code-based (Lambda) evaluators.
     *
     * @param evaluator - The custom evaluator construct to reference
     * @returns An EvaluatorReference instance
     *
     * @example
     * declare const myCustomEvaluator: agentcore.IEvaluator;
     * const ref = agentcore.EvaluatorReference.custom(myCustomEvaluator);
     */
    static custom(evaluator: IEvaluator): EvaluatorReference;
    /**
     * The evaluator identifier.
     */
    readonly evaluatorId: string;
    private constructor();
    /**
     * Binds the evaluator reference to produce the L1 property.
     */
    bind(): EvaluatorReferenceBindResult;
}
