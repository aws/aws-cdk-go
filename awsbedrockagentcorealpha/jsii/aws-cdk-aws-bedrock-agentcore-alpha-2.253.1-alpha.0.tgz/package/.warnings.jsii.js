const VALIDATORS = { _aws_cdk_aws_bedrock_agentcore_alpha_MemoryProps: function _aws_cdk_aws_bedrock_agentcore_alpha_MemoryProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.memoryStrategies != null)
                for (const o of p.memoryStrategies)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_IMemoryStrategy(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ManagedStrategyProps: function _aws_cdk_aws_bedrock_agentcore_alpha_ManagedStrategyProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.customConsolidation))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_OverrideConfig(p.customConsolidation);
            if (!visitedObjects.has(p.customExtraction))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_OverrideConfig(p.customExtraction);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_SelfManagedStrategyProps: function _aws_cdk_aws_bedrock_agentcore_alpha_SelfManagedStrategyProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.invocationConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_InvocationConfiguration(p.invocationConfiguration);
            if (!visitedObjects.has(p.triggerConditions))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_TriggerConditions(p.triggerConditions);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_VpcConfigProps: function _aws_cdk_aws_bedrock_agentcore_alpha_VpcConfigProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_AgentRuntimeAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_AgentRuntimeAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CodeAssetOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_CodeAssetOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.readers != null)
                for (const o of p.readers)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IGrantable(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeProps: function _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.lifecycleConfiguration))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_LifecycleConfiguration(p.lifecycleConfiguration);
            if (p.loggingConfigs != null)
                for (const o of p.loggingConfigs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_LoggingConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustomAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustomAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomProps: function _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.recordingConfig))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_RecordingConfig(p.recordingConfig);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomAttributes: function _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_AddLambdaTargetOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_AddLambdaTargetOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_AddApiGatewayTargetOptions: function _aws_cdk_aws_bedrock_agentcore_alpha_AddApiGatewayTargetOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayProps: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.interceptorConfigurations != null)
                for (const o of p.interceptorConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_IInterceptor(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_CognitoAuthorizerProps: function _aws_cdk_aws_bedrock_agentcore_alpha_CognitoAuthorizerProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.allowedClients != null)
                for (const o of p.allowedClients)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_cognito_IUserPoolClient(o);
            if (p.customClaims != null)
                for (const o of p.customClaims)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_GatewayCustomClaim(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetLambdaProps: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetLambdaProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetApiGatewayProps: function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetApiGatewayProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.credentialProviderConfigurations != null)
                for (const o of p.credentialProviderConfigurations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition: function _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.items))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(p.items);
            if (p.properties != null)
                for (const o of Object.values(p.properties))
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_ToolDefinition: function _aws_cdk_aws_bedrock_agentcore_alpha_ToolDefinition(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.inputSchema))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(p.inputSchema);
            if (!visitedObjects.has(p.outputSchema))
                module.exports._aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(p.outputSchema);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OnlineEvaluationBaseProps: function _aws_cdk_aws_bedrock_agentcore_alpha_OnlineEvaluationBaseProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.filters != null)
                for (const o of p.filters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_FilterConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_agentcore_alpha_OnlineEvaluationConfigProps: function _aws_cdk_aws_bedrock_agentcore_alpha_OnlineEvaluationConfigProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.evaluators != null)
                for (const o of p.evaluators)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_EvaluatorReference(o);
            if (p.filters != null)
                for (const o of p.filters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_agentcore_alpha_FilterConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
