function _aws_cdk_aws_bedrock_agentcore_alpha_IMemory(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_MemoryBase(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_MemoryProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.memoryStrategies != null)
            for (const o of p.memoryStrategies)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_IMemoryStrategy(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_MemoryAttributes(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_Memory(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_OverrideConfig(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_EpisodicReflectionConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ManagedStrategyProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.customConsolidation))
            _aws_cdk_aws_bedrock_agentcore_alpha_OverrideConfig(p.customConsolidation);
        if (!visitedObjects.has(p.customExtraction))
            _aws_cdk_aws_bedrock_agentcore_alpha_OverrideConfig(p.customExtraction);
        if (!visitedObjects.has(p.reflectionConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_EpisodicReflectionConfiguration(p.reflectionConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ManagedMemoryStrategy(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_TriggerConditions(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_InvocationConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_SelfManagedStrategyProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.invocationConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_InvocationConfiguration(p.invocationConfiguration);
        if (!visitedObjects.has(p.triggerConditions))
            _aws_cdk_aws_bedrock_agentcore_alpha_TriggerConditions(p.triggerConditions);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_SelfManagedMemoryStrategy(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_MemoryStrategyType(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_MemoryStrategyCommonProps(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_IMemoryStrategy(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_MemoryStrategy(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_VpcConfigProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_NetworkConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_BrowserNetworkConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterNetworkConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeNetworkConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_CustomClaimOperator(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ProtocolType(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_RequestHeaderConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_LifecycleConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_IBedrockAgentRuntime(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeBase(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_AgentRuntimeAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_AgentCoreRuntime(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_CodeAssetOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.runtime))
            _aws_cdk_aws_bedrock_agentcore_alpha_AgentCoreRuntime(p.runtime);
        if (p.readers != null)
            for (const o of p.readers)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IGrantable(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_AgentRuntimeArtifact(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeCustomClaim(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeAuthorizerConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_IRuntimeEndpoint(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeEndpointBase(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeEndpointAttributes(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeEndpointProps(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeEndpoint(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.agentRuntimeArtifact))
            _aws_cdk_aws_bedrock_agentcore_alpha_AgentRuntimeArtifact(p.agentRuntimeArtifact);
        if (!visitedObjects.has(p.authorizerConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeAuthorizerConfiguration(p.authorizerConfiguration);
        if (!visitedObjects.has(p.lifecycleConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_LifecycleConfiguration(p.lifecycleConfiguration);
        if (!visitedObjects.has(p.networkConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeNetworkConfiguration(p.networkConfiguration);
        if (!visitedObjects.has(p.protocolConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_ProtocolType(p.protocolConfiguration);
        if (!visitedObjects.has(p.requestHeaderConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_RequestHeaderConfiguration(p.requestHeaderConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_AddEndpointOptions(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_Runtime(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ICodeInterpreterCustom(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustomBase(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustomProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.networkConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterNetworkConfiguration(p.networkConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustomAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustom(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_BrowserSigning(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_IBrowserCustom(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomBase(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_RecordingConfig(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.browserSigning))
            _aws_cdk_aws_bedrock_agentcore_alpha_BrowserSigning(p.browserSigning);
        if (!visitedObjects.has(p.networkConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_BrowserNetworkConfiguration(p.networkConfiguration);
        if (!visitedObjects.has(p.recordingConfig))
            _aws_cdk_aws_bedrock_agentcore_alpha_RecordingConfig(p.recordingConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustom(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayExceptionLevel(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayBase(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_AddLambdaTargetOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.toolSchema))
            _aws_cdk_aws_bedrock_agentcore_alpha_ToolSchema(p.toolSchema);
        if (p.credentialProviderConfigurations != null)
            for (const o of p.credentialProviderConfigurations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_AddOpenApiTargetOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.apiSchema))
            _aws_cdk_aws_bedrock_agentcore_alpha_ApiSchema(p.apiSchema);
        if (p.credentialProviderConfigurations != null)
            for (const o of p.credentialProviderConfigurations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_AddSmithyTargetOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.smithyModel))
            _aws_cdk_aws_bedrock_agentcore_alpha_ApiSchema(p.smithyModel);
        if (p.credentialProviderConfigurations != null)
            for (const o of p.credentialProviderConfigurations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_AddMcpServerTargetOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.credentialProviderConfigurations != null)
            for (const o of p.credentialProviderConfigurations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_AddApiGatewayTargetOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.apiGatewayToolConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolConfiguration(p.apiGatewayToolConfiguration);
        if (p.credentialProviderConfigurations != null)
            for (const o of p.credentialProviderConfigurations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
        if (!visitedObjects.has(p.metadataConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_MetadataConfiguration(p.metadataConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.authorizerConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_IGatewayAuthorizerConfig(p.authorizerConfiguration);
        if (!visitedObjects.has(p.exceptionLevel))
            _aws_cdk_aws_bedrock_agentcore_alpha_GatewayExceptionLevel(p.exceptionLevel);
        if (p.interceptorConfigurations != null)
            for (const o of p.interceptorConfigurations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_IInterceptor(o);
        if (!visitedObjects.has(p.protocolConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_IGatewayProtocolConfig(p.protocolConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayAttributes(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_Gateway(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_InterceptionPoint(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_InterceptorOptions(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_IInterceptor(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_InterceptorBindConfig(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_LambdaInterceptor(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_IGatewayProtocolConfig(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayProtocol(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_MCPProtocolVersion(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_McpGatewaySearchType(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_McpConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.searchType))
            _aws_cdk_aws_bedrock_agentcore_alpha_McpGatewaySearchType(p.searchType);
        if (p.supportedVersions != null)
            for (const o of p.supportedVersions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_MCPProtocolVersion(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_McpProtocolConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayAuthorizerType(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_IGatewayAuthorizerConfig(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_CustomJwtConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.customClaims != null)
            for (const o of p.customClaims)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_GatewayCustomClaim(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_CustomJwtAuthorizer(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_IamAuthorizer(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_CognitoAuthorizerProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.allowedClients != null)
            for (const o of p.allowedClients)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_cognito_IUserPoolClient(o);
        if (p.customClaims != null)
            for (const o of p.customClaims)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_GatewayCustomClaim(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayAuthorizer(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayCustomClaim(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_CredentialProviderType(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayCredentialProvider(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyAdditionalConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyCredentialLocation(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyCredentialProviderProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.credentialLocation))
            _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyCredentialLocation(p.credentialLocation);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_OAuthConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetProtocolType(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_McpTargetType(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_IGatewayTarget(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_IMcpGatewayTarget(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetBase(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetCommonProps(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.gateway))
            _aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
        if (!visitedObjects.has(p.targetConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_ITargetConfiguration(p.targetConfiguration);
        if (p.credentialProviderConfigurations != null)
            for (const o of p.credentialProviderConfigurations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetLambdaProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.gateway))
            _aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
        if (!visitedObjects.has(p.toolSchema))
            _aws_cdk_aws_bedrock_agentcore_alpha_ToolSchema(p.toolSchema);
        if (p.credentialProviderConfigurations != null)
            for (const o of p.credentialProviderConfigurations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetOpenApiProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.apiSchema))
            _aws_cdk_aws_bedrock_agentcore_alpha_ApiSchema(p.apiSchema);
        if (!visitedObjects.has(p.gateway))
            _aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
        if (p.credentialProviderConfigurations != null)
            for (const o of p.credentialProviderConfigurations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetSmithyProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.gateway))
            _aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
        if (!visitedObjects.has(p.smithyModel))
            _aws_cdk_aws_bedrock_agentcore_alpha_ApiSchema(p.smithyModel);
        if (p.credentialProviderConfigurations != null)
            for (const o of p.credentialProviderConfigurations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetMcpServerProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.credentialProviderConfigurations != null)
            for (const o of p.credentialProviderConfigurations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
        if (!visitedObjects.has(p.gateway))
            _aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetApiGatewayProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.apiGatewayToolConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolConfiguration(p.apiGatewayToolConfiguration);
        if (!visitedObjects.has(p.gateway))
            _aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
        if (p.credentialProviderConfigurations != null)
            for (const o of p.credentialProviderConfigurations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig(o);
        if (!visitedObjects.has(p.metadataConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_MetadataConfiguration(p.metadataConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.gateway))
            _aws_cdk_aws_bedrock_agentcore_alpha_IGateway(p.gateway);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTarget(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_TargetConfigurationConfig(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ITargetConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_McpTargetConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_LambdaTargetConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_OpenApiTargetConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_SmithyTargetConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_McpServerTargetConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayHttpMethod(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolFilter(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.methods != null)
            for (const o of p.methods)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayHttpMethod(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolOverride(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.method))
            _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayHttpMethod(p.method);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_MetadataConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.toolFilters != null)
            for (const o of p.toolFilters)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolFilter(o);
        if (p.toolOverrides != null)
            for (const o of p.toolOverrides)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolOverride(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayTargetConfigurationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.apiGatewayToolConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolConfiguration(p.apiGatewayToolConfiguration);
        if (!visitedObjects.has(p.metadataConfiguration))
            _aws_cdk_aws_bedrock_agentcore_alpha_MetadataConfiguration(p.metadataConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayTargetConfiguration(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ApiSchema(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_AssetApiSchema(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_InlineApiSchema(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_S3ApiSchema(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinitionType(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.type))
            _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinitionType(p.type);
        if (!visitedObjects.has(p.items))
            _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(p.items);
        if (p.properties != null)
            for (const o of Object.values(p.properties))
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ToolDefinition(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputSchema))
            _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(p.inputSchema);
        if (!visitedObjects.has(p.outputSchema))
            _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition(p.outputSchema);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_agentcore_alpha_ToolSchema(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_AssetToolSchema(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_InlineToolSchema(p) {
}
function _aws_cdk_aws_bedrock_agentcore_alpha_S3ToolSchema(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_bedrock_agentcore_alpha_IMemory, _aws_cdk_aws_bedrock_agentcore_alpha_MemoryBase, _aws_cdk_aws_bedrock_agentcore_alpha_MemoryProps, _aws_cdk_aws_bedrock_agentcore_alpha_MemoryAttributes, _aws_cdk_aws_bedrock_agentcore_alpha_Memory, _aws_cdk_aws_bedrock_agentcore_alpha_OverrideConfig, _aws_cdk_aws_bedrock_agentcore_alpha_EpisodicReflectionConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_ManagedStrategyProps, _aws_cdk_aws_bedrock_agentcore_alpha_ManagedMemoryStrategy, _aws_cdk_aws_bedrock_agentcore_alpha_TriggerConditions, _aws_cdk_aws_bedrock_agentcore_alpha_InvocationConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_SelfManagedStrategyProps, _aws_cdk_aws_bedrock_agentcore_alpha_SelfManagedMemoryStrategy, _aws_cdk_aws_bedrock_agentcore_alpha_MemoryStrategyType, _aws_cdk_aws_bedrock_agentcore_alpha_MemoryStrategyCommonProps, _aws_cdk_aws_bedrock_agentcore_alpha_IMemoryStrategy, _aws_cdk_aws_bedrock_agentcore_alpha_MemoryStrategy, _aws_cdk_aws_bedrock_agentcore_alpha_VpcConfigProps, _aws_cdk_aws_bedrock_agentcore_alpha_NetworkConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_BrowserNetworkConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterNetworkConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeNetworkConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_CustomClaimOperator, _aws_cdk_aws_bedrock_agentcore_alpha_ProtocolType, _aws_cdk_aws_bedrock_agentcore_alpha_RequestHeaderConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_LifecycleConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_IBedrockAgentRuntime, _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeBase, _aws_cdk_aws_bedrock_agentcore_alpha_AgentRuntimeAttributes, _aws_cdk_aws_bedrock_agentcore_alpha_AgentCoreRuntime, _aws_cdk_aws_bedrock_agentcore_alpha_CodeAssetOptions, _aws_cdk_aws_bedrock_agentcore_alpha_AgentRuntimeArtifact, _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeCustomClaim, _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeAuthorizerConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_IRuntimeEndpoint, _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeEndpointBase, _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeEndpointAttributes, _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeEndpointProps, _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeEndpoint, _aws_cdk_aws_bedrock_agentcore_alpha_RuntimeProps, _aws_cdk_aws_bedrock_agentcore_alpha_AddEndpointOptions, _aws_cdk_aws_bedrock_agentcore_alpha_Runtime, _aws_cdk_aws_bedrock_agentcore_alpha_ICodeInterpreterCustom, _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustomBase, _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustomProps, _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustomAttributes, _aws_cdk_aws_bedrock_agentcore_alpha_CodeInterpreterCustom, _aws_cdk_aws_bedrock_agentcore_alpha_BrowserSigning, _aws_cdk_aws_bedrock_agentcore_alpha_IBrowserCustom, _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomBase, _aws_cdk_aws_bedrock_agentcore_alpha_RecordingConfig, _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomProps, _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustomAttributes, _aws_cdk_aws_bedrock_agentcore_alpha_BrowserCustom, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayExceptionLevel, _aws_cdk_aws_bedrock_agentcore_alpha_IGateway, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayBase, _aws_cdk_aws_bedrock_agentcore_alpha_AddLambdaTargetOptions, _aws_cdk_aws_bedrock_agentcore_alpha_AddOpenApiTargetOptions, _aws_cdk_aws_bedrock_agentcore_alpha_AddSmithyTargetOptions, _aws_cdk_aws_bedrock_agentcore_alpha_AddMcpServerTargetOptions, _aws_cdk_aws_bedrock_agentcore_alpha_AddApiGatewayTargetOptions, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayProps, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayAttributes, _aws_cdk_aws_bedrock_agentcore_alpha_Gateway, _aws_cdk_aws_bedrock_agentcore_alpha_InterceptionPoint, _aws_cdk_aws_bedrock_agentcore_alpha_InterceptorOptions, _aws_cdk_aws_bedrock_agentcore_alpha_IInterceptor, _aws_cdk_aws_bedrock_agentcore_alpha_InterceptorBindConfig, _aws_cdk_aws_bedrock_agentcore_alpha_LambdaInterceptor, _aws_cdk_aws_bedrock_agentcore_alpha_IGatewayProtocolConfig, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayProtocol, _aws_cdk_aws_bedrock_agentcore_alpha_MCPProtocolVersion, _aws_cdk_aws_bedrock_agentcore_alpha_McpGatewaySearchType, _aws_cdk_aws_bedrock_agentcore_alpha_McpConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_McpProtocolConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayAuthorizerType, _aws_cdk_aws_bedrock_agentcore_alpha_IGatewayAuthorizerConfig, _aws_cdk_aws_bedrock_agentcore_alpha_CustomJwtConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_CustomJwtAuthorizer, _aws_cdk_aws_bedrock_agentcore_alpha_IamAuthorizer, _aws_cdk_aws_bedrock_agentcore_alpha_CognitoAuthorizerProps, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayAuthorizer, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayCustomClaim, _aws_cdk_aws_bedrock_agentcore_alpha_CredentialProviderType, _aws_cdk_aws_bedrock_agentcore_alpha_ICredentialProviderConfig, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayCredentialProvider, _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyAdditionalConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyCredentialLocation, _aws_cdk_aws_bedrock_agentcore_alpha_ApiKeyCredentialProviderProps, _aws_cdk_aws_bedrock_agentcore_alpha_OAuthConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetProtocolType, _aws_cdk_aws_bedrock_agentcore_alpha_McpTargetType, _aws_cdk_aws_bedrock_agentcore_alpha_IGatewayTarget, _aws_cdk_aws_bedrock_agentcore_alpha_IMcpGatewayTarget, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetBase, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetCommonProps, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetProps, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetLambdaProps, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetOpenApiProps, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetSmithyProps, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetMcpServerProps, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetApiGatewayProps, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTargetAttributes, _aws_cdk_aws_bedrock_agentcore_alpha_GatewayTarget, _aws_cdk_aws_bedrock_agentcore_alpha_TargetConfigurationConfig, _aws_cdk_aws_bedrock_agentcore_alpha_ITargetConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_McpTargetConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_LambdaTargetConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_OpenApiTargetConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_SmithyTargetConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_McpServerTargetConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayHttpMethod, _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolFilter, _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolOverride, _aws_cdk_aws_bedrock_agentcore_alpha_MetadataConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayToolConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayTargetConfigurationProps, _aws_cdk_aws_bedrock_agentcore_alpha_ApiGatewayTargetConfiguration, _aws_cdk_aws_bedrock_agentcore_alpha_ApiSchema, _aws_cdk_aws_bedrock_agentcore_alpha_AssetApiSchema, _aws_cdk_aws_bedrock_agentcore_alpha_InlineApiSchema, _aws_cdk_aws_bedrock_agentcore_alpha_S3ApiSchema, _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinitionType, _aws_cdk_aws_bedrock_agentcore_alpha_SchemaDefinition, _aws_cdk_aws_bedrock_agentcore_alpha_ToolDefinition, _aws_cdk_aws_bedrock_agentcore_alpha_ToolSchema, _aws_cdk_aws_bedrock_agentcore_alpha_AssetToolSchema, _aws_cdk_aws_bedrock_agentcore_alpha_InlineToolSchema, _aws_cdk_aws_bedrock_agentcore_alpha_S3ToolSchema };
