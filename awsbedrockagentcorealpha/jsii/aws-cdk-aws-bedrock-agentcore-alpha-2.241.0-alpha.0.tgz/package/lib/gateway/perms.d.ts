/******************************************************************************
   * Data Plane Permissions
   *****************************************************************************/
/**
 * Permissions to invoke the gateway
 * Used by agents or other services that need to call the gateway
 */
export declare const GATEWAY_INVOKE_PERMS: string[];
/******************************************************************************
   * Execution Role Permissions
   *****************************************************************************/
/**
 * KMS permissions for encryption
 * Required when using KMS keys for encryption
 */
export declare const GATEWAY_KMS_KEY_PERMS: string[];
/**
 * Assume role permission
 * Required for the gateway service to assume the execution role
 */
export declare const GATEWAY_ASSUME_ROLE: string[];
/**
 * Outbound auth - Workload identity permissions
 * Used to obtain access tokens for workload identity
 */
export declare const GATEWAY_WORKLOAD_IDENTITY_PERMS: string[];
/**
 * Outbound auth - OAuth permissions
 * Used to obtain OAuth tokens for target authentication
 */
export declare const GATEWAY_OAUTH_PERMS: string[];
/**
 * Outbound auth - API Key permissions
 * Used to retrieve API keys for target authentication
 */
export declare const GATEWAY_API_KEY_PERMS: string[];
/**
 * Secrets Manager permissions
 * Required for storing and retrieving API keys and OAuth credentials
 */
export declare const GATEWAY_SECRETS_PERMS: string[];
/******************************************************************************
   * Control Plane Permissions
   *****************************************************************************/
/**
 * Get permissions for gateway resources
 */
export declare const GATEWAY_GET_PERMS: string[];
/**
 * List permissions for gateway resources
 */
export declare const GATEWAY_LIST_PERMS: string[];
/**
 * Create permissions for gateway resources
 */
export declare const GATEWAY_CREATE_PERMS: string[];
/**
 * Update permissions for gateway resources
 */
export declare const GATEWAY_UPDATE_PERMS: string[];
/**
 * Delete permissions for gateway resources
 */
export declare const GATEWAY_DELETE_PERMS: string[];
/**
 * Combined manage permissions (create, update, delete)
 */
export declare const GATEWAY_MANAGE_PERMS: string[];
/**
 * Synchronization permissions for MCP server targets
 * Used to refresh tool catalogs when MCP server tools change
 */
export declare const GATEWAY_SYNC_PERMS: string[];
