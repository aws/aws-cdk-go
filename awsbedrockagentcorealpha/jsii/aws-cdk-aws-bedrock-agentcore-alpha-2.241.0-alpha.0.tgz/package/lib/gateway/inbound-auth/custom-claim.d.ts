/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import type { CfnGateway } from 'aws-cdk-lib/aws-bedrockagentcore';
import { CustomClaimOperator } from '../../common/types';
/**
 * Represents a custom claim validation configuration for Gateway JWT authorizers.
 * Custom claims allow you to validate additional fields in JWT tokens beyond
 * the standard audience, client, and scope validations.
 */
export declare class GatewayCustomClaim {
    private readonly name;
    private readonly valueType;
    private readonly operator;
    private readonly value;
    /**
     * Create a custom claim with a string value.
     * String claims must use the EQUALS operator.
     *
     * @param name The name of the claim in the JWT token
     * @param value The string value to match (must exactly equal)
     * @returns A GatewayCustomClaim configured for string validation
     */
    static withStringValue(name: string, value: string): GatewayCustomClaim;
    /**
     * Create a custom claim with a string array value.
     * String array claims can use CONTAINS (default) or CONTAINS_ANY operator.
     *
     * @param name The name of the claim in the JWT token
     * @param values The array of string values to match. For CONTAINS operator, must contain exactly one value.
     * @param operator The match operator (defaults to CONTAINS)
     * @returns A GatewayCustomClaim configured for string array validation
     */
    static withStringArrayValue(name: string, values: string[], operator?: CustomClaimOperator): GatewayCustomClaim;
    private constructor();
    /**
     * Render the custom claim as a CloudFormation property
     * @internal
     */
    _render(): CfnGateway.CustomClaimValidationTypeProperty;
}
