import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { IBucket, Location } from 'aws-cdk-lib/aws-s3';
import * as s3_assets from 'aws-cdk-lib/aws-s3-assets';
import type { Construct } from 'constructs';
import { TargetSchema } from './base-schema';
/******************************************************************************
 *                       API SCHEMA CLASS
 *****************************************************************************/
/**
 * Represents the concept of an API Schema for a Gateway Target.
 */
export declare abstract class ApiSchema extends TargetSchema {
    /**
     * Creates an API Schema from a local file.
     * @param path - the path to the local file containing the OpenAPI schema for the action group
     */
    static fromLocalAsset(path: string): AssetApiSchema;
    /**
     * Creates an API Schema from an inline string.
     * @param schema - the JSON or YAML payload defining the schema (OpenAPI or Smithy)
     */
    static fromInline(schema: string): InlineApiSchema;
    /**
     * Creates an API Schema from an S3 File
     * @param bucket - the bucket containing the local file containing the OpenAPI schema for the action group
     * @param objectKey - object key in the bucket
     * @param bucketOwnerAccountId - optional The account ID of the Amazon S3 bucket owner. This ID is used for cross-account access to the bucket.
     */
    static fromS3File(bucket: IBucket, objectKey: string, bucketOwnerAccountId?: string): S3ApiSchema;
    /**
     * The S3 location of the API schema file, if using an S3-based schema.
     * Contains the bucket name and object key information.
     */
    readonly s3File?: Location;
    /**
     * The inline OpenAPI schema definition as a string, if using an inline schema.
     * Can be in JSON or YAML format.
     */
    readonly inlineSchema?: string;
    /**
     * The account ID of the S3 bucket owner for cross-account access
     */
    readonly bucketOwnerAccountId?: string;
    protected constructor(s3File?: Location, bucketOwnerAccountId?: string, inlineSchema?: string);
    /**
     * Format as CFN properties
     * @internal This is an internal core function and should not be called directly.
     */
    abstract _render(): any;
}
/**
 * API Schema from a local asset.
 *
 * The asset is uploaded to an S3 staging bucket, then moved to its final location
 * by CloudFormation during deployment.
 */
export declare class AssetApiSchema extends ApiSchema {
    private readonly path;
    private readonly options;
    private asset?;
    constructor(path: string, options?: s3_assets.AssetOptions);
    /**
     * Gets the file path for internal validation purposes
     * @internal
     */
    _getFilePath(): string;
    /**
     * Binds this API schema to a construct scope.
     * This method initializes the S3 asset if it hasn't been initialized yet.
     * Must be called before rendering the schema as CFN properties.
     *
     * @param scope - The construct scope to bind to
     */
    bind(scope: Construct): void;
    /**
     * Format as CFN properties
     * @internal This is an internal core function and should not be called directly.
     */
    _render(): any;
    grantPermissionsToRole(role: IRole): void;
}
/**
 * Class to define an API Schema from an inline string.
 * The schema can be provided directly as a string.
 * Validation is performed at the target configuration level where the schema type is known.
 */
export declare class InlineApiSchema extends ApiSchema {
    private readonly schema;
    constructor(schema: string);
    /**
     * @internal This is an internal core function and should not be called directly.
     */
    _render(): any;
    grantPermissionsToRole(_role: IRole): void;
    bind(scope: Construct): void;
}
/**
 * Class to define an API Schema from an S3 object.
 */
export declare class S3ApiSchema extends ApiSchema {
    private readonly location;
    readonly bucketOwnerAccountId?: string | undefined;
    constructor(location: Location, bucketOwnerAccountId?: string | undefined);
    /**
     * @internal This is an internal core function and should not be called directly.
     */
    _render(): any;
    bind(scope: Construct): void;
    grantPermissionsToRole(role: IRole): void;
}
