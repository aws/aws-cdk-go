/******************************************************************************
 *                               BROWSER
 *****************************************************************************/
/**
 * Permissions for the Browser tool
 * See https://docs.aws.amazon.com/service-authorization/latest/reference/list_amazonbedrockagentcore.html
 */
/******************************************************************************
   *                         Data Plane Permissions
   *****************************************************************************/
/**
 * Permissions to manage a specific browser session
 */
export declare const BROWSER_SESSION_PERMS: string[];
/**
 * Permissions to connect to a browser live view or automation stream
 */
export declare const BROWSER_STREAM_PERMS: string[];
/******************************************************************************
   *                         Control Plane Permissions
   *****************************************************************************/
/**
 * Grants control plane operations to manage the browser (CRUD)
 */
export declare const BROWSER_ADMIN_PERMS: string[];
/**
 * Permissions for reading browser information
 */
export declare const BROWSER_READ_PERMS: string[];
/**
 * Permissions for listing browser resources
 */
export declare const BROWSER_LIST_PERMS: string[];
/**
 * Permissions for using browser functionality
 */
export declare const BROWSER_USE_PERMS: string[];
/******************************************************************************
 *                               CODE INTERPRETER
 *****************************************************************************/
/**
 * Permissions for the Code Interpreter tool
 * See https://docs.aws.amazon.com/service-authorization/latest/reference/list_amazonbedrockagentcore.html
 */
/******************************************************************************
   *                         Data Plane Permissions
   *****************************************************************************/
/**
 * Permissions to manage a specific code interpreter session
 */
export declare const CODE_INTERPRETER_SESSION_PERMS: string[];
/**
 * Permissions to invoke a code interpreter
 */
export declare const CODE_INTERPRETER_INVOKE_PERMS: string[];
/******************************************************************************
   *                         Control Plane Permissions
   *****************************************************************************/
/**
 * Grants control plane operations to manage the code interpreter (CRUD)
 */
export declare const CODE_INTERPRETER_ADMIN_PERMS: string[];
/**
 * Permissions for reading code interpreter information
 */
export declare const CODE_INTERPRETER_READ_PERMS: string[];
/**
 * Permissions for listing code interpreter resources
 */
export declare const CODE_INTERPRETER_LIST_PERMS: string[];
/**
 * Permissions for using code interpreter functionality
 */
export declare const CODE_INTERPRETER_USE_PERMS: string[];
