import * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import type { RuntimeAuthorizerConfiguration } from './inbound-auth/runtime-authorizer-configuration';
import type { AgentRuntimeArtifact } from './runtime-artifact';
import type { IBedrockAgentRuntime, AgentRuntimeAttributes } from './runtime-base';
import { RuntimeBase } from './runtime-base';
import { RuntimeEndpoint } from './runtime-endpoint';
import type { LifecycleConfiguration, RequestHeaderConfiguration } from './types';
import { ProtocolType } from './types';
import { RuntimeNetworkConfiguration } from '../network/network-configuration';
/******************************************************************************
 *                                Props
 *****************************************************************************/
/**
 * Properties for creating a Bedrock Agent Core Runtime resource
 */
export interface RuntimeProps {
    /**
     * The name of the agent runtime
     * Valid characters are a-z, A-Z, 0-9, _ (underscore)
     * Must start with a letter and can be up to 48 characters long
     * Pattern: ^[a-zA-Z][a-zA-Z0-9_]{0,47}$
     * @default - auto generate
     */
    readonly runtimeName?: string;
    /**
     * The artifact configuration for the agent runtime
     * Contains the container configuration with ECR URI
     */
    readonly agentRuntimeArtifact: AgentRuntimeArtifact;
    /**
     * The IAM role that provides permissions for the agent runtime
     * If not provided, a role will be created automatically
     * @default - A new role will be created
     */
    readonly executionRole?: iam.IRole;
    /**
     * Network configuration for the agent runtime
     * @default - RuntimeNetworkConfiguration.usingPublicNetwork()
     */
    readonly networkConfiguration?: RuntimeNetworkConfiguration;
    /**
     * Optional description for the agent runtime
     * @default - No description
     * Length Minimum: 1 , Maximum: 1200
     */
    readonly description?: string;
    /**
     * Protocol configuration for the agent runtime
     * @default - ProtocolType.HTTP
     */
    readonly protocolConfiguration?: ProtocolType;
    /**
     * Environment variables for the agent runtime
     * - Maximum 50 environment variables
     * - Key: Must be 1-100 characters, start with letter or underscore, contain only letters, numbers, and underscores
     * - Value: Must be 0-2048 characters (per CloudFormation specification)
     * @default - No environment variables
     */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
     * Authorizer configuration for the agent runtime
     * Use RuntimeAuthorizerConfiguration static methods to create the configuration
     * @default - RuntimeAuthorizerConfiguration.iam() (IAM authentication)
     */
    readonly authorizerConfiguration?: RuntimeAuthorizerConfiguration;
    /**
     * Tags for the agent runtime
     * A list of key:value pairs of tags to apply to this Runtime resource
     * @default {} - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
    /**
     * Configuration for HTTP request headers that will be passed through to the runtime.
     * @default - No request headers configured
     */
    readonly requestHeaderConfiguration?: RequestHeaderConfiguration;
    /**
     * The life cycle configuration for the AgentCore Runtime.
     * @default - No lifecycle configuration
     */
    readonly lifecycleConfiguration?: LifecycleConfiguration;
}
/**
 * Options for adding an endpoint to the runtime
 */
export interface AddEndpointOptions {
    /**
     * Description for the endpoint, Must be between 1 and 1200 characters
     * @default - No description
     */
    readonly description?: string;
    /**
     * Override the runtime version for this endpoint
     * @default  1
     */
    readonly version?: string;
}
/******************************************************************************
 *                                Class
 *****************************************************************************/
/**
 * Bedrock Agent Core Runtime
 * Enables running containerized agents with specific network configurations,
 * security settings, and runtime artifacts.
 *
 * @resource AWS::BedrockAgentCore::Runtime
 * @see https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/runtime.html
 */
export declare class Runtime extends RuntimeBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing Agent Runtime using attributes
     * This allows you to reference an Agent Runtime that was created outside of CDK
     *
     * @param scope The construct scope
     * @param id The construct id
     * @param attrs The attributes of the existing Agent Runtime
     * @returns An IBedrockAgentRuntime instance representing the imported runtime
     */
    static fromAgentRuntimeAttributes(scope: Construct, id: string, attrs: AgentRuntimeAttributes): IBedrockAgentRuntime;
    /**
     * The ARN of the agent runtime
     * @attribute
     * @returns a token representing the ARN of this agent runtime
     */
    readonly agentRuntimeArn: string;
    /**
     * The unique identifier of the agent runtime
     * @attribute
     * @returns a token representing the ID of this agent runtime
     */
    readonly agentRuntimeId: string;
    /**
     * The name of the agent runtime
     * @attribute
     * @returns a token representing the name of this agent runtime
     */
    readonly agentRuntimeName: string;
    readonly role: iam.IRole;
    /**
     * The version of the agent runtime
     * @attribute
     * @returns a token representing the version of this agent runtime
     */
    readonly agentRuntimeVersion?: string;
    /**
     * The status of the agent runtime
     * @attribute
     * @returns a token representing the status of this agent runtime
     */
    readonly agentStatus?: string;
    /**
     * Optional description for the agent runtime
     */
    readonly description?: string;
    /**
     * The timestamp when the agent runtime was created
     * @attribute
     * @returns a token representing the creation timestamp of this agent runtime
     */
    readonly createdAt?: string;
    /**
     * The timestamp when the agent runtime was last updated
     * @attribute
     * @returns a token representing the last update timestamp of this agent runtime
     */
    readonly lastUpdatedAt?: string;
    readonly grantPrincipal: iam.IPrincipal;
    private readonly runtimeResource;
    /**
     * The artifact configuration for the agent runtime
     */
    readonly agentRuntimeArtifact: AgentRuntimeArtifact;
    private readonly networkConfiguration;
    private readonly protocolConfiguration;
    private readonly authorizerConfiguration?;
    private readonly lifecycleConfiguration?;
    constructor(scope: Construct, id: string, props: RuntimeProps);
    /**
     * Renders the environment variables for CloudFormation
     * @internal
     */
    private renderEnvironmentVariables;
    /**
     * Adds proper permissions to the execution role for the agent runtime
     * Based on: https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/runtime-permissions.html
     */
    private addExecutionRolePermissions;
    /**
     * Renders the artifact configuration for CloudFormation
     * @internal
     */
    private renderAgentRuntimeArtifact;
    /**
     * Renders the request header configuration for CloudFormation
     * @internal
     */
    private renderRequestHeaderConfiguration;
    /**
     * Renders the lifecycle configuration for CloudFormation
     * @internal
     */
    private renderLifecycleConfiguration;
    /**
     * Validates the request header configuration
     * @throws Error if validation fails
     */
    private validateRequestHeaderConfiguration;
    /**
     * Validates the lifecycle configuration
     * @throws Error if validation fails
     */
    private validateLifecycleConfiguration;
    /**
     * Validates the runtime name format
     * Pattern: ^[a-zA-Z][a-zA-Z0-9_]{0,47}$
     * @throws Error if validation fails
     */
    private validateRuntimeName;
    /**
     * Validates the description format
     * Must be between 1 and 1200 characters (per CloudFormation specification)
     * @throws Error if validation fails
     */
    private validateDescription;
    /**
     * Validates environment variables
     * - Maximum 50 entries
     * - Key: 1-100 characters
     * - Value: 0-2048 characters (per CloudFormation specification)
     * @throws Error if validation fails
     */
    private validateEnvironmentVariables;
    /**
     * Validates the tags format
     * @param tags The tags object to validate
     * @throws Error if validation fails
     */
    private validateTags;
    /**
     * Validates the container URI format
     */
    private validateContainerUri;
    /**
     * Validates the IAM role ARN format and structure
     * @throws Error if validation fails
     */
    private validateRoleArn;
    /**
     * Add an endpoint to this runtime
     * This is a convenience method that creates a RuntimeEndpoint associated with this runtime
     *
     * @param endpointName The name of the endpoint
     * @param options Optional configuration for the endpoint
     * @returns The created RuntimeEndpoint
     */
    addEndpoint(endpointName: string, options?: AddEndpointOptions): RuntimeEndpoint;
}
