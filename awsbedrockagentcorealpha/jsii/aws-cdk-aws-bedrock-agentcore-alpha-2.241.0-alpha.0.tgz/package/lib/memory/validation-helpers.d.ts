/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
import type { IConstruct } from 'constructs';
interface IntervalValidation {
    fieldName: string;
    minLength: number;
    maxLength: number;
}
interface StringLengthValidation extends IntervalValidation {
    value: string;
}
/**
 * Validates the length of a string field against minimum and maximum constraints.
 * @param params - Validation parameters including value, fieldName, minLength, and maxLength
 * @param scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateStringFieldLength(params: StringLengthValidation, _scope?: IConstruct): string[];
/**
 * Validates a string field against a regex pattern.
 * @param value - The string value to validate
 * @param fieldName - Name of the field being validated (for error messages)
 * @param pattern - Regular expression pattern to test against
 * @param customMessage - Optional custom error message
 * @param scope - The construct scope for error reporting (optional)
 * @returns Array of validation error messages, empty if valid
 */
export declare function validateFieldPattern(value: string, fieldName: string, pattern: RegExp, customMessage?: string, _scope?: IConstruct): string[];
export type ValidationFn<T> = (param: T, scope?: IConstruct) => string[];
export declare function throwIfInvalid<T>(validationFn: ValidationFn<T>, param: T, scope?: IConstruct): T;
export {};
