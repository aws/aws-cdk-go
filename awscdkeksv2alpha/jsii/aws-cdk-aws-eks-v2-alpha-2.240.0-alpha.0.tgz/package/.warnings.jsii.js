function _aws_cdk_aws_eks_v2_alpha_ICluster(p) {
}
function _aws_cdk_aws_eks_v2_alpha_ClusterAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("clusterName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterAttributes#clusterName", "");
        if ("clusterCertificateAuthorityData" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterAttributes#clusterCertificateAuthorityData", "");
        if ("clusterEncryptionConfigKeyArn" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterAttributes#clusterEncryptionConfigKeyArn", "");
        if ("clusterEndpoint" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterAttributes#clusterEndpoint", "");
        if ("clusterSecurityGroupId" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterAttributes#clusterSecurityGroupId", "");
        if ("ipFamily" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterAttributes#ipFamily", "");
        if (!visitedObjects.has(p.ipFamily))
            _aws_cdk_aws_eks_v2_alpha_IpFamily(p.ipFamily);
        if ("kubectlProvider" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterAttributes#kubectlProvider", "");
        if (!visitedObjects.has(p.kubectlProvider))
            _aws_cdk_aws_eks_v2_alpha_IKubectlProvider(p.kubectlProvider);
        if ("kubectlProviderOptions" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterAttributes#kubectlProviderOptions", "");
        if (!visitedObjects.has(p.kubectlProviderOptions))
            _aws_cdk_aws_eks_v2_alpha_KubectlProviderOptions(p.kubectlProviderOptions);
        if ("openIdConnectProvider" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterAttributes#openIdConnectProvider", "");
        if ("prune" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterAttributes#prune", "");
        if ("securityGroupIds" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterAttributes#securityGroupIds", "");
        if ("vpc" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterAttributes#vpc", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_ClusterCommonOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("version" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#version", "");
        if (!visitedObjects.has(p.version))
            _aws_cdk_aws_eks_v2_alpha_KubernetesVersion(p.version);
        if ("albController" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#albController", "");
        if (!visitedObjects.has(p.albController))
            _aws_cdk_aws_eks_v2_alpha_AlbControllerOptions(p.albController);
        if ("clusterLogging" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#clusterLogging", "");
        if (p.clusterLogging != null)
            for (const o of p.clusterLogging)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_ClusterLoggingTypes(o);
        if ("clusterName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#clusterName", "");
        if ("coreDnsComputeType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#coreDnsComputeType", "");
        if (!visitedObjects.has(p.coreDnsComputeType))
            _aws_cdk_aws_eks_v2_alpha_CoreDnsComputeType(p.coreDnsComputeType);
        if ("endpointAccess" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#endpointAccess", "");
        if (!visitedObjects.has(p.endpointAccess))
            _aws_cdk_aws_eks_v2_alpha_EndpointAccess(p.endpointAccess);
        if ("ipFamily" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#ipFamily", "");
        if (!visitedObjects.has(p.ipFamily))
            _aws_cdk_aws_eks_v2_alpha_IpFamily(p.ipFamily);
        if ("kubectlProviderOptions" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#kubectlProviderOptions", "");
        if (!visitedObjects.has(p.kubectlProviderOptions))
            _aws_cdk_aws_eks_v2_alpha_KubectlProviderOptions(p.kubectlProviderOptions);
        if ("mastersRole" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#mastersRole", "");
        if ("prune" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#prune", "");
        if ("remoteNodeNetworks" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#remoteNodeNetworks", "");
        if (p.remoteNodeNetworks != null)
            for (const o of p.remoteNodeNetworks)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_RemoteNodeNetwork(o);
        if ("remotePodNetworks" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#remotePodNetworks", "");
        if (p.remotePodNetworks != null)
            for (const o of p.remotePodNetworks)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_RemotePodNetwork(o);
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#removalPolicy", "");
        if ("role" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#role", "");
        if ("secretsEncryptionKey" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#secretsEncryptionKey", "");
        if ("securityGroup" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#securityGroup", "");
        if ("serviceIpv4Cidr" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#serviceIpv4Cidr", "");
        if ("tags" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#tags", "");
        if ("vpc" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#vpc", "");
        if ("vpcSubnets" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#vpcSubnets", "");
        if (p.vpcSubnets != null)
            for (const o of p.vpcSubnets)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_EndpointAccess(p) {
}
function _aws_cdk_aws_eks_v2_alpha_RemoteNodeNetwork(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("cidrs" in p)
            print("@aws-cdk/aws-eks-v2-alpha.RemoteNodeNetwork#cidrs", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_RemotePodNetwork(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("cidrs" in p)
            print("@aws-cdk/aws-eks-v2-alpha.RemotePodNetwork#cidrs", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_ComputeConfig(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("nodePools" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ComputeConfig#nodePools", "");
        if ("nodeRole" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ComputeConfig#nodeRole", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_ClusterProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("bootstrapClusterCreatorAdminPermissions" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterProps#bootstrapClusterCreatorAdminPermissions", "");
        if ("bootstrapSelfManagedAddons" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterProps#bootstrapSelfManagedAddons", "");
        if ("compute" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterProps#compute", "");
        if (!visitedObjects.has(p.compute))
            _aws_cdk_aws_eks_v2_alpha_ComputeConfig(p.compute);
        if ("defaultCapacity" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterProps#defaultCapacity", "");
        if ("defaultCapacityInstance" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterProps#defaultCapacityInstance", "");
        if ("defaultCapacityType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterProps#defaultCapacityType", "");
        if (!visitedObjects.has(p.defaultCapacityType))
            _aws_cdk_aws_eks_v2_alpha_DefaultCapacityType(p.defaultCapacityType);
        if ("outputConfigCommand" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterProps#outputConfigCommand", "");
        if ("version" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#version", "");
        if (!visitedObjects.has(p.version))
            _aws_cdk_aws_eks_v2_alpha_KubernetesVersion(p.version);
        if ("albController" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#albController", "");
        if (!visitedObjects.has(p.albController))
            _aws_cdk_aws_eks_v2_alpha_AlbControllerOptions(p.albController);
        if ("clusterLogging" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#clusterLogging", "");
        if (p.clusterLogging != null)
            for (const o of p.clusterLogging)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_ClusterLoggingTypes(o);
        if ("clusterName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#clusterName", "");
        if ("coreDnsComputeType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#coreDnsComputeType", "");
        if (!visitedObjects.has(p.coreDnsComputeType))
            _aws_cdk_aws_eks_v2_alpha_CoreDnsComputeType(p.coreDnsComputeType);
        if ("endpointAccess" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#endpointAccess", "");
        if (!visitedObjects.has(p.endpointAccess))
            _aws_cdk_aws_eks_v2_alpha_EndpointAccess(p.endpointAccess);
        if ("ipFamily" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#ipFamily", "");
        if (!visitedObjects.has(p.ipFamily))
            _aws_cdk_aws_eks_v2_alpha_IpFamily(p.ipFamily);
        if ("kubectlProviderOptions" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#kubectlProviderOptions", "");
        if (!visitedObjects.has(p.kubectlProviderOptions))
            _aws_cdk_aws_eks_v2_alpha_KubectlProviderOptions(p.kubectlProviderOptions);
        if ("mastersRole" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#mastersRole", "");
        if ("prune" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#prune", "");
        if ("remoteNodeNetworks" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#remoteNodeNetworks", "");
        if (p.remoteNodeNetworks != null)
            for (const o of p.remoteNodeNetworks)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_RemoteNodeNetwork(o);
        if ("remotePodNetworks" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#remotePodNetworks", "");
        if (p.remotePodNetworks != null)
            for (const o of p.remotePodNetworks)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_RemotePodNetwork(o);
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#removalPolicy", "");
        if ("role" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#role", "");
        if ("secretsEncryptionKey" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#secretsEncryptionKey", "");
        if ("securityGroup" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#securityGroup", "");
        if ("serviceIpv4Cidr" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#serviceIpv4Cidr", "");
        if ("tags" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#tags", "");
        if ("vpc" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#vpc", "");
        if ("vpcSubnets" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#vpcSubnets", "");
        if (p.vpcSubnets != null)
            for (const o of p.vpcSubnets)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_KubernetesVersion(p) {
}
function _aws_cdk_aws_eks_v2_alpha_ClusterLoggingTypes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.ClusterLoggingTypes", "");
        const ns = require("./lib/cluster.js");
        if (Object.values(ns.ClusterLoggingTypes).filter(x => x === p).length > 1)
            return;
        if (p === ns.ClusterLoggingTypes.API)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterLoggingTypes#API", "");
        if (p === ns.ClusterLoggingTypes.AUDIT)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterLoggingTypes#AUDIT", "");
        if (p === ns.ClusterLoggingTypes.AUTHENTICATOR)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterLoggingTypes#AUTHENTICATOR", "");
        if (p === ns.ClusterLoggingTypes.CONTROLLER_MANAGER)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterLoggingTypes#CONTROLLER_MANAGER", "");
        if (p === ns.ClusterLoggingTypes.SCHEDULER)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterLoggingTypes#SCHEDULER", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_IpFamily(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.IpFamily", "");
        const ns = require("./lib/cluster.js");
        if (Object.values(ns.IpFamily).filter(x => x === p).length > 1)
            return;
        if (p === ns.IpFamily.IP_V4)
            print("@aws-cdk/aws-eks-v2-alpha.IpFamily#IP_V4", "");
        if (p === ns.IpFamily.IP_V6)
            print("@aws-cdk/aws-eks-v2-alpha.IpFamily#IP_V6", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_ServiceLoadBalancerAddressOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("namespace" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceLoadBalancerAddressOptions#namespace", "");
        if ("timeout" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceLoadBalancerAddressOptions#timeout", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_IngressLoadBalancerAddressOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("namespace" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceLoadBalancerAddressOptions#namespace", "");
        if ("timeout" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceLoadBalancerAddressOptions#timeout", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_GrantAccessOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("accessEntryType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.GrantAccessOptions#accessEntryType", "");
        if (!visitedObjects.has(p.accessEntryType))
            _aws_cdk_aws_eks_v2_alpha_AccessEntryType(p.accessEntryType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_Cluster(p) {
}
function _aws_cdk_aws_eks_v2_alpha_AutoScalingGroupCapacityOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("instanceType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AutoScalingGroupCapacityOptions#instanceType", "");
        if ("bootstrapEnabled" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AutoScalingGroupCapacityOptions#bootstrapEnabled", "");
        if ("bootstrapOptions" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AutoScalingGroupCapacityOptions#bootstrapOptions", "");
        if (!visitedObjects.has(p.bootstrapOptions))
            _aws_cdk_aws_eks_v2_alpha_BootstrapOptions(p.bootstrapOptions);
        if ("machineImageType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AutoScalingGroupCapacityOptions#machineImageType", "");
        if (!visitedObjects.has(p.machineImageType))
            _aws_cdk_aws_eks_v2_alpha_MachineImageType(p.machineImageType);
        if (p.blockDevices != null)
            for (const o of p.blockDevices)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_autoscaling_BlockDevice(o);
        if (p.groupMetrics != null)
            for (const o of p.groupMetrics)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_autoscaling_GroupMetrics(o);
        if ("healthCheck" in p)
            print("aws-cdk-lib.aws_autoscaling.CommonAutoScalingGroupProps#healthCheck", "Use `healthChecks` instead");
        if ("keyName" in p)
            print("aws-cdk-lib.aws_autoscaling.CommonAutoScalingGroupProps#keyName", "- Use `keyPair` instead - https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_ec2-readme.html#using-an-existing-ec2-key-pair");
        if (p.notifications != null)
            for (const o of p.notifications)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_autoscaling_NotificationConfiguration(o);
        if (p.terminationPolicies != null)
            for (const o of p.terminationPolicies)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_autoscaling_TerminationPolicy(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_BootstrapOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("additionalArgs" in p)
            print("@aws-cdk/aws-eks-v2-alpha.BootstrapOptions#additionalArgs", "");
        if ("awsApiRetryAttempts" in p)
            print("@aws-cdk/aws-eks-v2-alpha.BootstrapOptions#awsApiRetryAttempts", "");
        if ("dnsClusterIp" in p)
            print("@aws-cdk/aws-eks-v2-alpha.BootstrapOptions#dnsClusterIp", "");
        if ("dockerConfigJson" in p)
            print("@aws-cdk/aws-eks-v2-alpha.BootstrapOptions#dockerConfigJson", "");
        if ("enableDockerBridge" in p)
            print("@aws-cdk/aws-eks-v2-alpha.BootstrapOptions#enableDockerBridge", "");
        if ("kubeletExtraArgs" in p)
            print("@aws-cdk/aws-eks-v2-alpha.BootstrapOptions#kubeletExtraArgs", "");
        if ("useMaxPods" in p)
            print("@aws-cdk/aws-eks-v2-alpha.BootstrapOptions#useMaxPods", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_AutoScalingGroupOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("bootstrapEnabled" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AutoScalingGroupOptions#bootstrapEnabled", "");
        if ("bootstrapOptions" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AutoScalingGroupOptions#bootstrapOptions", "");
        if (!visitedObjects.has(p.bootstrapOptions))
            _aws_cdk_aws_eks_v2_alpha_BootstrapOptions(p.bootstrapOptions);
        if ("machineImageType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AutoScalingGroupOptions#machineImageType", "");
        if (!visitedObjects.has(p.machineImageType))
            _aws_cdk_aws_eks_v2_alpha_MachineImageType(p.machineImageType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_EksOptimizedImageProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("cpuArch" in p)
            print("@aws-cdk/aws-eks-v2-alpha.EksOptimizedImageProps#cpuArch", "");
        if (!visitedObjects.has(p.cpuArch))
            _aws_cdk_aws_eks_v2_alpha_CpuArch(p.cpuArch);
        if ("kubernetesVersion" in p)
            print("@aws-cdk/aws-eks-v2-alpha.EksOptimizedImageProps#kubernetesVersion", "");
        if ("nodeType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.EksOptimizedImageProps#nodeType", "");
        if (!visitedObjects.has(p.nodeType))
            _aws_cdk_aws_eks_v2_alpha_NodeType(p.nodeType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_EksOptimizedImage(p) {
}
function _aws_cdk_aws_eks_v2_alpha_NodeType(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.NodeType", "");
        const ns = require("./lib/cluster.js");
        if (Object.values(ns.NodeType).filter(x => x === p).length > 1)
            return;
        if (p === ns.NodeType.STANDARD)
            print("@aws-cdk/aws-eks-v2-alpha.NodeType#STANDARD", "");
        if (p === ns.NodeType.GPU)
            print("@aws-cdk/aws-eks-v2-alpha.NodeType#GPU", "");
        if (p === ns.NodeType.INFERENTIA)
            print("@aws-cdk/aws-eks-v2-alpha.NodeType#INFERENTIA", "");
        if (p === ns.NodeType.TRAINIUM)
            print("@aws-cdk/aws-eks-v2-alpha.NodeType#TRAINIUM", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_CpuArch(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.CpuArch", "");
        const ns = require("./lib/cluster.js");
        if (Object.values(ns.CpuArch).filter(x => x === p).length > 1)
            return;
        if (p === ns.CpuArch.ARM_64)
            print("@aws-cdk/aws-eks-v2-alpha.CpuArch#ARM_64", "");
        if (p === ns.CpuArch.X86_64)
            print("@aws-cdk/aws-eks-v2-alpha.CpuArch#X86_64", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_CoreDnsComputeType(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.CoreDnsComputeType", "");
        const ns = require("./lib/cluster.js");
        if (Object.values(ns.CoreDnsComputeType).filter(x => x === p).length > 1)
            return;
        if (p === ns.CoreDnsComputeType.EC2)
            print("@aws-cdk/aws-eks-v2-alpha.CoreDnsComputeType#EC2", "");
        if (p === ns.CoreDnsComputeType.FARGATE)
            print("@aws-cdk/aws-eks-v2-alpha.CoreDnsComputeType#FARGATE", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_DefaultCapacityType(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.DefaultCapacityType", "");
        const ns = require("./lib/cluster.js");
        if (Object.values(ns.DefaultCapacityType).filter(x => x === p).length > 1)
            return;
        if (p === ns.DefaultCapacityType.NODEGROUP)
            print("@aws-cdk/aws-eks-v2-alpha.DefaultCapacityType#NODEGROUP", "");
        if (p === ns.DefaultCapacityType.EC2)
            print("@aws-cdk/aws-eks-v2-alpha.DefaultCapacityType#EC2", "");
        if (p === ns.DefaultCapacityType.AUTOMODE)
            print("@aws-cdk/aws-eks-v2-alpha.DefaultCapacityType#AUTOMODE", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_MachineImageType(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.MachineImageType", "");
        const ns = require("./lib/cluster.js");
        if (Object.values(ns.MachineImageType).filter(x => x === p).length > 1)
            return;
        if (p === ns.MachineImageType.AMAZON_LINUX_2)
            print("@aws-cdk/aws-eks-v2-alpha.MachineImageType#AMAZON_LINUX_2", "");
        if (p === ns.MachineImageType.BOTTLEROCKET)
            print("@aws-cdk/aws-eks-v2-alpha.MachineImageType#BOTTLEROCKET", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_FargateProfileOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("selectors" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateProfileOptions#selectors", "");
        if (p.selectors != null)
            for (const o of p.selectors)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_Selector(o);
        if ("fargateProfileName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateProfileOptions#fargateProfileName", "");
        if ("podExecutionRole" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateProfileOptions#podExecutionRole", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateProfileOptions#removalPolicy", "");
        if ("subnetSelection" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateProfileOptions#subnetSelection", "");
        if ("vpc" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateProfileOptions#vpc", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_FargateProfileProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("cluster" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateProfileProps#cluster", "");
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_eks_v2_alpha_Cluster(p.cluster);
        if ("selectors" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateProfileOptions#selectors", "");
        if (p.selectors != null)
            for (const o of p.selectors)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_Selector(o);
        if ("fargateProfileName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateProfileOptions#fargateProfileName", "");
        if ("podExecutionRole" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateProfileOptions#podExecutionRole", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateProfileOptions#removalPolicy", "");
        if ("subnetSelection" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateProfileOptions#subnetSelection", "");
        if ("vpc" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateProfileOptions#vpc", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_Selector(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("namespace" in p)
            print("@aws-cdk/aws-eks-v2-alpha.Selector#namespace", "");
        if ("labels" in p)
            print("@aws-cdk/aws-eks-v2-alpha.Selector#labels", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_FargateProfile(p) {
}
function _aws_cdk_aws_eks_v2_alpha_HelmChartOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("atomic" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#atomic", "");
        if ("chart" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#chart", "");
        if ("chartAsset" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#chartAsset", "");
        if ("createNamespace" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#createNamespace", "");
        if ("namespace" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#namespace", "");
        if ("release" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#release", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#removalPolicy", "");
        if ("repository" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#repository", "");
        if ("skipCrds" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#skipCrds", "");
        if ("timeout" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#timeout", "");
        if ("values" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#values", "");
        if ("version" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#version", "");
        if ("wait" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#wait", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_HelmChartProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("cluster" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartProps#cluster", "");
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_eks_v2_alpha_ICluster(p.cluster);
        if ("atomic" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#atomic", "");
        if ("chart" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#chart", "");
        if ("chartAsset" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#chartAsset", "");
        if ("createNamespace" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#createNamespace", "");
        if ("namespace" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#namespace", "");
        if ("release" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#release", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#removalPolicy", "");
        if ("repository" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#repository", "");
        if ("skipCrds" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#skipCrds", "");
        if ("timeout" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#timeout", "");
        if ("values" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#values", "");
        if ("version" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#version", "");
        if ("wait" in p)
            print("@aws-cdk/aws-eks-v2-alpha.HelmChartOptions#wait", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_HelmChart(p) {
}
function _aws_cdk_aws_eks_v2_alpha_KubernetesPatchProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("applyPatch" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesPatchProps#applyPatch", "");
        if ("cluster" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesPatchProps#cluster", "");
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_eks_v2_alpha_ICluster(p.cluster);
        if ("resourceName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesPatchProps#resourceName", "");
        if ("restorePatch" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesPatchProps#restorePatch", "");
        if ("patchType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesPatchProps#patchType", "");
        if (!visitedObjects.has(p.patchType))
            _aws_cdk_aws_eks_v2_alpha_PatchType(p.patchType);
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesPatchProps#removalPolicy", "");
        if ("resourceNamespace" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesPatchProps#resourceNamespace", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_PatchType(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.PatchType", "");
        const ns = require("./lib/k8s-patch.js");
        if (Object.values(ns.PatchType).filter(x => x === p).length > 1)
            return;
        if (p === ns.PatchType.JSON)
            print("@aws-cdk/aws-eks-v2-alpha.PatchType#JSON", "");
        if (p === ns.PatchType.MERGE)
            print("@aws-cdk/aws-eks-v2-alpha.PatchType#MERGE", "");
        if (p === ns.PatchType.STRATEGIC)
            print("@aws-cdk/aws-eks-v2-alpha.PatchType#STRATEGIC", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_KubernetesPatch(p) {
}
function _aws_cdk_aws_eks_v2_alpha_KubernetesManifestOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("ingressAlb" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesManifestOptions#ingressAlb", "");
        if ("ingressAlbScheme" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesManifestOptions#ingressAlbScheme", "");
        if (!visitedObjects.has(p.ingressAlbScheme))
            _aws_cdk_aws_eks_v2_alpha_AlbScheme(p.ingressAlbScheme);
        if ("prune" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesManifestOptions#prune", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesManifestOptions#removalPolicy", "");
        if ("skipValidation" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesManifestOptions#skipValidation", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_KubernetesManifestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("cluster" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesManifestProps#cluster", "");
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_eks_v2_alpha_ICluster(p.cluster);
        if ("manifest" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesManifestProps#manifest", "");
        if ("overwrite" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesManifestProps#overwrite", "");
        if ("ingressAlb" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesManifestOptions#ingressAlb", "");
        if ("ingressAlbScheme" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesManifestOptions#ingressAlbScheme", "");
        if (!visitedObjects.has(p.ingressAlbScheme))
            _aws_cdk_aws_eks_v2_alpha_AlbScheme(p.ingressAlbScheme);
        if ("prune" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesManifestOptions#prune", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesManifestOptions#removalPolicy", "");
        if ("skipValidation" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesManifestOptions#skipValidation", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_KubernetesManifest(p) {
}
function _aws_cdk_aws_eks_v2_alpha_KubernetesObjectValueProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("cluster" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesObjectValueProps#cluster", "");
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_eks_v2_alpha_ICluster(p.cluster);
        if ("jsonPath" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesObjectValueProps#jsonPath", "");
        if ("objectName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesObjectValueProps#objectName", "");
        if ("objectType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesObjectValueProps#objectType", "");
        if ("objectNamespace" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesObjectValueProps#objectNamespace", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesObjectValueProps#removalPolicy", "");
        if ("timeout" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubernetesObjectValueProps#timeout", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_KubernetesObjectValue(p) {
}
function _aws_cdk_aws_eks_v2_alpha_KubectlProviderOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("kubectlLayer" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#kubectlLayer", "");
        if ("awscliLayer" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#awscliLayer", "");
        if ("environment" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#environment", "");
        if ("memory" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#memory", "");
        if ("privateSubnets" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#privateSubnets", "");
        if (p.privateSubnets != null)
            for (const o of p.privateSubnets)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISubnet(o);
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#removalPolicy", "");
        if ("role" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#role", "");
        if ("securityGroup" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#securityGroup", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_KubectlProviderProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("cluster" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderProps#cluster", "");
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_eks_v2_alpha_ICluster(p.cluster);
        if ("kubectlLayer" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#kubectlLayer", "");
        if ("awscliLayer" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#awscliLayer", "");
        if ("environment" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#environment", "");
        if ("memory" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#memory", "");
        if ("privateSubnets" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#privateSubnets", "");
        if (p.privateSubnets != null)
            for (const o of p.privateSubnets)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISubnet(o);
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#removalPolicy", "");
        if ("role" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#role", "");
        if ("securityGroup" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderOptions#securityGroup", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_KubectlProviderAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("serviceToken" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderAttributes#serviceToken", "");
        if ("role" in p)
            print("@aws-cdk/aws-eks-v2-alpha.KubectlProviderAttributes#role", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_IKubectlProvider(p) {
}
function _aws_cdk_aws_eks_v2_alpha_KubectlProvider(p) {
}
function _aws_cdk_aws_eks_v2_alpha_FargateClusterProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("defaultProfile" in p)
            print("@aws-cdk/aws-eks-v2-alpha.FargateClusterProps#defaultProfile", "");
        if (!visitedObjects.has(p.defaultProfile))
            _aws_cdk_aws_eks_v2_alpha_FargateProfileOptions(p.defaultProfile);
        if ("version" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#version", "");
        if (!visitedObjects.has(p.version))
            _aws_cdk_aws_eks_v2_alpha_KubernetesVersion(p.version);
        if ("albController" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#albController", "");
        if (!visitedObjects.has(p.albController))
            _aws_cdk_aws_eks_v2_alpha_AlbControllerOptions(p.albController);
        if ("clusterLogging" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#clusterLogging", "");
        if (p.clusterLogging != null)
            for (const o of p.clusterLogging)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_ClusterLoggingTypes(o);
        if ("clusterName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#clusterName", "");
        if ("coreDnsComputeType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#coreDnsComputeType", "");
        if (!visitedObjects.has(p.coreDnsComputeType))
            _aws_cdk_aws_eks_v2_alpha_CoreDnsComputeType(p.coreDnsComputeType);
        if ("endpointAccess" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#endpointAccess", "");
        if (!visitedObjects.has(p.endpointAccess))
            _aws_cdk_aws_eks_v2_alpha_EndpointAccess(p.endpointAccess);
        if ("ipFamily" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#ipFamily", "");
        if (!visitedObjects.has(p.ipFamily))
            _aws_cdk_aws_eks_v2_alpha_IpFamily(p.ipFamily);
        if ("kubectlProviderOptions" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#kubectlProviderOptions", "");
        if (!visitedObjects.has(p.kubectlProviderOptions))
            _aws_cdk_aws_eks_v2_alpha_KubectlProviderOptions(p.kubectlProviderOptions);
        if ("mastersRole" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#mastersRole", "");
        if ("prune" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#prune", "");
        if ("remoteNodeNetworks" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#remoteNodeNetworks", "");
        if (p.remoteNodeNetworks != null)
            for (const o of p.remoteNodeNetworks)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_RemoteNodeNetwork(o);
        if ("remotePodNetworks" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#remotePodNetworks", "");
        if (p.remotePodNetworks != null)
            for (const o of p.remotePodNetworks)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_RemotePodNetwork(o);
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#removalPolicy", "");
        if ("role" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#role", "");
        if ("secretsEncryptionKey" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#secretsEncryptionKey", "");
        if ("securityGroup" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#securityGroup", "");
        if ("serviceIpv4Cidr" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#serviceIpv4Cidr", "");
        if ("tags" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#tags", "");
        if ("vpc" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#vpc", "");
        if ("vpcSubnets" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ClusterCommonOptions#vpcSubnets", "");
        if (p.vpcSubnets != null)
            for (const o of p.vpcSubnets)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_FargateCluster(p) {
}
function _aws_cdk_aws_eks_v2_alpha_IdentityType(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.IdentityType", "");
        const ns = require("./lib/service-account.js");
        if (Object.values(ns.IdentityType).filter(x => x === p).length > 1)
            return;
        if (p === ns.IdentityType.IRSA)
            print("@aws-cdk/aws-eks-v2-alpha.IdentityType#IRSA", "");
        if (p === ns.IdentityType.POD_IDENTITY)
            print("@aws-cdk/aws-eks-v2-alpha.IdentityType#POD_IDENTITY", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_ServiceAccountOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("annotations" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#annotations", "");
        if ("identityType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#identityType", "");
        if (!visitedObjects.has(p.identityType))
            _aws_cdk_aws_eks_v2_alpha_IdentityType(p.identityType);
        if ("labels" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#labels", "");
        if ("name" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#name", "");
        if ("namespace" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#namespace", "");
        if ("overwriteServiceAccount" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#overwriteServiceAccount", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#removalPolicy", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_ServiceAccountProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("cluster" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountProps#cluster", "");
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_eks_v2_alpha_ICluster(p.cluster);
        if ("annotations" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#annotations", "");
        if ("identityType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#identityType", "");
        if (!visitedObjects.has(p.identityType))
            _aws_cdk_aws_eks_v2_alpha_IdentityType(p.identityType);
        if ("labels" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#labels", "");
        if ("name" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#name", "");
        if ("namespace" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#namespace", "");
        if ("overwriteServiceAccount" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#overwriteServiceAccount", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.ServiceAccountOptions#removalPolicy", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_ServiceAccount(p) {
}
function _aws_cdk_aws_eks_v2_alpha_INodegroup(p) {
}
function _aws_cdk_aws_eks_v2_alpha_NodegroupAmiType(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType", "");
        const ns = require("./lib/managed-nodegroup.js");
        if (Object.values(ns.NodegroupAmiType).filter(x => x === p).length > 1)
            return;
        if (p === ns.NodegroupAmiType.AL2_X86_64)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#AL2_X86_64", "");
        if (p === ns.NodegroupAmiType.AL2_X86_64_GPU)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#AL2_X86_64_GPU", "");
        if (p === ns.NodegroupAmiType.AL2_ARM_64)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#AL2_ARM_64", "");
        if (p === ns.NodegroupAmiType.BOTTLEROCKET_ARM_64)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#BOTTLEROCKET_ARM_64", "");
        if (p === ns.NodegroupAmiType.BOTTLEROCKET_X86_64)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#BOTTLEROCKET_X86_64", "");
        if (p === ns.NodegroupAmiType.BOTTLEROCKET_ARM_64_NVIDIA)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#BOTTLEROCKET_ARM_64_NVIDIA", "");
        if (p === ns.NodegroupAmiType.BOTTLEROCKET_X86_64_NVIDIA)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#BOTTLEROCKET_X86_64_NVIDIA", "");
        if (p === ns.NodegroupAmiType.BOTTLEROCKET_ARM_64_FIPS)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#BOTTLEROCKET_ARM_64_FIPS", "");
        if (p === ns.NodegroupAmiType.BOTTLEROCKET_X86_64_FIPS)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#BOTTLEROCKET_X86_64_FIPS", "");
        if (p === ns.NodegroupAmiType.WINDOWS_CORE_2019_X86_64)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#WINDOWS_CORE_2019_X86_64", "");
        if (p === ns.NodegroupAmiType.WINDOWS_CORE_2022_X86_64)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#WINDOWS_CORE_2022_X86_64", "");
        if (p === ns.NodegroupAmiType.WINDOWS_FULL_2019_X86_64)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#WINDOWS_FULL_2019_X86_64", "");
        if (p === ns.NodegroupAmiType.WINDOWS_FULL_2022_X86_64)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#WINDOWS_FULL_2022_X86_64", "");
        if (p === ns.NodegroupAmiType.AL2023_X86_64_STANDARD)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#AL2023_X86_64_STANDARD", "");
        if (p === ns.NodegroupAmiType.AL2023_X86_64_NEURON)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#AL2023_X86_64_NEURON", "");
        if (p === ns.NodegroupAmiType.AL2023_X86_64_NVIDIA)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#AL2023_X86_64_NVIDIA", "");
        if (p === ns.NodegroupAmiType.AL2023_ARM_64_NVIDIA)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#AL2023_ARM_64_NVIDIA", "");
        if (p === ns.NodegroupAmiType.AL2023_ARM_64_STANDARD)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupAmiType#AL2023_ARM_64_STANDARD", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_CapacityType(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.CapacityType", "");
        const ns = require("./lib/managed-nodegroup.js");
        if (Object.values(ns.CapacityType).filter(x => x === p).length > 1)
            return;
        if (p === ns.CapacityType.SPOT)
            print("@aws-cdk/aws-eks-v2-alpha.CapacityType#SPOT", "");
        if (p === ns.CapacityType.ON_DEMAND)
            print("@aws-cdk/aws-eks-v2-alpha.CapacityType#ON_DEMAND", "");
        if (p === ns.CapacityType.CAPACITY_BLOCK)
            print("@aws-cdk/aws-eks-v2-alpha.CapacityType#CAPACITY_BLOCK", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_NodegroupRemoteAccess(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("sshKeyName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupRemoteAccess#sshKeyName", "");
        if ("sourceSecurityGroups" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupRemoteAccess#sourceSecurityGroups", "");
        if (p.sourceSecurityGroups != null)
            for (const o of p.sourceSecurityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_LaunchTemplateSpec(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("id" in p)
            print("@aws-cdk/aws-eks-v2-alpha.LaunchTemplateSpec#id", "");
        if ("version" in p)
            print("@aws-cdk/aws-eks-v2-alpha.LaunchTemplateSpec#version", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_TaintEffect(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.TaintEffect", "");
        const ns = require("./lib/managed-nodegroup.js");
        if (Object.values(ns.TaintEffect).filter(x => x === p).length > 1)
            return;
        if (p === ns.TaintEffect.NO_SCHEDULE)
            print("@aws-cdk/aws-eks-v2-alpha.TaintEffect#NO_SCHEDULE", "");
        if (p === ns.TaintEffect.PREFER_NO_SCHEDULE)
            print("@aws-cdk/aws-eks-v2-alpha.TaintEffect#PREFER_NO_SCHEDULE", "");
        if (p === ns.TaintEffect.NO_EXECUTE)
            print("@aws-cdk/aws-eks-v2-alpha.TaintEffect#NO_EXECUTE", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_TaintSpec(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("effect" in p)
            print("@aws-cdk/aws-eks-v2-alpha.TaintSpec#effect", "");
        if (!visitedObjects.has(p.effect))
            _aws_cdk_aws_eks_v2_alpha_TaintEffect(p.effect);
        if ("key" in p)
            print("@aws-cdk/aws-eks-v2-alpha.TaintSpec#key", "");
        if ("value" in p)
            print("@aws-cdk/aws-eks-v2-alpha.TaintSpec#value", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_NodegroupOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("amiType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#amiType", "");
        if (!visitedObjects.has(p.amiType))
            _aws_cdk_aws_eks_v2_alpha_NodegroupAmiType(p.amiType);
        if ("capacityType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#capacityType", "");
        if (!visitedObjects.has(p.capacityType))
            _aws_cdk_aws_eks_v2_alpha_CapacityType(p.capacityType);
        if ("desiredSize" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#desiredSize", "");
        if ("diskSize" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#diskSize", "");
        if ("enableNodeAutoRepair" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#enableNodeAutoRepair", "");
        if ("forceUpdate" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#forceUpdate", "");
        if ("instanceType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#instanceType", "Use `instanceTypes` instead.");
        if ("instanceTypes" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#instanceTypes", "");
        if (p.instanceTypes != null)
            for (const o of p.instanceTypes)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_InstanceType(o);
        if ("labels" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#labels", "");
        if ("launchTemplateSpec" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#launchTemplateSpec", "");
        if (!visitedObjects.has(p.launchTemplateSpec))
            _aws_cdk_aws_eks_v2_alpha_LaunchTemplateSpec(p.launchTemplateSpec);
        if ("maxSize" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#maxSize", "");
        if ("maxUnavailable" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#maxUnavailable", "");
        if ("maxUnavailablePercentage" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#maxUnavailablePercentage", "");
        if ("minSize" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#minSize", "");
        if ("nodegroupName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#nodegroupName", "");
        if ("nodeRole" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#nodeRole", "");
        if ("releaseVersion" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#releaseVersion", "");
        if ("remoteAccess" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#remoteAccess", "");
        if (!visitedObjects.has(p.remoteAccess))
            _aws_cdk_aws_eks_v2_alpha_NodegroupRemoteAccess(p.remoteAccess);
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#removalPolicy", "");
        if ("subnets" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#subnets", "");
        if ("tags" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#tags", "");
        if ("taints" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#taints", "");
        if (p.taints != null)
            for (const o of p.taints)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_TaintSpec(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_NodegroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("cluster" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupProps#cluster", "");
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_eks_v2_alpha_ICluster(p.cluster);
        if ("amiType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#amiType", "");
        if (!visitedObjects.has(p.amiType))
            _aws_cdk_aws_eks_v2_alpha_NodegroupAmiType(p.amiType);
        if ("capacityType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#capacityType", "");
        if (!visitedObjects.has(p.capacityType))
            _aws_cdk_aws_eks_v2_alpha_CapacityType(p.capacityType);
        if ("desiredSize" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#desiredSize", "");
        if ("diskSize" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#diskSize", "");
        if ("enableNodeAutoRepair" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#enableNodeAutoRepair", "");
        if ("forceUpdate" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#forceUpdate", "");
        if ("instanceType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#instanceType", "Use `instanceTypes` instead.");
        if ("instanceTypes" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#instanceTypes", "");
        if (p.instanceTypes != null)
            for (const o of p.instanceTypes)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_InstanceType(o);
        if ("labels" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#labels", "");
        if ("launchTemplateSpec" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#launchTemplateSpec", "");
        if (!visitedObjects.has(p.launchTemplateSpec))
            _aws_cdk_aws_eks_v2_alpha_LaunchTemplateSpec(p.launchTemplateSpec);
        if ("maxSize" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#maxSize", "");
        if ("maxUnavailable" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#maxUnavailable", "");
        if ("maxUnavailablePercentage" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#maxUnavailablePercentage", "");
        if ("minSize" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#minSize", "");
        if ("nodegroupName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#nodegroupName", "");
        if ("nodeRole" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#nodeRole", "");
        if ("releaseVersion" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#releaseVersion", "");
        if ("remoteAccess" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#remoteAccess", "");
        if (!visitedObjects.has(p.remoteAccess))
            _aws_cdk_aws_eks_v2_alpha_NodegroupRemoteAccess(p.remoteAccess);
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#removalPolicy", "");
        if ("subnets" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#subnets", "");
        if ("tags" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#tags", "");
        if ("taints" in p)
            print("@aws-cdk/aws-eks-v2-alpha.NodegroupOptions#taints", "");
        if (p.taints != null)
            for (const o of p.taints)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_TaintSpec(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_Nodegroup(p) {
}
function _aws_cdk_aws_eks_v2_alpha_OpenIdConnectProviderProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("url" in p)
            print("@aws-cdk/aws-eks-v2-alpha.OpenIdConnectProviderProps#url", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.OpenIdConnectProviderProps#removalPolicy", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_OidcProviderNativeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("url" in p)
            print("@aws-cdk/aws-eks-v2-alpha.OpenIdConnectProviderProps#url", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.OpenIdConnectProviderProps#removalPolicy", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_OpenIdConnectProvider(p) {
}
function _aws_cdk_aws_eks_v2_alpha_OidcProviderNative(p) {
}
function _aws_cdk_aws_eks_v2_alpha_AlbControllerVersion(p) {
}
function _aws_cdk_aws_eks_v2_alpha_AlbScheme(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.AlbScheme", "");
        const ns = require("./lib/alb-controller.js");
        if (Object.values(ns.AlbScheme).filter(x => x === p).length > 1)
            return;
        if (p === ns.AlbScheme.INTERNAL)
            print("@aws-cdk/aws-eks-v2-alpha.AlbScheme#INTERNAL", "");
        if (p === ns.AlbScheme.INTERNET_FACING)
            print("@aws-cdk/aws-eks-v2-alpha.AlbScheme#INTERNET_FACING", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_AlbControllerOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("version" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AlbControllerOptions#version", "");
        if (!visitedObjects.has(p.version))
            _aws_cdk_aws_eks_v2_alpha_AlbControllerVersion(p.version);
        if ("additionalHelmChartValues" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AlbControllerOptions#additionalHelmChartValues", "");
        if ("overwriteServiceAccount" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AlbControllerOptions#overwriteServiceAccount", "");
        if ("policy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AlbControllerOptions#policy", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AlbControllerOptions#removalPolicy", "");
        if ("repository" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AlbControllerOptions#repository", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_AlbControllerProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("cluster" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AlbControllerProps#cluster", "");
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_eks_v2_alpha_Cluster(p.cluster);
        if ("version" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AlbControllerOptions#version", "");
        if (!visitedObjects.has(p.version))
            _aws_cdk_aws_eks_v2_alpha_AlbControllerVersion(p.version);
        if ("additionalHelmChartValues" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AlbControllerOptions#additionalHelmChartValues", "");
        if ("overwriteServiceAccount" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AlbControllerOptions#overwriteServiceAccount", "");
        if ("policy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AlbControllerOptions#policy", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AlbControllerOptions#removalPolicy", "");
        if ("repository" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AlbControllerOptions#repository", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_AlbController(p) {
}
function _aws_cdk_aws_eks_v2_alpha_IAccessEntry(p) {
}
function _aws_cdk_aws_eks_v2_alpha_AccessEntryAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("accessEntryArn" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryAttributes#accessEntryArn", "");
        if ("accessEntryName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryAttributes#accessEntryName", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_AccessScopeType(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.AccessScopeType", "");
        const ns = require("./lib/access-entry.js");
        if (Object.values(ns.AccessScopeType).filter(x => x === p).length > 1)
            return;
        if (p === ns.AccessScopeType.NAMESPACE)
            print("@aws-cdk/aws-eks-v2-alpha.AccessScopeType#NAMESPACE", "");
        if (p === ns.AccessScopeType.CLUSTER)
            print("@aws-cdk/aws-eks-v2-alpha.AccessScopeType#CLUSTER", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_AccessScope(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("type" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessScope#type", "");
        if (!visitedObjects.has(p.type))
            _aws_cdk_aws_eks_v2_alpha_AccessScopeType(p.type);
        if ("namespaces" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessScope#namespaces", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_AccessPolicyArn(p) {
}
function _aws_cdk_aws_eks_v2_alpha_IAccessPolicy(p) {
}
function _aws_cdk_aws_eks_v2_alpha_AccessPolicyProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("accessScope" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessPolicyProps#accessScope", "");
        if (!visitedObjects.has(p.accessScope))
            _aws_cdk_aws_eks_v2_alpha_AccessScope(p.accessScope);
        if ("policy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessPolicyProps#policy", "");
        if (!visitedObjects.has(p.policy))
            _aws_cdk_aws_eks_v2_alpha_AccessPolicyArn(p.policy);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_AccessPolicyNameOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("accessScopeType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessPolicyNameOptions#accessScopeType", "");
        if (!visitedObjects.has(p.accessScopeType))
            _aws_cdk_aws_eks_v2_alpha_AccessScopeType(p.accessScopeType);
        if ("namespaces" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessPolicyNameOptions#namespaces", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_AccessPolicy(p) {
}
function _aws_cdk_aws_eks_v2_alpha_AccessEntryType(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        print("@aws-cdk/aws-eks-v2-alpha.AccessEntryType", "");
        const ns = require("./lib/access-entry.js");
        if (Object.values(ns.AccessEntryType).filter(x => x === p).length > 1)
            return;
        if (p === ns.AccessEntryType.STANDARD)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryType#STANDARD", "");
        if (p === ns.AccessEntryType.FARGATE_LINUX)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryType#FARGATE_LINUX", "");
        if (p === ns.AccessEntryType.EC2_LINUX)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryType#EC2_LINUX", "");
        if (p === ns.AccessEntryType.EC2_WINDOWS)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryType#EC2_WINDOWS", "");
        if (p === ns.AccessEntryType.EC2)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryType#EC2", "");
        if (p === ns.AccessEntryType.HYBRID_LINUX)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryType#HYBRID_LINUX", "");
        if (p === ns.AccessEntryType.HYPERPOD_LINUX)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryType#HYPERPOD_LINUX", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_AccessEntryProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("accessPolicies" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryProps#accessPolicies", "");
        if (p.accessPolicies != null)
            for (const o of p.accessPolicies)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_eks_v2_alpha_IAccessPolicy(o);
        if ("cluster" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryProps#cluster", "");
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_eks_v2_alpha_ICluster(p.cluster);
        if ("principal" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryProps#principal", "");
        if ("accessEntryName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryProps#accessEntryName", "");
        if ("accessEntryType" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryProps#accessEntryType", "");
        if (!visitedObjects.has(p.accessEntryType))
            _aws_cdk_aws_eks_v2_alpha_AccessEntryType(p.accessEntryType);
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AccessEntryProps#removalPolicy", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_AccessEntry(p) {
}
function _aws_cdk_aws_eks_v2_alpha_IAddon(p) {
}
function _aws_cdk_aws_eks_v2_alpha_AddonProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("addonName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AddonProps#addonName", "");
        if ("cluster" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AddonProps#cluster", "");
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_eks_v2_alpha_ICluster(p.cluster);
        if ("addonVersion" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AddonProps#addonVersion", "");
        if ("configurationValues" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AddonProps#configurationValues", "");
        if ("preserveOnDelete" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AddonProps#preserveOnDelete", "");
        if ("removalPolicy" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AddonProps#removalPolicy", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_AddonAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("addonName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AddonAttributes#addonName", "");
        if ("clusterName" in p)
            print("@aws-cdk/aws-eks-v2-alpha.AddonAttributes#clusterName", "");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_eks_v2_alpha_Addon(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_eks_v2_alpha_ICluster, _aws_cdk_aws_eks_v2_alpha_ClusterAttributes, _aws_cdk_aws_eks_v2_alpha_ClusterCommonOptions, _aws_cdk_aws_eks_v2_alpha_EndpointAccess, _aws_cdk_aws_eks_v2_alpha_RemoteNodeNetwork, _aws_cdk_aws_eks_v2_alpha_RemotePodNetwork, _aws_cdk_aws_eks_v2_alpha_ComputeConfig, _aws_cdk_aws_eks_v2_alpha_ClusterProps, _aws_cdk_aws_eks_v2_alpha_KubernetesVersion, _aws_cdk_aws_eks_v2_alpha_ClusterLoggingTypes, _aws_cdk_aws_eks_v2_alpha_IpFamily, _aws_cdk_aws_eks_v2_alpha_ServiceLoadBalancerAddressOptions, _aws_cdk_aws_eks_v2_alpha_IngressLoadBalancerAddressOptions, _aws_cdk_aws_eks_v2_alpha_GrantAccessOptions, _aws_cdk_aws_eks_v2_alpha_Cluster, _aws_cdk_aws_eks_v2_alpha_AutoScalingGroupCapacityOptions, _aws_cdk_aws_eks_v2_alpha_BootstrapOptions, _aws_cdk_aws_eks_v2_alpha_AutoScalingGroupOptions, _aws_cdk_aws_eks_v2_alpha_EksOptimizedImageProps, _aws_cdk_aws_eks_v2_alpha_EksOptimizedImage, _aws_cdk_aws_eks_v2_alpha_NodeType, _aws_cdk_aws_eks_v2_alpha_CpuArch, _aws_cdk_aws_eks_v2_alpha_CoreDnsComputeType, _aws_cdk_aws_eks_v2_alpha_DefaultCapacityType, _aws_cdk_aws_eks_v2_alpha_MachineImageType, _aws_cdk_aws_eks_v2_alpha_FargateProfileOptions, _aws_cdk_aws_eks_v2_alpha_FargateProfileProps, _aws_cdk_aws_eks_v2_alpha_Selector, _aws_cdk_aws_eks_v2_alpha_FargateProfile, _aws_cdk_aws_eks_v2_alpha_HelmChartOptions, _aws_cdk_aws_eks_v2_alpha_HelmChartProps, _aws_cdk_aws_eks_v2_alpha_HelmChart, _aws_cdk_aws_eks_v2_alpha_KubernetesPatchProps, _aws_cdk_aws_eks_v2_alpha_PatchType, _aws_cdk_aws_eks_v2_alpha_KubernetesPatch, _aws_cdk_aws_eks_v2_alpha_KubernetesManifestOptions, _aws_cdk_aws_eks_v2_alpha_KubernetesManifestProps, _aws_cdk_aws_eks_v2_alpha_KubernetesManifest, _aws_cdk_aws_eks_v2_alpha_KubernetesObjectValueProps, _aws_cdk_aws_eks_v2_alpha_KubernetesObjectValue, _aws_cdk_aws_eks_v2_alpha_KubectlProviderOptions, _aws_cdk_aws_eks_v2_alpha_KubectlProviderProps, _aws_cdk_aws_eks_v2_alpha_KubectlProviderAttributes, _aws_cdk_aws_eks_v2_alpha_IKubectlProvider, _aws_cdk_aws_eks_v2_alpha_KubectlProvider, _aws_cdk_aws_eks_v2_alpha_FargateClusterProps, _aws_cdk_aws_eks_v2_alpha_FargateCluster, _aws_cdk_aws_eks_v2_alpha_IdentityType, _aws_cdk_aws_eks_v2_alpha_ServiceAccountOptions, _aws_cdk_aws_eks_v2_alpha_ServiceAccountProps, _aws_cdk_aws_eks_v2_alpha_ServiceAccount, _aws_cdk_aws_eks_v2_alpha_INodegroup, _aws_cdk_aws_eks_v2_alpha_NodegroupAmiType, _aws_cdk_aws_eks_v2_alpha_CapacityType, _aws_cdk_aws_eks_v2_alpha_NodegroupRemoteAccess, _aws_cdk_aws_eks_v2_alpha_LaunchTemplateSpec, _aws_cdk_aws_eks_v2_alpha_TaintEffect, _aws_cdk_aws_eks_v2_alpha_TaintSpec, _aws_cdk_aws_eks_v2_alpha_NodegroupOptions, _aws_cdk_aws_eks_v2_alpha_NodegroupProps, _aws_cdk_aws_eks_v2_alpha_Nodegroup, _aws_cdk_aws_eks_v2_alpha_OpenIdConnectProviderProps, _aws_cdk_aws_eks_v2_alpha_OidcProviderNativeProps, _aws_cdk_aws_eks_v2_alpha_OpenIdConnectProvider, _aws_cdk_aws_eks_v2_alpha_OidcProviderNative, _aws_cdk_aws_eks_v2_alpha_AlbControllerVersion, _aws_cdk_aws_eks_v2_alpha_AlbScheme, _aws_cdk_aws_eks_v2_alpha_AlbControllerOptions, _aws_cdk_aws_eks_v2_alpha_AlbControllerProps, _aws_cdk_aws_eks_v2_alpha_AlbController, _aws_cdk_aws_eks_v2_alpha_IAccessEntry, _aws_cdk_aws_eks_v2_alpha_AccessEntryAttributes, _aws_cdk_aws_eks_v2_alpha_AccessScopeType, _aws_cdk_aws_eks_v2_alpha_AccessScope, _aws_cdk_aws_eks_v2_alpha_AccessPolicyArn, _aws_cdk_aws_eks_v2_alpha_IAccessPolicy, _aws_cdk_aws_eks_v2_alpha_AccessPolicyProps, _aws_cdk_aws_eks_v2_alpha_AccessPolicyNameOptions, _aws_cdk_aws_eks_v2_alpha_AccessPolicy, _aws_cdk_aws_eks_v2_alpha_AccessEntryType, _aws_cdk_aws_eks_v2_alpha_AccessEntryProps, _aws_cdk_aws_eks_v2_alpha_AccessEntry, _aws_cdk_aws_eks_v2_alpha_IAddon, _aws_cdk_aws_eks_v2_alpha_AddonProps, _aws_cdk_aws_eks_v2_alpha_AddonAttributes, _aws_cdk_aws_eks_v2_alpha_Addon };
