import type { RemovalPolicy } from 'aws-cdk-lib/core';
import { Duration } from 'aws-cdk-lib/core';
import { Construct } from 'constructs';
import type { ICluster } from './cluster';
/**
 * Properties for KubernetesObjectValue.
 */
export interface KubernetesObjectValueProps {
    /**
     * The EKS cluster to fetch attributes from.
     *
     * [disable-awslint:ref-via-interface]
     */
    readonly cluster: ICluster;
    /**
     * The object type to query. (e.g 'service', 'pod'...)
     */
    readonly objectType: string;
    /**
     * The name of the object to query.
     */
    readonly objectName: string;
    /**
     * The namespace the object belongs to.
     *
     * @default 'default'
     */
    readonly objectNamespace?: string;
    /**
     * JSONPath to the specific value.
     *
     * @see https://kubernetes.io/docs/reference/kubectl/jsonpath/
     */
    readonly jsonPath: string;
    /**
     * Timeout for waiting on a value.
     *
     * @default Duration.minutes(5)
     */
    readonly timeout?: Duration;
    /**
     * The removal policy applied to the custom resource that manages the Kubernetes object value.
     *
     * The removal policy controls what happens to the resource if it stops being managed by CloudFormation.
     * This can happen in one of three situations:
     *
     * - The resource is removed from the template, so CloudFormation stops managing it
     * - A change to the resource is made that requires it to be replaced, so CloudFormation stops managing it
     * - The stack is deleted, so CloudFormation stops managing all resources in it
     *
     * @default RemovalPolicy.DESTROY
     */
    readonly removalPolicy?: RemovalPolicy;
}
/**
 * Represents a value of a specific object deployed in the cluster.
 * Use this to fetch any information available by the `kubectl get` command.
 */
export declare class KubernetesObjectValue extends Construct {
    /**
     * The CloudFormation resource type.
     */
    static readonly RESOURCE_TYPE = "Custom::AWSCDK-EKS-KubernetesObjectValue";
    private _resource;
    constructor(scope: Construct, id: string, props: KubernetesObjectValueProps);
    /**
     * The value as a string token.
     */
    get value(): string;
}
