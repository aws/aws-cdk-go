import type { IResource, RemovalPolicy } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import type { ICluster } from './cluster';
/**
 * Represents an Amazon EKS Add-On.
 */
export interface IAddon extends IResource {
    /**
     * Name of the Add-On.
     * @attribute
     */
    readonly addonName: string;
    /**
     * ARN of the Add-On.
     * @attribute
     */
    readonly addonArn: string;
}
/**
 * Properties for creating an Amazon EKS Add-On.
 */
export interface AddonProps {
    /**
     * Name of the Add-On.
     */
    readonly addonName: string;
    /**
     * Version of the Add-On. You can check all available versions with describe-addon-versions.
     * For example, this lists all available versions for the `eks-pod-identity-agent` addon:
     * $ aws eks describe-addon-versions --addon-name eks-pod-identity-agent \
     * --query 'addons[*].addonVersions[*].addonVersion'
     *
     * @default the latest version.
     */
    readonly addonVersion?: string;
    /**
     * The EKS cluster the Add-On is associated with.
     */
    readonly cluster: ICluster;
    /**
     * Specifying this option preserves the add-on software on your cluster but Amazon EKS stops managing any settings for the add-on.
     * If an IAM account is associated with the add-on, it isn't removed.
     *
     * @default true
     */
    readonly preserveOnDelete?: boolean;
    /**
     * The configuration values for the Add-on.
     *
     * @default - Use default configuration.
     */
    readonly configurationValues?: Record<string, any>;
    /**
     * The removal policy applied to the EKS add-on.
     *
     * The removal policy controls what happens to the resource if it stops being managed by CloudFormation.
     * This can happen in one of three situations:
     *
     * - The resource is removed from the template, so CloudFormation stops managing it
     * - A change to the resource is made that requires it to be replaced, so CloudFormation stops managing it
     * - The stack is deleted, so CloudFormation stops managing all resources in it
     *
     * @default RemovalPolicy.DESTROY
     */
    readonly removalPolicy?: RemovalPolicy;
}
/**
 * Represents the attributes of an addon for an Amazon EKS cluster.
 */
export interface AddonAttributes {
    /**
     * The name of the addon.
     */
    readonly addonName: string;
    /**
     * The name of the Amazon EKS cluster the addon is associated with.
     */
    readonly clusterName: string;
}
/**
 * Represents an Amazon EKS Add-On.
 * @resource AWS::EKS::Addon
 */
export declare class Addon extends Resource implements IAddon {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Creates an `IAddon` instance from the given addon attributes.
     *
     * @param scope - The parent construct.
     * @param id - The construct ID.
     * @param attrs - The attributes of the addon, including the addon name and the cluster name.
     * @returns An `IAddon` instance.
     */
    static fromAddonAttributes(scope: Construct, id: string, attrs: AddonAttributes): IAddon;
    /**
     * Creates an `IAddon` from an existing addon ARN.
     *
     * @param scope - The parent construct.
     * @param id - The ID of the construct.
     * @param addonArn - The ARN of the addon.
     * @returns An `IAddon` implementation.
     */
    static fromAddonArn(scope: Construct, id: string, addonArn: string): IAddon;
    private readonly clusterName;
    private resource;
    /**
     * Creates a new Amazon EKS Add-On.
     * @param scope The parent construct.
     * @param id The construct ID.
     * @param props The properties for the Add-On.
     */
    constructor(scope: Construct, id: string, props: AddonProps);
    /**
     * Name of the addon.
     */
    get addonName(): string;
    get addonArn(): string;
}
