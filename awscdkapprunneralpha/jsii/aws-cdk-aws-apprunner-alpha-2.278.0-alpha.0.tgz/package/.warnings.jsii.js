const VALIDATORS = { _aws_cdk_aws_apprunner_alpha_SourceConfig: function _aws_cdk_aws_apprunner_alpha_SourceConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.codeRepository))
                module.exports._aws_cdk_aws_apprunner_alpha_CodeRepositoryProps(p.codeRepository);
            if (!visitedObjects.has(p.ecrRepository))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecr_IRepository(p.ecrRepository);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.imageRepository))
                module.exports._aws_cdk_aws_apprunner_alpha_ImageRepository(p.imageRepository);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_GithubRepositoryProps: function _aws_cdk_aws_apprunner_alpha_GithubRepositoryProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.codeConfigurationValues))
                module.exports._aws_cdk_aws_apprunner_alpha_CodeConfigurationValues(p.codeConfigurationValues);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_EcrPublicProps: function _aws_cdk_aws_apprunner_alpha_EcrPublicProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.imageConfiguration))
                module.exports._aws_cdk_aws_apprunner_alpha_ImageConfiguration(p.imageConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_EcrProps: function _aws_cdk_aws_apprunner_alpha_EcrProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.repository))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecr_IRepository(p.repository);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.imageConfiguration))
                module.exports._aws_cdk_aws_apprunner_alpha_ImageConfiguration(p.imageConfiguration);
            if ("tag" in p)
                print("@aws-cdk/aws-apprunner-alpha.EcrProps#tag", "use `tagOrDigest`");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_AssetProps: function _aws_cdk_aws_apprunner_alpha_AssetProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.asset))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecr_assets_DockerImageAsset(p.asset);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.imageConfiguration))
                module.exports._aws_cdk_aws_apprunner_alpha_ImageConfiguration(p.imageConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_ImageConfiguration: function _aws_cdk_aws_apprunner_alpha_ImageConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("environment" in p)
                print("@aws-cdk/aws-apprunner-alpha.ImageConfiguration#environment", "use environmentVariables.");
            if (p.environmentSecrets != null)
                for (const o of Object.values(p.environmentSecrets))
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_apprunner_alpha_Secret(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_ImageRepository: function _aws_cdk_aws_apprunner_alpha_ImageRepository(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.imageConfiguration))
                module.exports._aws_cdk_aws_apprunner_alpha_ImageConfiguration(p.imageConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_CodeRepositoryProps: function _aws_cdk_aws_apprunner_alpha_CodeRepositoryProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.codeConfiguration))
                module.exports._aws_cdk_aws_apprunner_alpha_CodeConfiguration(p.codeConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_ServiceProps: function _aws_cdk_aws_apprunner_alpha_ServiceProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.accessRole))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.accessRole);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.instanceRole))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.instanceRole);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.kmsKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.kmsKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_CodeConfiguration: function _aws_cdk_aws_apprunner_alpha_CodeConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.configurationValues))
                module.exports._aws_cdk_aws_apprunner_alpha_CodeConfigurationValues(p.configurationValues);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_CodeConfigurationValues: function _aws_cdk_aws_apprunner_alpha_CodeConfigurationValues(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("environment" in p)
                print("@aws-cdk/aws-apprunner-alpha.CodeConfigurationValues#environment", "use environmentVariables.");
            if (p.environmentSecrets != null)
                for (const o of Object.values(p.environmentSecrets))
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_apprunner_alpha_Secret(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_HttpHealthCheckOptions: function _aws_cdk_aws_apprunner_alpha_HttpHealthCheckOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.interval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.interval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.timeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.timeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_TcpHealthCheckOptions: function _aws_cdk_aws_apprunner_alpha_TcpHealthCheckOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.interval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.interval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.timeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.timeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_VpcConnectorProps: function _aws_cdk_aws_apprunner_alpha_VpcConnectorProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.vpc))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_IVpc(p.vpc);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.vpcSubnets))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(p.vpcSubnets);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_VpcConnectorAttributes: function _aws_cdk_aws_apprunner_alpha_VpcConnectorAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_apprunner_alpha_VpcIngressConnectionProps: function _aws_cdk_aws_apprunner_alpha_VpcIngressConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.interfaceVpcEndpoint))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_IInterfaceVpcEndpoint(p.interfaceVpcEndpoint);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.vpc))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_IVpc(p.vpc);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
