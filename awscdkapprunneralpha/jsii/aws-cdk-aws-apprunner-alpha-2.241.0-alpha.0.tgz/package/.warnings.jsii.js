function _aws_cdk_aws_apprunner_alpha_AutoScalingConfigurationProps(p) {
}
function _aws_cdk_aws_apprunner_alpha_AutoScalingConfigurationAttributes(p) {
}
function _aws_cdk_aws_apprunner_alpha_IAutoScalingConfiguration(p) {
}
function _aws_cdk_aws_apprunner_alpha_AutoScalingConfiguration(p) {
}
function _aws_cdk_aws_apprunner_alpha_TraceConfigurationVendor(p) {
}
function _aws_cdk_aws_apprunner_alpha_ObservabilityConfigurationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.traceConfigurationVendor))
            _aws_cdk_aws_apprunner_alpha_TraceConfigurationVendor(p.traceConfigurationVendor);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_ObservabilityConfigurationAttributes(p) {
}
function _aws_cdk_aws_apprunner_alpha_IObservabilityConfiguration(p) {
}
function _aws_cdk_aws_apprunner_alpha_ObservabilityConfiguration(p) {
}
function _aws_cdk_aws_apprunner_alpha_ImageRepositoryType(p) {
}
function _aws_cdk_aws_apprunner_alpha_Cpu(p) {
}
function _aws_cdk_aws_apprunner_alpha_Memory(p) {
}
function _aws_cdk_aws_apprunner_alpha_Runtime(p) {
}
function _aws_cdk_aws_apprunner_alpha_SourceConfig(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.codeRepository))
            _aws_cdk_aws_apprunner_alpha_CodeRepositoryProps(p.codeRepository);
        if (!visitedObjects.has(p.imageRepository))
            _aws_cdk_aws_apprunner_alpha_ImageRepository(p.imageRepository);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_GithubRepositoryProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.configurationSource))
            _aws_cdk_aws_apprunner_alpha_ConfigurationSourceType(p.configurationSource);
        if (!visitedObjects.has(p.connection))
            _aws_cdk_aws_apprunner_alpha_GitHubConnection(p.connection);
        if (!visitedObjects.has(p.codeConfigurationValues))
            _aws_cdk_aws_apprunner_alpha_CodeConfigurationValues(p.codeConfigurationValues);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_EcrPublicProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.imageConfiguration))
            _aws_cdk_aws_apprunner_alpha_ImageConfiguration(p.imageConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_EcrProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.imageConfiguration))
            _aws_cdk_aws_apprunner_alpha_ImageConfiguration(p.imageConfiguration);
        if ("tag" in p)
            print("@aws-cdk/aws-apprunner-alpha.EcrProps#tag", "use `tagOrDigest`");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_AssetProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.imageConfiguration))
            _aws_cdk_aws_apprunner_alpha_ImageConfiguration(p.imageConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_SecretVersionInfo(p) {
}
function _aws_cdk_aws_apprunner_alpha_Source(p) {
}
function _aws_cdk_aws_apprunner_alpha_GithubSource(p) {
}
function _aws_cdk_aws_apprunner_alpha_EcrSource(p) {
}
function _aws_cdk_aws_apprunner_alpha_EcrPublicSource(p) {
}
function _aws_cdk_aws_apprunner_alpha_AssetSource(p) {
}
function _aws_cdk_aws_apprunner_alpha_ImageConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("environment" in p)
            print("@aws-cdk/aws-apprunner-alpha.ImageConfiguration#environment", "use environmentVariables.");
        if (p.environmentSecrets != null)
            for (const o of Object.values(p.environmentSecrets))
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_apprunner_alpha_Secret(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_ImageRepository(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.imageRepositoryType))
            _aws_cdk_aws_apprunner_alpha_ImageRepositoryType(p.imageRepositoryType);
        if (!visitedObjects.has(p.imageConfiguration))
            _aws_cdk_aws_apprunner_alpha_ImageConfiguration(p.imageConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_SourceCodeVersion(p) {
}
function _aws_cdk_aws_apprunner_alpha_CodeRepositoryProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.codeConfiguration))
            _aws_cdk_aws_apprunner_alpha_CodeConfiguration(p.codeConfiguration);
        if (!visitedObjects.has(p.connection))
            _aws_cdk_aws_apprunner_alpha_GitHubConnection(p.connection);
        if (!visitedObjects.has(p.sourceCodeVersion))
            _aws_cdk_aws_apprunner_alpha_SourceCodeVersion(p.sourceCodeVersion);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_ServiceProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.source))
            _aws_cdk_aws_apprunner_alpha_Source(p.source);
        if (!visitedObjects.has(p.autoScalingConfiguration))
            _aws_cdk_aws_apprunner_alpha_IAutoScalingConfiguration(p.autoScalingConfiguration);
        if (!visitedObjects.has(p.cpu))
            _aws_cdk_aws_apprunner_alpha_Cpu(p.cpu);
        if (!visitedObjects.has(p.healthCheck))
            _aws_cdk_aws_apprunner_alpha_HealthCheck(p.healthCheck);
        if (!visitedObjects.has(p.ipAddressType))
            _aws_cdk_aws_apprunner_alpha_IpAddressType(p.ipAddressType);
        if (!visitedObjects.has(p.memory))
            _aws_cdk_aws_apprunner_alpha_Memory(p.memory);
        if (!visitedObjects.has(p.observabilityConfiguration))
            _aws_cdk_aws_apprunner_alpha_IObservabilityConfiguration(p.observabilityConfiguration);
        if (!visitedObjects.has(p.vpcConnector))
            _aws_cdk_aws_apprunner_alpha_IVpcConnector(p.vpcConnector);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_ConfigurationSourceType(p) {
}
function _aws_cdk_aws_apprunner_alpha_CodeConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.configurationSource))
            _aws_cdk_aws_apprunner_alpha_ConfigurationSourceType(p.configurationSource);
        if (!visitedObjects.has(p.configurationValues))
            _aws_cdk_aws_apprunner_alpha_CodeConfigurationValues(p.configurationValues);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_CodeConfigurationValues(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.runtime))
            _aws_cdk_aws_apprunner_alpha_Runtime(p.runtime);
        if ("environment" in p)
            print("@aws-cdk/aws-apprunner-alpha.CodeConfigurationValues#environment", "use environmentVariables.");
        if (p.environmentSecrets != null)
            for (const o of Object.values(p.environmentSecrets))
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_apprunner_alpha_Secret(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_GitHubConnection(p) {
}
function _aws_cdk_aws_apprunner_alpha_HealthCheckProtocolType(p) {
}
function _aws_cdk_aws_apprunner_alpha_HttpHealthCheckOptions(p) {
}
function _aws_cdk_aws_apprunner_alpha_TcpHealthCheckOptions(p) {
}
function _aws_cdk_aws_apprunner_alpha_HealthCheck(p) {
}
function _aws_cdk_aws_apprunner_alpha_IpAddressType(p) {
}
function _aws_cdk_aws_apprunner_alpha_ServiceAttributes(p) {
}
function _aws_cdk_aws_apprunner_alpha_IService(p) {
}
function _aws_cdk_aws_apprunner_alpha_Secret(p) {
}
function _aws_cdk_aws_apprunner_alpha_Service(p) {
}
function _aws_cdk_aws_apprunner_alpha_VpcConnectorProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_VpcConnectorAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_IVpcConnector(p) {
}
function _aws_cdk_aws_apprunner_alpha_VpcConnector(p) {
}
function _aws_cdk_aws_apprunner_alpha_VpcIngressConnectionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.service))
            _aws_cdk_aws_apprunner_alpha_IService(p.service);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_apprunner_alpha_VpcIngressConnectionAttributes(p) {
}
function _aws_cdk_aws_apprunner_alpha_IVpcIngressConnection(p) {
}
function _aws_cdk_aws_apprunner_alpha_VpcIngressConnection(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_apprunner_alpha_AutoScalingConfigurationProps, _aws_cdk_aws_apprunner_alpha_AutoScalingConfigurationAttributes, _aws_cdk_aws_apprunner_alpha_IAutoScalingConfiguration, _aws_cdk_aws_apprunner_alpha_AutoScalingConfiguration, _aws_cdk_aws_apprunner_alpha_TraceConfigurationVendor, _aws_cdk_aws_apprunner_alpha_ObservabilityConfigurationProps, _aws_cdk_aws_apprunner_alpha_ObservabilityConfigurationAttributes, _aws_cdk_aws_apprunner_alpha_IObservabilityConfiguration, _aws_cdk_aws_apprunner_alpha_ObservabilityConfiguration, _aws_cdk_aws_apprunner_alpha_ImageRepositoryType, _aws_cdk_aws_apprunner_alpha_Cpu, _aws_cdk_aws_apprunner_alpha_Memory, _aws_cdk_aws_apprunner_alpha_Runtime, _aws_cdk_aws_apprunner_alpha_SourceConfig, _aws_cdk_aws_apprunner_alpha_GithubRepositoryProps, _aws_cdk_aws_apprunner_alpha_EcrPublicProps, _aws_cdk_aws_apprunner_alpha_EcrProps, _aws_cdk_aws_apprunner_alpha_AssetProps, _aws_cdk_aws_apprunner_alpha_SecretVersionInfo, _aws_cdk_aws_apprunner_alpha_Source, _aws_cdk_aws_apprunner_alpha_GithubSource, _aws_cdk_aws_apprunner_alpha_EcrSource, _aws_cdk_aws_apprunner_alpha_EcrPublicSource, _aws_cdk_aws_apprunner_alpha_AssetSource, _aws_cdk_aws_apprunner_alpha_ImageConfiguration, _aws_cdk_aws_apprunner_alpha_ImageRepository, _aws_cdk_aws_apprunner_alpha_SourceCodeVersion, _aws_cdk_aws_apprunner_alpha_CodeRepositoryProps, _aws_cdk_aws_apprunner_alpha_ServiceProps, _aws_cdk_aws_apprunner_alpha_ConfigurationSourceType, _aws_cdk_aws_apprunner_alpha_CodeConfiguration, _aws_cdk_aws_apprunner_alpha_CodeConfigurationValues, _aws_cdk_aws_apprunner_alpha_GitHubConnection, _aws_cdk_aws_apprunner_alpha_HealthCheckProtocolType, _aws_cdk_aws_apprunner_alpha_HttpHealthCheckOptions, _aws_cdk_aws_apprunner_alpha_TcpHealthCheckOptions, _aws_cdk_aws_apprunner_alpha_HealthCheck, _aws_cdk_aws_apprunner_alpha_IpAddressType, _aws_cdk_aws_apprunner_alpha_ServiceAttributes, _aws_cdk_aws_apprunner_alpha_IService, _aws_cdk_aws_apprunner_alpha_Secret, _aws_cdk_aws_apprunner_alpha_Service, _aws_cdk_aws_apprunner_alpha_VpcConnectorProps, _aws_cdk_aws_apprunner_alpha_VpcConnectorAttributes, _aws_cdk_aws_apprunner_alpha_IVpcConnector, _aws_cdk_aws_apprunner_alpha_VpcConnector, _aws_cdk_aws_apprunner_alpha_VpcIngressConnectionProps, _aws_cdk_aws_apprunner_alpha_VpcIngressConnectionAttributes, _aws_cdk_aws_apprunner_alpha_IVpcIngressConnection, _aws_cdk_aws_apprunner_alpha_VpcIngressConnection };
