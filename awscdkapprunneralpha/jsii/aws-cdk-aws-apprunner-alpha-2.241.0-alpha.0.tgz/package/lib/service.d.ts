import { CfnService } from 'aws-cdk-lib/aws-apprunner';
import type * as ecr from 'aws-cdk-lib/aws-ecr';
import type * as assets from 'aws-cdk-lib/aws-ecr-assets';
import * as iam from 'aws-cdk-lib/aws-iam';
import type * as kms from 'aws-cdk-lib/aws-kms';
import type * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import type * as ssm from 'aws-cdk-lib/aws-ssm';
import * as cdk from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import type { IAutoScalingConfiguration } from './auto-scaling-configuration';
import type { IObservabilityConfiguration } from './observability-configuration';
import type { IVpcConnector } from './vpc-connector';
/**
 * The image repository types
 */
export declare enum ImageRepositoryType {
    /**
     * Amazon ECR Public
     */
    ECR_PUBLIC = "ECR_PUBLIC",
    /**
     * Amazon ECR
     */
    ECR = "ECR"
}
/**
 * The number of CPU units reserved for each instance of your App Runner service.
 *
 */
export declare class Cpu {
    readonly unit: string;
    /**
     * 0.25 vCPU
     */
    static readonly QUARTER_VCPU: Cpu;
    /**
     * 0.5 vCPU
     */
    static readonly HALF_VCPU: Cpu;
    /**
     * 1 vCPU
     */
    static readonly ONE_VCPU: Cpu;
    /**
     * 2 vCPU
     */
    static readonly TWO_VCPU: Cpu;
    /**
     * 4 vCPU
     */
    static readonly FOUR_VCPU: Cpu;
    /**
     * Custom CPU unit
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apprunner-service-instanceconfiguration.html#cfn-apprunner-service-instanceconfiguration-cpu
     *
     * @param unit custom CPU unit
     */
    static of(unit: string): Cpu;
    /**
     *
     * @param unit The unit of CPU.
     */
    private constructor();
}
/**
 * The amount of memory reserved for each instance of your App Runner service.
 */
export declare class Memory {
    readonly unit: string;
    /**
     * 0.5 GB(for 0.25 vCPU)
     */
    static readonly HALF_GB: Memory;
    /**
     * 1 GB(for 0.25 or 0.5 vCPU)
     */
    static readonly ONE_GB: Memory;
    /**
     * 2 GB(for 1 vCPU)
     */
    static readonly TWO_GB: Memory;
    /**
     * 3 GB(for 1 vCPU)
     */
    static readonly THREE_GB: Memory;
    /**
     * 4 GB(for 1 or 2 vCPU)
     */
    static readonly FOUR_GB: Memory;
    /**
     * 6 GB(for 2 vCPU)
     */
    static readonly SIX_GB: Memory;
    /**
     * 8 GB(for 4 vCPU)
     */
    static readonly EIGHT_GB: Memory;
    /**
     * 10 GB(for 4 vCPU)
     */
    static readonly TEN_GB: Memory;
    /**
     * 12 GB(for 4 vCPU)
     */
    static readonly TWELVE_GB: Memory;
    /**
     * Custom Memory unit
     *
     * @param unit custom Memory unit
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apprunner-service-instanceconfiguration.html#cfn-apprunner-service-instanceconfiguration-memory
     */
    static of(unit: string): Memory;
    /**
     *
     * @param unit The unit of memory.
     */
    private constructor();
}
/**
 * The code runtimes
 */
export declare class Runtime {
    readonly name: string;
    /**
     * CORRETTO 8
     */
    static readonly CORRETTO_8: Runtime;
    /**
     * CORRETTO 11
     */
    static readonly CORRETTO_11: Runtime;
    /**
     * .NET 6
     */
    static readonly DOTNET_6: Runtime;
    /**
     * Go 1.18
     */
    static readonly GO_1: Runtime;
    /**
     * NodeJS 12
     */
    static readonly NODEJS_12: Runtime;
    /**
     * NodeJS 14
     */
    static readonly NODEJS_14: Runtime;
    /**
     * NodeJS 16
     */
    static readonly NODEJS_16: Runtime;
    /**
     * NodeJS 18
     */
    static readonly NODEJS_18: Runtime;
    /**
     * PHP 8.1
     */
    static readonly PHP_81: Runtime;
    /**
     * Python 3
     */
    static readonly PYTHON_3: Runtime;
    /**
     * Python 3.11
     */
    static readonly PYTHON_311: Runtime;
    /**
     * Ruby 3.1
     */
    static readonly RUBY_31: Runtime;
    /**
     * NodeJS 22
     */
    static readonly NODEJS_22: Runtime;
    /**
     * Other runtimes
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apprunner-service-codeconfigurationvalues.html#cfn-apprunner-service-codeconfigurationvalues-runtime for all available runtimes.
     *
     * @param name runtime name
     *
     */
    static of(name: string): Runtime;
    /**
     *
     * @param name The runtime name.
     */
    private constructor();
}
/**
 * Result of binding `Source` into a `Service`.
 */
export interface SourceConfig {
    /**
     * The image repository configuration (mutually exclusive  with `codeRepository`).
     *
     * @default - no image repository.
     */
    readonly imageRepository?: ImageRepository;
    /**
     * The ECR repository (required to grant the pull privileges for the iam role).
     *
     * @default - no ECR repository.
     */
    readonly ecrRepository?: ecr.IRepository;
    /**
     * The code repository configuration (mutually exclusive  with `imageRepository`).
     *
     * @default - no code repository.
     */
    readonly codeRepository?: CodeRepositoryProps;
}
/**
 * Properties of the Github repository for `Source.fromGitHub()`
 */
export interface GithubRepositoryProps {
    /**
     * The code configuration values. Will be ignored if configurationSource is `REPOSITORY`.
     * @default - no values will be passed. The `apprunner.yaml` from the github reopsitory will be used instead.
     */
    readonly codeConfigurationValues?: CodeConfigurationValues;
    /**
     * The source of the App Runner configuration.
     */
    readonly configurationSource: ConfigurationSourceType;
    /**
     * The location of the repository that contains the source code.
     */
    readonly repositoryUrl: string;
    /**
     * The branch name that represents a specific version for the repository.
     *
     * @default main
     */
    readonly branch?: string;
    /**
     * ARN of the connection to Github. Only required for Github source.
     */
    readonly connection: GitHubConnection;
}
/**
 * Properties of the image repository for `Source.fromEcrPublic()`
 */
export interface EcrPublicProps {
    /**
     * The image configuration for the image from ECR Public.
     * @default - no image configuration will be passed. The default `port` will be 8080.
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apprunner-service-imageconfiguration.html#cfn-apprunner-service-imageconfiguration-port
     */
    readonly imageConfiguration?: ImageConfiguration;
    /**
     * The ECR Public image URI.
     */
    readonly imageIdentifier: string;
}
/**
 * Properties of the image repository for `Source.fromEcr()`
 */
export interface EcrProps {
    /**
     * The image configuration for the image from ECR.
     * @default - no image configuration will be passed. The default `port` will be 8080.
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apprunner-service-imageconfiguration.html#cfn-apprunner-service-imageconfiguration-port
     */
    readonly imageConfiguration?: ImageConfiguration;
    /**
     * Represents the ECR repository.
     */
    readonly repository: ecr.IRepository;
    /**
     * Image tag.
     * @default - 'latest'
     * @deprecated use `tagOrDigest`
     */
    readonly tag?: string;
    /**
     * Image tag or digest (digests must start with `sha256:`).
     * @default - 'latest'
     */
    readonly tagOrDigest?: string;
}
/**
 * Properties of the image repository for `Source.fromAsset()`
 */
export interface AssetProps {
    /**
     * The image configuration for the image built from the asset.
     * @default - no image configuration will be passed. The default `port` will be 8080.
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apprunner-service-imageconfiguration.html#cfn-apprunner-service-imageconfiguration-port
     */
    readonly imageConfiguration?: ImageConfiguration;
    /**
     * Represents the docker image asset.
     */
    readonly asset: assets.DockerImageAsset;
}
/**
 * Specify the secret's version id or version stage
 */
export interface SecretVersionInfo {
    /**
     * version id of the secret
     *
     * @default - use default version id
     */
    readonly versionId?: string;
    /**
     * version stage of the secret
     *
     * @default - use default version stage
     */
    readonly versionStage?: string;
}
/**
 * Represents the App Runner service source.
 */
export declare abstract class Source {
    /**
     * Source from the GitHub repository.
     */
    static fromGitHub(props: GithubRepositoryProps): GithubSource;
    /**
     * Source from the ECR repository.
     */
    static fromEcr(props: EcrProps): EcrSource;
    /**
     * Source from the ECR Public repository.
     */
    static fromEcrPublic(props: EcrPublicProps): EcrPublicSource;
    /**
     * Source from local assets.
     */
    static fromAsset(props: AssetProps): AssetSource;
    /**
     * Called when the Job is initialized to allow this object to bind.
     */
    abstract bind(scope: Construct): SourceConfig;
}
/**
 * Represents the service source from a Github repository.
 */
export declare class GithubSource extends Source {
    private readonly props;
    constructor(props: GithubRepositoryProps);
    bind(_scope: Construct): SourceConfig;
}
/**
 * Represents the service source from ECR.
 */
export declare class EcrSource extends Source {
    private readonly props;
    constructor(props: EcrProps);
    bind(_scope: Construct): SourceConfig;
}
/**
 * Represents the service source from ECR Public.
 */
export declare class EcrPublicSource extends Source {
    private readonly props;
    constructor(props: EcrPublicProps);
    bind(_scope: Construct): SourceConfig;
}
/**
 * Represents the source from local assets.
 */
export declare class AssetSource extends Source {
    private readonly props;
    constructor(props: AssetProps);
    bind(_scope: Construct): SourceConfig;
}
/**
 * Describes the configuration that AWS App Runner uses to run an App Runner service
 * using an image pulled from a source image repository.
 *
 * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apprunner-service-imageconfiguration.html
 */
export interface ImageConfiguration {
    /**
     * The port that your application listens to in the container.
     *
     * @default 8080
     */
    readonly port?: number;
    /**
     * Environment variables that are available to your running App Runner service.
     *
     * @default - no environment variables
     * @deprecated use environmentVariables.
     */
    readonly environment?: {
        [key: string]: string;
    };
    /**
     * Environment variables that are available to your running App Runner service.
     *
     * @default - no environment variables
     */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
     * Environment secrets that are available to your running App Runner service.
     *
     * @default - no environment secrets
     */
    readonly environmentSecrets?: {
        [key: string]: Secret;
    };
    /**
     * An optional command that App Runner runs to start the application in the source image.
     * If specified, this command overrides the Docker image’s default start command.
     *
     * @default - no start command
     */
    readonly startCommand?: string;
}
/**
 * Describes a source image repository.
 *
 * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apprunner-service-imagerepository.html
 */
export interface ImageRepository {
    /**
     * The identifier of the image. For `ECR_PUBLIC` imageRepositoryType, the identifier domain should
     * always be `public.ecr.aws`. For `ECR`, the pattern should be
     * `([0-9]{12}.dkr.ecr.[a-z\-]+-[0-9]{1}.amazonaws.com\/.*)`.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apprunner-service-imagerepository.html
     */
    readonly imageIdentifier: string;
    /**
     * The type of the image repository. This reflects the repository provider and whether
     * the repository is private or public.
     */
    readonly imageRepositoryType: ImageRepositoryType;
    /**
     * Configuration for running the identified image.
     * @default - no image configuration will be passed. The default `port` will be 8080.
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apprunner-service-imageconfiguration.html#cfn-apprunner-service-imageconfiguration-port
     */
    readonly imageConfiguration?: ImageConfiguration;
}
/**
 * Identifies a version of code that AWS App Runner refers to within a source code repository.
 *
 * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apprunner-service-sourcecodeversion.html
 */
export interface SourceCodeVersion {
    /**
     * The type of version identifier.
     */
    readonly type: string;
    /**
     * A source code version.
     */
    readonly value: string;
}
/**
 * Properties of the CodeRepository.
 */
export interface CodeRepositoryProps {
    /**
     * Configuration for building and running the service from a source code repository.
     */
    readonly codeConfiguration: CodeConfiguration;
    /**
     * The location of the repository that contains the source code.
     */
    readonly repositoryUrl: string;
    /**
     * The version that should be used within the source code repository.
     */
    readonly sourceCodeVersion: SourceCodeVersion;
    /**
     * The App Runner connection for GitHub.
     */
    readonly connection: GitHubConnection;
}
/**
 * Properties of the AppRunner Service
 */
export interface ServiceProps {
    /**
     * The source of the repository for the service.
     */
    readonly source: Source;
    /**
     * Specifies whether to enable continuous integration from the source repository.
     *
     * If true, continuous integration from the source repository is enabled for the App Runner service.
     * Each repository change (including any source code commit or new image version) starts a deployment.
     * By default, App Runner sets to false for a source image that uses an ECR Public repository or an ECR repository that's in an AWS account other than the one that the service is in.
     * App Runner sets to true in all other cases (which currently include a source code repository or a source image using a same-account ECR repository).
     *
     * @default - no value will be passed.
     */
    readonly autoDeploymentsEnabled?: boolean;
    /**
     * Specifies an App Runner Auto Scaling Configuration.
     *
     * A default configuration is either the AWS recommended configuration,
     * or the configuration you set as the default.
     *
     * @see https://docs.aws.amazon.com/apprunner/latest/dg/manage-autoscaling.html
     *
     * @default - the latest revision of a default auto scaling configuration is used.
     */
    readonly autoScalingConfiguration?: IAutoScalingConfiguration;
    /**
     * The number of CPU units reserved for each instance of your App Runner service.
     *
     * @default Cpu.ONE_VCPU
     */
    readonly cpu?: Cpu;
    /**
     * The amount of memory reserved for each instance of your App Runner service.
     *
     * @default Memory.TWO_GB
     */
    readonly memory?: Memory;
    /**
     * The IAM role that grants the App Runner service access to a source repository.
     * It's required for ECR image repositories (but not for ECR Public repositories).
     *
     * The role must be assumable by the 'build.apprunner.amazonaws.com' service principal.
     *
     * @see https://docs.aws.amazon.com/apprunner/latest/dg/security_iam_service-with-iam.html#security_iam_service-with-iam-roles-service.access
     *
     * @default - generate a new access role.
     */
    readonly accessRole?: iam.IRole;
    /**
     * The IAM role that provides permissions to your App Runner service.
     * These are permissions that your code needs when it calls any AWS APIs.
     *
     * The role must be assumable by the 'tasks.apprunner.amazonaws.com' service principal.
     *
     * @see https://docs.aws.amazon.com/apprunner/latest/dg/security_iam_service-with-iam.html#security_iam_service-with-iam-roles-service.instance
     *
     * @default - generate a new instance role.
     */
    readonly instanceRole?: iam.IRole;
    /**
     * Name of the service.
     *
     * @default - auto-generated if undefined.
     */
    readonly serviceName?: string;
    /**
     * Settings for an App Runner VPC connector to associate with the service.
     *
     * @default - no VPC connector, uses the DEFAULT egress type instead
     */
    readonly vpcConnector?: IVpcConnector;
    /**
     * Specifies whether your App Runner service is publicly accessible.
     *
     * If you use `VpcIngressConnection`, you must set this property to `false`.
     *
     * @default true
     */
    readonly isPubliclyAccessible?: boolean;
    /**
     * Settings for the health check that AWS App Runner performs to monitor the health of a service.
     *
     * You can specify it by static methods `HealthCheck.http` or `HealthCheck.tcp`.
     *
     * @default - no health check configuration
     */
    readonly healthCheck?: HealthCheck;
    /**
     * The customer managed key that AWS App Runner uses to encrypt copies of the source repository and service logs.
     *
     * @default - Use an AWS managed key
     */
    readonly kmsKey?: kms.IKeyRef;
    /**
     * The IP address type for your incoming public network configuration.
     *
     * @default - IpAddressType.IPV4
     */
    readonly ipAddressType?: IpAddressType;
    /**
     * Settings for an App Runner observability configuration.
     *
     * @default - no observability configuration resource is associated with the service.
     */
    readonly observabilityConfiguration?: IObservabilityConfiguration;
}
/**
 * The source of the App Runner configuration.
 */
export declare enum ConfigurationSourceType {
    /**
     * App Runner reads configuration values from `the apprunner.yaml` file in the source code repository
     * and ignores `configurationValues`.
     */
    REPOSITORY = "REPOSITORY",
    /**
     * App Runner uses configuration values provided in `configurationValues` and ignores the `apprunner.yaml`
     * file in the source code repository.
     */
    API = "API"
}
/**
 * Describes the configuration that AWS App Runner uses to build and run an App Runner service
 * from a source code repository.
 *
 * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-apprunner-service-codeconfiguration.html
 */
export interface CodeConfiguration {
    /**
     * The basic configuration for building and running the App Runner service.
     * Use it to quickly launch an App Runner service without providing a apprunner.yaml file in the
     * source code repository (or ignoring the file if it exists).
     *
     * @default - not specified. Use `apprunner.yaml` instead.
     */
    readonly configurationValues?: CodeConfigurationValues;
    /**
     * The source of the App Runner configuration.
     */
    readonly configurationSource: ConfigurationSourceType;
}
/**
 * Describes the basic configuration needed for building and running an AWS App Runner service.
 * This type doesn't support the full set of possible configuration options. Fur full configuration capabilities,
 * use a `apprunner.yaml` file in the source code repository.
 */
export interface CodeConfigurationValues {
    /**
     * The command App Runner runs to build your application.
     *
     * @default - no build command.
     */
    readonly buildCommand?: string;
    /**
     * The port that your application listens to in the container.
     *
     * @default 8080
     */
    readonly port?: string;
    /**
     * A runtime environment type for building and running an App Runner service. It represents
     * a programming language runtime.
     */
    readonly runtime: Runtime;
    /**
     * The environment variables that are available to your running App Runner service.
     *
     * @default - no environment variables.
     * @deprecated use environmentVariables.
     */
    readonly environment?: {
        [key: string]: string;
    };
    /**
     * The environment variables that are available to your running App Runner service.
     *
     * @default - no environment variables.
     */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
     * The environment secrets that are available to your running App Runner service.
     *
     * @default - no environment secrets.
     */
    readonly environmentSecrets?: {
        [key: string]: Secret;
    };
    /**
     * The command App Runner runs to start your application.
     *
     * @default - no start command.
     */
    readonly startCommand?: string;
}
/**
 * Represents the App Runner connection that enables the App Runner service to connect
 * to a source repository. It's required for GitHub code repositories.
 */
export declare class GitHubConnection {
    /**
     * Using existing App Runner connection by specifying the connection ARN.
     * @param arn connection ARN
     * @returns Connection
     */
    static fromConnectionArn(arn: string): GitHubConnection;
    /**
     * The ARN of the Connection for App Runner service to connect to the repository.
     */
    readonly connectionArn: string;
    constructor(arn: string);
}
/**
 * The health check protocol type
 */
export declare enum HealthCheckProtocolType {
    /**
     * HTTP protocol
     */
    HTTP = "HTTP",
    /**
     * TCP protocol
     */
    TCP = "TCP"
}
/**
 * Describes the settings for the health check that AWS App Runner performs to monitor the health of a service.
 */
interface HealthCheckCommonOptions {
    /**
     * The number of consecutive checks that must succeed before App Runner decides that the service is healthy.
     *
     * @default 1
     */
    readonly healthyThreshold?: number;
    /**
     * The time interval, in seconds, between health checks.
     *
     * @default Duration.seconds(5)
     */
    readonly interval?: cdk.Duration;
    /**
     * The time, in seconds, to wait for a health check response before deciding it failed.
     *
     * @default Duration.seconds(2)
     */
    readonly timeout?: cdk.Duration;
    /**
     * The number of consecutive checks that must fail before App Runner decides that the service is unhealthy.
     *
     * @default 5
     */
    readonly unhealthyThreshold?: number;
}
/**
 * Properties used to define HTTP Based healthchecks.
 */
export interface HttpHealthCheckOptions extends HealthCheckCommonOptions {
    /**
     * The URL that health check requests are sent to.
     *
     * @default /
     */
    readonly path?: string;
}
/**
 * Properties used to define TCP Based healthchecks.
 */
export interface TcpHealthCheckOptions extends HealthCheckCommonOptions {
}
/**
 * Contains static factory methods for creating health checks for different protocols
 */
export declare class HealthCheck {
    readonly healthCheckProtocolType: HealthCheckProtocolType;
    readonly healthyThreshold: number;
    readonly interval: cdk.Duration;
    readonly timeout: cdk.Duration;
    readonly unhealthyThreshold: number;
    readonly path?: string | undefined;
    /**
     * Construct a HTTP health check
     */
    static http(options?: HttpHealthCheckOptions): HealthCheck;
    /**
     * Construct a TCP health check
     */
    static tcp(options?: TcpHealthCheckOptions): HealthCheck;
    private constructor();
    bind(): CfnService.HealthCheckConfigurationProperty;
}
/**
 * The IP address type for your incoming public network configuration.
 */
export declare enum IpAddressType {
    /**
     * IPV4
     */
    IPV4 = "IPV4",
    /**
     * DUAL_STACK
     */
    DUAL_STACK = "DUAL_STACK"
}
/**
 * Attributes for the App Runner Service
 */
export interface ServiceAttributes {
    /**
     * The name of the service.
     */
    readonly serviceName: string;
    /**
     * The ARN of the service.
     */
    readonly serviceArn: string;
    /**
     * The URL of the service.
     */
    readonly serviceUrl: string;
    /**
     * The status of the service.
     */
    readonly serviceStatus: string;
}
/**
 * Represents the App Runner Service.
 */
export interface IService extends cdk.IResource {
    /**
     * The Name of the service.
     */
    readonly serviceName: string;
    /**
     * The ARN of the service.
     * @attribute
     */
    readonly serviceArn: string;
}
/**
 * A secret environment variable.
 */
export declare abstract class Secret {
    /**
     * Creates an environment variable value from a parameter stored in AWS
     * Systems Manager Parameter Store.
     */
    static fromSsmParameter(parameter: ssm.IParameter): Secret;
    /**
     * Creates a environment variable value from a secret stored in AWS Secrets
     * Manager.
     *
     * @param secret the secret stored in AWS Secrets Manager
     * @param field the name of the field with the value that you want to set as
     * the environment variable value. Only values in JSON format are supported.
     * If you do not specify a JSON field, then the full content of the secret is
     * used.
     */
    static fromSecretsManager(secret: secretsmanager.ISecret, field?: string): Secret;
    /**
     * Creates a environment variable value from a secret stored in AWS Secrets
     * Manager.
     *
     * @param secret the secret stored in AWS Secrets Manager
     * @param versionInfo the version information to reference the secret
     * @param field the name of the field with the value that you want to set as
     * the environment variable value. Only values in JSON format are supported.
     * If you do not specify a JSON field, then the full content of the secret is
     * used.
     */
    static fromSecretsManagerVersion(secret: secretsmanager.ISecret, versionInfo: SecretVersionInfo, field?: string): Secret;
    /**
     * The ARN of the secret
     */
    abstract readonly arn: string;
    /**
     * Whether this secret uses a specific JSON field
     */
    abstract readonly hasField?: boolean;
    /**
     * Grants reading the secret to a principal
     *
     * [disable-awslint:no-grants]
     */
    abstract grantRead(grantee: iam.IGrantable): iam.Grant;
}
/**
 * The App Runner Service.
 */
export declare class Service extends cdk.Resource implements IService, iam.IGrantable {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import from service name.
     */
    static fromServiceName(scope: Construct, id: string, serviceName: string): IService;
    /**
     * Import from service attributes.
     */
    static fromServiceAttributes(scope: Construct, id: string, attrs: ServiceAttributes): IService;
    readonly grantPrincipal: iam.IPrincipal;
    private readonly props;
    private accessRole?;
    private instanceRole;
    private source;
    /**
     * Environment variables for this service.
     *
     * @deprecated use environmentVariables.
     */
    readonly environment: {
        [key: string]: string;
    };
    /**
     * Environment secrets for this service.
     */
    private readonly secrets;
    /**
     * Environment variables for this service.
     */
    private readonly variables;
    /**
     * The ARN of the Service.
     * @attribute
     */
    readonly serviceArn: string;
    /**
     * The ID of the Service.
     * @attribute
     */
    readonly serviceId: string;
    /**
     * The URL of the Service.
     * @attribute
     */
    readonly serviceUrl: string;
    /**
     * The status of the Service.
     * @attribute
     */
    readonly serviceStatus: string;
    /**
     * The name of the service.
     */
    readonly serviceName: string;
    constructor(scope: Construct, id: string, props: ServiceProps);
    /**
     * Adds a statement to the instance role.
     */
    addToRolePolicy(statement: iam.PolicyStatement): void;
    /**
     * This method adds an environment variable to the App Runner service.
     */
    addEnvironmentVariable(name: string, value: string): void;
    /**
     * This method adds a secret as environment variable to the App Runner service.
     */
    addSecret(name: string, secret: Secret): void;
    /**
     * This method generates an Instance Role. Needed if using secrets and props.instanceRole is undefined
     * @returns iam.IRole
     */
    private createInstanceRole;
    /**
     * This method generates an Access Role only when ImageRepositoryType is ECR and props.accessRole is undefined
     * @returns iam.IRole
     */
    private generateDefaultRole;
    private getEnvironmentSecrets;
    private getEnvironmentVariables;
    private renderAuthenticationConfiguration;
    private renderCodeConfiguration;
    private renderCodeConfigurationValues;
    private renderEnvironmentVariables;
    private renderEnvironmentSecrets;
    private renderImageRepository;
}
export {};
