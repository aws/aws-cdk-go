/** Returns a bare-safe identifier unchanged; otherwise double-quotes it, doubling embedded double quotes. */
export declare function quoteIdentifier(identifier: string): string;
/** Applies {@link quoteIdentifier} to each `.`-separated component, keeping the dot separator. */
export declare function quoteQualifiedIdentifier(qualified: string): string;
/** Quotes a SQL string literal, doubling any embedded single quote. */
export declare function quoteLiteral(literal: string): string;
