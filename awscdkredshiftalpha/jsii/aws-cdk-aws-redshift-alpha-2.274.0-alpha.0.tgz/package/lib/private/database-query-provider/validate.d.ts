/**
 * Redshift folds only ASCII letters in identifiers to lower case, and `public` is a pseudo-role rather than a user.
 *
 * @see https://docs.aws.amazon.com/redshift/latest/dg/r_names.html
 */
export declare function isPublicGrantee(username: string): boolean;
export declare function validateUsername(username: string): void;
