function _aws_cdk_aws_redshift_alpha_NodeType(p) {
}
function _aws_cdk_aws_redshift_alpha_ClusterType(p) {
}
function _aws_cdk_aws_redshift_alpha_ResourceAction(p) {
}
function _aws_cdk_aws_redshift_alpha_Login(p) {
}
function _aws_cdk_aws_redshift_alpha_LoggingProperties(p) {
}
function _aws_cdk_aws_redshift_alpha_RotationMultiUserOptions(p) {
}
function _aws_cdk_aws_redshift_alpha_MaintenanceTrackName(p) {
}
function _aws_cdk_aws_redshift_alpha_ICluster(p) {
}
function _aws_cdk_aws_redshift_alpha_ClusterAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_redshift_alpha_ClusterProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.masterUser))
            _aws_cdk_aws_redshift_alpha_Login(p.masterUser);
        if (!visitedObjects.has(p.clusterType))
            _aws_cdk_aws_redshift_alpha_ClusterType(p.clusterType);
        if (!visitedObjects.has(p.loggingProperties))
            _aws_cdk_aws_redshift_alpha_LoggingProperties(p.loggingProperties);
        if (!visitedObjects.has(p.maintenanceTrackName))
            _aws_cdk_aws_redshift_alpha_MaintenanceTrackName(p.maintenanceTrackName);
        if (!visitedObjects.has(p.nodeType))
            _aws_cdk_aws_redshift_alpha_NodeType(p.nodeType);
        if (!visitedObjects.has(p.parameterGroup))
            _aws_cdk_aws_redshift_alpha_IClusterParameterGroup(p.parameterGroup);
        if (!visitedObjects.has(p.resourceAction))
            _aws_cdk_aws_redshift_alpha_ResourceAction(p.resourceAction);
        if (p.roles != null)
            for (const o of p.roles)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(o);
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        if (!visitedObjects.has(p.subnetGroup))
            _aws_cdk_aws_redshift_alpha_IClusterSubnetGroup(p.subnetGroup);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_redshift_alpha_Cluster(p) {
}
function _aws_cdk_aws_redshift_alpha_IClusterParameterGroup(p) {
}
function _aws_cdk_aws_redshift_alpha_ClusterParameterGroupProps(p) {
}
function _aws_cdk_aws_redshift_alpha_ClusterParameterGroup(p) {
}
function _aws_cdk_aws_redshift_alpha_DatabaseOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_redshift_alpha_ICluster(p.cluster);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_redshift_alpha_DatabaseSecretProps(p) {
}
function _aws_cdk_aws_redshift_alpha_DatabaseSecret(p) {
}
function _aws_cdk_aws_redshift_alpha_Endpoint(p) {
}
function _aws_cdk_aws_redshift_alpha_IClusterSubnetGroup(p) {
}
function _aws_cdk_aws_redshift_alpha_ClusterSubnetGroupProps(p) {
}
function _aws_cdk_aws_redshift_alpha_ClusterSubnetGroup(p) {
}
function _aws_cdk_aws_redshift_alpha_TableAction(p) {
}
function _aws_cdk_aws_redshift_alpha_Column(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.encoding))
            _aws_cdk_aws_redshift_alpha_ColumnEncoding(p.encoding);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_redshift_alpha_TableProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.tableColumns != null)
            for (const o of p.tableColumns)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_redshift_alpha_Column(o);
        if (!visitedObjects.has(p.distStyle))
            _aws_cdk_aws_redshift_alpha_TableDistStyle(p.distStyle);
        if (!visitedObjects.has(p.sortStyle))
            _aws_cdk_aws_redshift_alpha_TableSortStyle(p.sortStyle);
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_redshift_alpha_ICluster(p.cluster);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_redshift_alpha_ITable(p) {
}
function _aws_cdk_aws_redshift_alpha_TableAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_redshift_alpha_ICluster(p.cluster);
        if (p.tableColumns != null)
            for (const o of p.tableColumns)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_redshift_alpha_Column(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_redshift_alpha_Table(p) {
}
function _aws_cdk_aws_redshift_alpha_TableDistStyle(p) {
}
function _aws_cdk_aws_redshift_alpha_TableSortStyle(p) {
}
function _aws_cdk_aws_redshift_alpha_ColumnEncoding(p) {
}
function _aws_cdk_aws_redshift_alpha_UserProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_redshift_alpha_ICluster(p.cluster);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_redshift_alpha_IUser(p) {
}
function _aws_cdk_aws_redshift_alpha_UserAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_redshift_alpha_ICluster(p.cluster);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_redshift_alpha_User(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_redshift_alpha_NodeType, _aws_cdk_aws_redshift_alpha_ClusterType, _aws_cdk_aws_redshift_alpha_ResourceAction, _aws_cdk_aws_redshift_alpha_Login, _aws_cdk_aws_redshift_alpha_LoggingProperties, _aws_cdk_aws_redshift_alpha_RotationMultiUserOptions, _aws_cdk_aws_redshift_alpha_MaintenanceTrackName, _aws_cdk_aws_redshift_alpha_ICluster, _aws_cdk_aws_redshift_alpha_ClusterAttributes, _aws_cdk_aws_redshift_alpha_ClusterProps, _aws_cdk_aws_redshift_alpha_Cluster, _aws_cdk_aws_redshift_alpha_IClusterParameterGroup, _aws_cdk_aws_redshift_alpha_ClusterParameterGroupProps, _aws_cdk_aws_redshift_alpha_ClusterParameterGroup, _aws_cdk_aws_redshift_alpha_DatabaseOptions, _aws_cdk_aws_redshift_alpha_DatabaseSecretProps, _aws_cdk_aws_redshift_alpha_DatabaseSecret, _aws_cdk_aws_redshift_alpha_Endpoint, _aws_cdk_aws_redshift_alpha_IClusterSubnetGroup, _aws_cdk_aws_redshift_alpha_ClusterSubnetGroupProps, _aws_cdk_aws_redshift_alpha_ClusterSubnetGroup, _aws_cdk_aws_redshift_alpha_TableAction, _aws_cdk_aws_redshift_alpha_Column, _aws_cdk_aws_redshift_alpha_TableProps, _aws_cdk_aws_redshift_alpha_ITable, _aws_cdk_aws_redshift_alpha_TableAttributes, _aws_cdk_aws_redshift_alpha_Table, _aws_cdk_aws_redshift_alpha_TableDistStyle, _aws_cdk_aws_redshift_alpha_TableSortStyle, _aws_cdk_aws_redshift_alpha_ColumnEncoding, _aws_cdk_aws_redshift_alpha_UserProps, _aws_cdk_aws_redshift_alpha_IUser, _aws_cdk_aws_redshift_alpha_UserAttributes, _aws_cdk_aws_redshift_alpha_User };
