export declare enum HandlerName {
    User = "user",
    Table = "table",
    UserTablePrivileges = "user-table-privileges"
}
