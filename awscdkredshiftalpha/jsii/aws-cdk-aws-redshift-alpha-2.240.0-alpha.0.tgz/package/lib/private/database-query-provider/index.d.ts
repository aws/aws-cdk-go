import type * as AWSLambda from 'aws-lambda';
export declare function handler(event: AWSLambda.CloudFormationCustomResourceEvent): Promise<any>;
