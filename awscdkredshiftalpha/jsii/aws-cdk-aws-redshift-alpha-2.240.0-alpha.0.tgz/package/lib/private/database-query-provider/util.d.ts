import type { ClusterProps } from './types';
import type { Column } from '../../table';
export declare function makePhysicalId(resourceName: string, clusterProps: ClusterProps, requestId: string): string;
export declare function getDistKeyColumn(columns: Column[]): Column | undefined;
export declare function getSortKeyColumns(columns: Column[]): Column[];
export declare function areColumnsEqual(columnsA: Column[], columnsB: Column[]): boolean;
