import type * as AWSLambda from 'aws-lambda';
import type { UserTablePrivilegesHandlerProps } from '../handler-props';
import type { ClusterProps } from './types';
export declare function handler(props: UserTablePrivilegesHandlerProps & ClusterProps, event: AWSLambda.CloudFormationCustomResourceEvent): Promise<{
    PhysicalResourceId: string;
} | undefined>;
