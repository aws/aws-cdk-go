import type * as AWSLambda from 'aws-lambda';
import type { TableAndClusterProps } from './types';
export declare function handler(props: TableAndClusterProps, event: AWSLambda.CloudFormationCustomResourceEvent): Promise<{
    PhysicalResourceId: string;
} | undefined>;
