import type { ClusterProps } from './types';
export declare function executeStatement(statement: string, clusterProps: ClusterProps): Promise<void>;
