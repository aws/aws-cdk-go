import type * as AWSLambda from 'aws-lambda';
import type { ClusterProps } from './types';
import type { UserHandlerProps } from '../handler-props';
export declare function handler(props: UserHandlerProps & ClusterProps, event: AWSLambda.CloudFormationCustomResourceEvent): Promise<{
    PhysicalResourceId: string;
    Data: {
        username: string;
    };
} | undefined>;
