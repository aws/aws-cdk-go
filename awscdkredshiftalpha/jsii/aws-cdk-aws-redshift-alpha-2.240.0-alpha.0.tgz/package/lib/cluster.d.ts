import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';
import type * as kms from 'aws-cdk-lib/aws-kms';
import type * as s3 from 'aws-cdk-lib/aws-s3';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import type { IResource, SecretValue } from 'aws-cdk-lib/core';
import { Duration, RemovalPolicy, Resource } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import { Endpoint } from './endpoint';
import type { IClusterParameterGroup } from './parameter-group';
import type { IClusterSubnetGroup } from './subnet-group';
/**
 * Possible Node Types to use in the cluster
 * used for defining `ClusterProps.nodeType`.
 */
export declare enum NodeType {
    /**
     * ds2.xlarge
     */
    DS2_XLARGE = "ds2.xlarge",
    /**
     * ds2.8xlarge
     */
    DS2_8XLARGE = "ds2.8xlarge",
    /**
     * dc1.large
     */
    DC1_LARGE = "dc1.large",
    /**
     * dc1.8xlarge
     */
    DC1_8XLARGE = "dc1.8xlarge",
    /**
     * dc2.large
     */
    DC2_LARGE = "dc2.large",
    /**
     * dc2.8xlarge
     */
    DC2_8XLARGE = "dc2.8xlarge",
    /**
     * ra3.large
     */
    RA3_LARGE = "ra3.large",
    /**
     * ra3.xlplus
     */
    RA3_XLPLUS = "ra3.xlplus",
    /**
     * ra3.4xlarge
     */
    RA3_4XLARGE = "ra3.4xlarge",
    /**
     * ra3.16xlarge
     */
    RA3_16XLARGE = "ra3.16xlarge"
}
/**
 * What cluster type to use.
 * Used by `ClusterProps.clusterType`
 */
export declare enum ClusterType {
    /**
     * single-node cluster, the `ClusterProps.numberOfNodes` parameter is not required
     */
    SINGLE_NODE = "single-node",
    /**
     * multi-node cluster, set the amount of nodes using `ClusterProps.numberOfNodes` parameter
     */
    MULTI_NODE = "multi-node"
}
/**
 * The Amazon Redshift operation
 */
export declare enum ResourceAction {
    /**
     * Pause the cluster
     */
    PAUSE_CLUSTER = "pause-cluster",
    /**
     * Resume the cluster
     */
    RESUME_CLUSTER = "resume-cluster",
    /**
     * Failing over to the other availability zone
     *
     * @see https://docs.aws.amazon.com/redshift/latest/mgmt/test-cluster-multi-az.html
     */
    FAILOVER_PRIMARY_COMPUTE = "failover-primary-compute"
}
/**
 * Username and password combination
 */
export interface Login {
    /**
     * Username
     */
    readonly masterUsername: string;
    /**
     * Password
     *
     * Do not put passwords in your CDK code directly.
     *
     * @default - a Secrets Manager generated password
     */
    readonly masterPassword?: SecretValue;
    /**
     * KMS encryption key to encrypt the generated secret.
     *
     * @default - default master key
     */
    readonly encryptionKey?: kms.IKey;
    /**
     * Characters to not include in the generated password.
     *
     * @default '"@/\\\ \''
     */
    readonly excludeCharacters?: string;
}
/**
 * Logging bucket and S3 prefix combination
 */
export interface LoggingProperties {
    /**
     * Bucket to send logs to.
     * Logging information includes queries and connection attempts, for the specified Amazon Redshift cluster.
     */
    readonly loggingBucket: s3.IBucket;
    /**
     * Prefix used for logging.
     */
    readonly loggingKeyPrefix: string;
}
/**
 * Options to add the multi user rotation
 */
export interface RotationMultiUserOptions {
    /**
     * The secret to rotate. It must be a JSON string with the following format:
     * ```
     * {
     *   "engine": <required: database engine>,
     *   "host": <required: instance host name>,
     *   "username": <required: username>,
     *   "password": <required: password>,
     *   "dbname": <optional: database name>,
     *   "port": <optional: if not specified, default port will be used>,
     *   "masterarn": <required: the arn of the master secret which will be used to create users/change passwords>
     * }
     * ```
     */
    readonly secret: secretsmanager.ISecret;
    /**
     * Specifies the number of days after the previous rotation before
     * Secrets Manager triggers the next automatic rotation.
     *
     * @default Duration.days(30)
     */
    readonly automaticallyAfter?: Duration;
}
/**
 * The maintenance track for the cluster.
 *
 * @see https://docs.aws.amazon.com/redshift/latest/mgmt/managing-cluster-considerations.html#rs-mgmt-maintenance-tracks
 */
export declare enum MaintenanceTrackName {
    /**
     * Updated to the most recently certified maintenance release.
     */
    CURRENT = "current",
    /**
     * Update to the previously certified maintenance release.
     */
    TRAILING = "trailing"
}
/**
 * Create a Redshift Cluster with a given number of nodes.
 * Implemented by `Cluster` via `ClusterBase`.
 */
export interface ICluster extends IResource, ec2.IConnectable, secretsmanager.ISecretAttachmentTarget {
    /**
     * Name of the cluster
     *
     * @attribute ClusterName
     */
    readonly clusterName: string;
    /**
     * The endpoint to use for read/write operations
     *
     * @attribute EndpointAddress,EndpointPort
     */
    readonly clusterEndpoint: Endpoint;
}
/**
 * Properties that describe an existing cluster instance
 */
export interface ClusterAttributes {
    /**
     * The security groups of the redshift cluster
     *
     * @default no security groups will be attached to the import
     */
    readonly securityGroups?: ec2.ISecurityGroup[];
    /**
     * Identifier for the cluster
     */
    readonly clusterName: string;
    /**
     * Cluster endpoint address
     */
    readonly clusterEndpointAddress: string;
    /**
     * Cluster endpoint port
     */
    readonly clusterEndpointPort: number;
}
/**
 * Properties for a new database cluster
 */
export interface ClusterProps {
    /**
     * An optional identifier for the cluster
     *
     * @default - A name is automatically generated.
     */
    readonly clusterName?: string;
    /**
     * Additional parameters to pass to the database engine
     * https://docs.aws.amazon.com/redshift/latest/mgmt/working-with-parameter-groups.html
     *
     * @default - No parameter group.
     */
    readonly parameterGroup?: IClusterParameterGroup;
    /**
     * Number of compute nodes in the cluster. Only specify this property for multi-node clusters.
     *
     * Value must be at least 2 and no more than 100.
     *
     * @default - 2 if `clusterType` is ClusterType.MULTI_NODE, undefined otherwise
     */
    readonly numberOfNodes?: number;
    /**
     * The node type to be provisioned for the cluster.
     *
     * @default `NodeType.RA3_LARGE`
     */
    readonly nodeType?: NodeType;
    /**
     * Settings for the individual instances that are launched
     *
     * @default `ClusterType.MULTI_NODE`
     */
    readonly clusterType?: ClusterType;
    /**
     * What port to listen on
     *
     * @default - The default for the engine is used.
     */
    readonly port?: number;
    /**
     * Whether to enable encryption of data at rest in the cluster.
     *
     * @default true
     */
    readonly encrypted?: boolean;
    /**
     * The KMS key to use for encryption of data at rest.
     *
     * @default - AWS-managed key, if encryption at rest is enabled
     */
    readonly encryptionKey?: kms.IKeyRef;
    /**
     * A preferred maintenance window day/time range. Should be specified as a range ddd:hh24:mi-ddd:hh24:mi (24H Clock UTC).
     *
     * Example: 'Sun:23:45-Mon:00:15'
     *
     * @default - 30-minute window selected at random from an 8-hour block of time for
     * each AWS Region, occurring on a random day of the week.
     * @see https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/USER_UpgradeDBInstance.Maintenance.html#Concepts.DBMaintenance
     */
    readonly preferredMaintenanceWindow?: string;
    /**
     * The VPC to place the cluster in.
     */
    readonly vpc: ec2.IVpc;
    /**
     * Where to place the instances within the VPC
     *
     * @default - private subnets
     */
    readonly vpcSubnets?: ec2.SubnetSelection;
    /**
     * Security group.
     *
     * @default - a new security group is created.
     */
    readonly securityGroups?: ec2.ISecurityGroup[];
    /**
     * A cluster subnet group to use with this cluster.
     *
     * @default - a new subnet group will be created.
     */
    readonly subnetGroup?: IClusterSubnetGroup;
    /**
     * Username and password for the administrative user
     */
    readonly masterUser: Login;
    /**
     * A list of AWS Identity and Access Management (IAM) role that can be used by the cluster to access other AWS services.
     * The maximum number of roles to attach to a cluster is subject to a quota.
     *
     * @default - No role is attached to the cluster.
     */
    readonly roles?: iam.IRole[];
    /**
     * A single AWS Identity and Access Management (IAM) role to be used as the default role for the cluster.
     * The default role must be included in the roles list.
     *
     * @default - No default role is specified for the cluster.
     */
    readonly defaultRole?: iam.IRole;
    /**
     * Name of a database which is automatically created inside the cluster
     *
     * @default - default_db
     */
    readonly defaultDatabaseName?: string;
    /**
     * Bucket details for log files to be sent to, including prefix.
     *
     * @default - No logging bucket is used
     */
    readonly loggingProperties?: LoggingProperties;
    /**
     * The removal policy to apply when the cluster and its instances are removed
     * from the stack or replaced during an update.
     *
     * @default RemovalPolicy.RETAIN
     */
    readonly removalPolicy?: RemovalPolicy;
    /**
     * Whether to make cluster publicly accessible.
     *
     * @default false
     */
    readonly publiclyAccessible?: boolean;
    /**
     * If this flag is set, the cluster resizing type will be set to classic.
     * When resizing a cluster, classic resizing will always provision a new cluster and transfer the data there.
     *
     * Classic resize takes more time to complete, but it can be useful in cases where the change in node count or
     * the node type to migrate to doesn't fall within the bounds for elastic resize.
     *
     * @see https://docs.aws.amazon.com/redshift/latest/mgmt/managing-cluster-operations.html#elastic-resize
     *
     * @default - Elastic resize type
     */
    readonly classicResizing?: boolean;
    /**
     * The Elastic IP (EIP) address for the cluster.
     *
     * @see https://docs.aws.amazon.com/redshift/latest/mgmt/managing-clusters-vpc.html
     *
     * @default - No Elastic IP
     */
    readonly elasticIp?: string;
    /**
     * If this flag is set, the cluster will be rebooted when changes to the cluster's parameter group that require a restart to apply.
     * @default false
     */
    readonly rebootForParameterChanges?: boolean;
    /**
     * If this flag is set, Amazon Redshift forces all COPY and UNLOAD traffic between your cluster and your data repositories through your virtual private cloud (VPC).
     *
     * @see https://docs.aws.amazon.com/redshift/latest/mgmt/enhanced-vpc-routing.html
     *
     * @default - false
     */
    readonly enhancedVpcRouting?: boolean;
    /**
     * Indicating whether Amazon Redshift should deploy the cluster in two Availability Zones.
     *
     * @default - false
     */
    readonly multiAz?: boolean;
    /**
     * The Amazon Redshift operation to be performed.
     *
     * @default - no operation
     */
    readonly resourceAction?: ResourceAction;
    /**
     * Whether to enable relocation for an Amazon Redshift cluster between Availability Zones after the cluster is created.
     *
     * @see https://docs.aws.amazon.com/redshift/latest/mgmt/managing-cluster-recovery.html
     *
     * @default - false
     */
    readonly availabilityZoneRelocation?: boolean;
    /**
     * The maintenance track name for the cluster.
     *
     * @see https://docs.aws.amazon.com/redshift/latest/mgmt/managing-cluster-considerations.html#rs-mgmt-maintenance-tracks
     *
     * @default undefined - Redshift default is current
     */
    readonly maintenanceTrackName?: MaintenanceTrackName;
}
/**
 * A new or imported clustered database.
 */
declare abstract class ClusterBase extends Resource implements ICluster {
    /**
     * Name of the cluster
     */
    abstract readonly clusterName: string;
    /**
     * The endpoint to use for read/write operations
     */
    abstract readonly clusterEndpoint: Endpoint;
    /**
     * Access to the network connections
     */
    abstract readonly connections: ec2.Connections;
    /**
     * Renders the secret attachment target specifications.
     */
    asSecretAttachmentTarget(): secretsmanager.SecretAttachmentTargetProps;
}
/**
 * Create a Redshift cluster a given number of nodes.
 *
 * @resource AWS::Redshift::Cluster
 */
export declare class Cluster extends ClusterBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an existing DatabaseCluster from properties
     */
    static fromClusterAttributes(scope: Construct, id: string, attrs: ClusterAttributes): ICluster;
    /**
     * Identifier of the cluster
     */
    readonly clusterName: string;
    /**
     * The endpoint to use for read/write operations
     */
    readonly clusterEndpoint: Endpoint;
    /**
     * Access to the network connections
     */
    readonly connections: ec2.Connections;
    /**
     * The secret attached to this cluster
     */
    readonly secret?: secretsmanager.ISecret;
    private readonly singleUserRotationApplication;
    private readonly multiUserRotationApplication;
    /**
     * The VPC where the DB subnet group is created.
     */
    private readonly vpc;
    /**
     * The subnets used by the DB subnet group.
     */
    private readonly vpcSubnets?;
    /**
     * The underlying CfnCluster
     */
    private readonly cluster;
    /**
     * The cluster's parameter group
     */
    protected parameterGroup?: IClusterParameterGroup;
    /**
     * The ARNs of the roles that will be attached to the cluster.
     *
     * **NOTE** Please do not access this directly, use the `addIamRole` method instead.
     */
    private readonly roles;
    constructor(scope: Construct, id: string, props: ClusterProps);
    /**
     * Adds the single user rotation of the master password to this cluster.
     *
     * @param [automaticallyAfter=Duration.days(30)] Specifies the number of days after the previous rotation
     * before Secrets Manager triggers the next automatic rotation.
     */
    addRotationSingleUser(automaticallyAfter?: Duration): secretsmanager.SecretRotation;
    /**
     * Adds the multi user rotation to this cluster.
     */
    addRotationMultiUser(id: string, options: RotationMultiUserOptions): secretsmanager.SecretRotation;
    private validateNodeCount;
    /**
     * Adds a parameter to the Clusters' parameter group
     *
     * @param name the parameter name
     * @param value the parameter name
     */
    addToParameterGroup(name: string, value: string): void;
    /**
     * Enables automatic cluster rebooting when changes to the cluster's parameter group require a restart to apply.
     */
    enableRebootForParameterChanges(): void;
    /**
     * Adds default IAM role to cluster. The default IAM role must be already associated to the cluster to be added as the default role.
     *
     * @param defaultIamRole the IAM role to be set as the default role
     */
    addDefaultIamRole(defaultIamRole: iam.IRole): void;
    /**
     * Adds a role to the cluster
     *
     * @param role the role to add
     */
    addIamRole(role: iam.IRole): void;
}
export {};
