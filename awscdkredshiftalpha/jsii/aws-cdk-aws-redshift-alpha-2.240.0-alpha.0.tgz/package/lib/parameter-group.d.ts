import type { IResource } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
/**
 * A parameter group
 */
export interface IClusterParameterGroup extends IResource {
    /**
     * The name of this parameter group
     *
     * @attribute
     */
    readonly clusterParameterGroupName: string;
}
/**
 * A new cluster or instance parameter group
 */
declare abstract class ClusterParameterGroupBase extends Resource implements IClusterParameterGroup {
    /**
     * The name of the parameter group
     */
    abstract readonly clusterParameterGroupName: string;
}
/**
 * Properties for a parameter group
 */
export interface ClusterParameterGroupProps {
    /**
     * Description for this parameter group
     *
     * @default a CDK generated description
     */
    readonly description?: string;
    /**
     * The parameters in this parameter group
     */
    readonly parameters: {
        [name: string]: string;
    };
}
/**
 * A cluster parameter group
 *
 * @resource AWS::Redshift::ClusterParameterGroup
 */
export declare class ClusterParameterGroup extends ClusterParameterGroupBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Imports a parameter group
     */
    static fromClusterParameterGroupName(scope: Construct, id: string, clusterParameterGroupName: string): IClusterParameterGroup;
    /**
     * The name of the parameter group
     */
    readonly clusterParameterGroupName: string;
    /**
     * The parameters in the parameter group
     */
    readonly parameters: {
        [name: string]: string;
    };
    /**
     * The underlying CfnClusterParameterGroup
     */
    private readonly resource;
    constructor(scope: Construct, id: string, props: ClusterParameterGroupProps);
    private parseParameters;
    /**
     * Adds a parameter to the parameter group
     *
     * @param name the parameter name
     * @param value the parameter name
     */
    addParameter(name: string, value: string): void;
}
export {};
