const VALIDATORS = { _aws_cdk_aws_redshift_alpha_ClusterAttributes: function _aws_cdk_aws_redshift_alpha_ClusterAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_redshift_alpha_ClusterProps: function _aws_cdk_aws_redshift_alpha_ClusterProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.masterUser))
                module.exports._aws_cdk_aws_redshift_alpha_Login(p.masterUser);
            if (!visitedObjects.has(p.loggingProperties))
                module.exports._aws_cdk_aws_redshift_alpha_LoggingProperties(p.loggingProperties);
            if (p.roles != null)
                for (const o of p.roles)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(o);
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_redshift_alpha_TableProps: function _aws_cdk_aws_redshift_alpha_TableProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tableColumns != null)
                for (const o of p.tableColumns)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_redshift_alpha_Column(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
