function _aws_cdk_aws_msk_alpha_ICluster(p) {
}
function _aws_cdk_aws_msk_alpha_ClusterBase(p) {
}
function _aws_cdk_aws_msk_alpha_ClusterProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.kafkaVersion))
            _aws_cdk_aws_msk_alpha_KafkaVersion(p.kafkaVersion);
        if (!visitedObjects.has(p.brokerType))
            _aws_cdk_aws_msk_alpha_BrokerType(p.brokerType);
        if (!visitedObjects.has(p.clientAuthentication))
            _aws_cdk_aws_msk_alpha_ClientAuthentication(p.clientAuthentication);
        if (!visitedObjects.has(p.configurationInfo))
            _aws_cdk_aws_msk_alpha_ClusterConfigurationInfo(p.configurationInfo);
        if (!visitedObjects.has(p.ebsStorageInfo))
            _aws_cdk_aws_msk_alpha_EbsStorageInfo(p.ebsStorageInfo);
        if (!visitedObjects.has(p.encryptionInTransit))
            _aws_cdk_aws_msk_alpha_EncryptionInTransitConfig(p.encryptionInTransit);
        if (!visitedObjects.has(p.logging))
            _aws_cdk_aws_msk_alpha_BrokerLogging(p.logging);
        if (!visitedObjects.has(p.monitoring))
            _aws_cdk_aws_msk_alpha_MonitoringConfiguration(p.monitoring);
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        if (!visitedObjects.has(p.storageMode))
            _aws_cdk_aws_msk_alpha_StorageMode(p.storageMode);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_msk_alpha_EbsStorageInfo(p) {
}
function _aws_cdk_aws_msk_alpha_StorageMode(p) {
}
function _aws_cdk_aws_msk_alpha_BrokerType(p) {
}
function _aws_cdk_aws_msk_alpha_ClusterConfigurationInfo(p) {
}
function _aws_cdk_aws_msk_alpha_ClusterMonitoringLevel(p) {
}
function _aws_cdk_aws_msk_alpha_MonitoringConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.clusterMonitoringLevel))
            _aws_cdk_aws_msk_alpha_ClusterMonitoringLevel(p.clusterMonitoringLevel);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_msk_alpha_BrokerLogging(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.s3))
            _aws_cdk_aws_msk_alpha_S3LoggingConfiguration(p.s3);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_msk_alpha_S3LoggingConfiguration(p) {
}
function _aws_cdk_aws_msk_alpha_ClientBrokerEncryption(p) {
}
function _aws_cdk_aws_msk_alpha_EncryptionInTransitConfig(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.clientBroker))
            _aws_cdk_aws_msk_alpha_ClientBrokerEncryption(p.clientBroker);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_msk_alpha_SaslAuthProps(p) {
}
function _aws_cdk_aws_msk_alpha_TlsAuthProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.certificateAuthorities != null)
            for (const o of p.certificateAuthorities)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_acmpca_ICertificateAuthority(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_msk_alpha_SaslTlsAuthProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.certificateAuthorities != null)
            for (const o of p.certificateAuthorities)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_acmpca_ICertificateAuthority(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_msk_alpha_ClientAuthentication(p) {
}
function _aws_cdk_aws_msk_alpha_Cluster(p) {
}
function _aws_cdk_aws_msk_alpha_KafkaVersionFeatures(p) {
}
function _aws_cdk_aws_msk_alpha_KafkaVersion(p) {
}
function _aws_cdk_aws_msk_alpha_ServerlessClusterProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.vpcConfigs != null)
            for (const o of p.vpcConfigs)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_msk_alpha_VpcConfig(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_msk_alpha_VpcConfig(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_msk_alpha_ServerlessCluster(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_msk_alpha_ICluster, _aws_cdk_aws_msk_alpha_ClusterBase, _aws_cdk_aws_msk_alpha_ClusterProps, _aws_cdk_aws_msk_alpha_EbsStorageInfo, _aws_cdk_aws_msk_alpha_StorageMode, _aws_cdk_aws_msk_alpha_BrokerType, _aws_cdk_aws_msk_alpha_ClusterConfigurationInfo, _aws_cdk_aws_msk_alpha_ClusterMonitoringLevel, _aws_cdk_aws_msk_alpha_MonitoringConfiguration, _aws_cdk_aws_msk_alpha_BrokerLogging, _aws_cdk_aws_msk_alpha_S3LoggingConfiguration, _aws_cdk_aws_msk_alpha_ClientBrokerEncryption, _aws_cdk_aws_msk_alpha_EncryptionInTransitConfig, _aws_cdk_aws_msk_alpha_SaslAuthProps, _aws_cdk_aws_msk_alpha_TlsAuthProps, _aws_cdk_aws_msk_alpha_SaslTlsAuthProps, _aws_cdk_aws_msk_alpha_ClientAuthentication, _aws_cdk_aws_msk_alpha_Cluster, _aws_cdk_aws_msk_alpha_KafkaVersionFeatures, _aws_cdk_aws_msk_alpha_KafkaVersion, _aws_cdk_aws_msk_alpha_ServerlessClusterProps, _aws_cdk_aws_msk_alpha_VpcConfig, _aws_cdk_aws_msk_alpha_ServerlessCluster };
