import * as ec2 from 'aws-cdk-lib/aws-ec2';
import type * as constructs from 'constructs';
import type { ICluster } from '.';
import { ClusterBase } from '.';
/**
 *  Properties for a MSK Serverless Cluster
 */
export interface ServerlessClusterProps {
    /**
     * The physical name of the cluster.
     *
     * @default - auto generate
     */
    readonly clusterName?: string;
    /**
     * The configuration of the Amazon VPCs for the cluster.
     * You can specify up to 5 VPC configurations.
     */
    readonly vpcConfigs: VpcConfig[];
}
/**
 * The configuration of the Amazon VPCs for the cluster.
 */
export interface VpcConfig {
    /**
     * Defines the virtual networking environment for this cluster.
     * Must have at least 2 subnets in two different AZs.
     */
    readonly vpc: ec2.IVpc;
    /**
     * The subnets associated with the cluster.
     *
     * @default - the Vpc default strategy if not specified.
     */
    readonly vpcSubnets?: ec2.SubnetSelection;
    /**
     * The security groups associated with the cluster.
     * You can specify up to 5 security groups.
     *
     * @default - create new security group
     */
    readonly securityGroups?: ec2.ISecurityGroup[];
}
/**
 * Create a MSK Serverless Cluster.
 *
 * @resource AWS::MSK::ServerlessCluster
 */
export declare class ServerlessCluster extends ClusterBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Reference an existing cluster, defined outside of the CDK code, by name.
     */
    static fromClusterArn(scope: constructs.Construct, id: string, clusterArn: string): ICluster;
    private resource;
    private _securityGroups;
    constructor(scope: constructs.Construct, id: string, props: ServerlessClusterProps);
    get clusterName(): string;
    get clusterArn(): string;
    /**
     * Render Vpc Config property
     */
    private _renderVpcConfig;
}
