const VALIDATORS = { _aws_cdk_aws_msk_alpha_ClusterProps: function _aws_cdk_aws_msk_alpha_ClusterProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.vpc))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_IVpc(p.vpc);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.ebsStorageInfo))
                module.exports._aws_cdk_aws_msk_alpha_EbsStorageInfo(p.ebsStorageInfo);
            if (!visitedObjects.has(p.instanceType))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_InstanceType(p.instanceType);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.logging))
                module.exports._aws_cdk_aws_msk_alpha_BrokerLogging(p.logging);
            if (!visitedObjects.has(p.removalPolicy))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_RemovalPolicy(p.removalPolicy);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.vpcSubnets))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(p.vpcSubnets);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_msk_alpha_EbsStorageInfo: function _aws_cdk_aws_msk_alpha_EbsStorageInfo(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.encryptionKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.encryptionKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_msk_alpha_BrokerLogging: function _aws_cdk_aws_msk_alpha_BrokerLogging(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.cloudwatchLogGroup))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_logs_ILogGroup(p.cloudwatchLogGroup);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.s3))
                module.exports._aws_cdk_aws_msk_alpha_S3LoggingConfiguration(p.s3);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_msk_alpha_S3LoggingConfiguration: function _aws_cdk_aws_msk_alpha_S3LoggingConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bucket))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_s3_IBucket(p.bucket);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_msk_alpha_SaslAuthProps: function _aws_cdk_aws_msk_alpha_SaslAuthProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.key))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.key);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_msk_alpha_TlsAuthProps: function _aws_cdk_aws_msk_alpha_TlsAuthProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.certificateAuthorities != null)
                for (const o of p.certificateAuthorities)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_acmpca_ICertificateAuthority(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_msk_alpha_SaslTlsAuthProps: function _aws_cdk_aws_msk_alpha_SaslTlsAuthProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.key))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_kms_IKeyRef(p.key);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.certificateAuthorities != null)
                for (const o of p.certificateAuthorities)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_acmpca_ICertificateAuthority(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_msk_alpha_ServerlessClusterProps: function _aws_cdk_aws_msk_alpha_ServerlessClusterProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.vpcConfigs != null)
                for (const o of p.vpcConfigs)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_msk_alpha_VpcConfig(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_msk_alpha_VpcConfig: function _aws_cdk_aws_msk_alpha_VpcConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.vpc))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_IVpc(p.vpc);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.vpcSubnets))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(p.vpcSubnets);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
