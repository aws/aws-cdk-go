function _aws_cdk_aws_glue_alpha_Code(p) {
}
function _aws_cdk_aws_glue_alpha_S3Code(p) {
}
function _aws_cdk_aws_glue_alpha_AssetCode(p) {
}
function _aws_cdk_aws_glue_alpha_CodeConfig(p) {
}
function _aws_cdk_aws_glue_alpha_ConnectionType(p) {
}
function _aws_cdk_aws_glue_alpha_IConnection(p) {
}
function _aws_cdk_aws_glue_alpha_ConnectionOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_ConnectionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.type))
            _aws_cdk_aws_glue_alpha_ConnectionType(p.type);
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_Connection(p) {
}
function _aws_cdk_aws_glue_alpha_InputFormat(p) {
}
function _aws_cdk_aws_glue_alpha_OutputFormat(p) {
}
function _aws_cdk_aws_glue_alpha_SerializationLibrary(p) {
}
function _aws_cdk_aws_glue_alpha_ClassificationString(p) {
}
function _aws_cdk_aws_glue_alpha_DataFormatProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputFormat))
            _aws_cdk_aws_glue_alpha_InputFormat(p.inputFormat);
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_aws_glue_alpha_OutputFormat(p.outputFormat);
        if (!visitedObjects.has(p.serializationLibrary))
            _aws_cdk_aws_glue_alpha_SerializationLibrary(p.serializationLibrary);
        if (!visitedObjects.has(p.classificationString))
            _aws_cdk_aws_glue_alpha_ClassificationString(p.classificationString);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_DataFormat(p) {
}
function _aws_cdk_aws_glue_alpha_DataQualityTargetTable(p) {
}
function _aws_cdk_aws_glue_alpha_IDataQualityRuleset(p) {
}
function _aws_cdk_aws_glue_alpha_DataQualityRulesetProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.targetTable))
            _aws_cdk_aws_glue_alpha_DataQualityTargetTable(p.targetTable);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_DataQualityRuleset(p) {
}
function _aws_cdk_aws_glue_alpha_IDatabase(p) {
}
function _aws_cdk_aws_glue_alpha_DatabaseProps(p) {
}
function _aws_cdk_aws_glue_alpha_Database(p) {
}
function _aws_cdk_aws_glue_alpha_ExternalTableProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.connection))
            _aws_cdk_aws_glue_alpha_IConnection(p.connection);
        if (p.columns != null)
            for (const o of p.columns)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Column(o);
        if (!visitedObjects.has(p.database))
            _aws_cdk_aws_glue_alpha_IDatabase(p.database);
        if (!visitedObjects.has(p.dataFormat))
            _aws_cdk_aws_glue_alpha_DataFormat(p.dataFormat);
        if (p.partitionIndexes != null)
            for (const o of p.partitionIndexes)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_PartitionIndex(o);
        if (p.partitionKeys != null)
            for (const o of p.partitionKeys)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Column(o);
        if (p.partitionProjection != null)
            for (const o of Object.values(p.partitionProjection))
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_PartitionProjectionConfiguration(o);
        if (p.storageParameters != null)
            for (const o of p.storageParameters)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_StorageParameter(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_ExternalTable(p) {
}
function _aws_cdk_aws_glue_alpha_PartitionProjectionType(p) {
}
function _aws_cdk_aws_glue_alpha_DateIntervalUnit(p) {
}
function _aws_cdk_aws_glue_alpha_IntegerPartitionProjectionConfigurationProps(p) {
}
function _aws_cdk_aws_glue_alpha_DatePartitionProjectionConfigurationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.intervalUnit))
            _aws_cdk_aws_glue_alpha_DateIntervalUnit(p.intervalUnit);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_EnumPartitionProjectionConfigurationProps(p) {
}
function _aws_cdk_aws_glue_alpha_PartitionProjectionConfiguration(p) {
}
function _aws_cdk_aws_glue_alpha_TableEncryption(p) {
}
function _aws_cdk_aws_glue_alpha_S3TableProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.encryption))
            _aws_cdk_aws_glue_alpha_TableEncryption(p.encryption);
        if (p.columns != null)
            for (const o of p.columns)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Column(o);
        if (!visitedObjects.has(p.database))
            _aws_cdk_aws_glue_alpha_IDatabase(p.database);
        if (!visitedObjects.has(p.dataFormat))
            _aws_cdk_aws_glue_alpha_DataFormat(p.dataFormat);
        if (p.partitionIndexes != null)
            for (const o of p.partitionIndexes)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_PartitionIndex(o);
        if (p.partitionKeys != null)
            for (const o of p.partitionKeys)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Column(o);
        if (p.partitionProjection != null)
            for (const o of Object.values(p.partitionProjection))
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_PartitionProjectionConfiguration(o);
        if (p.storageParameters != null)
            for (const o of p.storageParameters)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_StorageParameter(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_S3Table(p) {
}
function _aws_cdk_aws_glue_alpha_Column(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.type))
            _aws_cdk_aws_glue_alpha_Type(p.type);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_Type(p) {
}
function _aws_cdk_aws_glue_alpha_Schema(p) {
}
function _aws_cdk_aws_glue_alpha_ISecurityConfiguration(p) {
}
function _aws_cdk_aws_glue_alpha_S3EncryptionMode(p) {
}
function _aws_cdk_aws_glue_alpha_CloudWatchEncryptionMode(p) {
}
function _aws_cdk_aws_glue_alpha_JobBookmarksEncryptionMode(p) {
}
function _aws_cdk_aws_glue_alpha_S3Encryption(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.mode))
            _aws_cdk_aws_glue_alpha_S3EncryptionMode(p.mode);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_CloudWatchEncryption(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.mode))
            _aws_cdk_aws_glue_alpha_CloudWatchEncryptionMode(p.mode);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_JobBookmarksEncryption(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.mode))
            _aws_cdk_aws_glue_alpha_JobBookmarksEncryptionMode(p.mode);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_SecurityConfigurationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.cloudWatchEncryption))
            _aws_cdk_aws_glue_alpha_CloudWatchEncryption(p.cloudWatchEncryption);
        if (!visitedObjects.has(p.jobBookmarksEncryption))
            _aws_cdk_aws_glue_alpha_JobBookmarksEncryption(p.jobBookmarksEncryption);
        if (!visitedObjects.has(p.s3Encryption))
            _aws_cdk_aws_glue_alpha_S3Encryption(p.s3Encryption);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_SecurityConfiguration(p) {
}
function _aws_cdk_aws_glue_alpha_CompressionType(p) {
}
function _aws_cdk_aws_glue_alpha_InvalidCharHandlingAction(p) {
}
function _aws_cdk_aws_glue_alpha_NumericOverflowHandlingAction(p) {
}
function _aws_cdk_aws_glue_alpha_SurplusBytesHandlingAction(p) {
}
function _aws_cdk_aws_glue_alpha_SurplusCharHandlingAction(p) {
}
function _aws_cdk_aws_glue_alpha_ColumnCountMismatchHandlingAction(p) {
}
function _aws_cdk_aws_glue_alpha_WriteParallel(p) {
}
function _aws_cdk_aws_glue_alpha_OrcColumnMappingType(p) {
}
function _aws_cdk_aws_glue_alpha_StorageParameters(p) {
}
function _aws_cdk_aws_glue_alpha_StorageParameter(p) {
}
function _aws_cdk_aws_glue_alpha_WorkerType(p) {
}
function _aws_cdk_aws_glue_alpha_JobState(p) {
}
function _aws_cdk_aws_glue_alpha_MetricType(p) {
}
function _aws_cdk_aws_glue_alpha_ExecutionClass(p) {
}
function _aws_cdk_aws_glue_alpha_GlueVersion(p) {
}
function _aws_cdk_aws_glue_alpha_JobLanguage(p) {
}
function _aws_cdk_aws_glue_alpha_PythonVersion(p) {
}
function _aws_cdk_aws_glue_alpha_Runtime(p) {
}
function _aws_cdk_aws_glue_alpha_JobType(p) {
}
function _aws_cdk_aws_glue_alpha_MaxCapacity(p) {
}
function _aws_cdk_aws_glue_alpha_PredicateLogical(p) {
}
function _aws_cdk_aws_glue_alpha_ConditionLogicalOperator(p) {
}
function _aws_cdk_aws_glue_alpha_CrawlerState(p) {
}
function _aws_cdk_aws_glue_alpha_IJob(p) {
}
function _aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p) {
}
function _aws_cdk_aws_glue_alpha_JobBase(p) {
}
function _aws_cdk_aws_glue_alpha_JobAttributes(p) {
}
function _aws_cdk_aws_glue_alpha_JobProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.script))
            _aws_cdk_aws_glue_alpha_Code(p.script);
        if (p.connections != null)
            for (const o of p.connections)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_IConnection(o);
        if (!visitedObjects.has(p.continuousLogging))
            _aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        if (!visitedObjects.has(p.glueVersion))
            _aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
        if (!visitedObjects.has(p.securityConfiguration))
            _aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
        if (!visitedObjects.has(p.workerType))
            _aws_cdk_aws_glue_alpha_WorkerType(p.workerType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_Job(p) {
}
function _aws_cdk_aws_glue_alpha_SparkExtraCodeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.extraFiles != null)
            for (const o of p.extraFiles)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (p.extraJars != null)
            for (const o of p.extraJars)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (p.extraPythonFiles != null)
            for (const o of p.extraPythonFiles)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_SparkUIProps(p) {
}
function _aws_cdk_aws_glue_alpha_SparkUILoggingLocation(p) {
}
function _aws_cdk_aws_glue_alpha_SparkJobProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sparkUI))
            _aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
        if (!visitedObjects.has(p.script))
            _aws_cdk_aws_glue_alpha_Code(p.script);
        if (p.connections != null)
            for (const o of p.connections)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_IConnection(o);
        if (!visitedObjects.has(p.continuousLogging))
            _aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        if (!visitedObjects.has(p.glueVersion))
            _aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
        if (!visitedObjects.has(p.securityConfiguration))
            _aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
        if (!visitedObjects.has(p.workerType))
            _aws_cdk_aws_glue_alpha_WorkerType(p.workerType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_SparkJob(p) {
}
function _aws_cdk_aws_glue_alpha_PySparkEtlJobProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.extraFiles != null)
            for (const o of p.extraFiles)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (p.extraJars != null)
            for (const o of p.extraJars)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (p.extraPythonFiles != null)
            for (const o of p.extraPythonFiles)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (!visitedObjects.has(p.sparkUI))
            _aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
        if (!visitedObjects.has(p.script))
            _aws_cdk_aws_glue_alpha_Code(p.script);
        if (p.connections != null)
            for (const o of p.connections)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_IConnection(o);
        if (!visitedObjects.has(p.continuousLogging))
            _aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        if (!visitedObjects.has(p.glueVersion))
            _aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
        if (!visitedObjects.has(p.securityConfiguration))
            _aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
        if (!visitedObjects.has(p.workerType))
            _aws_cdk_aws_glue_alpha_WorkerType(p.workerType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_PySparkEtlJob(p) {
}
function _aws_cdk_aws_glue_alpha_PySparkFlexEtlJobProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.extraFiles != null)
            for (const o of p.extraFiles)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (p.extraJars != null)
            for (const o of p.extraJars)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (p.extraPythonFiles != null)
            for (const o of p.extraPythonFiles)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (!visitedObjects.has(p.sparkUI))
            _aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
        if (!visitedObjects.has(p.script))
            _aws_cdk_aws_glue_alpha_Code(p.script);
        if (p.connections != null)
            for (const o of p.connections)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_IConnection(o);
        if (!visitedObjects.has(p.continuousLogging))
            _aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        if (!visitedObjects.has(p.glueVersion))
            _aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
        if (!visitedObjects.has(p.securityConfiguration))
            _aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
        if (!visitedObjects.has(p.workerType))
            _aws_cdk_aws_glue_alpha_WorkerType(p.workerType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_PySparkFlexEtlJob(p) {
}
function _aws_cdk_aws_glue_alpha_PySparkStreamingJobProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.extraFiles != null)
            for (const o of p.extraFiles)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (p.extraJars != null)
            for (const o of p.extraJars)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (p.extraPythonFiles != null)
            for (const o of p.extraPythonFiles)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (!visitedObjects.has(p.sparkUI))
            _aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
        if (!visitedObjects.has(p.script))
            _aws_cdk_aws_glue_alpha_Code(p.script);
        if (p.connections != null)
            for (const o of p.connections)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_IConnection(o);
        if (!visitedObjects.has(p.continuousLogging))
            _aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        if (!visitedObjects.has(p.glueVersion))
            _aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
        if (!visitedObjects.has(p.securityConfiguration))
            _aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
        if (!visitedObjects.has(p.workerType))
            _aws_cdk_aws_glue_alpha_WorkerType(p.workerType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_PySparkStreamingJob(p) {
}
function _aws_cdk_aws_glue_alpha_PythonShellJobProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.maxCapacity))
            _aws_cdk_aws_glue_alpha_MaxCapacity(p.maxCapacity);
        if (!visitedObjects.has(p.pythonVersion))
            _aws_cdk_aws_glue_alpha_PythonVersion(p.pythonVersion);
        if (!visitedObjects.has(p.script))
            _aws_cdk_aws_glue_alpha_Code(p.script);
        if (p.connections != null)
            for (const o of p.connections)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_IConnection(o);
        if (!visitedObjects.has(p.continuousLogging))
            _aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        if (!visitedObjects.has(p.glueVersion))
            _aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
        if (!visitedObjects.has(p.securityConfiguration))
            _aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
        if (!visitedObjects.has(p.workerType))
            _aws_cdk_aws_glue_alpha_WorkerType(p.workerType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_PythonShellJob(p) {
}
function _aws_cdk_aws_glue_alpha_RayJobProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.runtime))
            _aws_cdk_aws_glue_alpha_Runtime(p.runtime);
        if (!visitedObjects.has(p.script))
            _aws_cdk_aws_glue_alpha_Code(p.script);
        if (p.connections != null)
            for (const o of p.connections)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_IConnection(o);
        if (!visitedObjects.has(p.continuousLogging))
            _aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        if (!visitedObjects.has(p.glueVersion))
            _aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
        if (!visitedObjects.has(p.securityConfiguration))
            _aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
        if (!visitedObjects.has(p.workerType))
            _aws_cdk_aws_glue_alpha_WorkerType(p.workerType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_RayJob(p) {
}
function _aws_cdk_aws_glue_alpha_ScalaSparkEtlJobProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.extraFiles != null)
            for (const o of p.extraFiles)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (p.extraJars != null)
            for (const o of p.extraJars)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (!visitedObjects.has(p.sparkUI))
            _aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
        if (!visitedObjects.has(p.script))
            _aws_cdk_aws_glue_alpha_Code(p.script);
        if (p.connections != null)
            for (const o of p.connections)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_IConnection(o);
        if (!visitedObjects.has(p.continuousLogging))
            _aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        if (!visitedObjects.has(p.glueVersion))
            _aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
        if (!visitedObjects.has(p.securityConfiguration))
            _aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
        if (!visitedObjects.has(p.workerType))
            _aws_cdk_aws_glue_alpha_WorkerType(p.workerType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_ScalaSparkEtlJob(p) {
}
function _aws_cdk_aws_glue_alpha_ScalaSparkFlexEtlJobProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.extraFiles != null)
            for (const o of p.extraFiles)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (p.extraJars != null)
            for (const o of p.extraJars)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (!visitedObjects.has(p.sparkUI))
            _aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
        if (!visitedObjects.has(p.script))
            _aws_cdk_aws_glue_alpha_Code(p.script);
        if (p.connections != null)
            for (const o of p.connections)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_IConnection(o);
        if (!visitedObjects.has(p.continuousLogging))
            _aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        if (!visitedObjects.has(p.glueVersion))
            _aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
        if (!visitedObjects.has(p.securityConfiguration))
            _aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
        if (!visitedObjects.has(p.workerType))
            _aws_cdk_aws_glue_alpha_WorkerType(p.workerType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_ScalaSparkFlexEtlJob(p) {
}
function _aws_cdk_aws_glue_alpha_ScalaSparkStreamingJobProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.extraFiles != null)
            for (const o of p.extraFiles)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (p.extraJars != null)
            for (const o of p.extraJars)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Code(o);
        if (!visitedObjects.has(p.sparkUI))
            _aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
        if (!visitedObjects.has(p.script))
            _aws_cdk_aws_glue_alpha_Code(p.script);
        if (p.connections != null)
            for (const o of p.connections)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_IConnection(o);
        if (!visitedObjects.has(p.continuousLogging))
            _aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        if (!visitedObjects.has(p.glueVersion))
            _aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
        if (!visitedObjects.has(p.securityConfiguration))
            _aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
        if (!visitedObjects.has(p.workerType))
            _aws_cdk_aws_glue_alpha_WorkerType(p.workerType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_ScalaSparkStreamingJob(p) {
}
function _aws_cdk_aws_glue_alpha_PartitionIndex(p) {
}
function _aws_cdk_aws_glue_alpha_ITable(p) {
}
function _aws_cdk_aws_glue_alpha_TableAttributes(p) {
}
function _aws_cdk_aws_glue_alpha_TableBaseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.columns != null)
            for (const o of p.columns)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Column(o);
        if (!visitedObjects.has(p.database))
            _aws_cdk_aws_glue_alpha_IDatabase(p.database);
        if (!visitedObjects.has(p.dataFormat))
            _aws_cdk_aws_glue_alpha_DataFormat(p.dataFormat);
        if (p.partitionIndexes != null)
            for (const o of p.partitionIndexes)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_PartitionIndex(o);
        if (p.partitionKeys != null)
            for (const o of p.partitionKeys)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Column(o);
        if (p.partitionProjection != null)
            for (const o of Object.values(p.partitionProjection))
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_PartitionProjectionConfiguration(o);
        if (p.storageParameters != null)
            for (const o of p.storageParameters)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_StorageParameter(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_TableBase(p) {
}
function _aws_cdk_aws_glue_alpha_TableProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.encryption))
            _aws_cdk_aws_glue_alpha_TableEncryption(p.encryption);
        if (p.columns != null)
            for (const o of p.columns)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Column(o);
        if (!visitedObjects.has(p.database))
            _aws_cdk_aws_glue_alpha_IDatabase(p.database);
        if (!visitedObjects.has(p.dataFormat))
            _aws_cdk_aws_glue_alpha_DataFormat(p.dataFormat);
        if (p.partitionIndexes != null)
            for (const o of p.partitionIndexes)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_PartitionIndex(o);
        if (p.partitionKeys != null)
            for (const o of p.partitionKeys)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Column(o);
        if (p.partitionProjection != null)
            for (const o of Object.values(p.partitionProjection))
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_PartitionProjectionConfiguration(o);
        if (p.storageParameters != null)
            for (const o of p.storageParameters)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_StorageParameter(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_Table(p) {
}
function _aws_cdk_aws_glue_alpha_IWorkflow(p) {
}
function _aws_cdk_aws_glue_alpha_WorkflowAttributes(p) {
}
function _aws_cdk_aws_glue_alpha_WorkflowProps(p) {
}
function _aws_cdk_aws_glue_alpha_WorkflowBase(p) {
}
function _aws_cdk_aws_glue_alpha_Workflow(p) {
}
function _aws_cdk_aws_glue_alpha_Action(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.job))
            _aws_cdk_aws_glue_alpha_IJob(p.job);
        if (!visitedObjects.has(p.securityConfiguration))
            _aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_TriggerSchedule(p) {
}
function _aws_cdk_aws_glue_alpha_Predicate(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.conditions != null)
            for (const o of p.conditions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Condition(o);
        if (!visitedObjects.has(p.logical))
            _aws_cdk_aws_glue_alpha_PredicateLogical(p.logical);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_Condition(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.crawlState))
            _aws_cdk_aws_glue_alpha_CrawlerState(p.crawlState);
        if (!visitedObjects.has(p.job))
            _aws_cdk_aws_glue_alpha_IJob(p.job);
        if (!visitedObjects.has(p.logicalOperator))
            _aws_cdk_aws_glue_alpha_ConditionLogicalOperator(p.logicalOperator);
        if (!visitedObjects.has(p.state))
            _aws_cdk_aws_glue_alpha_JobState(p.state);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_EventBatchingCondition(p) {
}
function _aws_cdk_aws_glue_alpha_TriggerOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.actions != null)
            for (const o of p.actions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Action(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_OnDemandTriggerOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.actions != null)
            for (const o of p.actions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Action(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_DailyScheduleTriggerOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.actions != null)
            for (const o of p.actions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Action(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_WeeklyScheduleTriggerOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.actions != null)
            for (const o of p.actions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Action(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_CustomScheduledTriggerOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.schedule))
            _aws_cdk_aws_glue_alpha_TriggerSchedule(p.schedule);
        if (p.actions != null)
            for (const o of p.actions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Action(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_NotifyEventTriggerOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.eventBatchingCondition))
            _aws_cdk_aws_glue_alpha_EventBatchingCondition(p.eventBatchingCondition);
        if (p.actions != null)
            for (const o of p.actions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Action(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_glue_alpha_ConditionalTriggerOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.predicate))
            _aws_cdk_aws_glue_alpha_Predicate(p.predicate);
        if (p.actions != null)
            for (const o of p.actions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_glue_alpha_Action(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_glue_alpha_Code, _aws_cdk_aws_glue_alpha_S3Code, _aws_cdk_aws_glue_alpha_AssetCode, _aws_cdk_aws_glue_alpha_CodeConfig, _aws_cdk_aws_glue_alpha_ConnectionType, _aws_cdk_aws_glue_alpha_IConnection, _aws_cdk_aws_glue_alpha_ConnectionOptions, _aws_cdk_aws_glue_alpha_ConnectionProps, _aws_cdk_aws_glue_alpha_Connection, _aws_cdk_aws_glue_alpha_InputFormat, _aws_cdk_aws_glue_alpha_OutputFormat, _aws_cdk_aws_glue_alpha_SerializationLibrary, _aws_cdk_aws_glue_alpha_ClassificationString, _aws_cdk_aws_glue_alpha_DataFormatProps, _aws_cdk_aws_glue_alpha_DataFormat, _aws_cdk_aws_glue_alpha_DataQualityTargetTable, _aws_cdk_aws_glue_alpha_IDataQualityRuleset, _aws_cdk_aws_glue_alpha_DataQualityRulesetProps, _aws_cdk_aws_glue_alpha_DataQualityRuleset, _aws_cdk_aws_glue_alpha_IDatabase, _aws_cdk_aws_glue_alpha_DatabaseProps, _aws_cdk_aws_glue_alpha_Database, _aws_cdk_aws_glue_alpha_ExternalTableProps, _aws_cdk_aws_glue_alpha_ExternalTable, _aws_cdk_aws_glue_alpha_PartitionProjectionType, _aws_cdk_aws_glue_alpha_DateIntervalUnit, _aws_cdk_aws_glue_alpha_IntegerPartitionProjectionConfigurationProps, _aws_cdk_aws_glue_alpha_DatePartitionProjectionConfigurationProps, _aws_cdk_aws_glue_alpha_EnumPartitionProjectionConfigurationProps, _aws_cdk_aws_glue_alpha_PartitionProjectionConfiguration, _aws_cdk_aws_glue_alpha_TableEncryption, _aws_cdk_aws_glue_alpha_S3TableProps, _aws_cdk_aws_glue_alpha_S3Table, _aws_cdk_aws_glue_alpha_Column, _aws_cdk_aws_glue_alpha_Type, _aws_cdk_aws_glue_alpha_Schema, _aws_cdk_aws_glue_alpha_ISecurityConfiguration, _aws_cdk_aws_glue_alpha_S3EncryptionMode, _aws_cdk_aws_glue_alpha_CloudWatchEncryptionMode, _aws_cdk_aws_glue_alpha_JobBookmarksEncryptionMode, _aws_cdk_aws_glue_alpha_S3Encryption, _aws_cdk_aws_glue_alpha_CloudWatchEncryption, _aws_cdk_aws_glue_alpha_JobBookmarksEncryption, _aws_cdk_aws_glue_alpha_SecurityConfigurationProps, _aws_cdk_aws_glue_alpha_SecurityConfiguration, _aws_cdk_aws_glue_alpha_CompressionType, _aws_cdk_aws_glue_alpha_InvalidCharHandlingAction, _aws_cdk_aws_glue_alpha_NumericOverflowHandlingAction, _aws_cdk_aws_glue_alpha_SurplusBytesHandlingAction, _aws_cdk_aws_glue_alpha_SurplusCharHandlingAction, _aws_cdk_aws_glue_alpha_ColumnCountMismatchHandlingAction, _aws_cdk_aws_glue_alpha_WriteParallel, _aws_cdk_aws_glue_alpha_OrcColumnMappingType, _aws_cdk_aws_glue_alpha_StorageParameters, _aws_cdk_aws_glue_alpha_StorageParameter, _aws_cdk_aws_glue_alpha_WorkerType, _aws_cdk_aws_glue_alpha_JobState, _aws_cdk_aws_glue_alpha_MetricType, _aws_cdk_aws_glue_alpha_ExecutionClass, _aws_cdk_aws_glue_alpha_GlueVersion, _aws_cdk_aws_glue_alpha_JobLanguage, _aws_cdk_aws_glue_alpha_PythonVersion, _aws_cdk_aws_glue_alpha_Runtime, _aws_cdk_aws_glue_alpha_JobType, _aws_cdk_aws_glue_alpha_MaxCapacity, _aws_cdk_aws_glue_alpha_PredicateLogical, _aws_cdk_aws_glue_alpha_ConditionLogicalOperator, _aws_cdk_aws_glue_alpha_CrawlerState, _aws_cdk_aws_glue_alpha_IJob, _aws_cdk_aws_glue_alpha_ContinuousLoggingProps, _aws_cdk_aws_glue_alpha_JobBase, _aws_cdk_aws_glue_alpha_JobAttributes, _aws_cdk_aws_glue_alpha_JobProps, _aws_cdk_aws_glue_alpha_Job, _aws_cdk_aws_glue_alpha_SparkExtraCodeProps, _aws_cdk_aws_glue_alpha_SparkUIProps, _aws_cdk_aws_glue_alpha_SparkUILoggingLocation, _aws_cdk_aws_glue_alpha_SparkJobProps, _aws_cdk_aws_glue_alpha_SparkJob, _aws_cdk_aws_glue_alpha_PySparkEtlJobProps, _aws_cdk_aws_glue_alpha_PySparkEtlJob, _aws_cdk_aws_glue_alpha_PySparkFlexEtlJobProps, _aws_cdk_aws_glue_alpha_PySparkFlexEtlJob, _aws_cdk_aws_glue_alpha_PySparkStreamingJobProps, _aws_cdk_aws_glue_alpha_PySparkStreamingJob, _aws_cdk_aws_glue_alpha_PythonShellJobProps, _aws_cdk_aws_glue_alpha_PythonShellJob, _aws_cdk_aws_glue_alpha_RayJobProps, _aws_cdk_aws_glue_alpha_RayJob, _aws_cdk_aws_glue_alpha_ScalaSparkEtlJobProps, _aws_cdk_aws_glue_alpha_ScalaSparkEtlJob, _aws_cdk_aws_glue_alpha_ScalaSparkFlexEtlJobProps, _aws_cdk_aws_glue_alpha_ScalaSparkFlexEtlJob, _aws_cdk_aws_glue_alpha_ScalaSparkStreamingJobProps, _aws_cdk_aws_glue_alpha_ScalaSparkStreamingJob, _aws_cdk_aws_glue_alpha_PartitionIndex, _aws_cdk_aws_glue_alpha_ITable, _aws_cdk_aws_glue_alpha_TableAttributes, _aws_cdk_aws_glue_alpha_TableBaseProps, _aws_cdk_aws_glue_alpha_TableBase, _aws_cdk_aws_glue_alpha_TableProps, _aws_cdk_aws_glue_alpha_Table, _aws_cdk_aws_glue_alpha_IWorkflow, _aws_cdk_aws_glue_alpha_WorkflowAttributes, _aws_cdk_aws_glue_alpha_WorkflowProps, _aws_cdk_aws_glue_alpha_WorkflowBase, _aws_cdk_aws_glue_alpha_Workflow, _aws_cdk_aws_glue_alpha_Action, _aws_cdk_aws_glue_alpha_TriggerSchedule, _aws_cdk_aws_glue_alpha_Predicate, _aws_cdk_aws_glue_alpha_Condition, _aws_cdk_aws_glue_alpha_EventBatchingCondition, _aws_cdk_aws_glue_alpha_TriggerOptions, _aws_cdk_aws_glue_alpha_OnDemandTriggerOptions, _aws_cdk_aws_glue_alpha_DailyScheduleTriggerOptions, _aws_cdk_aws_glue_alpha_WeeklyScheduleTriggerOptions, _aws_cdk_aws_glue_alpha_CustomScheduledTriggerOptions, _aws_cdk_aws_glue_alpha_NotifyEventTriggerOptions, _aws_cdk_aws_glue_alpha_ConditionalTriggerOptions };
