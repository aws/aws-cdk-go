import type { IResource } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
import type * as constructs from 'constructs';
/**
 * Properties of a DataQualityTargetTable.
 */
export declare class DataQualityTargetTable {
    /**
     * The database name of the target table.
     */
    readonly databaseName: string;
    /**
     * The table name of the target table.
     */
    readonly tableName: string;
    constructor(databaseName: string, tableName: string);
}
export interface IDataQualityRuleset extends IResource {
    /**
     * The ARN of the ruleset
     * @attribute
     */
    readonly rulesetArn: string;
    /**
     * The name of the ruleset
     * @attribute
     */
    readonly rulesetName: string;
}
/**
 * Construction properties for `DataQualityRuleset`
 */
export interface DataQualityRulesetProps {
    /**
     * The name of the ruleset
     * @default cloudformation generated name
     */
    readonly rulesetName?: string;
    /**
     * The client token of the ruleset
     * @attribute
     */
    readonly clientToken?: string;
    /**
     * The description of the ruleset
     * @attribute
     */
    readonly description?: string;
    /**
     * The dqdl of the ruleset
     * @attribute
     */
    readonly rulesetDqdl: string;
    /**
     *  Key-Value pairs that define tags for the ruleset.
     *  @default empty tags
     */
    readonly tags?: {
        [key: string]: string;
    };
    /**
     * The target table of the ruleset
     * @attribute
     */
    readonly targetTable: DataQualityTargetTable;
}
/**
 * A Glue Data Quality ruleset.
 */
export declare class DataQualityRuleset extends Resource implements IDataQualityRuleset {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    static fromRulesetArn(scope: constructs.Construct, id: string, rulesetArn: string): IDataQualityRuleset;
    static fromRulesetName(scope: constructs.Construct, id: string, rulesetName: string): IDataQualityRuleset;
    private static buildRulesetArn;
    private resource;
    constructor(scope: constructs.Construct, id: string, props: DataQualityRulesetProps);
    /**
     * Name of this ruleset.
     */
    get rulesetName(): string;
    /**
     * ARN of this ruleset.
     */
    get rulesetArn(): string;
}
