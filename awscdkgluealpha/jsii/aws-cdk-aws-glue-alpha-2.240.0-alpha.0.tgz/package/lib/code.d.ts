import type * as iam from 'aws-cdk-lib/aws-iam';
import type * as s3 from 'aws-cdk-lib/aws-s3';
import * as s3assets from 'aws-cdk-lib/aws-s3-assets';
import type * as constructs from 'constructs';
/**
 * Represents a Glue Job's Code assets (an asset can be a scripts, a jar, a python file or any other file).
 */
export declare abstract class Code {
    /**
     * Job code as an S3 object.
     * @param bucket The S3 bucket
     * @param key The object key
     */
    static fromBucket(bucket: s3.IBucket, key: string): S3Code;
    /**
     * Job code from a local disk path.
     *
     * @param path code file (not a directory).
     */
    static fromAsset(path: string, options?: s3assets.AssetOptions): AssetCode;
    /**
     * Called when the Job is initialized to allow this object to bind.
     */
    abstract bind(scope: constructs.Construct, grantable: iam.IGrantable): CodeConfig;
}
/**
 * Glue job Code from an S3 bucket.
 */
export declare class S3Code extends Code {
    private readonly bucket;
    private readonly key;
    constructor(bucket: s3.IBucket, key: string);
    bind(_scope: constructs.Construct, grantable: iam.IGrantable): CodeConfig;
}
/**
 * Job Code from a local file.
 */
export declare class AssetCode extends Code {
    private readonly path;
    private readonly options;
    private asset?;
    /**
     * @param path The path to the Code file.
     */
    constructor(path: string, options?: s3assets.AssetOptions);
    bind(scope: constructs.Construct, grantable: iam.IGrantable): CodeConfig;
    /**
     * Hash a string
     */
    private hashcode;
}
/**
 * Result of binding `Code` into a `Job`.
 */
export interface CodeConfig {
    /**
     * The location of the code in S3.
     */
    readonly s3Location: s3.Location;
}
