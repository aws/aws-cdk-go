import type * as cdk from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import type { Code } from '../code';
import type { SparkJobProps } from './spark-job';
import { SparkJob } from './spark-job';
/**
 * Flex Jobs class
 *
 * Flex jobs supports Python and Scala language.
 * The flexible execution class is appropriate for non-urgent jobs such as
 * pre-production jobs, testing, and one-time data loads.
 * Flexible job runs are supported for jobs using AWS Glue version 3.0 or later and G.1X or
 * G.2X worker types but will default to the latest version of Glue (currently Glue 3.0.)
 *
 * Similar to ETL, we’ll enable these features: —enable-metrics, —enable-spark-ui,
 * —enable-continuous-cloudwatch-log
 *
 */
export interface ScalaSparkFlexEtlJobProps extends SparkJobProps {
    /**
     * Specifies configuration properties of a notification (optional).
     * After a job run starts, the number of minutes to wait before sending a job run delay notification.
     * @default - undefined
     */
    readonly notifyDelayAfter?: cdk.Duration;
    /**
     * The fully qualified Scala class name that serves as the entry point for the job.
     *
     * @see `--class` in https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-glue-arguments.html
     */
    readonly className: string;
    /**
     * Additional files, such as configuration files that AWS Glue copies to the working directory of your script before executing it.
     *
     * @default - no extra files specified.
     *
     * @see https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-glue-arguments.html
     */
    readonly extraFiles?: Code[];
    /**
     * Extra Jars S3 URL (optional)
     * S3 URL where additional jar dependencies are located
     * @default - no extra jar files
     */
    readonly extraJars?: Code[];
    /**
     * Setting this value to true prioritizes the customer's extra JAR files in the classpath.
     *
     * @default false - priority is not given to user-provided jars
     *
     * @see `--user-jars-first` in https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-glue-arguments.html
     */
    readonly extraJarsFirst?: boolean;
}
/**
 * Spark ETL Jobs class
 *
 * ETL jobs support pySpark and Scala languages, for which there are separate
 * but similar constructors. ETL jobs default to the G2 worker type, but you
 * can override this default with other supported worker type values
 * (G1, G2, G4 and G8). ETL jobs defaults to Glue version 4.0, which you can
 * override to 3.0. The following ETL features are enabled by default:
 * —enable-metrics, —enable-spark-ui, —enable-continuous-cloudwatch-log.
 * You can find more details about version, worker type and other features
 * in Glue's public documentation.
 */
export declare class ScalaSparkFlexEtlJob extends SparkJob {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    private resource;
    /**
     * ScalaSparkFlexEtlJob constructor
     */
    constructor(scope: Construct, id: string, props: ScalaSparkFlexEtlJobProps);
    get jobArn(): string;
    get jobName(): string;
    /**
     * Set the executable arguments with best practices enabled by default
     *
     * @returns An array of arguments for Glue to use on execution
     */
    private executableArguments;
}
