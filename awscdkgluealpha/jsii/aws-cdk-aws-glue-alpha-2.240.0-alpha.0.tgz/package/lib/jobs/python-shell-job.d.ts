import type * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import type { JobProps } from './job';
import { Job } from './job';
import { PythonVersion, MaxCapacity } from '../constants';
/**
 * Properties for creating a Python Shell job
 */
export interface PythonShellJobProps extends JobProps {
    /**
     * Python Version
     * The version of Python to use to execute this job
     * @default 3.9 for Shell Jobs
     **/
    readonly pythonVersion?: PythonVersion;
    /**
     * The total number of DPU to assign to the Python Job
     *
     * @default 0.0625
     */
    readonly maxCapacity?: MaxCapacity;
    /**
     * Specifies whether job run queuing is enabled for the job runs for this job.
     * A value of true means job run queuing is enabled for the job runs.
     * If false or not populated, the job runs will not be considered for queueing.
     * If this field does not match the value set in the job run, then the value from
     * the job run field will be used. This property must be set to false for flex jobs.
     * If this property is enabled, maxRetries must be set to zero.
     *
     * @default false
     */
    readonly jobRunQueuingEnabled?: boolean;
}
/**
 * Python Shell Jobs class
 *
 * A Python shell job runs Python scripts as a shell and supports a Python version that
 * depends on the AWS Glue version you are using.
 * This can be used to schedule and run tasks that don't require an Apache Spark environment.
 */
export declare class PythonShellJob extends Job {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    readonly role: iam.IRole;
    readonly grantPrincipal: iam.IPrincipal;
    private resource;
    /**
     * PythonShellJob constructor
     */
    constructor(scope: Construct, id: string, props: PythonShellJobProps);
    get jobArn(): string;
    get jobName(): string;
    /**
     * Set the executable arguments with best practices enabled by default
     *
     * @returns An array of arguments for Glue to use on execution
     */
    private executableArguments;
}
