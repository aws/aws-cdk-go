import { CfnTable } from 'aws-cdk-lib/aws-glue';
import type * as iam from 'aws-cdk-lib/aws-iam';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as s3 from 'aws-cdk-lib/aws-s3';
import type { Construct } from 'constructs';
import type { PartitionIndex, TableBaseProps } from './table-base';
import { TableBase } from './table-base';
/**
 * Encryption options for a Table.
 *
 * @see https://docs.aws.amazon.com/athena/latest/ug/encryption.html
 */
export declare enum TableEncryption {
    /**
     * Server side encryption (SSE) with an Amazon S3-managed key.
     *
     * @see https://docs.aws.amazon.com/AmazonS3/latest/dev/UsingServerSideEncryption.html
     */
    S3_MANAGED = "SSE-S3",
    /**
     * Server-side encryption (SSE) with an AWS KMS key managed by the account owner.
     *
     * @see https://docs.aws.amazon.com/AmazonS3/latest/dev/UsingKMSEncryption.html
     */
    KMS = "SSE-KMS",
    /**
     * Server-side encryption (SSE) with an AWS KMS key managed by the KMS service.
     */
    KMS_MANAGED = "SSE-KMS-MANAGED",
    /**
     * Client-side encryption (CSE) with an AWS KMS key managed by the account owner.
     *
     * @see https://docs.aws.amazon.com/AmazonS3/latest/dev/UsingClientSideEncryption.html
     */
    CLIENT_SIDE_KMS = "CSE-KMS"
}
export interface S3TableProps extends TableBaseProps {
    /**
     * S3 bucket in which to store data.
     *
     * @default one is created for you
     */
    readonly bucket?: s3.IBucket;
    /**
     * S3 prefix under which table objects are stored.
     *
     * @default - No prefix. The data will be stored under the root of the bucket.
     */
    readonly s3Prefix?: string;
    /**
     * The kind of encryption to secure the data with.
     *
     * You can only provide this option if you are not explicitly passing in a bucket.
     *
     * If you choose `SSE-KMS`, you *can* provide an un-managed KMS key with `encryptionKey`.
     * If you choose `CSE-KMS`, you *must* provide an un-managed KMS key with `encryptionKey`.
     *
     * @default BucketEncryption.S3_MANAGED
     */
    readonly encryption?: TableEncryption;
    /**
     * External KMS key to use for bucket encryption.
     *
     * The `encryption` property must be `SSE-KMS` or `CSE-KMS`.
     *
     * @default key is managed by KMS.
     */
    readonly encryptionKey?: kms.IKey;
}
/**
 * A Glue table that targets a S3 dataset.
 * @resource AWS::Glue::Table
 */
export declare class S3Table extends TableBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    private resource;
    /**
     * S3 bucket in which the table's data resides.
     */
    readonly bucket: s3.IBucket;
    /**
     * S3 Key Prefix under which this table's files are stored in S3.
     */
    readonly s3Prefix: string;
    /**
     * The type of encryption enabled for the table.
     */
    readonly encryption: TableEncryption;
    /**
     * The KMS key used to secure the data if `encryption` is set to `CSE-KMS` or `SSE-KMS`. Otherwise, `undefined`.
     */
    readonly encryptionKey?: kms.IKey;
    /**
     * This table's partition indexes.
     */
    readonly partitionIndexes?: PartitionIndex[];
    protected readonly tableResource: CfnTable;
    constructor(scope: Construct, id: string, props: S3TableProps);
    /**
     * Name of this table.
     */
    get tableName(): string;
    /**
     * ARN of this table.
     */
    get tableArn(): string;
    /**
     * Grant read permissions to the table and the underlying data stored in S3 to an IAM principal.
     * [disable-awslint:no-grants]
     *
     * @param grantee the principal
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant write permissions to the table and the underlying data stored in S3 to an IAM principal.
     * [disable-awslint:no-grants]
     *
     * @param grantee the principal
     */
    grantWrite(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant read and write permissions to the table and the underlying data stored in S3 to an IAM principal.
     * [disable-awslint:no-grants]
     *
     * @param grantee the principal
     */
    grantReadWrite(grantee: iam.IGrantable): iam.Grant;
    protected generateS3PrefixForGrant(): string;
}
