import { CfnTable } from 'aws-cdk-lib/aws-glue';
import type * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import type { IConnection } from './connection';
import type { PartitionIndex, TableBaseProps } from './table-base';
import { TableBase } from './table-base';
export interface ExternalTableProps extends TableBaseProps {
    /**
     * The connection the table will use when performing reads and writes.
     *
     * @default - No connection
     */
    readonly connection: IConnection;
    /**
     * The data source location of the glue table, (e.g. `default_db_public_example` for Redshift).
     *
     * If this property is set, it will override both `bucket` and `s3Prefix`.
     *
     * @default - No outsourced data source location
     */
    readonly externalDataLocation: string;
}
/**
 * A Glue table that targets an external data location (e.g. A table in a Redshift Cluster).
 * @resource AWS::Glue::Table
 */
export declare class ExternalTable extends TableBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * The connection associated to this table
     */
    readonly connection: IConnection;
    /**
     * This table's partition indexes.
     */
    readonly partitionIndexes?: PartitionIndex[];
    protected readonly tableResource: CfnTable;
    private resource;
    constructor(scope: Construct, id: string, props: ExternalTableProps);
    /**
     * Name of this table.
     */
    get tableName(): string;
    /**
     * ARN of this table.
     */
    get tableArn(): string;
    /**
     * Grant read permissions to the table
     * [disable-awslint:no-grants]
     *
     * @param grantee the principal
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant write permissions to the table
     * [disable-awslint:no-grants]
     *
     * @param grantee the principal
     */
    grantWrite(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant read and write permissions to the table
     * [disable-awslint:no-grants]
     *
     * @param grantee the principal
     */
    grantReadWrite(grantee: iam.IGrantable): iam.Grant;
}
