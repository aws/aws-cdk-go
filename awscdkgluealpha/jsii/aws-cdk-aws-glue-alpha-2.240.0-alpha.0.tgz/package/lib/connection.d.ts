import type * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as cdk from 'aws-cdk-lib/core';
import type * as constructs from 'constructs';
/**
 * The type of the glue connection
 *
 * If you need to use a connection type that doesn't exist as a static member, you
 * can instantiate a `ConnectionType` object, e.g: `new ConnectionType('NEW_TYPE')`.
 *
 * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-glue-connection-connectioninput.html#cfn-glue-connection-connectioninput-connectiontype
 */
export declare class ConnectionType {
    /**
     * Designates a connection to a database through Java Database Connectivity (JDBC).
     */
    static readonly JDBC: ConnectionType;
    /**
     * Designates a connection to an Apache Kafka streaming platform.
     */
    static readonly KAFKA: ConnectionType;
    /**
     * Designates a connection to a MongoDB document database.
     */
    static readonly MONGODB: ConnectionType;
    /**
     * Designates a connection used for view validation by Amazon Redshift.
     */
    static readonly VIEW_VALIDATION_REDSHIFT: ConnectionType;
    /**
     * Designates a connection used for view validation by Amazon Athena.
     */
    static readonly VIEW_VALIDATION_ATHENA: ConnectionType;
    /**
     * Designates a network connection to a data source within an Amazon Virtual Private Cloud environment (Amazon VPC).
     */
    static readonly NETWORK: ConnectionType;
    /**
     * Uses configuration settings contained in a connector purchased from AWS Marketplace
     * to read from and write to data stores that are not natively supported by AWS Glue.
     */
    static readonly MARKETPLACE: ConnectionType;
    /**
     * Uses configuration settings contained in a custom connector to read from and write to data stores
     * that are not natively supported by AWS Glue.
     */
    static readonly CUSTOM: ConnectionType;
    /**
     * Designates a connection to Facebook Ads.
     */
    static readonly FACEBOOKADS: ConnectionType;
    /**
     * Designates a connection to Google Ads.
     */
    static readonly GOOGLEADS: ConnectionType;
    /**
     * Designates a connection to Google Sheets.
     */
    static readonly GOOGLESHEETS: ConnectionType;
    /**
     * Designates a connection to Google Analytics 4.
     */
    static readonly GOOGLEANALYTICS4: ConnectionType;
    /**
     * Designates a connection to HubSpot.
     */
    static readonly HUBSPOT: ConnectionType;
    /**
     * Designates a connection to Instagram Ads.
     */
    static readonly INSTAGRAMADS: ConnectionType;
    /**
     * Designates a connection to Intercom.
     */
    static readonly INTERCOM: ConnectionType;
    /**
     * Designates a connection to Jira Cloud.
     */
    static readonly JIRACLOUD: ConnectionType;
    /**
     * Designates a connection to Adobe Marketo Engage.
     */
    static readonly MARKETO: ConnectionType;
    /**
     * Designates a connection to Oracle NetSuite.
     */
    static readonly NETSUITEERP: ConnectionType;
    /**
     * Designates a connection to Salesforce using OAuth authentication.
     */
    static readonly SALESFORCE: ConnectionType;
    /**
     * Designates a connection to Salesforce Marketing Cloud.
     */
    static readonly SALESFORCEMARKETINGCLOUD: ConnectionType;
    /**
     * Designates a connection to Salesforce Marketing Cloud Account Engagement (MCAE).
     */
    static readonly SALESFORCEPARDOT: ConnectionType;
    /**
     * Designates a connection to SAP OData.
     */
    static readonly SAPODATA: ConnectionType;
    /**
     * Designates a connection to ServiceNow.
     */
    static readonly SERVICENOW: ConnectionType;
    /**
     * Designates a connection to Slack.
     */
    static readonly SLACK: ConnectionType;
    /**
     * Designates a connection to Snapchat Ads.
     */
    static readonly SNAPCHATADS: ConnectionType;
    /**
     * Designates a connection to Stripe.
     */
    static readonly STRIPE: ConnectionType;
    /**
     * Designates a connection to Zendesk.
     */
    static readonly ZENDESK: ConnectionType;
    /**
     * Designates a connection to Zoho CRM.
     */
    static readonly ZOHOCRM: ConnectionType;
    /**
     * The name of this ConnectionType, as expected by Connection resource.
     */
    readonly name: string;
    constructor(name: string);
    /**
     * The connection type name as expected by Connection resource.
     */
    toString(): string;
}
/**
 * Interface representing a created or an imported `Connection`
 */
export interface IConnection extends cdk.IResource {
    /**
     * The name of the connection
     * @attribute
     */
    readonly connectionName: string;
    /**
     * The ARN of the connection
     * @attribute
     */
    readonly connectionArn: string;
}
/**
 * Base Connection Options
 */
export interface ConnectionOptions {
    /**
     * The name of the connection
     * @default cloudformation generated name
     */
    readonly connectionName?: string;
    /**
     * The description of the connection.
     * @default no description
     */
    readonly description?: string;
    /**
     *  Key-Value pairs that define parameters for the connection.
     *  @default empty properties
     *  @see https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-connect.html
     */
    readonly properties?: {
        [key: string]: string;
    };
    /**
     * A list of criteria that can be used in selecting this connection.
     * This is useful for filtering the results of https://awscli.amazonaws.com/v2/documentation/api/latest/reference/glue/get-connections.html
     * @default no match criteria
     */
    readonly matchCriteria?: string[];
    /**
     * The list of security groups needed to successfully make this connection e.g. to successfully connect to VPC.
     * @default no security group
     */
    readonly securityGroups?: ec2.ISecurityGroup[];
    /**
     * The VPC subnet to connect to resources within a VPC. See more at https://docs.aws.amazon.com/glue/latest/dg/start-connecting.html.
     * @default no subnet
     */
    readonly subnet?: ec2.ISubnet;
}
/**
 * Construction properties for `Connection`
 */
export interface ConnectionProps extends ConnectionOptions {
    /**
     * The type of the connection
     */
    readonly type: ConnectionType;
}
/**
 * An AWS Glue connection to a data source.
 */
export declare class Connection extends cdk.Resource implements IConnection {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Creates a Connection construct that represents an external connection.
     *
     * @param scope The scope creating construct (usually `this`).
     * @param id The construct's id.
     * @param connectionArn arn of external connection.
     */
    static fromConnectionArn(scope: constructs.Construct, id: string, connectionArn: string): IConnection;
    /**
     * Creates a Connection construct that represents an external connection.
     *
     * @param scope The scope creating construct (usually `this`).
     * @param id The construct's id.
     * @param connectionName name of external connection.
     */
    static fromConnectionName(scope: constructs.Construct, id: string, connectionName: string): IConnection;
    private static buildConnectionArn;
    private readonly properties;
    private readonly resource;
    constructor(scope: constructs.Construct, id: string, props: ConnectionProps);
    /**
     * The name of the connection
     */
    get connectionName(): string;
    /**
     * The ARN of the connection
     */
    get connectionArn(): string;
    /**
     * Add additional connection parameters
     * @param key parameter key
     * @param value parameter value
     */
    addProperty(key: string, value: string): void;
}
