import type { CatalogReference, ICatalogRef } from 'aws-cdk-lib/aws-glue';
import type * as iam from 'aws-cdk-lib/aws-iam';
import type * as kms from 'aws-cdk-lib/aws-kms';
import type { IResource } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
/**
 * The encryption-at-rest mode for a Glue Data Catalog.
 *
 * @see https://docs.aws.amazon.com/glue/latest/webapi/API_EncryptionAtRest.html#Glue-Type-EncryptionAtRest-CatalogEncryptionMode
 */
export declare enum CatalogEncryptionMode {
    /**
     * Encryption at rest is disabled.
     */
    DISABLED = "DISABLED",
    /**
     * Server-side encryption (SSE) with an AWS KMS key.
     */
    SSE_KMS = "SSE-KMS",
    /**
     * Server-side encryption (SSE) with an AWS KMS key, using a service role that
     * AWS Glue assumes to access the key on your behalf.
     */
    SSE_KMS_WITH_SERVICE_ROLE = "SSE-KMS-WITH-SERVICE-ROLE"
}
/**
 * Encryption-at-rest configuration for a Glue Data Catalog.
 *
 * The Data Catalog encryption at rest and the connection password encryption
 * are independent: enabling one does not require the other, and each may use a
 * different KMS key.
 *
 * @see https://docs.aws.amazon.com/glue/latest/webapi/API_EncryptionAtRest.html
 */
export declare class DataCatalogEncryptionAtRest {
    /**
     * Disable encryption at rest for the Data Catalog.
     */
    static disabled(): DataCatalogEncryptionAtRest;
    /**
     * Encrypt the Data Catalog at rest with an AWS KMS key.
     *
     * @param key the KMS key to use. If omitted, an AWS-managed key is used and
     * the key is not exposed as a grantable resource.
     */
    static kms(key?: kms.IKey): DataCatalogEncryptionAtRest;
    /**
     * Encrypt the Data Catalog at rest with an AWS KMS key, accessed through a
     * service role that AWS Glue assumes on your behalf.
     *
     * When a customer-managed `key` is provided, the `role` is automatically
     * granted `kms:Encrypt`/`kms:Decrypt`/`kms:GenerateDataKey*` on it.
     *
     * @param role the service role that AWS Glue assumes to access the key.
     * @param key the KMS key to use. If omitted, an AWS-managed key is used and
     * the key is not exposed as a grantable resource.
     */
    static kmsWithServiceRole(role: iam.IRole, key?: kms.IKey): DataCatalogEncryptionAtRest;
    /**
     * The encryption mode.
     */
    readonly mode: CatalogEncryptionMode;
    /**
     * The customer-managed KMS key used for encryption at rest, if any.
     */
    readonly kmsKey?: kms.IKeyRef;
    /**
     * The service role that AWS Glue assumes to access the KMS key, if any.
     */
    readonly serviceRole?: iam.IRole;
    private constructor();
}
/**
 * Connection-password encryption configuration for a Glue Data Catalog.
 *
 * When enabled, the Data Catalog encrypts the password as part of
 * `CreateConnection` or `UpdateConnection` and stores it in the
 * `ENCRYPTED_PASSWORD` field of the connection properties. This is independent
 * from catalog encryption at rest, and may use a different KMS key.
 *
 * @see https://docs.aws.amazon.com/glue/latest/webapi/API_ConnectionPasswordEncryption.html
 */
export interface ConnectionPasswordEncryption {
    /**
     * The KMS key used to encrypt connection passwords.
     *
     * @default - an AWS-managed key is used and the key is not exposed as a grantable resource.
     */
    readonly kmsKey?: kms.IKeyRef;
    /**
     * Whether passwords remain encrypted in the responses of `GetConnection` and
     * `GetConnections`. This takes effect independently from catalog encryption.
     *
     * @default true
     */
    readonly returnConnectionPasswordEncrypted?: boolean;
}
/**
 * Encryption configuration for a Glue Data Catalog.
 *
 * Encryption is fixed at construction: a catalog either carries encryption
 * settings or it does not, which keeps its configuration easy to reason about
 * and avoids order-dependent mutation after the catalog is created.
 */
export interface CatalogEncryptionOptions {
    /**
     * Encryption-at-rest configuration for the catalog.
     *
     * @default - encryption at rest is not managed by CDK (the catalog default applies)
     */
    readonly encryptionAtRest?: DataCatalogEncryptionAtRest;
    /**
     * Connection-password encryption configuration for the catalog.
     *
     * @default - connection-password encryption is not managed by CDK
     */
    readonly connectionPasswordEncryption?: ConnectionPasswordEncryption;
}
/**
 * A Glue Data Catalog, either the implicit account-wide catalog or one created
 * as an `AWS::Glue::Catalog` resource.
 */
export interface ICatalog extends IResource, ICatalogRef {
    /**
     * The id of the catalog (for the account-wide catalog, the AWS account id).
     * @attribute
     */
    readonly catalogId: string;
    /**
     * The ARN of the catalog.
     * @attribute
     */
    readonly catalogArn: string;
    /**
     * The customer-managed KMS key used for the catalog's encryption at rest, if
     * one was configured.
     *
     * Undefined when encryption is disabled or an AWS-managed key is used. Grant
     * access to it via `KeyGrants`, e.g.
     * `if (catalog.encryptionKey) { KeyGrants.fromKey(catalog.encryptionKey).encrypt(grantee); }`.
     */
    readonly encryptionKey?: kms.IKeyRef;
    /**
     * The customer-managed KMS key used to encrypt connection passwords, if one
     * was configured.
     *
     * Undefined when password encryption uses an AWS-managed key or is not
     * configured. Grant access to it via `KeyGrants`, e.g.
     * `if (catalog.connectionPasswordKey) { KeyGrants.fromKey(catalog.connectionPasswordKey).encrypt(grantee); }`.
     */
    readonly connectionPasswordKey?: kms.IKeyRef;
}
/**
 * Base class for all `ICatalog` implementations. Materializes the single
 * `CfnDataCatalogEncryptionSettings` resource (targeting its own `catalogId`)
 * from the encryption options supplied at construction. Encryption is fixed at
 * construction, so a catalog either carries settings or it does not.
 */
export declare abstract class CatalogBase extends Resource implements ICatalog {
    abstract readonly catalogId: string;
    abstract readonly catalogArn: string;
    private _encryptionKey?;
    private _connectionPasswordKey?;
    get encryptionKey(): kms.IKeyRef | undefined;
    get connectionPasswordKey(): kms.IKeyRef | undefined;
    get catalogRef(): CatalogReference;
    /**
     * Emit the catalog's encryption settings from the options fixed at
     * construction. Subclasses call this once, after `catalogId`/`catalogArn` are
     * assigned. When neither block is configured, no resource is emitted, avoiding
     * an empty settings resource that would reset the catalog on deploy.
     */
    protected configureEncryption(options: CatalogEncryptionOptions): void;
}
/**
 * Construction properties for a `Catalog`.
 */
export interface CatalogProps extends CatalogEncryptionOptions {
    /**
     * The name of the catalog.
     */
    readonly catalogName: string;
    /**
     * A description of the catalog.
     *
     * @default - no description
     */
    readonly description?: string;
}
/**
 * A Glue Data Catalog.
 *
 * Use `Catalog.forAccount(scope)` to obtain the implicit account-wide catalog,
 * `Catalog.encryptAccount(scope, options)` to configure its Data Catalog
 * encryption, or `new Catalog(...)` to create an `AWS::Glue::Catalog` resource.
 */
export declare class Catalog extends CatalogBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Obtain the implicit, account-wide Data Catalog.
     *
     * The account catalog is not a CloudFormation resource; it always exists. This
     * returns a stack-scoped singleton, so repeated calls within the same stack
     * return the same instance.
     *
     * This returns the account catalog without managing its encryption. To
     * configure Data Catalog encryption for the account, use
     * `Catalog.encryptAccount(scope, options)` instead - it must be called before
     * the account catalog is first used in the stack.
     */
    static forAccount(scope: Construct): ICatalog;
    /**
     * Configure Data Catalog encryption for the implicit, account-wide catalog and
     * return it.
     *
     * The account catalog's encryption is an account/region-wide setting, managed
     * through the singleton `PutDataCatalogEncryptionSettings` API. Because
     * encryption is fixed at construction, it must be configured before the
     * account catalog is first used in the stack: calling this after the account
     * catalog has already been materialized (for example by `Catalog.forAccount`,
     * or by a `Database` that uses the account catalog) throws.
     *
     * Configure it in exactly one stack. Configuring it from multiple stacks in the
     * same account and region makes those stacks overwrite one another at deploy
     * time, and the result is order-dependent. Unlike duplicate settings within a
     * single stack (which CloudFormation rejects), this cross-stack conflict is not
     * caught at synthesis time, because each stack synthesizes to its own template.
     */
    static encryptAccount(scope: Construct, options: CatalogEncryptionOptions): ICatalog;
    /**
     * Import an existing catalog by its ARN.
     *
     * The ARN must be a Glue catalog ARN, either the account-wide catalog
     * (`arn:aws:glue:<region>:<account>:catalog`, whose id is the account) or a
     * named catalog (`arn:aws:glue:<region>:<account>:catalog/<name>`, whose id is
     * the name).
     *
     * The imported catalog is a pure identity handle and does not manage the
     * catalog's encryption. To manage an existing catalog's Data Catalog
     * encryption, add a `CfnDataCatalogEncryptionSettings` resource targeting its
     * id.
     */
    static fromCatalogArn(scope: Construct, id: string, catalogArn: string): ICatalog;
    /**
     * Import an existing catalog by its id.
     *
     * The imported catalog is a pure identity handle and does not manage the
     * catalog's encryption. To manage an existing catalog's Data Catalog
     * encryption, add a `CfnDataCatalogEncryptionSettings` resource targeting its
     * id.
     */
    static fromCatalogId(scope: Construct, id: string, catalogId: string): ICatalog;
    readonly catalogId: string;
    readonly catalogArn: string;
    private readonly resource;
    constructor(scope: Construct, id: string, props: CatalogProps);
}
