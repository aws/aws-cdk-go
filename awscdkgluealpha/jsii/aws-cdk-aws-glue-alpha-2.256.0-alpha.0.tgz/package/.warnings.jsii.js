const VALIDATORS = { _aws_cdk_aws_glue_alpha_ConnectionOptions: function _aws_cdk_aws_glue_alpha_ConnectionOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ConnectionProps: function _aws_cdk_aws_glue_alpha_ConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_S3TableProps: function _aws_cdk_aws_glue_alpha_S3TableProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.columns != null)
                for (const o of p.columns)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Column(o);
            if (p.partitionIndexes != null)
                for (const o of p.partitionIndexes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_PartitionIndex(o);
            if (p.partitionKeys != null)
                for (const o of p.partitionKeys)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Column(o);
            if (p.partitionProjection != null)
                for (const o of Object.values(p.partitionProjection))
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_PartitionProjectionConfiguration(o);
            if (p.storageParameters != null)
                for (const o of p.storageParameters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_StorageParameter(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_SecurityConfigurationProps: function _aws_cdk_aws_glue_alpha_SecurityConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.cloudWatchEncryption))
                module.exports._aws_cdk_aws_glue_alpha_CloudWatchEncryption(p.cloudWatchEncryption);
            if (!visitedObjects.has(p.jobBookmarksEncryption))
                module.exports._aws_cdk_aws_glue_alpha_JobBookmarksEncryption(p.jobBookmarksEncryption);
            if (!visitedObjects.has(p.s3Encryption))
                module.exports._aws_cdk_aws_glue_alpha_S3Encryption(p.s3Encryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_JobProps: function _aws_cdk_aws_glue_alpha_JobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_SparkJobProps: function _aws_cdk_aws_glue_alpha_SparkJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PySparkEtlJobProps: function _aws_cdk_aws_glue_alpha_PySparkEtlJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraPythonFiles != null)
                for (const o of p.extraPythonFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PySparkFlexEtlJobProps: function _aws_cdk_aws_glue_alpha_PySparkFlexEtlJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraPythonFiles != null)
                for (const o of p.extraPythonFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PySparkStreamingJobProps: function _aws_cdk_aws_glue_alpha_PySparkStreamingJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraPythonFiles != null)
                for (const o of p.extraPythonFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PythonShellJobProps: function _aws_cdk_aws_glue_alpha_PythonShellJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraPythonFiles != null)
                for (const o of p.extraPythonFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_RayJobProps: function _aws_cdk_aws_glue_alpha_RayJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ScalaSparkEtlJobProps: function _aws_cdk_aws_glue_alpha_ScalaSparkEtlJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ScalaSparkFlexEtlJobProps: function _aws_cdk_aws_glue_alpha_ScalaSparkFlexEtlJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ScalaSparkStreamingJobProps: function _aws_cdk_aws_glue_alpha_ScalaSparkStreamingJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_TableProps: function _aws_cdk_aws_glue_alpha_TableProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.columns != null)
                for (const o of p.columns)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Column(o);
            if (p.partitionIndexes != null)
                for (const o of p.partitionIndexes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_PartitionIndex(o);
            if (p.partitionKeys != null)
                for (const o of p.partitionKeys)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Column(o);
            if (p.partitionProjection != null)
                for (const o of Object.values(p.partitionProjection))
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_PartitionProjectionConfiguration(o);
            if (p.storageParameters != null)
                for (const o of p.storageParameters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_StorageParameter(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_TriggerOptions: function _aws_cdk_aws_glue_alpha_TriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_OnDemandTriggerOptions: function _aws_cdk_aws_glue_alpha_OnDemandTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_DailyScheduleTriggerOptions: function _aws_cdk_aws_glue_alpha_DailyScheduleTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_WeeklyScheduleTriggerOptions: function _aws_cdk_aws_glue_alpha_WeeklyScheduleTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_CustomScheduledTriggerOptions: function _aws_cdk_aws_glue_alpha_CustomScheduledTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_NotifyEventTriggerOptions: function _aws_cdk_aws_glue_alpha_NotifyEventTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventBatchingCondition))
                module.exports._aws_cdk_aws_glue_alpha_EventBatchingCondition(p.eventBatchingCondition);
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ConditionalTriggerOptions: function _aws_cdk_aws_glue_alpha_ConditionalTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
