import type { Construct } from 'constructs';
import type { Code } from '../code';
import type { SparkJobProps } from './spark-job';
import { SparkJob } from './spark-job';
/**
 * Properties for creating a Python Spark ETL job
 */
export interface PySparkStreamingJobProps extends SparkJobProps {
    /**
     * Extra Python Files S3 URL (optional)
     * S3 URL where additional python dependencies are located
     *
     * @default - no extra files
     */
    readonly extraPythonFiles?: Code[];
    /**
     * Additional files, such as configuration files that AWS Glue copies to the working directory of your script before executing it.
     *
     * @default - no extra files specified.
     *
     * @see https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-glue-arguments.html
     */
    readonly extraFiles?: Code[];
    /**
     * Extra Jars S3 URL (optional)
     * S3 URL where additional jar dependencies are located
     * @default - no extra jar files
     */
    readonly extraJars?: Code[];
    /**
     * Setting this value to true prioritizes the customer's extra JAR files in the classpath.
     *
     * @default false - priority is not given to user-provided jars
     *
     * @see `--user-jars-first` in https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-glue-arguments.html
     */
    readonly extraJarsFirst?: boolean;
    /**
     * Specifies whether job run queuing is enabled for the job runs for this job.
     * A value of true means job run queuing is enabled for the job runs.
     * If false or not populated, the job runs will not be considered for queueing.
     * If this field does not match the value set in the job run, then the value from
     * the job run field will be used. This property must be set to false for flex jobs.
     * If this property is enabled, maxRetries must be set to zero.
     *
     * @default - no job run queuing
     */
    readonly jobRunQueuingEnabled?: boolean;
}
/**
 * Python Spark Streaming Jobs class
 *
 * A Streaming job is similar to an ETL job, except that it performs ETL on data streams
 * using the Apache Spark Structured Streaming framework.
 * These jobs will default to use Python 3.9.
 *
 * Similar to ETL jobs, streaming job supports Scala and Python languages. Similar to ETL,
 * it supports G1 and G2 worker type and 2.0, 3.0 and 4.0 version. We’ll default to G2 worker
 * and 4.0 version for streaming jobs which developers can override.
 * We will enable --enable-metrics, --enable-continuous-cloudwatch-log. The Spark UI
 * (--enable-spark-ui) is off by default; enable it by setting the `sparkUI` prop.
 */
export declare class PySparkStreamingJob extends SparkJob {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    private resource;
    /**
     * PySparkStreamingJob constructor
     */
    constructor(scope: Construct, id: string, props: PySparkStreamingJobProps);
    get jobArn(): string;
    get jobName(): string;
    /**
     * Set the executable arguments with best practices enabled by default
     *
     * @returns An array of arguments for Glue to use on execution
     */
    private executableArguments;
}
