const VALIDATORS = { _aws_cdk_aws_glue_alpha_CatalogEncryptionOptions: function _aws_cdk_aws_glue_alpha_CatalogEncryptionOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.connectionPasswordEncryption))
                module.exports._aws_cdk_aws_glue_alpha_ConnectionPasswordEncryption(p.connectionPasswordEncryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_CatalogProps: function _aws_cdk_aws_glue_alpha_CatalogProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.connectionPasswordEncryption))
                module.exports._aws_cdk_aws_glue_alpha_ConnectionPasswordEncryption(p.connectionPasswordEncryption);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ConnectionOptions: function _aws_cdk_aws_glue_alpha_ConnectionOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ConnectionProps: function _aws_cdk_aws_glue_alpha_ConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_WorkerType: function _aws_cdk_aws_glue_alpha_WorkerType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p === "Z.2X")
                print("@aws-cdk/aws-glue-alpha.WorkerType#Z_2X", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nThis worker type was only used for Ray jobs. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_Runtime: function _aws_cdk_aws_glue_alpha_Runtime(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.Runtime", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
            if (p === "Ray2.4")
                print("@aws-cdk/aws-glue-alpha.Runtime#RAY_TWO_FOUR", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_JobType: function _aws_cdk_aws_glue_alpha_JobType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p === "glueray")
                print("@aws-cdk/aws-glue-alpha.JobType#RAY", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_JobProps: function _aws_cdk_aws_glue_alpha_JobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_WorkerConfiguration: function _aws_cdk_aws_glue_alpha_WorkerConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.workerType))
                module.exports._aws_cdk_aws_glue_alpha_WorkerType(p.workerType);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_SparkJobProps: function _aws_cdk_aws_glue_alpha_SparkJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PySparkEtlJobProps: function _aws_cdk_aws_glue_alpha_PySparkEtlJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraPythonFiles != null)
                for (const o of p.extraPythonFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PySparkFlexEtlJobProps: function _aws_cdk_aws_glue_alpha_PySparkFlexEtlJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraPythonFiles != null)
                for (const o of p.extraPythonFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PySparkStreamingJobProps: function _aws_cdk_aws_glue_alpha_PySparkStreamingJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraPythonFiles != null)
                for (const o of p.extraPythonFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PythonShellJobProps: function _aws_cdk_aws_glue_alpha_PythonShellJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraPythonFiles != null)
                for (const o of p.extraPythonFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_RayJobProps: function _aws_cdk_aws_glue_alpha_RayJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("enableMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.RayJobProps#enableMetrics", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
            if ("enableObservabilityMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.RayJobProps#enableObservabilityMetrics", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
            if ("jobRunQueuingEnabled" in p)
                print("@aws-cdk/aws-glue-alpha.RayJobProps#jobRunQueuingEnabled", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
            if ("numberOfWorkers" in p)
                print("@aws-cdk/aws-glue-alpha.RayJobProps#numberOfWorkers", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
            if ("runtime" in p)
                print("@aws-cdk/aws-glue-alpha.RayJobProps#runtime", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
            if (!visitedObjects.has(p.runtime))
                module.exports._aws_cdk_aws_glue_alpha_Runtime(p.runtime);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ScalaSparkEtlJobProps: function _aws_cdk_aws_glue_alpha_ScalaSparkEtlJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ScalaSparkFlexEtlJobProps: function _aws_cdk_aws_glue_alpha_ScalaSparkFlexEtlJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ScalaSparkStreamingJobProps: function _aws_cdk_aws_glue_alpha_ScalaSparkStreamingJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_TriggerOptions: function _aws_cdk_aws_glue_alpha_TriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_OnDemandTriggerOptions: function _aws_cdk_aws_glue_alpha_OnDemandTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_DailyScheduleTriggerOptions: function _aws_cdk_aws_glue_alpha_DailyScheduleTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_WeeklyScheduleTriggerOptions: function _aws_cdk_aws_glue_alpha_WeeklyScheduleTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_CustomScheduledTriggerOptions: function _aws_cdk_aws_glue_alpha_CustomScheduledTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_NotifyEventTriggerOptions: function _aws_cdk_aws_glue_alpha_NotifyEventTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.eventBatchingCondition))
                module.exports._aws_cdk_aws_glue_alpha_EventBatchingCondition(p.eventBatchingCondition);
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ConditionalTriggerOptions: function _aws_cdk_aws_glue_alpha_ConditionalTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
