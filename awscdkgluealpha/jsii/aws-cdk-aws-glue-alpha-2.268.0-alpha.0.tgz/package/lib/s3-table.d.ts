import { CfnTable } from 'aws-cdk-lib/aws-glue';
import type * as iam from 'aws-cdk-lib/aws-iam';
import * as kms from 'aws-cdk-lib/aws-kms';
import * as s3 from 'aws-cdk-lib/aws-s3';
import type { Construct } from 'constructs';
import type { PartitionIndex, TableBaseProps } from './table-base';
import { TableBase } from './table-base';
/**
 * Server-side encryption for the S3 bucket that a managed `S3Table` creates.
 *
 * Applies only when the table manages its own bucket (via
 * `S3TableStorage.managedBucket`). An existing bucket keeps whatever encryption
 * it was created with.
 */
export declare class S3TableEncryption {
    /**
     * Server-side encryption (SSE-S3) with an Amazon S3-managed key.
     */
    static s3Managed(): S3TableEncryption;
    /**
     * Server-side encryption (SSE-KMS) with an AWS KMS key managed by the account owner.
     *
     * @param key the KMS key used to encrypt the data. A key is created if one is not provided.
     */
    static kms(key?: kms.IKey): S3TableEncryption;
    /**
     * Server-side encryption (SSE-KMS) with an AWS KMS key managed by the KMS service.
     */
    static kmsManaged(): S3TableEncryption;
    /** @internal */
    readonly _bucketEncryption: s3.BucketEncryption;
    /**
     * @internal
     * Typed `kms.IKey` (not `IKeyRef`) because it is forwarded to `s3.Bucket`, whose `encryptionKey` prop requires `IKey`.
     */
    readonly _kmsKey?: kms.IKey;
    private constructor();
}
/**
 * Where an `S3Table` stores its data.
 *
 * The two paths are mutually exclusive: a managed bucket may specify its
 * server-side encryption, while an existing bucket keeps its own encryption — so
 * an encryption choice can never be paired with a bring-your-own bucket.
 */
export declare class S3TableStorage {
    /**
     * Store the table's data in a bucket created and managed by the table.
     *
     * @param encryption the server-side encryption for the created bucket.
     * @default - S3-managed (SSE-S3) encryption
     */
    static managedBucket(encryption?: S3TableEncryption): S3TableStorage;
    /**
     * Store the table's data in an existing bucket. CDK does not manage the
     * bucket's encryption.
     *
     * The bucket can be one you don't own, imported with
     * `Bucket.fromBucketArn()` or `Bucket.fromBucketAttributes()`. If that bucket
     * is KMS-encrypted, import it with `Bucket.fromBucketAttributes()` and supply
     * the `encryptionKey` attribute. Otherwise, CDK has no reference to the key,
     * which means that `S3Table.grantRead()`/`grantWrite()` will correctly grant
     * S3 access but silently skip the KMS permissions on the key. As a consequence,
     * at runtime, reads and writes will fail with access denied on the key.
     *
     * @param bucket the bucket that holds the table's data.
     */
    static fromBucket(bucket: s3.IBucket): S3TableStorage;
    /** @internal */
    readonly _bucket?: s3.IBucket;
    /** @internal */
    readonly _encryption?: S3TableEncryption;
    private constructor();
}
/**
 * Client-side encryption for an `S3Table`'s data.
 *
 * Independent of the bucket's server-side encryption and of who owns the bucket:
 * the data is encrypted by the client before it is written to S3. When set, the
 * `grant*` methods also grant the relevant KMS permissions on the key.
 */
export declare class TableClientSideEncryption {
    /**
     * Client-side encryption (CSE-KMS) with an AWS KMS key managed by the account owner.
     *
     * @param key the KMS key used to encrypt the data. A key is created if one is not provided.
     */
    static kms(key?: kms.IKeyRef): TableClientSideEncryption;
    /** @internal */
    readonly _kmsKey?: kms.IKeyRef;
    private constructor();
}
export interface S3TableProps extends TableBaseProps {
    /**
     * Where the table's data is stored: a bucket created and managed by the table,
     * or an existing bucket you provide.
     *
     * @default - a managed bucket with S3-managed (SSE-S3) encryption
     */
    readonly storage?: S3TableStorage;
    /**
     * S3 prefix under which table objects are stored.
     *
     * When the table shares a bucket with other tables or consumers, set this so
     * that the `grant*` methods scope S3 access to this table's data. Without a
     * prefix, those grants cover the entire bucket.
     *
     * @default - No prefix. The data will be stored under the root of the bucket.
     */
    readonly s3Prefix?: string;
    /**
     * Client-side encryption (CSE-KMS) for the table's data.
     *
     * Independent of the bucket's server-side encryption, and valid whether the
     * bucket is managed or provided.
     *
     * @default - no client-side encryption
     */
    readonly clientSideEncryption?: TableClientSideEncryption;
}
/**
 * A Glue table that targets a S3 dataset.
 * @resource AWS::Glue::Table
 */
export declare class S3Table extends TableBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    private resource;
    /**
     * S3 bucket in which the table's data resides.
     */
    readonly bucket: s3.IBucket;
    /**
     * S3 Key Prefix under which this table's files are stored in S3.
     */
    readonly s3Prefix: string;
    /**
     * The KMS key used for client-side encryption of the table's data, if
     * `clientSideEncryption` was configured. Otherwise, `undefined`.
     *
     * For server-side (bucket) encryption, read `bucket.encryptionKey` instead.
     */
    readonly clientSideEncryptionKey?: kms.IKeyRef;
    /**
     * This table's partition indexes.
     */
    readonly partitionIndexes?: PartitionIndex[];
    protected readonly tableResource: CfnTable;
    /**
     * Whether the data bucket was supplied by the user (as opposed to created by
     * this construct). A user-supplied bucket may hold data for other tables, so
     * granting access to the whole bucket can over-grant.
     */
    private readonly userProvidedBucket;
    constructor(scope: Construct, id: string, props: S3TableProps);
    /**
     * Name of this table.
     */
    get tableName(): string;
    /**
     * ARN of this table.
     */
    get tableArn(): string;
    /**
     * Grant read permissions to the table and the underlying data stored in S3 to an IAM principal.
     * [disable-awslint:no-grants]
     *
     * @param grantee the principal
     */
    grantRead(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant write permissions to the table and the underlying data stored in S3 to an IAM principal.
     * [disable-awslint:no-grants]
     *
     * @param grantee the principal
     */
    grantWrite(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant read and write permissions to the table and the underlying data stored in S3 to an IAM principal.
     * [disable-awslint:no-grants]
     *
     * @param grantee the principal
     */
    grantReadWrite(grantee: iam.IGrantable): iam.Grant;
    protected generateS3PrefixForGrant(): string;
    private createManagedBucket;
}
