import { type IDatabaseRef } from 'aws-cdk-lib/aws-glue';
import type { IResource, RemovalPolicy } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
import type * as constructs from 'constructs';
import type { ITable } from './table-base';
/**
 * The Glue table a `DataQualityRuleset` evaluates.
 */
export declare class DataQualityTargetTable {
    /**
     * Target an L2 table in a database.
     *
     * @param database the database that holds the table.
     * @param table the table to evaluate.
     */
    static fromTable(database: IDatabaseRef, table: ITable): DataQualityTargetTable;
    /**
     * Target a table by name in a database. Use this when the table is not
     * modeled as an L2 construct (e.g. it is imported or created elsewhere).
     *
     * @param database the database that holds the table.
     * @param tableName the name of the table to evaluate.
     */
    static fromTableName(database: IDatabaseRef, tableName: string): DataQualityTargetTable;
    /**
     * The database name of the target table.
     */
    readonly databaseName: string;
    /**
     * The table name of the target table.
     */
    readonly tableName: string;
    private constructor();
}
/**
 * The Data Quality Definition Language (DQDL) document for a `DataQualityRuleset`.
 *
 * DQDL is an authored string that Glue parses and validates at deploy time. Build
 * one from a raw DQDL string with {@link Dqdl.fromString}.
 *
 * @see https://docs.aws.amazon.com/glue/latest/dg/dqdl.html
 */
export declare class Dqdl {
    private readonly dqdl;
    /**
     * Create a `Dqdl` from a raw DQDL string.
     *
     * @param dqdl the DQDL document, e.g. `Rules = [ RowCount > 100 ]`.
     */
    static fromString(dqdl: string): Dqdl;
    private constructor();
    /**
     * Render this DQDL to the string expected by the Glue ruleset resource.
     *
     * @internal
     */
    _render(): string;
}
export interface IDataQualityRuleset extends IResource {
    /**
     * The ARN of the ruleset
     * @attribute
     */
    readonly rulesetArn: string;
    /**
     * The name of the ruleset
     * @attribute
     */
    readonly rulesetName: string;
}
/**
 * Construction properties for `DataQualityRuleset`
 */
export interface DataQualityRulesetProps {
    /**
     * The name of the ruleset
     */
    readonly rulesetName: string;
    /**
     * The description of the ruleset
     * @attribute
     */
    readonly description?: string;
    /**
     * The DQDL document defining the ruleset's data quality rules.
     *
     * Build it with `Dqdl.fromString(...)`.
     */
    readonly dqdl: Dqdl;
    /**
     *  Key-Value pairs that define tags for the ruleset.
     *  @default empty tags
     */
    readonly tags?: {
        [key: string]: string;
    };
    /**
     * The target table of the ruleset
     * @attribute
     */
    readonly targetTable: DataQualityTargetTable;
    /**
     * Policy to apply when the ruleset is removed from the stack.
     *
     * @default - resource will be destroyed
     */
    readonly removalPolicy?: RemovalPolicy;
}
/**
 * A Glue Data Quality ruleset.
 */
export declare class DataQualityRuleset extends Resource implements IDataQualityRuleset {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    static fromRulesetArn(scope: constructs.Construct, id: string, rulesetArn: string): IDataQualityRuleset;
    static fromRulesetName(scope: constructs.Construct, id: string, rulesetName: string): IDataQualityRuleset;
    private static buildRulesetArn;
    private resource;
    constructor(scope: constructs.Construct, id: string, props: DataQualityRulesetProps);
    /**
     * Name of this ruleset.
     */
    get rulesetName(): string;
    /**
     * ARN of this ruleset.
     */
    get rulesetArn(): string;
}
