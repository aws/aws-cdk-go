import type * as cdk from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import type { Code } from '../code';
import type { SparkJobProps } from './spark-job';
import { SparkJob } from './spark-job';
/**
 * Properties for creating a Scala Spark ETL job
 */
export interface ScalaSparkEtlJobProps extends SparkJobProps {
    /**
     * Class name (required for Scala scripts)
     * Package and class name for the entry point of Glue job execution for
     * Java scripts
     **/
    readonly className: string;
    /**
     * Specifies configuration properties of a notification (optional).
     * After a job run starts, the number of minutes to wait before sending a job run delay notification.
     * @default - undefined
     */
    readonly notifyDelayAfter?: cdk.Duration;
    /**
     * Additional files, such as configuration files that AWS Glue copies to the working directory of your script before executing it.
     *
     * @default - no extra files specified.
     *
     * @see https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-glue-arguments.html
     */
    readonly extraFiles?: Code[];
    /**
     * Extra Jars S3 URL (optional)
     * S3 URL where additional jar dependencies are located
     * @default - no extra jar files
     */
    readonly extraJars?: Code[];
    /**
     * Setting this value to true prioritizes the customer's extra JAR files in the classpath.
     *
     * @default false - priority is not given to user-provided jars
     *
     * @see `--user-jars-first` in https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-glue-arguments.html
     */
    readonly extraJarsFirst?: boolean;
    /**
     * Specifies whether job run queuing is enabled for the job runs for this job.
     * A value of true means job run queuing is enabled for the job runs.
     * If false or not populated, the job runs will not be considered for queueing.
     * If this field does not match the value set in the job run, then the value from
     * the job run field will be used. This property must be set to false for flex jobs.
     * If this property is enabled, maxRetries must be set to zero.
     *
     * @default - no job run queuing
     */
    readonly jobRunQueuingEnabled?: boolean;
}
/**
 * Spark ETL Jobs class
 *
 * ETL jobs support pySpark and Scala languages, for which there are separate
 * but similar constructors. ETL jobs default to the G1 worker type, but you
 * can override this default with other supported worker type values
 * (G1, G2, G4 and G8). ETL jobs defaults to Glue version 4.0, which you can
 * override to 3.0. The following ETL features are enabled by default:
 * --enable-metrics, --enable-continuous-cloudwatch-log. The Spark UI
 * (--enable-spark-ui) is off by default; enable it by setting the `sparkUI` prop.
 * You can find more details about version, worker type and other features
 * in Glue's public documentation.
 */
export declare class ScalaSparkEtlJob extends SparkJob {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    private resource;
    /**
     * ScalaSparkEtlJob constructor
     */
    constructor(scope: Construct, id: string, props: ScalaSparkEtlJobProps);
    get jobArn(): string;
    get jobName(): string;
    /**
     * Set the executable arguments with best practices enabled by default
     *
     * @returns An array of arguments for Glue to use on execution
     */
    private executableArguments;
}
