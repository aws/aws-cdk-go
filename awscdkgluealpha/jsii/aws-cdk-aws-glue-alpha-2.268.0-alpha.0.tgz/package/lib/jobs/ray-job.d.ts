import type * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import type { JobProps } from './job';
import { Job } from './job';
import { Runtime } from '../constants';
/**
 * Properties for creating a Ray Glue job
 *
 * @deprecated AWS Glue for Ray is closed to new customers as of April 30, 2026.
 * Migrate to Amazon EKS with KubeRay Operator. See
 * https://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html
 */
export interface RayJobProps extends JobProps {
    /**
     * Sets the Ray runtime environment version
     *
     * @default - Runtime version will default to Ray2.4
     */
    readonly runtime?: Runtime;
    /**
     * The number of workers allocated when a job runs.
     *
     * Ray jobs only support the Z.2X worker type, so the worker type is not configurable.
     *
     * @default 3
     */
    readonly numberOfWorkers?: number;
    /**
     * Specifies whether job run queuing is enabled for the job runs for this job.
     * A value of true means job run queuing is enabled for the job runs.
     * If false or not populated, the job runs will not be considered for queueing.
     * If this field does not match the value set in the job run, then the value from
     * the job run field will be used. This property must be set to false for flex jobs.
     * If this property is enabled, maxRetries must be set to zero.
     *
     * @default - no job run queuing
     */
    readonly jobRunQueuingEnabled?: boolean;
    /**
     * Enable profiling metrics for the Glue job.
     *
     * When enabled, adds '--enable-metrics' to job arguments.
     *
     * @default true
     */
    readonly enableMetrics?: boolean;
    /**
     * Enable observability metrics for the Glue job.
     *
     * When enabled, adds '--enable-observability-metrics': 'true' to job arguments.
     *
     * @default true
     */
    readonly enableObservabilityMetrics?: boolean;
}
/**
 * Ray Jobs class
 *
 * Glue Ray jobs use worker type Z.2X and Glue version 4.0.
 * These are not overrideable since these are the only configuration that
 * Glue Ray jobs currently support. The runtime defaults to Ray2.4 and min
 * workers defaults to 3.
 *
 * @deprecated AWS Glue for Ray is closed to new customers as of April 30, 2026.
 * Migrate to Amazon EKS with KubeRay Operator. See
 * https://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html
 */
export declare class RayJob extends Job {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    readonly role: iam.IRole;
    readonly grantPrincipal: iam.IPrincipal;
    private resource;
    /**
     * RayJob constructor
     */
    constructor(scope: Construct, id: string, props: RayJobProps);
    get jobArn(): string;
    get jobName(): string;
}
