/**
 * Partition projection type.
 *
 * Determines how Athena projects partition values.
 *
 * @see https://docs.aws.amazon.com/athena/latest/ug/partition-projection-supported-types.html
 */
export declare enum PartitionProjectionType {
    /**
     * Project partition values as integers within a range.
     */
    INTEGER = "integer",
    /**
     * Project partition values as dates within a range.
     */
    DATE = "date",
    /**
     * Project partition values from an explicit list of values.
     */
    ENUM = "enum",
    /**
     * Project partition values that are injected at query time.
     */
    INJECTED = "injected"
}
/**
 * Date interval unit for partition projection.
 *
 * @see https://docs.aws.amazon.com/athena/latest/ug/partition-projection-supported-types.html#partition-projection-date-type
 */
export declare enum DateIntervalUnit {
    /**
     * Year interval.
     */
    YEARS = "YEARS",
    /**
     * Month interval.
     */
    MONTHS = "MONTHS",
    /**
     * Week interval.
     */
    WEEKS = "WEEKS",
    /**
     * Day interval (default).
     */
    DAYS = "DAYS",
    /**
     * Hour interval.
     */
    HOURS = "HOURS",
    /**
     * Minute interval.
     */
    MINUTES = "MINUTES",
    /**
     * Second interval.
     */
    SECONDS = "SECONDS"
}
/**
 * Properties for INTEGER partition projection configuration.
 */
export interface IntegerPartitionProjectionConfigurationProps {
    /**
     * Minimum value for the integer partition range (inclusive).
     */
    readonly min: number;
    /**
     * Maximum value for the integer partition range (inclusive).
     */
    readonly max: number;
    /**
     * Interval between partition values.
     *
     * @default 1
     */
    readonly interval?: number;
    /**
     * Number of digits to pad the partition value with leading zeros.
     *
     * With digits: 4, partition values: 0001, 0002, ..., 0100
     *
     * @default - no static number of digits and no leading zeroes
     */
    readonly digits?: number;
}
/**
 * Properties for DATE partition projection configuration.
 */
export interface DatePartitionProjectionConfigurationProps {
    /**
     * Start date for the partition range (inclusive).
     *
     * Can be either:
     * - Fixed date in the format specified by `format` property
     *   (e.g., '2020-01-01' for format 'yyyy-MM-dd')
     * - Relative date using NOW syntax
     *   (e.g., 'NOW', 'NOW-3YEARS', 'NOW+1MONTH')
     *
     * @see https://docs.aws.amazon.com/athena/latest/ug/partition-projection-supported-types.html#partition-projection-date-type
     */
    readonly min: string;
    /**
     * End date for the partition range (inclusive).
     *
     * Can be either:
     * - Fixed date in the format specified by `format` property
     * - Relative date using NOW syntax
     *
     * Same format constraints as `min`.
     */
    readonly max: string;
    /**
     * Date format for partition values.
     *
     * Uses Java SimpleDateFormat patterns.
     *
     * @see https://docs.oracle.com/javase/8/docs/api/java/text/SimpleDateFormat.html
     */
    readonly format: string;
    /**
     * Interval between partition values.
     *
     * Required (together with `intervalUnit`) when `format` carries sub-day
     * precision — i.e. a field finer than a day, such as hours or AM/PM. At day
     * or coarser precision Athena defaults the step, so it is optional.
     *
     * @default - Athena's default step for the format's precision; required when `format` is sub-day precision
     */
    readonly interval?: number;
    /**
     * Unit for the interval.
     *
     * Required (together with `interval`) when `format` carries sub-day
     * precision — i.e. a field finer than a day, such as hours or AM/PM. At day
     * or coarser precision Athena defaults the step, so it is optional.
     *
     * @default - Athena's default unit for the format's precision; required when `format` is sub-day precision
     */
    readonly intervalUnit?: DateIntervalUnit;
}
/**
 * Properties for ENUM partition projection configuration.
 */
export interface EnumPartitionProjectionConfigurationProps {
    /**
     * Explicit list of partition values.
     *
     * @example ['us-east-1', 'us-west-2', 'eu-west-1']
     */
    readonly values: string[];
}
/**
 * Factory class for creating partition projection configurations.
 */
export declare class PartitionProjectionConfiguration {
    /**
     * Create an INTEGER partition projection configuration.
     */
    static integer(props: IntegerPartitionProjectionConfigurationProps): PartitionProjectionConfiguration;
    /**
     * Create a DATE partition projection configuration.
     */
    static date(props: DatePartitionProjectionConfigurationProps): PartitionProjectionConfiguration;
    /**
     * Create an ENUM partition projection configuration.
     */
    static enum(props: EnumPartitionProjectionConfigurationProps): PartitionProjectionConfiguration;
    /**
     * Create an INJECTED partition projection configuration.
     *
     * Partition values are injected at query time through the query statement.
     *
     * @see https://docs.aws.amazon.com/athena/latest/ug/partition-projection-supported-types.html#partition-projection-injected-type
     */
    static injected(): PartitionProjectionConfiguration;
    /**
     * The type of partition projection.
     */
    readonly type: PartitionProjectionType;
    /**
     * Range of partition values for INTEGER type.
     *
     * Array of [min, max] as numbers.
     */
    readonly integerRange?: number[];
    /**
     * Range of partition values for DATE type.
     *
     * Array of [start, end] as date strings.
     */
    readonly dateRange?: string[];
    /**
     * Interval between partition values.
     */
    readonly interval?: number;
    /**
     * Number of digits to pad INTEGER partition values.
     */
    readonly digits?: number;
    /**
     * Date format for DATE partition values (Java SimpleDateFormat).
     */
    readonly format?: string;
    /**
     * Unit for DATE partition interval.
     */
    readonly intervalUnit?: DateIntervalUnit;
    /**
     * Explicit list of values for ENUM partitions.
     */
    readonly values?: string[];
    private constructor();
    /**
     * Renders CloudFormation parameters for this partition projection configuration.
     *
     * @param columnName - The partition column name
     * @internal
     */
    _renderParameters(columnName: string): {
        [key: string]: string;
    };
}
/**
 * Partition projection configuration for a table.
 *
 * Maps partition column names to their projection configurations.
 * The key is the partition column name, the value is the partition configuration.
 */
export type PartitionProjection = {
    [columnName: string]: PartitionProjectionConfiguration;
};
/**
 * Generates CloudFormation parameters for partition projection configuration.
 *
 * @param columnName - The partition column name
 * @param config - The partition configuration
 * @returns CloudFormation parameters
 */
export declare function generatePartitionProjectionParameters(columnName: string, config: PartitionProjectionConfiguration): {
    [key: string]: string;
};
