import type * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import type { JobProps } from './job';
import { Job } from './job';
import type { Code } from '../code';
import { PythonVersion, MaxCapacity, LibrarySet } from '../constants';
/**
 * Properties for creating a Python Shell job
 */
export interface PythonShellJobProps extends JobProps {
    /**
     * The version of Python to use to execute this job.
     *
     * Python shell jobs only support `PythonVersion.THREE_NINE`. The older `PythonVersion.TWO`
     * (Python 2.7) and `PythonVersion.THREE` (Python 3.6) runtimes have been retired by AWS Glue
     * and are no longer available for Python shell jobs.
     *
     * @default PythonVersion.THREE_NINE
     **/
    readonly pythonVersion?: PythonVersion;
    /**
     * The total number of DPU to assign to the Python Job
     *
     * @default 0.0625
     */
    readonly maxCapacity?: MaxCapacity;
    /**
     * The set of pre-installed Python libraries to make available to the job.
     *
     * Only applies to jobs running Python 3.9. Set to `LibrarySet.NONE` when your libraries are
     * custom or conflict with the pre-installed ones.
     *
     * @default LibrarySet.ANALYTICS when running Python 3.9, otherwise no library set is configured
     *
     * @see https://docs.aws.amazon.com/glue/latest/dg/add-job-python.html#python-shell-supported-library
     */
    readonly librarySet?: LibrarySet;
    /**
     * Additional Python files that AWS Glue adds to the Python path before executing your script.
     * Only individual files are supported, directories are not supported.
     * Equivalent to the `--extra-py-files` job argument.
     *
     * @default - no extra Python files
     *
     * @see https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-glue-arguments.html
     */
    readonly extraPythonFiles?: Code[];
    /**
     * Specifies whether job run queuing is enabled for the job runs for this job.
     * A value of true means job run queuing is enabled for the job runs.
     * If false or not populated, the job runs will not be considered for queueing.
     * If this field does not match the value set in the job run, then the value from
     * the job run field will be used. This property must be set to false for flex jobs.
     * If this property is enabled, maxRetries must be set to zero.
     *
     * @default false
     */
    readonly jobRunQueuingEnabled?: boolean;
}
/**
 * Python Shell Jobs class
 *
 * A Python shell job runs Python scripts as a shell and supports a Python version that
 * depends on the AWS Glue version you are using.
 * This can be used to schedule and run tasks that don't require an Apache Spark environment.
 */
export declare class PythonShellJob extends Job {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    readonly role: iam.IRole;
    readonly grantPrincipal: iam.IPrincipal;
    private resource;
    /**
     * PythonShellJob constructor
     */
    constructor(scope: Construct, id: string, props: PythonShellJobProps);
    get jobArn(): string;
    get jobName(): string;
    /**
     * Register the executable arguments with best practices enabled by default.
     */
    private executableArguments;
}
