import type * as ec2 from 'aws-cdk-lib/aws-ec2';
import type { ISecretRef } from 'aws-cdk-lib/aws-secretsmanager';
import * as cdk from 'aws-cdk-lib/core';
import type * as constructs from 'constructs';
/**
 * The type of the glue connection
 *
 * If you need to use a connection type that doesn't exist as a static member, you
 * can instantiate a `ConnectionType` object, e.g: `new ConnectionType('NEW_TYPE')`.
 *
 * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-glue-connection-connectioninput.html#cfn-glue-connection-connectioninput-connectiontype
 */
export declare class ConnectionType {
    /**
     * Designates a connection to a database through Java Database Connectivity (JDBC).
     */
    static readonly JDBC: ConnectionType;
    /**
     * Designates a connection to an Apache Kafka streaming platform.
     */
    static readonly KAFKA: ConnectionType;
    /**
     * Designates a connection to a MongoDB document database.
     */
    static readonly MONGODB: ConnectionType;
    /**
     * Designates a connection used for view validation by Amazon Redshift.
     */
    static readonly VIEW_VALIDATION_REDSHIFT: ConnectionType;
    /**
     * Designates a connection used for view validation by Amazon Athena.
     */
    static readonly VIEW_VALIDATION_ATHENA: ConnectionType;
    /**
     * Designates a network connection to a data source within an Amazon Virtual Private Cloud environment (Amazon VPC).
     */
    static readonly NETWORK: ConnectionType;
    /**
     * Uses configuration settings contained in a connector purchased from AWS Marketplace
     * to read from and write to data stores that are not natively supported by AWS Glue.
     */
    static readonly MARKETPLACE: ConnectionType;
    /**
     * Uses configuration settings contained in a custom connector to read from and write to data stores
     * that are not natively supported by AWS Glue.
     */
    static readonly CUSTOM: ConnectionType;
    /**
     * Designates a connection to Facebook Ads.
     */
    static readonly FACEBOOKADS: ConnectionType;
    /**
     * Designates a connection to Google Ads.
     */
    static readonly GOOGLEADS: ConnectionType;
    /**
     * Designates a connection to Google Sheets.
     */
    static readonly GOOGLESHEETS: ConnectionType;
    /**
     * Designates a connection to Google Analytics 4.
     */
    static readonly GOOGLEANALYTICS4: ConnectionType;
    /**
     * Designates a connection to HubSpot.
     */
    static readonly HUBSPOT: ConnectionType;
    /**
     * Designates a connection to Instagram Ads.
     */
    static readonly INSTAGRAMADS: ConnectionType;
    /**
     * Designates a connection to Intercom.
     */
    static readonly INTERCOM: ConnectionType;
    /**
     * Designates a connection to Jira Cloud.
     */
    static readonly JIRACLOUD: ConnectionType;
    /**
     * Designates a connection to Adobe Marketo Engage.
     */
    static readonly MARKETO: ConnectionType;
    /**
     * Designates a connection to Oracle NetSuite.
     */
    static readonly NETSUITEERP: ConnectionType;
    /**
     * Designates a connection to Salesforce using OAuth authentication.
     */
    static readonly SALESFORCE: ConnectionType;
    /**
     * Designates a connection to Salesforce Marketing Cloud.
     */
    static readonly SALESFORCEMARKETINGCLOUD: ConnectionType;
    /**
     * Designates a connection to Salesforce Marketing Cloud Account Engagement (MCAE).
     */
    static readonly SALESFORCEPARDOT: ConnectionType;
    /**
     * Designates a connection to SAP OData.
     */
    static readonly SAPODATA: ConnectionType;
    /**
     * Designates a connection to ServiceNow.
     */
    static readonly SERVICENOW: ConnectionType;
    /**
     * Designates a connection to Slack.
     */
    static readonly SLACK: ConnectionType;
    /**
     * Designates a connection to Snapchat Ads.
     */
    static readonly SNAPCHATADS: ConnectionType;
    /**
     * Designates a connection to Stripe.
     */
    static readonly STRIPE: ConnectionType;
    /**
     * Designates a connection to Zendesk.
     */
    static readonly ZENDESK: ConnectionType;
    /**
     * Designates a connection to Zoho CRM.
     */
    static readonly ZOHOCRM: ConnectionType;
    /**
     * Designates a connection to Google BigQuery.
     */
    static readonly BIGQUERY: ConnectionType;
    /**
     * Designates a connection to Azure SQL Database.
     */
    static readonly AZURESQL: ConnectionType;
    /**
     * Designates a connection to Azure Cosmos DB.
     */
    static readonly AZURECOSMOS: ConnectionType;
    /**
     * Designates a connection to Amazon OpenSearch Service.
     */
    static readonly OPENSEARCH: ConnectionType;
    /**
     * Designates a connection to MySQL.
     */
    static readonly MYSQL: ConnectionType;
    /**
     * Designates a connection to PostgreSQL.
     */
    static readonly POSTGRESQL: ConnectionType;
    /**
     * Designates a connection to Oracle Database.
     */
    static readonly ORACLE: ConnectionType;
    /**
     * Designates a connection to Microsoft SQL Server.
     */
    static readonly SQLSERVER: ConnectionType;
    /**
     * Designates a connection to SAP HANA.
     */
    static readonly SAPHANA: ConnectionType;
    /**
     * Designates a connection to Teradata.
     */
    static readonly TERADATA: ConnectionType;
    /**
     * Designates a connection to Vertica.
     */
    static readonly VERTICA: ConnectionType;
    /**
     * Designates a connection to Amazon DynamoDB.
     */
    static readonly DYNAMODB: ConnectionType;
    /**
     * The name of this ConnectionType, as expected by Connection resource.
     */
    readonly name: string;
    constructor(name: string);
    /**
     * The connection type name as expected by Connection resource.
     */
    toString(): string;
}
/**
 * Interface representing a created or an imported `Connection`
 */
export interface IConnection extends cdk.IResource {
    /**
     * The name of the connection
     * @attribute
     */
    readonly connectionName: string;
    /**
     * The ARN of the connection
     * @attribute
     */
    readonly connectionArn: string;
}
/**
 * VPC network placement for a Glue `Connection`.
 *
 * A Glue connection targets a single subnet. Choose the placement with one of
 * the mutually-exclusive factories — an explicit subnet, or a VPC to select one
 * from — so a subnet paired with a VPC, or a subnet selection without a VPC,
 * cannot be expressed.
 */
export declare class ConnectionNetwork {
    /**
     * Pin the connection to a specific subnet.
     *
     * @param subnet the subnet the connection targets.
     */
    static subnet(subnet: ec2.ISubnet): ConnectionNetwork;
    /**
     * Select the connection's subnet from a VPC. Since a Glue connection targets
     * a single subnet, the first subnet of the selection is used.
     *
     * @param vpc the VPC to select a subnet from.
     * @param vpcSubnets which subnets to select from.
     * @default vpcSubnets - private subnets
     */
    static vpc(vpc: ec2.IVpc, vpcSubnets?: ec2.SubnetSelection): ConnectionNetwork;
    /** @internal */
    readonly _subnet?: ec2.ISubnet;
    /** @internal */
    readonly _vpc?: ec2.IVpc;
    /** @internal */
    readonly _vpcSubnets?: ec2.SubnetSelection;
    private constructor();
    /**
     * Resolve the single subnet this network targets.
     *
     * @internal
     */
    _resolveSubnet(scope: constructs.Construct): ec2.ISubnet | undefined;
}
/**
 * Base Connection Options
 */
export interface ConnectionOptions {
    /**
     * The name of the connection
     * @default cloudformation generated name
     */
    readonly connectionName?: string;
    /**
     * The description of the connection.
     * @default no description
     */
    readonly description?: string;
    /**
     *  Key-Value pairs that define parameters for the connection.
     *  @default empty properties
     *  @see https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-connect.html
     */
    readonly properties?: {
        [key: string]: string;
    };
    /**
     * A reference to a Secrets Manager secret holding the credentials for this connection.
     *
     * The secret is referenced through the connection's `SECRET_ID` property, so
     * Glue reads the credentials at runtime and the secret value never appears in
     * the synthesized template. Prefer this over placing credentials directly in
     * `properties`. Accepts any `secretsmanager.ISecret`.
     *
     * @default - no secret; any credentials must be supplied via `properties`
     */
    readonly secret?: ISecretRef;
    /**
     * A list of criteria that can be used in selecting this connection.
     * This is useful for filtering the results of https://awscli.amazonaws.com/v2/documentation/api/latest/reference/glue/get-connections.html
     * @default no match criteria
     */
    readonly matchCriteria?: string[];
    /**
     * The list of security groups needed to successfully make this connection e.g. to successfully connect to VPC.
     * @default no security group
     */
    readonly securityGroups?: ec2.ISecurityGroup[];
    /**
     * The VPC network placement for this connection, so it can reach resources
     * inside a VPC. See more at https://docs.aws.amazon.com/glue/latest/dg/start-connecting.html.
     *
     * Build it with `ConnectionNetwork.subnet(subnet)` to pin a specific subnet,
     * or `ConnectionNetwork.vpc(vpc, vpcSubnets?)` to let the CDK select one.
     *
     * @default - no VPC network placement
     */
    readonly network?: ConnectionNetwork;
}
/**
 * Construction properties for `Connection`
 */
export interface ConnectionProps extends ConnectionOptions {
    /**
     * The type of the connection
     */
    readonly type: ConnectionType;
}
/**
 * An AWS Glue connection to a data source.
 */
export declare class Connection extends cdk.Resource implements IConnection {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Creates a Connection construct that represents an external connection.
     *
     * @param scope The scope creating construct (usually `this`).
     * @param id The construct's id.
     * @param connectionArn arn of external connection.
     */
    static fromConnectionArn(scope: constructs.Construct, id: string, connectionArn: string): IConnection;
    /**
     * Creates a Connection construct that represents an external connection.
     *
     * @param scope The scope creating construct (usually `this`).
     * @param id The construct's id.
     * @param connectionName name of external connection.
     */
    static fromConnectionName(scope: constructs.Construct, id: string, connectionName: string): IConnection;
    private static buildConnectionArn;
    private readonly properties;
    private readonly resource;
    constructor(scope: constructs.Construct, id: string, props: ConnectionProps);
    /**
     * The name of the connection
     */
    get connectionName(): string;
    /**
     * The ARN of the connection
     */
    get connectionArn(): string;
    /**
     * Add additional connection parameters
     * @param key parameter key
     * @param value parameter value
     */
    addProperty(key: string, value: string): void;
}
