const VALIDATORS = { _aws_cdk_aws_sagemaker_alpha_EndpointConfigProps: function _aws_cdk_aws_sagemaker_alpha_EndpointConfigProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.instanceProductionVariants != null)
                for (const o of p.instanceProductionVariants)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_sagemaker_alpha_InstanceProductionVariantProps(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_sagemaker_alpha_ModelAttributes: function _aws_cdk_aws_sagemaker_alpha_ModelAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_sagemaker_alpha_ModelProps: function _aws_cdk_aws_sagemaker_alpha_ModelProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.containers != null)
                for (const o of p.containers)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_sagemaker_alpha_ContainerDefinition(o);
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
