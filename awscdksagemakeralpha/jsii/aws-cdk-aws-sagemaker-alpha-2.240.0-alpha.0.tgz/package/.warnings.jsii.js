function _aws_cdk_aws_sagemaker_alpha_AcceleratorType(p) {
}
function _aws_cdk_aws_sagemaker_alpha_ContainerImageConfig(p) {
}
function _aws_cdk_aws_sagemaker_alpha_ContainerImage(p) {
}
function _aws_cdk_aws_sagemaker_alpha_IEndpoint(p) {
}
function _aws_cdk_aws_sagemaker_alpha_IEndpointInstanceProductionVariant(p) {
}
function _aws_cdk_aws_sagemaker_alpha_EndpointAttributes(p) {
}
function _aws_cdk_aws_sagemaker_alpha_EndpointProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.endpointConfig))
            _aws_cdk_aws_sagemaker_alpha_IEndpointConfig(p.endpointConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_sagemaker_alpha_InvocationHttpResponseCode(p) {
}
function _aws_cdk_aws_sagemaker_alpha_Endpoint(p) {
}
function _aws_cdk_aws_sagemaker_alpha_IEndpointConfig(p) {
}
function _aws_cdk_aws_sagemaker_alpha_InstanceProductionVariantProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.model))
            _aws_cdk_aws_sagemaker_alpha_IModel(p.model);
        if (!visitedObjects.has(p.acceleratorType))
            _aws_cdk_aws_sagemaker_alpha_AcceleratorType(p.acceleratorType);
        if (!visitedObjects.has(p.instanceType))
            _aws_cdk_aws_sagemaker_alpha_InstanceType(p.instanceType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_sagemaker_alpha_ServerlessProductionVariantProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.model))
            _aws_cdk_aws_sagemaker_alpha_IModel(p.model);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_sagemaker_alpha_EndpointConfigProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.instanceProductionVariants != null)
            for (const o of p.instanceProductionVariants)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_sagemaker_alpha_InstanceProductionVariantProps(o);
        if (!visitedObjects.has(p.serverlessProductionVariant))
            _aws_cdk_aws_sagemaker_alpha_ServerlessProductionVariantProps(p.serverlessProductionVariant);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_sagemaker_alpha_EndpointConfig(p) {
}
function _aws_cdk_aws_sagemaker_alpha_InstanceType(p) {
}
function _aws_cdk_aws_sagemaker_alpha_IModel(p) {
}
function _aws_cdk_aws_sagemaker_alpha_ModelAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_sagemaker_alpha_ContainerDefinition(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.image))
            _aws_cdk_aws_sagemaker_alpha_ContainerImage(p.image);
        if (!visitedObjects.has(p.modelData))
            _aws_cdk_aws_sagemaker_alpha_ModelData(p.modelData);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_sagemaker_alpha_ModelProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.containers != null)
            for (const o of p.containers)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_sagemaker_alpha_ContainerDefinition(o);
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_sagemaker_alpha_Model(p) {
}
function _aws_cdk_aws_sagemaker_alpha_ModelDataConfig(p) {
}
function _aws_cdk_aws_sagemaker_alpha_ModelData(p) {
}
function _aws_cdk_aws_sagemaker_alpha_PipelineAttributes(p) {
}
function _aws_cdk_aws_sagemaker_alpha_PipelineProps(p) {
}
function _aws_cdk_aws_sagemaker_alpha_Pipeline(p) {
}
function _aws_cdk_aws_sagemaker_alpha_ScalableInstanceCountProps(p) {
}
function _aws_cdk_aws_sagemaker_alpha_ScalableInstanceCount(p) {
}
function _aws_cdk_aws_sagemaker_alpha_InvocationsScalingProps(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_sagemaker_alpha_AcceleratorType, _aws_cdk_aws_sagemaker_alpha_ContainerImageConfig, _aws_cdk_aws_sagemaker_alpha_ContainerImage, _aws_cdk_aws_sagemaker_alpha_IEndpoint, _aws_cdk_aws_sagemaker_alpha_IEndpointInstanceProductionVariant, _aws_cdk_aws_sagemaker_alpha_EndpointAttributes, _aws_cdk_aws_sagemaker_alpha_EndpointProps, _aws_cdk_aws_sagemaker_alpha_InvocationHttpResponseCode, _aws_cdk_aws_sagemaker_alpha_Endpoint, _aws_cdk_aws_sagemaker_alpha_IEndpointConfig, _aws_cdk_aws_sagemaker_alpha_InstanceProductionVariantProps, _aws_cdk_aws_sagemaker_alpha_ServerlessProductionVariantProps, _aws_cdk_aws_sagemaker_alpha_EndpointConfigProps, _aws_cdk_aws_sagemaker_alpha_EndpointConfig, _aws_cdk_aws_sagemaker_alpha_InstanceType, _aws_cdk_aws_sagemaker_alpha_IModel, _aws_cdk_aws_sagemaker_alpha_ModelAttributes, _aws_cdk_aws_sagemaker_alpha_ContainerDefinition, _aws_cdk_aws_sagemaker_alpha_ModelProps, _aws_cdk_aws_sagemaker_alpha_Model, _aws_cdk_aws_sagemaker_alpha_ModelDataConfig, _aws_cdk_aws_sagemaker_alpha_ModelData, _aws_cdk_aws_sagemaker_alpha_PipelineAttributes, _aws_cdk_aws_sagemaker_alpha_PipelineProps, _aws_cdk_aws_sagemaker_alpha_Pipeline, _aws_cdk_aws_sagemaker_alpha_ScalableInstanceCountProps, _aws_cdk_aws_sagemaker_alpha_ScalableInstanceCount, _aws_cdk_aws_sagemaker_alpha_InvocationsScalingProps };
