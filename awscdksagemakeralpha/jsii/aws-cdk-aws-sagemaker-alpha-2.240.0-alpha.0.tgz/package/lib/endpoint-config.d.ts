import type * as kms from 'aws-cdk-lib/aws-kms';
import * as cdk from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import type { AcceleratorType } from './accelerator-type';
import { InstanceType } from './instance-type';
import type { IModel } from './model';
/**
 * The interface for a SageMaker EndpointConfig resource.
 */
export interface IEndpointConfig extends cdk.IResource {
    /**
     * The ARN of the endpoint configuration.
     *
     * @attribute
     */
    readonly endpointConfigArn: string;
    /**
     * The name of the endpoint configuration.
     *
     * @attribute
     */
    readonly endpointConfigName: string;
}
/**
 * Common construction properties for all production variant types (e.g., instance, serverless).
 */
interface ProductionVariantProps {
    /**
     * Determines initial traffic distribution among all of the models that you specify in the
     * endpoint configuration. The traffic to a production variant is determined by the ratio of the
     * variant weight to the sum of all variant weight values across all production variants.
     *
     * @default 1.0
     */
    readonly initialVariantWeight?: number;
    /**
     * The model to host.
     */
    readonly model: IModel;
    /**
     * Name of the production variant.
     */
    readonly variantName: string;
}
/**
 * Construction properties for an instance production variant.
 */
export interface InstanceProductionVariantProps extends ProductionVariantProps {
    /**
     * The size of the Elastic Inference (EI) instance to use for the production variant. EI instances
     * provide on-demand GPU computing for inference.
     *
     * @default - none
     */
    readonly acceleratorType?: AcceleratorType;
    /**
     * Number of instances to launch initially.
     *
     * @default 1
     */
    readonly initialInstanceCount?: number;
    /**
     * Instance type of the production variant.
     *
     * @default InstanceType.T2_MEDIUM
     */
    readonly instanceType?: InstanceType;
    /**
     * The timeout value, in seconds, for your inference container to pass health check.
     * Range between 60 and 3600 seconds.
     * @default - none
     */
    readonly containerStartupHealthCheckTimeout?: cdk.Duration;
}
/**
 * Construction properties for a serverless production variant.
 */
export interface ServerlessProductionVariantProps extends ProductionVariantProps {
    /**
     * The maximum number of concurrent invocations your serverless endpoint can process.
     *
     * Valid range: 1-200
     */
    readonly maxConcurrency: number;
    /**
     * The memory size of your serverless endpoint. Valid values are in 1 GB increments:
     * 1024 MB, 2048 MB, 3072 MB, 4096 MB, 5120 MB, or 6144 MB.
     */
    readonly memorySizeInMB: number;
    /**
     * The number of concurrent invocations that are provisioned and ready to respond to your endpoint.
     *
     * Valid range: 1-200, must be less than or equal to maxConcurrency.
     *
     * @default - none
     */
    readonly provisionedConcurrency?: number;
}
/**
 * Represents common attributes of all production variant types (e.g., instance, serverless) once
 * associated to an EndpointConfig.
 */
interface ProductionVariant {
    /**
     * Determines initial traffic distribution among all of the models that you specify in the
     * endpoint configuration. The traffic to a production variant is determined by the ratio of the
     * variant weight to the sum of all variant weight values across all production variants.
     */
    readonly initialVariantWeight: number;
    /**
     * The name of the model to host.
     */
    readonly modelName: string;
    /**
     * The name of the production variant.
     */
    readonly variantName: string;
}
/**
 * Represents an instance production variant that has been associated with an EndpointConfig.
 *
 * @internal
 */
export interface InstanceProductionVariant extends ProductionVariant {
    /**
     * The size of the Elastic Inference (EI) instance to use for the production variant. EI instances
     * provide on-demand GPU computing for inference.
     *
     * @default - none
     */
    readonly acceleratorType?: AcceleratorType;
    /**
     * Number of instances to launch initially.
     */
    readonly initialInstanceCount: number;
    /**
     * Instance type of the production variant.
     */
    readonly instanceType: InstanceType;
    /**
     * The timeout value, in seconds, for your inference container to pass health check.
     * Range between 60 and 3600 seconds.
     * @default - none
     */
    readonly containerStartupHealthCheckTimeoutInSeconds?: number;
}
/**
 * Construction properties for a SageMaker EndpointConfig.
 */
export interface EndpointConfigProps {
    /**
     * Name of the endpoint configuration.
     *
     * @default - AWS CloudFormation generates a unique physical ID and uses that ID for the endpoint
     * configuration's name.
     */
    readonly endpointConfigName?: string;
    /**
     * Optional KMS encryption key associated with this stream.
     *
     * @default - none
     */
    readonly encryptionKey?: kms.IKeyRef;
    /**
     * A list of instance production variants. You can always add more variants later by calling
     * `EndpointConfig#addInstanceProductionVariant`.
     *
     * Cannot be specified if `serverlessProductionVariant` is specified.
     *
     * @default - none
     */
    readonly instanceProductionVariants?: InstanceProductionVariantProps[];
    /**
     * A serverless production variant. Serverless endpoints automatically launch compute resources
     * and scale them in and out depending on traffic.
     *
     * Cannot be specified if `instanceProductionVariants` is specified.
     *
     * @default - none
     */
    readonly serverlessProductionVariant?: ServerlessProductionVariantProps;
}
/**
 * Defines a SageMaker EndpointConfig.
 */
export declare class EndpointConfig extends cdk.Resource implements IEndpointConfig {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Imports an EndpointConfig defined either outside the CDK or in a different CDK stack.
     * @param scope the Construct scope.
     * @param id the resource id.
     * @param endpointConfigArn the ARN of the endpoint configuration.
     */
    static fromEndpointConfigArn(scope: Construct, id: string, endpointConfigArn: string): IEndpointConfig;
    /**
     * Imports an EndpointConfig defined either outside the CDK or in a different CDK stack.
     * @param scope the Construct scope.
     * @param id the resource id.
     * @param endpointConfigName the name of the endpoint configuration.
     */
    static fromEndpointConfigName(scope: Construct, id: string, endpointConfigName: string): IEndpointConfig;
    private readonly resource;
    private readonly instanceProductionVariantsByName;
    private serverlessProductionVariant?;
    constructor(scope: Construct, id: string, props?: EndpointConfigProps);
    /**
     * The name of the endpoint configuration.
     */
    get endpointConfigName(): string;
    /**
     * The ARN of the endpoint configuration.
     */
    get endpointConfigArn(): string;
    /**
     * Add production variant to the endpoint configuration.
     *
     * @param props The properties of a production variant to add.
     */
    addInstanceProductionVariant(props: InstanceProductionVariantProps): void;
    /**
     * Add serverless production variant to the endpoint configuration.
     *
     * @param props The properties of a serverless production variant to add.
     */
    addServerlessProductionVariant(props: ServerlessProductionVariantProps): void;
    /**
     * Get instance production variants associated with endpoint configuration.
     *
     * @internal
     */
    get _instanceProductionVariants(): InstanceProductionVariant[];
    /**
     * Find instance production variant based on variant name
     * @param name Variant name from production variant
     *
     * @internal
     */
    _findInstanceProductionVariant(name: string): InstanceProductionVariant;
    private validateProductionVariants;
    private validateInstanceProductionVariantProps;
    private validateServerlessProductionVariantProps;
    /**
     * Render the list of production variants (instance or serverless).
     */
    private renderProductionVariants;
    /**
     * Render the list of instance production variants.
     */
    private renderInstanceProductionVariants;
    /**
     * Render the serverless production variant.
     */
    private renderServerlessProductionVariant;
}
export {};
