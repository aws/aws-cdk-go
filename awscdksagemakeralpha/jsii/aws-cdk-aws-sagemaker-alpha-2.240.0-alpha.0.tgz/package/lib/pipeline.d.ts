import { Resource } from 'aws-cdk-lib';
import { Grant } from 'aws-cdk-lib/aws-iam';
import type { IGrantable } from 'aws-cdk-lib/aws-iam';
import type { IPipeline, PipelineReference } from 'aws-cdk-lib/aws-sagemaker';
import type { Construct } from 'constructs';
/**
 * Attributes for importing a SageMaker Pipeline
 */
export interface PipelineAttributes {
    /**
     * The ARN of the pipeline
     * @default - Either this or pipelineName must be provided
     */
    readonly pipelineArn?: string;
    /**
     * The name of the pipeline
     * @default - Either this or pipelineArn must be provided
     */
    readonly pipelineName?: string;
    /**
     * The account the pipeline is in
     * @default - same account as the stack
     */
    readonly account?: string;
    /**
     * The region the pipeline is in
     * @default - same region as the stack
     */
    readonly region?: string;
}
/**
 * Properties for defining a SageMaker Pipeline
 */
export interface PipelineProps {
    /**
     * The physical name of the pipeline
     * @default - CDK generated name
     */
    readonly pipelineName?: string;
}
/**
 * A SageMaker Pipeline
 *
 * @resource AWS::SageMaker::Pipeline
 */
export declare class Pipeline extends Resource implements IPipeline {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import a pipeline from its ARN
     *
     * @param scope The parent construct
     * @param id The construct id
     * @param pipelineArn The ARN of the pipeline
     */
    static fromPipelineArn(scope: Construct, id: string, pipelineArn: string): IPipeline;
    /**
     * Import a pipeline from its name
     *
     * For this to work, the pipeline must be in the same account and region as the stack.
     *
     * @param scope The parent construct
     * @param id The construct id
     * @param pipelineName The name of the pipeline
     */
    static fromPipelineName(scope: Construct, id: string, pipelineName: string): IPipeline;
    /**
     * Import a pipeline from attributes
     *
     * @param scope The parent construct
     * @param id The construct id
     * @param attrs The attributes of the pipeline to import
     */
    static fromPipelineAttributes(scope: Construct, id: string, attrs: PipelineAttributes): IPipeline;
    /**
     * The ARN of the pipeline.
     */
    readonly pipelineArn: string;
    /**
     * The name of the pipeline.
     */
    readonly pipelineName: string;
    /**
     * A reference to this pipeline.
     */
    get pipelineRef(): PipelineReference;
    /**
     * Create a new Pipeline (not supported - use import methods instead)
     * @internal
     */
    constructor(scope: Construct, id: string, props?: PipelineProps);
    /**
     * Permits an IAM principal to start this pipeline execution
     * @param grantee The principal to grant access to
     */
    grantStartPipelineExecution(grantee: IGrantable): Grant;
}
