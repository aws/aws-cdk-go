function _aws_cdk_aws_ivs_alpha_IChannel(p) {
}
function _aws_cdk_aws_ivs_alpha_ContainerFormat(p) {
}
function _aws_cdk_aws_ivs_alpha_LatencyMode(p) {
}
function _aws_cdk_aws_ivs_alpha_ChannelType(p) {
}
function _aws_cdk_aws_ivs_alpha_Preset(p) {
}
function _aws_cdk_aws_ivs_alpha_ChannelProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.containerFormat))
            _aws_cdk_aws_ivs_alpha_ContainerFormat(p.containerFormat);
        if (!visitedObjects.has(p.latencyMode))
            _aws_cdk_aws_ivs_alpha_LatencyMode(p.latencyMode);
        if (!visitedObjects.has(p.multitrackInputConfiguration))
            _aws_cdk_aws_ivs_alpha_MultitrackInputConfiguration(p.multitrackInputConfiguration);
        if (!visitedObjects.has(p.preset))
            _aws_cdk_aws_ivs_alpha_Preset(p.preset);
        if (!visitedObjects.has(p.recordingConfiguration))
            _aws_cdk_aws_ivs_alpha_IRecordingConfiguration(p.recordingConfiguration);
        if (!visitedObjects.has(p.type))
            _aws_cdk_aws_ivs_alpha_ChannelType(p.type);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ivs_alpha_MaximumResolution(p) {
}
function _aws_cdk_aws_ivs_alpha_Policy(p) {
}
function _aws_cdk_aws_ivs_alpha_MultitrackInputConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.maximumResolution))
            _aws_cdk_aws_ivs_alpha_MaximumResolution(p.maximumResolution);
        if (!visitedObjects.has(p.policy))
            _aws_cdk_aws_ivs_alpha_Policy(p.policy);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ivs_alpha_Channel(p) {
}
function _aws_cdk_aws_ivs_alpha_IPlaybackKeyPair(p) {
}
function _aws_cdk_aws_ivs_alpha_PlaybackKeyPairProps(p) {
}
function _aws_cdk_aws_ivs_alpha_PlaybackKeyPair(p) {
}
function _aws_cdk_aws_ivs_alpha_RecordingConfigurationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.renditionConfiguration))
            _aws_cdk_aws_ivs_alpha_RenditionConfiguration(p.renditionConfiguration);
        if (!visitedObjects.has(p.thumbnailConfiguration))
            _aws_cdk_aws_ivs_alpha_ThumbnailConfiguration(p.thumbnailConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ivs_alpha_IRecordingConfiguration(p) {
}
function _aws_cdk_aws_ivs_alpha_RecordingConfiguration(p) {
}
function _aws_cdk_aws_ivs_alpha_RenditionSelection(p) {
}
function _aws_cdk_aws_ivs_alpha_RenditionConfiguration(p) {
}
function _aws_cdk_aws_ivs_alpha_IStreamKey(p) {
}
function _aws_cdk_aws_ivs_alpha_StreamKeyProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.channel))
            _aws_cdk_aws_ivs_alpha_IChannel(p.channel);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ivs_alpha_StreamKey(p) {
}
function _aws_cdk_aws_ivs_alpha_RecordingMode(p) {
}
function _aws_cdk_aws_ivs_alpha_Storage(p) {
}
function _aws_cdk_aws_ivs_alpha_ThumbnailConfiguration(p) {
}
function _aws_cdk_aws_ivs_alpha_Resolution(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_ivs_alpha_IChannel, _aws_cdk_aws_ivs_alpha_ContainerFormat, _aws_cdk_aws_ivs_alpha_LatencyMode, _aws_cdk_aws_ivs_alpha_ChannelType, _aws_cdk_aws_ivs_alpha_Preset, _aws_cdk_aws_ivs_alpha_ChannelProps, _aws_cdk_aws_ivs_alpha_MaximumResolution, _aws_cdk_aws_ivs_alpha_Policy, _aws_cdk_aws_ivs_alpha_MultitrackInputConfiguration, _aws_cdk_aws_ivs_alpha_Channel, _aws_cdk_aws_ivs_alpha_IPlaybackKeyPair, _aws_cdk_aws_ivs_alpha_PlaybackKeyPairProps, _aws_cdk_aws_ivs_alpha_PlaybackKeyPair, _aws_cdk_aws_ivs_alpha_RecordingConfigurationProps, _aws_cdk_aws_ivs_alpha_IRecordingConfiguration, _aws_cdk_aws_ivs_alpha_RecordingConfiguration, _aws_cdk_aws_ivs_alpha_RenditionSelection, _aws_cdk_aws_ivs_alpha_RenditionConfiguration, _aws_cdk_aws_ivs_alpha_IStreamKey, _aws_cdk_aws_ivs_alpha_StreamKeyProps, _aws_cdk_aws_ivs_alpha_StreamKey, _aws_cdk_aws_ivs_alpha_RecordingMode, _aws_cdk_aws_ivs_alpha_Storage, _aws_cdk_aws_ivs_alpha_ThumbnailConfiguration, _aws_cdk_aws_ivs_alpha_Resolution };
