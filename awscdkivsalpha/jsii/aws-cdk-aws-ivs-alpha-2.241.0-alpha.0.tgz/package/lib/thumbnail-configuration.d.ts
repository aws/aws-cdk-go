import { Duration } from 'aws-cdk-lib';
import type { Resolution } from './util';
/**
 * Thumbnail recording mode.
 */
export declare enum RecordingMode {
    /**
     * Use INTERVAL to enable the generation of thumbnails for recorded video at a time interval controlled by the TargetIntervalSeconds property.
     */
    INTERVAL = "INTERVAL",
    /**
     * Use DISABLED to disable the generation of thumbnails for recorded video.
     */
    DISABLED = "DISABLED"
}
/**
 * The format in which thumbnails are recorded for a stream.
 */
export declare enum Storage {
    /**
     * SEQUENTIAL records all generated thumbnails in a serial manner, to the media/thumbnails directory.
     */
    SEQUENTIAL = "SEQUENTIAL",
    /**
     * LATEST saves the latest thumbnail in media/thumbnails/latest/thumb.jpg and overwrites it at the interval specified by thumbnailTargetInterval.
     */
    LATEST = "LATEST"
}
/**
 * Thumbnail configuration for IVS Recording configuration
 */
export declare class ThumbnailConfiguration {
    readonly recordingMode?: RecordingMode | undefined;
    readonly resolution?: Resolution | undefined;
    readonly storage?: Storage[] | undefined;
    readonly targetInterval?: Duration | undefined;
    /**
     * Disable the generation of thumbnails for recorded video
     */
    static disable(): ThumbnailConfiguration;
    /**
     * Enable the generation of thumbnails for recorded video at a time interval.
     *
     * @param resolution The desired resolution of recorded thumbnails for a stream. If you do not specify this property, same resolution as Input stream is used.
     * @param storage The format in which thumbnails are recorded for a stream. If you do not specify this property, `ThumbnailStorage.SEQUENTIAL` is set.
     * @param targetInterval The targeted thumbnail-generation interval. If you do not specify this property, `Duration.seconds(60)` is set.
     */
    static interval(resolution?: Resolution, storage?: Storage[], targetInterval?: Duration): ThumbnailConfiguration;
    /**
     * @param recordingMode Thumbnail recording mode. If you do not specify this property, `ThumbnailRecordingMode.INTERVAL` is set.
     * @param resolution The desired resolution of recorded thumbnails for a stream. If you do not specify this property, same resolution as Input stream is used.
     * @param storage The format in which thumbnails are recorded for a stream. If you do not specify this property, `ThumbnailStorage.SEQUENTIAL` is set.
     * @param targetInterval The targeted thumbnail-generation interval. Must be between 1 and 60 seconds. If you do not specify this property, `Duration.seconds(60)` is set.
     */
    private constructor();
}
