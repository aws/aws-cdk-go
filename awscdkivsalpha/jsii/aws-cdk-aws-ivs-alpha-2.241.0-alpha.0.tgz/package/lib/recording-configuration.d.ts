import type { IBucketRef } from 'aws-cdk-lib/aws-s3';
import type { IResource } from 'aws-cdk-lib/core';
import { Duration, Resource } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import type { RenditionConfiguration } from './rendition-configuration';
import type { ThumbnailConfiguration } from './thumbnail-configuration';
/**
 * Properties of the IVS Recording configuration
 */
export interface RecordingConfigurationProps {
    /**
     * S3 bucket where recorded videos will be stored.
     */
    readonly bucket: IBucketRef;
    /**
     * The name of the Recording configuration.
     * The value does not need to be unique.
     *
     * @default - auto generate
     */
    readonly recordingConfigurationName?: string;
    /**
     * If a broadcast disconnects and then reconnects within the specified interval,
     * the multiple streams will be considered a single broadcast and merged together.
     *
     * `recordingReconnectWindow` must be between 0 and 300 seconds
     *
     * @default - 0 seconds (means disabled)
     */
    readonly recordingReconnectWindow?: Duration;
    /**
     * A rendition configuration describes which renditions should be recorded for a stream.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivs-recordingconfiguration-renditionconfiguration.html
     *
     * @default - no rendition configuration
     */
    readonly renditionConfiguration?: RenditionConfiguration;
    /**
     * A thumbnail configuration enables/disables the recording of thumbnails for a live session and controls the interval at which thumbnails are generated for the live session.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivs-recordingconfiguration-thumbnailconfiguration.html
     *
     * @default - no thumbnail configuration
     */
    readonly thumbnailConfiguration?: ThumbnailConfiguration;
}
/**
 * Represents the IVS Recording configuration.
 */
export interface IRecordingConfiguration extends IResource {
    /**
     * The ID of the Recording configuration.
     * @attribute
     */
    readonly recordingConfigurationId: string;
    /**
     * The ARN of the Recording configuration.
     * @attribute
     */
    readonly recordingConfigurationArn: string;
}
/**
 * The IVS Recording configuration
 *
 * @resource AWS::IVS::RecordingConfiguration
 */
export declare class RecordingConfiguration extends Resource implements IRecordingConfiguration {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Imports an IVS Recording Configuration from attributes.
     */
    static fromRecordingConfigurationId(scope: Construct, id: string, recordingConfigurationId: string): IRecordingConfiguration;
    /**
     * Imports an IVS Recording Configuration from its ARN
     */
    static fromArn(scope: Construct, id: string, recordingConfigurationArn: string): IRecordingConfiguration;
    /**
     * The ID of the Recording configuration.
     * @attribute
     */
    readonly recordingConfigurationId: string;
    /**
     * The ARN of the Recording configuration.
     * @attribute
     */
    readonly recordingConfigurationArn: string;
    private readonly props;
    constructor(scope: Construct, id: string, props: RecordingConfigurationProps);
    private _renderRenditionConfiguration;
    private _renderThumbnailConfiguration;
    private validateRecordingConfigurationName;
    private validateRecordingReconnectWindowSeconds;
}
