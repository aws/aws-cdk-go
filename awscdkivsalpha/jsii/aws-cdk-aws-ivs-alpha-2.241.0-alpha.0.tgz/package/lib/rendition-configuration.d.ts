import type { Resolution } from './util';
/**
 * Rendition selection mode.
 */
export declare enum RenditionSelection {
    /**
     * Record all available renditions.
     */
    ALL = "ALL",
    /**
     * Does not record any video. This option is useful if you just want to record thumbnails.
     */
    NONE = "NONE",
    /**
     * Select a subset of video renditions to record.
     */
    CUSTOM = "CUSTOM"
}
/**
 * Rendition configuration for IVS Recording configuration
 */
export declare class RenditionConfiguration {
    readonly renditionSelection: RenditionSelection;
    readonly renditions?: Resolution[] | undefined;
    /**
     * Record all available renditions.
     */
    static all(): RenditionConfiguration;
    /**
     * Does not record any video.
     */
    static none(): RenditionConfiguration;
    /**
     * Record a subset of video renditions.
     *
     * @param renditions A list of which renditions are recorded for a stream.
     */
    static custom(renditions: Resolution[]): RenditionConfiguration;
    /**
     * @param renditionSelection The set of renditions are recorded for a stream.
     * @param renditions A list of which renditions are recorded for a stream. If you do not specify this property, no resolution is selected.
     */
    private constructor();
}
