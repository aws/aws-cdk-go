function _aws_cdk_aws_ec2_alpha_SecondaryAddressProps(p) {
}
function _aws_cdk_aws_ec2_alpha_Ipv6PoolSecondaryAddressProps(p) {
}
function _aws_cdk_aws_ec2_alpha_IpAddresses(p) {
}
function _aws_cdk_aws_ec2_alpha_VpcCidrOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.dependencies != null)
            for (const o of p.dependencies)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnResource(o);
        if (!visitedObjects.has(p.ipv4IpamPool))
            _aws_cdk_aws_ec2_alpha_IIpamPool(p.ipv4IpamPool);
        if (!visitedObjects.has(p.ipv6IpamPool))
            _aws_cdk_aws_ec2_alpha_IIpamPool(p.ipv6IpamPool);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_IIpAddresses(p) {
}
function _aws_cdk_aws_ec2_alpha_VpcV2Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.primaryAddressBlock))
            _aws_cdk_aws_ec2_alpha_IIpAddresses(p.primaryAddressBlock);
        if (p.secondaryAddressBlocks != null)
            for (const o of p.secondaryAddressBlocks)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_ec2_alpha_IIpAddresses(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_VpcV2Attributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.secondaryCidrBlocks != null)
            for (const o of p.secondaryCidrBlocks)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_ec2_alpha_VPCCidrBlockattributes(o);
        if (p.subnets != null)
            for (const o of p.subnets)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_ec2_alpha_SubnetV2Attributes(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_VpcV2(p) {
}
function _aws_cdk_aws_ec2_alpha_IVPCCidrBlock(p) {
}
function _aws_cdk_aws_ec2_alpha_VPCCidrBlockattributes(p) {
}
function _aws_cdk_aws_ec2_alpha_AddressFamily(p) {
}
function _aws_cdk_aws_ec2_alpha_IpamPoolPublicIpSource(p) {
}
function _aws_cdk_aws_ec2_alpha_AwsServiceName(p) {
}
function _aws_cdk_aws_ec2_alpha_IpamProps(p) {
}
function _aws_cdk_aws_ec2_alpha_IpamScopeType(p) {
}
function _aws_cdk_aws_ec2_alpha_PoolOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.addressFamily))
            _aws_cdk_aws_ec2_alpha_AddressFamily(p.addressFamily);
        if (!visitedObjects.has(p.awsService))
            _aws_cdk_aws_ec2_alpha_AwsServiceName(p.awsService);
        if (!visitedObjects.has(p.publicIpSource))
            _aws_cdk_aws_ec2_alpha_IpamPoolPublicIpSource(p.publicIpSource);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_IpamPoolCidrProvisioningOptions(p) {
}
function _aws_cdk_aws_ec2_alpha_IIpamPool(p) {
}
function _aws_cdk_aws_ec2_alpha_IpamScopeOptions(p) {
}
function _aws_cdk_aws_ec2_alpha_IpamOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.ipamPool))
            _aws_cdk_aws_ec2_alpha_IIpamPool(p.ipamPool);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_IIpamScopeBase(p) {
}
function _aws_cdk_aws_ec2_alpha_Ipam(p) {
}
function _aws_cdk_aws_ec2_alpha_EgressOnlyInternetGatewayOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.subnets != null)
            for (const o of p.subnets)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_InternetGatewayOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.subnets != null)
            for (const o of p.subnets)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_VPNGatewayV2Options(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.vpnRoutePropagation != null)
            for (const o of p.vpnRoutePropagation)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_IVpcV2(p) {
}
function _aws_cdk_aws_ec2_alpha_VpcV2Base(p) {
}
function _aws_cdk_aws_ec2_alpha_IpCidr(p) {
}
function _aws_cdk_aws_ec2_alpha_SubnetV2Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.ipv4CidrBlock))
            _aws_cdk_aws_ec2_alpha_IpCidr(p.ipv4CidrBlock);
        if (!visitedObjects.has(p.vpc))
            _aws_cdk_aws_ec2_alpha_IVpcV2(p.vpc);
        if (!visitedObjects.has(p.ipv6CidrBlock))
            _aws_cdk_aws_ec2_alpha_IpCidr(p.ipv6CidrBlock);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_ISubnetV2(p) {
}
function _aws_cdk_aws_ec2_alpha_SubnetV2(p) {
}
function _aws_cdk_aws_ec2_alpha_SubnetV2Attributes(p) {
}
function _aws_cdk_aws_ec2_alpha_NatConnectivityType(p) {
}
function _aws_cdk_aws_ec2_alpha_IRouteTarget(p) {
}
function _aws_cdk_aws_ec2_alpha_EgressOnlyInternetGatewayProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.vpc))
            _aws_cdk_aws_ec2_alpha_IVpcV2(p.vpc);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_InternetGatewayProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.vpc))
            _aws_cdk_aws_ec2_alpha_IVpcV2(p.vpc);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_VPNGatewayV2Props(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.vpc))
            _aws_cdk_aws_ec2_alpha_IVpcV2(p.vpc);
        if (p.vpnRoutePropagation != null)
            for (const o of p.vpnRoutePropagation)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_NatGatewayOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.subnet))
            _aws_cdk_aws_ec2_alpha_ISubnetV2(p.subnet);
        if (!visitedObjects.has(p.connectivityType))
            _aws_cdk_aws_ec2_alpha_NatConnectivityType(p.connectivityType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_NatGatewayProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.vpc))
            _aws_cdk_aws_ec2_alpha_IVpcV2(p.vpc);
        if (!visitedObjects.has(p.subnet))
            _aws_cdk_aws_ec2_alpha_ISubnetV2(p.subnet);
        if (!visitedObjects.has(p.connectivityType))
            _aws_cdk_aws_ec2_alpha_NatConnectivityType(p.connectivityType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_VPCPeeringConnectionOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.acceptorVpc))
            _aws_cdk_aws_ec2_alpha_IVpcV2(p.acceptorVpc);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_VPCPeeringConnectionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.requestorVpc))
            _aws_cdk_aws_ec2_alpha_IVpcV2(p.requestorVpc);
        if (!visitedObjects.has(p.acceptorVpc))
            _aws_cdk_aws_ec2_alpha_IVpcV2(p.acceptorVpc);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_EgressOnlyInternetGateway(p) {
}
function _aws_cdk_aws_ec2_alpha_InternetGateway(p) {
}
function _aws_cdk_aws_ec2_alpha_VPNGatewayV2(p) {
}
function _aws_cdk_aws_ec2_alpha_NatGateway(p) {
}
function _aws_cdk_aws_ec2_alpha_VPCPeeringConnection(p) {
}
function _aws_cdk_aws_ec2_alpha_RouteTargetProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.gateway))
            _aws_cdk_aws_ec2_alpha_IRouteTarget(p.gateway);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_RouteTargetType(p) {
}
function _aws_cdk_aws_ec2_alpha_IRouteV2(p) {
}
function _aws_cdk_aws_ec2_alpha_RouteProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.target))
            _aws_cdk_aws_ec2_alpha_RouteTargetType(p.target);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_Route(p) {
}
function _aws_cdk_aws_ec2_alpha_RouteTableProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.vpc))
            _aws_cdk_aws_ec2_alpha_IVpcV2(p.vpc);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_RouteTable(p) {
}
function _aws_cdk_aws_ec2_alpha_ITransitGateway(p) {
}
function _aws_cdk_aws_ec2_alpha_TransitGatewayProps(p) {
}
function _aws_cdk_aws_ec2_alpha_TransitGateway(p) {
}
function _aws_cdk_aws_ec2_alpha_ITransitGatewayRoute(p) {
}
function _aws_cdk_aws_ec2_alpha_BaseTransitGatewayRouteProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.transitGatewayRouteTable))
            _aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTable(p.transitGatewayRouteTable);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_TransitGatewayRouteProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.transitGatewayAttachment))
            _aws_cdk_aws_ec2_alpha_ITransitGatewayAttachment(p.transitGatewayAttachment);
        if (!visitedObjects.has(p.transitGatewayRouteTable))
            _aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTable(p.transitGatewayRouteTable);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_TransitGatewayBlackholeRouteProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.transitGatewayRouteTable))
            _aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTable(p.transitGatewayRouteTable);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_TransitGatewayRoute(p) {
}
function _aws_cdk_aws_ec2_alpha_TransitGatewayBlackholeRoute(p) {
}
function _aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTable(p) {
}
function _aws_cdk_aws_ec2_alpha_TransitGatewayRouteTableProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.transitGateway))
            _aws_cdk_aws_ec2_alpha_ITransitGateway(p.transitGateway);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_TransitGatewayRouteTable(p) {
}
function _aws_cdk_aws_ec2_alpha_ITransitGatewayAttachment(p) {
}
function _aws_cdk_aws_ec2_alpha_ITransitGatewayVpcAttachmentOptions(p) {
}
function _aws_cdk_aws_ec2_alpha_ITransitGatewayVpcAttachment(p) {
}
function _aws_cdk_aws_ec2_alpha_TransitGatewayVpcAttachmentProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.subnets != null)
            for (const o of p.subnets)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISubnet(o);
        if (!visitedObjects.has(p.transitGateway))
            _aws_cdk_aws_ec2_alpha_ITransitGateway(p.transitGateway);
        if (!visitedObjects.has(p.vpcAttachmentOptions))
            _aws_cdk_aws_ec2_alpha_ITransitGatewayVpcAttachmentOptions(p.vpcAttachmentOptions);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_AttachVpcOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.subnets != null)
            for (const o of p.subnets)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISubnet(o);
        if (!visitedObjects.has(p.associationRouteTable))
            _aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTable(p.associationRouteTable);
        if (p.propagationRouteTables != null)
            for (const o of p.propagationRouteTables)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTable(o);
        if (!visitedObjects.has(p.vpcAttachmentOptions))
            _aws_cdk_aws_ec2_alpha_ITransitGatewayVpcAttachmentOptions(p.vpcAttachmentOptions);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_TransitGatewayVpcAttachment(p) {
}
function _aws_cdk_aws_ec2_alpha_ITransitGatewayAssociation(p) {
}
function _aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTableAssociation(p) {
}
function _aws_cdk_aws_ec2_alpha_TransitGatewayRouteTableAssociationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.transitGatewayRouteTable))
            _aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTable(p.transitGatewayRouteTable);
        if (!visitedObjects.has(p.transitGatewayVpcAttachment))
            _aws_cdk_aws_ec2_alpha_ITransitGatewayAttachment(p.transitGatewayVpcAttachment);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_TransitGatewayRouteTableAssociation(p) {
}
function _aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTablePropagation(p) {
}
function _aws_cdk_aws_ec2_alpha_TransitGatewayRouteTablePropagationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.transitGatewayRouteTable))
            _aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTable(p.transitGatewayRouteTable);
        if (!visitedObjects.has(p.transitGatewayVpcAttachment))
            _aws_cdk_aws_ec2_alpha_ITransitGatewayAttachment(p.transitGatewayVpcAttachment);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_ec2_alpha_TransitGatewayRouteTablePropagation(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_ec2_alpha_SecondaryAddressProps, _aws_cdk_aws_ec2_alpha_Ipv6PoolSecondaryAddressProps, _aws_cdk_aws_ec2_alpha_IpAddresses, _aws_cdk_aws_ec2_alpha_VpcCidrOptions, _aws_cdk_aws_ec2_alpha_IIpAddresses, _aws_cdk_aws_ec2_alpha_VpcV2Props, _aws_cdk_aws_ec2_alpha_VpcV2Attributes, _aws_cdk_aws_ec2_alpha_VpcV2, _aws_cdk_aws_ec2_alpha_IVPCCidrBlock, _aws_cdk_aws_ec2_alpha_VPCCidrBlockattributes, _aws_cdk_aws_ec2_alpha_AddressFamily, _aws_cdk_aws_ec2_alpha_IpamPoolPublicIpSource, _aws_cdk_aws_ec2_alpha_AwsServiceName, _aws_cdk_aws_ec2_alpha_IpamProps, _aws_cdk_aws_ec2_alpha_IpamScopeType, _aws_cdk_aws_ec2_alpha_PoolOptions, _aws_cdk_aws_ec2_alpha_IpamPoolCidrProvisioningOptions, _aws_cdk_aws_ec2_alpha_IIpamPool, _aws_cdk_aws_ec2_alpha_IpamScopeOptions, _aws_cdk_aws_ec2_alpha_IpamOptions, _aws_cdk_aws_ec2_alpha_IIpamScopeBase, _aws_cdk_aws_ec2_alpha_Ipam, _aws_cdk_aws_ec2_alpha_EgressOnlyInternetGatewayOptions, _aws_cdk_aws_ec2_alpha_InternetGatewayOptions, _aws_cdk_aws_ec2_alpha_VPNGatewayV2Options, _aws_cdk_aws_ec2_alpha_IVpcV2, _aws_cdk_aws_ec2_alpha_VpcV2Base, _aws_cdk_aws_ec2_alpha_IpCidr, _aws_cdk_aws_ec2_alpha_SubnetV2Props, _aws_cdk_aws_ec2_alpha_ISubnetV2, _aws_cdk_aws_ec2_alpha_SubnetV2, _aws_cdk_aws_ec2_alpha_SubnetV2Attributes, _aws_cdk_aws_ec2_alpha_NatConnectivityType, _aws_cdk_aws_ec2_alpha_IRouteTarget, _aws_cdk_aws_ec2_alpha_EgressOnlyInternetGatewayProps, _aws_cdk_aws_ec2_alpha_InternetGatewayProps, _aws_cdk_aws_ec2_alpha_VPNGatewayV2Props, _aws_cdk_aws_ec2_alpha_NatGatewayOptions, _aws_cdk_aws_ec2_alpha_NatGatewayProps, _aws_cdk_aws_ec2_alpha_VPCPeeringConnectionOptions, _aws_cdk_aws_ec2_alpha_VPCPeeringConnectionProps, _aws_cdk_aws_ec2_alpha_EgressOnlyInternetGateway, _aws_cdk_aws_ec2_alpha_InternetGateway, _aws_cdk_aws_ec2_alpha_VPNGatewayV2, _aws_cdk_aws_ec2_alpha_NatGateway, _aws_cdk_aws_ec2_alpha_VPCPeeringConnection, _aws_cdk_aws_ec2_alpha_RouteTargetProps, _aws_cdk_aws_ec2_alpha_RouteTargetType, _aws_cdk_aws_ec2_alpha_IRouteV2, _aws_cdk_aws_ec2_alpha_RouteProps, _aws_cdk_aws_ec2_alpha_Route, _aws_cdk_aws_ec2_alpha_RouteTableProps, _aws_cdk_aws_ec2_alpha_RouteTable, _aws_cdk_aws_ec2_alpha_ITransitGateway, _aws_cdk_aws_ec2_alpha_TransitGatewayProps, _aws_cdk_aws_ec2_alpha_TransitGateway, _aws_cdk_aws_ec2_alpha_ITransitGatewayRoute, _aws_cdk_aws_ec2_alpha_BaseTransitGatewayRouteProps, _aws_cdk_aws_ec2_alpha_TransitGatewayRouteProps, _aws_cdk_aws_ec2_alpha_TransitGatewayBlackholeRouteProps, _aws_cdk_aws_ec2_alpha_TransitGatewayRoute, _aws_cdk_aws_ec2_alpha_TransitGatewayBlackholeRoute, _aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTable, _aws_cdk_aws_ec2_alpha_TransitGatewayRouteTableProps, _aws_cdk_aws_ec2_alpha_TransitGatewayRouteTable, _aws_cdk_aws_ec2_alpha_ITransitGatewayAttachment, _aws_cdk_aws_ec2_alpha_ITransitGatewayVpcAttachmentOptions, _aws_cdk_aws_ec2_alpha_ITransitGatewayVpcAttachment, _aws_cdk_aws_ec2_alpha_TransitGatewayVpcAttachmentProps, _aws_cdk_aws_ec2_alpha_AttachVpcOptions, _aws_cdk_aws_ec2_alpha_TransitGatewayVpcAttachment, _aws_cdk_aws_ec2_alpha_ITransitGatewayAssociation, _aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTableAssociation, _aws_cdk_aws_ec2_alpha_TransitGatewayRouteTableAssociationProps, _aws_cdk_aws_ec2_alpha_TransitGatewayRouteTableAssociation, _aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTablePropagation, _aws_cdk_aws_ec2_alpha_TransitGatewayRouteTablePropagationProps, _aws_cdk_aws_ec2_alpha_TransitGatewayRouteTablePropagation };
