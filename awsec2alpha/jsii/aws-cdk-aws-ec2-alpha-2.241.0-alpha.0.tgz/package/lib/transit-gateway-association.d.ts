import type { IResource } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
/**
 * Represents a Transit Gateway Route Table Association.
 */
export interface ITransitGatewayAssociation extends IResource {
    /**
     * The ID of the transit gateway route table association.
     * @attribute
     */
    readonly transitGatewayAssociationId: string;
}
/**
 * A Transit Gateway Association.
 * @internal
 */
export declare abstract class TransitGatewayAssociationBase extends Resource implements ITransitGatewayAssociation {
    abstract readonly transitGatewayAssociationId: string;
}
