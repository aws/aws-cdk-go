import type { IResource } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import type { ITransitGatewayAttachment } from './transit-gateway-attachment';
import type { ITransitGatewayRouteTable } from './transit-gateway-route-table';
/**
 * Represents a Transit Gateway Route Table Propagation.
 */
export interface ITransitGatewayRouteTablePropagation extends IResource {
    /**
     * The ID of the transit gateway route table propagation.
     * @attribute
     */
    readonly transitGatewayRouteTablePropagationId: string;
}
/**
 * Common properties for a Transit Gateway Route Table Propagation.
 */
export interface TransitGatewayRouteTablePropagationProps {
    /**
     * The ID of the transit gateway route table propagation.
     */
    readonly transitGatewayVpcAttachment: ITransitGatewayAttachment;
    /**
     * The ID of the transit gateway route table propagation.
     */
    readonly transitGatewayRouteTable: ITransitGatewayRouteTable;
    /**
     * Physical name of this propagation.
     *
     * @default - Assigned by CloudFormation.
     */
    readonly transitGatewayRouteTablePropagationName?: string;
}
/**
 * Create a Transit Gateway Route Table Propagation.
 *
 * @resource AWS::EC2::TransitGatewayRouteTablePropagation
 */
export declare class TransitGatewayRouteTablePropagation extends Resource implements ITransitGatewayRouteTablePropagation {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * The ID of the transit gateway route table propagation.
     */
    readonly transitGatewayRouteTablePropagationId: string;
    constructor(scope: Construct, id: string, props: TransitGatewayRouteTablePropagationProps);
}
