import type { ISubnet, IVpc } from 'aws-cdk-lib/aws-ec2';
import type { Construct } from 'constructs';
import type { ITransitGateway } from './transit-gateway';
import type { ITransitGatewayAttachment } from './transit-gateway-attachment';
import { TransitGatewayAttachmentBase } from './transit-gateway-attachment';
import type { ITransitGatewayRouteTable } from './transit-gateway-route-table';
/**
 * Options for Transit Gateway VPC Attachment.
 */
export interface ITransitGatewayVpcAttachmentOptions {
    /**
     * Enable or disable appliance mode support.
     *
     * @default - disable (false)
     */
    readonly applianceModeSupport?: boolean;
    /**
     * Enable or disable DNS support.
     *
     * @default - disable (false)
     */
    readonly dnsSupport?: boolean;
    /**
     * Enable or disable IPv6 support.
     *
     * @default - disable (false)
     */
    readonly ipv6Support?: boolean;
    /**
     * Enables you to reference a security group across VPCs attached to a transit gateway.
     *
     * @default - disable (false)
     */
    readonly securityGroupReferencingSupport?: boolean;
}
/**
 * Represents a Transit Gateway VPC Attachment.
 */
export interface ITransitGatewayVpcAttachment extends ITransitGatewayAttachment {
    /**
     * Add additional subnets to this attachment.
     */
    addSubnets(subnets: ISubnet[]): void;
    /**
     * Remove subnets from this attachment.
     */
    removeSubnets(subnets: ISubnet[]): void;
}
/**
 * Base class for Transit Gateway VPC Attachment.
 */
interface BaseTransitGatewayVpcAttachmentProps {
    /**
     * A list of one or more subnets to place the attachment in.
     * It is recommended to specify more subnets for better availability.
     */
    readonly subnets: ISubnet[];
    /**
     * A VPC attachment(s) will get assigned to.
     */
    readonly vpc: IVpc;
    /**
     * The VPC attachment options.
     *
     * @default - All options are disabled.
     */
    readonly vpcAttachmentOptions?: ITransitGatewayVpcAttachmentOptions;
    /**
     * Physical name of this Transit Gateway VPC Attachment.
     *
     * @default - Assigned by CloudFormation.
     */
    readonly transitGatewayAttachmentName?: string;
}
/**
 * Common properties for creating a Transit Gateway VPC Attachment resource.
 */
export interface TransitGatewayVpcAttachmentProps extends BaseTransitGatewayVpcAttachmentProps {
    /**
     * The transit gateway this attachment gets assigned to.
     */
    readonly transitGateway: ITransitGateway;
}
/**
 * Options for creating an Attachment via the attachVpc() method.
 */
export interface AttachVpcOptions extends BaseTransitGatewayVpcAttachmentProps {
    /**
     * An optional route table to associate with this VPC attachment.
     *
     * @default - No associations will be created unless it is for the default route table and automatic association is enabled.
     */
    readonly associationRouteTable?: ITransitGatewayRouteTable;
    /**
     * A list of optional route tables to propagate routes to.
     *
     * @default - No propagations will be created unless it is for the default route table and automatic propagation is enabled.
     */
    readonly propagationRouteTables?: ITransitGatewayRouteTable[];
}
/**
 * Creates a Transit Gateway VPC Attachment.
 *
 * @resource AWS::EC2::TransitGatewayAttachment
 */
export declare class TransitGatewayVpcAttachment extends TransitGatewayAttachmentBase implements ITransitGatewayVpcAttachment {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    readonly transitGatewayAttachmentId: string;
    private readonly subnets;
    /**
     * The AWS CloudFormation resource representing the Transit Gateway Attachment.
     */
    private readonly _resource;
    constructor(scope: Construct, id: string, props: TransitGatewayVpcAttachmentProps);
    /**
     * Add additional subnets to this attachment.
     */
    addSubnets(subnets: ISubnet[]): void;
    /**
     * Remove additional subnets to this attachment.
     */
    removeSubnets(subnets: ISubnet[]): void;
}
export {};
