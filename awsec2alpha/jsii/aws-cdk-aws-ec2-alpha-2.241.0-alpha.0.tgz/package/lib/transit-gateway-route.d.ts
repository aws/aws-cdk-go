import { CfnTransitGatewayRoute } from 'aws-cdk-lib/aws-ec2';
import type { IResource } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import type { ITransitGatewayAttachment } from './transit-gateway-attachment';
import type { ITransitGatewayRouteTable } from './transit-gateway-route-table';
/**
 * Represents a Transit Gateway Route.
 */
export interface ITransitGatewayRoute extends IResource {
    /**
     * The destination CIDR block for this route.
     *
     * Destination Cidr cannot overlap for static routes but is allowed for propagated routes.
     * When overlapping occurs, static routes take precedence over propagated routes.
     */
    readonly destinationCidrBlock: string;
    /**
     * The transit gateway route table this route belongs to.
     */
    readonly routeTable: ITransitGatewayRouteTable;
}
/**
 * Common properties for a Transit Gateway Route.
 */
export interface BaseTransitGatewayRouteProps {
    /**
     * The destination CIDR block for this route.
     *
     * Destination Cidr cannot overlap for static routes but is allowed for propagated routes.
     * When overlapping occurs, static routes take precedence over propagated routes.
     */
    readonly destinationCidrBlock: string;
    /**
     * The transit gateway route table you want to install this route into.
     */
    readonly transitGatewayRouteTable: ITransitGatewayRouteTable;
    /**
     * Physical name of this Transit Gateway Route.
     *
     * @default - Assigned by CloudFormation.
     */
    readonly transitGatewayRouteName?: string;
}
/**
 * Common properties for a Transit Gateway Route.
 */
export interface TransitGatewayRouteProps extends BaseTransitGatewayRouteProps {
    /**
     * The transit gateway attachment to route the traffic to.
     */
    readonly transitGatewayAttachment: ITransitGatewayAttachment;
}
/**
 * Properties for a Transit Gateway Blackhole Route.
 */
export interface TransitGatewayBlackholeRouteProps extends BaseTransitGatewayRouteProps {
}
/**
 * A Transit Gateway Route.
 * @internal
 */
declare abstract class TransitGatewayRouteBase extends Resource implements ITransitGatewayRoute {
    abstract routeTable: ITransitGatewayRouteTable;
    abstract destinationCidrBlock: string;
}
/**
 * Create a Transit Gateway Active Route.
 *
 * @resource AWS::EC2::TransitGatewayRoute
 */
export declare class TransitGatewayRoute extends TransitGatewayRouteBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    readonly routeTable: ITransitGatewayRouteTable;
    readonly destinationCidrBlock: string;
    /**
     * The AWS CloudFormation resource representing the Transit Gateway Route.
     */
    readonly resource: CfnTransitGatewayRoute;
    constructor(scope: Construct, id: string, props: TransitGatewayRouteProps);
}
/**
 * Create a Transit Gateway Blackhole Route.
 *
 * @resource AWS::EC2::TransitGatewayRoute
 */
export declare class TransitGatewayBlackholeRoute extends TransitGatewayRouteBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    readonly routeTable: ITransitGatewayRouteTable;
    readonly destinationCidrBlock: string;
    constructor(scope: Construct, id: string, props: TransitGatewayBlackholeRouteProps);
}
export {};
