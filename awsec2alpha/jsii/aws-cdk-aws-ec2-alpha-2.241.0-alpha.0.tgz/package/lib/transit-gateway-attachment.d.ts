import type { IResource } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
/**
 * Represents a Transit Gateway Attachment.
 */
export interface ITransitGatewayAttachment extends IResource {
    /**
     * The ID of the transit gateway attachment.
     * @attribute
     */
    readonly transitGatewayAttachmentId: string;
}
/**
 * A Transit Gateway Attachment.
 * @internal
 */
export declare abstract class TransitGatewayAttachmentBase extends Resource implements ITransitGatewayAttachment {
    abstract readonly transitGatewayAttachmentId: string;
}
