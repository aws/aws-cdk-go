import type { IRouteTable } from 'aws-cdk-lib/aws-ec2';
import type { IResource } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import type { ITransitGateway } from './transit-gateway';
import type { ITransitGatewayAttachment } from './transit-gateway-attachment';
import type { ITransitGatewayRoute } from './transit-gateway-route';
import type { ITransitGatewayRouteTableAssociation } from './transit-gateway-route-table-association';
import type { ITransitGatewayRouteTablePropagation } from './transit-gateway-route-table-propagation';
/**
 * Represents a Transit Gateway Route Table.
 */
export interface ITransitGatewayRouteTable extends IResource, IRouteTable {
    /**
     * Add an active route to this route table.
     *
     * @returns ITransitGatewayRoute
     */
    addRoute(id: string, transitGatewayAttachment: ITransitGatewayAttachment, destinationCidr: string): ITransitGatewayRoute;
    /**
     * Add a blackhole route to this route table.
     *
     * @returns ITransitGatewayRoute
     */
    addBlackholeRoute(id: string, destinationCidr: string): ITransitGatewayRoute;
    /**
     * Associate the provided Attachments with this route table.
     *
     * @returns ITransitGatewayRouteTableAssociation
     */
    addAssociation(id: string, transitGatewayAttachment: ITransitGatewayAttachment): ITransitGatewayRouteTableAssociation;
    /**
     * Enable propagation from the provided Attachments to this route table.
     *
     * @returns ITransitGatewayRouteTablePropagation
     */
    enablePropagation(id: string, transitGatewayAttachment: ITransitGatewayAttachment): ITransitGatewayRouteTablePropagation;
}
/**
 * Common properties for creating a Transit Gateway Route Table resource.
 */
export interface TransitGatewayRouteTableProps {
    /**
     * The Transit Gateway that this route table belongs to.
     */
    readonly transitGateway: ITransitGateway;
    /**
     * Physical name of this Transit Gateway Route Table.
     *
     * @default - Assigned by CloudFormation.
     */
    readonly transitGatewayRouteTableName?: string;
}
/**
 * A Transit Gateway Route Table.
 * @internal
 */
declare abstract class TransitGatewayRouteTableBase extends Resource implements ITransitGatewayRouteTable {
    abstract readonly routeTableId: string;
    abstract readonly transitGateway: ITransitGateway;
    addRoute(id: string, transitGatewayAttachment: ITransitGatewayAttachment, destinationCidr: string): ITransitGatewayRoute;
    addBlackholeRoute(id: string, destinationCidr: string): ITransitGatewayRoute;
    addAssociation(id: string, transitGatewayAttachment: ITransitGatewayAttachment): ITransitGatewayRouteTableAssociation;
    enablePropagation(id: string, transitGatewayAttachment: ITransitGatewayAttachment): ITransitGatewayRouteTablePropagation;
}
/**
 * Creates a Transit Gateway route table.
 *
 * @resource AWS::EC2::TransitGatewayRouteTable
 */
export declare class TransitGatewayRouteTable extends TransitGatewayRouteTableBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    readonly routeTableId: string;
    /**
     * The Transit Gateway.
     */
    readonly transitGateway: ITransitGateway;
    constructor(scope: Construct, id: string, props: TransitGatewayRouteTableProps);
}
export {};
