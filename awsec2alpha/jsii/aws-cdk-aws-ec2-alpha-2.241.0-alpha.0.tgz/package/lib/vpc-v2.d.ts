import type { DefaultInstanceTenancy, ISubnet } from 'aws-cdk-lib/aws-ec2';
import { CfnVPC } from 'aws-cdk-lib/aws-ec2';
import type { CfnResource } from 'aws-cdk-lib/core';
import type { Construct, IDependable } from 'constructs';
import type { IpamOptions, IIpamPool } from './ipam';
import type { SubnetV2Attributes } from './subnet-v2';
import type { IVpcV2 } from './vpc-v2-base';
import { VpcV2Base } from './vpc-v2-base';
/**
 * Additional props needed for secondary Address
 */
export interface SecondaryAddressProps {
    /**
     * Required to set Secondary cidr block resource name
     * in order to generate unique logical id for the resource.
     */
    readonly cidrBlockName: string;
}
/**
 * Additional props needed for BYOIP IPv6 address props
 */
export interface Ipv6PoolSecondaryAddressProps extends SecondaryAddressProps {
    /**
     * ID of the IPv6 address pool from which to allocate the IPv6 CIDR block.
     * Note: BYOIP Pool ID is different from the IPAM Pool ID.
     * To onboard your IPv6 address range to your AWS account please refer to the below documentation
     * @see https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/byoip-onboard.html
     */
    readonly ipv6PoolId: string;
    /**
     * A valid IPv6 CIDR block from the IPv6 address pool onboarded to AWS using BYOIP.
     * The most specific IPv6 address range that you can bring is /48 for CIDRs that are publicly advertisable
     * and /56 for CIDRs that are not publicly advertisable.
     * @see https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-byoip.html#byoip-definitions
     */
    readonly ipv6CidrBlock: string;
}
/**
 * IpAddress options to define VPC V2
 */
export declare class IpAddresses {
    /**
     * An IPv4 CIDR Range
     */
    static ipv4(ipv4Cidr: string, props?: SecondaryAddressProps): IIpAddresses;
    /**
     * An Ipv4 Ipam Pool
     */
    static ipv4Ipam(ipv4IpamOptions: IpamOptions): IIpAddresses;
    /**
     * An Ipv6 Ipam Pool
     */
    static ipv6Ipam(ipv6IpamOptions: IpamOptions): IIpAddresses;
    /**
     * Amazon Provided Ipv6 range
     */
    static amazonProvidedIpv6(props: SecondaryAddressProps): IIpAddresses;
    /**
     * A BYOIP IPv6 address pool
     */
    static ipv6ByoipPool(props: Ipv6PoolSecondaryAddressProps): IIpAddresses;
}
/**
 * Consolidated return parameters to pass to VPC construct
 */
export interface VpcCidrOptions {
    /**
     * IPv4 CIDR Block
     *
     * @default '10.0.0.0/16'
     */
    readonly ipv4CidrBlock?: string;
    /**
     * CIDR Mask for Vpc
     *
     * @default - Only required when using IPAM Ipv4
     */
    readonly ipv4NetmaskLength?: number;
    /**
     * Ipv4 IPAM Pool
     *
     * @default - Only required when using IPAM Ipv4
     */
    readonly ipv4IpamPool?: IIpamPool;
    /**
     * CIDR Mask for Vpc
     *
     * @default - Only required when using AWS Ipam
     */
    readonly ipv6NetmaskLength?: number;
    /**
     * Ipv6 IPAM pool id for VPC range, can only be defined
     * under public scope
     *
     * @default - no pool id
     */
    readonly ipv6IpamPool?: IIpamPool;
    /**
     * Use amazon provided IP range
     *
     * @default false
     */
    readonly amazonProvided?: boolean;
    /**
     * Dependency to associate Ipv6 CIDR block
     *
     * @default - No dependency
     */
    readonly dependencies?: CfnResource[];
    /**
     * Required to set Secondary cidr block resource name
     * in order to generate unique logical id for the resource.
     *
     * @default - no name for primary addresses
     */
    readonly cidrBlockName?: string;
    /**
     * IPv4 CIDR provisioned under pool
     * Required to check for overlapping CIDRs after provisioning
     * is complete under IPAM pool
     * @default - no IPAM IPv4 CIDR range is provisioned using IPAM
     */
    readonly ipv4IpamProvisionedCidrs?: string[];
    /**
     * IPv6 CIDR block from the BOYIP IPv6 address pool.
     *
     * @default - None
     */
    readonly ipv6CidrBlock?: string;
    /**
     * ID of the BYOIP IPv6 address pool from which to allocate the IPv6 CIDR block.
     *
     * @default - None
     */
    readonly ipv6PoolId?: string;
}
/**
 * Implements ip address allocation according to the IPAdress type
 */
export interface IIpAddresses {
    /**
     * Method to define the implementation logic of
     * IP address allocation
     */
    allocateVpcCidr(): VpcCidrOptions;
}
/**
 * Properties to define VPC
 * [disable-awslint:from-method]
 */
export interface VpcV2Props {
    /** A must IPv4 CIDR block for the VPC
     * @see https://docs.aws.amazon.com/vpc/latest/userguide/vpc-cidr-blocks.html
     *
     * @default - Ipv4 CIDR Block ('10.0.0.0/16')
     */
    readonly primaryAddressBlock?: IIpAddresses;
    /**
     * The secondary CIDR blocks associated with the VPC.
     * Can be  IPv4 or IPv6, two IPv4 ranges must follow RFC#1918 convention
     * For more information, @see https://docs.aws.amazon.com/vpc/latest/userguide/vpc-cidr-blocks.html#vpc-resize}.
     *
     * @default - No secondary IP address
     */
    readonly secondaryAddressBlocks?: IIpAddresses[];
    /**
     * Indicates whether the instances launched in the VPC get DNS hostnames.
     *
     * @default true
     */
    readonly enableDnsHostnames?: boolean;
    /**
     * Indicates whether the DNS resolution is supported for the VPC.
     *
     * @default true
     */
    readonly enableDnsSupport?: boolean;
    /**
     * The default tenancy of instances launched into the VPC.
     *
     * By setting this to dedicated tenancy, instances will be launched on
     * hardware dedicated to a single AWS customer, unless specifically specified
     * at instance launch time. Please note, not all instance types are usable
     * with Dedicated tenancy.
     *
     * @default DefaultInstanceTenancy.Default (shared) tenancy
     */
    readonly defaultInstanceTenancy?: DefaultInstanceTenancy;
    /**
     * Physical name for the VPC
     *
     * @default - autogenerated by CDK
     */
    readonly vpcName?: string;
}
/**
 * Options to import a VPC created outside of CDK stack
 */
export interface VpcV2Attributes {
    /**
     * The VPC ID
     * Refers to physical Id of the resource
     */
    readonly vpcId: string;
    /**
     * Region in which imported VPC is hosted
     * required in case of cross region VPC
     * as given value will be used to set field region for imported VPC,
     * which then later can be used for establishing VPC peering connection.
     *
     * @default - constructed with stack region value
     */
    readonly region?: string;
    /**
     * The ID of the AWS account that owns the imported VPC
     * required in case of cross account VPC
     * as given value will be used to set field account for imported VPC,
     * which then later can be used for establishing VPC peering connection.
     *
     * @default - constructed with stack account value
     */
    readonly ownerAccountId?: string;
    /**
     * Primary VPC CIDR Block of the imported VPC
     * Can only be IPv4
     */
    readonly vpcCidrBlock: string;
    /**
     * A VPN Gateway is attached to the VPC
     *
     * @default - No VPN Gateway
     */
    readonly vpnGatewayId?: string;
    /**
     * Subnets associated with imported VPC
     *
     * @default - no subnets provided to be imported
     */
    readonly subnets?: SubnetV2Attributes[];
    /**
     * Import Secondary CIDR blocks associated with VPC
     *
     * @default - No secondary IP address
     */
    readonly secondaryCidrBlocks?: VPCCidrBlockattributes[];
}
/**
 * This class provides a foundation for creating and configuring a VPC with advanced features such as IPAM (IP Address Management) and IPv6 support.
 *
 * For more information, see the {@link https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib.aws_ec2.Vpc.html|AWS CDK Documentation on VPCs}.
 *
 * @resource AWS::EC2::VPC
 */
export declare class VpcV2 extends VpcV2Base {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Create a VPC from existing attributes
     */
    static fromVpcV2Attributes(scope: Construct, id: string, attrs: VpcV2Attributes): IVpcV2;
    /**
     * Identifier for this VPC
     */
    readonly vpcId: string;
    /**
     * @attribute
     */
    readonly vpcArn: string;
    /**
     * @attribute
     */
    readonly vpcCidrBlock: string;
    /**
     * The IPv6 CIDR blocks for the VPC.
     *
     * See https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-vpc.html#aws-resource-ec2-vpc-return-values
     */
    readonly ipv6CidrBlocks: string[];
    /**
     * The provider of ipv4 addresses
     */
    readonly ipAddresses: IIpAddresses;
    /**
     * The AWS CloudFormation resource representing the VPC.
     */
    readonly resource: CfnVPC;
    /**
     * Indicates if instances launched in this VPC will have public DNS hostnames.
     */
    readonly dnsHostnamesEnabled: boolean;
    /**
     * Indicates if DNS support is enabled for this VPC.
     */
    readonly dnsSupportEnabled: boolean;
    /**
     * Isolated Subnets that are part of this VPC.
     */
    readonly isolatedSubnets: ISubnet[];
    /**
     * Public Subnets that are part of this VPC.
     */
    readonly publicSubnets: ISubnet[];
    /**
     * Public Subnets that are part of this VPC.
     */
    readonly privateSubnets: ISubnet[];
    /**
     * To define dependency on internet connectivity
     */
    readonly internetConnectivityEstablished: IDependable;
    /**
     * reference to all secondary blocks attached
     */
    readonly secondaryCidrBlock?: IVPCCidrBlock[];
    /**
     * IPv4 CIDR provisioned using IPAM pool
     * Required to check for overlapping CIDRs after provisioning
     * is complete under IPAM
     */
    readonly ipv4IpamProvisionedCidrs?: string[];
    /**
     * Region for this VPC
     */
    readonly region: string;
    /**
     * Identifier of the owner for this VPC
     */
    readonly ownerAccountId: string;
    /**
     * For validation to define IPv6 subnets, set to true in case of
     * Amazon Provided IPv6 cidr range
     * if true, IPv6 addresses can be attached to the subnets.
     *
     * @default false
     */
    readonly useIpv6: boolean;
    /**
     * VpcName to be used for tagging its components
     * @attribute
     */
    readonly vpcName?: string;
    readonly ipv4CidrBlock: string;
    constructor(scope: Construct, id: string, props?: VpcV2Props);
}
/**
 * Interface to create L2 for VPC Cidr Block
 */
export interface IVPCCidrBlock {
    /**
     * Amazon Provided Ipv6
     */
    readonly amazonProvidedIpv6CidrBlock?: boolean;
    /**
     * The secondary IPv4 CIDR Block
     *
     * @default - no CIDR block provided
     */
    readonly cidrBlock?: string;
    /**
     * IPAM pool for IPv6 address type
     */
    readonly ipv6IpamPoolId?: string;
    /**
     * IPAM pool for IPv4 address type
     */
    readonly ipv4IpamPoolId?: string;
    /**
     * The IPv6 CIDR block from the specified IPv6 address pool.
     */
    readonly ipv6CidrBlock?: string;
    /**
     * The ID of the IPv6 address pool from which to allocate the IPv6 CIDR block.
     */
    readonly ipv6Pool?: string;
}
/**
 * Attributes for VPCCidrBlock used for defining a new CIDR Block
 * and also for importing an existing CIDR
 */
export interface VPCCidrBlockattributes {
    /**
     * Amazon Provided Ipv6
     *
     * @default false
     */
    readonly amazonProvidedIpv6CidrBlock?: boolean;
    /**
     * The secondary IPv4 CIDR Block
     *
     * @default - no CIDR block provided
     */
    readonly cidrBlock?: string;
    /**
     * The secondary IPv4 CIDR Block
     *
     * @default - no CIDR block provided
     */
    readonly cidrBlockName?: string;
    /**
     * Net mask length for IPv6 address type
     *
     * @default - no Net mask length configured for IPv6
     */
    readonly ipv6NetmaskLength?: number;
    /**
     * Net mask length for IPv4 address type
     *
     * @default - no Net mask length configured for IPv4
     */
    readonly ipv4NetmaskLength?: number;
    /**
     * IPAM pool for IPv6 address type
     *
     * @default - no IPAM pool Id provided for IPv6
     */
    readonly ipv6IpamPoolId?: string;
    /**
     * IPAM pool for IPv4 address type
     *
     * @default - no IPAM pool Id provided for IPv4
     */
    readonly ipv4IpamPoolId?: string;
    /**
     * IPv4 CIDR provisioned under pool
     * Required to check for overlapping CIDRs after provisioning
     * is complete under IPAM pool
     * @default - no IPAM IPv4 CIDR range is provisioned using IPAM
     */
    readonly ipv4IpamProvisionedCidrs?: string[];
    /**
     * The IPv6 CIDR block from the specified IPv6 address pool.
     *
     * @default - No IPv6 CIDR block associated with VPC.
     */
    readonly ipv6CidrBlock?: string;
    /**
     * The ID of the IPv6 address pool from which to allocate the IPv6 CIDR block.
     * Note: BYOIP Pool ID is different than IPAM Pool ID.
     *
     * @default - No BYOIP pool associated with VPC.
     */
    readonly ipv6Pool?: string;
}
