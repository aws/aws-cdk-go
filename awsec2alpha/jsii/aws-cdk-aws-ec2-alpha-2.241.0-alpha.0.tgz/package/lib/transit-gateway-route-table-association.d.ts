import type { Construct } from 'constructs';
import type { ITransitGatewayAssociation } from './transit-gateway-association';
import { TransitGatewayAssociationBase } from './transit-gateway-association';
import type { ITransitGatewayAttachment } from './transit-gateway-attachment';
import type { ITransitGatewayRouteTable } from './transit-gateway-route-table';
/**
 * Represents a Transit Gateway Route Table Association.
 */
export interface ITransitGatewayRouteTableAssociation extends ITransitGatewayAssociation {
}
/**
 * Common properties for a Transit Gateway Route Table Association.
 */
export interface TransitGatewayRouteTableAssociationProps {
    /**
     * The ID of the transit gateway route table association.
     */
    readonly transitGatewayVpcAttachment: ITransitGatewayAttachment;
    /**
     * The ID of the transit gateway route table association.
     */
    readonly transitGatewayRouteTable: ITransitGatewayRouteTable;
    /**
     * Physical name of this association.
     *
     * @default - Assigned by CloudFormation.
     */
    readonly transitGatewayRouteTableAssociationName?: string;
}
/**
 * Create a Transit Gateway Route Table Association.
 *
 * @resource AWS::EC2::TransitGatewayRouteTableAssociation
 */
export declare class TransitGatewayRouteTableAssociation extends TransitGatewayAssociationBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * The ID of the transit gateway route table association.
     */
    readonly transitGatewayAssociationId: string;
    constructor(scope: Construct, id: string, props: TransitGatewayRouteTableAssociationProps);
}
