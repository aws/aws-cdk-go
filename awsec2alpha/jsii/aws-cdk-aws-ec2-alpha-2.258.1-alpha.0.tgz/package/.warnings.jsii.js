const VALIDATORS = { _aws_cdk_aws_ec2_alpha_VpcCidrOptions: function _aws_cdk_aws_ec2_alpha_VpcCidrOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.dependencies != null)
                for (const o of p.dependencies)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnResource(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_ec2_alpha_VpcV2Props: function _aws_cdk_aws_ec2_alpha_VpcV2Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.secondaryAddressBlocks != null)
                for (const o of p.secondaryAddressBlocks)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_ec2_alpha_IIpAddresses(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_ec2_alpha_VpcV2Attributes: function _aws_cdk_aws_ec2_alpha_VpcV2Attributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.secondaryCidrBlocks != null)
                for (const o of p.secondaryCidrBlocks)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_ec2_alpha_VPCCidrBlockattributes(o);
            if (p.subnets != null)
                for (const o of p.subnets)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_ec2_alpha_SubnetV2Attributes(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_ec2_alpha_EgressOnlyInternetGatewayOptions: function _aws_cdk_aws_ec2_alpha_EgressOnlyInternetGatewayOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.subnets != null)
                for (const o of p.subnets)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_ec2_alpha_InternetGatewayOptions: function _aws_cdk_aws_ec2_alpha_InternetGatewayOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.subnets != null)
                for (const o of p.subnets)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_ec2_alpha_VPNGatewayV2Options: function _aws_cdk_aws_ec2_alpha_VPNGatewayV2Options(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.vpnRoutePropagation != null)
                for (const o of p.vpnRoutePropagation)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_ec2_alpha_VPNGatewayV2Props: function _aws_cdk_aws_ec2_alpha_VPNGatewayV2Props(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.vpnRoutePropagation != null)
                for (const o of p.vpnRoutePropagation)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_ec2_alpha_TransitGatewayVpcAttachmentProps: function _aws_cdk_aws_ec2_alpha_TransitGatewayVpcAttachmentProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.subnets != null)
                for (const o of p.subnets)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISubnet(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_ec2_alpha_AttachVpcOptions: function _aws_cdk_aws_ec2_alpha_AttachVpcOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.subnets != null)
                for (const o of p.subnets)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISubnet(o);
            if (p.propagationRouteTables != null)
                for (const o of p.propagationRouteTables)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_ec2_alpha_ITransitGatewayRouteTable(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
