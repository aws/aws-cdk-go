import { SourceWithDeadLetterTarget } from '@aws-cdk/aws-pipes-alpha';
import type { Duration } from 'aws-cdk-lib';
import type { ITopic } from 'aws-cdk-lib/aws-sns';
import type { IQueue } from 'aws-cdk-lib/aws-sqs';
import type { OnPartialBatchItemFailure } from './enums';
/**
 * Base parameters for streaming sources.
 */
export interface StreamSourceParameters {
    /**
     * The maximum number of records to include in each batch.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipesourcekinesisstreamparameters.html#cfn-pipes-pipe-pipesourcekinesisstreamparameters-batchsize
     * @default 1
     */
    readonly batchSize?: number;
    /**
     * Define the target to send dead-letter queue events to.
     *
     * The dead-letter queue stores any events that are not successfully delivered to a Pipes target after all retry attempts are exhausted.
     * You can then resolve the issue that caused the failed invocations and replay the events at a later time.
     * In some cases, such as when access is denied to a resource, events are sent directly to the dead-letter queue and are not retried.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipesourcekinesisstreamparameters.html#cfn-pipes-pipe-pipesourcekinesisstreamparameters-deadletterconfig
     * @default - no dead-letter queue or topic
     */
    readonly deadLetterTarget?: IQueue | ITopic;
    /**
     * The maximum length of a time to wait for events.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipesourcekinesisstreamparameters.html#cfn-pipes-pipe-pipesourcekinesisstreamparameters-maximumbatchingwindowinseconds
     * @default - the events will be handled immediately
     */
    readonly maximumBatchingWindow?: Duration;
    /**
     * Discard records older than the specified age. The default value is -1, which sets the maximum age to infinite. When the value is set to infinite, EventBridge never discards old records.
     *
     *  @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipesourcekinesisstreamparameters.html#cfn-pipes-pipe-pipesourcekinesisstreamparameters-maximumrecordageinseconds
     * @default -1 - EventBridge won't discard old records
     */
    readonly maximumRecordAge?: Duration;
    /**
     * Discard records after the specified number of retries. The default value is -1, which sets the maximum number of retries to infinite. When MaximumRetryAttempts is infinite, EventBridge retries failed records until the record expires in the event source.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipesourcekinesisstreamparameters.html#cfn-pipes-pipe-pipesourcekinesisstreamparameters-maximumretryattempts
     * @default -1 - EventBridge will retry failed records until the record expires in the event source
     */
    readonly maximumRetryAttempts?: number;
    /**
     * Define how to handle item process failures. {@link OnPartialBatchItemFailure.AUTOMATIC_BISECT} halves each batch and will retry each half until all the records are processed or there is one failed message left in the batch.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipesourcekinesisstreamparameters.html#cfn-pipes-pipe-pipesourcekinesisstreamparameters-onpartialbatchitemfailure
     * @default off - EventBridge will retry the entire batch
     */
    readonly onPartialBatchItemFailure?: OnPartialBatchItemFailure;
    /**
     * The number of batches to process concurrently from each shard.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipesourcekinesisstreamparameters.html#cfn-pipes-pipe-pipesourcekinesisstreamparameters-parallelizationfactor
     * @default 1
     */
    readonly parallelizationFactor?: number;
}
/**
 * Streaming sources.
 */
export declare abstract class StreamSource extends SourceWithDeadLetterTarget {
    /**
     * The ARN of the source resource.
     */
    readonly sourceArn: string;
    /**
     * Base parameters for streaming sources.
     */
    readonly sourceParameters: StreamSourceParameters;
    constructor(sourceArn: string, sourceParameters: StreamSourceParameters);
}
