import type { IPipe, SourceConfig } from '@aws-cdk/aws-pipes-alpha';
import type { ITableV2 } from 'aws-cdk-lib/aws-dynamodb';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { DynamoDBStartingPosition } from './enums';
import type { StreamSourceParameters } from './streamSource';
import { StreamSource } from './streamSource';
/**
 * Parameters for the DynamoDB source.
 */
export interface DynamoDBSourceParameters extends StreamSourceParameters {
    /**
     * The position in a stream from which to start reading.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipesourcedynamodbstreamparameters.html#cfn-pipes-pipe-pipesourcedynamodbstreamparameters-startingposition
     */
    readonly startingPosition: DynamoDBStartingPosition;
}
/**
 * A source that reads from an DynamoDB stream.
 */
export declare class DynamoDBSource extends StreamSource {
    private readonly table;
    private readonly startingPosition;
    private readonly deadLetterTargetArn?;
    constructor(table: ITableV2, parameters: DynamoDBSourceParameters);
    bind(_pipe: IPipe): SourceConfig;
    grantRead(grantee: IRole): void;
}
