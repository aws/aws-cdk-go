import type { IPipe, SourceConfig } from '@aws-cdk/aws-pipes-alpha';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import type { IStream } from 'aws-cdk-lib/aws-kinesis';
import { KinesisStartingPosition } from './enums';
import type { StreamSourceParameters } from './streamSource';
import { StreamSource } from './streamSource';
/**
 * Parameters for the Kinesis source.
 */
export interface KinesisSourceParameters extends StreamSourceParameters {
    /**
     * The position in a stream from which to start reading.
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipesourcekinesisstreamparameters.html#cfn-pipes-pipe-pipesourcekinesisstreamparameters-startingposition
     */
    readonly startingPosition: KinesisStartingPosition;
    /**
     * With StartingPosition set to AT_TIMESTAMP, the time from which to start reading, in ISO 8601 format.
     *
     * @example
     * new Date(Date.UTC(1969, 10, 20, 0, 0, 0))
     *
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pipes-pipe-pipesourcekinesisstreamparameters.html#cfn-pipes-pipe-pipesourcekinesisstreamparameters-startingpositiontimestamp
     * @default - no starting position timestamp
     */
    readonly startingPositionTimestamp?: Date;
}
/**
 * A source that reads from Kinesis.
 */
export declare class KinesisSource extends StreamSource {
    private readonly stream;
    private readonly startingPosition;
    private readonly startingPositionTimestamp?;
    private readonly deadLetterTargetArn?;
    constructor(stream: IStream, parameters: KinesisSourceParameters);
    bind(_pipe: IPipe): SourceConfig;
    grantRead(grantee: IRole): void;
}
