function _aws_cdk_aws_pipes_sources_alpha_DynamoDBSourceParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.startingPosition))
            _aws_cdk_aws_pipes_sources_alpha_DynamoDBStartingPosition(p.startingPosition);
        if (!visitedObjects.has(p.onPartialBatchItemFailure))
            _aws_cdk_aws_pipes_sources_alpha_OnPartialBatchItemFailure(p.onPartialBatchItemFailure);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_pipes_sources_alpha_DynamoDBSource(p) {
}
function _aws_cdk_aws_pipes_sources_alpha_OnPartialBatchItemFailure(p) {
}
function _aws_cdk_aws_pipes_sources_alpha_KinesisStartingPosition(p) {
}
function _aws_cdk_aws_pipes_sources_alpha_DynamoDBStartingPosition(p) {
}
function _aws_cdk_aws_pipes_sources_alpha_KinesisSourceParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.startingPosition))
            _aws_cdk_aws_pipes_sources_alpha_KinesisStartingPosition(p.startingPosition);
        if (!visitedObjects.has(p.onPartialBatchItemFailure))
            _aws_cdk_aws_pipes_sources_alpha_OnPartialBatchItemFailure(p.onPartialBatchItemFailure);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_pipes_sources_alpha_KinesisSource(p) {
}
function _aws_cdk_aws_pipes_sources_alpha_SqsSourceParameters(p) {
}
function _aws_cdk_aws_pipes_sources_alpha_SqsSource(p) {
}
function _aws_cdk_aws_pipes_sources_alpha_StreamSourceParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.onPartialBatchItemFailure))
            _aws_cdk_aws_pipes_sources_alpha_OnPartialBatchItemFailure(p.onPartialBatchItemFailure);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_pipes_sources_alpha_StreamSource(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_pipes_sources_alpha_DynamoDBSourceParameters, _aws_cdk_aws_pipes_sources_alpha_DynamoDBSource, _aws_cdk_aws_pipes_sources_alpha_OnPartialBatchItemFailure, _aws_cdk_aws_pipes_sources_alpha_KinesisStartingPosition, _aws_cdk_aws_pipes_sources_alpha_DynamoDBStartingPosition, _aws_cdk_aws_pipes_sources_alpha_KinesisSourceParameters, _aws_cdk_aws_pipes_sources_alpha_KinesisSource, _aws_cdk_aws_pipes_sources_alpha_SqsSourceParameters, _aws_cdk_aws_pipes_sources_alpha_SqsSource, _aws_cdk_aws_pipes_sources_alpha_StreamSourceParameters, _aws_cdk_aws_pipes_sources_alpha_StreamSource };
