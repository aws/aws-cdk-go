"use strict";
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Agent = exports.AgentBase = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const crypto = require("crypto");
const bedrock = require("aws-cdk-lib/aws-bedrock");
const cloudwatch = require("aws-cdk-lib/aws-cloudwatch");
const events = require("aws-cdk-lib/aws-events");
const iam = require("aws-cdk-lib/aws-iam");
const kms = require("aws-cdk-lib/aws-kms");
const s3 = require("aws-cdk-lib/aws-s3");
const core_1 = require("aws-cdk-lib/core");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
// Internal Libs
const action_group_1 = require("./action-group");
const agent_alias_1 = require("./agent-alias");
const api_schema_1 = require("./api-schema");
const orchestration_executor_1 = require("./orchestration-executor");
const validation = require("./validation-helpers");
/******************************************************************************
 *                              CONSTANTS
 *****************************************************************************/
/**
 * The minimum number of characters required for an agent instruction.
 * @internal
 */
const MIN_INSTRUCTION_LENGTH = 40;
/**
 * The maximum length for the node address in permission policy names.
 * @internal
 */
const MAX_POLICY_NAME_NODE_LENGTH = 16;
/******************************************************************************
 *                        ABSTRACT BASE CLASS
 *****************************************************************************/
/**
 * Abstract base class for an Agent.
 * Contains methods and attributes valid for Agents either created with CDK or imported.
 */
class AgentBase extends core_1.Resource {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AgentBase", version: "2.242.0-alpha.0" };
    /**
     * Grant invoke permissions on this agent to an IAM principal.
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant invoke permissions to
     * @default - Default grant configuration:
     * - actions: ['bedrock:InvokeAgent']
     * - resourceArns: [this.agentArn]
     * @returns An IAM Grant object representing the granted permissions
     */
    grantInvoke(grantee) {
        return iam.Grant.addToPrincipal({
            grantee,
            actions: ['bedrock:InvokeAgent'],
            resourceArns: [this.agentArn],
        });
    }
    /**
     * Creates an EventBridge rule for agent events.
     *
     * @param id - Unique identifier for the rule
     * @param options - Configuration options for the event rule
     * @default - Default event pattern:
     * - source: ['aws.bedrock']
     * - detail: { 'agent-id': [this.agentId] }
     * @returns An EventBridge Rule configured for agent events
     */
    onEvent(id, options = {}) {
        const rule = new events.Rule(this, id, options);
        rule.addEventPattern({
            source: ['aws.bedrock'],
            detail: {
                'agent-id': [this.agentId],
            },
        });
        rule.addTarget(options.target);
        return rule;
    }
    /**
     * Creates a CloudWatch metric for tracking agent invocations.
     *
     * @param props - Configuration options for the metric
     * @default - Default metric configuration:
     * - namespace: 'AWS/Bedrock'
     * - metricName: 'Invocations'
     * - dimensionsMap: { AgentId: this.agentId }
     * @returns A CloudWatch Metric configured for agent invocation counts
     */
    metricCount(props) {
        return new cloudwatch.Metric({
            namespace: 'AWS/Bedrock',
            metricName: 'Invocations',
            dimensionsMap: {
                AgentId: this.agentId,
            },
            ...props,
        }).attachTo(this);
    }
}
exports.AgentBase = AgentBase;
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create (or import) an Agent with CDK.
 * @cloudformationResource AWS::Bedrock::Agent
 */
let Agent = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = AgentBase;
    let _instanceExtraInitializers = [];
    let _addGuardrail_decorators;
    let _addActionGroup_decorators;
    let _addActionGroups_decorators;
    var Agent = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _addGuardrail_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addActionGroup_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addActionGroups_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            __esDecorate(this, null, _addGuardrail_decorators, { kind: "method", name: "addGuardrail", static: false, private: false, access: { has: obj => "addGuardrail" in obj, get: obj => obj.addGuardrail }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addActionGroup_decorators, { kind: "method", name: "addActionGroup", static: false, private: false, access: { has: obj => "addActionGroup" in obj, get: obj => obj.addActionGroup }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addActionGroups_decorators, { kind: "method", name: "addActionGroups", static: false, private: false, access: { has: obj => "addActionGroups" in obj, get: obj => obj.addActionGroups }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            Agent = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.Agent", version: "2.242.0-alpha.0" };
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.Agent';
        /**
         * Static Method for importing an existing Bedrock Agent.
         */
        /**
         * Creates an Agent reference from an existing agent's attributes.
         *
         * @param scope - The construct scope
         * @param id - Identifier of the construct
         * @param attrs - Attributes of the existing agent
         * @default - For attrs.agentVersion: 'DRAFT' if no explicit version is provided
         * @returns An IAgent reference to the existing agent
         */
        static fromAgentAttributes(scope, id, attrs) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentAttributes(attrs);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.fromAgentAttributes);
                }
                throw error;
            }
            class Import extends AgentBase {
                agentArn = attrs.agentArn;
                agentId = core_1.Arn.split(attrs.agentArn, core_1.ArnFormat.SLASH_RESOURCE_NAME).resourceName;
                role = iam.Role.fromRoleArn(scope, `${id}Role`, attrs.roleArn);
                kmsKey = attrs.kmsKeyArn ? kms.Key.fromKeyArn(scope, `${id}Key`, attrs.kmsKeyArn) : undefined;
                lastUpdated = attrs.lastUpdated;
                agentVersion = attrs.agentVersion ?? 'DRAFT';
                grantPrincipal = this.role;
            }
            // Return new Agent
            return new Import(scope, id);
        }
        // ------------------------------------------------------
        // Base attributes
        // ------------------------------------------------------
        /**
         * The unique identifier for the agent
         * @attribute
         */
        agentId = __runInitializers(this, _instanceExtraInitializers);
        /**
         * The ARN of the agent.
         * @attribute
         */
        agentArn;
        /**
         * The version of the agent.
         * @attribute
         */
        agentVersion;
        /**
         * The IAM role associated to the agent.
         */
        role;
        /**
         * Optional KMS encryption key associated with this agent
         */
        kmsKey;
        /**
         * When this agent was last updated.
         */
        lastUpdated;
        /**
         * The principal to grant permissions to
         */
        grantPrincipal;
        /**
         * Default alias of the agent
         */
        testAlias;
        /**
         * action groups associated with the ageny
         */
        actionGroups = [];
        /**
         * The guardrail that will be associated with the agent.
         */
        guardrail;
        // ------------------------------------------------------
        // CDK-only attributes
        // ------------------------------------------------------
        /**
         * The name of the agent.
         */
        name;
        // ------------------------------------------------------
        // Internal Only
        // ------------------------------------------------------
        ROLE_NAME_SUFFIX = '-bedrockagent';
        MAXLENGTH_FOR_ROLE_NAME = 64;
        idleSessionTTL;
        foundationModel;
        userInputEnabled;
        codeInterpreterEnabled;
        agentCollaboration;
        customOrchestrationExecutor;
        promptOverrideConfiguration;
        __resource;
        // ------------------------------------------------------
        // CONSTRUCTOR
        // ------------------------------------------------------
        constructor(scope, id, props) {
            super(scope, id);
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentProps(props);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, Agent);
                }
                throw error;
            }
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            // ------------------------------------------------------
            // Validate props
            // ------------------------------------------------------
            if (props.instruction !== undefined &&
                !core_1.Token.isUnresolved(props.instruction) &&
                props.instruction.length < MIN_INSTRUCTION_LENGTH) {
                throw new core_1.ValidationError(`instruction must be at least ${MIN_INSTRUCTION_LENGTH} characters`, this);
            }
            // Validate idleSessionTTL
            if (props.idleSessionTTL !== undefined &&
                !core_1.Token.isUnresolved(props.idleSessionTTL) &&
                (props.idleSessionTTL.toMinutes() < 1 || props.idleSessionTTL.toMinutes() > 60)) {
                throw new core_1.ValidationError('idleSessionTTL must be between 1 and 60 minutes', this);
            }
            // ------------------------------------------------------
            // Set properties and defaults
            // ------------------------------------------------------
            this.name =
                props.agentName ?? this.generatePhysicalName() + this.ROLE_NAME_SUFFIX;
            this.idleSessionTTL = props.idleSessionTTL ?? core_1.Duration.minutes(10);
            this.userInputEnabled = props.userInputEnabled ?? false;
            this.codeInterpreterEnabled = props.codeInterpreterEnabled ?? false;
            this.foundationModel = props.foundationModel;
            // Optional
            this.promptOverrideConfiguration = props.promptOverrideConfiguration;
            this.kmsKey = props.kmsKey;
            this.customOrchestrationExecutor = props.customOrchestrationExecutor;
            // ------------------------------------------------------
            // Role
            // ------------------------------------------------------
            // If existing role is provided, use it.
            if (props.existingRole) {
                this.role = props.existingRole;
                this.grantPrincipal = this.role;
                // Otherwise, create a new one
            }
            else {
                this.role = new iam.Role(this, 'Role', {
                    // generate a role name
                    roleName: this.generatePhysicalName() + this.ROLE_NAME_SUFFIX,
                    // ensure the role has a trust policy that allows the Bedrock service to assume the role
                    assumedBy: new iam.ServicePrincipal('bedrock.amazonaws.com').withConditions({
                        StringEquals: {
                            'aws:SourceAccount': { Ref: 'AWS::AccountId' },
                        },
                        ArnLike: {
                            'aws:SourceArn': core_1.Stack.of(this).formatArn({
                                service: 'bedrock',
                                resource: 'agent',
                                resourceName: '*',
                                arnFormat: core_1.ArnFormat.SLASH_RESOURCE_NAME,
                            }),
                        },
                    }),
                });
                this.grantPrincipal = this.role;
            }
            // ------------------------------------------------------
            // Set Lazy Props initial values
            // ------------------------------------------------------
            // Add Default Action Groups
            this.addActionGroup(action_group_1.AgentActionGroup.userInput(this.userInputEnabled));
            this.addActionGroup(action_group_1.AgentActionGroup.codeInterpreter(this.codeInterpreterEnabled));
            // Add specified elems through methods to handle permissions
            // this needs to happen after role creation / assignment
            props.actionGroups?.forEach(ag => {
                this.addActionGroup(ag);
            });
            // Set agent collaboration configuration
            this.agentCollaboration = props.agentCollaboration;
            if (props.agentCollaboration) {
                props.agentCollaboration.collaborators.forEach(ac => {
                    this.grantPermissionToAgent(ac);
                });
            }
            if (props.guardrail) {
                this.addGuardrail(props.guardrail);
            }
            // Grant permissions for custom orchestration if provided
            if (this.customOrchestrationExecutor?.lambdaFunction) {
                this.customOrchestrationExecutor.lambdaFunction.grantInvoke(this.role);
                this.customOrchestrationExecutor.lambdaFunction.addPermission(`OrchestrationLambdaInvocationPolicy-${this.node.addr.slice(0, MAX_POLICY_NAME_NODE_LENGTH)}`, {
                    principal: new iam.ServicePrincipal('bedrock.amazonaws.com'),
                    sourceArn: core_1.Lazy.string({ produce: () => this.agentArn }),
                    sourceAccount: { Ref: 'AWS::AccountId' },
                });
            }
            // ------------------------------------------------------
            // CFN Props - With Lazy support
            // ------------------------------------------------------
            const cfnProps = {
                actionGroups: core_1.Lazy.any({ produce: () => this.renderActionGroups() }, { omitEmptyArray: true }),
                agentName: this.name,
                agentResourceRoleArn: this.role.roleArn,
                autoPrepare: props.shouldPrepareAgent ?? false,
                customerEncryptionKeyArn: props.kmsKey?.keyArn,
                description: props.description,
                foundationModel: this.foundationModel.invokableArn,
                guardrailConfiguration: core_1.Lazy.any({ produce: () => this.renderGuardrail() }),
                idleSessionTtlInSeconds: this.idleSessionTTL.toSeconds(),
                instruction: props.instruction,
                memoryConfiguration: props.memory?._render(),
                promptOverrideConfiguration: this.promptOverrideConfiguration?._render(),
                skipResourceInUseCheckOnDelete: props.forceDelete ?? false,
                agentCollaboration: props.agentCollaboration?.type,
                agentCollaborators: core_1.Lazy.any({ produce: () => this.renderAgentCollaborators() }, { omitEmptyArray: true }),
                customOrchestration: this.renderCustomOrchestration(),
                orchestrationType: this.customOrchestrationExecutor ? orchestration_executor_1.OrchestrationType.CUSTOM_ORCHESTRATION : orchestration_executor_1.OrchestrationType.DEFAULT,
            };
            // ------------------------------------------------------
            // L1 Instantiation
            // ------------------------------------------------------
            this.__resource = new bedrock.CfnAgent(this, 'Resource', cfnProps);
            this.agentId = this.__resource.attrAgentId;
            this.agentArn = this.__resource.attrAgentArn;
            this.agentVersion = this.__resource.attrAgentVersion;
            this.lastUpdated = this.__resource.attrUpdatedAt;
            // Add explicit dependency between the agent resource and the agent's role default policy
            // See https://github.com/awslabs/generative-ai-cdk-constructs/issues/899
            const grant = this.foundationModel.grantInvoke(this.role);
            grant.applyBefore(this.__resource);
            this.testAlias = agent_alias_1.AgentAlias.fromAttributes(this, 'DefaultAlias', {
                aliasId: 'TSTALIASID',
                aliasName: 'AgentTestAlias',
                agentVersion: 'DRAFT',
                agent: this,
            });
        }
        // ------------------------------------------------------
        // HELPER METHODS - addX()
        // ------------------------------------------------------
        /**
         * Add guardrail to the agent.
         */
        addGuardrail(guardrail) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_IGuardrail(guardrail);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addGuardrail);
                }
                throw error;
            }
            // Do some checks
            validation.throwIfInvalid(this.validateGuardrail, guardrail);
            // Add it to the construct
            this.guardrail = guardrail;
            // Handle permissions
            guardrail.grantApply(this.role);
        }
        /**
         * Adds an action group to the agent and configures necessary permissions.
         *
         * @param actionGroup - The action group to add
         * @default - Default permissions:
         * - Lambda function invoke permissions if executor is present
         * - S3 GetObject permissions if apiSchema.s3File is present
         */
        addActionGroup(actionGroup) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentActionGroup(actionGroup);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addActionGroup);
                }
                throw error;
            }
            validation.throwIfInvalid(this.validateActionGroup, actionGroup);
            this.actionGroups.push(actionGroup);
            // Handle permissions to invoke the lambda function
            actionGroup.executor?.lambdaFunction?.grantInvoke(this.role);
            actionGroup.executor?.lambdaFunction?.addPermission(`LambdaInvocationPolicy-${this.node.addr.slice(0, MAX_POLICY_NAME_NODE_LENGTH)}`, {
                principal: new iam.ServicePrincipal('bedrock.amazonaws.com'),
                sourceArn: this.agentArn,
                sourceAccount: { Ref: 'AWS::AccountId' },
            });
            // Handle permissions to access the schema file from S3
            if (actionGroup.apiSchema instanceof api_schema_1.AssetApiSchema) {
                const rendered = actionGroup.apiSchema._render();
                if (!('s3' in rendered) || !rendered.s3) {
                    throw new core_1.ValidationError('S3 configuration is missing in AssetApiSchema', this);
                }
                const s3Config = rendered.s3;
                if (!('s3BucketName' in s3Config) || !('s3ObjectKey' in s3Config)) {
                    throw new core_1.ValidationError('S3 bucket name and object key are required in AssetApiSchema', this);
                }
                const bucketName = s3Config.s3BucketName;
                const objectKey = s3Config.s3ObjectKey;
                if (!bucketName || bucketName.trim() === '') {
                    throw new core_1.ValidationError('S3 bucket name cannot be empty in AssetApiSchema', this);
                }
                if (!objectKey || objectKey.trim() === '') {
                    throw new core_1.ValidationError('S3 object key cannot be empty in AssetApiSchema', this);
                }
                const bucket = s3.Bucket.fromBucketName(this, `${actionGroup.name}SchemaBucket`, bucketName);
                bucket.grantRead(this.role, objectKey);
            }
            else if (actionGroup.apiSchema instanceof api_schema_1.S3ApiSchema) {
                const s3File = actionGroup.apiSchema.s3File;
                if (!s3File) {
                    throw new core_1.ValidationError('S3 file configuration is missing in S3ApiSchema', this);
                }
                if (!s3File.bucketName || s3File.bucketName.trim() === '') {
                    throw new core_1.ValidationError('S3 bucket name cannot be empty in S3ApiSchema', this);
                }
                if (!s3File.objectKey || s3File.objectKey.trim() === '') {
                    throw new core_1.ValidationError('S3 object key cannot be empty in S3ApiSchema', this);
                }
                const bucket = s3.Bucket.fromBucketName(this, `${actionGroup.name}SchemaBucket`, s3File.bucketName);
                bucket.grantRead(this.role, s3File.objectKey);
            }
        }
        /**
         * Grants permissions for an agent collaborator to this agent's role.
         * This method only grants IAM permissions and does not add the collaborator
         * to the agent's collaboration configuration. To add collaborators to the
         * agent configuration, include them in the AgentCollaboration when creating the agent.
         *
         * @param agentCollaborator - The collaborator to grant permissions for
         */
        grantPermissionToAgent(agentCollaborator) {
            agentCollaborator.grant(this.role);
        }
        /**
         * Configuration for agent collaboration.
         *
         * @default - No collaboration configuration.
         */
        addActionGroups(...actionGroups) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentActionGroup(actionGroups);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addActionGroups);
                }
                throw error;
            }
            actionGroups.forEach(ag => this.addActionGroup(ag));
        }
        // ------------------------------------------------------
        // Lazy Renderers
        // ------------------------------------------------------
        /**
         * Render the guardrail configuration.
         *
         * @internal This is an internal core function and should not be called directly.
         */
        renderGuardrail() {
            return this.guardrail
                ? {
                    guardrailIdentifier: this.guardrail.guardrailId,
                    guardrailVersion: this.guardrail.guardrailVersion,
                }
                : undefined;
        }
        /**
         * Render the action groups
         *
         * @returns Array of AgentActionGroupProperty objects in CloudFormation format
         * @default - Empty array if no action groups are defined
         * @internal This is an internal core function and should not be called directly.
         */
        renderActionGroups() {
            const actionGroupsCfn = [];
            // Build the associations in the CFN format
            this.actionGroups.forEach(ag => {
                actionGroupsCfn.push(ag._render());
            });
            return actionGroupsCfn;
        }
        /**
         * Render the agent collaborators.
         *
         * @returns Array of AgentCollaboratorProperty objects in CloudFormation format, or undefined if no collaborators
         * @default - undefined if no collaborators are defined or array is empty
         * @internal This is an internal core function and should not be called directly.
         */
        renderAgentCollaborators() {
            if (!this.agentCollaboration || !this.agentCollaboration.collaborators || this.agentCollaboration.collaborators.length === 0) {
                return undefined;
            }
            return this.agentCollaboration.collaborators.map(ac => ac._render());
        }
        /**
         * Render the custom orchestration.
         *
         * @returns CustomOrchestrationProperty object in CloudFormation format, or undefined if no custom orchestration
         * @default - undefined if no custom orchestration is defined
         * @internal This is an internal core function and should not be called directly.
         */
        renderCustomOrchestration() {
            if (!this.customOrchestrationExecutor) {
                return undefined;
            }
            return {
                executor: {
                    lambda: this.customOrchestrationExecutor.lambdaFunction.functionArn,
                },
            };
        }
        // ------------------------------------------------------
        // Validators
        // ------------------------------------------------------
        /**
         * Checks if the Guardrail is valid
         *
         * @param guardrail - The guardrail to validate
         * @returns Array of validation error messages, empty if valid
         */
        validateGuardrail = (guardrail) => {
            let errors = [];
            if (this.guardrail) {
                errors.push(`Cannot add Guardrail ${guardrail.guardrailId}. ` +
                    `Guardrail ${this.guardrail.guardrailId} has already been specified for this agent.`);
            }
            errors.push(...validation.validateFieldPattern(guardrail.guardrailVersion, 'version', /^(([0-9]{1,8})|(DRAFT))$/));
            return errors;
        };
        /**
         * Check if the action group is valid
         *
         * @param actionGroup - The action group to validate
         * @returns Array of validation error messages, empty if valid
         */
        validateActionGroup = (actionGroup) => {
            let errors = [];
            // Find if there is a conflicting action group name
            if (this.actionGroups?.find(ag => ag.name === actionGroup.name)) {
                errors.push('Action group already exists');
            }
            return errors;
        };
        /**
         * Generates a unique, deterministic name for AWS resources that includes a hash component.
         * This method ensures consistent naming while avoiding conflicts and adhering to AWS naming constraints.
         * @param scope - The construct scope used for generating unique names
         * @param prefix - The prefix to prepend to the generated name
         * @param options - Configuration options for name generation
         * @param options.maxLength - Maximum length of the generated name
         * @default - maxLength: 256
         * @param options.lower - Convert the generated name to lowercase
         * @default - lower: false
         * @param options.separator - Character(s) to use between name components
         * @default - separator: ''
         * @param options.allowedSpecialCharacters - String of allowed special characters
         * @default - undefined
         * @param options.destroyCreate - Object to include in hash generation for destroy/create operations
         * @default - undefined
         * @returns A string containing the generated name with format: prefix + hash + separator + uniqueName
         * @throws ValidationError if the generated name would exceed maxLength or if prefix is too long
         * @internal
         */
        generatePhysicalNameHash(scope, prefix, options) {
            const objectToHash = (obj) => {
                if (obj === undefined) {
                    return '';
                }
                const jsonString = JSON.stringify(obj);
                const hash = crypto.createHash('sha256');
                return hash.update(jsonString).digest('hex').slice(0, 7);
            };
            const { maxLength = 256, lower = false, separator = '', allowedSpecialCharacters = undefined, destroyCreate = undefined, } = options ?? {};
            const hash = objectToHash(destroyCreate);
            if (maxLength < (prefix + hash + separator).length) {
                throw new core_1.ValidationError('The prefix is longer than the maximum length.', this);
            }
            const uniqueName = core_1.Names.uniqueResourceName(scope, { maxLength: maxLength - (prefix + hash + separator).length, separator, allowedSpecialCharacters });
            const name = `${prefix}${hash}${separator}${uniqueName}`;
            if (name.length > maxLength) {
                throw new core_1.ValidationError(`The generated name is longer than the maximum length of ${maxLength}`, this);
            }
            return lower ? name.toLowerCase() : name;
        }
        /**
         * Generates a physical name for the agent.
         * @returns A unique name for the agent with appropriate length constraints
         * @default - Generated name format: 'agent-{hash}-{uniqueName}' with:
         * - maxLength: MAXLENGTH_FOR_ROLE_NAME - '-bedrockagent'.length
         * - lower: true
         * - separator: '-'
         * @protected
         */
        generatePhysicalName() {
            const maxLength = this.MAXLENGTH_FOR_ROLE_NAME - this.ROLE_NAME_SUFFIX.length;
            return this.generatePhysicalNameHash(this, 'agent', {
                maxLength,
                lower: true,
                separator: '-',
            });
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return Agent = _classThis;
})();
exports.Agent = Agent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWdlbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhZ2VudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxpQ0FBaUM7QUFDakMsbURBQW1EO0FBQ25ELHlEQUF5RDtBQUN6RCxpREFBaUQ7QUFDakQsMkNBQTJDO0FBQzNDLDJDQUEyQztBQUMzQyx5Q0FBeUM7QUFFekMsMkNBQWtIO0FBQ2xILDhFQUE4RjtBQUM5RiwwRUFBMEU7QUFFMUUsZ0JBQWdCO0FBQ2hCLGlEQUFrRDtBQUVsRCwrQ0FBMkM7QUFHM0MsNkNBQTJEO0FBRzNELHFFQUE2RDtBQUU3RCxtREFBbUQ7QUFJbkQ7OytFQUUrRTtBQUMvRTs7O0dBR0c7QUFDSCxNQUFNLHNCQUFzQixHQUFHLEVBQUUsQ0FBQztBQUVsQzs7O0dBR0c7QUFDSCxNQUFNLDJCQUEyQixHQUFHLEVBQUUsQ0FBQztBQWtEdkM7OytFQUUrRTtBQUMvRTs7O0dBR0c7QUFDSCxNQUFzQixTQUFVLFNBQVEsZUFBUTs7SUFhOUM7Ozs7Ozs7OztPQVNHO0lBQ0ksV0FBVyxDQUFDLE9BQXVCO1FBQ3hDLE9BQU8sR0FBRyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUM7WUFDOUIsT0FBTztZQUNQLE9BQU8sRUFBRSxDQUFDLHFCQUFxQixDQUFDO1lBQ2hDLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7U0FDOUIsQ0FBQyxDQUFDO0tBQ0o7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSSxPQUFPLENBQUMsRUFBVSxFQUFFLFVBQWlDLEVBQUU7UUFDNUQsTUFBTSxJQUFJLEdBQUcsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLGVBQWUsQ0FBQztZQUNuQixNQUFNLEVBQUUsQ0FBQyxhQUFhLENBQUM7WUFDdkIsTUFBTSxFQUFFO2dCQUNOLFVBQVUsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7YUFDM0I7U0FDRixDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMvQixPQUFPLElBQUksQ0FBQztLQUNiO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0ksV0FBVyxDQUFDLEtBQWdDO1FBQ2pELE9BQU8sSUFBSSxVQUFVLENBQUMsTUFBTSxDQUFDO1lBQzNCLFNBQVMsRUFBRSxhQUFhO1lBQ3hCLFVBQVUsRUFBRSxhQUFhO1lBQ3pCLGFBQWEsRUFBRTtnQkFDYixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87YUFDdEI7WUFDRCxHQUFHLEtBQUs7U0FDVCxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ25COztBQXpFSCw4QkEwRUM7QUFpS0Q7OytFQUUrRTtBQUMvRTs7O0dBR0c7SUFFVSxLQUFLOzRCQURqQixvQ0FBa0I7Ozs7c0JBQ1EsU0FBUzs7Ozs7cUJBQWpCLFNBQVEsV0FBUzs7Ozt3Q0E2UGpDLElBQUEsa0NBQWMsR0FBRTswQ0FrQmhCLElBQUEsa0NBQWMsR0FBRTsyQ0FnRWhCLElBQUEsa0NBQWMsR0FBRTtZQWpGakIsdUxBQU8sWUFBWSw2REFPbEI7WUFXRCw2TEFBTyxjQUFjLDZEQTRDcEI7WUFvQkQsZ01BQU8sZUFBZSw2REFFckI7WUFsVkgsNktBMmdCQzs7Ozs7UUExZ0JDLHNDQUFzQztRQUMvQixNQUFNLENBQVUscUJBQXFCLEdBQVcsa0NBQWtDLENBQUM7UUFFMUY7O1dBRUc7UUFDSDs7Ozs7Ozs7V0FRRztRQUNJLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxLQUFnQixFQUFFLEVBQVUsRUFBRSxLQUFzQjs7Ozs7Ozs7OztZQUNwRixNQUFNLE1BQU8sU0FBUSxTQUFTO2dCQUNaLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDO2dCQUMxQixPQUFPLEdBQUcsVUFBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLGdCQUFTLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxZQUFhLENBQUM7Z0JBQ2pGLElBQUksR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQy9ELE1BQU0sR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztnQkFDOUYsV0FBVyxHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUM7Z0JBQ2hDLFlBQVksR0FBRyxLQUFLLENBQUMsWUFBWSxJQUFJLE9BQU8sQ0FBQztnQkFDN0MsY0FBYyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDNUM7WUFFRCxtQkFBbUI7WUFDbkIsT0FBTyxJQUFJLE1BQU0sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDOUI7UUFDRCx5REFBeUQ7UUFDekQsa0JBQWtCO1FBQ2xCLHlEQUF5RDtRQUN6RDs7O1dBR0c7UUFDYSxPQUFPLEdBckNaLG1EQUFLLENBcUNnQjtRQUNoQzs7O1dBR0c7UUFDYSxRQUFRLENBQVM7UUFDakM7OztXQUdHO1FBQ2EsWUFBWSxDQUFTO1FBQ3JDOztXQUVHO1FBQ2EsSUFBSSxDQUFZO1FBQ2hDOztXQUVHO1FBQ2EsTUFBTSxDQUFZO1FBQ2xDOztXQUVHO1FBQ2EsV0FBVyxDQUFVO1FBQ3JDOztXQUVHO1FBQ2EsY0FBYyxDQUFpQjtRQUMvQzs7V0FFRztRQUNhLFNBQVMsQ0FBYztRQUN2Qzs7V0FFRztRQUNhLFlBQVksR0FBdUIsRUFBRSxDQUFDO1FBQ3REOztXQUVHO1FBQ0ksU0FBUyxDQUFjO1FBQzlCLHlEQUF5RDtRQUN6RCxzQkFBc0I7UUFDdEIseURBQXlEO1FBQ3pEOztXQUVHO1FBQ2EsSUFBSSxDQUFTO1FBRTdCLHlEQUF5RDtRQUN6RCxnQkFBZ0I7UUFDaEIseURBQXlEO1FBQ3hDLGdCQUFnQixHQUFHLGVBQWUsQ0FBQztRQUNuQyx1QkFBdUIsR0FBRyxFQUFFLENBQUM7UUFDN0IsY0FBYyxDQUFXO1FBQ3pCLGVBQWUsQ0FBb0I7UUFDbkMsZ0JBQWdCLENBQVU7UUFDMUIsc0JBQXNCLENBQVU7UUFDaEMsa0JBQWtCLENBQXNCO1FBQ3hDLDJCQUEyQixDQUErQjtRQUMxRCwyQkFBMkIsQ0FBK0I7UUFDMUQsVUFBVSxDQUFtQjtRQUU5Qyx5REFBeUQ7UUFDekQsY0FBYztRQUNkLHlEQUF5RDtRQUN6RCxZQUFZLEtBQWdCLEVBQUUsRUFBVSxFQUFFLEtBQWlCO1lBQ3pELEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7Ozs7OzttREF0R1IsS0FBSzs7OztZQXVHZCxtQ0FBbUM7WUFDbkMsSUFBQSx3Q0FBb0IsRUFBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFbEMseURBQXlEO1lBQ3pELGlCQUFpQjtZQUNqQix5REFBeUQ7WUFDekQsSUFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLFNBQVM7Z0JBQy9CLENBQUMsWUFBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDO2dCQUN0QyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxzQkFBc0IsRUFBRSxDQUFDO2dCQUN0RCxNQUFNLElBQUksc0JBQWUsQ0FBQyxnQ0FBZ0Msc0JBQXNCLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN2RyxDQUFDO1lBRUQsMEJBQTBCO1lBQzFCLElBQUksS0FBSyxDQUFDLGNBQWMsS0FBSyxTQUFTO2dCQUNsQyxDQUFDLFlBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQztnQkFDekMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsSUFBSSxLQUFLLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7Z0JBQ3BGLE1BQU0sSUFBSSxzQkFBZSxDQUFDLGlEQUFpRCxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3JGLENBQUM7WUFFRCx5REFBeUQ7WUFDekQsOEJBQThCO1lBQzlCLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMsSUFBSTtnQkFDUCxLQUFLLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztZQUN6RSxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQyxjQUFjLElBQUksZUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNuRSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLGdCQUFnQixJQUFJLEtBQUssQ0FBQztZQUN4RCxJQUFJLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDLHNCQUFzQixJQUFJLEtBQUssQ0FBQztZQUNwRSxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQyxlQUFlLENBQUM7WUFDN0MsV0FBVztZQUNYLElBQUksQ0FBQywyQkFBMkIsR0FBRyxLQUFLLENBQUMsMkJBQTJCLENBQUM7WUFDckUsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBQzNCLElBQUksQ0FBQywyQkFBMkIsR0FBRyxLQUFLLENBQUMsMkJBQTJCLENBQUM7WUFFckUseURBQXlEO1lBQ3pELE9BQU87WUFDUCx5REFBeUQ7WUFDekQsd0NBQXdDO1lBQ3hDLElBQUksS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUN2QixJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUM7Z0JBQy9CLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFDaEMsOEJBQThCO1lBQ2hDLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFO29CQUNyQyx1QkFBdUI7b0JBQ3ZCLFFBQVEsRUFBRSxJQUFJLENBQUMsb0JBQW9CLEVBQUUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCO29CQUM3RCx3RkFBd0Y7b0JBQ3hGLFNBQVMsRUFBRSxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLGNBQWMsQ0FBQzt3QkFDMUUsWUFBWSxFQUFFOzRCQUNaLG1CQUFtQixFQUFFLEVBQUUsR0FBRyxFQUFFLGdCQUFnQixFQUFFO3lCQUMvQzt3QkFDRCxPQUFPLEVBQUU7NEJBQ1AsZUFBZSxFQUFFLFlBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDO2dDQUN4QyxPQUFPLEVBQUUsU0FBUztnQ0FDbEIsUUFBUSxFQUFFLE9BQU87Z0NBQ2pCLFlBQVksRUFBRSxHQUFHO2dDQUNqQixTQUFTLEVBQUUsZ0JBQVMsQ0FBQyxtQkFBbUI7NkJBQ3pDLENBQUM7eUJBQ0g7cUJBQ0YsQ0FBQztpQkFDSCxDQUFDLENBQUM7Z0JBQ0gsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ2xDLENBQUM7WUFDRCx5REFBeUQ7WUFDekQsZ0NBQWdDO1lBQ2hDLHlEQUF5RDtZQUN6RCw0QkFBNEI7WUFDNUIsSUFBSSxDQUFDLGNBQWMsQ0FBQywrQkFBZ0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztZQUN2RSxJQUFJLENBQUMsY0FBYyxDQUFDLCtCQUFnQixDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO1lBRW5GLDREQUE0RDtZQUM1RCx3REFBd0Q7WUFDeEQsS0FBSyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUU7Z0JBQy9CLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDMUIsQ0FBQyxDQUFDLENBQUM7WUFFSCx3Q0FBd0M7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQztZQUNuRCxJQUFJLEtBQUssQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO2dCQUM3QixLQUFLLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRTtvQkFDbEQsSUFBSSxDQUFDLHNCQUFzQixDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNsQyxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUM7WUFFRCxJQUFJLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDcEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDckMsQ0FBQztZQUVELHlEQUF5RDtZQUN6RCxJQUFJLElBQUksQ0FBQywyQkFBMkIsRUFBRSxjQUFjLEVBQUUsQ0FBQztnQkFDckQsSUFBSSxDQUFDLDJCQUEyQixDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN2RSxJQUFJLENBQUMsMkJBQTJCLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyx1Q0FBdUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSwyQkFBMkIsQ0FBQyxFQUFFLEVBQUU7b0JBQzNKLFNBQVMsRUFBRSxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQztvQkFDNUQsU0FBUyxFQUFFLFdBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUN4RCxhQUFhLEVBQUUsRUFBRSxHQUFHLEVBQUUsZ0JBQWdCLEVBQVM7aUJBQ2hELENBQUMsQ0FBQztZQUNMLENBQUM7WUFFRCx5REFBeUQ7WUFDekQsZ0NBQWdDO1lBQ2hDLHlEQUF5RDtZQUN6RCxNQUFNLFFBQVEsR0FBMEI7Z0JBQ3RDLFlBQVksRUFBRSxXQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLENBQUM7Z0JBQzlGLFNBQVMsRUFBRSxJQUFJLENBQUMsSUFBSTtnQkFDcEIsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPO2dCQUN2QyxXQUFXLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixJQUFJLEtBQUs7Z0JBQzlDLHdCQUF3QixFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTTtnQkFDOUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXO2dCQUM5QixlQUFlLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZO2dCQUNsRCxzQkFBc0IsRUFBRSxXQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsRUFBRSxDQUFDO2dCQUMzRSx1QkFBdUIsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRTtnQkFDeEQsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXO2dCQUM5QixtQkFBbUIsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRTtnQkFDNUMsMkJBQTJCLEVBQUUsSUFBSSxDQUFDLDJCQUEyQixFQUFFLE9BQU8sRUFBRTtnQkFDeEUsOEJBQThCLEVBQUUsS0FBSyxDQUFDLFdBQVcsSUFBSSxLQUFLO2dCQUMxRCxrQkFBa0IsRUFBRSxLQUFLLENBQUMsa0JBQWtCLEVBQUUsSUFBSTtnQkFDbEQsa0JBQWtCLEVBQUUsV0FBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsRUFBRSxFQUFFLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxDQUFDO2dCQUMxRyxtQkFBbUIsRUFBRSxJQUFJLENBQUMseUJBQXlCLEVBQUU7Z0JBQ3JELGlCQUFpQixFQUFFLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsMENBQWlCLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLDBDQUFpQixDQUFDLE9BQU87YUFDekgsQ0FBQztZQUVGLHlEQUF5RDtZQUN6RCxtQkFBbUI7WUFDbkIseURBQXlEO1lBQ3pELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFFbkUsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQztZQUMzQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDO1lBQzdDLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQztZQUNyRCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO1lBRWpELHlGQUF5RjtZQUN6Rix5RUFBeUU7WUFDekUsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzFELEtBQUssQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRW5DLElBQUksQ0FBQyxTQUFTLEdBQUcsd0JBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLGNBQWMsRUFBRTtnQkFDL0QsT0FBTyxFQUFFLFlBQVk7Z0JBQ3JCLFNBQVMsRUFBRSxnQkFBZ0I7Z0JBQzNCLFlBQVksRUFBRSxPQUFPO2dCQUNyQixLQUFLLEVBQUUsSUFBSTthQUNaLENBQUMsQ0FBQztTQUNKO1FBRUQseURBQXlEO1FBQ3pELDBCQUEwQjtRQUMxQix5REFBeUQ7UUFFekQ7O1dBRUc7UUFFSSxZQUFZLENBQUMsU0FBcUI7Ozs7Ozs7Ozs7WUFDdkMsaUJBQWlCO1lBQ2pCLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQzdELDBCQUEwQjtZQUMxQixJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztZQUMzQixxQkFBcUI7WUFDckIsU0FBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDakM7UUFFRDs7Ozs7OztXQU9HO1FBRUksY0FBYyxDQUFDLFdBQTZCOzs7Ozs7Ozs7O1lBQ2pELFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLFdBQVcsQ0FBQyxDQUFDO1lBQ2pFLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3BDLG1EQUFtRDtZQUNuRCxXQUFXLENBQUMsUUFBUSxFQUFFLGNBQWMsRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzdELFdBQVcsQ0FBQyxRQUFRLEVBQUUsY0FBYyxFQUFFLGFBQWEsQ0FBQywwQkFBMEIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSwyQkFBMkIsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3BJLFNBQVMsRUFBRSxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQztnQkFDNUQsU0FBUyxFQUFFLElBQUksQ0FBQyxRQUFRO2dCQUN4QixhQUFhLEVBQUUsRUFBRSxHQUFHLEVBQUUsZ0JBQWdCLEVBQVM7YUFDaEQsQ0FBQyxDQUFDO1lBQ0gsdURBQXVEO1lBQ3ZELElBQUksV0FBVyxDQUFDLFNBQVMsWUFBWSwyQkFBYyxFQUFFLENBQUM7Z0JBQ3BELE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ2pELElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQztvQkFDeEMsTUFBTSxJQUFJLHNCQUFlLENBQUMsK0NBQStDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ25GLENBQUM7Z0JBQ0QsTUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLEVBQUUsQ0FBQztnQkFDN0IsSUFBSSxDQUFDLENBQUMsY0FBYyxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxhQUFhLElBQUksUUFBUSxDQUFDLEVBQUUsQ0FBQztvQkFDbEUsTUFBTSxJQUFJLHNCQUFlLENBQUMsOERBQThELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2xHLENBQUM7Z0JBQ0QsTUFBTSxVQUFVLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQztnQkFDekMsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQztnQkFDdkMsSUFBSSxDQUFDLFVBQVUsSUFBSSxVQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUM7b0JBQzVDLE1BQU0sSUFBSSxzQkFBZSxDQUFDLGtEQUFrRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN0RixDQUFDO2dCQUNELElBQUksQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDO29CQUMxQyxNQUFNLElBQUksc0JBQWUsQ0FBQyxpREFBaUQsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDckYsQ0FBQztnQkFDRCxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxXQUFXLENBQUMsSUFBSSxjQUFjLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBQzdGLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztZQUN6QyxDQUFDO2lCQUFNLElBQUksV0FBVyxDQUFDLFNBQVMsWUFBWSx3QkFBVyxFQUFFLENBQUM7Z0JBQ3hELE1BQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2dCQUM1QyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQ1osTUFBTSxJQUFJLHNCQUFlLENBQUMsaURBQWlELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3JGLENBQUM7Z0JBQ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLElBQUksTUFBTSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQztvQkFDMUQsTUFBTSxJQUFJLHNCQUFlLENBQUMsK0NBQStDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ25GLENBQUM7Z0JBQ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQztvQkFDeEQsTUFBTSxJQUFJLHNCQUFlLENBQUMsOENBQThDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2xGLENBQUM7Z0JBQ0QsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLEdBQUcsV0FBVyxDQUFDLElBQUksY0FBYyxFQUFFLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDcEcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNoRCxDQUFDO1NBQ0Y7UUFFRDs7Ozs7OztXQU9HO1FBQ0ssc0JBQXNCLENBQUMsaUJBQW9DO1lBQ2pFLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDcEM7UUFFRDs7OztXQUlHO1FBRUksZUFBZSxDQUFDLEdBQUcsWUFBZ0M7Ozs7Ozs7Ozs7WUFDeEQsWUFBWSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUNyRDtRQUVELHlEQUF5RDtRQUN6RCxpQkFBaUI7UUFDakIseURBQXlEO1FBRXpEOzs7O1dBSUc7UUFDSyxlQUFlO1lBQ3JCLE9BQU8sSUFBSSxDQUFDLFNBQVM7Z0JBQ25CLENBQUMsQ0FBQztvQkFDQSxtQkFBbUIsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVc7b0JBQy9DLGdCQUFnQixFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCO2lCQUNsRDtnQkFDRCxDQUFDLENBQUMsU0FBUyxDQUFDO1NBQ2Y7UUFFRDs7Ozs7O1dBTUc7UUFDSyxrQkFBa0I7WUFDeEIsTUFBTSxlQUFlLEdBQWdELEVBQUUsQ0FBQztZQUN4RSwyQ0FBMkM7WUFDM0MsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUU7Z0JBQzdCLGVBQWUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFDckMsQ0FBQyxDQUFDLENBQUM7WUFDSCxPQUFPLGVBQWUsQ0FBQztTQUN4QjtRQUVEOzs7Ozs7V0FNRztRQUNLLHdCQUF3QjtZQUM5QixJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQixJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFDN0gsT0FBTyxTQUFTLENBQUM7WUFDbkIsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztTQUN0RTtRQUVEOzs7Ozs7V0FNRztRQUNLLHlCQUF5QjtZQUMvQixJQUFJLENBQUMsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7Z0JBQ3RDLE9BQU8sU0FBUyxDQUFDO1lBQ25CLENBQUM7WUFFRCxPQUFPO2dCQUNMLFFBQVEsRUFBRTtvQkFDUixNQUFNLEVBQUUsSUFBSSxDQUFDLDJCQUEyQixDQUFDLGNBQWMsQ0FBQyxXQUFXO2lCQUNwRTthQUNGLENBQUM7U0FDSDtRQUVELHlEQUF5RDtRQUN6RCxhQUFhO1FBQ2IseURBQXlEO1FBQ3pEOzs7OztXQUtHO1FBQ0ssaUJBQWlCLEdBQUcsQ0FBQyxTQUFxQixFQUFFLEVBQUU7WUFDcEQsSUFBSSxNQUFNLEdBQWEsRUFBRSxDQUFDO1lBQzFCLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUNuQixNQUFNLENBQUMsSUFBSSxDQUNULHdCQUF3QixTQUFTLENBQUMsV0FBVyxJQUFJO29CQUMvQyxhQUFhLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyw2Q0FBNkMsQ0FDdkYsQ0FBQztZQUNKLENBQUM7WUFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsVUFBVSxDQUFDLG9CQUFvQixDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsRUFBRSxTQUFTLEVBQUUsMEJBQTBCLENBQUMsQ0FBQyxDQUFDO1lBQ25ILE9BQU8sTUFBTSxDQUFDO1FBQ2hCLENBQUMsQ0FBQztRQUVGOzs7OztXQUtHO1FBQ0ssbUJBQW1CLEdBQUcsQ0FBQyxXQUE2QixFQUFFLEVBQUU7WUFDOUQsSUFBSSxNQUFNLEdBQWEsRUFBRSxDQUFDO1lBQzFCLG1EQUFtRDtZQUNuRCxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztnQkFDaEUsTUFBTSxDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1lBQzdDLENBQUM7WUFDRCxPQUFPLE1BQU0sQ0FBQztRQUNoQixDQUFDLENBQUM7UUFFRjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztXQW1CRztRQUNLLHdCQUF3QixDQUM5QixLQUFpQixFQUNqQixNQUFjLEVBQ2QsT0FNQztZQUVELE1BQU0sWUFBWSxHQUFHLENBQUMsR0FBUSxFQUFVLEVBQUU7Z0JBQ3hDLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUFDLENBQUM7Z0JBQ3JDLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3ZDLE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3pDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUMzRCxDQUFDLENBQUM7WUFFRixNQUFNLEVBQ0osU0FBUyxHQUFHLEdBQUcsRUFDZixLQUFLLEdBQUcsS0FBSyxFQUNiLFNBQVMsR0FBRyxFQUFFLEVBQ2Qsd0JBQXdCLEdBQUcsU0FBUyxFQUNwQyxhQUFhLEdBQUcsU0FBUyxHQUMxQixHQUFHLE9BQU8sSUFBSSxFQUFFLENBQUM7WUFFbEIsTUFBTSxJQUFJLEdBQUcsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3pDLElBQUksU0FBUyxHQUFHLENBQUMsTUFBTSxHQUFHLElBQUksR0FBRyxTQUFTLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFDbkQsTUFBTSxJQUFJLHNCQUFlLENBQUMsK0NBQStDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDbkYsQ0FBQztZQUVELE1BQU0sVUFBVSxHQUFHLFlBQUssQ0FBQyxrQkFBa0IsQ0FDekMsS0FBSyxFQUNMLEVBQUUsU0FBUyxFQUFFLFNBQVMsR0FBRyxDQUFDLE1BQU0sR0FBRyxJQUFJLEdBQUcsU0FBUyxDQUFDLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSx3QkFBd0IsRUFBRSxDQUNuRyxDQUFDO1lBQ0YsTUFBTSxJQUFJLEdBQUcsR0FBRyxNQUFNLEdBQUcsSUFBSSxHQUFHLFNBQVMsR0FBRyxVQUFVLEVBQUUsQ0FBQztZQUN6RCxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsU0FBUyxFQUFFLENBQUM7Z0JBQzVCLE1BQU0sSUFBSSxzQkFBZSxDQUFDLDJEQUEyRCxTQUFTLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUMxRyxDQUFDO1lBQ0QsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1NBQzFDO1FBRUQ7Ozs7Ozs7O1dBUUc7UUFDTyxvQkFBb0I7WUFDNUIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUM7WUFDOUUsT0FBTyxJQUFJLENBQUMsd0JBQXdCLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRTtnQkFDbEQsU0FBUztnQkFDVCxLQUFLLEVBQUUsSUFBSTtnQkFDWCxTQUFTLEVBQUUsR0FBRzthQUNmLENBQUMsQ0FBQztTQUNKOztZQTFnQlUsdURBQUs7Ozs7O0FBQUwsc0JBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBjcnlwdG8gZnJvbSAnY3J5cHRvJztcbmltcG9ydCAqIGFzIGJlZHJvY2sgZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0ICogYXMgY2xvdWR3YXRjaCBmcm9tICdhd3MtY2RrLWxpYi9hd3MtY2xvdWR3YXRjaCc7XG5pbXBvcnQgKiBhcyBldmVudHMgZnJvbSAnYXdzLWNkay1saWIvYXdzLWV2ZW50cyc7XG5pbXBvcnQgKiBhcyBpYW0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWlhbSc7XG5pbXBvcnQgKiBhcyBrbXMgZnJvbSAnYXdzLWNkay1saWIvYXdzLWttcyc7XG5pbXBvcnQgKiBhcyBzMyBmcm9tICdhd3MtY2RrLWxpYi9hd3MtczMnO1xuaW1wb3J0IHR5cGUgeyBJUmVzb3VyY2UgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlJztcbmltcG9ydCB7IEFybiwgQXJuRm9ybWF0LCBEdXJhdGlvbiwgTGF6eSwgTmFtZXMsIFJlc291cmNlLCBTdGFjaywgVG9rZW4sIFZhbGlkYXRpb25FcnJvciB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUnO1xuaW1wb3J0IHsgYWRkQ29uc3RydWN0TWV0YWRhdGEsIE1ldGhvZE1ldGFkYXRhIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvbWV0YWRhdGEtcmVzb3VyY2UnO1xuaW1wb3J0IHsgcHJvcGVydHlJbmplY3RhYmxlIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvcHJvcC1pbmplY3RhYmxlJztcbmltcG9ydCB0eXBlIHsgQ29uc3RydWN0LCBJQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG4vLyBJbnRlcm5hbCBMaWJzXG5pbXBvcnQgeyBBZ2VudEFjdGlvbkdyb3VwIH0gZnJvbSAnLi9hY3Rpb24tZ3JvdXAnO1xuaW1wb3J0IHR5cGUgeyBJQWdlbnRBbGlhcyB9IGZyb20gJy4vYWdlbnQtYWxpYXMnO1xuaW1wb3J0IHsgQWdlbnRBbGlhcyB9IGZyb20gJy4vYWdlbnQtYWxpYXMnO1xuaW1wb3J0IHR5cGUgeyBBZ2VudENvbGxhYm9yYXRpb24gfSBmcm9tICcuL2FnZW50LWNvbGxhYm9yYXRpb24nO1xuaW1wb3J0IHR5cGUgeyBBZ2VudENvbGxhYm9yYXRvciB9IGZyb20gJy4vYWdlbnQtY29sbGFib3JhdG9yJztcbmltcG9ydCB7IEFzc2V0QXBpU2NoZW1hLCBTM0FwaVNjaGVtYSB9IGZyb20gJy4vYXBpLXNjaGVtYSc7XG5pbXBvcnQgdHlwZSB7IE1lbW9yeSB9IGZyb20gJy4vbWVtb3J5JztcbmltcG9ydCB0eXBlIHsgQ3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yIH0gZnJvbSAnLi9vcmNoZXN0cmF0aW9uLWV4ZWN1dG9yJztcbmltcG9ydCB7IE9yY2hlc3RyYXRpb25UeXBlIH0gZnJvbSAnLi9vcmNoZXN0cmF0aW9uLWV4ZWN1dG9yJztcbmltcG9ydCB0eXBlIHsgUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uIH0gZnJvbSAnLi9wcm9tcHQtb3ZlcnJpZGUnO1xuaW1wb3J0ICogYXMgdmFsaWRhdGlvbiBmcm9tICcuL3ZhbGlkYXRpb24taGVscGVycyc7XG5pbXBvcnQgdHlwZSB7IElCZWRyb2NrSW52b2thYmxlIH0gZnJvbSAnLi4vLi9tb2RlbHMnO1xuaW1wb3J0IHR5cGUgeyBJR3VhcmRyYWlsIH0gZnJvbSAnLi4vZ3VhcmRyYWlscy9ndWFyZHJhaWxzJztcblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDT05TVEFOVFNcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogVGhlIG1pbmltdW0gbnVtYmVyIG9mIGNoYXJhY3RlcnMgcmVxdWlyZWQgZm9yIGFuIGFnZW50IGluc3RydWN0aW9uLlxuICogQGludGVybmFsXG4gKi9cbmNvbnN0IE1JTl9JTlNUUlVDVElPTl9MRU5HVEggPSA0MDtcblxuLyoqXG4gKiBUaGUgbWF4aW11bSBsZW5ndGggZm9yIHRoZSBub2RlIGFkZHJlc3MgaW4gcGVybWlzc2lvbiBwb2xpY3kgbmFtZXMuXG4gKiBAaW50ZXJuYWxcbiAqL1xuY29uc3QgTUFYX1BPTElDWV9OQU1FX05PREVfTEVOR1RIID0gMTY7XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ09NTU9OXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIFJlcHJlc2VudHMgYW4gQWdlbnQsIGVpdGhlciBjcmVhdGVkIHdpdGggQ0RLIG9yIGltcG9ydGVkLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIElBZ2VudCBleHRlbmRzIElSZXNvdXJjZSwgaWFtLklHcmFudGFibGUge1xuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgYWdlbnQuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHJlYWRvbmx5IGFnZW50QXJuOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgSUQgb2YgdGhlIEFnZW50LlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICByZWFkb25seSBhZ2VudElkOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgSUFNIHJvbGUgYXNzb2NpYXRlZCB0byB0aGUgYWdlbnQuXG4gICAqL1xuICByZWFkb25seSByb2xlOiBpYW0uSVJvbGU7XG4gIC8qKlxuICAgKiBPcHRpb25hbCBLTVMgZW5jcnlwdGlvbiBrZXkgYXNzb2NpYXRlZCB3aXRoIHRoaXMgYWdlbnRcbiAgICovXG4gIHJlYWRvbmx5IGttc0tleT86IGttcy5JS2V5O1xuICAvKipcbiAgICogV2hlbiB0aGlzIGFnZW50IHdhcyBsYXN0IHVwZGF0ZWQuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHJlYWRvbmx5IGxhc3RVcGRhdGVkPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBHcmFudCBpbnZva2UgcGVybWlzc2lvbnMgb24gdGhpcyBhZ2VudCB0byBhbiBJQU0gcHJpbmNpcGFsLlxuICAgKiBOb3RlOiBUaGlzIGdyYW50IHdpbGwgb25seSB3b3JrIHdoZW4gdGhlIGdyYW50ZWUgaXMgaW4gdGhlIHNhbWUgQVdTIGFjY291bnRcbiAgICogd2hlcmUgdGhlIGFnZW50IGlzIGRlZmluZWQuIENyb3NzLWFjY291bnQgaW52b2NhdGlvbiBpcyBub3Qgc3VwcG9ydGVkLlxuICAgKi9cbiAgZ3JhbnRJbnZva2UoZ3JhbnRlZTogaWFtLklHcmFudGFibGUpOiBpYW0uR3JhbnQ7XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYSBDbG91ZFdhdGNoIGV2ZW50IHJ1bGUgdHJpZ2dlcmVkIGJ5IGFnZW50IGV2ZW50cy5cbiAgICovXG4gIG9uRXZlbnQoaWQ6IHN0cmluZywgb3B0aW9ucz86IGV2ZW50cy5PbkV2ZW50T3B0aW9ucyk6IGV2ZW50cy5SdWxlO1xuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIENsb3VkV2F0Y2ggbWV0cmljIGZvciBhZ2VudCBjb3VudC5cbiAgICovXG4gIG1ldHJpY0NvdW50KHByb3BzPzogY2xvdWR3YXRjaC5NZXRyaWNPcHRpb25zKTogY2xvdWR3YXRjaC5NZXRyaWM7XG59XG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIEFCU1RSQUNUIEJBU0UgQ0xBU1NcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogQWJzdHJhY3QgYmFzZSBjbGFzcyBmb3IgYW4gQWdlbnQuXG4gKiBDb250YWlucyBtZXRob2RzIGFuZCBhdHRyaWJ1dGVzIHZhbGlkIGZvciBBZ2VudHMgZWl0aGVyIGNyZWF0ZWQgd2l0aCBDREsgb3IgaW1wb3J0ZWQuXG4gKi9cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBBZ2VudEJhc2UgZXh0ZW5kcyBSZXNvdXJjZSBpbXBsZW1lbnRzIElBZ2VudCB7XG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSBhZ2VudEFybjogc3RyaW5nO1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkgYWdlbnRJZDogc3RyaW5nO1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkgcm9sZTogaWFtLklSb2xlO1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkga21zS2V5Pzoga21zLklLZXk7XG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSBsYXN0VXBkYXRlZD86IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSB2ZXJzaW9uIG9mIHRoZSBhZ2VudC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGFnZW50VmVyc2lvbjogc3RyaW5nO1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkgZ3JhbnRQcmluY2lwYWw6IGlhbS5JUHJpbmNpcGFsO1xuXG4gIC8qKlxuICAgKiBHcmFudCBpbnZva2UgcGVybWlzc2lvbnMgb24gdGhpcyBhZ2VudCB0byBhbiBJQU0gcHJpbmNpcGFsLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICpcbiAgICogQHBhcmFtIGdyYW50ZWUgLSBUaGUgSUFNIHByaW5jaXBhbCB0byBncmFudCBpbnZva2UgcGVybWlzc2lvbnMgdG9cbiAgICogQGRlZmF1bHQgLSBEZWZhdWx0IGdyYW50IGNvbmZpZ3VyYXRpb246XG4gICAqIC0gYWN0aW9uczogWydiZWRyb2NrOkludm9rZUFnZW50J11cbiAgICogLSByZXNvdXJjZUFybnM6IFt0aGlzLmFnZW50QXJuXVxuICAgKiBAcmV0dXJucyBBbiBJQU0gR3JhbnQgb2JqZWN0IHJlcHJlc2VudGluZyB0aGUgZ3JhbnRlZCBwZXJtaXNzaW9uc1xuICAgKi9cbiAgcHVibGljIGdyYW50SW52b2tlKGdyYW50ZWU6IGlhbS5JR3JhbnRhYmxlKTogaWFtLkdyYW50IHtcbiAgICByZXR1cm4gaWFtLkdyYW50LmFkZFRvUHJpbmNpcGFsKHtcbiAgICAgIGdyYW50ZWUsXG4gICAgICBhY3Rpb25zOiBbJ2JlZHJvY2s6SW52b2tlQWdlbnQnXSxcbiAgICAgIHJlc291cmNlQXJuczogW3RoaXMuYWdlbnRBcm5dLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYW4gRXZlbnRCcmlkZ2UgcnVsZSBmb3IgYWdlbnQgZXZlbnRzLlxuICAgKlxuICAgKiBAcGFyYW0gaWQgLSBVbmlxdWUgaWRlbnRpZmllciBmb3IgdGhlIHJ1bGVcbiAgICogQHBhcmFtIG9wdGlvbnMgLSBDb25maWd1cmF0aW9uIG9wdGlvbnMgZm9yIHRoZSBldmVudCBydWxlXG4gICAqIEBkZWZhdWx0IC0gRGVmYXVsdCBldmVudCBwYXR0ZXJuOlxuICAgKiAtIHNvdXJjZTogWydhd3MuYmVkcm9jayddXG4gICAqIC0gZGV0YWlsOiB7ICdhZ2VudC1pZCc6IFt0aGlzLmFnZW50SWRdIH1cbiAgICogQHJldHVybnMgQW4gRXZlbnRCcmlkZ2UgUnVsZSBjb25maWd1cmVkIGZvciBhZ2VudCBldmVudHNcbiAgICovXG4gIHB1YmxpYyBvbkV2ZW50KGlkOiBzdHJpbmcsIG9wdGlvbnM6IGV2ZW50cy5PbkV2ZW50T3B0aW9ucyA9IHt9KTogZXZlbnRzLlJ1bGUge1xuICAgIGNvbnN0IHJ1bGUgPSBuZXcgZXZlbnRzLlJ1bGUodGhpcywgaWQsIG9wdGlvbnMpO1xuICAgIHJ1bGUuYWRkRXZlbnRQYXR0ZXJuKHtcbiAgICAgIHNvdXJjZTogWydhd3MuYmVkcm9jayddLFxuICAgICAgZGV0YWlsOiB7XG4gICAgICAgICdhZ2VudC1pZCc6IFt0aGlzLmFnZW50SWRdLFxuICAgICAgfSxcbiAgICB9KTtcblxuICAgIHJ1bGUuYWRkVGFyZ2V0KG9wdGlvbnMudGFyZ2V0KTtcbiAgICByZXR1cm4gcnVsZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgQ2xvdWRXYXRjaCBtZXRyaWMgZm9yIHRyYWNraW5nIGFnZW50IGludm9jYXRpb25zLlxuICAgKlxuICAgKiBAcGFyYW0gcHJvcHMgLSBDb25maWd1cmF0aW9uIG9wdGlvbnMgZm9yIHRoZSBtZXRyaWNcbiAgICogQGRlZmF1bHQgLSBEZWZhdWx0IG1ldHJpYyBjb25maWd1cmF0aW9uOlxuICAgKiAtIG5hbWVzcGFjZTogJ0FXUy9CZWRyb2NrJ1xuICAgKiAtIG1ldHJpY05hbWU6ICdJbnZvY2F0aW9ucydcbiAgICogLSBkaW1lbnNpb25zTWFwOiB7IEFnZW50SWQ6IHRoaXMuYWdlbnRJZCB9XG4gICAqIEByZXR1cm5zIEEgQ2xvdWRXYXRjaCBNZXRyaWMgY29uZmlndXJlZCBmb3IgYWdlbnQgaW52b2NhdGlvbiBjb3VudHNcbiAgICovXG4gIHB1YmxpYyBtZXRyaWNDb3VudChwcm9wcz86IGNsb3Vkd2F0Y2guTWV0cmljT3B0aW9ucyk6IGNsb3Vkd2F0Y2guTWV0cmljIHtcbiAgICByZXR1cm4gbmV3IGNsb3Vkd2F0Y2guTWV0cmljKHtcbiAgICAgIG5hbWVzcGFjZTogJ0FXUy9CZWRyb2NrJyxcbiAgICAgIG1ldHJpY05hbWU6ICdJbnZvY2F0aW9ucycsXG4gICAgICBkaW1lbnNpb25zTWFwOiB7XG4gICAgICAgIEFnZW50SWQ6IHRoaXMuYWdlbnRJZCxcbiAgICAgIH0sXG4gICAgICAuLi5wcm9wcyxcbiAgICB9KS5hdHRhY2hUbyh0aGlzKTtcbiAgfVxufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIFBST1BTIEZPUiBORVcgQ09OU1RSVUNUXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNyZWF0aW5nIGEgQ0RLIG1hbmFnZWQgQmVkcm9jayBBZ2VudC5cbiAqIFRPRE86IEtub3dsZWRnZSBiYXNlcyBjb25maWd1cmF0aW9uIHdpbGwgYmUgYWRkZWQgaW4gYSBmdXR1cmUgdXBkYXRlXG4gKiBUT0RPOiBJbmZlcmVuY2UgcHJvZmlsZSBjb25maWd1cmF0aW9uIHdpbGwgYmUgYWRkZWQgaW4gYSBmdXR1cmUgdXBkYXRlXG4gKlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFnZW50UHJvcHMge1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgYWdlbnQuXG4gICAqIFRoaXMgd2lsbCBiZSB1c2VkIGFzIHRoZSBwaHlzaWNhbCBuYW1lIG9mIHRoZSBhZ2VudC5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBBIG5hbWUgaXMgZ2VuZXJhdGVkIGJ5IENESy5cbiAgICogU3VwcG9ydGVkIHBhdHRlcm4gOiBeKFswLTlhLXpBLVpdW18tXT8pezEsMTAwfSRcbiAgICovXG4gIHJlYWRvbmx5IGFnZW50TmFtZT86IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBpbnN0cnVjdGlvbiB1c2VkIGJ5IHRoZSBhZ2VudC4gVGhpcyBkZXRlcm1pbmVzIGhvdyB0aGUgYWdlbnQgd2lsbCBwZXJmb3JtIGhpcyB0YXNrLlxuICAgKiBUaGlzIGluc3RydWN0aW9uIG11c3QgaGF2ZSBhIG1pbmltdW0gb2YgNDAgY2hhcmFjdGVycy5cbiAgICovXG4gIHJlYWRvbmx5IGluc3RydWN0aW9uOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgZm91bmRhdGlvbiBtb2RlbCB1c2VkIGZvciBvcmNoZXN0cmF0aW9uIGJ5IHRoZSBhZ2VudC5cbiAgICovXG4gIHJlYWRvbmx5IGZvdW5kYXRpb25Nb2RlbDogSUJlZHJvY2tJbnZva2FibGU7XG4gIC8qKlxuICAgKiBBbiBleGlzdGluZyBJQU0gUm9sZSB0byBhc3NvY2lhdGUgd2l0aCB0aGlzIGFnZW50LlxuICAgKiBVc2UgdGhpcyBwcm9wZXJ0eSB3aGVuIHlvdSB3YW50IHRvIHJldXNlIGFuIGV4aXN0aW5nIElBTSByb2xlIHJhdGhlciB0aGFuIGNyZWF0ZSBhIG5ldyBvbmUuXG4gICAqIFRoZSByb2xlIG11c3QgaGF2ZSBhIHRydXN0IHBvbGljeSB0aGF0IGFsbG93cyB0aGUgQmVkcm9jayBzZXJ2aWNlIHRvIGFzc3VtZSBpdC5cbiAgICogQGRlZmF1bHQgLSBBIG5ldyByb2xlIGlzIGNyZWF0ZWQgZm9yIHlvdS5cbiAgICovXG4gIHJlYWRvbmx5IGV4aXN0aW5nUm9sZT86IGlhbS5JUm9sZTtcbiAgLyoqXG4gICAqIFNwZWNpZmllcyB3aGV0aGVyIHRvIGF1dG9tYXRpY2FsbHkgdXBkYXRlIHRoZSBgRFJBRlRgIHZlcnNpb24gb2YgdGhlIGFnZW50IGFmdGVyXG4gICAqIG1ha2luZyBjaGFuZ2VzIHRvIHRoZSBhZ2VudC4gVGhlIGBEUkFGVGAgdmVyc2lvbiBjYW4gYmUgY29udGludWFsbHkgaXRlcmF0ZWRcbiAgICogdXBvbiBkdXJpbmcgaW50ZXJuYWwgZGV2ZWxvcG1lbnQuXG4gICAqXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICByZWFkb25seSBzaG91bGRQcmVwYXJlQWdlbnQ/OiBib29sZWFuO1xuICAvKipcbiAgICogSG93IGxvbmcgc2Vzc2lvbnMgc2hvdWxkIGJlIGtlcHQgb3BlbiBmb3IgdGhlIGFnZW50LiBJZiBubyBjb252ZXJzYXRpb24gb2NjdXJzXG4gICAqIGR1cmluZyB0aGlzIHRpbWUsIHRoZSBzZXNzaW9uIGV4cGlyZXMgYW5kIEFtYXpvbiBCZWRyb2NrIGRlbGV0ZXMgYW55IGRhdGFcbiAgICogcHJvdmlkZWQgYmVmb3JlIHRoZSB0aW1lb3V0LlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIDEwIG1pbnV0ZXNcbiAgICovXG4gIHJlYWRvbmx5IGlkbGVTZXNzaW9uVFRMPzogRHVyYXRpb247XG4gIC8qKlxuICAgKiBUaGUgS01TIGtleSBvZiB0aGUgYWdlbnQgaWYgY3VzdG9tIGVuY3J5cHRpb24gaXMgY29uZmlndXJlZC5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBBbiBBV1MgbWFuYWdlZCBrZXkgaXMgdXNlZC5cbiAgICovXG4gIHJlYWRvbmx5IGttc0tleT86IGttcy5JS2V5O1xuICAvKipcbiAgICogQSBkZXNjcmlwdGlvbiBvZiB0aGUgYWdlbnQuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTm8gZGVzY3JpcHRpb24gaXMgcHJvdmlkZWQuXG4gICAqL1xuICByZWFkb25seSBkZXNjcmlwdGlvbj86IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBBY3Rpb24gR3JvdXBzIGFzc29jaWF0ZWQgd2l0aCB0aGUgYWdlbnQuXG4gICAqIEBkZWZhdWx0IC0gT25seSBkZWZhdWx0IGFjdGlvbiBncm91cHMgKFVzZXJJbnB1dCBhbmQgQ29kZUludGVycHJldGVyKSBhcmUgYWRkZWRcbiAgICovXG4gIHJlYWRvbmx5IGFjdGlvbkdyb3Vwcz86IEFnZW50QWN0aW9uR3JvdXBbXTtcbiAgLyoqXG4gICAqIFRoZSBndWFyZHJhaWwgdGhhdCB3aWxsIGJlIGFzc29jaWF0ZWQgd2l0aCB0aGUgYWdlbnQuXG4gICAqIEBkZWZhdWx0IC0gTm8gZ3VhcmRyYWlsIGlzIHByb3ZpZGVkLlxuICAgKi9cbiAgcmVhZG9ubHkgZ3VhcmRyYWlsPzogSUd1YXJkcmFpbDtcbiAgLyoqXG4gICAqIE92ZXJyaWRlcyBzb21lIHByb21wdCB0ZW1wbGF0ZXMgaW4gZGlmZmVyZW50IHBhcnRzIG9mIGFuIGFnZW50IHNlcXVlbmNlIGNvbmZpZ3VyYXRpb24uXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTm8gb3ZlcnJpZGVzIGFyZSBwcm92aWRlZC5cbiAgICovXG4gIHJlYWRvbmx5IHByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbj86IFByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbjtcbiAgLyoqXG4gICAqIFNlbGVjdCB3aGV0aGVyIHRoZSBhZ2VudCBjYW4gcHJvbXB0IGFkZGl0aW9uYWwgaW5mb3JtYXRpb24gZnJvbSB0aGUgdXNlciB3aGVuIGl0IGRvZXMgbm90IGhhdmVcbiAgICogZW5vdWdoIGluZm9ybWF0aW9uIHRvIHJlc3BvbmQgdG8gYW4gdXR0ZXJhbmNlXG4gICAqXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICByZWFkb25seSB1c2VySW5wdXRFbmFibGVkPzogYm9vbGVhbjtcbiAgLyoqXG4gICAqIFNlbGVjdCB3aGV0aGVyIHRoZSBhZ2VudCBjYW4gZ2VuZXJhdGUsIHJ1biwgYW5kIHRyb3VibGVzaG9vdCBjb2RlIHdoZW4gdHJ5aW5nIHRvIGNvbXBsZXRlIGEgdGFza1xuICAgKlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgcmVhZG9ubHkgY29kZUludGVycHJldGVyRW5hYmxlZD86IGJvb2xlYW47XG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIGRlbGV0ZSB0aGUgcmVzb3VyY2UgZXZlbiBpZiBpdCdzIGluIHVzZS5cbiAgICpcbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIHJlYWRvbmx5IGZvcmNlRGVsZXRlPzogYm9vbGVhbjtcbiAgLyoqXG4gICAqIFRoZSB0eXBlIGFuZCBjb25maWd1cmF0aW9uIG9mIHRoZSBtZW1vcnkgdG8gbWFpbnRhaW4gY29udGV4dCBhY3Jvc3MgbXVsdGlwbGUgc2Vzc2lvbnMgYW5kIHJlY2FsbCBwYXN0IGludGVyYWN0aW9ucy5cbiAgICogVGhpcyBjYW4gYmUgdXNlZnVsIGZvciBtYWludGFpbmluZyBjb250aW51aXR5IGluIG11bHRpLXR1cm4gY29udmVyc2F0aW9ucyBhbmQgcmVjYWxsaW5nIHVzZXIgcHJlZmVyZW5jZXNcbiAgICogb3IgcGFzdCBpbnRlcmFjdGlvbnMuXG4gICAqXG4gICAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9hZ2VudHMtbWVtb3J5Lmh0bWxcbiAgICogQGRlZmF1bHQgLSBObyBtZW1vcnkgd2lsbCBiZSB1c2VkLiBBZ2VudHMgd2lsbCByZXRhaW4gY29udGV4dCBmcm9tIHRoZSBjdXJyZW50IHNlc3Npb24gb25seS5cbiAgICovXG4gIHJlYWRvbmx5IG1lbW9yeT86IE1lbW9yeTtcbiAgLyoqXG4gICAqIENvbmZpZ3VyYXRpb24gZm9yIGFnZW50IGNvbGxhYm9yYXRpb24gc2V0dGluZ3MsIGluY2x1ZGluZyBBZ2VudENvbGxhYm9yYXRvclR5cGUgYW5kIEFnZW50Q29sbGFib3JhdG9ycy5cbiAgICogVGhpcyBwcm9wZXJ0eSBhbGxvd3MgeW91IHRvIGRlZmluZSBob3cgdGhlIGFnZW50IGNvbGxhYm9yYXRlcyB3aXRoIG90aGVyIGFnZW50c1xuICAgKiBhbmQgd2hhdCBjb2xsYWJvcmF0b3JzIGl0IGNhbiB3b3JrIHdpdGguXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTm8gYWdlbnQgY29sbGFib3JhdGlvbiBjb25maWd1cmF0aW9uLlxuICAgKi9cbiAgcmVhZG9ubHkgYWdlbnRDb2xsYWJvcmF0aW9uPzogQWdlbnRDb2xsYWJvcmF0aW9uO1xuICAvKipcbiAgICogVGhlIExhbWJkYSBmdW5jdGlvbiB0byB1c2UgZm9yIGN1c3RvbSBvcmNoZXN0cmF0aW9uLlxuICAgKiBJZiBwcm92aWRlZCwgY3VzdG9tIG9yY2hlc3RyYXRpb24gd2lsbCBiZSB1c2VkLlxuICAgKiBJZiBub3QgcHJvdmlkZWQsIGRlZmF1bHQgb3JjaGVzdHJhdGlvbiB3aWxsIGJlIHVzZWQuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gRGVmYXVsdCBvcmNoZXN0cmF0aW9uXG4gICAqL1xuICByZWFkb25seSBjdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3I/OiBDdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3I7XG59XG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICBBVFRSUyBGT1IgSU1QT1JURUQgQ09OU1RSVUNUXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIEF0dHJpYnV0ZXMgZm9yIHNwZWNpZnlpbmcgYW4gaW1wb3J0ZWQgQmVkcm9jayBBZ2VudC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBBZ2VudEF0dHJpYnV0ZXMge1xuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgYWdlbnQuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHJlYWRvbmx5IGFnZW50QXJuOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBJQU0gcm9sZSBhc3NvY2lhdGVkIHRvIHRoZSBhZ2VudC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcmVhZG9ubHkgcm9sZUFybjogc3RyaW5nO1xuICAvKipcbiAgICogT3B0aW9uYWwgS01TIGVuY3J5cHRpb24ga2V5IGFzc29jaWF0ZWQgd2l0aCB0aGlzIGFnZW50XG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIEFuIEFXUyBtYW5hZ2VkIGtleSBpcyB1c2VkXG4gICAqL1xuICByZWFkb25seSBrbXNLZXlBcm4/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBXaGVuIHRoaXMgYWdlbnQgd2FzIGxhc3QgdXBkYXRlZC5cbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8gbGFzdCB1cGRhdGVkIHRpbWVzdGFtcCBpcyBwcm92aWRlZFxuICAgKi9cbiAgcmVhZG9ubHkgbGFzdFVwZGF0ZWQ/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgYWdlbnQgdmVyc2lvbi4gSWYgbm8gZXhwbGljaXQgdmVyc2lvbnMgaGF2ZSBiZWVuIGNyZWF0ZWQsXG4gICAqIGxlYXZlIHRoaXMgZW1wdHkgdG8gdXNlIHRoZSBEUkFGVCB2ZXJzaW9uLiBPdGhlcndpc2UsIHVzZSB0aGVcbiAgICogdmVyc2lvbiBudW1iZXIgKGUuZy4gMSkuXG4gICAqIEBkZWZhdWx0ICdEUkFGVCdcbiAgICovXG4gIHJlYWRvbmx5IGFnZW50VmVyc2lvbj86IHN0cmluZztcbn1cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgTkVXIENPTlNUUlVDVCBERUZJTklUSU9OXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIENsYXNzIHRvIGNyZWF0ZSAob3IgaW1wb3J0KSBhbiBBZ2VudCB3aXRoIENESy5cbiAqIEBjbG91ZGZvcm1hdGlvblJlc291cmNlIEFXUzo6QmVkcm9jazo6QWdlbnRcbiAqL1xuQHByb3BlcnR5SW5qZWN0YWJsZVxuZXhwb3J0IGNsYXNzIEFnZW50IGV4dGVuZHMgQWdlbnRCYXNlIGltcGxlbWVudHMgSUFnZW50IHtcbiAgLyoqIFVuaXF1ZWx5IGlkZW50aWZpZXMgdGhpcyBjbGFzcy4gKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBQUk9QRVJUWV9JTkpFQ1RJT05fSUQ6IHN0cmluZyA9ICdAYXdzLWNkay5hd3MtYmVkcm9jay1hbHBoYS5BZ2VudCc7XG5cbiAgLyoqXG4gICAqIFN0YXRpYyBNZXRob2QgZm9yIGltcG9ydGluZyBhbiBleGlzdGluZyBCZWRyb2NrIEFnZW50LlxuICAgKi9cbiAgLyoqXG4gICAqIENyZWF0ZXMgYW4gQWdlbnQgcmVmZXJlbmNlIGZyb20gYW4gZXhpc3RpbmcgYWdlbnQncyBhdHRyaWJ1dGVzLlxuICAgKlxuICAgKiBAcGFyYW0gc2NvcGUgLSBUaGUgY29uc3RydWN0IHNjb3BlXG4gICAqIEBwYXJhbSBpZCAtIElkZW50aWZpZXIgb2YgdGhlIGNvbnN0cnVjdFxuICAgKiBAcGFyYW0gYXR0cnMgLSBBdHRyaWJ1dGVzIG9mIHRoZSBleGlzdGluZyBhZ2VudFxuICAgKiBAZGVmYXVsdCAtIEZvciBhdHRycy5hZ2VudFZlcnNpb246ICdEUkFGVCcgaWYgbm8gZXhwbGljaXQgdmVyc2lvbiBpcyBwcm92aWRlZFxuICAgKiBAcmV0dXJucyBBbiBJQWdlbnQgcmVmZXJlbmNlIHRvIHRoZSBleGlzdGluZyBhZ2VudFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tQWdlbnRBdHRyaWJ1dGVzKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIGF0dHJzOiBBZ2VudEF0dHJpYnV0ZXMpOiBJQWdlbnQge1xuICAgIGNsYXNzIEltcG9ydCBleHRlbmRzIEFnZW50QmFzZSB7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgYWdlbnRBcm4gPSBhdHRycy5hZ2VudEFybjtcbiAgICAgIHB1YmxpYyByZWFkb25seSBhZ2VudElkID0gQXJuLnNwbGl0KGF0dHJzLmFnZW50QXJuLCBBcm5Gb3JtYXQuU0xBU0hfUkVTT1VSQ0VfTkFNRSkucmVzb3VyY2VOYW1lITtcbiAgICAgIHB1YmxpYyByZWFkb25seSByb2xlID0gaWFtLlJvbGUuZnJvbVJvbGVBcm4oc2NvcGUsIGAke2lkfVJvbGVgLCBhdHRycy5yb2xlQXJuKTtcbiAgICAgIHB1YmxpYyByZWFkb25seSBrbXNLZXkgPSBhdHRycy5rbXNLZXlBcm4gPyBrbXMuS2V5LmZyb21LZXlBcm4oc2NvcGUsIGAke2lkfUtleWAsIGF0dHJzLmttc0tleUFybikgOiB1bmRlZmluZWQ7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgbGFzdFVwZGF0ZWQgPSBhdHRycy5sYXN0VXBkYXRlZDtcbiAgICAgIHB1YmxpYyByZWFkb25seSBhZ2VudFZlcnNpb24gPSBhdHRycy5hZ2VudFZlcnNpb24gPz8gJ0RSQUZUJztcbiAgICAgIHB1YmxpYyByZWFkb25seSBncmFudFByaW5jaXBhbCA9IHRoaXMucm9sZTtcbiAgICB9XG5cbiAgICAvLyBSZXR1cm4gbmV3IEFnZW50XG4gICAgcmV0dXJuIG5ldyBJbXBvcnQoc2NvcGUsIGlkKTtcbiAgfVxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQmFzZSBhdHRyaWJ1dGVzXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvKipcbiAgICogVGhlIHVuaXF1ZSBpZGVudGlmaWVyIGZvciB0aGUgYWdlbnRcbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGFnZW50SWQ6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBBUk4gb2YgdGhlIGFnZW50LlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgYWdlbnRBcm46IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSB2ZXJzaW9uIG9mIHRoZSBhZ2VudC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGFnZW50VmVyc2lvbjogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIElBTSByb2xlIGFzc29jaWF0ZWQgdG8gdGhlIGFnZW50LlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHJvbGU6IGlhbS5JUm9sZTtcbiAgLyoqXG4gICAqIE9wdGlvbmFsIEtNUyBlbmNyeXB0aW9uIGtleSBhc3NvY2lhdGVkIHdpdGggdGhpcyBhZ2VudFxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGttc0tleT86IGttcy5JS2V5O1xuICAvKipcbiAgICogV2hlbiB0aGlzIGFnZW50IHdhcyBsYXN0IHVwZGF0ZWQuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgbGFzdFVwZGF0ZWQ/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgcHJpbmNpcGFsIHRvIGdyYW50IHBlcm1pc3Npb25zIHRvXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZ3JhbnRQcmluY2lwYWw6IGlhbS5JUHJpbmNpcGFsO1xuICAvKipcbiAgICogRGVmYXVsdCBhbGlhcyBvZiB0aGUgYWdlbnRcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSB0ZXN0QWxpYXM6IElBZ2VudEFsaWFzO1xuICAvKipcbiAgICogYWN0aW9uIGdyb3VwcyBhc3NvY2lhdGVkIHdpdGggdGhlIGFnZW55XG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgYWN0aW9uR3JvdXBzOiBBZ2VudEFjdGlvbkdyb3VwW10gPSBbXTtcbiAgLyoqXG4gICAqIFRoZSBndWFyZHJhaWwgdGhhdCB3aWxsIGJlIGFzc29jaWF0ZWQgd2l0aCB0aGUgYWdlbnQuXG4gICAqL1xuICBwdWJsaWMgZ3VhcmRyYWlsPzogSUd1YXJkcmFpbDtcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIENESy1vbmx5IGF0dHJpYnV0ZXNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgYWdlbnQuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBJbnRlcm5hbCBPbmx5XG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBwcml2YXRlIHJlYWRvbmx5IFJPTEVfTkFNRV9TVUZGSVggPSAnLWJlZHJvY2thZ2VudCc7XG4gIHByaXZhdGUgcmVhZG9ubHkgTUFYTEVOR1RIX0ZPUl9ST0xFX05BTUUgPSA2NDtcbiAgcHJpdmF0ZSByZWFkb25seSBpZGxlU2Vzc2lvblRUTDogRHVyYXRpb247XG4gIHByaXZhdGUgcmVhZG9ubHkgZm91bmRhdGlvbk1vZGVsOiBJQmVkcm9ja0ludm9rYWJsZTtcbiAgcHJpdmF0ZSByZWFkb25seSB1c2VySW5wdXRFbmFibGVkOiBib29sZWFuO1xuICBwcml2YXRlIHJlYWRvbmx5IGNvZGVJbnRlcnByZXRlckVuYWJsZWQ6IGJvb2xlYW47XG4gIHByaXZhdGUgcmVhZG9ubHkgYWdlbnRDb2xsYWJvcmF0aW9uPzogQWdlbnRDb2xsYWJvcmF0aW9uO1xuICBwcml2YXRlIHJlYWRvbmx5IGN1c3RvbU9yY2hlc3RyYXRpb25FeGVjdXRvcj86IEN1c3RvbU9yY2hlc3RyYXRpb25FeGVjdXRvcjtcbiAgcHJpdmF0ZSByZWFkb25seSBwcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb24/OiBQcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb247XG4gIHByaXZhdGUgcmVhZG9ubHkgX19yZXNvdXJjZTogYmVkcm9jay5DZm5BZ2VudDtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQ09OU1RSVUNUT1JcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzOiBBZ2VudFByb3BzKSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkKTtcbiAgICAvLyBFbmhhbmNlZCBDREsgQW5hbHl0aWNzIFRlbGVtZXRyeVxuICAgIGFkZENvbnN0cnVjdE1ldGFkYXRhKHRoaXMsIHByb3BzKTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIFZhbGlkYXRlIHByb3BzXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgaWYgKHByb3BzLmluc3RydWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChwcm9wcy5pbnN0cnVjdGlvbikgJiZcbiAgICAgICAgcHJvcHMuaW5zdHJ1Y3Rpb24ubGVuZ3RoIDwgTUlOX0lOU1RSVUNUSU9OX0xFTkdUSCkge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgaW5zdHJ1Y3Rpb24gbXVzdCBiZSBhdCBsZWFzdCAke01JTl9JTlNUUlVDVElPTl9MRU5HVEh9IGNoYXJhY3RlcnNgLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBpZGxlU2Vzc2lvblRUTFxuICAgIGlmIChwcm9wcy5pZGxlU2Vzc2lvblRUTCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQocHJvcHMuaWRsZVNlc3Npb25UVEwpICYmXG4gICAgICAgIChwcm9wcy5pZGxlU2Vzc2lvblRUTC50b01pbnV0ZXMoKSA8IDEgfHwgcHJvcHMuaWRsZVNlc3Npb25UVEwudG9NaW51dGVzKCkgPiA2MCkpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ2lkbGVTZXNzaW9uVFRMIG11c3QgYmUgYmV0d2VlbiAxIGFuZCA2MCBtaW51dGVzJywgdGhpcyk7XG4gICAgfVxuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gU2V0IHByb3BlcnRpZXMgYW5kIGRlZmF1bHRzXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy5uYW1lID1cbiAgICAgIHByb3BzLmFnZW50TmFtZSA/PyB0aGlzLmdlbmVyYXRlUGh5c2ljYWxOYW1lKCkgKyB0aGlzLlJPTEVfTkFNRV9TVUZGSVg7XG4gICAgdGhpcy5pZGxlU2Vzc2lvblRUTCA9IHByb3BzLmlkbGVTZXNzaW9uVFRMID8/IER1cmF0aW9uLm1pbnV0ZXMoMTApO1xuICAgIHRoaXMudXNlcklucHV0RW5hYmxlZCA9IHByb3BzLnVzZXJJbnB1dEVuYWJsZWQgPz8gZmFsc2U7XG4gICAgdGhpcy5jb2RlSW50ZXJwcmV0ZXJFbmFibGVkID0gcHJvcHMuY29kZUludGVycHJldGVyRW5hYmxlZCA/PyBmYWxzZTtcbiAgICB0aGlzLmZvdW5kYXRpb25Nb2RlbCA9IHByb3BzLmZvdW5kYXRpb25Nb2RlbDtcbiAgICAvLyBPcHRpb25hbFxuICAgIHRoaXMucHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uID0gcHJvcHMucHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uO1xuICAgIHRoaXMua21zS2V5ID0gcHJvcHMua21zS2V5O1xuICAgIHRoaXMuY3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yID0gcHJvcHMuY3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gUm9sZVxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIElmIGV4aXN0aW5nIHJvbGUgaXMgcHJvdmlkZWQsIHVzZSBpdC5cbiAgICBpZiAocHJvcHMuZXhpc3RpbmdSb2xlKSB7XG4gICAgICB0aGlzLnJvbGUgPSBwcm9wcy5leGlzdGluZ1JvbGU7XG4gICAgICB0aGlzLmdyYW50UHJpbmNpcGFsID0gdGhpcy5yb2xlO1xuICAgICAgLy8gT3RoZXJ3aXNlLCBjcmVhdGUgYSBuZXcgb25lXG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMucm9sZSA9IG5ldyBpYW0uUm9sZSh0aGlzLCAnUm9sZScsIHtcbiAgICAgICAgLy8gZ2VuZXJhdGUgYSByb2xlIG5hbWVcbiAgICAgICAgcm9sZU5hbWU6IHRoaXMuZ2VuZXJhdGVQaHlzaWNhbE5hbWUoKSArIHRoaXMuUk9MRV9OQU1FX1NVRkZJWCxcbiAgICAgICAgLy8gZW5zdXJlIHRoZSByb2xlIGhhcyBhIHRydXN0IHBvbGljeSB0aGF0IGFsbG93cyB0aGUgQmVkcm9jayBzZXJ2aWNlIHRvIGFzc3VtZSB0aGUgcm9sZVxuICAgICAgICBhc3N1bWVkQnk6IG5ldyBpYW0uU2VydmljZVByaW5jaXBhbCgnYmVkcm9jay5hbWF6b25hd3MuY29tJykud2l0aENvbmRpdGlvbnMoe1xuICAgICAgICAgIFN0cmluZ0VxdWFsczoge1xuICAgICAgICAgICAgJ2F3czpTb3VyY2VBY2NvdW50JzogeyBSZWY6ICdBV1M6OkFjY291bnRJZCcgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIEFybkxpa2U6IHtcbiAgICAgICAgICAgICdhd3M6U291cmNlQXJuJzogU3RhY2sub2YodGhpcykuZm9ybWF0QXJuKHtcbiAgICAgICAgICAgICAgc2VydmljZTogJ2JlZHJvY2snLFxuICAgICAgICAgICAgICByZXNvdXJjZTogJ2FnZW50JyxcbiAgICAgICAgICAgICAgcmVzb3VyY2VOYW1lOiAnKicsXG4gICAgICAgICAgICAgIGFybkZvcm1hdDogQXJuRm9ybWF0LlNMQVNIX1JFU09VUkNFX05BTUUsXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KSxcbiAgICAgIH0pO1xuICAgICAgdGhpcy5ncmFudFByaW5jaXBhbCA9IHRoaXMucm9sZTtcbiAgICB9XG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gU2V0IExhenkgUHJvcHMgaW5pdGlhbCB2YWx1ZXNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBBZGQgRGVmYXVsdCBBY3Rpb24gR3JvdXBzXG4gICAgdGhpcy5hZGRBY3Rpb25Hcm91cChBZ2VudEFjdGlvbkdyb3VwLnVzZXJJbnB1dCh0aGlzLnVzZXJJbnB1dEVuYWJsZWQpKTtcbiAgICB0aGlzLmFkZEFjdGlvbkdyb3VwKEFnZW50QWN0aW9uR3JvdXAuY29kZUludGVycHJldGVyKHRoaXMuY29kZUludGVycHJldGVyRW5hYmxlZCkpO1xuXG4gICAgLy8gQWRkIHNwZWNpZmllZCBlbGVtcyB0aHJvdWdoIG1ldGhvZHMgdG8gaGFuZGxlIHBlcm1pc3Npb25zXG4gICAgLy8gdGhpcyBuZWVkcyB0byBoYXBwZW4gYWZ0ZXIgcm9sZSBjcmVhdGlvbiAvIGFzc2lnbm1lbnRcbiAgICBwcm9wcy5hY3Rpb25Hcm91cHM/LmZvckVhY2goYWcgPT4ge1xuICAgICAgdGhpcy5hZGRBY3Rpb25Hcm91cChhZyk7XG4gICAgfSk7XG5cbiAgICAvLyBTZXQgYWdlbnQgY29sbGFib3JhdGlvbiBjb25maWd1cmF0aW9uXG4gICAgdGhpcy5hZ2VudENvbGxhYm9yYXRpb24gPSBwcm9wcy5hZ2VudENvbGxhYm9yYXRpb247XG4gICAgaWYgKHByb3BzLmFnZW50Q29sbGFib3JhdGlvbikge1xuICAgICAgcHJvcHMuYWdlbnRDb2xsYWJvcmF0aW9uLmNvbGxhYm9yYXRvcnMuZm9yRWFjaChhYyA9PiB7XG4gICAgICAgIHRoaXMuZ3JhbnRQZXJtaXNzaW9uVG9BZ2VudChhYyk7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBpZiAocHJvcHMuZ3VhcmRyYWlsKSB7XG4gICAgICB0aGlzLmFkZEd1YXJkcmFpbChwcm9wcy5ndWFyZHJhaWwpO1xuICAgIH1cblxuICAgIC8vIEdyYW50IHBlcm1pc3Npb25zIGZvciBjdXN0b20gb3JjaGVzdHJhdGlvbiBpZiBwcm92aWRlZFxuICAgIGlmICh0aGlzLmN1c3RvbU9yY2hlc3RyYXRpb25FeGVjdXRvcj8ubGFtYmRhRnVuY3Rpb24pIHtcbiAgICAgIHRoaXMuY3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yLmxhbWJkYUZ1bmN0aW9uLmdyYW50SW52b2tlKHRoaXMucm9sZSk7XG4gICAgICB0aGlzLmN1c3RvbU9yY2hlc3RyYXRpb25FeGVjdXRvci5sYW1iZGFGdW5jdGlvbi5hZGRQZXJtaXNzaW9uKGBPcmNoZXN0cmF0aW9uTGFtYmRhSW52b2NhdGlvblBvbGljeS0ke3RoaXMubm9kZS5hZGRyLnNsaWNlKDAsIE1BWF9QT0xJQ1lfTkFNRV9OT0RFX0xFTkdUSCl9YCwge1xuICAgICAgICBwcmluY2lwYWw6IG5ldyBpYW0uU2VydmljZVByaW5jaXBhbCgnYmVkcm9jay5hbWF6b25hd3MuY29tJyksXG4gICAgICAgIHNvdXJjZUFybjogTGF6eS5zdHJpbmcoeyBwcm9kdWNlOiAoKSA9PiB0aGlzLmFnZW50QXJuIH0pLFxuICAgICAgICBzb3VyY2VBY2NvdW50OiB7IFJlZjogJ0FXUzo6QWNjb3VudElkJyB9IGFzIGFueSxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIENGTiBQcm9wcyAtIFdpdGggTGF6eSBzdXBwb3J0XG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgY29uc3QgY2ZuUHJvcHM6IGJlZHJvY2suQ2ZuQWdlbnRQcm9wcyA9IHtcbiAgICAgIGFjdGlvbkdyb3VwczogTGF6eS5hbnkoeyBwcm9kdWNlOiAoKSA9PiB0aGlzLnJlbmRlckFjdGlvbkdyb3VwcygpIH0sIHsgb21pdEVtcHR5QXJyYXk6IHRydWUgfSksXG4gICAgICBhZ2VudE5hbWU6IHRoaXMubmFtZSxcbiAgICAgIGFnZW50UmVzb3VyY2VSb2xlQXJuOiB0aGlzLnJvbGUucm9sZUFybixcbiAgICAgIGF1dG9QcmVwYXJlOiBwcm9wcy5zaG91bGRQcmVwYXJlQWdlbnQgPz8gZmFsc2UsXG4gICAgICBjdXN0b21lckVuY3J5cHRpb25LZXlBcm46IHByb3BzLmttc0tleT8ua2V5QXJuLFxuICAgICAgZGVzY3JpcHRpb246IHByb3BzLmRlc2NyaXB0aW9uLFxuICAgICAgZm91bmRhdGlvbk1vZGVsOiB0aGlzLmZvdW5kYXRpb25Nb2RlbC5pbnZva2FibGVBcm4sXG4gICAgICBndWFyZHJhaWxDb25maWd1cmF0aW9uOiBMYXp5LmFueSh7IHByb2R1Y2U6ICgpID0+IHRoaXMucmVuZGVyR3VhcmRyYWlsKCkgfSksXG4gICAgICBpZGxlU2Vzc2lvblR0bEluU2Vjb25kczogdGhpcy5pZGxlU2Vzc2lvblRUTC50b1NlY29uZHMoKSxcbiAgICAgIGluc3RydWN0aW9uOiBwcm9wcy5pbnN0cnVjdGlvbixcbiAgICAgIG1lbW9yeUNvbmZpZ3VyYXRpb246IHByb3BzLm1lbW9yeT8uX3JlbmRlcigpLFxuICAgICAgcHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uOiB0aGlzLnByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbj8uX3JlbmRlcigpLFxuICAgICAgc2tpcFJlc291cmNlSW5Vc2VDaGVja09uRGVsZXRlOiBwcm9wcy5mb3JjZURlbGV0ZSA/PyBmYWxzZSxcbiAgICAgIGFnZW50Q29sbGFib3JhdGlvbjogcHJvcHMuYWdlbnRDb2xsYWJvcmF0aW9uPy50eXBlLFxuICAgICAgYWdlbnRDb2xsYWJvcmF0b3JzOiBMYXp5LmFueSh7IHByb2R1Y2U6ICgpID0+IHRoaXMucmVuZGVyQWdlbnRDb2xsYWJvcmF0b3JzKCkgfSwgeyBvbWl0RW1wdHlBcnJheTogdHJ1ZSB9KSxcbiAgICAgIGN1c3RvbU9yY2hlc3RyYXRpb246IHRoaXMucmVuZGVyQ3VzdG9tT3JjaGVzdHJhdGlvbigpLFxuICAgICAgb3JjaGVzdHJhdGlvblR5cGU6IHRoaXMuY3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yID8gT3JjaGVzdHJhdGlvblR5cGUuQ1VTVE9NX09SQ0hFU1RSQVRJT04gOiBPcmNoZXN0cmF0aW9uVHlwZS5ERUZBVUxULFxuICAgIH07XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBMMSBJbnN0YW50aWF0aW9uXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy5fX3Jlc291cmNlID0gbmV3IGJlZHJvY2suQ2ZuQWdlbnQodGhpcywgJ1Jlc291cmNlJywgY2ZuUHJvcHMpO1xuXG4gICAgdGhpcy5hZ2VudElkID0gdGhpcy5fX3Jlc291cmNlLmF0dHJBZ2VudElkO1xuICAgIHRoaXMuYWdlbnRBcm4gPSB0aGlzLl9fcmVzb3VyY2UuYXR0ckFnZW50QXJuO1xuICAgIHRoaXMuYWdlbnRWZXJzaW9uID0gdGhpcy5fX3Jlc291cmNlLmF0dHJBZ2VudFZlcnNpb247XG4gICAgdGhpcy5sYXN0VXBkYXRlZCA9IHRoaXMuX19yZXNvdXJjZS5hdHRyVXBkYXRlZEF0O1xuXG4gICAgLy8gQWRkIGV4cGxpY2l0IGRlcGVuZGVuY3kgYmV0d2VlbiB0aGUgYWdlbnQgcmVzb3VyY2UgYW5kIHRoZSBhZ2VudCdzIHJvbGUgZGVmYXVsdCBwb2xpY3lcbiAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL2F3c2xhYnMvZ2VuZXJhdGl2ZS1haS1jZGstY29uc3RydWN0cy9pc3N1ZXMvODk5XG4gICAgY29uc3QgZ3JhbnQgPSB0aGlzLmZvdW5kYXRpb25Nb2RlbC5ncmFudEludm9rZSh0aGlzLnJvbGUpO1xuICAgIGdyYW50LmFwcGx5QmVmb3JlKHRoaXMuX19yZXNvdXJjZSk7XG5cbiAgICB0aGlzLnRlc3RBbGlhcyA9IEFnZW50QWxpYXMuZnJvbUF0dHJpYnV0ZXModGhpcywgJ0RlZmF1bHRBbGlhcycsIHtcbiAgICAgIGFsaWFzSWQ6ICdUU1RBTElBU0lEJyxcbiAgICAgIGFsaWFzTmFtZTogJ0FnZW50VGVzdEFsaWFzJyxcbiAgICAgIGFnZW50VmVyc2lvbjogJ0RSQUZUJyxcbiAgICAgIGFnZW50OiB0aGlzLFxuICAgIH0pO1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEhFTFBFUiBNRVRIT0RTIC0gYWRkWCgpXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gIC8qKlxuICAgKiBBZGQgZ3VhcmRyYWlsIHRvIHRoZSBhZ2VudC5cbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBhZGRHdWFyZHJhaWwoZ3VhcmRyYWlsOiBJR3VhcmRyYWlsKSB7XG4gICAgLy8gRG8gc29tZSBjaGVja3NcbiAgICB2YWxpZGF0aW9uLnRocm93SWZJbnZhbGlkKHRoaXMudmFsaWRhdGVHdWFyZHJhaWwsIGd1YXJkcmFpbCk7XG4gICAgLy8gQWRkIGl0IHRvIHRoZSBjb25zdHJ1Y3RcbiAgICB0aGlzLmd1YXJkcmFpbCA9IGd1YXJkcmFpbDtcbiAgICAvLyBIYW5kbGUgcGVybWlzc2lvbnNcbiAgICBndWFyZHJhaWwuZ3JhbnRBcHBseSh0aGlzLnJvbGUpO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgYW4gYWN0aW9uIGdyb3VwIHRvIHRoZSBhZ2VudCBhbmQgY29uZmlndXJlcyBuZWNlc3NhcnkgcGVybWlzc2lvbnMuXG4gICAqXG4gICAqIEBwYXJhbSBhY3Rpb25Hcm91cCAtIFRoZSBhY3Rpb24gZ3JvdXAgdG8gYWRkXG4gICAqIEBkZWZhdWx0IC0gRGVmYXVsdCBwZXJtaXNzaW9uczpcbiAgICogLSBMYW1iZGEgZnVuY3Rpb24gaW52b2tlIHBlcm1pc3Npb25zIGlmIGV4ZWN1dG9yIGlzIHByZXNlbnRcbiAgICogLSBTMyBHZXRPYmplY3QgcGVybWlzc2lvbnMgaWYgYXBpU2NoZW1hLnMzRmlsZSBpcyBwcmVzZW50XG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgYWRkQWN0aW9uR3JvdXAoYWN0aW9uR3JvdXA6IEFnZW50QWN0aW9uR3JvdXApIHtcbiAgICB2YWxpZGF0aW9uLnRocm93SWZJbnZhbGlkKHRoaXMudmFsaWRhdGVBY3Rpb25Hcm91cCwgYWN0aW9uR3JvdXApO1xuICAgIHRoaXMuYWN0aW9uR3JvdXBzLnB1c2goYWN0aW9uR3JvdXApO1xuICAgIC8vIEhhbmRsZSBwZXJtaXNzaW9ucyB0byBpbnZva2UgdGhlIGxhbWJkYSBmdW5jdGlvblxuICAgIGFjdGlvbkdyb3VwLmV4ZWN1dG9yPy5sYW1iZGFGdW5jdGlvbj8uZ3JhbnRJbnZva2UodGhpcy5yb2xlKTtcbiAgICBhY3Rpb25Hcm91cC5leGVjdXRvcj8ubGFtYmRhRnVuY3Rpb24/LmFkZFBlcm1pc3Npb24oYExhbWJkYUludm9jYXRpb25Qb2xpY3ktJHt0aGlzLm5vZGUuYWRkci5zbGljZSgwLCBNQVhfUE9MSUNZX05BTUVfTk9ERV9MRU5HVEgpfWAsIHtcbiAgICAgIHByaW5jaXBhbDogbmV3IGlhbS5TZXJ2aWNlUHJpbmNpcGFsKCdiZWRyb2NrLmFtYXpvbmF3cy5jb20nKSxcbiAgICAgIHNvdXJjZUFybjogdGhpcy5hZ2VudEFybixcbiAgICAgIHNvdXJjZUFjY291bnQ6IHsgUmVmOiAnQVdTOjpBY2NvdW50SWQnIH0gYXMgYW55LFxuICAgIH0pO1xuICAgIC8vIEhhbmRsZSBwZXJtaXNzaW9ucyB0byBhY2Nlc3MgdGhlIHNjaGVtYSBmaWxlIGZyb20gUzNcbiAgICBpZiAoYWN0aW9uR3JvdXAuYXBpU2NoZW1hIGluc3RhbmNlb2YgQXNzZXRBcGlTY2hlbWEpIHtcbiAgICAgIGNvbnN0IHJlbmRlcmVkID0gYWN0aW9uR3JvdXAuYXBpU2NoZW1hLl9yZW5kZXIoKTtcbiAgICAgIGlmICghKCdzMycgaW4gcmVuZGVyZWQpIHx8ICFyZW5kZXJlZC5zMykge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdTMyBjb25maWd1cmF0aW9uIGlzIG1pc3NpbmcgaW4gQXNzZXRBcGlTY2hlbWEnLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHMzQ29uZmlnID0gcmVuZGVyZWQuczM7XG4gICAgICBpZiAoISgnczNCdWNrZXROYW1lJyBpbiBzM0NvbmZpZykgfHwgISgnczNPYmplY3RLZXknIGluIHMzQ29uZmlnKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdTMyBidWNrZXQgbmFtZSBhbmQgb2JqZWN0IGtleSBhcmUgcmVxdWlyZWQgaW4gQXNzZXRBcGlTY2hlbWEnLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGJ1Y2tldE5hbWUgPSBzM0NvbmZpZy5zM0J1Y2tldE5hbWU7XG4gICAgICBjb25zdCBvYmplY3RLZXkgPSBzM0NvbmZpZy5zM09iamVjdEtleTtcbiAgICAgIGlmICghYnVja2V0TmFtZSB8fCBidWNrZXROYW1lLnRyaW0oKSA9PT0gJycpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignUzMgYnVja2V0IG5hbWUgY2Fubm90IGJlIGVtcHR5IGluIEFzc2V0QXBpU2NoZW1hJywgdGhpcyk7XG4gICAgICB9XG4gICAgICBpZiAoIW9iamVjdEtleSB8fCBvYmplY3RLZXkudHJpbSgpID09PSAnJykge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdTMyBvYmplY3Qga2V5IGNhbm5vdCBiZSBlbXB0eSBpbiBBc3NldEFwaVNjaGVtYScsIHRoaXMpO1xuICAgICAgfVxuICAgICAgY29uc3QgYnVja2V0ID0gczMuQnVja2V0LmZyb21CdWNrZXROYW1lKHRoaXMsIGAke2FjdGlvbkdyb3VwLm5hbWV9U2NoZW1hQnVja2V0YCwgYnVja2V0TmFtZSk7XG4gICAgICBidWNrZXQuZ3JhbnRSZWFkKHRoaXMucm9sZSwgb2JqZWN0S2V5KTtcbiAgICB9IGVsc2UgaWYgKGFjdGlvbkdyb3VwLmFwaVNjaGVtYSBpbnN0YW5jZW9mIFMzQXBpU2NoZW1hKSB7XG4gICAgICBjb25zdCBzM0ZpbGUgPSBhY3Rpb25Hcm91cC5hcGlTY2hlbWEuczNGaWxlO1xuICAgICAgaWYgKCFzM0ZpbGUpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignUzMgZmlsZSBjb25maWd1cmF0aW9uIGlzIG1pc3NpbmcgaW4gUzNBcGlTY2hlbWEnLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGlmICghczNGaWxlLmJ1Y2tldE5hbWUgfHwgczNGaWxlLmJ1Y2tldE5hbWUudHJpbSgpID09PSAnJykge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdTMyBidWNrZXQgbmFtZSBjYW5ub3QgYmUgZW1wdHkgaW4gUzNBcGlTY2hlbWEnLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGlmICghczNGaWxlLm9iamVjdEtleSB8fCBzM0ZpbGUub2JqZWN0S2V5LnRyaW0oKSA9PT0gJycpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignUzMgb2JqZWN0IGtleSBjYW5ub3QgYmUgZW1wdHkgaW4gUzNBcGlTY2hlbWEnLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGJ1Y2tldCA9IHMzLkJ1Y2tldC5mcm9tQnVja2V0TmFtZSh0aGlzLCBgJHthY3Rpb25Hcm91cC5uYW1lfVNjaGVtYUJ1Y2tldGAsIHMzRmlsZS5idWNrZXROYW1lKTtcbiAgICAgIGJ1Y2tldC5ncmFudFJlYWQodGhpcy5yb2xlLCBzM0ZpbGUub2JqZWN0S2V5KTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogR3JhbnRzIHBlcm1pc3Npb25zIGZvciBhbiBhZ2VudCBjb2xsYWJvcmF0b3IgdG8gdGhpcyBhZ2VudCdzIHJvbGUuXG4gICAqIFRoaXMgbWV0aG9kIG9ubHkgZ3JhbnRzIElBTSBwZXJtaXNzaW9ucyBhbmQgZG9lcyBub3QgYWRkIHRoZSBjb2xsYWJvcmF0b3JcbiAgICogdG8gdGhlIGFnZW50J3MgY29sbGFib3JhdGlvbiBjb25maWd1cmF0aW9uLiBUbyBhZGQgY29sbGFib3JhdG9ycyB0byB0aGVcbiAgICogYWdlbnQgY29uZmlndXJhdGlvbiwgaW5jbHVkZSB0aGVtIGluIHRoZSBBZ2VudENvbGxhYm9yYXRpb24gd2hlbiBjcmVhdGluZyB0aGUgYWdlbnQuXG4gICAqXG4gICAqIEBwYXJhbSBhZ2VudENvbGxhYm9yYXRvciAtIFRoZSBjb2xsYWJvcmF0b3IgdG8gZ3JhbnQgcGVybWlzc2lvbnMgZm9yXG4gICAqL1xuICBwcml2YXRlIGdyYW50UGVybWlzc2lvblRvQWdlbnQoYWdlbnRDb2xsYWJvcmF0b3I6IEFnZW50Q29sbGFib3JhdG9yKSB7XG4gICAgYWdlbnRDb2xsYWJvcmF0b3IuZ3JhbnQodGhpcy5yb2xlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciBhZ2VudCBjb2xsYWJvcmF0aW9uLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIE5vIGNvbGxhYm9yYXRpb24gY29uZmlndXJhdGlvbi5cbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBhZGRBY3Rpb25Hcm91cHMoLi4uYWN0aW9uR3JvdXBzOiBBZ2VudEFjdGlvbkdyb3VwW10pIHtcbiAgICBhY3Rpb25Hcm91cHMuZm9yRWFjaChhZyA9PiB0aGlzLmFkZEFjdGlvbkdyb3VwKGFnKSk7XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gTGF6eSBSZW5kZXJlcnNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgLyoqXG4gICAqIFJlbmRlciB0aGUgZ3VhcmRyYWlsIGNvbmZpZ3VyYXRpb24uXG4gICAqXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHJpdmF0ZSByZW5kZXJHdWFyZHJhaWwoKTogYmVkcm9jay5DZm5BZ2VudC5HdWFyZHJhaWxDb25maWd1cmF0aW9uUHJvcGVydHkgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiB0aGlzLmd1YXJkcmFpbFxuICAgICAgPyB7XG4gICAgICAgIGd1YXJkcmFpbElkZW50aWZpZXI6IHRoaXMuZ3VhcmRyYWlsLmd1YXJkcmFpbElkLFxuICAgICAgICBndWFyZHJhaWxWZXJzaW9uOiB0aGlzLmd1YXJkcmFpbC5ndWFyZHJhaWxWZXJzaW9uLFxuICAgICAgfVxuICAgICAgOiB1bmRlZmluZWQ7XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVyIHRoZSBhY3Rpb24gZ3JvdXBzXG4gICAqXG4gICAqIEByZXR1cm5zIEFycmF5IG9mIEFnZW50QWN0aW9uR3JvdXBQcm9wZXJ0eSBvYmplY3RzIGluIENsb3VkRm9ybWF0aW9uIGZvcm1hdFxuICAgKiBAZGVmYXVsdCAtIEVtcHR5IGFycmF5IGlmIG5vIGFjdGlvbiBncm91cHMgYXJlIGRlZmluZWRcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwcml2YXRlIHJlbmRlckFjdGlvbkdyb3VwcygpOiBiZWRyb2NrLkNmbkFnZW50LkFnZW50QWN0aW9uR3JvdXBQcm9wZXJ0eVtdIHtcbiAgICBjb25zdCBhY3Rpb25Hcm91cHNDZm46IGJlZHJvY2suQ2ZuQWdlbnQuQWdlbnRBY3Rpb25Hcm91cFByb3BlcnR5W10gPSBbXTtcbiAgICAvLyBCdWlsZCB0aGUgYXNzb2NpYXRpb25zIGluIHRoZSBDRk4gZm9ybWF0XG4gICAgdGhpcy5hY3Rpb25Hcm91cHMuZm9yRWFjaChhZyA9PiB7XG4gICAgICBhY3Rpb25Hcm91cHNDZm4ucHVzaChhZy5fcmVuZGVyKCkpO1xuICAgIH0pO1xuICAgIHJldHVybiBhY3Rpb25Hcm91cHNDZm47XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVyIHRoZSBhZ2VudCBjb2xsYWJvcmF0b3JzLlxuICAgKlxuICAgKiBAcmV0dXJucyBBcnJheSBvZiBBZ2VudENvbGxhYm9yYXRvclByb3BlcnR5IG9iamVjdHMgaW4gQ2xvdWRGb3JtYXRpb24gZm9ybWF0LCBvciB1bmRlZmluZWQgaWYgbm8gY29sbGFib3JhdG9yc1xuICAgKiBAZGVmYXVsdCAtIHVuZGVmaW5lZCBpZiBubyBjb2xsYWJvcmF0b3JzIGFyZSBkZWZpbmVkIG9yIGFycmF5IGlzIGVtcHR5XG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHJpdmF0ZSByZW5kZXJBZ2VudENvbGxhYm9yYXRvcnMoKTogYmVkcm9jay5DZm5BZ2VudC5BZ2VudENvbGxhYm9yYXRvclByb3BlcnR5W10gfCB1bmRlZmluZWQge1xuICAgIGlmICghdGhpcy5hZ2VudENvbGxhYm9yYXRpb24gfHwgIXRoaXMuYWdlbnRDb2xsYWJvcmF0aW9uLmNvbGxhYm9yYXRvcnMgfHwgdGhpcy5hZ2VudENvbGxhYm9yYXRpb24uY29sbGFib3JhdG9ycy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuYWdlbnRDb2xsYWJvcmF0aW9uLmNvbGxhYm9yYXRvcnMubWFwKGFjID0+IGFjLl9yZW5kZXIoKSk7XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVyIHRoZSBjdXN0b20gb3JjaGVzdHJhdGlvbi5cbiAgICpcbiAgICogQHJldHVybnMgQ3VzdG9tT3JjaGVzdHJhdGlvblByb3BlcnR5IG9iamVjdCBpbiBDbG91ZEZvcm1hdGlvbiBmb3JtYXQsIG9yIHVuZGVmaW5lZCBpZiBubyBjdXN0b20gb3JjaGVzdHJhdGlvblxuICAgKiBAZGVmYXVsdCAtIHVuZGVmaW5lZCBpZiBubyBjdXN0b20gb3JjaGVzdHJhdGlvbiBpcyBkZWZpbmVkXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHJpdmF0ZSByZW5kZXJDdXN0b21PcmNoZXN0cmF0aW9uKCk6IGJlZHJvY2suQ2ZuQWdlbnQuQ3VzdG9tT3JjaGVzdHJhdGlvblByb3BlcnR5IHwgdW5kZWZpbmVkIHtcbiAgICBpZiAoIXRoaXMuY3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBleGVjdXRvcjoge1xuICAgICAgICBsYW1iZGE6IHRoaXMuY3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yLmxhbWJkYUZ1bmN0aW9uLmZ1bmN0aW9uQXJuLFxuICAgICAgfSxcbiAgICB9O1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIFZhbGlkYXRvcnNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBDaGVja3MgaWYgdGhlIEd1YXJkcmFpbCBpcyB2YWxpZFxuICAgKlxuICAgKiBAcGFyYW0gZ3VhcmRyYWlsIC0gVGhlIGd1YXJkcmFpbCB0byB2YWxpZGF0ZVxuICAgKiBAcmV0dXJucyBBcnJheSBvZiB2YWxpZGF0aW9uIGVycm9yIG1lc3NhZ2VzLCBlbXB0eSBpZiB2YWxpZFxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZUd1YXJkcmFpbCA9IChndWFyZHJhaWw6IElHdWFyZHJhaWwpID0+IHtcbiAgICBsZXQgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xuICAgIGlmICh0aGlzLmd1YXJkcmFpbCkge1xuICAgICAgZXJyb3JzLnB1c2goXG4gICAgICAgIGBDYW5ub3QgYWRkIEd1YXJkcmFpbCAke2d1YXJkcmFpbC5ndWFyZHJhaWxJZH0uIGAgK1xuICAgICAgICAgIGBHdWFyZHJhaWwgJHt0aGlzLmd1YXJkcmFpbC5ndWFyZHJhaWxJZH0gaGFzIGFscmVhZHkgYmVlbiBzcGVjaWZpZWQgZm9yIHRoaXMgYWdlbnQuYCxcbiAgICAgICk7XG4gICAgfVxuICAgIGVycm9ycy5wdXNoKC4uLnZhbGlkYXRpb24udmFsaWRhdGVGaWVsZFBhdHRlcm4oZ3VhcmRyYWlsLmd1YXJkcmFpbFZlcnNpb24sICd2ZXJzaW9uJywgL14oKFswLTldezEsOH0pfChEUkFGVCkpJC8pKTtcbiAgICByZXR1cm4gZXJyb3JzO1xuICB9O1xuXG4gIC8qKlxuICAgKiBDaGVjayBpZiB0aGUgYWN0aW9uIGdyb3VwIGlzIHZhbGlkXG4gICAqXG4gICAqIEBwYXJhbSBhY3Rpb25Hcm91cCAtIFRoZSBhY3Rpb24gZ3JvdXAgdG8gdmFsaWRhdGVcbiAgICogQHJldHVybnMgQXJyYXkgb2YgdmFsaWRhdGlvbiBlcnJvciBtZXNzYWdlcywgZW1wdHkgaWYgdmFsaWRcbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVBY3Rpb25Hcm91cCA9IChhY3Rpb25Hcm91cDogQWdlbnRBY3Rpb25Hcm91cCkgPT4ge1xuICAgIGxldCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG4gICAgLy8gRmluZCBpZiB0aGVyZSBpcyBhIGNvbmZsaWN0aW5nIGFjdGlvbiBncm91cCBuYW1lXG4gICAgaWYgKHRoaXMuYWN0aW9uR3JvdXBzPy5maW5kKGFnID0+IGFnLm5hbWUgPT09IGFjdGlvbkdyb3VwLm5hbWUpKSB7XG4gICAgICBlcnJvcnMucHVzaCgnQWN0aW9uIGdyb3VwIGFscmVhZHkgZXhpc3RzJyk7XG4gICAgfVxuICAgIHJldHVybiBlcnJvcnM7XG4gIH07XG5cbiAgLyoqXG4gICAqIEdlbmVyYXRlcyBhIHVuaXF1ZSwgZGV0ZXJtaW5pc3RpYyBuYW1lIGZvciBBV1MgcmVzb3VyY2VzIHRoYXQgaW5jbHVkZXMgYSBoYXNoIGNvbXBvbmVudC5cbiAgICogVGhpcyBtZXRob2QgZW5zdXJlcyBjb25zaXN0ZW50IG5hbWluZyB3aGlsZSBhdm9pZGluZyBjb25mbGljdHMgYW5kIGFkaGVyaW5nIHRvIEFXUyBuYW1pbmcgY29uc3RyYWludHMuXG4gICAqIEBwYXJhbSBzY29wZSAtIFRoZSBjb25zdHJ1Y3Qgc2NvcGUgdXNlZCBmb3IgZ2VuZXJhdGluZyB1bmlxdWUgbmFtZXNcbiAgICogQHBhcmFtIHByZWZpeCAtIFRoZSBwcmVmaXggdG8gcHJlcGVuZCB0byB0aGUgZ2VuZXJhdGVkIG5hbWVcbiAgICogQHBhcmFtIG9wdGlvbnMgLSBDb25maWd1cmF0aW9uIG9wdGlvbnMgZm9yIG5hbWUgZ2VuZXJhdGlvblxuICAgKiBAcGFyYW0gb3B0aW9ucy5tYXhMZW5ndGggLSBNYXhpbXVtIGxlbmd0aCBvZiB0aGUgZ2VuZXJhdGVkIG5hbWVcbiAgICogQGRlZmF1bHQgLSBtYXhMZW5ndGg6IDI1NlxuICAgKiBAcGFyYW0gb3B0aW9ucy5sb3dlciAtIENvbnZlcnQgdGhlIGdlbmVyYXRlZCBuYW1lIHRvIGxvd2VyY2FzZVxuICAgKiBAZGVmYXVsdCAtIGxvd2VyOiBmYWxzZVxuICAgKiBAcGFyYW0gb3B0aW9ucy5zZXBhcmF0b3IgLSBDaGFyYWN0ZXIocykgdG8gdXNlIGJldHdlZW4gbmFtZSBjb21wb25lbnRzXG4gICAqIEBkZWZhdWx0IC0gc2VwYXJhdG9yOiAnJ1xuICAgKiBAcGFyYW0gb3B0aW9ucy5hbGxvd2VkU3BlY2lhbENoYXJhY3RlcnMgLSBTdHJpbmcgb2YgYWxsb3dlZCBzcGVjaWFsIGNoYXJhY3RlcnNcbiAgICogQGRlZmF1bHQgLSB1bmRlZmluZWRcbiAgICogQHBhcmFtIG9wdGlvbnMuZGVzdHJveUNyZWF0ZSAtIE9iamVjdCB0byBpbmNsdWRlIGluIGhhc2ggZ2VuZXJhdGlvbiBmb3IgZGVzdHJveS9jcmVhdGUgb3BlcmF0aW9uc1xuICAgKiBAZGVmYXVsdCAtIHVuZGVmaW5lZFxuICAgKiBAcmV0dXJucyBBIHN0cmluZyBjb250YWluaW5nIHRoZSBnZW5lcmF0ZWQgbmFtZSB3aXRoIGZvcm1hdDogcHJlZml4ICsgaGFzaCArIHNlcGFyYXRvciArIHVuaXF1ZU5hbWVcbiAgICogQHRocm93cyBWYWxpZGF0aW9uRXJyb3IgaWYgdGhlIGdlbmVyYXRlZCBuYW1lIHdvdWxkIGV4Y2VlZCBtYXhMZW5ndGggb3IgaWYgcHJlZml4IGlzIHRvbyBsb25nXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgcHJpdmF0ZSBnZW5lcmF0ZVBoeXNpY2FsTmFtZUhhc2goXG4gICAgc2NvcGU6IElDb25zdHJ1Y3QsXG4gICAgcHJlZml4OiBzdHJpbmcsXG4gICAgb3B0aW9ucz86IHtcbiAgICAgIG1heExlbmd0aD86IG51bWJlcjtcbiAgICAgIGxvd2VyPzogYm9vbGVhbjtcbiAgICAgIHNlcGFyYXRvcj86IHN0cmluZztcbiAgICAgIGFsbG93ZWRTcGVjaWFsQ2hhcmFjdGVycz86IHN0cmluZztcbiAgICAgIGRlc3Ryb3lDcmVhdGU/OiBhbnk7XG4gICAgfSxcbiAgKTogc3RyaW5nIHtcbiAgICBjb25zdCBvYmplY3RUb0hhc2ggPSAob2JqOiBhbnkpOiBzdHJpbmcgPT4ge1xuICAgICAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiAnJzsgfVxuICAgICAgY29uc3QganNvblN0cmluZyA9IEpTT04uc3RyaW5naWZ5KG9iaik7XG4gICAgICBjb25zdCBoYXNoID0gY3J5cHRvLmNyZWF0ZUhhc2goJ3NoYTI1NicpO1xuICAgICAgcmV0dXJuIGhhc2gudXBkYXRlKGpzb25TdHJpbmcpLmRpZ2VzdCgnaGV4Jykuc2xpY2UoMCwgNyk7XG4gICAgfTtcblxuICAgIGNvbnN0IHtcbiAgICAgIG1heExlbmd0aCA9IDI1NixcbiAgICAgIGxvd2VyID0gZmFsc2UsXG4gICAgICBzZXBhcmF0b3IgPSAnJyxcbiAgICAgIGFsbG93ZWRTcGVjaWFsQ2hhcmFjdGVycyA9IHVuZGVmaW5lZCxcbiAgICAgIGRlc3Ryb3lDcmVhdGUgPSB1bmRlZmluZWQsXG4gICAgfSA9IG9wdGlvbnMgPz8ge307XG5cbiAgICBjb25zdCBoYXNoID0gb2JqZWN0VG9IYXNoKGRlc3Ryb3lDcmVhdGUpO1xuICAgIGlmIChtYXhMZW5ndGggPCAocHJlZml4ICsgaGFzaCArIHNlcGFyYXRvcikubGVuZ3RoKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdUaGUgcHJlZml4IGlzIGxvbmdlciB0aGFuIHRoZSBtYXhpbXVtIGxlbmd0aC4nLCB0aGlzKTtcbiAgICB9XG5cbiAgICBjb25zdCB1bmlxdWVOYW1lID0gTmFtZXMudW5pcXVlUmVzb3VyY2VOYW1lKFxuICAgICAgc2NvcGUsXG4gICAgICB7IG1heExlbmd0aDogbWF4TGVuZ3RoIC0gKHByZWZpeCArIGhhc2ggKyBzZXBhcmF0b3IpLmxlbmd0aCwgc2VwYXJhdG9yLCBhbGxvd2VkU3BlY2lhbENoYXJhY3RlcnMgfSxcbiAgICApO1xuICAgIGNvbnN0IG5hbWUgPSBgJHtwcmVmaXh9JHtoYXNofSR7c2VwYXJhdG9yfSR7dW5pcXVlTmFtZX1gO1xuICAgIGlmIChuYW1lLmxlbmd0aCA+IG1heExlbmd0aCkge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgVGhlIGdlbmVyYXRlZCBuYW1lIGlzIGxvbmdlciB0aGFuIHRoZSBtYXhpbXVtIGxlbmd0aCBvZiAke21heExlbmd0aH1gLCB0aGlzKTtcbiAgICB9XG4gICAgcmV0dXJuIGxvd2VyID8gbmFtZS50b0xvd2VyQ2FzZSgpIDogbmFtZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZW5lcmF0ZXMgYSBwaHlzaWNhbCBuYW1lIGZvciB0aGUgYWdlbnQuXG4gICAqIEByZXR1cm5zIEEgdW5pcXVlIG5hbWUgZm9yIHRoZSBhZ2VudCB3aXRoIGFwcHJvcHJpYXRlIGxlbmd0aCBjb25zdHJhaW50c1xuICAgKiBAZGVmYXVsdCAtIEdlbmVyYXRlZCBuYW1lIGZvcm1hdDogJ2FnZW50LXtoYXNofS17dW5pcXVlTmFtZX0nIHdpdGg6XG4gICAqIC0gbWF4TGVuZ3RoOiBNQVhMRU5HVEhfRk9SX1JPTEVfTkFNRSAtICctYmVkcm9ja2FnZW50Jy5sZW5ndGhcbiAgICogLSBsb3dlcjogdHJ1ZVxuICAgKiAtIHNlcGFyYXRvcjogJy0nXG4gICAqIEBwcm90ZWN0ZWRcbiAgICovXG4gIHByb3RlY3RlZCBnZW5lcmF0ZVBoeXNpY2FsTmFtZSgpOiBzdHJpbmcge1xuICAgIGNvbnN0IG1heExlbmd0aCA9IHRoaXMuTUFYTEVOR1RIX0ZPUl9ST0xFX05BTUUgLSB0aGlzLlJPTEVfTkFNRV9TVUZGSVgubGVuZ3RoO1xuICAgIHJldHVybiB0aGlzLmdlbmVyYXRlUGh5c2ljYWxOYW1lSGFzaCh0aGlzLCAnYWdlbnQnLCB7XG4gICAgICBtYXhMZW5ndGgsXG4gICAgICBsb3dlcjogdHJ1ZSxcbiAgICAgIHNlcGFyYXRvcjogJy0nLFxuICAgIH0pO1xuICB9XG59XG4iXX0=