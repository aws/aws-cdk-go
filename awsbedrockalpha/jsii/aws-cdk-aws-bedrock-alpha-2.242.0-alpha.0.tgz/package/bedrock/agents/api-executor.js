"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActionGroupExecutor = exports.CustomControl = void 0;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
/**
 * The type of custom control for the action group executor.
 */
var CustomControl;
(function (CustomControl) {
    /**
     * Returns the action group invocation results directly in the InvokeAgent response.
     */
    CustomControl["RETURN_CONTROL"] = "RETURN_CONTROL";
})(CustomControl || (exports.CustomControl = CustomControl = {}));
/******************************************************************************
 *                         Action Group Executor
 *****************************************************************************/
/**
 * Defines how fulfillment of the action group is handled after the necessary
 * information has been elicited from the user.
 * Valid executors are:
 * - Lambda function
 * - Return Control
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/action-handle.html
 */
class ActionGroupExecutor {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ActionGroupExecutor", version: "2.242.0-alpha.0" };
    /**
     * Returns the action group invocation results directly in the InvokeAgent response.
     * The information and parameters can be sent to your own systems to yield results.
     * @see https://docs.aws.amazon.com/bedrock/latest/userguide/agents-returncontrol.html
     */
    static RETURN_CONTROL = new ActionGroupExecutor(undefined, CustomControl.RETURN_CONTROL);
    /**
     * Defines an action group with a Lambda function containing the business logic.
     * @param lambdaFunction - Lambda function to be called by the action group.
     * @see https://docs.aws.amazon.com/bedrock/latest/userguide/agents-lambda.html
     */
    static fromLambda(lambdaFunction) {
        return new ActionGroupExecutor(lambdaFunction, undefined);
    }
    /**
     * The Lambda function that will be called by the action group.
     * Contains the business logic for handling the action group's invocation.
     */
    lambdaFunction;
    /**
     * The custom control type for the action group executor.
     * Currently only supports 'RETURN_CONTROL' which returns results directly in the InvokeAgent response.
     */
    customControl;
    constructor(lambdaFunction, customControl) {
        if (lambdaFunction && customControl) {
            throw new errors_1.UnscopedValidationError('ActionGroupExecutor cannot have both lambdaFunction and customControl defined - they are mutually exclusive.');
        }
        this.lambdaFunction = lambdaFunction;
        this.customControl = customControl;
    }
    /**
     * Format as CFN properties
     *
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            customControl: this.customControl,
            lambda: this.lambdaFunction?.functionArn,
        };
    }
}
exports.ActionGroupExecutor = ActionGroupExecutor;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLWV4ZWN1dG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYXBpLWV4ZWN1dG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFFQSx3REFBc0U7QUFFdEU7O0dBRUc7QUFDSCxJQUFZLGFBS1g7QUFMRCxXQUFZLGFBQWE7SUFDdkI7O09BRUc7SUFDSCxrREFBaUMsQ0FBQTtBQUNuQyxDQUFDLEVBTFcsYUFBYSw2QkFBYixhQUFhLFFBS3hCO0FBRUQ7OytFQUUrRTtBQUMvRTs7Ozs7OztHQU9HO0FBQ0gsTUFBYSxtQkFBbUI7O0lBQzlCOzs7O09BSUc7SUFDSSxNQUFNLENBQVUsY0FBYyxHQUFHLElBQUksbUJBQW1CLENBQUMsU0FBUyxFQUFFLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUV6Rzs7OztPQUlHO0lBQ0ksTUFBTSxDQUFDLFVBQVUsQ0FBQyxjQUF5QjtRQUNoRCxPQUFPLElBQUksbUJBQW1CLENBQUMsY0FBYyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0tBQzNEO0lBRUQ7OztPQUdHO0lBQ2EsY0FBYyxDQUFhO0lBRTNDOzs7T0FHRztJQUNhLGFBQWEsQ0FBaUI7SUFFOUMsWUFBb0IsY0FBMEIsRUFBRSxhQUE2QjtRQUMzRSxJQUFJLGNBQWMsSUFBSSxhQUFhLEVBQUUsQ0FBQztZQUNwQyxNQUFNLElBQUksZ0NBQXVCLENBQUMsOEdBQThHLENBQUMsQ0FBQztRQUNwSixDQUFDO1FBQ0QsSUFBSSxDQUFDLGNBQWMsR0FBRyxjQUFjLENBQUM7UUFDckMsSUFBSSxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7S0FDcEM7SUFFRDs7OztPQUlHO0lBQ0ksT0FBTztRQUNaLE9BQU87WUFDTCxhQUFhLEVBQUUsSUFBSSxDQUFDLGFBQWE7WUFDakMsTUFBTSxFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsV0FBVztTQUN6QyxDQUFDO0tBQ0g7O0FBL0NILGtEQWdEQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlICogYXMgYmVkcm9jayBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgdHlwZSB7IElGdW5jdGlvbiB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1sYW1iZGEnO1xuaW1wb3J0IHsgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9lcnJvcnMnO1xuXG4vKipcbiAqIFRoZSB0eXBlIG9mIGN1c3RvbSBjb250cm9sIGZvciB0aGUgYWN0aW9uIGdyb3VwIGV4ZWN1dG9yLlxuICovXG5leHBvcnQgZW51bSBDdXN0b21Db250cm9sIHtcbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGFjdGlvbiBncm91cCBpbnZvY2F0aW9uIHJlc3VsdHMgZGlyZWN0bHkgaW4gdGhlIEludm9rZUFnZW50IHJlc3BvbnNlLlxuICAgKi9cbiAgUkVUVVJOX0NPTlRST0wgPSAnUkVUVVJOX0NPTlRST0wnLFxufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICBBY3Rpb24gR3JvdXAgRXhlY3V0b3JcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogRGVmaW5lcyBob3cgZnVsZmlsbG1lbnQgb2YgdGhlIGFjdGlvbiBncm91cCBpcyBoYW5kbGVkIGFmdGVyIHRoZSBuZWNlc3NhcnlcbiAqIGluZm9ybWF0aW9uIGhhcyBiZWVuIGVsaWNpdGVkIGZyb20gdGhlIHVzZXIuXG4gKiBWYWxpZCBleGVjdXRvcnMgYXJlOlxuICogLSBMYW1iZGEgZnVuY3Rpb25cbiAqIC0gUmV0dXJuIENvbnRyb2xcbiAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9hY3Rpb24taGFuZGxlLmh0bWxcbiAqL1xuZXhwb3J0IGNsYXNzIEFjdGlvbkdyb3VwRXhlY3V0b3Ige1xuICAvKipcbiAgICogUmV0dXJucyB0aGUgYWN0aW9uIGdyb3VwIGludm9jYXRpb24gcmVzdWx0cyBkaXJlY3RseSBpbiB0aGUgSW52b2tlQWdlbnQgcmVzcG9uc2UuXG4gICAqIFRoZSBpbmZvcm1hdGlvbiBhbmQgcGFyYW1ldGVycyBjYW4gYmUgc2VudCB0byB5b3VyIG93biBzeXN0ZW1zIHRvIHlpZWxkIHJlc3VsdHMuXG4gICAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9hZ2VudHMtcmV0dXJuY29udHJvbC5odG1sXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFJFVFVSTl9DT05UUk9MID0gbmV3IEFjdGlvbkdyb3VwRXhlY3V0b3IodW5kZWZpbmVkLCBDdXN0b21Db250cm9sLlJFVFVSTl9DT05UUk9MKTtcblxuICAvKipcbiAgICogRGVmaW5lcyBhbiBhY3Rpb24gZ3JvdXAgd2l0aCBhIExhbWJkYSBmdW5jdGlvbiBjb250YWluaW5nIHRoZSBidXNpbmVzcyBsb2dpYy5cbiAgICogQHBhcmFtIGxhbWJkYUZ1bmN0aW9uIC0gTGFtYmRhIGZ1bmN0aW9uIHRvIGJlIGNhbGxlZCBieSB0aGUgYWN0aW9uIGdyb3VwLlxuICAgKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9iZWRyb2NrL2xhdGVzdC91c2VyZ3VpZGUvYWdlbnRzLWxhbWJkYS5odG1sXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21MYW1iZGEobGFtYmRhRnVuY3Rpb246IElGdW5jdGlvbik6IEFjdGlvbkdyb3VwRXhlY3V0b3Ige1xuICAgIHJldHVybiBuZXcgQWN0aW9uR3JvdXBFeGVjdXRvcihsYW1iZGFGdW5jdGlvbiwgdW5kZWZpbmVkKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgTGFtYmRhIGZ1bmN0aW9uIHRoYXQgd2lsbCBiZSBjYWxsZWQgYnkgdGhlIGFjdGlvbiBncm91cC5cbiAgICogQ29udGFpbnMgdGhlIGJ1c2luZXNzIGxvZ2ljIGZvciBoYW5kbGluZyB0aGUgYWN0aW9uIGdyb3VwJ3MgaW52b2NhdGlvbi5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBsYW1iZGFGdW5jdGlvbj86IElGdW5jdGlvbjtcblxuICAvKipcbiAgICogVGhlIGN1c3RvbSBjb250cm9sIHR5cGUgZm9yIHRoZSBhY3Rpb24gZ3JvdXAgZXhlY3V0b3IuXG4gICAqIEN1cnJlbnRseSBvbmx5IHN1cHBvcnRzICdSRVRVUk5fQ09OVFJPTCcgd2hpY2ggcmV0dXJucyByZXN1bHRzIGRpcmVjdGx5IGluIHRoZSBJbnZva2VBZ2VudCByZXNwb25zZS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBjdXN0b21Db250cm9sPzogQ3VzdG9tQ29udHJvbDtcblxuICBwcml2YXRlIGNvbnN0cnVjdG9yKGxhbWJkYUZ1bmN0aW9uPzogSUZ1bmN0aW9uLCBjdXN0b21Db250cm9sPzogQ3VzdG9tQ29udHJvbCkge1xuICAgIGlmIChsYW1iZGFGdW5jdGlvbiAmJiBjdXN0b21Db250cm9sKSB7XG4gICAgICB0aHJvdyBuZXcgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IoJ0FjdGlvbkdyb3VwRXhlY3V0b3IgY2Fubm90IGhhdmUgYm90aCBsYW1iZGFGdW5jdGlvbiBhbmQgY3VzdG9tQ29udHJvbCBkZWZpbmVkIC0gdGhleSBhcmUgbXV0dWFsbHkgZXhjbHVzaXZlLicpO1xuICAgIH1cbiAgICB0aGlzLmxhbWJkYUZ1bmN0aW9uID0gbGFtYmRhRnVuY3Rpb247XG4gICAgdGhpcy5jdXN0b21Db250cm9sID0gY3VzdG9tQ29udHJvbDtcbiAgfVxuXG4gIC8qKlxuICAgKiBGb3JtYXQgYXMgQ0ZOIHByb3BlcnRpZXNcbiAgICpcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBiZWRyb2NrLkNmbkFnZW50LkFjdGlvbkdyb3VwRXhlY3V0b3JQcm9wZXJ0eSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGN1c3RvbUNvbnRyb2w6IHRoaXMuY3VzdG9tQ29udHJvbCxcbiAgICAgIGxhbWJkYTogdGhpcy5sYW1iZGFGdW5jdGlvbj8uZnVuY3Rpb25Bcm4sXG4gICAgfTtcbiAgfVxufVxuIl19