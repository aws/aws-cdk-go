"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3ApiSchema = exports.InlineApiSchema = exports.AssetApiSchema = exports.ApiSchema = void 0;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const s3_assets = require("aws-cdk-lib/aws-s3-assets");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const schema_base_1 = require("./schema-base");
/******************************************************************************
 *                       API SCHEMA CLASS
 *****************************************************************************/
/**
 * Represents the concept of an API Schema for a Bedrock Agent Action Group.
 */
class ApiSchema extends schema_base_1.ActionGroupSchema {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ApiSchema", version: "2.242.0-alpha.0" };
    /**
     * Creates an API Schema from a local file.
     * @param path - the path to the local file containing the OpenAPI schema for the action group
     */
    static fromLocalAsset(path) {
        return new AssetApiSchema(path);
    }
    /**
     * Creates an API Schema from an inline string.
     * @param schema - the JSON or YAML payload defining the OpenAPI schema for the action group
     */
    static fromInline(schema) {
        return new InlineApiSchema(schema);
    }
    /**
     * Creates an API Schema from an S3 File
     * @param bucket - the bucket containing the local file containing the OpenAPI schema for the action group
     * @param objectKey - object key in the bucket
     */
    static fromS3File(bucket, objectKey) {
        return new S3ApiSchema({
            bucketName: bucket.bucketRef.bucketName,
            objectKey: objectKey,
        });
    }
    /**
     * The S3 location of the API schema file, if using an S3-based schema.
     * Contains the bucket name and object key information.
     */
    s3File;
    /**
     * The inline OpenAPI schema definition as a string, if using an inline schema.
     * Can be in JSON or YAML format.
     */
    inlineSchema;
    constructor(s3File, inlineSchema) {
        super();
        this.s3File = s3File;
        this.inlineSchema = inlineSchema;
    }
}
exports.ApiSchema = ApiSchema;
/**
 * API Schema from a local asset.
 *
 * The asset is uploaded to an S3 staging bucket, then moved to its final location
 * by CloudFormation during deployment.
 */
class AssetApiSchema extends ApiSchema {
    path;
    options;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AssetApiSchema", version: "2.242.0-alpha.0" };
    asset;
    constructor(path, options = {}) {
        super();
        this.path = path;
        this.options = options;
    }
    /**
     * Binds this API schema to a construct scope.
     * This method initializes the S3 asset if it hasn't been initialized yet.
     * Must be called before rendering the schema as CFN properties.
     *
     * @param scope - The construct scope to bind to
     */
    bind(scope) {
        // If the same AssetApiSchema is used multiple times, retain only the first instantiation
        if (!this.asset) {
            this.asset = new s3_assets.Asset(scope, 'Schema', {
                path: this.path,
                ...this.options,
            });
            // Note: Permissions will be granted by the Agent construct when adding the action group
        }
    }
    /**
     * Format as CFN properties
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        if (!this.asset) {
            throw new errors_1.UnscopedValidationError('ApiSchema must be bound to a scope before rendering. Call bind() first.');
        }
        return {
            s3: {
                s3BucketName: this.asset.s3BucketName,
                s3ObjectKey: this.asset.s3ObjectKey,
            },
        };
    }
}
exports.AssetApiSchema = AssetApiSchema;
// ------------------------------------------------------
/**
 * Class to define an API Schema from an inline string.
 * The schema can be provided directly as a string in either JSON or YAML format.
 */
class InlineApiSchema extends ApiSchema {
    schema;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.InlineApiSchema", version: "2.242.0-alpha.0" };
    constructor(schema) {
        super(undefined, schema);
        this.schema = schema;
    }
    /**
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            payload: this.schema,
        };
    }
}
exports.InlineApiSchema = InlineApiSchema;
// ------------------------------------------------------
// S3 File
// ------------------------------------------------------
/**
 * Class to define an API Schema from an S3 object.
 */
class S3ApiSchema extends ApiSchema {
    location;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.S3ApiSchema", version: "2.242.0-alpha.0" };
    constructor(location) {
        super(location, undefined);
        this.location = location;
    }
    /**
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            s3: {
                s3BucketName: this.location.bucketName,
                s3ObjectKey: this.location.objectKey,
            },
        };
    }
}
exports.S3ApiSchema = S3ApiSchema;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLXNjaGVtYS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImFwaS1zY2hlbWEudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUVBLHVEQUF1RDtBQUN2RCx3REFBc0U7QUFFdEUsK0NBQWtEO0FBRWxEOzsrRUFFK0U7QUFDL0U7O0dBRUc7QUFDSCxNQUFzQixTQUFVLFNBQVEsK0JBQWlCOztJQUN2RDs7O09BR0c7SUFDSSxNQUFNLENBQUMsY0FBYyxDQUFDLElBQVk7UUFDdkMsT0FBTyxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUNqQztJQUVEOzs7T0FHRztJQUNJLE1BQU0sQ0FBQyxVQUFVLENBQUMsTUFBYztRQUNyQyxPQUFPLElBQUksZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0tBQ3BDO0lBRUQ7Ozs7T0FJRztJQUNJLE1BQU0sQ0FBQyxVQUFVLENBQUMsTUFBa0IsRUFBRSxTQUFpQjtRQUM1RCxPQUFPLElBQUksV0FBVyxDQUFDO1lBQ3JCLFVBQVUsRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQVU7WUFDdkMsU0FBUyxFQUFFLFNBQVM7U0FDckIsQ0FBQyxDQUFDO0tBQ0o7SUFFRDs7O09BR0c7SUFDYSxNQUFNLENBQVk7SUFFbEM7OztPQUdHO0lBQ2EsWUFBWSxDQUFVO0lBRXRDLFlBQXNCLE1BQWlCLEVBQUUsWUFBcUI7UUFDNUQsS0FBSyxFQUFFLENBQUM7UUFDUixJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUNyQixJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztLQUNsQzs7QUE3Q0gsOEJBcURDO0FBRUQ7Ozs7O0dBS0c7QUFDSCxNQUFhLGNBQWUsU0FBUSxTQUFTO0lBR2Q7SUFBK0I7O0lBRnBELEtBQUssQ0FBbUI7SUFFaEMsWUFBNkIsSUFBWSxFQUFtQixVQUFrQyxFQUFFO1FBQzlGLEtBQUssRUFBRSxDQUFDO1FBRG1CLFNBQUksR0FBSixJQUFJLENBQVE7UUFBbUIsWUFBTyxHQUFQLE9BQU8sQ0FBNkI7S0FFL0Y7SUFFRDs7Ozs7O09BTUc7SUFDSSxJQUFJLENBQUMsS0FBZ0I7UUFDMUIseUZBQXlGO1FBQ3pGLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDaEIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRTtnQkFDaEQsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2dCQUNmLEdBQUcsSUFBSSxDQUFDLE9BQU87YUFDaEIsQ0FBQyxDQUFDO1lBQ0gsd0ZBQXdGO1FBQzFGLENBQUM7S0FDRjtJQUVEOzs7T0FHRztJQUNJLE9BQU87UUFDWixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2hCLE1BQU0sSUFBSSxnQ0FBdUIsQ0FBQyx5RUFBeUUsQ0FBQyxDQUFDO1FBQy9HLENBQUM7UUFFRCxPQUFPO1lBQ0wsRUFBRSxFQUFFO2dCQUNGLFlBQVksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVk7Z0JBQ3JDLFdBQVcsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVc7YUFDcEM7U0FDRixDQUFDO0tBQ0g7O0FBeENILHdDQXlDQztBQUVELHlEQUF5RDtBQUN6RDs7O0dBR0c7QUFDSCxNQUFhLGVBQWdCLFNBQVEsU0FBUztJQUNmOztJQUE3QixZQUE2QixNQUFjO1FBQ3pDLEtBQUssQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFERSxXQUFNLEdBQU4sTUFBTSxDQUFRO0tBRTFDO0lBRUQ7O09BRUc7SUFDSSxPQUFPO1FBQ1osT0FBTztZQUNMLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTTtTQUNyQixDQUFDO0tBQ0g7O0FBWkgsMENBYUM7QUFFRCx5REFBeUQ7QUFDekQsVUFBVTtBQUNWLHlEQUF5RDtBQUN6RDs7R0FFRztBQUNILE1BQWEsV0FBWSxTQUFRLFNBQVM7SUFDWDs7SUFBN0IsWUFBNkIsUUFBa0I7UUFDN0MsS0FBSyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQURBLGFBQVEsR0FBUixRQUFRLENBQVU7S0FFOUM7SUFDRDs7T0FFRztJQUNJLE9BQU87UUFDWixPQUFPO1lBQ0wsRUFBRSxFQUFFO2dCQUNGLFlBQVksRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVU7Z0JBQ3RDLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVM7YUFDckM7U0FDRixDQUFDO0tBQ0g7O0FBZEgsa0NBZUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IENmbkFnZW50IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHR5cGUgeyBJQnVja2V0UmVmLCBMb2NhdGlvbiB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1zMyc7XG5pbXBvcnQgKiBhcyBzM19hc3NldHMgZnJvbSAnYXdzLWNkay1saWIvYXdzLXMzLWFzc2V0cyc7XG5pbXBvcnQgeyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvciB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2Vycm9ycyc7XG5pbXBvcnQgdHlwZSB7IENvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuaW1wb3J0IHsgQWN0aW9uR3JvdXBTY2hlbWEgfSBmcm9tICcuL3NjaGVtYS1iYXNlJztcblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgIEFQSSBTQ0hFTUEgQ0xBU1NcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogUmVwcmVzZW50cyB0aGUgY29uY2VwdCBvZiBhbiBBUEkgU2NoZW1hIGZvciBhIEJlZHJvY2sgQWdlbnQgQWN0aW9uIEdyb3VwLlxuICovXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgQXBpU2NoZW1hIGV4dGVuZHMgQWN0aW9uR3JvdXBTY2hlbWEge1xuICAvKipcbiAgICogQ3JlYXRlcyBhbiBBUEkgU2NoZW1hIGZyb20gYSBsb2NhbCBmaWxlLlxuICAgKiBAcGFyYW0gcGF0aCAtIHRoZSBwYXRoIHRvIHRoZSBsb2NhbCBmaWxlIGNvbnRhaW5pbmcgdGhlIE9wZW5BUEkgc2NoZW1hIGZvciB0aGUgYWN0aW9uIGdyb3VwXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21Mb2NhbEFzc2V0KHBhdGg6IHN0cmluZyk6IEFzc2V0QXBpU2NoZW1hIHtcbiAgICByZXR1cm4gbmV3IEFzc2V0QXBpU2NoZW1hKHBhdGgpO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYW4gQVBJIFNjaGVtYSBmcm9tIGFuIGlubGluZSBzdHJpbmcuXG4gICAqIEBwYXJhbSBzY2hlbWEgLSB0aGUgSlNPTiBvciBZQU1MIHBheWxvYWQgZGVmaW5pbmcgdGhlIE9wZW5BUEkgc2NoZW1hIGZvciB0aGUgYWN0aW9uIGdyb3VwXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21JbmxpbmUoc2NoZW1hOiBzdHJpbmcpOiBJbmxpbmVBcGlTY2hlbWEge1xuICAgIHJldHVybiBuZXcgSW5saW5lQXBpU2NoZW1hKHNjaGVtYSk7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBhbiBBUEkgU2NoZW1hIGZyb20gYW4gUzMgRmlsZVxuICAgKiBAcGFyYW0gYnVja2V0IC0gdGhlIGJ1Y2tldCBjb250YWluaW5nIHRoZSBsb2NhbCBmaWxlIGNvbnRhaW5pbmcgdGhlIE9wZW5BUEkgc2NoZW1hIGZvciB0aGUgYWN0aW9uIGdyb3VwXG4gICAqIEBwYXJhbSBvYmplY3RLZXkgLSBvYmplY3Qga2V5IGluIHRoZSBidWNrZXRcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbVMzRmlsZShidWNrZXQ6IElCdWNrZXRSZWYsIG9iamVjdEtleTogc3RyaW5nKTogUzNBcGlTY2hlbWEge1xuICAgIHJldHVybiBuZXcgUzNBcGlTY2hlbWEoe1xuICAgICAgYnVja2V0TmFtZTogYnVja2V0LmJ1Y2tldFJlZi5idWNrZXROYW1lLFxuICAgICAgb2JqZWN0S2V5OiBvYmplY3RLZXksXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVGhlIFMzIGxvY2F0aW9uIG9mIHRoZSBBUEkgc2NoZW1hIGZpbGUsIGlmIHVzaW5nIGFuIFMzLWJhc2VkIHNjaGVtYS5cbiAgICogQ29udGFpbnMgdGhlIGJ1Y2tldCBuYW1lIGFuZCBvYmplY3Qga2V5IGluZm9ybWF0aW9uLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHMzRmlsZT86IExvY2F0aW9uO1xuXG4gIC8qKlxuICAgKiBUaGUgaW5saW5lIE9wZW5BUEkgc2NoZW1hIGRlZmluaXRpb24gYXMgYSBzdHJpbmcsIGlmIHVzaW5nIGFuIGlubGluZSBzY2hlbWEuXG4gICAqIENhbiBiZSBpbiBKU09OIG9yIFlBTUwgZm9ybWF0LlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGlubGluZVNjaGVtYT86IHN0cmluZztcblxuICBwcm90ZWN0ZWQgY29uc3RydWN0b3IoczNGaWxlPzogTG9jYXRpb24sIGlubGluZVNjaGVtYT86IHN0cmluZykge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5zM0ZpbGUgPSBzM0ZpbGU7XG4gICAgdGhpcy5pbmxpbmVTY2hlbWEgPSBpbmxpbmVTY2hlbWE7XG4gIH1cblxuICAvKipcbiAgICogRm9ybWF0IGFzIENGTiBwcm9wZXJ0aWVzXG4gICAqXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIGFic3RyYWN0IF9yZW5kZXIoKTogQ2ZuQWdlbnQuQVBJU2NoZW1hUHJvcGVydHk7XG59XG5cbi8qKlxuICogQVBJIFNjaGVtYSBmcm9tIGEgbG9jYWwgYXNzZXQuXG4gKlxuICogVGhlIGFzc2V0IGlzIHVwbG9hZGVkIHRvIGFuIFMzIHN0YWdpbmcgYnVja2V0LCB0aGVuIG1vdmVkIHRvIGl0cyBmaW5hbCBsb2NhdGlvblxuICogYnkgQ2xvdWRGb3JtYXRpb24gZHVyaW5nIGRlcGxveW1lbnQuXG4gKi9cbmV4cG9ydCBjbGFzcyBBc3NldEFwaVNjaGVtYSBleHRlbmRzIEFwaVNjaGVtYSB7XG4gIHByaXZhdGUgYXNzZXQ/OiBzM19hc3NldHMuQXNzZXQ7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSByZWFkb25seSBwYXRoOiBzdHJpbmcsIHByaXZhdGUgcmVhZG9ubHkgb3B0aW9uczogczNfYXNzZXRzLkFzc2V0T3B0aW9ucyA9IHt9KSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBCaW5kcyB0aGlzIEFQSSBzY2hlbWEgdG8gYSBjb25zdHJ1Y3Qgc2NvcGUuXG4gICAqIFRoaXMgbWV0aG9kIGluaXRpYWxpemVzIHRoZSBTMyBhc3NldCBpZiBpdCBoYXNuJ3QgYmVlbiBpbml0aWFsaXplZCB5ZXQuXG4gICAqIE11c3QgYmUgY2FsbGVkIGJlZm9yZSByZW5kZXJpbmcgdGhlIHNjaGVtYSBhcyBDRk4gcHJvcGVydGllcy5cbiAgICpcbiAgICogQHBhcmFtIHNjb3BlIC0gVGhlIGNvbnN0cnVjdCBzY29wZSB0byBiaW5kIHRvXG4gICAqL1xuICBwdWJsaWMgYmluZChzY29wZTogQ29uc3RydWN0KTogdm9pZCB7XG4gICAgLy8gSWYgdGhlIHNhbWUgQXNzZXRBcGlTY2hlbWEgaXMgdXNlZCBtdWx0aXBsZSB0aW1lcywgcmV0YWluIG9ubHkgdGhlIGZpcnN0IGluc3RhbnRpYXRpb25cbiAgICBpZiAoIXRoaXMuYXNzZXQpIHtcbiAgICAgIHRoaXMuYXNzZXQgPSBuZXcgczNfYXNzZXRzLkFzc2V0KHNjb3BlLCAnU2NoZW1hJywge1xuICAgICAgICBwYXRoOiB0aGlzLnBhdGgsXG4gICAgICAgIC4uLnRoaXMub3B0aW9ucyxcbiAgICAgIH0pO1xuICAgICAgLy8gTm90ZTogUGVybWlzc2lvbnMgd2lsbCBiZSBncmFudGVkIGJ5IHRoZSBBZ2VudCBjb25zdHJ1Y3Qgd2hlbiBhZGRpbmcgdGhlIGFjdGlvbiBncm91cFxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBGb3JtYXQgYXMgQ0ZOIHByb3BlcnRpZXNcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBDZm5BZ2VudC5BUElTY2hlbWFQcm9wZXJ0eSB7XG4gICAgaWYgKCF0aGlzLmFzc2V0KSB7XG4gICAgICB0aHJvdyBuZXcgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IoJ0FwaVNjaGVtYSBtdXN0IGJlIGJvdW5kIHRvIGEgc2NvcGUgYmVmb3JlIHJlbmRlcmluZy4gQ2FsbCBiaW5kKCkgZmlyc3QuJyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHMzOiB7XG4gICAgICAgIHMzQnVja2V0TmFtZTogdGhpcy5hc3NldC5zM0J1Y2tldE5hbWUsXG4gICAgICAgIHMzT2JqZWN0S2V5OiB0aGlzLmFzc2V0LnMzT2JqZWN0S2V5LFxuICAgICAgfSxcbiAgICB9O1xuICB9XG59XG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLyoqXG4gKiBDbGFzcyB0byBkZWZpbmUgYW4gQVBJIFNjaGVtYSBmcm9tIGFuIGlubGluZSBzdHJpbmcuXG4gKiBUaGUgc2NoZW1hIGNhbiBiZSBwcm92aWRlZCBkaXJlY3RseSBhcyBhIHN0cmluZyBpbiBlaXRoZXIgSlNPTiBvciBZQU1MIGZvcm1hdC5cbiAqL1xuZXhwb3J0IGNsYXNzIElubGluZUFwaVNjaGVtYSBleHRlbmRzIEFwaVNjaGVtYSB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgc2NoZW1hOiBzdHJpbmcpIHtcbiAgICBzdXBlcih1bmRlZmluZWQsIHNjaGVtYSk7XG4gIH1cblxuICAvKipcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBDZm5BZ2VudC5BUElTY2hlbWFQcm9wZXJ0eSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHBheWxvYWQ6IHRoaXMuc2NoZW1hLFxuICAgIH07XG4gIH1cbn1cblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyBTMyBGaWxlXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8qKlxuICogQ2xhc3MgdG8gZGVmaW5lIGFuIEFQSSBTY2hlbWEgZnJvbSBhbiBTMyBvYmplY3QuXG4gKi9cbmV4cG9ydCBjbGFzcyBTM0FwaVNjaGVtYSBleHRlbmRzIEFwaVNjaGVtYSB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgbG9jYXRpb246IExvY2F0aW9uKSB7XG4gICAgc3VwZXIobG9jYXRpb24sIHVuZGVmaW5lZCk7XG4gIH1cbiAgLyoqXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIF9yZW5kZXIoKTogQ2ZuQWdlbnQuQVBJU2NoZW1hUHJvcGVydHkge1xuICAgIHJldHVybiB7XG4gICAgICBzMzoge1xuICAgICAgICBzM0J1Y2tldE5hbWU6IHRoaXMubG9jYXRpb24uYnVja2V0TmFtZSxcbiAgICAgICAgczNPYmplY3RLZXk6IHRoaXMubG9jYXRpb24ub2JqZWN0S2V5LFxuICAgICAgfSxcbiAgICB9O1xuICB9XG59XG4iXX0=