"use strict";
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Guardrail = exports.GuardrailBase = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const fs = require("fs");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const bedrock = require("aws-cdk-lib/aws-bedrock");
const aws_cloudwatch_1 = require("aws-cdk-lib/aws-cloudwatch");
const iam = require("aws-cdk-lib/aws-iam");
const aws_kms_1 = require("aws-cdk-lib/aws-kms");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
// Internal Libs
const filters = require("./guardrail-filters");
const guardrail_version_1 = require("./guardrail-version");
/**
 * Abstract base class for a Guardrail.
 * Contains methods and attributes valid for Guardrails either created with CDK or imported.
 */
class GuardrailBase extends aws_cdk_lib_1.Resource {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.GuardrailBase", version: "2.242.0-alpha.0" };
    /**
     * Return the given named metric for all guardrails.
     *
     * By default, the metric will be calculated as a sum over a period of 5 minutes.
     * You can customize this by using the `statistic` and `period` properties.
     */
    static metricAll(metricName, props) {
        return new aws_cloudwatch_1.Metric({
            namespace: 'AWS/Bedrock/Guardrails',
            dimensionsMap: { Operation: 'ApplyGuardrail' },
            metricName,
            ...props,
        });
    }
    /**
     * Return the invocations metric for all guardrails.
     */
    static metricAllInvocations(props) {
        return this.metricAll('Invocations', props);
    }
    /**
     * Return the text unit count metric for all guardrails.
     */
    static metricAllTextUnitCount(props) {
        return this.metricAll('TextUnitCount', props);
    }
    /**
     * Return the invocations intervened metric for all guardrails.
     */
    static metricAllInvocationsIntervened(props) {
        return this.metricAll('InvocationsIntervened', props);
    }
    /**
     * Return the invocation latency metric for all guardrails.
     */
    static metricAllInvocationLatency(props) {
        return this.metricAll('InvocationLatency', props);
    }
    _version = 'DRAFT';
    /**
     * The version of the guardrail.
     * @attribute
     */
    get guardrailVersion() {
        return this._version;
    }
    updateVersion(version) {
        this._version = version;
    }
    /**
     * Grant the given principal identity permissions to perform actions on this guardrail.
     * [disable-awslint:no-grants]
     */
    grant(grantee, ...actions) {
        return iam.Grant.addToPrincipal({
            grantee,
            actions,
            resourceArns: [this.guardrailArn],
        });
    }
    /**
     * Grant the given identity permissions to apply the guardrail.
     * [disable-awslint:no-grants]
     */
    grantApply(grantee) {
        const baseGrant = this.grant(grantee, 'bedrock:ApplyGuardrail');
        if (this.kmsKey) {
            // If KMS key exists, create encryption grant and combine with base grant
            const kmsGrant = this.kmsKey.grantEncryptDecrypt(grantee);
            return kmsGrant.combine(baseGrant);
        }
        else {
            // If no KMS key exists, return only the base grant
            return baseGrant;
        }
    }
    /**
     * Return the given named metric for this guardrail.
     *
     * By default, the metric will be calculated as a sum over a period of 5 minutes.
     * You can customize this by using the `statistic` and `period` properties.
     */
    metric(metricName, props) {
        const metricProps = {
            namespace: 'AWS/Bedrock/Guardrails',
            metricName,
            dimensionsMap: { GuardrailArn: this.guardrailArn, GuardrailVersion: this.guardrailVersion },
            ...props,
        };
        return this.configureMetric(metricProps);
    }
    /**
     * Return the invocations metric for this guardrail.
     */
    metricInvocations(props) {
        return this.metric('Invocations', props);
    }
    /**
     * Return the invocation latency metric for this guardrail.
     */
    metricInvocationLatency(props) {
        return this.metric('InvocationLatency', props);
    }
    /**
     * Return the invocation client errors metric for this guardrail.
     */
    metricInvocationClientErrors(props) {
        return this.metric('InvocationClientErrors', props);
    }
    /**
     * Return the invocation server errors metric for this guardrail.
     */
    metricInvocationServerErrors(props) {
        return this.metric('InvocationServerErrors', props);
    }
    /**
     * Return the invocation throttles metric for this guardrail.
     */
    metricInvocationThrottles(props) {
        return this.metric('InvocationThrottles', props);
    }
    /**
     * Return the text unit count metric for this guardrail.
     */
    metricTextUnitCount(props) {
        return this.metric('TextUnitCount', props);
    }
    /**
     * Return the invocations intervened metric for this guardrail.
     */
    metricInvocationsIntervened(props) {
        return this.metric('InvocationsIntervened', props);
    }
    configureMetric(props) {
        return new aws_cloudwatch_1.Metric({
            ...props,
            region: props?.region ?? this.stack.region,
            account: props?.account ?? this.stack.account,
        });
    }
}
exports.GuardrailBase = GuardrailBase;
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create a Guardrail with CDK.
 * @cloudformationResource AWS::Bedrock::Guardrail
 */
let Guardrail = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = GuardrailBase;
    let _instanceExtraInitializers = [];
    let _addContentFilter_decorators;
    let _addPIIFilter_decorators;
    let _addRegexFilter_decorators;
    let _addDeniedTopicFilter_decorators;
    let _addContextualGroundingFilter_decorators;
    let _addWordFilter_decorators;
    let _addWordFilterFromFile_decorators;
    let _addManagedWordListFilter_decorators;
    let _createVersion_decorators;
    var Guardrail = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _addContentFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addPIIFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addRegexFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addDeniedTopicFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addContextualGroundingFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addWordFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addWordFilterFromFile_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addManagedWordListFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _createVersion_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            __esDecorate(this, null, _addContentFilter_decorators, { kind: "method", name: "addContentFilter", static: false, private: false, access: { has: obj => "addContentFilter" in obj, get: obj => obj.addContentFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addPIIFilter_decorators, { kind: "method", name: "addPIIFilter", static: false, private: false, access: { has: obj => "addPIIFilter" in obj, get: obj => obj.addPIIFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addRegexFilter_decorators, { kind: "method", name: "addRegexFilter", static: false, private: false, access: { has: obj => "addRegexFilter" in obj, get: obj => obj.addRegexFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addDeniedTopicFilter_decorators, { kind: "method", name: "addDeniedTopicFilter", static: false, private: false, access: { has: obj => "addDeniedTopicFilter" in obj, get: obj => obj.addDeniedTopicFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addContextualGroundingFilter_decorators, { kind: "method", name: "addContextualGroundingFilter", static: false, private: false, access: { has: obj => "addContextualGroundingFilter" in obj, get: obj => obj.addContextualGroundingFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addWordFilter_decorators, { kind: "method", name: "addWordFilter", static: false, private: false, access: { has: obj => "addWordFilter" in obj, get: obj => obj.addWordFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addWordFilterFromFile_decorators, { kind: "method", name: "addWordFilterFromFile", static: false, private: false, access: { has: obj => "addWordFilterFromFile" in obj, get: obj => obj.addWordFilterFromFile }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addManagedWordListFilter_decorators, { kind: "method", name: "addManagedWordListFilter", static: false, private: false, access: { has: obj => "addManagedWordListFilter" in obj, get: obj => obj.addManagedWordListFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _createVersion_decorators, { kind: "method", name: "createVersion", static: false, private: false, access: { has: obj => "createVersion" in obj, get: obj => obj.createVersion }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            Guardrail = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.Guardrail", version: "2.242.0-alpha.0" };
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.Guardrail';
        /**
         * Import a guardrail given its attributes
         */
        static fromGuardrailAttributes(scope, id, attrs) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_GuardrailAttributes(attrs);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.fromGuardrailAttributes);
                }
                throw error;
            }
            class Import extends GuardrailBase {
                guardrailArn = attrs.guardrailArn;
                guardrailId = aws_cdk_lib_1.Arn.split(attrs.guardrailArn, aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME).resourceName;
                kmsKey = attrs.kmsKey;
                lastUpdated = undefined;
                constructor() {
                    super(scope, id);
                    this.updateVersion(attrs.guardrailVersion ?? 'DRAFT');
                }
            }
            return new Import();
        }
        /**
         * Import a low-level L1 Cfn Guardrail
         */
        static fromCfnGuardrail(cfnGuardrail) {
            return new (class extends GuardrailBase {
                guardrailArn = cfnGuardrail.attrGuardrailArn;
                guardrailId = cfnGuardrail.attrGuardrailId;
                kmsKey = cfnGuardrail.kmsKeyArn
                    ? aws_kms_1.Key.fromKeyArn(this, '@FromCfnGuardrailKey', cfnGuardrail.kmsKeyArn)
                    : undefined;
                lastUpdated = cfnGuardrail.attrUpdatedAt;
                constructor() {
                    super(cfnGuardrail, '@FromCfnGuardrail');
                    this.updateVersion(cfnGuardrail.attrVersion);
                }
            })();
        }
        /**
         * The ARN of the guardrail.
         * @attribute
         */
        guardrailArn = __runInitializers(this, _instanceExtraInitializers);
        /**
         * The ID of the guardrail.
         * @attribute
         */
        guardrailId;
        /**
         * The name of the guardrail.
         */
        name;
        /**
         * The KMS key used to encrypt data.
         *
         * @default undefined - "Data is encrypted by default with a key that AWS owns and manages for you"
         */
        kmsKey;
        /**
         * The content filters applied by the guardrail.
         */
        contentFilters;
        /**
         * The PII filters applied by the guardrail.
         */
        piiFilters;
        /**
         * The regex filters applied by the guardrail.
         */
        regexFilters;
        /**
         * The denied topic filters applied by the guardrail.
         */
        deniedTopics;
        /**
         * The contextual grounding filters applied by the guardrail.
         */
        contextualGroundingFilters;
        /**
         * The word filters applied by the guardrail.
         */
        wordFilters;
        /**
         * The managed word list filters applied by the guardrail.
         */
        managedWordListFilters;
        /**
         * When this guardrail was last updated
         */
        lastUpdated;
        /**
         * The computed hash of the guardrail properties.
         */
        hash;
        /**
         * The L1 representation of the guardrail
         */
        __resource;
        /**
         * The tier that your guardrail uses for denied topic filters.
         * @default filters.TierConfig.CLASSIC
         */
        topicsTierConfig;
        /**
         * The tier that your guardrail uses for content filters.
         * Consider using a tier that balances performance, accuracy, and compatibility with your existing generative AI workflows.
         * @default filters.TierConfig.CLASSIC
         */
        contentFiltersTierConfig;
        /**
         * The cross-region configuration for the guardrail.
         */
        crossRegionConfig;
        /**
         * The message to return when the guardrail blocks a prompt.
         * @default "Sorry, your query violates our usage policy."
         */
        blockedInputMessaging;
        /**
         * The message to return when the guardrail blocks a model response.
         * @default "Sorry, I am unable to answer your question because of our usage policy."
         */
        blockedOutputsMessaging;
        constructor(scope, id, props) {
            super(scope, id, {
                physicalName: props.guardrailName,
            });
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_GuardrailProps(props);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, Guardrail);
                }
                throw error;
            }
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            // ------------------------------------------------------
            // Set properties or defaults
            // ------------------------------------------------------
            this.name = this.physicalName;
            this.contentFilters = props.contentFilters ?? [];
            this.piiFilters = props.piiFilters ?? [];
            this.regexFilters = props.regexFilters ?? [];
            this.deniedTopics = props.deniedTopics ?? [];
            this.contextualGroundingFilters = props.contextualGroundingFilters ?? [];
            this.wordFilters = props.wordFilters ?? [];
            this.managedWordListFilters = props.managedWordListFilters ?? [];
            this.topicsTierConfig = props.topicsTierConfig ?? filters.TierConfig.CLASSIC;
            this.contentFiltersTierConfig = props.contentFiltersTierConfig ?? filters.TierConfig.CLASSIC;
            this.crossRegionConfig = props.crossRegionConfig;
            this.blockedInputMessaging = props.blockedInputMessaging ?? 'Sorry, your query violates our usage policy.';
            this.blockedOutputsMessaging = props.blockedOutputsMessaging ?? 'Sorry, I am unable to answer your question because of our usage policy.';
            // ------------------------------------------------------
            // Validate all filter arrays
            // ------------------------------------------------------
            this.validateContentFilters(this.contentFilters);
            this.validatePiiFilters(this.piiFilters);
            this.validateRegexFilters(this.regexFilters);
            this.validateDeniedTopics(this.deniedTopics);
            this.validateContextualGroundingFilters(this.contextualGroundingFilters);
            this.validateWordFilters(this.wordFilters);
            this.validateManagedWordListFilters(this.managedWordListFilters);
            // ------------------------------------------------------
            // Validate messaging properties
            // ------------------------------------------------------
            this.validateMessagingProperty(this.blockedInputMessaging, 'blockedInputMessaging');
            this.validateMessagingProperty(this.blockedOutputsMessaging, 'blockedOutputsMessaging');
            // ------------------------------------------------------
            // Validate tier configuration requirements
            // ------------------------------------------------------
            this.validateTierConfiguration(props);
            // ------------------------------------------------------
            // CFN Props - With Lazy support
            // ------------------------------------------------------
            let cfnProps = {
                name: props.guardrailName,
                description: props.description,
                kmsKeyArn: props.kmsKey?.keyArn,
                blockedInputMessaging: this.blockedInputMessaging,
                blockedOutputsMessaging: this.blockedOutputsMessaging,
                // Lazy props
                crossRegionConfig: this.generateCfnCrossRegionConfig(),
                contentPolicyConfig: this.generateCfnContentPolicyConfig(),
                contextualGroundingPolicyConfig: this.generateCfnContextualPolicyConfig(),
                topicPolicyConfig: this.generateCfnTopicPolicy(),
                wordPolicyConfig: this.generateCfnWordPolicyConfig(),
                sensitiveInformationPolicyConfig: this.generateCfnSensitiveInformationPolicyConfig(),
            };
            // Hash calculation useful for versioning of the guardrail
            this.hash = (0, helpers_internal_1.md5hash)(JSON.stringify(cfnProps));
            // ------------------------------------------------------
            // L1 Instantiation
            // ------------------------------------------------------
            this.__resource = new bedrock.CfnGuardrail(this, 'MyGuardrail', cfnProps);
            this.guardrailId = this.__resource.attrGuardrailId;
            this.guardrailArn = this.__resource.attrGuardrailArn;
            this.updateVersion(this.__resource.attrVersion);
            this.lastUpdated = this.__resource.attrUpdatedAt;
        }
        // ------------------------------------------------------
        // METHODS
        // ------------------------------------------------------
        /**
         * Adds a content filter to the guardrail.
         * @param filter The content filter to add.
         */
        addContentFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ContentFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addContentFilter);
                }
                throw error;
            }
            this.validateSingleContentFilter(filter);
            this.contentFilters.push(filter);
        }
        /**
         * Adds a PII filter to the guardrail.
         * @param filter The PII filter to add.
         */
        addPIIFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_PIIFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addPIIFilter);
                }
                throw error;
            }
            this.validateSinglePiiFilter(filter);
            this.piiFilters.push(filter);
        }
        /**
         * Adds a regex filter to the guardrail.
         * @param filter The regex filter to add.
         */
        addRegexFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_RegexFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addRegexFilter);
                }
                throw error;
            }
            this.validateSingleRegexFilter(filter);
            this.regexFilters.push(filter);
        }
        /**
         * Adds a denied topic filter to the guardrail.
         * @param filter The denied topic filter to add.
         */
        addDeniedTopicFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_Topic(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addDeniedTopicFilter);
                }
                throw error;
            }
            this.validateSingleDeniedTopic(filter);
            this.deniedTopics.push(filter);
        }
        /**
         * Adds a contextual grounding filter to the guardrail.
         * @param filter The contextual grounding filter to add.
         */
        addContextualGroundingFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ContextualGroundingFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addContextualGroundingFilter);
                }
                throw error;
            }
            this.validateSingleContextualGroundingFilter(filter);
            this.contextualGroundingFilters.push(filter);
        }
        /**
         * Adds a word filter to the guardrail.
         * @param filter The word filter to add.
         */
        addWordFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_WordFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addWordFilter);
                }
                throw error;
            }
            this.validateSingleWordFilter(filter);
            this.wordFilters.push(filter);
        }
        /**
         * Adds a word filter to the guardrail.
         * @param filePath The location of the word filter file.
         */
        addWordFilterFromFile(filePath, inputAction, outputAction, inputEnabled, outputEnabled) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_GuardrailAction(inputAction);
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_GuardrailAction(outputAction);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addWordFilterFromFile);
                }
                throw error;
            }
            const fileContents = fs.readFileSync(filePath, 'utf8');
            const words = fileContents.trim().split(',');
            for (const word of words)
                this.addWordFilter({ text: word, inputAction, outputAction, inputEnabled, outputEnabled });
        }
        /**
         * Adds a managed word list filter to the guardrail.
         * @param filter The managed word list filter to add.
         */
        addManagedWordListFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ManagedWordFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addManagedWordListFilter);
                }
                throw error;
            }
            this.validateSingleManagedWordListFilter(filter);
            this.managedWordListFilters.push(filter);
        }
        /**
         * Create a version for the guardrail.
         * @param description The description of the version.
         * @returns The guardrail version.
         */
        createVersion(description) {
            const cfnVersion = new guardrail_version_1.GuardrailVersion(this, `GuardrailVersion-${this.hash.slice(0, 16)}`, {
                description: description,
                guardrail: this,
            });
            this.updateVersion(cfnVersion.guardrailVersion);
            return this.guardrailVersion;
        }
        // ------------------------------------------------------
        // CFN Generators
        // ------------------------------------------------------
        /**
         * Returns the content filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnContentPolicyConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.contentFilters.length > 0) {
                        const contentPolicyConfig = {
                            filtersConfig: this.contentFilters,
                            ...(this.contentFiltersTierConfig && {
                                contentFiltersTierConfig: {
                                    tierName: this.contentFiltersTierConfig,
                                },
                            }),
                        };
                        return contentPolicyConfig;
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Returns the topic filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnTopicPolicy() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.deniedTopics.length > 0) {
                        const topicPolicyConfig = {
                            topicsConfig: this.deniedTopics.flatMap((topic) => {
                                return {
                                    definition: topic.definition,
                                    name: topic.name,
                                    examples: topic.examples,
                                    type: 'DENY',
                                    inputAction: topic.inputAction,
                                    inputEnabled: topic.inputEnabled,
                                    outputAction: topic.outputAction,
                                    outputEnabled: topic.outputEnabled,
                                };
                            }),
                            ...(this.topicsTierConfig && {
                                topicsTierConfig: {
                                    tierName: this.topicsTierConfig,
                                },
                            }),
                        };
                        return topicPolicyConfig;
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Returns the contectual filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnContextualPolicyConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.contextualGroundingFilters.length > 0) {
                        return {
                            filtersConfig: this.contextualGroundingFilters.flatMap((filter) => {
                                return {
                                    type: filter.type,
                                    threshold: filter.threshold,
                                    action: filter.action,
                                    enabled: filter.enabled,
                                };
                            }),
                        };
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Returns the word config applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnWordPolicyConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.wordFilters.length > 0 || this.managedWordListFilters.length > 0) {
                        return {
                            wordsConfig: this.generateCfnWordConfig(),
                            managedWordListsConfig: this.generateCfnManagedWordListsConfig(),
                        };
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Returns the word filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnWordConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    return this.wordFilters.flatMap((word) => {
                        return {
                            text: word.text,
                            inputAction: word.inputAction,
                            inputEnabled: word.inputEnabled,
                            outputAction: word.outputAction,
                            outputEnabled: word.outputEnabled,
                        };
                    });
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the word filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnManagedWordListsConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    return this.managedWordListFilters.flatMap((filter) => {
                        return {
                            type: filter.type,
                            inputAction: filter.inputAction,
                            inputEnabled: filter.inputEnabled,
                            outputAction: filter.outputAction,
                            outputEnabled: filter.outputEnabled,
                        };
                    });
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the sensitive information config applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnSensitiveInformationPolicyConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.regexFilters.length > 0 || this.piiFilters.length > 0) {
                        return {
                            regexesConfig: this.generateCfnRegexesConfig(),
                            piiEntitiesConfig: this.generateCfnPiiEntitiesConfig(),
                        };
                    }
                    else {
                        return undefined;
                    }
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the regex filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnRegexesConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    return this.regexFilters.flatMap((regex) => {
                        return {
                            name: regex.name,
                            description: regex.description,
                            pattern: regex.pattern,
                            action: regex.action,
                            inputAction: regex.inputAction,
                            inputEnabled: regex.inputEnabled,
                            outputAction: regex.outputAction,
                            outputEnabled: regex.outputEnabled,
                        };
                    });
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the Pii filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnPiiEntitiesConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    return this.piiFilters.flatMap((filter) => {
                        return {
                            type: filter.type.value,
                            action: filter.action,
                            inputAction: filter.inputAction,
                            inputEnabled: filter.inputEnabled,
                            outputAction: filter.outputAction,
                            outputEnabled: filter.outputEnabled,
                        };
                    });
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the cross-region configuration for the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnCrossRegionConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.crossRegionConfig) {
                        return {
                            guardrailProfileArn: this.crossRegionConfig.guardrailProfileArn,
                        };
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Validates a RegexFilter object and applies default values for optional properties.
         * @param filter The regex filter to validate.
         * @param index Optional index for error messages when validating arrays.
         */
        validateRegexFilter(filter, index) {
            const prefix = index !== undefined ? `Invalid RegexFilter at index ${index}` : 'Invalid RegexFilter';
            // Validate name: between 1 and 100 characters
            if (filter.name !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.name)) {
                if (filter.name.length < 1) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: The field name is ${filter.name.length} characters long but must be at least 1 characters`, this);
                }
                if (filter.name.length > 100) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: The field name is ${filter.name.length} characters long but must be less than or equal to 100 characters`, this);
                }
            }
            // Validate description: between 1 and 1000 characters (if provided)
            if (filter.description !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.description)) {
                if (filter.description.length < 1) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: The field description is ${filter.description.length} characters long but must be at least 1 characters`, this);
                }
                if (filter.description.length > 1000) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: The field description is ${filter.description.length} characters long but must be less than or equal to 1000 characters`, this);
                }
            }
            // Validate pattern: at least one character
            if (filter.pattern !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.pattern)) {
                if (filter.pattern.length < 1) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: The field pattern is ${filter.pattern.length} characters long but must be at least 1 characters`, this);
                }
            }
            // Validate action: must be a valid GuardrailAction value
            if (filter.action !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.action) && !Object.values(filters.GuardrailAction).includes(filter.action)) {
                throw new aws_cdk_lib_1.ValidationError(`${prefix}: action must be a valid GuardrailAction value`, this);
            }
            // Validate inputAction: must be a valid GuardrailAction value (if provided)
            if (filter.inputAction !== undefined &&
                !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputAction must be a valid GuardrailAction value`, this);
            }
            // Validate outputAction: must be a valid GuardrailAction value (if provided)
            if (filter.outputAction !== undefined &&
                !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputAction must be a valid GuardrailAction value`, this);
            }
            // Validate inputEnabled: must be a boolean (if provided)
            if (filter.inputEnabled !== undefined &&
                !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                typeof filter.inputEnabled !== 'boolean') {
                throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputEnabled must be a boolean value`, this);
            }
            // Validate outputEnabled: must be a boolean (if provided)
            if (filter.outputEnabled !== undefined &&
                !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                typeof filter.outputEnabled !== 'boolean') {
                throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputEnabled must be a boolean value`, this);
            }
            // Apply default values for optional properties if not provided
            if (filter.inputAction === undefined) {
                filter.inputAction = filters.GuardrailAction.BLOCK;
            }
            if (filter.inputEnabled === undefined) {
                filter.inputEnabled = true;
            }
            if (filter.outputAction === undefined) {
                filter.outputAction = filters.GuardrailAction.BLOCK;
            }
            if (filter.outputEnabled === undefined) {
                filter.outputEnabled = true;
            }
        }
        /**
         * Validates a messaging property (blockedInputMessaging or blockedOutputsMessaging).
         * @param value The messaging value to validate.
         * @param propertyName The name of the property being validated.
         */
        validateMessagingProperty(value, propertyName) {
            if (value !== undefined && !aws_cdk_lib_1.Token.isUnresolved(value)) {
                if (value.length < 1) {
                    throw new aws_cdk_lib_1.ValidationError(`Invalid ${propertyName}: The field ${propertyName} is ${value.length} characters long but must be at least 1 characters`, this);
                }
                if (value.length > 500) {
                    throw new aws_cdk_lib_1.ValidationError(`Invalid ${propertyName}: The field ${propertyName} is ${value.length} characters long but must be less than or equal to 500 characters`, this);
                }
            }
        }
        /**
         * Validates that cross-region configuration is provided when STANDARD tier is used.
         * @param props The guardrail properties to validate.
         */
        validateTierConfiguration(props) {
            const contentTierConfig = props.contentFiltersTierConfig ?? filters.TierConfig.CLASSIC;
            const topicsTierConfig = props.topicsTierConfig ?? filters.TierConfig.CLASSIC;
            const hasCrossRegionConfig = props.crossRegionConfig !== undefined;
            // Check if STANDARD tier is used for content filters
            if (contentTierConfig === filters.TierConfig.STANDARD && !hasCrossRegionConfig) {
                throw new aws_cdk_lib_1.ValidationError('Cross-region configuration is required when using STANDARD tier for content filters. ' +
                    'Please provide a crossRegionConfig property with a valid guardrailProfileArn.', this);
            }
            // Check if STANDARD tier is used for topic filters
            if (topicsTierConfig === filters.TierConfig.STANDARD && !hasCrossRegionConfig) {
                throw new aws_cdk_lib_1.ValidationError('Cross-region configuration is required when using STANDARD tier for topic filters. ' +
                    'Please provide a crossRegionConfig property with a valid guardrailProfileArn.', this);
            }
        }
        /**
         * Validates content filters array and applies default values for optional properties.
         * @param contentFilters The content filters to validate.
         */
        validateContentFilters(contentFilters) {
            if (!contentFilters)
                return;
            contentFilters.forEach((filter, index) => {
                const prefix = `Invalid ContentFilter at index ${index}`;
                // Validate that the filter has required properties
                if (!filter.type) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: type is required`, this);
                }
                // Validate input strength
                if (filter.inputStrength !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.inputStrength)) {
                    if (!Object.values(filters.ContentFilterStrength).includes(filter.inputStrength)) {
                        throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputStrength must be a valid ContentFilterStrength value`, this);
                    }
                }
                // Validate output strength
                if (filter.outputStrength !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.outputStrength)) {
                    if (!Object.values(filters.ContentFilterStrength).includes(filter.outputStrength)) {
                        throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputStrength must be a valid ContentFilterStrength value`, this);
                    }
                }
                // Validate input modalities
                if (filter.inputModalities) {
                    filter.inputModalities.forEach((modality, modalityIndex) => {
                        if (!Object.values(filters.ModalityType).includes(modality)) {
                            throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputModalities[${modalityIndex}] must be a valid ModalityType value`, this);
                        }
                    });
                }
                // Validate output modalities
                if (filter.outputModalities) {
                    filter.outputModalities.forEach((modality, modalityIndex) => {
                        if (!Object.values(filters.ModalityType).includes(modality)) {
                            throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputModalities[${modalityIndex}] must be a valid ModalityType value`, this);
                        }
                    });
                }
                // Validate inputAction: must be a valid GuardrailAction value (if provided)
                if (filter.inputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                // Validate outputAction: must be a valid GuardrailAction value (if provided)
                if (filter.outputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (filter.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                    typeof filter.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (filter.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                    typeof filter.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.inputAction === undefined) {
                    filter.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.inputEnabled === undefined) {
                    filter.inputEnabled = true;
                }
                if (filter.outputAction === undefined) {
                    filter.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.outputEnabled === undefined) {
                    filter.outputEnabled = true;
                }
            });
        }
        /**
         * Validates PII filters array and applies default values for optional properties.
         * @param piiFilters The PII filters to validate.
         */
        validatePiiFilters(piiFilters) {
            if (!piiFilters)
                return;
            piiFilters.forEach((filter, index) => {
                const prefix = `Invalid PIIFilter at index ${index}`;
                // Validate that the filter has required properties
                if (!filter.type) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: type is required`, this);
                }
                if (!filter.action) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: action is required`, this);
                }
                // Validate action values
                if (!aws_cdk_lib_1.Token.isUnresolved(filter.action) && !Object.values(filters.GuardrailAction).includes(filter.action)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: action must be a valid GuardrailAction value`, this);
                }
                if (filter.inputAction &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                if (filter.outputAction &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (filter.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                    typeof filter.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (filter.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                    typeof filter.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.inputAction === undefined) {
                    filter.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.inputEnabled === undefined) {
                    filter.inputEnabled = true;
                }
                if (filter.outputAction === undefined) {
                    filter.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.outputEnabled === undefined) {
                    filter.outputEnabled = true;
                }
            });
        }
        /**
         * Validates regex filters array.
         * @param regexFilters The regex filters to validate.
         */
        validateRegexFilters(regexFilters) {
            if (!regexFilters)
                return;
            regexFilters.forEach((filter, index) => {
                this.validateRegexFilter(filter, index);
            });
        }
        /**
         * Validates denied topics array and applies default values for optional properties.
         * @param deniedTopics The denied topics to validate.
         */
        validateDeniedTopics(deniedTopics) {
            if (!deniedTopics)
                return;
            deniedTopics.forEach((topic, index) => {
                const prefix = `Invalid Topic at index ${index}`;
                // Validate that the topic has required properties
                if (!topic.name) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: name is required`, this);
                }
                if (!topic.definition) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: definition is required`, this);
                }
                // Validate name length
                if (!aws_cdk_lib_1.Token.isUnresolved(topic.name) && topic.name.length > 100) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: name must be 100 characters or less`, this);
                }
                // Validate definition length
                if (!aws_cdk_lib_1.Token.isUnresolved(topic.definition) && topic.definition.length > 1000) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: definition must be 1000 characters or less`, this);
                }
                // Validate examples if provided
                if (topic.examples) {
                    if (topic.examples.length > 100) {
                        throw new aws_cdk_lib_1.ValidationError(`${prefix}: examples array cannot contain more than 100 examples`, this);
                    }
                    topic.examples.forEach((example, exampleIndex) => {
                        if (!aws_cdk_lib_1.Token.isUnresolved(example) && example.length > 100) {
                            throw new aws_cdk_lib_1.ValidationError(`${prefix}: examples[${exampleIndex}] must be 100 characters or less`, this);
                        }
                    });
                }
                // Validate inputAction: must be a valid GuardrailAction value (if provided)
                if (topic.inputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(topic.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(topic.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                // Validate outputAction: must be a valid GuardrailAction value (if provided)
                if (topic.outputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(topic.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(topic.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (topic.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(topic.inputEnabled) &&
                    typeof topic.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (topic.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(topic.outputEnabled) &&
                    typeof topic.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (topic.inputAction === undefined) {
                    topic.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (topic.inputEnabled === undefined) {
                    topic.inputEnabled = true;
                }
                if (topic.outputAction === undefined) {
                    topic.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (topic.outputEnabled === undefined) {
                    topic.outputEnabled = true;
                }
            });
        }
        /**
         * Validates contextual grounding filters array and applies default values for optional properties.
         * @param contextualGroundingFilters The contextual grounding filters to validate.
         */
        validateContextualGroundingFilters(contextualGroundingFilters) {
            if (!contextualGroundingFilters)
                return;
            contextualGroundingFilters.forEach((filter, index) => {
                const prefix = `Invalid ContextualGroundingFilter at index ${index}`;
                // Validate that the filter has required properties
                if (!filter.type) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: type is required`, this);
                }
                if (filter.threshold === undefined) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: threshold is required`, this);
                }
                // Validate type
                if (!Object.values(filters.ContextualGroundingFilterType).includes(filter.type)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: type must be a valid ContextualGroundingFilterType value`, this);
                }
                // Validate threshold range
                if (!aws_cdk_lib_1.Token.isUnresolved(filter.threshold)) {
                    if (filter.threshold < 0 || filter.threshold > 0.99) {
                        throw new aws_cdk_lib_1.ValidationError(`${prefix}: threshold must be between 0 and 0.99`, this);
                    }
                }
                // Validate action: must be a valid GuardrailAction value (if provided)
                if (filter.action !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.action) &&
                    !Object.values(filters.GuardrailAction).includes(filter.action)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: action must be a valid GuardrailAction value`, this);
                }
                // Validate enabled: must be a boolean (if provided)
                if (filter.enabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.enabled) &&
                    typeof filter.enabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: enabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.action === undefined) {
                    filter.action = filters.GuardrailAction.BLOCK;
                }
                if (filter.enabled === undefined) {
                    filter.enabled = true;
                }
            });
        }
        /**
         * Validates word filters array and applies default values for optional properties.
         * @param wordFilters The word filters to validate.
         */
        validateWordFilters(wordFilters) {
            if (!wordFilters)
                return;
            wordFilters.forEach((filter, index) => {
                const prefix = `Invalid WordFilter at index ${index}`;
                // Validate that the filter has required properties
                if (!filter.text) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: text is required`, this);
                }
                // Validate text length
                if (!aws_cdk_lib_1.Token.isUnresolved(filter.text) && filter.text.length > 100) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: text must be 100 characters or less`, this);
                }
                // Validate inputAction: must be a valid GuardrailAction value (if provided)
                if (filter.inputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                // Validate outputAction: must be a valid GuardrailAction value (if provided)
                if (filter.outputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (filter.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                    typeof filter.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (filter.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                    typeof filter.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.inputAction === undefined) {
                    filter.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.inputEnabled === undefined) {
                    filter.inputEnabled = true;
                }
                if (filter.outputAction === undefined) {
                    filter.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.outputEnabled === undefined) {
                    filter.outputEnabled = true;
                }
            });
        }
        /**
         * Validates managed word list filters array and applies default values for optional properties.
         * @param managedWordListFilters The managed word list filters to validate.
         */
        validateManagedWordListFilters(managedWordListFilters) {
            if (!managedWordListFilters)
                return;
            managedWordListFilters.forEach((filter, index) => {
                const prefix = `Invalid ManagedWordFilter at index ${index}`;
                // Validate type: must be a valid ManagedWordFilterType value (if provided)
                if (filter.type !== undefined && !Object.values(filters.ManagedWordFilterType).includes(filter.type)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: type must be a valid ManagedWordFilterType value`, this);
                }
                // Validate inputAction: must be a valid GuardrailAction value (if provided)
                if (filter.inputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                // Validate outputAction: must be a valid GuardrailAction value (if provided)
                if (filter.outputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (filter.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                    typeof filter.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (filter.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                    typeof filter.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError(`${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.type === undefined) {
                    filter.type = filters.ManagedWordFilterType.PROFANITY;
                }
                if (filter.inputAction === undefined) {
                    filter.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.inputEnabled === undefined) {
                    filter.inputEnabled = true;
                }
                if (filter.outputAction === undefined) {
                    filter.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.outputEnabled === undefined) {
                    filter.outputEnabled = true;
                }
            });
        }
        /**
         * Validates a single content filter and applies default values for optional properties.
         * @param filter The content filter to validate.
         */
        validateSingleContentFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateContentFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single PII filter and applies default values for optional properties.
         * @param filter The PII filter to validate.
         */
        validateSinglePiiFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validatePiiFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single regex filter and applies default values for optional properties.
         * @param filter The regex filter to validate.
         */
        validateSingleRegexFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateRegexFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single denied topic and applies default values for optional properties.
         * @param filter The denied topic to validate.
         */
        validateSingleDeniedTopic(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateDeniedTopics([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single contextual grounding filter and applies default values for optional properties.
         * @param filter The contextual grounding filter to validate.
         */
        validateSingleContextualGroundingFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateContextualGroundingFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single word filter and applies default values for optional properties.
         * @param filter The word filter to validate.
         */
        validateSingleWordFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateWordFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single managed word list filter and applies default values for optional properties.
         * @param filter The managed word list filter to validate.
         */
        validateSingleManagedWordListFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateManagedWordListFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(message, this);
                }
                throw error;
            }
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return Guardrail = _classThis;
})();
exports.Guardrail = Guardrail;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3VhcmRyYWlscy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImd1YXJkcmFpbHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEseUJBQXlCO0FBRXpCLDZDQUFxRjtBQUNyRixtREFBbUQ7QUFFbkQsK0RBQW9EO0FBQ3BELDJDQUEyQztBQUUzQyxpREFBMEM7QUFDMUMsNEVBQWdFO0FBQ2hFLDhFQUE4RjtBQUM5RiwwRUFBMEU7QUFFMUUsZ0JBQWdCO0FBQ2hCLCtDQUErQztBQUMvQywyREFBdUQ7QUFpR3ZEOzs7R0FHRztBQUNILE1BQXNCLGFBQWMsU0FBUSxzQkFBUTs7SUFDbEQ7Ozs7O09BS0c7SUFDSSxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQWtCLEVBQUUsS0FBcUI7UUFDL0QsT0FBTyxJQUFJLHVCQUFNLENBQUM7WUFDaEIsU0FBUyxFQUFFLHdCQUF3QjtZQUNuQyxhQUFhLEVBQUUsRUFBRSxTQUFTLEVBQUUsZ0JBQWdCLEVBQUU7WUFDOUMsVUFBVTtZQUNWLEdBQUcsS0FBSztTQUNULENBQUMsQ0FBQztLQUNKO0lBRUQ7O09BRUc7SUFDSSxNQUFNLENBQUMsb0JBQW9CLENBQUMsS0FBcUI7UUFDdEQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztLQUM3QztJQUVEOztPQUVHO0lBQ0ksTUFBTSxDQUFDLHNCQUFzQixDQUFDLEtBQXFCO1FBQ3hELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDL0M7SUFFRDs7T0FFRztJQUNJLE1BQU0sQ0FBQyw4QkFBOEIsQ0FBQyxLQUFxQjtRQUNoRSxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDdkQ7SUFFRDs7T0FFRztJQUNJLE1BQU0sQ0FBQywwQkFBMEIsQ0FBQyxLQUFxQjtRQUM1RCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDbkQ7SUFFTyxRQUFRLEdBQVcsT0FBTyxDQUFDO0lBd0JuQzs7O09BR0c7SUFDSCxJQUFXLGdCQUFnQjtRQUN6QixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7S0FDdEI7SUFFUyxhQUFhLENBQUMsT0FBZTtRQUNyQyxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQztLQUN6QjtJQUVEOzs7T0FHRztJQUNJLEtBQUssQ0FBQyxPQUF1QixFQUFFLEdBQUcsT0FBaUI7UUFDeEQsT0FBTyxHQUFHLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQztZQUM5QixPQUFPO1lBQ1AsT0FBTztZQUNQLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7U0FDbEMsQ0FBQyxDQUFDO0tBQ0o7SUFFRDs7O09BR0c7SUFDSSxVQUFVLENBQUMsT0FBdUI7UUFDdkMsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztRQUVoRSxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNoQix5RUFBeUU7WUFDekUsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUMxRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDckMsQ0FBQzthQUFNLENBQUM7WUFDTixtREFBbUQ7WUFDbkQsT0FBTyxTQUFTLENBQUM7UUFDbkIsQ0FBQztLQUNGO0lBRUQ7Ozs7O09BS0c7SUFDSSxNQUFNLENBQUMsVUFBa0IsRUFBRSxLQUFxQjtRQUNyRCxNQUFNLFdBQVcsR0FBZ0I7WUFDL0IsU0FBUyxFQUFFLHdCQUF3QjtZQUNuQyxVQUFVO1lBQ1YsYUFBYSxFQUFFLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZLEVBQUUsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQzNGLEdBQUcsS0FBSztTQUNULENBQUM7UUFDRixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLENBQUM7S0FDMUM7SUFFRDs7T0FFRztJQUNJLGlCQUFpQixDQUFDLEtBQXFCO1FBQzVDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDMUM7SUFFRDs7T0FFRztJQUNJLHVCQUF1QixDQUFDLEtBQXFCO1FBQ2xELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLENBQUMsQ0FBQztLQUNoRDtJQUVEOztPQUVHO0lBQ0ksNEJBQTRCLENBQUMsS0FBcUI7UUFDdkQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLHdCQUF3QixFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQ3JEO0lBRUQ7O09BRUc7SUFDSSw0QkFBNEIsQ0FBQyxLQUFxQjtRQUN2RCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsd0JBQXdCLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDckQ7SUFFRDs7T0FFRztJQUNJLHlCQUF5QixDQUFDLEtBQXFCO1FBQ3BELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsRUFBRSxLQUFLLENBQUMsQ0FBQztLQUNsRDtJQUVEOztPQUVHO0lBQ0ksbUJBQW1CLENBQUMsS0FBcUI7UUFDOUMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztLQUM1QztJQUVEOztPQUVHO0lBQ0ksMkJBQTJCLENBQUMsS0FBcUI7UUFDdEQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQ3BEO0lBRU8sZUFBZSxDQUFDLEtBQWtCO1FBQ3hDLE9BQU8sSUFBSSx1QkFBTSxDQUFDO1lBQ2hCLEdBQUcsS0FBSztZQUNSLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTTtZQUMxQyxPQUFPLEVBQUUsS0FBSyxFQUFFLE9BQU8sSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU87U0FDOUMsQ0FBQyxDQUFDO0tBQ0o7O0FBcExILHNDQXFMQztBQWdIRDs7K0VBRStFO0FBQy9FOzs7R0FHRztJQUVVLFNBQVM7NEJBRHJCLG9DQUFrQjs7OztzQkFDWSxhQUFhOzs7Ozs7Ozs7Ozt5QkFBckIsU0FBUSxXQUFhOzs7OzRDQXlOekMsSUFBQSxrQ0FBYyxHQUFFO3dDQVVoQixJQUFBLGtDQUFjLEdBQUU7MENBVWhCLElBQUEsa0NBQWMsR0FBRTtnREFVaEIsSUFBQSxrQ0FBYyxHQUFFO3dEQVVoQixJQUFBLGtDQUFjLEdBQUU7eUNBVWhCLElBQUEsa0NBQWMsR0FBRTtpREFVaEIsSUFBQSxrQ0FBYyxHQUFFO29EQWVoQixJQUFBLGtDQUFjLEdBQUU7eUNBV2hCLElBQUEsa0NBQWMsR0FBRTtZQXJGakIsbU1BQU8sZ0JBQWdCLDZEQUd0QjtZQU9ELHVMQUFPLFlBQVksNkRBR2xCO1lBT0QsNkxBQU8sY0FBYyw2REFHcEI7WUFPRCwrTUFBTyxvQkFBb0IsNkRBRzFCO1lBT0QsdU9BQU8sNEJBQTRCLDZEQUdsQztZQU9ELDBMQUFPLGFBQWEsNkRBR25CO1lBT0Qsa05BQU8scUJBQXFCLDZEQVEzQjtZQU9ELDJOQUFPLHdCQUF3Qiw2REFHOUI7WUFRRCwwTEFBTyxhQUFhLDZEQVFuQjtZQXhUSCw2S0E4dENDOzs7OztRQTd0Q0Msc0NBQXNDO1FBQy9CLE1BQU0sQ0FBVSxxQkFBcUIsR0FBVyxzQ0FBc0MsQ0FBQztRQUU5Rjs7V0FFRztRQUNJLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQyxLQUFnQixFQUFFLEVBQVUsRUFBRSxLQUEwQjs7Ozs7Ozs7OztZQUM1RixNQUFNLE1BQU8sU0FBUSxhQUFhO2dCQUNoQixZQUFZLEdBQUcsS0FBSyxDQUFDLFlBQVksQ0FBQztnQkFDbEMsV0FBVyxHQUFHLGlCQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsdUJBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLFlBQWEsQ0FBQztnQkFDekYsTUFBTSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUM7Z0JBQ3RCLFdBQVcsR0FBRyxTQUFTLENBQUM7Z0JBRXhDO29CQUNFLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ2pCLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLGdCQUFnQixJQUFJLE9BQU8sQ0FBQyxDQUFDO2dCQUN4RCxDQUFDO2FBQ0Y7WUFFRCxPQUFPLElBQUksTUFBTSxFQUFFLENBQUM7U0FDckI7UUFFRDs7V0FFRztRQUNJLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFrQztZQUMvRCxPQUFPLElBQUksQ0FBQyxLQUFNLFNBQVEsYUFBYTtnQkFDckIsWUFBWSxHQUFHLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDN0MsV0FBVyxHQUFHLFlBQVksQ0FBQyxlQUFlLENBQUM7Z0JBQzNDLE1BQU0sR0FBRyxZQUFZLENBQUMsU0FBUztvQkFDN0MsQ0FBQyxDQUFDLGFBQUcsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLHNCQUFzQixFQUFFLFlBQVksQ0FBQyxTQUFTLENBQUM7b0JBQ3RFLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0JBQ0UsV0FBVyxHQUFHLFlBQVksQ0FBQyxhQUFhLENBQUM7Z0JBRXpEO29CQUNFLEtBQUssQ0FBQyxZQUFZLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztvQkFDekMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQy9DLENBQUM7YUFDRixDQUFDLEVBQUUsQ0FBQztTQUNOO1FBRUQ7OztXQUdHO1FBQ2EsWUFBWSxHQTlDakIsbURBQVMsQ0E4Q2lCO1FBQ3JDOzs7V0FHRztRQUNhLFdBQVcsQ0FBUztRQUNwQzs7V0FFRztRQUNhLElBQUksQ0FBUztRQUM3Qjs7OztXQUlHO1FBQ2EsTUFBTSxDQUFRO1FBQzlCOztXQUVHO1FBQ2EsY0FBYyxDQUEwQjtRQUN4RDs7V0FFRztRQUNhLFVBQVUsQ0FBc0I7UUFDaEQ7O1dBRUc7UUFDYSxZQUFZLENBQXdCO1FBQ3BEOztXQUVHO1FBQ2EsWUFBWSxDQUFrQjtRQUM5Qzs7V0FFRztRQUNhLDBCQUEwQixDQUFzQztRQUNoRjs7V0FFRztRQUNhLFdBQVcsQ0FBdUI7UUFDbEQ7O1dBRUc7UUFDYSxzQkFBc0IsQ0FBOEI7UUFDcEU7O1dBRUc7UUFDYSxXQUFXLENBQVU7UUFDckM7O1dBRUc7UUFDYSxJQUFJLENBQVM7UUFDN0I7O1dBRUc7UUFDYyxVQUFVLENBQXVCO1FBRWxEOzs7V0FHRztRQUNhLGdCQUFnQixDQUFxQjtRQUVyRDs7OztXQUlHO1FBQ2Esd0JBQXdCLENBQXFCO1FBQzdEOztXQUVHO1FBQ2EsaUJBQWlCLENBQXNDO1FBRXZFOzs7V0FHRztRQUNhLHFCQUFxQixDQUFTO1FBRTlDOzs7V0FHRztRQUNhLHVCQUF1QixDQUFTO1FBRWhELFlBQVksS0FBZ0IsRUFBRSxFQUFVLEVBQUUsS0FBcUI7WUFDN0QsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7Z0JBQ2YsWUFBWSxFQUFFLEtBQUssQ0FBQyxhQUFhO2FBQ2xDLENBQUMsQ0FBQzs7Ozs7O21EQXZJTSxTQUFTOzs7O1lBd0lsQixtQ0FBbUM7WUFDbkMsSUFBQSx3Q0FBb0IsRUFBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFbEMseURBQXlEO1lBQ3pELDZCQUE2QjtZQUM3Qix5REFBeUQ7WUFDekQsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1lBQzlCLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDLGNBQWMsSUFBSSxFQUFFLENBQUM7WUFDakQsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQztZQUN6QyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxZQUFZLElBQUksRUFBRSxDQUFDO1lBQzdDLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDLFlBQVksSUFBSSxFQUFFLENBQUM7WUFDN0MsSUFBSSxDQUFDLDBCQUEwQixHQUFHLEtBQUssQ0FBQywwQkFBMEIsSUFBSSxFQUFFLENBQUM7WUFDekUsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQztZQUMzQyxJQUFJLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDLHNCQUFzQixJQUFJLEVBQUUsQ0FBQztZQUNqRSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLGdCQUFnQixJQUFJLE9BQU8sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO1lBQzdFLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxLQUFLLENBQUMsd0JBQXdCLElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7WUFDN0YsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztZQUNqRCxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDLHFCQUFxQixJQUFJLDhDQUE4QyxDQUFDO1lBQzNHLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxLQUFLLENBQUMsdUJBQXVCLElBQUkseUVBQXlFLENBQUM7WUFFMUkseURBQXlEO1lBQ3pELDZCQUE2QjtZQUM3Qix5REFBeUQ7WUFDekQsSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUNqRCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3pDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDN0MsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUM3QyxJQUFJLENBQUMsa0NBQWtDLENBQUMsSUFBSSxDQUFDLDBCQUEwQixDQUFDLENBQUM7WUFDekUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUMzQyxJQUFJLENBQUMsOEJBQThCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLENBQUM7WUFFakUseURBQXlEO1lBQ3pELGdDQUFnQztZQUNoQyx5REFBeUQ7WUFDekQsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO1lBQ3BGLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUseUJBQXlCLENBQUMsQ0FBQztZQUV4Rix5REFBeUQ7WUFDekQsMkNBQTJDO1lBQzNDLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMseUJBQXlCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFdEMseURBQXlEO1lBQ3pELGdDQUFnQztZQUNoQyx5REFBeUQ7WUFDekQsSUFBSSxRQUFRLEdBQThCO2dCQUN4QyxJQUFJLEVBQUUsS0FBSyxDQUFDLGFBQWE7Z0JBQ3pCLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztnQkFDOUIsU0FBUyxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTTtnQkFDL0IscUJBQXFCLEVBQUUsSUFBSSxDQUFDLHFCQUFxQjtnQkFDakQsdUJBQXVCLEVBQUUsSUFBSSxDQUFDLHVCQUF1QjtnQkFDckQsYUFBYTtnQkFDYixpQkFBaUIsRUFBRSxJQUFJLENBQUMsNEJBQTRCLEVBQUU7Z0JBQ3RELG1CQUFtQixFQUFFLElBQUksQ0FBQyw4QkFBOEIsRUFBRTtnQkFDMUQsK0JBQStCLEVBQUUsSUFBSSxDQUFDLGlDQUFpQyxFQUFFO2dCQUN6RSxpQkFBaUIsRUFBRSxJQUFJLENBQUMsc0JBQXNCLEVBQUU7Z0JBQ2hELGdCQUFnQixFQUFFLElBQUksQ0FBQywyQkFBMkIsRUFBRTtnQkFDcEQsZ0NBQWdDLEVBQUUsSUFBSSxDQUFDLDJDQUEyQyxFQUFFO2FBQ3JGLENBQUM7WUFFRiwwREFBMEQ7WUFDMUQsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFBLDBCQUFPLEVBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBRTlDLHlEQUF5RDtZQUN6RCxtQkFBbUI7WUFDbkIseURBQXlEO1lBQ3pELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxhQUFhLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFFMUUsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQztZQUNuRCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUM7WUFDckQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ2hELElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUM7U0FDbEQ7UUFFRCx5REFBeUQ7UUFDekQsVUFBVTtRQUNWLHlEQUF5RDtRQUN6RDs7O1dBR0c7UUFFSSxnQkFBZ0IsQ0FBQyxNQUE2Qjs7Ozs7Ozs7OztZQUNuRCxJQUFJLENBQUMsMkJBQTJCLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDekMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDbEM7UUFFRDs7O1dBR0c7UUFFSSxZQUFZLENBQUMsTUFBeUI7Ozs7Ozs7Ozs7WUFDM0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3JDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQzlCO1FBRUQ7OztXQUdHO1FBRUksY0FBYyxDQUFDLE1BQTJCOzs7Ozs7Ozs7O1lBQy9DLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN2QyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNoQztRQUVEOzs7V0FHRztRQUVJLG9CQUFvQixDQUFDLE1BQXFCOzs7Ozs7Ozs7O1lBQy9DLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN2QyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNoQztRQUVEOzs7V0FHRztRQUVJLDRCQUE0QixDQUFDLE1BQXlDOzs7Ozs7Ozs7O1lBQzNFLElBQUksQ0FBQyx1Q0FBdUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNyRCxJQUFJLENBQUMsMEJBQTBCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQzlDO1FBRUQ7OztXQUdHO1FBRUksYUFBYSxDQUFDLE1BQTBCOzs7Ozs7Ozs7O1lBQzdDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN0QyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMvQjtRQUVEOzs7V0FHRztRQUVJLHFCQUFxQixDQUFDLFFBQWdCLEVBQzNDLFdBQXFDLEVBQ3JDLFlBQXNDLEVBQ3RDLFlBQXNCLEVBQ3RCLGFBQXVCOzs7Ozs7Ozs7OztZQUN2QixNQUFNLFlBQVksR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUN2RCxNQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzdDLEtBQUssTUFBTSxJQUFJLElBQUksS0FBSztnQkFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsQ0FBQyxDQUFDO1NBQ3RIO1FBRUQ7OztXQUdHO1FBRUksd0JBQXdCLENBQUMsTUFBaUM7Ozs7Ozs7Ozs7WUFDL0QsSUFBSSxDQUFDLG1DQUFtQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2pELElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDMUM7UUFFRDs7OztXQUlHO1FBRUksYUFBYSxDQUFDLFdBQW9CO1lBQ3ZDLE1BQU0sVUFBVSxHQUFHLElBQUksb0NBQWdCLENBQUMsSUFBSSxFQUFFLG9CQUFvQixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDMUYsV0FBVyxFQUFFLFdBQVc7Z0JBQ3hCLFNBQVMsRUFBRSxJQUFJO2FBQ2hCLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDaEQsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7U0FDOUI7UUFFRCx5REFBeUQ7UUFDekQsaUJBQWlCO1FBQ2pCLHlEQUF5RDtRQUN6RDs7O1dBR0c7UUFDSyw4QkFBOEI7WUFDcEMsT0FBTyxrQkFBSSxDQUFDLEdBQUcsQ0FBQztnQkFDZCxPQUFPLEVBQUUsR0FBRyxFQUFFO29CQUNaLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7d0JBQ25DLE1BQU0sbUJBQW1CLEdBQXFEOzRCQUM1RSxhQUFhLEVBQUUsSUFBSSxDQUFDLGNBQWM7NEJBQ2xDLEdBQUcsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLElBQUk7Z0NBQ25DLHdCQUF3QixFQUFFO29DQUN4QixRQUFRLEVBQUUsSUFBSSxDQUFDLHdCQUF3QjtpQ0FDaUI7NkJBQzNELENBQUM7eUJBQ0gsQ0FBQzt3QkFFRixPQUFPLG1CQUFtQixDQUFDO29CQUM3QixDQUFDO3lCQUFNLENBQUM7d0JBQ04sT0FBTyxTQUFTLENBQUM7b0JBQ25CLENBQUM7Z0JBQ0gsQ0FBQzthQUNGLENBQUMsQ0FBQztTQUNKO1FBRUQ7OztXQUdHO1FBQ0ssc0JBQXNCO1lBQzVCLE9BQU8sa0JBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQ2QsT0FBTyxFQUFFLEdBQUcsRUFBRTtvQkFDWixJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO3dCQUNqQyxNQUFNLGlCQUFpQixHQUFtRDs0QkFDeEUsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBb0IsRUFBRSxFQUFFO2dDQUMvRCxPQUFPO29DQUNMLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVTtvQ0FDNUIsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJO29DQUNoQixRQUFRLEVBQUUsS0FBSyxDQUFDLFFBQVE7b0NBQ3hCLElBQUksRUFBRSxNQUFNO29DQUNaLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztvQ0FDOUIsWUFBWSxFQUFFLEtBQUssQ0FBQyxZQUFZO29DQUNoQyxZQUFZLEVBQUUsS0FBSyxDQUFDLFlBQVk7b0NBQ2hDLGFBQWEsRUFBRSxLQUFLLENBQUMsYUFBYTtpQ0FDUyxDQUFDOzRCQUNoRCxDQUFDLENBQUM7NEJBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsSUFBSTtnQ0FDM0IsZ0JBQWdCLEVBQUU7b0NBQ2hCLFFBQVEsRUFBRSxJQUFJLENBQUMsZ0JBQWdCO2lDQUNpQjs2QkFDbkQsQ0FBQzt5QkFDSCxDQUFDO3dCQUVGLE9BQU8saUJBQWlCLENBQUM7b0JBQzNCLENBQUM7eUJBQU0sQ0FBQzt3QkFDTixPQUFPLFNBQVMsQ0FBQztvQkFDbkIsQ0FBQztnQkFDSCxDQUFDO2FBQ0YsQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7O1dBR0c7UUFDSyxpQ0FBaUM7WUFDdkMsT0FBTyxrQkFBSSxDQUFDLEdBQUcsQ0FBQztnQkFDZCxPQUFPLEVBQUUsR0FBRyxFQUFFO29CQUNaLElBQUksSUFBSSxDQUFDLDBCQUEwQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQzt3QkFDL0MsT0FBTzs0QkFDTCxhQUFhLEVBQUUsSUFBSSxDQUFDLDBCQUEwQixDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQXlDLEVBQUUsRUFBRTtnQ0FDbkcsT0FBTztvQ0FDTCxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7b0NBQ2pCLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztvQ0FDM0IsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO29DQUNyQixPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87aUNBQ3dDLENBQUM7NEJBQ3BFLENBQUMsQ0FBQzt5QkFDSCxDQUFDO29CQUNKLENBQUM7eUJBQU0sQ0FBQzt3QkFDTixPQUFPLFNBQVMsQ0FBQztvQkFDbkIsQ0FBQztnQkFDSCxDQUFDO2FBQ0YsQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7O1dBR0c7UUFDSywyQkFBMkI7WUFDakMsT0FBTyxrQkFBSSxDQUFDLEdBQUcsQ0FBQztnQkFDZCxPQUFPLEVBQUUsR0FBRyxFQUFFO29CQUNaLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7d0JBQzFFLE9BQU87NEJBQ0wsV0FBVyxFQUFFLElBQUksQ0FBQyxxQkFBcUIsRUFBRTs0QkFDekMsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLGlDQUFpQyxFQUFFO3lCQUNoQixDQUFDO29CQUNyRCxDQUFDO3lCQUFNLENBQUM7d0JBQ04sT0FBTyxTQUFTLENBQUM7b0JBQ25CLENBQUM7Z0JBQ0gsQ0FBQzthQUNGLENBQUMsQ0FBQztTQUNKO1FBRUQ7OztXQUdHO1FBQ0sscUJBQXFCO1lBQzNCLE9BQU8sa0JBQUksQ0FBQyxHQUFHLENBQ2I7Z0JBQ0UsT0FBTyxFQUFFLEdBQUcsRUFBRTtvQkFDWixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBd0IsRUFBRSxFQUFFO3dCQUMzRCxPQUFPOzRCQUNMLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTs0QkFDZixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVc7NEJBQzdCLFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDL0IsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUMvQixhQUFhLEVBQUUsSUFBSSxDQUFDLGFBQWE7eUJBQ1MsQ0FBQztvQkFDL0MsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQzthQUNGLEVBQ0QsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLENBQ3pCLENBQUM7U0FDSDtRQUVEOzs7V0FHRztRQUNLLGlDQUFpQztZQUN2QyxPQUFPLGtCQUFJLENBQUMsR0FBRyxDQUNiO2dCQUNFLE9BQU8sRUFBRSxHQUFHLEVBQUU7b0JBQ1osT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBaUMsRUFBRSxFQUFFO3dCQUMvRSxPQUFPOzRCQUNMLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSTs0QkFDakIsV0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXOzRCQUMvQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7NEJBQ2pDLFlBQVksRUFBRSxNQUFNLENBQUMsWUFBWTs0QkFDakMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxhQUFhO3lCQUNlLENBQUM7b0JBQ3ZELENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7YUFDRixFQUNELEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxDQUN6QixDQUFDO1NBQ0g7UUFFRDs7O1dBR0c7UUFDSywyQ0FBMkM7WUFDakQsT0FBTyxrQkFBSSxDQUFDLEdBQUcsQ0FDYjtnQkFDRSxPQUFPLEVBQUUsR0FBRyxFQUFFO29CQUNaLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO3dCQUMvRCxPQUFPOzRCQUNMLGFBQWEsRUFBRSxJQUFJLENBQUMsd0JBQXdCLEVBQUU7NEJBQzlDLGlCQUFpQixFQUFFLElBQUksQ0FBQyw0QkFBNEIsRUFBRTt5QkFDdkQsQ0FBQztvQkFDSixDQUFDO3lCQUFNLENBQUM7d0JBQ04sT0FBTyxTQUFTLENBQUM7b0JBQ25CLENBQUM7Z0JBQ0gsQ0FBQzthQUNGLEVBQ0QsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLENBQ3pCLENBQUM7U0FDSDtRQUVEOzs7V0FHRztRQUNLLHdCQUF3QjtZQUM5QixPQUFPLGtCQUFJLENBQUMsR0FBRyxDQUNiO2dCQUNFLE9BQU8sRUFBRSxHQUFHLEVBQUU7b0JBQ1osT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQTBCLEVBQUUsRUFBRTt3QkFDOUQsT0FBTzs0QkFDTCxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7NEJBQ2hCLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVzs0QkFDOUIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPOzRCQUN0QixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU07NEJBQ3BCLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVzs0QkFDOUIsWUFBWSxFQUFFLEtBQUssQ0FBQyxZQUFZOzRCQUNoQyxZQUFZLEVBQUUsS0FBSyxDQUFDLFlBQVk7NEJBQ2hDLGFBQWEsRUFBRSxLQUFLLENBQUMsYUFBYTt5QkFDUyxDQUFDO29CQUNoRCxDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDO2FBQ0YsRUFDRCxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsQ0FDekIsQ0FBQztTQUNIO1FBRUQ7OztXQUdHO1FBQ0ssNEJBQTRCO1lBQ2xDLE9BQU8sa0JBQUksQ0FBQyxHQUFHLENBQ2I7Z0JBQ0UsT0FBTyxFQUFFLEdBQUcsRUFBRTtvQkFDWixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBeUIsRUFBRSxFQUFFO3dCQUMzRCxPQUFPOzRCQUNMLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUs7NEJBQ3ZCLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTTs0QkFDckIsV0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXOzRCQUMvQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7NEJBQ2pDLFlBQVksRUFBRSxNQUFNLENBQUMsWUFBWTs0QkFDakMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxhQUFhO3lCQUNZLENBQUM7b0JBQ3BELENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7YUFDRixFQUNELEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxDQUN6QixDQUFDO1NBQ0g7UUFFRDs7O1dBR0c7UUFDSyw0QkFBNEI7WUFDbEMsT0FBTyxrQkFBSSxDQUFDLEdBQUcsQ0FBQztnQkFDZCxPQUFPLEVBQUUsR0FBRyxFQUFFO29CQUNaLElBQUksSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7d0JBQzNCLE9BQU87NEJBQ0wsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLG1CQUFtQjt5QkFDTCxDQUFDO29CQUMvRCxDQUFDO3lCQUFNLENBQUM7d0JBQ04sT0FBTyxTQUFTLENBQUM7b0JBQ25CLENBQUM7Z0JBQ0gsQ0FBQzthQUNGLENBQUMsQ0FBQztTQUNKO1FBRUQ7Ozs7V0FJRztRQUNLLG1CQUFtQixDQUFDLE1BQTJCLEVBQUUsS0FBYztZQUNyRSxNQUFNLE1BQU0sR0FBRyxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxnQ0FBZ0MsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDO1lBRXJHLDhDQUE4QztZQUM5QyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQ2xFLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQzNCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSx1QkFBdUIsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLG9EQUFvRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMxSSxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7b0JBQzdCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSx1QkFBdUIsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLG1FQUFtRSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN6SixDQUFDO1lBQ0gsQ0FBQztZQUVELG9FQUFvRTtZQUNwRSxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7Z0JBQ2hGLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQ2xDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSw4QkFBOEIsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLG9EQUFvRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN4SixDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxFQUFFLENBQUM7b0JBQ3JDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSw4QkFBOEIsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLG9FQUFvRSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN4SyxDQUFDO1lBQ0gsQ0FBQztZQUVELDJDQUEyQztZQUMzQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7Z0JBQ3hFLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQzlCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSwwQkFBMEIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLG9EQUFvRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNoSixDQUFDO1lBQ0gsQ0FBQztZQUVELHlEQUF5RDtZQUN6RCxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO2dCQUN6SSxNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0sZ0RBQWdELEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDN0YsQ0FBQztZQUVELDRFQUE0RTtZQUM1RSxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUztnQkFDaEMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO2dCQUN2QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztnQkFDekUsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHFEQUFxRCxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ2xHLENBQUM7WUFFRCw2RUFBNkU7WUFDN0UsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVM7Z0JBQ2pDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztnQkFDeEMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7Z0JBQzFFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSxzREFBc0QsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNuRyxDQUFDO1lBRUQseURBQXlEO1lBQ3pELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTO2dCQUNqQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7Z0JBQ3hDLE9BQU8sTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDN0MsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHdDQUF3QyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3JGLENBQUM7WUFFRCwwREFBMEQ7WUFDMUQsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVM7Z0JBQ2xDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztnQkFDekMsT0FBTyxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO2dCQUM5QyxNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0seUNBQXlDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDdEYsQ0FBQztZQUVELCtEQUErRDtZQUMvRCxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUyxFQUFFLENBQUM7Z0JBQ3BDLE1BQWMsQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7WUFDOUQsQ0FBQztZQUNELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDckMsTUFBYyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDdEMsQ0FBQztZQUNELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDckMsTUFBYyxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztZQUMvRCxDQUFDO1lBQ0QsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO2dCQUN0QyxNQUFjLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztZQUN2QyxDQUFDO1NBQ0Y7UUFFRDs7OztXQUlHO1FBQ0sseUJBQXlCLENBQUMsS0FBeUIsRUFBRSxZQUFvQjtZQUMvRSxJQUFJLEtBQUssS0FBSyxTQUFTLElBQUksQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN0RCxJQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQ3JCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLFdBQVcsWUFBWSxlQUFlLFlBQVksT0FBTyxLQUFLLENBQUMsTUFBTSxvREFBb0QsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDN0osQ0FBQztnQkFDRCxJQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7b0JBQ3ZCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLFdBQVcsWUFBWSxlQUFlLFlBQVksT0FBTyxLQUFLLENBQUMsTUFBTSxtRUFBbUUsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDNUssQ0FBQztZQUNILENBQUM7U0FDRjtRQUVEOzs7V0FHRztRQUNLLHlCQUF5QixDQUFDLEtBQXFCO1lBQ3JELE1BQU0saUJBQWlCLEdBQUcsS0FBSyxDQUFDLHdCQUF3QixJQUFJLE9BQU8sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO1lBQ3ZGLE1BQU0sZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLGdCQUFnQixJQUFJLE9BQU8sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO1lBQzlFLE1BQU0sb0JBQW9CLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixLQUFLLFNBQVMsQ0FBQztZQUVuRSxxREFBcUQ7WUFDckQsSUFBSSxpQkFBaUIsS0FBSyxPQUFPLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7Z0JBQy9FLE1BQU0sSUFBSSw2QkFBZSxDQUN2Qix1RkFBdUY7b0JBQ3ZGLCtFQUErRSxFQUMvRSxJQUFJLENBQ0wsQ0FBQztZQUNKLENBQUM7WUFFRCxtREFBbUQ7WUFDbkQsSUFBSSxnQkFBZ0IsS0FBSyxPQUFPLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7Z0JBQzlFLE1BQU0sSUFBSSw2QkFBZSxDQUN2QixxRkFBcUY7b0JBQ3JGLCtFQUErRSxFQUMvRSxJQUFJLENBQ0wsQ0FBQztZQUNKLENBQUM7U0FDRjtRQUVEOzs7V0FHRztRQUNLLHNCQUFzQixDQUFDLGNBQXdDO1lBQ3JFLElBQUksQ0FBQyxjQUFjO2dCQUFFLE9BQU87WUFFNUIsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDdkMsTUFBTSxNQUFNLEdBQUcsa0NBQWtDLEtBQUssRUFBRSxDQUFDO2dCQUV6RCxtREFBbUQ7Z0JBQ25ELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2pCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSxvQkFBb0IsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDakUsQ0FBQztnQkFFRCwwQkFBMEI7Z0JBQzFCLElBQUksTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTLElBQUksQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQztvQkFDcEYsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDO3dCQUNqRixNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0sNkRBQTZELEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQzFHLENBQUM7Z0JBQ0gsQ0FBQztnQkFFRCwyQkFBMkI7Z0JBQzNCLElBQUksTUFBTSxDQUFDLGNBQWMsS0FBSyxTQUFTLElBQUksQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQztvQkFDdEYsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDO3dCQUNsRixNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0sOERBQThELEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQzNHLENBQUM7Z0JBQ0gsQ0FBQztnQkFFRCw0QkFBNEI7Z0JBQzVCLElBQUksTUFBTSxDQUFDLGVBQWUsRUFBRSxDQUFDO29CQUMzQixNQUFNLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsRUFBRSxhQUFhLEVBQUUsRUFBRTt3QkFDekQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDOzRCQUM1RCxNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0scUJBQXFCLGFBQWEsc0NBQXNDLEVBQUUsSUFBSSxDQUFDLENBQUM7d0JBQ3JILENBQUM7b0JBQ0gsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQztnQkFFRCw2QkFBNkI7Z0JBQzdCLElBQUksTUFBTSxDQUFDLGdCQUFnQixFQUFFLENBQUM7b0JBQzVCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLEVBQUUsYUFBYSxFQUFFLEVBQUU7d0JBQzFELElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQzs0QkFDNUQsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHNCQUFzQixhQUFhLHNDQUFzQyxFQUFFLElBQUksQ0FBQyxDQUFDO3dCQUN0SCxDQUFDO29CQUNILENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7Z0JBRUQsNEVBQTRFO2dCQUM1RSxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUztvQkFDaEMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO29CQUN2QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztvQkFDekUsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHFEQUFxRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNsRyxDQUFDO2dCQUVELDZFQUE2RTtnQkFDN0UsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVM7b0JBQ2pDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztvQkFDeEMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7b0JBQzFFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSxzREFBc0QsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDbkcsQ0FBQztnQkFFRCx5REFBeUQ7Z0JBQ3pELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTO29CQUNqQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7b0JBQ3hDLE9BQU8sTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDN0MsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHdDQUF3QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNyRixDQUFDO2dCQUVELDBEQUEwRDtnQkFDMUQsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVM7b0JBQ2xDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztvQkFDekMsT0FBTyxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM5QyxNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0seUNBQXlDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3RGLENBQUM7Z0JBRUQsK0RBQStEO2dCQUMvRCxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3BDLE1BQWMsQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7Z0JBQzlELENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNyQyxNQUFjLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztnQkFDdEMsQ0FBQztnQkFDRCxJQUFJLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3JDLE1BQWMsQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7Z0JBQy9ELENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUN0QyxNQUFjLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztnQkFDdkMsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7O1dBR0c7UUFDSyxrQkFBa0IsQ0FBQyxVQUFnQztZQUN6RCxJQUFJLENBQUMsVUFBVTtnQkFBRSxPQUFPO1lBRXhCLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUU7Z0JBQ25DLE1BQU0sTUFBTSxHQUFHLDhCQUE4QixLQUFLLEVBQUUsQ0FBQztnQkFFckQsbURBQW1EO2dCQUNuRCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNqQixNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0sb0JBQW9CLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2pFLENBQUM7Z0JBRUQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQztvQkFDbkIsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHNCQUFzQixFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNuRSxDQUFDO2dCQUVELHlCQUF5QjtnQkFDekIsSUFBSSxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztvQkFDMUcsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLGdEQUFnRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUM3RixDQUFDO2dCQUVELElBQUksTUFBTSxDQUFDLFdBQVc7b0JBQ2xCLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztvQkFDdkMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7b0JBQ3pFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSxxREFBcUQsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDbEcsQ0FBQztnQkFFRCxJQUFJLE1BQU0sQ0FBQyxZQUFZO29CQUNuQixDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7b0JBQ3hDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO29CQUMxRSxNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0sc0RBQXNELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ25HLENBQUM7Z0JBRUQseURBQXlEO2dCQUN6RCxJQUFJLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUztvQkFDakMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDO29CQUN4QyxPQUFPLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQzdDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSx3Q0FBd0MsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDckYsQ0FBQztnQkFFRCwwREFBMEQ7Z0JBQzFELElBQUksTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTO29CQUNsQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7b0JBQ3pDLE9BQU8sTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDOUMsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHlDQUF5QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN0RixDQUFDO2dCQUVELCtEQUErRDtnQkFDL0QsSUFBSSxNQUFNLENBQUMsV0FBVyxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNwQyxNQUFjLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO2dCQUM5RCxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDckMsTUFBYyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7Z0JBQ3RDLENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNyQyxNQUFjLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO2dCQUMvRCxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDdEMsTUFBYyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZDLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztTQUNKO1FBRUQ7OztXQUdHO1FBQ0ssb0JBQW9CLENBQUMsWUFBb0M7WUFDL0QsSUFBSSxDQUFDLFlBQVk7Z0JBQUUsT0FBTztZQUUxQixZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFO2dCQUNyQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzFDLENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7O1dBR0c7UUFDSyxvQkFBb0IsQ0FBQyxZQUE4QjtZQUN6RCxJQUFJLENBQUMsWUFBWTtnQkFBRSxPQUFPO1lBRTFCLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUU7Z0JBQ3BDLE1BQU0sTUFBTSxHQUFHLDBCQUEwQixLQUFLLEVBQUUsQ0FBQztnQkFFakQsa0RBQWtEO2dCQUNsRCxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNoQixNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0sb0JBQW9CLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2pFLENBQUM7Z0JBRUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsQ0FBQztvQkFDdEIsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLDBCQUEwQixFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN2RSxDQUFDO2dCQUVELHVCQUF1QjtnQkFDdkIsSUFBSSxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQztvQkFDL0QsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHVDQUF1QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNwRixDQUFDO2dCQUVELDZCQUE2QjtnQkFDN0IsSUFBSSxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxJQUFJLEVBQUUsQ0FBQztvQkFDNUUsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLDhDQUE4QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMzRixDQUFDO2dCQUVELGdDQUFnQztnQkFDaEMsSUFBSSxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7b0JBQ25CLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7d0JBQ2hDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSx3REFBd0QsRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDckcsQ0FBQztvQkFFRCxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsRUFBRTt3QkFDL0MsSUFBSSxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7NEJBQ3pELE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSxjQUFjLFlBQVksa0NBQWtDLEVBQUUsSUFBSSxDQUFDLENBQUM7d0JBQ3pHLENBQUM7b0JBQ0gsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQztnQkFFRCw0RUFBNEU7Z0JBQzVFLElBQUksS0FBSyxDQUFDLFdBQVcsS0FBSyxTQUFTO29CQUMvQixDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUM7b0JBQ3RDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDO29CQUN4RSxNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0scURBQXFELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2xHLENBQUM7Z0JBRUQsNkVBQTZFO2dCQUM3RSxJQUFJLEtBQUssQ0FBQyxZQUFZLEtBQUssU0FBUztvQkFDaEMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDO29CQUN2QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztvQkFDekUsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHNEQUFzRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNuRyxDQUFDO2dCQUVELHlEQUF5RDtnQkFDekQsSUFBSSxLQUFLLENBQUMsWUFBWSxLQUFLLFNBQVM7b0JBQ2hDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQztvQkFDdkMsT0FBTyxLQUFLLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM1QyxNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0sd0NBQXdDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3JGLENBQUM7Z0JBRUQsMERBQTBEO2dCQUMxRCxJQUFJLEtBQUssQ0FBQyxhQUFhLEtBQUssU0FBUztvQkFDakMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDO29CQUN4QyxPQUFPLEtBQUssQ0FBQyxhQUFhLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQzdDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSx5Q0FBeUMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDdEYsQ0FBQztnQkFFRCwrREFBK0Q7Z0JBQy9ELElBQUksS0FBSyxDQUFDLFdBQVcsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDbkMsS0FBYSxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztnQkFDN0QsQ0FBQztnQkFDRCxJQUFJLEtBQUssQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3BDLEtBQWEsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO2dCQUNyQyxDQUFDO2dCQUNELElBQUksS0FBSyxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDcEMsS0FBYSxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztnQkFDOUQsQ0FBQztnQkFDRCxJQUFJLEtBQUssQ0FBQyxhQUFhLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3JDLEtBQWEsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO2dCQUN0QyxDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUVEOzs7V0FHRztRQUNLLGtDQUFrQyxDQUFDLDBCQUFnRTtZQUN6RyxJQUFJLENBQUMsMEJBQTBCO2dCQUFFLE9BQU87WUFFeEMsMEJBQTBCLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFO2dCQUNuRCxNQUFNLE1BQU0sR0FBRyw4Q0FBOEMsS0FBSyxFQUFFLENBQUM7Z0JBRXJFLG1EQUFtRDtnQkFDbkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDakIsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLG9CQUFvQixFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNqRSxDQUFDO2dCQUVELElBQUksTUFBTSxDQUFDLFNBQVMsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDbkMsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHlCQUF5QixFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN0RSxDQUFDO2dCQUVELGdCQUFnQjtnQkFDaEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLDZCQUE2QixDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO29CQUNoRixNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0sNERBQTRELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3pHLENBQUM7Z0JBRUQsMkJBQTJCO2dCQUMzQixJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7b0JBQzFDLElBQUksTUFBTSxDQUFDLFNBQVMsR0FBRyxDQUFDLElBQUksTUFBTSxDQUFDLFNBQVMsR0FBRyxJQUFJLEVBQUUsQ0FBQzt3QkFDcEQsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHdDQUF3QyxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUNyRixDQUFDO2dCQUNILENBQUM7Z0JBRUQsdUVBQXVFO2dCQUN2RSxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssU0FBUztvQkFDM0IsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO29CQUNsQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztvQkFDcEUsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLGdEQUFnRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUM3RixDQUFDO2dCQUVELG9EQUFvRDtnQkFDcEQsSUFBSSxNQUFNLENBQUMsT0FBTyxLQUFLLFNBQVM7b0JBQzVCLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztvQkFDbkMsT0FBTyxNQUFNLENBQUMsT0FBTyxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUN4QyxNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0sbUNBQW1DLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2hGLENBQUM7Z0JBRUQsK0RBQStEO2dCQUMvRCxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQy9CLE1BQWMsQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7Z0JBQ3pELENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsT0FBTyxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNoQyxNQUFjLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztnQkFDakMsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7O1dBR0c7UUFDSyxtQkFBbUIsQ0FBQyxXQUFrQztZQUM1RCxJQUFJLENBQUMsV0FBVztnQkFBRSxPQUFPO1lBRXpCLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUU7Z0JBQ3BDLE1BQU0sTUFBTSxHQUFHLCtCQUErQixLQUFLLEVBQUUsQ0FBQztnQkFFdEQsbURBQW1EO2dCQUNuRCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNqQixNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0sb0JBQW9CLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2pFLENBQUM7Z0JBRUQsdUJBQXVCO2dCQUN2QixJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDO29CQUNqRSxNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0sdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3BGLENBQUM7Z0JBRUQsNEVBQTRFO2dCQUM1RSxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUztvQkFDaEMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO29CQUN2QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztvQkFDekUsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHFEQUFxRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNsRyxDQUFDO2dCQUVELDZFQUE2RTtnQkFDN0UsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVM7b0JBQ2pDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztvQkFDeEMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7b0JBQzFFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSxzREFBc0QsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDbkcsQ0FBQztnQkFFRCx5REFBeUQ7Z0JBQ3pELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTO29CQUNqQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7b0JBQ3hDLE9BQU8sTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDN0MsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHdDQUF3QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNyRixDQUFDO2dCQUVELDBEQUEwRDtnQkFDMUQsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVM7b0JBQ2xDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztvQkFDekMsT0FBTyxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM5QyxNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0seUNBQXlDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3RGLENBQUM7Z0JBRUQsK0RBQStEO2dCQUMvRCxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3BDLE1BQWMsQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7Z0JBQzlELENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNyQyxNQUFjLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztnQkFDdEMsQ0FBQztnQkFDRCxJQUFJLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3JDLE1BQWMsQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7Z0JBQy9ELENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUN0QyxNQUFjLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztnQkFDdkMsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7O1dBR0c7UUFDSyw4QkFBOEIsQ0FBQyxzQkFBb0Q7WUFDekYsSUFBSSxDQUFDLHNCQUFzQjtnQkFBRSxPQUFPO1lBRXBDLHNCQUFzQixDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDL0MsTUFBTSxNQUFNLEdBQUcsc0NBQXNDLEtBQUssRUFBRSxDQUFDO2dCQUU3RCwyRUFBMkU7Z0JBQzNFLElBQUksTUFBTSxDQUFDLElBQUksS0FBSyxTQUFTLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztvQkFDckcsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLG9EQUFvRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNqRyxDQUFDO2dCQUVELDRFQUE0RTtnQkFDNUUsSUFBSSxNQUFNLENBQUMsV0FBVyxLQUFLLFNBQVM7b0JBQ2hDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztvQkFDdkMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7b0JBQ3pFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSxxREFBcUQsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDbEcsQ0FBQztnQkFFRCw2RUFBNkU7Z0JBQzdFLElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTO29CQUNqQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7b0JBQ3hDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO29CQUMxRSxNQUFNLElBQUksNkJBQWUsQ0FBQyxHQUFHLE1BQU0sc0RBQXNELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ25HLENBQUM7Z0JBRUQseURBQXlEO2dCQUN6RCxJQUFJLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUztvQkFDakMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDO29CQUN4QyxPQUFPLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQzdDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLEdBQUcsTUFBTSx3Q0FBd0MsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDckYsQ0FBQztnQkFFRCwwREFBMEQ7Z0JBQzFELElBQUksTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTO29CQUNsQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7b0JBQ3pDLE9BQU8sTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDOUMsTUFBTSxJQUFJLDZCQUFlLENBQUMsR0FBRyxNQUFNLHlDQUF5QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN0RixDQUFDO2dCQUVELCtEQUErRDtnQkFDL0QsSUFBSSxNQUFNLENBQUMsSUFBSSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM3QixNQUFjLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxTQUFTLENBQUM7Z0JBQ2pFLENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsV0FBVyxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNwQyxNQUFjLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO2dCQUM5RCxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDckMsTUFBYyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7Z0JBQ3RDLENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNyQyxNQUFjLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO2dCQUMvRCxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDdEMsTUFBYyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZDLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztTQUNKO1FBRUQ7OztXQUdHO1FBQ0ssMkJBQTJCLENBQUMsTUFBNkI7WUFDL0Qsd0ZBQXdGO1lBQ3hGLElBQUksQ0FBQztnQkFDSCxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ3hDLENBQUM7WUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO2dCQUNmLElBQUksS0FBSyxZQUFZLDZCQUFlLEVBQUUsQ0FBQztvQkFDckMsMkVBQTJFO29CQUMzRSxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ3pELE1BQU0sSUFBSSw2QkFBZSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDM0MsQ0FBQztnQkFDRCxNQUFNLEtBQUssQ0FBQztZQUNkLENBQUM7U0FDRjtRQUVEOzs7V0FHRztRQUNLLHVCQUF1QixDQUFDLE1BQXlCO1lBQ3ZELHdGQUF3RjtZQUN4RixJQUFJLENBQUM7Z0JBQ0gsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUNwQyxDQUFDO1lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztnQkFDZixJQUFJLEtBQUssWUFBWSw2QkFBZSxFQUFFLENBQUM7b0JBQ3JDLDJFQUEyRTtvQkFDM0UsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUN6RCxNQUFNLElBQUksNkJBQWUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzNDLENBQUM7Z0JBQ0QsTUFBTSxLQUFLLENBQUM7WUFDZCxDQUFDO1NBQ0Y7UUFFRDs7O1dBR0c7UUFDSyx5QkFBeUIsQ0FBQyxNQUEyQjtZQUMzRCx3RkFBd0Y7WUFDeEYsSUFBSSxDQUFDO2dCQUNILElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDdEMsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxLQUFLLFlBQVksNkJBQWUsRUFBRSxDQUFDO29CQUNyQywyRUFBMkU7b0JBQzNFLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDekQsTUFBTSxJQUFJLDZCQUFlLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMzQyxDQUFDO2dCQUNELE1BQU0sS0FBSyxDQUFDO1lBQ2QsQ0FBQztTQUNGO1FBRUQ7OztXQUdHO1FBQ0sseUJBQXlCLENBQUMsTUFBcUI7WUFDckQsd0ZBQXdGO1lBQ3hGLElBQUksQ0FBQztnQkFDSCxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ3RDLENBQUM7WUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO2dCQUNmLElBQUksS0FBSyxZQUFZLDZCQUFlLEVBQUUsQ0FBQztvQkFDckMsMkVBQTJFO29CQUMzRSxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ3pELE1BQU0sSUFBSSw2QkFBZSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDM0MsQ0FBQztnQkFDRCxNQUFNLEtBQUssQ0FBQztZQUNkLENBQUM7U0FDRjtRQUVEOzs7V0FHRztRQUNLLHVDQUF1QyxDQUFDLE1BQXlDO1lBQ3ZGLHdGQUF3RjtZQUN4RixJQUFJLENBQUM7Z0JBQ0gsSUFBSSxDQUFDLGtDQUFrQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUNwRCxDQUFDO1lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztnQkFDZixJQUFJLEtBQUssWUFBWSw2QkFBZSxFQUFFLENBQUM7b0JBQ3JDLDJFQUEyRTtvQkFDM0UsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUN6RCxNQUFNLElBQUksNkJBQWUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzNDLENBQUM7Z0JBQ0QsTUFBTSxLQUFLLENBQUM7WUFDZCxDQUFDO1NBQ0Y7UUFFRDs7O1dBR0c7UUFDSyx3QkFBd0IsQ0FBQyxNQUEwQjtZQUN6RCx3RkFBd0Y7WUFDeEYsSUFBSSxDQUFDO2dCQUNILElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDckMsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxLQUFLLFlBQVksNkJBQWUsRUFBRSxDQUFDO29CQUNyQywyRUFBMkU7b0JBQzNFLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDekQsTUFBTSxJQUFJLDZCQUFlLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMzQyxDQUFDO2dCQUNELE1BQU0sS0FBSyxDQUFDO1lBQ2QsQ0FBQztTQUNGO1FBRUQ7OztXQUdHO1FBQ0ssbUNBQW1DLENBQUMsTUFBaUM7WUFDM0Usd0ZBQXdGO1lBQ3hGLElBQUksQ0FBQztnQkFDSCxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ2hELENBQUM7WUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO2dCQUNmLElBQUksS0FBSyxZQUFZLDZCQUFlLEVBQUUsQ0FBQztvQkFDckMsMkVBQTJFO29CQUMzRSxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ3pELE1BQU0sSUFBSSw2QkFBZSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDM0MsQ0FBQztnQkFDRCxNQUFNLEtBQUssQ0FBQztZQUNkLENBQUM7U0FDRjs7WUE3dENVLHVEQUFTOzs7OztBQUFULDhCQUFTIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgZnMgZnJvbSAnZnMnO1xuaW1wb3J0IHR5cGUgeyBJUmVzb2x2YWJsZSwgSVJlc291cmNlIH0gZnJvbSAnYXdzLWNkay1saWInO1xuaW1wb3J0IHsgQXJuLCBBcm5Gb3JtYXQsIExhenksIFJlc291cmNlLCBUb2tlbiwgVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnYXdzLWNkay1saWInO1xuaW1wb3J0ICogYXMgYmVkcm9jayBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgdHlwZSB7IE1ldHJpY09wdGlvbnMsIE1ldHJpY1Byb3BzIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWNsb3Vkd2F0Y2gnO1xuaW1wb3J0IHsgTWV0cmljIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWNsb3Vkd2F0Y2gnO1xuaW1wb3J0ICogYXMgaWFtIGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0IHR5cGUgeyBJS2V5IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWttcyc7XG5pbXBvcnQgeyBLZXkgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3Mta21zJztcbmltcG9ydCB7IG1kNWhhc2ggfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9oZWxwZXJzLWludGVybmFsJztcbmltcG9ydCB7IGFkZENvbnN0cnVjdE1ldGFkYXRhLCBNZXRob2RNZXRhZGF0YSB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL21ldGFkYXRhLXJlc291cmNlJztcbmltcG9ydCB7IHByb3BlcnR5SW5qZWN0YWJsZSB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL3Byb3AtaW5qZWN0YWJsZSc7XG5pbXBvcnQgdHlwZSB7IENvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuLy8gSW50ZXJuYWwgTGlic1xuaW1wb3J0ICogYXMgZmlsdGVycyBmcm9tICcuL2d1YXJkcmFpbC1maWx0ZXJzJztcbmltcG9ydCB7IEd1YXJkcmFpbFZlcnNpb24gfSBmcm9tICcuL2d1YXJkcmFpbC12ZXJzaW9uJztcblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDT01NT05cbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogR3VhcmRyYWlsQ3Jvc3NSZWdpb25Db25maWdQcm9wZXJ0eVxuICovXG5leHBvcnQgaW50ZXJmYWNlIEd1YXJkcmFpbENyb3NzUmVnaW9uQ29uZmlnUHJvcGVydHkge1xuICAvKipcbiAgICogVGhlIGFybiBvZiB0aGVzeXN0ZW0tZGVmaW5lZCBndWFyZHJhaWwgcHJvZmlsZSB0aGF0IHlvdSdyZSB1c2luZyB3aXRoIHlvdXIgZ3VhcmRyYWlsLlxuICAgKiBHdWFyZHJhaWwgcHJvZmlsZXMgZGVmaW5lIHRoZSBkZXN0aW5hdGlvbiBBV1MgUmVnaW9ucyB3aGVyZSBndWFyZHJhaWwgaW5mZXJlbmNlIHJlcXVlc3RzIGNhbiBiZSBhdXRvbWF0aWNhbGx5IHJvdXRlZC5cbiAgICogVXNpbmcgZ3VhcmRyYWlsIHByb2ZpbGVzIGhlbHBzIG1haW50YWluIGd1YXJkcmFpbCBwZXJmb3JtYW5jZSBhbmQgcmVsaWFiaWxpdHkgd2hlbiBkZW1hbmQgaW5jcmVhc2VzLlxuICAgKiBAZGVmYXVsdCAtIE5vIGNyb3NzLXJlZ2lvbiBjb25maWd1cmF0aW9uXG4gICAqL1xuICByZWFkb25seSBndWFyZHJhaWxQcm9maWxlQXJuOiBzdHJpbmc7XG59XG5cbi8qKlxuICogUmVwcmVzZW50cyBhIEd1YXJkcmFpbCwgZWl0aGVyIGNyZWF0ZWQgd2l0aCBDREsgb3IgaW1wb3J0ZWQuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSUd1YXJkcmFpbCBleHRlbmRzIElSZXNvdXJjZSB7XG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHJlYWRvbmx5IGd1YXJkcmFpbEFybjogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIElEIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHJlYWRvbmx5IGd1YXJkcmFpbElkOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBPcHRpb25hbCBLTVMgZW5jcnlwdGlvbiBrZXkgYXNzb2NpYXRlZCB3aXRoIHRoaXMgZ3VhcmRyYWlsXG4gICAqL1xuICByZWFkb25seSBrbXNLZXk/OiBJS2V5O1xuICAvKipcbiAgICogV2hlbiB0aGlzIGd1YXJkcmFpbCB3YXMgbGFzdCB1cGRhdGVkLlxuICAgKi9cbiAgcmVhZG9ubHkgbGFzdFVwZGF0ZWQ/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgdmVyc2lvbiBvZiB0aGUgZ3VhcmRyYWlsLiBJZiBubyBleHBsaWNpdCB2ZXJzaW9uIGlzIGNyZWF0ZWQsXG4gICAqIHRoaXMgd2lsbCBkZWZhdWx0IHRvIFwiRFJBRlRcIlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICByZWFkb25seSBndWFyZHJhaWxWZXJzaW9uOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEdyYW50IHRoZSBnaXZlbiBwcmluY2lwYWwgaWRlbnRpdHkgcGVybWlzc2lvbnMgdG8gcGVyZm9ybSBhY3Rpb25zIG9uIHRoaXMgZ3VhcmRyYWlsLlxuICAgKi9cbiAgZ3JhbnQoZ3JhbnRlZTogaWFtLklHcmFudGFibGUsIC4uLmFjdGlvbnM6IHN0cmluZ1tdKTogaWFtLkdyYW50O1xuICAvKipcbiAgICogR3JhbnQgdGhlIGdpdmVuIGlkZW50aXR5IHBlcm1pc3Npb25zIHRvIGFwcGx5IHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBncmFudEFwcGx5KGdyYW50ZWU6IGlhbS5JR3JhbnRhYmxlKTogaWFtLkdyYW50O1xuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGdpdmVuIG5hbWVkIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBtZXRyaWMobWV0cmljTmFtZTogc3RyaW5nLCBwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWM7XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbnMgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIG1ldHJpY0ludm9jYXRpb25zKHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYztcblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBpbnZvY2F0aW9uIGxhdGVuY3kgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIG1ldHJpY0ludm9jYXRpb25MYXRlbmN5KHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYztcblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBpbnZvY2F0aW9uIGNsaWVudCBlcnJvcnMgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIG1ldHJpY0ludm9jYXRpb25DbGllbnRFcnJvcnMocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljO1xuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb24gc2VydmVyIGVycm9ycyBtZXRyaWMgZm9yIHRoaXMgZ3VhcmRyYWlsLlxuICAgKi9cbiAgbWV0cmljSW52b2NhdGlvblNlcnZlckVycm9ycyhwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWM7XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbiB0aHJvdHRsZXMgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIG1ldHJpY0ludm9jYXRpb25UaHJvdHRsZXMocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljO1xuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIHRleHQgdW5pdCBjb3VudCBtZXRyaWMgZm9yIHRoaXMgZ3VhcmRyYWlsLlxuICAgKi9cbiAgbWV0cmljVGV4dFVuaXRDb3VudChwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWM7XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbnMgaW50ZXJ2ZW5lZCBtZXRyaWMgZm9yIHRoaXMgZ3VhcmRyYWlsLlxuICAgKi9cbiAgbWV0cmljSW52b2NhdGlvbnNJbnRlcnZlbmVkKHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYztcbn1cblxuLyoqXG4gKiBBYnN0cmFjdCBiYXNlIGNsYXNzIGZvciBhIEd1YXJkcmFpbC5cbiAqIENvbnRhaW5zIG1ldGhvZHMgYW5kIGF0dHJpYnV0ZXMgdmFsaWQgZm9yIEd1YXJkcmFpbHMgZWl0aGVyIGNyZWF0ZWQgd2l0aCBDREsgb3IgaW1wb3J0ZWQuXG4gKi9cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBHdWFyZHJhaWxCYXNlIGV4dGVuZHMgUmVzb3VyY2UgaW1wbGVtZW50cyBJR3VhcmRyYWlsIHtcbiAgLyoqXG4gICAqIFJldHVybiB0aGUgZ2l2ZW4gbmFtZWQgbWV0cmljIGZvciBhbGwgZ3VhcmRyYWlscy5cbiAgICpcbiAgICogQnkgZGVmYXVsdCwgdGhlIG1ldHJpYyB3aWxsIGJlIGNhbGN1bGF0ZWQgYXMgYSBzdW0gb3ZlciBhIHBlcmlvZCBvZiA1IG1pbnV0ZXMuXG4gICAqIFlvdSBjYW4gY3VzdG9taXplIHRoaXMgYnkgdXNpbmcgdGhlIGBzdGF0aXN0aWNgIGFuZCBgcGVyaW9kYCBwcm9wZXJ0aWVzLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBtZXRyaWNBbGwobWV0cmljTmFtZTogc3RyaW5nLCBwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiBuZXcgTWV0cmljKHtcbiAgICAgIG5hbWVzcGFjZTogJ0FXUy9CZWRyb2NrL0d1YXJkcmFpbHMnLFxuICAgICAgZGltZW5zaW9uc01hcDogeyBPcGVyYXRpb246ICdBcHBseUd1YXJkcmFpbCcgfSxcbiAgICAgIG1ldHJpY05hbWUsXG4gICAgICAuLi5wcm9wcyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb25zIG1ldHJpYyBmb3IgYWxsIGd1YXJkcmFpbHMuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIG1ldHJpY0FsbEludm9jYXRpb25zKHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYyB7XG4gICAgcmV0dXJuIHRoaXMubWV0cmljQWxsKCdJbnZvY2F0aW9ucycsIHByb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIHRleHQgdW5pdCBjb3VudCBtZXRyaWMgZm9yIGFsbCBndWFyZHJhaWxzLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBtZXRyaWNBbGxUZXh0VW5pdENvdW50KHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYyB7XG4gICAgcmV0dXJuIHRoaXMubWV0cmljQWxsKCdUZXh0VW5pdENvdW50JywgcHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbnMgaW50ZXJ2ZW5lZCBtZXRyaWMgZm9yIGFsbCBndWFyZHJhaWxzLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBtZXRyaWNBbGxJbnZvY2F0aW9uc0ludGVydmVuZWQocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gdGhpcy5tZXRyaWNBbGwoJ0ludm9jYXRpb25zSW50ZXJ2ZW5lZCcsIHByb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb24gbGF0ZW5jeSBtZXRyaWMgZm9yIGFsbCBndWFyZHJhaWxzLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBtZXRyaWNBbGxJbnZvY2F0aW9uTGF0ZW5jeShwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiB0aGlzLm1ldHJpY0FsbCgnSW52b2NhdGlvbkxhdGVuY3knLCBwcm9wcyk7XG4gIH1cblxuICBwcml2YXRlIF92ZXJzaW9uOiBzdHJpbmcgPSAnRFJBRlQnO1xuXG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSBndWFyZHJhaWxBcm46IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIElEIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSBndWFyZHJhaWxJZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBPcHRpb25hbCBLTVMgZW5jcnlwdGlvbiBrZXkgYXNzb2NpYXRlZCB3aXRoIHRoaXMgZ3VhcmRyYWlsXG4gICAqL1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkga21zS2V5PzogSUtleTtcblxuICAvKipcbiAgICogV2hlbiB0aGlzIGd1YXJkcmFpbCB3YXMgbGFzdCB1cGRhdGVkLlxuICAgKi9cbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGxhc3RVcGRhdGVkPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgdmVyc2lvbiBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgZ2V0IGd1YXJkcmFpbFZlcnNpb24oKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy5fdmVyc2lvbjtcbiAgfVxuXG4gIHByb3RlY3RlZCB1cGRhdGVWZXJzaW9uKHZlcnNpb246IHN0cmluZykge1xuICAgIHRoaXMuX3ZlcnNpb24gPSB2ZXJzaW9uO1xuICB9XG5cbiAgLyoqXG4gICAqIEdyYW50IHRoZSBnaXZlbiBwcmluY2lwYWwgaWRlbnRpdHkgcGVybWlzc2lvbnMgdG8gcGVyZm9ybSBhY3Rpb25zIG9uIHRoaXMgZ3VhcmRyYWlsLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICovXG4gIHB1YmxpYyBncmFudChncmFudGVlOiBpYW0uSUdyYW50YWJsZSwgLi4uYWN0aW9uczogc3RyaW5nW10pIHtcbiAgICByZXR1cm4gaWFtLkdyYW50LmFkZFRvUHJpbmNpcGFsKHtcbiAgICAgIGdyYW50ZWUsXG4gICAgICBhY3Rpb25zLFxuICAgICAgcmVzb3VyY2VBcm5zOiBbdGhpcy5ndWFyZHJhaWxBcm5dLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEdyYW50IHRoZSBnaXZlbiBpZGVudGl0eSBwZXJtaXNzaW9ucyB0byBhcHBseSB0aGUgZ3VhcmRyYWlsLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICovXG4gIHB1YmxpYyBncmFudEFwcGx5KGdyYW50ZWU6IGlhbS5JR3JhbnRhYmxlKTogaWFtLkdyYW50IHtcbiAgICBjb25zdCBiYXNlR3JhbnQgPSB0aGlzLmdyYW50KGdyYW50ZWUsICdiZWRyb2NrOkFwcGx5R3VhcmRyYWlsJyk7XG5cbiAgICBpZiAodGhpcy5rbXNLZXkpIHtcbiAgICAgIC8vIElmIEtNUyBrZXkgZXhpc3RzLCBjcmVhdGUgZW5jcnlwdGlvbiBncmFudCBhbmQgY29tYmluZSB3aXRoIGJhc2UgZ3JhbnRcbiAgICAgIGNvbnN0IGttc0dyYW50ID0gdGhpcy5rbXNLZXkuZ3JhbnRFbmNyeXB0RGVjcnlwdChncmFudGVlKTtcbiAgICAgIHJldHVybiBrbXNHcmFudC5jb21iaW5lKGJhc2VHcmFudCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIElmIG5vIEtNUyBrZXkgZXhpc3RzLCByZXR1cm4gb25seSB0aGUgYmFzZSBncmFudFxuICAgICAgcmV0dXJuIGJhc2VHcmFudDtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBnaXZlbiBuYW1lZCBtZXRyaWMgZm9yIHRoaXMgZ3VhcmRyYWlsLlxuICAgKlxuICAgKiBCeSBkZWZhdWx0LCB0aGUgbWV0cmljIHdpbGwgYmUgY2FsY3VsYXRlZCBhcyBhIHN1bSBvdmVyIGEgcGVyaW9kIG9mIDUgbWludXRlcy5cbiAgICogWW91IGNhbiBjdXN0b21pemUgdGhpcyBieSB1c2luZyB0aGUgYHN0YXRpc3RpY2AgYW5kIGBwZXJpb2RgIHByb3BlcnRpZXMuXG4gICAqL1xuICBwdWJsaWMgbWV0cmljKG1ldHJpY05hbWU6IHN0cmluZywgcHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICBjb25zdCBtZXRyaWNQcm9wczogTWV0cmljUHJvcHMgPSB7XG4gICAgICBuYW1lc3BhY2U6ICdBV1MvQmVkcm9jay9HdWFyZHJhaWxzJyxcbiAgICAgIG1ldHJpY05hbWUsXG4gICAgICBkaW1lbnNpb25zTWFwOiB7IEd1YXJkcmFpbEFybjogdGhpcy5ndWFyZHJhaWxBcm4sIEd1YXJkcmFpbFZlcnNpb246IHRoaXMuZ3VhcmRyYWlsVmVyc2lvbiB9LFxuICAgICAgLi4ucHJvcHMsXG4gICAgfTtcbiAgICByZXR1cm4gdGhpcy5jb25maWd1cmVNZXRyaWMobWV0cmljUHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbnMgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIHB1YmxpYyBtZXRyaWNJbnZvY2F0aW9ucyhwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiB0aGlzLm1ldHJpYygnSW52b2NhdGlvbnMnLCBwcm9wcyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBpbnZvY2F0aW9uIGxhdGVuY3kgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIHB1YmxpYyBtZXRyaWNJbnZvY2F0aW9uTGF0ZW5jeShwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiB0aGlzLm1ldHJpYygnSW52b2NhdGlvbkxhdGVuY3knLCBwcm9wcyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBpbnZvY2F0aW9uIGNsaWVudCBlcnJvcnMgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIHB1YmxpYyBtZXRyaWNJbnZvY2F0aW9uQ2xpZW50RXJyb3JzKHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYyB7XG4gICAgcmV0dXJuIHRoaXMubWV0cmljKCdJbnZvY2F0aW9uQ2xpZW50RXJyb3JzJywgcHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbiBzZXJ2ZXIgZXJyb3JzIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgbWV0cmljSW52b2NhdGlvblNlcnZlckVycm9ycyhwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiB0aGlzLm1ldHJpYygnSW52b2NhdGlvblNlcnZlckVycm9ycycsIHByb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb24gdGhyb3R0bGVzIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgbWV0cmljSW52b2NhdGlvblRocm90dGxlcyhwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiB0aGlzLm1ldHJpYygnSW52b2NhdGlvblRocm90dGxlcycsIHByb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIHRleHQgdW5pdCBjb3VudCBtZXRyaWMgZm9yIHRoaXMgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIG1ldHJpY1RleHRVbml0Q291bnQocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMoJ1RleHRVbml0Q291bnQnLCBwcm9wcyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBpbnZvY2F0aW9ucyBpbnRlcnZlbmVkIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgbWV0cmljSW52b2NhdGlvbnNJbnRlcnZlbmVkKHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYyB7XG4gICAgcmV0dXJuIHRoaXMubWV0cmljKCdJbnZvY2F0aW9uc0ludGVydmVuZWQnLCBwcm9wcyk7XG4gIH1cblxuICBwcml2YXRlIGNvbmZpZ3VyZU1ldHJpYyhwcm9wczogTWV0cmljUHJvcHMpIHtcbiAgICByZXR1cm4gbmV3IE1ldHJpYyh7XG4gICAgICAuLi5wcm9wcyxcbiAgICAgIHJlZ2lvbjogcHJvcHM/LnJlZ2lvbiA/PyB0aGlzLnN0YWNrLnJlZ2lvbixcbiAgICAgIGFjY291bnQ6IHByb3BzPy5hY2NvdW50ID8/IHRoaXMuc3RhY2suYWNjb3VudCxcbiAgICB9KTtcbiAgfVxufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIFBST1BTIEZPUiBORVcgQ09OU1RSVUNUXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNyZWF0aW5nIGEgR3VhcmRyYWlsLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEd1YXJkcmFpbFByb3BzIHtcbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqIFRoaXMgd2lsbCBiZSB1c2VkIGFzIHRoZSBwaHlzaWNhbCBuYW1lIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICByZWFkb25seSBndWFyZHJhaWxOYW1lOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgZGVzY3JpcHRpb24gb2YgdGhlIGd1YXJkcmFpbC5cbiAgICogQGRlZmF1bHQgLSBObyBkZXNjcmlwdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgbWVzc2FnZSB0byByZXR1cm4gd2hlbiB0aGUgZ3VhcmRyYWlsIGJsb2NrcyBhIHByb21wdC5cbiAgICogTXVzdCBiZSBiZXR3ZWVuIDEgYW5kIDUwMCBjaGFyYWN0ZXJzLlxuICAgKiBAZGVmYXVsdCBcIlNvcnJ5LCB5b3VyIHF1ZXJ5IHZpb2xhdGVzIG91ciB1c2FnZSBwb2xpY3kuXCJcbiAgICovXG4gIHJlYWRvbmx5IGJsb2NrZWRJbnB1dE1lc3NhZ2luZz86IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBtZXNzYWdlIHRvIHJldHVybiB3aGVuIHRoZSBndWFyZHJhaWwgYmxvY2tzIGEgbW9kZWwgcmVzcG9uc2UuXG4gICAqIE11c3QgYmUgYmV0d2VlbiAxIGFuZCA1MDAgY2hhcmFjdGVycy5cbiAgICogQGRlZmF1bHQgXCJTb3JyeSwgSSBhbSB1bmFibGUgdG8gYW5zd2VyIHlvdXIgcXVlc3Rpb24gYmVjYXVzZSBvZiBvdXIgdXNhZ2UgcG9saWN5LlwiXG4gICAqL1xuICByZWFkb25seSBibG9ja2VkT3V0cHV0c01lc3NhZ2luZz86IHN0cmluZztcbiAgLyoqXG4gICAqIEEgY3VzdG9tIEtNUyBrZXkgdG8gdXNlIGZvciBlbmNyeXB0aW5nIGRhdGEuXG4gICAqIEBkZWZhdWx0IC0gRGF0YSBpcyBlbmNyeXB0ZWQgYnkgZGVmYXVsdCB3aXRoIGEga2V5IHRoYXQgQVdTIG93bnMgYW5kIG1hbmFnZXMgZm9yIHlvdVxuICAgKi9cbiAgcmVhZG9ubHkga21zS2V5PzogSUtleTtcbiAgLyoqXG4gICAqIFRoZSBjb250ZW50IGZpbHRlcnMgdG8gYXBwbHkgdG8gdGhlIGd1YXJkcmFpbC5cbiAgICogQGRlZmF1bHQgW11cbiAgICovXG4gIHJlYWRvbmx5IGNvbnRlbnRGaWx0ZXJzPzogZmlsdGVycy5Db250ZW50RmlsdGVyW107XG4gIC8qKlxuICAgKiBUaGUgdGllciBjb25maWd1cmF0aW9uIHRvIGFwcGx5IHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IGZpbHRlcnMuVGllckNvbmZpZy5DTEFTU0lDXG4gICAqL1xuICByZWFkb25seSBjb250ZW50RmlsdGVyc1RpZXJDb25maWc/OiBmaWx0ZXJzLlRpZXJDb25maWc7XG4gIC8qKlxuICAgKiBBIGxpc3Qgb2YgcG9saWNpZXMgcmVsYXRlZCB0byB0b3BpY3MgdGhhdCB0aGUgZ3VhcmRyYWlsIHNob3VsZCBkZW55LlxuICAgKiBAZGVmYXVsdCBbXVxuICAgKi9cbiAgcmVhZG9ubHkgZGVuaWVkVG9waWNzPzogZmlsdGVycy5Ub3BpY1tdO1xuICAvKipcbiAgICogVGhlIHRpZXIgY29uZmlndXJhdGlvbiB0byBhcHBseSB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAZGVmYXVsdCBmaWx0ZXJzLlRpZXJDb25maWcuQ0xBU1NJQ1xuICAgKi9cbiAgcmVhZG9ubHkgdG9waWNzVGllckNvbmZpZz86IGZpbHRlcnMuVGllckNvbmZpZztcbiAgLyoqXG4gICAqIFRoZSB3b3JkIGZpbHRlcnMgdG8gYXBwbHkgdG8gdGhlIGd1YXJkcmFpbC5cbiAgICogQGRlZmF1bHQgW11cbiAgICovXG4gIHJlYWRvbmx5IHdvcmRGaWx0ZXJzPzogZmlsdGVycy5Xb3JkRmlsdGVyW107XG4gIC8qKlxuICAgKiBUaGUgbWFuYWdlZCB3b3JkIGZpbHRlcnMgdG8gYXBwbHkgdG8gdGhlIGd1YXJkcmFpbC5cbiAgICogQGRlZmF1bHQgW11cbiAgICovXG4gIHJlYWRvbmx5IG1hbmFnZWRXb3JkTGlzdEZpbHRlcnM/OiBmaWx0ZXJzLk1hbmFnZWRXb3JkRmlsdGVyW107XG4gIC8qKlxuICAgKiBUaGUgUElJIGZpbHRlcnMgdG8gYXBwbHkgdG8gdGhlIGd1YXJkcmFpbC5cbiAgICogQGRlZmF1bHQgW11cbiAgICovXG4gIHJlYWRvbmx5IHBpaUZpbHRlcnM/OiBmaWx0ZXJzLlBJSUZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIHJlZ3VsYXIgZXhwcmVzc2lvbiAocmVnZXgpIGZpbHRlcnMgdG8gYXBwbHkgdG8gdGhlIGd1YXJkcmFpbC5cbiAgICogQGRlZmF1bHQgW11cbiAgICovXG4gIHJlYWRvbmx5IHJlZ2V4RmlsdGVycz86IGZpbHRlcnMuUmVnZXhGaWx0ZXJbXTtcbiAgLyoqXG4gICAqIFRoZSBjb250ZXh0dWFsIGdyb3VuZGluZyBmaWx0ZXJzIHRvIGFwcGx5IHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IFtdXG4gICAqL1xuICByZWFkb25seSBjb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycz86IGZpbHRlcnMuQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIGNyb3NzLXJlZ2lvbiBjb25maWd1cmF0aW9uIGZvciB0aGUgZ3VhcmRyYWlsLlxuICAgKiBUaGlzIGlzIG9wdGlvbmFsIGFuZCB3aGVuIHByb3ZpZGVkLCBpdCBzaG91bGQgYmUgb2YgdHlwZSBHdWFyZHJhaWxDcm9zc1JlZ2lvbkNvbmZpZ1Byb3BlcnR5LlxuICAgKiBAZGVmYXVsdCAtIE5vIGNyb3NzLXJlZ2lvbiBjb25maWd1cmF0aW9uXG4gICAqL1xuICByZWFkb25seSBjcm9zc1JlZ2lvbkNvbmZpZz86IEd1YXJkcmFpbENyb3NzUmVnaW9uQ29uZmlnUHJvcGVydHk7XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgIEFUVFJTIEZPUiBJTVBPUlRFRCBDT05TVFJVQ1RcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbmV4cG9ydCBpbnRlcmZhY2UgR3VhcmRyYWlsQXR0cmlidXRlcyB7XG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBndWFyZHJhaWwuIEF0IGxlYXN0IG9uZSBvZiBndWFyZHJhaWxBcm4gb3IgZ3VhcmRyYWlsSWQgbXVzdCBiZVxuICAgKiBkZWZpbmVkIGluIG9yZGVyIHRvIGluaXRpYWxpemUgYSBndWFyZHJhaWwgcmVmLlxuICAgKi9cbiAgcmVhZG9ubHkgZ3VhcmRyYWlsQXJuOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgS01TIGtleSBvZiB0aGUgZ3VhcmRyYWlsIGlmIGN1c3RvbSBlbmNyeXB0aW9uIGlzIGNvbmZpZ3VyZWQuXG4gICAqXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE1lYW5zIGRhdGEgaXMgZW5jcnlwdGVkIGJ5IGRlZmF1bHQgd2l0aCBhIEFXUy1tYW5hZ2VkIGtleVxuICAgKi9cbiAgcmVhZG9ubHkga21zS2V5PzogSUtleTtcbiAgLyoqXG4gICAqIFRoZSB2ZXJzaW9uIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqXG4gICAqIEBkZWZhdWx0IFwiRFJBRlRcIlxuICAgKi9cbiAgcmVhZG9ubHkgZ3VhcmRyYWlsVmVyc2lvbj86IHN0cmluZztcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBORVcgQ09OU1RSVUNUIERFRklOSVRJT05cbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogQ2xhc3MgdG8gY3JlYXRlIGEgR3VhcmRyYWlsIHdpdGggQ0RLLlxuICogQGNsb3VkZm9ybWF0aW9uUmVzb3VyY2UgQVdTOjpCZWRyb2NrOjpHdWFyZHJhaWxcbiAqL1xuQHByb3BlcnR5SW5qZWN0YWJsZVxuZXhwb3J0IGNsYXNzIEd1YXJkcmFpbCBleHRlbmRzIEd1YXJkcmFpbEJhc2Uge1xuICAvKiogVW5pcXVlbHkgaWRlbnRpZmllcyB0aGlzIGNsYXNzLiAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFBST1BFUlRZX0lOSkVDVElPTl9JRDogc3RyaW5nID0gJ0Bhd3MtY2RrLmF3cy1iZWRyb2NrLWFscGhhLkd1YXJkcmFpbCc7XG5cbiAgLyoqXG4gICAqIEltcG9ydCBhIGd1YXJkcmFpbCBnaXZlbiBpdHMgYXR0cmlidXRlc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tR3VhcmRyYWlsQXR0cmlidXRlcyhzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBhdHRyczogR3VhcmRyYWlsQXR0cmlidXRlcyk6IElHdWFyZHJhaWwge1xuICAgIGNsYXNzIEltcG9ydCBleHRlbmRzIEd1YXJkcmFpbEJhc2Uge1xuICAgICAgcHVibGljIHJlYWRvbmx5IGd1YXJkcmFpbEFybiA9IGF0dHJzLmd1YXJkcmFpbEFybjtcbiAgICAgIHB1YmxpYyByZWFkb25seSBndWFyZHJhaWxJZCA9IEFybi5zcGxpdChhdHRycy5ndWFyZHJhaWxBcm4sIEFybkZvcm1hdC5TTEFTSF9SRVNPVVJDRV9OQU1FKS5yZXNvdXJjZU5hbWUhO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGttc0tleSA9IGF0dHJzLmttc0tleTtcbiAgICAgIHB1YmxpYyByZWFkb25seSBsYXN0VXBkYXRlZCA9IHVuZGVmaW5lZDtcblxuICAgICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKHNjb3BlLCBpZCk7XG4gICAgICAgIHRoaXMudXBkYXRlVmVyc2lvbihhdHRycy5ndWFyZHJhaWxWZXJzaW9uID8/ICdEUkFGVCcpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBuZXcgSW1wb3J0KCk7XG4gIH1cblxuICAvKipcbiAgICogSW1wb3J0IGEgbG93LWxldmVsIEwxIENmbiBHdWFyZHJhaWxcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUNmbkd1YXJkcmFpbChjZm5HdWFyZHJhaWw6IGJlZHJvY2suQ2ZuR3VhcmRyYWlsKTogSUd1YXJkcmFpbCB7XG4gICAgcmV0dXJuIG5ldyAoY2xhc3MgZXh0ZW5kcyBHdWFyZHJhaWxCYXNlIHtcbiAgICAgIHB1YmxpYyByZWFkb25seSBndWFyZHJhaWxBcm4gPSBjZm5HdWFyZHJhaWwuYXR0ckd1YXJkcmFpbEFybjtcbiAgICAgIHB1YmxpYyByZWFkb25seSBndWFyZHJhaWxJZCA9IGNmbkd1YXJkcmFpbC5hdHRyR3VhcmRyYWlsSWQ7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkga21zS2V5ID0gY2ZuR3VhcmRyYWlsLmttc0tleUFyblxuICAgICAgICA/IEtleS5mcm9tS2V5QXJuKHRoaXMsICdARnJvbUNmbkd1YXJkcmFpbEtleScsIGNmbkd1YXJkcmFpbC5rbXNLZXlBcm4pXG4gICAgICAgIDogdW5kZWZpbmVkO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGxhc3RVcGRhdGVkID0gY2ZuR3VhcmRyYWlsLmF0dHJVcGRhdGVkQXQ7XG5cbiAgICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihjZm5HdWFyZHJhaWwsICdARnJvbUNmbkd1YXJkcmFpbCcpO1xuICAgICAgICB0aGlzLnVwZGF0ZVZlcnNpb24oY2ZuR3VhcmRyYWlsLmF0dHJWZXJzaW9uKTtcbiAgICAgIH1cbiAgICB9KSgpO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBBUk4gb2YgdGhlIGd1YXJkcmFpbC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGd1YXJkcmFpbEFybjogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIElEIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBndWFyZHJhaWxJZDogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIGd1YXJkcmFpbC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBuYW1lOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgS01TIGtleSB1c2VkIHRvIGVuY3J5cHQgZGF0YS5cbiAgICpcbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gXCJEYXRhIGlzIGVuY3J5cHRlZCBieSBkZWZhdWx0IHdpdGggYSBrZXkgdGhhdCBBV1Mgb3ducyBhbmQgbWFuYWdlcyBmb3IgeW91XCJcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBrbXNLZXk/OiBJS2V5O1xuICAvKipcbiAgICogVGhlIGNvbnRlbnQgZmlsdGVycyBhcHBsaWVkIGJ5IHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgY29udGVudEZpbHRlcnM6IGZpbHRlcnMuQ29udGVudEZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIFBJSSBmaWx0ZXJzIGFwcGxpZWQgYnkgdGhlIGd1YXJkcmFpbC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBwaWlGaWx0ZXJzOiBmaWx0ZXJzLlBJSUZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIHJlZ2V4IGZpbHRlcnMgYXBwbGllZCBieSB0aGUgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHJlZ2V4RmlsdGVyczogZmlsdGVycy5SZWdleEZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIGRlbmllZCB0b3BpYyBmaWx0ZXJzIGFwcGxpZWQgYnkgdGhlIGd1YXJkcmFpbC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBkZW5pZWRUb3BpY3M6IGZpbHRlcnMuVG9waWNbXTtcbiAgLyoqXG4gICAqIFRoZSBjb250ZXh0dWFsIGdyb3VuZGluZyBmaWx0ZXJzIGFwcGxpZWQgYnkgdGhlIGd1YXJkcmFpbC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBjb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyczogZmlsdGVycy5Db250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyW107XG4gIC8qKlxuICAgKiBUaGUgd29yZCBmaWx0ZXJzIGFwcGxpZWQgYnkgdGhlIGd1YXJkcmFpbC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSB3b3JkRmlsdGVyczogZmlsdGVycy5Xb3JkRmlsdGVyW107XG4gIC8qKlxuICAgKiBUaGUgbWFuYWdlZCB3b3JkIGxpc3QgZmlsdGVycyBhcHBsaWVkIGJ5IHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgbWFuYWdlZFdvcmRMaXN0RmlsdGVyczogZmlsdGVycy5NYW5hZ2VkV29yZEZpbHRlcltdO1xuICAvKipcbiAgICogV2hlbiB0aGlzIGd1YXJkcmFpbCB3YXMgbGFzdCB1cGRhdGVkXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgbGFzdFVwZGF0ZWQ/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgY29tcHV0ZWQgaGFzaCBvZiB0aGUgZ3VhcmRyYWlsIHByb3BlcnRpZXMuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgaGFzaDogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIEwxIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBndWFyZHJhaWxcbiAgICovXG4gIHByaXZhdGUgcmVhZG9ubHkgX19yZXNvdXJjZTogYmVkcm9jay5DZm5HdWFyZHJhaWw7XG5cbiAgLyoqXG4gICAqIFRoZSB0aWVyIHRoYXQgeW91ciBndWFyZHJhaWwgdXNlcyBmb3IgZGVuaWVkIHRvcGljIGZpbHRlcnMuXG4gICAqIEBkZWZhdWx0IGZpbHRlcnMuVGllckNvbmZpZy5DTEFTU0lDXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgdG9waWNzVGllckNvbmZpZzogZmlsdGVycy5UaWVyQ29uZmlnO1xuXG4gIC8qKlxuICAgKiBUaGUgdGllciB0aGF0IHlvdXIgZ3VhcmRyYWlsIHVzZXMgZm9yIGNvbnRlbnQgZmlsdGVycy5cbiAgICogQ29uc2lkZXIgdXNpbmcgYSB0aWVyIHRoYXQgYmFsYW5jZXMgcGVyZm9ybWFuY2UsIGFjY3VyYWN5LCBhbmQgY29tcGF0aWJpbGl0eSB3aXRoIHlvdXIgZXhpc3RpbmcgZ2VuZXJhdGl2ZSBBSSB3b3JrZmxvd3MuXG4gICAqIEBkZWZhdWx0IGZpbHRlcnMuVGllckNvbmZpZy5DTEFTU0lDXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgY29udGVudEZpbHRlcnNUaWVyQ29uZmlnOiBmaWx0ZXJzLlRpZXJDb25maWc7XG4gIC8qKlxuICAgKiBUaGUgY3Jvc3MtcmVnaW9uIGNvbmZpZ3VyYXRpb24gZm9yIHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgY3Jvc3NSZWdpb25Db25maWc/OiBHdWFyZHJhaWxDcm9zc1JlZ2lvbkNvbmZpZ1Byb3BlcnR5O1xuXG4gIC8qKlxuICAgKiBUaGUgbWVzc2FnZSB0byByZXR1cm4gd2hlbiB0aGUgZ3VhcmRyYWlsIGJsb2NrcyBhIHByb21wdC5cbiAgICogQGRlZmF1bHQgXCJTb3JyeSwgeW91ciBxdWVyeSB2aW9sYXRlcyBvdXIgdXNhZ2UgcG9saWN5LlwiXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgYmxvY2tlZElucHV0TWVzc2FnaW5nOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBtZXNzYWdlIHRvIHJldHVybiB3aGVuIHRoZSBndWFyZHJhaWwgYmxvY2tzIGEgbW9kZWwgcmVzcG9uc2UuXG4gICAqIEBkZWZhdWx0IFwiU29ycnksIEkgYW0gdW5hYmxlIHRvIGFuc3dlciB5b3VyIHF1ZXN0aW9uIGJlY2F1c2Ugb2Ygb3VyIHVzYWdlIHBvbGljeS5cIlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGJsb2NrZWRPdXRwdXRzTWVzc2FnaW5nOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM6IEd1YXJkcmFpbFByb3BzKSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCB7XG4gICAgICBwaHlzaWNhbE5hbWU6IHByb3BzLmd1YXJkcmFpbE5hbWUsXG4gICAgfSk7XG4gICAgLy8gRW5oYW5jZWQgQ0RLIEFuYWx5dGljcyBUZWxlbWV0cnlcbiAgICBhZGRDb25zdHJ1Y3RNZXRhZGF0YSh0aGlzLCBwcm9wcyk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBTZXQgcHJvcGVydGllcyBvciBkZWZhdWx0c1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMubmFtZSA9IHRoaXMucGh5c2ljYWxOYW1lO1xuICAgIHRoaXMuY29udGVudEZpbHRlcnMgPSBwcm9wcy5jb250ZW50RmlsdGVycyA/PyBbXTtcbiAgICB0aGlzLnBpaUZpbHRlcnMgPSBwcm9wcy5waWlGaWx0ZXJzID8/IFtdO1xuICAgIHRoaXMucmVnZXhGaWx0ZXJzID0gcHJvcHMucmVnZXhGaWx0ZXJzID8/IFtdO1xuICAgIHRoaXMuZGVuaWVkVG9waWNzID0gcHJvcHMuZGVuaWVkVG9waWNzID8/IFtdO1xuICAgIHRoaXMuY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMgPSBwcm9wcy5jb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycyA/PyBbXTtcbiAgICB0aGlzLndvcmRGaWx0ZXJzID0gcHJvcHMud29yZEZpbHRlcnMgPz8gW107XG4gICAgdGhpcy5tYW5hZ2VkV29yZExpc3RGaWx0ZXJzID0gcHJvcHMubWFuYWdlZFdvcmRMaXN0RmlsdGVycyA/PyBbXTtcbiAgICB0aGlzLnRvcGljc1RpZXJDb25maWcgPSBwcm9wcy50b3BpY3NUaWVyQ29uZmlnID8/IGZpbHRlcnMuVGllckNvbmZpZy5DTEFTU0lDO1xuICAgIHRoaXMuY29udGVudEZpbHRlcnNUaWVyQ29uZmlnID0gcHJvcHMuY29udGVudEZpbHRlcnNUaWVyQ29uZmlnID8/IGZpbHRlcnMuVGllckNvbmZpZy5DTEFTU0lDO1xuICAgIHRoaXMuY3Jvc3NSZWdpb25Db25maWcgPSBwcm9wcy5jcm9zc1JlZ2lvbkNvbmZpZztcbiAgICB0aGlzLmJsb2NrZWRJbnB1dE1lc3NhZ2luZyA9IHByb3BzLmJsb2NrZWRJbnB1dE1lc3NhZ2luZyA/PyAnU29ycnksIHlvdXIgcXVlcnkgdmlvbGF0ZXMgb3VyIHVzYWdlIHBvbGljeS4nO1xuICAgIHRoaXMuYmxvY2tlZE91dHB1dHNNZXNzYWdpbmcgPSBwcm9wcy5ibG9ja2VkT3V0cHV0c01lc3NhZ2luZyA/PyAnU29ycnksIEkgYW0gdW5hYmxlIHRvIGFuc3dlciB5b3VyIHF1ZXN0aW9uIGJlY2F1c2Ugb2Ygb3VyIHVzYWdlIHBvbGljeS4nO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gVmFsaWRhdGUgYWxsIGZpbHRlciBhcnJheXNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLnZhbGlkYXRlQ29udGVudEZpbHRlcnModGhpcy5jb250ZW50RmlsdGVycyk7XG4gICAgdGhpcy52YWxpZGF0ZVBpaUZpbHRlcnModGhpcy5waWlGaWx0ZXJzKTtcbiAgICB0aGlzLnZhbGlkYXRlUmVnZXhGaWx0ZXJzKHRoaXMucmVnZXhGaWx0ZXJzKTtcbiAgICB0aGlzLnZhbGlkYXRlRGVuaWVkVG9waWNzKHRoaXMuZGVuaWVkVG9waWNzKTtcbiAgICB0aGlzLnZhbGlkYXRlQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnModGhpcy5jb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycyk7XG4gICAgdGhpcy52YWxpZGF0ZVdvcmRGaWx0ZXJzKHRoaXMud29yZEZpbHRlcnMpO1xuICAgIHRoaXMudmFsaWRhdGVNYW5hZ2VkV29yZExpc3RGaWx0ZXJzKHRoaXMubWFuYWdlZFdvcmRMaXN0RmlsdGVycyk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBWYWxpZGF0ZSBtZXNzYWdpbmcgcHJvcGVydGllc1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMudmFsaWRhdGVNZXNzYWdpbmdQcm9wZXJ0eSh0aGlzLmJsb2NrZWRJbnB1dE1lc3NhZ2luZywgJ2Jsb2NrZWRJbnB1dE1lc3NhZ2luZycpO1xuICAgIHRoaXMudmFsaWRhdGVNZXNzYWdpbmdQcm9wZXJ0eSh0aGlzLmJsb2NrZWRPdXRwdXRzTWVzc2FnaW5nLCAnYmxvY2tlZE91dHB1dHNNZXNzYWdpbmcnKTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIFZhbGlkYXRlIHRpZXIgY29uZmlndXJhdGlvbiByZXF1aXJlbWVudHNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLnZhbGlkYXRlVGllckNvbmZpZ3VyYXRpb24ocHJvcHMpO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gQ0ZOIFByb3BzIC0gV2l0aCBMYXp5IHN1cHBvcnRcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBsZXQgY2ZuUHJvcHM6IGJlZHJvY2suQ2ZuR3VhcmRyYWlsUHJvcHMgPSB7XG4gICAgICBuYW1lOiBwcm9wcy5ndWFyZHJhaWxOYW1lLFxuICAgICAgZGVzY3JpcHRpb246IHByb3BzLmRlc2NyaXB0aW9uLFxuICAgICAga21zS2V5QXJuOiBwcm9wcy5rbXNLZXk/LmtleUFybixcbiAgICAgIGJsb2NrZWRJbnB1dE1lc3NhZ2luZzogdGhpcy5ibG9ja2VkSW5wdXRNZXNzYWdpbmcsXG4gICAgICBibG9ja2VkT3V0cHV0c01lc3NhZ2luZzogdGhpcy5ibG9ja2VkT3V0cHV0c01lc3NhZ2luZyxcbiAgICAgIC8vIExhenkgcHJvcHNcbiAgICAgIGNyb3NzUmVnaW9uQ29uZmlnOiB0aGlzLmdlbmVyYXRlQ2ZuQ3Jvc3NSZWdpb25Db25maWcoKSxcbiAgICAgIGNvbnRlbnRQb2xpY3lDb25maWc6IHRoaXMuZ2VuZXJhdGVDZm5Db250ZW50UG9saWN5Q29uZmlnKCksXG4gICAgICBjb250ZXh0dWFsR3JvdW5kaW5nUG9saWN5Q29uZmlnOiB0aGlzLmdlbmVyYXRlQ2ZuQ29udGV4dHVhbFBvbGljeUNvbmZpZygpLFxuICAgICAgdG9waWNQb2xpY3lDb25maWc6IHRoaXMuZ2VuZXJhdGVDZm5Ub3BpY1BvbGljeSgpLFxuICAgICAgd29yZFBvbGljeUNvbmZpZzogdGhpcy5nZW5lcmF0ZUNmbldvcmRQb2xpY3lDb25maWcoKSxcbiAgICAgIHNlbnNpdGl2ZUluZm9ybWF0aW9uUG9saWN5Q29uZmlnOiB0aGlzLmdlbmVyYXRlQ2ZuU2Vuc2l0aXZlSW5mb3JtYXRpb25Qb2xpY3lDb25maWcoKSxcbiAgICB9O1xuXG4gICAgLy8gSGFzaCBjYWxjdWxhdGlvbiB1c2VmdWwgZm9yIHZlcnNpb25pbmcgb2YgdGhlIGd1YXJkcmFpbFxuICAgIHRoaXMuaGFzaCA9IG1kNWhhc2goSlNPTi5zdHJpbmdpZnkoY2ZuUHJvcHMpKTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIEwxIEluc3RhbnRpYXRpb25cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLl9fcmVzb3VyY2UgPSBuZXcgYmVkcm9jay5DZm5HdWFyZHJhaWwodGhpcywgJ015R3VhcmRyYWlsJywgY2ZuUHJvcHMpO1xuXG4gICAgdGhpcy5ndWFyZHJhaWxJZCA9IHRoaXMuX19yZXNvdXJjZS5hdHRyR3VhcmRyYWlsSWQ7XG4gICAgdGhpcy5ndWFyZHJhaWxBcm4gPSB0aGlzLl9fcmVzb3VyY2UuYXR0ckd1YXJkcmFpbEFybjtcbiAgICB0aGlzLnVwZGF0ZVZlcnNpb24odGhpcy5fX3Jlc291cmNlLmF0dHJWZXJzaW9uKTtcbiAgICB0aGlzLmxhc3RVcGRhdGVkID0gdGhpcy5fX3Jlc291cmNlLmF0dHJVcGRhdGVkQXQ7XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gTUVUSE9EU1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIEFkZHMgYSBjb250ZW50IGZpbHRlciB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSBjb250ZW50IGZpbHRlciB0byBhZGQuXG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgYWRkQ29udGVudEZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuQ29udGVudEZpbHRlcik6IHZvaWQge1xuICAgIHRoaXMudmFsaWRhdGVTaW5nbGVDb250ZW50RmlsdGVyKGZpbHRlcik7XG4gICAgdGhpcy5jb250ZW50RmlsdGVycy5wdXNoKGZpbHRlcik7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhIFBJSSBmaWx0ZXIgdG8gdGhlIGd1YXJkcmFpbC5cbiAgICogQHBhcmFtIGZpbHRlciBUaGUgUElJIGZpbHRlciB0byBhZGQuXG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgYWRkUElJRmlsdGVyKGZpbHRlcjogZmlsdGVycy5QSUlGaWx0ZXIpOiB2b2lkIHtcbiAgICB0aGlzLnZhbGlkYXRlU2luZ2xlUGlpRmlsdGVyKGZpbHRlcik7XG4gICAgdGhpcy5waWlGaWx0ZXJzLnB1c2goZmlsdGVyKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGEgcmVnZXggZmlsdGVyIHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIHJlZ2V4IGZpbHRlciB0byBhZGQuXG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgYWRkUmVnZXhGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLlJlZ2V4RmlsdGVyKTogdm9pZCB7XG4gICAgdGhpcy52YWxpZGF0ZVNpbmdsZVJlZ2V4RmlsdGVyKGZpbHRlcik7XG4gICAgdGhpcy5yZWdleEZpbHRlcnMucHVzaChmaWx0ZXIpO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgYSBkZW5pZWQgdG9waWMgZmlsdGVyIHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIGRlbmllZCB0b3BpYyBmaWx0ZXIgdG8gYWRkLlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGFkZERlbmllZFRvcGljRmlsdGVyKGZpbHRlcjogZmlsdGVycy5Ub3BpYyk6IHZvaWQge1xuICAgIHRoaXMudmFsaWRhdGVTaW5nbGVEZW5pZWRUb3BpYyhmaWx0ZXIpO1xuICAgIHRoaXMuZGVuaWVkVG9waWNzLnB1c2goZmlsdGVyKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGEgY29udGV4dHVhbCBncm91bmRpbmcgZmlsdGVyIHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIGNvbnRleHR1YWwgZ3JvdW5kaW5nIGZpbHRlciB0byBhZGQuXG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgYWRkQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcik6IHZvaWQge1xuICAgIHRoaXMudmFsaWRhdGVTaW5nbGVDb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyKGZpbHRlcik7XG4gICAgdGhpcy5jb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycy5wdXNoKGZpbHRlcik7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhIHdvcmQgZmlsdGVyIHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIHdvcmQgZmlsdGVyIHRvIGFkZC5cbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBhZGRXb3JkRmlsdGVyKGZpbHRlcjogZmlsdGVycy5Xb3JkRmlsdGVyKTogdm9pZCB7XG4gICAgdGhpcy52YWxpZGF0ZVNpbmdsZVdvcmRGaWx0ZXIoZmlsdGVyKTtcbiAgICB0aGlzLndvcmRGaWx0ZXJzLnB1c2goZmlsdGVyKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGEgd29yZCBmaWx0ZXIgdG8gdGhlIGd1YXJkcmFpbC5cbiAgICogQHBhcmFtIGZpbGVQYXRoIFRoZSBsb2NhdGlvbiBvZiB0aGUgd29yZCBmaWx0ZXIgZmlsZS5cbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBhZGRXb3JkRmlsdGVyRnJvbUZpbGUoZmlsZVBhdGg6IHN0cmluZyxcbiAgICBpbnB1dEFjdGlvbj86IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLFxuICAgIG91dHB1dEFjdGlvbj86IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLFxuICAgIGlucHV0RW5hYmxlZD86IGJvb2xlYW4sXG4gICAgb3V0cHV0RW5hYmxlZD86IGJvb2xlYW4pOiB2b2lkIHtcbiAgICBjb25zdCBmaWxlQ29udGVudHMgPSBmcy5yZWFkRmlsZVN5bmMoZmlsZVBhdGgsICd1dGY4Jyk7XG4gICAgY29uc3Qgd29yZHMgPSBmaWxlQ29udGVudHMudHJpbSgpLnNwbGl0KCcsJyk7XG4gICAgZm9yIChjb25zdCB3b3JkIG9mIHdvcmRzKSB0aGlzLmFkZFdvcmRGaWx0ZXIoeyB0ZXh0OiB3b3JkLCBpbnB1dEFjdGlvbiwgb3V0cHV0QWN0aW9uLCBpbnB1dEVuYWJsZWQsIG91dHB1dEVuYWJsZWQgfSk7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhIG1hbmFnZWQgd29yZCBsaXN0IGZpbHRlciB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSBtYW5hZ2VkIHdvcmQgbGlzdCBmaWx0ZXIgdG8gYWRkLlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGFkZE1hbmFnZWRXb3JkTGlzdEZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuTWFuYWdlZFdvcmRGaWx0ZXIpOiB2b2lkIHtcbiAgICB0aGlzLnZhbGlkYXRlU2luZ2xlTWFuYWdlZFdvcmRMaXN0RmlsdGVyKGZpbHRlcik7XG4gICAgdGhpcy5tYW5hZ2VkV29yZExpc3RGaWx0ZXJzLnB1c2goZmlsdGVyKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgYSB2ZXJzaW9uIGZvciB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAcGFyYW0gZGVzY3JpcHRpb24gVGhlIGRlc2NyaXB0aW9uIG9mIHRoZSB2ZXJzaW9uLlxuICAgKiBAcmV0dXJucyBUaGUgZ3VhcmRyYWlsIHZlcnNpb24uXG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgY3JlYXRlVmVyc2lvbihkZXNjcmlwdGlvbj86IHN0cmluZyk6IHN0cmluZyB7XG4gICAgY29uc3QgY2ZuVmVyc2lvbiA9IG5ldyBHdWFyZHJhaWxWZXJzaW9uKHRoaXMsIGBHdWFyZHJhaWxWZXJzaW9uLSR7dGhpcy5oYXNoLnNsaWNlKDAsIDE2KX1gLCB7XG4gICAgICBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24sXG4gICAgICBndWFyZHJhaWw6IHRoaXMsXG4gICAgfSk7XG5cbiAgICB0aGlzLnVwZGF0ZVZlcnNpb24oY2ZuVmVyc2lvbi5ndWFyZHJhaWxWZXJzaW9uKTtcbiAgICByZXR1cm4gdGhpcy5ndWFyZHJhaWxWZXJzaW9uO1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIENGTiBHZW5lcmF0b3JzXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvKipcbiAgICogUmV0dXJucyB0aGUgY29udGVudCBmaWx0ZXJzIGFwcGxpZWQgdG8gdGhlIGd1YXJkcmFpbC4gVGhpcyBtZXRob2QgZGVmZXJzIHRoZSBjb21wdXRhdGlvblxuICAgKiB0byBzeW50aCB0aW1lLlxuICAgKi9cbiAgcHJpdmF0ZSBnZW5lcmF0ZUNmbkNvbnRlbnRQb2xpY3lDb25maWcoKTogSVJlc29sdmFibGUge1xuICAgIHJldHVybiBMYXp5LmFueSh7XG4gICAgICBwcm9kdWNlOiAoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLmNvbnRlbnRGaWx0ZXJzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICBjb25zdCBjb250ZW50UG9saWN5Q29uZmlnOiBiZWRyb2NrLkNmbkd1YXJkcmFpbC5Db250ZW50UG9saWN5Q29uZmlnUHJvcGVydHkgPSB7XG4gICAgICAgICAgICBmaWx0ZXJzQ29uZmlnOiB0aGlzLmNvbnRlbnRGaWx0ZXJzLFxuICAgICAgICAgICAgLi4uKHRoaXMuY29udGVudEZpbHRlcnNUaWVyQ29uZmlnICYmIHtcbiAgICAgICAgICAgICAgY29udGVudEZpbHRlcnNUaWVyQ29uZmlnOiB7XG4gICAgICAgICAgICAgICAgdGllck5hbWU6IHRoaXMuY29udGVudEZpbHRlcnNUaWVyQ29uZmlnLFxuICAgICAgICAgICAgICB9IGFzIGJlZHJvY2suQ2ZuR3VhcmRyYWlsLkNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZ1Byb3BlcnR5LFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgfTtcblxuICAgICAgICAgIHJldHVybiBjb250ZW50UG9saWN5Q29uZmlnO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgdG9waWMgZmlsdGVycyBhcHBsaWVkIHRvIHRoZSBndWFyZHJhaWwuIFRoaXMgbWV0aG9kIGRlZmVycyB0aGUgY29tcHV0YXRpb25cbiAgICogdG8gc3ludGggdGltZS5cbiAgICovXG4gIHByaXZhdGUgZ2VuZXJhdGVDZm5Ub3BpY1BvbGljeSgpOiBJUmVzb2x2YWJsZSB7XG4gICAgcmV0dXJuIExhenkuYW55KHtcbiAgICAgIHByb2R1Y2U6ICgpID0+IHtcbiAgICAgICAgaWYgKHRoaXMuZGVuaWVkVG9waWNzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICBjb25zdCB0b3BpY1BvbGljeUNvbmZpZzogYmVkcm9jay5DZm5HdWFyZHJhaWwuVG9waWNQb2xpY3lDb25maWdQcm9wZXJ0eSA9IHtcbiAgICAgICAgICAgIHRvcGljc0NvbmZpZzogdGhpcy5kZW5pZWRUb3BpY3MuZmxhdE1hcCgodG9waWM6IGZpbHRlcnMuVG9waWMpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBkZWZpbml0aW9uOiB0b3BpYy5kZWZpbml0aW9uLFxuICAgICAgICAgICAgICAgIG5hbWU6IHRvcGljLm5hbWUsXG4gICAgICAgICAgICAgICAgZXhhbXBsZXM6IHRvcGljLmV4YW1wbGVzLFxuICAgICAgICAgICAgICAgIHR5cGU6ICdERU5ZJyxcbiAgICAgICAgICAgICAgICBpbnB1dEFjdGlvbjogdG9waWMuaW5wdXRBY3Rpb24sXG4gICAgICAgICAgICAgICAgaW5wdXRFbmFibGVkOiB0b3BpYy5pbnB1dEVuYWJsZWQsXG4gICAgICAgICAgICAgICAgb3V0cHV0QWN0aW9uOiB0b3BpYy5vdXRwdXRBY3Rpb24sXG4gICAgICAgICAgICAgICAgb3V0cHV0RW5hYmxlZDogdG9waWMub3V0cHV0RW5hYmxlZCxcbiAgICAgICAgICAgICAgfSBhcyBiZWRyb2NrLkNmbkd1YXJkcmFpbC5Ub3BpY0NvbmZpZ1Byb3BlcnR5O1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAuLi4odGhpcy50b3BpY3NUaWVyQ29uZmlnICYmIHtcbiAgICAgICAgICAgICAgdG9waWNzVGllckNvbmZpZzoge1xuICAgICAgICAgICAgICAgIHRpZXJOYW1lOiB0aGlzLnRvcGljc1RpZXJDb25maWcsXG4gICAgICAgICAgICAgIH0gYXMgYmVkcm9jay5DZm5HdWFyZHJhaWwuVG9waWNzVGllckNvbmZpZ1Byb3BlcnR5LFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgfTtcblxuICAgICAgICAgIHJldHVybiB0b3BpY1BvbGljeUNvbmZpZztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGNvbnRlY3R1YWwgZmlsdGVycyBhcHBsaWVkIHRvIHRoZSBndWFyZHJhaWwuIFRoaXMgbWV0aG9kIGRlZmVycyB0aGUgY29tcHV0YXRpb25cbiAgICogdG8gc3ludGggdGltZS5cbiAgICovXG4gIHByaXZhdGUgZ2VuZXJhdGVDZm5Db250ZXh0dWFsUG9saWN5Q29uZmlnKCk6IElSZXNvbHZhYmxlIHtcbiAgICByZXR1cm4gTGF6eS5hbnkoe1xuICAgICAgcHJvZHVjZTogKCkgPT4ge1xuICAgICAgICBpZiAodGhpcy5jb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGZpbHRlcnNDb25maWc6IHRoaXMuY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMuZmxhdE1hcCgoZmlsdGVyOiBmaWx0ZXJzLkNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXIpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICB0eXBlOiBmaWx0ZXIudHlwZSxcbiAgICAgICAgICAgICAgICB0aHJlc2hvbGQ6IGZpbHRlci50aHJlc2hvbGQsXG4gICAgICAgICAgICAgICAgYWN0aW9uOiBmaWx0ZXIuYWN0aW9uLFxuICAgICAgICAgICAgICAgIGVuYWJsZWQ6IGZpbHRlci5lbmFibGVkLFxuICAgICAgICAgICAgICB9IGFzIGJlZHJvY2suQ2ZuR3VhcmRyYWlsLkNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJDb25maWdQcm9wZXJ0eTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIH07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSB3b3JkIGNvbmZpZyBhcHBsaWVkIHRvIHRoZSBndWFyZHJhaWwuIFRoaXMgbWV0aG9kIGRlZmVycyB0aGUgY29tcHV0YXRpb25cbiAgICogdG8gc3ludGggdGltZS5cbiAgICovXG4gIHByaXZhdGUgZ2VuZXJhdGVDZm5Xb3JkUG9saWN5Q29uZmlnKCk6IElSZXNvbHZhYmxlIHtcbiAgICByZXR1cm4gTGF6eS5hbnkoe1xuICAgICAgcHJvZHVjZTogKCkgPT4ge1xuICAgICAgICBpZiAodGhpcy53b3JkRmlsdGVycy5sZW5ndGggPiAwIHx8IHRoaXMubWFuYWdlZFdvcmRMaXN0RmlsdGVycy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHdvcmRzQ29uZmlnOiB0aGlzLmdlbmVyYXRlQ2ZuV29yZENvbmZpZygpLFxuICAgICAgICAgICAgbWFuYWdlZFdvcmRMaXN0c0NvbmZpZzogdGhpcy5nZW5lcmF0ZUNmbk1hbmFnZWRXb3JkTGlzdHNDb25maWcoKSxcbiAgICAgICAgICB9IGFzIGJlZHJvY2suQ2ZuR3VhcmRyYWlsLldvcmRQb2xpY3lDb25maWdQcm9wZXJ0eTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHdvcmQgZmlsdGVycyBhcHBsaWVkIHRvIHRoZSBndWFyZHJhaWwuIFRoaXMgbWV0aG9kIGRlZmVycyB0aGUgY29tcHV0YXRpb25cbiAgICogdG8gc3ludGggdGltZS5cbiAgICovXG4gIHByaXZhdGUgZ2VuZXJhdGVDZm5Xb3JkQ29uZmlnKCk6IElSZXNvbHZhYmxlIHtcbiAgICByZXR1cm4gTGF6eS5hbnkoXG4gICAgICB7XG4gICAgICAgIHByb2R1Y2U6ICgpID0+IHtcbiAgICAgICAgICByZXR1cm4gdGhpcy53b3JkRmlsdGVycy5mbGF0TWFwKCh3b3JkOiBmaWx0ZXJzLldvcmRGaWx0ZXIpID0+IHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIHRleHQ6IHdvcmQudGV4dCxcbiAgICAgICAgICAgICAgaW5wdXRBY3Rpb246IHdvcmQuaW5wdXRBY3Rpb24sXG4gICAgICAgICAgICAgIGlucHV0RW5hYmxlZDogd29yZC5pbnB1dEVuYWJsZWQsXG4gICAgICAgICAgICAgIG91dHB1dEFjdGlvbjogd29yZC5vdXRwdXRBY3Rpb24sXG4gICAgICAgICAgICAgIG91dHB1dEVuYWJsZWQ6IHdvcmQub3V0cHV0RW5hYmxlZCxcbiAgICAgICAgICAgIH0gYXMgYmVkcm9jay5DZm5HdWFyZHJhaWwuV29yZENvbmZpZ1Byb3BlcnR5O1xuICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIHsgb21pdEVtcHR5QXJyYXk6IHRydWUgfSxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHdvcmQgZmlsdGVycyBhcHBsaWVkIHRvIHRoZSBndWFyZHJhaWwuIFRoaXMgbWV0aG9kIGRlZmVycyB0aGUgY29tcHV0YXRpb25cbiAgICogdG8gc3ludGggdGltZS5cbiAgICovXG4gIHByaXZhdGUgZ2VuZXJhdGVDZm5NYW5hZ2VkV29yZExpc3RzQ29uZmlnKCk6IElSZXNvbHZhYmxlIHtcbiAgICByZXR1cm4gTGF6eS5hbnkoXG4gICAgICB7XG4gICAgICAgIHByb2R1Y2U6ICgpID0+IHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5tYW5hZ2VkV29yZExpc3RGaWx0ZXJzLmZsYXRNYXAoKGZpbHRlcjogZmlsdGVycy5NYW5hZ2VkV29yZEZpbHRlcikgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgdHlwZTogZmlsdGVyLnR5cGUsXG4gICAgICAgICAgICAgIGlucHV0QWN0aW9uOiBmaWx0ZXIuaW5wdXRBY3Rpb24sXG4gICAgICAgICAgICAgIGlucHV0RW5hYmxlZDogZmlsdGVyLmlucHV0RW5hYmxlZCxcbiAgICAgICAgICAgICAgb3V0cHV0QWN0aW9uOiBmaWx0ZXIub3V0cHV0QWN0aW9uLFxuICAgICAgICAgICAgICBvdXRwdXRFbmFibGVkOiBmaWx0ZXIub3V0cHV0RW5hYmxlZCxcbiAgICAgICAgICAgIH0gYXMgYmVkcm9jay5DZm5HdWFyZHJhaWwuTWFuYWdlZFdvcmRzQ29uZmlnUHJvcGVydHk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgeyBvbWl0RW1wdHlBcnJheTogdHJ1ZSB9LFxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgc2Vuc2l0aXZlIGluZm9ybWF0aW9uIGNvbmZpZyBhcHBsaWVkIHRvIHRoZSBndWFyZHJhaWwuIFRoaXMgbWV0aG9kIGRlZmVycyB0aGUgY29tcHV0YXRpb25cbiAgICogdG8gc3ludGggdGltZS5cbiAgICovXG4gIHByaXZhdGUgZ2VuZXJhdGVDZm5TZW5zaXRpdmVJbmZvcm1hdGlvblBvbGljeUNvbmZpZygpOiBJUmVzb2x2YWJsZSB7XG4gICAgcmV0dXJuIExhenkuYW55KFxuICAgICAge1xuICAgICAgICBwcm9kdWNlOiAoKSA9PiB7XG4gICAgICAgICAgaWYgKHRoaXMucmVnZXhGaWx0ZXJzLmxlbmd0aCA+IDAgfHwgdGhpcy5waWlGaWx0ZXJzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIHJlZ2V4ZXNDb25maWc6IHRoaXMuZ2VuZXJhdGVDZm5SZWdleGVzQ29uZmlnKCksXG4gICAgICAgICAgICAgIHBpaUVudGl0aWVzQ29uZmlnOiB0aGlzLmdlbmVyYXRlQ2ZuUGlpRW50aXRpZXNDb25maWcoKSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIHsgb21pdEVtcHR5QXJyYXk6IHRydWUgfSxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHJlZ2V4IGZpbHRlcnMgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuUmVnZXhlc0NvbmZpZygpOiBJUmVzb2x2YWJsZSB7XG4gICAgcmV0dXJuIExhenkuYW55KFxuICAgICAge1xuICAgICAgICBwcm9kdWNlOiAoKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMucmVnZXhGaWx0ZXJzLmZsYXRNYXAoKHJlZ2V4OiBmaWx0ZXJzLlJlZ2V4RmlsdGVyKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBuYW1lOiByZWdleC5uYW1lLFxuICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogcmVnZXguZGVzY3JpcHRpb24sXG4gICAgICAgICAgICAgIHBhdHRlcm46IHJlZ2V4LnBhdHRlcm4sXG4gICAgICAgICAgICAgIGFjdGlvbjogcmVnZXguYWN0aW9uLFxuICAgICAgICAgICAgICBpbnB1dEFjdGlvbjogcmVnZXguaW5wdXRBY3Rpb24sXG4gICAgICAgICAgICAgIGlucHV0RW5hYmxlZDogcmVnZXguaW5wdXRFbmFibGVkLFxuICAgICAgICAgICAgICBvdXRwdXRBY3Rpb246IHJlZ2V4Lm91dHB1dEFjdGlvbixcbiAgICAgICAgICAgICAgb3V0cHV0RW5hYmxlZDogcmVnZXgub3V0cHV0RW5hYmxlZCxcbiAgICAgICAgICAgIH0gYXMgYmVkcm9jay5DZm5HdWFyZHJhaWwuUmVnZXhDb25maWdQcm9wZXJ0eTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB7IG9taXRFbXB0eUFycmF5OiB0cnVlIH0sXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBQaWkgZmlsdGVycyBhcHBsaWVkIHRvIHRoZSBndWFyZHJhaWwuIFRoaXMgbWV0aG9kIGRlZmVycyB0aGUgY29tcHV0YXRpb25cbiAgICogdG8gc3ludGggdGltZS5cbiAgICovXG4gIHByaXZhdGUgZ2VuZXJhdGVDZm5QaWlFbnRpdGllc0NvbmZpZygpOiBJUmVzb2x2YWJsZSB7XG4gICAgcmV0dXJuIExhenkuYW55KFxuICAgICAge1xuICAgICAgICBwcm9kdWNlOiAoKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMucGlpRmlsdGVycy5mbGF0TWFwKChmaWx0ZXI6IGZpbHRlcnMuUElJRmlsdGVyKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICB0eXBlOiBmaWx0ZXIudHlwZS52YWx1ZSxcbiAgICAgICAgICAgICAgYWN0aW9uOiBmaWx0ZXIuYWN0aW9uLFxuICAgICAgICAgICAgICBpbnB1dEFjdGlvbjogZmlsdGVyLmlucHV0QWN0aW9uLFxuICAgICAgICAgICAgICBpbnB1dEVuYWJsZWQ6IGZpbHRlci5pbnB1dEVuYWJsZWQsXG4gICAgICAgICAgICAgIG91dHB1dEFjdGlvbjogZmlsdGVyLm91dHB1dEFjdGlvbixcbiAgICAgICAgICAgICAgb3V0cHV0RW5hYmxlZDogZmlsdGVyLm91dHB1dEVuYWJsZWQsXG4gICAgICAgICAgICB9IGFzIGJlZHJvY2suQ2ZuR3VhcmRyYWlsLlBpaUVudGl0eUNvbmZpZ1Byb3BlcnR5O1xuICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIHsgb21pdEVtcHR5QXJyYXk6IHRydWUgfSxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGNyb3NzLXJlZ2lvbiBjb25maWd1cmF0aW9uIGZvciB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuQ3Jvc3NSZWdpb25Db25maWcoKTogSVJlc29sdmFibGUge1xuICAgIHJldHVybiBMYXp5LmFueSh7XG4gICAgICBwcm9kdWNlOiAoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLmNyb3NzUmVnaW9uQ29uZmlnKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGd1YXJkcmFpbFByb2ZpbGVBcm46IHRoaXMuY3Jvc3NSZWdpb25Db25maWcuZ3VhcmRyYWlsUHJvZmlsZUFybixcbiAgICAgICAgICB9IGFzIGJlZHJvY2suQ2ZuR3VhcmRyYWlsLkd1YXJkcmFpbENyb3NzUmVnaW9uQ29uZmlnUHJvcGVydHk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgYSBSZWdleEZpbHRlciBvYmplY3QgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIHJlZ2V4IGZpbHRlciB0byB2YWxpZGF0ZS5cbiAgICogQHBhcmFtIGluZGV4IE9wdGlvbmFsIGluZGV4IGZvciBlcnJvciBtZXNzYWdlcyB3aGVuIHZhbGlkYXRpbmcgYXJyYXlzLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVJlZ2V4RmlsdGVyKGZpbHRlcjogZmlsdGVycy5SZWdleEZpbHRlciwgaW5kZXg/OiBudW1iZXIpOiB2b2lkIHtcbiAgICBjb25zdCBwcmVmaXggPSBpbmRleCAhPT0gdW5kZWZpbmVkID8gYEludmFsaWQgUmVnZXhGaWx0ZXIgYXQgaW5kZXggJHtpbmRleH1gIDogJ0ludmFsaWQgUmVnZXhGaWx0ZXInO1xuXG4gICAgLy8gVmFsaWRhdGUgbmFtZTogYmV0d2VlbiAxIGFuZCAxMDAgY2hhcmFjdGVyc1xuICAgIGlmIChmaWx0ZXIubmFtZSAhPT0gdW5kZWZpbmVkICYmICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLm5hbWUpKSB7XG4gICAgICBpZiAoZmlsdGVyLm5hbWUubGVuZ3RoIDwgMSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IFRoZSBmaWVsZCBuYW1lIGlzICR7ZmlsdGVyLm5hbWUubGVuZ3RofSBjaGFyYWN0ZXJzIGxvbmcgYnV0IG11c3QgYmUgYXQgbGVhc3QgMSBjaGFyYWN0ZXJzYCwgdGhpcyk7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLm5hbWUubGVuZ3RoID4gMTAwKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogVGhlIGZpZWxkIG5hbWUgaXMgJHtmaWx0ZXIubmFtZS5sZW5ndGh9IGNoYXJhY3RlcnMgbG9uZyBidXQgbXVzdCBiZSBsZXNzIHRoYW4gb3IgZXF1YWwgdG8gMTAwIGNoYXJhY3RlcnNgLCB0aGlzKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBkZXNjcmlwdGlvbjogYmV0d2VlbiAxIGFuZCAxMDAwIGNoYXJhY3RlcnMgKGlmIHByb3ZpZGVkKVxuICAgIGlmIChmaWx0ZXIuZGVzY3JpcHRpb24gIT09IHVuZGVmaW5lZCAmJiAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5kZXNjcmlwdGlvbikpIHtcbiAgICAgIGlmIChmaWx0ZXIuZGVzY3JpcHRpb24ubGVuZ3RoIDwgMSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IFRoZSBmaWVsZCBkZXNjcmlwdGlvbiBpcyAke2ZpbHRlci5kZXNjcmlwdGlvbi5sZW5ndGh9IGNoYXJhY3RlcnMgbG9uZyBidXQgbXVzdCBiZSBhdCBsZWFzdCAxIGNoYXJhY3RlcnNgLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGlmIChmaWx0ZXIuZGVzY3JpcHRpb24ubGVuZ3RoID4gMTAwMCkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IFRoZSBmaWVsZCBkZXNjcmlwdGlvbiBpcyAke2ZpbHRlci5kZXNjcmlwdGlvbi5sZW5ndGh9IGNoYXJhY3RlcnMgbG9uZyBidXQgbXVzdCBiZSBsZXNzIHRoYW4gb3IgZXF1YWwgdG8gMTAwMCBjaGFyYWN0ZXJzYCwgdGhpcyk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgcGF0dGVybjogYXQgbGVhc3Qgb25lIGNoYXJhY3RlclxuICAgIGlmIChmaWx0ZXIucGF0dGVybiAhPT0gdW5kZWZpbmVkICYmICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLnBhdHRlcm4pKSB7XG4gICAgICBpZiAoZmlsdGVyLnBhdHRlcm4ubGVuZ3RoIDwgMSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IFRoZSBmaWVsZCBwYXR0ZXJuIGlzICR7ZmlsdGVyLnBhdHRlcm4ubGVuZ3RofSBjaGFyYWN0ZXJzIGxvbmcgYnV0IG11c3QgYmUgYXQgbGVhc3QgMSBjaGFyYWN0ZXJzYCwgdGhpcyk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgYWN0aW9uOiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlXG4gICAgaWYgKGZpbHRlci5hY3Rpb24gIT09IHVuZGVmaW5lZCAmJiAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5hY3Rpb24pICYmICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIuYWN0aW9uKSkge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiBhY3Rpb24gbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZWAsIHRoaXMpO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIGlucHV0QWN0aW9uOiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlIChpZiBwcm92aWRlZClcbiAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRBY3Rpb24pICYmXG4gICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIuaW5wdXRBY3Rpb24pKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IGlucHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBvdXRwdXRBY3Rpb246IG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWUgKGlmIHByb3ZpZGVkKVxuICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIub3V0cHV0QWN0aW9uKSAmJlxuICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLm91dHB1dEFjdGlvbikpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBpbnB1dEVuYWJsZWQ6IG11c3QgYmUgYSBib29sZWFuIChpZiBwcm92aWRlZClcbiAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLmlucHV0RW5hYmxlZCkgJiZcbiAgICAgICAgdHlwZW9mIGZpbHRlci5pbnB1dEVuYWJsZWQgIT09ICdib29sZWFuJykge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiBpbnB1dEVuYWJsZWQgbXVzdCBiZSBhIGJvb2xlYW4gdmFsdWVgLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBvdXRwdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgaWYgKGZpbHRlci5vdXRwdXRFbmFibGVkICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIub3V0cHV0RW5hYmxlZCkgJiZcbiAgICAgICAgdHlwZW9mIGZpbHRlci5vdXRwdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogb3V0cHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgIH1cblxuICAgIC8vIEFwcGx5IGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzIGlmIG5vdCBwcm92aWRlZFxuICAgIGlmIChmaWx0ZXIuaW5wdXRBY3Rpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgKGZpbHRlciBhcyBhbnkpLmlucHV0QWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgfVxuICAgIGlmIChmaWx0ZXIuaW5wdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgIChmaWx0ZXIgYXMgYW55KS5pbnB1dEVuYWJsZWQgPSB0cnVlO1xuICAgIH1cbiAgICBpZiAoZmlsdGVyLm91dHB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAoZmlsdGVyIGFzIGFueSkub3V0cHV0QWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgfVxuICAgIGlmIChmaWx0ZXIub3V0cHV0RW5hYmxlZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAoZmlsdGVyIGFzIGFueSkub3V0cHV0RW5hYmxlZCA9IHRydWU7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBhIG1lc3NhZ2luZyBwcm9wZXJ0eSAoYmxvY2tlZElucHV0TWVzc2FnaW5nIG9yIGJsb2NrZWRPdXRwdXRzTWVzc2FnaW5nKS5cbiAgICogQHBhcmFtIHZhbHVlIFRoZSBtZXNzYWdpbmcgdmFsdWUgdG8gdmFsaWRhdGUuXG4gICAqIEBwYXJhbSBwcm9wZXJ0eU5hbWUgVGhlIG5hbWUgb2YgdGhlIHByb3BlcnR5IGJlaW5nIHZhbGlkYXRlZC5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVNZXNzYWdpbmdQcm9wZXJ0eSh2YWx1ZTogc3RyaW5nIHwgdW5kZWZpbmVkLCBwcm9wZXJ0eU5hbWU6IHN0cmluZyk6IHZvaWQge1xuICAgIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkICYmICFUb2tlbi5pc1VucmVzb2x2ZWQodmFsdWUpKSB7XG4gICAgICBpZiAodmFsdWUubGVuZ3RoIDwgMSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGBJbnZhbGlkICR7cHJvcGVydHlOYW1lfTogVGhlIGZpZWxkICR7cHJvcGVydHlOYW1lfSBpcyAke3ZhbHVlLmxlbmd0aH0gY2hhcmFjdGVycyBsb25nIGJ1dCBtdXN0IGJlIGF0IGxlYXN0IDEgY2hhcmFjdGVyc2AsIHRoaXMpO1xuICAgICAgfVxuICAgICAgaWYgKHZhbHVlLmxlbmd0aCA+IDUwMCkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGBJbnZhbGlkICR7cHJvcGVydHlOYW1lfTogVGhlIGZpZWxkICR7cHJvcGVydHlOYW1lfSBpcyAke3ZhbHVlLmxlbmd0aH0gY2hhcmFjdGVycyBsb25nIGJ1dCBtdXN0IGJlIGxlc3MgdGhhbiBvciBlcXVhbCB0byA1MDAgY2hhcmFjdGVyc2AsIHRoaXMpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgdGhhdCBjcm9zcy1yZWdpb24gY29uZmlndXJhdGlvbiBpcyBwcm92aWRlZCB3aGVuIFNUQU5EQVJEIHRpZXIgaXMgdXNlZC5cbiAgICogQHBhcmFtIHByb3BzIFRoZSBndWFyZHJhaWwgcHJvcGVydGllcyB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVUaWVyQ29uZmlndXJhdGlvbihwcm9wczogR3VhcmRyYWlsUHJvcHMpOiB2b2lkIHtcbiAgICBjb25zdCBjb250ZW50VGllckNvbmZpZyA9IHByb3BzLmNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZyA/PyBmaWx0ZXJzLlRpZXJDb25maWcuQ0xBU1NJQztcbiAgICBjb25zdCB0b3BpY3NUaWVyQ29uZmlnID0gcHJvcHMudG9waWNzVGllckNvbmZpZyA/PyBmaWx0ZXJzLlRpZXJDb25maWcuQ0xBU1NJQztcbiAgICBjb25zdCBoYXNDcm9zc1JlZ2lvbkNvbmZpZyA9IHByb3BzLmNyb3NzUmVnaW9uQ29uZmlnICE9PSB1bmRlZmluZWQ7XG5cbiAgICAvLyBDaGVjayBpZiBTVEFOREFSRCB0aWVyIGlzIHVzZWQgZm9yIGNvbnRlbnQgZmlsdGVyc1xuICAgIGlmIChjb250ZW50VGllckNvbmZpZyA9PT0gZmlsdGVycy5UaWVyQ29uZmlnLlNUQU5EQVJEICYmICFoYXNDcm9zc1JlZ2lvbkNvbmZpZykge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihcbiAgICAgICAgJ0Nyb3NzLXJlZ2lvbiBjb25maWd1cmF0aW9uIGlzIHJlcXVpcmVkIHdoZW4gdXNpbmcgU1RBTkRBUkQgdGllciBmb3IgY29udGVudCBmaWx0ZXJzLiAnICtcbiAgICAgICAgJ1BsZWFzZSBwcm92aWRlIGEgY3Jvc3NSZWdpb25Db25maWcgcHJvcGVydHkgd2l0aCBhIHZhbGlkIGd1YXJkcmFpbFByb2ZpbGVBcm4uJyxcbiAgICAgICAgdGhpcyxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgaWYgU1RBTkRBUkQgdGllciBpcyB1c2VkIGZvciB0b3BpYyBmaWx0ZXJzXG4gICAgaWYgKHRvcGljc1RpZXJDb25maWcgPT09IGZpbHRlcnMuVGllckNvbmZpZy5TVEFOREFSRCAmJiAhaGFzQ3Jvc3NSZWdpb25Db25maWcpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoXG4gICAgICAgICdDcm9zcy1yZWdpb24gY29uZmlndXJhdGlvbiBpcyByZXF1aXJlZCB3aGVuIHVzaW5nIFNUQU5EQVJEIHRpZXIgZm9yIHRvcGljIGZpbHRlcnMuICcgK1xuICAgICAgICAnUGxlYXNlIHByb3ZpZGUgYSBjcm9zc1JlZ2lvbkNvbmZpZyBwcm9wZXJ0eSB3aXRoIGEgdmFsaWQgZ3VhcmRyYWlsUHJvZmlsZUFybi4nLFxuICAgICAgICB0aGlzLFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGNvbnRlbnQgZmlsdGVycyBhcnJheSBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIGNvbnRlbnRGaWx0ZXJzIFRoZSBjb250ZW50IGZpbHRlcnMgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlQ29udGVudEZpbHRlcnMoY29udGVudEZpbHRlcnM/OiBmaWx0ZXJzLkNvbnRlbnRGaWx0ZXJbXSk6IHZvaWQge1xuICAgIGlmICghY29udGVudEZpbHRlcnMpIHJldHVybjtcblxuICAgIGNvbnRlbnRGaWx0ZXJzLmZvckVhY2goKGZpbHRlciwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IHByZWZpeCA9IGBJbnZhbGlkIENvbnRlbnRGaWx0ZXIgYXQgaW5kZXggJHtpbmRleH1gO1xuXG4gICAgICAvLyBWYWxpZGF0ZSB0aGF0IHRoZSBmaWx0ZXIgaGFzIHJlcXVpcmVkIHByb3BlcnRpZXNcbiAgICAgIGlmICghZmlsdGVyLnR5cGUpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiB0eXBlIGlzIHJlcXVpcmVkYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIGlucHV0IHN0cmVuZ3RoXG4gICAgICBpZiAoZmlsdGVyLmlucHV0U3RyZW5ndGggIT09IHVuZGVmaW5lZCAmJiAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5pbnB1dFN0cmVuZ3RoKSkge1xuICAgICAgICBpZiAoIU9iamVjdC52YWx1ZXMoZmlsdGVycy5Db250ZW50RmlsdGVyU3RyZW5ndGgpLmluY2x1ZGVzKGZpbHRlci5pbnB1dFN0cmVuZ3RoKSkge1xuICAgICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogaW5wdXRTdHJlbmd0aCBtdXN0IGJlIGEgdmFsaWQgQ29udGVudEZpbHRlclN0cmVuZ3RoIHZhbHVlYCwgdGhpcyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgb3V0cHV0IHN0cmVuZ3RoXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dFN0cmVuZ3RoICE9PSB1bmRlZmluZWQgJiYgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIub3V0cHV0U3RyZW5ndGgpKSB7XG4gICAgICAgIGlmICghT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkNvbnRlbnRGaWx0ZXJTdHJlbmd0aCkuaW5jbHVkZXMoZmlsdGVyLm91dHB1dFN0cmVuZ3RoKSkge1xuICAgICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogb3V0cHV0U3RyZW5ndGggbXVzdCBiZSBhIHZhbGlkIENvbnRlbnRGaWx0ZXJTdHJlbmd0aCB2YWx1ZWAsIHRoaXMpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIGlucHV0IG1vZGFsaXRpZXNcbiAgICAgIGlmIChmaWx0ZXIuaW5wdXRNb2RhbGl0aWVzKSB7XG4gICAgICAgIGZpbHRlci5pbnB1dE1vZGFsaXRpZXMuZm9yRWFjaCgobW9kYWxpdHksIG1vZGFsaXR5SW5kZXgpID0+IHtcbiAgICAgICAgICBpZiAoIU9iamVjdC52YWx1ZXMoZmlsdGVycy5Nb2RhbGl0eVR5cGUpLmluY2x1ZGVzKG1vZGFsaXR5KSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiBpbnB1dE1vZGFsaXRpZXNbJHttb2RhbGl0eUluZGV4fV0gbXVzdCBiZSBhIHZhbGlkIE1vZGFsaXR5VHlwZSB2YWx1ZWAsIHRoaXMpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIG91dHB1dCBtb2RhbGl0aWVzXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dE1vZGFsaXRpZXMpIHtcbiAgICAgICAgZmlsdGVyLm91dHB1dE1vZGFsaXRpZXMuZm9yRWFjaCgobW9kYWxpdHksIG1vZGFsaXR5SW5kZXgpID0+IHtcbiAgICAgICAgICBpZiAoIU9iamVjdC52YWx1ZXMoZmlsdGVycy5Nb2RhbGl0eVR5cGUpLmluY2x1ZGVzKG1vZGFsaXR5KSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiBvdXRwdXRNb2RhbGl0aWVzWyR7bW9kYWxpdHlJbmRleH1dIG11c3QgYmUgYSB2YWxpZCBNb2RhbGl0eVR5cGUgdmFsdWVgLCB0aGlzKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBpbnB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5pbnB1dEFjdGlvbikgJiZcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmlucHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IGlucHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgb3V0cHV0QWN0aW9uOiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlIChpZiBwcm92aWRlZClcbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5vdXRwdXRBY3Rpb24pICYmXG4gICAgICAgICAgIU9iamVjdC52YWx1ZXMoZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24pLmluY2x1ZGVzKGZpbHRlci5vdXRwdXRBY3Rpb24pKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIuaW5wdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiBpbnB1dEVuYWJsZWQgbXVzdCBiZSBhIGJvb2xlYW4gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgb3V0cHV0RW5hYmxlZDogbXVzdCBiZSBhIGJvb2xlYW4gKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRFbmFibGVkICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5vdXRwdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIub3V0cHV0RW5hYmxlZCAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogb3V0cHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBBcHBseSBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcyBpZiBub3QgcHJvdmlkZWRcbiAgICAgIGlmIChmaWx0ZXIuaW5wdXRBY3Rpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuaW5wdXRBY3Rpb24gPSBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbi5CTE9DSztcbiAgICAgIH1cbiAgICAgIGlmIChmaWx0ZXIuaW5wdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLmlucHV0RW5hYmxlZCA9IHRydWU7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5vdXRwdXRBY3Rpb24gPSBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbi5CTE9DSztcbiAgICAgIH1cbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0RW5hYmxlZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5vdXRwdXRFbmFibGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgUElJIGZpbHRlcnMgYXJyYXkgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBwaWlGaWx0ZXJzIFRoZSBQSUkgZmlsdGVycyB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVQaWlGaWx0ZXJzKHBpaUZpbHRlcnM/OiBmaWx0ZXJzLlBJSUZpbHRlcltdKTogdm9pZCB7XG4gICAgaWYgKCFwaWlGaWx0ZXJzKSByZXR1cm47XG5cbiAgICBwaWlGaWx0ZXJzLmZvckVhY2goKGZpbHRlciwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IHByZWZpeCA9IGBJbnZhbGlkIFBJSUZpbHRlciBhdCBpbmRleCAke2luZGV4fWA7XG5cbiAgICAgIC8vIFZhbGlkYXRlIHRoYXQgdGhlIGZpbHRlciBoYXMgcmVxdWlyZWQgcHJvcGVydGllc1xuICAgICAgaWYgKCFmaWx0ZXIudHlwZSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IHR5cGUgaXMgcmVxdWlyZWRgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgaWYgKCFmaWx0ZXIuYWN0aW9uKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogYWN0aW9uIGlzIHJlcXVpcmVkYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIGFjdGlvbiB2YWx1ZXNcbiAgICAgIGlmICghVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5hY3Rpb24pICYmICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIuYWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IGFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIGlmIChmaWx0ZXIuaW5wdXRBY3Rpb24gJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5pbnB1dEFjdGlvbikgJiZcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmlucHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IGlucHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRBY3Rpb24gJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5vdXRwdXRBY3Rpb24pICYmXG4gICAgICAgICAgIU9iamVjdC52YWx1ZXMoZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24pLmluY2x1ZGVzKGZpbHRlci5vdXRwdXRBY3Rpb24pKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIuaW5wdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiBpbnB1dEVuYWJsZWQgbXVzdCBiZSBhIGJvb2xlYW4gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgb3V0cHV0RW5hYmxlZDogbXVzdCBiZSBhIGJvb2xlYW4gKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRFbmFibGVkICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5vdXRwdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIub3V0cHV0RW5hYmxlZCAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogb3V0cHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBBcHBseSBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcyBpZiBub3QgcHJvdmlkZWRcbiAgICAgIGlmIChmaWx0ZXIuaW5wdXRBY3Rpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuaW5wdXRBY3Rpb24gPSBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbi5CTE9DSztcbiAgICAgIH1cbiAgICAgIGlmIChmaWx0ZXIuaW5wdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLmlucHV0RW5hYmxlZCA9IHRydWU7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5vdXRwdXRBY3Rpb24gPSBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbi5CTE9DSztcbiAgICAgIH1cbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0RW5hYmxlZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5vdXRwdXRFbmFibGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgcmVnZXggZmlsdGVycyBhcnJheS5cbiAgICogQHBhcmFtIHJlZ2V4RmlsdGVycyBUaGUgcmVnZXggZmlsdGVycyB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVSZWdleEZpbHRlcnMocmVnZXhGaWx0ZXJzPzogZmlsdGVycy5SZWdleEZpbHRlcltdKTogdm9pZCB7XG4gICAgaWYgKCFyZWdleEZpbHRlcnMpIHJldHVybjtcblxuICAgIHJlZ2V4RmlsdGVycy5mb3JFYWNoKChmaWx0ZXIsIGluZGV4KSA9PiB7XG4gICAgICB0aGlzLnZhbGlkYXRlUmVnZXhGaWx0ZXIoZmlsdGVyLCBpbmRleCk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGRlbmllZCB0b3BpY3MgYXJyYXkgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBkZW5pZWRUb3BpY3MgVGhlIGRlbmllZCB0b3BpY3MgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlRGVuaWVkVG9waWNzKGRlbmllZFRvcGljcz86IGZpbHRlcnMuVG9waWNbXSk6IHZvaWQge1xuICAgIGlmICghZGVuaWVkVG9waWNzKSByZXR1cm47XG5cbiAgICBkZW5pZWRUb3BpY3MuZm9yRWFjaCgodG9waWMsIGluZGV4KSA9PiB7XG4gICAgICBjb25zdCBwcmVmaXggPSBgSW52YWxpZCBUb3BpYyBhdCBpbmRleCAke2luZGV4fWA7XG5cbiAgICAgIC8vIFZhbGlkYXRlIHRoYXQgdGhlIHRvcGljIGhhcyByZXF1aXJlZCBwcm9wZXJ0aWVzXG4gICAgICBpZiAoIXRvcGljLm5hbWUpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiBuYW1lIGlzIHJlcXVpcmVkYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIGlmICghdG9waWMuZGVmaW5pdGlvbikge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IGRlZmluaXRpb24gaXMgcmVxdWlyZWRgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgbmFtZSBsZW5ndGhcbiAgICAgIGlmICghVG9rZW4uaXNVbnJlc29sdmVkKHRvcGljLm5hbWUpICYmIHRvcGljLm5hbWUubGVuZ3RoID4gMTAwKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogbmFtZSBtdXN0IGJlIDEwMCBjaGFyYWN0ZXJzIG9yIGxlc3NgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgZGVmaW5pdGlvbiBsZW5ndGhcbiAgICAgIGlmICghVG9rZW4uaXNVbnJlc29sdmVkKHRvcGljLmRlZmluaXRpb24pICYmIHRvcGljLmRlZmluaXRpb24ubGVuZ3RoID4gMTAwMCkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IGRlZmluaXRpb24gbXVzdCBiZSAxMDAwIGNoYXJhY3RlcnMgb3IgbGVzc2AsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBleGFtcGxlcyBpZiBwcm92aWRlZFxuICAgICAgaWYgKHRvcGljLmV4YW1wbGVzKSB7XG4gICAgICAgIGlmICh0b3BpYy5leGFtcGxlcy5sZW5ndGggPiAxMDApIHtcbiAgICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IGV4YW1wbGVzIGFycmF5IGNhbm5vdCBjb250YWluIG1vcmUgdGhhbiAxMDAgZXhhbXBsZXNgLCB0aGlzKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRvcGljLmV4YW1wbGVzLmZvckVhY2goKGV4YW1wbGUsIGV4YW1wbGVJbmRleCkgPT4ge1xuICAgICAgICAgIGlmICghVG9rZW4uaXNVbnJlc29sdmVkKGV4YW1wbGUpICYmIGV4YW1wbGUubGVuZ3RoID4gMTAwKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IGV4YW1wbGVzWyR7ZXhhbXBsZUluZGV4fV0gbXVzdCBiZSAxMDAgY2hhcmFjdGVycyBvciBsZXNzYCwgdGhpcyk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRBY3Rpb246IG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWUgKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKHRvcGljLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKHRvcGljLmlucHV0QWN0aW9uKSAmJlxuICAgICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyh0b3BpYy5pbnB1dEFjdGlvbikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiBpbnB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIG91dHB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAodG9waWMub3V0cHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKHRvcGljLm91dHB1dEFjdGlvbikgJiZcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXModG9waWMub3V0cHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IG91dHB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIGlucHV0RW5hYmxlZDogbXVzdCBiZSBhIGJvb2xlYW4gKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKHRvcGljLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZCh0b3BpYy5pbnB1dEVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIHRvcGljLmlucHV0RW5hYmxlZCAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogaW5wdXRFbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIG91dHB1dEVuYWJsZWQ6IG11c3QgYmUgYSBib29sZWFuIChpZiBwcm92aWRlZClcbiAgICAgIGlmICh0b3BpYy5vdXRwdXRFbmFibGVkICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKHRvcGljLm91dHB1dEVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIHRvcGljLm91dHB1dEVuYWJsZWQgIT09ICdib29sZWFuJykge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IG91dHB1dEVuYWJsZWQgbXVzdCBiZSBhIGJvb2xlYW4gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gQXBwbHkgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMgaWYgbm90IHByb3ZpZGVkXG4gICAgICBpZiAodG9waWMuaW5wdXRBY3Rpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAodG9waWMgYXMgYW55KS5pbnB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKHRvcGljLmlucHV0RW5hYmxlZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICh0b3BpYyBhcyBhbnkpLmlucHV0RW5hYmxlZCA9IHRydWU7XG4gICAgICB9XG4gICAgICBpZiAodG9waWMub3V0cHV0QWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKHRvcGljIGFzIGFueSkub3V0cHV0QWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgICB9XG4gICAgICBpZiAodG9waWMub3V0cHV0RW5hYmxlZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICh0b3BpYyBhcyBhbnkpLm91dHB1dEVuYWJsZWQgPSB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBjb250ZXh0dWFsIGdyb3VuZGluZyBmaWx0ZXJzIGFycmF5IGFuZCBhcHBsaWVzIGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzLlxuICAgKiBAcGFyYW0gY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMgVGhlIGNvbnRleHR1YWwgZ3JvdW5kaW5nIGZpbHRlcnMgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMoY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnM/OiBmaWx0ZXJzLkNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJbXSk6IHZvaWQge1xuICAgIGlmICghY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMpIHJldHVybjtcblxuICAgIGNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJzLmZvckVhY2goKGZpbHRlciwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IHByZWZpeCA9IGBJbnZhbGlkIENvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXIgYXQgaW5kZXggJHtpbmRleH1gO1xuXG4gICAgICAvLyBWYWxpZGF0ZSB0aGF0IHRoZSBmaWx0ZXIgaGFzIHJlcXVpcmVkIHByb3BlcnRpZXNcbiAgICAgIGlmICghZmlsdGVyLnR5cGUpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiB0eXBlIGlzIHJlcXVpcmVkYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIGlmIChmaWx0ZXIudGhyZXNob2xkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiB0aHJlc2hvbGQgaXMgcmVxdWlyZWRgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgdHlwZVxuICAgICAgaWYgKCFPYmplY3QudmFsdWVzKGZpbHRlcnMuQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlclR5cGUpLmluY2x1ZGVzKGZpbHRlci50eXBlKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IHR5cGUgbXVzdCBiZSBhIHZhbGlkIENvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJUeXBlIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIHRocmVzaG9sZCByYW5nZVxuICAgICAgaWYgKCFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLnRocmVzaG9sZCkpIHtcbiAgICAgICAgaWYgKGZpbHRlci50aHJlc2hvbGQgPCAwIHx8IGZpbHRlci50aHJlc2hvbGQgPiAwLjk5KSB7XG4gICAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiB0aHJlc2hvbGQgbXVzdCBiZSBiZXR3ZWVuIDAgYW5kIDAuOTlgLCB0aGlzKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBhY3Rpb246IG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWUgKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKGZpbHRlci5hY3Rpb24gIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLmFjdGlvbikgJiZcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmFjdGlvbikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiBhY3Rpb24gbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBlbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLmVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIGZpbHRlci5lbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiBlbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFwcGx5IGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzIGlmIG5vdCBwcm92aWRlZFxuICAgICAgaWYgKGZpbHRlci5hY3Rpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuYWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLmVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuZW5hYmxlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIHdvcmQgZmlsdGVycyBhcnJheSBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIHdvcmRGaWx0ZXJzIFRoZSB3b3JkIGZpbHRlcnMgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlV29yZEZpbHRlcnMod29yZEZpbHRlcnM/OiBmaWx0ZXJzLldvcmRGaWx0ZXJbXSk6IHZvaWQge1xuICAgIGlmICghd29yZEZpbHRlcnMpIHJldHVybjtcblxuICAgIHdvcmRGaWx0ZXJzLmZvckVhY2goKGZpbHRlciwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IHByZWZpeCA9IGBJbnZhbGlkIFdvcmRGaWx0ZXIgYXQgaW5kZXggJHtpbmRleH1gO1xuXG4gICAgICAvLyBWYWxpZGF0ZSB0aGF0IHRoZSBmaWx0ZXIgaGFzIHJlcXVpcmVkIHByb3BlcnRpZXNcbiAgICAgIGlmICghZmlsdGVyLnRleHQpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiB0ZXh0IGlzIHJlcXVpcmVkYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIHRleHQgbGVuZ3RoXG4gICAgICBpZiAoIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIudGV4dCkgJiYgZmlsdGVyLnRleHQubGVuZ3RoID4gMTAwKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogdGV4dCBtdXN0IGJlIDEwMCBjaGFyYWN0ZXJzIG9yIGxlc3NgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRBY3Rpb246IG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWUgKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKGZpbHRlci5pbnB1dEFjdGlvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRBY3Rpb24pICYmXG4gICAgICAgICAgIU9iamVjdC52YWx1ZXMoZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24pLmluY2x1ZGVzKGZpbHRlci5pbnB1dEFjdGlvbikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiBpbnB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIG91dHB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEFjdGlvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIub3V0cHV0QWN0aW9uKSAmJlxuICAgICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIub3V0cHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IG91dHB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIGlucHV0RW5hYmxlZDogbXVzdCBiZSBhIGJvb2xlYW4gKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKGZpbHRlci5pbnB1dEVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLmlucHV0RW5hYmxlZCkgJiZcbiAgICAgICAgICB0eXBlb2YgZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogaW5wdXRFbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIG91dHB1dEVuYWJsZWQ6IG11c3QgYmUgYSBib29sZWFuIChpZiBwcm92aWRlZClcbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIub3V0cHV0RW5hYmxlZCkgJiZcbiAgICAgICAgICB0eXBlb2YgZmlsdGVyLm91dHB1dEVuYWJsZWQgIT09ICdib29sZWFuJykge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IG91dHB1dEVuYWJsZWQgbXVzdCBiZSBhIGJvb2xlYW4gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gQXBwbHkgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMgaWYgbm90IHByb3ZpZGVkXG4gICAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLmlucHV0QWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5pbnB1dEVuYWJsZWQgPSB0cnVlO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRBY3Rpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkub3V0cHV0QWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkub3V0cHV0RW5hYmxlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIG1hbmFnZWQgd29yZCBsaXN0IGZpbHRlcnMgYXJyYXkgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBtYW5hZ2VkV29yZExpc3RGaWx0ZXJzIFRoZSBtYW5hZ2VkIHdvcmQgbGlzdCBmaWx0ZXJzIHRvIHZhbGlkYXRlLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZU1hbmFnZWRXb3JkTGlzdEZpbHRlcnMobWFuYWdlZFdvcmRMaXN0RmlsdGVycz86IGZpbHRlcnMuTWFuYWdlZFdvcmRGaWx0ZXJbXSk6IHZvaWQge1xuICAgIGlmICghbWFuYWdlZFdvcmRMaXN0RmlsdGVycykgcmV0dXJuO1xuXG4gICAgbWFuYWdlZFdvcmRMaXN0RmlsdGVycy5mb3JFYWNoKChmaWx0ZXIsIGluZGV4KSA9PiB7XG4gICAgICBjb25zdCBwcmVmaXggPSBgSW52YWxpZCBNYW5hZ2VkV29yZEZpbHRlciBhdCBpbmRleCAke2luZGV4fWA7XG5cbiAgICAgIC8vIFZhbGlkYXRlIHR5cGU6IG11c3QgYmUgYSB2YWxpZCBNYW5hZ2VkV29yZEZpbHRlclR5cGUgdmFsdWUgKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKGZpbHRlci50eXBlICE9PSB1bmRlZmluZWQgJiYgIU9iamVjdC52YWx1ZXMoZmlsdGVycy5NYW5hZ2VkV29yZEZpbHRlclR5cGUpLmluY2x1ZGVzKGZpbHRlci50eXBlKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IHR5cGUgbXVzdCBiZSBhIHZhbGlkIE1hbmFnZWRXb3JkRmlsdGVyVHlwZSB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBpbnB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5pbnB1dEFjdGlvbikgJiZcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmlucHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGAke3ByZWZpeH06IGlucHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgb3V0cHV0QWN0aW9uOiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlIChpZiBwcm92aWRlZClcbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5vdXRwdXRBY3Rpb24pICYmXG4gICAgICAgICAgIU9iamVjdC52YWx1ZXMoZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24pLmluY2x1ZGVzKGZpbHRlci5vdXRwdXRBY3Rpb24pKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIuaW5wdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihgJHtwcmVmaXh9OiBpbnB1dEVuYWJsZWQgbXVzdCBiZSBhIGJvb2xlYW4gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgb3V0cHV0RW5hYmxlZDogbXVzdCBiZSBhIGJvb2xlYW4gKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRFbmFibGVkICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5vdXRwdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIub3V0cHV0RW5hYmxlZCAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoYCR7cHJlZml4fTogb3V0cHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBBcHBseSBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcyBpZiBub3QgcHJvdmlkZWRcbiAgICAgIGlmIChmaWx0ZXIudHlwZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS50eXBlID0gZmlsdGVycy5NYW5hZ2VkV29yZEZpbHRlclR5cGUuUFJPRkFOSVRZO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5pbnB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5pbnB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5pbnB1dEVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuaW5wdXRFbmFibGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEVuYWJsZWQgPSB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBhIHNpbmdsZSBjb250ZW50IGZpbHRlciBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIGZpbHRlciBUaGUgY29udGVudCBmaWx0ZXIgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlU2luZ2xlQ29udGVudEZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuQ29udGVudEZpbHRlcik6IHZvaWQge1xuICAgIC8vIFVzZSB0aGUgZXhpc3RpbmcgdmFsaWRhdGlvbiBsb2dpYyBidXQgY2F0Y2ggYW5kIHJlLXRocm93IHdpdGggYSBjbGVhcmVyIGVycm9yIG1lc3NhZ2VcbiAgICB0cnkge1xuICAgICAgdGhpcy52YWxpZGF0ZUNvbnRlbnRGaWx0ZXJzKFtmaWx0ZXJdKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgVmFsaWRhdGlvbkVycm9yKSB7XG4gICAgICAgIC8vIFJlcGxhY2UgXCJhdCBpbmRleCAwXCIgd2l0aCBhIGNsZWFyZXIgbWVzc2FnZSBmb3Igc2luZ2xlIGZpbHRlciB2YWxpZGF0aW9uXG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlLnJlcGxhY2UoJyBhdCBpbmRleCAwJywgJycpO1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKG1lc3NhZ2UsIHRoaXMpO1xuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBhIHNpbmdsZSBQSUkgZmlsdGVyIGFuZCBhcHBsaWVzIGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSBQSUkgZmlsdGVyIHRvIHZhbGlkYXRlLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVNpbmdsZVBpaUZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuUElJRmlsdGVyKTogdm9pZCB7XG4gICAgLy8gVXNlIHRoZSBleGlzdGluZyB2YWxpZGF0aW9uIGxvZ2ljIGJ1dCBjYXRjaCBhbmQgcmUtdGhyb3cgd2l0aCBhIGNsZWFyZXIgZXJyb3IgbWVzc2FnZVxuICAgIHRyeSB7XG4gICAgICB0aGlzLnZhbGlkYXRlUGlpRmlsdGVycyhbZmlsdGVyXSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIFZhbGlkYXRpb25FcnJvcikge1xuICAgICAgICAvLyBSZXBsYWNlIFwiYXQgaW5kZXggMFwiIHdpdGggYSBjbGVhcmVyIG1lc3NhZ2UgZm9yIHNpbmdsZSBmaWx0ZXIgdmFsaWRhdGlvblxuICAgICAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IubWVzc2FnZS5yZXBsYWNlKCcgYXQgaW5kZXggMCcsICcnKTtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihtZXNzYWdlLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgYSBzaW5nbGUgcmVnZXggZmlsdGVyIGFuZCBhcHBsaWVzIGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSByZWdleCBmaWx0ZXIgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlU2luZ2xlUmVnZXhGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLlJlZ2V4RmlsdGVyKTogdm9pZCB7XG4gICAgLy8gVXNlIHRoZSBleGlzdGluZyB2YWxpZGF0aW9uIGxvZ2ljIGJ1dCBjYXRjaCBhbmQgcmUtdGhyb3cgd2l0aCBhIGNsZWFyZXIgZXJyb3IgbWVzc2FnZVxuICAgIHRyeSB7XG4gICAgICB0aGlzLnZhbGlkYXRlUmVnZXhGaWx0ZXJzKFtmaWx0ZXJdKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgVmFsaWRhdGlvbkVycm9yKSB7XG4gICAgICAgIC8vIFJlcGxhY2UgXCJhdCBpbmRleCAwXCIgd2l0aCBhIGNsZWFyZXIgbWVzc2FnZSBmb3Igc2luZ2xlIGZpbHRlciB2YWxpZGF0aW9uXG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlLnJlcGxhY2UoJyBhdCBpbmRleCAwJywgJycpO1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKG1lc3NhZ2UsIHRoaXMpO1xuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBhIHNpbmdsZSBkZW5pZWQgdG9waWMgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIGRlbmllZCB0b3BpYyB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVTaW5nbGVEZW5pZWRUb3BpYyhmaWx0ZXI6IGZpbHRlcnMuVG9waWMpOiB2b2lkIHtcbiAgICAvLyBVc2UgdGhlIGV4aXN0aW5nIHZhbGlkYXRpb24gbG9naWMgYnV0IGNhdGNoIGFuZCByZS10aHJvdyB3aXRoIGEgY2xlYXJlciBlcnJvciBtZXNzYWdlXG4gICAgdHJ5IHtcbiAgICAgIHRoaXMudmFsaWRhdGVEZW5pZWRUb3BpY3MoW2ZpbHRlcl0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBWYWxpZGF0aW9uRXJyb3IpIHtcbiAgICAgICAgLy8gUmVwbGFjZSBcImF0IGluZGV4IDBcIiB3aXRoIGEgY2xlYXJlciBtZXNzYWdlIGZvciBzaW5nbGUgZmlsdGVyIHZhbGlkYXRpb25cbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UucmVwbGFjZSgnIGF0IGluZGV4IDAnLCAnJyk7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobWVzc2FnZSwgdGhpcyk7XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGEgc2luZ2xlIGNvbnRleHR1YWwgZ3JvdW5kaW5nIGZpbHRlciBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIGZpbHRlciBUaGUgY29udGV4dHVhbCBncm91bmRpbmcgZmlsdGVyIHRvIHZhbGlkYXRlLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVNpbmdsZUNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLkNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXIpOiB2b2lkIHtcbiAgICAvLyBVc2UgdGhlIGV4aXN0aW5nIHZhbGlkYXRpb24gbG9naWMgYnV0IGNhdGNoIGFuZCByZS10aHJvdyB3aXRoIGEgY2xlYXJlciBlcnJvciBtZXNzYWdlXG4gICAgdHJ5IHtcbiAgICAgIHRoaXMudmFsaWRhdGVDb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycyhbZmlsdGVyXSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIFZhbGlkYXRpb25FcnJvcikge1xuICAgICAgICAvLyBSZXBsYWNlIFwiYXQgaW5kZXggMFwiIHdpdGggYSBjbGVhcmVyIG1lc3NhZ2UgZm9yIHNpbmdsZSBmaWx0ZXIgdmFsaWRhdGlvblxuICAgICAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IubWVzc2FnZS5yZXBsYWNlKCcgYXQgaW5kZXggMCcsICcnKTtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihtZXNzYWdlLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgYSBzaW5nbGUgd29yZCBmaWx0ZXIgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIHdvcmQgZmlsdGVyIHRvIHZhbGlkYXRlLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVNpbmdsZVdvcmRGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLldvcmRGaWx0ZXIpOiB2b2lkIHtcbiAgICAvLyBVc2UgdGhlIGV4aXN0aW5nIHZhbGlkYXRpb24gbG9naWMgYnV0IGNhdGNoIGFuZCByZS10aHJvdyB3aXRoIGEgY2xlYXJlciBlcnJvciBtZXNzYWdlXG4gICAgdHJ5IHtcbiAgICAgIHRoaXMudmFsaWRhdGVXb3JkRmlsdGVycyhbZmlsdGVyXSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIFZhbGlkYXRpb25FcnJvcikge1xuICAgICAgICAvLyBSZXBsYWNlIFwiYXQgaW5kZXggMFwiIHdpdGggYSBjbGVhcmVyIG1lc3NhZ2UgZm9yIHNpbmdsZSBmaWx0ZXIgdmFsaWRhdGlvblxuICAgICAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IubWVzc2FnZS5yZXBsYWNlKCcgYXQgaW5kZXggMCcsICcnKTtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihtZXNzYWdlLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgYSBzaW5nbGUgbWFuYWdlZCB3b3JkIGxpc3QgZmlsdGVyIGFuZCBhcHBsaWVzIGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSBtYW5hZ2VkIHdvcmQgbGlzdCBmaWx0ZXIgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlU2luZ2xlTWFuYWdlZFdvcmRMaXN0RmlsdGVyKGZpbHRlcjogZmlsdGVycy5NYW5hZ2VkV29yZEZpbHRlcik6IHZvaWQge1xuICAgIC8vIFVzZSB0aGUgZXhpc3RpbmcgdmFsaWRhdGlvbiBsb2dpYyBidXQgY2F0Y2ggYW5kIHJlLXRocm93IHdpdGggYSBjbGVhcmVyIGVycm9yIG1lc3NhZ2VcbiAgICB0cnkge1xuICAgICAgdGhpcy52YWxpZGF0ZU1hbmFnZWRXb3JkTGlzdEZpbHRlcnMoW2ZpbHRlcl0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBWYWxpZGF0aW9uRXJyb3IpIHtcbiAgICAgICAgLy8gUmVwbGFjZSBcImF0IGluZGV4IDBcIiB3aXRoIGEgY2xlYXJlciBtZXNzYWdlIGZvciBzaW5nbGUgZmlsdGVyIHZhbGlkYXRpb25cbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UucmVwbGFjZSgnIGF0IGluZGV4IDAnLCAnJyk7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobWVzc2FnZSwgdGhpcyk7XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG4gIH1cbn1cbiJdfQ==