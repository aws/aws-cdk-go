"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatMessage = exports.ChatMessageRole = void 0;
exports.createChatPromptVariant = createChatPromptVariant;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const prompt_template_configuration_1 = require("./prompt-template-configuration");
const prompt_variant_1 = require("./prompt-variant");
/**
 * The role of a message in a chat conversation.
 */
var ChatMessageRole;
(function (ChatMessageRole) {
    /**
     * This role represents the human user in the conversation. Inputs from the
     * user guide the conversation and prompt responses from the assistant.
     */
    ChatMessageRole["USER"] = "user";
    /**
     * This is the role of the model itself, responding to user inputs based on
     * the context set by the system.
     */
    ChatMessageRole["ASSISTANT"] = "assistant";
})(ChatMessageRole || (exports.ChatMessageRole = ChatMessageRole = {}));
/**
 * Represents a message in a chat conversation.
 */
class ChatMessage {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ChatMessage", version: "2.242.0-alpha.0" };
    /**
     * Creates a user message.
     *
     * @param text - The text content of the user message
     * @returns A ChatMessage instance representing a user message
     */
    static user(text) {
        return new ChatMessage(ChatMessageRole.USER, text);
    }
    /**
     * Creates an assistant message.
     *
     * @param text - The text content of the assistant message
     * @returns A ChatMessage instance representing an assistant message
     */
    static assistant(text) {
        return new ChatMessage(ChatMessageRole.ASSISTANT, text);
    }
    /**
     * The role of the message sender.
     */
    role;
    /**
     * The text content of the message.
     */
    text;
    constructor(role, text) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ChatMessageRole(role);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, ChatMessage);
            }
            throw error;
        }
        this.role = role;
        this.text = text;
    }
    /**
     * Renders the message as a CloudFormation property.
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            role: this.role,
            content: [
                {
                    text: this.text,
                },
            ],
        };
    }
}
exports.ChatMessage = ChatMessage;
/**
 * Creates a chat template variant. Use this template type when
 * the model supports the Converse API or the Anthropic Claude Messages API.
 * This allows you to include a System prompt and previous User messages
 * and Assistant messages for context.
 *
 * @param props - Properties for the chat prompt variant
 * @returns A PromptVariant configured for chat interactions
 */
function createChatPromptVariant(props) {
    // Validate that messages array is not empty
    if (!props.messages || props.messages.length === 0) {
        throw new errors_1.UnscopedValidationError('At least one message must be provided');
    }
    // Validate that the first message is a user message
    if (props.messages[0].role !== ChatMessageRole.USER) {
        throw new errors_1.UnscopedValidationError('The first message must be a User message');
    }
    // Validate that at least one user message exists
    const hasUserMessage = props.messages.some(message => message.role === ChatMessageRole.USER);
    if (!hasUserMessage) {
        throw new errors_1.UnscopedValidationError('At least one User message must be provided');
    }
    // Validate alternating pattern if more than one message
    if (props.messages.length > 1) {
        for (let i = 1; i < props.messages.length; i++) {
            const currentRole = props.messages[i].role;
            const previousRole = props.messages[i - 1].role;
            if (currentRole === previousRole) {
                throw new errors_1.UnscopedValidationError(`Messages must alternate between User and Assistant roles. Found consecutive ${currentRole} messages at positions ${i} and ${i + 1}`);
            }
        }
    }
    return {
        name: props.variantName,
        templateType: prompt_variant_1.PromptTemplateType.CHAT,
        modelId: props.model.invokableArn,
        inferenceConfiguration: props.inferenceConfiguration,
        templateConfiguration: prompt_template_configuration_1.PromptTemplateConfiguration.chat({
            inputVariables: props.promptVariables,
            messages: props.messages,
            system: props.system,
            toolConfiguration: props.toolConfiguration,
        }),
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hhdC1wcm9tcHQtdmFyaWFudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNoYXQtcHJvbXB0LXZhcmlhbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBMEhBLDBEQTJDQzs7O0FBcEtELHdEQUFzRTtBQUV0RSxtRkFBOEU7QUFFOUUscURBQXNEO0FBb0N0RDs7R0FFRztBQUNILElBQVksZUFZWDtBQVpELFdBQVksZUFBZTtJQUN6Qjs7O09BR0c7SUFDSCxnQ0FBYSxDQUFBO0lBRWI7OztPQUdHO0lBQ0gsMENBQXVCLENBQUE7QUFDekIsQ0FBQyxFQVpXLGVBQWUsK0JBQWYsZUFBZSxRQVkxQjtBQUVEOztHQUVHO0FBQ0gsTUFBYSxXQUFXOztJQUN0Qjs7Ozs7T0FLRztJQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBWTtRQUM3QixPQUFPLElBQUksV0FBVyxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDcEQ7SUFFRDs7Ozs7T0FLRztJQUNJLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBWTtRQUNsQyxPQUFPLElBQUksV0FBVyxDQUFDLGVBQWUsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDekQ7SUFFRDs7T0FFRztJQUNhLElBQUksQ0FBa0I7SUFFdEM7O09BRUc7SUFDYSxJQUFJLENBQVM7SUFFN0IsWUFBWSxJQUFxQixFQUFFLElBQVk7Ozs7OzsrQ0EvQnBDLFdBQVc7Ozs7UUFnQ3BCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0tBQ2xCO0lBRUQ7OztPQUdHO0lBQ0ksT0FBTztRQUNaLE9BQU87WUFDTCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDZixPQUFPLEVBQUU7Z0JBQ1A7b0JBQ0UsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2lCQUNoQjthQUNGO1NBQ0YsQ0FBQztLQUNIOztBQWpESCxrQ0FrREM7QUFFRDs7Ozs7Ozs7R0FRRztBQUNILFNBQWdCLHVCQUF1QixDQUFDLEtBQTZCO0lBQ25FLDRDQUE0QztJQUM1QyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztRQUNuRCxNQUFNLElBQUksZ0NBQXVCLENBQUMsdUNBQXVDLENBQUMsQ0FBQztJQUM3RSxDQUFDO0lBRUQsb0RBQW9EO0lBQ3BELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssZUFBZSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3BELE1BQU0sSUFBSSxnQ0FBdUIsQ0FBQywwQ0FBMEMsQ0FBQyxDQUFDO0lBQ2hGLENBQUM7SUFFRCxpREFBaUQ7SUFDakQsTUFBTSxjQUFjLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxLQUFLLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM3RixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDcEIsTUFBTSxJQUFJLGdDQUF1QixDQUFDLDRDQUE0QyxDQUFDLENBQUM7SUFDbEYsQ0FBQztJQUVELHdEQUF3RDtJQUN4RCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQzlCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQy9DLE1BQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzNDLE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUVoRCxJQUFJLFdBQVcsS0FBSyxZQUFZLEVBQUUsQ0FBQztnQkFDakMsTUFBTSxJQUFJLGdDQUF1QixDQUMvQiwrRUFBK0UsV0FBVywwQkFBMEIsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FDckksQ0FBQztZQUNKLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVELE9BQU87UUFDTCxJQUFJLEVBQUUsS0FBSyxDQUFDLFdBQVc7UUFDdkIsWUFBWSxFQUFFLG1DQUFrQixDQUFDLElBQUk7UUFDckMsT0FBTyxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWTtRQUNqQyxzQkFBc0IsRUFBRSxLQUFLLENBQUMsc0JBQXNCO1FBQ3BELHFCQUFxQixFQUFFLDJEQUEyQixDQUFDLElBQUksQ0FBQztZQUN0RCxjQUFjLEVBQUUsS0FBSyxDQUFDLGVBQWU7WUFDckMsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRO1lBQ3hCLE1BQU0sRUFBRSxLQUFLLENBQUMsTUFBTTtZQUNwQixpQkFBaUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCO1NBQzNDLENBQUM7S0FDSCxDQUFDO0FBQ0osQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgQ2ZuUHJvbXB0IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHsgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9lcnJvcnMnO1xuaW1wb3J0IHR5cGUgeyBQcm9tcHRJbmZlcmVuY2VDb25maWd1cmF0aW9uIH0gZnJvbSAnLi9wcm9tcHQtaW5mZXJlbmNlLWNvbmZpZ3VyYXRpb24nO1xuaW1wb3J0IHsgUHJvbXB0VGVtcGxhdGVDb25maWd1cmF0aW9uIH0gZnJvbSAnLi9wcm9tcHQtdGVtcGxhdGUtY29uZmlndXJhdGlvbic7XG5pbXBvcnQgdHlwZSB7IENvbW1vblByb21wdFZhcmlhbnRQcm9wcywgSVByb21wdFZhcmlhbnQgfSBmcm9tICcuL3Byb21wdC12YXJpYW50JztcbmltcG9ydCB7IFByb21wdFRlbXBsYXRlVHlwZSB9IGZyb20gJy4vcHJvbXB0LXZhcmlhbnQnO1xuaW1wb3J0IHR5cGUgeyBUb29sQ29uZmlndXJhdGlvbiB9IGZyb20gJy4vdG9vbC1jaG9pY2UnO1xuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNyZWF0aW5nIGEgY2hhdCBwcm9tcHQgdmFyaWFudC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDaGF0UHJvbXB0VmFyaWFudFByb3BzIGV4dGVuZHMgQ29tbW9uUHJvbXB0VmFyaWFudFByb3BzIHtcbiAgLyoqXG4gICAqIFRoZSBtZXNzYWdlcyBpbiB0aGUgY2hhdCBwcm9tcHQuXG4gICAqIE11c3QgaW5jbHVkZSBhdCBsZWFzdCBvbmUgVXNlciBNZXNzYWdlLlxuICAgKiBUaGUgbWVzc2FnZXMgc2hvdWxkIGFsdGVybmF0ZSBiZXR3ZWVuIFVzZXIgYW5kIEFzc2lzdGFudC5cbiAgICovXG4gIHJlYWRvbmx5IG1lc3NhZ2VzOiBDaGF0TWVzc2FnZVtdO1xuXG4gIC8qKlxuICAgKiBDb250ZXh0IG9yIGluc3RydWN0aW9ucyBmb3IgdGhlIG1vZGVsIHRvIGNvbnNpZGVyIGJlZm9yZSBnZW5lcmF0aW5nIGEgcmVzcG9uc2UuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTm8gc3lzdGVtIG1lc3NhZ2UgcHJvdmlkZWQuXG4gICAqL1xuICByZWFkb25seSBzeXN0ZW0/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBjb25maWd1cmF0aW9uIHdpdGggYXZhaWxhYmxlIHRvb2xzIHRvIHRoZSBtb2RlbCBhbmQgaG93IGl0IG11c3QgdXNlIHRoZW0uXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTm8gdG9vbCBjb25maWd1cmF0aW9uIHByb3ZpZGVkLlxuICAgKi9cbiAgcmVhZG9ubHkgdG9vbENvbmZpZ3VyYXRpb24/OiBUb29sQ29uZmlndXJhdGlvbjtcblxuICAvKipcbiAgICogSW5mZXJlbmNlIGNvbmZpZ3VyYXRpb24gZm9yIHRoZSBDaGF0IFByb21wdC5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyBpbmZlcmVuY2UgY29uZmlndXJhdGlvbiBwcm92aWRlZC5cbiAgICovXG4gIHJlYWRvbmx5IGluZmVyZW5jZUNvbmZpZ3VyYXRpb24/OiBQcm9tcHRJbmZlcmVuY2VDb25maWd1cmF0aW9uO1xufVxuXG4vKipcbiAqIFRoZSByb2xlIG9mIGEgbWVzc2FnZSBpbiBhIGNoYXQgY29udmVyc2F0aW9uLlxuICovXG5leHBvcnQgZW51bSBDaGF0TWVzc2FnZVJvbGUge1xuICAvKipcbiAgICogVGhpcyByb2xlIHJlcHJlc2VudHMgdGhlIGh1bWFuIHVzZXIgaW4gdGhlIGNvbnZlcnNhdGlvbi4gSW5wdXRzIGZyb20gdGhlXG4gICAqIHVzZXIgZ3VpZGUgdGhlIGNvbnZlcnNhdGlvbiBhbmQgcHJvbXB0IHJlc3BvbnNlcyBmcm9tIHRoZSBhc3Npc3RhbnQuXG4gICAqL1xuICBVU0VSID0gJ3VzZXInLFxuXG4gIC8qKlxuICAgKiBUaGlzIGlzIHRoZSByb2xlIG9mIHRoZSBtb2RlbCBpdHNlbGYsIHJlc3BvbmRpbmcgdG8gdXNlciBpbnB1dHMgYmFzZWQgb25cbiAgICogdGhlIGNvbnRleHQgc2V0IGJ5IHRoZSBzeXN0ZW0uXG4gICAqL1xuICBBU1NJU1RBTlQgPSAnYXNzaXN0YW50Jyxcbn1cblxuLyoqXG4gKiBSZXByZXNlbnRzIGEgbWVzc2FnZSBpbiBhIGNoYXQgY29udmVyc2F0aW9uLlxuICovXG5leHBvcnQgY2xhc3MgQ2hhdE1lc3NhZ2Uge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIHVzZXIgbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHRleHQgLSBUaGUgdGV4dCBjb250ZW50IG9mIHRoZSB1c2VyIG1lc3NhZ2VcbiAgICogQHJldHVybnMgQSBDaGF0TWVzc2FnZSBpbnN0YW5jZSByZXByZXNlbnRpbmcgYSB1c2VyIG1lc3NhZ2VcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgdXNlcih0ZXh0OiBzdHJpbmcpOiBDaGF0TWVzc2FnZSB7XG4gICAgcmV0dXJuIG5ldyBDaGF0TWVzc2FnZShDaGF0TWVzc2FnZVJvbGUuVVNFUiwgdGV4dCk7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBhbiBhc3Npc3RhbnQgbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHRleHQgLSBUaGUgdGV4dCBjb250ZW50IG9mIHRoZSBhc3Npc3RhbnQgbWVzc2FnZVxuICAgKiBAcmV0dXJucyBBIENoYXRNZXNzYWdlIGluc3RhbmNlIHJlcHJlc2VudGluZyBhbiBhc3Npc3RhbnQgbWVzc2FnZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBhc3Npc3RhbnQodGV4dDogc3RyaW5nKTogQ2hhdE1lc3NhZ2Uge1xuICAgIHJldHVybiBuZXcgQ2hhdE1lc3NhZ2UoQ2hhdE1lc3NhZ2VSb2xlLkFTU0lTVEFOVCwgdGV4dCk7XG4gIH1cblxuICAvKipcbiAgICogVGhlIHJvbGUgb2YgdGhlIG1lc3NhZ2Ugc2VuZGVyLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHJvbGU6IENoYXRNZXNzYWdlUm9sZTtcblxuICAvKipcbiAgICogVGhlIHRleHQgY29udGVudCBvZiB0aGUgbWVzc2FnZS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSB0ZXh0OiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3Iocm9sZTogQ2hhdE1lc3NhZ2VSb2xlLCB0ZXh0OiBzdHJpbmcpIHtcbiAgICB0aGlzLnJvbGUgPSByb2xlO1xuICAgIHRoaXMudGV4dCA9IHRleHQ7XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyB0aGUgbWVzc2FnZSBhcyBhIENsb3VkRm9ybWF0aW9uIHByb3BlcnR5LlxuICAgKiBAaW50ZXJuYWwgVGhpcyBpcyBhbiBpbnRlcm5hbCBjb3JlIGZ1bmN0aW9uIGFuZCBzaG91bGQgbm90IGJlIGNhbGxlZCBkaXJlY3RseS5cbiAgICovXG4gIHB1YmxpYyBfcmVuZGVyKCk6IENmblByb21wdC5NZXNzYWdlUHJvcGVydHkge1xuICAgIHJldHVybiB7XG4gICAgICByb2xlOiB0aGlzLnJvbGUsXG4gICAgICBjb250ZW50OiBbXG4gICAgICAgIHtcbiAgICAgICAgICB0ZXh0OiB0aGlzLnRleHQsXG4gICAgICAgIH0sXG4gICAgICBdLFxuICAgIH07XG4gIH1cbn1cblxuLyoqXG4gKiBDcmVhdGVzIGEgY2hhdCB0ZW1wbGF0ZSB2YXJpYW50LiBVc2UgdGhpcyB0ZW1wbGF0ZSB0eXBlIHdoZW5cbiAqIHRoZSBtb2RlbCBzdXBwb3J0cyB0aGUgQ29udmVyc2UgQVBJIG9yIHRoZSBBbnRocm9waWMgQ2xhdWRlIE1lc3NhZ2VzIEFQSS5cbiAqIFRoaXMgYWxsb3dzIHlvdSB0byBpbmNsdWRlIGEgU3lzdGVtIHByb21wdCBhbmQgcHJldmlvdXMgVXNlciBtZXNzYWdlc1xuICogYW5kIEFzc2lzdGFudCBtZXNzYWdlcyBmb3IgY29udGV4dC5cbiAqXG4gKiBAcGFyYW0gcHJvcHMgLSBQcm9wZXJ0aWVzIGZvciB0aGUgY2hhdCBwcm9tcHQgdmFyaWFudFxuICogQHJldHVybnMgQSBQcm9tcHRWYXJpYW50IGNvbmZpZ3VyZWQgZm9yIGNoYXQgaW50ZXJhY3Rpb25zXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVDaGF0UHJvbXB0VmFyaWFudChwcm9wczogQ2hhdFByb21wdFZhcmlhbnRQcm9wcyk6IElQcm9tcHRWYXJpYW50IHtcbiAgLy8gVmFsaWRhdGUgdGhhdCBtZXNzYWdlcyBhcnJheSBpcyBub3QgZW1wdHlcbiAgaWYgKCFwcm9wcy5tZXNzYWdlcyB8fCBwcm9wcy5tZXNzYWdlcy5sZW5ndGggPT09IDApIHtcbiAgICB0aHJvdyBuZXcgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IoJ0F0IGxlYXN0IG9uZSBtZXNzYWdlIG11c3QgYmUgcHJvdmlkZWQnKTtcbiAgfVxuXG4gIC8vIFZhbGlkYXRlIHRoYXQgdGhlIGZpcnN0IG1lc3NhZ2UgaXMgYSB1c2VyIG1lc3NhZ2VcbiAgaWYgKHByb3BzLm1lc3NhZ2VzWzBdLnJvbGUgIT09IENoYXRNZXNzYWdlUm9sZS5VU0VSKSB7XG4gICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKCdUaGUgZmlyc3QgbWVzc2FnZSBtdXN0IGJlIGEgVXNlciBtZXNzYWdlJyk7XG4gIH1cblxuICAvLyBWYWxpZGF0ZSB0aGF0IGF0IGxlYXN0IG9uZSB1c2VyIG1lc3NhZ2UgZXhpc3RzXG4gIGNvbnN0IGhhc1VzZXJNZXNzYWdlID0gcHJvcHMubWVzc2FnZXMuc29tZShtZXNzYWdlID0+IG1lc3NhZ2Uucm9sZSA9PT0gQ2hhdE1lc3NhZ2VSb2xlLlVTRVIpO1xuICBpZiAoIWhhc1VzZXJNZXNzYWdlKSB7XG4gICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKCdBdCBsZWFzdCBvbmUgVXNlciBtZXNzYWdlIG11c3QgYmUgcHJvdmlkZWQnKTtcbiAgfVxuXG4gIC8vIFZhbGlkYXRlIGFsdGVybmF0aW5nIHBhdHRlcm4gaWYgbW9yZSB0aGFuIG9uZSBtZXNzYWdlXG4gIGlmIChwcm9wcy5tZXNzYWdlcy5sZW5ndGggPiAxKSB7XG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCBwcm9wcy5tZXNzYWdlcy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgY3VycmVudFJvbGUgPSBwcm9wcy5tZXNzYWdlc1tpXS5yb2xlO1xuICAgICAgY29uc3QgcHJldmlvdXNSb2xlID0gcHJvcHMubWVzc2FnZXNbaSAtIDFdLnJvbGU7XG5cbiAgICAgIGlmIChjdXJyZW50Um9sZSA9PT0gcHJldmlvdXNSb2xlKSB7XG4gICAgICAgIHRocm93IG5ldyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvcihcbiAgICAgICAgICBgTWVzc2FnZXMgbXVzdCBhbHRlcm5hdGUgYmV0d2VlbiBVc2VyIGFuZCBBc3Npc3RhbnQgcm9sZXMuIEZvdW5kIGNvbnNlY3V0aXZlICR7Y3VycmVudFJvbGV9IG1lc3NhZ2VzIGF0IHBvc2l0aW9ucyAke2l9IGFuZCAke2kgKyAxfWAsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBuYW1lOiBwcm9wcy52YXJpYW50TmFtZSxcbiAgICB0ZW1wbGF0ZVR5cGU6IFByb21wdFRlbXBsYXRlVHlwZS5DSEFULFxuICAgIG1vZGVsSWQ6IHByb3BzLm1vZGVsLmludm9rYWJsZUFybixcbiAgICBpbmZlcmVuY2VDb25maWd1cmF0aW9uOiBwcm9wcy5pbmZlcmVuY2VDb25maWd1cmF0aW9uLFxuICAgIHRlbXBsYXRlQ29uZmlndXJhdGlvbjogUHJvbXB0VGVtcGxhdGVDb25maWd1cmF0aW9uLmNoYXQoe1xuICAgICAgaW5wdXRWYXJpYWJsZXM6IHByb3BzLnByb21wdFZhcmlhYmxlcyxcbiAgICAgIG1lc3NhZ2VzOiBwcm9wcy5tZXNzYWdlcyxcbiAgICAgIHN5c3RlbTogcHJvcHMuc3lzdGVtLFxuICAgICAgdG9vbENvbmZpZ3VyYXRpb246IHByb3BzLnRvb2xDb25maWd1cmF0aW9uLFxuICAgIH0pLFxuICB9O1xufVxuIl19