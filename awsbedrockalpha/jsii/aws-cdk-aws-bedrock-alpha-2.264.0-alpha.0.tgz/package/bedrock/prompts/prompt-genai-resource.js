"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptGenAiResource = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
/**
 * Abstract base class for prompt GenAI resource configurations.
 *
 * This provides a high-level abstraction over the underlying CloudFormation
 * GenAI resource properties, offering a more developer-friendly interface
 * while maintaining full compatibility with the underlying AWS Bedrock service.
 */
class PromptGenAiResource {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.PromptGenAiResource", version: "2.264.0-alpha.0" };
    /**
     * Creates an agent GenAI resource configuration.
     */
    static agent(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentGenAiResourceProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.agent);
            }
            throw error;
        }
        return new AgentGenAiResource(props);
    }
}
exports.PromptGenAiResource = PromptGenAiResource;
/**
 * Agent GenAI resource configuration for prompts.
 */
class AgentGenAiResource extends PromptGenAiResource {
    props;
    constructor(props) {
        super();
        this.props = props;
    }
    _render() {
        return {
            agent: {
                agentIdentifier: this.props.agentAlias.aliasArn,
            },
        };
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvbXB0LWdlbmFpLXJlc291cmNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicHJvbXB0LWdlbmFpLXJlc291cmNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBYUE7Ozs7OztHQU1HO0FBQ0gsTUFBc0IsbUJBQW1COztJQUN2Qzs7T0FFRztJQUNJLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBOEI7Ozs7Ozs7Ozs7UUFDaEQsT0FBTyxJQUFJLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO0tBQ3RDOztBQU5ILGtEQWFDO0FBRUQ7O0dBRUc7QUFDSCxNQUFNLGtCQUFtQixTQUFRLG1CQUFtQjtJQUNyQjtJQUE3QixZQUE2QixLQUE4QjtRQUN6RCxLQUFLLEVBQUUsQ0FBQztRQURtQixVQUFLLEdBQUwsS0FBSyxDQUF5QjtLQUUxRDtJQUVNLE9BQU87UUFDWixPQUFPO1lBQ0wsS0FBSyxFQUFFO2dCQUNMLGVBQWUsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxRQUFRO2FBQ2hEO1NBQ0YsQ0FBQztLQUNIO0NBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSAqIGFzIGJlZHJvY2sgZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHR5cGUgeyBJQWdlbnRBbGlhcyB9IGZyb20gJy4uL2FnZW50cy9hZ2VudC1hbGlhcyc7XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgY3JlYXRpbmcgYW4gYWdlbnQgR2VuQUkgcmVzb3VyY2UgY29uZmlndXJhdGlvbi5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBBZ2VudEdlbkFpUmVzb3VyY2VQcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgYWdlbnQgYWxpYXMgdG8gdXNlIGZvciB0aGUgR2VuQUkgcmVzb3VyY2UuXG4gICAqL1xuICByZWFkb25seSBhZ2VudEFsaWFzOiBJQWdlbnRBbGlhcztcbn1cblxuLyoqXG4gKiBBYnN0cmFjdCBiYXNlIGNsYXNzIGZvciBwcm9tcHQgR2VuQUkgcmVzb3VyY2UgY29uZmlndXJhdGlvbnMuXG4gKlxuICogVGhpcyBwcm92aWRlcyBhIGhpZ2gtbGV2ZWwgYWJzdHJhY3Rpb24gb3ZlciB0aGUgdW5kZXJseWluZyBDbG91ZEZvcm1hdGlvblxuICogR2VuQUkgcmVzb3VyY2UgcHJvcGVydGllcywgb2ZmZXJpbmcgYSBtb3JlIGRldmVsb3Blci1mcmllbmRseSBpbnRlcmZhY2VcbiAqIHdoaWxlIG1haW50YWluaW5nIGZ1bGwgY29tcGF0aWJpbGl0eSB3aXRoIHRoZSB1bmRlcmx5aW5nIEFXUyBCZWRyb2NrIHNlcnZpY2UuXG4gKi9cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBQcm9tcHRHZW5BaVJlc291cmNlIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYW4gYWdlbnQgR2VuQUkgcmVzb3VyY2UgY29uZmlndXJhdGlvbi5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgYWdlbnQocHJvcHM6IEFnZW50R2VuQWlSZXNvdXJjZVByb3BzKTogUHJvbXB0R2VuQWlSZXNvdXJjZSB7XG4gICAgcmV0dXJuIG5ldyBBZ2VudEdlbkFpUmVzb3VyY2UocHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgdGhlIEdlbkFJIHJlc291cmNlIGNvbmZpZ3VyYXRpb24gYXMgYSBDbG91ZEZvcm1hdGlvbiBwcm9wZXJ0eS5cbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwdWJsaWMgYWJzdHJhY3QgX3JlbmRlcigpOiBiZWRyb2NrLkNmblByb21wdC5Qcm9tcHRHZW5BaVJlc291cmNlUHJvcGVydHk7XG59XG5cbi8qKlxuICogQWdlbnQgR2VuQUkgcmVzb3VyY2UgY29uZmlndXJhdGlvbiBmb3IgcHJvbXB0cy5cbiAqL1xuY2xhc3MgQWdlbnRHZW5BaVJlc291cmNlIGV4dGVuZHMgUHJvbXB0R2VuQWlSZXNvdXJjZSB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgcHJvcHM6IEFnZW50R2VuQWlSZXNvdXJjZVByb3BzKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHB1YmxpYyBfcmVuZGVyKCk6IGJlZHJvY2suQ2ZuUHJvbXB0LlByb21wdEdlbkFpUmVzb3VyY2VQcm9wZXJ0eSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGFnZW50OiB7XG4gICAgICAgIGFnZW50SWRlbnRpZmllcjogdGhpcy5wcm9wcy5hZ2VudEFsaWFzLmFsaWFzQXJuLFxuICAgICAgfSxcbiAgICB9O1xuICB9XG59XG4iXX0=