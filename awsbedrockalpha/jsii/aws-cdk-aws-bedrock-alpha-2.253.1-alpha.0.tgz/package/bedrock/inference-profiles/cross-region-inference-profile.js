"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrossRegionInferenceProfile = exports.REGION_TO_GEO_AREA = exports.CrossRegionInferenceProfileRegion = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const aws_iam_1 = require("aws-cdk-lib/aws-iam");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const inference_profile_1 = require("./inference-profile");
/**
 * Geographic regions supported for cross-region inference profiles.
 * These regions help distribute traffic across multiple AWS regions for better
 * throughput and resilience during peak demands.
 */
var CrossRegionInferenceProfileRegion;
(function (CrossRegionInferenceProfileRegion) {
    /**
     * Global cross-region Inference Identifier.
     * Routes requests to any supported commercial AWS Region.
     */
    CrossRegionInferenceProfileRegion["GLOBAL"] = "global";
    /**
     * Cross-region Inference Identifier for the European area.
     * According to the model chosen, this might include:
     * - Frankfurt (`eu-central-1`)
     * - Ireland (`eu-west-1`)
     * - Paris (`eu-west-3`)
     * - London (`eu-west-2`)
     * - Stockholm (`eu-north-1`)
     * - Milan (`eu-south-1`)
     * - Spain (`eu-south-2`)
     * - Zurich (`eu-central-2`)
     */
    CrossRegionInferenceProfileRegion["EU"] = "eu";
    /**
     * Cross-region Inference Identifier for the United States area.
     * According to the model chosen, this might include:
     * - N. Virginia (`us-east-1`)
     * - Ohio (`us-east-2`)
     * - Oregon (`us-west-2`)
     */
    CrossRegionInferenceProfileRegion["US"] = "us";
    /**
     * Cross-region Inference Identifier for the US GovCloud area.
     * According to the model chosen, this might include:
     * - GovCloud US-East (`us-gov-east-1`)
     * - GovCloud US-West (`us-gov-west-1`)
     */
    CrossRegionInferenceProfileRegion["US_GOV"] = "us-gov";
    /**
     * Cross-region Inference Identifier for the Asia-Pacific area.
     * According to the model chosen, this might include:
     * - Tokyo (`ap-northeast-1`)
     * - Seoul (`ap-northeast-2`)
     * - Osaka (`ap-northeast-3`)
     * - Mumbai (`ap-south-1`)
     * - Hyderabad (`ap-south-2`)
     * - Singapore (`ap-southeast-1`)
     * - Sydney (`ap-southeast-2`)
     * - Jakarta (`ap-southeast-3`)
     * - Melbourne (`ap-southeast-4`)
     * - Malaysia (`ap-southeast-5`)
     * - Thailand (`ap-southeast-7`)
     * - Taipei (`ap-east-2`)
     * - Middle East (UAE) (`me-central-1`)
     */
    CrossRegionInferenceProfileRegion["APAC"] = "apac";
    /**
     * Cross-region Inference Identifier for the Japan area.
     * According to the model chosen, this might include:
     * - Tokyo (`ap-northeast-1`)
     * - Osaka (`ap-northeast-3`)
     */
    CrossRegionInferenceProfileRegion["JP"] = "jp";
    /**
     * Cross-region Inference Identifier for the Australia area.
     * According to the model chosen, this might include:
     * - Sydney (`ap-southeast-2`)
     * - Melbourne (`ap-southeast-4`)
     */
    CrossRegionInferenceProfileRegion["AU"] = "au";
})(CrossRegionInferenceProfileRegion || (exports.CrossRegionInferenceProfileRegion = CrossRegionInferenceProfileRegion = {}));
/**
 * Mapping of AWS regions to their corresponding geographic areas for cross-region inference.
 * This mapping is used to determine which cross-region inference profile to use based on the current region in prompt router.
 */
exports.REGION_TO_GEO_AREA = {
    // US Regions
    'us-east-1': CrossRegionInferenceProfileRegion.US, // N. Virginia
    'us-east-2': CrossRegionInferenceProfileRegion.US, // Ohio
    'us-west-2': CrossRegionInferenceProfileRegion.US, // Oregon
    // EU Regions
    'eu-central-1': CrossRegionInferenceProfileRegion.EU, // Frankfurt
    'eu-west-1': CrossRegionInferenceProfileRegion.EU, // Ireland
    'eu-west-3': CrossRegionInferenceProfileRegion.EU, // Paris
    // APAC Regions
    'ap-northeast-1': CrossRegionInferenceProfileRegion.APAC, // Tokyo
    'ap-northeast-2': CrossRegionInferenceProfileRegion.APAC, // Seoul
    'ap-south-1': CrossRegionInferenceProfileRegion.APAC, // Mumbai
    'ap-southeast-1': CrossRegionInferenceProfileRegion.APAC, // Singapore
    'ap-southeast-2': CrossRegionInferenceProfileRegion.APAC, // Sydney
};
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Cross-region inference enables you to seamlessly manage unplanned traffic
 * bursts by utilizing compute across different AWS Regions. With cross-region
 * inference, you can distribute traffic across multiple AWS Regions, enabling
 * higher throughput and enhanced resilience during periods of peak demands.
 *
 * This construct represents a system-defined inference profile that routes
 * requests across multiple regions based on availability and demand.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/cross-region-inference.html
 */
class CrossRegionInferenceProfile {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.CrossRegionInferenceProfile", version: "2.253.1-alpha.0" };
    /**
     * Creates a Cross-Region Inference Profile from the provided configuration.
     *
     * @param config - Configuration for the cross-region inference profile
     * @returns A new CrossRegionInferenceProfile instance
     * @throws ValidationError if the model doesn't support cross-region inference
     */
    static fromConfig(config) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_CrossRegionInferenceProfileProps(config);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.fromConfig);
            }
            throw error;
        }
        return new CrossRegionInferenceProfile(config);
    }
    /**
     * The unique identifier of the inference profile.
     * Format: {geoRegion}.{modelId}
     */
    inferenceProfileId;
    /**
     * The ARN of the inference profile.
     * @attribute
     */
    inferenceProfileArn;
    /**
     * The type of inference profile. Always SYSTEM_DEFINED for cross-region profiles.
     */
    type;
    /**
     * The underlying foundation model supporting cross-region inference.
     */
    inferenceProfileModel;
    /**
     * The ARN used for invoking this inference profile.
     * This equals to the inferenceProfileArn property, useful for implementing IBedrockInvokable interface.
     */
    invokableArn;
    constructor(props) {
        // Validate required properties
        if (!props.geoRegion) {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `GeoRegionRequired`, 'geoRegion is required');
        }
        if (!props.model) {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `ModelRequired`, 'model is required');
        }
        // Validate that the model supports cross-region inference
        if (!props.model.supportsCrossRegion) {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `ModelNotSupportedForCrossRegion`, `Model ${props.model.modelId} does not support cross-region inference`);
        }
        this.type = inference_profile_1.InferenceProfileType.SYSTEM_DEFINED;
        this.inferenceProfileModel = props.model;
        this.inferenceProfileId = `${props.geoRegion}.${props.model.modelId}`;
        this.inferenceProfileArn = aws_cdk_lib_1.Arn.format({
            partition: aws_cdk_lib_1.Aws.PARTITION,
            service: 'bedrock',
            account: aws_cdk_lib_1.Aws.ACCOUNT_ID,
            region: aws_cdk_lib_1.Aws.REGION,
            resource: 'inference-profile',
            resourceName: this.inferenceProfileId,
            arnFormat: aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME,
        });
        this.invokableArn = this.inferenceProfileArn;
    }
    /**
     * Gives the appropriate policies to invoke and use the Foundation Model.
     * For cross-region inference profiles, this method grants permissions to:
     * - Invoke the model in all regions where the inference profile can route requests
     * - Use the inference profile itself
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantInvoke(grantee) {
        // For cross-region inference profiles, we need to provide permissions to invoke the model in all regions
        // where the inference profile can route requests
        this.inferenceProfileModel.grantInvokeAllRegions(grantee);
        // And we need to provide permissions to invoke the inference profile itself
        return this.grantProfileUsage(grantee);
    }
    /**
     * Grants appropriate permissions to use the cross-region inference profile.
     * This method adds the necessary IAM permissions to allow the grantee to:
     * - Get inference profile details (bedrock:GetInferenceProfile)
     * - Invoke the model through the inference profile (bedrock:InvokeModel*)
     *
     * Note: This does not grant permissions to use the underlying model directly.
     * For comprehensive permissions, use grantInvoke() instead.
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantProfileUsage(grantee) {
        return aws_iam_1.Grant.addToPrincipal({
            grantee: grantee,
            actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel*'],
            resourceArns: [this.inferenceProfileArn],
        });
    }
}
exports.CrossRegionInferenceProfile = CrossRegionInferenceProfile;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3Jvc3MtcmVnaW9uLWluZmVyZW5jZS1wcm9maWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY3Jvc3MtcmVnaW9uLWluZmVyZW5jZS1wcm9maWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsNkNBQWtEO0FBRWxELGlEQUE0QztBQUM1Qyx3REFBc0U7QUFDdEUsNEVBQTREO0FBRzVELDJEQUEyRDtBQUUzRDs7OztHQUlHO0FBQ0gsSUFBWSxpQ0FrRVg7QUFsRUQsV0FBWSxpQ0FBaUM7SUFDM0M7OztPQUdHO0lBQ0gsc0RBQWlCLENBQUE7SUFDakI7Ozs7Ozs7Ozs7O09BV0c7SUFDSCw4Q0FBUyxDQUFBO0lBQ1Q7Ozs7OztPQU1HO0lBQ0gsOENBQVMsQ0FBQTtJQUNUOzs7OztPQUtHO0lBQ0gsc0RBQWlCLENBQUE7SUFDakI7Ozs7Ozs7Ozs7Ozs7Ozs7T0FnQkc7SUFDSCxrREFBYSxDQUFBO0lBQ2I7Ozs7O09BS0c7SUFDSCw4Q0FBUyxDQUFBO0lBQ1Q7Ozs7O09BS0c7SUFDSCw4Q0FBUyxDQUFBO0FBQ1gsQ0FBQyxFQWxFVyxpQ0FBaUMsaURBQWpDLGlDQUFpQyxRQWtFNUM7QUFFRDs7O0dBR0c7QUFDVSxRQUFBLGtCQUFrQixHQUF5RDtJQUN0RixhQUFhO0lBQ2IsV0FBVyxFQUFFLGlDQUFpQyxDQUFDLEVBQUUsRUFBRSxjQUFjO0lBQ2pFLFdBQVcsRUFBRSxpQ0FBaUMsQ0FBQyxFQUFFLEVBQUUsT0FBTztJQUMxRCxXQUFXLEVBQUUsaUNBQWlDLENBQUMsRUFBRSxFQUFFLFNBQVM7SUFFNUQsYUFBYTtJQUNiLGNBQWMsRUFBRSxpQ0FBaUMsQ0FBQyxFQUFFLEVBQUUsWUFBWTtJQUNsRSxXQUFXLEVBQUUsaUNBQWlDLENBQUMsRUFBRSxFQUFFLFVBQVU7SUFDN0QsV0FBVyxFQUFFLGlDQUFpQyxDQUFDLEVBQUUsRUFBRSxRQUFRO0lBRTNELGVBQWU7SUFDZixnQkFBZ0IsRUFBRSxpQ0FBaUMsQ0FBQyxJQUFJLEVBQUUsUUFBUTtJQUNsRSxnQkFBZ0IsRUFBRSxpQ0FBaUMsQ0FBQyxJQUFJLEVBQUUsUUFBUTtJQUNsRSxZQUFZLEVBQUUsaUNBQWlDLENBQUMsSUFBSSxFQUFFLFNBQVM7SUFDL0QsZ0JBQWdCLEVBQUUsaUNBQWlDLENBQUMsSUFBSSxFQUFFLFlBQVk7SUFDdEUsZ0JBQWdCLEVBQUUsaUNBQWlDLENBQUMsSUFBSSxFQUFFLFNBQVM7Q0FDcEUsQ0FBQztBQXNCRjs7K0VBRStFO0FBQy9FOzs7Ozs7Ozs7O0dBVUc7QUFDSCxNQUFhLDJCQUEyQjs7SUFDdEM7Ozs7OztPQU1HO0lBQ0ksTUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUF3Qzs7Ozs7Ozs7OztRQUMvRCxPQUFPLElBQUksMkJBQTJCLENBQUMsTUFBTSxDQUFDLENBQUM7S0FDaEQ7SUFFRDs7O09BR0c7SUFDYSxrQkFBa0IsQ0FBUztJQUUzQzs7O09BR0c7SUFDYSxtQkFBbUIsQ0FBUztJQUU1Qzs7T0FFRztJQUNhLElBQUksQ0FBdUI7SUFFM0M7O09BRUc7SUFDYSxxQkFBcUIsQ0FBeUI7SUFFOUQ7OztPQUdHO0lBQ2EsWUFBWSxDQUFTO0lBRXJDLFlBQW9CLEtBQXVDO1FBQ3pELCtCQUErQjtRQUMvQixJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ3JCLE1BQU0sSUFBSSxnQ0FBdUIsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsbUJBQW1CLEVBQUUsdUJBQXVCLENBQUMsQ0FBQztRQUNyRixDQUFDO1FBRUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNqQixNQUFNLElBQUksZ0NBQXVCLENBQUMsSUFBQSxzQkFBRyxFQUFBLGVBQWUsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO1FBQzdFLENBQUM7UUFFRCwwREFBMEQ7UUFDMUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztZQUNyQyxNQUFNLElBQUksZ0NBQXVCLENBQUMsSUFBQSxzQkFBRyxFQUFBLGlDQUFpQyxFQUFFLFNBQVMsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLDBDQUEwQyxDQUFDLENBQUM7UUFDbEosQ0FBQztRQUVELElBQUksQ0FBQyxJQUFJLEdBQUcsd0NBQW9CLENBQUMsY0FBYyxDQUFDO1FBQ2hELElBQUksQ0FBQyxxQkFBcUIsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxHQUFHLEtBQUssQ0FBQyxTQUFTLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUN0RSxJQUFJLENBQUMsbUJBQW1CLEdBQUcsaUJBQUcsQ0FBQyxNQUFNLENBQUM7WUFDcEMsU0FBUyxFQUFFLGlCQUFHLENBQUMsU0FBUztZQUN4QixPQUFPLEVBQUUsU0FBUztZQUNsQixPQUFPLEVBQUUsaUJBQUcsQ0FBQyxVQUFVO1lBQ3ZCLE1BQU0sRUFBRSxpQkFBRyxDQUFDLE1BQU07WUFDbEIsUUFBUSxFQUFFLG1CQUFtQjtZQUM3QixZQUFZLEVBQUUsSUFBSSxDQUFDLGtCQUFrQjtZQUNyQyxTQUFTLEVBQUUsdUJBQVMsQ0FBQyxtQkFBbUI7U0FDekMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUM7S0FDOUM7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSSxXQUFXLENBQUMsT0FBbUI7UUFDcEMseUdBQXlHO1FBQ3pHLGlEQUFpRDtRQUNqRCxJQUFJLENBQUMscUJBQXFCLENBQUMscUJBQXFCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFMUQsNEVBQTRFO1FBQzVFLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0tBQ3hDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0ksaUJBQWlCLENBQUMsT0FBbUI7UUFDMUMsT0FBTyxlQUFLLENBQUMsY0FBYyxDQUFDO1lBQzFCLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLE9BQU8sRUFBRSxDQUFDLDZCQUE2QixFQUFFLHNCQUFzQixDQUFDO1lBQ2hFLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztTQUN6QyxDQUFDLENBQUM7S0FDSjs7QUE1R0gsa0VBNkdDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXJuLCBBcm5Gb3JtYXQsIEF3cyB9IGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCB0eXBlIHsgSUdyYW50YWJsZSB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0IHsgR3JhbnQgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCB7IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvZXJyb3JzJztcbmltcG9ydCB7IGxpdCB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2hlbHBlcnMtaW50ZXJuYWwnO1xuaW1wb3J0IHR5cGUgeyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsLCBJQmVkcm9ja0ludm9rYWJsZSB9IGZyb20gJy4uL21vZGVscyc7XG5pbXBvcnQgdHlwZSB7IElJbmZlcmVuY2VQcm9maWxlIH0gZnJvbSAnLi9pbmZlcmVuY2UtcHJvZmlsZSc7XG5pbXBvcnQgeyBJbmZlcmVuY2VQcm9maWxlVHlwZSB9IGZyb20gJy4vaW5mZXJlbmNlLXByb2ZpbGUnO1xuXG4vKipcbiAqIEdlb2dyYXBoaWMgcmVnaW9ucyBzdXBwb3J0ZWQgZm9yIGNyb3NzLXJlZ2lvbiBpbmZlcmVuY2UgcHJvZmlsZXMuXG4gKiBUaGVzZSByZWdpb25zIGhlbHAgZGlzdHJpYnV0ZSB0cmFmZmljIGFjcm9zcyBtdWx0aXBsZSBBV1MgcmVnaW9ucyBmb3IgYmV0dGVyXG4gKiB0aHJvdWdocHV0IGFuZCByZXNpbGllbmNlIGR1cmluZyBwZWFrIGRlbWFuZHMuXG4gKi9cbmV4cG9ydCBlbnVtIENyb3NzUmVnaW9uSW5mZXJlbmNlUHJvZmlsZVJlZ2lvbiB7XG4gIC8qKlxuICAgKiBHbG9iYWwgY3Jvc3MtcmVnaW9uIEluZmVyZW5jZSBJZGVudGlmaWVyLlxuICAgKiBSb3V0ZXMgcmVxdWVzdHMgdG8gYW55IHN1cHBvcnRlZCBjb21tZXJjaWFsIEFXUyBSZWdpb24uXG4gICAqL1xuICBHTE9CQUwgPSAnZ2xvYmFsJyxcbiAgLyoqXG4gICAqIENyb3NzLXJlZ2lvbiBJbmZlcmVuY2UgSWRlbnRpZmllciBmb3IgdGhlIEV1cm9wZWFuIGFyZWEuXG4gICAqIEFjY29yZGluZyB0byB0aGUgbW9kZWwgY2hvc2VuLCB0aGlzIG1pZ2h0IGluY2x1ZGU6XG4gICAqIC0gRnJhbmtmdXJ0IChgZXUtY2VudHJhbC0xYClcbiAgICogLSBJcmVsYW5kIChgZXUtd2VzdC0xYClcbiAgICogLSBQYXJpcyAoYGV1LXdlc3QtM2ApXG4gICAqIC0gTG9uZG9uIChgZXUtd2VzdC0yYClcbiAgICogLSBTdG9ja2hvbG0gKGBldS1ub3J0aC0xYClcbiAgICogLSBNaWxhbiAoYGV1LXNvdXRoLTFgKVxuICAgKiAtIFNwYWluIChgZXUtc291dGgtMmApXG4gICAqIC0gWnVyaWNoIChgZXUtY2VudHJhbC0yYClcbiAgICovXG4gIEVVID0gJ2V1JyxcbiAgLyoqXG4gICAqIENyb3NzLXJlZ2lvbiBJbmZlcmVuY2UgSWRlbnRpZmllciBmb3IgdGhlIFVuaXRlZCBTdGF0ZXMgYXJlYS5cbiAgICogQWNjb3JkaW5nIHRvIHRoZSBtb2RlbCBjaG9zZW4sIHRoaXMgbWlnaHQgaW5jbHVkZTpcbiAgICogLSBOLiBWaXJnaW5pYSAoYHVzLWVhc3QtMWApXG4gICAqIC0gT2hpbyAoYHVzLWVhc3QtMmApXG4gICAqIC0gT3JlZ29uIChgdXMtd2VzdC0yYClcbiAgICovXG4gIFVTID0gJ3VzJyxcbiAgLyoqXG4gICAqIENyb3NzLXJlZ2lvbiBJbmZlcmVuY2UgSWRlbnRpZmllciBmb3IgdGhlIFVTIEdvdkNsb3VkIGFyZWEuXG4gICAqIEFjY29yZGluZyB0byB0aGUgbW9kZWwgY2hvc2VuLCB0aGlzIG1pZ2h0IGluY2x1ZGU6XG4gICAqIC0gR292Q2xvdWQgVVMtRWFzdCAoYHVzLWdvdi1lYXN0LTFgKVxuICAgKiAtIEdvdkNsb3VkIFVTLVdlc3QgKGB1cy1nb3Ytd2VzdC0xYClcbiAgICovXG4gIFVTX0dPViA9ICd1cy1nb3YnLFxuICAvKipcbiAgICogQ3Jvc3MtcmVnaW9uIEluZmVyZW5jZSBJZGVudGlmaWVyIGZvciB0aGUgQXNpYS1QYWNpZmljIGFyZWEuXG4gICAqIEFjY29yZGluZyB0byB0aGUgbW9kZWwgY2hvc2VuLCB0aGlzIG1pZ2h0IGluY2x1ZGU6XG4gICAqIC0gVG9reW8gKGBhcC1ub3J0aGVhc3QtMWApXG4gICAqIC0gU2VvdWwgKGBhcC1ub3J0aGVhc3QtMmApXG4gICAqIC0gT3Nha2EgKGBhcC1ub3J0aGVhc3QtM2ApXG4gICAqIC0gTXVtYmFpIChgYXAtc291dGgtMWApXG4gICAqIC0gSHlkZXJhYmFkIChgYXAtc291dGgtMmApXG4gICAqIC0gU2luZ2Fwb3JlIChgYXAtc291dGhlYXN0LTFgKVxuICAgKiAtIFN5ZG5leSAoYGFwLXNvdXRoZWFzdC0yYClcbiAgICogLSBKYWthcnRhIChgYXAtc291dGhlYXN0LTNgKVxuICAgKiAtIE1lbGJvdXJuZSAoYGFwLXNvdXRoZWFzdC00YClcbiAgICogLSBNYWxheXNpYSAoYGFwLXNvdXRoZWFzdC01YClcbiAgICogLSBUaGFpbGFuZCAoYGFwLXNvdXRoZWFzdC03YClcbiAgICogLSBUYWlwZWkgKGBhcC1lYXN0LTJgKVxuICAgKiAtIE1pZGRsZSBFYXN0IChVQUUpIChgbWUtY2VudHJhbC0xYClcbiAgICovXG4gIEFQQUMgPSAnYXBhYycsXG4gIC8qKlxuICAgKiBDcm9zcy1yZWdpb24gSW5mZXJlbmNlIElkZW50aWZpZXIgZm9yIHRoZSBKYXBhbiBhcmVhLlxuICAgKiBBY2NvcmRpbmcgdG8gdGhlIG1vZGVsIGNob3NlbiwgdGhpcyBtaWdodCBpbmNsdWRlOlxuICAgKiAtIFRva3lvIChgYXAtbm9ydGhlYXN0LTFgKVxuICAgKiAtIE9zYWthIChgYXAtbm9ydGhlYXN0LTNgKVxuICAgKi9cbiAgSlAgPSAnanAnLFxuICAvKipcbiAgICogQ3Jvc3MtcmVnaW9uIEluZmVyZW5jZSBJZGVudGlmaWVyIGZvciB0aGUgQXVzdHJhbGlhIGFyZWEuXG4gICAqIEFjY29yZGluZyB0byB0aGUgbW9kZWwgY2hvc2VuLCB0aGlzIG1pZ2h0IGluY2x1ZGU6XG4gICAqIC0gU3lkbmV5IChgYXAtc291dGhlYXN0LTJgKVxuICAgKiAtIE1lbGJvdXJuZSAoYGFwLXNvdXRoZWFzdC00YClcbiAgICovXG4gIEFVID0gJ2F1Jyxcbn1cblxuLyoqXG4gKiBNYXBwaW5nIG9mIEFXUyByZWdpb25zIHRvIHRoZWlyIGNvcnJlc3BvbmRpbmcgZ2VvZ3JhcGhpYyBhcmVhcyBmb3IgY3Jvc3MtcmVnaW9uIGluZmVyZW5jZS5cbiAqIFRoaXMgbWFwcGluZyBpcyB1c2VkIHRvIGRldGVybWluZSB3aGljaCBjcm9zcy1yZWdpb24gaW5mZXJlbmNlIHByb2ZpbGUgdG8gdXNlIGJhc2VkIG9uIHRoZSBjdXJyZW50IHJlZ2lvbiBpbiBwcm9tcHQgcm91dGVyLlxuICovXG5leHBvcnQgY29uc3QgUkVHSU9OX1RPX0dFT19BUkVBOiB7IFtrZXk6IHN0cmluZ106IENyb3NzUmVnaW9uSW5mZXJlbmNlUHJvZmlsZVJlZ2lvbiB9ID0ge1xuICAvLyBVUyBSZWdpb25zXG4gICd1cy1lYXN0LTEnOiBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGVSZWdpb24uVVMsIC8vIE4uIFZpcmdpbmlhXG4gICd1cy1lYXN0LTInOiBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGVSZWdpb24uVVMsIC8vIE9oaW9cbiAgJ3VzLXdlc3QtMic6IENyb3NzUmVnaW9uSW5mZXJlbmNlUHJvZmlsZVJlZ2lvbi5VUywgLy8gT3JlZ29uXG5cbiAgLy8gRVUgUmVnaW9uc1xuICAnZXUtY2VudHJhbC0xJzogQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlUmVnaW9uLkVVLCAvLyBGcmFua2Z1cnRcbiAgJ2V1LXdlc3QtMSc6IENyb3NzUmVnaW9uSW5mZXJlbmNlUHJvZmlsZVJlZ2lvbi5FVSwgLy8gSXJlbGFuZFxuICAnZXUtd2VzdC0zJzogQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlUmVnaW9uLkVVLCAvLyBQYXJpc1xuXG4gIC8vIEFQQUMgUmVnaW9uc1xuICAnYXAtbm9ydGhlYXN0LTEnOiBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGVSZWdpb24uQVBBQywgLy8gVG9reW9cbiAgJ2FwLW5vcnRoZWFzdC0yJzogQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlUmVnaW9uLkFQQUMsIC8vIFNlb3VsXG4gICdhcC1zb3V0aC0xJzogQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlUmVnaW9uLkFQQUMsIC8vIE11bWJhaVxuICAnYXAtc291dGhlYXN0LTEnOiBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGVSZWdpb24uQVBBQywgLy8gU2luZ2Fwb3JlXG4gICdhcC1zb3V0aGVhc3QtMic6IENyb3NzUmVnaW9uSW5mZXJlbmNlUHJvZmlsZVJlZ2lvbi5BUEFDLCAvLyBTeWRuZXlcbn07XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgUFJPUFMgRk9SIE5FVyBDT05TVFJVQ1RcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogUHJvcGVydGllcyBmb3IgY3JlYXRpbmcgYSBDcm9zcy1SZWdpb24gSW5mZXJlbmNlIFByb2ZpbGUuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlUHJvcHMge1xuICAvKipcbiAgICogVGhlIGdlb2dyYXBoaWMgcmVnaW9uIHdoZXJlIHRoZSB0cmFmZmljIGlzIGdvaW5nIHRvIGJlIGRpc3RyaWJ1dGVkLiBSb3V0aW5nXG4gICAqIGZhY3RvcnMgaW4gdXNlciB0cmFmZmljLCBkZW1hbmQgYW5kIHV0aWxpemF0aW9uIG9mIHJlc291cmNlcy5cbiAgICovXG4gIHJlYWRvbmx5IGdlb1JlZ2lvbjogQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlUmVnaW9uO1xuICAvKipcbiAgICogQSBmb3VuZGF0aW9uIG1vZGVsIHN1cHBvcnRpbmcgY3Jvc3MtcmVnaW9uIGluZmVyZW5jZS5cbiAgICogVGhlIG1vZGVsIG11c3QgaGF2ZSBjcm9zcy1yZWdpb24gc3VwcG9ydCBlbmFibGVkLlxuICAgKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9iZWRyb2NrL2xhdGVzdC91c2VyZ3VpZGUvY3Jvc3MtcmVnaW9uLWluZmVyZW5jZS1zdXBwb3J0Lmh0bWxcbiAgICovXG4gIHJlYWRvbmx5IG1vZGVsOiBCZWRyb2NrRm91bmRhdGlvbk1vZGVsO1xufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIE5FVyBDT05TVFJVQ1QgREVGSU5JVElPTlxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBDcm9zcy1yZWdpb24gaW5mZXJlbmNlIGVuYWJsZXMgeW91IHRvIHNlYW1sZXNzbHkgbWFuYWdlIHVucGxhbm5lZCB0cmFmZmljXG4gKiBidXJzdHMgYnkgdXRpbGl6aW5nIGNvbXB1dGUgYWNyb3NzIGRpZmZlcmVudCBBV1MgUmVnaW9ucy4gV2l0aCBjcm9zcy1yZWdpb25cbiAqIGluZmVyZW5jZSwgeW91IGNhbiBkaXN0cmlidXRlIHRyYWZmaWMgYWNyb3NzIG11bHRpcGxlIEFXUyBSZWdpb25zLCBlbmFibGluZ1xuICogaGlnaGVyIHRocm91Z2hwdXQgYW5kIGVuaGFuY2VkIHJlc2lsaWVuY2UgZHVyaW5nIHBlcmlvZHMgb2YgcGVhayBkZW1hbmRzLlxuICpcbiAqIFRoaXMgY29uc3RydWN0IHJlcHJlc2VudHMgYSBzeXN0ZW0tZGVmaW5lZCBpbmZlcmVuY2UgcHJvZmlsZSB0aGF0IHJvdXRlc1xuICogcmVxdWVzdHMgYWNyb3NzIG11bHRpcGxlIHJlZ2lvbnMgYmFzZWQgb24gYXZhaWxhYmlsaXR5IGFuZCBkZW1hbmQuXG4gKlxuICogQHNlZSBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vYmVkcm9jay9sYXRlc3QvdXNlcmd1aWRlL2Nyb3NzLXJlZ2lvbi1pbmZlcmVuY2UuaHRtbFxuICovXG5leHBvcnQgY2xhc3MgQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlIGltcGxlbWVudHMgSUJlZHJvY2tJbnZva2FibGUsIElJbmZlcmVuY2VQcm9maWxlIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBDcm9zcy1SZWdpb24gSW5mZXJlbmNlIFByb2ZpbGUgZnJvbSB0aGUgcHJvdmlkZWQgY29uZmlndXJhdGlvbi5cbiAgICpcbiAgICogQHBhcmFtIGNvbmZpZyAtIENvbmZpZ3VyYXRpb24gZm9yIHRoZSBjcm9zcy1yZWdpb24gaW5mZXJlbmNlIHByb2ZpbGVcbiAgICogQHJldHVybnMgQSBuZXcgQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlIGluc3RhbmNlXG4gICAqIEB0aHJvd3MgVmFsaWRhdGlvbkVycm9yIGlmIHRoZSBtb2RlbCBkb2Vzbid0IHN1cHBvcnQgY3Jvc3MtcmVnaW9uIGluZmVyZW5jZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tQ29uZmlnKGNvbmZpZzogQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlUHJvcHMpOiBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGUge1xuICAgIHJldHVybiBuZXcgQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlKGNvbmZpZyk7XG4gIH1cblxuICAvKipcbiAgICogVGhlIHVuaXF1ZSBpZGVudGlmaWVyIG9mIHRoZSBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogRm9ybWF0OiB7Z2VvUmVnaW9ufS57bW9kZWxJZH1cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlSWQ6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlQXJuOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSB0eXBlIG9mIGluZmVyZW5jZSBwcm9maWxlLiBBbHdheXMgU1lTVEVNX0RFRklORUQgZm9yIGNyb3NzLXJlZ2lvbiBwcm9maWxlcy5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSB0eXBlOiBJbmZlcmVuY2VQcm9maWxlVHlwZTtcblxuICAvKipcbiAgICogVGhlIHVuZGVybHlpbmcgZm91bmRhdGlvbiBtb2RlbCBzdXBwb3J0aW5nIGNyb3NzLXJlZ2lvbiBpbmZlcmVuY2UuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZU1vZGVsOiBCZWRyb2NrRm91bmRhdGlvbk1vZGVsO1xuXG4gIC8qKlxuICAgKiBUaGUgQVJOIHVzZWQgZm9yIGludm9raW5nIHRoaXMgaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFRoaXMgZXF1YWxzIHRvIHRoZSBpbmZlcmVuY2VQcm9maWxlQXJuIHByb3BlcnR5LCB1c2VmdWwgZm9yIGltcGxlbWVudGluZyBJQmVkcm9ja0ludm9rYWJsZSBpbnRlcmZhY2UuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgaW52b2thYmxlQXJuOiBzdHJpbmc7XG5cbiAgcHJpdmF0ZSBjb25zdHJ1Y3Rvcihwcm9wczogQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlUHJvcHMpIHtcbiAgICAvLyBWYWxpZGF0ZSByZXF1aXJlZCBwcm9wZXJ0aWVzXG4gICAgaWYgKCFwcm9wcy5nZW9SZWdpb24pIHtcbiAgICAgIHRocm93IG5ldyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvcihsaXRgR2VvUmVnaW9uUmVxdWlyZWRgLCAnZ2VvUmVnaW9uIGlzIHJlcXVpcmVkJyk7XG4gICAgfVxuXG4gICAgaWYgKCFwcm9wcy5tb2RlbCkge1xuICAgICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKGxpdGBNb2RlbFJlcXVpcmVkYCwgJ21vZGVsIGlzIHJlcXVpcmVkJyk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgdGhhdCB0aGUgbW9kZWwgc3VwcG9ydHMgY3Jvc3MtcmVnaW9uIGluZmVyZW5jZVxuICAgIGlmICghcHJvcHMubW9kZWwuc3VwcG9ydHNDcm9zc1JlZ2lvbikge1xuICAgICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKGxpdGBNb2RlbE5vdFN1cHBvcnRlZEZvckNyb3NzUmVnaW9uYCwgYE1vZGVsICR7cHJvcHMubW9kZWwubW9kZWxJZH0gZG9lcyBub3Qgc3VwcG9ydCBjcm9zcy1yZWdpb24gaW5mZXJlbmNlYCk7XG4gICAgfVxuXG4gICAgdGhpcy50eXBlID0gSW5mZXJlbmNlUHJvZmlsZVR5cGUuU1lTVEVNX0RFRklORUQ7XG4gICAgdGhpcy5pbmZlcmVuY2VQcm9maWxlTW9kZWwgPSBwcm9wcy5tb2RlbDtcbiAgICB0aGlzLmluZmVyZW5jZVByb2ZpbGVJZCA9IGAke3Byb3BzLmdlb1JlZ2lvbn0uJHtwcm9wcy5tb2RlbC5tb2RlbElkfWA7XG4gICAgdGhpcy5pbmZlcmVuY2VQcm9maWxlQXJuID0gQXJuLmZvcm1hdCh7XG4gICAgICBwYXJ0aXRpb246IEF3cy5QQVJUSVRJT04sXG4gICAgICBzZXJ2aWNlOiAnYmVkcm9jaycsXG4gICAgICBhY2NvdW50OiBBd3MuQUNDT1VOVF9JRCxcbiAgICAgIHJlZ2lvbjogQXdzLlJFR0lPTixcbiAgICAgIHJlc291cmNlOiAnaW5mZXJlbmNlLXByb2ZpbGUnLFxuICAgICAgcmVzb3VyY2VOYW1lOiB0aGlzLmluZmVyZW5jZVByb2ZpbGVJZCxcbiAgICAgIGFybkZvcm1hdDogQXJuRm9ybWF0LlNMQVNIX1JFU09VUkNFX05BTUUsXG4gICAgfSk7XG4gICAgdGhpcy5pbnZva2FibGVBcm4gPSB0aGlzLmluZmVyZW5jZVByb2ZpbGVBcm47XG4gIH1cblxuICAvKipcbiAgICogR2l2ZXMgdGhlIGFwcHJvcHJpYXRlIHBvbGljaWVzIHRvIGludm9rZSBhbmQgdXNlIHRoZSBGb3VuZGF0aW9uIE1vZGVsLlxuICAgKiBGb3IgY3Jvc3MtcmVnaW9uIGluZmVyZW5jZSBwcm9maWxlcywgdGhpcyBtZXRob2QgZ3JhbnRzIHBlcm1pc3Npb25zIHRvOlxuICAgKiAtIEludm9rZSB0aGUgbW9kZWwgaW4gYWxsIHJlZ2lvbnMgd2hlcmUgdGhlIGluZmVyZW5jZSBwcm9maWxlIGNhbiByb3V0ZSByZXF1ZXN0c1xuICAgKiAtIFVzZSB0aGUgaW5mZXJlbmNlIHByb2ZpbGUgaXRzZWxmXG4gICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgKlxuICAgKiBAcGFyYW0gZ3JhbnRlZSAtIFRoZSBJQU0gcHJpbmNpcGFsIHRvIGdyYW50IHBlcm1pc3Npb25zIHRvXG4gICAqIEByZXR1cm5zIEFuIElBTSBHcmFudCBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSBncmFudGVkIHBlcm1pc3Npb25zXG4gICAqL1xuICBwdWJsaWMgZ3JhbnRJbnZva2UoZ3JhbnRlZTogSUdyYW50YWJsZSk6IEdyYW50IHtcbiAgICAvLyBGb3IgY3Jvc3MtcmVnaW9uIGluZmVyZW5jZSBwcm9maWxlcywgd2UgbmVlZCB0byBwcm92aWRlIHBlcm1pc3Npb25zIHRvIGludm9rZSB0aGUgbW9kZWwgaW4gYWxsIHJlZ2lvbnNcbiAgICAvLyB3aGVyZSB0aGUgaW5mZXJlbmNlIHByb2ZpbGUgY2FuIHJvdXRlIHJlcXVlc3RzXG4gICAgdGhpcy5pbmZlcmVuY2VQcm9maWxlTW9kZWwuZ3JhbnRJbnZva2VBbGxSZWdpb25zKGdyYW50ZWUpO1xuXG4gICAgLy8gQW5kIHdlIG5lZWQgdG8gcHJvdmlkZSBwZXJtaXNzaW9ucyB0byBpbnZva2UgdGhlIGluZmVyZW5jZSBwcm9maWxlIGl0c2VsZlxuICAgIHJldHVybiB0aGlzLmdyYW50UHJvZmlsZVVzYWdlKGdyYW50ZWUpO1xuICB9XG5cbiAgLyoqXG4gICAqIEdyYW50cyBhcHByb3ByaWF0ZSBwZXJtaXNzaW9ucyB0byB1c2UgdGhlIGNyb3NzLXJlZ2lvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogVGhpcyBtZXRob2QgYWRkcyB0aGUgbmVjZXNzYXJ5IElBTSBwZXJtaXNzaW9ucyB0byBhbGxvdyB0aGUgZ3JhbnRlZSB0bzpcbiAgICogLSBHZXQgaW5mZXJlbmNlIHByb2ZpbGUgZGV0YWlscyAoYmVkcm9jazpHZXRJbmZlcmVuY2VQcm9maWxlKVxuICAgKiAtIEludm9rZSB0aGUgbW9kZWwgdGhyb3VnaCB0aGUgaW5mZXJlbmNlIHByb2ZpbGUgKGJlZHJvY2s6SW52b2tlTW9kZWwqKVxuICAgKlxuICAgKiBOb3RlOiBUaGlzIGRvZXMgbm90IGdyYW50IHBlcm1pc3Npb25zIHRvIHVzZSB0aGUgdW5kZXJseWluZyBtb2RlbCBkaXJlY3RseS5cbiAgICogRm9yIGNvbXByZWhlbnNpdmUgcGVybWlzc2lvbnMsIHVzZSBncmFudEludm9rZSgpIGluc3RlYWQuXG4gICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgKlxuICAgKiBAcGFyYW0gZ3JhbnRlZSAtIFRoZSBJQU0gcHJpbmNpcGFsIHRvIGdyYW50IHBlcm1pc3Npb25zIHRvXG4gICAqIEByZXR1cm5zIEFuIElBTSBHcmFudCBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSBncmFudGVkIHBlcm1pc3Npb25zXG4gICAqL1xuICBwdWJsaWMgZ3JhbnRQcm9maWxlVXNhZ2UoZ3JhbnRlZTogSUdyYW50YWJsZSk6IEdyYW50IHtcbiAgICByZXR1cm4gR3JhbnQuYWRkVG9QcmluY2lwYWwoe1xuICAgICAgZ3JhbnRlZTogZ3JhbnRlZSxcbiAgICAgIGFjdGlvbnM6IFsnYmVkcm9jazpHZXRJbmZlcmVuY2VQcm9maWxlJywgJ2JlZHJvY2s6SW52b2tlTW9kZWwqJ10sXG4gICAgICByZXNvdXJjZUFybnM6IFt0aGlzLmluZmVyZW5jZVByb2ZpbGVBcm5dLFxuICAgIH0pO1xuICB9XG59XG4iXX0=