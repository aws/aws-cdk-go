import type { IGrantable } from 'aws-cdk-lib/aws-iam';
import { Grant } from 'aws-cdk-lib/aws-iam';
import type { IBedrockInvokable } from '../models';
import { BedrockFoundationModel } from '../models';
/**
 * Represents a Prompt Router, which provides intelligent routing between different models.
 */
export interface IPromptRouter {
    /**
     * The ARN of the prompt router.
     * @attribute
     */
    readonly promptRouterArn: string;
    /**
     * The ID of the prompt router.
     * @attribute
     */
    readonly promptRouterId: string;
    /**
     * The foundation models / profiles this router will route to.
     */
    readonly routingEndpoints: IBedrockInvokable[];
}
/**
 * Properties for configuring a Prompt Router.
 */
export interface PromptRouterProps {
    /**
     * Prompt Router ID that identifies the routing configuration.
     */
    readonly promptRouterId: string;
    /**
     * The foundation models this router will route to.
     * The router will intelligently select between these models based on the request.
     */
    readonly routingModels: BedrockFoundationModel[];
}
/**
 * Represents identifiers for default prompt routers in Bedrock.
 * These are pre-configured routers provided by AWS that route between
 * different models in the same family for optimal performance and cost.
 */
export declare class DefaultPromptRouterIdentifier {
    /**
     * Anthropic Claude V1 router configuration.
     * Routes between Claude Haiku and Claude 3.5 Sonnet models for optimal
     * balance between performance and cost.
     */
    static readonly ANTHROPIC_CLAUDE_V1: DefaultPromptRouterIdentifier;
    /**
     * Meta Llama 3.1 router configuration.
     * Routes between different sizes of Llama 3.1 models (8B and 70B)
     * for optimal performance based on request complexity.
     */
    static readonly META_LLAMA_3_1: DefaultPromptRouterIdentifier;
    /**
     * The unique identifier for this prompt router.
     */
    readonly promptRouterId: string;
    /**
     * The foundation models that this router can route between.
     */
    readonly routingModels: BedrockFoundationModel[];
    private constructor();
}
/**
 * Amazon Bedrock intelligent prompt routing provides a single serverless endpoint
 * for efficiently routing requests between different foundational models within
 * the same model family. It can help you optimize for response quality and cost.
 *
 * Intelligent prompt routing predicts the performance of each model for each request,
 * and dynamically routes each request to the model that it predicts is most likely
 * to give the desired response at the lowest cost.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/prompt-routing.html
 */
export declare class PromptRouter implements IBedrockInvokable, IPromptRouter {
    /**
     * Creates a PromptRouter from a default router identifier.
     *
     * @param defaultRouter - The default router configuration to use
     * @param region - The AWS region where the router will be used
     * @returns A new PromptRouter instance configured with the default settings
     */
    static fromDefaultId(defaultRouter: DefaultPromptRouterIdentifier, region: string): PromptRouter;
    /**
     * The ARN of the prompt router.
     * @attribute
     */
    readonly promptRouterArn: string;
    /**
     * The ID of the prompt router.
     * @attribute
     */
    readonly promptRouterId: string;
    /**
     * The ARN used for invoking this prompt router.
     * This equals to the promptRouterArn property, useful for implementing IBedrockInvokable interface.
     */
    readonly invokableArn: string;
    /**
     * The inference endpoints (cross-region profiles) that this router will route to.
     * These are created automatically based on the routing models and region.
     */
    readonly routingEndpoints: IBedrockInvokable[];
    constructor(props: PromptRouterProps, region: string);
    /**
     * Grants the necessary permissions to invoke this prompt router and all its routing endpoints.
     * This method grants permissions to:
     * - Get prompt router details (bedrock:GetPromptRouter)
     * - Invoke models through the router (bedrock:InvokeModel)
     * - Use all underlying models and cross-region profiles
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantInvoke(grantee: IGrantable): Grant;
}
