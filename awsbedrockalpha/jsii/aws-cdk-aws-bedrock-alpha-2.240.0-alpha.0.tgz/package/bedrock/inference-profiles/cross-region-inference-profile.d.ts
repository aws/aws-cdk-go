import type { IGrantable } from 'aws-cdk-lib/aws-iam';
import { Grant } from 'aws-cdk-lib/aws-iam';
import type { BedrockFoundationModel, IBedrockInvokable } from '../models';
import type { IInferenceProfile } from './inference-profile';
import { InferenceProfileType } from './inference-profile';
/**
 * Geographic regions supported for cross-region inference profiles.
 * These regions help distribute traffic across multiple AWS regions for better
 * throughput and resilience during peak demands.
 */
export declare enum CrossRegionInferenceProfileRegion {
    /**
     * Global cross-region Inference Identifier.
     * Routes requests to any supported commercial AWS Region.
     */
    GLOBAL = "global",
    /**
     * Cross-region Inference Identifier for the European area.
     * According to the model chosen, this might include:
     * - Frankfurt (`eu-central-1`)
     * - Ireland (`eu-west-1`)
     * - Paris (`eu-west-3`)
     * - London (`eu-west-2`)
     * - Stockholm (`eu-north-1`)
     * - Milan (`eu-south-1`)
     * - Spain (`eu-south-2`)
     * - Zurich (`eu-central-2`)
     */
    EU = "eu",
    /**
     * Cross-region Inference Identifier for the United States area.
     * According to the model chosen, this might include:
     * - N. Virginia (`us-east-1`)
     * - Ohio (`us-east-2`)
     * - Oregon (`us-west-2`)
     */
    US = "us",
    /**
     * Cross-region Inference Identifier for the US GovCloud area.
     * According to the model chosen, this might include:
     * - GovCloud US-East (`us-gov-east-1`)
     * - GovCloud US-West (`us-gov-west-1`)
     */
    US_GOV = "us-gov",
    /**
     * Cross-region Inference Identifier for the Asia-Pacific area.
     * According to the model chosen, this might include:
     * - Tokyo (`ap-northeast-1`)
     * - Seoul (`ap-northeast-2`)
     * - Osaka (`ap-northeast-3`)
     * - Mumbai (`ap-south-1`)
     * - Hyderabad (`ap-south-2`)
     * - Singapore (`ap-southeast-1`)
     * - Sydney (`ap-southeast-2`)
     * - Jakarta (`ap-southeast-3`)
     * - Melbourne (`ap-southeast-4`)
     * - Malaysia (`ap-southeast-5`)
     * - Thailand (`ap-southeast-7`)
     * - Taipei (`ap-east-2`)
     * - Middle East (UAE) (`me-central-1`)
     */
    APAC = "apac",
    /**
     * Cross-region Inference Identifier for the Japan area.
     * According to the model chosen, this might include:
     * - Tokyo (`ap-northeast-1`)
     * - Osaka (`ap-northeast-3`)
     */
    JP = "jp",
    /**
     * Cross-region Inference Identifier for the Australia area.
     * According to the model chosen, this might include:
     * - Sydney (`ap-southeast-2`)
     * - Melbourne (`ap-southeast-4`)
     */
    AU = "au"
}
/**
 * Mapping of AWS regions to their corresponding geographic areas for cross-region inference.
 * This mapping is used to determine which cross-region inference profile to use based on the current region in prompt router.
 */
export declare const REGION_TO_GEO_AREA: {
    [key: string]: CrossRegionInferenceProfileRegion;
};
/******************************************************************************
 *                        PROPS FOR NEW CONSTRUCT
 *****************************************************************************/
/**
 * Properties for creating a Cross-Region Inference Profile.
 */
export interface CrossRegionInferenceProfileProps {
    /**
     * The geographic region where the traffic is going to be distributed. Routing
     * factors in user traffic, demand and utilization of resources.
     */
    readonly geoRegion: CrossRegionInferenceProfileRegion;
    /**
     * A foundation model supporting cross-region inference.
     * The model must have cross-region support enabled.
     * @see https://docs.aws.amazon.com/bedrock/latest/userguide/cross-region-inference-support.html
     */
    readonly model: BedrockFoundationModel;
}
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Cross-region inference enables you to seamlessly manage unplanned traffic
 * bursts by utilizing compute across different AWS Regions. With cross-region
 * inference, you can distribute traffic across multiple AWS Regions, enabling
 * higher throughput and enhanced resilience during periods of peak demands.
 *
 * This construct represents a system-defined inference profile that routes
 * requests across multiple regions based on availability and demand.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/cross-region-inference.html
 */
export declare class CrossRegionInferenceProfile implements IBedrockInvokable, IInferenceProfile {
    /**
     * Creates a Cross-Region Inference Profile from the provided configuration.
     *
     * @param config - Configuration for the cross-region inference profile
     * @returns A new CrossRegionInferenceProfile instance
     * @throws ValidationError if the model doesn't support cross-region inference
     */
    static fromConfig(config: CrossRegionInferenceProfileProps): CrossRegionInferenceProfile;
    /**
     * The unique identifier of the inference profile.
     * Format: {geoRegion}.{modelId}
     */
    readonly inferenceProfileId: string;
    /**
     * The ARN of the inference profile.
     * @attribute
     */
    readonly inferenceProfileArn: string;
    /**
     * The type of inference profile. Always SYSTEM_DEFINED for cross-region profiles.
     */
    readonly type: InferenceProfileType;
    /**
     * The underlying foundation model supporting cross-region inference.
     */
    readonly inferenceProfileModel: BedrockFoundationModel;
    /**
     * The ARN used for invoking this inference profile.
     * This equals to the inferenceProfileArn property, useful for implementing IBedrockInvokable interface.
     */
    readonly invokableArn: string;
    private constructor();
    /**
     * Gives the appropriate policies to invoke and use the Foundation Model.
     * For cross-region inference profiles, this method grants permissions to:
     * - Invoke the model in all regions where the inference profile can route requests
     * - Use the inference profile itself
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantInvoke(grantee: IGrantable): Grant;
    /**
     * Grants appropriate permissions to use the cross-region inference profile.
     * This method adds the necessary IAM permissions to allow the grantee to:
     * - Get inference profile details (bedrock:GetInferenceProfile)
     * - Invoke the model through the inference profile (bedrock:InvokeModel*)
     *
     * Note: This does not grant permissions to use the underlying model directly.
     * For comprehensive permissions, use grantInvoke() instead.
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantProfileUsage(grantee: IGrantable): Grant;
}
