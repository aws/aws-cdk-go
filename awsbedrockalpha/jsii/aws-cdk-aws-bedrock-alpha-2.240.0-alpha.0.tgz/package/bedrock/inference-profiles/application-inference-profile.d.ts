import * as bedrock from 'aws-cdk-lib/aws-bedrock';
import type { IGrantable } from 'aws-cdk-lib/aws-iam';
import { Grant } from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import type { IInferenceProfile } from './inference-profile';
import { InferenceProfileBase, InferenceProfileType } from './inference-profile';
import type { IBedrockInvokable } from '../models';
/******************************************************************************
 *                        PROPS FOR NEW CONSTRUCT
 *****************************************************************************/
/**
 * Properties for creating an Application Inference Profile.
 */
export interface ApplicationInferenceProfileProps {
    /**
     * The name of the application inference profile.
     * This name will be used to identify the inference profile in the AWS console and APIs.
     * - Required:  Yes
     * - Maximum length: 64 characters
     * - Pattern: `^([0-9a-zA-Z:.][ _-]?)+$`
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-applicationinferenceprofile.html#cfn-bedrock-applicationinferenceprofile-inferenceprofilename
     */
    readonly applicationInferenceProfileName: string;
    /**
     * Description of the inference profile.
     * Provides additional context about the purpose and usage of this inference profile.
     *
     * - Maximum length: 200 characters when provided
     * - Pattern: `^([0-9a-zA-Z:.][ _-]?)+$`
     * @default - No description is provided
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-applicationinferenceprofile.html#cfn-bedrock-applicationinferenceprofile-description
     */
    readonly description?: string;
    /**
     * The model source for this inference profile.
     *
     * To create an application inference profile for one Region, specify a foundation model.
     * Usage and costs for requests made to that Region with that model will be tracked.
     *
     * To create an application inference profile for multiple Regions,
     * specify a cross region (system-defined) inference profile.
     * The inference profile will route requests to the Regions defined in
     * the cross region (system-defined) inference profile that you choose.
     * Usage and costs for requests made to the Regions in the inference profile will be tracked.
     *
     */
    readonly modelSource: IBedrockInvokable;
    /**
     * A list of tags associated with the inference profile.
     * Tags help you organize and categorize your AWS resources.
     *
     * @default - No tags are applied
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/******************************************************************************
 *                      ATTRS FOR IMPORTED CONSTRUCT
 *****************************************************************************/
/**
 * Attributes for specifying an imported Application Inference Profile.
 */
export interface ApplicationInferenceProfileAttributes {
    /**
     * The ARN of the application inference profile.
     * @attribute
     */
    readonly inferenceProfileArn: string;
    /**
     * The ID or Amazon Resource Name (ARN) of the inference profile.
     * This can be either the profile ID or the full ARN.
     * @attribute
     */
    readonly inferenceProfileIdentifier: string;
}
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create an Application Inference Profile with CDK.
 * These are inference profiles created by users (user defined).
 * This helps to track costs and model usage.
 *
 * Application inference profiles are user-defined profiles that help you track costs and model usage.
 * They can be created for a single region or for multiple regions using a cross-region inference profile.
 *
 * @cloudformationResource AWS::Bedrock::ApplicationInferenceProfile
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/inference-profiles-create.html
 */
export declare class ApplicationInferenceProfile extends InferenceProfileBase implements IBedrockInvokable {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import an Application Inference Profile given its attributes.
     * [disable-awslint:no-grants]
     *
     * @param scope - The construct scope
     * @param id - Identifier of the construct
     * @param attrs - Attributes of the existing application inference profile
     * @returns An IInferenceProfile reference to the existing application inference profile
     */
    static fromApplicationInferenceProfileAttributes(scope: Construct, id: string, attrs: ApplicationInferenceProfileAttributes): IInferenceProfile;
    /**
     * Import a low-level L1 Cfn Application Inference Profile.
     * [disable-awslint:no-grants]
     *
     * @param cfnApplicationInferenceProfile - The L1 CfnApplicationInferenceProfile to import
     * @returns An IInferenceProfile reference to the imported application inference profile
     */
    static fromCfnApplicationInferenceProfile(cfnApplicationInferenceProfile: bedrock.CfnApplicationInferenceProfile): IInferenceProfile;
    /**
     * The name of the application inference profile.
     */
    readonly inferenceProfileName: string;
    /**
     * The ARN of the application inference profile.
     * @attribute
     */
    readonly inferenceProfileArn: string;
    /**
     * The unique identifier of the application inference profile.
     * @attribute
     */
    readonly inferenceProfileId: string;
    /**
     * The underlying model/cross-region model used by the application inference profile.
     */
    readonly inferenceProfileModel: IBedrockInvokable;
    /**
     * The status of the application inference profile. ACTIVE means that the inference profile is ready to be used.
     * @attribute
     */
    readonly status: string;
    /**
     * The type of the inference profile. Always APPLICATION for application inference profiles.
     */
    readonly type: InferenceProfileType;
    /**
     * Time Stamp for Application Inference Profile creation.
     * @attribute
     */
    readonly createdAt: string;
    /**
     * Time Stamp for Application Inference Profile update.
     * @attribute
     */
    readonly updatedAt: string;
    /**
     * The ARN used for invoking this inference profile.
     * This equals to the inferenceProfileArn property, useful for implementing IBedrockInvokable interface.
     */
    readonly invokableArn: string;
    /**
     * Instance of CfnApplicationInferenceProfile.
     * @internal
     */
    private readonly __resource;
    constructor(scope: Construct, id: string, props: ApplicationInferenceProfileProps);
    /**
     * Validates the properties for creating an Application Inference Profile.
     *
     * @param props - The properties to validate
     * @throws ValidationError if any validation fails
     */
    private validateProps;
    /**
     * Gives the appropriate policies to invoke and use the application inference profile.
     * This method ensures the appropriate permissions are given to use either the inference profile
     * or the underlying foundation model/cross-region profile.
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantInvoke(grantee: IGrantable): Grant;
    /**
     * Grants appropriate permissions to use the application inference profile (AIP).
     * This method adds the necessary IAM permissions to allow the grantee to:
     * - Get inference profile details (bedrock:GetInferenceProfile)
     * - Invoke the model through the inference profile (bedrock:InvokeModel)
     *
     * Note: This does not grant permissions to use the underlying model/cross-region profile in the AIP.
     * For comprehensive permissions, use grantInvoke() instead.
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantProfileUsage(grantee: IGrantable): Grant;
}
