import type { IResource } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { Construct } from 'constructs';
import type { IGuardrail } from './guardrails';
/******************************************************************************
 *                              COMMON
 *****************************************************************************/
/**
 * Represents a Guardrail Version, either created with CDK or imported.
 */
export interface IGuardrailVersion extends IResource {
    /**
     * The Guardrail to which this version belongs.
     */
    readonly guardrail: IGuardrail;
    /**
     * The ID of the guardrail version.
     * @example "1"
     */
    readonly guardrailVersion: string;
}
/******************************************************************************
 *                        ABSTRACT BASE CLASS
 *****************************************************************************/
/**
 * Abstract base class for a Guardrail Version.
 * Contains methods and attributes valid for Guardrail Versions either created
 * with CDK or imported.
 */
export declare abstract class GuardrailVersionBase extends Resource implements IGuardrailVersion {
    abstract readonly guardrail: IGuardrail;
    abstract readonly guardrailVersion: string;
    constructor(scope: Construct, id: string);
}
/******************************************************************************
 *                        PROPS FOR NEW CONSTRUCT
 *****************************************************************************/
/**
 * Properties for creating a CDK-Managed Guardrail Version.
 */
/**
 * Properties for creating a Guardrail Version.
 */
export interface GuardrailVersionProps {
    /**
     * The guardrail to create a version for.
     */
    readonly guardrail: IGuardrail;
    /**
     * The description of the guardrail version.
     *
     * @example "This is a description of the guardrail version."
     * @default - No description is provided.
     */
    readonly description?: string;
}
/******************************************************************************
 *                      ATTRS FOR IMPORTED CONSTRUCT
 *****************************************************************************/
/**
 * Attributes needed to create an import
 */
export interface GuardrailVersionAttributes {
    /**
     * The ARN of the guardrail.
     */
    readonly guardrailArn: string;
    /**
     * The ID of the guardrail version.
     * @example "1"
     */
    readonly guardrailVersion: string;
}
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create a Guardrail Version with CDK.
 * @cloudformationResource AWS::Bedrock::GuardrailVersion
 */
export declare class GuardrailVersion extends GuardrailVersionBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import a Guardrail Version from its attributes.
     */
    static fromGuardrailVersionAttributes(scope: Construct, id: string, attrs: GuardrailVersionAttributes): IGuardrailVersion;
    readonly guardrail: IGuardrail;
    readonly guardrailVersion: string;
    /**
     * The underlying CfnGuardrailVersion resource.
     */
    private readonly _resource;
    /**
     *
     */
    constructor(scope: Construct, id: string, props: GuardrailVersionProps);
}
