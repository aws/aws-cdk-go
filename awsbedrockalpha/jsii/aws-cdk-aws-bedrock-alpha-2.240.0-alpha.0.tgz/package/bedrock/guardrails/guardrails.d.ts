import type { IResource } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import * as bedrock from 'aws-cdk-lib/aws-bedrock';
import type { MetricOptions } from 'aws-cdk-lib/aws-cloudwatch';
import { Metric } from 'aws-cdk-lib/aws-cloudwatch';
import * as iam from 'aws-cdk-lib/aws-iam';
import type { IKey } from 'aws-cdk-lib/aws-kms';
import type { Construct } from 'constructs';
import * as filters from './guardrail-filters';
/******************************************************************************
 *                              COMMON
 *****************************************************************************/
/**
 * GuardrailCrossRegionConfigProperty
 */
export interface GuardrailCrossRegionConfigProperty {
    /**
     * The arn of thesystem-defined guardrail profile that you're using with your guardrail.
     * Guardrail profiles define the destination AWS Regions where guardrail inference requests can be automatically routed.
     * Using guardrail profiles helps maintain guardrail performance and reliability when demand increases.
     * @default - No cross-region configuration
     */
    readonly guardrailProfileArn: string;
}
/**
 * Represents a Guardrail, either created with CDK or imported.
 */
export interface IGuardrail extends IResource {
    /**
     * The ARN of the guardrail.
     * @attribute
     */
    readonly guardrailArn: string;
    /**
     * The ID of the guardrail.
     * @attribute
     */
    readonly guardrailId: string;
    /**
     * Optional KMS encryption key associated with this guardrail
     */
    readonly kmsKey?: IKey;
    /**
     * When this guardrail was last updated.
     */
    readonly lastUpdated?: string;
    /**
     * The version of the guardrail. If no explicit version is created,
     * this will default to "DRAFT"
     * @attribute
     */
    readonly guardrailVersion: string;
    /**
     * Grant the given principal identity permissions to perform actions on this guardrail.
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grant the given identity permissions to apply the guardrail.
     */
    grantApply(grantee: iam.IGrantable): iam.Grant;
    /**
     * Return the given named metric for this guardrail.
     */
    metric(metricName: string, props?: MetricOptions): Metric;
    /**
     * Return the invocations metric for this guardrail.
     */
    metricInvocations(props?: MetricOptions): Metric;
    /**
     * Return the invocation latency metric for this guardrail.
     */
    metricInvocationLatency(props?: MetricOptions): Metric;
    /**
     * Return the invocation client errors metric for this guardrail.
     */
    metricInvocationClientErrors(props?: MetricOptions): Metric;
    /**
     * Return the invocation server errors metric for this guardrail.
     */
    metricInvocationServerErrors(props?: MetricOptions): Metric;
    /**
     * Return the invocation throttles metric for this guardrail.
     */
    metricInvocationThrottles(props?: MetricOptions): Metric;
    /**
     * Return the text unit count metric for this guardrail.
     */
    metricTextUnitCount(props?: MetricOptions): Metric;
    /**
     * Return the invocations intervened metric for this guardrail.
     */
    metricInvocationsIntervened(props?: MetricOptions): Metric;
}
/**
 * Abstract base class for a Guardrail.
 * Contains methods and attributes valid for Guardrails either created with CDK or imported.
 */
export declare abstract class GuardrailBase extends Resource implements IGuardrail {
    /**
     * Return the given named metric for all guardrails.
     *
     * By default, the metric will be calculated as a sum over a period of 5 minutes.
     * You can customize this by using the `statistic` and `period` properties.
     */
    static metricAll(metricName: string, props?: MetricOptions): Metric;
    /**
     * Return the invocations metric for all guardrails.
     */
    static metricAllInvocations(props?: MetricOptions): Metric;
    /**
     * Return the text unit count metric for all guardrails.
     */
    static metricAllTextUnitCount(props?: MetricOptions): Metric;
    /**
     * Return the invocations intervened metric for all guardrails.
     */
    static metricAllInvocationsIntervened(props?: MetricOptions): Metric;
    /**
     * Return the invocation latency metric for all guardrails.
     */
    static metricAllInvocationLatency(props?: MetricOptions): Metric;
    private _version;
    /**
     * The ARN of the guardrail.
     * @attribute
     */
    abstract readonly guardrailArn: string;
    /**
     * The ID of the guardrail.
     * @attribute
     */
    abstract readonly guardrailId: string;
    /**
     * Optional KMS encryption key associated with this guardrail
     */
    abstract readonly kmsKey?: IKey;
    /**
     * When this guardrail was last updated.
     */
    abstract readonly lastUpdated?: string;
    /**
     * The version of the guardrail.
     * @attribute
     */
    get guardrailVersion(): string;
    protected updateVersion(version: string): void;
    /**
     * Grant the given principal identity permissions to perform actions on this guardrail.
     * [disable-awslint:no-grants]
     */
    grant(grantee: iam.IGrantable, ...actions: string[]): iam.Grant;
    /**
     * Grant the given identity permissions to apply the guardrail.
     * [disable-awslint:no-grants]
     */
    grantApply(grantee: iam.IGrantable): iam.Grant;
    /**
     * Return the given named metric for this guardrail.
     *
     * By default, the metric will be calculated as a sum over a period of 5 minutes.
     * You can customize this by using the `statistic` and `period` properties.
     */
    metric(metricName: string, props?: MetricOptions): Metric;
    /**
     * Return the invocations metric for this guardrail.
     */
    metricInvocations(props?: MetricOptions): Metric;
    /**
     * Return the invocation latency metric for this guardrail.
     */
    metricInvocationLatency(props?: MetricOptions): Metric;
    /**
     * Return the invocation client errors metric for this guardrail.
     */
    metricInvocationClientErrors(props?: MetricOptions): Metric;
    /**
     * Return the invocation server errors metric for this guardrail.
     */
    metricInvocationServerErrors(props?: MetricOptions): Metric;
    /**
     * Return the invocation throttles metric for this guardrail.
     */
    metricInvocationThrottles(props?: MetricOptions): Metric;
    /**
     * Return the text unit count metric for this guardrail.
     */
    metricTextUnitCount(props?: MetricOptions): Metric;
    /**
     * Return the invocations intervened metric for this guardrail.
     */
    metricInvocationsIntervened(props?: MetricOptions): Metric;
    private configureMetric;
}
/******************************************************************************
 *                        PROPS FOR NEW CONSTRUCT
 *****************************************************************************/
/**
 * Properties for creating a Guardrail.
 */
export interface GuardrailProps {
    /**
     * The name of the guardrail.
     * This will be used as the physical name of the guardrail.
     */
    readonly guardrailName: string;
    /**
     * The description of the guardrail.
     * @default - No description
     */
    readonly description?: string;
    /**
     * The message to return when the guardrail blocks a prompt.
     * Must be between 1 and 500 characters.
     * @default "Sorry, your query violates our usage policy."
     */
    readonly blockedInputMessaging?: string;
    /**
     * The message to return when the guardrail blocks a model response.
     * Must be between 1 and 500 characters.
     * @default "Sorry, I am unable to answer your question because of our usage policy."
     */
    readonly blockedOutputsMessaging?: string;
    /**
     * A custom KMS key to use for encrypting data.
     * @default - Data is encrypted by default with a key that AWS owns and manages for you
     */
    readonly kmsKey?: IKey;
    /**
     * The content filters to apply to the guardrail.
     * @default []
     */
    readonly contentFilters?: filters.ContentFilter[];
    /**
     * The tier configuration to apply to the guardrail.
     * @default filters.TierConfig.CLASSIC
     */
    readonly contentFiltersTierConfig?: filters.TierConfig;
    /**
     * A list of policies related to topics that the guardrail should deny.
     * @default []
     */
    readonly deniedTopics?: filters.Topic[];
    /**
     * The tier configuration to apply to the guardrail.
     * @default filters.TierConfig.CLASSIC
     */
    readonly topicsTierConfig?: filters.TierConfig;
    /**
     * The word filters to apply to the guardrail.
     * @default []
     */
    readonly wordFilters?: filters.WordFilter[];
    /**
     * The managed word filters to apply to the guardrail.
     * @default []
     */
    readonly managedWordListFilters?: filters.ManagedWordFilter[];
    /**
     * The PII filters to apply to the guardrail.
     * @default []
     */
    readonly piiFilters?: filters.PIIFilter[];
    /**
     * The regular expression (regex) filters to apply to the guardrail.
     * @default []
     */
    readonly regexFilters?: filters.RegexFilter[];
    /**
     * The contextual grounding filters to apply to the guardrail.
     * @default []
     */
    readonly contextualGroundingFilters?: filters.ContextualGroundingFilter[];
    /**
     * The cross-region configuration for the guardrail.
     * This is optional and when provided, it should be of type GuardrailCrossRegionConfigProperty.
     * @default - No cross-region configuration
     */
    readonly crossRegionConfig?: GuardrailCrossRegionConfigProperty;
}
/******************************************************************************
 *                      ATTRS FOR IMPORTED CONSTRUCT
 *****************************************************************************/
export interface GuardrailAttributes {
    /**
     * The ARN of the guardrail. At least one of guardrailArn or guardrailId must be
     * defined in order to initialize a guardrail ref.
     */
    readonly guardrailArn: string;
    /**
     * The KMS key of the guardrail if custom encryption is configured.
     *
     * @default undefined - Means data is encrypted by default with a AWS-managed key
     */
    readonly kmsKey?: IKey;
    /**
     * The version of the guardrail.
     *
     * @default "DRAFT"
     */
    readonly guardrailVersion?: string;
}
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create a Guardrail with CDK.
 * @cloudformationResource AWS::Bedrock::Guardrail
 */
export declare class Guardrail extends GuardrailBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Import a guardrail given its attributes
     */
    static fromGuardrailAttributes(scope: Construct, id: string, attrs: GuardrailAttributes): IGuardrail;
    /**
     * Import a low-level L1 Cfn Guardrail
     */
    static fromCfnGuardrail(cfnGuardrail: bedrock.CfnGuardrail): IGuardrail;
    /**
     * The ARN of the guardrail.
     * @attribute
     */
    readonly guardrailArn: string;
    /**
     * The ID of the guardrail.
     * @attribute
     */
    readonly guardrailId: string;
    /**
     * The name of the guardrail.
     */
    readonly name: string;
    /**
     * The KMS key used to encrypt data.
     *
     * @default undefined - "Data is encrypted by default with a key that AWS owns and manages for you"
     */
    readonly kmsKey?: IKey;
    /**
     * The content filters applied by the guardrail.
     */
    readonly contentFilters: filters.ContentFilter[];
    /**
     * The PII filters applied by the guardrail.
     */
    readonly piiFilters: filters.PIIFilter[];
    /**
     * The regex filters applied by the guardrail.
     */
    readonly regexFilters: filters.RegexFilter[];
    /**
     * The denied topic filters applied by the guardrail.
     */
    readonly deniedTopics: filters.Topic[];
    /**
     * The contextual grounding filters applied by the guardrail.
     */
    readonly contextualGroundingFilters: filters.ContextualGroundingFilter[];
    /**
     * The word filters applied by the guardrail.
     */
    readonly wordFilters: filters.WordFilter[];
    /**
     * The managed word list filters applied by the guardrail.
     */
    readonly managedWordListFilters: filters.ManagedWordFilter[];
    /**
     * When this guardrail was last updated
     */
    readonly lastUpdated?: string;
    /**
     * The computed hash of the guardrail properties.
     */
    readonly hash: string;
    /**
     * The L1 representation of the guardrail
     */
    private readonly __resource;
    /**
     * The tier that your guardrail uses for denied topic filters.
     * @default filters.TierConfig.CLASSIC
     */
    readonly topicsTierConfig: filters.TierConfig;
    /**
     * The tier that your guardrail uses for content filters.
     * Consider using a tier that balances performance, accuracy, and compatibility with your existing generative AI workflows.
     * @default filters.TierConfig.CLASSIC
     */
    readonly contentFiltersTierConfig: filters.TierConfig;
    /**
     * The cross-region configuration for the guardrail.
     */
    readonly crossRegionConfig?: GuardrailCrossRegionConfigProperty;
    /**
     * The message to return when the guardrail blocks a prompt.
     * @default "Sorry, your query violates our usage policy."
     */
    readonly blockedInputMessaging: string;
    /**
     * The message to return when the guardrail blocks a model response.
     * @default "Sorry, I am unable to answer your question because of our usage policy."
     */
    readonly blockedOutputsMessaging: string;
    constructor(scope: Construct, id: string, props: GuardrailProps);
    /**
     * Adds a content filter to the guardrail.
     * @param filter The content filter to add.
     */
    addContentFilter(filter: filters.ContentFilter): void;
    /**
     * Adds a PII filter to the guardrail.
     * @param filter The PII filter to add.
     */
    addPIIFilter(filter: filters.PIIFilter): void;
    /**
     * Adds a regex filter to the guardrail.
     * @param filter The regex filter to add.
     */
    addRegexFilter(filter: filters.RegexFilter): void;
    /**
     * Adds a denied topic filter to the guardrail.
     * @param filter The denied topic filter to add.
     */
    addDeniedTopicFilter(filter: filters.Topic): void;
    /**
     * Adds a contextual grounding filter to the guardrail.
     * @param filter The contextual grounding filter to add.
     */
    addContextualGroundingFilter(filter: filters.ContextualGroundingFilter): void;
    /**
     * Adds a word filter to the guardrail.
     * @param filter The word filter to add.
     */
    addWordFilter(filter: filters.WordFilter): void;
    /**
     * Adds a word filter to the guardrail.
     * @param filePath The location of the word filter file.
     */
    addWordFilterFromFile(filePath: string, inputAction?: filters.GuardrailAction, outputAction?: filters.GuardrailAction, inputEnabled?: boolean, outputEnabled?: boolean): void;
    /**
     * Adds a managed word list filter to the guardrail.
     * @param filter The managed word list filter to add.
     */
    addManagedWordListFilter(filter: filters.ManagedWordFilter): void;
    /**
     * Create a version for the guardrail.
     * @param description The description of the version.
     * @returns The guardrail version.
     */
    createVersion(description?: string): string;
    /**
     * Returns the content filters applied to the guardrail. This method defers the computation
     * to synth time.
     */
    private generateCfnContentPolicyConfig;
    /**
     * Returns the topic filters applied to the guardrail. This method defers the computation
     * to synth time.
     */
    private generateCfnTopicPolicy;
    /**
     * Returns the contectual filters applied to the guardrail. This method defers the computation
     * to synth time.
     */
    private generateCfnContextualPolicyConfig;
    /**
     * Returns the word config applied to the guardrail. This method defers the computation
     * to synth time.
     */
    private generateCfnWordPolicyConfig;
    /**
     * Returns the word filters applied to the guardrail. This method defers the computation
     * to synth time.
     */
    private generateCfnWordConfig;
    /**
     * Returns the word filters applied to the guardrail. This method defers the computation
     * to synth time.
     */
    private generateCfnManagedWordListsConfig;
    /**
     * Returns the sensitive information config applied to the guardrail. This method defers the computation
     * to synth time.
     */
    private generateCfnSensitiveInformationPolicyConfig;
    /**
     * Returns the regex filters applied to the guardrail. This method defers the computation
     * to synth time.
     */
    private generateCfnRegexesConfig;
    /**
     * Returns the Pii filters applied to the guardrail. This method defers the computation
     * to synth time.
     */
    private generateCfnPiiEntitiesConfig;
    /**
     * Returns the cross-region configuration for the guardrail. This method defers the computation
     * to synth time.
     */
    private generateCfnCrossRegionConfig;
    /**
     * Validates a RegexFilter object and applies default values for optional properties.
     * @param filter The regex filter to validate.
     * @param index Optional index for error messages when validating arrays.
     */
    private validateRegexFilter;
    /**
     * Validates a messaging property (blockedInputMessaging or blockedOutputsMessaging).
     * @param value The messaging value to validate.
     * @param propertyName The name of the property being validated.
     */
    private validateMessagingProperty;
    /**
     * Validates that cross-region configuration is provided when STANDARD tier is used.
     * @param props The guardrail properties to validate.
     */
    private validateTierConfiguration;
    /**
     * Validates content filters array and applies default values for optional properties.
     * @param contentFilters The content filters to validate.
     */
    private validateContentFilters;
    /**
     * Validates PII filters array and applies default values for optional properties.
     * @param piiFilters The PII filters to validate.
     */
    private validatePiiFilters;
    /**
     * Validates regex filters array.
     * @param regexFilters The regex filters to validate.
     */
    private validateRegexFilters;
    /**
     * Validates denied topics array and applies default values for optional properties.
     * @param deniedTopics The denied topics to validate.
     */
    private validateDeniedTopics;
    /**
     * Validates contextual grounding filters array and applies default values for optional properties.
     * @param contextualGroundingFilters The contextual grounding filters to validate.
     */
    private validateContextualGroundingFilters;
    /**
     * Validates word filters array and applies default values for optional properties.
     * @param wordFilters The word filters to validate.
     */
    private validateWordFilters;
    /**
     * Validates managed word list filters array and applies default values for optional properties.
     * @param managedWordListFilters The managed word list filters to validate.
     */
    private validateManagedWordListFilters;
    /**
     * Validates a single content filter and applies default values for optional properties.
     * @param filter The content filter to validate.
     */
    private validateSingleContentFilter;
    /**
     * Validates a single PII filter and applies default values for optional properties.
     * @param filter The PII filter to validate.
     */
    private validateSinglePiiFilter;
    /**
     * Validates a single regex filter and applies default values for optional properties.
     * @param filter The regex filter to validate.
     */
    private validateSingleRegexFilter;
    /**
     * Validates a single denied topic and applies default values for optional properties.
     * @param filter The denied topic to validate.
     */
    private validateSingleDeniedTopic;
    /**
     * Validates a single contextual grounding filter and applies default values for optional properties.
     * @param filter The contextual grounding filter to validate.
     */
    private validateSingleContextualGroundingFilter;
    /**
     * Validates a single word filter and applies default values for optional properties.
     * @param filter The word filter to validate.
     */
    private validateSingleWordFilter;
    /**
     * Validates a single managed word list filter and applies default values for optional properties.
     * @param filter The managed word list filter to validate.
     */
    private validateSingleManagedWordListFilter;
}
