/**
 * Guardrail action when a sensitive entity is detected.
 */
export declare enum GuardrailAction {
    /**
     * If sensitive information is detected in the prompt or response, the guardrail
     * blocks all the content and returns a message that you configure.
     */
    BLOCK = "BLOCK",
    /**
     * If sensitive information is detected in the model response, the guardrail masks
     * it with an identifier, the sensitive information is masked and replaced with
     * identifier tags (for example: [NAME-1], [NAME-2], [EMAIL-1], etc.).
     */
    ANONYMIZE = "ANONYMIZE",
    /**
     * Do not take any action.
     */
    NONE = "NONE"
}
/******************************************************************************
 *                             TIER CONFIG
*****************************************************************************/
export declare enum TierConfig {
    /**
     * Provides established guardrails functionality supporting English, French, and Spanish languages.
     */
    CLASSIC = "CLASSIC",
    /**
     * Provides a more robust solution than the CLASSIC tier and has more comprehensive language support. This tier requires that your guardrail use cross-Region inference.
     */
    STANDARD = "STANDARD"
}
/******************************************************************************
 *                             CONTENT FILTERS
 *****************************************************************************/
/**
 * The strength of the content filter. As you increase the filter strength,
 * the likelihood of filtering harmful content increases and the probability
 * of seeing harmful content in your application reduces.
 */
export declare enum ContentFilterStrength {
    /**
     * No content filtering applied.
     */
    NONE = "NONE",
    /**
     * Low strength content filtering - minimal filtering of harmful content.
     */
    LOW = "LOW",
    /**
     * Medium strength content filtering - balanced filtering of harmful content.
     */
    MEDIUM = "MEDIUM",
    /**
     * High strength content filtering - aggressive filtering of harmful content.
     */
    HIGH = "HIGH"
}
/**
 * The type of modality that can be used in content filters.
 */
export declare enum ModalityType {
    /**
     * Text modality for content filters.
     */
    TEXT = "TEXT",
    /**
     * Image modality for content filters.
     */
    IMAGE = "IMAGE"
}
/**
 * The type of harmful category usable in a content filter.
 */
export declare enum ContentFilterType {
    /**
     * Describes input prompts and model responses that indicates sexual interest, activity,
     * or arousal using direct or indirect references to body parts, physical traits, or sex.
     */
    SEXUAL = "SEXUAL",
    /**
     * Describes input prompts and model responses that includes glorification of or threats
     * to inflict physical pain, hurt, or injury toward a person, group or thing.
     */
    VIOLENCE = "VIOLENCE",
    /**
     * Describes input prompts and model responses that discriminate, criticize, insult,
     * denounce, or dehumanize a person or group on the basis of an identity (such as race,
     * ethnicity, gender, religion, sexual orientation, ability, and national origin).
     */
    HATE = "HATE",
    /**
     * Describes input prompts and model responses that includes demeaning, humiliating,
     * mocking, insulting, or belittling language. This type of language is also labeled
     * as bullying.
     */
    INSULTS = "INSULTS",
    /**
     * Describes input prompts and model responses that seeks or provides information
     * about engaging in misconduct activity, or harming, defrauding, or taking advantage
     * of a person, group or institution.
     */
    MISCONDUCT = "MISCONDUCT",
    /**
     * Enable to detect and block user inputs attempting to override system instructions.
     * To avoid misclassifying system prompts as a prompt attack and ensure that the filters
     * are selectively applied to user inputs, use input tagging.
     */
    PROMPT_ATTACK = "PROMPT_ATTACK"
}
/**
 * Interface to declare a content filter.
 */
export interface ContentFilter {
    /**
     * The type of harmful category that the content filter is applied to
     */
    readonly type: ContentFilterType;
    /**
     * The strength of the content filter to apply to prompts / user input.
     */
    readonly inputStrength: ContentFilterStrength;
    /**
     * The strength of the content filter to apply to model responses.
     */
    readonly outputStrength: ContentFilterStrength;
    /**
     * The action to take when content is detected in the input.
     * @default GuardrailAction.BLOCK
     */
    readonly inputAction?: GuardrailAction;
    /**
     * Whether the content filter is enabled for input.
     * @default true
     */
    readonly inputEnabled?: boolean;
    /**
     * The action to take when content is detected in the output.
     * @default GuardrailAction.BLOCK
     */
    readonly outputAction?: GuardrailAction;
    /**
     * Whether the content filter is enabled for output.
     * @default true
     */
    readonly outputEnabled?: boolean;
    /**
     * The input modalities to apply the content filter to.
     * @default undefined - Applies to text modality
     */
    readonly inputModalities?: ModalityType[];
    /**
     * The output modalities to apply the content filter to.
     * @default undefined - Applies to text modality
     */
    readonly outputModalities?: ModalityType[];
}
/******************************************************************************
   *                              TOPIC FILTERS
   *****************************************************************************/
/**
 * Interface for creating a custom Topic
 */
export interface CustomTopicProps {
    /**
     * The name of the topic to deny.
     */
    readonly name: string;
    /**
     * Provide a clear definition to detect and block user inputs and FM responses
     * that fall into this topic. Avoid starting with "don't".
     * @example `Investment advice refers to inquiries, guidance, or recommendations
     * regarding the management or allocation of funds or assets with the goal of
     * generating returns or achieving specific financial objectives.`
     */
    readonly definition: string;
    /**
     * Representative phrases that refer to the topic. These phrases can represent
     * a user input or a model response. Add between 1 and 100 phrases, up to 100 characters
     * each.
     * @example "Where should I invest my money?"
     */
    readonly examples: string[];
    /**
     * The action to take when a topic is detected in the input.
     * @default GuardrailAction.BLOCK
     */
    readonly inputAction?: GuardrailAction;
    /**
     * Whether the topic filter is enabled for input.
     * @default true
     */
    readonly inputEnabled?: boolean;
    /**
     * The action to take when a topic is detected in the output.
     * @default GuardrailAction.BLOCK
     */
    readonly outputAction?: GuardrailAction;
    /**
     * Whether the topic filter is enabled for output.
     * @default true
     */
    readonly outputEnabled?: boolean;
}
/**
 * Represents predefined topics that can be used to filter content.
 */
export declare class Topic {
    /**
     * Filter for financial advice and investment recommendations.
     */
    static readonly FINANCIAL_ADVICE: Topic;
    /**
     * Filter for inappropriate or explicit content.
     */
    static readonly INAPPROPRIATE_CONTENT: Topic;
    /**
     * Filter for legal advice and recommendations.
     */
    static readonly LEGAL_ADVICE: Topic;
    /**
     * Filter for medical advice and health recommendations.
     */
    static readonly MEDICAL_ADVICE: Topic;
    /**
     * Filter for political advice and recommendations.
     */
    static readonly POLITICAL_ADVICE: Topic;
    /**
     * Create a custom topic filter.
     * @param props Properties for the custom topic filter
     */
    static custom(props: CustomTopicProps): Topic;
    /**
     * The name of the topic to deny.
     */
    readonly name: string;
    /**
     * Definition of the topic.
     */
    readonly definition: string;
    /**
     * Representative phrases that refer to the topic.
     */
    readonly examples?: string[];
    /**
     * The action to take when a topic is detected in the input.
     * @default GuardrailAction.BLOCK
     */
    readonly inputAction?: GuardrailAction;
    /**
     * Whether the topic filter is enabled for input.
     * @default true
     */
    readonly inputEnabled?: boolean;
    /**
     * The action to take when a topic is detected in the output.
     * @default GuardrailAction.BLOCK
     */
    readonly outputAction?: GuardrailAction;
    /**
     * Whether the topic filter is enabled for output.
     * @default true
     */
    readonly outputEnabled?: boolean;
    protected constructor(props: CustomTopicProps);
}
/******************************************************************************
   *                               WORD FILTERS
   *****************************************************************************/
/**
 * Interface to define a Word Filter.
 */
export interface WordFilter {
    /**
     * The text to filter.
     */
    readonly text: string;
    /**
     * The action to take when a word is detected in the input.
     * @default GuardrailAction.BLOCK
     */
    readonly inputAction?: GuardrailAction;
    /**
     * Whether the word filter is enabled for input.
     * @default true
     */
    readonly inputEnabled?: boolean;
    /**
     * The action to take when a word is detected in the output.
     * @default GuardrailAction.BLOCK
     */
    readonly outputAction?: GuardrailAction;
    /**
     * Whether the word filter is enabled for output.
     * @default true
     */
    readonly outputEnabled?: boolean;
}
/**
 * Managed word list filter types supported by Amazon Bedrock.
 */
export declare enum ManagedWordFilterType {
    /**
     * Filter for profanity and explicit language.
     */
    PROFANITY = "PROFANITY"
}
/**
 * Interface for managed word list filters.
 */
export interface ManagedWordFilter {
    /**
     * The type of managed word filter.
     * @default ManagedWordFilterType.PROFANITY
     */
    readonly type?: ManagedWordFilterType;
    /**
     * The action to take when a managed word is detected in the input.
     * @default GuardrailAction.BLOCK
     */
    readonly inputAction?: GuardrailAction;
    /**
     * Whether the managed word filter is enabled for input.
     * @default true
     */
    readonly inputEnabled?: boolean;
    /**
     * The action to take when a managed word is detected in the output.
     * @default GuardrailAction.BLOCK
     */
    readonly outputAction?: GuardrailAction;
    /**
     * Whether the managed word filter is enabled for output.
     * @default true
     */
    readonly outputEnabled?: boolean;
}
/******************************************************************************
   *                   SENSITIVE INFORMATION FILTERS - PII
   *****************************************************************************/
/**
 * Abstract base class for all PII types.
 */
export declare abstract class PIIType {
    /**
     * The string value of the PII type.
     */
    readonly value: string;
    /**
     * The string value of the PII type.
     */
    protected constructor(value: string);
    /**
     * Returns the string representation of the PII type.
     * @returns The string value of the PII type.
     */
    toString(): string;
}
/**
 * Types of PII that are general, and not domain-specific.
 */
export declare class GeneralPIIType extends PIIType {
    /**
     * A physical address, such as "100 Main Street, Anytown, USA" or "Suite #12,
     * Building 123". An address can include information such as the street, building,
     * location, city, state, country, county, zip code, precinct, and neighborhood.
     */
    static readonly ADDRESS: GeneralPIIType;
    /**
     * An individual's age, including the quantity and unit of time.
     */
    static readonly AGE: GeneralPIIType;
    /**
     * The number assigned to a driver's license, which is an official document
     * permitting an individual to operate one or more motorized vehicles on a
     * public road. A driver's license number consists of alphanumeric characters.
     */
    static readonly DRIVER_ID: GeneralPIIType;
    /**
     * An email address, such as marymajor@email.com.
     */
    static readonly EMAIL: GeneralPIIType;
    /**
     * A license plate for a vehicle is issued by the state or country where the
     * vehicle is registered. The format for passenger vehicles is typically five
     * to eight digits, consisting of upper-case letters and numbers. The format
     * varies depending on the location of the issuing state or country.
     */
    static readonly LICENSE_PLATE: GeneralPIIType;
    /**
     * An individual's name. This entity type does not include titles, such as Dr.,
     *  Mr., Mrs., or Miss.
     */
    static readonly NAME: GeneralPIIType;
    /**
     * An alphanumeric string that is used as a password, such as "*very20special#pass*".
     */
    static readonly PASSWORD: GeneralPIIType;
    /**
     * A phone number. This entity type also includes fax and pager numbers.
     */
    static readonly PHONE: GeneralPIIType;
    /**
     * A user name that identifies an account, such as a login name, screen name,
     * nick name, or handle.
     */
    static readonly USERNAME: GeneralPIIType;
    /**
     * A Vehicle Identification Number (VIN) uniquely identifies a vehicle. VIN
     * content and format are defined in the ISO 3779 specification. Each country
     * has specific codes and formats for VINs.
     */
    static readonly VEHICLE_IDENTIFICATION_NUMBER: GeneralPIIType;
    private constructor();
}
/**
 * Types of PII in the domain of Finance.
 */
export declare class FinancePIIType extends PIIType {
    /**
     * A three-digit card verification code (CVV) that is present on VISA, MasterCard,
     * and Discover credit and debit cards. For American Express credit or debit cards,
     * the CVV is a four-digit numeric code.
     */
    static readonly CREDIT_DEBIT_CARD_CVV: FinancePIIType;
    /**
     * The expiration date for a credit or debit card. This number is usually four digits
     * long and is often formatted as month/year or MM/YY. Guardrails recognizes expiration
     * dates such as 01/21, 01/2021, and Jan 2021.
     */
    static readonly CREDIT_DEBIT_CARD_EXPIRY: FinancePIIType;
    /**
     * The number for a credit or debit card. These numbers can vary from 13 to 16 digits
     * in length.
     */
    static readonly CREDIT_DEBIT_CARD_NUMBER: FinancePIIType;
    /**
     * A four-digit personal identification number (PIN) with which you can access your
     * bank account.
     */
    static readonly PIN: FinancePIIType;
    /**
     * A SWIFT code is a standard format of Bank Identifier Code (BIC) used to specify a
     * particular bank or branch. Banks use these codes for money transfers such as
     * international wire transfers. SWIFT codes consist of eight or 11 characters.
     */
    static readonly SWIFT_CODE: FinancePIIType;
    /**
     * An International Bank Account Number (IBAN). It has specific formats in each country.
     */
    static readonly INTERNATIONAL_BANK_ACCOUNT_NUMBER: FinancePIIType;
    private constructor();
}
/**
 * Types of PII in the domain of IT (Information Technology).
 */
export declare class InformationTechnologyPIIType extends PIIType {
    /**
     * A web address, such as www.example.com.
     */
    static readonly URL: InformationTechnologyPIIType;
    /**
     * An IPv4 address, such as 198.51.100.0.
     */
    static readonly IP_ADDRESS: InformationTechnologyPIIType;
    /**
     * A media access control (MAC) address assigned to a network interface.
     */
    static readonly MAC_ADDRESS: InformationTechnologyPIIType;
    /**
     * A unique identifier that's associated with a secret access key. You use
     * the access key ID and secret access key to sign programmatic AWS requests
     * cryptographically.
     */
    static readonly AWS_ACCESS_KEY: InformationTechnologyPIIType;
    /**
     * A unique identifier that's associated with a secret access key. You use
     * the access key ID and secret access key to sign programmatic AWS requests
     * cryptographically.
     */
    static readonly AWS_SECRET_KEY: InformationTechnologyPIIType;
    private constructor();
}
/**
 * Types of PII specific to the USA.
 */
export declare class USASpecificPIIType extends PIIType {
    /**
     * A US bank account number, which is typically 10 to 12 digits long.
     */
    static readonly US_BANK_ACCOUNT_NUMBER: USASpecificPIIType;
    /**
     * A US bank account routing number. These are typically nine digits long.
     */
    static readonly US_BANK_ROUTING_NUMBER: USASpecificPIIType;
    /**
     * A US Individual Taxpayer Identification Number (ITIN) is a nine-digit number
     * that starts with a "9" and contain a "7" or "8" as the fourth digit.
     */
    static readonly US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER: USASpecificPIIType;
    /**
     * A US passport number. Passport numbers range from six to nine alphanumeric characters.
     */
    static readonly US_PASSPORT_NUMBER: USASpecificPIIType;
    /**
     * A US Social Security Number (SSN) is a nine-digit number that is issued to US citizens,
     * permanent residents, and temporary working residents.
     */
    static readonly US_SOCIAL_SECURITY_NUMBER: USASpecificPIIType;
    private constructor();
}
/**
 * Types of PII specific to Canada.
 */
export declare class CanadaSpecificPIIType extends PIIType {
    /**
     * A Canadian Health Service Number is a 10-digit unique identifier,
     * required for individuals to access healthcare benefits.
     */
    static readonly CA_HEALTH_NUMBER: CanadaSpecificPIIType;
    /**
     * A Canadian Social Insurance Number (SIN) is a nine-digit unique identifier,
     * required for individuals to access government programs and benefits.
     */
    static readonly CA_SOCIAL_INSURANCE_NUMBER: CanadaSpecificPIIType;
    private constructor();
}
/**
 * Types of PII specific to the United Kingdom (UK).
 */
export declare class UKSpecificPIIType extends PIIType {
    /**
     * A UK National Health Service Number is a 10-17 digit number, such as 485 777 3456.
     */
    static readonly UK_NATIONAL_HEALTH_SERVICE_NUMBER: UKSpecificPIIType;
    /**
     * A UK National Insurance Number (NINO) provides individuals with access to National
     * Insurance (social security) benefits. It is also used for some purposes in the UK
     * tax system.
     */
    static readonly UK_NATIONAL_INSURANCE_NUMBER: UKSpecificPIIType;
    /**
     * A UK Unique Taxpayer Reference (UTR) is a 10-digit number that identifies a
     * taxpayer or a business.
     */
    static readonly UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER: UKSpecificPIIType;
    private constructor();
}
/**
 * Interface to define a PII Filter.
 */
export interface PIIFilter {
    /**
     * The type of PII to filter.
     */
    readonly type: PIIType;
    /**
     * The action to take when PII is detected.
     */
    readonly action: GuardrailAction;
    /**
     * The action to take when PII is detected in the input.
     * @default GuardrailAction.BLOCK
     */
    readonly inputAction?: GuardrailAction;
    /**
     * Whether the PII filter is enabled for input.
     * @default true
     */
    readonly inputEnabled?: boolean;
    /**
     * The action to take when PII is detected in the output.
     * @default GuardrailAction.BLOCK
     */
    readonly outputAction?: GuardrailAction;
    /**
     * Whether the PII filter is enabled for output.
     * @default true
     */
    readonly outputEnabled?: boolean;
}
/******************************************************************************
   *                  SENSITIVE INFORMATION FILTERS - REGEX
   *****************************************************************************/
/**
 * A Regular expression (regex) filter for sensitive information.
 *
 */
export interface RegexFilter {
    /**
     * The name of the regex filter.
     */
    readonly name: string;
    /**
     * The description of the regex filter.
     * @default - No description
     */
    readonly description?: string;
    /**
     * The action to take when a regex match is detected.
     */
    readonly action: GuardrailAction;
    /**
     * The action to take when a regex match is detected in the input.
     * @default GuardrailAction.BLOCK
     */
    readonly inputAction?: GuardrailAction;
    /**
     * Whether the regex filter is enabled for input.
     * @default true
     */
    readonly inputEnabled?: boolean;
    /**
     * The action to take when a regex match is detected in the output.
     * @default GuardrailAction.BLOCK
     */
    readonly outputAction?: GuardrailAction;
    /**
     * Whether the regex filter is enabled for output.
     * @default true
     */
    readonly outputEnabled?: boolean;
    /**
     * The regular expression pattern to match.
     */
    readonly pattern: string;
}
/******************************************************************************
   *                      CONTEXTUAL GROUNDING FILTERS
   *****************************************************************************/
/**
 * The type of contextual grounding filter.
 */
export declare enum ContextualGroundingFilterType {
    /**
     * Grounding score represents the confidence that the model response is factually
     * correct and grounded in the source. If the model response has a lower score than
     * the defined threshold, the response will be blocked and the configured blocked
     * message will be returned to the user. A higher threshold level blocks more responses.
     */
    GROUNDING = "GROUNDING",
    /**
     * Relevance score represents the confidence that the model response is relevant
     * to the user's query. If the model response has a lower score than the defined
     * threshold, the response will be blocked and the configured blocked message will
     * be returned to the user. A higher threshold level blocks more responses.
     */
    RELEVANCE = "RELEVANCE"
}
/**
 * Interface to define a Contextual Grounding Filter.
 */
export interface ContextualGroundingFilter {
    /**
     * The type of contextual grounding filter.
     */
    readonly type: ContextualGroundingFilterType;
    /**
     * The action to take when contextual grounding is detected.
     * @default GuardrailAction.BLOCK
     */
    readonly action?: GuardrailAction;
    /**
     * Whether the contextual grounding filter is enabled.
     * @default true
     */
    readonly enabled?: boolean;
    /**
     * The threshold for the contextual grounding filter.
     * - `0` (blocks nothing)
     * - `0.99` (blocks almost everything)
     */
    readonly threshold: number;
}
