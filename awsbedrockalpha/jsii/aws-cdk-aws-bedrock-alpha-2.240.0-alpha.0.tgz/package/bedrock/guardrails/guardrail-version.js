"use strict";
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GuardrailVersion = exports.GuardrailVersionBase = void 0;
const aws_cdk_lib_1 = require("aws-cdk-lib");
const aws_bedrock_1 = require("aws-cdk-lib/aws-bedrock");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
const guardrails_1 = require("./guardrails");
/******************************************************************************
 *                        ABSTRACT BASE CLASS
 *****************************************************************************/
/**
 * Abstract base class for a Guardrail Version.
 * Contains methods and attributes valid for Guardrail Versions either created
 * with CDK or imported.
 */
class GuardrailVersionBase extends aws_cdk_lib_1.Resource {
    constructor(scope, id) {
        super(scope, id);
    }
}
exports.GuardrailVersionBase = GuardrailVersionBase;
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create a Guardrail Version with CDK.
 * @cloudformationResource AWS::Bedrock::GuardrailVersion
 */
let GuardrailVersion = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = GuardrailVersionBase;
    var GuardrailVersion = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            GuardrailVersion = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.GuardrailVersion';
        /**
         * Import a Guardrail Version from its attributes.
         */
        static fromGuardrailVersionAttributes(scope, id, attrs) {
            class Import extends GuardrailVersionBase {
                guardrail = guardrails_1.Guardrail.fromGuardrailAttributes(scope, `Guardrail-${id}`, {
                    guardrailArn: attrs.guardrailArn,
                    guardrailVersion: attrs.guardrailVersion,
                });
                guardrailVersion = attrs.guardrailVersion;
            }
            return new Import(scope, id);
        }
        guardrail;
        guardrailVersion;
        /**
         * The underlying CfnGuardrailVersion resource.
         */
        _resource;
        /**
         *
         */
        constructor(scope, id, props) {
            super(scope, id);
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            this.guardrail = props.guardrail;
            // Compute hash from guardrail, to recreate the resource when guardrail has changed
            const hash = (0, helpers_internal_1.md5hash)(props.guardrail.lastUpdated ?? 'Default');
            this._resource = new aws_bedrock_1.CfnGuardrailVersion(this, `GuardrailVersion-${hash.slice(0, 16)}`, {
                guardrailIdentifier: this.guardrail.guardrailId,
                description: props.description,
            });
            this.guardrailVersion = this._resource.attrVersion;
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return GuardrailVersion = _classThis;
})();
exports.GuardrailVersion = GuardrailVersion;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3VhcmRyYWlsLXZlcnNpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJndWFyZHJhaWwtdmVyc2lvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsNkNBQXVDO0FBQ3ZDLHlEQUE4RDtBQUM5RCw0RUFBZ0U7QUFDaEUsOEVBQThFO0FBQzlFLDBFQUEwRTtBQUkxRSw2Q0FBeUM7QUFxQnpDOzsrRUFFK0U7QUFFL0U7Ozs7R0FJRztBQUNILE1BQXNCLG9CQUFxQixTQUFRLHNCQUFRO0lBR3pELFlBQVksS0FBZ0IsRUFBRSxFQUFVO1FBQ3RDLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7S0FDbEI7Q0FDRjtBQU5ELG9EQU1DO0FBMkNEOzsrRUFFK0U7QUFDL0U7OztHQUdHO0lBRVUsZ0JBQWdCOzRCQUQ1QixvQ0FBa0I7Ozs7c0JBQ21CLG9CQUFvQjtnQ0FBNUIsU0FBUSxXQUFvQjs7OztZQUExRCw2S0FnREM7Ozs7UUEvQ0Msc0NBQXNDO1FBQy9CLE1BQU0sQ0FBVSxxQkFBcUIsR0FBVyw2Q0FBNkMsQ0FBQztRQUVyRzs7V0FFRztRQUNJLE1BQU0sQ0FBQyw4QkFBOEIsQ0FDMUMsS0FBZ0IsRUFDaEIsRUFBVSxFQUNWLEtBQWlDO1lBRWpDLE1BQU0sTUFBTyxTQUFRLG9CQUFvQjtnQkFDdkIsU0FBUyxHQUFHLHNCQUFTLENBQUMsdUJBQXVCLENBQUMsS0FBSyxFQUFFLGFBQWEsRUFBRSxFQUFFLEVBQUU7b0JBQ3RGLFlBQVksRUFBRSxLQUFLLENBQUMsWUFBWTtvQkFDaEMsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLGdCQUFnQjtpQkFDekMsQ0FBQyxDQUFDO2dCQUNhLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQzthQUMzRDtZQUNELE9BQU8sSUFBSSxNQUFNLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQzlCO1FBRWUsU0FBUyxDQUFhO1FBQ3RCLGdCQUFnQixDQUFTO1FBQ3pDOztXQUVHO1FBQ2MsU0FBUyxDQUFzQjtRQUVoRDs7V0FFRztRQUNILFlBQVksS0FBZ0IsRUFBRSxFQUFVLEVBQUUsS0FBNEI7WUFDcEUsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNqQixtQ0FBbUM7WUFDbkMsSUFBQSx3Q0FBb0IsRUFBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBRWpDLG1GQUFtRjtZQUNuRixNQUFNLElBQUksR0FBRyxJQUFBLDBCQUFPLEVBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxXQUFXLElBQUksU0FBUyxDQUFDLENBQUM7WUFFL0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLGlDQUFtQixDQUFDLElBQUksRUFBRSxvQkFBb0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDdEYsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXO2dCQUMvQyxXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVc7YUFDL0IsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDO1NBQ3BEOztZQS9DVSx1REFBZ0I7Ozs7O0FBQWhCLDRDQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgSVJlc291cmNlIH0gZnJvbSAnYXdzLWNkay1saWInO1xuaW1wb3J0IHsgUmVzb3VyY2UgfSBmcm9tICdhd3MtY2RrLWxpYic7XG5pbXBvcnQgeyBDZm5HdWFyZHJhaWxWZXJzaW9uIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHsgbWQ1aGFzaCB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2hlbHBlcnMtaW50ZXJuYWwnO1xuaW1wb3J0IHsgYWRkQ29uc3RydWN0TWV0YWRhdGEgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9tZXRhZGF0YS1yZXNvdXJjZSc7XG5pbXBvcnQgeyBwcm9wZXJ0eUluamVjdGFibGUgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9wcm9wLWluamVjdGFibGUnO1xuaW1wb3J0IHR5cGUgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcbi8vIEludGVybmFsIExpYnNcbmltcG9ydCB0eXBlIHsgSUd1YXJkcmFpbCB9IGZyb20gJy4vZ3VhcmRyYWlscyc7XG5pbXBvcnQgeyBHdWFyZHJhaWwgfSBmcm9tICcuL2d1YXJkcmFpbHMnO1xuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENPTU1PTlxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBSZXByZXNlbnRzIGEgR3VhcmRyYWlsIFZlcnNpb24sIGVpdGhlciBjcmVhdGVkIHdpdGggQ0RLIG9yIGltcG9ydGVkLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIElHdWFyZHJhaWxWZXJzaW9uIGV4dGVuZHMgSVJlc291cmNlIHtcbiAgLyoqXG4gICAqIFRoZSBHdWFyZHJhaWwgdG8gd2hpY2ggdGhpcyB2ZXJzaW9uIGJlbG9uZ3MuXG4gICAqL1xuICByZWFkb25seSBndWFyZHJhaWw6IElHdWFyZHJhaWw7XG5cbiAgLyoqXG4gICAqIFRoZSBJRCBvZiB0aGUgZ3VhcmRyYWlsIHZlcnNpb24uXG4gICAqIEBleGFtcGxlIFwiMVwiXG4gICAqL1xuICByZWFkb25seSBndWFyZHJhaWxWZXJzaW9uOiBzdHJpbmc7XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgQUJTVFJBQ1QgQkFTRSBDTEFTU1xuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG4vKipcbiAqIEFic3RyYWN0IGJhc2UgY2xhc3MgZm9yIGEgR3VhcmRyYWlsIFZlcnNpb24uXG4gKiBDb250YWlucyBtZXRob2RzIGFuZCBhdHRyaWJ1dGVzIHZhbGlkIGZvciBHdWFyZHJhaWwgVmVyc2lvbnMgZWl0aGVyIGNyZWF0ZWRcbiAqIHdpdGggQ0RLIG9yIGltcG9ydGVkLlxuICovXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgR3VhcmRyYWlsVmVyc2lvbkJhc2UgZXh0ZW5kcyBSZXNvdXJjZSBpbXBsZW1lbnRzIElHdWFyZHJhaWxWZXJzaW9uIHtcbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGd1YXJkcmFpbDogSUd1YXJkcmFpbDtcbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGd1YXJkcmFpbFZlcnNpb246IHN0cmluZztcbiAgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCk7XG4gIH1cbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBQUk9QUyBGT1IgTkVXIENPTlNUUlVDVFxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBjcmVhdGluZyBhIENESy1NYW5hZ2VkIEd1YXJkcmFpbCBWZXJzaW9uLlxuICovXG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgY3JlYXRpbmcgYSBHdWFyZHJhaWwgVmVyc2lvbi5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBHdWFyZHJhaWxWZXJzaW9uUHJvcHMge1xuICAvKipcbiAgICogVGhlIGd1YXJkcmFpbCB0byBjcmVhdGUgYSB2ZXJzaW9uIGZvci5cbiAgICovXG4gIHJlYWRvbmx5IGd1YXJkcmFpbDogSUd1YXJkcmFpbDtcbiAgLyoqXG4gICAqIFRoZSBkZXNjcmlwdGlvbiBvZiB0aGUgZ3VhcmRyYWlsIHZlcnNpb24uXG4gICAqXG4gICAqIEBleGFtcGxlIFwiVGhpcyBpcyBhIGRlc2NyaXB0aW9uIG9mIHRoZSBndWFyZHJhaWwgdmVyc2lvbi5cIlxuICAgKiBAZGVmYXVsdCAtIE5vIGRlc2NyaXB0aW9uIGlzIHByb3ZpZGVkLlxuICAgKi9cbiAgcmVhZG9ubHkgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgIEFUVFJTIEZPUiBJTVBPUlRFRCBDT05TVFJVQ1RcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogQXR0cmlidXRlcyBuZWVkZWQgdG8gY3JlYXRlIGFuIGltcG9ydFxuICovXG5leHBvcnQgaW50ZXJmYWNlIEd1YXJkcmFpbFZlcnNpb25BdHRyaWJ1dGVzIHtcbiAgLyoqXG4gICAqIFRoZSBBUk4gb2YgdGhlIGd1YXJkcmFpbC5cbiAgICovXG4gIHJlYWRvbmx5IGd1YXJkcmFpbEFybjogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIElEIG9mIHRoZSBndWFyZHJhaWwgdmVyc2lvbi5cbiAgICogQGV4YW1wbGUgXCIxXCJcbiAgICovXG4gIHJlYWRvbmx5IGd1YXJkcmFpbFZlcnNpb246IHN0cmluZztcbn1cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgTkVXIENPTlNUUlVDVCBERUZJTklUSU9OXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIENsYXNzIHRvIGNyZWF0ZSBhIEd1YXJkcmFpbCBWZXJzaW9uIHdpdGggQ0RLLlxuICogQGNsb3VkZm9ybWF0aW9uUmVzb3VyY2UgQVdTOjpCZWRyb2NrOjpHdWFyZHJhaWxWZXJzaW9uXG4gKi9cbkBwcm9wZXJ0eUluamVjdGFibGVcbmV4cG9ydCBjbGFzcyBHdWFyZHJhaWxWZXJzaW9uIGV4dGVuZHMgR3VhcmRyYWlsVmVyc2lvbkJhc2Uge1xuICAvKiogVW5pcXVlbHkgaWRlbnRpZmllcyB0aGlzIGNsYXNzLiAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFBST1BFUlRZX0lOSkVDVElPTl9JRDogc3RyaW5nID0gJ0Bhd3MtY2RrLmF3cy1iZWRyb2NrLWFscGhhLkd1YXJkcmFpbFZlcnNpb24nO1xuXG4gIC8qKlxuICAgKiBJbXBvcnQgYSBHdWFyZHJhaWwgVmVyc2lvbiBmcm9tIGl0cyBhdHRyaWJ1dGVzLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tR3VhcmRyYWlsVmVyc2lvbkF0dHJpYnV0ZXMoXG4gICAgc2NvcGU6IENvbnN0cnVjdCxcbiAgICBpZDogc3RyaW5nLFxuICAgIGF0dHJzOiBHdWFyZHJhaWxWZXJzaW9uQXR0cmlidXRlcyxcbiAgKTogSUd1YXJkcmFpbFZlcnNpb24ge1xuICAgIGNsYXNzIEltcG9ydCBleHRlbmRzIEd1YXJkcmFpbFZlcnNpb25CYXNlIHtcbiAgICAgIHB1YmxpYyByZWFkb25seSBndWFyZHJhaWwgPSBHdWFyZHJhaWwuZnJvbUd1YXJkcmFpbEF0dHJpYnV0ZXMoc2NvcGUsIGBHdWFyZHJhaWwtJHtpZH1gLCB7XG4gICAgICAgIGd1YXJkcmFpbEFybjogYXR0cnMuZ3VhcmRyYWlsQXJuLFxuICAgICAgICBndWFyZHJhaWxWZXJzaW9uOiBhdHRycy5ndWFyZHJhaWxWZXJzaW9uLFxuICAgICAgfSk7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgZ3VhcmRyYWlsVmVyc2lvbiA9IGF0dHJzLmd1YXJkcmFpbFZlcnNpb247XG4gICAgfVxuICAgIHJldHVybiBuZXcgSW1wb3J0KHNjb3BlLCBpZCk7XG4gIH1cblxuICBwdWJsaWMgcmVhZG9ubHkgZ3VhcmRyYWlsOiBJR3VhcmRyYWlsO1xuICBwdWJsaWMgcmVhZG9ubHkgZ3VhcmRyYWlsVmVyc2lvbjogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHVuZGVybHlpbmcgQ2ZuR3VhcmRyYWlsVmVyc2lvbiByZXNvdXJjZS5cbiAgICovXG4gIHByaXZhdGUgcmVhZG9ubHkgX3Jlc291cmNlOiBDZm5HdWFyZHJhaWxWZXJzaW9uO1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM6IEd1YXJkcmFpbFZlcnNpb25Qcm9wcykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCk7XG4gICAgLy8gRW5oYW5jZWQgQ0RLIEFuYWx5dGljcyBUZWxlbWV0cnlcbiAgICBhZGRDb25zdHJ1Y3RNZXRhZGF0YSh0aGlzLCBwcm9wcyk7XG4gICAgdGhpcy5ndWFyZHJhaWwgPSBwcm9wcy5ndWFyZHJhaWw7XG5cbiAgICAvLyBDb21wdXRlIGhhc2ggZnJvbSBndWFyZHJhaWwsIHRvIHJlY3JlYXRlIHRoZSByZXNvdXJjZSB3aGVuIGd1YXJkcmFpbCBoYXMgY2hhbmdlZFxuICAgIGNvbnN0IGhhc2ggPSBtZDVoYXNoKHByb3BzLmd1YXJkcmFpbC5sYXN0VXBkYXRlZCA/PyAnRGVmYXVsdCcpO1xuXG4gICAgdGhpcy5fcmVzb3VyY2UgPSBuZXcgQ2ZuR3VhcmRyYWlsVmVyc2lvbih0aGlzLCBgR3VhcmRyYWlsVmVyc2lvbi0ke2hhc2guc2xpY2UoMCwgMTYpfWAsIHtcbiAgICAgIGd1YXJkcmFpbElkZW50aWZpZXI6IHRoaXMuZ3VhcmRyYWlsLmd1YXJkcmFpbElkLFxuICAgICAgZGVzY3JpcHRpb246IHByb3BzLmRlc2NyaXB0aW9uLFxuICAgIH0pO1xuXG4gICAgdGhpcy5ndWFyZHJhaWxWZXJzaW9uID0gdGhpcy5fcmVzb3VyY2UuYXR0clZlcnNpb247XG4gIH1cbn1cbiJdfQ==