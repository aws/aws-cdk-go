import { Construct } from 'constructs';
import type { IPrompt } from './prompt';
/******************************************************************************
 *                        PROPS FOR NEW CONSTRUCT
 *****************************************************************************/
/**
 * Properties for creating a CDK managed Bedrock Prompt Version.
 */
export interface PromptVersionProps {
    /**
     * The prompt to use for this version.
     */
    readonly prompt: IPrompt;
    /**
     * The description of the prompt version.
     *
     * @default - No description provided.
     * Maximum length: 200
     */
    readonly description?: string;
}
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create a Prompt Version with CDK.
 *
 * Creates a version of the prompt. Use this to create a static snapshot of your
 * prompt that can be deployed to production. Versions allow you to easily switch
 * between different configurations for your prompt and update your application
 * with the most appropriate version for your use-case.
 *
 * @cloudformationResource AWS::Bedrock::PromptVersion
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/prompt-management-deploy.html
 */
export declare class PromptVersion extends Construct {
    /******************************************************************************
     *                              ATTRIBUTES
     *****************************************************************************/
    /**
     * The Amazon Resource Name (ARN) of the prompt version.
     * @attribute
     * @example "arn:aws:bedrock:us-east-1:123456789012:prompt/PROMPT12345:1"
     */
    readonly versionArn: string;
    /**
     * The prompt used by this version.
     */
    readonly prompt: IPrompt;
    /**
     * The version of the prompt that was created.
     * @attribute
     */
    readonly version: string;
    /**
     * The description of the prompt version.
     */
    readonly description?: string;
    /******************************************************************************
     *                            INTERNAL ONLY
     *****************************************************************************/
    /**
     * Instance of prompt version.
     * @internal
     */
    private readonly __resource;
    /******************************************************************************
     *                            CONSTRUCTOR
     *****************************************************************************/
    constructor(scope: Construct, id: string, props: PromptVersionProps);
    /******************************************************************************
     *                            VALIDATION METHODS
     *****************************************************************************/
    /**
     * Validates whether the description length is within the allowed limit (immediate validation).
     * @param description - The description to validate
     * @returns Array of validation error messages, empty if valid
     */
    private validateDescriptionImmediate;
    /**
     * Validates whether the description length is within the allowed limit.
     * @returns Array of validation error messages, empty if valid
     */
    private validateDescription;
}
