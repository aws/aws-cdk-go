import type * as bedrock from 'aws-cdk-lib/aws-bedrock';
import type { ChatMessage } from './chat-prompt-variant';
import type { ToolConfiguration } from './tool-choice';
/**
 * Properties for creating a text template configuration.
 */
export interface TextTemplateConfigurationProps {
    /**
     * The input variables for the template.
     *
     * @default - No input variables
     */
    readonly inputVariables?: string[];
    /**
     * The text content of the template.
     */
    readonly text: string;
}
/**
 * Properties for creating a chat template configuration.
 */
export interface ChatTemplateConfigurationProps {
    /**
     * The input variables for the template.
     *
     * @default - No input variables
     */
    readonly inputVariables?: string[];
    /**
     * The messages in the chat template.
     */
    readonly messages: ChatMessage[];
    /**
     * The system message for the chat template.
     *
     * @default - No system message
     */
    readonly system?: string;
    /**
     * The tool configuration for the chat template.
     *
     * @default - No tool configuration
     */
    readonly toolConfiguration?: ToolConfiguration;
}
/**
 * Abstract base class for prompt template configurations.
 *
 * This provides a high-level abstraction over the underlying CloudFormation
 * template configuration properties, offering a more developer-friendly interface
 * while maintaining full compatibility with the underlying AWS Bedrock service.
 */
export declare abstract class PromptTemplateConfiguration {
    /**
     * Creates a text template configuration.
     */
    static text(props: TextTemplateConfigurationProps): PromptTemplateConfiguration;
    /**
     * Creates a chat template configuration.
     */
    static chat(props: ChatTemplateConfigurationProps): PromptTemplateConfiguration;
    /**
     * Renders the template configuration as a CloudFormation property.
     * @internal This is an internal core function and should not be called directly.
     */
    abstract _render(): bedrock.CfnPrompt.PromptTemplateConfigurationProperty;
}
