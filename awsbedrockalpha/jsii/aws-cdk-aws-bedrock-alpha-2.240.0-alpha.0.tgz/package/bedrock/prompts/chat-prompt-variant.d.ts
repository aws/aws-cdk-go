import type { CfnPrompt } from 'aws-cdk-lib/aws-bedrock';
import type { PromptInferenceConfiguration } from './prompt-inference-configuration';
import type { CommonPromptVariantProps, IPromptVariant } from './prompt-variant';
import type { ToolConfiguration } from './tool-choice';
/**
 * Properties for creating a chat prompt variant.
 */
export interface ChatPromptVariantProps extends CommonPromptVariantProps {
    /**
     * The messages in the chat prompt.
     * Must include at least one User Message.
     * The messages should alternate between User and Assistant.
     */
    readonly messages: ChatMessage[];
    /**
     * Context or instructions for the model to consider before generating a response.
     *
     * @default - No system message provided.
     */
    readonly system?: string;
    /**
     * The configuration with available tools to the model and how it must use them.
     *
     * @default - No tool configuration provided.
     */
    readonly toolConfiguration?: ToolConfiguration;
    /**
     * Inference configuration for the Chat Prompt.
     *
     * @default - No inference configuration provided.
     */
    readonly inferenceConfiguration?: PromptInferenceConfiguration;
}
/**
 * The role of a message in a chat conversation.
 */
export declare enum ChatMessageRole {
    /**
     * This role represents the human user in the conversation. Inputs from the
     * user guide the conversation and prompt responses from the assistant.
     */
    USER = "user",
    /**
     * This is the role of the model itself, responding to user inputs based on
     * the context set by the system.
     */
    ASSISTANT = "assistant"
}
/**
 * Represents a message in a chat conversation.
 */
export declare class ChatMessage {
    /**
     * Creates a user message.
     *
     * @param text - The text content of the user message
     * @returns A ChatMessage instance representing a user message
     */
    static user(text: string): ChatMessage;
    /**
     * Creates an assistant message.
     *
     * @param text - The text content of the assistant message
     * @returns A ChatMessage instance representing an assistant message
     */
    static assistant(text: string): ChatMessage;
    /**
     * The role of the message sender.
     */
    readonly role: ChatMessageRole;
    /**
     * The text content of the message.
     */
    readonly text: string;
    constructor(role: ChatMessageRole, text: string);
    /**
     * Renders the message as a CloudFormation property.
     * @internal This is an internal core function and should not be called directly.
     */
    _render(): CfnPrompt.MessageProperty;
}
/**
 * Creates a chat template variant. Use this template type when
 * the model supports the Converse API or the Anthropic Claude Messages API.
 * This allows you to include a System prompt and previous User messages
 * and Assistant messages for context.
 *
 * @param props - Properties for the chat prompt variant
 * @returns A PromptVariant configured for chat interactions
 */
export declare function createChatPromptVariant(props: ChatPromptVariantProps): IPromptVariant;
