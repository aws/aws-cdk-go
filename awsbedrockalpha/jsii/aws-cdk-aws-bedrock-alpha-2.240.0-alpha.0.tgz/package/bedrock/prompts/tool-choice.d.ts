import type { CfnPrompt } from 'aws-cdk-lib/aws-bedrock';
/**
 * Configuration for tools available to the model.
 */
export interface ToolConfiguration {
    /**
     * How the model should choose which tool to use.
     */
    readonly toolChoice: ToolChoice;
    /**
     * The tools available to the model.
     */
    readonly tools: Tool[];
}
/**
 * Properties for creating a function tool.
 */
export interface FunctionToolProps {
    /**
     * The name of the function.
     */
    readonly name: string;
    /**
     * A description of what the function does.
     */
    readonly description: string;
    /**
     * The input schema for the function parameters.
     */
    readonly inputSchema: any;
}
/**
 * Abstract base class for tools that can be used by the model.
 */
export declare abstract class Tool {
    /**
     * Creates a function tool.
     */
    static function(props: FunctionToolProps): Tool;
    /**
     * Renders the tool as a CloudFormation property.
     * @internal This is an internal core function and should not be called directly.
     */
    abstract _render(): CfnPrompt.ToolProperty;
}
/**
 * Defines how the model should choose which tool to use.
 */
export declare class ToolChoice {
    /**
     * The model must request at least one tool (no text is generated).
     */
    static readonly ANY: ToolChoice;
    /**
     * (Default). The Model automatically decides if a tool should be called or whether to generate text instead.
     */
    static readonly AUTO: ToolChoice;
    /**
     * The Model must request the specified tool. Only supported by some models like Anthropic Claude 3 models.
     *
     * @param toolName - The name of the specific tool to use
     * @returns A ToolChoice instance configured for the specific tool
     */
    static specificTool(toolName: string): ToolChoice;
    /**
     * Configuration for ANY tool choice.
     */
    readonly any?: any;
    /**
     * Configuration for AUTO tool choice.
     */
    readonly auto?: any;
    /**
     * The specific tool name if using specific tool choice.
     */
    readonly tool?: string;
    constructor(any: any, auto: any, tool?: string);
    /**
     * Renders the tool choice as a CloudFormation property.
     * @internal This is an internal core function and should not be called directly.
     */
    _render(): CfnPrompt.ToolChoiceProperty;
}
