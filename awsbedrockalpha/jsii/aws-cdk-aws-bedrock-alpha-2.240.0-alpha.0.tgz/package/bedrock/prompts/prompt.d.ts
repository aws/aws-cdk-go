import * as iam from 'aws-cdk-lib/aws-iam';
import type * as kms from 'aws-cdk-lib/aws-kms';
import type { IResource } from 'aws-cdk-lib/core';
import { Resource } from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import type { IPromptVariant } from './prompt-variant';
import { PromptVersion } from './prompt-version';
/******************************************************************************
 *                              COMMON
 *****************************************************************************/
/**
 * Represents a Prompt, either created with CDK or imported.
 */
export interface IPrompt extends IResource {
    /**
     * The ARN of the prompt.
     * @attribute
     * @example "arn:aws:bedrock:us-east-1:123456789012:prompt/PROMPT12345"
     */
    readonly promptArn: string;
    /**
     * The ID of the prompt.
     * @attribute
     * @example "PROMPT12345"
     */
    readonly promptId: string;
    /**
     * The version of the prompt.
     * @attribute
     * @default "DRAFT"
     */
    readonly promptVersion: string;
    /**
     * Optional KMS encryption key associated with this prompt.
     */
    readonly kmsKey?: kms.IKey;
    /**
     * Grant the given identity permissions to get the prompt.
     */
    grantGet(grantee: iam.IGrantable): iam.Grant;
}
/******************************************************************************
 *                        ABSTRACT BASE CLASS
 *****************************************************************************/
/**
 * Abstract base class for a Prompt.
 * Contains methods and attributes valid for Prompts either created with CDK or imported.
 */
export declare abstract class PromptBase extends Resource implements IPrompt {
    abstract readonly promptArn: string;
    abstract readonly promptId: string;
    abstract readonly kmsKey?: kms.IKey;
    abstract readonly promptVersion: string;
    /**
     * Grant the given identity permissions to get the prompt.
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @default - Default grant configuration:
     * - actions: ['bedrock:GetPrompt']
     * - resourceArns: [this.promptArn]
     * @returns An IAM Grant object representing the granted permissions
     */
    grantGet(grantee: iam.IGrantable): iam.Grant;
}
/******************************************************************************
 *                        PROPS FOR NEW CONSTRUCT
 *****************************************************************************/
/**
 * Properties for creating a CDK managed Bedrock Prompt.
 */
export interface PromptProps {
    /**
     * The name of the prompt.
     * This will be used as the physical name of the prompt.
     * Allowed Pattern: ^([0-9a-zA-Z][_-]?){1,100}$
     */
    readonly promptName: string;
    /**
     * A description of what the prompt does.
     *
     * @default - No description provided.
     * Maximum Length: 200
     */
    readonly description?: string;
    /**
     * The KMS key that the prompt is encrypted with.
     *
     * @default - AWS owned and managed key.
     */
    readonly kmsKey?: kms.IKey;
    /**
     * The Prompt Variant that will be used by default.
     *
     * @default - No default variant provided.
     */
    readonly defaultVariant?: IPromptVariant;
    /**
     * The variants of your prompt. Variants can use different messages, models,
     * or configurations so that you can compare their outputs to decide the best
     * variant for your use case. Maximum of 1 variants.
     *
     * @default - No additional variants provided.
     */
    readonly variants?: IPromptVariant[];
    /**
     * Tags to apply to the prompt.
     *
     * @default - No tags applied.
     */
    readonly tags?: Record<string, string>;
}
/******************************************************************************
 *                      ATTRS FOR IMPORTED CONSTRUCT
 *****************************************************************************/
/**
 * Attributes for specifying an imported Bedrock Prompt.
 */
export interface PromptAttributes {
    /**
     * The ARN of the prompt.
     * @attribute
     * @example "arn:aws:bedrock:us-east-1:123456789012:prompt/PROMPT12345"
     */
    readonly promptArn: string;
    /**
     * Optional KMS encryption key associated with this prompt.
     * @default undefined - An AWS managed key is used
     */
    readonly kmsKey?: kms.IKey;
    /**
     * The version of the prompt.
     * @default "DRAFT"
     */
    readonly promptVersion?: string;
}
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create (or import) a Prompt with CDK.
 *
 * Prompts are a specific set of inputs that guide Foundation Models (FMs) on Amazon Bedrock to
 * generate an appropriate response or output for a given task or instruction.
 * You can optimize the prompt for specific use cases and models.
 *
 * @cloudformationResource AWS::Bedrock::Prompt
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/prompt-management.html
 */
export declare class Prompt extends PromptBase implements IPrompt {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /******************************************************************************
     *                            IMPORT METHODS
     *****************************************************************************/
    /**
     * Creates a Prompt reference from an existing prompt's attributes.
     *
     * @param scope - The construct scope
     * @param id - Identifier of the construct
     * @param attrs - Attributes of the existing prompt
     * @default - For attrs.promptVersion: 'DRAFT' if no explicit version is provided
     * @returns An IPrompt reference to the existing prompt
     */
    static fromPromptAttributes(scope: Construct, id: string, attrs: PromptAttributes): IPrompt;
    /**
     * The maximum number of variants allowed for a prompt.
     * @internal
     */
    private static readonly MAX_VARIANTS;
    /**
     * The name of the prompt.
     * @attribute
     */
    readonly promptName: string;
    /**
     * The KMS key that the prompt is encrypted with.
     */
    readonly kmsKey?: kms.IKey;
    /**
     * The ARN of the prompt.
     * @attribute
     * @example "arn:aws:bedrock:us-east-1:123456789012:prompt/PROMPT12345"
     */
    readonly promptArn: string;
    /**
     * The ID of the prompt.
     * @attribute
     * @example "PROMPT12345"
     */
    readonly promptId: string;
    /**
     * The version of the prompt.
     * @attribute
     */
    readonly promptVersion: string;
    /**
     * The variants of the prompt.
     */
    readonly variants: IPromptVariant[];
    /**
     * The description of the prompt.
     */
    readonly description?: string;
    /******************************************************************************
     *                            INTERNAL ONLY
     *****************************************************************************/
    /**
     * The computed hash of the prompt properties.
     * @internal
     */
    protected readonly _hash: string;
    /**
     * L1 resource
     * @internal
     */
    private readonly __resource;
    /******************************************************************************
     *                            CONSTRUCTOR
     *****************************************************************************/
    constructor(scope: Construct, id: string, props: PromptProps);
    /******************************************************************************
     *                            VALIDATION METHODS
     *****************************************************************************/
    /**
     * Validates whether the prompt name is valid according to the specification.
     * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-prompt.html#cfn-bedrock-prompt-name
     * @returns Array of validation error messages, empty if valid
     */
    private validatePromptName;
    /**
     * Validates whether the number of prompt variants is respected.
     * @returns Array of validation error messages, empty if valid
     */
    private validatePromptVariants;
    /**
     * Validates that if the prompt has a default, it was also added to the variants array
     * @param props - The properties set in the constructor
     */
    private validatePromptDefault;
    /**
     * Validates whether the description length is within the allowed limit.
     * @returns Array of validation error messages, empty if valid
     */
    private validateDescription;
    /**
     * Validates whether all variant names are unique.
     * @returns Array of validation error messages, empty if valid
     */
    private validateVariantNames;
    /******************************************************************************
     *                            HELPER METHODS
     *****************************************************************************/
    /**
     * Creates a prompt version, a static snapshot of your prompt that can be
     * deployed to production.
     *
     * @param description - Optional description for the version
     * @default - No description provided
     * @returns A PromptVersion object containing the version details including ARN and version string
     */
    createVersion(description?: string): PromptVersion;
    /**
     * Adds a prompt variant to the prompt.
     *
     * @param variant - The prompt variant to add
     * @throws ValidationError if adding the variant would exceed the maximum allowed variants
     */
    addVariant(variant: IPromptVariant): void;
    /**
     * Validates whether a variant can be added without exceeding limits.
     * @param variant - The variant to validate
     * @returns Array of validation error messages, empty if valid
     */
    private validateVariantAddition;
}
