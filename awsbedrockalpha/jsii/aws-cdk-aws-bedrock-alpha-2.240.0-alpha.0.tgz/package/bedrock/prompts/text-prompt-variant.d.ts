import type { PromptInferenceConfiguration } from './prompt-inference-configuration';
import type { CommonPromptVariantProps, IPromptVariant } from './prompt-variant';
/**
 * Properties for creating a text prompt variant.
 */
export interface TextPromptVariantProps extends CommonPromptVariantProps {
    /**
     * Inference configuration for the Text Prompt.
     *
     * @default - No inference configuration provided.
     */
    readonly inferenceConfiguration?: PromptInferenceConfiguration;
    /**
     * The text prompt. Variables are used by enclosing its name with double curly braces
     * as in `{{variable_name}}`.
     */
    readonly promptText: string;
}
/**
 * Creates a text template variant.
 *
 * @param props - Properties for the text prompt variant
 * @returns A PromptVariant configured for text processing
 */
export declare function createTextPromptVariant(props: TextPromptVariantProps): IPromptVariant;
