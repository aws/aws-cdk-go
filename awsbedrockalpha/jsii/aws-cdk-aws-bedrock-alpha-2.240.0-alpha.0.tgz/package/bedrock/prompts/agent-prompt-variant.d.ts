import type { CommonPromptVariantProps, IPromptVariant } from './prompt-variant';
import type { IAgentAlias } from '../agents/agent-alias';
/**
 * Properties for creating an agent prompt variant.
 */
export interface AgentPromptVariantProps extends CommonPromptVariantProps {
    /**
     * An alias pointing to the agent version to be used.
     */
    readonly agentAlias: IAgentAlias;
    /**
     * The text prompt. Variables are used by enclosing its name with double curly braces
     * as in `{{variable_name}}`.
     */
    readonly promptText: string;
}
/**
 * Creates an agent prompt template variant.
 *
 * @param props - Properties for the agent prompt variant
 * @returns A PromptVariant configured for agent interactions
 */
export declare function createAgentPromptVariant(props: AgentPromptVariantProps): IPromptVariant;
