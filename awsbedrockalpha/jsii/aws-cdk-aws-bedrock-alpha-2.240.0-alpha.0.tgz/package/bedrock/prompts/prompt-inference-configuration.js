"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptInferenceConfiguration = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const validation_helpers_1 = require("../agents/validation-helpers");
/**
 * Abstract base class for prompt inference configurations.
 *
 * This provides a high-level abstraction over the underlying CloudFormation
 * inference configuration properties, offering a more developer-friendly interface
 * while maintaining full compatibility with the underlying AWS Bedrock service.
 */
class PromptInferenceConfiguration {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.PromptInferenceConfiguration", version: "2.240.0-alpha.0" };
    /**
     * Creates a text inference configuration.
     */
    static text(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_PromptInferenceConfigurationProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.text);
            }
            throw error;
        }
        return new TextInferenceConfiguration(props);
    }
}
exports.PromptInferenceConfiguration = PromptInferenceConfiguration;
/**
 * Text inference configuration for prompts.
 */
class TextInferenceConfiguration extends PromptInferenceConfiguration {
    props;
    constructor(props) {
        super();
        this.props = props;
        // Validate maxTokens if provided
        if (props.maxTokens !== undefined && props.maxTokens <= 0) {
            throw new validation_helpers_1.ValidationError('maxTokens must be a positive number');
        }
        // Validate temperature range if provided
        if (props.temperature !== undefined && (props.temperature < 0.0 || props.temperature > 1.0)) {
            throw new validation_helpers_1.ValidationError('temperature must be between 0.0 and 1.0');
        }
        // Validate topP range if provided
        if (props.topP !== undefined && (props.topP < 0.0 || props.topP > 1.0)) {
            throw new validation_helpers_1.ValidationError('topP must be between 0.0 and 1.0');
        }
    }
    _render() {
        return {
            text: {
                maxTokens: this.props.maxTokens,
                stopSequences: this.props.stopSequences,
                temperature: this.props.temperature,
                topP: this.props.topP,
            },
        };
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvbXB0LWluZmVyZW5jZS1jb25maWd1cmF0aW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicHJvbXB0LWluZmVyZW5jZS1jb25maWd1cmF0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQ0EscUVBQStEO0FBc0MvRDs7Ozs7O0dBTUc7QUFDSCxNQUFzQiw0QkFBNEI7O0lBQ2hEOztPQUVHO0lBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUF3Qzs7Ozs7Ozs7OztRQUN6RCxPQUFPLElBQUksMEJBQTBCLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDOUM7O0FBTkgsb0VBYUM7QUFFRDs7R0FFRztBQUNILE1BQU0sMEJBQTJCLFNBQVEsNEJBQTRCO0lBQ3RDO0lBQTdCLFlBQTZCLEtBQXdDO1FBQ25FLEtBQUssRUFBRSxDQUFDO1FBRG1CLFVBQUssR0FBTCxLQUFLLENBQW1DO1FBR25FLGlDQUFpQztRQUNqQyxJQUFJLEtBQUssQ0FBQyxTQUFTLEtBQUssU0FBUyxJQUFJLEtBQUssQ0FBQyxTQUFTLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDMUQsTUFBTSxJQUFJLG9DQUFlLENBQUMscUNBQXFDLENBQUMsQ0FBQztRQUNuRSxDQUFDO1FBRUQseUNBQXlDO1FBQ3pDLElBQUksS0FBSyxDQUFDLFdBQVcsS0FBSyxTQUFTLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsSUFBSSxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDNUYsTUFBTSxJQUFJLG9DQUFlLENBQUMseUNBQXlDLENBQUMsQ0FBQztRQUN2RSxDQUFDO1FBRUQsa0NBQWtDO1FBQ2xDLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxTQUFTLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLEdBQUcsSUFBSSxLQUFLLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDdkUsTUFBTSxJQUFJLG9DQUFlLENBQUMsa0NBQWtDLENBQUMsQ0FBQztRQUNoRSxDQUFDO0tBQ0Y7SUFFTSxPQUFPO1FBQ1osT0FBTztZQUNMLElBQUksRUFBRTtnQkFDSixTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTO2dCQUMvQixhQUFhLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhO2dCQUN2QyxXQUFXLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXO2dCQUNuQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJO2FBQ3RCO1NBQ0YsQ0FBQztLQUNIO0NBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSAqIGFzIGJlZHJvY2sgZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHsgVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnLi4vYWdlbnRzL3ZhbGlkYXRpb24taGVscGVycyc7XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgY3JlYXRpbmcgYSBwcm9tcHQgaW5mZXJlbmNlIGNvbmZpZ3VyYXRpb24uXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0SW5mZXJlbmNlQ29uZmlndXJhdGlvblByb3BzIHtcbiAgLyoqXG4gICAqIFRoZSBtYXhpbXVtIG51bWJlciBvZiB0b2tlbnMgdG8gcmV0dXJuIGluIHRoZSByZXNwb25zZS5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyBsaW1pdCBzcGVjaWZpZWRcbiAgICovXG4gIHJlYWRvbmx5IG1heFRva2Vucz86IG51bWJlcjtcblxuICAvKipcbiAgICogQSBsaXN0IG9mIHN0cmluZ3MgdGhhdCBkZWZpbmUgc2VxdWVuY2VzIGFmdGVyIHdoaWNoIHRoZSBtb2RlbCB3aWxsIHN0b3AgZ2VuZXJhdGluZy5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyBzdG9wIHNlcXVlbmNlc1xuICAgKi9cbiAgcmVhZG9ubHkgc3RvcFNlcXVlbmNlcz86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBDb250cm9scyB0aGUgcmFuZG9tbmVzcyBvZiB0aGUgcmVzcG9uc2UuXG4gICAqIEhpZ2hlciB2YWx1ZXMgbWFrZSBvdXRwdXQgbW9yZSByYW5kb20sIGxvd2VyIHZhbHVlcyBtb3JlIGRldGVybWluaXN0aWMuXG4gICAqIFZhbGlkIHJhbmdlIGlzIDAuMCB0byAxLjAuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTW9kZWwgZGVmYXVsdCB0ZW1wZXJhdHVyZVxuICAgKi9cbiAgcmVhZG9ubHkgdGVtcGVyYXR1cmU/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIFRoZSBwZXJjZW50YWdlIG9mIG1vc3QtbGlrZWx5IGNhbmRpZGF0ZXMgdGhhdCB0aGUgbW9kZWwgY29uc2lkZXJzIGZvciB0aGUgbmV4dCB0b2tlbi5cbiAgICogVmFsaWQgcmFuZ2UgaXMgMC4wIHRvIDEuMC5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBNb2RlbCBkZWZhdWx0IHRvcFBcbiAgICovXG4gIHJlYWRvbmx5IHRvcFA/OiBudW1iZXI7XG59XG5cbi8qKlxuICogQWJzdHJhY3QgYmFzZSBjbGFzcyBmb3IgcHJvbXB0IGluZmVyZW5jZSBjb25maWd1cmF0aW9ucy5cbiAqXG4gKiBUaGlzIHByb3ZpZGVzIGEgaGlnaC1sZXZlbCBhYnN0cmFjdGlvbiBvdmVyIHRoZSB1bmRlcmx5aW5nIENsb3VkRm9ybWF0aW9uXG4gKiBpbmZlcmVuY2UgY29uZmlndXJhdGlvbiBwcm9wZXJ0aWVzLCBvZmZlcmluZyBhIG1vcmUgZGV2ZWxvcGVyLWZyaWVuZGx5IGludGVyZmFjZVxuICogd2hpbGUgbWFpbnRhaW5pbmcgZnVsbCBjb21wYXRpYmlsaXR5IHdpdGggdGhlIHVuZGVybHlpbmcgQVdTIEJlZHJvY2sgc2VydmljZS5cbiAqL1xuZXhwb3J0IGFic3RyYWN0IGNsYXNzIFByb21wdEluZmVyZW5jZUNvbmZpZ3VyYXRpb24ge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIHRleHQgaW5mZXJlbmNlIGNvbmZpZ3VyYXRpb24uXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHRleHQocHJvcHM6IFByb21wdEluZmVyZW5jZUNvbmZpZ3VyYXRpb25Qcm9wcyk6IFByb21wdEluZmVyZW5jZUNvbmZpZ3VyYXRpb24ge1xuICAgIHJldHVybiBuZXcgVGV4dEluZmVyZW5jZUNvbmZpZ3VyYXRpb24ocHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgdGhlIGluZmVyZW5jZSBjb25maWd1cmF0aW9uIGFzIGEgQ2xvdWRGb3JtYXRpb24gcHJvcGVydHkuXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIGFic3RyYWN0IF9yZW5kZXIoKTogYmVkcm9jay5DZm5Qcm9tcHQuUHJvbXB0SW5mZXJlbmNlQ29uZmlndXJhdGlvblByb3BlcnR5O1xufVxuXG4vKipcbiAqIFRleHQgaW5mZXJlbmNlIGNvbmZpZ3VyYXRpb24gZm9yIHByb21wdHMuXG4gKi9cbmNsYXNzIFRleHRJbmZlcmVuY2VDb25maWd1cmF0aW9uIGV4dGVuZHMgUHJvbXB0SW5mZXJlbmNlQ29uZmlndXJhdGlvbiB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgcHJvcHM6IFByb21wdEluZmVyZW5jZUNvbmZpZ3VyYXRpb25Qcm9wcykge1xuICAgIHN1cGVyKCk7XG5cbiAgICAvLyBWYWxpZGF0ZSBtYXhUb2tlbnMgaWYgcHJvdmlkZWRcbiAgICBpZiAocHJvcHMubWF4VG9rZW5zICE9PSB1bmRlZmluZWQgJiYgcHJvcHMubWF4VG9rZW5zIDw9IDApIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ21heFRva2VucyBtdXN0IGJlIGEgcG9zaXRpdmUgbnVtYmVyJyk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgdGVtcGVyYXR1cmUgcmFuZ2UgaWYgcHJvdmlkZWRcbiAgICBpZiAocHJvcHMudGVtcGVyYXR1cmUgIT09IHVuZGVmaW5lZCAmJiAocHJvcHMudGVtcGVyYXR1cmUgPCAwLjAgfHwgcHJvcHMudGVtcGVyYXR1cmUgPiAxLjApKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCd0ZW1wZXJhdHVyZSBtdXN0IGJlIGJldHdlZW4gMC4wIGFuZCAxLjAnKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSB0b3BQIHJhbmdlIGlmIHByb3ZpZGVkXG4gICAgaWYgKHByb3BzLnRvcFAgIT09IHVuZGVmaW5lZCAmJiAocHJvcHMudG9wUCA8IDAuMCB8fCBwcm9wcy50b3BQID4gMS4wKSkge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcigndG9wUCBtdXN0IGJlIGJldHdlZW4gMC4wIGFuZCAxLjAnKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgX3JlbmRlcigpOiBiZWRyb2NrLkNmblByb21wdC5Qcm9tcHRJbmZlcmVuY2VDb25maWd1cmF0aW9uUHJvcGVydHkge1xuICAgIHJldHVybiB7XG4gICAgICB0ZXh0OiB7XG4gICAgICAgIG1heFRva2VuczogdGhpcy5wcm9wcy5tYXhUb2tlbnMsXG4gICAgICAgIHN0b3BTZXF1ZW5jZXM6IHRoaXMucHJvcHMuc3RvcFNlcXVlbmNlcyxcbiAgICAgICAgdGVtcGVyYXR1cmU6IHRoaXMucHJvcHMudGVtcGVyYXR1cmUsXG4gICAgICAgIHRvcFA6IHRoaXMucHJvcHMudG9wUCxcbiAgICAgIH0sXG4gICAgfTtcbiAgfVxufVxuIl19