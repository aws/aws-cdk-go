"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3ApiSchema = exports.InlineApiSchema = exports.AssetApiSchema = exports.ApiSchema = void 0;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const s3_assets = require("aws-cdk-lib/aws-s3-assets");
const schema_base_1 = require("./schema-base");
/**
 * Error thrown when an ApiSchema is not properly initialized.
 */
class ApiSchemaError extends Error {
    cause;
    constructor(message, cause) {
        super(message);
        this.cause = cause;
        this.name = 'ApiSchemaError';
    }
}
/******************************************************************************
 *                       API SCHEMA CLASS
 *****************************************************************************/
/**
 * Represents the concept of an API Schema for a Bedrock Agent Action Group.
 */
class ApiSchema extends schema_base_1.ActionGroupSchema {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ApiSchema", version: "2.240.0-alpha.0" };
    /**
     * Creates an API Schema from a local file.
     * @param path - the path to the local file containing the OpenAPI schema for the action group
     */
    static fromLocalAsset(path) {
        return new AssetApiSchema(path);
    }
    /**
     * Creates an API Schema from an inline string.
     * @param schema - the JSON or YAML payload defining the OpenAPI schema for the action group
     */
    static fromInline(schema) {
        return new InlineApiSchema(schema);
    }
    /**
     * Creates an API Schema from an S3 File
     * @param bucket - the bucket containing the local file containing the OpenAPI schema for the action group
     * @param objectKey - object key in the bucket
     */
    static fromS3File(bucket, objectKey) {
        return new S3ApiSchema({
            bucketName: bucket.bucketRef.bucketName,
            objectKey: objectKey,
        });
    }
    /**
     * The S3 location of the API schema file, if using an S3-based schema.
     * Contains the bucket name and object key information.
     */
    s3File;
    /**
     * The inline OpenAPI schema definition as a string, if using an inline schema.
     * Can be in JSON or YAML format.
     */
    inlineSchema;
    constructor(s3File, inlineSchema) {
        super();
        this.s3File = s3File;
        this.inlineSchema = inlineSchema;
    }
}
exports.ApiSchema = ApiSchema;
/**
 * API Schema from a local asset.
 *
 * The asset is uploaded to an S3 staging bucket, then moved to its final location
 * by CloudFormation during deployment.
 */
class AssetApiSchema extends ApiSchema {
    path;
    options;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AssetApiSchema", version: "2.240.0-alpha.0" };
    asset;
    constructor(path, options = {}) {
        super();
        this.path = path;
        this.options = options;
    }
    /**
     * Binds this API schema to a construct scope.
     * This method initializes the S3 asset if it hasn't been initialized yet.
     * Must be called before rendering the schema as CFN properties.
     *
     * @param scope - The construct scope to bind to
     */
    bind(scope) {
        // If the same AssetApiSchema is used multiple times, retain only the first instantiation
        if (!this.asset) {
            this.asset = new s3_assets.Asset(scope, 'Schema', {
                path: this.path,
                ...this.options,
            });
            // Note: Permissions will be granted by the Agent construct when adding the action group
        }
    }
    /**
     * Format as CFN properties
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        if (!this.asset) {
            throw new ApiSchemaError('ApiSchema must be bound to a scope before rendering. Call bind() first.', 'Asset not initialized');
        }
        return {
            s3: {
                s3BucketName: this.asset.s3BucketName,
                s3ObjectKey: this.asset.s3ObjectKey,
            },
        };
    }
}
exports.AssetApiSchema = AssetApiSchema;
// ------------------------------------------------------
/**
 * Class to define an API Schema from an inline string.
 * The schema can be provided directly as a string in either JSON or YAML format.
 */
class InlineApiSchema extends ApiSchema {
    schema;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.InlineApiSchema", version: "2.240.0-alpha.0" };
    constructor(schema) {
        super(undefined, schema);
        this.schema = schema;
    }
    /**
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            payload: this.schema,
        };
    }
}
exports.InlineApiSchema = InlineApiSchema;
// ------------------------------------------------------
// S3 File
// ------------------------------------------------------
/**
 * Class to define an API Schema from an S3 object.
 */
class S3ApiSchema extends ApiSchema {
    location;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.S3ApiSchema", version: "2.240.0-alpha.0" };
    constructor(location) {
        super(location, undefined);
        this.location = location;
    }
    /**
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            s3: {
                s3BucketName: this.location.bucketName,
                s3ObjectKey: this.location.objectKey,
            },
        };
    }
}
exports.S3ApiSchema = S3ApiSchema;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLXNjaGVtYS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImFwaS1zY2hlbWEudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUVBLHVEQUF1RDtBQUV2RCwrQ0FBa0Q7QUFFbEQ7O0dBRUc7QUFDSCxNQUFNLGNBQWUsU0FBUSxLQUFLO0lBQ2E7SUFBN0MsWUFBWSxPQUFlLEVBQWtCLEtBQWM7UUFDekQsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRDRCLFVBQUssR0FBTCxLQUFLLENBQVM7UUFFekQsSUFBSSxDQUFDLElBQUksR0FBRyxnQkFBZ0IsQ0FBQztLQUM5QjtDQUNGO0FBRUQ7OytFQUUrRTtBQUMvRTs7R0FFRztBQUNILE1BQXNCLFNBQVUsU0FBUSwrQkFBaUI7O0lBQ3ZEOzs7T0FHRztJQUNJLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBWTtRQUN2QyxPQUFPLElBQUksY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ2pDO0lBRUQ7OztPQUdHO0lBQ0ksTUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUFjO1FBQ3JDLE9BQU8sSUFBSSxlQUFlLENBQUMsTUFBTSxDQUFDLENBQUM7S0FDcEM7SUFFRDs7OztPQUlHO0lBQ0ksTUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUFrQixFQUFFLFNBQWlCO1FBQzVELE9BQU8sSUFBSSxXQUFXLENBQUM7WUFDckIsVUFBVSxFQUFFLE1BQU0sQ0FBQyxTQUFTLENBQUMsVUFBVTtZQUN2QyxTQUFTLEVBQUUsU0FBUztTQUNyQixDQUFDLENBQUM7S0FDSjtJQUVEOzs7T0FHRztJQUNhLE1BQU0sQ0FBWTtJQUVsQzs7O09BR0c7SUFDYSxZQUFZLENBQVU7SUFFdEMsWUFBc0IsTUFBaUIsRUFBRSxZQUFxQjtRQUM1RCxLQUFLLEVBQUUsQ0FBQztRQUNSLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO0tBQ2xDOztBQTdDSCw4QkFxREM7QUFFRDs7Ozs7R0FLRztBQUNILE1BQWEsY0FBZSxTQUFRLFNBQVM7SUFHZDtJQUErQjs7SUFGcEQsS0FBSyxDQUFtQjtJQUVoQyxZQUE2QixJQUFZLEVBQW1CLFVBQWtDLEVBQUU7UUFDOUYsS0FBSyxFQUFFLENBQUM7UUFEbUIsU0FBSSxHQUFKLElBQUksQ0FBUTtRQUFtQixZQUFPLEdBQVAsT0FBTyxDQUE2QjtLQUUvRjtJQUVEOzs7Ozs7T0FNRztJQUNJLElBQUksQ0FBQyxLQUFnQjtRQUMxQix5RkFBeUY7UUFDekYsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNoQixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsUUFBUSxFQUFFO2dCQUNoRCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7Z0JBQ2YsR0FBRyxJQUFJLENBQUMsT0FBTzthQUNoQixDQUFDLENBQUM7WUFDSCx3RkFBd0Y7UUFDMUYsQ0FBQztLQUNGO0lBRUQ7OztPQUdHO0lBQ0ksT0FBTztRQUNaLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDaEIsTUFBTSxJQUFJLGNBQWMsQ0FBQyx5RUFBeUUsRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO1FBQy9ILENBQUM7UUFFRCxPQUFPO1lBQ0wsRUFBRSxFQUFFO2dCQUNGLFlBQVksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVk7Z0JBQ3JDLFdBQVcsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVc7YUFDcEM7U0FDRixDQUFDO0tBQ0g7O0FBeENILHdDQXlDQztBQUVELHlEQUF5RDtBQUN6RDs7O0dBR0c7QUFDSCxNQUFhLGVBQWdCLFNBQVEsU0FBUztJQUNmOztJQUE3QixZQUE2QixNQUFjO1FBQ3pDLEtBQUssQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFERSxXQUFNLEdBQU4sTUFBTSxDQUFRO0tBRTFDO0lBRUQ7O09BRUc7SUFDSSxPQUFPO1FBQ1osT0FBTztZQUNMLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTTtTQUNyQixDQUFDO0tBQ0g7O0FBWkgsMENBYUM7QUFFRCx5REFBeUQ7QUFDekQsVUFBVTtBQUNWLHlEQUF5RDtBQUN6RDs7R0FFRztBQUNILE1BQWEsV0FBWSxTQUFRLFNBQVM7SUFDWDs7SUFBN0IsWUFBNkIsUUFBa0I7UUFDN0MsS0FBSyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQURBLGFBQVEsR0FBUixRQUFRLENBQVU7S0FFOUM7SUFDRDs7T0FFRztJQUNJLE9BQU87UUFDWixPQUFPO1lBQ0wsRUFBRSxFQUFFO2dCQUNGLFlBQVksRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVU7Z0JBQ3RDLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVM7YUFDckM7U0FDRixDQUFDO0tBQ0g7O0FBZEgsa0NBZUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IENmbkFnZW50IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHR5cGUgeyBJQnVja2V0UmVmLCBMb2NhdGlvbiB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1zMyc7XG5pbXBvcnQgKiBhcyBzM19hc3NldHMgZnJvbSAnYXdzLWNkay1saWIvYXdzLXMzLWFzc2V0cyc7XG5pbXBvcnQgdHlwZSB7IENvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuaW1wb3J0IHsgQWN0aW9uR3JvdXBTY2hlbWEgfSBmcm9tICcuL3NjaGVtYS1iYXNlJztcblxuLyoqXG4gKiBFcnJvciB0aHJvd24gd2hlbiBhbiBBcGlTY2hlbWEgaXMgbm90IHByb3Blcmx5IGluaXRpYWxpemVkLlxuICovXG5jbGFzcyBBcGlTY2hlbWFFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgY29uc3RydWN0b3IobWVzc2FnZTogc3RyaW5nLCBwdWJsaWMgcmVhZG9ubHkgY2F1c2U/OiBzdHJpbmcpIHtcbiAgICBzdXBlcihtZXNzYWdlKTtcbiAgICB0aGlzLm5hbWUgPSAnQXBpU2NoZW1hRXJyb3InO1xuICB9XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICBBUEkgU0NIRU1BIENMQVNTXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIFJlcHJlc2VudHMgdGhlIGNvbmNlcHQgb2YgYW4gQVBJIFNjaGVtYSBmb3IgYSBCZWRyb2NrIEFnZW50IEFjdGlvbiBHcm91cC5cbiAqL1xuZXhwb3J0IGFic3RyYWN0IGNsYXNzIEFwaVNjaGVtYSBleHRlbmRzIEFjdGlvbkdyb3VwU2NoZW1hIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYW4gQVBJIFNjaGVtYSBmcm9tIGEgbG9jYWwgZmlsZS5cbiAgICogQHBhcmFtIHBhdGggLSB0aGUgcGF0aCB0byB0aGUgbG9jYWwgZmlsZSBjb250YWluaW5nIHRoZSBPcGVuQVBJIHNjaGVtYSBmb3IgdGhlIGFjdGlvbiBncm91cFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tTG9jYWxBc3NldChwYXRoOiBzdHJpbmcpOiBBc3NldEFwaVNjaGVtYSB7XG4gICAgcmV0dXJuIG5ldyBBc3NldEFwaVNjaGVtYShwYXRoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGFuIEFQSSBTY2hlbWEgZnJvbSBhbiBpbmxpbmUgc3RyaW5nLlxuICAgKiBAcGFyYW0gc2NoZW1hIC0gdGhlIEpTT04gb3IgWUFNTCBwYXlsb2FkIGRlZmluaW5nIHRoZSBPcGVuQVBJIHNjaGVtYSBmb3IgdGhlIGFjdGlvbiBncm91cFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tSW5saW5lKHNjaGVtYTogc3RyaW5nKTogSW5saW5lQXBpU2NoZW1hIHtcbiAgICByZXR1cm4gbmV3IElubGluZUFwaVNjaGVtYShzY2hlbWEpO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYW4gQVBJIFNjaGVtYSBmcm9tIGFuIFMzIEZpbGVcbiAgICogQHBhcmFtIGJ1Y2tldCAtIHRoZSBidWNrZXQgY29udGFpbmluZyB0aGUgbG9jYWwgZmlsZSBjb250YWluaW5nIHRoZSBPcGVuQVBJIHNjaGVtYSBmb3IgdGhlIGFjdGlvbiBncm91cFxuICAgKiBAcGFyYW0gb2JqZWN0S2V5IC0gb2JqZWN0IGtleSBpbiB0aGUgYnVja2V0XG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21TM0ZpbGUoYnVja2V0OiBJQnVja2V0UmVmLCBvYmplY3RLZXk6IHN0cmluZyk6IFMzQXBpU2NoZW1hIHtcbiAgICByZXR1cm4gbmV3IFMzQXBpU2NoZW1hKHtcbiAgICAgIGJ1Y2tldE5hbWU6IGJ1Y2tldC5idWNrZXRSZWYuYnVja2V0TmFtZSxcbiAgICAgIG9iamVjdEtleTogb2JqZWN0S2V5LFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBTMyBsb2NhdGlvbiBvZiB0aGUgQVBJIHNjaGVtYSBmaWxlLCBpZiB1c2luZyBhbiBTMy1iYXNlZCBzY2hlbWEuXG4gICAqIENvbnRhaW5zIHRoZSBidWNrZXQgbmFtZSBhbmQgb2JqZWN0IGtleSBpbmZvcm1hdGlvbi5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBzM0ZpbGU/OiBMb2NhdGlvbjtcblxuICAvKipcbiAgICogVGhlIGlubGluZSBPcGVuQVBJIHNjaGVtYSBkZWZpbml0aW9uIGFzIGEgc3RyaW5nLCBpZiB1c2luZyBhbiBpbmxpbmUgc2NoZW1hLlxuICAgKiBDYW4gYmUgaW4gSlNPTiBvciBZQU1MIGZvcm1hdC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBpbmxpbmVTY2hlbWE/OiBzdHJpbmc7XG5cbiAgcHJvdGVjdGVkIGNvbnN0cnVjdG9yKHMzRmlsZT86IExvY2F0aW9uLCBpbmxpbmVTY2hlbWE/OiBzdHJpbmcpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuczNGaWxlID0gczNGaWxlO1xuICAgIHRoaXMuaW5saW5lU2NoZW1hID0gaW5saW5lU2NoZW1hO1xuICB9XG5cbiAgLyoqXG4gICAqIEZvcm1hdCBhcyBDRk4gcHJvcGVydGllc1xuICAgKlxuICAgKiBAaW50ZXJuYWwgVGhpcyBpcyBhbiBpbnRlcm5hbCBjb3JlIGZ1bmN0aW9uIGFuZCBzaG91bGQgbm90IGJlIGNhbGxlZCBkaXJlY3RseS5cbiAgICovXG4gIHB1YmxpYyBhYnN0cmFjdCBfcmVuZGVyKCk6IENmbkFnZW50LkFQSVNjaGVtYVByb3BlcnR5O1xufVxuXG4vKipcbiAqIEFQSSBTY2hlbWEgZnJvbSBhIGxvY2FsIGFzc2V0LlxuICpcbiAqIFRoZSBhc3NldCBpcyB1cGxvYWRlZCB0byBhbiBTMyBzdGFnaW5nIGJ1Y2tldCwgdGhlbiBtb3ZlZCB0byBpdHMgZmluYWwgbG9jYXRpb25cbiAqIGJ5IENsb3VkRm9ybWF0aW9uIGR1cmluZyBkZXBsb3ltZW50LlxuICovXG5leHBvcnQgY2xhc3MgQXNzZXRBcGlTY2hlbWEgZXh0ZW5kcyBBcGlTY2hlbWEge1xuICBwcml2YXRlIGFzc2V0PzogczNfYXNzZXRzLkFzc2V0O1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgcGF0aDogc3RyaW5nLCBwcml2YXRlIHJlYWRvbmx5IG9wdGlvbnM6IHMzX2Fzc2V0cy5Bc3NldE9wdGlvbnMgPSB7fSkge1xuICAgIHN1cGVyKCk7XG4gIH1cblxuICAvKipcbiAgICogQmluZHMgdGhpcyBBUEkgc2NoZW1hIHRvIGEgY29uc3RydWN0IHNjb3BlLlxuICAgKiBUaGlzIG1ldGhvZCBpbml0aWFsaXplcyB0aGUgUzMgYXNzZXQgaWYgaXQgaGFzbid0IGJlZW4gaW5pdGlhbGl6ZWQgeWV0LlxuICAgKiBNdXN0IGJlIGNhbGxlZCBiZWZvcmUgcmVuZGVyaW5nIHRoZSBzY2hlbWEgYXMgQ0ZOIHByb3BlcnRpZXMuXG4gICAqXG4gICAqIEBwYXJhbSBzY29wZSAtIFRoZSBjb25zdHJ1Y3Qgc2NvcGUgdG8gYmluZCB0b1xuICAgKi9cbiAgcHVibGljIGJpbmQoc2NvcGU6IENvbnN0cnVjdCk6IHZvaWQge1xuICAgIC8vIElmIHRoZSBzYW1lIEFzc2V0QXBpU2NoZW1hIGlzIHVzZWQgbXVsdGlwbGUgdGltZXMsIHJldGFpbiBvbmx5IHRoZSBmaXJzdCBpbnN0YW50aWF0aW9uXG4gICAgaWYgKCF0aGlzLmFzc2V0KSB7XG4gICAgICB0aGlzLmFzc2V0ID0gbmV3IHMzX2Fzc2V0cy5Bc3NldChzY29wZSwgJ1NjaGVtYScsIHtcbiAgICAgICAgcGF0aDogdGhpcy5wYXRoLFxuICAgICAgICAuLi50aGlzLm9wdGlvbnMsXG4gICAgICB9KTtcbiAgICAgIC8vIE5vdGU6IFBlcm1pc3Npb25zIHdpbGwgYmUgZ3JhbnRlZCBieSB0aGUgQWdlbnQgY29uc3RydWN0IHdoZW4gYWRkaW5nIHRoZSBhY3Rpb24gZ3JvdXBcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRm9ybWF0IGFzIENGTiBwcm9wZXJ0aWVzXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIF9yZW5kZXIoKTogQ2ZuQWdlbnQuQVBJU2NoZW1hUHJvcGVydHkge1xuICAgIGlmICghdGhpcy5hc3NldCkge1xuICAgICAgdGhyb3cgbmV3IEFwaVNjaGVtYUVycm9yKCdBcGlTY2hlbWEgbXVzdCBiZSBib3VuZCB0byBhIHNjb3BlIGJlZm9yZSByZW5kZXJpbmcuIENhbGwgYmluZCgpIGZpcnN0LicsICdBc3NldCBub3QgaW5pdGlhbGl6ZWQnKTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgczM6IHtcbiAgICAgICAgczNCdWNrZXROYW1lOiB0aGlzLmFzc2V0LnMzQnVja2V0TmFtZSxcbiAgICAgICAgczNPYmplY3RLZXk6IHRoaXMuYXNzZXQuczNPYmplY3RLZXksXG4gICAgICB9LFxuICAgIH07XG4gIH1cbn1cblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vKipcbiAqIENsYXNzIHRvIGRlZmluZSBhbiBBUEkgU2NoZW1hIGZyb20gYW4gaW5saW5lIHN0cmluZy5cbiAqIFRoZSBzY2hlbWEgY2FuIGJlIHByb3ZpZGVkIGRpcmVjdGx5IGFzIGEgc3RyaW5nIGluIGVpdGhlciBKU09OIG9yIFlBTUwgZm9ybWF0LlxuICovXG5leHBvcnQgY2xhc3MgSW5saW5lQXBpU2NoZW1hIGV4dGVuZHMgQXBpU2NoZW1hIHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSByZWFkb25seSBzY2hlbWE6IHN0cmluZykge1xuICAgIHN1cGVyKHVuZGVmaW5lZCwgc2NoZW1hKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAaW50ZXJuYWwgVGhpcyBpcyBhbiBpbnRlcm5hbCBjb3JlIGZ1bmN0aW9uIGFuZCBzaG91bGQgbm90IGJlIGNhbGxlZCBkaXJlY3RseS5cbiAgICovXG4gIHB1YmxpYyBfcmVuZGVyKCk6IENmbkFnZW50LkFQSVNjaGVtYVByb3BlcnR5IHtcbiAgICByZXR1cm4ge1xuICAgICAgcGF5bG9hZDogdGhpcy5zY2hlbWEsXG4gICAgfTtcbiAgfVxufVxuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIFMzIEZpbGVcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLyoqXG4gKiBDbGFzcyB0byBkZWZpbmUgYW4gQVBJIFNjaGVtYSBmcm9tIGFuIFMzIG9iamVjdC5cbiAqL1xuZXhwb3J0IGNsYXNzIFMzQXBpU2NoZW1hIGV4dGVuZHMgQXBpU2NoZW1hIHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSByZWFkb25seSBsb2NhdGlvbjogTG9jYXRpb24pIHtcbiAgICBzdXBlcihsb2NhdGlvbiwgdW5kZWZpbmVkKTtcbiAgfVxuICAvKipcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBDZm5BZ2VudC5BUElTY2hlbWFQcm9wZXJ0eSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHMzOiB7XG4gICAgICAgIHMzQnVja2V0TmFtZTogdGhpcy5sb2NhdGlvbi5idWNrZXROYW1lLFxuICAgICAgICBzM09iamVjdEtleTogdGhpcy5sb2NhdGlvbi5vYmplY3RLZXksXG4gICAgICB9LFxuICAgIH07XG4gIH1cbn1cbiJdfQ==