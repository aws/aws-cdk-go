"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptOverrideConfiguration = exports.AgentStepType = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const validation = require("./validation-helpers");
/**
 * The step in the agent sequence that this prompt configuration applies to.
 */
var AgentStepType;
(function (AgentStepType) {
    /**
     * Pre-processing step that prepares the user input for orchestration.
     */
    AgentStepType["PRE_PROCESSING"] = "PRE_PROCESSING";
    /**
     * Main orchestration step that determines the agent's actions.
     */
    AgentStepType["ORCHESTRATION"] = "ORCHESTRATION";
    /**
     * Post-processing step that refines the agent's response.
     */
    AgentStepType["POST_PROCESSING"] = "POST_PROCESSING";
    /**
     * Step that classifies and routes requests to appropriate collaborators.
     */
    AgentStepType["ROUTING_CLASSIFIER"] = "ROUTING_CLASSIFIER";
    /**
     * Step that summarizes conversation history for memory retention.
     */
    AgentStepType["MEMORY_SUMMARIZATION"] = "MEMORY_SUMMARIZATION";
    /**
     * Step that generates responses using knowledge base content.
     */
    AgentStepType["KNOWLEDGE_BASE_RESPONSE_GENERATION"] = "KNOWLEDGE_BASE_RESPONSE_GENERATION";
})(AgentStepType || (exports.AgentStepType = AgentStepType = {}));
/**
 * Configuration for overriding prompt templates and behaviors in different parts
 * of an agent's sequence. This allows customizing how the agent processes inputs,
 * makes decisions, and generates responses.
 */
class PromptOverrideConfiguration {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.PromptOverrideConfiguration", version: "2.240.0-alpha.0" };
    /**
     * Creates a PromptOverrideConfiguration from individual step configurations.
     * Use this method when you want to override prompts without using a custom parser.
     * @param steps The step configurations to use
     * @returns A new PromptOverrideConfiguration instance
     */
    static fromSteps(steps) {
        if (!steps || steps.length === 0) {
            throw new validation.ValidationError('Steps array cannot be empty');
        }
        // Convert steps array to props format
        const stepMap = steps.reduce((acc, step) => {
            switch (step.stepType) {
                case AgentStepType.PRE_PROCESSING:
                    return { ...acc, preProcessingStep: step };
                case AgentStepType.ORCHESTRATION:
                    return { ...acc, orchestrationStep: step };
                case AgentStepType.POST_PROCESSING:
                    return { ...acc, postProcessingStep: step };
                case AgentStepType.ROUTING_CLASSIFIER:
                    return { ...acc, routingClassifierStep: step };
                case AgentStepType.MEMORY_SUMMARIZATION:
                    return { ...acc, memorySummarizationStep: step };
                case AgentStepType.KNOWLEDGE_BASE_RESPONSE_GENERATION:
                    return { ...acc, knowledgeBaseResponseGenerationStep: step };
                default:
                    return acc;
            }
        }, {});
        return new PromptOverrideConfiguration(stepMap);
    }
    /**
     * Creates a PromptOverrideConfiguration with a custom Lambda parser function.
     * @param props Configuration including:
     *   - `parser`: Lambda function to use as custom parser
     *   - Individual step configurations. At least one of the steps must make use of the custom parser.
     */
    static withCustomParser(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_CustomParserProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.withCustomParser);
            }
            throw error;
        }
        return new PromptOverrideConfiguration(props);
    }
    /**
     * The custom Lambda parser function to use.
     * The Lambda parser processes and interprets the raw foundation model output.
     * It receives an input event with:
     * - messageVersion: Version of message format (1.0)
     * - agent: Info about the agent (name, id, alias, version)
     * - invokeModelRawResponse: Raw model output to parse
     * - promptType: Type of prompt being parsed
     * - overrideType: Type of override (OUTPUT_PARSER)
     *
     * The Lambda must return a response that the agent uses for next actions.
     * @see https://docs.aws.amazon.com/bedrock/latest/userguide/lambda-parser.html
     */
    parser;
    /**
     * Configuration for the pre-processing step.
     */
    preProcessingStep;
    /**
     * Configuration for the orchestration step.
     */
    orchestrationStep;
    /**
     * Configuration for the post-processing step.
     */
    postProcessingStep;
    /**
     * Configuration for the routing classifier step.
     */
    routingClassifierStep;
    /**
     * Configuration for the memory summarization step.
     */
    memorySummarizationStep;
    /**
     * Configuration for the knowledge base response generation step.
     */
    knowledgeBaseResponseGenerationStep;
    /**
     * Create a new PromptOverrideConfiguration.
     *
     * @internal - This is marked as private so end users leverage it only through static methods
     */
    constructor(props) {
        // Validate props
        validation.throwIfInvalid(this.validateSteps, props);
        if (props.parser) {
            validation.throwIfInvalid(this.validateCustomParser, props);
        }
        this.parser = props.parser;
        this.preProcessingStep = props.preProcessingStep;
        this.orchestrationStep = props.orchestrationStep;
        this.postProcessingStep = props.postProcessingStep;
        this.routingClassifierStep = props.routingClassifierStep;
        this.memorySummarizationStep = props.memorySummarizationStep;
        this.knowledgeBaseResponseGenerationStep = props.knowledgeBaseResponseGenerationStep;
    }
    /**
     * Format as CfnAgent.PromptOverrideConfigurationProperty
     *
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        const configurations = [];
        // Helper function to add configuration if step exists
        const addConfiguration = (step, type) => {
            if (step) {
                configurations.push({
                    promptType: type,
                    promptState: step.stepEnabled === undefined ? undefined : step.stepEnabled ? 'ENABLED' : 'DISABLED',
                    parserMode: step.useCustomParser === undefined ? undefined : step.useCustomParser ? 'OVERRIDDEN' : 'DEFAULT',
                    promptCreationMode: step.customPromptTemplate === undefined ? undefined : step.customPromptTemplate ? 'OVERRIDDEN' : 'DEFAULT',
                    basePromptTemplate: step.customPromptTemplate,
                    inferenceConfiguration: step.inferenceConfig,
                    // Include foundation model if it's a routing classifier step
                    foundationModel: type === AgentStepType.ROUTING_CLASSIFIER
                        ? step.foundationModel?.invokableArn
                        : undefined,
                });
            }
        };
        // Add configurations for each step type if defined
        addConfiguration(this.preProcessingStep, AgentStepType.PRE_PROCESSING);
        addConfiguration(this.orchestrationStep, AgentStepType.ORCHESTRATION);
        addConfiguration(this.postProcessingStep, AgentStepType.POST_PROCESSING);
        addConfiguration(this.routingClassifierStep, AgentStepType.ROUTING_CLASSIFIER);
        addConfiguration(this.memorySummarizationStep, AgentStepType.MEMORY_SUMMARIZATION);
        addConfiguration(this.knowledgeBaseResponseGenerationStep, AgentStepType.KNOWLEDGE_BASE_RESPONSE_GENERATION);
        return {
            overrideLambda: this.parser?.functionArn,
            promptConfigurations: configurations,
        };
    }
    validateInferenceConfig = (config) => {
        const errors = [];
        if (config) {
            if (config.temperature < 0 || config.temperature > 1) {
                errors.push('Temperature must be between 0 and 1');
            }
            if (config.topP < 0 || config.topP > 1) {
                errors.push('TopP must be between 0 and 1');
            }
            if (config.topK < 0 || config.topK > 500) {
                errors.push('TopK must be between 0 and 500');
            }
            if (config.stopSequences.length > 4) {
                errors.push('Maximum 4 stop sequences allowed');
            }
            if (config.maximumLength < 0 || config.maximumLength > 4096) {
                errors.push('MaximumLength must be between 0 and 4096');
            }
        }
        return errors;
    };
    validateSteps = (props) => {
        const errors = [];
        // Check if any steps are defined
        const hasSteps = [
            props.preProcessingStep,
            props.orchestrationStep,
            props.postProcessingStep,
            props.routingClassifierStep,
            props.memorySummarizationStep,
            props.knowledgeBaseResponseGenerationStep,
        ].some(step => step !== undefined);
        if (!hasSteps) {
            errors.push('Steps array cannot be empty');
        }
        // Helper function to validate a step's inference config
        const validateStep = (step, stepName) => {
            if (step) {
                // Check for foundation model in non-ROUTING_CLASSIFIER steps
                if ('foundationModel' in step && step.stepType !== AgentStepType.ROUTING_CLASSIFIER) {
                    errors.push('Foundation model can only be specified for ROUTING_CLASSIFIER step type');
                }
                const inferenceErrors = this.validateInferenceConfig(step.inferenceConfig);
                if (inferenceErrors.length > 0) {
                    errors.push(`${stepName} step: ${inferenceErrors.join(', ')}`);
                }
            }
        };
        // Validate each step's inference config
        validateStep(props.preProcessingStep, 'Pre-processing');
        validateStep(props.orchestrationStep, 'Orchestration');
        validateStep(props.postProcessingStep, 'Post-processing');
        validateStep(props.routingClassifierStep, 'Routing classifier');
        validateStep(props.memorySummarizationStep, 'Memory summarization');
        validateStep(props.knowledgeBaseResponseGenerationStep, 'Knowledge base response generation');
        // Validate routing classifier's foundation model if provided
        if (props.routingClassifierStep?.foundationModel) {
            if (!props.routingClassifierStep.foundationModel.invokableArn) {
                errors.push('Foundation model must be a valid IBedrockInvokable with an invokableArn');
            }
        }
        return errors;
    };
    validateCustomParser = (props) => {
        const errors = [];
        // Check if at least one step uses custom parser
        const hasCustomParser = [
            props.preProcessingStep?.useCustomParser,
            props.orchestrationStep?.useCustomParser,
            props.postProcessingStep?.useCustomParser,
            props.routingClassifierStep?.useCustomParser,
            props.memorySummarizationStep?.useCustomParser,
            props.knowledgeBaseResponseGenerationStep?.useCustomParser,
        ].some(useCustomParser => useCustomParser === true);
        if (!hasCustomParser) {
            errors.push('At least one step must use custom parser');
        }
        return errors;
    };
}
exports.PromptOverrideConfiguration = PromptOverrideConfiguration;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvbXB0LW92ZXJyaWRlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicHJvbXB0LW92ZXJyaWRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBRUEsbURBQW1EO0FBR25EOztHQUVHO0FBQ0gsSUFBWSxhQThCWDtBQTlCRCxXQUFZLGFBQWE7SUFDdkI7O09BRUc7SUFDSCxrREFBaUMsQ0FBQTtJQUVqQzs7T0FFRztJQUNILGdEQUErQixDQUFBO0lBRS9COztPQUVHO0lBQ0gsb0RBQW1DLENBQUE7SUFFbkM7O09BRUc7SUFDSCwwREFBeUMsQ0FBQTtJQUV6Qzs7T0FFRztJQUNILDhEQUE2QyxDQUFBO0lBRTdDOztPQUVHO0lBQ0gsMEZBQXlFLENBQUE7QUFDM0UsQ0FBQyxFQTlCVyxhQUFhLDZCQUFiLGFBQWEsUUE4QnhCO0FBNExEOzs7O0dBSUc7QUFDSCxNQUFhLDJCQUEyQjs7SUFDdEM7Ozs7O09BS0c7SUFDSSxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQTZCO1FBQ25ELElBQUksQ0FBQyxLQUFLLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNqQyxNQUFNLElBQUksVUFBVSxDQUFDLGVBQWUsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1FBQ3RFLENBQUM7UUFFRCxzQ0FBc0M7UUFDdEMsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRTtZQUN6QyxRQUFRLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDdEIsS0FBSyxhQUFhLENBQUMsY0FBYztvQkFDL0IsT0FBTyxFQUFFLEdBQUcsR0FBRyxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxDQUFDO2dCQUM3QyxLQUFLLGFBQWEsQ0FBQyxhQUFhO29CQUM5QixPQUFPLEVBQUUsR0FBRyxHQUFHLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLENBQUM7Z0JBQzdDLEtBQUssYUFBYSxDQUFDLGVBQWU7b0JBQ2hDLE9BQU8sRUFBRSxHQUFHLEdBQUcsRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FBQztnQkFDOUMsS0FBSyxhQUFhLENBQUMsa0JBQWtCO29CQUNuQyxPQUFPLEVBQUUsR0FBRyxHQUFHLEVBQUUscUJBQXFCLEVBQUUsSUFBaUQsRUFBRSxDQUFDO2dCQUM5RixLQUFLLGFBQWEsQ0FBQyxvQkFBb0I7b0JBQ3JDLE9BQU8sRUFBRSxHQUFHLEdBQUcsRUFBRSx1QkFBdUIsRUFBRSxJQUFJLEVBQUUsQ0FBQztnQkFDbkQsS0FBSyxhQUFhLENBQUMsa0NBQWtDO29CQUNuRCxPQUFPLEVBQUUsR0FBRyxHQUFHLEVBQUUsbUNBQW1DLEVBQUUsSUFBSSxFQUFFLENBQUM7Z0JBQy9EO29CQUNFLE9BQU8sR0FBRyxDQUFDO1lBQ2YsQ0FBQztRQUNILENBQUMsRUFBRSxFQUF1QixDQUFDLENBQUM7UUFFNUIsT0FBTyxJQUFJLDJCQUEyQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0tBQ2pEO0lBRUQ7Ozs7O09BS0c7SUFDSSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsS0FBd0I7Ozs7Ozs7Ozs7UUFDckQsT0FBTyxJQUFJLDJCQUEyQixDQUFDLEtBQUssQ0FBQyxDQUFDO0tBQy9DO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ00sTUFBTSxDQUFhO0lBRTVCOztPQUVHO0lBQ00saUJBQWlCLENBQXlDO0lBRW5FOztPQUVHO0lBQ00saUJBQWlCLENBQXlDO0lBRW5FOztPQUVHO0lBQ00sa0JBQWtCLENBQTBDO0lBRXJFOztPQUVHO0lBQ00scUJBQXFCLENBQTZDO0lBRTNFOztPQUVHO0lBQ00sdUJBQXVCLENBQStDO0lBRS9FOztPQUVHO0lBQ00sbUNBQW1DLENBQTJEO0lBRXZHOzs7O09BSUc7SUFDSCxZQUFvQixLQUF3QjtRQUMxQyxpQkFBaUI7UUFDakIsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3JELElBQUksS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2pCLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzlELENBQUM7UUFDRCxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUM7UUFDM0IsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztRQUNqRCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixDQUFDO1FBQ2pELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUMsa0JBQWtCLENBQUM7UUFDbkQsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQztRQUN6RCxJQUFJLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDLHVCQUF1QixDQUFDO1FBQzdELElBQUksQ0FBQyxtQ0FBbUMsR0FBRyxLQUFLLENBQUMsbUNBQW1DLENBQUM7S0FDdEY7SUFFRDs7OztPQUlHO0lBQ0ksT0FBTztRQUNaLE1BQU0sY0FBYyxHQUEyQyxFQUFFLENBQUM7UUFFbEUsc0RBQXNEO1FBQ3RELE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQyxJQUFzQyxFQUFFLElBQW1CLEVBQUUsRUFBRTtZQUN2RixJQUFJLElBQUksRUFBRSxDQUFDO2dCQUNULGNBQWMsQ0FBQyxJQUFJLENBQUM7b0JBQ2xCLFVBQVUsRUFBRSxJQUFJO29CQUNoQixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVcsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVO29CQUNuRyxVQUFVLEVBQUUsSUFBSSxDQUFDLGVBQWUsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxTQUFTO29CQUM1RyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsb0JBQW9CLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxTQUFTO29CQUM5SCxrQkFBa0IsRUFBRSxJQUFJLENBQUMsb0JBQW9CO29CQUM3QyxzQkFBc0IsRUFBRSxJQUFJLENBQUMsZUFBZTtvQkFDNUMsNkRBQTZEO29CQUM3RCxlQUFlLEVBQUUsSUFBSSxLQUFLLGFBQWEsQ0FBQyxrQkFBa0I7d0JBQ3hELENBQUMsQ0FBRSxJQUFrRCxDQUFDLGVBQWUsRUFBRSxZQUFZO3dCQUNuRixDQUFDLENBQUMsU0FBUztpQkFDZCxDQUFDLENBQUM7WUFDTCxDQUFDO1FBQ0gsQ0FBQyxDQUFDO1FBRUYsbURBQW1EO1FBQ25ELGdCQUFnQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxhQUFhLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDdkUsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUN0RSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQ3pFLGdCQUFnQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxhQUFhLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUMvRSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsYUFBYSxDQUFDLG9CQUFvQixDQUFDLENBQUM7UUFDbkYsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLG1DQUFtQyxFQUFFLGFBQWEsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO1FBRTdHLE9BQU87WUFDTCxjQUFjLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxXQUFXO1lBQ3hDLG9CQUFvQixFQUFFLGNBQWM7U0FDckMsQ0FBQztLQUNIO0lBRU8sdUJBQXVCLEdBQUcsQ0FBQyxNQUErQixFQUFZLEVBQUU7UUFDOUUsTUFBTSxNQUFNLEdBQWEsRUFBRSxDQUFDO1FBQzVCLElBQUksTUFBTSxFQUFFLENBQUM7WUFDWCxJQUFJLE1BQU0sQ0FBQyxXQUFXLEdBQUcsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxXQUFXLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQ3JELE1BQU0sQ0FBQyxJQUFJLENBQUMscUNBQXFDLENBQUMsQ0FBQztZQUNyRCxDQUFDO1lBQ0QsSUFBSSxNQUFNLENBQUMsSUFBSSxHQUFHLENBQUMsSUFBSSxNQUFNLENBQUMsSUFBSSxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUN2QyxNQUFNLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUM7WUFDOUMsQ0FBQztZQUNELElBQUksTUFBTSxDQUFDLElBQUksR0FBRyxDQUFDLElBQUksTUFBTSxDQUFDLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztnQkFDekMsTUFBTSxDQUFDLElBQUksQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO1lBQ2hELENBQUM7WUFDRCxJQUFJLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUNwQyxNQUFNLENBQUMsSUFBSSxDQUFDLGtDQUFrQyxDQUFDLENBQUM7WUFDbEQsQ0FBQztZQUNELElBQUksTUFBTSxDQUFDLGFBQWEsR0FBRyxDQUFDLElBQUksTUFBTSxDQUFDLGFBQWEsR0FBRyxJQUFJLEVBQUUsQ0FBQztnQkFDNUQsTUFBTSxDQUFDLElBQUksQ0FBQywwQ0FBMEMsQ0FBQyxDQUFDO1lBQzFELENBQUM7UUFDSCxDQUFDO1FBQ0QsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQyxDQUFDO0lBRU0sYUFBYSxHQUFHLENBQUMsS0FBd0IsRUFBWSxFQUFFO1FBQzdELE1BQU0sTUFBTSxHQUFhLEVBQUUsQ0FBQztRQUU1QixpQ0FBaUM7UUFDakMsTUFBTSxRQUFRLEdBQUc7WUFDZixLQUFLLENBQUMsaUJBQWlCO1lBQ3ZCLEtBQUssQ0FBQyxpQkFBaUI7WUFDdkIsS0FBSyxDQUFDLGtCQUFrQjtZQUN4QixLQUFLLENBQUMscUJBQXFCO1lBQzNCLEtBQUssQ0FBQyx1QkFBdUI7WUFDN0IsS0FBSyxDQUFDLG1DQUFtQztTQUMxQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksS0FBSyxTQUFTLENBQUMsQ0FBQztRQUVuQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDZCxNQUFNLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDLENBQUM7UUFDN0MsQ0FBQztRQUVELHdEQUF3RDtRQUN4RCxNQUFNLFlBQVksR0FBRyxDQUFDLElBQXNDLEVBQUUsUUFBZ0IsRUFBRSxFQUFFO1lBQ2hGLElBQUksSUFBSSxFQUFFLENBQUM7Z0JBQ1QsNkRBQTZEO2dCQUM3RCxJQUFJLGlCQUFpQixJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLGFBQWEsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO29CQUNwRixNQUFNLENBQUMsSUFBSSxDQUFDLHlFQUF5RSxDQUFDLENBQUM7Z0JBQ3pGLENBQUM7Z0JBRUQsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFDM0UsSUFBSSxlQUFlLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUMvQixNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsUUFBUSxVQUFVLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNqRSxDQUFDO1lBQ0gsQ0FBQztRQUNILENBQUMsQ0FBQztRQUVGLHdDQUF3QztRQUN4QyxZQUFZLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLGdCQUFnQixDQUFDLENBQUM7UUFDeEQsWUFBWSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxlQUFlLENBQUMsQ0FBQztRQUN2RCxZQUFZLENBQUMsS0FBSyxDQUFDLGtCQUFrQixFQUFFLGlCQUFpQixDQUFDLENBQUM7UUFDMUQsWUFBWSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO1FBQ2hFLFlBQVksQ0FBQyxLQUFLLENBQUMsdUJBQXVCLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztRQUNwRSxZQUFZLENBQUMsS0FBSyxDQUFDLG1DQUFtQyxFQUFFLG9DQUFvQyxDQUFDLENBQUM7UUFFOUYsNkRBQTZEO1FBQzdELElBQUksS0FBSyxDQUFDLHFCQUFxQixFQUFFLGVBQWUsRUFBRSxDQUFDO1lBQ2pELElBQUksQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsZUFBZSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUM5RCxNQUFNLENBQUMsSUFBSSxDQUFDLHlFQUF5RSxDQUFDLENBQUM7WUFDekYsQ0FBQztRQUNILENBQUM7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDLENBQUM7SUFFTSxvQkFBb0IsR0FBRyxDQUFDLEtBQXdCLEVBQVksRUFBRTtRQUNwRSxNQUFNLE1BQU0sR0FBYSxFQUFFLENBQUM7UUFFNUIsZ0RBQWdEO1FBQ2hELE1BQU0sZUFBZSxHQUFHO1lBQ3RCLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxlQUFlO1lBQ3hDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxlQUFlO1lBQ3hDLEtBQUssQ0FBQyxrQkFBa0IsRUFBRSxlQUFlO1lBQ3pDLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSxlQUFlO1lBQzVDLEtBQUssQ0FBQyx1QkFBdUIsRUFBRSxlQUFlO1lBQzlDLEtBQUssQ0FBQyxtQ0FBbUMsRUFBRSxlQUFlO1NBQzNELENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsZUFBZSxLQUFLLElBQUksQ0FBQyxDQUFDO1FBRXBELElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUNyQixNQUFNLENBQUMsSUFBSSxDQUFDLDBDQUEwQyxDQUFDLENBQUM7UUFDMUQsQ0FBQztRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUMsQ0FBQzs7QUFoUEosa0VBaVBDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBDZm5BZ2VudCB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1iZWRyb2NrJztcbmltcG9ydCB0eXBlIHsgSUZ1bmN0aW9uIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWxhbWJkYSc7XG5pbXBvcnQgKiBhcyB2YWxpZGF0aW9uIGZyb20gJy4vdmFsaWRhdGlvbi1oZWxwZXJzJztcbmltcG9ydCB0eXBlIHsgSUJlZHJvY2tJbnZva2FibGUgfSBmcm9tICcuLi9tb2RlbHMnO1xuXG4vKipcbiAqIFRoZSBzdGVwIGluIHRoZSBhZ2VudCBzZXF1ZW5jZSB0aGF0IHRoaXMgcHJvbXB0IGNvbmZpZ3VyYXRpb24gYXBwbGllcyB0by5cbiAqL1xuZXhwb3J0IGVudW0gQWdlbnRTdGVwVHlwZSB7XG4gIC8qKlxuICAgKiBQcmUtcHJvY2Vzc2luZyBzdGVwIHRoYXQgcHJlcGFyZXMgdGhlIHVzZXIgaW5wdXQgZm9yIG9yY2hlc3RyYXRpb24uXG4gICAqL1xuICBQUkVfUFJPQ0VTU0lORyA9ICdQUkVfUFJPQ0VTU0lORycsXG5cbiAgLyoqXG4gICAqIE1haW4gb3JjaGVzdHJhdGlvbiBzdGVwIHRoYXQgZGV0ZXJtaW5lcyB0aGUgYWdlbnQncyBhY3Rpb25zLlxuICAgKi9cbiAgT1JDSEVTVFJBVElPTiA9ICdPUkNIRVNUUkFUSU9OJyxcblxuICAvKipcbiAgICogUG9zdC1wcm9jZXNzaW5nIHN0ZXAgdGhhdCByZWZpbmVzIHRoZSBhZ2VudCdzIHJlc3BvbnNlLlxuICAgKi9cbiAgUE9TVF9QUk9DRVNTSU5HID0gJ1BPU1RfUFJPQ0VTU0lORycsXG5cbiAgLyoqXG4gICAqIFN0ZXAgdGhhdCBjbGFzc2lmaWVzIGFuZCByb3V0ZXMgcmVxdWVzdHMgdG8gYXBwcm9wcmlhdGUgY29sbGFib3JhdG9ycy5cbiAgICovXG4gIFJPVVRJTkdfQ0xBU1NJRklFUiA9ICdST1VUSU5HX0NMQVNTSUZJRVInLFxuXG4gIC8qKlxuICAgKiBTdGVwIHRoYXQgc3VtbWFyaXplcyBjb252ZXJzYXRpb24gaGlzdG9yeSBmb3IgbWVtb3J5IHJldGVudGlvbi5cbiAgICovXG4gIE1FTU9SWV9TVU1NQVJJWkFUSU9OID0gJ01FTU9SWV9TVU1NQVJJWkFUSU9OJyxcblxuICAvKipcbiAgICogU3RlcCB0aGF0IGdlbmVyYXRlcyByZXNwb25zZXMgdXNpbmcga25vd2xlZGdlIGJhc2UgY29udGVudC5cbiAgICovXG4gIEtOT1dMRURHRV9CQVNFX1JFU1BPTlNFX0dFTkVSQVRJT04gPSAnS05PV0xFREdFX0JBU0VfUkVTUE9OU0VfR0VORVJBVElPTicsXG59XG5cbi8qKlxuICogTExNIGluZmVyZW5jZSBjb25maWd1cmF0aW9uXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSW5mZXJlbmNlQ29uZmlndXJhdGlvbiB7XG4gIC8qKlxuICAgKiBUaGUgbGlrZWxpaG9vZCBvZiB0aGUgbW9kZWwgc2VsZWN0aW5nIGhpZ2hlci1wcm9iYWJpbGl0eSBvcHRpb25zIHdoaWxlXG4gICAqIGdlbmVyYXRpbmcgYSByZXNwb25zZS4gQSBsb3dlciB2YWx1ZSBtYWtlcyB0aGUgbW9kZWwgbW9yZSBsaWtlbHkgdG8gY2hvb3NlXG4gICAqIGhpZ2hlci1wcm9iYWJpbGl0eSBvcHRpb25zLCB3aGlsZSBhIGhpZ2hlciB2YWx1ZSBtYWtlcyB0aGUgbW9kZWwgbW9yZVxuICAgKiBsaWtlbHkgdG8gY2hvb3NlIGxvd2VyLXByb2JhYmlsaXR5IG9wdGlvbnMuXG4gICAqXG4gICAqIEZsb2F0aW5nIHBvaW50XG4gICAqXG4gICAqIG1pbiAwXG4gICAqIG1heCAxXG4gICAqL1xuICByZWFkb25seSB0ZW1wZXJhdHVyZTogbnVtYmVyO1xuICAvKipcbiAgICogV2hpbGUgZ2VuZXJhdGluZyBhIHJlc3BvbnNlLCB0aGUgbW9kZWwgZGV0ZXJtaW5lcyB0aGUgcHJvYmFiaWxpdHkgb2YgdGhlXG4gICAqIGZvbGxvd2luZyB0b2tlbiBhdCBlYWNoIHBvaW50IG9mIGdlbmVyYXRpb24uIFRoZSB2YWx1ZSB0aGF0IHlvdSBzZXQgZm9yXG4gICAqIFRvcCBQIGRldGVybWluZXMgdGhlIG51bWJlciBvZiBtb3N0LWxpa2VseSBjYW5kaWRhdGVzIGZyb20gd2hpY2ggdGhlIG1vZGVsXG4gICAqIGNob29zZXMgdGhlIG5leHQgdG9rZW4gaW4gdGhlIHNlcXVlbmNlLiBGb3IgZXhhbXBsZSwgaWYgeW91IHNldCB0b3BQIHRvXG4gICAqIDgwLCB0aGUgbW9kZWwgb25seSBzZWxlY3RzIHRoZSBuZXh0IHRva2VuIGZyb20gdGhlIHRvcCA4MCUgb2YgdGhlXG4gICAqIHByb2JhYmlsaXR5IGRpc3RyaWJ1dGlvbiBvZiBuZXh0IHRva2Vucy5cbiAgICpcbiAgICogRmxvYXRpbmcgcG9pbnRcbiAgICpcbiAgICogbWluIDBcbiAgICogbWF4IDFcbiAgICovXG4gIHJlYWRvbmx5IHRvcFA6IG51bWJlcjtcbiAgLyoqXG4gICAqIFdoaWxlIGdlbmVyYXRpbmcgYSByZXNwb25zZSwgdGhlIG1vZGVsIGRldGVybWluZXMgdGhlIHByb2JhYmlsaXR5IG9mIHRoZVxuICAgKiBmb2xsb3dpbmcgdG9rZW4gYXQgZWFjaCBwb2ludCBvZiBnZW5lcmF0aW9uLiBUaGUgdmFsdWUgdGhhdCB5b3Ugc2V0IGZvclxuICAgKiB0b3BLIGlzIHRoZSBudW1iZXIgb2YgbW9zdC1saWtlbHkgY2FuZGlkYXRlcyBmcm9tIHdoaWNoIHRoZSBtb2RlbCBjaG9vc2VzXG4gICAqIHRoZSBuZXh0IHRva2VuIGluIHRoZSBzZXF1ZW5jZS4gRm9yIGV4YW1wbGUsIGlmIHlvdSBzZXQgdG9wSyB0byA1MCwgdGhlXG4gICAqIG1vZGVsIHNlbGVjdHMgdGhlIG5leHQgdG9rZW4gZnJvbSBhbW9uZyB0aGUgdG9wIDUwIG1vc3QgbGlrZWx5IGNob2ljZXMuXG4gICAqXG4gICAqIEludGVnZXJcbiAgICpcbiAgICogbWluIDBcbiAgICogbWF4IDUwMFxuICAgKi9cbiAgcmVhZG9ubHkgdG9wSzogbnVtYmVyO1xuICAvKipcbiAgICogQSBsaXN0IG9mIHN0b3Agc2VxdWVuY2VzLiBBIHN0b3Agc2VxdWVuY2UgaXMgYSBzZXF1ZW5jZSBvZiBjaGFyYWN0ZXJzIHRoYXRcbiAgICogY2F1c2VzIHRoZSBtb2RlbCB0byBzdG9wIGdlbmVyYXRpbmcgdGhlIHJlc3BvbnNlLlxuICAgKlxuICAgKiBsZW5ndGggMC00XG4gICAqL1xuICByZWFkb25seSBzdG9wU2VxdWVuY2VzOiBzdHJpbmdbXTtcbiAgLyoqXG4gICAqIFRoZSBtYXhpbXVtIG51bWJlciBvZiB0b2tlbnMgdG8gZ2VuZXJhdGUgaW4gdGhlIHJlc3BvbnNlLlxuICAgKlxuICAgKiBJbnRlZ2VyXG4gICAqXG4gICAqIG1pbiAwXG4gICAqIG1heCA0MDk2XG4gICAqL1xuICByZWFkb25seSBtYXhpbXVtTGVuZ3RoOiBudW1iZXI7XG59XG5cbi8qKlxuICogQmFzZSBjb25maWd1cmF0aW9uIGludGVyZmFjZSBmb3IgYWxsIHByb21wdCBzdGVwIHR5cGVzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0U3RlcENvbmZpZ0Jhc2Uge1xuICAvKipcbiAgICogVGhlIHR5cGUgb2Ygc3RlcCB0aGlzIGNvbmZpZ3VyYXRpb24gYXBwbGllcyB0by5cbiAgICovXG4gIHJlYWRvbmx5IHN0ZXBUeXBlOiBBZ2VudFN0ZXBUeXBlO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIGVuYWJsZSBvciBza2lwIHRoaXMgc3RlcCBpbiB0aGUgYWdlbnQgc2VxdWVuY2UuXG4gICAqIEBkZWZhdWx0IC0gVGhlIGRlZmF1bHQgc3RhdGUgZm9yIGVhY2ggc3RlcCB0eXBlIGlzIGFzIGZvbGxvd3MuXG4gICAqXG4gICAqICAgICBQUkVfUFJPQ0VTU0lORyDigJMgRU5BQkxFRFxuICAgKiAgICAgT1JDSEVTVFJBVElPTiDigJMgRU5BQkxFRFxuICAgKiAgICAgS05PV0xFREdFX0JBU0VfUkVTUE9OU0VfR0VORVJBVElPTiDigJMgRU5BQkxFRFxuICAgKiAgICAgUE9TVF9QUk9DRVNTSU5HIOKAkyBESVNBQkxFRFxuICAgKi9cbiAgcmVhZG9ubHkgc3RlcEVuYWJsZWQ/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBUaGUgY3VzdG9tIHByb21wdCB0ZW1wbGF0ZSB0byBiZSB1c2VkLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIFRoZSBkZWZhdWx0IHByb21wdCB0ZW1wbGF0ZSB3aWxsIGJlIHVzZWQuXG4gICAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9wcm9tcHQtcGxhY2Vob2xkZXJzLmh0bWxcbiAgICovXG4gIHJlYWRvbmx5IGN1c3RvbVByb21wdFRlbXBsYXRlPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgaW5mZXJlbmNlIGNvbmZpZ3VyYXRpb24gcGFyYW1ldGVycyB0byB1c2UuXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIERlZmF1bHQgaW5mZXJlbmNlIGNvbmZpZ3VyYXRpb24gd2lsbCBiZSB1c2VkXG4gICAqL1xuICByZWFkb25seSBpbmZlcmVuY2VDb25maWc/OiBJbmZlcmVuY2VDb25maWd1cmF0aW9uO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIHVzZSB0aGUgY3VzdG9tIExhbWJkYSBwYXJzZXIgZGVmaW5lZCBmb3IgdGhlIHNlcXVlbmNlLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIGZhbHNlXG4gICAqL1xuICByZWFkb25seSB1c2VDdXN0b21QYXJzZXI/OiBib29sZWFuO1xufVxuXG4vKipcbiAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSBwcmUtcHJvY2Vzc2luZyBzdGVwXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0UHJlUHJvY2Vzc2luZ0NvbmZpZ0N1c3RvbVBhcnNlciBleHRlbmRzIFByb21wdFN0ZXBDb25maWdCYXNlIHt9XG5cbi8qKlxuICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIG9yY2hlc3RyYXRpb24gc3RlcFxuICovXG5leHBvcnQgaW50ZXJmYWNlIFByb21wdE9yY2hlc3RyYXRpb25Db25maWdDdXN0b21QYXJzZXIgZXh0ZW5kcyBQcm9tcHRTdGVwQ29uZmlnQmFzZSB7fVxuXG4vKipcbiAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSBwb3N0LXByb2Nlc3Npbmcgc3RlcFxuICovXG5leHBvcnQgaW50ZXJmYWNlIFByb21wdFBvc3RQcm9jZXNzaW5nQ29uZmlnQ3VzdG9tUGFyc2VyIGV4dGVuZHMgUHJvbXB0U3RlcENvbmZpZ0Jhc2Uge31cblxuLyoqXG4gKiBDb25maWd1cmF0aW9uIGZvciB0aGUgcm91dGluZyBjbGFzc2lmaWVyIHN0ZXBcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBQcm9tcHRSb3V0aW5nQ2xhc3NpZmllckNvbmZpZ0N1c3RvbVBhcnNlciBleHRlbmRzIFByb21wdFN0ZXBDb25maWdCYXNlIHtcbiAgLyoqXG4gICAqIFRoZSBmb3VuZGF0aW9uIG1vZGVsIHRvIHVzZSBmb3IgdGhlIHJvdXRpbmcgY2xhc3NpZmllciBzdGVwLlxuICAgKiBUaGlzIGlzIHJlcXVpcmVkIGZvciB0aGUgcm91dGluZyBjbGFzc2lmaWVyIHN0ZXAuXG4gICAqL1xuICByZWFkb25seSBmb3VuZGF0aW9uTW9kZWw6IElCZWRyb2NrSW52b2thYmxlO1xufVxuXG4vKipcbiAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSBtZW1vcnkgc3VtbWFyaXphdGlvbiBzdGVwXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0TWVtb3J5U3VtbWFyaXphdGlvbkNvbmZpZ0N1c3RvbVBhcnNlciBleHRlbmRzIFByb21wdFN0ZXBDb25maWdCYXNlIHt9XG5cbi8qKlxuICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIGtub3dsZWRnZSBiYXNlIHJlc3BvbnNlIGdlbmVyYXRpb24gc3RlcFxuICovXG5leHBvcnQgaW50ZXJmYWNlIFByb21wdEtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25Db25maWdDdXN0b21QYXJzZXIgZXh0ZW5kcyBQcm9tcHRTdGVwQ29uZmlnQmFzZSB7fVxuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNvbmZpZ3VyaW5nIGEgY3VzdG9tIExhbWJkYSBwYXJzZXIgZm9yIHByb21wdCBvdmVycmlkZXMuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ3VzdG9tUGFyc2VyUHJvcHMge1xuICAvKipcbiAgICogTGFtYmRhIGZ1bmN0aW9uIHRvIHVzZSBhcyBjdXN0b20gcGFyc2VyLlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBjdXN0b20gcGFyc2VyIGlzIHVzZWRcbiAgICovXG4gIHJlYWRvbmx5IHBhcnNlcj86IElGdW5jdGlvbjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIHByZS1wcm9jZXNzaW5nIHN0ZXAuXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIHByZS1wcm9jZXNzaW5nIGNvbmZpZ3VyYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IHByZVByb2Nlc3NpbmdTdGVwPzogUHJvbXB0UHJlUHJvY2Vzc2luZ0NvbmZpZ0N1c3RvbVBhcnNlcjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIG9yY2hlc3RyYXRpb24gc3RlcC5cbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8gb3JjaGVzdHJhdGlvbiBjb25maWd1cmF0aW9uXG4gICAqL1xuICByZWFkb25seSBvcmNoZXN0cmF0aW9uU3RlcD86IFByb21wdE9yY2hlc3RyYXRpb25Db25maWdDdXN0b21QYXJzZXI7XG5cbiAgLyoqXG4gICAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSBwb3N0LXByb2Nlc3Npbmcgc3RlcC5cbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8gcG9zdC1wcm9jZXNzaW5nIGNvbmZpZ3VyYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IHBvc3RQcm9jZXNzaW5nU3RlcD86IFByb21wdFBvc3RQcm9jZXNzaW5nQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUgcm91dGluZyBjbGFzc2lmaWVyIHN0ZXAuXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIHJvdXRpbmcgY2xhc3NpZmllciBjb25maWd1cmF0aW9uXG4gICAqL1xuICByZWFkb25seSByb3V0aW5nQ2xhc3NpZmllclN0ZXA/OiBQcm9tcHRSb3V0aW5nQ2xhc3NpZmllckNvbmZpZ0N1c3RvbVBhcnNlcjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIG1lbW9yeSBzdW1tYXJpemF0aW9uIHN0ZXAuXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIG1lbW9yeSBzdW1tYXJpemF0aW9uIGNvbmZpZ3VyYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IG1lbW9yeVN1bW1hcml6YXRpb25TdGVwPzogUHJvbXB0TWVtb3J5U3VtbWFyaXphdGlvbkNvbmZpZ0N1c3RvbVBhcnNlcjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIGtub3dsZWRnZSBiYXNlIHJlc3BvbnNlIGdlbmVyYXRpb24gc3RlcC5cbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8ga25vd2xlZGdlIGJhc2UgcmVzcG9uc2UgZ2VuZXJhdGlvbiBjb25maWd1cmF0aW9uXG4gICAqL1xuICByZWFkb25seSBrbm93bGVkZ2VCYXNlUmVzcG9uc2VHZW5lcmF0aW9uU3RlcD86IFByb21wdEtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25Db25maWdDdXN0b21QYXJzZXI7XG59XG5cbi8qKlxuICogQ29uZmlndXJhdGlvbiBmb3Igb3ZlcnJpZGluZyBwcm9tcHQgdGVtcGxhdGVzIGFuZCBiZWhhdmlvcnMgaW4gZGlmZmVyZW50IHBhcnRzXG4gKiBvZiBhbiBhZ2VudCdzIHNlcXVlbmNlLiBUaGlzIGFsbG93cyBjdXN0b21pemluZyBob3cgdGhlIGFnZW50IHByb2Nlc3NlcyBpbnB1dHMsXG4gKiBtYWtlcyBkZWNpc2lvbnMsIGFuZCBnZW5lcmF0ZXMgcmVzcG9uc2VzLlxuICovXG5leHBvcnQgY2xhc3MgUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBQcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb24gZnJvbSBpbmRpdmlkdWFsIHN0ZXAgY29uZmlndXJhdGlvbnMuXG4gICAqIFVzZSB0aGlzIG1ldGhvZCB3aGVuIHlvdSB3YW50IHRvIG92ZXJyaWRlIHByb21wdHMgd2l0aG91dCB1c2luZyBhIGN1c3RvbSBwYXJzZXIuXG4gICAqIEBwYXJhbSBzdGVwcyBUaGUgc3RlcCBjb25maWd1cmF0aW9ucyB0byB1c2VcbiAgICogQHJldHVybnMgQSBuZXcgUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uIGluc3RhbmNlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21TdGVwcyhzdGVwczogUHJvbXB0U3RlcENvbmZpZ0Jhc2VbXSk6IFByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbiB7XG4gICAgaWYgKCFzdGVwcyB8fCBzdGVwcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IG5ldyB2YWxpZGF0aW9uLlZhbGlkYXRpb25FcnJvcignU3RlcHMgYXJyYXkgY2Fubm90IGJlIGVtcHR5Jyk7XG4gICAgfVxuXG4gICAgLy8gQ29udmVydCBzdGVwcyBhcnJheSB0byBwcm9wcyBmb3JtYXRcbiAgICBjb25zdCBzdGVwTWFwID0gc3RlcHMucmVkdWNlKChhY2MsIHN0ZXApID0+IHtcbiAgICAgIHN3aXRjaCAoc3RlcC5zdGVwVHlwZSkge1xuICAgICAgICBjYXNlIEFnZW50U3RlcFR5cGUuUFJFX1BST0NFU1NJTkc6XG4gICAgICAgICAgcmV0dXJuIHsgLi4uYWNjLCBwcmVQcm9jZXNzaW5nU3RlcDogc3RlcCB9O1xuICAgICAgICBjYXNlIEFnZW50U3RlcFR5cGUuT1JDSEVTVFJBVElPTjpcbiAgICAgICAgICByZXR1cm4geyAuLi5hY2MsIG9yY2hlc3RyYXRpb25TdGVwOiBzdGVwIH07XG4gICAgICAgIGNhc2UgQWdlbnRTdGVwVHlwZS5QT1NUX1BST0NFU1NJTkc6XG4gICAgICAgICAgcmV0dXJuIHsgLi4uYWNjLCBwb3N0UHJvY2Vzc2luZ1N0ZXA6IHN0ZXAgfTtcbiAgICAgICAgY2FzZSBBZ2VudFN0ZXBUeXBlLlJPVVRJTkdfQ0xBU1NJRklFUjpcbiAgICAgICAgICByZXR1cm4geyAuLi5hY2MsIHJvdXRpbmdDbGFzc2lmaWVyU3RlcDogc3RlcCBhcyBQcm9tcHRSb3V0aW5nQ2xhc3NpZmllckNvbmZpZ0N1c3RvbVBhcnNlciB9O1xuICAgICAgICBjYXNlIEFnZW50U3RlcFR5cGUuTUVNT1JZX1NVTU1BUklaQVRJT046XG4gICAgICAgICAgcmV0dXJuIHsgLi4uYWNjLCBtZW1vcnlTdW1tYXJpemF0aW9uU3RlcDogc3RlcCB9O1xuICAgICAgICBjYXNlIEFnZW50U3RlcFR5cGUuS05PV0xFREdFX0JBU0VfUkVTUE9OU0VfR0VORVJBVElPTjpcbiAgICAgICAgICByZXR1cm4geyAuLi5hY2MsIGtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25TdGVwOiBzdGVwIH07XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgcmV0dXJuIGFjYztcbiAgICAgIH1cbiAgICB9LCB7fSBhcyBDdXN0b21QYXJzZXJQcm9wcyk7XG5cbiAgICByZXR1cm4gbmV3IFByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbihzdGVwTWFwKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uIHdpdGggYSBjdXN0b20gTGFtYmRhIHBhcnNlciBmdW5jdGlvbi5cbiAgICogQHBhcmFtIHByb3BzIENvbmZpZ3VyYXRpb24gaW5jbHVkaW5nOlxuICAgKiAgIC0gYHBhcnNlcmA6IExhbWJkYSBmdW5jdGlvbiB0byB1c2UgYXMgY3VzdG9tIHBhcnNlclxuICAgKiAgIC0gSW5kaXZpZHVhbCBzdGVwIGNvbmZpZ3VyYXRpb25zLiBBdCBsZWFzdCBvbmUgb2YgdGhlIHN0ZXBzIG11c3QgbWFrZSB1c2Ugb2YgdGhlIGN1c3RvbSBwYXJzZXIuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHdpdGhDdXN0b21QYXJzZXIocHJvcHM6IEN1c3RvbVBhcnNlclByb3BzKTogUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uIHtcbiAgICByZXR1cm4gbmV3IFByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbihwcm9wcyk7XG4gIH1cblxuICAvKipcbiAgICogVGhlIGN1c3RvbSBMYW1iZGEgcGFyc2VyIGZ1bmN0aW9uIHRvIHVzZS5cbiAgICogVGhlIExhbWJkYSBwYXJzZXIgcHJvY2Vzc2VzIGFuZCBpbnRlcnByZXRzIHRoZSByYXcgZm91bmRhdGlvbiBtb2RlbCBvdXRwdXQuXG4gICAqIEl0IHJlY2VpdmVzIGFuIGlucHV0IGV2ZW50IHdpdGg6XG4gICAqIC0gbWVzc2FnZVZlcnNpb246IFZlcnNpb24gb2YgbWVzc2FnZSBmb3JtYXQgKDEuMClcbiAgICogLSBhZ2VudDogSW5mbyBhYm91dCB0aGUgYWdlbnQgKG5hbWUsIGlkLCBhbGlhcywgdmVyc2lvbilcbiAgICogLSBpbnZva2VNb2RlbFJhd1Jlc3BvbnNlOiBSYXcgbW9kZWwgb3V0cHV0IHRvIHBhcnNlXG4gICAqIC0gcHJvbXB0VHlwZTogVHlwZSBvZiBwcm9tcHQgYmVpbmcgcGFyc2VkXG4gICAqIC0gb3ZlcnJpZGVUeXBlOiBUeXBlIG9mIG92ZXJyaWRlIChPVVRQVVRfUEFSU0VSKVxuICAgKlxuICAgKiBUaGUgTGFtYmRhIG11c3QgcmV0dXJuIGEgcmVzcG9uc2UgdGhhdCB0aGUgYWdlbnQgdXNlcyBmb3IgbmV4dCBhY3Rpb25zLlxuICAgKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9iZWRyb2NrL2xhdGVzdC91c2VyZ3VpZGUvbGFtYmRhLXBhcnNlci5odG1sXG4gICAqL1xuICByZWFkb25seSBwYXJzZXI/OiBJRnVuY3Rpb247XG5cbiAgLyoqXG4gICAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSBwcmUtcHJvY2Vzc2luZyBzdGVwLlxuICAgKi9cbiAgcmVhZG9ubHkgcHJlUHJvY2Vzc2luZ1N0ZXA/OiBQcm9tcHRQcmVQcm9jZXNzaW5nQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUgb3JjaGVzdHJhdGlvbiBzdGVwLlxuICAgKi9cbiAgcmVhZG9ubHkgb3JjaGVzdHJhdGlvblN0ZXA/OiBQcm9tcHRPcmNoZXN0cmF0aW9uQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUgcG9zdC1wcm9jZXNzaW5nIHN0ZXAuXG4gICAqL1xuICByZWFkb25seSBwb3N0UHJvY2Vzc2luZ1N0ZXA/OiBQcm9tcHRQb3N0UHJvY2Vzc2luZ0NvbmZpZ0N1c3RvbVBhcnNlcjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIHJvdXRpbmcgY2xhc3NpZmllciBzdGVwLlxuICAgKi9cbiAgcmVhZG9ubHkgcm91dGluZ0NsYXNzaWZpZXJTdGVwPzogUHJvbXB0Um91dGluZ0NsYXNzaWZpZXJDb25maWdDdXN0b21QYXJzZXI7XG5cbiAgLyoqXG4gICAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSBtZW1vcnkgc3VtbWFyaXphdGlvbiBzdGVwLlxuICAgKi9cbiAgcmVhZG9ubHkgbWVtb3J5U3VtbWFyaXphdGlvblN0ZXA/OiBQcm9tcHRNZW1vcnlTdW1tYXJpemF0aW9uQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUga25vd2xlZGdlIGJhc2UgcmVzcG9uc2UgZ2VuZXJhdGlvbiBzdGVwLlxuICAgKi9cbiAgcmVhZG9ubHkga25vd2xlZGdlQmFzZVJlc3BvbnNlR2VuZXJhdGlvblN0ZXA/OiBQcm9tcHRLbm93bGVkZ2VCYXNlUmVzcG9uc2VHZW5lcmF0aW9uQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDcmVhdGUgYSBuZXcgUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uLlxuICAgKlxuICAgKiBAaW50ZXJuYWwgLSBUaGlzIGlzIG1hcmtlZCBhcyBwcml2YXRlIHNvIGVuZCB1c2VycyBsZXZlcmFnZSBpdCBvbmx5IHRocm91Z2ggc3RhdGljIG1ldGhvZHNcbiAgICovXG4gIHByaXZhdGUgY29uc3RydWN0b3IocHJvcHM6IEN1c3RvbVBhcnNlclByb3BzKSB7XG4gICAgLy8gVmFsaWRhdGUgcHJvcHNcbiAgICB2YWxpZGF0aW9uLnRocm93SWZJbnZhbGlkKHRoaXMudmFsaWRhdGVTdGVwcywgcHJvcHMpO1xuICAgIGlmIChwcm9wcy5wYXJzZXIpIHtcbiAgICAgIHZhbGlkYXRpb24udGhyb3dJZkludmFsaWQodGhpcy52YWxpZGF0ZUN1c3RvbVBhcnNlciwgcHJvcHMpO1xuICAgIH1cbiAgICB0aGlzLnBhcnNlciA9IHByb3BzLnBhcnNlcjtcbiAgICB0aGlzLnByZVByb2Nlc3NpbmdTdGVwID0gcHJvcHMucHJlUHJvY2Vzc2luZ1N0ZXA7XG4gICAgdGhpcy5vcmNoZXN0cmF0aW9uU3RlcCA9IHByb3BzLm9yY2hlc3RyYXRpb25TdGVwO1xuICAgIHRoaXMucG9zdFByb2Nlc3NpbmdTdGVwID0gcHJvcHMucG9zdFByb2Nlc3NpbmdTdGVwO1xuICAgIHRoaXMucm91dGluZ0NsYXNzaWZpZXJTdGVwID0gcHJvcHMucm91dGluZ0NsYXNzaWZpZXJTdGVwO1xuICAgIHRoaXMubWVtb3J5U3VtbWFyaXphdGlvblN0ZXAgPSBwcm9wcy5tZW1vcnlTdW1tYXJpemF0aW9uU3RlcDtcbiAgICB0aGlzLmtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25TdGVwID0gcHJvcHMua25vd2xlZGdlQmFzZVJlc3BvbnNlR2VuZXJhdGlvblN0ZXA7XG4gIH1cblxuICAvKipcbiAgICogRm9ybWF0IGFzIENmbkFnZW50LlByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvblByb3BlcnR5XG4gICAqXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIF9yZW5kZXIoKTogQ2ZuQWdlbnQuUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uUHJvcGVydHkge1xuICAgIGNvbnN0IGNvbmZpZ3VyYXRpb25zOiBDZm5BZ2VudC5Qcm9tcHRDb25maWd1cmF0aW9uUHJvcGVydHlbXSA9IFtdO1xuXG4gICAgLy8gSGVscGVyIGZ1bmN0aW9uIHRvIGFkZCBjb25maWd1cmF0aW9uIGlmIHN0ZXAgZXhpc3RzXG4gICAgY29uc3QgYWRkQ29uZmlndXJhdGlvbiA9IChzdGVwOiBQcm9tcHRTdGVwQ29uZmlnQmFzZSB8IHVuZGVmaW5lZCwgdHlwZTogQWdlbnRTdGVwVHlwZSkgPT4ge1xuICAgICAgaWYgKHN0ZXApIHtcbiAgICAgICAgY29uZmlndXJhdGlvbnMucHVzaCh7XG4gICAgICAgICAgcHJvbXB0VHlwZTogdHlwZSxcbiAgICAgICAgICBwcm9tcHRTdGF0ZTogc3RlcC5zdGVwRW5hYmxlZCA9PT0gdW5kZWZpbmVkID8gdW5kZWZpbmVkIDogc3RlcC5zdGVwRW5hYmxlZCA/ICdFTkFCTEVEJyA6ICdESVNBQkxFRCcsXG4gICAgICAgICAgcGFyc2VyTW9kZTogc3RlcC51c2VDdXN0b21QYXJzZXIgPT09IHVuZGVmaW5lZCA/IHVuZGVmaW5lZCA6IHN0ZXAudXNlQ3VzdG9tUGFyc2VyID8gJ09WRVJSSURERU4nIDogJ0RFRkFVTFQnLFxuICAgICAgICAgIHByb21wdENyZWF0aW9uTW9kZTogc3RlcC5jdXN0b21Qcm9tcHRUZW1wbGF0ZSA9PT0gdW5kZWZpbmVkID8gdW5kZWZpbmVkIDogc3RlcC5jdXN0b21Qcm9tcHRUZW1wbGF0ZSA/ICdPVkVSUklEREVOJyA6ICdERUZBVUxUJyxcbiAgICAgICAgICBiYXNlUHJvbXB0VGVtcGxhdGU6IHN0ZXAuY3VzdG9tUHJvbXB0VGVtcGxhdGUsXG4gICAgICAgICAgaW5mZXJlbmNlQ29uZmlndXJhdGlvbjogc3RlcC5pbmZlcmVuY2VDb25maWcsXG4gICAgICAgICAgLy8gSW5jbHVkZSBmb3VuZGF0aW9uIG1vZGVsIGlmIGl0J3MgYSByb3V0aW5nIGNsYXNzaWZpZXIgc3RlcFxuICAgICAgICAgIGZvdW5kYXRpb25Nb2RlbDogdHlwZSA9PT0gQWdlbnRTdGVwVHlwZS5ST1VUSU5HX0NMQVNTSUZJRVJcbiAgICAgICAgICAgID8gKHN0ZXAgYXMgUHJvbXB0Um91dGluZ0NsYXNzaWZpZXJDb25maWdDdXN0b21QYXJzZXIpLmZvdW5kYXRpb25Nb2RlbD8uaW52b2thYmxlQXJuXG4gICAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIC8vIEFkZCBjb25maWd1cmF0aW9ucyBmb3IgZWFjaCBzdGVwIHR5cGUgaWYgZGVmaW5lZFxuICAgIGFkZENvbmZpZ3VyYXRpb24odGhpcy5wcmVQcm9jZXNzaW5nU3RlcCwgQWdlbnRTdGVwVHlwZS5QUkVfUFJPQ0VTU0lORyk7XG4gICAgYWRkQ29uZmlndXJhdGlvbih0aGlzLm9yY2hlc3RyYXRpb25TdGVwLCBBZ2VudFN0ZXBUeXBlLk9SQ0hFU1RSQVRJT04pO1xuICAgIGFkZENvbmZpZ3VyYXRpb24odGhpcy5wb3N0UHJvY2Vzc2luZ1N0ZXAsIEFnZW50U3RlcFR5cGUuUE9TVF9QUk9DRVNTSU5HKTtcbiAgICBhZGRDb25maWd1cmF0aW9uKHRoaXMucm91dGluZ0NsYXNzaWZpZXJTdGVwLCBBZ2VudFN0ZXBUeXBlLlJPVVRJTkdfQ0xBU1NJRklFUik7XG4gICAgYWRkQ29uZmlndXJhdGlvbih0aGlzLm1lbW9yeVN1bW1hcml6YXRpb25TdGVwLCBBZ2VudFN0ZXBUeXBlLk1FTU9SWV9TVU1NQVJJWkFUSU9OKTtcbiAgICBhZGRDb25maWd1cmF0aW9uKHRoaXMua25vd2xlZGdlQmFzZVJlc3BvbnNlR2VuZXJhdGlvblN0ZXAsIEFnZW50U3RlcFR5cGUuS05PV0xFREdFX0JBU0VfUkVTUE9OU0VfR0VORVJBVElPTik7XG5cbiAgICByZXR1cm4ge1xuICAgICAgb3ZlcnJpZGVMYW1iZGE6IHRoaXMucGFyc2VyPy5mdW5jdGlvbkFybixcbiAgICAgIHByb21wdENvbmZpZ3VyYXRpb25zOiBjb25maWd1cmF0aW9ucyxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSB2YWxpZGF0ZUluZmVyZW5jZUNvbmZpZyA9IChjb25maWc/OiBJbmZlcmVuY2VDb25maWd1cmF0aW9uKTogc3RyaW5nW10gPT4ge1xuICAgIGNvbnN0IGVycm9yczogc3RyaW5nW10gPSBbXTtcbiAgICBpZiAoY29uZmlnKSB7XG4gICAgICBpZiAoY29uZmlnLnRlbXBlcmF0dXJlIDwgMCB8fCBjb25maWcudGVtcGVyYXR1cmUgPiAxKSB7XG4gICAgICAgIGVycm9ycy5wdXNoKCdUZW1wZXJhdHVyZSBtdXN0IGJlIGJldHdlZW4gMCBhbmQgMScpO1xuICAgICAgfVxuICAgICAgaWYgKGNvbmZpZy50b3BQIDwgMCB8fCBjb25maWcudG9wUCA+IDEpIHtcbiAgICAgICAgZXJyb3JzLnB1c2goJ1RvcFAgbXVzdCBiZSBiZXR3ZWVuIDAgYW5kIDEnKTtcbiAgICAgIH1cbiAgICAgIGlmIChjb25maWcudG9wSyA8IDAgfHwgY29uZmlnLnRvcEsgPiA1MDApIHtcbiAgICAgICAgZXJyb3JzLnB1c2goJ1RvcEsgbXVzdCBiZSBiZXR3ZWVuIDAgYW5kIDUwMCcpO1xuICAgICAgfVxuICAgICAgaWYgKGNvbmZpZy5zdG9wU2VxdWVuY2VzLmxlbmd0aCA+IDQpIHtcbiAgICAgICAgZXJyb3JzLnB1c2goJ01heGltdW0gNCBzdG9wIHNlcXVlbmNlcyBhbGxvd2VkJyk7XG4gICAgICB9XG4gICAgICBpZiAoY29uZmlnLm1heGltdW1MZW5ndGggPCAwIHx8IGNvbmZpZy5tYXhpbXVtTGVuZ3RoID4gNDA5Nikge1xuICAgICAgICBlcnJvcnMucHVzaCgnTWF4aW11bUxlbmd0aCBtdXN0IGJlIGJldHdlZW4gMCBhbmQgNDA5NicpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZXJyb3JzO1xuICB9O1xuXG4gIHByaXZhdGUgdmFsaWRhdGVTdGVwcyA9IChwcm9wczogQ3VzdG9tUGFyc2VyUHJvcHMpOiBzdHJpbmdbXSA9PiB7XG4gICAgY29uc3QgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgLy8gQ2hlY2sgaWYgYW55IHN0ZXBzIGFyZSBkZWZpbmVkXG4gICAgY29uc3QgaGFzU3RlcHMgPSBbXG4gICAgICBwcm9wcy5wcmVQcm9jZXNzaW5nU3RlcCxcbiAgICAgIHByb3BzLm9yY2hlc3RyYXRpb25TdGVwLFxuICAgICAgcHJvcHMucG9zdFByb2Nlc3NpbmdTdGVwLFxuICAgICAgcHJvcHMucm91dGluZ0NsYXNzaWZpZXJTdGVwLFxuICAgICAgcHJvcHMubWVtb3J5U3VtbWFyaXphdGlvblN0ZXAsXG4gICAgICBwcm9wcy5rbm93bGVkZ2VCYXNlUmVzcG9uc2VHZW5lcmF0aW9uU3RlcCxcbiAgICBdLnNvbWUoc3RlcCA9PiBzdGVwICE9PSB1bmRlZmluZWQpO1xuXG4gICAgaWYgKCFoYXNTdGVwcykge1xuICAgICAgZXJyb3JzLnB1c2goJ1N0ZXBzIGFycmF5IGNhbm5vdCBiZSBlbXB0eScpO1xuICAgIH1cblxuICAgIC8vIEhlbHBlciBmdW5jdGlvbiB0byB2YWxpZGF0ZSBhIHN0ZXAncyBpbmZlcmVuY2UgY29uZmlnXG4gICAgY29uc3QgdmFsaWRhdGVTdGVwID0gKHN0ZXA6IFByb21wdFN0ZXBDb25maWdCYXNlIHwgdW5kZWZpbmVkLCBzdGVwTmFtZTogc3RyaW5nKSA9PiB7XG4gICAgICBpZiAoc3RlcCkge1xuICAgICAgICAvLyBDaGVjayBmb3IgZm91bmRhdGlvbiBtb2RlbCBpbiBub24tUk9VVElOR19DTEFTU0lGSUVSIHN0ZXBzXG4gICAgICAgIGlmICgnZm91bmRhdGlvbk1vZGVsJyBpbiBzdGVwICYmIHN0ZXAuc3RlcFR5cGUgIT09IEFnZW50U3RlcFR5cGUuUk9VVElOR19DTEFTU0lGSUVSKSB7XG4gICAgICAgICAgZXJyb3JzLnB1c2goJ0ZvdW5kYXRpb24gbW9kZWwgY2FuIG9ubHkgYmUgc3BlY2lmaWVkIGZvciBST1VUSU5HX0NMQVNTSUZJRVIgc3RlcCB0eXBlJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBpbmZlcmVuY2VFcnJvcnMgPSB0aGlzLnZhbGlkYXRlSW5mZXJlbmNlQ29uZmlnKHN0ZXAuaW5mZXJlbmNlQ29uZmlnKTtcbiAgICAgICAgaWYgKGluZmVyZW5jZUVycm9ycy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgZXJyb3JzLnB1c2goYCR7c3RlcE5hbWV9IHN0ZXA6ICR7aW5mZXJlbmNlRXJyb3JzLmpvaW4oJywgJyl9YCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gVmFsaWRhdGUgZWFjaCBzdGVwJ3MgaW5mZXJlbmNlIGNvbmZpZ1xuICAgIHZhbGlkYXRlU3RlcChwcm9wcy5wcmVQcm9jZXNzaW5nU3RlcCwgJ1ByZS1wcm9jZXNzaW5nJyk7XG4gICAgdmFsaWRhdGVTdGVwKHByb3BzLm9yY2hlc3RyYXRpb25TdGVwLCAnT3JjaGVzdHJhdGlvbicpO1xuICAgIHZhbGlkYXRlU3RlcChwcm9wcy5wb3N0UHJvY2Vzc2luZ1N0ZXAsICdQb3N0LXByb2Nlc3NpbmcnKTtcbiAgICB2YWxpZGF0ZVN0ZXAocHJvcHMucm91dGluZ0NsYXNzaWZpZXJTdGVwLCAnUm91dGluZyBjbGFzc2lmaWVyJyk7XG4gICAgdmFsaWRhdGVTdGVwKHByb3BzLm1lbW9yeVN1bW1hcml6YXRpb25TdGVwLCAnTWVtb3J5IHN1bW1hcml6YXRpb24nKTtcbiAgICB2YWxpZGF0ZVN0ZXAocHJvcHMua25vd2xlZGdlQmFzZVJlc3BvbnNlR2VuZXJhdGlvblN0ZXAsICdLbm93bGVkZ2UgYmFzZSByZXNwb25zZSBnZW5lcmF0aW9uJyk7XG5cbiAgICAvLyBWYWxpZGF0ZSByb3V0aW5nIGNsYXNzaWZpZXIncyBmb3VuZGF0aW9uIG1vZGVsIGlmIHByb3ZpZGVkXG4gICAgaWYgKHByb3BzLnJvdXRpbmdDbGFzc2lmaWVyU3RlcD8uZm91bmRhdGlvbk1vZGVsKSB7XG4gICAgICBpZiAoIXByb3BzLnJvdXRpbmdDbGFzc2lmaWVyU3RlcC5mb3VuZGF0aW9uTW9kZWwuaW52b2thYmxlQXJuKSB7XG4gICAgICAgIGVycm9ycy5wdXNoKCdGb3VuZGF0aW9uIG1vZGVsIG11c3QgYmUgYSB2YWxpZCBJQmVkcm9ja0ludm9rYWJsZSB3aXRoIGFuIGludm9rYWJsZUFybicpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBlcnJvcnM7XG4gIH07XG5cbiAgcHJpdmF0ZSB2YWxpZGF0ZUN1c3RvbVBhcnNlciA9IChwcm9wczogQ3VzdG9tUGFyc2VyUHJvcHMpOiBzdHJpbmdbXSA9PiB7XG4gICAgY29uc3QgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgLy8gQ2hlY2sgaWYgYXQgbGVhc3Qgb25lIHN0ZXAgdXNlcyBjdXN0b20gcGFyc2VyXG4gICAgY29uc3QgaGFzQ3VzdG9tUGFyc2VyID0gW1xuICAgICAgcHJvcHMucHJlUHJvY2Vzc2luZ1N0ZXA/LnVzZUN1c3RvbVBhcnNlcixcbiAgICAgIHByb3BzLm9yY2hlc3RyYXRpb25TdGVwPy51c2VDdXN0b21QYXJzZXIsXG4gICAgICBwcm9wcy5wb3N0UHJvY2Vzc2luZ1N0ZXA/LnVzZUN1c3RvbVBhcnNlcixcbiAgICAgIHByb3BzLnJvdXRpbmdDbGFzc2lmaWVyU3RlcD8udXNlQ3VzdG9tUGFyc2VyLFxuICAgICAgcHJvcHMubWVtb3J5U3VtbWFyaXphdGlvblN0ZXA/LnVzZUN1c3RvbVBhcnNlcixcbiAgICAgIHByb3BzLmtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25TdGVwPy51c2VDdXN0b21QYXJzZXIsXG4gICAgXS5zb21lKHVzZUN1c3RvbVBhcnNlciA9PiB1c2VDdXN0b21QYXJzZXIgPT09IHRydWUpO1xuXG4gICAgaWYgKCFoYXNDdXN0b21QYXJzZXIpIHtcbiAgICAgIGVycm9ycy5wdXNoKCdBdCBsZWFzdCBvbmUgc3RlcCBtdXN0IHVzZSBjdXN0b20gcGFyc2VyJyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGVycm9ycztcbiAgfTtcbn1cbiJdfQ==