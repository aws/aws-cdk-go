"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActionGroupExecutor = exports.CustomControl = void 0;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const validation_helpers_1 = require("./validation-helpers");
/**
 * The type of custom control for the action group executor.
 */
var CustomControl;
(function (CustomControl) {
    /**
     * Returns the action group invocation results directly in the InvokeAgent response.
     */
    CustomControl["RETURN_CONTROL"] = "RETURN_CONTROL";
})(CustomControl || (exports.CustomControl = CustomControl = {}));
/******************************************************************************
 *                         Action Group Executor
 *****************************************************************************/
/**
 * Defines how fulfillment of the action group is handled after the necessary
 * information has been elicited from the user.
 * Valid executors are:
 * - Lambda function
 * - Return Control
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/action-handle.html
 */
class ActionGroupExecutor {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ActionGroupExecutor", version: "2.240.0-alpha.0" };
    /**
     * Returns the action group invocation results directly in the InvokeAgent response.
     * The information and parameters can be sent to your own systems to yield results.
     * @see https://docs.aws.amazon.com/bedrock/latest/userguide/agents-returncontrol.html
     */
    static RETURN_CONTROL = new ActionGroupExecutor(undefined, CustomControl.RETURN_CONTROL);
    /**
     * Defines an action group with a Lambda function containing the business logic.
     * @param lambdaFunction - Lambda function to be called by the action group.
     * @see https://docs.aws.amazon.com/bedrock/latest/userguide/agents-lambda.html
     */
    static fromLambda(lambdaFunction) {
        return new ActionGroupExecutor(lambdaFunction, undefined);
    }
    /**
     * The Lambda function that will be called by the action group.
     * Contains the business logic for handling the action group's invocation.
     */
    lambdaFunction;
    /**
     * The custom control type for the action group executor.
     * Currently only supports 'RETURN_CONTROL' which returns results directly in the InvokeAgent response.
     */
    customControl;
    constructor(lambdaFunction, customControl) {
        if (lambdaFunction && customControl) {
            throw new validation_helpers_1.ValidationError('ActionGroupExecutor cannot have both lambdaFunction and customControl defined - they are mutually exclusive.');
        }
        this.lambdaFunction = lambdaFunction;
        this.customControl = customControl;
    }
    /**
     * Format as CFN properties
     *
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            customControl: this.customControl,
            lambda: this.lambdaFunction?.functionArn,
        };
    }
}
exports.ActionGroupExecutor = ActionGroupExecutor;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLWV4ZWN1dG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYXBpLWV4ZWN1dG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFFQSw2REFBdUQ7QUFFdkQ7O0dBRUc7QUFDSCxJQUFZLGFBS1g7QUFMRCxXQUFZLGFBQWE7SUFDdkI7O09BRUc7SUFDSCxrREFBaUMsQ0FBQTtBQUNuQyxDQUFDLEVBTFcsYUFBYSw2QkFBYixhQUFhLFFBS3hCO0FBRUQ7OytFQUUrRTtBQUMvRTs7Ozs7OztHQU9HO0FBQ0gsTUFBYSxtQkFBbUI7O0lBQzlCOzs7O09BSUc7SUFDSSxNQUFNLENBQVUsY0FBYyxHQUFHLElBQUksbUJBQW1CLENBQUMsU0FBUyxFQUFFLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUV6Rzs7OztPQUlHO0lBQ0ksTUFBTSxDQUFDLFVBQVUsQ0FBQyxjQUF5QjtRQUNoRCxPQUFPLElBQUksbUJBQW1CLENBQUMsY0FBYyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0tBQzNEO0lBRUQ7OztPQUdHO0lBQ2EsY0FBYyxDQUFhO0lBRTNDOzs7T0FHRztJQUNhLGFBQWEsQ0FBaUI7SUFFOUMsWUFBb0IsY0FBMEIsRUFBRSxhQUE2QjtRQUMzRSxJQUFJLGNBQWMsSUFBSSxhQUFhLEVBQUUsQ0FBQztZQUNwQyxNQUFNLElBQUksb0NBQWUsQ0FBQyw4R0FBOEcsQ0FBQyxDQUFDO1FBQzVJLENBQUM7UUFDRCxJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQztRQUNyQyxJQUFJLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQztLQUNwQztJQUVEOzs7O09BSUc7SUFDSSxPQUFPO1FBQ1osT0FBTztZQUNMLGFBQWEsRUFBRSxJQUFJLENBQUMsYUFBYTtZQUNqQyxNQUFNLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBRSxXQUFXO1NBQ3pDLENBQUM7S0FDSDs7QUEvQ0gsa0RBZ0RDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgKiBhcyBiZWRyb2NrIGZyb20gJ2F3cy1jZGstbGliL2F3cy1iZWRyb2NrJztcbmltcG9ydCB0eXBlIHsgSUZ1bmN0aW9uIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWxhbWJkYSc7XG5pbXBvcnQgeyBWYWxpZGF0aW9uRXJyb3IgfSBmcm9tICcuL3ZhbGlkYXRpb24taGVscGVycyc7XG5cbi8qKlxuICogVGhlIHR5cGUgb2YgY3VzdG9tIGNvbnRyb2wgZm9yIHRoZSBhY3Rpb24gZ3JvdXAgZXhlY3V0b3IuXG4gKi9cbmV4cG9ydCBlbnVtIEN1c3RvbUNvbnRyb2wge1xuICAvKipcbiAgICogUmV0dXJucyB0aGUgYWN0aW9uIGdyb3VwIGludm9jYXRpb24gcmVzdWx0cyBkaXJlY3RseSBpbiB0aGUgSW52b2tlQWdlbnQgcmVzcG9uc2UuXG4gICAqL1xuICBSRVRVUk5fQ09OVFJPTCA9ICdSRVRVUk5fQ09OVFJPTCcsXG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgIEFjdGlvbiBHcm91cCBFeGVjdXRvclxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBEZWZpbmVzIGhvdyBmdWxmaWxsbWVudCBvZiB0aGUgYWN0aW9uIGdyb3VwIGlzIGhhbmRsZWQgYWZ0ZXIgdGhlIG5lY2Vzc2FyeVxuICogaW5mb3JtYXRpb24gaGFzIGJlZW4gZWxpY2l0ZWQgZnJvbSB0aGUgdXNlci5cbiAqIFZhbGlkIGV4ZWN1dG9ycyBhcmU6XG4gKiAtIExhbWJkYSBmdW5jdGlvblxuICogLSBSZXR1cm4gQ29udHJvbFxuICogQHNlZSBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vYmVkcm9jay9sYXRlc3QvdXNlcmd1aWRlL2FjdGlvbi1oYW5kbGUuaHRtbFxuICovXG5leHBvcnQgY2xhc3MgQWN0aW9uR3JvdXBFeGVjdXRvciB7XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBhY3Rpb24gZ3JvdXAgaW52b2NhdGlvbiByZXN1bHRzIGRpcmVjdGx5IGluIHRoZSBJbnZva2VBZ2VudCByZXNwb25zZS5cbiAgICogVGhlIGluZm9ybWF0aW9uIGFuZCBwYXJhbWV0ZXJzIGNhbiBiZSBzZW50IHRvIHlvdXIgb3duIHN5c3RlbXMgdG8geWllbGQgcmVzdWx0cy5cbiAgICogQHNlZSBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vYmVkcm9jay9sYXRlc3QvdXNlcmd1aWRlL2FnZW50cy1yZXR1cm5jb250cm9sLmh0bWxcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgUkVUVVJOX0NPTlRST0wgPSBuZXcgQWN0aW9uR3JvdXBFeGVjdXRvcih1bmRlZmluZWQsIEN1c3RvbUNvbnRyb2wuUkVUVVJOX0NPTlRST0wpO1xuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGFuIGFjdGlvbiBncm91cCB3aXRoIGEgTGFtYmRhIGZ1bmN0aW9uIGNvbnRhaW5pbmcgdGhlIGJ1c2luZXNzIGxvZ2ljLlxuICAgKiBAcGFyYW0gbGFtYmRhRnVuY3Rpb24gLSBMYW1iZGEgZnVuY3Rpb24gdG8gYmUgY2FsbGVkIGJ5IHRoZSBhY3Rpb24gZ3JvdXAuXG4gICAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9hZ2VudHMtbGFtYmRhLmh0bWxcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUxhbWJkYShsYW1iZGFGdW5jdGlvbjogSUZ1bmN0aW9uKTogQWN0aW9uR3JvdXBFeGVjdXRvciB7XG4gICAgcmV0dXJuIG5ldyBBY3Rpb25Hcm91cEV4ZWN1dG9yKGxhbWJkYUZ1bmN0aW9uLCB1bmRlZmluZWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBMYW1iZGEgZnVuY3Rpb24gdGhhdCB3aWxsIGJlIGNhbGxlZCBieSB0aGUgYWN0aW9uIGdyb3VwLlxuICAgKiBDb250YWlucyB0aGUgYnVzaW5lc3MgbG9naWMgZm9yIGhhbmRsaW5nIHRoZSBhY3Rpb24gZ3JvdXAncyBpbnZvY2F0aW9uLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGxhbWJkYUZ1bmN0aW9uPzogSUZ1bmN0aW9uO1xuXG4gIC8qKlxuICAgKiBUaGUgY3VzdG9tIGNvbnRyb2wgdHlwZSBmb3IgdGhlIGFjdGlvbiBncm91cCBleGVjdXRvci5cbiAgICogQ3VycmVudGx5IG9ubHkgc3VwcG9ydHMgJ1JFVFVSTl9DT05UUk9MJyB3aGljaCByZXR1cm5zIHJlc3VsdHMgZGlyZWN0bHkgaW4gdGhlIEludm9rZUFnZW50IHJlc3BvbnNlLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGN1c3RvbUNvbnRyb2w/OiBDdXN0b21Db250cm9sO1xuXG4gIHByaXZhdGUgY29uc3RydWN0b3IobGFtYmRhRnVuY3Rpb24/OiBJRnVuY3Rpb24sIGN1c3RvbUNvbnRyb2w/OiBDdXN0b21Db250cm9sKSB7XG4gICAgaWYgKGxhbWJkYUZ1bmN0aW9uICYmIGN1c3RvbUNvbnRyb2wpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ0FjdGlvbkdyb3VwRXhlY3V0b3IgY2Fubm90IGhhdmUgYm90aCBsYW1iZGFGdW5jdGlvbiBhbmQgY3VzdG9tQ29udHJvbCBkZWZpbmVkIC0gdGhleSBhcmUgbXV0dWFsbHkgZXhjbHVzaXZlLicpO1xuICAgIH1cbiAgICB0aGlzLmxhbWJkYUZ1bmN0aW9uID0gbGFtYmRhRnVuY3Rpb247XG4gICAgdGhpcy5jdXN0b21Db250cm9sID0gY3VzdG9tQ29udHJvbDtcbiAgfVxuXG4gIC8qKlxuICAgKiBGb3JtYXQgYXMgQ0ZOIHByb3BlcnRpZXNcbiAgICpcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBiZWRyb2NrLkNmbkFnZW50LkFjdGlvbkdyb3VwRXhlY3V0b3JQcm9wZXJ0eSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGN1c3RvbUNvbnRyb2w6IHRoaXMuY3VzdG9tQ29udHJvbCxcbiAgICAgIGxhbWJkYTogdGhpcy5sYW1iZGFGdW5jdGlvbj8uZnVuY3Rpb25Bcm4sXG4gICAgfTtcbiAgfVxufVxuIl19