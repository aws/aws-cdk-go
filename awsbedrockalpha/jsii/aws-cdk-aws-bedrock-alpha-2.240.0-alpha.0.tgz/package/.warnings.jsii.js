function _aws_cdk_aws_bedrock_alpha_ParentActionGroupSignature(p) {
}
function _aws_cdk_aws_bedrock_alpha_AgentActionGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.apiSchema))
            _aws_cdk_aws_bedrock_alpha_ApiSchema(p.apiSchema);
        if (!visitedObjects.has(p.executor))
            _aws_cdk_aws_bedrock_alpha_ActionGroupExecutor(p.executor);
        if (!visitedObjects.has(p.functionSchema))
            _aws_cdk_aws_bedrock_alpha_FunctionSchema(p.functionSchema);
        if (!visitedObjects.has(p.parentActionGroupSignature))
            _aws_cdk_aws_bedrock_alpha_ParentActionGroupSignature(p.parentActionGroupSignature);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_AgentActionGroup(p) {
}
function _aws_cdk_aws_bedrock_alpha_IAgent(p) {
}
function _aws_cdk_aws_bedrock_alpha_AgentBase(p) {
}
function _aws_cdk_aws_bedrock_alpha_AgentProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.foundationModel))
            _aws_cdk_aws_bedrock_alpha_IBedrockInvokable(p.foundationModel);
        if (p.actionGroups != null)
            for (const o of p.actionGroups)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_AgentActionGroup(o);
        if (!visitedObjects.has(p.agentCollaboration))
            _aws_cdk_aws_bedrock_alpha_AgentCollaboration(p.agentCollaboration);
        if (!visitedObjects.has(p.customOrchestrationExecutor))
            _aws_cdk_aws_bedrock_alpha_CustomOrchestrationExecutor(p.customOrchestrationExecutor);
        if (!visitedObjects.has(p.guardrail))
            _aws_cdk_aws_bedrock_alpha_IGuardrail(p.guardrail);
        if (!visitedObjects.has(p.memory))
            _aws_cdk_aws_bedrock_alpha_Memory(p.memory);
        if (!visitedObjects.has(p.promptOverrideConfiguration))
            _aws_cdk_aws_bedrock_alpha_PromptOverrideConfiguration(p.promptOverrideConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_AgentAttributes(p) {
}
function _aws_cdk_aws_bedrock_alpha_Agent(p) {
}
function _aws_cdk_aws_bedrock_alpha_IAgentAlias(p) {
}
function _aws_cdk_aws_bedrock_alpha_AgentAliasBase(p) {
}
function _aws_cdk_aws_bedrock_alpha_AgentAliasProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.agent))
            _aws_cdk_aws_bedrock_alpha_IAgent(p.agent);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_AgentAliasAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.agent))
            _aws_cdk_aws_bedrock_alpha_IAgent(p.agent);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_AgentAlias(p) {
}
function _aws_cdk_aws_bedrock_alpha_CustomControl(p) {
}
function _aws_cdk_aws_bedrock_alpha_ActionGroupExecutor(p) {
}
function _aws_cdk_aws_bedrock_alpha_ApiSchema(p) {
}
function _aws_cdk_aws_bedrock_alpha_AssetApiSchema(p) {
}
function _aws_cdk_aws_bedrock_alpha_InlineApiSchema(p) {
}
function _aws_cdk_aws_bedrock_alpha_S3ApiSchema(p) {
}
function _aws_cdk_aws_bedrock_alpha_AgentStepType(p) {
}
function _aws_cdk_aws_bedrock_alpha_InferenceConfiguration(p) {
}
function _aws_cdk_aws_bedrock_alpha_PromptStepConfigBase(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.stepType))
            _aws_cdk_aws_bedrock_alpha_AgentStepType(p.stepType);
        if (!visitedObjects.has(p.inferenceConfig))
            _aws_cdk_aws_bedrock_alpha_InferenceConfiguration(p.inferenceConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_PromptPreProcessingConfigCustomParser(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.stepType))
            _aws_cdk_aws_bedrock_alpha_AgentStepType(p.stepType);
        if (!visitedObjects.has(p.inferenceConfig))
            _aws_cdk_aws_bedrock_alpha_InferenceConfiguration(p.inferenceConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_PromptOrchestrationConfigCustomParser(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.stepType))
            _aws_cdk_aws_bedrock_alpha_AgentStepType(p.stepType);
        if (!visitedObjects.has(p.inferenceConfig))
            _aws_cdk_aws_bedrock_alpha_InferenceConfiguration(p.inferenceConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_PromptPostProcessingConfigCustomParser(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.stepType))
            _aws_cdk_aws_bedrock_alpha_AgentStepType(p.stepType);
        if (!visitedObjects.has(p.inferenceConfig))
            _aws_cdk_aws_bedrock_alpha_InferenceConfiguration(p.inferenceConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_PromptRoutingClassifierConfigCustomParser(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.foundationModel))
            _aws_cdk_aws_bedrock_alpha_IBedrockInvokable(p.foundationModel);
        if (!visitedObjects.has(p.stepType))
            _aws_cdk_aws_bedrock_alpha_AgentStepType(p.stepType);
        if (!visitedObjects.has(p.inferenceConfig))
            _aws_cdk_aws_bedrock_alpha_InferenceConfiguration(p.inferenceConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_PromptMemorySummarizationConfigCustomParser(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.stepType))
            _aws_cdk_aws_bedrock_alpha_AgentStepType(p.stepType);
        if (!visitedObjects.has(p.inferenceConfig))
            _aws_cdk_aws_bedrock_alpha_InferenceConfiguration(p.inferenceConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_PromptKnowledgeBaseResponseGenerationConfigCustomParser(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.stepType))
            _aws_cdk_aws_bedrock_alpha_AgentStepType(p.stepType);
        if (!visitedObjects.has(p.inferenceConfig))
            _aws_cdk_aws_bedrock_alpha_InferenceConfiguration(p.inferenceConfig);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_CustomParserProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.knowledgeBaseResponseGenerationStep))
            _aws_cdk_aws_bedrock_alpha_PromptKnowledgeBaseResponseGenerationConfigCustomParser(p.knowledgeBaseResponseGenerationStep);
        if (!visitedObjects.has(p.memorySummarizationStep))
            _aws_cdk_aws_bedrock_alpha_PromptMemorySummarizationConfigCustomParser(p.memorySummarizationStep);
        if (!visitedObjects.has(p.orchestrationStep))
            _aws_cdk_aws_bedrock_alpha_PromptOrchestrationConfigCustomParser(p.orchestrationStep);
        if (!visitedObjects.has(p.postProcessingStep))
            _aws_cdk_aws_bedrock_alpha_PromptPostProcessingConfigCustomParser(p.postProcessingStep);
        if (!visitedObjects.has(p.preProcessingStep))
            _aws_cdk_aws_bedrock_alpha_PromptPreProcessingConfigCustomParser(p.preProcessingStep);
        if (!visitedObjects.has(p.routingClassifierStep))
            _aws_cdk_aws_bedrock_alpha_PromptRoutingClassifierConfigCustomParser(p.routingClassifierStep);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_PromptOverrideConfiguration(p) {
}
function _aws_cdk_aws_bedrock_alpha_SessionSummaryMemoryProps(p) {
}
function _aws_cdk_aws_bedrock_alpha_Memory(p) {
}
function _aws_cdk_aws_bedrock_alpha_AgentCollaboratorType(p) {
}
function _aws_cdk_aws_bedrock_alpha_AgentCollaboratorProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.agentAlias))
            _aws_cdk_aws_bedrock_alpha_IAgentAlias(p.agentAlias);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_AgentCollaborator(p) {
}
function _aws_cdk_aws_bedrock_alpha_AgentCollaborationConfig(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.collaborators != null)
            for (const o of p.collaborators)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_AgentCollaborator(o);
        if (!visitedObjects.has(p.type))
            _aws_cdk_aws_bedrock_alpha_AgentCollaboratorType(p.type);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_AgentCollaboration(p) {
}
function _aws_cdk_aws_bedrock_alpha_OrchestrationType(p) {
}
function _aws_cdk_aws_bedrock_alpha_CustomOrchestrationExecutor(p) {
}
function _aws_cdk_aws_bedrock_alpha_ParameterType(p) {
}
function _aws_cdk_aws_bedrock_alpha_RequireConfirmation(p) {
}
function _aws_cdk_aws_bedrock_alpha_FunctionParameterProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.type))
            _aws_cdk_aws_bedrock_alpha_ParameterType(p.type);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_FunctionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.parameters != null)
            for (const o of Object.values(p.parameters))
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_FunctionParameterProps(o);
        if (!visitedObjects.has(p.requireConfirmation))
            _aws_cdk_aws_bedrock_alpha_RequireConfirmation(p.requireConfirmation);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_FunctionSchemaProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.functions != null)
            for (const o of p.functions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_FunctionProps(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_FunctionParameter(p) {
}
function _aws_cdk_aws_bedrock_alpha_Function(p) {
}
function _aws_cdk_aws_bedrock_alpha_FunctionSchema(p) {
}
function _aws_cdk_aws_bedrock_alpha_GuardrailAction(p) {
}
function _aws_cdk_aws_bedrock_alpha_TierConfig(p) {
}
function _aws_cdk_aws_bedrock_alpha_ContentFilterStrength(p) {
}
function _aws_cdk_aws_bedrock_alpha_ModalityType(p) {
}
function _aws_cdk_aws_bedrock_alpha_ContentFilterType(p) {
}
function _aws_cdk_aws_bedrock_alpha_ContentFilter(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputStrength))
            _aws_cdk_aws_bedrock_alpha_ContentFilterStrength(p.inputStrength);
        if (!visitedObjects.has(p.outputStrength))
            _aws_cdk_aws_bedrock_alpha_ContentFilterStrength(p.outputStrength);
        if (!visitedObjects.has(p.type))
            _aws_cdk_aws_bedrock_alpha_ContentFilterType(p.type);
        if (!visitedObjects.has(p.inputAction))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.inputAction);
        if (p.inputModalities != null)
            for (const o of p.inputModalities)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_ModalityType(o);
        if (!visitedObjects.has(p.outputAction))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.outputAction);
        if (p.outputModalities != null)
            for (const o of p.outputModalities)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_ModalityType(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_CustomTopicProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputAction))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.inputAction);
        if (!visitedObjects.has(p.outputAction))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.outputAction);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_Topic(p) {
}
function _aws_cdk_aws_bedrock_alpha_WordFilter(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputAction))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.inputAction);
        if (!visitedObjects.has(p.outputAction))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.outputAction);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_ManagedWordFilterType(p) {
}
function _aws_cdk_aws_bedrock_alpha_ManagedWordFilter(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputAction))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.inputAction);
        if (!visitedObjects.has(p.outputAction))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.outputAction);
        if (!visitedObjects.has(p.type))
            _aws_cdk_aws_bedrock_alpha_ManagedWordFilterType(p.type);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_PIIType(p) {
}
function _aws_cdk_aws_bedrock_alpha_GeneralPIIType(p) {
}
function _aws_cdk_aws_bedrock_alpha_FinancePIIType(p) {
}
function _aws_cdk_aws_bedrock_alpha_InformationTechnologyPIIType(p) {
}
function _aws_cdk_aws_bedrock_alpha_USASpecificPIIType(p) {
}
function _aws_cdk_aws_bedrock_alpha_CanadaSpecificPIIType(p) {
}
function _aws_cdk_aws_bedrock_alpha_UKSpecificPIIType(p) {
}
function _aws_cdk_aws_bedrock_alpha_PIIFilter(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.action))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.action);
        if (!visitedObjects.has(p.type))
            _aws_cdk_aws_bedrock_alpha_PIIType(p.type);
        if (!visitedObjects.has(p.inputAction))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.inputAction);
        if (!visitedObjects.has(p.outputAction))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.outputAction);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_RegexFilter(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.action))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.action);
        if (!visitedObjects.has(p.inputAction))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.inputAction);
        if (!visitedObjects.has(p.outputAction))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.outputAction);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_ContextualGroundingFilterType(p) {
}
function _aws_cdk_aws_bedrock_alpha_ContextualGroundingFilter(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.type))
            _aws_cdk_aws_bedrock_alpha_ContextualGroundingFilterType(p.type);
        if (!visitedObjects.has(p.action))
            _aws_cdk_aws_bedrock_alpha_GuardrailAction(p.action);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_GuardrailCrossRegionConfigProperty(p) {
}
function _aws_cdk_aws_bedrock_alpha_IGuardrail(p) {
}
function _aws_cdk_aws_bedrock_alpha_GuardrailBase(p) {
}
function _aws_cdk_aws_bedrock_alpha_GuardrailProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.contentFilters != null)
            for (const o of p.contentFilters)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_ContentFilter(o);
        if (!visitedObjects.has(p.contentFiltersTierConfig))
            _aws_cdk_aws_bedrock_alpha_TierConfig(p.contentFiltersTierConfig);
        if (p.contextualGroundingFilters != null)
            for (const o of p.contextualGroundingFilters)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_ContextualGroundingFilter(o);
        if (!visitedObjects.has(p.crossRegionConfig))
            _aws_cdk_aws_bedrock_alpha_GuardrailCrossRegionConfigProperty(p.crossRegionConfig);
        if (p.deniedTopics != null)
            for (const o of p.deniedTopics)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_Topic(o);
        if (p.managedWordListFilters != null)
            for (const o of p.managedWordListFilters)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_ManagedWordFilter(o);
        if (p.piiFilters != null)
            for (const o of p.piiFilters)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_PIIFilter(o);
        if (p.regexFilters != null)
            for (const o of p.regexFilters)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_RegexFilter(o);
        if (!visitedObjects.has(p.topicsTierConfig))
            _aws_cdk_aws_bedrock_alpha_TierConfig(p.topicsTierConfig);
        if (p.wordFilters != null)
            for (const o of p.wordFilters)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_WordFilter(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_GuardrailAttributes(p) {
}
function _aws_cdk_aws_bedrock_alpha_Guardrail(p) {
}
function _aws_cdk_aws_bedrock_alpha_IPrompt(p) {
}
function _aws_cdk_aws_bedrock_alpha_PromptBase(p) {
}
function _aws_cdk_aws_bedrock_alpha_PromptProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.defaultVariant))
            _aws_cdk_aws_bedrock_alpha_IPromptVariant(p.defaultVariant);
        if (p.variants != null)
            for (const o of p.variants)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_IPromptVariant(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_PromptAttributes(p) {
}
function _aws_cdk_aws_bedrock_alpha_Prompt(p) {
}
function _aws_cdk_aws_bedrock_alpha_PromptTemplateType(p) {
}
function _aws_cdk_aws_bedrock_alpha_CommonPromptVariantProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.model))
            _aws_cdk_aws_bedrock_alpha_IBedrockInvokable(p.model);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_IPromptVariant(p) {
}
function _aws_cdk_aws_bedrock_alpha_PromptVariant(p) {
}
function _aws_cdk_aws_bedrock_alpha_PromptVersionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.prompt))
            _aws_cdk_aws_bedrock_alpha_IPrompt(p.prompt);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_PromptVersion(p) {
}
function _aws_cdk_aws_bedrock_alpha_ToolConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.toolChoice))
            _aws_cdk_aws_bedrock_alpha_ToolChoice(p.toolChoice);
        if (p.tools != null)
            for (const o of p.tools)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_Tool(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_FunctionToolProps(p) {
}
function _aws_cdk_aws_bedrock_alpha_Tool(p) {
}
function _aws_cdk_aws_bedrock_alpha_ToolChoice(p) {
}
function _aws_cdk_aws_bedrock_alpha_TextPromptVariantProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inferenceConfiguration))
            _aws_cdk_aws_bedrock_alpha_PromptInferenceConfiguration(p.inferenceConfiguration);
        if (!visitedObjects.has(p.model))
            _aws_cdk_aws_bedrock_alpha_IBedrockInvokable(p.model);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_ChatPromptVariantProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.messages != null)
            for (const o of p.messages)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_ChatMessage(o);
        if (!visitedObjects.has(p.inferenceConfiguration))
            _aws_cdk_aws_bedrock_alpha_PromptInferenceConfiguration(p.inferenceConfiguration);
        if (!visitedObjects.has(p.toolConfiguration))
            _aws_cdk_aws_bedrock_alpha_ToolConfiguration(p.toolConfiguration);
        if (!visitedObjects.has(p.model))
            _aws_cdk_aws_bedrock_alpha_IBedrockInvokable(p.model);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_ChatMessageRole(p) {
}
function _aws_cdk_aws_bedrock_alpha_ChatMessage(p) {
}
function _aws_cdk_aws_bedrock_alpha_AgentPromptVariantProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.agentAlias))
            _aws_cdk_aws_bedrock_alpha_IAgentAlias(p.agentAlias);
        if (!visitedObjects.has(p.model))
            _aws_cdk_aws_bedrock_alpha_IBedrockInvokable(p.model);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_PromptInferenceConfigurationProps(p) {
}
function _aws_cdk_aws_bedrock_alpha_PromptInferenceConfiguration(p) {
}
function _aws_cdk_aws_bedrock_alpha_TextTemplateConfigurationProps(p) {
}
function _aws_cdk_aws_bedrock_alpha_ChatTemplateConfigurationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.messages != null)
            for (const o of p.messages)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_ChatMessage(o);
        if (!visitedObjects.has(p.toolConfiguration))
            _aws_cdk_aws_bedrock_alpha_ToolConfiguration(p.toolConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_PromptTemplateConfiguration(p) {
}
function _aws_cdk_aws_bedrock_alpha_AgentGenAiResourceProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.agentAlias))
            _aws_cdk_aws_bedrock_alpha_IAgentAlias(p.agentAlias);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_PromptGenAiResource(p) {
}
function _aws_cdk_aws_bedrock_alpha_InferenceProfileType(p) {
}
function _aws_cdk_aws_bedrock_alpha_IInferenceProfile(p) {
}
function _aws_cdk_aws_bedrock_alpha_InferenceProfileBase(p) {
}
function _aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfileProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.modelSource))
            _aws_cdk_aws_bedrock_alpha_IBedrockInvokable(p.modelSource);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfileAttributes(p) {
}
function _aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfile(p) {
}
function _aws_cdk_aws_bedrock_alpha_CrossRegionInferenceProfileRegion(p) {
}
function _aws_cdk_aws_bedrock_alpha_CrossRegionInferenceProfileProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.geoRegion))
            _aws_cdk_aws_bedrock_alpha_CrossRegionInferenceProfileRegion(p.geoRegion);
        if (!visitedObjects.has(p.model))
            _aws_cdk_aws_bedrock_alpha_BedrockFoundationModel(p.model);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_CrossRegionInferenceProfile(p) {
}
function _aws_cdk_aws_bedrock_alpha_IPromptRouter(p) {
}
function _aws_cdk_aws_bedrock_alpha_PromptRouterProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.routingModels != null)
            for (const o of p.routingModels)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_BedrockFoundationModel(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_DefaultPromptRouterIdentifier(p) {
}
function _aws_cdk_aws_bedrock_alpha_PromptRouter(p) {
}
function _aws_cdk_aws_bedrock_alpha_VectorType(p) {
}
function _aws_cdk_aws_bedrock_alpha_IBedrockInvokable(p) {
}
function _aws_cdk_aws_bedrock_alpha_BedrockFoundationModelProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.supportedVectorType != null)
            for (const o of p.supportedVectorType)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_bedrock_alpha_VectorType(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_bedrock_alpha_BedrockFoundationModel(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_bedrock_alpha_ParentActionGroupSignature, _aws_cdk_aws_bedrock_alpha_AgentActionGroupProps, _aws_cdk_aws_bedrock_alpha_AgentActionGroup, _aws_cdk_aws_bedrock_alpha_IAgent, _aws_cdk_aws_bedrock_alpha_AgentBase, _aws_cdk_aws_bedrock_alpha_AgentProps, _aws_cdk_aws_bedrock_alpha_AgentAttributes, _aws_cdk_aws_bedrock_alpha_Agent, _aws_cdk_aws_bedrock_alpha_IAgentAlias, _aws_cdk_aws_bedrock_alpha_AgentAliasBase, _aws_cdk_aws_bedrock_alpha_AgentAliasProps, _aws_cdk_aws_bedrock_alpha_AgentAliasAttributes, _aws_cdk_aws_bedrock_alpha_AgentAlias, _aws_cdk_aws_bedrock_alpha_CustomControl, _aws_cdk_aws_bedrock_alpha_ActionGroupExecutor, _aws_cdk_aws_bedrock_alpha_ApiSchema, _aws_cdk_aws_bedrock_alpha_AssetApiSchema, _aws_cdk_aws_bedrock_alpha_InlineApiSchema, _aws_cdk_aws_bedrock_alpha_S3ApiSchema, _aws_cdk_aws_bedrock_alpha_AgentStepType, _aws_cdk_aws_bedrock_alpha_InferenceConfiguration, _aws_cdk_aws_bedrock_alpha_PromptStepConfigBase, _aws_cdk_aws_bedrock_alpha_PromptPreProcessingConfigCustomParser, _aws_cdk_aws_bedrock_alpha_PromptOrchestrationConfigCustomParser, _aws_cdk_aws_bedrock_alpha_PromptPostProcessingConfigCustomParser, _aws_cdk_aws_bedrock_alpha_PromptRoutingClassifierConfigCustomParser, _aws_cdk_aws_bedrock_alpha_PromptMemorySummarizationConfigCustomParser, _aws_cdk_aws_bedrock_alpha_PromptKnowledgeBaseResponseGenerationConfigCustomParser, _aws_cdk_aws_bedrock_alpha_CustomParserProps, _aws_cdk_aws_bedrock_alpha_PromptOverrideConfiguration, _aws_cdk_aws_bedrock_alpha_SessionSummaryMemoryProps, _aws_cdk_aws_bedrock_alpha_Memory, _aws_cdk_aws_bedrock_alpha_AgentCollaboratorType, _aws_cdk_aws_bedrock_alpha_AgentCollaboratorProps, _aws_cdk_aws_bedrock_alpha_AgentCollaborator, _aws_cdk_aws_bedrock_alpha_AgentCollaborationConfig, _aws_cdk_aws_bedrock_alpha_AgentCollaboration, _aws_cdk_aws_bedrock_alpha_OrchestrationType, _aws_cdk_aws_bedrock_alpha_CustomOrchestrationExecutor, _aws_cdk_aws_bedrock_alpha_ParameterType, _aws_cdk_aws_bedrock_alpha_RequireConfirmation, _aws_cdk_aws_bedrock_alpha_FunctionParameterProps, _aws_cdk_aws_bedrock_alpha_FunctionProps, _aws_cdk_aws_bedrock_alpha_FunctionSchemaProps, _aws_cdk_aws_bedrock_alpha_FunctionParameter, _aws_cdk_aws_bedrock_alpha_Function, _aws_cdk_aws_bedrock_alpha_FunctionSchema, _aws_cdk_aws_bedrock_alpha_GuardrailAction, _aws_cdk_aws_bedrock_alpha_TierConfig, _aws_cdk_aws_bedrock_alpha_ContentFilterStrength, _aws_cdk_aws_bedrock_alpha_ModalityType, _aws_cdk_aws_bedrock_alpha_ContentFilterType, _aws_cdk_aws_bedrock_alpha_ContentFilter, _aws_cdk_aws_bedrock_alpha_CustomTopicProps, _aws_cdk_aws_bedrock_alpha_Topic, _aws_cdk_aws_bedrock_alpha_WordFilter, _aws_cdk_aws_bedrock_alpha_ManagedWordFilterType, _aws_cdk_aws_bedrock_alpha_ManagedWordFilter, _aws_cdk_aws_bedrock_alpha_PIIType, _aws_cdk_aws_bedrock_alpha_GeneralPIIType, _aws_cdk_aws_bedrock_alpha_FinancePIIType, _aws_cdk_aws_bedrock_alpha_InformationTechnologyPIIType, _aws_cdk_aws_bedrock_alpha_USASpecificPIIType, _aws_cdk_aws_bedrock_alpha_CanadaSpecificPIIType, _aws_cdk_aws_bedrock_alpha_UKSpecificPIIType, _aws_cdk_aws_bedrock_alpha_PIIFilter, _aws_cdk_aws_bedrock_alpha_RegexFilter, _aws_cdk_aws_bedrock_alpha_ContextualGroundingFilterType, _aws_cdk_aws_bedrock_alpha_ContextualGroundingFilter, _aws_cdk_aws_bedrock_alpha_GuardrailCrossRegionConfigProperty, _aws_cdk_aws_bedrock_alpha_IGuardrail, _aws_cdk_aws_bedrock_alpha_GuardrailBase, _aws_cdk_aws_bedrock_alpha_GuardrailProps, _aws_cdk_aws_bedrock_alpha_GuardrailAttributes, _aws_cdk_aws_bedrock_alpha_Guardrail, _aws_cdk_aws_bedrock_alpha_IPrompt, _aws_cdk_aws_bedrock_alpha_PromptBase, _aws_cdk_aws_bedrock_alpha_PromptProps, _aws_cdk_aws_bedrock_alpha_PromptAttributes, _aws_cdk_aws_bedrock_alpha_Prompt, _aws_cdk_aws_bedrock_alpha_PromptTemplateType, _aws_cdk_aws_bedrock_alpha_CommonPromptVariantProps, _aws_cdk_aws_bedrock_alpha_IPromptVariant, _aws_cdk_aws_bedrock_alpha_PromptVariant, _aws_cdk_aws_bedrock_alpha_PromptVersionProps, _aws_cdk_aws_bedrock_alpha_PromptVersion, _aws_cdk_aws_bedrock_alpha_ToolConfiguration, _aws_cdk_aws_bedrock_alpha_FunctionToolProps, _aws_cdk_aws_bedrock_alpha_Tool, _aws_cdk_aws_bedrock_alpha_ToolChoice, _aws_cdk_aws_bedrock_alpha_TextPromptVariantProps, _aws_cdk_aws_bedrock_alpha_ChatPromptVariantProps, _aws_cdk_aws_bedrock_alpha_ChatMessageRole, _aws_cdk_aws_bedrock_alpha_ChatMessage, _aws_cdk_aws_bedrock_alpha_AgentPromptVariantProps, _aws_cdk_aws_bedrock_alpha_PromptInferenceConfigurationProps, _aws_cdk_aws_bedrock_alpha_PromptInferenceConfiguration, _aws_cdk_aws_bedrock_alpha_TextTemplateConfigurationProps, _aws_cdk_aws_bedrock_alpha_ChatTemplateConfigurationProps, _aws_cdk_aws_bedrock_alpha_PromptTemplateConfiguration, _aws_cdk_aws_bedrock_alpha_AgentGenAiResourceProps, _aws_cdk_aws_bedrock_alpha_PromptGenAiResource, _aws_cdk_aws_bedrock_alpha_InferenceProfileType, _aws_cdk_aws_bedrock_alpha_IInferenceProfile, _aws_cdk_aws_bedrock_alpha_InferenceProfileBase, _aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfileProps, _aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfileAttributes, _aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfile, _aws_cdk_aws_bedrock_alpha_CrossRegionInferenceProfileRegion, _aws_cdk_aws_bedrock_alpha_CrossRegionInferenceProfileProps, _aws_cdk_aws_bedrock_alpha_CrossRegionInferenceProfile, _aws_cdk_aws_bedrock_alpha_IPromptRouter, _aws_cdk_aws_bedrock_alpha_PromptRouterProps, _aws_cdk_aws_bedrock_alpha_DefaultPromptRouterIdentifier, _aws_cdk_aws_bedrock_alpha_PromptRouter, _aws_cdk_aws_bedrock_alpha_VectorType, _aws_cdk_aws_bedrock_alpha_IBedrockInvokable, _aws_cdk_aws_bedrock_alpha_BedrockFoundationModelProps, _aws_cdk_aws_bedrock_alpha_BedrockFoundationModel };
