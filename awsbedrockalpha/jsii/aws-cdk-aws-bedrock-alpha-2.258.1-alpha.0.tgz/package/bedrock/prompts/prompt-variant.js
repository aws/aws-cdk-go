"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptVariant = exports.PromptTemplateType = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const agent_prompt_variant_1 = require("./agent-prompt-variant");
const chat_prompt_variant_1 = require("./chat-prompt-variant");
const text_prompt_variant_1 = require("./text-prompt-variant");
/******************************************************************************
 *                              COMMON
 *****************************************************************************/
/**
 * The type of prompt template.
 */
var PromptTemplateType;
(function (PromptTemplateType) {
    /**
     * Text template for simple text-based prompts.
     */
    PromptTemplateType["TEXT"] = "TEXT";
    /**
     * Chat template for conversational prompts with message history.
     */
    PromptTemplateType["CHAT"] = "CHAT";
})(PromptTemplateType || (exports.PromptTemplateType = PromptTemplateType = {}));
/******************************************************************************
 *                              PROMPT VARIANT FACTORY
 *****************************************************************************/
/**
 * Factory class for creating prompt variants.
 * Provides static methods to create different types of prompt variants
 * with proper configuration and type safety.
 */
class PromptVariant {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.PromptVariant", version: "2.258.1-alpha.0" };
    /******************************************************************************
     *                            STATIC METHODS
     *****************************************************************************/
    /**
     * Creates a text template variant.
     *
     * @param props - Properties for the text prompt variant
     * @returns A PromptVariant configured for text processing
     */
    static text(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_TextPromptVariantProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.text);
            }
            throw error;
        }
        return (0, text_prompt_variant_1.createTextPromptVariant)(props);
    }
    /**
     * Creates a chat template variant. Use this template type when
     * the model supports the Converse API or the Anthropic Claude Messages API.
     * This allows you to include a System prompt and previous User messages
     * and Assistant messages for context.
     *
     * @param props - Properties for the chat prompt variant
     * @returns A PromptVariant configured for chat interactions
     */
    static chat(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ChatPromptVariantProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.chat);
            }
            throw error;
        }
        return (0, chat_prompt_variant_1.createChatPromptVariant)(props);
    }
    /**
     * Creates an agent prompt template variant.
     *
     * @param props - Properties for the agent prompt variant
     * @returns A PromptVariant configured for agent interactions
     */
    static agent(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentPromptVariantProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.agent);
            }
            throw error;
        }
        return (0, agent_prompt_variant_1.createAgentPromptVariant)(props);
    }
    /******************************************************************************
     *                            CONSTRUCTOR
     *****************************************************************************/
    constructor() {
    }
}
exports.PromptVariant = PromptVariant;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvbXB0LXZhcmlhbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJwcm9tcHQtdmFyaWFudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUdBLGlFQUFrRTtBQUVsRSwrREFBZ0U7QUFLaEUsK0RBQWdFO0FBRWhFOzsrRUFFK0U7QUFDL0U7O0dBRUc7QUFDSCxJQUFZLGtCQVNYO0FBVEQsV0FBWSxrQkFBa0I7SUFDNUI7O09BRUc7SUFDSCxtQ0FBYSxDQUFBO0lBQ2I7O09BRUc7SUFDSCxtQ0FBYSxDQUFBO0FBQ2YsQ0FBQyxFQVRXLGtCQUFrQixrQ0FBbEIsa0JBQWtCLFFBUzdCO0FBa0VEOzsrRUFFK0U7QUFDL0U7Ozs7R0FJRztBQUNILE1BQWEsYUFBYTs7SUFDeEI7O21GQUUrRTtJQUMvRTs7Ozs7T0FLRztJQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBNkI7Ozs7Ozs7Ozs7UUFDOUMsT0FBTyxJQUFBLDZDQUF1QixFQUFDLEtBQUssQ0FBQyxDQUFDO0tBQ3ZDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQTZCOzs7Ozs7Ozs7O1FBQzlDLE9BQU8sSUFBQSw2Q0FBdUIsRUFBQyxLQUFLLENBQUMsQ0FBQztLQUN2QztJQUVEOzs7OztPQUtHO0lBQ0ksTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUE4Qjs7Ozs7Ozs7OztRQUNoRCxPQUFPLElBQUEsK0NBQXdCLEVBQUMsS0FBSyxDQUFDLENBQUM7S0FDeEM7SUFFRDs7bUZBRStFO0lBQy9FO0tBR0M7O0FBM0NILHNDQTRDQyIsInNvdXJjZXNDb250ZW50IjpbIi8vIEludGVybmFsIExpYnNcbmltcG9ydCB0eXBlIHsgSUJlZHJvY2tJbnZva2FibGUgfSBmcm9tICcuLi9tb2RlbHMnO1xuaW1wb3J0IHR5cGUgeyBBZ2VudFByb21wdFZhcmlhbnRQcm9wcyB9IGZyb20gJy4vYWdlbnQtcHJvbXB0LXZhcmlhbnQnO1xuaW1wb3J0IHsgY3JlYXRlQWdlbnRQcm9tcHRWYXJpYW50IH0gZnJvbSAnLi9hZ2VudC1wcm9tcHQtdmFyaWFudCc7XG5pbXBvcnQgdHlwZSB7IENoYXRQcm9tcHRWYXJpYW50UHJvcHMgfSBmcm9tICcuL2NoYXQtcHJvbXB0LXZhcmlhbnQnO1xuaW1wb3J0IHsgY3JlYXRlQ2hhdFByb21wdFZhcmlhbnQgfSBmcm9tICcuL2NoYXQtcHJvbXB0LXZhcmlhbnQnO1xuaW1wb3J0IHR5cGUgeyBQcm9tcHRHZW5BaVJlc291cmNlIH0gZnJvbSAnLi9wcm9tcHQtZ2VuYWktcmVzb3VyY2UnO1xuaW1wb3J0IHR5cGUgeyBQcm9tcHRJbmZlcmVuY2VDb25maWd1cmF0aW9uIH0gZnJvbSAnLi9wcm9tcHQtaW5mZXJlbmNlLWNvbmZpZ3VyYXRpb24nO1xuaW1wb3J0IHR5cGUgeyBQcm9tcHRUZW1wbGF0ZUNvbmZpZ3VyYXRpb24gfSBmcm9tICcuL3Byb21wdC10ZW1wbGF0ZS1jb25maWd1cmF0aW9uJztcbmltcG9ydCB0eXBlIHsgVGV4dFByb21wdFZhcmlhbnRQcm9wcyB9IGZyb20gJy4vdGV4dC1wcm9tcHQtdmFyaWFudCc7XG5pbXBvcnQgeyBjcmVhdGVUZXh0UHJvbXB0VmFyaWFudCB9IGZyb20gJy4vdGV4dC1wcm9tcHQtdmFyaWFudCc7XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ09NTU9OXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIFRoZSB0eXBlIG9mIHByb21wdCB0ZW1wbGF0ZS5cbiAqL1xuZXhwb3J0IGVudW0gUHJvbXB0VGVtcGxhdGVUeXBlIHtcbiAgLyoqXG4gICAqIFRleHQgdGVtcGxhdGUgZm9yIHNpbXBsZSB0ZXh0LWJhc2VkIHByb21wdHMuXG4gICAqL1xuICBURVhUID0gJ1RFWFQnLFxuICAvKipcbiAgICogQ2hhdCB0ZW1wbGF0ZSBmb3IgY29udmVyc2F0aW9uYWwgcHJvbXB0cyB3aXRoIG1lc3NhZ2UgaGlzdG9yeS5cbiAgICovXG4gIENIQVQgPSAnQ0hBVCcsXG59XG5cbi8qKlxuICogQ29tbW9uIHByb3BlcnRpZXMgZm9yIGFsbCBwcm9tcHQgdmFyaWFudHMuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29tbW9uUHJvbXB0VmFyaWFudFByb3BzIHtcbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBwcm9tcHQgdmFyaWFudC5cbiAgICovXG4gIHJlYWRvbmx5IHZhcmlhbnROYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBtb2RlbCB3aGljaCBpcyB1c2VkIHRvIHJ1biB0aGUgcHJvbXB0LiBUaGUgbW9kZWwgY291bGQgYmUgYSBmb3VuZGF0aW9uXG4gICAqIG1vZGVsLCBhIGN1c3RvbSBtb2RlbCwgb3IgYSBwcm92aXNpb25lZCBtb2RlbC5cbiAgICovXG4gIHJlYWRvbmx5IG1vZGVsOiBJQmVkcm9ja0ludm9rYWJsZTtcblxuICAvKipcbiAgICogVGhlIHZhcmlhYmxlcyBpbiB0aGUgcHJvbXB0IHRlbXBsYXRlIHRoYXQgY2FuIGJlIGZpbGxlZCBpbiBhdCBydW50aW1lLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIE5vIHZhcmlhYmxlcyBkZWZpbmVkLlxuICAgKi9cbiAgcmVhZG9ubHkgcHJvbXB0VmFyaWFibGVzPzogc3RyaW5nW107XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUFJPTVBUIFZBUklBTlQgSU5URVJGQUNFXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIEludGVyZmFjZSByZXByZXNlbnRpbmcgYSBwcm9tcHQgdmFyaWFudCBjb25maWd1cmF0aW9uLlxuICogVmFyaWFudHMgYXJlIHNwZWNpZmljIHNldHMgb2YgaW5wdXRzIHRoYXQgZ3VpZGUgRk1zIG9uIEFtYXpvbiBCZWRyb2NrIHRvXG4gKiBnZW5lcmF0ZSBhbiBhcHByb3ByaWF0ZSByZXNwb25zZSBvciBvdXRwdXQgZm9yIGEgZ2l2ZW4gdGFzayBvciBpbnN0cnVjdGlvbi5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBJUHJvbXB0VmFyaWFudCB7XG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgcHJvbXB0IHZhcmlhbnQuXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSB0eXBlIG9mIHByb21wdCB0ZW1wbGF0ZS5cbiAgICogQGRlZmF1bHQgLSBUZXh0XG4gICAqL1xuICByZWFkb25seSB0ZW1wbGF0ZVR5cGU6IFByb21wdFRlbXBsYXRlVHlwZTtcblxuICAvKipcbiAgICogVGhlIGluZmVyZW5jZSBjb25maWd1cmF0aW9uLlxuICAgKi9cbiAgcmVhZG9ubHkgaW5mZXJlbmNlQ29uZmlndXJhdGlvbj86IFByb21wdEluZmVyZW5jZUNvbmZpZ3VyYXRpb247XG5cbiAgLyoqXG4gICAqIFRoZSB1bmlxdWUgaWRlbnRpZmllciBvZiB0aGUgbW9kZWwgd2l0aCB3aGljaCB0byBydW4gaW5mZXJlbmNlIG9uIHRoZSBwcm9tcHQuXG4gICAqL1xuICByZWFkb25seSBtb2RlbElkPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgdGVtcGxhdGUgY29uZmlndXJhdGlvbi5cbiAgICovXG4gIHJlYWRvbmx5IHRlbXBsYXRlQ29uZmlndXJhdGlvbjogUHJvbXB0VGVtcGxhdGVDb25maWd1cmF0aW9uO1xuXG4gIC8qKlxuICAgKiBUaGUgZ2VuZXJhdGl2ZSBBSSByZXNvdXJjZSBjb25maWd1cmF0aW9uLlxuICAgKi9cbiAgcmVhZG9ubHkgZ2VuQWlSZXNvdXJjZT86IFByb21wdEdlbkFpUmVzb3VyY2U7XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUFJPTVBUIFZBUklBTlQgRkFDVE9SWVxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBGYWN0b3J5IGNsYXNzIGZvciBjcmVhdGluZyBwcm9tcHQgdmFyaWFudHMuXG4gKiBQcm92aWRlcyBzdGF0aWMgbWV0aG9kcyB0byBjcmVhdGUgZGlmZmVyZW50IHR5cGVzIG9mIHByb21wdCB2YXJpYW50c1xuICogd2l0aCBwcm9wZXIgY29uZmlndXJhdGlvbiBhbmQgdHlwZSBzYWZldHkuXG4gKi9cbmV4cG9ydCBjbGFzcyBQcm9tcHRWYXJpYW50IHtcbiAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBTVEFUSUMgTUVUSE9EU1xuICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgdGV4dCB0ZW1wbGF0ZSB2YXJpYW50LlxuICAgKlxuICAgKiBAcGFyYW0gcHJvcHMgLSBQcm9wZXJ0aWVzIGZvciB0aGUgdGV4dCBwcm9tcHQgdmFyaWFudFxuICAgKiBAcmV0dXJucyBBIFByb21wdFZhcmlhbnQgY29uZmlndXJlZCBmb3IgdGV4dCBwcm9jZXNzaW5nXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHRleHQocHJvcHM6IFRleHRQcm9tcHRWYXJpYW50UHJvcHMpOiBJUHJvbXB0VmFyaWFudCB7XG4gICAgcmV0dXJuIGNyZWF0ZVRleHRQcm9tcHRWYXJpYW50KHByb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgY2hhdCB0ZW1wbGF0ZSB2YXJpYW50LiBVc2UgdGhpcyB0ZW1wbGF0ZSB0eXBlIHdoZW5cbiAgICogdGhlIG1vZGVsIHN1cHBvcnRzIHRoZSBDb252ZXJzZSBBUEkgb3IgdGhlIEFudGhyb3BpYyBDbGF1ZGUgTWVzc2FnZXMgQVBJLlxuICAgKiBUaGlzIGFsbG93cyB5b3UgdG8gaW5jbHVkZSBhIFN5c3RlbSBwcm9tcHQgYW5kIHByZXZpb3VzIFVzZXIgbWVzc2FnZXNcbiAgICogYW5kIEFzc2lzdGFudCBtZXNzYWdlcyBmb3IgY29udGV4dC5cbiAgICpcbiAgICogQHBhcmFtIHByb3BzIC0gUHJvcGVydGllcyBmb3IgdGhlIGNoYXQgcHJvbXB0IHZhcmlhbnRcbiAgICogQHJldHVybnMgQSBQcm9tcHRWYXJpYW50IGNvbmZpZ3VyZWQgZm9yIGNoYXQgaW50ZXJhY3Rpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGNoYXQocHJvcHM6IENoYXRQcm9tcHRWYXJpYW50UHJvcHMpOiBJUHJvbXB0VmFyaWFudCB7XG4gICAgcmV0dXJuIGNyZWF0ZUNoYXRQcm9tcHRWYXJpYW50KHByb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGFuIGFnZW50IHByb21wdCB0ZW1wbGF0ZSB2YXJpYW50LlxuICAgKlxuICAgKiBAcGFyYW0gcHJvcHMgLSBQcm9wZXJ0aWVzIGZvciB0aGUgYWdlbnQgcHJvbXB0IHZhcmlhbnRcbiAgICogQHJldHVybnMgQSBQcm9tcHRWYXJpYW50IGNvbmZpZ3VyZWQgZm9yIGFnZW50IGludGVyYWN0aW9uc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyBhZ2VudChwcm9wczogQWdlbnRQcm9tcHRWYXJpYW50UHJvcHMpOiBJUHJvbXB0VmFyaWFudCB7XG4gICAgcmV0dXJuIGNyZWF0ZUFnZW50UHJvbXB0VmFyaWFudChwcm9wcyk7XG4gIH1cblxuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgIENPTlNUUlVDVE9SXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbiAgcHJpdmF0ZSBjb25zdHJ1Y3RvcigpIHtcbiAgICAvLyBQcml2YXRlIGNvbnN0cnVjdG9yIHRvIHByZXZlbnQgaW5zdGFudGlhdGlvblxuICAgIC8vIFRoaXMgY2xhc3Mgc2hvdWxkIG9ubHkgYmUgdXNlZCBmb3IgaXRzIHN0YXRpYyBmYWN0b3J5IG1ldGhvZHNcbiAgfVxufVxuIl19