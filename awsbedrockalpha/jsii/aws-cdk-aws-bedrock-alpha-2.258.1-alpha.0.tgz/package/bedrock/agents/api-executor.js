"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActionGroupExecutor = exports.CustomControl = void 0;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
/**
 * The type of custom control for the action group executor.
 */
var CustomControl;
(function (CustomControl) {
    /**
     * Returns the action group invocation results directly in the InvokeAgent response.
     */
    CustomControl["RETURN_CONTROL"] = "RETURN_CONTROL";
})(CustomControl || (exports.CustomControl = CustomControl = {}));
/******************************************************************************
 *                         Action Group Executor
 *****************************************************************************/
/**
 * Defines how fulfillment of the action group is handled after the necessary
 * information has been elicited from the user.
 * Valid executors are:
 * - Lambda function
 * - Return Control
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/action-handle.html
 */
class ActionGroupExecutor {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ActionGroupExecutor", version: "2.258.1-alpha.0" };
    /**
     * Returns the action group invocation results directly in the InvokeAgent response.
     * The information and parameters can be sent to your own systems to yield results.
     * @see https://docs.aws.amazon.com/bedrock/latest/userguide/agents-returncontrol.html
     */
    static RETURN_CONTROL = new ActionGroupExecutor(undefined, CustomControl.RETURN_CONTROL);
    /**
     * Defines an action group with a Lambda function containing the business logic.
     * @param lambdaFunction - Lambda function to be called by the action group.
     * @see https://docs.aws.amazon.com/bedrock/latest/userguide/agents-lambda.html
     */
    static fromLambda(lambdaFunction) {
        return new ActionGroupExecutor(lambdaFunction, undefined);
    }
    /**
     * The Lambda function that will be called by the action group.
     * Contains the business logic for handling the action group's invocation.
     */
    lambdaFunction;
    /**
     * The custom control type for the action group executor.
     * Currently only supports 'RETURN_CONTROL' which returns results directly in the InvokeAgent response.
     */
    customControl;
    constructor(lambdaFunction, customControl) {
        if (lambdaFunction && customControl) {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `MutuallyExclusiveExecutorTypes`, 'ActionGroupExecutor cannot have both lambdaFunction and customControl defined - they are mutually exclusive.');
        }
        this.lambdaFunction = lambdaFunction;
        this.customControl = customControl;
    }
    /**
     * Format as CFN properties
     *
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            customControl: this.customControl,
            lambda: this.lambdaFunction?.functionArn,
        };
    }
}
exports.ActionGroupExecutor = ActionGroupExecutor;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLWV4ZWN1dG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYXBpLWV4ZWN1dG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFFQSx3REFBc0U7QUFDdEUsNEVBQTREO0FBRTVEOztHQUVHO0FBQ0gsSUFBWSxhQUtYO0FBTEQsV0FBWSxhQUFhO0lBQ3ZCOztPQUVHO0lBQ0gsa0RBQWlDLENBQUE7QUFDbkMsQ0FBQyxFQUxXLGFBQWEsNkJBQWIsYUFBYSxRQUt4QjtBQUVEOzsrRUFFK0U7QUFDL0U7Ozs7Ozs7R0FPRztBQUNILE1BQWEsbUJBQW1COztJQUM5Qjs7OztPQUlHO0lBQ0ksTUFBTSxDQUFVLGNBQWMsR0FBRyxJQUFJLG1CQUFtQixDQUFDLFNBQVMsRUFBRSxhQUFhLENBQUMsY0FBYyxDQUFDLENBQUM7SUFFekc7Ozs7T0FJRztJQUNJLE1BQU0sQ0FBQyxVQUFVLENBQUMsY0FBeUI7UUFDaEQsT0FBTyxJQUFJLG1CQUFtQixDQUFDLGNBQWMsRUFBRSxTQUFTLENBQUMsQ0FBQztLQUMzRDtJQUVEOzs7T0FHRztJQUNhLGNBQWMsQ0FBYTtJQUUzQzs7O09BR0c7SUFDYSxhQUFhLENBQWlCO0lBRTlDLFlBQW9CLGNBQTBCLEVBQUUsYUFBNkI7UUFDM0UsSUFBSSxjQUFjLElBQUksYUFBYSxFQUFFLENBQUM7WUFDcEMsTUFBTSxJQUFJLGdDQUF1QixDQUFDLElBQUEsc0JBQUcsRUFBQSxnQ0FBZ0MsRUFBRSw4R0FBOEcsQ0FBQyxDQUFDO1FBQ3pMLENBQUM7UUFDRCxJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQztRQUNyQyxJQUFJLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQztLQUNwQztJQUVEOzs7O09BSUc7SUFDSSxPQUFPO1FBQ1osT0FBTztZQUNMLGFBQWEsRUFBRSxJQUFJLENBQUMsYUFBYTtZQUNqQyxNQUFNLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBRSxXQUFXO1NBQ3pDLENBQUM7S0FDSDs7QUEvQ0gsa0RBZ0RDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgKiBhcyBiZWRyb2NrIGZyb20gJ2F3cy1jZGstbGliL2F3cy1iZWRyb2NrJztcbmltcG9ydCB0eXBlIHsgSUZ1bmN0aW9uIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWxhbWJkYSc7XG5pbXBvcnQgeyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvciB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2Vycm9ycyc7XG5pbXBvcnQgeyBsaXQgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9oZWxwZXJzLWludGVybmFsJztcblxuLyoqXG4gKiBUaGUgdHlwZSBvZiBjdXN0b20gY29udHJvbCBmb3IgdGhlIGFjdGlvbiBncm91cCBleGVjdXRvci5cbiAqL1xuZXhwb3J0IGVudW0gQ3VzdG9tQ29udHJvbCB7XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBhY3Rpb24gZ3JvdXAgaW52b2NhdGlvbiByZXN1bHRzIGRpcmVjdGx5IGluIHRoZSBJbnZva2VBZ2VudCByZXNwb25zZS5cbiAgICovXG4gIFJFVFVSTl9DT05UUk9MID0gJ1JFVFVSTl9DT05UUk9MJyxcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgQWN0aW9uIEdyb3VwIEV4ZWN1dG9yXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIERlZmluZXMgaG93IGZ1bGZpbGxtZW50IG9mIHRoZSBhY3Rpb24gZ3JvdXAgaXMgaGFuZGxlZCBhZnRlciB0aGUgbmVjZXNzYXJ5XG4gKiBpbmZvcm1hdGlvbiBoYXMgYmVlbiBlbGljaXRlZCBmcm9tIHRoZSB1c2VyLlxuICogVmFsaWQgZXhlY3V0b3JzIGFyZTpcbiAqIC0gTGFtYmRhIGZ1bmN0aW9uXG4gKiAtIFJldHVybiBDb250cm9sXG4gKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9iZWRyb2NrL2xhdGVzdC91c2VyZ3VpZGUvYWN0aW9uLWhhbmRsZS5odG1sXG4gKi9cbmV4cG9ydCBjbGFzcyBBY3Rpb25Hcm91cEV4ZWN1dG9yIHtcbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGFjdGlvbiBncm91cCBpbnZvY2F0aW9uIHJlc3VsdHMgZGlyZWN0bHkgaW4gdGhlIEludm9rZUFnZW50IHJlc3BvbnNlLlxuICAgKiBUaGUgaW5mb3JtYXRpb24gYW5kIHBhcmFtZXRlcnMgY2FuIGJlIHNlbnQgdG8geW91ciBvd24gc3lzdGVtcyB0byB5aWVsZCByZXN1bHRzLlxuICAgKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9iZWRyb2NrL2xhdGVzdC91c2VyZ3VpZGUvYWdlbnRzLXJldHVybmNvbnRyb2wuaHRtbFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBSRVRVUk5fQ09OVFJPTCA9IG5ldyBBY3Rpb25Hcm91cEV4ZWN1dG9yKHVuZGVmaW5lZCwgQ3VzdG9tQ29udHJvbC5SRVRVUk5fQ09OVFJPTCk7XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYW4gYWN0aW9uIGdyb3VwIHdpdGggYSBMYW1iZGEgZnVuY3Rpb24gY29udGFpbmluZyB0aGUgYnVzaW5lc3MgbG9naWMuXG4gICAqIEBwYXJhbSBsYW1iZGFGdW5jdGlvbiAtIExhbWJkYSBmdW5jdGlvbiB0byBiZSBjYWxsZWQgYnkgdGhlIGFjdGlvbiBncm91cC5cbiAgICogQHNlZSBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vYmVkcm9jay9sYXRlc3QvdXNlcmd1aWRlL2FnZW50cy1sYW1iZGEuaHRtbFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tTGFtYmRhKGxhbWJkYUZ1bmN0aW9uOiBJRnVuY3Rpb24pOiBBY3Rpb25Hcm91cEV4ZWN1dG9yIHtcbiAgICByZXR1cm4gbmV3IEFjdGlvbkdyb3VwRXhlY3V0b3IobGFtYmRhRnVuY3Rpb24sIHVuZGVmaW5lZCk7XG4gIH1cblxuICAvKipcbiAgICogVGhlIExhbWJkYSBmdW5jdGlvbiB0aGF0IHdpbGwgYmUgY2FsbGVkIGJ5IHRoZSBhY3Rpb24gZ3JvdXAuXG4gICAqIENvbnRhaW5zIHRoZSBidXNpbmVzcyBsb2dpYyBmb3IgaGFuZGxpbmcgdGhlIGFjdGlvbiBncm91cCdzIGludm9jYXRpb24uXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgbGFtYmRhRnVuY3Rpb24/OiBJRnVuY3Rpb247XG5cbiAgLyoqXG4gICAqIFRoZSBjdXN0b20gY29udHJvbCB0eXBlIGZvciB0aGUgYWN0aW9uIGdyb3VwIGV4ZWN1dG9yLlxuICAgKiBDdXJyZW50bHkgb25seSBzdXBwb3J0cyAnUkVUVVJOX0NPTlRST0wnIHdoaWNoIHJldHVybnMgcmVzdWx0cyBkaXJlY3RseSBpbiB0aGUgSW52b2tlQWdlbnQgcmVzcG9uc2UuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgY3VzdG9tQ29udHJvbD86IEN1c3RvbUNvbnRyb2w7XG5cbiAgcHJpdmF0ZSBjb25zdHJ1Y3RvcihsYW1iZGFGdW5jdGlvbj86IElGdW5jdGlvbiwgY3VzdG9tQ29udHJvbD86IEN1c3RvbUNvbnRyb2wpIHtcbiAgICBpZiAobGFtYmRhRnVuY3Rpb24gJiYgY3VzdG9tQ29udHJvbCkge1xuICAgICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKGxpdGBNdXR1YWxseUV4Y2x1c2l2ZUV4ZWN1dG9yVHlwZXNgLCAnQWN0aW9uR3JvdXBFeGVjdXRvciBjYW5ub3QgaGF2ZSBib3RoIGxhbWJkYUZ1bmN0aW9uIGFuZCBjdXN0b21Db250cm9sIGRlZmluZWQgLSB0aGV5IGFyZSBtdXR1YWxseSBleGNsdXNpdmUuJyk7XG4gICAgfVxuICAgIHRoaXMubGFtYmRhRnVuY3Rpb24gPSBsYW1iZGFGdW5jdGlvbjtcbiAgICB0aGlzLmN1c3RvbUNvbnRyb2wgPSBjdXN0b21Db250cm9sO1xuICB9XG5cbiAgLyoqXG4gICAqIEZvcm1hdCBhcyBDRk4gcHJvcGVydGllc1xuICAgKlxuICAgKiBAaW50ZXJuYWwgVGhpcyBpcyBhbiBpbnRlcm5hbCBjb3JlIGZ1bmN0aW9uIGFuZCBzaG91bGQgbm90IGJlIGNhbGxlZCBkaXJlY3RseS5cbiAgICovXG4gIHB1YmxpYyBfcmVuZGVyKCk6IGJlZHJvY2suQ2ZuQWdlbnQuQWN0aW9uR3JvdXBFeGVjdXRvclByb3BlcnR5IHtcbiAgICByZXR1cm4ge1xuICAgICAgY3VzdG9tQ29udHJvbDogdGhpcy5jdXN0b21Db250cm9sLFxuICAgICAgbGFtYmRhOiB0aGlzLmxhbWJkYUZ1bmN0aW9uPy5mdW5jdGlvbkFybixcbiAgICB9O1xuICB9XG59XG4iXX0=