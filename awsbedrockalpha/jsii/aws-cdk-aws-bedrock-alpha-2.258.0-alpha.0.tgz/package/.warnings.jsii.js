const VALIDATORS = { _aws_cdk_aws_bedrock_alpha_AgentProps: function _aws_cdk_aws_bedrock_alpha_AgentProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actionGroups != null)
                for (const o of p.actionGroups)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_AgentActionGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_alpha_GuardrailProps: function _aws_cdk_aws_bedrock_alpha_GuardrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.contentFilters != null)
                for (const o of p.contentFilters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_ContentFilter(o);
            if (p.contextualGroundingFilters != null)
                for (const o of p.contextualGroundingFilters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_ContextualGroundingFilter(o);
            if (p.deniedTopics != null)
                for (const o of p.deniedTopics)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_Topic(o);
            if (p.managedWordListFilters != null)
                for (const o of p.managedWordListFilters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_ManagedWordFilter(o);
            if (p.piiFilters != null)
                for (const o of p.piiFilters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_PIIFilter(o);
            if (p.regexFilters != null)
                for (const o of p.regexFilters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_RegexFilter(o);
            if (p.wordFilters != null)
                for (const o of p.wordFilters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_WordFilter(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_alpha_PromptProps: function _aws_cdk_aws_bedrock_alpha_PromptProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.variants != null)
                for (const o of p.variants)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_IPromptVariant(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
