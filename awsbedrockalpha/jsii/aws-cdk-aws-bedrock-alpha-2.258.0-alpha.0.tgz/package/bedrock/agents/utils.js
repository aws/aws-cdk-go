"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.recommendedMaximumLambdaMemorySize = exports.maximumLambdaMemorySizeContextItem = exports.version = void 0;
exports.generatePhysicalName = generatePhysicalName;
exports.generatePhysicalNameV2 = generatePhysicalNameV2;
exports.lambdaMemorySizeLimiter = lambdaMemorySizeLimiter;
exports.addCfnSuppressRules = addCfnSuppressRules;
exports.isPlainObject = isPlainObject;
const crypto_1 = require("crypto");
const cdk = __importStar(require("aws-cdk-lib"));
const aws_cdk_lib_1 = require("aws-cdk-lib");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
/**
 * The version of this package
 */
// eslint-disable-next-line @typescript-eslint/no-require-imports
exports.version = require('../../../package.json').version;
/**
 * @internal This is an internal core function and should not be called directly by Solutions Constructs clients.
 *
 * @summary Creates a physical resource name in the style of the CDK (string+hash) - this value incorporates Stack ID,
 * so it will remain static in multiple updates of a single stack, but will be different in a separate stack instance
 * @param {IConstruct} scope - the CDK scope of the resource
 * @param {string} prefix - the prefix for the name
 * @param {string[]} parts - the various string components of the name (eg - stackName, solutions construct ID, L2 construct ID)
 * @param {number} maxLength - the longest string that can be returned
 * @returns {string} - a string with concatenated parts (truncated if necessary) + a hash of the full concatenated parts
 *
 * @deprecated This function is deprecated and will be removed in a future major version.
 * Please use the new function generatePhysicalNameV2 instead.
 */
function generatePhysicalName(scope, prefix, parts, maxLength) {
    // The result will consist of:
    //    -The prefix - unaltered
    //    -The parts concatenated, but reduced in size to meet the maxLength limit for the overall name
    //    -A hyphen delimiter
    //    -The GUID portion of the stack arn
    const stackIdGuidLength = 36;
    const prefixLength = prefix.length;
    const maxPartsLength = maxLength - prefixLength - 1 - stackIdGuidLength; // 1 is the hyphen
    // Extract the Stack ID Guid
    const uniqueStackIdPart = cdk.Fn.select(2, cdk.Fn.split('/', `${cdk.Aws.STACK_ID}`));
    let allParts = '';
    parts.forEach((part) => {
        allParts += part;
    });
    if (allParts.length > maxPartsLength) {
        const subStringLength = maxPartsLength / 2;
        allParts = allParts.substring(0, subStringLength) + allParts.substring(allParts.length - subStringLength);
    }
    if (prefix.length + allParts.length + stackIdGuidLength + 1 /* hyphen */ > maxLength) {
        throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `GeneratedNameTooLong`, `The generated name is longer than the maximum length of ${maxLength}`, scope);
    }
    return prefix.toLowerCase() + allParts + '-' + uniqueStackIdPart;
}
/**
 * @internal This is an internal core function and should not be called directly by Solutions Constructs clients.
 *
 * @summary Creates a physical resource name in the style of the CDK (string+hash) - this value incorporates
 * the Stack Name and node ID, so it will remain static in multiple updates of a single stack, but will be
 * different in a separate stack instance.
 *
 * This new version allows for names shorter than 36 characters with control over casing.
 *
 * The minimum length is the length of the prefix and separator plus 10.
 */
function generatePhysicalNameV2(
/**
 * The CDK scope of the resource.
 */
scope, 
/**
 * The prefix for the name.
 */
prefix, 
/**
 * Options for generating the name.
 */
options) {
    function objectToHash(obj) {
        // Nothing to hash if undefined
        if (obj === undefined) {
            return '';
        }
        // Convert the object to a JSON string
        const jsonString = JSON.stringify(obj);
        // Create a SHA-256 hash
        const hash = (0, crypto_1.createHash)('sha256');
        // Update the hash with the JSON string and get the digest in hexadecimal format
        // Shorten it (modeled after seven characters like git commit hash shortening)
        return hash.update(jsonString).digest('hex').slice(0, 7);
    }
    const { maxLength = 256, lower = false, separator = '', allowedSpecialCharacters = undefined, destroyCreate = undefined, } = options ?? {};
    const hash = objectToHash(destroyCreate);
    if (maxLength < (prefix + hash + separator).length) {
        throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `PrefixTooLong`, `The prefix length (${prefix.length}) plus hash length (${hash.length}) and separator length (${separator.length}) exceeds the maximum allowed length of ${maxLength}`, scope);
    }
    const uniqueName = cdk.Names.uniqueResourceName(scope, { maxLength: maxLength - (prefix + hash + separator).length, separator, allowedSpecialCharacters });
    const name = `${prefix}${hash}${separator}${uniqueName}`;
    if (name.length > maxLength) {
        throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `GeneratedNameTooLong`, `The generated name is longer than the maximum length of ${maxLength}`, scope);
    }
    return lower ? name.toLowerCase() : name;
}
exports.maximumLambdaMemorySizeContextItem = 'maximumLambdaMemorySize';
exports.recommendedMaximumLambdaMemorySize = 7076;
function lambdaMemorySizeLimiter(construct, requestedMemorySizeInMegabytes) {
    const maximumLambdaMemorySize = construct.node.tryGetContext(exports.maximumLambdaMemorySizeContextItem) === undefined ?
        exports.recommendedMaximumLambdaMemorySize :
        parseInt(construct.node.tryGetContext(exports.maximumLambdaMemorySizeContextItem));
    if (maximumLambdaMemorySize < exports.recommendedMaximumLambdaMemorySize) {
        cdk.Annotations.of(construct).addWarning(`Maximum Lambda memorySize, ${maximumLambdaMemorySize}, is less than the recommended ${exports.recommendedMaximumLambdaMemorySize}.`);
    }
    if (requestedMemorySizeInMegabytes > maximumLambdaMemorySize) {
        cdk.Annotations.of(construct).addWarning(`Reducing Lambda memorySize, ${requestedMemorySizeInMegabytes} to ${maximumLambdaMemorySize} for ${construct.constructor.name}`);
        return maximumLambdaMemorySize;
    }
    else {
        return requestedMemorySizeInMegabytes;
    }
}
/**
 * Adds CFN NAG suppress rules to the CDK resource.
 * @param resource The CDK resource
 * @param rules The CFN NAG suppress rules
 */
function addCfnSuppressRules(resource, rules) {
    if (resource instanceof cdk.Resource) {
        resource = resource.node.defaultChild;
    }
    if (resource.cfnOptions.metadata?.cfn_nag?.rules_to_suppress) {
        resource.cfnOptions.metadata?.cfn_nag.rules_to_suppress.push(...rules);
    }
    else {
        resource.addMetadata('cfn_nag', {
            rules_to_suppress: rules,
        });
    }
}
function isObject(val) {
    return val !== null && typeof val === 'object' && !Array.isArray(val);
}
function isPlainObject(o) {
    if (!isObject(o))
        return false;
    if (Object.getPrototypeOf(o) === null)
        return true;
    let proto = o;
    while (Object.getPrototypeOf(proto) !== null) {
        proto = Object.getPrototypeOf(proto);
    }
    return Object.getPrototypeOf(o) === proto;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ1dGlscy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQ0Esb0RBbUNDO0FBMkJELHdEQWdEQztBQUlELDBEQWlCQztBQU9ELGtEQVlDO0FBTUQsc0NBVUM7QUF4TUQsbUNBQW9DO0FBQ3BDLGlEQUFtQztBQUNuQyw2Q0FBOEM7QUFDOUMsNEVBQTREO0FBWTVEOztHQUVHO0FBQ0gsaUVBQWlFO0FBQ3BELFFBQUEsT0FBTyxHQUFHLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNoRTs7Ozs7Ozs7Ozs7OztHQWFHO0FBQ0gsU0FBZ0Isb0JBQW9CLENBQ2xDLEtBQWlCLEVBQ2pCLE1BQWMsRUFDZCxLQUFlLEVBQ2YsU0FBaUI7SUFFakIsOEJBQThCO0lBQzlCLDZCQUE2QjtJQUM3QixtR0FBbUc7SUFDbkcseUJBQXlCO0lBQ3pCLHdDQUF3QztJQUV4QyxNQUFNLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztJQUM3QixNQUFNLFlBQVksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDO0lBQ25DLE1BQU0sY0FBYyxHQUFHLFNBQVMsR0FBRyxZQUFZLEdBQUcsQ0FBQyxHQUFHLGlCQUFpQixDQUFDLENBQUMsa0JBQWtCO0lBRTNGLDRCQUE0QjtJQUM1QixNQUFNLGlCQUFpQixHQUFHLEdBQUcsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUVyRixJQUFJLFFBQVEsR0FBVyxFQUFFLENBQUM7SUFFMUIsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO1FBQ3JCLFFBQVEsSUFBSSxJQUFJLENBQUM7SUFDbkIsQ0FBQyxDQUFDLENBQUM7SUFFSCxJQUFJLFFBQVEsQ0FBQyxNQUFNLEdBQUcsY0FBYyxFQUFFLENBQUM7UUFDckMsTUFBTSxlQUFlLEdBQUcsY0FBYyxHQUFHLENBQUMsQ0FBQztRQUMzQyxRQUFRLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsZUFBZSxDQUFDLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLGVBQWUsQ0FBQyxDQUFDO0lBQzVHLENBQUM7SUFFRCxJQUFJLE1BQU0sQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDLE1BQU0sR0FBRyxpQkFBaUIsR0FBRyxDQUFDLENBQUMsWUFBWSxHQUFHLFNBQVMsRUFBRSxDQUFDO1FBQ3JGLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSxzQkFBc0IsRUFBRSwyREFBMkQsU0FBUyxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdEksQ0FBQztJQUVELE9BQU8sTUFBTSxDQUFDLFdBQVcsRUFBRSxHQUFHLFFBQVEsR0FBRyxHQUFHLEdBQUcsaUJBQWlCLENBQUM7QUFDbkUsQ0FBQztBQWdCRDs7Ozs7Ozs7OztHQVVHO0FBQ0gsU0FBZ0Isc0JBQXNCO0FBQ3BDOztHQUVHO0FBQ0gsS0FBaUI7QUFDakI7O0dBRUc7QUFDSCxNQUFjO0FBQ2Q7O0dBRUc7QUFDSCxPQUF1QztJQUV2QyxTQUFTLFlBQVksQ0FBQyxHQUFRO1FBQzVCLCtCQUErQjtRQUMvQixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUFDLE9BQU8sRUFBRSxDQUFDO1FBQUMsQ0FBQztRQUVyQyxzQ0FBc0M7UUFDdEMsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUV2Qyx3QkFBd0I7UUFDeEIsTUFBTSxJQUFJLEdBQUcsSUFBQSxtQkFBVSxFQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRWxDLGdGQUFnRjtRQUNoRiw4RUFBOEU7UUFDOUUsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFDRCxNQUFNLEVBQ0osU0FBUyxHQUFHLEdBQUcsRUFDZixLQUFLLEdBQUcsS0FBSyxFQUNiLFNBQVMsR0FBRyxFQUFFLEVBQ2Qsd0JBQXdCLEdBQUcsU0FBUyxFQUNwQyxhQUFhLEdBQUcsU0FBUyxHQUMxQixHQUFHLE9BQU8sSUFBSSxFQUFFLENBQUM7SUFDbEIsTUFBTSxJQUFJLEdBQUcsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQ3pDLElBQUksU0FBUyxHQUFHLENBQUMsTUFBTSxHQUFHLElBQUksR0FBRyxTQUFTLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNuRCxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsZUFBZSxFQUFFLHNCQUFzQixNQUFNLENBQUMsTUFBTSx1QkFBdUIsSUFBSSxDQUFDLE1BQU0sMkJBQTJCLFNBQVMsQ0FBQyxNQUFNLDJDQUEyQyxTQUFTLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUMvTixDQUFDO0lBQ0QsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FDN0MsS0FBSyxFQUNMLEVBQUUsU0FBUyxFQUFFLFNBQVMsR0FBRyxDQUFDLE1BQU0sR0FBRyxJQUFJLEdBQUcsU0FBUyxDQUFDLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSx3QkFBd0IsRUFBRSxDQUNuRyxDQUFDO0lBQ0YsTUFBTSxJQUFJLEdBQUcsR0FBRyxNQUFNLEdBQUcsSUFBSSxHQUFHLFNBQVMsR0FBRyxVQUFVLEVBQUUsQ0FBQztJQUN6RCxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsU0FBUyxFQUFFLENBQUM7UUFDNUIsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHNCQUFzQixFQUFFLDJEQUEyRCxTQUFTLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0SSxDQUFDO0lBQ0QsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzNDLENBQUM7QUFFWSxRQUFBLGtDQUFrQyxHQUFHLHlCQUF5QixDQUFDO0FBQy9ELFFBQUEsa0NBQWtDLEdBQUcsSUFBSSxDQUFDO0FBQ3ZELFNBQWdCLHVCQUF1QixDQUFDLFNBQXFCLEVBQUUsOEJBQXNDO0lBQ25HLE1BQU0sdUJBQXVCLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsMENBQWtDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQztRQUM5RywwQ0FBa0MsQ0FBQyxDQUFDO1FBQ3BDLFFBQVEsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQywwQ0FBa0MsQ0FBQyxDQUFDLENBQUM7SUFDN0UsSUFBSSx1QkFBdUIsR0FBRywwQ0FBa0MsRUFBRSxDQUFDO1FBQ2pFLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsQ0FDdEMsOEJBQThCLHVCQUF1QixrQ0FBa0MsMENBQWtDLEdBQUcsQ0FDN0gsQ0FBQztJQUNKLENBQUM7SUFDRCxJQUFJLDhCQUE4QixHQUFHLHVCQUF1QixFQUFFLENBQUM7UUFDN0QsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxDQUN0QywrQkFBK0IsOEJBQThCLE9BQU8sdUJBQXVCLFFBQVEsU0FBUyxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FDaEksQ0FBQztRQUNGLE9BQU8sdUJBQXVCLENBQUM7SUFDakMsQ0FBQztTQUFNLENBQUM7UUFDTixPQUFPLDhCQUE4QixDQUFDO0lBQ3hDLENBQUM7QUFDSCxDQUFDO0FBRUQ7Ozs7R0FJRztBQUNILFNBQWdCLG1CQUFtQixDQUFDLFFBQXdDLEVBQUUsS0FBMkI7SUFDdkcsSUFBSSxRQUFRLFlBQVksR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3JDLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQStCLENBQUM7SUFDM0QsQ0FBQztJQUVELElBQUksUUFBUSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLENBQUM7UUFDN0QsUUFBUSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO0lBQ3pFLENBQUM7U0FBTSxDQUFDO1FBQ04sUUFBUSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUU7WUFDOUIsaUJBQWlCLEVBQUUsS0FBSztTQUN6QixDQUFDLENBQUM7SUFDTCxDQUFDO0FBQ0gsQ0FBQztBQUVELFNBQVMsUUFBUSxDQUFDLEdBQVc7SUFDM0IsT0FBTyxHQUFHLEtBQUssSUFBSSxJQUFJLE9BQU8sR0FBRyxLQUFLLFFBQVEsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDeEUsQ0FBQztBQUVELFNBQWdCLGFBQWEsQ0FBQyxDQUFTO0lBQ3JDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQUUsT0FBTyxLQUFLLENBQUM7SUFFL0IsSUFBSSxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUk7UUFBRSxPQUFPLElBQUksQ0FBQztJQUVuRCxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7SUFDZCxPQUFPLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUM7UUFDN0MsS0FBSyxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUNELE9BQU8sTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUM7QUFDNUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUhhc2ggfSBmcm9tICdjcnlwdG8nO1xuaW1wb3J0ICogYXMgY2RrIGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCB7IFZhbGlkYXRpb25FcnJvciB9IGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCB7IGxpdCB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2hlbHBlcnMtaW50ZXJuYWwnO1xuaW1wb3J0IHR5cGUgeyBJQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5cbi8qKlxuICogVGhlIENGTiBOQUcgc3VwcHJlc3MgcnVsZSBpbnRlcmZhY2VcbiAqIEBpbnRlcmZhY2UgQ2ZuTmFnU3VwcHJlc3NSdWxlXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2ZuTmFnU3VwcHJlc3NSdWxlIHtcbiAgcmVhZG9ubHkgaWQ6IHN0cmluZztcbiAgcmVhZG9ubHkgcmVhc29uOiBzdHJpbmc7XG59XG5cbi8qKlxuICogVGhlIHZlcnNpb24gb2YgdGhpcyBwYWNrYWdlXG4gKi9cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tcmVxdWlyZS1pbXBvcnRzXG5leHBvcnQgY29uc3QgdmVyc2lvbiA9IHJlcXVpcmUoJy4uLy4uLy4uL3BhY2thZ2UuanNvbicpLnZlcnNpb247XG4vKipcbiAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5IGJ5IFNvbHV0aW9ucyBDb25zdHJ1Y3RzIGNsaWVudHMuXG4gKlxuICogQHN1bW1hcnkgQ3JlYXRlcyBhIHBoeXNpY2FsIHJlc291cmNlIG5hbWUgaW4gdGhlIHN0eWxlIG9mIHRoZSBDREsgKHN0cmluZytoYXNoKSAtIHRoaXMgdmFsdWUgaW5jb3Jwb3JhdGVzIFN0YWNrIElELFxuICogc28gaXQgd2lsbCByZW1haW4gc3RhdGljIGluIG11bHRpcGxlIHVwZGF0ZXMgb2YgYSBzaW5nbGUgc3RhY2ssIGJ1dCB3aWxsIGJlIGRpZmZlcmVudCBpbiBhIHNlcGFyYXRlIHN0YWNrIGluc3RhbmNlXG4gKiBAcGFyYW0ge0lDb25zdHJ1Y3R9IHNjb3BlIC0gdGhlIENESyBzY29wZSBvZiB0aGUgcmVzb3VyY2VcbiAqIEBwYXJhbSB7c3RyaW5nfSBwcmVmaXggLSB0aGUgcHJlZml4IGZvciB0aGUgbmFtZVxuICogQHBhcmFtIHtzdHJpbmdbXX0gcGFydHMgLSB0aGUgdmFyaW91cyBzdHJpbmcgY29tcG9uZW50cyBvZiB0aGUgbmFtZSAoZWcgLSBzdGFja05hbWUsIHNvbHV0aW9ucyBjb25zdHJ1Y3QgSUQsIEwyIGNvbnN0cnVjdCBJRClcbiAqIEBwYXJhbSB7bnVtYmVyfSBtYXhMZW5ndGggLSB0aGUgbG9uZ2VzdCBzdHJpbmcgdGhhdCBjYW4gYmUgcmV0dXJuZWRcbiAqIEByZXR1cm5zIHtzdHJpbmd9IC0gYSBzdHJpbmcgd2l0aCBjb25jYXRlbmF0ZWQgcGFydHMgKHRydW5jYXRlZCBpZiBuZWNlc3NhcnkpICsgYSBoYXNoIG9mIHRoZSBmdWxsIGNvbmNhdGVuYXRlZCBwYXJ0c1xuICpcbiAqIEBkZXByZWNhdGVkIFRoaXMgZnVuY3Rpb24gaXMgZGVwcmVjYXRlZCBhbmQgd2lsbCBiZSByZW1vdmVkIGluIGEgZnV0dXJlIG1ham9yIHZlcnNpb24uXG4gKiBQbGVhc2UgdXNlIHRoZSBuZXcgZnVuY3Rpb24gZ2VuZXJhdGVQaHlzaWNhbE5hbWVWMiBpbnN0ZWFkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVQaHlzaWNhbE5hbWUoXG4gIHNjb3BlOiBJQ29uc3RydWN0LFxuICBwcmVmaXg6IHN0cmluZyxcbiAgcGFydHM6IHN0cmluZ1tdLFxuICBtYXhMZW5ndGg6IG51bWJlcixcbik6IHN0cmluZyB7XG4gIC8vIFRoZSByZXN1bHQgd2lsbCBjb25zaXN0IG9mOlxuICAvLyAgICAtVGhlIHByZWZpeCAtIHVuYWx0ZXJlZFxuICAvLyAgICAtVGhlIHBhcnRzIGNvbmNhdGVuYXRlZCwgYnV0IHJlZHVjZWQgaW4gc2l6ZSB0byBtZWV0IHRoZSBtYXhMZW5ndGggbGltaXQgZm9yIHRoZSBvdmVyYWxsIG5hbWVcbiAgLy8gICAgLUEgaHlwaGVuIGRlbGltaXRlclxuICAvLyAgICAtVGhlIEdVSUQgcG9ydGlvbiBvZiB0aGUgc3RhY2sgYXJuXG5cbiAgY29uc3Qgc3RhY2tJZEd1aWRMZW5ndGggPSAzNjtcbiAgY29uc3QgcHJlZml4TGVuZ3RoID0gcHJlZml4Lmxlbmd0aDtcbiAgY29uc3QgbWF4UGFydHNMZW5ndGggPSBtYXhMZW5ndGggLSBwcmVmaXhMZW5ndGggLSAxIC0gc3RhY2tJZEd1aWRMZW5ndGg7IC8vIDEgaXMgdGhlIGh5cGhlblxuXG4gIC8vIEV4dHJhY3QgdGhlIFN0YWNrIElEIEd1aWRcbiAgY29uc3QgdW5pcXVlU3RhY2tJZFBhcnQgPSBjZGsuRm4uc2VsZWN0KDIsIGNkay5Gbi5zcGxpdCgnLycsIGAke2Nkay5Bd3MuU1RBQ0tfSUR9YCkpO1xuXG4gIGxldCBhbGxQYXJ0czogc3RyaW5nID0gJyc7XG5cbiAgcGFydHMuZm9yRWFjaCgocGFydCkgPT4ge1xuICAgIGFsbFBhcnRzICs9IHBhcnQ7XG4gIH0pO1xuXG4gIGlmIChhbGxQYXJ0cy5sZW5ndGggPiBtYXhQYXJ0c0xlbmd0aCkge1xuICAgIGNvbnN0IHN1YlN0cmluZ0xlbmd0aCA9IG1heFBhcnRzTGVuZ3RoIC8gMjtcbiAgICBhbGxQYXJ0cyA9IGFsbFBhcnRzLnN1YnN0cmluZygwLCBzdWJTdHJpbmdMZW5ndGgpICsgYWxsUGFydHMuc3Vic3RyaW5nKGFsbFBhcnRzLmxlbmd0aCAtIHN1YlN0cmluZ0xlbmd0aCk7XG4gIH1cblxuICBpZiAocHJlZml4Lmxlbmd0aCArIGFsbFBhcnRzLmxlbmd0aCArIHN0YWNrSWRHdWlkTGVuZ3RoICsgMSAvKiBoeXBoZW4gKi8gPiBtYXhMZW5ndGgpIHtcbiAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBHZW5lcmF0ZWROYW1lVG9vTG9uZ2AsIGBUaGUgZ2VuZXJhdGVkIG5hbWUgaXMgbG9uZ2VyIHRoYW4gdGhlIG1heGltdW0gbGVuZ3RoIG9mICR7bWF4TGVuZ3RofWAsIHNjb3BlKTtcbiAgfVxuXG4gIHJldHVybiBwcmVmaXgudG9Mb3dlckNhc2UoKSArIGFsbFBhcnRzICsgJy0nICsgdW5pcXVlU3RhY2tJZFBhcnQ7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgR2VuZXJhdGVQaHlzaWNhbE5hbWVWMk9wdGlvbnMgZXh0ZW5kcyBjZGsuVW5pcXVlUmVzb3VyY2VOYW1lT3B0aW9ucyB7XG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIGNvbnZlcnQgdGhlIG5hbWUgdG8gbG93ZXIgY2FzZS5cbiAgICpcbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIGxvd2VyPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogVGhpcyBvYmplY3QgaXMgaGFzaGVkIGZvciB1bmlxdWVuZXNzIGFuZCBjYW4gZm9yY2UgYSBkZXN0cm95IGluc3RlYWQgb2YgYSByZXBsYWNlLlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWRcbiAgICovXG4gIGRlc3Ryb3lDcmVhdGU/OiBhbnk7XG59XG4vKipcbiAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5IGJ5IFNvbHV0aW9ucyBDb25zdHJ1Y3RzIGNsaWVudHMuXG4gKlxuICogQHN1bW1hcnkgQ3JlYXRlcyBhIHBoeXNpY2FsIHJlc291cmNlIG5hbWUgaW4gdGhlIHN0eWxlIG9mIHRoZSBDREsgKHN0cmluZytoYXNoKSAtIHRoaXMgdmFsdWUgaW5jb3Jwb3JhdGVzXG4gKiB0aGUgU3RhY2sgTmFtZSBhbmQgbm9kZSBJRCwgc28gaXQgd2lsbCByZW1haW4gc3RhdGljIGluIG11bHRpcGxlIHVwZGF0ZXMgb2YgYSBzaW5nbGUgc3RhY2ssIGJ1dCB3aWxsIGJlXG4gKiBkaWZmZXJlbnQgaW4gYSBzZXBhcmF0ZSBzdGFjayBpbnN0YW5jZS5cbiAqXG4gKiBUaGlzIG5ldyB2ZXJzaW9uIGFsbG93cyBmb3IgbmFtZXMgc2hvcnRlciB0aGFuIDM2IGNoYXJhY3RlcnMgd2l0aCBjb250cm9sIG92ZXIgY2FzaW5nLlxuICpcbiAqIFRoZSBtaW5pbXVtIGxlbmd0aCBpcyB0aGUgbGVuZ3RoIG9mIHRoZSBwcmVmaXggYW5kIHNlcGFyYXRvciBwbHVzIDEwLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVQaHlzaWNhbE5hbWVWMihcbiAgLyoqXG4gICAqIFRoZSBDREsgc2NvcGUgb2YgdGhlIHJlc291cmNlLlxuICAgKi9cbiAgc2NvcGU6IElDb25zdHJ1Y3QsXG4gIC8qKlxuICAgKiBUaGUgcHJlZml4IGZvciB0aGUgbmFtZS5cbiAgICovXG4gIHByZWZpeDogc3RyaW5nLFxuICAvKipcbiAgICogT3B0aW9ucyBmb3IgZ2VuZXJhdGluZyB0aGUgbmFtZS5cbiAgICovXG4gIG9wdGlvbnM/OiBHZW5lcmF0ZVBoeXNpY2FsTmFtZVYyT3B0aW9ucyxcbik6IHN0cmluZyB7XG4gIGZ1bmN0aW9uIG9iamVjdFRvSGFzaChvYmo6IGFueSk6IHN0cmluZyB7XG4gICAgLy8gTm90aGluZyB0byBoYXNoIGlmIHVuZGVmaW5lZFxuICAgIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gJyc7IH1cblxuICAgIC8vIENvbnZlcnQgdGhlIG9iamVjdCB0byBhIEpTT04gc3RyaW5nXG4gICAgY29uc3QganNvblN0cmluZyA9IEpTT04uc3RyaW5naWZ5KG9iaik7XG5cbiAgICAvLyBDcmVhdGUgYSBTSEEtMjU2IGhhc2hcbiAgICBjb25zdCBoYXNoID0gY3JlYXRlSGFzaCgnc2hhMjU2Jyk7XG5cbiAgICAvLyBVcGRhdGUgdGhlIGhhc2ggd2l0aCB0aGUgSlNPTiBzdHJpbmcgYW5kIGdldCB0aGUgZGlnZXN0IGluIGhleGFkZWNpbWFsIGZvcm1hdFxuICAgIC8vIFNob3J0ZW4gaXQgKG1vZGVsZWQgYWZ0ZXIgc2V2ZW4gY2hhcmFjdGVycyBsaWtlIGdpdCBjb21taXQgaGFzaCBzaG9ydGVuaW5nKVxuICAgIHJldHVybiBoYXNoLnVwZGF0ZShqc29uU3RyaW5nKS5kaWdlc3QoJ2hleCcpLnNsaWNlKDAsIDcpO1xuICB9XG4gIGNvbnN0IHtcbiAgICBtYXhMZW5ndGggPSAyNTYsXG4gICAgbG93ZXIgPSBmYWxzZSxcbiAgICBzZXBhcmF0b3IgPSAnJyxcbiAgICBhbGxvd2VkU3BlY2lhbENoYXJhY3RlcnMgPSB1bmRlZmluZWQsXG4gICAgZGVzdHJveUNyZWF0ZSA9IHVuZGVmaW5lZCxcbiAgfSA9IG9wdGlvbnMgPz8ge307XG4gIGNvbnN0IGhhc2ggPSBvYmplY3RUb0hhc2goZGVzdHJveUNyZWF0ZSk7XG4gIGlmIChtYXhMZW5ndGggPCAocHJlZml4ICsgaGFzaCArIHNlcGFyYXRvcikubGVuZ3RoKSB7XG4gICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgUHJlZml4VG9vTG9uZ2AsIGBUaGUgcHJlZml4IGxlbmd0aCAoJHtwcmVmaXgubGVuZ3RofSkgcGx1cyBoYXNoIGxlbmd0aCAoJHtoYXNoLmxlbmd0aH0pIGFuZCBzZXBhcmF0b3IgbGVuZ3RoICgke3NlcGFyYXRvci5sZW5ndGh9KSBleGNlZWRzIHRoZSBtYXhpbXVtIGFsbG93ZWQgbGVuZ3RoIG9mICR7bWF4TGVuZ3RofWAsIHNjb3BlKTtcbiAgfVxuICBjb25zdCB1bmlxdWVOYW1lID0gY2RrLk5hbWVzLnVuaXF1ZVJlc291cmNlTmFtZShcbiAgICBzY29wZSxcbiAgICB7IG1heExlbmd0aDogbWF4TGVuZ3RoIC0gKHByZWZpeCArIGhhc2ggKyBzZXBhcmF0b3IpLmxlbmd0aCwgc2VwYXJhdG9yLCBhbGxvd2VkU3BlY2lhbENoYXJhY3RlcnMgfSxcbiAgKTtcbiAgY29uc3QgbmFtZSA9IGAke3ByZWZpeH0ke2hhc2h9JHtzZXBhcmF0b3J9JHt1bmlxdWVOYW1lfWA7XG4gIGlmIChuYW1lLmxlbmd0aCA+IG1heExlbmd0aCkge1xuICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YEdlbmVyYXRlZE5hbWVUb29Mb25nYCwgYFRoZSBnZW5lcmF0ZWQgbmFtZSBpcyBsb25nZXIgdGhhbiB0aGUgbWF4aW11bSBsZW5ndGggb2YgJHttYXhMZW5ndGh9YCwgc2NvcGUpO1xuICB9XG4gIHJldHVybiBsb3dlciA/IG5hbWUudG9Mb3dlckNhc2UoKSA6IG5hbWU7XG59XG5cbmV4cG9ydCBjb25zdCBtYXhpbXVtTGFtYmRhTWVtb3J5U2l6ZUNvbnRleHRJdGVtID0gJ21heGltdW1MYW1iZGFNZW1vcnlTaXplJztcbmV4cG9ydCBjb25zdCByZWNvbW1lbmRlZE1heGltdW1MYW1iZGFNZW1vcnlTaXplID0gNzA3NjtcbmV4cG9ydCBmdW5jdGlvbiBsYW1iZGFNZW1vcnlTaXplTGltaXRlcihjb25zdHJ1Y3Q6IElDb25zdHJ1Y3QsIHJlcXVlc3RlZE1lbW9yeVNpemVJbk1lZ2FieXRlczogbnVtYmVyKSB7XG4gIGNvbnN0IG1heGltdW1MYW1iZGFNZW1vcnlTaXplID0gY29uc3RydWN0Lm5vZGUudHJ5R2V0Q29udGV4dChtYXhpbXVtTGFtYmRhTWVtb3J5U2l6ZUNvbnRleHRJdGVtKSA9PT0gdW5kZWZpbmVkID9cbiAgICByZWNvbW1lbmRlZE1heGltdW1MYW1iZGFNZW1vcnlTaXplIDpcbiAgICBwYXJzZUludChjb25zdHJ1Y3Qubm9kZS50cnlHZXRDb250ZXh0KG1heGltdW1MYW1iZGFNZW1vcnlTaXplQ29udGV4dEl0ZW0pKTtcbiAgaWYgKG1heGltdW1MYW1iZGFNZW1vcnlTaXplIDwgcmVjb21tZW5kZWRNYXhpbXVtTGFtYmRhTWVtb3J5U2l6ZSkge1xuICAgIGNkay5Bbm5vdGF0aW9ucy5vZihjb25zdHJ1Y3QpLmFkZFdhcm5pbmcoXG4gICAgICBgTWF4aW11bSBMYW1iZGEgbWVtb3J5U2l6ZSwgJHttYXhpbXVtTGFtYmRhTWVtb3J5U2l6ZX0sIGlzIGxlc3MgdGhhbiB0aGUgcmVjb21tZW5kZWQgJHtyZWNvbW1lbmRlZE1heGltdW1MYW1iZGFNZW1vcnlTaXplfS5gLFxuICAgICk7XG4gIH1cbiAgaWYgKHJlcXVlc3RlZE1lbW9yeVNpemVJbk1lZ2FieXRlcyA+IG1heGltdW1MYW1iZGFNZW1vcnlTaXplKSB7XG4gICAgY2RrLkFubm90YXRpb25zLm9mKGNvbnN0cnVjdCkuYWRkV2FybmluZyhcbiAgICAgIGBSZWR1Y2luZyBMYW1iZGEgbWVtb3J5U2l6ZSwgJHtyZXF1ZXN0ZWRNZW1vcnlTaXplSW5NZWdhYnl0ZXN9IHRvICR7bWF4aW11bUxhbWJkYU1lbW9yeVNpemV9IGZvciAke2NvbnN0cnVjdC5jb25zdHJ1Y3Rvci5uYW1lfWAsXG4gICAgKTtcbiAgICByZXR1cm4gbWF4aW11bUxhbWJkYU1lbW9yeVNpemU7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIHJlcXVlc3RlZE1lbW9yeVNpemVJbk1lZ2FieXRlcztcbiAgfVxufVxuXG4vKipcbiAqIEFkZHMgQ0ZOIE5BRyBzdXBwcmVzcyBydWxlcyB0byB0aGUgQ0RLIHJlc291cmNlLlxuICogQHBhcmFtIHJlc291cmNlIFRoZSBDREsgcmVzb3VyY2VcbiAqIEBwYXJhbSBydWxlcyBUaGUgQ0ZOIE5BRyBzdXBwcmVzcyBydWxlc1xuICovXG5leHBvcnQgZnVuY3Rpb24gYWRkQ2ZuU3VwcHJlc3NSdWxlcyhyZXNvdXJjZTogY2RrLlJlc291cmNlIHwgY2RrLkNmblJlc291cmNlLCBydWxlczogQ2ZuTmFnU3VwcHJlc3NSdWxlW10pIHtcbiAgaWYgKHJlc291cmNlIGluc3RhbmNlb2YgY2RrLlJlc291cmNlKSB7XG4gICAgcmVzb3VyY2UgPSByZXNvdXJjZS5ub2RlLmRlZmF1bHRDaGlsZCBhcyBjZGsuQ2ZuUmVzb3VyY2U7XG4gIH1cblxuICBpZiAocmVzb3VyY2UuY2ZuT3B0aW9ucy5tZXRhZGF0YT8uY2ZuX25hZz8ucnVsZXNfdG9fc3VwcHJlc3MpIHtcbiAgICByZXNvdXJjZS5jZm5PcHRpb25zLm1ldGFkYXRhPy5jZm5fbmFnLnJ1bGVzX3RvX3N1cHByZXNzLnB1c2goLi4ucnVsZXMpO1xuICB9IGVsc2Uge1xuICAgIHJlc291cmNlLmFkZE1ldGFkYXRhKCdjZm5fbmFnJywge1xuICAgICAgcnVsZXNfdG9fc3VwcHJlc3M6IHJ1bGVzLFxuICAgIH0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIGlzT2JqZWN0KHZhbDogb2JqZWN0KSB7XG4gIHJldHVybiB2YWwgIT09IG51bGwgJiYgdHlwZW9mIHZhbCA9PT0gJ29iamVjdCcgJiYgIUFycmF5LmlzQXJyYXkodmFsKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzUGxhaW5PYmplY3Qobzogb2JqZWN0KSB7XG4gIGlmICghaXNPYmplY3QobykpIHJldHVybiBmYWxzZTtcblxuICBpZiAoT2JqZWN0LmdldFByb3RvdHlwZU9mKG8pID09PSBudWxsKSByZXR1cm4gdHJ1ZTtcblxuICBsZXQgcHJvdG8gPSBvO1xuICB3aGlsZSAoT2JqZWN0LmdldFByb3RvdHlwZU9mKHByb3RvKSAhPT0gbnVsbCkge1xuICAgIHByb3RvID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKHByb3RvKTtcbiAgfVxuICByZXR1cm4gT2JqZWN0LmdldFByb3RvdHlwZU9mKG8pID09PSBwcm90bztcbn1cbiJdfQ==