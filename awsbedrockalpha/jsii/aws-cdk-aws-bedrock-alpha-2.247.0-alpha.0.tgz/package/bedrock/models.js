"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BedrockFoundationModel = exports.VectorType = void 0;
const jsiiDeprecationWarnings = require("../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
const aws_cdk_lib_1 = require("aws-cdk-lib");
const aws_iam_1 = require("aws-cdk-lib/aws-iam");
/**
 * The data type for the vectors when using a model to convert text into vector embeddings.
 * The model must support the specified data type for vector embeddings. Floating-point (float32)
 * is the default data type, and is supported by most models for vector embeddings. See Supported
 * embeddings models for information on the available models and their vector data types.
 */
var VectorType;
(function (VectorType) {
    /**
     * `FLOATING_POINT` convert the data to floating-point (float32) vector embeddings (more precise, but more costly).
     */
    VectorType["FLOATING_POINT"] = "FLOAT32";
    /**
     * `BINARY` convert the data to binary vector embeddings (less precise, but less costly).
     */
    VectorType["BINARY"] = "BINARY";
})(VectorType || (exports.VectorType = VectorType = {}));
/**
 * Bedrock models.
 *
 * If you need to use a model name that doesn't exist as a static member, you
 * can instantiate a `BedrockFoundationModel` object, e.g: `new BedrockFoundationModel('my-model')`.
 */
class BedrockFoundationModel {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.BedrockFoundationModel", version: "2.247.0-alpha.0" };
    /****************************************************************************
     *                            AI21
     ***************************************************************************/
    /**
     * AI21's Jamba 1.5 Large model optimized for text generation tasks.
     * Suitable for complex language understanding and generation tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Optimized for natural language processing
     * - Best for: Content generation, summarization, and complex text analysis
     */
    static AI21_JAMBA_1_5_LARGE_V1 = new BedrockFoundationModel('ai21.jamba-1-5-large-v1:0', {
        supportsAgents: true,
    });
    /**
     * AI21's Jamba 1.5 Mini model, a lighter version optimized for faster processing.
     * Balances performance with efficiency for general text tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Faster response times compared to larger models
     * - Best for: Quick text processing, basic content generation
     */
    static AI21_JAMBA_1_5_MINI_V1 = new BedrockFoundationModel('ai21.jamba-1-5-mini-v1:0', {
        supportsAgents: true,
    });
    /**
     * AI21's Jamba Instruct model, specifically designed for instruction-following tasks.
     * Optimized for understanding and executing specific instructions.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Enhanced instruction understanding
     * - Best for: Task-specific instructions, command processing
     */
    static AI21_JAMBA_INSTRUCT_V1 = new BedrockFoundationModel('ai21.jamba-instruct-v1:0', {
        supportsAgents: true,
    });
    /****************************************************************************
     *                            AMAZON
     ***************************************************************************/
    /**
     * Amazon's Titan Text Express model, optimized for fast text generation.
     * Provides quick responses while maintaining good quality output.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Fast response times
     * - Best for: Real-time applications, chatbots, quick content generation
     */
    static AMAZON_TITAN_TEXT_EXPRESS_V1 = new BedrockFoundationModel('amazon.titan-text-express-v1', {
        supportsAgents: true,
    });
    /**
     * Amazon's Titan Text Premier model, designed for high-quality text generation.
     * Offers enhanced capabilities for complex language tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Advanced language understanding
     * - Best for: Complex content generation, detailed analysis
     */
    static AMAZON_TITAN_PREMIER_V1_0 = new BedrockFoundationModel('amazon.titan-text-premier-v1:0', {
        supportsAgents: true,
    });
    /**
     * Amazon's Nova Micro model, a lightweight model optimized for efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Quick processing tasks, basic language understanding
     */
    static AMAZON_NOVA_MICRO_V1 = new BedrockFoundationModel('amazon.nova-micro-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
        optimizedForAgents: true,
    });
    /**
     * Amazon's Nova Lite model, balancing performance with efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: General-purpose language tasks, moderate complexity
     */
    static AMAZON_NOVA_LITE_V1 = new BedrockFoundationModel('amazon.nova-lite-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
        optimizedForAgents: true,
    });
    /**
     * Amazon's Nova Pro model, offering advanced capabilities for complex tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Complex language tasks, professional applications
     */
    static AMAZON_NOVA_PRO_V1 = new BedrockFoundationModel('amazon.nova-pro-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
        optimizedForAgents: true,
    });
    /**
     * Amazon's Nova Premier model, the most advanced in the Nova series.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: High-end applications, complex analysis, premium performance
     */
    static AMAZON_NOVA_PREMIER_V1 = new BedrockFoundationModel('amazon.nova-premier-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
        optimizedForAgents: true,
    });
    /**
     * Amazon's Titan Embed Text V1 model for text embeddings.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 1536-dimensional vectors
     * - Floating-point vector type
     * - Best for: Text embeddings, semantic search, document similarity
     */
    static TITAN_EMBED_TEXT_V1 = new BedrockFoundationModel('amazon.titan-embed-text-v1', {
        supportsKnowledgeBase: true,
        vectorDimensions: 1536,
        supportedVectorType: [VectorType.FLOATING_POINT],
    });
    /**
     * Amazon's Titan Embed Text V2 model with 1024-dimensional vectors.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 1024-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: High-dimensional embeddings, advanced semantic search
     */
    static TITAN_EMBED_TEXT_V2_1024 = new BedrockFoundationModel('amazon.titan-embed-text-v2:0', {
        supportsKnowledgeBase: true,
        vectorDimensions: 1024,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /**
     * Amazon's Titan Embed Text V2 model with 512-dimensional vectors.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 512-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: Balanced performance and dimensionality
     */
    static TITAN_EMBED_TEXT_V2_512 = new BedrockFoundationModel('amazon.titan-embed-text-v2:0', {
        supportsKnowledgeBase: true,
        vectorDimensions: 512,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /**
     * Amazon's Titan Embed Text V2 model with 256-dimensional vectors.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 256-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: Efficient embeddings with lower dimensionality
     */
    static TITAN_EMBED_TEXT_V2_256 = new BedrockFoundationModel('amazon.titan-embed-text-v2:0', {
        supportsKnowledgeBase: true,
        vectorDimensions: 256,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /****************************************************************************
     *                            ANTHROPIC
     ***************************************************************************/
    /**
     * Anthropic's Claude Haiku 4.5 model, most cost-efficient and fastest.
     * Delivers near-frontier performance with substantially lower cost and faster speeds.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Large-scale deployments, budget-conscious applications, real-time customer service, latency-sensitive use cases
     */
    static ANTHROPIC_CLAUDE_HAIKU_4_5_V1_0 = new BedrockFoundationModel('anthropic.claude-haiku-4-5-20251001-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Sonnet 4.5 model, most intelligent in the Claude 4 series.
     * Demonstrates advancements in agent capabilities with enhanced performance in tool handling,
     * memory management, and context processing. Excels at autonomous long-horizon coding tasks.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Enhanced tool handling and memory management for long-running tasks
     * - Best for: Complex agents, coding, autonomous long-horizon tasks, research and analysis, cybersecurity and finance applications
     */
    static ANTHROPIC_CLAUDE_SONNET_4_5_V1_0 = new BedrockFoundationModel('anthropic.claude-sonnet-4-5-20250929-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4.6 model, the most intelligent model and the world's best model
     * for coding, enterprise agents, and professional work.
     * Supports both 200K and 1M context tokens (with the latter in preview).
     * Excels in agentic workflows, complex coding projects, and enterprise applications
     * requiring sophisticated reasoning.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Financial analysis, cybersecurity, computer use workflows, long-horizon development, multi-tool orchestration
     */
    static ANTHROPIC_CLAUDE_OPUS_4_6_V1 = new BedrockFoundationModel('anthropic.claude-opus-4-6-v1', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Sonnet 4.6 model.
     * Improved performance for coding, agentic workflows, and browser-based automation.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Coding, agentic workflows, browser-based automation, enterprise applications
     */
    static ANTHROPIC_CLAUDE_SONNET_4_6 = new BedrockFoundationModel('anthropic.claude-sonnet-4-6', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4.5 model, the flagship model released November 2025.
     * Excels at real-world programming tasks, scoring highest on SWE-bench Verified benchmarks.
     * Demonstrates superior performance in long-horizon, goal-directed agentic work with fewer dead-ends.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Software engineering, code migration, agentic workflows, financial modeling, deep research
     */
    static ANTHROPIC_CLAUDE_OPUS_4_5_V1_0 = new BedrockFoundationModel('anthropic.claude-opus-4-5-20251101-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4.1 model, most advanced for coding and agentic applications.
     * Excels at independently planning and executing complex development tasks end-to-end.
     * Drop-in replacement for Opus 4 with superior performance and precision.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Complex end-to-end development, agentic applications, research, advanced reasoning
     */
    static ANTHROPIC_CLAUDE_OPUS_4_1_V1_0 = new BedrockFoundationModel('anthropic.claude-opus-4-1-20250805-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4 model, next-generation frontier model.
     * High-performance model for advanced reasoning and complex multi-step tasks.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Advanced reasoning, complex workflows, enterprise applications
     */
    static ANTHROPIC_CLAUDE_OPUS_4_V1_0 = new BedrockFoundationModel('anthropic.claude-opus-4-20250514-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Sonnet 4 model, next-generation frontier model.
     * Advanced model with improved performance for production environments.
     * Balances quality, cost-effectiveness, and responsiveness.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Production applications, complex language tasks, balanced performance and cost
     */
    static ANTHROPIC_CLAUDE_SONNET_4_V1_0 = new BedrockFoundationModel('anthropic.claude-sonnet-4-20250514-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude 3.7 Sonnet model, latest in the Claude 3 series.
     * Advanced language model with enhanced capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Complex reasoning, analysis, and content generation
     */
    static ANTHROPIC_CLAUDE_3_7_SONNET_V1_0 = new BedrockFoundationModel('anthropic.claude-3-7-sonnet-20250219-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: false });
    /**
     * Anthropic's Claude 3.5 Sonnet V2 model, optimized for agent interactions.
     * Enhanced version with improved performance and capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Agent-based applications, complex dialogue
     */
    static ANTHROPIC_CLAUDE_3_5_SONNET_V2_0 = new BedrockFoundationModel('anthropic.claude-3-5-sonnet-20241022-v2:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude 3.5 Sonnet V1 model, balanced performance model.
     * Offers good balance between performance and efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: General language tasks, balanced performance
     */
    static ANTHROPIC_CLAUDE_3_5_SONNET_V1_0 = new BedrockFoundationModel('anthropic.claude-3-5-sonnet-20240620-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude 3.5 Haiku model, optimized for quick responses.
     * Lightweight model focused on speed and efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Fast responses, lightweight processing
     */
    static ANTHROPIC_CLAUDE_3_5_HAIKU_V1_0 = new BedrockFoundationModel('anthropic.claude-3-5-haiku-20241022-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus model, designed for advanced tasks.
     * High-performance model with extensive capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Optimized for agents
     * - Best for: Complex reasoning, research, and analysis
     */
    static ANTHROPIC_CLAUDE_OPUS_V1_0 = new BedrockFoundationModel('anthropic.claude-3-opus-20240229-v1:0', { supportsAgents: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Sonnet model, legacy version.
     * Balanced model for general-purpose tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Legacy model with EOL date
     * - Best for: General language tasks, standard applications
     */
    static ANTHROPIC_CLAUDE_SONNET_V1_0 = new BedrockFoundationModel('anthropic.claude-3-sonnet-20240229-v1:0', { supportsAgents: true, supportsCrossRegion: true, legacy: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Haiku model, optimized for efficiency.
     * Fast and efficient model for lightweight tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Quick responses, simple tasks
     */
    static ANTHROPIC_CLAUDE_HAIKU_V1_0 = new BedrockFoundationModel('anthropic.claude-3-haiku-20240307-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude V2.1 model, legacy version.
     * Improved version of Claude V2 with enhanced capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Legacy model with EOL date
     * - Optimized for agents
     * - Best for: General language tasks, legacy applications
     */
    static ANTHROPIC_CLAUDE_V2_1 = new BedrockFoundationModel('anthropic.claude-v2:1', {
        supportsAgents: true,
        legacy: true,
        optimizedForAgents: true,
    });
    /**
     * Anthropic's Claude V2 model, legacy version.
     * Original Claude V2 model with broad capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Legacy model with EOL date
     * - Optimized for agents
     * - Best for: General language tasks, legacy applications
     */
    static ANTHROPIC_CLAUDE_V2 = new BedrockFoundationModel('anthropic.claude-v2', {
        supportsAgents: true,
        legacy: true,
        optimizedForAgents: true,
    });
    /**
     * Anthropic's Claude Instant V1.2 model, legacy version.
     * Fast and efficient model optimized for quick responses.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Legacy model with EOL date
     * - Optimized for agents
     * - Best for: Quick responses, simple tasks, legacy applications
     */
    static ANTHROPIC_CLAUDE_INSTANT_V1_2 = new BedrockFoundationModel('anthropic.claude-instant-v1', {
        supportsAgents: true,
        legacy: true,
        optimizedForAgents: true,
    });
    /****************************************************************************
     *                            COHERE
     ***************************************************************************/
    /**
     * Cohere's English embedding model, optimized for English text embeddings.
     * Specialized for semantic understanding of English content.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 1024-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: English text embeddings, semantic search, content similarity
     */
    static COHERE_EMBED_ENGLISH_V3 = new BedrockFoundationModel('cohere.embed-english-v3', {
        supportsKnowledgeBase: true,
        vectorDimensions: 1024,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /**
     * Cohere's Multilingual embedding model, supporting multiple languages.
     * Enables semantic understanding across different languages.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 1024-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: Cross-lingual embeddings, multilingual semantic search
     */
    static COHERE_EMBED_MULTILINGUAL_V3 = new BedrockFoundationModel('cohere.embed-multilingual-v3', {
        supportsKnowledgeBase: true,
        vectorDimensions: 1024,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /****************************************************************************
     *                            DEEPSEEK
     ***************************************************************************/
    /**
     * Deepseek's R1 model, designed for general language understanding.
     * Balanced model for various language tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: General language tasks, content generation
     */
    static DEEPSEEK_R1_V1 = new BedrockFoundationModel('deepseek.r1-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /****************************************************************************
     *                            META
     ***************************************************************************/
    /**
     * Meta's Llama 3 1.8B Instruct model, compact instruction-following model.
     * Efficient model optimized for instruction-based tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Lightweight instruction processing, quick responses
     */
    static META_LLAMA_3_1_8B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-1-8b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3 70B Instruct model, large-scale instruction model.
     * High-capacity model for complex language understanding.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Complex instructions, advanced language tasks
     */
    static META_LLAMA_3_1_70B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-1-70b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3.2 11B Instruct model, mid-sized instruction model.
     * Balanced model for general instruction processing.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: General instruction tasks, balanced performance
     */
    static META_LLAMA_3_2_11B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-2-11b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3.2 3B Instruct model, compact efficient model.
     * Lightweight model for basic instruction processing.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Basic instructions, efficient processing
     */
    static META_LLAMA_3_2_3B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-2-3b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3.2 1B Instruct model, ultra-lightweight model.
     * Most compact model in the Llama 3.2 series.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Simple instructions, fastest response times
     */
    static META_LLAMA_3_2_1B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-2-1b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3.3 70B Instruct model, latest large-scale model.
     * Advanced model with enhanced capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Complex reasoning, advanced language tasks
     */
    static META_LLAMA_3_3_70B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-3-70b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 4 Maverick 17B Instruct model, innovative mid-sized model.
     * Specialized for creative and dynamic responses.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Creative tasks, innovative solutions
     */
    static META_LLAMA_4_MAVERICK_17B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama4-maverick-17b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 4 Scout 17B Instruct model, analytical mid-sized model.
     * Focused on precise and analytical responses.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Analytical tasks, precise responses
     */
    static META_LLAMA_4_SCOUT_17B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama4-scout-17b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /****************************************************************************
     *                            MISTRAL AI
     ***************************************************************************/
    /**
     * Mistral's 7B Instruct model, efficient instruction-following model.
     * Balanced performance for instruction processing.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Optimized for instruction tasks
     * - Best for: General instruction processing, balanced performance
     */
    static MISTRAL_7B_INSTRUCT_V0 = new BedrockFoundationModel('mistral.mistral-7b-instruct-v0:2', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Mixtral 8x7B Instruct model, mixture-of-experts architecture.
     * Advanced model combining multiple expert networks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Specialized expert networks
     * - Best for: Complex tasks, diverse language understanding
     */
    static MISTRAL_MIXTRAL_8X7B_INSTRUCT_V0 = new BedrockFoundationModel('mistral.mixtral-8x7b-instruct-v0:1', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Small 2402 model, compact efficient model.
     * Optimized for quick responses and efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Efficient processing
     * - Best for: Quick responses, basic language tasks
     */
    static MISTRAL_SMALL_2402_V1 = new BedrockFoundationModel('mistral.mistral-small-2402-v1:0', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Large 2402 model, high-capacity language model.
     * Advanced model for complex language understanding.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Enhanced language capabilities
     * - Best for: Complex reasoning, detailed analysis
     */
    static MISTRAL_LARGE_2402_V1 = new BedrockFoundationModel('mistral.mistral-large-2402-v1:0', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Large 2407 model, updated large-scale model.
     * Enhanced version with improved capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Advanced language processing
     * - Best for: Sophisticated language tasks, complex analysis
     */
    static MISTRAL_LARGE_2407_V1 = new BedrockFoundationModel('mistral.mistral-large-2407-v1:0', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Pixtral Large 2502 model, specialized large model.
     * Advanced model with cross-region support.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Advanced language tasks, distributed applications
     */
    static MISTRAL_PIXTRAL_LARGE_2502_V1 = new BedrockFoundationModel('mistral.pixtral-large-2502-v1:0', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: true,
    });
    /**
     * Creates a BedrockFoundationModel from a FoundationModelIdentifier.
     * Use this method when you have a model identifier from the CDK.
     * @param modelId - The foundation model identifier
     * @param props - Optional properties for the model
     * @returns A new BedrockFoundationModel instance
     */
    static fromCdkFoundationModelId(modelId, props = {}) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_BedrockFoundationModelProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.fromCdkFoundationModelId);
            }
            throw error;
        }
        return new BedrockFoundationModel(modelId.modelId, props);
    }
    /**
     * Creates a BedrockFoundationModel from a FoundationModel.
     * Use this method when you have a foundation model from the CDK.
     * @param modelId - The foundation model
     * @param props - Optional properties for the model
     * @returns A new BedrockFoundationModel instance
     */
    static fromCdkFoundationModel(modelId, props = {}) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_BedrockFoundationModelProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.fromCdkFoundationModel);
            }
            throw error;
        }
        return new BedrockFoundationModel(modelId.modelId, props);
    }
    /****************************************************************************
     *                            Constructor
     ***************************************************************************/
    /**
     * The unique identifier of the foundation model.
     */
    modelId;
    /**
     * The ARN of the foundation model.
     * Format: arn:${Partition}:bedrock:${Region}::foundation-model/${ResourceId}
     */
    modelArn;
    /**
     * The ARN used for invoking the model.
     * This is the same as modelArn for foundation models.
     */
    invokableArn;
    /**
     * Whether this model supports integration with Bedrock Agents.
     * When true, the model can be used with Bedrock Agents for automated task execution.
     */
    supportsAgents;
    /**
     * Whether this model supports cross-region inference.
     * When true, the model can be used with Cross-Region Inference Profiles.
     */
    supportsCrossRegion;
    /**
     * The dimensionality of the vector embeddings produced by this model.
     * Only applicable for embedding models.
     */
    vectorDimensions;
    /**
     * Whether this model supports integration with Bedrock Knowledge Base.
     * When true, the model can be used for knowledge base operations.
     */
    supportsKnowledgeBase;
    /**
     * The vector types supported by this model for embeddings.
     * Defines whether the model supports floating-point or binary vectors.
     */
    supportedVectorType;
    constructor(value, props = {}) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_BedrockFoundationModelProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, BedrockFoundationModel);
            }
            throw error;
        }
        this.modelId = value;
        this.modelArn = aws_cdk_lib_1.Arn.format({
            partition: aws_cdk_lib_1.Aws.PARTITION,
            service: 'bedrock',
            region: aws_cdk_lib_1.Aws.REGION,
            account: '',
            resource: 'foundation-model',
            resourceName: this.modelId,
            arnFormat: aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME,
        });
        this.invokableArn = this.modelArn;
        this.supportsCrossRegion = props.supportsCrossRegion ?? false;
        this.supportsAgents = props.supportsAgents ?? false;
        this.vectorDimensions = props.vectorDimensions;
        this.supportsKnowledgeBase = props.supportsKnowledgeBase ?? false;
        this.supportedVectorType = props.supportedVectorType;
    }
    toString() {
        return this.modelId;
    }
    /**
     * Returns the ARN of the foundation model in the following format:
     * `arn:${Partition}:bedrock:${Region}::foundation-model/${ResourceId}`
     */
    asArn() {
        return this.modelArn;
    }
    /**
     * Returns the IModel
     */
    asIModel() {
        return this;
    }
    /**
     * Gives the appropriate policies to invoke and use the Foundation Model in the stack region.
     * [disable-awslint:no-grants]
     */
    grantInvoke(grantee) {
        const grant = aws_iam_1.Grant.addToPrincipal({
            grantee: grantee,
            actions: ['bedrock:InvokeModel*', 'bedrock:GetFoundationModel'],
            resourceArns: [this.invokableArn],
        });
        return grant;
    }
    /**
     * Gives the appropriate policies to invoke and use the Foundation Model in all regions.
     * [disable-awslint:no-grants]
     */
    grantInvokeAllRegions(grantee) {
        const invokableArn = aws_cdk_lib_1.Arn.format({
            partition: aws_cdk_lib_1.Aws.PARTITION,
            service: 'bedrock',
            region: '*',
            account: '',
            resource: 'foundation-model',
            resourceName: this.modelId,
            arnFormat: aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME,
        });
        return aws_iam_1.Grant.addToPrincipal({
            grantee: grantee,
            actions: ['bedrock:InvokeModel*', 'bedrock:GetFoundationModel'],
            resourceArns: [invokableArn],
        });
    }
}
exports.BedrockFoundationModel = BedrockFoundationModel;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kZWxzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibW9kZWxzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCw2Q0FBa0Q7QUFHbEQsaURBQTRDO0FBRTVDOzs7OztHQUtHO0FBQ0gsSUFBWSxVQVNYO0FBVEQsV0FBWSxVQUFVO0lBQ3BCOztPQUVHO0lBQ0gsd0NBQTBCLENBQUE7SUFDMUI7O09BRUc7SUFDSCwrQkFBaUIsQ0FBQTtBQUNuQixDQUFDLEVBVFcsVUFBVSwwQkFBVixVQUFVLFFBU3JCO0FBa0ZEOzs7OztHQUtHO0FBQ0gsTUFBYSxzQkFBc0I7O0lBQ2pDOztpRkFFNkU7SUFFN0U7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsdUJBQXVCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDekUsMkJBQTJCLEVBQzNCO1FBQ0UsY0FBYyxFQUFFLElBQUk7S0FDckIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsc0JBQXNCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDeEUsMEJBQTBCLEVBQzFCO1FBQ0UsY0FBYyxFQUFFLElBQUk7S0FDckIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsc0JBQXNCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDeEUsMEJBQTBCLEVBQzFCO1FBQ0UsY0FBYyxFQUFFLElBQUk7S0FDckIsQ0FDRixDQUFDO0lBQ0Y7O2lGQUU2RTtJQUU3RTs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSw0QkFBNEIsR0FBRyxJQUFJLHNCQUFzQixDQUM5RSw4QkFBOEIsRUFDOUI7UUFDRSxjQUFjLEVBQUUsSUFBSTtLQUNyQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSx5QkFBeUIsR0FBRyxJQUFJLHNCQUFzQixDQUMzRSxnQ0FBZ0MsRUFDaEM7UUFDRSxjQUFjLEVBQUUsSUFBSTtLQUNyQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSxvQkFBb0IsR0FBRyxJQUFJLHNCQUFzQixDQUN0RSx3QkFBd0IsRUFDeEI7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO1FBQ3pCLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsbUJBQW1CLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQyx1QkFBdUIsRUFBRTtRQUMvRixjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO1FBQ3pCLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FBQyxDQUFDO0lBRUg7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsa0JBQWtCLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQyxzQkFBc0IsRUFBRTtRQUM3RixjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO1FBQ3pCLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FBQyxDQUFDO0lBRUg7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsc0JBQXNCLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQywwQkFBMEIsRUFBRTtRQUNyRyxjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO1FBQ3pCLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FBQyxDQUFDO0lBRUg7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsbUJBQW1CLEdBQUcsSUFBSSxzQkFBc0IsQ0FDckUsNEJBQTRCLEVBQzVCO1FBQ0UscUJBQXFCLEVBQUUsSUFBSTtRQUMzQixnQkFBZ0IsRUFBRSxJQUFJO1FBQ3RCLG1CQUFtQixFQUFFLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQztLQUNqRCxDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSx3QkFBd0IsR0FBRyxJQUFJLHNCQUFzQixDQUMxRSw4QkFBOEIsRUFDOUI7UUFDRSxxQkFBcUIsRUFBRSxJQUFJO1FBQzNCLGdCQUFnQixFQUFFLElBQUk7UUFDdEIsbUJBQW1CLEVBQUUsQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUM7S0FDcEUsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsdUJBQXVCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDekUsOEJBQThCLEVBQzlCO1FBQ0UscUJBQXFCLEVBQUUsSUFBSTtRQUMzQixnQkFBZ0IsRUFBRSxHQUFHO1FBQ3JCLG1CQUFtQixFQUFFLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDO0tBQ3BFLENBQ0YsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLHVCQUF1QixHQUFHLElBQUksc0JBQXNCLENBQ3pFLDhCQUE4QixFQUM5QjtRQUNFLHFCQUFxQixFQUFFLElBQUk7UUFDM0IsZ0JBQWdCLEVBQUUsR0FBRztRQUNyQixtQkFBbUIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQztLQUNwRSxDQUNGLENBQUM7SUFDRjs7aUZBRTZFO0lBRTdFOzs7Ozs7Ozs7T0FTRztJQUNJLE1BQU0sQ0FBVSwrQkFBK0IsR0FBRyxJQUFJLHNCQUFzQixDQUNqRiwwQ0FBMEMsRUFDMUMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FDOUUsQ0FBQztJQUVGOzs7Ozs7Ozs7OztPQVdHO0lBQ0ksTUFBTSxDQUFVLGdDQUFnQyxHQUFHLElBQUksc0JBQXNCLENBQ2xGLDJDQUEyQyxFQUMzQyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUM5RSxDQUFDO0lBRUY7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0ksTUFBTSxDQUFVLDRCQUE0QixHQUFHLElBQUksc0JBQXNCLENBQzlFLDhCQUE4QixFQUM5QixFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUM5RSxDQUFDO0lBRUY7Ozs7Ozs7OztPQVNHO0lBQ0ksTUFBTSxDQUFVLDJCQUEyQixHQUFHLElBQUksc0JBQXNCLENBQzdFLDZCQUE2QixFQUM3QixFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUM5RSxDQUFDO0lBRUY7Ozs7Ozs7Ozs7T0FVRztJQUNJLE1BQU0sQ0FBVSw4QkFBOEIsR0FBRyxJQUFJLHNCQUFzQixDQUNoRix5Q0FBeUMsRUFDekMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FDOUUsQ0FBQztJQUVGOzs7Ozs7Ozs7O09BVUc7SUFDSSxNQUFNLENBQVUsOEJBQThCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDaEYseUNBQXlDLEVBQ3pDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsNEJBQTRCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDOUUsdUNBQXVDLEVBQ3ZDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7OztPQVVHO0lBQ0ksTUFBTSxDQUFVLDhCQUE4QixHQUFHLElBQUksc0JBQXNCLENBQ2hGLHlDQUF5QyxFQUN6QyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUM5RSxDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsZ0NBQWdDLEdBQUcsSUFBSSxzQkFBc0IsQ0FDbEYsMkNBQTJDLEVBRTNDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsS0FBSyxFQUFFLENBQy9FLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsZ0NBQWdDLEdBQUcsSUFBSSxzQkFBc0IsQ0FDbEYsMkNBQTJDLEVBQzNDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsZ0NBQWdDLEdBQUcsSUFBSSxzQkFBc0IsQ0FDbEYsMkNBQTJDLEVBQzNDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsK0JBQStCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDakYsMENBQTBDLEVBQzFDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSwwQkFBMEIsR0FBRyxJQUFJLHNCQUFzQixDQUM1RSx1Q0FBdUMsRUFDdkMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUNuRCxDQUFDO0lBRUY7Ozs7Ozs7OztPQVNHO0lBQ0ksTUFBTSxDQUFVLDRCQUE0QixHQUFHLElBQUksc0JBQXNCLENBQzlFLHlDQUF5QyxFQUN6QyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzVGLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsMkJBQTJCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDN0Usd0NBQXdDLEVBQ3hDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUscUJBQXFCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDdkUsdUJBQXVCLEVBQ3ZCO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsTUFBTSxFQUFFLElBQUk7UUFDWixrQkFBa0IsRUFBRSxJQUFJO0tBQ3pCLENBQ0YsQ0FBQztJQUVGOzs7Ozs7Ozs7T0FTRztJQUNJLE1BQU0sQ0FBVSxtQkFBbUIsR0FBRyxJQUFJLHNCQUFzQixDQUFDLHFCQUFxQixFQUFFO1FBQzdGLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLE1BQU0sRUFBRSxJQUFJO1FBQ1osa0JBQWtCLEVBQUUsSUFBSTtLQUN6QixDQUFDLENBQUM7SUFFSDs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsNkJBQTZCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDL0UsNkJBQTZCLEVBQzdCO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsTUFBTSxFQUFFLElBQUk7UUFDWixrQkFBa0IsRUFBRSxJQUFJO0tBQ3pCLENBQ0YsQ0FBQztJQUVGOztpRkFFNkU7SUFFN0U7Ozs7Ozs7OztPQVNHO0lBQ0ksTUFBTSxDQUFVLHVCQUF1QixHQUFHLElBQUksc0JBQXNCLENBQ3pFLHlCQUF5QixFQUN6QjtRQUNFLHFCQUFxQixFQUFFLElBQUk7UUFDM0IsZ0JBQWdCLEVBQUUsSUFBSTtRQUN0QixtQkFBbUIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQztLQUNwRSxDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsNEJBQTRCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDOUUsOEJBQThCLEVBQzlCO1FBQ0UscUJBQXFCLEVBQUUsSUFBSTtRQUMzQixnQkFBZ0IsRUFBRSxJQUFJO1FBQ3RCLG1CQUFtQixFQUFFLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDO0tBQ3BFLENBQ0YsQ0FBQztJQUNGOztpRkFFNkU7SUFFN0U7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsY0FBYyxHQUFHLElBQUksc0JBQXNCLENBQUMsa0JBQWtCLEVBQUU7UUFDckYsY0FBYyxFQUFFLElBQUk7UUFDcEIsbUJBQW1CLEVBQUUsSUFBSTtLQUMxQixDQUFDLENBQUM7SUFFSDs7aUZBRTZFO0lBRTdFOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLDZCQUE2QixHQUFHLElBQUksc0JBQXNCLENBQy9FLGdDQUFnQyxFQUNoQztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLG1CQUFtQixFQUFFLElBQUk7S0FDMUIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsOEJBQThCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDaEYsaUNBQWlDLEVBQ2pDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsbUJBQW1CLEVBQUUsSUFBSTtLQUMxQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSw4QkFBOEIsR0FBRyxJQUFJLHNCQUFzQixDQUNoRixpQ0FBaUMsRUFDakM7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO0tBQzFCLENBQ0YsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLDZCQUE2QixHQUFHLElBQUksc0JBQXNCLENBQy9FLGdDQUFnQyxFQUNoQztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLG1CQUFtQixFQUFFLElBQUk7S0FDMUIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsNkJBQTZCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDL0UsZ0NBQWdDLEVBQ2hDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsbUJBQW1CLEVBQUUsSUFBSTtLQUMxQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSw4QkFBOEIsR0FBRyxJQUFJLHNCQUFzQixDQUNoRixpQ0FBaUMsRUFDakM7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO0tBQzFCLENBQ0YsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLHFDQUFxQyxHQUFHLElBQUksc0JBQXNCLENBQ3ZGLHdDQUF3QyxFQUN4QztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLG1CQUFtQixFQUFFLElBQUk7S0FDMUIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsa0NBQWtDLEdBQUcsSUFBSSxzQkFBc0IsQ0FDcEYscUNBQXFDLEVBQ3JDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsbUJBQW1CLEVBQUUsSUFBSTtLQUMxQixDQUNGLENBQUM7SUFDRjs7aUZBRTZFO0lBRTdFOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLHNCQUFzQixHQUFHLElBQUksc0JBQXNCLENBQ3hFLGtDQUFrQyxFQUNsQztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLGtCQUFrQixFQUFFLEtBQUs7UUFDekIsbUJBQW1CLEVBQUUsS0FBSztLQUMzQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSxnQ0FBZ0MsR0FBRyxJQUFJLHNCQUFzQixDQUNsRixvQ0FBb0MsRUFDcEM7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixrQkFBa0IsRUFBRSxLQUFLO1FBQ3pCLG1CQUFtQixFQUFFLEtBQUs7S0FDM0IsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUscUJBQXFCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDdkUsaUNBQWlDLEVBQ2pDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsa0JBQWtCLEVBQUUsS0FBSztRQUN6QixtQkFBbUIsRUFBRSxLQUFLO0tBQzNCLENBQ0YsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLHFCQUFxQixHQUFHLElBQUksc0JBQXNCLENBQ3ZFLGlDQUFpQyxFQUNqQztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLGtCQUFrQixFQUFFLEtBQUs7UUFDekIsbUJBQW1CLEVBQUUsS0FBSztLQUMzQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSxxQkFBcUIsR0FBRyxJQUFJLHNCQUFzQixDQUN2RSxpQ0FBaUMsRUFDakM7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixrQkFBa0IsRUFBRSxLQUFLO1FBQ3pCLG1CQUFtQixFQUFFLEtBQUs7S0FDM0IsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsNkJBQTZCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDL0UsaUNBQWlDLEVBQ2pDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsa0JBQWtCLEVBQUUsS0FBSztRQUN6QixtQkFBbUIsRUFBRSxJQUFJO0tBQzFCLENBQ0YsQ0FBQztJQUVGOzs7Ozs7T0FNRztJQUNJLE1BQU0sQ0FBQyx3QkFBd0IsQ0FDcEMsT0FBa0MsRUFDbEMsUUFBcUMsRUFBRTs7Ozs7Ozs7OztRQUV2QyxPQUFPLElBQUksc0JBQXNCLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztLQUMzRDtJQUNEOzs7Ozs7T0FNRztJQUNJLE1BQU0sQ0FBQyxzQkFBc0IsQ0FDbEMsT0FBd0IsRUFDeEIsUUFBcUMsRUFBRTs7Ozs7Ozs7OztRQUV2QyxPQUFPLElBQUksc0JBQXNCLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztLQUMzRDtJQUVEOztpRkFFNkU7SUFDN0U7O09BRUc7SUFDYSxPQUFPLENBQVM7SUFFaEM7OztPQUdHO0lBQ2EsUUFBUSxDQUFTO0lBRWpDOzs7T0FHRztJQUNhLFlBQVksQ0FBUztJQUVyQzs7O09BR0c7SUFDYSxjQUFjLENBQVU7SUFFeEM7OztPQUdHO0lBQ2EsbUJBQW1CLENBQVU7SUFFN0M7OztPQUdHO0lBQ2EsZ0JBQWdCLENBQVU7SUFFMUM7OztPQUdHO0lBQ2EscUJBQXFCLENBQVU7SUFFL0M7OztPQUdHO0lBQ2EsbUJBQW1CLENBQWdCO0lBQ25ELFlBQVksS0FBYSxFQUFFLFFBQXFDLEVBQUU7Ozs7OzsrQ0FsNEJ2RCxzQkFBc0I7Ozs7UUFtNEIvQixJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztRQUNyQixJQUFJLENBQUMsUUFBUSxHQUFHLGlCQUFHLENBQUMsTUFBTSxDQUFDO1lBQ3pCLFNBQVMsRUFBRSxpQkFBRyxDQUFDLFNBQVM7WUFDeEIsT0FBTyxFQUFFLFNBQVM7WUFDbEIsTUFBTSxFQUFFLGlCQUFHLENBQUMsTUFBTTtZQUNsQixPQUFPLEVBQUUsRUFBRTtZQUNYLFFBQVEsRUFBRSxrQkFBa0I7WUFDNUIsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPO1lBQzFCLFNBQVMsRUFBRSx1QkFBUyxDQUFDLG1CQUFtQjtTQUN6QyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDbEMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQyxtQkFBbUIsSUFBSSxLQUFLLENBQUM7UUFDOUQsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUMsY0FBYyxJQUFJLEtBQUssQ0FBQztRQUNwRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLGdCQUFnQixDQUFDO1FBQy9DLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxLQUFLLENBQUMscUJBQXFCLElBQUksS0FBSyxDQUFDO1FBQ2xFLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxLQUFLLENBQUMsbUJBQW1CLENBQUM7S0FDdEQ7SUFFRCxRQUFRO1FBQ04sT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDO0tBQ3JCO0lBRUQ7OztPQUdHO0lBQ0gsS0FBSztRQUNILE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQztLQUN0QjtJQUVEOztPQUVHO0lBQ0gsUUFBUTtRQUNOLE9BQU8sSUFBSSxDQUFDO0tBQ2I7SUFFRDs7O09BR0c7SUFDSSxXQUFXLENBQUMsT0FBbUI7UUFDcEMsTUFBTSxLQUFLLEdBQUcsZUFBSyxDQUFDLGNBQWMsQ0FBQztZQUNqQyxPQUFPLEVBQUUsT0FBTztZQUNoQixPQUFPLEVBQUUsQ0FBQyxzQkFBc0IsRUFBRSw0QkFBNEIsQ0FBQztZQUMvRCxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO1NBQ2xDLENBQUMsQ0FBQztRQUNILE9BQU8sS0FBSyxDQUFDO0tBQ2Q7SUFFRDs7O09BR0c7SUFDSSxxQkFBcUIsQ0FBQyxPQUFtQjtRQUM5QyxNQUFNLFlBQVksR0FBRyxpQkFBRyxDQUFDLE1BQU0sQ0FBQztZQUM5QixTQUFTLEVBQUUsaUJBQUcsQ0FBQyxTQUFTO1lBQ3hCLE9BQU8sRUFBRSxTQUFTO1lBQ2xCLE1BQU0sRUFBRSxHQUFHO1lBQ1gsT0FBTyxFQUFFLEVBQUU7WUFDWCxRQUFRLEVBQUUsa0JBQWtCO1lBQzVCLFlBQVksRUFBRSxJQUFJLENBQUMsT0FBTztZQUMxQixTQUFTLEVBQUUsdUJBQVMsQ0FBQyxtQkFBbUI7U0FDekMsQ0FBQyxDQUFDO1FBRUgsT0FBTyxlQUFLLENBQUMsY0FBYyxDQUFDO1lBQzFCLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLE9BQU8sRUFBRSxDQUFDLHNCQUFzQixFQUFFLDRCQUE0QixDQUFDO1lBQy9ELFlBQVksRUFBRSxDQUFDLFlBQVksQ0FBQztTQUM3QixDQUFDLENBQUM7S0FDSjs7QUF6OEJILHdEQTA4QkMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqICBDb3B5cmlnaHQgQW1hem9uLmNvbSwgSW5jLiBvciBpdHMgYWZmaWxpYXRlcy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiAgTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKS4gWW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZVxuICogIHdpdGggdGhlIExpY2Vuc2UuIEEgY29weSBvZiB0aGUgTGljZW5zZSBpcyBsb2NhdGVkIGF0XG4gKlxuICogICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiAgb3IgaW4gdGhlICdsaWNlbnNlJyBmaWxlIGFjY29tcGFueWluZyB0aGlzIGZpbGUuIFRoaXMgZmlsZSBpcyBkaXN0cmlidXRlZCBvbiBhbiAnQVMgSVMnIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVNcbiAqICBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBleHByZXNzIG9yIGltcGxpZWQuIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9uc1xuICogIGFuZCBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgeyBBcm4sIEFybkZvcm1hdCwgQXdzIH0gZnJvbSAnYXdzLWNkay1saWInO1xuaW1wb3J0IHR5cGUgeyBJTW9kZWwsIEZvdW5kYXRpb25Nb2RlbCwgRm91bmRhdGlvbk1vZGVsSWRlbnRpZmllciB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1iZWRyb2NrJztcbmltcG9ydCB0eXBlIHsgSUdyYW50YWJsZSB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0IHsgR3JhbnQgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcblxuLyoqXG4gKiBUaGUgZGF0YSB0eXBlIGZvciB0aGUgdmVjdG9ycyB3aGVuIHVzaW5nIGEgbW9kZWwgdG8gY29udmVydCB0ZXh0IGludG8gdmVjdG9yIGVtYmVkZGluZ3MuXG4gKiBUaGUgbW9kZWwgbXVzdCBzdXBwb3J0IHRoZSBzcGVjaWZpZWQgZGF0YSB0eXBlIGZvciB2ZWN0b3IgZW1iZWRkaW5ncy4gRmxvYXRpbmctcG9pbnQgKGZsb2F0MzIpXG4gKiBpcyB0aGUgZGVmYXVsdCBkYXRhIHR5cGUsIGFuZCBpcyBzdXBwb3J0ZWQgYnkgbW9zdCBtb2RlbHMgZm9yIHZlY3RvciBlbWJlZGRpbmdzLiBTZWUgU3VwcG9ydGVkXG4gKiBlbWJlZGRpbmdzIG1vZGVscyBmb3IgaW5mb3JtYXRpb24gb24gdGhlIGF2YWlsYWJsZSBtb2RlbHMgYW5kIHRoZWlyIHZlY3RvciBkYXRhIHR5cGVzLlxuICovXG5leHBvcnQgZW51bSBWZWN0b3JUeXBlIHtcbiAgLyoqXG4gICAqIGBGTE9BVElOR19QT0lOVGAgY29udmVydCB0aGUgZGF0YSB0byBmbG9hdGluZy1wb2ludCAoZmxvYXQzMikgdmVjdG9yIGVtYmVkZGluZ3MgKG1vcmUgcHJlY2lzZSwgYnV0IG1vcmUgY29zdGx5KS5cbiAgICovXG4gIEZMT0FUSU5HX1BPSU5UID0gJ0ZMT0FUMzInLFxuICAvKipcbiAgICogYEJJTkFSWWAgY29udmVydCB0aGUgZGF0YSB0byBiaW5hcnkgdmVjdG9yIGVtYmVkZGluZ3MgKGxlc3MgcHJlY2lzZSwgYnV0IGxlc3MgY29zdGx5KS5cbiAgICovXG4gIEJJTkFSWSA9ICdCSU5BUlknLFxufVxuXG4vKipcbiAqIFJlcHJlc2VudHMgYW4gQW1hem9uIEJlZHJvY2sgYWJzdHJhY3Rpb24gb24gd2hpY2ggeW91IGNhblxuICogcnVuIHRoZSBgSW52b2tlYCBBUEkuIFRoaXMgY2FuIGJlIGEgRm91bmRhdGlvbmFsIE1vZGVsLFxuICogYSBDdXN0b20gTW9kZWwsIG9yIGFuIEluZmVyZW5jZSBQcm9maWxlLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIElCZWRyb2NrSW52b2thYmxlIHtcbiAgLyoqXG4gICAqIFRoZSBBUk4gb2YgdGhlIEJlZHJvY2sgaW52b2thYmxlIGFic3RyYWN0aW9uLlxuICAgKi9cbiAgcmVhZG9ubHkgaW52b2thYmxlQXJuOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEdpdmVzIHRoZSBhcHByb3ByaWF0ZSBwb2xpY2llcyB0byBpbnZva2UgYW5kIHVzZSB0aGUgaW52b2thYmxlIGFic3RyYWN0aW9uLlxuICAgKi9cbiAgZ3JhbnRJbnZva2UoZ3JhbnRlZTogSUdyYW50YWJsZSk6IEdyYW50O1xufVxuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNvbmZpZ3VyaW5nIGEgQmVkcm9jayBGb3VuZGF0aW9uIE1vZGVsLlxuICogVGhlc2UgcHJvcGVydGllcyBkZWZpbmUgdGhlIG1vZGVsJ3MgY2FwYWJpbGl0aWVzIGFuZCBzdXBwb3J0ZWQgZmVhdHVyZXMuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbFByb3BzIHtcbiAgLyoqXG4gICAqIEJlZHJvY2sgQWdlbnRzIGNhbiB1c2UgdGhpcyBtb2RlbC5cbiAgICogV2hlbiB0cnVlLCB0aGUgbW9kZWwgY2FuIGJlIHVzZWQgd2l0aCBCZWRyb2NrIEFnZW50cyBmb3IgYXV0b21hdGVkIHRhc2sgZXhlY3V0aW9uLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIGZhbHNlXG4gICAqL1xuICByZWFkb25seSBzdXBwb3J0c0FnZW50cz86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIEN1cnJlbnRseSwgc29tZSBvZiB0aGUgb2ZmZXJlZCBtb2RlbHMgYXJlIG9wdGltaXplZCB3aXRoIHByb21wdHMvcGFyc2VycyBmaW5lLXR1bmVkIGZvciBpbnRlZ3JhdGluZyB3aXRoIHRoZSBhZ2VudHMgYXJjaGl0ZWN0dXJlLlxuICAgKiBXaGVuIHRydWUsIHRoZSBtb2RlbCBoYXMgYmVlbiBzcGVjaWZpY2FsbHkgb3B0aW1pemVkIGZvciBhZ2VudCBpbnRlcmFjdGlvbnMuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gZmFsc2VcbiAgICovXG4gIHJlYWRvbmx5IG9wdGltaXplZEZvckFnZW50cz86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9iZWRyb2NrL2xhdGVzdC91c2VyZ3VpZGUvbW9kZWwtbGlmZWN5Y2xlLmh0bWxcbiAgICogQSB2ZXJzaW9uIGlzIG1hcmtlZCBMZWdhY3kgd2hlbiB0aGVyZSBpcyBhIG1vcmUgcmVjZW50IHZlcnNpb24gd2hpY2ggcHJvdmlkZXMgc3VwZXJpb3IgcGVyZm9ybWFuY2UuXG4gICAqIEFtYXpvbiBCZWRyb2NrIHNldHMgYW4gRU9MIGRhdGUgZm9yIExlZ2FjeSB2ZXJzaW9ucy5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBmYWxzZVxuICAgKi9cbiAgcmVhZG9ubHkgbGVnYWN5PzogYm9vbGVhbjtcblxuICAvKipcbiAgICogQmVkcm9jayBLbm93bGVkZ2UgQmFzZSBjYW4gdXNlIHRoaXMgbW9kZWwuXG4gICAqIFdoZW4gdHJ1ZSwgdGhlIG1vZGVsIGNhbiBiZSB1c2VkIGZvciBrbm93bGVkZ2UgYmFzZSBvcGVyYXRpb25zLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIGZhbHNlXG4gICAqL1xuICByZWFkb25seSBzdXBwb3J0c0tub3dsZWRnZUJhc2U/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBDYW4gYmUgdXNlZCB3aXRoIGEgQ3Jvc3MtUmVnaW9uIEluZmVyZW5jZSBQcm9maWxlLlxuICAgKiBXaGVuIHRydWUsIHRoZSBtb2RlbCBzdXBwb3J0cyBpbmZlcmVuY2UgYWNyb3NzIGRpZmZlcmVudCBBV1MgcmVnaW9ucy5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBmYWxzZVxuICAgKi9cbiAgcmVhZG9ubHkgc3VwcG9ydHNDcm9zc1JlZ2lvbj86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIEVtYmVkZGluZyBtb2RlbHMgaGF2ZSBkaWZmZXJlbnQgdmVjdG9yIGRpbWVuc2lvbnMuXG4gICAqIE9ubHkgYXBwbGljYWJsZSBmb3IgZW1iZWRkaW5nIG1vZGVscy4gRGVmaW5lcyB0aGUgZGltZW5zaW9uYWxpdHkgb2YgdGhlIHZlY3RvciBlbWJlZGRpbmdzLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIHVuZGVmaW5lZFxuICAgKi9cbiAgcmVhZG9ubHkgdmVjdG9yRGltZW5zaW9ucz86IG51bWJlcjtcblxuICAvKipcbiAgICogRW1iZWRkaW5ncyBtb2RlbHMgaGF2ZSBkaWZmZXJlbnQgc3VwcG9ydGVkIHZlY3RvciB0eXBlcy5cbiAgICogRGVmaW5lcyB3aGV0aGVyIHRoZSBtb2RlbCBzdXBwb3J0cyBmbG9hdGluZy1wb2ludCBvciBiaW5hcnkgdmVjdG9ycy5cbiAgICpcbiAgICogQGRlZmF1bHQgLSB1bmRlZmluZWRcbiAgICovXG4gIHJlYWRvbmx5IHN1cHBvcnRlZFZlY3RvclR5cGU/OiBWZWN0b3JUeXBlW107XG59XG5cbi8qKlxuICogQmVkcm9jayBtb2RlbHMuXG4gKlxuICogSWYgeW91IG5lZWQgdG8gdXNlIGEgbW9kZWwgbmFtZSB0aGF0IGRvZXNuJ3QgZXhpc3QgYXMgYSBzdGF0aWMgbWVtYmVyLCB5b3VcbiAqIGNhbiBpbnN0YW50aWF0ZSBhIGBCZWRyb2NrRm91bmRhdGlvbk1vZGVsYCBvYmplY3QsIGUuZzogYG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKCdteS1tb2RlbCcpYC5cbiAqL1xuZXhwb3J0IGNsYXNzIEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwgaW1wbGVtZW50cyBJQmVkcm9ja0ludm9rYWJsZSB7XG4gIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFJMjFcbiAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cblxuICAvKipcbiAgICogQUkyMSdzIEphbWJhIDEuNSBMYXJnZSBtb2RlbCBvcHRpbWl6ZWQgZm9yIHRleHQgZ2VuZXJhdGlvbiB0YXNrcy5cbiAgICogU3VpdGFibGUgZm9yIGNvbXBsZXggbGFuZ3VhZ2UgdW5kZXJzdGFuZGluZyBhbmQgZ2VuZXJhdGlvbiB0YXNrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBPcHRpbWl6ZWQgZm9yIG5hdHVyYWwgbGFuZ3VhZ2UgcHJvY2Vzc2luZ1xuICAgKiAtIEJlc3QgZm9yOiBDb250ZW50IGdlbmVyYXRpb24sIHN1bW1hcml6YXRpb24sIGFuZCBjb21wbGV4IHRleHQgYW5hbHlzaXNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQUkyMV9KQU1CQV8xXzVfTEFSR0VfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYWkyMS5qYW1iYS0xLTUtbGFyZ2UtdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogQUkyMSdzIEphbWJhIDEuNSBNaW5pIG1vZGVsLCBhIGxpZ2h0ZXIgdmVyc2lvbiBvcHRpbWl6ZWQgZm9yIGZhc3RlciBwcm9jZXNzaW5nLlxuICAgKiBCYWxhbmNlcyBwZXJmb3JtYW5jZSB3aXRoIGVmZmljaWVuY3kgZm9yIGdlbmVyYWwgdGV4dCB0YXNrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBGYXN0ZXIgcmVzcG9uc2UgdGltZXMgY29tcGFyZWQgdG8gbGFyZ2VyIG1vZGVsc1xuICAgKiAtIEJlc3QgZm9yOiBRdWljayB0ZXh0IHByb2Nlc3NpbmcsIGJhc2ljIGNvbnRlbnQgZ2VuZXJhdGlvblxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBSTIxX0pBTUJBXzFfNV9NSU5JX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FpMjEuamFtYmEtMS01LW1pbmktdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogQUkyMSdzIEphbWJhIEluc3RydWN0IG1vZGVsLCBzcGVjaWZpY2FsbHkgZGVzaWduZWQgZm9yIGluc3RydWN0aW9uLWZvbGxvd2luZyB0YXNrcy5cbiAgICogT3B0aW1pemVkIGZvciB1bmRlcnN0YW5kaW5nIGFuZCBleGVjdXRpbmcgc3BlY2lmaWMgaW5zdHJ1Y3Rpb25zLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIEVuaGFuY2VkIGluc3RydWN0aW9uIHVuZGVyc3RhbmRpbmdcbiAgICogLSBCZXN0IGZvcjogVGFzay1zcGVjaWZpYyBpbnN0cnVjdGlvbnMsIGNvbW1hbmQgcHJvY2Vzc2luZ1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBSTIxX0pBTUJBX0lOU1RSVUNUX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FpMjEuamFtYmEtaW5zdHJ1Y3QtdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgfSxcbiAgKTtcbiAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgQU1BWk9OXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbiAgLyoqXG4gICAqIEFtYXpvbidzIFRpdGFuIFRleHQgRXhwcmVzcyBtb2RlbCwgb3B0aW1pemVkIGZvciBmYXN0IHRleHQgZ2VuZXJhdGlvbi5cbiAgICogUHJvdmlkZXMgcXVpY2sgcmVzcG9uc2VzIHdoaWxlIG1haW50YWluaW5nIGdvb2QgcXVhbGl0eSBvdXRwdXQuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gRmFzdCByZXNwb25zZSB0aW1lc1xuICAgKiAtIEJlc3QgZm9yOiBSZWFsLXRpbWUgYXBwbGljYXRpb25zLCBjaGF0Ym90cywgcXVpY2sgY29udGVudCBnZW5lcmF0aW9uXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFNQVpPTl9USVRBTl9URVhUX0VYUFJFU1NfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW1hem9uLnRpdGFuLXRleHQtZXhwcmVzcy12MScsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW1hem9uJ3MgVGl0YW4gVGV4dCBQcmVtaWVyIG1vZGVsLCBkZXNpZ25lZCBmb3IgaGlnaC1xdWFsaXR5IHRleHQgZ2VuZXJhdGlvbi5cbiAgICogT2ZmZXJzIGVuaGFuY2VkIGNhcGFiaWxpdGllcyBmb3IgY29tcGxleCBsYW5ndWFnZSB0YXNrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBBZHZhbmNlZCBsYW5ndWFnZSB1bmRlcnN0YW5kaW5nXG4gICAqIC0gQmVzdCBmb3I6IENvbXBsZXggY29udGVudCBnZW5lcmF0aW9uLCBkZXRhaWxlZCBhbmFseXNpc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTUFaT05fVElUQU5fUFJFTUlFUl9WMV8wID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FtYXpvbi50aXRhbi10ZXh0LXByZW1pZXItdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW1hem9uJ3MgTm92YSBNaWNybyBtb2RlbCwgYSBsaWdodHdlaWdodCBtb2RlbCBvcHRpbWl6ZWQgZm9yIGVmZmljaWVuY3kuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBPcHRpbWl6ZWQgZm9yIGFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBRdWljayBwcm9jZXNzaW5nIHRhc2tzLCBiYXNpYyBsYW5ndWFnZSB1bmRlcnN0YW5kaW5nXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFNQVpPTl9OT1ZBX01JQ1JPX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FtYXpvbi5ub3ZhLW1pY3JvLXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgICAgIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbWF6b24ncyBOb3ZhIExpdGUgbW9kZWwsIGJhbGFuY2luZyBwZXJmb3JtYW5jZSB3aXRoIGVmZmljaWVuY3kuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBPcHRpbWl6ZWQgZm9yIGFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBHZW5lcmFsLXB1cnBvc2UgbGFuZ3VhZ2UgdGFza3MsIG1vZGVyYXRlIGNvbXBsZXhpdHlcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU1BWk9OX05PVkFfTElURV9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKCdhbWF6b24ubm92YS1saXRlLXYxOjAnLCB7XG4gICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgICBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUsXG4gIH0pO1xuXG4gIC8qKlxuICAgKiBBbWF6b24ncyBOb3ZhIFBybyBtb2RlbCwgb2ZmZXJpbmcgYWR2YW5jZWQgY2FwYWJpbGl0aWVzIGZvciBjb21wbGV4IHRhc2tzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gT3B0aW1pemVkIGZvciBhZ2VudHNcbiAgICogLSBCZXN0IGZvcjogQ29tcGxleCBsYW5ndWFnZSB0YXNrcywgcHJvZmVzc2lvbmFsIGFwcGxpY2F0aW9uc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTUFaT05fTk9WQV9QUk9fVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCgnYW1hem9uLm5vdmEtcHJvLXYxOjAnLCB7XG4gICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgICBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUsXG4gIH0pO1xuXG4gIC8qKlxuICAgKiBBbWF6b24ncyBOb3ZhIFByZW1pZXIgbW9kZWwsIHRoZSBtb3N0IGFkdmFuY2VkIGluIHRoZSBOb3ZhIHNlcmllcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IEhpZ2gtZW5kIGFwcGxpY2F0aW9ucywgY29tcGxleCBhbmFseXNpcywgcHJlbWl1bSBwZXJmb3JtYW5jZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTUFaT05fTk9WQV9QUkVNSUVSX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoJ2FtYXpvbi5ub3ZhLXByZW1pZXItdjE6MCcsIHtcbiAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSxcbiAgfSk7XG5cbiAgLyoqXG4gICAqIEFtYXpvbidzIFRpdGFuIEVtYmVkIFRleHQgVjEgbW9kZWwgZm9yIHRleHQgZW1iZWRkaW5ncy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgS25vd2xlZGdlIEJhc2UgaW50ZWdyYXRpb25cbiAgICogLSAxNTM2LWRpbWVuc2lvbmFsIHZlY3RvcnNcbiAgICogLSBGbG9hdGluZy1wb2ludCB2ZWN0b3IgdHlwZVxuICAgKiAtIEJlc3QgZm9yOiBUZXh0IGVtYmVkZGluZ3MsIHNlbWFudGljIHNlYXJjaCwgZG9jdW1lbnQgc2ltaWxhcml0eVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBUSVRBTl9FTUJFRF9URVhUX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FtYXpvbi50aXRhbi1lbWJlZC10ZXh0LXYxJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0tub3dsZWRnZUJhc2U6IHRydWUsXG4gICAgICB2ZWN0b3JEaW1lbnNpb25zOiAxNTM2LFxuICAgICAgc3VwcG9ydGVkVmVjdG9yVHlwZTogW1ZlY3RvclR5cGUuRkxPQVRJTkdfUE9JTlRdLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFtYXpvbidzIFRpdGFuIEVtYmVkIFRleHQgVjIgbW9kZWwgd2l0aCAxMDI0LWRpbWVuc2lvbmFsIHZlY3RvcnMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEtub3dsZWRnZSBCYXNlIGludGVncmF0aW9uXG4gICAqIC0gMTAyNC1kaW1lbnNpb25hbCB2ZWN0b3JzXG4gICAqIC0gU3VwcG9ydHMgYm90aCBmbG9hdGluZy1wb2ludCBhbmQgYmluYXJ5IHZlY3RvcnNcbiAgICogLSBCZXN0IGZvcjogSGlnaC1kaW1lbnNpb25hbCBlbWJlZGRpbmdzLCBhZHZhbmNlZCBzZW1hbnRpYyBzZWFyY2hcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgVElUQU5fRU1CRURfVEVYVF9WMl8xMDI0ID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FtYXpvbi50aXRhbi1lbWJlZC10ZXh0LXYyOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzS25vd2xlZGdlQmFzZTogdHJ1ZSxcbiAgICAgIHZlY3RvckRpbWVuc2lvbnM6IDEwMjQsXG4gICAgICBzdXBwb3J0ZWRWZWN0b3JUeXBlOiBbVmVjdG9yVHlwZS5GTE9BVElOR19QT0lOVCwgVmVjdG9yVHlwZS5CSU5BUlldLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFtYXpvbidzIFRpdGFuIEVtYmVkIFRleHQgVjIgbW9kZWwgd2l0aCA1MTItZGltZW5zaW9uYWwgdmVjdG9ycy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgS25vd2xlZGdlIEJhc2UgaW50ZWdyYXRpb25cbiAgICogLSA1MTItZGltZW5zaW9uYWwgdmVjdG9yc1xuICAgKiAtIFN1cHBvcnRzIGJvdGggZmxvYXRpbmctcG9pbnQgYW5kIGJpbmFyeSB2ZWN0b3JzXG4gICAqIC0gQmVzdCBmb3I6IEJhbGFuY2VkIHBlcmZvcm1hbmNlIGFuZCBkaW1lbnNpb25hbGl0eVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBUSVRBTl9FTUJFRF9URVhUX1YyXzUxMiA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbWF6b24udGl0YW4tZW1iZWQtdGV4dC12MjowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0tub3dsZWRnZUJhc2U6IHRydWUsXG4gICAgICB2ZWN0b3JEaW1lbnNpb25zOiA1MTIsXG4gICAgICBzdXBwb3J0ZWRWZWN0b3JUeXBlOiBbVmVjdG9yVHlwZS5GTE9BVElOR19QT0lOVCwgVmVjdG9yVHlwZS5CSU5BUlldLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFtYXpvbidzIFRpdGFuIEVtYmVkIFRleHQgVjIgbW9kZWwgd2l0aCAyNTYtZGltZW5zaW9uYWwgdmVjdG9ycy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgS25vd2xlZGdlIEJhc2UgaW50ZWdyYXRpb25cbiAgICogLSAyNTYtZGltZW5zaW9uYWwgdmVjdG9yc1xuICAgKiAtIFN1cHBvcnRzIGJvdGggZmxvYXRpbmctcG9pbnQgYW5kIGJpbmFyeSB2ZWN0b3JzXG4gICAqIC0gQmVzdCBmb3I6IEVmZmljaWVudCBlbWJlZGRpbmdzIHdpdGggbG93ZXIgZGltZW5zaW9uYWxpdHlcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgVElUQU5fRU1CRURfVEVYVF9WMl8yNTYgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW1hem9uLnRpdGFuLWVtYmVkLXRleHQtdjI6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNLbm93bGVkZ2VCYXNlOiB0cnVlLFxuICAgICAgdmVjdG9yRGltZW5zaW9uczogMjU2LFxuICAgICAgc3VwcG9ydGVkVmVjdG9yVHlwZTogW1ZlY3RvclR5cGUuRkxPQVRJTkdfUE9JTlQsIFZlY3RvclR5cGUuQklOQVJZXSxcbiAgICB9LFxuICApO1xuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBTlRIUk9QSUNcbiAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIEhhaWt1IDQuNSBtb2RlbCwgbW9zdCBjb3N0LWVmZmljaWVudCBhbmQgZmFzdGVzdC5cbiAgICogRGVsaXZlcnMgbmVhci1mcm9udGllciBwZXJmb3JtYW5jZSB3aXRoIHN1YnN0YW50aWFsbHkgbG93ZXIgY29zdCBhbmQgZmFzdGVyIHNwZWVkcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgdmlzaW9uIChJbWFnZSBpbnB1dCBtb2RhbGl0eSlcbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IExhcmdlLXNjYWxlIGRlcGxveW1lbnRzLCBidWRnZXQtY29uc2Npb3VzIGFwcGxpY2F0aW9ucywgcmVhbC10aW1lIGN1c3RvbWVyIHNlcnZpY2UsIGxhdGVuY3ktc2Vuc2l0aXZlIHVzZSBjYXNlc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX0hBSUtVXzRfNV9WMV8wID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtaGFpa3UtNC01LTIwMjUxMDAxLXYxOjAnLFxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgU29ubmV0IDQuNSBtb2RlbCwgbW9zdCBpbnRlbGxpZ2VudCBpbiB0aGUgQ2xhdWRlIDQgc2VyaWVzLlxuICAgKiBEZW1vbnN0cmF0ZXMgYWR2YW5jZW1lbnRzIGluIGFnZW50IGNhcGFiaWxpdGllcyB3aXRoIGVuaGFuY2VkIHBlcmZvcm1hbmNlIGluIHRvb2wgaGFuZGxpbmcsXG4gICAqIG1lbW9yeSBtYW5hZ2VtZW50LCBhbmQgY29udGV4dCBwcm9jZXNzaW5nLiBFeGNlbHMgYXQgYXV0b25vbW91cyBsb25nLWhvcml6b24gY29kaW5nIHRhc2tzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyB2aXNpb24gKEltYWdlIGlucHV0IG1vZGFsaXR5KVxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHNcbiAgICogLSBFbmhhbmNlZCB0b29sIGhhbmRsaW5nIGFuZCBtZW1vcnkgbWFuYWdlbWVudCBmb3IgbG9uZy1ydW5uaW5nIHRhc2tzXG4gICAqIC0gQmVzdCBmb3I6IENvbXBsZXggYWdlbnRzLCBjb2RpbmcsIGF1dG9ub21vdXMgbG9uZy1ob3Jpem9uIHRhc2tzLCByZXNlYXJjaCBhbmQgYW5hbHlzaXMsIGN5YmVyc2VjdXJpdHkgYW5kIGZpbmFuY2UgYXBwbGljYXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfU09OTkVUXzRfNV9WMV8wID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtc29ubmV0LTQtNS0yMDI1MDkyOS12MTowJyxcbiAgICB7IHN1cHBvcnRzQWdlbnRzOiB0cnVlLCBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLCBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIE9wdXMgNC42IG1vZGVsLCB0aGUgbW9zdCBpbnRlbGxpZ2VudCBtb2RlbCBhbmQgdGhlIHdvcmxkJ3MgYmVzdCBtb2RlbFxuICAgKiBmb3IgY29kaW5nLCBlbnRlcnByaXNlIGFnZW50cywgYW5kIHByb2Zlc3Npb25hbCB3b3JrLlxuICAgKiBTdXBwb3J0cyBib3RoIDIwMEsgYW5kIDFNIGNvbnRleHQgdG9rZW5zICh3aXRoIHRoZSBsYXR0ZXIgaW4gcHJldmlldykuXG4gICAqIEV4Y2VscyBpbiBhZ2VudGljIHdvcmtmbG93cywgY29tcGxleCBjb2RpbmcgcHJvamVjdHMsIGFuZCBlbnRlcnByaXNlIGFwcGxpY2F0aW9uc1xuICAgKiByZXF1aXJpbmcgc29waGlzdGljYXRlZCByZWFzb25pbmcuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIHZpc2lvbiAoSW1hZ2UgaW5wdXQgbW9kYWxpdHkpXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBGaW5hbmNpYWwgYW5hbHlzaXMsIGN5YmVyc2VjdXJpdHksIGNvbXB1dGVyIHVzZSB3b3JrZmxvd3MsIGxvbmctaG9yaXpvbiBkZXZlbG9wbWVudCwgbXVsdGktdG9vbCBvcmNoZXN0cmF0aW9uXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfT1BVU180XzZfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1vcHVzLTQtNi12MScsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBTb25uZXQgNC42IG1vZGVsLlxuICAgKiBJbXByb3ZlZCBwZXJmb3JtYW5jZSBmb3IgY29kaW5nLCBhZ2VudGljIHdvcmtmbG93cywgYW5kIGJyb3dzZXItYmFzZWQgYXV0b21hdGlvbi5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgdmlzaW9uIChJbWFnZSBpbnB1dCBtb2RhbGl0eSlcbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IENvZGluZywgYWdlbnRpYyB3b3JrZmxvd3MsIGJyb3dzZXItYmFzZWQgYXV0b21hdGlvbiwgZW50ZXJwcmlzZSBhcHBsaWNhdGlvbnNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV9TT05ORVRfNF82ID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtc29ubmV0LTQtNicsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBPcHVzIDQuNSBtb2RlbCwgdGhlIGZsYWdzaGlwIG1vZGVsIHJlbGVhc2VkIE5vdmVtYmVyIDIwMjUuXG4gICAqIEV4Y2VscyBhdCByZWFsLXdvcmxkIHByb2dyYW1taW5nIHRhc2tzLCBzY29yaW5nIGhpZ2hlc3Qgb24gU1dFLWJlbmNoIFZlcmlmaWVkIGJlbmNobWFya3MuXG4gICAqIERlbW9uc3RyYXRlcyBzdXBlcmlvciBwZXJmb3JtYW5jZSBpbiBsb25nLWhvcml6b24sIGdvYWwtZGlyZWN0ZWQgYWdlbnRpYyB3b3JrIHdpdGggZmV3ZXIgZGVhZC1lbmRzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyB2aXNpb24gKEltYWdlIGlucHV0IG1vZGFsaXR5KVxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHNcbiAgICogLSBCZXN0IGZvcjogU29mdHdhcmUgZW5naW5lZXJpbmcsIGNvZGUgbWlncmF0aW9uLCBhZ2VudGljIHdvcmtmbG93cywgZmluYW5jaWFsIG1vZGVsaW5nLCBkZWVwIHJlc2VhcmNoXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfT1BVU180XzVfVjFfMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbnRocm9waWMuY2xhdWRlLW9wdXMtNC01LTIwMjUxMTAxLXYxOjAnLFxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgT3B1cyA0LjEgbW9kZWwsIG1vc3QgYWR2YW5jZWQgZm9yIGNvZGluZyBhbmQgYWdlbnRpYyBhcHBsaWNhdGlvbnMuXG4gICAqIEV4Y2VscyBhdCBpbmRlcGVuZGVudGx5IHBsYW5uaW5nIGFuZCBleGVjdXRpbmcgY29tcGxleCBkZXZlbG9wbWVudCB0YXNrcyBlbmQtdG8tZW5kLlxuICAgKiBEcm9wLWluIHJlcGxhY2VtZW50IGZvciBPcHVzIDQgd2l0aCBzdXBlcmlvciBwZXJmb3JtYW5jZSBhbmQgcHJlY2lzaW9uLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyB2aXNpb24gKEltYWdlIGlucHV0IG1vZGFsaXR5KVxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHNcbiAgICogLSBCZXN0IGZvcjogQ29tcGxleCBlbmQtdG8tZW5kIGRldmVsb3BtZW50LCBhZ2VudGljIGFwcGxpY2F0aW9ucywgcmVzZWFyY2gsIGFkdmFuY2VkIHJlYXNvbmluZ1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX09QVVNfNF8xX1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1vcHVzLTQtMS0yMDI1MDgwNS12MTowJyxcbiAgICB7IHN1cHBvcnRzQWdlbnRzOiB0cnVlLCBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLCBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIE9wdXMgNCBtb2RlbCwgbmV4dC1nZW5lcmF0aW9uIGZyb250aWVyIG1vZGVsLlxuICAgKiBIaWdoLXBlcmZvcm1hbmNlIG1vZGVsIGZvciBhZHZhbmNlZCByZWFzb25pbmcgYW5kIGNvbXBsZXggbXVsdGktc3RlcCB0YXNrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgdmlzaW9uIChJbWFnZSBpbnB1dCBtb2RhbGl0eSlcbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IEFkdmFuY2VkIHJlYXNvbmluZywgY29tcGxleCB3b3JrZmxvd3MsIGVudGVycHJpc2UgYXBwbGljYXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfT1BVU180X1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1vcHVzLTQtMjAyNTA1MTQtdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBTb25uZXQgNCBtb2RlbCwgbmV4dC1nZW5lcmF0aW9uIGZyb250aWVyIG1vZGVsLlxuICAgKiBBZHZhbmNlZCBtb2RlbCB3aXRoIGltcHJvdmVkIHBlcmZvcm1hbmNlIGZvciBwcm9kdWN0aW9uIGVudmlyb25tZW50cy5cbiAgICogQmFsYW5jZXMgcXVhbGl0eSwgY29zdC1lZmZlY3RpdmVuZXNzLCBhbmQgcmVzcG9uc2l2ZW5lc3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIHZpc2lvbiAoSW1hZ2UgaW5wdXQgbW9kYWxpdHkpXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBQcm9kdWN0aW9uIGFwcGxpY2F0aW9ucywgY29tcGxleCBsYW5ndWFnZSB0YXNrcywgYmFsYW5jZWQgcGVyZm9ybWFuY2UgYW5kIGNvc3RcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV9TT05ORVRfNF9WMV8wID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtc29ubmV0LTQtMjAyNTA1MTQtdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSAzLjcgU29ubmV0IG1vZGVsLCBsYXRlc3QgaW4gdGhlIENsYXVkZSAzIHNlcmllcy5cbiAgICogQWR2YW5jZWQgbGFuZ3VhZ2UgbW9kZWwgd2l0aCBlbmhhbmNlZCBjYXBhYmlsaXRpZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogQ29tcGxleCByZWFzb25pbmcsIGFuYWx5c2lzLCBhbmQgY29udGVudCBnZW5lcmF0aW9uXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfM183X1NPTk5FVF9WMV8wID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtMy03LXNvbm5ldC0yMDI1MDIxOS12MTowJyxcblxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsIG9wdGltaXplZEZvckFnZW50czogZmFsc2UgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIDMuNSBTb25uZXQgVjIgbW9kZWwsIG9wdGltaXplZCBmb3IgYWdlbnQgaW50ZXJhY3Rpb25zLlxuICAgKiBFbmhhbmNlZCB2ZXJzaW9uIHdpdGggaW1wcm92ZWQgcGVyZm9ybWFuY2UgYW5kIGNhcGFiaWxpdGllcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IEFnZW50LWJhc2VkIGFwcGxpY2F0aW9ucywgY29tcGxleCBkaWFsb2d1ZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFXzNfNV9TT05ORVRfVjJfMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbnRocm9waWMuY2xhdWRlLTMtNS1zb25uZXQtMjAyNDEwMjItdjI6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSAzLjUgU29ubmV0IFYxIG1vZGVsLCBiYWxhbmNlZCBwZXJmb3JtYW5jZSBtb2RlbC5cbiAgICogT2ZmZXJzIGdvb2QgYmFsYW5jZSBiZXR3ZWVuIHBlcmZvcm1hbmNlIGFuZCBlZmZpY2llbmN5LlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gT3B0aW1pemVkIGZvciBhZ2VudHNcbiAgICogLSBCZXN0IGZvcjogR2VuZXJhbCBsYW5ndWFnZSB0YXNrcywgYmFsYW5jZWQgcGVyZm9ybWFuY2VcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV8zXzVfU09OTkVUX1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS0zLTUtc29ubmV0LTIwMjQwNjIwLXYxOjAnLFxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgMy41IEhhaWt1IG1vZGVsLCBvcHRpbWl6ZWQgZm9yIHF1aWNrIHJlc3BvbnNlcy5cbiAgICogTGlnaHR3ZWlnaHQgbW9kZWwgZm9jdXNlZCBvbiBzcGVlZCBhbmQgZWZmaWNpZW5jeS5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IEZhc3QgcmVzcG9uc2VzLCBsaWdodHdlaWdodCBwcm9jZXNzaW5nXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfM181X0hBSUtVX1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS0zLTUtaGFpa3UtMjAyNDEwMjItdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBPcHVzIG1vZGVsLCBkZXNpZ25lZCBmb3IgYWR2YW5jZWQgdGFza3MuXG4gICAqIEhpZ2gtcGVyZm9ybWFuY2UgbW9kZWwgd2l0aCBleHRlbnNpdmUgY2FwYWJpbGl0aWVzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IENvbXBsZXggcmVhc29uaW5nLCByZXNlYXJjaCwgYW5kIGFuYWx5c2lzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfT1BVU19WMV8wID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtMy1vcHVzLTIwMjQwMjI5LXYxOjAnLFxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgU29ubmV0IG1vZGVsLCBsZWdhY3kgdmVyc2lvbi5cbiAgICogQmFsYW5jZWQgbW9kZWwgZm9yIGdlbmVyYWwtcHVycG9zZSB0YXNrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIExlZ2FjeSBtb2RlbCB3aXRoIEVPTCBkYXRlXG4gICAqIC0gQmVzdCBmb3I6IEdlbmVyYWwgbGFuZ3VhZ2UgdGFza3MsIHN0YW5kYXJkIGFwcGxpY2F0aW9uc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX1NPTk5FVF9WMV8wID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtMy1zb25uZXQtMjAyNDAyMjktdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgbGVnYWN5OiB0cnVlLCBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIEhhaWt1IG1vZGVsLCBvcHRpbWl6ZWQgZm9yIGVmZmljaWVuY3kuXG4gICAqIEZhc3QgYW5kIGVmZmljaWVudCBtb2RlbCBmb3IgbGlnaHR3ZWlnaHQgdGFza3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBPcHRpbWl6ZWQgZm9yIGFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBRdWljayByZXNwb25zZXMsIHNpbXBsZSB0YXNrc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX0hBSUtVX1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS0zLWhhaWt1LTIwMjQwMzA3LXYxOjAnLFxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgVjIuMSBtb2RlbCwgbGVnYWN5IHZlcnNpb24uXG4gICAqIEltcHJvdmVkIHZlcnNpb24gb2YgQ2xhdWRlIFYyIHdpdGggZW5oYW5jZWQgY2FwYWJpbGl0aWVzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIExlZ2FjeSBtb2RlbCB3aXRoIEVPTCBkYXRlXG4gICAqIC0gT3B0aW1pemVkIGZvciBhZ2VudHNcbiAgICogLSBCZXN0IGZvcjogR2VuZXJhbCBsYW5ndWFnZSB0YXNrcywgbGVnYWN5IGFwcGxpY2F0aW9uc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX1YyXzEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS12MjoxJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIGxlZ2FjeTogdHJ1ZSxcbiAgICAgIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgVjIgbW9kZWwsIGxlZ2FjeSB2ZXJzaW9uLlxuICAgKiBPcmlnaW5hbCBDbGF1ZGUgVjIgbW9kZWwgd2l0aCBicm9hZCBjYXBhYmlsaXRpZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gTGVnYWN5IG1vZGVsIHdpdGggRU9MIGRhdGVcbiAgICogLSBPcHRpbWl6ZWQgZm9yIGFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBHZW5lcmFsIGxhbmd1YWdlIHRhc2tzLCBsZWdhY3kgYXBwbGljYXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfVjIgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCgnYW50aHJvcGljLmNsYXVkZS12MicsIHtcbiAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICBsZWdhY3k6IHRydWUsXG4gICAgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlLFxuICB9KTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIEluc3RhbnQgVjEuMiBtb2RlbCwgbGVnYWN5IHZlcnNpb24uXG4gICAqIEZhc3QgYW5kIGVmZmljaWVudCBtb2RlbCBvcHRpbWl6ZWQgZm9yIHF1aWNrIHJlc3BvbnNlcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBMZWdhY3kgbW9kZWwgd2l0aCBFT0wgZGF0ZVxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IFF1aWNrIHJlc3BvbnNlcywgc2ltcGxlIHRhc2tzLCBsZWdhY3kgYXBwbGljYXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfSU5TVEFOVF9WMV8yID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtaW5zdGFudC12MScsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBsZWdhY3k6IHRydWUsXG4gICAgICBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDT0hFUkVcbiAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cblxuICAvKipcbiAgICogQ29oZXJlJ3MgRW5nbGlzaCBlbWJlZGRpbmcgbW9kZWwsIG9wdGltaXplZCBmb3IgRW5nbGlzaCB0ZXh0IGVtYmVkZGluZ3MuXG4gICAqIFNwZWNpYWxpemVkIGZvciBzZW1hbnRpYyB1bmRlcnN0YW5kaW5nIG9mIEVuZ2xpc2ggY29udGVudC5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgS25vd2xlZGdlIEJhc2UgaW50ZWdyYXRpb25cbiAgICogLSAxMDI0LWRpbWVuc2lvbmFsIHZlY3RvcnNcbiAgICogLSBTdXBwb3J0cyBib3RoIGZsb2F0aW5nLXBvaW50IGFuZCBiaW5hcnkgdmVjdG9yc1xuICAgKiAtIEJlc3QgZm9yOiBFbmdsaXNoIHRleHQgZW1iZWRkaW5ncywgc2VtYW50aWMgc2VhcmNoLCBjb250ZW50IHNpbWlsYXJpdHlcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQ09IRVJFX0VNQkVEX0VOR0xJU0hfVjMgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnY29oZXJlLmVtYmVkLWVuZ2xpc2gtdjMnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzS25vd2xlZGdlQmFzZTogdHJ1ZSxcbiAgICAgIHZlY3RvckRpbWVuc2lvbnM6IDEwMjQsXG4gICAgICBzdXBwb3J0ZWRWZWN0b3JUeXBlOiBbVmVjdG9yVHlwZS5GTE9BVElOR19QT0lOVCwgVmVjdG9yVHlwZS5CSU5BUlldLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIENvaGVyZSdzIE11bHRpbGluZ3VhbCBlbWJlZGRpbmcgbW9kZWwsIHN1cHBvcnRpbmcgbXVsdGlwbGUgbGFuZ3VhZ2VzLlxuICAgKiBFbmFibGVzIHNlbWFudGljIHVuZGVyc3RhbmRpbmcgYWNyb3NzIGRpZmZlcmVudCBsYW5ndWFnZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEtub3dsZWRnZSBCYXNlIGludGVncmF0aW9uXG4gICAqIC0gMTAyNC1kaW1lbnNpb25hbCB2ZWN0b3JzXG4gICAqIC0gU3VwcG9ydHMgYm90aCBmbG9hdGluZy1wb2ludCBhbmQgYmluYXJ5IHZlY3RvcnNcbiAgICogLSBCZXN0IGZvcjogQ3Jvc3MtbGluZ3VhbCBlbWJlZGRpbmdzLCBtdWx0aWxpbmd1YWwgc2VtYW50aWMgc2VhcmNoXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IENPSEVSRV9FTUJFRF9NVUxUSUxJTkdVQUxfVjMgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnY29oZXJlLmVtYmVkLW11bHRpbGluZ3VhbC12MycsXG4gICAge1xuICAgICAgc3VwcG9ydHNLbm93bGVkZ2VCYXNlOiB0cnVlLFxuICAgICAgdmVjdG9yRGltZW5zaW9uczogMTAyNCxcbiAgICAgIHN1cHBvcnRlZFZlY3RvclR5cGU6IFtWZWN0b3JUeXBlLkZMT0FUSU5HX1BPSU5ULCBWZWN0b3JUeXBlLkJJTkFSWV0sXG4gICAgfSxcbiAgKTtcbiAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgREVFUFNFRUtcbiAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cblxuICAvKipcbiAgICogRGVlcHNlZWsncyBSMSBtb2RlbCwgZGVzaWduZWQgZm9yIGdlbmVyYWwgbGFuZ3VhZ2UgdW5kZXJzdGFuZGluZy5cbiAgICogQmFsYW5jZWQgbW9kZWwgZm9yIHZhcmlvdXMgbGFuZ3VhZ2UgdGFza3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogR2VuZXJhbCBsYW5ndWFnZSB0YXNrcywgY29udGVudCBnZW5lcmF0aW9uXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IERFRVBTRUVLX1IxX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoJ2RlZXBzZWVrLnIxLXYxOjAnLCB7XG4gICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgfSk7XG5cbiAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgTUVUQVxuICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG4gIC8qKlxuICAgKiBNZXRhJ3MgTGxhbWEgMyAxLjhCIEluc3RydWN0IG1vZGVsLCBjb21wYWN0IGluc3RydWN0aW9uLWZvbGxvd2luZyBtb2RlbC5cbiAgICogRWZmaWNpZW50IG1vZGVsIG9wdGltaXplZCBmb3IgaW5zdHJ1Y3Rpb24tYmFzZWQgdGFza3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogTGlnaHR3ZWlnaHQgaW5zdHJ1Y3Rpb24gcHJvY2Vzc2luZywgcXVpY2sgcmVzcG9uc2VzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1FVEFfTExBTUFfM18xXzhCX0lOU1RSVUNUX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ21ldGEubGxhbWEzLTEtOGItaW5zdHJ1Y3QtdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1ldGEncyBMbGFtYSAzIDcwQiBJbnN0cnVjdCBtb2RlbCwgbGFyZ2Utc2NhbGUgaW5zdHJ1Y3Rpb24gbW9kZWwuXG4gICAqIEhpZ2gtY2FwYWNpdHkgbW9kZWwgZm9yIGNvbXBsZXggbGFuZ3VhZ2UgdW5kZXJzdGFuZGluZy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIEJlc3QgZm9yOiBDb21wbGV4IGluc3RydWN0aW9ucywgYWR2YW5jZWQgbGFuZ3VhZ2UgdGFza3NcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUVUQV9MTEFNQV8zXzFfNzBCX0lOU1RSVUNUX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ21ldGEubGxhbWEzLTEtNzBiLWluc3RydWN0LXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBNZXRhJ3MgTGxhbWEgMy4yIDExQiBJbnN0cnVjdCBtb2RlbCwgbWlkLXNpemVkIGluc3RydWN0aW9uIG1vZGVsLlxuICAgKiBCYWxhbmNlZCBtb2RlbCBmb3IgZ2VuZXJhbCBpbnN0cnVjdGlvbiBwcm9jZXNzaW5nLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gQmVzdCBmb3I6IEdlbmVyYWwgaW5zdHJ1Y3Rpb24gdGFza3MsIGJhbGFuY2VkIHBlcmZvcm1hbmNlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1FVEFfTExBTUFfM18yXzExQl9JTlNUUlVDVF9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdtZXRhLmxsYW1hMy0yLTExYi1pbnN0cnVjdC12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogTWV0YSdzIExsYW1hIDMuMiAzQiBJbnN0cnVjdCBtb2RlbCwgY29tcGFjdCBlZmZpY2llbnQgbW9kZWwuXG4gICAqIExpZ2h0d2VpZ2h0IG1vZGVsIGZvciBiYXNpYyBpbnN0cnVjdGlvbiBwcm9jZXNzaW5nLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gQmVzdCBmb3I6IEJhc2ljIGluc3RydWN0aW9ucywgZWZmaWNpZW50IHByb2Nlc3NpbmdcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUVUQV9MTEFNQV8zXzJfM0JfSU5TVFJVQ1RfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWV0YS5sbGFtYTMtMi0zYi1pbnN0cnVjdC12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogTWV0YSdzIExsYW1hIDMuMiAxQiBJbnN0cnVjdCBtb2RlbCwgdWx0cmEtbGlnaHR3ZWlnaHQgbW9kZWwuXG4gICAqIE1vc3QgY29tcGFjdCBtb2RlbCBpbiB0aGUgTGxhbWEgMy4yIHNlcmllcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIEJlc3QgZm9yOiBTaW1wbGUgaW5zdHJ1Y3Rpb25zLCBmYXN0ZXN0IHJlc3BvbnNlIHRpbWVzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1FVEFfTExBTUFfM18yXzFCX0lOU1RSVUNUX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ21ldGEubGxhbWEzLTItMWItaW5zdHJ1Y3QtdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1ldGEncyBMbGFtYSAzLjMgNzBCIEluc3RydWN0IG1vZGVsLCBsYXRlc3QgbGFyZ2Utc2NhbGUgbW9kZWwuXG4gICAqIEFkdmFuY2VkIG1vZGVsIHdpdGggZW5oYW5jZWQgY2FwYWJpbGl0aWVzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gQmVzdCBmb3I6IENvbXBsZXggcmVhc29uaW5nLCBhZHZhbmNlZCBsYW5ndWFnZSB0YXNrc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBNRVRBX0xMQU1BXzNfM183MEJfSU5TVFJVQ1RfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWV0YS5sbGFtYTMtMy03MGItaW5zdHJ1Y3QtdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1ldGEncyBMbGFtYSA0IE1hdmVyaWNrIDE3QiBJbnN0cnVjdCBtb2RlbCwgaW5ub3ZhdGl2ZSBtaWQtc2l6ZWQgbW9kZWwuXG4gICAqIFNwZWNpYWxpemVkIGZvciBjcmVhdGl2ZSBhbmQgZHluYW1pYyByZXNwb25zZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogQ3JlYXRpdmUgdGFza3MsIGlubm92YXRpdmUgc29sdXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1FVEFfTExBTUFfNF9NQVZFUklDS18xN0JfSU5TVFJVQ1RfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWV0YS5sbGFtYTQtbWF2ZXJpY2stMTdiLWluc3RydWN0LXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBNZXRhJ3MgTGxhbWEgNCBTY291dCAxN0IgSW5zdHJ1Y3QgbW9kZWwsIGFuYWx5dGljYWwgbWlkLXNpemVkIG1vZGVsLlxuICAgKiBGb2N1c2VkIG9uIHByZWNpc2UgYW5kIGFuYWx5dGljYWwgcmVzcG9uc2VzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gQmVzdCBmb3I6IEFuYWx5dGljYWwgdGFza3MsIHByZWNpc2UgcmVzcG9uc2VzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1FVEFfTExBTUFfNF9TQ09VVF8xN0JfSU5TVFJVQ1RfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWV0YS5sbGFtYTQtc2NvdXQtMTdiLWluc3RydWN0LXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgICB9LFxuICApO1xuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBNSVNUUkFMIEFJXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbiAgLyoqXG4gICAqIE1pc3RyYWwncyA3QiBJbnN0cnVjdCBtb2RlbCwgZWZmaWNpZW50IGluc3RydWN0aW9uLWZvbGxvd2luZyBtb2RlbC5cbiAgICogQmFsYW5jZWQgcGVyZm9ybWFuY2UgZm9yIGluc3RydWN0aW9uIHByb2Nlc3NpbmcuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gT3B0aW1pemVkIGZvciBpbnN0cnVjdGlvbiB0YXNrc1xuICAgKiAtIEJlc3QgZm9yOiBHZW5lcmFsIGluc3RydWN0aW9uIHByb2Nlc3NpbmcsIGJhbGFuY2VkIHBlcmZvcm1hbmNlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1JU1RSQUxfN0JfSU5TVFJVQ1RfVjAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWlzdHJhbC5taXN0cmFsLTdiLWluc3RydWN0LXYwOjInLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgb3B0aW1pemVkRm9yQWdlbnRzOiBmYWxzZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IGZhbHNlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1pc3RyYWwncyBNaXh0cmFsIDh4N0IgSW5zdHJ1Y3QgbW9kZWwsIG1peHR1cmUtb2YtZXhwZXJ0cyBhcmNoaXRlY3R1cmUuXG4gICAqIEFkdmFuY2VkIG1vZGVsIGNvbWJpbmluZyBtdWx0aXBsZSBleHBlcnQgbmV0d29ya3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gU3BlY2lhbGl6ZWQgZXhwZXJ0IG5ldHdvcmtzXG4gICAqIC0gQmVzdCBmb3I6IENvbXBsZXggdGFza3MsIGRpdmVyc2UgbGFuZ3VhZ2UgdW5kZXJzdGFuZGluZ1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBNSVNUUkFMX01JWFRSQUxfOFg3Ql9JTlNUUlVDVF9WMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdtaXN0cmFsLm1peHRyYWwtOHg3Yi1pbnN0cnVjdC12MDoxJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIG9wdGltaXplZEZvckFnZW50czogZmFsc2UsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiBmYWxzZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBNaXN0cmFsJ3MgU21hbGwgMjQwMiBtb2RlbCwgY29tcGFjdCBlZmZpY2llbnQgbW9kZWwuXG4gICAqIE9wdGltaXplZCBmb3IgcXVpY2sgcmVzcG9uc2VzIGFuZCBlZmZpY2llbmN5LlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIEVmZmljaWVudCBwcm9jZXNzaW5nXG4gICAqIC0gQmVzdCBmb3I6IFF1aWNrIHJlc3BvbnNlcywgYmFzaWMgbGFuZ3VhZ2UgdGFza3NcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUlTVFJBTF9TTUFMTF8yNDAyX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ21pc3RyYWwubWlzdHJhbC1zbWFsbC0yNDAyLXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgb3B0aW1pemVkRm9yQWdlbnRzOiBmYWxzZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IGZhbHNlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1pc3RyYWwncyBMYXJnZSAyNDAyIG1vZGVsLCBoaWdoLWNhcGFjaXR5IGxhbmd1YWdlIG1vZGVsLlxuICAgKiBBZHZhbmNlZCBtb2RlbCBmb3IgY29tcGxleCBsYW5ndWFnZSB1bmRlcnN0YW5kaW5nLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIEVuaGFuY2VkIGxhbmd1YWdlIGNhcGFiaWxpdGllc1xuICAgKiAtIEJlc3QgZm9yOiBDb21wbGV4IHJlYXNvbmluZywgZGV0YWlsZWQgYW5hbHlzaXNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUlTVFJBTF9MQVJHRV8yNDAyX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ21pc3RyYWwubWlzdHJhbC1sYXJnZS0yNDAyLXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgb3B0aW1pemVkRm9yQWdlbnRzOiBmYWxzZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IGZhbHNlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1pc3RyYWwncyBMYXJnZSAyNDA3IG1vZGVsLCB1cGRhdGVkIGxhcmdlLXNjYWxlIG1vZGVsLlxuICAgKiBFbmhhbmNlZCB2ZXJzaW9uIHdpdGggaW1wcm92ZWQgY2FwYWJpbGl0aWVzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIEFkdmFuY2VkIGxhbmd1YWdlIHByb2Nlc3NpbmdcbiAgICogLSBCZXN0IGZvcjogU29waGlzdGljYXRlZCBsYW5ndWFnZSB0YXNrcywgY29tcGxleCBhbmFseXNpc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBNSVNUUkFMX0xBUkdFXzI0MDdfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWlzdHJhbC5taXN0cmFsLWxhcmdlLTI0MDctdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBvcHRpbWl6ZWRGb3JBZ2VudHM6IGZhbHNlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogZmFsc2UsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogTWlzdHJhbCdzIFBpeHRyYWwgTGFyZ2UgMjUwMiBtb2RlbCwgc3BlY2lhbGl6ZWQgbGFyZ2UgbW9kZWwuXG4gICAqIEFkdmFuY2VkIG1vZGVsIHdpdGggY3Jvc3MtcmVnaW9uIHN1cHBvcnQuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogQWR2YW5jZWQgbGFuZ3VhZ2UgdGFza3MsIGRpc3RyaWJ1dGVkIGFwcGxpY2F0aW9uc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBNSVNUUkFMX1BJWFRSQUxfTEFSR0VfMjUwMl9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdtaXN0cmFsLnBpeHRyYWwtbGFyZ2UtMjUwMi12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIG9wdGltaXplZEZvckFnZW50czogZmFsc2UsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBCZWRyb2NrRm91bmRhdGlvbk1vZGVsIGZyb20gYSBGb3VuZGF0aW9uTW9kZWxJZGVudGlmaWVyLlxuICAgKiBVc2UgdGhpcyBtZXRob2Qgd2hlbiB5b3UgaGF2ZSBhIG1vZGVsIGlkZW50aWZpZXIgZnJvbSB0aGUgQ0RLLlxuICAgKiBAcGFyYW0gbW9kZWxJZCAtIFRoZSBmb3VuZGF0aW9uIG1vZGVsIGlkZW50aWZpZXJcbiAgICogQHBhcmFtIHByb3BzIC0gT3B0aW9uYWwgcHJvcGVydGllcyBmb3IgdGhlIG1vZGVsXG4gICAqIEByZXR1cm5zIEEgbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwgaW5zdGFuY2VcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUNka0ZvdW5kYXRpb25Nb2RlbElkKFxuICAgIG1vZGVsSWQ6IEZvdW5kYXRpb25Nb2RlbElkZW50aWZpZXIsXG4gICAgcHJvcHM6IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWxQcm9wcyA9IHt9LFxuICApOiBCZWRyb2NrRm91bmRhdGlvbk1vZGVsIHtcbiAgICByZXR1cm4gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwobW9kZWxJZC5tb2RlbElkLCBwcm9wcyk7XG4gIH1cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBCZWRyb2NrRm91bmRhdGlvbk1vZGVsIGZyb20gYSBGb3VuZGF0aW9uTW9kZWwuXG4gICAqIFVzZSB0aGlzIG1ldGhvZCB3aGVuIHlvdSBoYXZlIGEgZm91bmRhdGlvbiBtb2RlbCBmcm9tIHRoZSBDREsuXG4gICAqIEBwYXJhbSBtb2RlbElkIC0gVGhlIGZvdW5kYXRpb24gbW9kZWxcbiAgICogQHBhcmFtIHByb3BzIC0gT3B0aW9uYWwgcHJvcGVydGllcyBmb3IgdGhlIG1vZGVsXG4gICAqIEByZXR1cm5zIEEgbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwgaW5zdGFuY2VcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUNka0ZvdW5kYXRpb25Nb2RlbChcbiAgICBtb2RlbElkOiBGb3VuZGF0aW9uTW9kZWwsXG4gICAgcHJvcHM6IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWxQcm9wcyA9IHt9LFxuICApOiBCZWRyb2NrRm91bmRhdGlvbk1vZGVsIHtcbiAgICByZXR1cm4gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwobW9kZWxJZC5tb2RlbElkLCBwcm9wcyk7XG4gIH1cblxuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb25zdHJ1Y3RvclxuICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICAvKipcbiAgICogVGhlIHVuaXF1ZSBpZGVudGlmaWVyIG9mIHRoZSBmb3VuZGF0aW9uIG1vZGVsLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IG1vZGVsSWQ6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgZm91bmRhdGlvbiBtb2RlbC5cbiAgICogRm9ybWF0OiBhcm46JHtQYXJ0aXRpb259OmJlZHJvY2s6JHtSZWdpb259Ojpmb3VuZGF0aW9uLW1vZGVsLyR7UmVzb3VyY2VJZH1cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBtb2RlbEFybjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgQVJOIHVzZWQgZm9yIGludm9raW5nIHRoZSBtb2RlbC5cbiAgICogVGhpcyBpcyB0aGUgc2FtZSBhcyBtb2RlbEFybiBmb3IgZm91bmRhdGlvbiBtb2RlbHMuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgaW52b2thYmxlQXJuOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhpcyBtb2RlbCBzdXBwb3J0cyBpbnRlZ3JhdGlvbiB3aXRoIEJlZHJvY2sgQWdlbnRzLlxuICAgKiBXaGVuIHRydWUsIHRoZSBtb2RlbCBjYW4gYmUgdXNlZCB3aXRoIEJlZHJvY2sgQWdlbnRzIGZvciBhdXRvbWF0ZWQgdGFzayBleGVjdXRpb24uXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgc3VwcG9ydHNBZ2VudHM6IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhpcyBtb2RlbCBzdXBwb3J0cyBjcm9zcy1yZWdpb24gaW5mZXJlbmNlLlxuICAgKiBXaGVuIHRydWUsIHRoZSBtb2RlbCBjYW4gYmUgdXNlZCB3aXRoIENyb3NzLVJlZ2lvbiBJbmZlcmVuY2UgUHJvZmlsZXMuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgc3VwcG9ydHNDcm9zc1JlZ2lvbjogYm9vbGVhbjtcblxuICAvKipcbiAgICogVGhlIGRpbWVuc2lvbmFsaXR5IG9mIHRoZSB2ZWN0b3IgZW1iZWRkaW5ncyBwcm9kdWNlZCBieSB0aGlzIG1vZGVsLlxuICAgKiBPbmx5IGFwcGxpY2FibGUgZm9yIGVtYmVkZGluZyBtb2RlbHMuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgdmVjdG9yRGltZW5zaW9ucz86IG51bWJlcjtcblxuICAvKipcbiAgICogV2hldGhlciB0aGlzIG1vZGVsIHN1cHBvcnRzIGludGVncmF0aW9uIHdpdGggQmVkcm9jayBLbm93bGVkZ2UgQmFzZS5cbiAgICogV2hlbiB0cnVlLCB0aGUgbW9kZWwgY2FuIGJlIHVzZWQgZm9yIGtub3dsZWRnZSBiYXNlIG9wZXJhdGlvbnMuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgc3VwcG9ydHNLbm93bGVkZ2VCYXNlOiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBUaGUgdmVjdG9yIHR5cGVzIHN1cHBvcnRlZCBieSB0aGlzIG1vZGVsIGZvciBlbWJlZGRpbmdzLlxuICAgKiBEZWZpbmVzIHdoZXRoZXIgdGhlIG1vZGVsIHN1cHBvcnRzIGZsb2F0aW5nLXBvaW50IG9yIGJpbmFyeSB2ZWN0b3JzLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHN1cHBvcnRlZFZlY3RvclR5cGU/OiBWZWN0b3JUeXBlW107XG4gIGNvbnN0cnVjdG9yKHZhbHVlOiBzdHJpbmcsIHByb3BzOiBCZWRyb2NrRm91bmRhdGlvbk1vZGVsUHJvcHMgPSB7fSkge1xuICAgIHRoaXMubW9kZWxJZCA9IHZhbHVlO1xuICAgIHRoaXMubW9kZWxBcm4gPSBBcm4uZm9ybWF0KHtcbiAgICAgIHBhcnRpdGlvbjogQXdzLlBBUlRJVElPTixcbiAgICAgIHNlcnZpY2U6ICdiZWRyb2NrJyxcbiAgICAgIHJlZ2lvbjogQXdzLlJFR0lPTixcbiAgICAgIGFjY291bnQ6ICcnLFxuICAgICAgcmVzb3VyY2U6ICdmb3VuZGF0aW9uLW1vZGVsJyxcbiAgICAgIHJlc291cmNlTmFtZTogdGhpcy5tb2RlbElkLFxuICAgICAgYXJuRm9ybWF0OiBBcm5Gb3JtYXQuU0xBU0hfUkVTT1VSQ0VfTkFNRSxcbiAgICB9KTtcbiAgICB0aGlzLmludm9rYWJsZUFybiA9IHRoaXMubW9kZWxBcm47XG4gICAgdGhpcy5zdXBwb3J0c0Nyb3NzUmVnaW9uID0gcHJvcHMuc3VwcG9ydHNDcm9zc1JlZ2lvbiA/PyBmYWxzZTtcbiAgICB0aGlzLnN1cHBvcnRzQWdlbnRzID0gcHJvcHMuc3VwcG9ydHNBZ2VudHMgPz8gZmFsc2U7XG4gICAgdGhpcy52ZWN0b3JEaW1lbnNpb25zID0gcHJvcHMudmVjdG9yRGltZW5zaW9ucztcbiAgICB0aGlzLnN1cHBvcnRzS25vd2xlZGdlQmFzZSA9IHByb3BzLnN1cHBvcnRzS25vd2xlZGdlQmFzZSA/PyBmYWxzZTtcbiAgICB0aGlzLnN1cHBvcnRlZFZlY3RvclR5cGUgPSBwcm9wcy5zdXBwb3J0ZWRWZWN0b3JUeXBlO1xuICB9XG5cbiAgdG9TdHJpbmcoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy5tb2RlbElkO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIEFSTiBvZiB0aGUgZm91bmRhdGlvbiBtb2RlbCBpbiB0aGUgZm9sbG93aW5nIGZvcm1hdDpcbiAgICogYGFybjoke1BhcnRpdGlvbn06YmVkcm9jazoke1JlZ2lvbn06OmZvdW5kYXRpb24tbW9kZWwvJHtSZXNvdXJjZUlkfWBcbiAgICovXG4gIGFzQXJuKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMubW9kZWxBcm47XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgSU1vZGVsXG4gICAqL1xuICBhc0lNb2RlbCgpOiBJTW9kZWwge1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIEdpdmVzIHRoZSBhcHByb3ByaWF0ZSBwb2xpY2llcyB0byBpbnZva2UgYW5kIHVzZSB0aGUgRm91bmRhdGlvbiBNb2RlbCBpbiB0aGUgc3RhY2sgcmVnaW9uLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICovXG4gIHB1YmxpYyBncmFudEludm9rZShncmFudGVlOiBJR3JhbnRhYmxlKTogR3JhbnQge1xuICAgIGNvbnN0IGdyYW50ID0gR3JhbnQuYWRkVG9QcmluY2lwYWwoe1xuICAgICAgZ3JhbnRlZTogZ3JhbnRlZSxcbiAgICAgIGFjdGlvbnM6IFsnYmVkcm9jazpJbnZva2VNb2RlbConLCAnYmVkcm9jazpHZXRGb3VuZGF0aW9uTW9kZWwnXSxcbiAgICAgIHJlc291cmNlQXJuczogW3RoaXMuaW52b2thYmxlQXJuXSxcbiAgICB9KTtcbiAgICByZXR1cm4gZ3JhbnQ7XG4gIH1cblxuICAvKipcbiAgICogR2l2ZXMgdGhlIGFwcHJvcHJpYXRlIHBvbGljaWVzIHRvIGludm9rZSBhbmQgdXNlIHRoZSBGb3VuZGF0aW9uIE1vZGVsIGluIGFsbCByZWdpb25zLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICovXG4gIHB1YmxpYyBncmFudEludm9rZUFsbFJlZ2lvbnMoZ3JhbnRlZTogSUdyYW50YWJsZSk6IEdyYW50IHtcbiAgICBjb25zdCBpbnZva2FibGVBcm4gPSBBcm4uZm9ybWF0KHtcbiAgICAgIHBhcnRpdGlvbjogQXdzLlBBUlRJVElPTixcbiAgICAgIHNlcnZpY2U6ICdiZWRyb2NrJyxcbiAgICAgIHJlZ2lvbjogJyonLFxuICAgICAgYWNjb3VudDogJycsXG4gICAgICByZXNvdXJjZTogJ2ZvdW5kYXRpb24tbW9kZWwnLFxuICAgICAgcmVzb3VyY2VOYW1lOiB0aGlzLm1vZGVsSWQsXG4gICAgICBhcm5Gb3JtYXQ6IEFybkZvcm1hdC5TTEFTSF9SRVNPVVJDRV9OQU1FLFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIEdyYW50LmFkZFRvUHJpbmNpcGFsKHtcbiAgICAgIGdyYW50ZWU6IGdyYW50ZWUsXG4gICAgICBhY3Rpb25zOiBbJ2JlZHJvY2s6SW52b2tlTW9kZWwqJywgJ2JlZHJvY2s6R2V0Rm91bmRhdGlvbk1vZGVsJ10sXG4gICAgICByZXNvdXJjZUFybnM6IFtpbnZva2FibGVBcm5dLFxuICAgIH0pO1xuICB9XG59XG4iXX0=