"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContextualGroundingFilterType = exports.UKSpecificPIIType = exports.CanadaSpecificPIIType = exports.USASpecificPIIType = exports.InformationTechnologyPIIType = exports.FinancePIIType = exports.GeneralPIIType = exports.PIIType = exports.ManagedWordFilterType = exports.Topic = exports.ContentFilterType = exports.ModalityType = exports.ContentFilterStrength = exports.TierConfig = exports.GuardrailAction = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
/**
 * Guardrail action when a sensitive entity is detected.
 */
var GuardrailAction;
(function (GuardrailAction) {
    /**
     * If sensitive information is detected in the prompt or response, the guardrail
     * blocks all the content and returns a message that you configure.
     */
    GuardrailAction["BLOCK"] = "BLOCK";
    /**
     * If sensitive information is detected in the model response, the guardrail masks
     * it with an identifier, the sensitive information is masked and replaced with
     * identifier tags (for example: [NAME-1], [NAME-2], [EMAIL-1], etc.).
     */
    GuardrailAction["ANONYMIZE"] = "ANONYMIZE";
    /**
     * Do not take any action.
     */
    GuardrailAction["NONE"] = "NONE";
})(GuardrailAction || (exports.GuardrailAction = GuardrailAction = {}));
/******************************************************************************
 *                             TIER CONFIG
*****************************************************************************/
var TierConfig;
(function (TierConfig) {
    /**
     * Provides established guardrails functionality supporting English, French, and Spanish languages.
     */
    TierConfig["CLASSIC"] = "CLASSIC";
    /**
     * Provides a more robust solution than the CLASSIC tier and has more comprehensive language support. This tier requires that your guardrail use cross-Region inference.
     */
    TierConfig["STANDARD"] = "STANDARD";
})(TierConfig || (exports.TierConfig = TierConfig = {}));
/******************************************************************************
 *                             CONTENT FILTERS
 *****************************************************************************/
/**
 * The strength of the content filter. As you increase the filter strength,
 * the likelihood of filtering harmful content increases and the probability
 * of seeing harmful content in your application reduces.
 */
var ContentFilterStrength;
(function (ContentFilterStrength) {
    /**
     * No content filtering applied.
     */
    ContentFilterStrength["NONE"] = "NONE";
    /**
     * Low strength content filtering - minimal filtering of harmful content.
     */
    ContentFilterStrength["LOW"] = "LOW";
    /**
     * Medium strength content filtering - balanced filtering of harmful content.
     */
    ContentFilterStrength["MEDIUM"] = "MEDIUM";
    /**
     * High strength content filtering - aggressive filtering of harmful content.
     */
    ContentFilterStrength["HIGH"] = "HIGH";
})(ContentFilterStrength || (exports.ContentFilterStrength = ContentFilterStrength = {}));
/**
 * The type of modality that can be used in content filters.
 */
var ModalityType;
(function (ModalityType) {
    /**
     * Text modality for content filters.
     */
    ModalityType["TEXT"] = "TEXT";
    /**
     * Image modality for content filters.
     */
    ModalityType["IMAGE"] = "IMAGE";
})(ModalityType || (exports.ModalityType = ModalityType = {}));
/**
 * The type of harmful category usable in a content filter.
 */
var ContentFilterType;
(function (ContentFilterType) {
    /**
     * Describes input prompts and model responses that indicates sexual interest, activity,
     * or arousal using direct or indirect references to body parts, physical traits, or sex.
     */
    ContentFilterType["SEXUAL"] = "SEXUAL";
    /**
     * Describes input prompts and model responses that includes glorification of or threats
     * to inflict physical pain, hurt, or injury toward a person, group or thing.
     */
    ContentFilterType["VIOLENCE"] = "VIOLENCE";
    /**
     * Describes input prompts and model responses that discriminate, criticize, insult,
     * denounce, or dehumanize a person or group on the basis of an identity (such as race,
     * ethnicity, gender, religion, sexual orientation, ability, and national origin).
     */
    ContentFilterType["HATE"] = "HATE";
    /**
     * Describes input prompts and model responses that includes demeaning, humiliating,
     * mocking, insulting, or belittling language. This type of language is also labeled
     * as bullying.
     */
    ContentFilterType["INSULTS"] = "INSULTS";
    /**
     * Describes input prompts and model responses that seeks or provides information
     * about engaging in misconduct activity, or harming, defrauding, or taking advantage
     * of a person, group or institution.
     */
    ContentFilterType["MISCONDUCT"] = "MISCONDUCT";
    /**
     * Enable to detect and block user inputs attempting to override system instructions.
     * To avoid misclassifying system prompts as a prompt attack and ensure that the filters
     * are selectively applied to user inputs, use input tagging.
     */
    ContentFilterType["PROMPT_ATTACK"] = "PROMPT_ATTACK";
})(ContentFilterType || (exports.ContentFilterType = ContentFilterType = {}));
/**
 * Represents predefined topics that can be used to filter content.
 */
class Topic {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.Topic", version: "2.248.0-alpha.0" };
    /**
     * Filter for financial advice and investment recommendations.
     */
    static FINANCIAL_ADVICE = new Topic({
        name: 'Financial_Advice',
        definition: "'Discussions that involve providing guidance, recommendations, or suggestions related to managing, investing, or handling finances, investments, or assets.",
        examples: [
            'Can you suggest some good stocks to invest in right now?',
            "What's the best way to save for retirement?",
            'Should I put my money in a high-risk investment?',
            'How can I maximize my returns on investments?',
            'Is it a good time to buy real estate?',
        ],
        inputAction: GuardrailAction.BLOCK,
        inputEnabled: true,
        outputAction: GuardrailAction.BLOCK,
        outputEnabled: true,
    });
    /**
     * Filter for inappropriate or explicit content.
     */
    static INAPPROPRIATE_CONTENT = new Topic({
        name: 'Inappropriate_Content',
        definition: 'Conversations that express views, opinions, or endorsements related to political parties, political ideologies, elections, or political figures.',
        examples: [
            "What's your stance on the current government policies?",
            'Do you support party X or Y in the upcoming election?',
            'Can you tell me which political party is better?',
            'What do you think about the new policy introduced by the president?',
            'Should I vote for this candidate?',
        ],
        inputAction: GuardrailAction.BLOCK,
        inputEnabled: true,
        outputAction: GuardrailAction.BLOCK,
        outputEnabled: true,
    });
    /**
     * Filter for legal advice and recommendations.
     */
    static LEGAL_ADVICE = new Topic({
        name: 'Legal_Advice',
        definition: 'Providing recommendations, diagnosis, treatment options, or guidance on medical conditions, symptoms, medications, or health-related issues.',
        examples: [
            'What should I do to treat a persistent cough?',
            'Can you recommend some medication for my headache?',
            'What are the symptoms of a specific medical condition?',
            'Is this drug effective for treating my illness?',
            "Do I need to see a doctor for this pain I'm experiencing?",
        ],
        inputAction: GuardrailAction.BLOCK,
        inputEnabled: true,
        outputAction: GuardrailAction.BLOCK,
        outputEnabled: true,
    });
    /**
     * Filter for medical advice and health recommendations.
     */
    static MEDICAL_ADVICE = new Topic({
        name: 'Medical_Advice',
        definition: 'Any discussions or references that include hate speech, discriminatory remarks, sexual content, or explicit language.',
        examples: [
            'Why are people from X country so [discriminatory remark]?',
            'Can you tell me a dirty joke?',
            '[Use of explicit language]',
            'This service is as bad as [hate speech].',
            'Do you have any adult content or products?',
        ],
        inputAction: GuardrailAction.BLOCK,
        inputEnabled: true,
        outputAction: GuardrailAction.BLOCK,
        outputEnabled: true,
    });
    /**
     * Filter for political advice and recommendations.
     */
    static POLITICAL_ADVICE = new Topic({
        name: 'Political_Advice',
        definition: 'Offering guidance or suggestions on legal matters, legal actions, interpretation of laws, or legal rights and responsibilities.',
        examples: [
            'Can I sue someone for this?',
            'What are my legal rights in this situation?',
            'Is this action against the law?',
            'What should I do to file a legal complaint?',
            'Can you explain this law to me?',
        ],
        inputAction: GuardrailAction.BLOCK,
        inputEnabled: true,
        outputAction: GuardrailAction.BLOCK,
        outputEnabled: true,
    });
    /**
     * Create a custom topic filter.
     * @param props Properties for the custom topic filter
     */
    static custom(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_CustomTopicProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.custom);
            }
            throw error;
        }
        return new Topic(props);
    }
    /**
     * The name of the topic to deny.
     */
    name;
    /**
     * Definition of the topic.
     */
    definition;
    /**
     * Representative phrases that refer to the topic.
     */
    examples;
    /**
     * The action to take when a topic is detected in the input.
     * @default GuardrailAction.BLOCK
     */
    inputAction;
    /**
     * Whether the topic filter is enabled for input.
     * @default true
     */
    inputEnabled;
    /**
     * The action to take when a topic is detected in the output.
     * @default GuardrailAction.BLOCK
     */
    outputAction;
    /**
     * Whether the topic filter is enabled for output.
     * @default true
     */
    outputEnabled;
    constructor(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_CustomTopicProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, Topic);
            }
            throw error;
        }
        // Validate examples field constraints
        const examplesValidationRules = [
            {
                condition: (p) => !p.examples || p.examples.length < 1,
                message: () => 'examples field must contain at least 1 example',
            },
            {
                condition: (p) => p.examples && p.examples.length > 100,
                message: () => 'examples field cannot contain more than 100 examples',
            },
        ];
        // Note: We can't use validateAllProps here since we don't have a Construct scope
        // Instead, we'll validate directly
        for (const rule of examplesValidationRules) {
            if (rule.condition(props)) {
                throw new Error(rule.message(props));
            }
        }
        this.name = props.name;
        this.definition = props.definition;
        this.examples = props.examples;
        this.inputAction = props.inputAction;
        this.inputEnabled = props.inputEnabled;
        this.outputAction = props.outputAction;
        this.outputEnabled = props.outputEnabled;
    }
}
exports.Topic = Topic;
/**
 * Managed word list filter types supported by Amazon Bedrock.
 */
var ManagedWordFilterType;
(function (ManagedWordFilterType) {
    /**
     * Filter for profanity and explicit language.
     */
    ManagedWordFilterType["PROFANITY"] = "PROFANITY";
})(ManagedWordFilterType || (exports.ManagedWordFilterType = ManagedWordFilterType = {}));
/******************************************************************************
   *                   SENSITIVE INFORMATION FILTERS - PII
   *****************************************************************************/
/**
 * Abstract base class for all PII types.
 */
class PIIType {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.PIIType", version: "2.248.0-alpha.0" };
    /**
     * The string value of the PII type.
     */
    value;
    /**
     * The string value of the PII type.
     */
    constructor(value) {
        this.value = value;
    }
    /**
     * Returns the string representation of the PII type.
     * @returns The string value of the PII type.
     */
    toString() { return this.value; }
}
exports.PIIType = PIIType;
/**
 * Types of PII that are general, and not domain-specific.
 */
class GeneralPIIType extends PIIType {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.GeneralPIIType", version: "2.248.0-alpha.0" };
    /**
     * A physical address, such as "100 Main Street, Anytown, USA" or "Suite #12,
     * Building 123". An address can include information such as the street, building,
     * location, city, state, country, county, zip code, precinct, and neighborhood.
     */
    static ADDRESS = new GeneralPIIType('ADDRESS');
    /**
     * An individual's age, including the quantity and unit of time.
     */
    static AGE = new GeneralPIIType('AGE');
    /**
     * The number assigned to a driver's license, which is an official document
     * permitting an individual to operate one or more motorized vehicles on a
     * public road. A driver's license number consists of alphanumeric characters.
     */
    static DRIVER_ID = new GeneralPIIType('DRIVER_ID');
    /**
     * An email address, such as marymajor@email.com.
     */
    static EMAIL = new GeneralPIIType('EMAIL');
    /**
     * A license plate for a vehicle is issued by the state or country where the
     * vehicle is registered. The format for passenger vehicles is typically five
     * to eight digits, consisting of upper-case letters and numbers. The format
     * varies depending on the location of the issuing state or country.
     */
    static LICENSE_PLATE = new GeneralPIIType('LICENSE_PLATE');
    /**
     * An individual's name. This entity type does not include titles, such as Dr.,
     *  Mr., Mrs., or Miss.
     */
    static NAME = new GeneralPIIType('NAME');
    /**
     * An alphanumeric string that is used as a password, such as "*very20special#pass*".
     */
    static PASSWORD = new GeneralPIIType('PASSWORD');
    /**
     * A phone number. This entity type also includes fax and pager numbers.
     */
    static PHONE = new GeneralPIIType('PHONE');
    /**
     * A user name that identifies an account, such as a login name, screen name,
     * nick name, or handle.
     */
    static USERNAME = new GeneralPIIType('USERNAME');
    /**
     * A Vehicle Identification Number (VIN) uniquely identifies a vehicle. VIN
     * content and format are defined in the ISO 3779 specification. Each country
     * has specific codes and formats for VINs.
     */
    static VEHICLE_IDENTIFICATION_NUMBER = new GeneralPIIType('VEHICLE_IDENTIFICATION_NUMBER');
    constructor(value) { super(value); }
}
exports.GeneralPIIType = GeneralPIIType;
/**
 * Types of PII in the domain of Finance.
 */
class FinancePIIType extends PIIType {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.FinancePIIType", version: "2.248.0-alpha.0" };
    /**
     * A three-digit card verification code (CVV) that is present on VISA, MasterCard,
     * and Discover credit and debit cards. For American Express credit or debit cards,
     * the CVV is a four-digit numeric code.
     */
    static CREDIT_DEBIT_CARD_CVV = new FinancePIIType('CREDIT_DEBIT_CARD_CVV');
    /**
     * The expiration date for a credit or debit card. This number is usually four digits
     * long and is often formatted as month/year or MM/YY. Guardrails recognizes expiration
     * dates such as 01/21, 01/2021, and Jan 2021.
     */
    static CREDIT_DEBIT_CARD_EXPIRY = new FinancePIIType('CREDIT_DEBIT_CARD_EXPIRY');
    /**
     * The number for a credit or debit card. These numbers can vary from 13 to 16 digits
     * in length.
     */
    static CREDIT_DEBIT_CARD_NUMBER = new FinancePIIType('CREDIT_DEBIT_CARD_NUMBER');
    /**
     * A four-digit personal identification number (PIN) with which you can access your
     * bank account.
     */
    static PIN = new FinancePIIType('PIN');
    /**
     * A SWIFT code is a standard format of Bank Identifier Code (BIC) used to specify a
     * particular bank or branch. Banks use these codes for money transfers such as
     * international wire transfers. SWIFT codes consist of eight or 11 characters.
     */
    static SWIFT_CODE = new FinancePIIType('SWIFT_CODE');
    /**
     * An International Bank Account Number (IBAN). It has specific formats in each country.
     */
    static INTERNATIONAL_BANK_ACCOUNT_NUMBER = new FinancePIIType('INTERNATIONAL_BANK_ACCOUNT_NUMBER');
    constructor(value) { super(value); }
}
exports.FinancePIIType = FinancePIIType;
/**
 * Types of PII in the domain of IT (Information Technology).
 */
class InformationTechnologyPIIType extends PIIType {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.InformationTechnologyPIIType", version: "2.248.0-alpha.0" };
    /**
     * A web address, such as www.example.com.
     */
    static URL = new InformationTechnologyPIIType('URL');
    /**
     * An IPv4 address, such as 198.51.100.0.
     */
    static IP_ADDRESS = new InformationTechnologyPIIType('IP_ADDRESS');
    /**
     * A media access control (MAC) address assigned to a network interface.
     */
    static MAC_ADDRESS = new InformationTechnologyPIIType('MAC_ADDRESS');
    /**
     * A unique identifier that's associated with a secret access key. You use
     * the access key ID and secret access key to sign programmatic AWS requests
     * cryptographically.
     */
    static AWS_ACCESS_KEY = new InformationTechnologyPIIType('AWS_ACCESS_KEY');
    /**
     * A unique identifier that's associated with a secret access key. You use
     * the access key ID and secret access key to sign programmatic AWS requests
     * cryptographically.
     */
    static AWS_SECRET_KEY = new InformationTechnologyPIIType('AWS_SECRET_KEY');
    constructor(value) { super(value); }
}
exports.InformationTechnologyPIIType = InformationTechnologyPIIType;
/**
 * Types of PII specific to the USA.
 */
class USASpecificPIIType extends PIIType {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.USASpecificPIIType", version: "2.248.0-alpha.0" };
    /**
     * A US bank account number, which is typically 10 to 12 digits long.
     */
    static US_BANK_ACCOUNT_NUMBER = new USASpecificPIIType('US_BANK_ACCOUNT_NUMBER');
    /**
     * A US bank account routing number. These are typically nine digits long.
     */
    static US_BANK_ROUTING_NUMBER = new USASpecificPIIType('US_BANK_ROUTING_NUMBER');
    /**
     * A US Individual Taxpayer Identification Number (ITIN) is a nine-digit number
     * that starts with a "9" and contain a "7" or "8" as the fourth digit.
     */
    static US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER = new USASpecificPIIType('US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER');
    /**
     * A US passport number. Passport numbers range from six to nine alphanumeric characters.
     */
    static US_PASSPORT_NUMBER = new USASpecificPIIType('US_PASSPORT_NUMBER');
    /**
     * A US Social Security Number (SSN) is a nine-digit number that is issued to US citizens,
     * permanent residents, and temporary working residents.
     */
    static US_SOCIAL_SECURITY_NUMBER = new USASpecificPIIType('US_SOCIAL_SECURITY_NUMBER');
    constructor(value) { super(value); }
}
exports.USASpecificPIIType = USASpecificPIIType;
/**
 * Types of PII specific to Canada.
 */
class CanadaSpecificPIIType extends PIIType {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.CanadaSpecificPIIType", version: "2.248.0-alpha.0" };
    /**
     * A Canadian Health Service Number is a 10-digit unique identifier,
     * required for individuals to access healthcare benefits.
     */
    static CA_HEALTH_NUMBER = new CanadaSpecificPIIType('CA_HEALTH_NUMBER');
    /**
     * A Canadian Social Insurance Number (SIN) is a nine-digit unique identifier,
     * required for individuals to access government programs and benefits.
     */
    static CA_SOCIAL_INSURANCE_NUMBER = new CanadaSpecificPIIType('CA_SOCIAL_INSURANCE_NUMBER');
    constructor(value) { super(value); }
}
exports.CanadaSpecificPIIType = CanadaSpecificPIIType;
/**
 * Types of PII specific to the United Kingdom (UK).
 */
class UKSpecificPIIType extends PIIType {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.UKSpecificPIIType", version: "2.248.0-alpha.0" };
    /**
     * A UK National Health Service Number is a 10-17 digit number, such as 485 777 3456.
     */
    static UK_NATIONAL_HEALTH_SERVICE_NUMBER = new UKSpecificPIIType('UK_NATIONAL_HEALTH_SERVICE_NUMBER');
    /**
     * A UK National Insurance Number (NINO) provides individuals with access to National
     * Insurance (social security) benefits. It is also used for some purposes in the UK
     * tax system.
     */
    static UK_NATIONAL_INSURANCE_NUMBER = new UKSpecificPIIType('UK_NATIONAL_INSURANCE_NUMBER');
    /**
     * A UK Unique Taxpayer Reference (UTR) is a 10-digit number that identifies a
     * taxpayer or a business.
     */
    static UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER = new UKSpecificPIIType('UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER');
    constructor(value) { super(value); }
}
exports.UKSpecificPIIType = UKSpecificPIIType;
/******************************************************************************
   *                      CONTEXTUAL GROUNDING FILTERS
   *****************************************************************************/
/**
 * The type of contextual grounding filter.
 */
var ContextualGroundingFilterType;
(function (ContextualGroundingFilterType) {
    /**
     * Grounding score represents the confidence that the model response is factually
     * correct and grounded in the source. If the model response has a lower score than
     * the defined threshold, the response will be blocked and the configured blocked
     * message will be returned to the user. A higher threshold level blocks more responses.
     */
    ContextualGroundingFilterType["GROUNDING"] = "GROUNDING";
    /**
     * Relevance score represents the confidence that the model response is relevant
     * to the user's query. If the model response has a lower score than the defined
     * threshold, the response will be blocked and the configured blocked message will
     * be returned to the user. A higher threshold level blocks more responses.
     */
    ContextualGroundingFilterType["RELEVANCE"] = "RELEVANCE";
})(ContextualGroundingFilterType || (exports.ContextualGroundingFilterType = ContextualGroundingFilterType = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3VhcmRyYWlsLWZpbHRlcnMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJndWFyZHJhaWwtZmlsdGVycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUVBOztHQUVHO0FBQ0gsSUFBWSxlQWdCWDtBQWhCRCxXQUFZLGVBQWU7SUFDekI7OztPQUdHO0lBQ0gsa0NBQWUsQ0FBQTtJQUNmOzs7O09BSUc7SUFDSCwwQ0FBdUIsQ0FBQTtJQUN2Qjs7T0FFRztJQUNILGdDQUFhLENBQUE7QUFDZixDQUFDLEVBaEJXLGVBQWUsK0JBQWYsZUFBZSxRQWdCMUI7QUFFRDs7OEVBRThFO0FBQzlFLElBQVksVUFTWDtBQVRELFdBQVksVUFBVTtJQUNwQjs7T0FFRztJQUNILGlDQUFtQixDQUFBO0lBQ25COztPQUVHO0lBQ0gsbUNBQXFCLENBQUE7QUFDdkIsQ0FBQyxFQVRXLFVBQVUsMEJBQVYsVUFBVSxRQVNyQjtBQUVEOzsrRUFFK0U7QUFDL0U7Ozs7R0FJRztBQUNILElBQVkscUJBaUJYO0FBakJELFdBQVkscUJBQXFCO0lBQy9COztPQUVHO0lBQ0gsc0NBQWEsQ0FBQTtJQUNiOztPQUVHO0lBQ0gsb0NBQVcsQ0FBQTtJQUNYOztPQUVHO0lBQ0gsMENBQWlCLENBQUE7SUFDakI7O09BRUc7SUFDSCxzQ0FBYSxDQUFBO0FBQ2YsQ0FBQyxFQWpCVyxxQkFBcUIscUNBQXJCLHFCQUFxQixRQWlCaEM7QUFFRDs7R0FFRztBQUNILElBQVksWUFTWDtBQVRELFdBQVksWUFBWTtJQUN0Qjs7T0FFRztJQUNILDZCQUFhLENBQUE7SUFDYjs7T0FFRztJQUNILCtCQUFlLENBQUE7QUFDakIsQ0FBQyxFQVRXLFlBQVksNEJBQVosWUFBWSxRQVN2QjtBQUVEOztHQUVHO0FBQ0gsSUFBWSxpQkFtQ1g7QUFuQ0QsV0FBWSxpQkFBaUI7SUFDM0I7OztPQUdHO0lBQ0gsc0NBQWlCLENBQUE7SUFDakI7OztPQUdHO0lBQ0gsMENBQXFCLENBQUE7SUFDckI7Ozs7T0FJRztJQUNILGtDQUFhLENBQUE7SUFDYjs7OztPQUlHO0lBQ0gsd0NBQW1CLENBQUE7SUFDbkI7Ozs7T0FJRztJQUNILDhDQUF5QixDQUFBO0lBQ3pCOzs7O09BSUc7SUFDSCxvREFBK0IsQ0FBQTtBQUNqQyxDQUFDLEVBbkNXLGlCQUFpQixpQ0FBakIsaUJBQWlCLFFBbUM1QjtBQWtHRDs7R0FFRztBQUNILE1BQWEsS0FBSzs7SUFDaEI7O09BRUc7SUFDSSxNQUFNLENBQVUsZ0JBQWdCLEdBQUcsSUFBSSxLQUFLLENBQUM7UUFDbEQsSUFBSSxFQUFFLGtCQUFrQjtRQUN4QixVQUFVLEVBQ04sNkpBQTZKO1FBQ2pLLFFBQVEsRUFBRTtZQUNSLDBEQUEwRDtZQUMxRCw2Q0FBNkM7WUFDN0Msa0RBQWtEO1lBQ2xELCtDQUErQztZQUMvQyx1Q0FBdUM7U0FDeEM7UUFDRCxXQUFXLEVBQUUsZUFBZSxDQUFDLEtBQUs7UUFDbEMsWUFBWSxFQUFFLElBQUk7UUFDbEIsWUFBWSxFQUFFLGVBQWUsQ0FBQyxLQUFLO1FBQ25DLGFBQWEsRUFBRSxJQUFJO0tBQ3BCLENBQUMsQ0FBQztJQUVIOztPQUVHO0lBQ0ksTUFBTSxDQUFVLHFCQUFxQixHQUFHLElBQUksS0FBSyxDQUFDO1FBQ3ZELElBQUksRUFBRSx1QkFBdUI7UUFDN0IsVUFBVSxFQUNOLGtKQUFrSjtRQUN0SixRQUFRLEVBQUU7WUFDUix3REFBd0Q7WUFDeEQsdURBQXVEO1lBQ3ZELGtEQUFrRDtZQUNsRCxxRUFBcUU7WUFDckUsbUNBQW1DO1NBQ3BDO1FBQ0QsV0FBVyxFQUFFLGVBQWUsQ0FBQyxLQUFLO1FBQ2xDLFlBQVksRUFBRSxJQUFJO1FBQ2xCLFlBQVksRUFBRSxlQUFlLENBQUMsS0FBSztRQUNuQyxhQUFhLEVBQUUsSUFBSTtLQUNwQixDQUFDLENBQUM7SUFFSDs7T0FFRztJQUNJLE1BQU0sQ0FBVSxZQUFZLEdBQUcsSUFBSSxLQUFLLENBQUM7UUFDOUMsSUFBSSxFQUFFLGNBQWM7UUFDcEIsVUFBVSxFQUNOLDhJQUE4STtRQUNsSixRQUFRLEVBQUU7WUFDUiwrQ0FBK0M7WUFDL0Msb0RBQW9EO1lBQ3BELHdEQUF3RDtZQUN4RCxpREFBaUQ7WUFDakQsMkRBQTJEO1NBQzVEO1FBQ0QsV0FBVyxFQUFFLGVBQWUsQ0FBQyxLQUFLO1FBQ2xDLFlBQVksRUFBRSxJQUFJO1FBQ2xCLFlBQVksRUFBRSxlQUFlLENBQUMsS0FBSztRQUNuQyxhQUFhLEVBQUUsSUFBSTtLQUNwQixDQUFDLENBQUM7SUFFSDs7T0FFRztJQUNJLE1BQU0sQ0FBVSxjQUFjLEdBQUcsSUFBSSxLQUFLLENBQUM7UUFDaEQsSUFBSSxFQUFFLGdCQUFnQjtRQUN0QixVQUFVLEVBQ04sdUhBQXVIO1FBQzNILFFBQVEsRUFBRTtZQUNSLDJEQUEyRDtZQUMzRCwrQkFBK0I7WUFDL0IsNEJBQTRCO1lBQzVCLDBDQUEwQztZQUMxQyw0Q0FBNEM7U0FDN0M7UUFDRCxXQUFXLEVBQUUsZUFBZSxDQUFDLEtBQUs7UUFDbEMsWUFBWSxFQUFFLElBQUk7UUFDbEIsWUFBWSxFQUFFLGVBQWUsQ0FBQyxLQUFLO1FBQ25DLGFBQWEsRUFBRSxJQUFJO0tBQ3BCLENBQUMsQ0FBQztJQUVIOztPQUVHO0lBQ0ksTUFBTSxDQUFVLGdCQUFnQixHQUFHLElBQUksS0FBSyxDQUFDO1FBQ2xELElBQUksRUFBRSxrQkFBa0I7UUFDeEIsVUFBVSxFQUNOLGlJQUFpSTtRQUNySSxRQUFRLEVBQUU7WUFDUiw2QkFBNkI7WUFDN0IsNkNBQTZDO1lBQzdDLGlDQUFpQztZQUNqQyw2Q0FBNkM7WUFDN0MsaUNBQWlDO1NBQ2xDO1FBQ0QsV0FBVyxFQUFFLGVBQWUsQ0FBQyxLQUFLO1FBQ2xDLFlBQVksRUFBRSxJQUFJO1FBQ2xCLFlBQVksRUFBRSxlQUFlLENBQUMsS0FBSztRQUNuQyxhQUFhLEVBQUUsSUFBSTtLQUNwQixDQUFDLENBQUM7SUFFSDs7O09BR0c7SUFDSSxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQXVCOzs7Ozs7Ozs7O1FBQzFDLE9BQU8sSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDekI7SUFFRDs7T0FFRztJQUNNLElBQUksQ0FBUztJQUN0Qjs7T0FFRztJQUNNLFVBQVUsQ0FBUztJQUM1Qjs7T0FFRztJQUNNLFFBQVEsQ0FBWTtJQUM3Qjs7O09BR0c7SUFDTSxXQUFXLENBQW1CO0lBQ3ZDOzs7T0FHRztJQUNNLFlBQVksQ0FBVztJQUNoQzs7O09BR0c7SUFDTSxZQUFZLENBQW1CO0lBQ3hDOzs7T0FHRztJQUNNLGFBQWEsQ0FBVztJQUVqQyxZQUFzQixLQUF1Qjs7Ozs7OytDQTlJbEMsS0FBSzs7OztRQStJZCxzQ0FBc0M7UUFDdEMsTUFBTSx1QkFBdUIsR0FBdUM7WUFDbEU7Z0JBQ0UsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQztnQkFDdEQsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLGdEQUFnRDthQUNoRTtZQUNEO2dCQUNFLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxHQUFHO2dCQUN2RCxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsc0RBQXNEO2FBQ3RFO1NBQ0YsQ0FBQztRQUVGLGlGQUFpRjtRQUNqRixtQ0FBbUM7UUFDbkMsS0FBSyxNQUFNLElBQUksSUFBSSx1QkFBdUIsRUFBRSxDQUFDO1lBQzNDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUMxQixNQUFNLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUN2QyxDQUFDO1FBQ0gsQ0FBQztRQUVELElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQztRQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQyxVQUFVLENBQUM7UUFDbkMsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDO1FBQy9CLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQztRQUNyQyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUM7UUFDdkMsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUMsWUFBWSxDQUFDO1FBQ3ZDLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQztLQUMxQzs7QUExS0gsc0JBMktDO0FBbUNEOztHQUVHO0FBQ0gsSUFBWSxxQkFLWDtBQUxELFdBQVkscUJBQXFCO0lBQy9COztPQUVHO0lBQ0gsZ0RBQXVCLENBQUE7QUFDekIsQ0FBQyxFQUxXLHFCQUFxQixxQ0FBckIscUJBQXFCLFFBS2hDO0FBaUNEOztpRkFFaUY7QUFDakY7O0dBRUc7QUFDSCxNQUFzQixPQUFPOztJQUMzQjs7T0FFRztJQUNhLEtBQUssQ0FBUztJQUU5Qjs7T0FFRztJQUNILFlBQXNCLEtBQWE7UUFDakMsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7S0FDcEI7SUFFRDs7O09BR0c7SUFDSCxRQUFRLEtBQWEsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7O0FBakIzQywwQkFrQkM7QUFFRDs7R0FFRztBQUNILE1BQWEsY0FBZSxTQUFRLE9BQU87O0lBQ3pDOzs7O09BSUc7SUFDSSxNQUFNLENBQVUsT0FBTyxHQUFHLElBQUksY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQy9EOztPQUVHO0lBQ0ksTUFBTSxDQUFVLEdBQUcsR0FBRyxJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN2RDs7OztPQUlHO0lBQ0ksTUFBTSxDQUFVLFNBQVMsR0FBRyxJQUFJLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUNuRTs7T0FFRztJQUNJLE1BQU0sQ0FBVSxLQUFLLEdBQUcsSUFBSSxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDM0Q7Ozs7O09BS0c7SUFDSSxNQUFNLENBQVUsYUFBYSxHQUFHLElBQUksY0FBYyxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQzNFOzs7T0FHRztJQUNJLE1BQU0sQ0FBVSxJQUFJLEdBQUcsSUFBSSxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDekQ7O09BRUc7SUFDSSxNQUFNLENBQVUsUUFBUSxHQUFHLElBQUksY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ2pFOztPQUVHO0lBQ0ksTUFBTSxDQUFVLEtBQUssR0FBRyxJQUFJLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUMzRDs7O09BR0c7SUFDSSxNQUFNLENBQVUsUUFBUSxHQUFHLElBQUksY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ2pFOzs7O09BSUc7SUFDSSxNQUFNLENBQVUsNkJBQTZCLEdBQUcsSUFBSSxjQUFjLENBQUMsK0JBQStCLENBQUMsQ0FBQztJQUUzRyxZQUFvQixLQUFhLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7O0FBckR0RCx3Q0FzREM7QUFFRDs7R0FFRztBQUNILE1BQWEsY0FBZSxTQUFRLE9BQU87O0lBQ3pDOzs7O09BSUc7SUFDSSxNQUFNLENBQVUscUJBQXFCLEdBQUcsSUFBSSxjQUFjLENBQUMsdUJBQXVCLENBQUMsQ0FBQztJQUMzRjs7OztPQUlHO0lBQ0ksTUFBTSxDQUFVLHdCQUF3QixHQUFHLElBQUksY0FBYyxDQUFDLDBCQUEwQixDQUFDLENBQUM7SUFDakc7OztPQUdHO0lBQ0ksTUFBTSxDQUFVLHdCQUF3QixHQUFHLElBQUksY0FBYyxDQUFDLDBCQUEwQixDQUFDLENBQUM7SUFDakc7OztPQUdHO0lBQ0ksTUFBTSxDQUFVLEdBQUcsR0FBRyxJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN2RDs7OztPQUlHO0lBQ0ksTUFBTSxDQUFVLFVBQVUsR0FBRyxJQUFJLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUNyRTs7T0FFRztJQUNJLE1BQU0sQ0FBVSxpQ0FBaUMsR0FBRyxJQUFJLGNBQWMsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO0lBRW5ILFlBQW9CLEtBQWEsSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTs7QUFsQ3RELHdDQW1DQztBQUVEOztHQUVHO0FBQ0gsTUFBYSw0QkFBNkIsU0FBUSxPQUFPOztJQUN2RDs7T0FFRztJQUNJLE1BQU0sQ0FBVSxHQUFHLEdBQUcsSUFBSSw0QkFBNEIsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNyRTs7T0FFRztJQUNJLE1BQU0sQ0FBVSxVQUFVLEdBQUcsSUFBSSw0QkFBNEIsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUNuRjs7T0FFRztJQUNJLE1BQU0sQ0FBVSxXQUFXLEdBQUcsSUFBSSw0QkFBNEIsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNyRjs7OztPQUlHO0lBQ0ksTUFBTSxDQUFVLGNBQWMsR0FBRyxJQUFJLDRCQUE0QixDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDM0Y7Ozs7T0FJRztJQUNJLE1BQU0sQ0FBVSxjQUFjLEdBQUcsSUFBSSw0QkFBNEIsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBRTNGLFlBQW9CLEtBQWEsSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTs7QUExQnRELG9FQTJCQztBQUVEOztHQUVHO0FBQ0gsTUFBYSxrQkFBbUIsU0FBUSxPQUFPOztJQUM3Qzs7T0FFRztJQUNJLE1BQU0sQ0FBVSxzQkFBc0IsR0FBRyxJQUFJLGtCQUFrQixDQUFDLHdCQUF3QixDQUFDLENBQUM7SUFDakc7O09BRUc7SUFDSSxNQUFNLENBQVUsc0JBQXNCLEdBQUcsSUFBSSxrQkFBa0IsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBQ2pHOzs7T0FHRztJQUNJLE1BQU0sQ0FBVSx1Q0FBdUMsR0FBRyxJQUFJLGtCQUFrQixDQUFDLHlDQUF5QyxDQUFDLENBQUM7SUFDbkk7O09BRUc7SUFDSSxNQUFNLENBQVUsa0JBQWtCLEdBQUcsSUFBSSxrQkFBa0IsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ3pGOzs7T0FHRztJQUNJLE1BQU0sQ0FBVSx5QkFBeUIsR0FBRyxJQUFJLGtCQUFrQixDQUFDLDJCQUEyQixDQUFDLENBQUM7SUFFdkcsWUFBb0IsS0FBYSxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFOztBQXhCdEQsZ0RBeUJDO0FBRUQ7O0dBRUc7QUFDSCxNQUFhLHFCQUFzQixTQUFRLE9BQU87O0lBQ2hEOzs7T0FHRztJQUNJLE1BQU0sQ0FBVSxnQkFBZ0IsR0FBRyxJQUFJLHFCQUFxQixDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDeEY7OztPQUdHO0lBQ0ksTUFBTSxDQUFVLDBCQUEwQixHQUFHLElBQUkscUJBQXFCLENBQUMsNEJBQTRCLENBQUMsQ0FBQztJQUU1RyxZQUFvQixLQUFhLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7O0FBWnRELHNEQWFDO0FBRUQ7O0dBRUc7QUFDSCxNQUFhLGlCQUFrQixTQUFRLE9BQU87O0lBQzVDOztPQUVHO0lBQ0ksTUFBTSxDQUFVLGlDQUFpQyxHQUFHLElBQUksaUJBQWlCLENBQUMsbUNBQW1DLENBQUMsQ0FBQztJQUN0SDs7OztPQUlHO0lBQ0ksTUFBTSxDQUFVLDRCQUE0QixHQUFHLElBQUksaUJBQWlCLENBQUMsOEJBQThCLENBQUMsQ0FBQztJQUM1Rzs7O09BR0c7SUFDSSxNQUFNLENBQVUsbUNBQW1DLEdBQUcsSUFBSSxpQkFBaUIsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO0lBRTFILFlBQW9CLEtBQWEsSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTs7QUFqQnRELDhDQWtCQztBQW1GRDs7aUZBRWlGO0FBQ2pGOztHQUVHO0FBQ0gsSUFBWSw2QkFlWDtBQWZELFdBQVksNkJBQTZCO0lBQ3ZDOzs7OztPQUtHO0lBQ0gsd0RBQXVCLENBQUE7SUFDdkI7Ozs7O09BS0c7SUFDSCx3REFBdUIsQ0FBQTtBQUN6QixDQUFDLEVBZlcsNkJBQTZCLDZDQUE3Qiw2QkFBNkIsUUFleEMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFZhbGlkYXRpb25SdWxlIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvaGVscGVycy1pbnRlcm5hbCc7XG5cbi8qKlxuICogR3VhcmRyYWlsIGFjdGlvbiB3aGVuIGEgc2Vuc2l0aXZlIGVudGl0eSBpcyBkZXRlY3RlZC5cbiAqL1xuZXhwb3J0IGVudW0gR3VhcmRyYWlsQWN0aW9uIHtcbiAgLyoqXG4gICAqIElmIHNlbnNpdGl2ZSBpbmZvcm1hdGlvbiBpcyBkZXRlY3RlZCBpbiB0aGUgcHJvbXB0IG9yIHJlc3BvbnNlLCB0aGUgZ3VhcmRyYWlsXG4gICAqIGJsb2NrcyBhbGwgdGhlIGNvbnRlbnQgYW5kIHJldHVybnMgYSBtZXNzYWdlIHRoYXQgeW91IGNvbmZpZ3VyZS5cbiAgICovXG4gIEJMT0NLID0gJ0JMT0NLJyxcbiAgLyoqXG4gICAqIElmIHNlbnNpdGl2ZSBpbmZvcm1hdGlvbiBpcyBkZXRlY3RlZCBpbiB0aGUgbW9kZWwgcmVzcG9uc2UsIHRoZSBndWFyZHJhaWwgbWFza3NcbiAgICogaXQgd2l0aCBhbiBpZGVudGlmaWVyLCB0aGUgc2Vuc2l0aXZlIGluZm9ybWF0aW9uIGlzIG1hc2tlZCBhbmQgcmVwbGFjZWQgd2l0aFxuICAgKiBpZGVudGlmaWVyIHRhZ3MgKGZvciBleGFtcGxlOiBbTkFNRS0xXSwgW05BTUUtMl0sIFtFTUFJTC0xXSwgZXRjLikuXG4gICAqL1xuICBBTk9OWU1JWkUgPSAnQU5PTllNSVpFJyxcbiAgLyoqXG4gICAqIERvIG5vdCB0YWtlIGFueSBhY3Rpb24uXG4gICAqL1xuICBOT05FID0gJ05PTkUnLFxufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVElFUiBDT05GSUdcbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuZXhwb3J0IGVudW0gVGllckNvbmZpZyB7XG4gIC8qKlxuICAgKiBQcm92aWRlcyBlc3RhYmxpc2hlZCBndWFyZHJhaWxzIGZ1bmN0aW9uYWxpdHkgc3VwcG9ydGluZyBFbmdsaXNoLCBGcmVuY2gsIGFuZCBTcGFuaXNoIGxhbmd1YWdlcy5cbiAgICovXG4gIENMQVNTSUMgPSAnQ0xBU1NJQycsXG4gIC8qKlxuICAgKiBQcm92aWRlcyBhIG1vcmUgcm9idXN0IHNvbHV0aW9uIHRoYW4gdGhlIENMQVNTSUMgdGllciBhbmQgaGFzIG1vcmUgY29tcHJlaGVuc2l2ZSBsYW5ndWFnZSBzdXBwb3J0LiBUaGlzIHRpZXIgcmVxdWlyZXMgdGhhdCB5b3VyIGd1YXJkcmFpbCB1c2UgY3Jvc3MtUmVnaW9uIGluZmVyZW5jZS5cbiAgICovXG4gIFNUQU5EQVJEID0gJ1NUQU5EQVJEJyxcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgIENPTlRFTlQgRklMVEVSU1xuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBUaGUgc3RyZW5ndGggb2YgdGhlIGNvbnRlbnQgZmlsdGVyLiBBcyB5b3UgaW5jcmVhc2UgdGhlIGZpbHRlciBzdHJlbmd0aCxcbiAqIHRoZSBsaWtlbGlob29kIG9mIGZpbHRlcmluZyBoYXJtZnVsIGNvbnRlbnQgaW5jcmVhc2VzIGFuZCB0aGUgcHJvYmFiaWxpdHlcbiAqIG9mIHNlZWluZyBoYXJtZnVsIGNvbnRlbnQgaW4geW91ciBhcHBsaWNhdGlvbiByZWR1Y2VzLlxuICovXG5leHBvcnQgZW51bSBDb250ZW50RmlsdGVyU3RyZW5ndGgge1xuICAvKipcbiAgICogTm8gY29udGVudCBmaWx0ZXJpbmcgYXBwbGllZC5cbiAgICovXG4gIE5PTkUgPSAnTk9ORScsXG4gIC8qKlxuICAgKiBMb3cgc3RyZW5ndGggY29udGVudCBmaWx0ZXJpbmcgLSBtaW5pbWFsIGZpbHRlcmluZyBvZiBoYXJtZnVsIGNvbnRlbnQuXG4gICAqL1xuICBMT1cgPSAnTE9XJyxcbiAgLyoqXG4gICAqIE1lZGl1bSBzdHJlbmd0aCBjb250ZW50IGZpbHRlcmluZyAtIGJhbGFuY2VkIGZpbHRlcmluZyBvZiBoYXJtZnVsIGNvbnRlbnQuXG4gICAqL1xuICBNRURJVU0gPSAnTUVESVVNJyxcbiAgLyoqXG4gICAqIEhpZ2ggc3RyZW5ndGggY29udGVudCBmaWx0ZXJpbmcgLSBhZ2dyZXNzaXZlIGZpbHRlcmluZyBvZiBoYXJtZnVsIGNvbnRlbnQuXG4gICAqL1xuICBISUdIID0gJ0hJR0gnLFxufVxuXG4vKipcbiAqIFRoZSB0eXBlIG9mIG1vZGFsaXR5IHRoYXQgY2FuIGJlIHVzZWQgaW4gY29udGVudCBmaWx0ZXJzLlxuICovXG5leHBvcnQgZW51bSBNb2RhbGl0eVR5cGUge1xuICAvKipcbiAgICogVGV4dCBtb2RhbGl0eSBmb3IgY29udGVudCBmaWx0ZXJzLlxuICAgKi9cbiAgVEVYVCA9ICdURVhUJyxcbiAgLyoqXG4gICAqIEltYWdlIG1vZGFsaXR5IGZvciBjb250ZW50IGZpbHRlcnMuXG4gICAqL1xuICBJTUFHRSA9ICdJTUFHRScsXG59XG5cbi8qKlxuICogVGhlIHR5cGUgb2YgaGFybWZ1bCBjYXRlZ29yeSB1c2FibGUgaW4gYSBjb250ZW50IGZpbHRlci5cbiAqL1xuZXhwb3J0IGVudW0gQ29udGVudEZpbHRlclR5cGUge1xuICAvKipcbiAgICogRGVzY3JpYmVzIGlucHV0IHByb21wdHMgYW5kIG1vZGVsIHJlc3BvbnNlcyB0aGF0IGluZGljYXRlcyBzZXh1YWwgaW50ZXJlc3QsIGFjdGl2aXR5LFxuICAgKiBvciBhcm91c2FsIHVzaW5nIGRpcmVjdCBvciBpbmRpcmVjdCByZWZlcmVuY2VzIHRvIGJvZHkgcGFydHMsIHBoeXNpY2FsIHRyYWl0cywgb3Igc2V4LlxuICAgKi9cbiAgU0VYVUFMID0gJ1NFWFVBTCcsXG4gIC8qKlxuICAgKiBEZXNjcmliZXMgaW5wdXQgcHJvbXB0cyBhbmQgbW9kZWwgcmVzcG9uc2VzIHRoYXQgaW5jbHVkZXMgZ2xvcmlmaWNhdGlvbiBvZiBvciB0aHJlYXRzXG4gICAqIHRvIGluZmxpY3QgcGh5c2ljYWwgcGFpbiwgaHVydCwgb3IgaW5qdXJ5IHRvd2FyZCBhIHBlcnNvbiwgZ3JvdXAgb3IgdGhpbmcuXG4gICAqL1xuICBWSU9MRU5DRSA9ICdWSU9MRU5DRScsXG4gIC8qKlxuICAgKiBEZXNjcmliZXMgaW5wdXQgcHJvbXB0cyBhbmQgbW9kZWwgcmVzcG9uc2VzIHRoYXQgZGlzY3JpbWluYXRlLCBjcml0aWNpemUsIGluc3VsdCxcbiAgICogZGVub3VuY2UsIG9yIGRlaHVtYW5pemUgYSBwZXJzb24gb3IgZ3JvdXAgb24gdGhlIGJhc2lzIG9mIGFuIGlkZW50aXR5IChzdWNoIGFzIHJhY2UsXG4gICAqIGV0aG5pY2l0eSwgZ2VuZGVyLCByZWxpZ2lvbiwgc2V4dWFsIG9yaWVudGF0aW9uLCBhYmlsaXR5LCBhbmQgbmF0aW9uYWwgb3JpZ2luKS5cbiAgICovXG4gIEhBVEUgPSAnSEFURScsXG4gIC8qKlxuICAgKiBEZXNjcmliZXMgaW5wdXQgcHJvbXB0cyBhbmQgbW9kZWwgcmVzcG9uc2VzIHRoYXQgaW5jbHVkZXMgZGVtZWFuaW5nLCBodW1pbGlhdGluZyxcbiAgICogbW9ja2luZywgaW5zdWx0aW5nLCBvciBiZWxpdHRsaW5nIGxhbmd1YWdlLiBUaGlzIHR5cGUgb2YgbGFuZ3VhZ2UgaXMgYWxzbyBsYWJlbGVkXG4gICAqIGFzIGJ1bGx5aW5nLlxuICAgKi9cbiAgSU5TVUxUUyA9ICdJTlNVTFRTJyxcbiAgLyoqXG4gICAqIERlc2NyaWJlcyBpbnB1dCBwcm9tcHRzIGFuZCBtb2RlbCByZXNwb25zZXMgdGhhdCBzZWVrcyBvciBwcm92aWRlcyBpbmZvcm1hdGlvblxuICAgKiBhYm91dCBlbmdhZ2luZyBpbiBtaXNjb25kdWN0IGFjdGl2aXR5LCBvciBoYXJtaW5nLCBkZWZyYXVkaW5nLCBvciB0YWtpbmcgYWR2YW50YWdlXG4gICAqIG9mIGEgcGVyc29uLCBncm91cCBvciBpbnN0aXR1dGlvbi5cbiAgICovXG4gIE1JU0NPTkRVQ1QgPSAnTUlTQ09ORFVDVCcsXG4gIC8qKlxuICAgKiBFbmFibGUgdG8gZGV0ZWN0IGFuZCBibG9jayB1c2VyIGlucHV0cyBhdHRlbXB0aW5nIHRvIG92ZXJyaWRlIHN5c3RlbSBpbnN0cnVjdGlvbnMuXG4gICAqIFRvIGF2b2lkIG1pc2NsYXNzaWZ5aW5nIHN5c3RlbSBwcm9tcHRzIGFzIGEgcHJvbXB0IGF0dGFjayBhbmQgZW5zdXJlIHRoYXQgdGhlIGZpbHRlcnNcbiAgICogYXJlIHNlbGVjdGl2ZWx5IGFwcGxpZWQgdG8gdXNlciBpbnB1dHMsIHVzZSBpbnB1dCB0YWdnaW5nLlxuICAgKi9cbiAgUFJPTVBUX0FUVEFDSyA9ICdQUk9NUFRfQVRUQUNLJyxcbn1cblxuLyoqXG4gKiBJbnRlcmZhY2UgdG8gZGVjbGFyZSBhIGNvbnRlbnQgZmlsdGVyLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnRlbnRGaWx0ZXIge1xuICAvKipcbiAgICogVGhlIHR5cGUgb2YgaGFybWZ1bCBjYXRlZ29yeSB0aGF0IHRoZSBjb250ZW50IGZpbHRlciBpcyBhcHBsaWVkIHRvXG4gICAqL1xuICByZWFkb25seSB0eXBlOiBDb250ZW50RmlsdGVyVHlwZTtcbiAgLyoqXG4gICAqIFRoZSBzdHJlbmd0aCBvZiB0aGUgY29udGVudCBmaWx0ZXIgdG8gYXBwbHkgdG8gcHJvbXB0cyAvIHVzZXIgaW5wdXQuXG4gICAqL1xuICByZWFkb25seSBpbnB1dFN0cmVuZ3RoOiBDb250ZW50RmlsdGVyU3RyZW5ndGg7XG4gIC8qKlxuICAgKiBUaGUgc3RyZW5ndGggb2YgdGhlIGNvbnRlbnQgZmlsdGVyIHRvIGFwcGx5IHRvIG1vZGVsIHJlc3BvbnNlcy5cbiAgICovXG4gIHJlYWRvbmx5IG91dHB1dFN0cmVuZ3RoOiBDb250ZW50RmlsdGVyU3RyZW5ndGg7XG4gIC8qKlxuICAgKiBUaGUgYWN0aW9uIHRvIHRha2Ugd2hlbiBjb250ZW50IGlzIGRldGVjdGVkIGluIHRoZSBpbnB1dC5cbiAgICogQGRlZmF1bHQgR3VhcmRyYWlsQWN0aW9uLkJMT0NLXG4gICAqL1xuICByZWFkb25seSBpbnB1dEFjdGlvbj86IEd1YXJkcmFpbEFjdGlvbjtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIGNvbnRlbnQgZmlsdGVyIGlzIGVuYWJsZWQgZm9yIGlucHV0LlxuICAgKiBAZGVmYXVsdCB0cnVlXG4gICAqL1xuICByZWFkb25seSBpbnB1dEVuYWJsZWQ/OiBib29sZWFuO1xuICAvKipcbiAgICogVGhlIGFjdGlvbiB0byB0YWtlIHdoZW4gY29udGVudCBpcyBkZXRlY3RlZCBpbiB0aGUgb3V0cHV0LlxuICAgKiBAZGVmYXVsdCBHdWFyZHJhaWxBY3Rpb24uQkxPQ0tcbiAgICovXG4gIHJlYWRvbmx5IG91dHB1dEFjdGlvbj86IEd1YXJkcmFpbEFjdGlvbjtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIGNvbnRlbnQgZmlsdGVyIGlzIGVuYWJsZWQgZm9yIG91dHB1dC5cbiAgICogQGRlZmF1bHQgdHJ1ZVxuICAgKi9cbiAgcmVhZG9ubHkgb3V0cHV0RW5hYmxlZD86IGJvb2xlYW47XG4gIC8qKlxuICAgKiBUaGUgaW5wdXQgbW9kYWxpdGllcyB0byBhcHBseSB0aGUgY29udGVudCBmaWx0ZXIgdG8uXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIEFwcGxpZXMgdG8gdGV4dCBtb2RhbGl0eVxuICAgKi9cbiAgcmVhZG9ubHkgaW5wdXRNb2RhbGl0aWVzPzogTW9kYWxpdHlUeXBlW107XG4gIC8qKlxuICAgKiBUaGUgb3V0cHV0IG1vZGFsaXRpZXMgdG8gYXBwbHkgdGhlIGNvbnRlbnQgZmlsdGVyIHRvLlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBBcHBsaWVzIHRvIHRleHQgbW9kYWxpdHlcbiAgICovXG4gIHJlYWRvbmx5IG91dHB1dE1vZGFsaXRpZXM/OiBNb2RhbGl0eVR5cGVbXTtcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRPUElDIEZJTFRFUlNcbiAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBJbnRlcmZhY2UgZm9yIGNyZWF0aW5nIGEgY3VzdG9tIFRvcGljXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ3VzdG9tVG9waWNQcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgdG9waWMgdG8gZGVueS5cbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcbiAgLyoqXG4gICAqIFByb3ZpZGUgYSBjbGVhciBkZWZpbml0aW9uIHRvIGRldGVjdCBhbmQgYmxvY2sgdXNlciBpbnB1dHMgYW5kIEZNIHJlc3BvbnNlc1xuICAgKiB0aGF0IGZhbGwgaW50byB0aGlzIHRvcGljLiBBdm9pZCBzdGFydGluZyB3aXRoIFwiZG9uJ3RcIi5cbiAgICogQGV4YW1wbGUgYEludmVzdG1lbnQgYWR2aWNlIHJlZmVycyB0byBpbnF1aXJpZXMsIGd1aWRhbmNlLCBvciByZWNvbW1lbmRhdGlvbnNcbiAgICogcmVnYXJkaW5nIHRoZSBtYW5hZ2VtZW50IG9yIGFsbG9jYXRpb24gb2YgZnVuZHMgb3IgYXNzZXRzIHdpdGggdGhlIGdvYWwgb2ZcbiAgICogZ2VuZXJhdGluZyByZXR1cm5zIG9yIGFjaGlldmluZyBzcGVjaWZpYyBmaW5hbmNpYWwgb2JqZWN0aXZlcy5gXG4gICAqL1xuICByZWFkb25seSBkZWZpbml0aW9uOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBSZXByZXNlbnRhdGl2ZSBwaHJhc2VzIHRoYXQgcmVmZXIgdG8gdGhlIHRvcGljLiBUaGVzZSBwaHJhc2VzIGNhbiByZXByZXNlbnRcbiAgICogYSB1c2VyIGlucHV0IG9yIGEgbW9kZWwgcmVzcG9uc2UuIEFkZCBiZXR3ZWVuIDEgYW5kIDEwMCBwaHJhc2VzLCB1cCB0byAxMDAgY2hhcmFjdGVyc1xuICAgKiBlYWNoLlxuICAgKiBAZXhhbXBsZSBcIldoZXJlIHNob3VsZCBJIGludmVzdCBteSBtb25leT9cIlxuICAgKi9cbiAgcmVhZG9ubHkgZXhhbXBsZXM6IHN0cmluZ1tdO1xuICAvKipcbiAgICogVGhlIGFjdGlvbiB0byB0YWtlIHdoZW4gYSB0b3BpYyBpcyBkZXRlY3RlZCBpbiB0aGUgaW5wdXQuXG4gICAqIEBkZWZhdWx0IEd1YXJkcmFpbEFjdGlvbi5CTE9DS1xuICAgKi9cbiAgcmVhZG9ubHkgaW5wdXRBY3Rpb24/OiBHdWFyZHJhaWxBY3Rpb247XG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoZSB0b3BpYyBmaWx0ZXIgaXMgZW5hYmxlZCBmb3IgaW5wdXQuXG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICovXG4gIHJlYWRvbmx5IGlucHV0RW5hYmxlZD86IGJvb2xlYW47XG4gIC8qKlxuICAgKiBUaGUgYWN0aW9uIHRvIHRha2Ugd2hlbiBhIHRvcGljIGlzIGRldGVjdGVkIGluIHRoZSBvdXRwdXQuXG4gICAqIEBkZWZhdWx0IEd1YXJkcmFpbEFjdGlvbi5CTE9DS1xuICAgKi9cbiAgcmVhZG9ubHkgb3V0cHV0QWN0aW9uPzogR3VhcmRyYWlsQWN0aW9uO1xuICAvKipcbiAgICogV2hldGhlciB0aGUgdG9waWMgZmlsdGVyIGlzIGVuYWJsZWQgZm9yIG91dHB1dC5cbiAgICogQGRlZmF1bHQgdHJ1ZVxuICAgKi9cbiAgcmVhZG9ubHkgb3V0cHV0RW5hYmxlZD86IGJvb2xlYW47XG59XG5cbi8qKlxuICogUmVwcmVzZW50cyBwcmVkZWZpbmVkIHRvcGljcyB0aGF0IGNhbiBiZSB1c2VkIHRvIGZpbHRlciBjb250ZW50LlxuICovXG5leHBvcnQgY2xhc3MgVG9waWMge1xuICAvKipcbiAgICogRmlsdGVyIGZvciBmaW5hbmNpYWwgYWR2aWNlIGFuZCBpbnZlc3RtZW50IHJlY29tbWVuZGF0aW9ucy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgRklOQU5DSUFMX0FEVklDRSA9IG5ldyBUb3BpYyh7XG4gICAgbmFtZTogJ0ZpbmFuY2lhbF9BZHZpY2UnLFxuICAgIGRlZmluaXRpb246XG4gICAgICAgIFwiJ0Rpc2N1c3Npb25zIHRoYXQgaW52b2x2ZSBwcm92aWRpbmcgZ3VpZGFuY2UsIHJlY29tbWVuZGF0aW9ucywgb3Igc3VnZ2VzdGlvbnMgcmVsYXRlZCB0byBtYW5hZ2luZywgaW52ZXN0aW5nLCBvciBoYW5kbGluZyBmaW5hbmNlcywgaW52ZXN0bWVudHMsIG9yIGFzc2V0cy5cIixcbiAgICBleGFtcGxlczogW1xuICAgICAgJ0NhbiB5b3Ugc3VnZ2VzdCBzb21lIGdvb2Qgc3RvY2tzIHRvIGludmVzdCBpbiByaWdodCBub3c/JyxcbiAgICAgIFwiV2hhdCdzIHRoZSBiZXN0IHdheSB0byBzYXZlIGZvciByZXRpcmVtZW50P1wiLFxuICAgICAgJ1Nob3VsZCBJIHB1dCBteSBtb25leSBpbiBhIGhpZ2gtcmlzayBpbnZlc3RtZW50PycsXG4gICAgICAnSG93IGNhbiBJIG1heGltaXplIG15IHJldHVybnMgb24gaW52ZXN0bWVudHM/JyxcbiAgICAgICdJcyBpdCBhIGdvb2QgdGltZSB0byBidXkgcmVhbCBlc3RhdGU/JyxcbiAgICBdLFxuICAgIGlucHV0QWN0aW9uOiBHdWFyZHJhaWxBY3Rpb24uQkxPQ0ssXG4gICAgaW5wdXRFbmFibGVkOiB0cnVlLFxuICAgIG91dHB1dEFjdGlvbjogR3VhcmRyYWlsQWN0aW9uLkJMT0NLLFxuICAgIG91dHB1dEVuYWJsZWQ6IHRydWUsXG4gIH0pO1xuXG4gIC8qKlxuICAgKiBGaWx0ZXIgZm9yIGluYXBwcm9wcmlhdGUgb3IgZXhwbGljaXQgY29udGVudC5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgSU5BUFBST1BSSUFURV9DT05URU5UID0gbmV3IFRvcGljKHtcbiAgICBuYW1lOiAnSW5hcHByb3ByaWF0ZV9Db250ZW50JyxcbiAgICBkZWZpbml0aW9uOlxuICAgICAgICAnQ29udmVyc2F0aW9ucyB0aGF0IGV4cHJlc3Mgdmlld3MsIG9waW5pb25zLCBvciBlbmRvcnNlbWVudHMgcmVsYXRlZCB0byBwb2xpdGljYWwgcGFydGllcywgcG9saXRpY2FsIGlkZW9sb2dpZXMsIGVsZWN0aW9ucywgb3IgcG9saXRpY2FsIGZpZ3VyZXMuJyxcbiAgICBleGFtcGxlczogW1xuICAgICAgXCJXaGF0J3MgeW91ciBzdGFuY2Ugb24gdGhlIGN1cnJlbnQgZ292ZXJubWVudCBwb2xpY2llcz9cIixcbiAgICAgICdEbyB5b3Ugc3VwcG9ydCBwYXJ0eSBYIG9yIFkgaW4gdGhlIHVwY29taW5nIGVsZWN0aW9uPycsXG4gICAgICAnQ2FuIHlvdSB0ZWxsIG1lIHdoaWNoIHBvbGl0aWNhbCBwYXJ0eSBpcyBiZXR0ZXI/JyxcbiAgICAgICdXaGF0IGRvIHlvdSB0aGluayBhYm91dCB0aGUgbmV3IHBvbGljeSBpbnRyb2R1Y2VkIGJ5IHRoZSBwcmVzaWRlbnQ/JyxcbiAgICAgICdTaG91bGQgSSB2b3RlIGZvciB0aGlzIGNhbmRpZGF0ZT8nLFxuICAgIF0sXG4gICAgaW5wdXRBY3Rpb246IEd1YXJkcmFpbEFjdGlvbi5CTE9DSyxcbiAgICBpbnB1dEVuYWJsZWQ6IHRydWUsXG4gICAgb3V0cHV0QWN0aW9uOiBHdWFyZHJhaWxBY3Rpb24uQkxPQ0ssXG4gICAgb3V0cHV0RW5hYmxlZDogdHJ1ZSxcbiAgfSk7XG5cbiAgLyoqXG4gICAqIEZpbHRlciBmb3IgbGVnYWwgYWR2aWNlIGFuZCByZWNvbW1lbmRhdGlvbnMuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IExFR0FMX0FEVklDRSA9IG5ldyBUb3BpYyh7XG4gICAgbmFtZTogJ0xlZ2FsX0FkdmljZScsXG4gICAgZGVmaW5pdGlvbjpcbiAgICAgICAgJ1Byb3ZpZGluZyByZWNvbW1lbmRhdGlvbnMsIGRpYWdub3NpcywgdHJlYXRtZW50IG9wdGlvbnMsIG9yIGd1aWRhbmNlIG9uIG1lZGljYWwgY29uZGl0aW9ucywgc3ltcHRvbXMsIG1lZGljYXRpb25zLCBvciBoZWFsdGgtcmVsYXRlZCBpc3N1ZXMuJyxcbiAgICBleGFtcGxlczogW1xuICAgICAgJ1doYXQgc2hvdWxkIEkgZG8gdG8gdHJlYXQgYSBwZXJzaXN0ZW50IGNvdWdoPycsXG4gICAgICAnQ2FuIHlvdSByZWNvbW1lbmQgc29tZSBtZWRpY2F0aW9uIGZvciBteSBoZWFkYWNoZT8nLFxuICAgICAgJ1doYXQgYXJlIHRoZSBzeW1wdG9tcyBvZiBhIHNwZWNpZmljIG1lZGljYWwgY29uZGl0aW9uPycsXG4gICAgICAnSXMgdGhpcyBkcnVnIGVmZmVjdGl2ZSBmb3IgdHJlYXRpbmcgbXkgaWxsbmVzcz8nLFxuICAgICAgXCJEbyBJIG5lZWQgdG8gc2VlIGEgZG9jdG9yIGZvciB0aGlzIHBhaW4gSSdtIGV4cGVyaWVuY2luZz9cIixcbiAgICBdLFxuICAgIGlucHV0QWN0aW9uOiBHdWFyZHJhaWxBY3Rpb24uQkxPQ0ssXG4gICAgaW5wdXRFbmFibGVkOiB0cnVlLFxuICAgIG91dHB1dEFjdGlvbjogR3VhcmRyYWlsQWN0aW9uLkJMT0NLLFxuICAgIG91dHB1dEVuYWJsZWQ6IHRydWUsXG4gIH0pO1xuXG4gIC8qKlxuICAgKiBGaWx0ZXIgZm9yIG1lZGljYWwgYWR2aWNlIGFuZCBoZWFsdGggcmVjb21tZW5kYXRpb25zLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBNRURJQ0FMX0FEVklDRSA9IG5ldyBUb3BpYyh7XG4gICAgbmFtZTogJ01lZGljYWxfQWR2aWNlJyxcbiAgICBkZWZpbml0aW9uOlxuICAgICAgICAnQW55IGRpc2N1c3Npb25zIG9yIHJlZmVyZW5jZXMgdGhhdCBpbmNsdWRlIGhhdGUgc3BlZWNoLCBkaXNjcmltaW5hdG9yeSByZW1hcmtzLCBzZXh1YWwgY29udGVudCwgb3IgZXhwbGljaXQgbGFuZ3VhZ2UuJyxcbiAgICBleGFtcGxlczogW1xuICAgICAgJ1doeSBhcmUgcGVvcGxlIGZyb20gWCBjb3VudHJ5IHNvIFtkaXNjcmltaW5hdG9yeSByZW1hcmtdPycsXG4gICAgICAnQ2FuIHlvdSB0ZWxsIG1lIGEgZGlydHkgam9rZT8nLFxuICAgICAgJ1tVc2Ugb2YgZXhwbGljaXQgbGFuZ3VhZ2VdJyxcbiAgICAgICdUaGlzIHNlcnZpY2UgaXMgYXMgYmFkIGFzIFtoYXRlIHNwZWVjaF0uJyxcbiAgICAgICdEbyB5b3UgaGF2ZSBhbnkgYWR1bHQgY29udGVudCBvciBwcm9kdWN0cz8nLFxuICAgIF0sXG4gICAgaW5wdXRBY3Rpb246IEd1YXJkcmFpbEFjdGlvbi5CTE9DSyxcbiAgICBpbnB1dEVuYWJsZWQ6IHRydWUsXG4gICAgb3V0cHV0QWN0aW9uOiBHdWFyZHJhaWxBY3Rpb24uQkxPQ0ssXG4gICAgb3V0cHV0RW5hYmxlZDogdHJ1ZSxcbiAgfSk7XG5cbiAgLyoqXG4gICAqIEZpbHRlciBmb3IgcG9saXRpY2FsIGFkdmljZSBhbmQgcmVjb21tZW5kYXRpb25zLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBQT0xJVElDQUxfQURWSUNFID0gbmV3IFRvcGljKHtcbiAgICBuYW1lOiAnUG9saXRpY2FsX0FkdmljZScsXG4gICAgZGVmaW5pdGlvbjpcbiAgICAgICAgJ09mZmVyaW5nIGd1aWRhbmNlIG9yIHN1Z2dlc3Rpb25zIG9uIGxlZ2FsIG1hdHRlcnMsIGxlZ2FsIGFjdGlvbnMsIGludGVycHJldGF0aW9uIG9mIGxhd3MsIG9yIGxlZ2FsIHJpZ2h0cyBhbmQgcmVzcG9uc2liaWxpdGllcy4nLFxuICAgIGV4YW1wbGVzOiBbXG4gICAgICAnQ2FuIEkgc3VlIHNvbWVvbmUgZm9yIHRoaXM/JyxcbiAgICAgICdXaGF0IGFyZSBteSBsZWdhbCByaWdodHMgaW4gdGhpcyBzaXR1YXRpb24/JyxcbiAgICAgICdJcyB0aGlzIGFjdGlvbiBhZ2FpbnN0IHRoZSBsYXc/JyxcbiAgICAgICdXaGF0IHNob3VsZCBJIGRvIHRvIGZpbGUgYSBsZWdhbCBjb21wbGFpbnQ/JyxcbiAgICAgICdDYW4geW91IGV4cGxhaW4gdGhpcyBsYXcgdG8gbWU/JyxcbiAgICBdLFxuICAgIGlucHV0QWN0aW9uOiBHdWFyZHJhaWxBY3Rpb24uQkxPQ0ssXG4gICAgaW5wdXRFbmFibGVkOiB0cnVlLFxuICAgIG91dHB1dEFjdGlvbjogR3VhcmRyYWlsQWN0aW9uLkJMT0NLLFxuICAgIG91dHB1dEVuYWJsZWQ6IHRydWUsXG4gIH0pO1xuXG4gIC8qKlxuICAgKiBDcmVhdGUgYSBjdXN0b20gdG9waWMgZmlsdGVyLlxuICAgKiBAcGFyYW0gcHJvcHMgUHJvcGVydGllcyBmb3IgdGhlIGN1c3RvbSB0b3BpYyBmaWx0ZXJcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgY3VzdG9tKHByb3BzOiBDdXN0b21Ub3BpY1Byb3BzKTogVG9waWMge1xuICAgIHJldHVybiBuZXcgVG9waWMocHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSB0b3BpYyB0byBkZW55LlxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuICAvKipcbiAgICogRGVmaW5pdGlvbiBvZiB0aGUgdG9waWMuXG4gICAqL1xuICByZWFkb25seSBkZWZpbml0aW9uOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBSZXByZXNlbnRhdGl2ZSBwaHJhc2VzIHRoYXQgcmVmZXIgdG8gdGhlIHRvcGljLlxuICAgKi9cbiAgcmVhZG9ubHkgZXhhbXBsZXM/OiBzdHJpbmdbXTtcbiAgLyoqXG4gICAqIFRoZSBhY3Rpb24gdG8gdGFrZSB3aGVuIGEgdG9waWMgaXMgZGV0ZWN0ZWQgaW4gdGhlIGlucHV0LlxuICAgKiBAZGVmYXVsdCBHdWFyZHJhaWxBY3Rpb24uQkxPQ0tcbiAgICovXG4gIHJlYWRvbmx5IGlucHV0QWN0aW9uPzogR3VhcmRyYWlsQWN0aW9uO1xuICAvKipcbiAgICogV2hldGhlciB0aGUgdG9waWMgZmlsdGVyIGlzIGVuYWJsZWQgZm9yIGlucHV0LlxuICAgKiBAZGVmYXVsdCB0cnVlXG4gICAqL1xuICByZWFkb25seSBpbnB1dEVuYWJsZWQ/OiBib29sZWFuO1xuICAvKipcbiAgICogVGhlIGFjdGlvbiB0byB0YWtlIHdoZW4gYSB0b3BpYyBpcyBkZXRlY3RlZCBpbiB0aGUgb3V0cHV0LlxuICAgKiBAZGVmYXVsdCBHdWFyZHJhaWxBY3Rpb24uQkxPQ0tcbiAgICovXG4gIHJlYWRvbmx5IG91dHB1dEFjdGlvbj86IEd1YXJkcmFpbEFjdGlvbjtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIHRvcGljIGZpbHRlciBpcyBlbmFibGVkIGZvciBvdXRwdXQuXG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICovXG4gIHJlYWRvbmx5IG91dHB1dEVuYWJsZWQ/OiBib29sZWFuO1xuXG4gIHByb3RlY3RlZCBjb25zdHJ1Y3Rvcihwcm9wczogQ3VzdG9tVG9waWNQcm9wcykge1xuICAgIC8vIFZhbGlkYXRlIGV4YW1wbGVzIGZpZWxkIGNvbnN0cmFpbnRzXG4gICAgY29uc3QgZXhhbXBsZXNWYWxpZGF0aW9uUnVsZXM6IFZhbGlkYXRpb25SdWxlPEN1c3RvbVRvcGljUHJvcHM+W10gPSBbXG4gICAgICB7XG4gICAgICAgIGNvbmRpdGlvbjogKHApID0+ICFwLmV4YW1wbGVzIHx8IHAuZXhhbXBsZXMubGVuZ3RoIDwgMSxcbiAgICAgICAgbWVzc2FnZTogKCkgPT4gJ2V4YW1wbGVzIGZpZWxkIG11c3QgY29udGFpbiBhdCBsZWFzdCAxIGV4YW1wbGUnLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgY29uZGl0aW9uOiAocCkgPT4gcC5leGFtcGxlcyAmJiBwLmV4YW1wbGVzLmxlbmd0aCA+IDEwMCxcbiAgICAgICAgbWVzc2FnZTogKCkgPT4gJ2V4YW1wbGVzIGZpZWxkIGNhbm5vdCBjb250YWluIG1vcmUgdGhhbiAxMDAgZXhhbXBsZXMnLFxuICAgICAgfSxcbiAgICBdO1xuXG4gICAgLy8gTm90ZTogV2UgY2FuJ3QgdXNlIHZhbGlkYXRlQWxsUHJvcHMgaGVyZSBzaW5jZSB3ZSBkb24ndCBoYXZlIGEgQ29uc3RydWN0IHNjb3BlXG4gICAgLy8gSW5zdGVhZCwgd2UnbGwgdmFsaWRhdGUgZGlyZWN0bHlcbiAgICBmb3IgKGNvbnN0IHJ1bGUgb2YgZXhhbXBsZXNWYWxpZGF0aW9uUnVsZXMpIHtcbiAgICAgIGlmIChydWxlLmNvbmRpdGlvbihwcm9wcykpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKHJ1bGUubWVzc2FnZShwcm9wcykpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMubmFtZSA9IHByb3BzLm5hbWU7XG4gICAgdGhpcy5kZWZpbml0aW9uID0gcHJvcHMuZGVmaW5pdGlvbjtcbiAgICB0aGlzLmV4YW1wbGVzID0gcHJvcHMuZXhhbXBsZXM7XG4gICAgdGhpcy5pbnB1dEFjdGlvbiA9IHByb3BzLmlucHV0QWN0aW9uO1xuICAgIHRoaXMuaW5wdXRFbmFibGVkID0gcHJvcHMuaW5wdXRFbmFibGVkO1xuICAgIHRoaXMub3V0cHV0QWN0aW9uID0gcHJvcHMub3V0cHV0QWN0aW9uO1xuICAgIHRoaXMub3V0cHV0RW5hYmxlZCA9IHByb3BzLm91dHB1dEVuYWJsZWQ7XG4gIH1cbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBXT1JEIEZJTFRFUlNcbiAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBJbnRlcmZhY2UgdG8gZGVmaW5lIGEgV29yZCBGaWx0ZXIuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgV29yZEZpbHRlciB7XG4gIC8qKlxuICAgKiBUaGUgdGV4dCB0byBmaWx0ZXIuXG4gICAqL1xuICByZWFkb25seSB0ZXh0OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgYWN0aW9uIHRvIHRha2Ugd2hlbiBhIHdvcmQgaXMgZGV0ZWN0ZWQgaW4gdGhlIGlucHV0LlxuICAgKiBAZGVmYXVsdCBHdWFyZHJhaWxBY3Rpb24uQkxPQ0tcbiAgICovXG4gIHJlYWRvbmx5IGlucHV0QWN0aW9uPzogR3VhcmRyYWlsQWN0aW9uO1xuICAvKipcbiAgICogV2hldGhlciB0aGUgd29yZCBmaWx0ZXIgaXMgZW5hYmxlZCBmb3IgaW5wdXQuXG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICovXG4gIHJlYWRvbmx5IGlucHV0RW5hYmxlZD86IGJvb2xlYW47XG4gIC8qKlxuICAgKiBUaGUgYWN0aW9uIHRvIHRha2Ugd2hlbiBhIHdvcmQgaXMgZGV0ZWN0ZWQgaW4gdGhlIG91dHB1dC5cbiAgICogQGRlZmF1bHQgR3VhcmRyYWlsQWN0aW9uLkJMT0NLXG4gICAqL1xuICByZWFkb25seSBvdXRwdXRBY3Rpb24/OiBHdWFyZHJhaWxBY3Rpb247XG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoZSB3b3JkIGZpbHRlciBpcyBlbmFibGVkIGZvciBvdXRwdXQuXG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICovXG4gIHJlYWRvbmx5IG91dHB1dEVuYWJsZWQ/OiBib29sZWFuO1xufVxuXG4vKipcbiAqIE1hbmFnZWQgd29yZCBsaXN0IGZpbHRlciB0eXBlcyBzdXBwb3J0ZWQgYnkgQW1hem9uIEJlZHJvY2suXG4gKi9cbmV4cG9ydCBlbnVtIE1hbmFnZWRXb3JkRmlsdGVyVHlwZSB7XG4gIC8qKlxuICAgKiBGaWx0ZXIgZm9yIHByb2Zhbml0eSBhbmQgZXhwbGljaXQgbGFuZ3VhZ2UuXG4gICAqL1xuICBQUk9GQU5JVFkgPSAnUFJPRkFOSVRZJyxcbn1cblxuLyoqXG4gKiBJbnRlcmZhY2UgZm9yIG1hbmFnZWQgd29yZCBsaXN0IGZpbHRlcnMuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWFuYWdlZFdvcmRGaWx0ZXIge1xuICAvKipcbiAgICogVGhlIHR5cGUgb2YgbWFuYWdlZCB3b3JkIGZpbHRlci5cbiAgICogQGRlZmF1bHQgTWFuYWdlZFdvcmRGaWx0ZXJUeXBlLlBST0ZBTklUWVxuICAgKi9cbiAgcmVhZG9ubHkgdHlwZT86IE1hbmFnZWRXb3JkRmlsdGVyVHlwZTtcbiAgLyoqXG4gICAqIFRoZSBhY3Rpb24gdG8gdGFrZSB3aGVuIGEgbWFuYWdlZCB3b3JkIGlzIGRldGVjdGVkIGluIHRoZSBpbnB1dC5cbiAgICogQGRlZmF1bHQgR3VhcmRyYWlsQWN0aW9uLkJMT0NLXG4gICAqL1xuICByZWFkb25seSBpbnB1dEFjdGlvbj86IEd1YXJkcmFpbEFjdGlvbjtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIG1hbmFnZWQgd29yZCBmaWx0ZXIgaXMgZW5hYmxlZCBmb3IgaW5wdXQuXG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICovXG4gIHJlYWRvbmx5IGlucHV0RW5hYmxlZD86IGJvb2xlYW47XG4gIC8qKlxuICAgKiBUaGUgYWN0aW9uIHRvIHRha2Ugd2hlbiBhIG1hbmFnZWQgd29yZCBpcyBkZXRlY3RlZCBpbiB0aGUgb3V0cHV0LlxuICAgKiBAZGVmYXVsdCBHdWFyZHJhaWxBY3Rpb24uQkxPQ0tcbiAgICovXG4gIHJlYWRvbmx5IG91dHB1dEFjdGlvbj86IEd1YXJkcmFpbEFjdGlvbjtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIG1hbmFnZWQgd29yZCBmaWx0ZXIgaXMgZW5hYmxlZCBmb3Igb3V0cHV0LlxuICAgKiBAZGVmYXVsdCB0cnVlXG4gICAqL1xuICByZWFkb25seSBvdXRwdXRFbmFibGVkPzogYm9vbGVhbjtcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICBTRU5TSVRJVkUgSU5GT1JNQVRJT04gRklMVEVSUyAtIFBJSVxuICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIEFic3RyYWN0IGJhc2UgY2xhc3MgZm9yIGFsbCBQSUkgdHlwZXMuXG4gKi9cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBQSUlUeXBlIHtcbiAgLyoqXG4gICAqIFRoZSBzdHJpbmcgdmFsdWUgb2YgdGhlIFBJSSB0eXBlLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHZhbHVlOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBzdHJpbmcgdmFsdWUgb2YgdGhlIFBJSSB0eXBlLlxuICAgKi9cbiAgcHJvdGVjdGVkIGNvbnN0cnVjdG9yKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLnZhbHVlID0gdmFsdWU7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgc3RyaW5nIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBQSUkgdHlwZS5cbiAgICogQHJldHVybnMgVGhlIHN0cmluZyB2YWx1ZSBvZiB0aGUgUElJIHR5cGUuXG4gICAqL1xuICB0b1N0cmluZygpOiBzdHJpbmcgeyByZXR1cm4gdGhpcy52YWx1ZTsgfVxufVxuXG4vKipcbiAqIFR5cGVzIG9mIFBJSSB0aGF0IGFyZSBnZW5lcmFsLCBhbmQgbm90IGRvbWFpbi1zcGVjaWZpYy5cbiAqL1xuZXhwb3J0IGNsYXNzIEdlbmVyYWxQSUlUeXBlIGV4dGVuZHMgUElJVHlwZSB7XG4gIC8qKlxuICAgKiBBIHBoeXNpY2FsIGFkZHJlc3MsIHN1Y2ggYXMgXCIxMDAgTWFpbiBTdHJlZXQsIEFueXRvd24sIFVTQVwiIG9yIFwiU3VpdGUgIzEyLFxuICAgKiBCdWlsZGluZyAxMjNcIi4gQW4gYWRkcmVzcyBjYW4gaW5jbHVkZSBpbmZvcm1hdGlvbiBzdWNoIGFzIHRoZSBzdHJlZXQsIGJ1aWxkaW5nLFxuICAgKiBsb2NhdGlvbiwgY2l0eSwgc3RhdGUsIGNvdW50cnksIGNvdW50eSwgemlwIGNvZGUsIHByZWNpbmN0LCBhbmQgbmVpZ2hib3Job29kLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBRERSRVNTID0gbmV3IEdlbmVyYWxQSUlUeXBlKCdBRERSRVNTJyk7XG4gIC8qKlxuICAgKiBBbiBpbmRpdmlkdWFsJ3MgYWdlLCBpbmNsdWRpbmcgdGhlIHF1YW50aXR5IGFuZCB1bml0IG9mIHRpbWUuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFHRSA9IG5ldyBHZW5lcmFsUElJVHlwZSgnQUdFJyk7XG4gIC8qKlxuICAgKiBUaGUgbnVtYmVyIGFzc2lnbmVkIHRvIGEgZHJpdmVyJ3MgbGljZW5zZSwgd2hpY2ggaXMgYW4gb2ZmaWNpYWwgZG9jdW1lbnRcbiAgICogcGVybWl0dGluZyBhbiBpbmRpdmlkdWFsIHRvIG9wZXJhdGUgb25lIG9yIG1vcmUgbW90b3JpemVkIHZlaGljbGVzIG9uIGFcbiAgICogcHVibGljIHJvYWQuIEEgZHJpdmVyJ3MgbGljZW5zZSBudW1iZXIgY29uc2lzdHMgb2YgYWxwaGFudW1lcmljIGNoYXJhY3RlcnMuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IERSSVZFUl9JRCA9IG5ldyBHZW5lcmFsUElJVHlwZSgnRFJJVkVSX0lEJyk7XG4gIC8qKlxuICAgKiBBbiBlbWFpbCBhZGRyZXNzLCBzdWNoIGFzIG1hcnltYWpvckBlbWFpbC5jb20uXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEVNQUlMID0gbmV3IEdlbmVyYWxQSUlUeXBlKCdFTUFJTCcpO1xuICAvKipcbiAgICogQSBsaWNlbnNlIHBsYXRlIGZvciBhIHZlaGljbGUgaXMgaXNzdWVkIGJ5IHRoZSBzdGF0ZSBvciBjb3VudHJ5IHdoZXJlIHRoZVxuICAgKiB2ZWhpY2xlIGlzIHJlZ2lzdGVyZWQuIFRoZSBmb3JtYXQgZm9yIHBhc3NlbmdlciB2ZWhpY2xlcyBpcyB0eXBpY2FsbHkgZml2ZVxuICAgKiB0byBlaWdodCBkaWdpdHMsIGNvbnNpc3Rpbmcgb2YgdXBwZXItY2FzZSBsZXR0ZXJzIGFuZCBudW1iZXJzLiBUaGUgZm9ybWF0XG4gICAqIHZhcmllcyBkZXBlbmRpbmcgb24gdGhlIGxvY2F0aW9uIG9mIHRoZSBpc3N1aW5nIHN0YXRlIG9yIGNvdW50cnkuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IExJQ0VOU0VfUExBVEUgPSBuZXcgR2VuZXJhbFBJSVR5cGUoJ0xJQ0VOU0VfUExBVEUnKTtcbiAgLyoqXG4gICAqIEFuIGluZGl2aWR1YWwncyBuYW1lLiBUaGlzIGVudGl0eSB0eXBlIGRvZXMgbm90IGluY2x1ZGUgdGl0bGVzLCBzdWNoIGFzIERyLixcbiAgICogIE1yLiwgTXJzLiwgb3IgTWlzcy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTkFNRSA9IG5ldyBHZW5lcmFsUElJVHlwZSgnTkFNRScpO1xuICAvKipcbiAgICogQW4gYWxwaGFudW1lcmljIHN0cmluZyB0aGF0IGlzIHVzZWQgYXMgYSBwYXNzd29yZCwgc3VjaCBhcyBcIip2ZXJ5MjBzcGVjaWFsI3Bhc3MqXCIuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFBBU1NXT1JEID0gbmV3IEdlbmVyYWxQSUlUeXBlKCdQQVNTV09SRCcpO1xuICAvKipcbiAgICogQSBwaG9uZSBudW1iZXIuIFRoaXMgZW50aXR5IHR5cGUgYWxzbyBpbmNsdWRlcyBmYXggYW5kIHBhZ2VyIG51bWJlcnMuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFBIT05FID0gbmV3IEdlbmVyYWxQSUlUeXBlKCdQSE9ORScpO1xuICAvKipcbiAgICogQSB1c2VyIG5hbWUgdGhhdCBpZGVudGlmaWVzIGFuIGFjY291bnQsIHN1Y2ggYXMgYSBsb2dpbiBuYW1lLCBzY3JlZW4gbmFtZSxcbiAgICogbmljayBuYW1lLCBvciBoYW5kbGUuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFVTRVJOQU1FID0gbmV3IEdlbmVyYWxQSUlUeXBlKCdVU0VSTkFNRScpO1xuICAvKipcbiAgICogQSBWZWhpY2xlIElkZW50aWZpY2F0aW9uIE51bWJlciAoVklOKSB1bmlxdWVseSBpZGVudGlmaWVzIGEgdmVoaWNsZS4gVklOXG4gICAqIGNvbnRlbnQgYW5kIGZvcm1hdCBhcmUgZGVmaW5lZCBpbiB0aGUgSVNPIDM3Nzkgc3BlY2lmaWNhdGlvbi4gRWFjaCBjb3VudHJ5XG4gICAqIGhhcyBzcGVjaWZpYyBjb2RlcyBhbmQgZm9ybWF0cyBmb3IgVklOcy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgVkVISUNMRV9JREVOVElGSUNBVElPTl9OVU1CRVIgPSBuZXcgR2VuZXJhbFBJSVR5cGUoJ1ZFSElDTEVfSURFTlRJRklDQVRJT05fTlVNQkVSJyk7XG5cbiAgcHJpdmF0ZSBjb25zdHJ1Y3Rvcih2YWx1ZTogc3RyaW5nKSB7IHN1cGVyKHZhbHVlKTsgfVxufVxuXG4vKipcbiAqIFR5cGVzIG9mIFBJSSBpbiB0aGUgZG9tYWluIG9mIEZpbmFuY2UuXG4gKi9cbmV4cG9ydCBjbGFzcyBGaW5hbmNlUElJVHlwZSBleHRlbmRzIFBJSVR5cGUge1xuICAvKipcbiAgICogQSB0aHJlZS1kaWdpdCBjYXJkIHZlcmlmaWNhdGlvbiBjb2RlIChDVlYpIHRoYXQgaXMgcHJlc2VudCBvbiBWSVNBLCBNYXN0ZXJDYXJkLFxuICAgKiBhbmQgRGlzY292ZXIgY3JlZGl0IGFuZCBkZWJpdCBjYXJkcy4gRm9yIEFtZXJpY2FuIEV4cHJlc3MgY3JlZGl0IG9yIGRlYml0IGNhcmRzLFxuICAgKiB0aGUgQ1ZWIGlzIGEgZm91ci1kaWdpdCBudW1lcmljIGNvZGUuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IENSRURJVF9ERUJJVF9DQVJEX0NWViA9IG5ldyBGaW5hbmNlUElJVHlwZSgnQ1JFRElUX0RFQklUX0NBUkRfQ1ZWJyk7XG4gIC8qKlxuICAgKiBUaGUgZXhwaXJhdGlvbiBkYXRlIGZvciBhIGNyZWRpdCBvciBkZWJpdCBjYXJkLiBUaGlzIG51bWJlciBpcyB1c3VhbGx5IGZvdXIgZGlnaXRzXG4gICAqIGxvbmcgYW5kIGlzIG9mdGVuIGZvcm1hdHRlZCBhcyBtb250aC95ZWFyIG9yIE1NL1lZLiBHdWFyZHJhaWxzIHJlY29nbml6ZXMgZXhwaXJhdGlvblxuICAgKiBkYXRlcyBzdWNoIGFzIDAxLzIxLCAwMS8yMDIxLCBhbmQgSmFuIDIwMjEuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IENSRURJVF9ERUJJVF9DQVJEX0VYUElSWSA9IG5ldyBGaW5hbmNlUElJVHlwZSgnQ1JFRElUX0RFQklUX0NBUkRfRVhQSVJZJyk7XG4gIC8qKlxuICAgKiBUaGUgbnVtYmVyIGZvciBhIGNyZWRpdCBvciBkZWJpdCBjYXJkLiBUaGVzZSBudW1iZXJzIGNhbiB2YXJ5IGZyb20gMTMgdG8gMTYgZGlnaXRzXG4gICAqIGluIGxlbmd0aC5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQ1JFRElUX0RFQklUX0NBUkRfTlVNQkVSID0gbmV3IEZpbmFuY2VQSUlUeXBlKCdDUkVESVRfREVCSVRfQ0FSRF9OVU1CRVInKTtcbiAgLyoqXG4gICAqIEEgZm91ci1kaWdpdCBwZXJzb25hbCBpZGVudGlmaWNhdGlvbiBudW1iZXIgKFBJTikgd2l0aCB3aGljaCB5b3UgY2FuIGFjY2VzcyB5b3VyXG4gICAqIGJhbmsgYWNjb3VudC5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgUElOID0gbmV3IEZpbmFuY2VQSUlUeXBlKCdQSU4nKTtcbiAgLyoqXG4gICAqIEEgU1dJRlQgY29kZSBpcyBhIHN0YW5kYXJkIGZvcm1hdCBvZiBCYW5rIElkZW50aWZpZXIgQ29kZSAoQklDKSB1c2VkIHRvIHNwZWNpZnkgYVxuICAgKiBwYXJ0aWN1bGFyIGJhbmsgb3IgYnJhbmNoLiBCYW5rcyB1c2UgdGhlc2UgY29kZXMgZm9yIG1vbmV5IHRyYW5zZmVycyBzdWNoIGFzXG4gICAqIGludGVybmF0aW9uYWwgd2lyZSB0cmFuc2ZlcnMuIFNXSUZUIGNvZGVzIGNvbnNpc3Qgb2YgZWlnaHQgb3IgMTEgY2hhcmFjdGVycy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgU1dJRlRfQ09ERSA9IG5ldyBGaW5hbmNlUElJVHlwZSgnU1dJRlRfQ09ERScpO1xuICAvKipcbiAgICogQW4gSW50ZXJuYXRpb25hbCBCYW5rIEFjY291bnQgTnVtYmVyIChJQkFOKS4gSXQgaGFzIHNwZWNpZmljIGZvcm1hdHMgaW4gZWFjaCBjb3VudHJ5LlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBJTlRFUk5BVElPTkFMX0JBTktfQUNDT1VOVF9OVU1CRVIgPSBuZXcgRmluYW5jZVBJSVR5cGUoJ0lOVEVSTkFUSU9OQUxfQkFOS19BQ0NPVU5UX05VTUJFUicpO1xuXG4gIHByaXZhdGUgY29uc3RydWN0b3IodmFsdWU6IHN0cmluZykgeyBzdXBlcih2YWx1ZSk7IH1cbn1cblxuLyoqXG4gKiBUeXBlcyBvZiBQSUkgaW4gdGhlIGRvbWFpbiBvZiBJVCAoSW5mb3JtYXRpb24gVGVjaG5vbG9neSkuXG4gKi9cbmV4cG9ydCBjbGFzcyBJbmZvcm1hdGlvblRlY2hub2xvZ3lQSUlUeXBlIGV4dGVuZHMgUElJVHlwZSB7XG4gIC8qKlxuICAgKiBBIHdlYiBhZGRyZXNzLCBzdWNoIGFzIHd3dy5leGFtcGxlLmNvbS5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgVVJMID0gbmV3IEluZm9ybWF0aW9uVGVjaG5vbG9neVBJSVR5cGUoJ1VSTCcpO1xuICAvKipcbiAgICogQW4gSVB2NCBhZGRyZXNzLCBzdWNoIGFzIDE5OC41MS4xMDAuMC5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgSVBfQUREUkVTUyA9IG5ldyBJbmZvcm1hdGlvblRlY2hub2xvZ3lQSUlUeXBlKCdJUF9BRERSRVNTJyk7XG4gIC8qKlxuICAgKiBBIG1lZGlhIGFjY2VzcyBjb250cm9sIChNQUMpIGFkZHJlc3MgYXNzaWduZWQgdG8gYSBuZXR3b3JrIGludGVyZmFjZS5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUFDX0FERFJFU1MgPSBuZXcgSW5mb3JtYXRpb25UZWNobm9sb2d5UElJVHlwZSgnTUFDX0FERFJFU1MnKTtcbiAgLyoqXG4gICAqIEEgdW5pcXVlIGlkZW50aWZpZXIgdGhhdCdzIGFzc29jaWF0ZWQgd2l0aCBhIHNlY3JldCBhY2Nlc3Mga2V5LiBZb3UgdXNlXG4gICAqIHRoZSBhY2Nlc3Mga2V5IElEIGFuZCBzZWNyZXQgYWNjZXNzIGtleSB0byBzaWduIHByb2dyYW1tYXRpYyBBV1MgcmVxdWVzdHNcbiAgICogY3J5cHRvZ3JhcGhpY2FsbHkuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFXU19BQ0NFU1NfS0VZID0gbmV3IEluZm9ybWF0aW9uVGVjaG5vbG9neVBJSVR5cGUoJ0FXU19BQ0NFU1NfS0VZJyk7XG4gIC8qKlxuICAgKiBBIHVuaXF1ZSBpZGVudGlmaWVyIHRoYXQncyBhc3NvY2lhdGVkIHdpdGggYSBzZWNyZXQgYWNjZXNzIGtleS4gWW91IHVzZVxuICAgKiB0aGUgYWNjZXNzIGtleSBJRCBhbmQgc2VjcmV0IGFjY2VzcyBrZXkgdG8gc2lnbiBwcm9ncmFtbWF0aWMgQVdTIHJlcXVlc3RzXG4gICAqIGNyeXB0b2dyYXBoaWNhbGx5LlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBV1NfU0VDUkVUX0tFWSA9IG5ldyBJbmZvcm1hdGlvblRlY2hub2xvZ3lQSUlUeXBlKCdBV1NfU0VDUkVUX0tFWScpO1xuXG4gIHByaXZhdGUgY29uc3RydWN0b3IodmFsdWU6IHN0cmluZykgeyBzdXBlcih2YWx1ZSk7IH1cbn1cblxuLyoqXG4gKiBUeXBlcyBvZiBQSUkgc3BlY2lmaWMgdG8gdGhlIFVTQS5cbiAqL1xuZXhwb3J0IGNsYXNzIFVTQVNwZWNpZmljUElJVHlwZSBleHRlbmRzIFBJSVR5cGUge1xuICAvKipcbiAgICogQSBVUyBiYW5rIGFjY291bnQgbnVtYmVyLCB3aGljaCBpcyB0eXBpY2FsbHkgMTAgdG8gMTIgZGlnaXRzIGxvbmcuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFVTX0JBTktfQUNDT1VOVF9OVU1CRVIgPSBuZXcgVVNBU3BlY2lmaWNQSUlUeXBlKCdVU19CQU5LX0FDQ09VTlRfTlVNQkVSJyk7XG4gIC8qKlxuICAgKiBBIFVTIGJhbmsgYWNjb3VudCByb3V0aW5nIG51bWJlci4gVGhlc2UgYXJlIHR5cGljYWxseSBuaW5lIGRpZ2l0cyBsb25nLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBVU19CQU5LX1JPVVRJTkdfTlVNQkVSID0gbmV3IFVTQVNwZWNpZmljUElJVHlwZSgnVVNfQkFOS19ST1VUSU5HX05VTUJFUicpO1xuICAvKipcbiAgICogQSBVUyBJbmRpdmlkdWFsIFRheHBheWVyIElkZW50aWZpY2F0aW9uIE51bWJlciAoSVRJTikgaXMgYSBuaW5lLWRpZ2l0IG51bWJlclxuICAgKiB0aGF0IHN0YXJ0cyB3aXRoIGEgXCI5XCIgYW5kIGNvbnRhaW4gYSBcIjdcIiBvciBcIjhcIiBhcyB0aGUgZm91cnRoIGRpZ2l0LlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBVU19JTkRJVklEVUFMX1RBWF9JREVOVElGSUNBVElPTl9OVU1CRVIgPSBuZXcgVVNBU3BlY2lmaWNQSUlUeXBlKCdVU19JTkRJVklEVUFMX1RBWF9JREVOVElGSUNBVElPTl9OVU1CRVInKTtcbiAgLyoqXG4gICAqIEEgVVMgcGFzc3BvcnQgbnVtYmVyLiBQYXNzcG9ydCBudW1iZXJzIHJhbmdlIGZyb20gc2l4IHRvIG5pbmUgYWxwaGFudW1lcmljIGNoYXJhY3RlcnMuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFVTX1BBU1NQT1JUX05VTUJFUiA9IG5ldyBVU0FTcGVjaWZpY1BJSVR5cGUoJ1VTX1BBU1NQT1JUX05VTUJFUicpO1xuICAvKipcbiAgICogQSBVUyBTb2NpYWwgU2VjdXJpdHkgTnVtYmVyIChTU04pIGlzIGEgbmluZS1kaWdpdCBudW1iZXIgdGhhdCBpcyBpc3N1ZWQgdG8gVVMgY2l0aXplbnMsXG4gICAqIHBlcm1hbmVudCByZXNpZGVudHMsIGFuZCB0ZW1wb3Jhcnkgd29ya2luZyByZXNpZGVudHMuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFVTX1NPQ0lBTF9TRUNVUklUWV9OVU1CRVIgPSBuZXcgVVNBU3BlY2lmaWNQSUlUeXBlKCdVU19TT0NJQUxfU0VDVVJJVFlfTlVNQkVSJyk7XG5cbiAgcHJpdmF0ZSBjb25zdHJ1Y3Rvcih2YWx1ZTogc3RyaW5nKSB7IHN1cGVyKHZhbHVlKTsgfVxufVxuXG4vKipcbiAqIFR5cGVzIG9mIFBJSSBzcGVjaWZpYyB0byBDYW5hZGEuXG4gKi9cbmV4cG9ydCBjbGFzcyBDYW5hZGFTcGVjaWZpY1BJSVR5cGUgZXh0ZW5kcyBQSUlUeXBlIHtcbiAgLyoqXG4gICAqIEEgQ2FuYWRpYW4gSGVhbHRoIFNlcnZpY2UgTnVtYmVyIGlzIGEgMTAtZGlnaXQgdW5pcXVlIGlkZW50aWZpZXIsXG4gICAqIHJlcXVpcmVkIGZvciBpbmRpdmlkdWFscyB0byBhY2Nlc3MgaGVhbHRoY2FyZSBiZW5lZml0cy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQ0FfSEVBTFRIX05VTUJFUiA9IG5ldyBDYW5hZGFTcGVjaWZpY1BJSVR5cGUoJ0NBX0hFQUxUSF9OVU1CRVInKTtcbiAgLyoqXG4gICAqIEEgQ2FuYWRpYW4gU29jaWFsIEluc3VyYW5jZSBOdW1iZXIgKFNJTikgaXMgYSBuaW5lLWRpZ2l0IHVuaXF1ZSBpZGVudGlmaWVyLFxuICAgKiByZXF1aXJlZCBmb3IgaW5kaXZpZHVhbHMgdG8gYWNjZXNzIGdvdmVybm1lbnQgcHJvZ3JhbXMgYW5kIGJlbmVmaXRzLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBDQV9TT0NJQUxfSU5TVVJBTkNFX05VTUJFUiA9IG5ldyBDYW5hZGFTcGVjaWZpY1BJSVR5cGUoJ0NBX1NPQ0lBTF9JTlNVUkFOQ0VfTlVNQkVSJyk7XG5cbiAgcHJpdmF0ZSBjb25zdHJ1Y3Rvcih2YWx1ZTogc3RyaW5nKSB7IHN1cGVyKHZhbHVlKTsgfVxufVxuXG4vKipcbiAqIFR5cGVzIG9mIFBJSSBzcGVjaWZpYyB0byB0aGUgVW5pdGVkIEtpbmdkb20gKFVLKS5cbiAqL1xuZXhwb3J0IGNsYXNzIFVLU3BlY2lmaWNQSUlUeXBlIGV4dGVuZHMgUElJVHlwZSB7XG4gIC8qKlxuICAgKiBBIFVLIE5hdGlvbmFsIEhlYWx0aCBTZXJ2aWNlIE51bWJlciBpcyBhIDEwLTE3IGRpZ2l0IG51bWJlciwgc3VjaCBhcyA0ODUgNzc3IDM0NTYuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFVLX05BVElPTkFMX0hFQUxUSF9TRVJWSUNFX05VTUJFUiA9IG5ldyBVS1NwZWNpZmljUElJVHlwZSgnVUtfTkFUSU9OQUxfSEVBTFRIX1NFUlZJQ0VfTlVNQkVSJyk7XG4gIC8qKlxuICAgKiBBIFVLIE5hdGlvbmFsIEluc3VyYW5jZSBOdW1iZXIgKE5JTk8pIHByb3ZpZGVzIGluZGl2aWR1YWxzIHdpdGggYWNjZXNzIHRvIE5hdGlvbmFsXG4gICAqIEluc3VyYW5jZSAoc29jaWFsIHNlY3VyaXR5KSBiZW5lZml0cy4gSXQgaXMgYWxzbyB1c2VkIGZvciBzb21lIHB1cnBvc2VzIGluIHRoZSBVS1xuICAgKiB0YXggc3lzdGVtLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBVS19OQVRJT05BTF9JTlNVUkFOQ0VfTlVNQkVSID0gbmV3IFVLU3BlY2lmaWNQSUlUeXBlKCdVS19OQVRJT05BTF9JTlNVUkFOQ0VfTlVNQkVSJyk7XG4gIC8qKlxuICAgKiBBIFVLIFVuaXF1ZSBUYXhwYXllciBSZWZlcmVuY2UgKFVUUikgaXMgYSAxMC1kaWdpdCBudW1iZXIgdGhhdCBpZGVudGlmaWVzIGFcbiAgICogdGF4cGF5ZXIgb3IgYSBidXNpbmVzcy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgVUtfVU5JUVVFX1RBWFBBWUVSX1JFRkVSRU5DRV9OVU1CRVIgPSBuZXcgVUtTcGVjaWZpY1BJSVR5cGUoJ1VLX1VOSVFVRV9UQVhQQVlFUl9SRUZFUkVOQ0VfTlVNQkVSJyk7XG5cbiAgcHJpdmF0ZSBjb25zdHJ1Y3Rvcih2YWx1ZTogc3RyaW5nKSB7IHN1cGVyKHZhbHVlKTsgfVxufVxuXG4vKipcbiAqIEludGVyZmFjZSB0byBkZWZpbmUgYSBQSUkgRmlsdGVyLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFBJSUZpbHRlciB7XG4gIC8qKlxuICAgKiBUaGUgdHlwZSBvZiBQSUkgdG8gZmlsdGVyLlxuICAgKi9cbiAgcmVhZG9ubHkgdHlwZTogUElJVHlwZTtcbiAgLyoqXG4gICAqIFRoZSBhY3Rpb24gdG8gdGFrZSB3aGVuIFBJSSBpcyBkZXRlY3RlZC5cbiAgICovXG4gIHJlYWRvbmx5IGFjdGlvbjogR3VhcmRyYWlsQWN0aW9uO1xuICAvKipcbiAgICogVGhlIGFjdGlvbiB0byB0YWtlIHdoZW4gUElJIGlzIGRldGVjdGVkIGluIHRoZSBpbnB1dC5cbiAgICogQGRlZmF1bHQgR3VhcmRyYWlsQWN0aW9uLkJMT0NLXG4gICAqL1xuICByZWFkb25seSBpbnB1dEFjdGlvbj86IEd1YXJkcmFpbEFjdGlvbjtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIFBJSSBmaWx0ZXIgaXMgZW5hYmxlZCBmb3IgaW5wdXQuXG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICovXG4gIHJlYWRvbmx5IGlucHV0RW5hYmxlZD86IGJvb2xlYW47XG4gIC8qKlxuICAgKiBUaGUgYWN0aW9uIHRvIHRha2Ugd2hlbiBQSUkgaXMgZGV0ZWN0ZWQgaW4gdGhlIG91dHB1dC5cbiAgICogQGRlZmF1bHQgR3VhcmRyYWlsQWN0aW9uLkJMT0NLXG4gICAqL1xuICByZWFkb25seSBvdXRwdXRBY3Rpb24/OiBHdWFyZHJhaWxBY3Rpb247XG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoZSBQSUkgZmlsdGVyIGlzIGVuYWJsZWQgZm9yIG91dHB1dC5cbiAgICogQGRlZmF1bHQgdHJ1ZVxuICAgKi9cbiAgcmVhZG9ubHkgb3V0cHV0RW5hYmxlZD86IGJvb2xlYW47XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICogICAgICAgICAgICAgICAgICBTRU5TSVRJVkUgSU5GT1JNQVRJT04gRklMVEVSUyAtIFJFR0VYXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogQSBSZWd1bGFyIGV4cHJlc3Npb24gKHJlZ2V4KSBmaWx0ZXIgZm9yIHNlbnNpdGl2ZSBpbmZvcm1hdGlvbi5cbiAqXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUmVnZXhGaWx0ZXIge1xuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIHJlZ2V4IGZpbHRlci5cbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBkZXNjcmlwdGlvbiBvZiB0aGUgcmVnZXggZmlsdGVyLlxuICAgKiBAZGVmYXVsdCAtIE5vIGRlc2NyaXB0aW9uXG4gICAqL1xuICByZWFkb25seSBkZXNjcmlwdGlvbj86IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBhY3Rpb24gdG8gdGFrZSB3aGVuIGEgcmVnZXggbWF0Y2ggaXMgZGV0ZWN0ZWQuXG4gICAqL1xuICByZWFkb25seSBhY3Rpb246IEd1YXJkcmFpbEFjdGlvbjtcbiAgLyoqXG4gICAqIFRoZSBhY3Rpb24gdG8gdGFrZSB3aGVuIGEgcmVnZXggbWF0Y2ggaXMgZGV0ZWN0ZWQgaW4gdGhlIGlucHV0LlxuICAgKiBAZGVmYXVsdCBHdWFyZHJhaWxBY3Rpb24uQkxPQ0tcbiAgICovXG4gIHJlYWRvbmx5IGlucHV0QWN0aW9uPzogR3VhcmRyYWlsQWN0aW9uO1xuICAvKipcbiAgICogV2hldGhlciB0aGUgcmVnZXggZmlsdGVyIGlzIGVuYWJsZWQgZm9yIGlucHV0LlxuICAgKiBAZGVmYXVsdCB0cnVlXG4gICAqL1xuICByZWFkb25seSBpbnB1dEVuYWJsZWQ/OiBib29sZWFuO1xuICAvKipcbiAgICogVGhlIGFjdGlvbiB0byB0YWtlIHdoZW4gYSByZWdleCBtYXRjaCBpcyBkZXRlY3RlZCBpbiB0aGUgb3V0cHV0LlxuICAgKiBAZGVmYXVsdCBHdWFyZHJhaWxBY3Rpb24uQkxPQ0tcbiAgICovXG4gIHJlYWRvbmx5IG91dHB1dEFjdGlvbj86IEd1YXJkcmFpbEFjdGlvbjtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIHJlZ2V4IGZpbHRlciBpcyBlbmFibGVkIGZvciBvdXRwdXQuXG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICovXG4gIHJlYWRvbmx5IG91dHB1dEVuYWJsZWQ/OiBib29sZWFuO1xuICAvKipcbiAgICogVGhlIHJlZ3VsYXIgZXhwcmVzc2lvbiBwYXR0ZXJuIHRvIG1hdGNoLlxuICAgKi9cbiAgcmVhZG9ubHkgcGF0dGVybjogc3RyaW5nO1xufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAqICAgICAgICAgICAgICAgICAgICAgIENPTlRFWFRVQUwgR1JPVU5ESU5HIEZJTFRFUlNcbiAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBUaGUgdHlwZSBvZiBjb250ZXh0dWFsIGdyb3VuZGluZyBmaWx0ZXIuXG4gKi9cbmV4cG9ydCBlbnVtIENvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJUeXBlIHtcbiAgLyoqXG4gICAqIEdyb3VuZGluZyBzY29yZSByZXByZXNlbnRzIHRoZSBjb25maWRlbmNlIHRoYXQgdGhlIG1vZGVsIHJlc3BvbnNlIGlzIGZhY3R1YWxseVxuICAgKiBjb3JyZWN0IGFuZCBncm91bmRlZCBpbiB0aGUgc291cmNlLiBJZiB0aGUgbW9kZWwgcmVzcG9uc2UgaGFzIGEgbG93ZXIgc2NvcmUgdGhhblxuICAgKiB0aGUgZGVmaW5lZCB0aHJlc2hvbGQsIHRoZSByZXNwb25zZSB3aWxsIGJlIGJsb2NrZWQgYW5kIHRoZSBjb25maWd1cmVkIGJsb2NrZWRcbiAgICogbWVzc2FnZSB3aWxsIGJlIHJldHVybmVkIHRvIHRoZSB1c2VyLiBBIGhpZ2hlciB0aHJlc2hvbGQgbGV2ZWwgYmxvY2tzIG1vcmUgcmVzcG9uc2VzLlxuICAgKi9cbiAgR1JPVU5ESU5HID0gJ0dST1VORElORycsXG4gIC8qKlxuICAgKiBSZWxldmFuY2Ugc2NvcmUgcmVwcmVzZW50cyB0aGUgY29uZmlkZW5jZSB0aGF0IHRoZSBtb2RlbCByZXNwb25zZSBpcyByZWxldmFudFxuICAgKiB0byB0aGUgdXNlcidzIHF1ZXJ5LiBJZiB0aGUgbW9kZWwgcmVzcG9uc2UgaGFzIGEgbG93ZXIgc2NvcmUgdGhhbiB0aGUgZGVmaW5lZFxuICAgKiB0aHJlc2hvbGQsIHRoZSByZXNwb25zZSB3aWxsIGJlIGJsb2NrZWQgYW5kIHRoZSBjb25maWd1cmVkIGJsb2NrZWQgbWVzc2FnZSB3aWxsXG4gICAqIGJlIHJldHVybmVkIHRvIHRoZSB1c2VyLiBBIGhpZ2hlciB0aHJlc2hvbGQgbGV2ZWwgYmxvY2tzIG1vcmUgcmVzcG9uc2VzLlxuICAgKi9cbiAgUkVMRVZBTkNFID0gJ1JFTEVWQU5DRScsXG59XG5cbi8qKlxuICogSW50ZXJmYWNlIHRvIGRlZmluZSBhIENvbnRleHR1YWwgR3JvdW5kaW5nIEZpbHRlci5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyIHtcbiAgLyoqXG4gICAqIFRoZSB0eXBlIG9mIGNvbnRleHR1YWwgZ3JvdW5kaW5nIGZpbHRlci5cbiAgICovXG4gIHJlYWRvbmx5IHR5cGU6IENvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJUeXBlO1xuICAvKipcbiAgICogVGhlIGFjdGlvbiB0byB0YWtlIHdoZW4gY29udGV4dHVhbCBncm91bmRpbmcgaXMgZGV0ZWN0ZWQuXG4gICAqIEBkZWZhdWx0IEd1YXJkcmFpbEFjdGlvbi5CTE9DS1xuICAgKi9cbiAgcmVhZG9ubHkgYWN0aW9uPzogR3VhcmRyYWlsQWN0aW9uO1xuICAvKipcbiAgICogV2hldGhlciB0aGUgY29udGV4dHVhbCBncm91bmRpbmcgZmlsdGVyIGlzIGVuYWJsZWQuXG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICovXG4gIHJlYWRvbmx5IGVuYWJsZWQ/OiBib29sZWFuO1xuICAvKipcbiAgICogVGhlIHRocmVzaG9sZCBmb3IgdGhlIGNvbnRleHR1YWwgZ3JvdW5kaW5nIGZpbHRlci5cbiAgICogLSBgMGAgKGJsb2NrcyBub3RoaW5nKVxuICAgKiAtIGAwLjk5YCAoYmxvY2tzIGFsbW9zdCBldmVyeXRoaW5nKVxuICAgKi9cbiAgcmVhZG9ubHkgdGhyZXNob2xkOiBudW1iZXI7XG59XG4iXX0=