"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VectorStore = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const knowledge_base_1 = require("../mixins/knowledge-base");
/**
 * The vector store that backs a vector knowledge base.
 *
 * Use one of the static factory methods to reference an existing store.
 */
class VectorStore {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.VectorStore", version: "2.274.0-alpha.0" };
    /**
     * An existing vector index in an Amazon OpenSearch Serverless collection.
     */
    static openSearchServerless(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_OpenSearchServerlessVectorStoreProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.openSearchServerless);
            }
            throw error;
        }
        return new VectorStore(new knowledge_base_1.KnowledgeBaseOpenSearchServerlessStorage(props));
    }
    /**
     * The mixin that configures a knowledge base to use this vector store.
     *
     * @internal
     */
    _mixin;
    constructor(mixin) {
        this._mixin = mixin;
    }
}
exports.VectorStore = VectorStore;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmVjdG9yLXN0b3JlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidmVjdG9yLXN0b3JlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBRUEsNkRBQW9GO0FBdUNwRjs7OztHQUlHO0FBQ0gsTUFBYSxXQUFXOztJQUN0Qjs7T0FFRztJQUNJLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxLQUEyQzs7Ozs7Ozs7OztRQUM1RSxPQUFPLElBQUksV0FBVyxDQUFDLElBQUkseURBQXdDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztLQUM3RTtJQUVEOzs7O09BSUc7SUFDYSxNQUFNLENBQVM7SUFFL0IsWUFBb0IsS0FBYTtRQUMvQixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztLQUNyQjs7QUFqQkgsa0NBa0JDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgKiBhcyBvcGVuc2VhcmNoc2VydmVybGVzcyBmcm9tICdhd3MtY2RrLWxpYi9hd3Mtb3BlbnNlYXJjaHNlcnZlcmxlc3MnO1xuaW1wb3J0IHR5cGUgeyBJTWl4aW4gfSBmcm9tICdjb25zdHJ1Y3RzJztcbmltcG9ydCB7IEtub3dsZWRnZUJhc2VPcGVuU2VhcmNoU2VydmVybGVzc1N0b3JhZ2UgfSBmcm9tICcuLi9taXhpbnMva25vd2xlZGdlLWJhc2UnO1xuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGFuIEFtYXpvbiBPcGVuU2VhcmNoIFNlcnZlcmxlc3MgdmVjdG9yIHN0b3JlLlxuICpcbiAqIFRoZSBjb2xsZWN0aW9uIGFuZCBpdHMgdmVjdG9yIGluZGV4IG11c3QgYWxyZWFkeSBleGlzdC4gQW1hem9uIEJlZHJvY2tcbiAqIHZhbGlkYXRlcyBhdCBjcmVhdGlvbiB0aW1lIHRoYXQgdGhlIGluZGV4IGV4aXN0cyBpbiB0aGUgY29sbGVjdGlvbiBhbmRcbiAqIHRoYXQgaXRzIHZlY3RvciBmaWVsZCBtYXRjaGVzIHRoZSBlbWJlZGRpbmdzIG1vZGVsLiBTcGVjaWZ5IHRoZSBmaWVsZFxuICogbmFtZXMgZXhhY3RseSBhcyB0aGV5IGFyZSBkZWZpbmVkIGluIHRoZSBpbmRleC5cbiAqXG4gKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9iZWRyb2NrL2xhdGVzdC91c2VyZ3VpZGUva25vd2xlZGdlLWJhc2Utc2V0dXAtb3NzLmh0bWxcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBPcGVuU2VhcmNoU2VydmVybGVzc1ZlY3RvclN0b3JlUHJvcHMge1xuICAvKipcbiAgICogVGhlIE9wZW5TZWFyY2ggU2VydmVybGVzcyBjb2xsZWN0aW9uIHRoYXQgY29udGFpbnMgdGhlIHZlY3RvciBpbmRleC5cbiAgICovXG4gIHJlYWRvbmx5IGNvbGxlY3Rpb246IG9wZW5zZWFyY2hzZXJ2ZXJsZXNzLklDb2xsZWN0aW9uUmVmO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgdmVjdG9yIGluZGV4IGluIHRoZSBjb2xsZWN0aW9uLlxuICAgKi9cbiAgcmVhZG9ubHkgdmVjdG9ySW5kZXhOYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBpbmRleCBmaWVsZCB0aGF0IHN0b3JlcyB0aGUgdmVjdG9yIGVtYmVkZGluZ3MuXG4gICAqL1xuICByZWFkb25seSB2ZWN0b3JGaWVsZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgaW5kZXggZmllbGQgdGhhdCBzdG9yZXMgdGhlIHJhdyB0ZXh0IG9mIGVhY2ggY2h1bmsuXG4gICAqL1xuICByZWFkb25seSB0ZXh0RmllbGQ6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIGluZGV4IGZpZWxkIHRoYXQgc3RvcmVzIHRoZSBtZXRhZGF0YSBvZiBlYWNoIGNodW5rLlxuICAgKi9cbiAgcmVhZG9ubHkgbWV0YWRhdGFGaWVsZDogc3RyaW5nO1xufVxuXG4vKipcbiAqIFRoZSB2ZWN0b3Igc3RvcmUgdGhhdCBiYWNrcyBhIHZlY3RvciBrbm93bGVkZ2UgYmFzZS5cbiAqXG4gKiBVc2Ugb25lIG9mIHRoZSBzdGF0aWMgZmFjdG9yeSBtZXRob2RzIHRvIHJlZmVyZW5jZSBhbiBleGlzdGluZyBzdG9yZS5cbiAqL1xuZXhwb3J0IGNsYXNzIFZlY3RvclN0b3JlIHtcbiAgLyoqXG4gICAqIEFuIGV4aXN0aW5nIHZlY3RvciBpbmRleCBpbiBhbiBBbWF6b24gT3BlblNlYXJjaCBTZXJ2ZXJsZXNzIGNvbGxlY3Rpb24uXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIG9wZW5TZWFyY2hTZXJ2ZXJsZXNzKHByb3BzOiBPcGVuU2VhcmNoU2VydmVybGVzc1ZlY3RvclN0b3JlUHJvcHMpOiBWZWN0b3JTdG9yZSB7XG4gICAgcmV0dXJuIG5ldyBWZWN0b3JTdG9yZShuZXcgS25vd2xlZGdlQmFzZU9wZW5TZWFyY2hTZXJ2ZXJsZXNzU3RvcmFnZShwcm9wcykpO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBtaXhpbiB0aGF0IGNvbmZpZ3VyZXMgYSBrbm93bGVkZ2UgYmFzZSB0byB1c2UgdGhpcyB2ZWN0b3Igc3RvcmUuXG4gICAqXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IF9taXhpbjogSU1peGluO1xuXG4gIHByaXZhdGUgY29uc3RydWN0b3IobWl4aW46IElNaXhpbikge1xuICAgIHRoaXMuX21peGluID0gbWl4aW47XG4gIH1cbn1cbiJdfQ==