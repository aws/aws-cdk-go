"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.GrantableRoles = void 0;
const aws_cdk_lib_1 = require("aws-cdk-lib");
const iam = __importStar(require("aws-cdk-lib/aws-iam"));
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const registries = new WeakMap();
/**
 * Finds the grantable role for a role ARN, in two steps: the role reference for
 * the ARN, then the grantable for that role reference.
 */
class GrantableRoles {
    /** The registry for the Stage that `construct` belongs to, or for its construct tree if there is no Stage. */
    static of(construct) {
        const root = aws_cdk_lib_1.Stage.of(construct) ?? construct.node.root;
        let registry = registries.get(root);
        if (registry === undefined) {
            registry = new GrantableRoles();
            registries.set(root, registry);
        }
        return registry;
    }
    roleRefsByArn = new Map();
    constructor() { }
    registerRoleObject(roleArn, roleRef) {
        this.roleRefsByArn.set(roleArn, roleRef);
    }
    /** The role to grant to for `roleArn`. */
    forRoleArn(roleArn) {
        // The role reference: the registered one, else the role the ARN references, which is
        // the iam.Role that owns the iam.CfnRole if there is one, since a CfnRole can't be granted to
        let roleRef = this.roleRefsByArn.get(roleArn);
        if (roleRef === undefined) {
            const reversed = aws_cdk_lib_1.Tokenization.reverse(roleArn, { failConcat: false });
            if (!aws_cdk_lib_1.Reference.isReference(reversed) || !iam.CfnRole.isCfnRole(reversed.target)) {
                throw new aws_cdk_lib_1.UnscopedValidationError((0, helpers_internal_1.lit) `RoleNotFoundForArn`, 'cannot determine the role for roleArn; it must reference an iam.Role defined in this app');
            }
            const cfnRole = reversed.target;
            const owner = cfnRole.node.scope;
            roleRef = iam.Role.isRole(owner) && owner.node.defaultChild === cfnRole ? owner : cfnRole;
        }
        // The grantable: the role reference itself, if it can be granted to
        const grantable = roleRef;
        if (grantable.grantPrincipal?.addToPrincipalPolicy === undefined) {
            throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `RoleNotGrantable`, `role ${roleRef.node.path} cannot be granted permissions; use an iam.Role`, roleRef);
        }
        return grantable;
    }
}
exports.GrantableRoles = GrantableRoles;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhbnRhYmxlLXJvbGVzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZ3JhbnRhYmxlLXJvbGVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDZDQUF1RztBQUN2Ryx5REFBMkM7QUFDM0MsNEVBQTREO0FBRzVELE1BQU0sVUFBVSxHQUFHLElBQUksT0FBTyxFQUE4QixDQUFDO0FBRTdEOzs7R0FHRztBQUNILE1BQWEsY0FBYztJQUN6Qiw4R0FBOEc7SUFDdkcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxTQUFxQjtRQUNwQyxNQUFNLElBQUksR0FBRyxtQkFBSyxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUN4RCxJQUFJLFFBQVEsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BDLElBQUksUUFBUSxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQzNCLFFBQVEsR0FBRyxJQUFJLGNBQWMsRUFBRSxDQUFDO1lBQ2hDLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQ2pDLENBQUM7UUFDRCxPQUFPLFFBQVEsQ0FBQztLQUNqQjtJQUVnQixhQUFhLEdBQUcsSUFBSSxHQUFHLEVBQXdCLENBQUM7SUFFakUsaUJBQXdCO0lBRWpCLGtCQUFrQixDQUFDLE9BQWUsRUFBRSxPQUFxQjtRQUM5RCxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7S0FDMUM7SUFFRCwwQ0FBMEM7SUFDbkMsVUFBVSxDQUFDLE9BQWU7UUFDL0IscUZBQXFGO1FBQ3JGLDhGQUE4RjtRQUM5RixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM5QyxJQUFJLE9BQU8sS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUMxQixNQUFNLFFBQVEsR0FBRywwQkFBWSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztZQUN0RSxJQUFJLENBQUMsdUJBQVMsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztnQkFDaEYsTUFBTSxJQUFJLHFDQUF1QixDQUMvQixJQUFBLHNCQUFHLEVBQUEsb0JBQW9CLEVBQ3ZCLDBGQUEwRixDQUMzRixDQUFDO1lBQ0osQ0FBQztZQUNELE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUM7WUFDaEMsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDakMsT0FBTyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7UUFDNUYsQ0FBQztRQUVELG9FQUFvRTtRQUNwRSxNQUFNLFNBQVMsR0FBRyxPQUFpRCxDQUFDO1FBQ3BFLElBQUksU0FBUyxDQUFDLGNBQWMsRUFBRSxvQkFBb0IsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUNqRSxNQUFNLElBQUksNkJBQWUsQ0FDdkIsSUFBQSxzQkFBRyxFQUFBLGtCQUFrQixFQUNyQixRQUFRLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxpREFBaUQsRUFDMUUsT0FBTyxDQUNSLENBQUM7UUFDSixDQUFDO1FBQ0QsT0FBTyxTQUEwQyxDQUFDO0tBQ25EO0NBQ0Y7QUFqREQsd0NBaURDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUmVmZXJlbmNlLCBTdGFnZSwgVG9rZW5pemF0aW9uLCBVbnNjb3BlZFZhbGlkYXRpb25FcnJvciwgVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnYXdzLWNkay1saWInO1xuaW1wb3J0ICogYXMgaWFtIGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0IHsgbGl0IH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvaGVscGVycy1pbnRlcm5hbCc7XG5pbXBvcnQgdHlwZSB7IElDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcblxuY29uc3QgcmVnaXN0cmllcyA9IG5ldyBXZWFrTWFwPElDb25zdHJ1Y3QsIEdyYW50YWJsZVJvbGVzPigpO1xuXG4vKipcbiAqIEZpbmRzIHRoZSBncmFudGFibGUgcm9sZSBmb3IgYSByb2xlIEFSTiwgaW4gdHdvIHN0ZXBzOiB0aGUgcm9sZSByZWZlcmVuY2UgZm9yXG4gKiB0aGUgQVJOLCB0aGVuIHRoZSBncmFudGFibGUgZm9yIHRoYXQgcm9sZSByZWZlcmVuY2UuXG4gKi9cbmV4cG9ydCBjbGFzcyBHcmFudGFibGVSb2xlcyB7XG4gIC8qKiBUaGUgcmVnaXN0cnkgZm9yIHRoZSBTdGFnZSB0aGF0IGBjb25zdHJ1Y3RgIGJlbG9uZ3MgdG8sIG9yIGZvciBpdHMgY29uc3RydWN0IHRyZWUgaWYgdGhlcmUgaXMgbm8gU3RhZ2UuICovXG4gIHB1YmxpYyBzdGF0aWMgb2YoY29uc3RydWN0OiBJQ29uc3RydWN0KTogR3JhbnRhYmxlUm9sZXMge1xuICAgIGNvbnN0IHJvb3QgPSBTdGFnZS5vZihjb25zdHJ1Y3QpID8/IGNvbnN0cnVjdC5ub2RlLnJvb3Q7XG4gICAgbGV0IHJlZ2lzdHJ5ID0gcmVnaXN0cmllcy5nZXQocm9vdCk7XG4gICAgaWYgKHJlZ2lzdHJ5ID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHJlZ2lzdHJ5ID0gbmV3IEdyYW50YWJsZVJvbGVzKCk7XG4gICAgICByZWdpc3RyaWVzLnNldChyb290LCByZWdpc3RyeSk7XG4gICAgfVxuICAgIHJldHVybiByZWdpc3RyeTtcbiAgfVxuXG4gIHByaXZhdGUgcmVhZG9ubHkgcm9sZVJlZnNCeUFybiA9IG5ldyBNYXA8c3RyaW5nLCBpYW0uSVJvbGVSZWY+KCk7XG5cbiAgcHJpdmF0ZSBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgcHVibGljIHJlZ2lzdGVyUm9sZU9iamVjdChyb2xlQXJuOiBzdHJpbmcsIHJvbGVSZWY6IGlhbS5JUm9sZVJlZik6IHZvaWQge1xuICAgIHRoaXMucm9sZVJlZnNCeUFybi5zZXQocm9sZUFybiwgcm9sZVJlZik7XG4gIH1cblxuICAvKiogVGhlIHJvbGUgdG8gZ3JhbnQgdG8gZm9yIGByb2xlQXJuYC4gKi9cbiAgcHVibGljIGZvclJvbGVBcm4ocm9sZUFybjogc3RyaW5nKTogaWFtLklSb2xlUmVmICYgaWFtLklHcmFudGFibGUge1xuICAgIC8vIFRoZSByb2xlIHJlZmVyZW5jZTogdGhlIHJlZ2lzdGVyZWQgb25lLCBlbHNlIHRoZSByb2xlIHRoZSBBUk4gcmVmZXJlbmNlcywgd2hpY2ggaXNcbiAgICAvLyB0aGUgaWFtLlJvbGUgdGhhdCBvd25zIHRoZSBpYW0uQ2ZuUm9sZSBpZiB0aGVyZSBpcyBvbmUsIHNpbmNlIGEgQ2ZuUm9sZSBjYW4ndCBiZSBncmFudGVkIHRvXG4gICAgbGV0IHJvbGVSZWYgPSB0aGlzLnJvbGVSZWZzQnlBcm4uZ2V0KHJvbGVBcm4pO1xuICAgIGlmIChyb2xlUmVmID09PSB1bmRlZmluZWQpIHtcbiAgICAgIGNvbnN0IHJldmVyc2VkID0gVG9rZW5pemF0aW9uLnJldmVyc2Uocm9sZUFybiwgeyBmYWlsQ29uY2F0OiBmYWxzZSB9KTtcbiAgICAgIGlmICghUmVmZXJlbmNlLmlzUmVmZXJlbmNlKHJldmVyc2VkKSB8fCAhaWFtLkNmblJvbGUuaXNDZm5Sb2xlKHJldmVyc2VkLnRhcmdldCkpIHtcbiAgICAgICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKFxuICAgICAgICAgIGxpdGBSb2xlTm90Rm91bmRGb3JBcm5gLFxuICAgICAgICAgICdjYW5ub3QgZGV0ZXJtaW5lIHRoZSByb2xlIGZvciByb2xlQXJuOyBpdCBtdXN0IHJlZmVyZW5jZSBhbiBpYW0uUm9sZSBkZWZpbmVkIGluIHRoaXMgYXBwJyxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNmblJvbGUgPSByZXZlcnNlZC50YXJnZXQ7XG4gICAgICBjb25zdCBvd25lciA9IGNmblJvbGUubm9kZS5zY29wZTtcbiAgICAgIHJvbGVSZWYgPSBpYW0uUm9sZS5pc1JvbGUob3duZXIpICYmIG93bmVyLm5vZGUuZGVmYXVsdENoaWxkID09PSBjZm5Sb2xlID8gb3duZXIgOiBjZm5Sb2xlO1xuICAgIH1cblxuICAgIC8vIFRoZSBncmFudGFibGU6IHRoZSByb2xlIHJlZmVyZW5jZSBpdHNlbGYsIGlmIGl0IGNhbiBiZSBncmFudGVkIHRvXG4gICAgY29uc3QgZ3JhbnRhYmxlID0gcm9sZVJlZiBhcyBpYW0uSVJvbGVSZWYgJiBQYXJ0aWFsPGlhbS5JR3JhbnRhYmxlPjtcbiAgICBpZiAoZ3JhbnRhYmxlLmdyYW50UHJpbmNpcGFsPy5hZGRUb1ByaW5jaXBhbFBvbGljeSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKFxuICAgICAgICBsaXRgUm9sZU5vdEdyYW50YWJsZWAsXG4gICAgICAgIGByb2xlICR7cm9sZVJlZi5ub2RlLnBhdGh9IGNhbm5vdCBiZSBncmFudGVkIHBlcm1pc3Npb25zOyB1c2UgYW4gaWFtLlJvbGVgLFxuICAgICAgICByb2xlUmVmLFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIGdyYW50YWJsZSBhcyBpYW0uSVJvbGVSZWYgJiBpYW0uSUdyYW50YWJsZTtcbiAgfVxufVxuIl19