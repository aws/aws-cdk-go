"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.VECTOR_KNOWLEDGE_BASE_TYPE = void 0;
exports.knowledgeBaseArnFromId = knowledgeBaseArnFromId;
exports.createKnowledgeBaseServiceRole = createKnowledgeBaseServiceRole;
exports.validateKnowledgeBaseProps = validateKnowledgeBaseProps;
const aws_cdk_lib_1 = require("aws-cdk-lib");
const iam = __importStar(require("aws-cdk-lib/aws-iam"));
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
/**
 * The `KnowledgeBaseConfiguration.Type` value of a vector knowledge base.
 */
exports.VECTOR_KNOWLEDGE_BASE_TYPE = 'VECTOR';
/**
 * Build the ARN of a knowledge base in the scope's account and region.
 */
function knowledgeBaseArnFromId(scope, knowledgeBaseId) {
    return aws_cdk_lib_1.Stack.of(scope).formatArn({
        service: 'bedrock',
        resource: 'knowledge-base',
        resourceName: knowledgeBaseId,
        arnFormat: aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME,
    });
}
/**
 * Create the service role Amazon Bedrock assumes to operate a knowledge base,
 * trusted only for knowledge bases in the scope's account and region
 */
function createKnowledgeBaseServiceRole(scope) {
    return new iam.Role(scope, 'Role', {
        assumedBy: new iam.ServicePrincipal('bedrock.amazonaws.com', {
            conditions: {
                StringEquals: {
                    'aws:SourceAccount': aws_cdk_lib_1.Stack.of(scope).account,
                },
                ArnLike: {
                    'aws:SourceArn': aws_cdk_lib_1.Stack.of(scope).formatArn({
                        service: 'bedrock',
                        resource: 'knowledge-base',
                        resourceName: '*',
                        arnFormat: aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME,
                    }),
                },
            },
        }),
    });
}
/**
 * Validate the knowledge base name and description against the constraints
 * of `AWS::Bedrock::KnowledgeBase`.
 */
function validateKnowledgeBaseProps(scope, props) {
    if (props.knowledgeBaseName !== undefined && !aws_cdk_lib_1.Token.isUnresolved(props.knowledgeBaseName)
        && !/^([0-9a-zA-Z][_-]?){1,100}$/.test(props.knowledgeBaseName)) {
        throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `InvalidKnowledgeBaseName`, `knowledgeBaseName ${JSON.stringify(props.knowledgeBaseName)} must be 1-100 characters of letters, digits, hyphens and underscores without consecutive hyphens or underscores`, scope);
    }
    if (props.description !== undefined && !aws_cdk_lib_1.Token.isUnresolved(props.description)
        && (props.description.length < 1 || props.description.length > 200)) {
        throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `InvalidKnowledgeBaseDescription`, `description must be 1-200 characters, got ${props.description.length}`, scope);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia25vd2xlZGdlLWJhc2UtaGVscGVycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImtub3dsZWRnZS1iYXNlLWhlbHBlcnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBY0Esd0RBT0M7QUFNRCx3RUFrQkM7QUFNRCxnRUFrQkM7QUFyRUQsNkNBQXVFO0FBQ3ZFLHlEQUEyQztBQUMzQyw0RUFBNEQ7QUFJNUQ7O0dBRUc7QUFDVSxRQUFBLDBCQUEwQixHQUFHLFFBQVEsQ0FBQztBQUVuRDs7R0FFRztBQUNILFNBQWdCLHNCQUFzQixDQUFDLEtBQWdCLEVBQUUsZUFBdUI7SUFDOUUsT0FBTyxtQkFBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUM7UUFDL0IsT0FBTyxFQUFFLFNBQVM7UUFDbEIsUUFBUSxFQUFFLGdCQUFnQjtRQUMxQixZQUFZLEVBQUUsZUFBZTtRQUM3QixTQUFTLEVBQUUsdUJBQVMsQ0FBQyxtQkFBbUI7S0FDekMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUVEOzs7R0FHRztBQUNILFNBQWdCLDhCQUE4QixDQUFDLEtBQWdCO0lBQzdELE9BQU8sSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUU7UUFDakMsU0FBUyxFQUFFLElBQUksR0FBRyxDQUFDLGdCQUFnQixDQUFDLHVCQUF1QixFQUFFO1lBQzNELFVBQVUsRUFBRTtnQkFDVixZQUFZLEVBQUU7b0JBQ1osbUJBQW1CLEVBQUUsbUJBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTztpQkFDN0M7Z0JBQ0QsT0FBTyxFQUFFO29CQUNQLGVBQWUsRUFBRSxtQkFBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUM7d0JBQ3pDLE9BQU8sRUFBRSxTQUFTO3dCQUNsQixRQUFRLEVBQUUsZ0JBQWdCO3dCQUMxQixZQUFZLEVBQUUsR0FBRzt3QkFDakIsU0FBUyxFQUFFLHVCQUFTLENBQUMsbUJBQW1CO3FCQUN6QyxDQUFDO2lCQUNIO2FBQ0Y7U0FDRixDQUFDO0tBQ0gsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUVEOzs7R0FHRztBQUNILFNBQWdCLDBCQUEwQixDQUFDLEtBQWdCLEVBQUUsS0FBeUI7SUFDcEYsSUFBSSxLQUFLLENBQUMsaUJBQWlCLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDO1dBQ3BGLENBQUMsNkJBQTZCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUM7UUFDbEUsTUFBTSxJQUFJLDZCQUFlLENBQ3ZCLElBQUEsc0JBQUcsRUFBQSwwQkFBMEIsRUFDN0IscUJBQXFCLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLGtIQUFrSCxFQUM5SyxLQUFLLENBQ04sQ0FBQztJQUNKLENBQUM7SUFFRCxJQUFJLEtBQUssQ0FBQyxXQUFXLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQztXQUN4RSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQ3RFLE1BQU0sSUFBSSw2QkFBZSxDQUN2QixJQUFBLHNCQUFHLEVBQUEsaUNBQWlDLEVBQ3BDLDZDQUE2QyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxFQUN2RSxLQUFLLENBQ04sQ0FBQztJQUNKLENBQUM7QUFDSCxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXJuRm9ybWF0LCBTdGFjaywgVG9rZW4sIFZhbGlkYXRpb25FcnJvciB9IGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCAqIGFzIGlhbSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCB7IGxpdCB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2hlbHBlcnMtaW50ZXJuYWwnO1xuaW1wb3J0IHR5cGUgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcbmltcG9ydCB0eXBlIHsgS25vd2xlZGdlQmFzZVByb3BzIH0gZnJvbSAnLi4va25vd2xlZGdlLWJhc2UnO1xuXG4vKipcbiAqIFRoZSBgS25vd2xlZGdlQmFzZUNvbmZpZ3VyYXRpb24uVHlwZWAgdmFsdWUgb2YgYSB2ZWN0b3Iga25vd2xlZGdlIGJhc2UuXG4gKi9cbmV4cG9ydCBjb25zdCBWRUNUT1JfS05PV0xFREdFX0JBU0VfVFlQRSA9ICdWRUNUT1InO1xuXG4vKipcbiAqIEJ1aWxkIHRoZSBBUk4gb2YgYSBrbm93bGVkZ2UgYmFzZSBpbiB0aGUgc2NvcGUncyBhY2NvdW50IGFuZCByZWdpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBrbm93bGVkZ2VCYXNlQXJuRnJvbUlkKHNjb3BlOiBDb25zdHJ1Y3QsIGtub3dsZWRnZUJhc2VJZDogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIFN0YWNrLm9mKHNjb3BlKS5mb3JtYXRBcm4oe1xuICAgIHNlcnZpY2U6ICdiZWRyb2NrJyxcbiAgICByZXNvdXJjZTogJ2tub3dsZWRnZS1iYXNlJyxcbiAgICByZXNvdXJjZU5hbWU6IGtub3dsZWRnZUJhc2VJZCxcbiAgICBhcm5Gb3JtYXQ6IEFybkZvcm1hdC5TTEFTSF9SRVNPVVJDRV9OQU1FLFxuICB9KTtcbn1cblxuLyoqXG4gKiBDcmVhdGUgdGhlIHNlcnZpY2Ugcm9sZSBBbWF6b24gQmVkcm9jayBhc3N1bWVzIHRvIG9wZXJhdGUgYSBrbm93bGVkZ2UgYmFzZSxcbiAqIHRydXN0ZWQgb25seSBmb3Iga25vd2xlZGdlIGJhc2VzIGluIHRoZSBzY29wZSdzIGFjY291bnQgYW5kIHJlZ2lvblxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlS25vd2xlZGdlQmFzZVNlcnZpY2VSb2xlKHNjb3BlOiBDb25zdHJ1Y3QpOiBpYW0uUm9sZSB7XG4gIHJldHVybiBuZXcgaWFtLlJvbGUoc2NvcGUsICdSb2xlJywge1xuICAgIGFzc3VtZWRCeTogbmV3IGlhbS5TZXJ2aWNlUHJpbmNpcGFsKCdiZWRyb2NrLmFtYXpvbmF3cy5jb20nLCB7XG4gICAgICBjb25kaXRpb25zOiB7XG4gICAgICAgIFN0cmluZ0VxdWFsczoge1xuICAgICAgICAgICdhd3M6U291cmNlQWNjb3VudCc6IFN0YWNrLm9mKHNjb3BlKS5hY2NvdW50LFxuICAgICAgICB9LFxuICAgICAgICBBcm5MaWtlOiB7XG4gICAgICAgICAgJ2F3czpTb3VyY2VBcm4nOiBTdGFjay5vZihzY29wZSkuZm9ybWF0QXJuKHtcbiAgICAgICAgICAgIHNlcnZpY2U6ICdiZWRyb2NrJyxcbiAgICAgICAgICAgIHJlc291cmNlOiAna25vd2xlZGdlLWJhc2UnLFxuICAgICAgICAgICAgcmVzb3VyY2VOYW1lOiAnKicsXG4gICAgICAgICAgICBhcm5Gb3JtYXQ6IEFybkZvcm1hdC5TTEFTSF9SRVNPVVJDRV9OQU1FLFxuICAgICAgICAgIH0pLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9KSxcbiAgfSk7XG59XG5cbi8qKlxuICogVmFsaWRhdGUgdGhlIGtub3dsZWRnZSBiYXNlIG5hbWUgYW5kIGRlc2NyaXB0aW9uIGFnYWluc3QgdGhlIGNvbnN0cmFpbnRzXG4gKiBvZiBgQVdTOjpCZWRyb2NrOjpLbm93bGVkZ2VCYXNlYC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHZhbGlkYXRlS25vd2xlZGdlQmFzZVByb3BzKHNjb3BlOiBDb25zdHJ1Y3QsIHByb3BzOiBLbm93bGVkZ2VCYXNlUHJvcHMpOiB2b2lkIHtcbiAgaWYgKHByb3BzLmtub3dsZWRnZUJhc2VOYW1lICE9PSB1bmRlZmluZWQgJiYgIVRva2VuLmlzVW5yZXNvbHZlZChwcm9wcy5rbm93bGVkZ2VCYXNlTmFtZSlcbiAgICAmJiAhL14oWzAtOWEtekEtWl1bXy1dPyl7MSwxMDB9JC8udGVzdChwcm9wcy5rbm93bGVkZ2VCYXNlTmFtZSkpIHtcbiAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKFxuICAgICAgbGl0YEludmFsaWRLbm93bGVkZ2VCYXNlTmFtZWAsXG4gICAgICBga25vd2xlZGdlQmFzZU5hbWUgJHtKU09OLnN0cmluZ2lmeShwcm9wcy5rbm93bGVkZ2VCYXNlTmFtZSl9IG11c3QgYmUgMS0xMDAgY2hhcmFjdGVycyBvZiBsZXR0ZXJzLCBkaWdpdHMsIGh5cGhlbnMgYW5kIHVuZGVyc2NvcmVzIHdpdGhvdXQgY29uc2VjdXRpdmUgaHlwaGVucyBvciB1bmRlcnNjb3Jlc2AsXG4gICAgICBzY29wZSxcbiAgICApO1xuICB9XG5cbiAgaWYgKHByb3BzLmRlc2NyaXB0aW9uICE9PSB1bmRlZmluZWQgJiYgIVRva2VuLmlzVW5yZXNvbHZlZChwcm9wcy5kZXNjcmlwdGlvbilcbiAgICAmJiAocHJvcHMuZGVzY3JpcHRpb24ubGVuZ3RoIDwgMSB8fCBwcm9wcy5kZXNjcmlwdGlvbi5sZW5ndGggPiAyMDApKSB7XG4gICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihcbiAgICAgIGxpdGBJbnZhbGlkS25vd2xlZGdlQmFzZURlc2NyaXB0aW9uYCxcbiAgICAgIGBkZXNjcmlwdGlvbiBtdXN0IGJlIDEtMjAwIGNoYXJhY3RlcnMsIGdvdCAke3Byb3BzLmRlc2NyaXB0aW9uLmxlbmd0aH1gLFxuICAgICAgc2NvcGUsXG4gICAgKTtcbiAgfVxufVxuIl19