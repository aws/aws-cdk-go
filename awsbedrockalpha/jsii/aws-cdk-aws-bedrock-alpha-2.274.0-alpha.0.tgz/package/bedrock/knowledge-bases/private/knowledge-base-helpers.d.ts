import * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import type { KnowledgeBaseProps } from '../knowledge-base';
/**
 * The `KnowledgeBaseConfiguration.Type` value of a vector knowledge base.
 */
export declare const VECTOR_KNOWLEDGE_BASE_TYPE = "VECTOR";
/**
 * Build the ARN of a knowledge base in the scope's account and region.
 */
export declare function knowledgeBaseArnFromId(scope: Construct, knowledgeBaseId: string): string;
/**
 * Create the service role Amazon Bedrock assumes to operate a knowledge base,
 * trusted only for knowledge bases in the scope's account and region
 */
export declare function createKnowledgeBaseServiceRole(scope: Construct): iam.Role;
/**
 * Validate the knowledge base name and description against the constraints
 * of `AWS::Bedrock::KnowledgeBase`.
 */
export declare function validateKnowledgeBaseProps(scope: Construct, props: KnowledgeBaseProps): void;
