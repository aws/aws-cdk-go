import * as iam from 'aws-cdk-lib/aws-iam';
import type { IConstruct } from 'constructs';
/**
 * Finds the grantable role for a role ARN, in two steps: the role reference for
 * the ARN, then the grantable for that role reference.
 */
export declare class GrantableRoles {
    /** The registry for the Stage that `construct` belongs to, or for its construct tree if there is no Stage. */
    static of(construct: IConstruct): GrantableRoles;
    private readonly roleRefsByArn;
    private constructor();
    registerRoleObject(roleArn: string, roleRef: iam.IRoleRef): void;
    /** The role to grant to for `roleArn`. */
    forRoleArn(roleArn: string): iam.IRoleRef & iam.IGrantable;
}
