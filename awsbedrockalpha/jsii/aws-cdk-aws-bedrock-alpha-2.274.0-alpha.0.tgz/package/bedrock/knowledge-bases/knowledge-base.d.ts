import type { IResource } from 'aws-cdk-lib';
import { Resource } from 'aws-cdk-lib';
import type { IKnowledgeBaseRef, KnowledgeBaseReference } from 'aws-cdk-lib/aws-bedrock';
import * as iam from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import { KnowledgeBaseReflection } from './knowledge-base-reflection';
import type { KnowledgeBaseType } from './knowledge-base-type';
import { KnowledgeBaseGrants } from '../../lib/bedrock-grants.generated';
/**
 * Represents an Amazon Bedrock knowledge base of any type, either created
 * with the CDK or imported
 */
export interface IKnowledgeBase extends IResource, IKnowledgeBaseRef, iam.IGrantable {
    /**
     * The ARN of the knowledge base.
     *
     * @attribute
     */
    readonly knowledgeBaseArn: string;
    /**
     * The unique identifier of the knowledge base.
     *
     * @attribute
     */
    readonly knowledgeBaseId: string;
    /**
     * The service role that Amazon Bedrock assumes to operate the knowledge base.
     *
     * To add permissions to the role, use `addToRolePolicy()` or grant to the
     * knowledge base itself, which is an `IGrantable`.
     *
     * Undefined for imported knowledge bases whose role was not provided.
     */
    readonly role?: iam.IRoleRef;
    /**
     * Grant permissions on this knowledge base to IAM principals.
     */
    readonly grants: KnowledgeBaseGrants;
    /**
     * Resolves the underlying `CfnKnowledgeBase` from the construct tree
     */
    readonly reflections: KnowledgeBaseReflection;
    /**
     * Adds a statement to the IAM policy of the knowledge base service role.
     *
     * For a referenced knowledge base whose role was not provided, the statement
     * cannot be applied; a warning is emitted with the statement to add to the
     * role manually.
     */
    addToRolePolicy(statement: iam.PolicyStatement): void;
}
/**
 * Properties for a knowledge base.
 */
export interface KnowledgeBaseProps {
    /**
     * The type of the knowledge base and its type-specific configuration.
     */
    readonly type: KnowledgeBaseType;
    /**
     * The name of the knowledge base.
     *
     * Must be 1-100 characters of letters, digits, hyphens and underscores, and
     * must not contain consecutive hyphens or underscores.
     *
     * @default - a unique name is generated
     */
    readonly knowledgeBaseName?: string;
    /**
     * A description of the knowledge base.
     *
     * Must be 1-200 characters.
     *
     * @default - no description
     */
    readonly description?: string;
    /**
     * The service role that Amazon Bedrock assumes to operate the knowledge base.
     *
     * The permissions the knowledge base needs to reach its data store and
     * models are granted to this role.
     *
     * @default - a new role is created, trusted by `bedrock.amazonaws.com` and
     * scoped to knowledge bases in this account
     */
    readonly role?: iam.IRoleRef & iam.IGrantable;
    /**
     * Tags to apply to the knowledge base.
     *
     * @default - no tags
     */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
 * Attributes for referencing an existing knowledge base.
 */
export interface KnowledgeBaseAttributes {
    /**
     * The ARN of the knowledge base.
     */
    readonly knowledgeBaseArn: string;
    /**
     * The service role of the knowledge base.
     *
     * @default - the role is unknown
     */
    readonly role?: iam.IRoleRef & iam.IGrantable;
}
/**
 * Base class for knowledge bases of any type, created or referenced.
 */
export declare abstract class KnowledgeBaseBase extends Resource implements IKnowledgeBase {
    abstract readonly knowledgeBaseArn: string;
    abstract readonly knowledgeBaseId: string;
    abstract readonly role?: iam.IRoleRef;
    abstract readonly grantPrincipal: iam.IPrincipal;
    get knowledgeBaseRef(): KnowledgeBaseReference;
    get grants(): KnowledgeBaseGrants;
    get reflections(): KnowledgeBaseReflection;
    addToRolePolicy(statement: iam.PolicyStatement): void;
}
/**
 * An Amazon Bedrock knowledge base.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/knowledge-base.html
 * @resource AWS::Bedrock::KnowledgeBase
 */
export declare class KnowledgeBase extends KnowledgeBaseBase {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Reference an existing knowledge base by ARN.
     */
    static fromKnowledgeBaseArn(scope: Construct, id: string, knowledgeBaseArn: string): IKnowledgeBase;
    /**
     * Reference an existing knowledge base by ID.
     *
     * The knowledge base is assumed to be in the same account and region as the scope.
     */
    static fromKnowledgeBaseId(scope: Construct, id: string, knowledgeBaseId: string): IKnowledgeBase;
    /**
     * Reference an existing knowledge base by its attributes.
     */
    static fromKnowledgeBaseAttributes(scope: Construct, id: string, attrs: KnowledgeBaseAttributes): IKnowledgeBase;
    private readonly resource;
    /**
     * The service role that Amazon Bedrock assumes to operate the knowledge base.
     *
     * Always defined for knowledge bases created with this construct.
     */
    readonly role?: iam.IRoleRef;
    readonly grantPrincipal: iam.IPrincipal;
    constructor(scope: Construct, id: string, props: KnowledgeBaseProps);
    get knowledgeBaseArn(): string;
    get knowledgeBaseId(): string;
}
