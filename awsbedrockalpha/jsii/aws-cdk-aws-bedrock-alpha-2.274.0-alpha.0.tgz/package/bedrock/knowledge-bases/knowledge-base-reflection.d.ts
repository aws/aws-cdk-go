import type { CfnKnowledgeBase, IKnowledgeBaseRef } from 'aws-cdk-lib/aws-bedrock';
/**
 * Provides read-only reflection on the configuration of a Bedrock knowledge base
 * underlying `CfnKnowledgeBase` resource
 *
 * Use `KnowledgeBaseReflection.of()` to obtain an instance from any KnowledgeBase reference.
 * All getters read directly from the L1 resource, providing a single source of
 * truth regardless of whether the knowledge base was created as an L2, imported, or
 * constructed directly as a CfnKnowledgeBase.
 */
export declare class KnowledgeBaseReflection {
    private readonly ref;
    /**
     * Creates a reflection facade for a knowledge base reference.
     */
    static of(knowledgeBaseRef: IKnowledgeBaseRef): KnowledgeBaseReflection;
    private readonly _knowledgeBase?;
    private constructor();
    /**
     * The underlying L1 knowledge base resource.
     *
     * @throws If the underlying CfnKnowledgeBase resource cannot be found.
     */
    get knowledgeBase(): CfnKnowledgeBase;
}
