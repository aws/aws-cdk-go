"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KnowledgeBaseType = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const knowledge_base_helpers_1 = require("./private/knowledge-base-helpers");
const knowledge_base_1 = require("../mixins/knowledge-base");
/**
 * The type of a knowledge base, which determines how its data is stored and queried.
 *
 * Use one of the static factory methods to configure a type. To configure a
 * `CfnKnowledgeBase` as a type, apply `mixins.KnowledgeBaseTypeConfiguration`.
 */
class KnowledgeBaseType {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.KnowledgeBaseType", version: "2.274.0-alpha.0" };
    /**
     * A knowledge base that stores vector embeddings of ingested documents in a
     * vector store and retrieves them by similarity search.
     */
    static vector(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_VectorKnowledgeBaseTypeProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.vector);
            }
            throw error;
        }
        const mixins = [
            new knowledge_base_1.KnowledgeBaseEmbeddingsModel({ embeddingsModel: props.embeddingsModel, vectorType: props.vectorType }),
            props.vectorStore._mixin,
        ];
        if (props.supplementalDataStorageBucket !== undefined) {
            mixins.push(new knowledge_base_1.KnowledgeBaseSupplementalDataStorage({ bucket: props.supplementalDataStorageBucket }));
        }
        return new KnowledgeBaseType(knowledge_base_helpers_1.VECTOR_KNOWLEDGE_BASE_TYPE, mixins);
    }
    /**
     * The mixins that configure a knowledge base of this type.
     *
     * @internal
     */
    _mixins;
    /**
     * The value of `KnowledgeBaseConfiguration.Type`.
     *
     * @internal
     */
    _typeName;
    constructor(typeName, mixins) {
        this._typeName = typeName;
        this._mixins = mixins;
    }
}
exports.KnowledgeBaseType = KnowledgeBaseType;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia25vd2xlZGdlLWJhc2UtdHlwZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImtub3dsZWRnZS1iYXNlLXR5cGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFFQSw2RUFBOEU7QUFFOUUsNkRBQThHO0FBbUM5Rzs7Ozs7R0FLRztBQUNILE1BQWEsaUJBQWlCOztJQUM1Qjs7O09BR0c7SUFDSSxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQW1DOzs7Ozs7Ozs7O1FBQ3RELE1BQU0sTUFBTSxHQUFhO1lBQ3ZCLElBQUksNkNBQTRCLENBQUMsRUFBRSxlQUFlLEVBQUUsS0FBSyxDQUFDLGVBQWUsRUFBRSxVQUFVLEVBQUUsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQzFHLEtBQUssQ0FBQyxXQUFXLENBQUMsTUFBTTtTQUN6QixDQUFDO1FBQ0YsSUFBSSxLQUFLLENBQUMsNkJBQTZCLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDdEQsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLHFEQUFvQyxDQUFDLEVBQUUsTUFBTSxFQUFFLEtBQUssQ0FBQyw2QkFBNkIsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN6RyxDQUFDO1FBQ0QsT0FBTyxJQUFJLGlCQUFpQixDQUFDLG1EQUEwQixFQUFFLE1BQU0sQ0FBQyxDQUFDO0tBQ2xFO0lBRUQ7Ozs7T0FJRztJQUNhLE9BQU8sQ0FBVztJQUVsQzs7OztPQUlHO0lBQ2EsU0FBUyxDQUFTO0lBRWxDLFlBQW9CLFFBQWdCLEVBQUUsTUFBZ0I7UUFDcEQsSUFBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUM7UUFDMUIsSUFBSSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7S0FDdkI7O0FBakNILDhDQWtDQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlICogYXMgczMgZnJvbSAnYXdzLWNkay1saWIvYXdzLXMzJztcbmltcG9ydCB0eXBlIHsgSU1peGluIH0gZnJvbSAnY29uc3RydWN0cyc7XG5pbXBvcnQgeyBWRUNUT1JfS05PV0xFREdFX0JBU0VfVFlQRSB9IGZyb20gJy4vcHJpdmF0ZS9rbm93bGVkZ2UtYmFzZS1oZWxwZXJzJztcbmltcG9ydCB0eXBlIHsgVmVjdG9yU3RvcmUgfSBmcm9tICcuL3ZlY3Rvci1zdG9yZSc7XG5pbXBvcnQgeyBLbm93bGVkZ2VCYXNlRW1iZWRkaW5nc01vZGVsLCBLbm93bGVkZ2VCYXNlU3VwcGxlbWVudGFsRGF0YVN0b3JhZ2UgfSBmcm9tICcuLi9taXhpbnMva25vd2xlZGdlLWJhc2UnO1xuaW1wb3J0IHR5cGUgeyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsLCBWZWN0b3JUeXBlIH0gZnJvbSAnLi4vbW9kZWxzJztcblxuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBhIHZlY3RvciBrbm93bGVkZ2UgYmFzZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBWZWN0b3JLbm93bGVkZ2VCYXNlVHlwZVByb3BzIHtcbiAgLyoqXG4gICAqIFRoZSBtb2RlbCB1c2VkIHRvIGNyZWF0ZSB2ZWN0b3IgZW1iZWRkaW5ncyBmb3IgdGhlIGtub3dsZWRnZSBiYXNlLlxuICAgKi9cbiAgcmVhZG9ubHkgZW1iZWRkaW5nc01vZGVsOiBCZWRyb2NrRm91bmRhdGlvbk1vZGVsO1xuXG4gIC8qKlxuICAgKiBUaGUgdmVjdG9yIHN0b3JlIGluIHdoaWNoIHRoZSBlbWJlZGRpbmdzIGFyZSBzdG9yZWQgYW5kIHNlYXJjaGVkLlxuICAgKi9cbiAgcmVhZG9ubHkgdmVjdG9yU3RvcmU6IFZlY3RvclN0b3JlO1xuXG4gIC8qKlxuICAgKiBUaGUgZGF0YSB0eXBlIG9mIHRoZSB2ZWN0b3IgZW1iZWRkaW5ncy5cbiAgICpcbiAgICogQGRlZmF1bHQgVmVjdG9yVHlwZS5GTE9BVElOR19QT0lOVFxuICAgKi9cbiAgcmVhZG9ubHkgdmVjdG9yVHlwZT86IFZlY3RvclR5cGU7XG5cbiAgLyoqXG4gICAqIFRoZSBBbWF6b24gUzMgYnVja2V0IGluIHdoaWNoIG11bHRpbWVkaWEgY29udGVudCBleHRyYWN0ZWQgZnJvbVxuICAgKiBtdWx0aW1vZGFsIGRvY3VtZW50cyAoaW1hZ2VzLCBhdWRpbywgdmlkZW8pIGlzIHN0b3JlZC5cbiAgICpcbiAgICogUmVxdWlyZWQgd2hlbiB0aGUga25vd2xlZGdlIGJhc2UgaW5nZXN0cyBtdWx0aW1vZGFsIGNvbnRlbnQuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gbm8gc3VwcGxlbWVudGFsIGRhdGEgc3RvcmFnZTsgb25seSB0ZXh0IGNvbnRlbnQgaXMgaW5nZXN0ZWRcbiAgICovXG4gIHJlYWRvbmx5IHN1cHBsZW1lbnRhbERhdGFTdG9yYWdlQnVja2V0PzogczMuSUJ1Y2tldFJlZjtcbn1cblxuLyoqXG4gKiBUaGUgdHlwZSBvZiBhIGtub3dsZWRnZSBiYXNlLCB3aGljaCBkZXRlcm1pbmVzIGhvdyBpdHMgZGF0YSBpcyBzdG9yZWQgYW5kIHF1ZXJpZWQuXG4gKlxuICogVXNlIG9uZSBvZiB0aGUgc3RhdGljIGZhY3RvcnkgbWV0aG9kcyB0byBjb25maWd1cmUgYSB0eXBlLiBUbyBjb25maWd1cmUgYVxuICogYENmbktub3dsZWRnZUJhc2VgIGFzIGEgdHlwZSwgYXBwbHkgYG1peGlucy5Lbm93bGVkZ2VCYXNlVHlwZUNvbmZpZ3VyYXRpb25gLlxuICovXG5leHBvcnQgY2xhc3MgS25vd2xlZGdlQmFzZVR5cGUge1xuICAvKipcbiAgICogQSBrbm93bGVkZ2UgYmFzZSB0aGF0IHN0b3JlcyB2ZWN0b3IgZW1iZWRkaW5ncyBvZiBpbmdlc3RlZCBkb2N1bWVudHMgaW4gYVxuICAgKiB2ZWN0b3Igc3RvcmUgYW5kIHJldHJpZXZlcyB0aGVtIGJ5IHNpbWlsYXJpdHkgc2VhcmNoLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyB2ZWN0b3IocHJvcHM6IFZlY3Rvcktub3dsZWRnZUJhc2VUeXBlUHJvcHMpOiBLbm93bGVkZ2VCYXNlVHlwZSB7XG4gICAgY29uc3QgbWl4aW5zOiBJTWl4aW5bXSA9IFtcbiAgICAgIG5ldyBLbm93bGVkZ2VCYXNlRW1iZWRkaW5nc01vZGVsKHsgZW1iZWRkaW5nc01vZGVsOiBwcm9wcy5lbWJlZGRpbmdzTW9kZWwsIHZlY3RvclR5cGU6IHByb3BzLnZlY3RvclR5cGUgfSksXG4gICAgICBwcm9wcy52ZWN0b3JTdG9yZS5fbWl4aW4sXG4gICAgXTtcbiAgICBpZiAocHJvcHMuc3VwcGxlbWVudGFsRGF0YVN0b3JhZ2VCdWNrZXQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgbWl4aW5zLnB1c2gobmV3IEtub3dsZWRnZUJhc2VTdXBwbGVtZW50YWxEYXRhU3RvcmFnZSh7IGJ1Y2tldDogcHJvcHMuc3VwcGxlbWVudGFsRGF0YVN0b3JhZ2VCdWNrZXQgfSkpO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IEtub3dsZWRnZUJhc2VUeXBlKFZFQ1RPUl9LTk9XTEVER0VfQkFTRV9UWVBFLCBtaXhpbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBtaXhpbnMgdGhhdCBjb25maWd1cmUgYSBrbm93bGVkZ2UgYmFzZSBvZiB0aGlzIHR5cGUuXG4gICAqXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IF9taXhpbnM6IElNaXhpbltdO1xuXG4gIC8qKlxuICAgKiBUaGUgdmFsdWUgb2YgYEtub3dsZWRnZUJhc2VDb25maWd1cmF0aW9uLlR5cGVgLlxuICAgKlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBfdHlwZU5hbWU6IHN0cmluZztcblxuICBwcml2YXRlIGNvbnN0cnVjdG9yKHR5cGVOYW1lOiBzdHJpbmcsIG1peGluczogSU1peGluW10pIHtcbiAgICB0aGlzLl90eXBlTmFtZSA9IHR5cGVOYW1lO1xuICAgIHRoaXMuX21peGlucyA9IG1peGlucztcbiAgfVxufVxuIl19