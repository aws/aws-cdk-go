"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.KnowledgeBase = exports.KnowledgeBaseBase = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const aws_bedrock_1 = require("aws-cdk-lib/aws-bedrock");
const iam = __importStar(require("aws-cdk-lib/aws-iam"));
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
const knowledge_base_reflection_1 = require("./knowledge-base-reflection");
const grantable_roles_1 = require("./private/grantable-roles");
const knowledge_base_helpers_1 = require("./private/knowledge-base-helpers");
const bedrock_grants_generated_1 = require("../../lib/bedrock-grants.generated");
const knowledge_base_1 = require("../mixins/knowledge-base");
/**
 * Base class for knowledge bases of any type, created or referenced.
 */
class KnowledgeBaseBase extends aws_cdk_lib_1.Resource {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.KnowledgeBaseBase", version: "2.274.0-alpha.0" };
    get knowledgeBaseRef() {
        return {
            knowledgeBaseId: this.knowledgeBaseId,
            knowledgeBaseArn: this.knowledgeBaseArn,
        };
    }
    get grants() {
        return bedrock_grants_generated_1.KnowledgeBaseGrants.fromKnowledgeBase(this);
    }
    get reflections() {
        return knowledge_base_reflection_1.KnowledgeBaseReflection.of(this);
    }
    addToRolePolicy(statement) {
        this.grantPrincipal.addToPrincipalPolicy(statement);
    }
}
exports.KnowledgeBaseBase = KnowledgeBaseBase;
/**
 * An Amazon Bedrock knowledge base.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/knowledge-base.html
 * @resource AWS::Bedrock::KnowledgeBase
 */
let KnowledgeBase = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = KnowledgeBaseBase;
    let _instanceExtraInitializers = [];
    let _get_knowledgeBaseArn_decorators;
    let _get_knowledgeBaseId_decorators;
    var KnowledgeBase = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _get_knowledgeBaseArn_decorators = [helpers_internal_1.memoizedGetter];
            _get_knowledgeBaseId_decorators = [helpers_internal_1.memoizedGetter];
            __esDecorate(this, null, _get_knowledgeBaseArn_decorators, { kind: "getter", name: "knowledgeBaseArn", static: false, private: false, access: { has: obj => "knowledgeBaseArn" in obj, get: obj => obj.knowledgeBaseArn }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _get_knowledgeBaseId_decorators, { kind: "getter", name: "knowledgeBaseId", static: false, private: false, access: { has: obj => "knowledgeBaseId" in obj, get: obj => obj.knowledgeBaseId }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            KnowledgeBase = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.KnowledgeBase", version: "2.274.0-alpha.0" };
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.KnowledgeBase';
        /**
         * Reference an existing knowledge base by ARN.
         */
        static fromKnowledgeBaseArn(scope, id, knowledgeBaseArn) {
            return KnowledgeBase.fromKnowledgeBaseAttributes(scope, id, { knowledgeBaseArn });
        }
        /**
         * Reference an existing knowledge base by ID.
         *
         * The knowledge base is assumed to be in the same account and region as the scope.
         */
        static fromKnowledgeBaseId(scope, id, knowledgeBaseId) {
            return KnowledgeBase.fromKnowledgeBaseAttributes(scope, id, {
                knowledgeBaseArn: (0, knowledge_base_helpers_1.knowledgeBaseArnFromId)(scope, knowledgeBaseId),
            });
        }
        /**
         * Reference an existing knowledge base by its attributes.
         */
        static fromKnowledgeBaseAttributes(scope, id, attrs) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_KnowledgeBaseAttributes(attrs);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.fromKnowledgeBaseAttributes);
                }
                throw error;
            }
            class Import extends KnowledgeBaseBase {
                knowledgeBaseArn = attrs.knowledgeBaseArn;
                knowledgeBaseId = aws_cdk_lib_1.Stack.of(scope).splitArn(attrs.knowledgeBaseArn, aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME).resourceName;
                role = attrs.role;
                grantPrincipal = attrs.role?.grantPrincipal ?? new iam.UnknownPrincipal({ resource: this });
            }
            return new Import(scope, id, { environmentFromArn: attrs.knowledgeBaseArn });
        }
        resource = __runInitializers(this, _instanceExtraInitializers);
        /**
         * The service role that Amazon Bedrock assumes to operate the knowledge base.
         *
         * Always defined for knowledge bases created with this construct.
         */
        role;
        grantPrincipal;
        constructor(scope, id, props) {
            super(scope, id);
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_KnowledgeBaseProps(props);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, KnowledgeBase);
                }
                throw error;
            }
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            (0, knowledge_base_helpers_1.validateKnowledgeBaseProps)(this, props);
            const role = props.role ?? (0, knowledge_base_helpers_1.createKnowledgeBaseServiceRole)(this);
            this.role = role;
            this.grantPrincipal = role.grantPrincipal;
            this.resource = new aws_bedrock_1.CfnKnowledgeBase(this, 'Resource', {
                name: props.knowledgeBaseName ?? aws_cdk_lib_1.Names.uniqueResourceName(this, { maxLength: 100 }),
                description: props.description,
                roleArn: role.roleRef.roleArn,
                knowledgeBaseConfiguration: { type: props.type._typeName },
                tags: props.tags,
            });
            // TODO: Temporarily here ONLY to deal with Role.fromRoleArn() objects; this should be generalized
            // The type's mixins resolve the role from `roleArn` when applied, so it must be registered first.
            grantable_roles_1.GrantableRoles.of(this).registerRoleObject(role.roleRef.roleArn, role);
            this.with(new knowledge_base_1.KnowledgeBaseTypeConfiguration(props.type));
        }
        get knowledgeBaseArn() {
            return this.resource.knowledgeBaseRef.knowledgeBaseArn;
        }
        get knowledgeBaseId() {
            return this.resource.knowledgeBaseRef.knowledgeBaseId;
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return KnowledgeBase = _classThis;
})();
exports.KnowledgeBase = KnowledgeBase;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia25vd2xlZGdlLWJhc2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJrbm93bGVkZ2UtYmFzZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSw2Q0FBZ0U7QUFFaEUseURBQTJEO0FBQzNELHlEQUEyQztBQUMzQyw0RUFBdUU7QUFDdkUsOEVBQThFO0FBQzlFLDBFQUEwRTtBQUUxRSwyRUFBc0U7QUFFdEUsK0RBQTJEO0FBQzNELDZFQUkwQztBQUMxQyxpRkFBeUU7QUFDekUsNkRBQTBFO0FBbUgxRTs7R0FFRztBQUNILE1BQXNCLGlCQUFrQixTQUFRLHNCQUFROztJQU10RCxJQUFXLGdCQUFnQjtRQUN6QixPQUFPO1lBQ0wsZUFBZSxFQUFFLElBQUksQ0FBQyxlQUFlO1lBQ3JDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxnQkFBZ0I7U0FDeEMsQ0FBQztLQUNIO0lBRUQsSUFBVyxNQUFNO1FBQ2YsT0FBTyw4Q0FBbUIsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUNwRDtJQUVELElBQVcsV0FBVztRQUNwQixPQUFPLG1EQUF1QixDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUN6QztJQUVNLGVBQWUsQ0FBQyxTQUE4QjtRQUNuRCxJQUFJLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDLFNBQVMsQ0FBQyxDQUFDO0tBQ3JEOztBQXZCSCw4Q0F3QkM7QUFFRDs7Ozs7R0FLRztJQUVVLGFBQWE7NEJBRHpCLG9DQUFrQjs7OztzQkFDZ0IsaUJBQWlCOzs7OzZCQUF6QixTQUFRLFdBQWlCOzs7O2dEQXdFakQsaUNBQWM7K0NBS2QsaUNBQWM7WUFKZix1TUFBVyxnQkFBZ0IsNkRBRTFCO1lBR0Qsb01BQVcsZUFBZSw2REFFekI7WUFoRkgsNktBaUZDOzs7OztRQWhGQyxzQ0FBc0M7UUFDL0IsTUFBTSxDQUFVLHFCQUFxQixHQUFXLDBDQUEwQyxDQUFDO1FBRWxHOztXQUVHO1FBQ0ksTUFBTSxDQUFDLG9CQUFvQixDQUFDLEtBQWdCLEVBQUUsRUFBVSxFQUFFLGdCQUF3QjtZQUN2RixPQUFPLGFBQWEsQ0FBQywyQkFBMkIsQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFLEVBQUUsZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDO1NBQ25GO1FBRUQ7Ozs7V0FJRztRQUNJLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxLQUFnQixFQUFFLEVBQVUsRUFBRSxlQUF1QjtZQUNyRixPQUFPLGFBQWEsQ0FBQywyQkFBMkIsQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFO2dCQUMxRCxnQkFBZ0IsRUFBRSxJQUFBLCtDQUFzQixFQUFDLEtBQUssRUFBRSxlQUFlLENBQUM7YUFDakUsQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7V0FFRztRQUNJLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxLQUFnQixFQUFFLEVBQVUsRUFBRSxLQUE4Qjs7Ozs7Ozs7OztZQUNwRyxNQUFNLE1BQU8sU0FBUSxpQkFBaUI7Z0JBQ3BCLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDMUMsZUFBZSxHQUFHLG1CQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLEVBQUUsdUJBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLFlBQWEsQ0FBQztnQkFDaEgsSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7Z0JBQ2xCLGNBQWMsR0FBbUIsS0FBSyxDQUFDLElBQUksRUFBRSxjQUFjLElBQUksSUFBSSxHQUFHLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQzthQUM3SDtZQUVELE9BQU8sSUFBSSxNQUFNLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRSxFQUFFLGtCQUFrQixFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLENBQUM7U0FDOUU7UUFFZ0IsUUFBUSxHQXBDZCxtREFBYSxDQW9Db0I7UUFFNUM7Ozs7V0FJRztRQUNhLElBQUksQ0FBZ0I7UUFDcEIsY0FBYyxDQUFpQjtRQUUvQyxZQUFZLEtBQWdCLEVBQUUsRUFBVSxFQUFFLEtBQXlCO1lBQ2pFLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7Ozs7OzttREEvQ1IsYUFBYTs7OztZQWdEdEIsbUNBQW1DO1lBQ25DLElBQUEsd0NBQW9CLEVBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRWxDLElBQUEsbURBQTBCLEVBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRXhDLE1BQU0sSUFBSSxHQUFrQyxLQUFLLENBQUMsSUFBSSxJQUFJLElBQUEsdURBQThCLEVBQUMsSUFBSSxDQUFDLENBQUM7WUFDL0YsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDakIsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO1lBRTFDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSw4QkFBZ0IsQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFO2dCQUNyRCxJQUFJLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixJQUFJLG1CQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxFQUFFLEVBQUUsU0FBUyxFQUFFLEdBQUcsRUFBRSxDQUFDO2dCQUNuRixXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVc7Z0JBQzlCLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU87Z0JBQzdCLDBCQUEwQixFQUFFLEVBQUUsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUMxRCxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7YUFDakIsQ0FBQyxDQUFDO1lBRUgsa0dBQWtHO1lBQ2xHLGtHQUFrRztZQUNsRyxnQ0FBYyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztZQUV2RSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksK0NBQThCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7U0FDM0Q7UUFHRCxJQUFXLGdCQUFnQjtZQUN6QixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUM7U0FDeEQ7UUFHRCxJQUFXLGVBQWU7WUFDeEIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQztTQUN2RDs7WUFoRlUsdURBQWE7Ozs7O0FBQWIsc0NBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IElSZXNvdXJjZSB9IGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCB7IEFybkZvcm1hdCwgTmFtZXMsIFJlc291cmNlLCBTdGFjayB9IGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCB0eXBlIHsgSUtub3dsZWRnZUJhc2VSZWYsIEtub3dsZWRnZUJhc2VSZWZlcmVuY2UgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgeyBDZm5Lbm93bGVkZ2VCYXNlIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0ICogYXMgaWFtIGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0IHsgbWVtb2l6ZWRHZXR0ZXIgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9oZWxwZXJzLWludGVybmFsJztcbmltcG9ydCB7IGFkZENvbnN0cnVjdE1ldGFkYXRhIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvbWV0YWRhdGEtcmVzb3VyY2UnO1xuaW1wb3J0IHsgcHJvcGVydHlJbmplY3RhYmxlIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvcHJvcC1pbmplY3RhYmxlJztcbmltcG9ydCB0eXBlIHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5pbXBvcnQgeyBLbm93bGVkZ2VCYXNlUmVmbGVjdGlvbiB9IGZyb20gJy4va25vd2xlZGdlLWJhc2UtcmVmbGVjdGlvbic7XG5pbXBvcnQgdHlwZSB7IEtub3dsZWRnZUJhc2VUeXBlIH0gZnJvbSAnLi9rbm93bGVkZ2UtYmFzZS10eXBlJztcbmltcG9ydCB7IEdyYW50YWJsZVJvbGVzIH0gZnJvbSAnLi9wcml2YXRlL2dyYW50YWJsZS1yb2xlcyc7XG5pbXBvcnQge1xuICBjcmVhdGVLbm93bGVkZ2VCYXNlU2VydmljZVJvbGUsXG4gIGtub3dsZWRnZUJhc2VBcm5Gcm9tSWQsXG4gIHZhbGlkYXRlS25vd2xlZGdlQmFzZVByb3BzLFxufSBmcm9tICcuL3ByaXZhdGUva25vd2xlZGdlLWJhc2UtaGVscGVycyc7XG5pbXBvcnQgeyBLbm93bGVkZ2VCYXNlR3JhbnRzIH0gZnJvbSAnLi4vLi4vbGliL2JlZHJvY2stZ3JhbnRzLmdlbmVyYXRlZCc7XG5pbXBvcnQgeyBLbm93bGVkZ2VCYXNlVHlwZUNvbmZpZ3VyYXRpb24gfSBmcm9tICcuLi9taXhpbnMva25vd2xlZGdlLWJhc2UnO1xuXG4vKipcbiAqIFJlcHJlc2VudHMgYW4gQW1hem9uIEJlZHJvY2sga25vd2xlZGdlIGJhc2Ugb2YgYW55IHR5cGUsIGVpdGhlciBjcmVhdGVkXG4gKiB3aXRoIHRoZSBDREsgb3IgaW1wb3J0ZWRcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBJS25vd2xlZGdlQmFzZSBleHRlbmRzIElSZXNvdXJjZSwgSUtub3dsZWRnZUJhc2VSZWYsIGlhbS5JR3JhbnRhYmxlIHtcbiAgLyoqXG4gICAqIFRoZSBBUk4gb2YgdGhlIGtub3dsZWRnZSBiYXNlLlxuICAgKlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICByZWFkb25seSBrbm93bGVkZ2VCYXNlQXJuOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSB1bmlxdWUgaWRlbnRpZmllciBvZiB0aGUga25vd2xlZGdlIGJhc2UuXG4gICAqXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHJlYWRvbmx5IGtub3dsZWRnZUJhc2VJZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgc2VydmljZSByb2xlIHRoYXQgQW1hem9uIEJlZHJvY2sgYXNzdW1lcyB0byBvcGVyYXRlIHRoZSBrbm93bGVkZ2UgYmFzZS5cbiAgICpcbiAgICogVG8gYWRkIHBlcm1pc3Npb25zIHRvIHRoZSByb2xlLCB1c2UgYGFkZFRvUm9sZVBvbGljeSgpYCBvciBncmFudCB0byB0aGVcbiAgICoga25vd2xlZGdlIGJhc2UgaXRzZWxmLCB3aGljaCBpcyBhbiBgSUdyYW50YWJsZWAuXG4gICAqXG4gICAqIFVuZGVmaW5lZCBmb3IgaW1wb3J0ZWQga25vd2xlZGdlIGJhc2VzIHdob3NlIHJvbGUgd2FzIG5vdCBwcm92aWRlZC5cbiAgICovXG4gIHJlYWRvbmx5IHJvbGU/OiBpYW0uSVJvbGVSZWY7XG5cbiAgLyoqXG4gICAqIEdyYW50IHBlcm1pc3Npb25zIG9uIHRoaXMga25vd2xlZGdlIGJhc2UgdG8gSUFNIHByaW5jaXBhbHMuXG4gICAqL1xuICByZWFkb25seSBncmFudHM6IEtub3dsZWRnZUJhc2VHcmFudHM7XG5cbiAgLyoqXG4gICAqIFJlc29sdmVzIHRoZSB1bmRlcmx5aW5nIGBDZm5Lbm93bGVkZ2VCYXNlYCBmcm9tIHRoZSBjb25zdHJ1Y3QgdHJlZVxuICAgKi9cbiAgcmVhZG9ubHkgcmVmbGVjdGlvbnM6IEtub3dsZWRnZUJhc2VSZWZsZWN0aW9uO1xuXG4gIC8qKlxuICAgKiBBZGRzIGEgc3RhdGVtZW50IHRvIHRoZSBJQU0gcG9saWN5IG9mIHRoZSBrbm93bGVkZ2UgYmFzZSBzZXJ2aWNlIHJvbGUuXG4gICAqXG4gICAqIEZvciBhIHJlZmVyZW5jZWQga25vd2xlZGdlIGJhc2Ugd2hvc2Ugcm9sZSB3YXMgbm90IHByb3ZpZGVkLCB0aGUgc3RhdGVtZW50XG4gICAqIGNhbm5vdCBiZSBhcHBsaWVkOyBhIHdhcm5pbmcgaXMgZW1pdHRlZCB3aXRoIHRoZSBzdGF0ZW1lbnQgdG8gYWRkIHRvIHRoZVxuICAgKiByb2xlIG1hbnVhbGx5LlxuICAgKi9cbiAgYWRkVG9Sb2xlUG9saWN5KHN0YXRlbWVudDogaWFtLlBvbGljeVN0YXRlbWVudCk6IHZvaWQ7XG59XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgYSBrbm93bGVkZ2UgYmFzZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBLbm93bGVkZ2VCYXNlUHJvcHMge1xuICAvKipcbiAgICogVGhlIHR5cGUgb2YgdGhlIGtub3dsZWRnZSBiYXNlIGFuZCBpdHMgdHlwZS1zcGVjaWZpYyBjb25maWd1cmF0aW9uLlxuICAgKi9cbiAgcmVhZG9ubHkgdHlwZTogS25vd2xlZGdlQmFzZVR5cGU7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBrbm93bGVkZ2UgYmFzZS5cbiAgICpcbiAgICogTXVzdCBiZSAxLTEwMCBjaGFyYWN0ZXJzIG9mIGxldHRlcnMsIGRpZ2l0cywgaHlwaGVucyBhbmQgdW5kZXJzY29yZXMsIGFuZFxuICAgKiBtdXN0IG5vdCBjb250YWluIGNvbnNlY3V0aXZlIGh5cGhlbnMgb3IgdW5kZXJzY29yZXMuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gYSB1bmlxdWUgbmFtZSBpcyBnZW5lcmF0ZWRcbiAgICovXG4gIHJlYWRvbmx5IGtub3dsZWRnZUJhc2VOYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBBIGRlc2NyaXB0aW9uIG9mIHRoZSBrbm93bGVkZ2UgYmFzZS5cbiAgICpcbiAgICogTXVzdCBiZSAxLTIwMCBjaGFyYWN0ZXJzLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIG5vIGRlc2NyaXB0aW9uXG4gICAqL1xuICByZWFkb25seSBkZXNjcmlwdGlvbj86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHNlcnZpY2Ugcm9sZSB0aGF0IEFtYXpvbiBCZWRyb2NrIGFzc3VtZXMgdG8gb3BlcmF0ZSB0aGUga25vd2xlZGdlIGJhc2UuXG4gICAqXG4gICAqIFRoZSBwZXJtaXNzaW9ucyB0aGUga25vd2xlZGdlIGJhc2UgbmVlZHMgdG8gcmVhY2ggaXRzIGRhdGEgc3RvcmUgYW5kXG4gICAqIG1vZGVscyBhcmUgZ3JhbnRlZCB0byB0aGlzIHJvbGUuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gYSBuZXcgcm9sZSBpcyBjcmVhdGVkLCB0cnVzdGVkIGJ5IGBiZWRyb2NrLmFtYXpvbmF3cy5jb21gIGFuZFxuICAgKiBzY29wZWQgdG8ga25vd2xlZGdlIGJhc2VzIGluIHRoaXMgYWNjb3VudFxuICAgKi9cbiAgcmVhZG9ubHkgcm9sZT86IGlhbS5JUm9sZVJlZiAmIGlhbS5JR3JhbnRhYmxlO1xuXG4gIC8qKlxuICAgKiBUYWdzIHRvIGFwcGx5IHRvIHRoZSBrbm93bGVkZ2UgYmFzZS5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBubyB0YWdzXG4gICAqL1xuICByZWFkb25seSB0YWdzPzogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfTtcbn1cblxuLyoqXG4gKiBBdHRyaWJ1dGVzIGZvciByZWZlcmVuY2luZyBhbiBleGlzdGluZyBrbm93bGVkZ2UgYmFzZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBLbm93bGVkZ2VCYXNlQXR0cmlidXRlcyB7XG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBrbm93bGVkZ2UgYmFzZS5cbiAgICovXG4gIHJlYWRvbmx5IGtub3dsZWRnZUJhc2VBcm46IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHNlcnZpY2Ugcm9sZSBvZiB0aGUga25vd2xlZGdlIGJhc2UuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gdGhlIHJvbGUgaXMgdW5rbm93blxuICAgKi9cbiAgcmVhZG9ubHkgcm9sZT86IGlhbS5JUm9sZVJlZiAmIGlhbS5JR3JhbnRhYmxlO1xufVxuXG4vKipcbiAqIEJhc2UgY2xhc3MgZm9yIGtub3dsZWRnZSBiYXNlcyBvZiBhbnkgdHlwZSwgY3JlYXRlZCBvciByZWZlcmVuY2VkLlxuICovXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgS25vd2xlZGdlQmFzZUJhc2UgZXh0ZW5kcyBSZXNvdXJjZSBpbXBsZW1lbnRzIElLbm93bGVkZ2VCYXNlIHtcbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGtub3dsZWRnZUJhc2VBcm46IHN0cmluZztcbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGtub3dsZWRnZUJhc2VJZDogc3RyaW5nO1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkgcm9sZT86IGlhbS5JUm9sZVJlZjtcbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGdyYW50UHJpbmNpcGFsOiBpYW0uSVByaW5jaXBhbDtcblxuICBwdWJsaWMgZ2V0IGtub3dsZWRnZUJhc2VSZWYoKTogS25vd2xlZGdlQmFzZVJlZmVyZW5jZSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGtub3dsZWRnZUJhc2VJZDogdGhpcy5rbm93bGVkZ2VCYXNlSWQsXG4gICAgICBrbm93bGVkZ2VCYXNlQXJuOiB0aGlzLmtub3dsZWRnZUJhc2VBcm4sXG4gICAgfTtcbiAgfVxuXG4gIHB1YmxpYyBnZXQgZ3JhbnRzKCk6IEtub3dsZWRnZUJhc2VHcmFudHMge1xuICAgIHJldHVybiBLbm93bGVkZ2VCYXNlR3JhbnRzLmZyb21Lbm93bGVkZ2VCYXNlKHRoaXMpO1xuICB9XG5cbiAgcHVibGljIGdldCByZWZsZWN0aW9ucygpOiBLbm93bGVkZ2VCYXNlUmVmbGVjdGlvbiB7XG4gICAgcmV0dXJuIEtub3dsZWRnZUJhc2VSZWZsZWN0aW9uLm9mKHRoaXMpO1xuICB9XG5cbiAgcHVibGljIGFkZFRvUm9sZVBvbGljeShzdGF0ZW1lbnQ6IGlhbS5Qb2xpY3lTdGF0ZW1lbnQpOiB2b2lkIHtcbiAgICB0aGlzLmdyYW50UHJpbmNpcGFsLmFkZFRvUHJpbmNpcGFsUG9saWN5KHN0YXRlbWVudCk7XG4gIH1cbn1cblxuLyoqXG4gKiBBbiBBbWF6b24gQmVkcm9jayBrbm93bGVkZ2UgYmFzZS5cbiAqXG4gKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9iZWRyb2NrL2xhdGVzdC91c2VyZ3VpZGUva25vd2xlZGdlLWJhc2UuaHRtbFxuICogQHJlc291cmNlIEFXUzo6QmVkcm9jazo6S25vd2xlZGdlQmFzZVxuICovXG5AcHJvcGVydHlJbmplY3RhYmxlXG5leHBvcnQgY2xhc3MgS25vd2xlZGdlQmFzZSBleHRlbmRzIEtub3dsZWRnZUJhc2VCYXNlIHtcbiAgLyoqIFVuaXF1ZWx5IGlkZW50aWZpZXMgdGhpcyBjbGFzcy4gKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBQUk9QRVJUWV9JTkpFQ1RJT05fSUQ6IHN0cmluZyA9ICdAYXdzLWNkay5hd3MtYmVkcm9jay1hbHBoYS5Lbm93bGVkZ2VCYXNlJztcblxuICAvKipcbiAgICogUmVmZXJlbmNlIGFuIGV4aXN0aW5nIGtub3dsZWRnZSBiYXNlIGJ5IEFSTi5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUtub3dsZWRnZUJhc2VBcm4oc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywga25vd2xlZGdlQmFzZUFybjogc3RyaW5nKTogSUtub3dsZWRnZUJhc2Uge1xuICAgIHJldHVybiBLbm93bGVkZ2VCYXNlLmZyb21Lbm93bGVkZ2VCYXNlQXR0cmlidXRlcyhzY29wZSwgaWQsIHsga25vd2xlZGdlQmFzZUFybiB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWZlcmVuY2UgYW4gZXhpc3Rpbmcga25vd2xlZGdlIGJhc2UgYnkgSUQuXG4gICAqXG4gICAqIFRoZSBrbm93bGVkZ2UgYmFzZSBpcyBhc3N1bWVkIHRvIGJlIGluIHRoZSBzYW1lIGFjY291bnQgYW5kIHJlZ2lvbiBhcyB0aGUgc2NvcGUuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21Lbm93bGVkZ2VCYXNlSWQoc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywga25vd2xlZGdlQmFzZUlkOiBzdHJpbmcpOiBJS25vd2xlZGdlQmFzZSB7XG4gICAgcmV0dXJuIEtub3dsZWRnZUJhc2UuZnJvbUtub3dsZWRnZUJhc2VBdHRyaWJ1dGVzKHNjb3BlLCBpZCwge1xuICAgICAga25vd2xlZGdlQmFzZUFybjoga25vd2xlZGdlQmFzZUFybkZyb21JZChzY29wZSwga25vd2xlZGdlQmFzZUlkKSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWZlcmVuY2UgYW4gZXhpc3Rpbmcga25vd2xlZGdlIGJhc2UgYnkgaXRzIGF0dHJpYnV0ZXMuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21Lbm93bGVkZ2VCYXNlQXR0cmlidXRlcyhzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBhdHRyczogS25vd2xlZGdlQmFzZUF0dHJpYnV0ZXMpOiBJS25vd2xlZGdlQmFzZSB7XG4gICAgY2xhc3MgSW1wb3J0IGV4dGVuZHMgS25vd2xlZGdlQmFzZUJhc2Uge1xuICAgICAgcHVibGljIHJlYWRvbmx5IGtub3dsZWRnZUJhc2VBcm4gPSBhdHRycy5rbm93bGVkZ2VCYXNlQXJuO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGtub3dsZWRnZUJhc2VJZCA9IFN0YWNrLm9mKHNjb3BlKS5zcGxpdEFybihhdHRycy5rbm93bGVkZ2VCYXNlQXJuLCBBcm5Gb3JtYXQuU0xBU0hfUkVTT1VSQ0VfTkFNRSkucmVzb3VyY2VOYW1lITtcbiAgICAgIHB1YmxpYyByZWFkb25seSByb2xlID0gYXR0cnMucm9sZTtcbiAgICAgIHB1YmxpYyByZWFkb25seSBncmFudFByaW5jaXBhbDogaWFtLklQcmluY2lwYWwgPSBhdHRycy5yb2xlPy5ncmFudFByaW5jaXBhbCA/PyBuZXcgaWFtLlVua25vd25QcmluY2lwYWwoeyByZXNvdXJjZTogdGhpcyB9KTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IEltcG9ydChzY29wZSwgaWQsIHsgZW52aXJvbm1lbnRGcm9tQXJuOiBhdHRycy5rbm93bGVkZ2VCYXNlQXJuIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSByZWFkb25seSByZXNvdXJjZTogQ2ZuS25vd2xlZGdlQmFzZTtcblxuICAvKipcbiAgICogVGhlIHNlcnZpY2Ugcm9sZSB0aGF0IEFtYXpvbiBCZWRyb2NrIGFzc3VtZXMgdG8gb3BlcmF0ZSB0aGUga25vd2xlZGdlIGJhc2UuXG4gICAqXG4gICAqIEFsd2F5cyBkZWZpbmVkIGZvciBrbm93bGVkZ2UgYmFzZXMgY3JlYXRlZCB3aXRoIHRoaXMgY29uc3RydWN0LlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHJvbGU/OiBpYW0uSVJvbGVSZWY7XG4gIHB1YmxpYyByZWFkb25seSBncmFudFByaW5jaXBhbDogaWFtLklQcmluY2lwYWw7XG5cbiAgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM6IEtub3dsZWRnZUJhc2VQcm9wcykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCk7XG4gICAgLy8gRW5oYW5jZWQgQ0RLIEFuYWx5dGljcyBUZWxlbWV0cnlcbiAgICBhZGRDb25zdHJ1Y3RNZXRhZGF0YSh0aGlzLCBwcm9wcyk7XG5cbiAgICB2YWxpZGF0ZUtub3dsZWRnZUJhc2VQcm9wcyh0aGlzLCBwcm9wcyk7XG5cbiAgICBjb25zdCByb2xlOiBpYW0uSVJvbGVSZWYgJiBpYW0uSUdyYW50YWJsZSA9IHByb3BzLnJvbGUgPz8gY3JlYXRlS25vd2xlZGdlQmFzZVNlcnZpY2VSb2xlKHRoaXMpO1xuICAgIHRoaXMucm9sZSA9IHJvbGU7XG4gICAgdGhpcy5ncmFudFByaW5jaXBhbCA9IHJvbGUuZ3JhbnRQcmluY2lwYWw7XG5cbiAgICB0aGlzLnJlc291cmNlID0gbmV3IENmbktub3dsZWRnZUJhc2UodGhpcywgJ1Jlc291cmNlJywge1xuICAgICAgbmFtZTogcHJvcHMua25vd2xlZGdlQmFzZU5hbWUgPz8gTmFtZXMudW5pcXVlUmVzb3VyY2VOYW1lKHRoaXMsIHsgbWF4TGVuZ3RoOiAxMDAgfSksXG4gICAgICBkZXNjcmlwdGlvbjogcHJvcHMuZGVzY3JpcHRpb24sXG4gICAgICByb2xlQXJuOiByb2xlLnJvbGVSZWYucm9sZUFybixcbiAgICAgIGtub3dsZWRnZUJhc2VDb25maWd1cmF0aW9uOiB7IHR5cGU6IHByb3BzLnR5cGUuX3R5cGVOYW1lIH0sXG4gICAgICB0YWdzOiBwcm9wcy50YWdzLFxuICAgIH0pO1xuXG4gICAgLy8gVE9ETzogVGVtcG9yYXJpbHkgaGVyZSBPTkxZIHRvIGRlYWwgd2l0aCBSb2xlLmZyb21Sb2xlQXJuKCkgb2JqZWN0czsgdGhpcyBzaG91bGQgYmUgZ2VuZXJhbGl6ZWRcbiAgICAvLyBUaGUgdHlwZSdzIG1peGlucyByZXNvbHZlIHRoZSByb2xlIGZyb20gYHJvbGVBcm5gIHdoZW4gYXBwbGllZCwgc28gaXQgbXVzdCBiZSByZWdpc3RlcmVkIGZpcnN0LlxuICAgIEdyYW50YWJsZVJvbGVzLm9mKHRoaXMpLnJlZ2lzdGVyUm9sZU9iamVjdChyb2xlLnJvbGVSZWYucm9sZUFybiwgcm9sZSk7XG5cbiAgICB0aGlzLndpdGgobmV3IEtub3dsZWRnZUJhc2VUeXBlQ29uZmlndXJhdGlvbihwcm9wcy50eXBlKSk7XG4gIH1cblxuICBAbWVtb2l6ZWRHZXR0ZXJcbiAgcHVibGljIGdldCBrbm93bGVkZ2VCYXNlQXJuKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMucmVzb3VyY2Uua25vd2xlZGdlQmFzZVJlZi5rbm93bGVkZ2VCYXNlQXJuO1xuICB9XG5cbiAgQG1lbW9pemVkR2V0dGVyXG4gIHB1YmxpYyBnZXQga25vd2xlZGdlQmFzZUlkKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMucmVzb3VyY2Uua25vd2xlZGdlQmFzZVJlZi5rbm93bGVkZ2VCYXNlSWQ7XG4gIH1cbn1cbiJdfQ==