"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KnowledgeBaseReflection = void 0;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
/**
 * Provides read-only reflection on the configuration of a Bedrock knowledge base
 * underlying `CfnKnowledgeBase` resource
 *
 * Use `KnowledgeBaseReflection.of()` to obtain an instance from any KnowledgeBase reference.
 * All getters read directly from the L1 resource, providing a single source of
 * truth regardless of whether the knowledge base was created as an L2, imported, or
 * constructed directly as a CfnKnowledgeBase.
 */
class KnowledgeBaseReflection {
    ref;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.KnowledgeBaseReflection", version: "2.274.0-alpha.0" };
    /**
     * Creates a reflection facade for a knowledge base reference.
     */
    static of(knowledgeBaseRef) {
        return new KnowledgeBaseReflection(knowledgeBaseRef);
    }
    _knowledgeBase;
    constructor(ref) {
        this.ref = ref;
        this._knowledgeBase = helpers_internal_1.ConstructReflection.of(ref).findCfnResource({
            cfnResourceType: 'AWS::Bedrock::KnowledgeBase',
            matches: (cfn) => cfn.knowledgeBaseRef.knowledgeBaseId === ref.knowledgeBaseRef.knowledgeBaseId,
        });
    }
    /**
     * The underlying L1 knowledge base resource.
     *
     * @throws If the underlying CfnKnowledgeBase resource cannot be found.
     */
    get knowledgeBase() {
        if (this._knowledgeBase === undefined) {
            throw new aws_cdk_lib_1.UnscopedValidationError((0, helpers_internal_1.lit) `CannotFindUnderlyingResource`, `Unable to find underlying resource for ${this.ref.node.path}. Please pass the resource construct directly.`);
        }
        return this._knowledgeBase;
    }
}
exports.KnowledgeBaseReflection = KnowledgeBaseReflection;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia25vd2xlZGdlLWJhc2UtcmVmbGVjdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImtub3dsZWRnZS1iYXNlLXJlZmxlY3Rpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLDZDQUFzRDtBQUV0RCw0RUFBaUY7QUFFakY7Ozs7Ozs7O0dBUUc7QUFDSCxNQUFhLHVCQUF1QjtJQVVHOztJQVRyQzs7T0FFRztJQUNJLE1BQU0sQ0FBQyxFQUFFLENBQUMsZ0JBQW1DO1FBQ2xELE9BQU8sSUFBSSx1QkFBdUIsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0tBQ3REO0lBRWdCLGNBQWMsQ0FBb0I7SUFFbkQsWUFBcUMsR0FBc0I7UUFBdEIsUUFBRyxHQUFILEdBQUcsQ0FBbUI7UUFDekQsSUFBSSxDQUFDLGNBQWMsR0FBRyxzQ0FBbUIsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsZUFBZSxDQUFDO1lBQ2hFLGVBQWUsRUFBRSw2QkFBNkI7WUFDOUMsT0FBTyxFQUFFLENBQUMsR0FBcUIsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLGVBQWUsS0FBSyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsZUFBZTtTQUNsSCxDQUFpQyxDQUFDO0tBQ3BDO0lBRUQ7Ozs7T0FJRztJQUNILElBQVcsYUFBYTtRQUN0QixJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDdEMsTUFBTSxJQUFJLHFDQUF1QixDQUFDLElBQUEsc0JBQUcsRUFBQSw4QkFBOEIsRUFBRSwwQ0FBMEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxnREFBZ0QsQ0FBQyxDQUFDO1FBQ3JMLENBQUM7UUFDRCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7S0FDNUI7O0FBM0JILDBEQTRCQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnYXdzLWNkay1saWInO1xuaW1wb3J0IHR5cGUgeyBDZm5Lbm93bGVkZ2VCYXNlLCBJS25vd2xlZGdlQmFzZVJlZiB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1iZWRyb2NrJztcbmltcG9ydCB7IENvbnN0cnVjdFJlZmxlY3Rpb24sIGxpdCB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2hlbHBlcnMtaW50ZXJuYWwnO1xuXG4vKipcbiAqIFByb3ZpZGVzIHJlYWQtb25seSByZWZsZWN0aW9uIG9uIHRoZSBjb25maWd1cmF0aW9uIG9mIGEgQmVkcm9jayBrbm93bGVkZ2UgYmFzZVxuICogdW5kZXJseWluZyBgQ2ZuS25vd2xlZGdlQmFzZWAgcmVzb3VyY2VcbiAqXG4gKiBVc2UgYEtub3dsZWRnZUJhc2VSZWZsZWN0aW9uLm9mKClgIHRvIG9idGFpbiBhbiBpbnN0YW5jZSBmcm9tIGFueSBLbm93bGVkZ2VCYXNlIHJlZmVyZW5jZS5cbiAqIEFsbCBnZXR0ZXJzIHJlYWQgZGlyZWN0bHkgZnJvbSB0aGUgTDEgcmVzb3VyY2UsIHByb3ZpZGluZyBhIHNpbmdsZSBzb3VyY2Ugb2ZcbiAqIHRydXRoIHJlZ2FyZGxlc3Mgb2Ygd2hldGhlciB0aGUga25vd2xlZGdlIGJhc2Ugd2FzIGNyZWF0ZWQgYXMgYW4gTDIsIGltcG9ydGVkLCBvclxuICogY29uc3RydWN0ZWQgZGlyZWN0bHkgYXMgYSBDZm5Lbm93bGVkZ2VCYXNlLlxuICovXG5leHBvcnQgY2xhc3MgS25vd2xlZGdlQmFzZVJlZmxlY3Rpb24ge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIHJlZmxlY3Rpb24gZmFjYWRlIGZvciBhIGtub3dsZWRnZSBiYXNlIHJlZmVyZW5jZS5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgb2Yoa25vd2xlZGdlQmFzZVJlZjogSUtub3dsZWRnZUJhc2VSZWYpOiBLbm93bGVkZ2VCYXNlUmVmbGVjdGlvbiB7XG4gICAgcmV0dXJuIG5ldyBLbm93bGVkZ2VCYXNlUmVmbGVjdGlvbihrbm93bGVkZ2VCYXNlUmVmKTtcbiAgfVxuXG4gIHByaXZhdGUgcmVhZG9ubHkgX2tub3dsZWRnZUJhc2U/OiBDZm5Lbm93bGVkZ2VCYXNlO1xuXG4gIHByaXZhdGUgY29uc3RydWN0b3IocHJpdmF0ZSByZWFkb25seSByZWY6IElLbm93bGVkZ2VCYXNlUmVmKSB7XG4gICAgdGhpcy5fa25vd2xlZGdlQmFzZSA9IENvbnN0cnVjdFJlZmxlY3Rpb24ub2YocmVmKS5maW5kQ2ZuUmVzb3VyY2Uoe1xuICAgICAgY2ZuUmVzb3VyY2VUeXBlOiAnQVdTOjpCZWRyb2NrOjpLbm93bGVkZ2VCYXNlJyxcbiAgICAgIG1hdGNoZXM6IChjZm46IENmbktub3dsZWRnZUJhc2UpID0+IGNmbi5rbm93bGVkZ2VCYXNlUmVmLmtub3dsZWRnZUJhc2VJZCA9PT0gcmVmLmtub3dsZWRnZUJhc2VSZWYua25vd2xlZGdlQmFzZUlkLFxuICAgIH0pIGFzIENmbktub3dsZWRnZUJhc2UgfCB1bmRlZmluZWQ7XG4gIH1cblxuICAvKipcbiAgICogVGhlIHVuZGVybHlpbmcgTDEga25vd2xlZGdlIGJhc2UgcmVzb3VyY2UuXG4gICAqXG4gICAqIEB0aHJvd3MgSWYgdGhlIHVuZGVybHlpbmcgQ2ZuS25vd2xlZGdlQmFzZSByZXNvdXJjZSBjYW5ub3QgYmUgZm91bmQuXG4gICAqL1xuICBwdWJsaWMgZ2V0IGtub3dsZWRnZUJhc2UoKTogQ2ZuS25vd2xlZGdlQmFzZSB7XG4gICAgaWYgKHRoaXMuX2tub3dsZWRnZUJhc2UgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKGxpdGBDYW5ub3RGaW5kVW5kZXJseWluZ1Jlc291cmNlYCwgYFVuYWJsZSB0byBmaW5kIHVuZGVybHlpbmcgcmVzb3VyY2UgZm9yICR7dGhpcy5yZWYubm9kZS5wYXRofS4gUGxlYXNlIHBhc3MgdGhlIHJlc291cmNlIGNvbnN0cnVjdCBkaXJlY3RseS5gKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2tub3dsZWRnZUJhc2U7XG4gIH1cbn1cbiJdfQ==