import { Mixin } from 'aws-cdk-lib';
import { CfnKnowledgeBase } from 'aws-cdk-lib/aws-bedrock';
import * as s3 from 'aws-cdk-lib/aws-s3';
import type { IConstruct } from 'constructs';
import type { KnowledgeBaseType } from '../knowledge-bases/knowledge-base-type';
import type { OpenSearchServerlessVectorStoreProps } from '../knowledge-bases/vector-store';
import type { BedrockFoundationModel } from '../models';
import { VectorType } from '../models';
/**
 * Properties for `KnowledgeBaseOpenSearchServerlessStorage`.
 */
export interface KnowledgeBaseOpenSearchServerlessStorageProps extends OpenSearchServerlessVectorStoreProps {
}
/**
 * Stores a knowledge base's vectors in an existing Amazon OpenSearch Serverless
 * vector index.
 *
 * Sets `StorageConfiguration` to `OPENSEARCH_SERVERLESS` with the given
 * collection, index and field mapping. Grants the role referenced by the knowledge
 * base's `roleArn` `aoss:APIAccessAll` on the collection and makes the knowledge
 * base depend on that policy.
 *
 * The index must already exist and the collection's data access policy must
 * allow the service role to describe, read and write it; neither is created here.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/knowledge-base-setup-oss.html
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/kb-permissions.html#kb-permissions-oss
 */
export declare class KnowledgeBaseOpenSearchServerlessStorage extends Mixin {
    private readonly props;
    constructor(props: KnowledgeBaseOpenSearchServerlessStorageProps);
    supports(construct: IConstruct): construct is CfnKnowledgeBase;
    applyTo(construct: IConstruct): void;
}
/**
 * Properties for `KnowledgeBaseEmbeddingsModel`.
 */
export interface KnowledgeBaseEmbeddingsModelProps {
    /**
     * The model used to create vector embeddings for the knowledge base.
     */
    readonly embeddingsModel: BedrockFoundationModel;
    /**
     * The data type of the vector embeddings.
     *
     * @default VectorType.FLOATING_POINT
     */
    readonly vectorType?: VectorType;
}
/**
 * Configures the embeddings model of a vector knowledge base.
 *
 * Sets `EmbeddingModelArn`, `Dimensions` (only for models with a configurable
 * dimension; CloudFormation rejects it otherwise) and `EmbeddingDataType`.
 * Grants the role referenced by the knowledge base's `roleArn` `bedrock:InvokeModel*`
 * and `bedrock:GetFoundationModel` on the model and makes the knowledge base depend
 * on that policy.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/kb-permissions.html#kb-permissions-fm
 */
export declare class KnowledgeBaseEmbeddingsModel extends Mixin {
    private readonly props;
    constructor(props: KnowledgeBaseEmbeddingsModelProps);
    supports(construct: IConstruct): construct is CfnKnowledgeBase;
    applyTo(construct: IConstruct): void;
}
/**
 * Properties for `KnowledgeBaseSupplementalDataStorage`.
 */
export interface KnowledgeBaseSupplementalDataStorageProps {
    /**
     * The S3 bucket in which multimedia content extracted from multimodal
     * documents is stored.
     *
     * Amazon Bedrock manages the layout of the extracted content within the
     * bucket; a key prefix cannot be specified.
     */
    readonly bucket: s3.IBucketRef;
}
/**
 * Stores the images, audio and video a vector knowledge base extracts from
 * multimodal documents in an Amazon S3 bucket.
 *
 * Merges `SupplementalDataStorageConfiguration` into the existing vector
 * configuration, replacing any location already set. Grants the role referenced
 * by the knowledge base's `roleArn` `s3:ListBucket` on the bucket and
 * `s3:GetObject`, `s3:PutObject` and `s3:DeleteObject` on its objects, and makes
 * the knowledge base depend on that policy.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/kb-permissions.html#kb-permissions-multimodal
 */
export declare class KnowledgeBaseSupplementalDataStorage extends Mixin {
    private readonly props;
    constructor(props: KnowledgeBaseSupplementalDataStorageProps);
    supports(construct: IConstruct): construct is CfnKnowledgeBase;
    applyTo(construct: IConstruct): void;
}
/**
 * Configures a knowledge base as the given type.
 *
 * Applies the type-specific configuration, permissions and dependencies that the
 * `type` property of `KnowledgeBase` applies, so a `CfnKnowledgeBase` can be
 * configured from a `KnowledgeBaseType` without applying its individual mixins.
 */
export declare class KnowledgeBaseTypeConfiguration extends Mixin {
    private readonly knowledgeBaseType;
    constructor(knowledgeBaseType: KnowledgeBaseType);
    supports(construct: IConstruct): construct is CfnKnowledgeBase;
    applyTo(construct: IConstruct): void;
}
