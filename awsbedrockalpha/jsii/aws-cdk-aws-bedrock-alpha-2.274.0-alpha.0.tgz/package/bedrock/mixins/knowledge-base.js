"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.KnowledgeBaseTypeConfiguration = exports.KnowledgeBaseSupplementalDataStorage = exports.KnowledgeBaseEmbeddingsModel = exports.KnowledgeBaseOpenSearchServerlessStorage = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const aws_bedrock_1 = require("aws-cdk-lib/aws-bedrock");
const iam = __importStar(require("aws-cdk-lib/aws-iam"));
const s3 = __importStar(require("aws-cdk-lib/aws-s3"));
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const grantable_roles_1 = require("../knowledge-bases/private/grantable-roles");
const knowledge_base_helpers_1 = require("../knowledge-bases/private/knowledge-base-helpers");
const models_1 = require("../models");
const OPENSEARCH_SERVERLESS_STORAGE_TYPE = 'OPENSEARCH_SERVERLESS';
function addVectorTypeValidation(construct, feature) {
    construct.node.addValidation({
        validate: () => {
            const configuration = construct.knowledgeBaseConfiguration;
            if ((0, aws_cdk_lib_1.isResolvableObject)(configuration) || aws_cdk_lib_1.Token.isUnresolved(configuration.type)) {
                return [];
            }
            return configuration.type === knowledge_base_helpers_1.VECTOR_KNOWLEDGE_BASE_TYPE
                ? []
                : [`${feature} can only be configured on a knowledge base of type ${knowledge_base_helpers_1.VECTOR_KNOWLEDGE_BASE_TYPE}, got ${JSON.stringify(configuration.type)}`];
        },
    });
}
function assertVectorConfigurationResolved(construct, feature) {
    const configuration = construct.knowledgeBaseConfiguration;
    if ((0, aws_cdk_lib_1.isResolvableObject)(configuration)
        || (0, aws_cdk_lib_1.isResolvableObject)(configuration.vectorKnowledgeBaseConfiguration)
        || (0, aws_cdk_lib_1.isResolvableObject)(configuration.vectorKnowledgeBaseConfiguration?.embeddingModelConfiguration)) {
        throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `KnowledgeBaseConfigurationUnresolved`, `${feature} cannot be configured on a knowledge base whose configuration contains deploy-time object values`, construct);
    }
}
/**
 * Stores a knowledge base's vectors in an existing Amazon OpenSearch Serverless
 * vector index.
 *
 * Sets `StorageConfiguration` to `OPENSEARCH_SERVERLESS` with the given
 * collection, index and field mapping. Grants the role referenced by the knowledge
 * base's `roleArn` `aoss:APIAccessAll` on the collection and makes the knowledge
 * base depend on that policy.
 *
 * The index must already exist and the collection's data access policy must
 * allow the service role to describe, read and write it; neither is created here.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/knowledge-base-setup-oss.html
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/kb-permissions.html#kb-permissions-oss
 */
class KnowledgeBaseOpenSearchServerlessStorage extends aws_cdk_lib_1.Mixin {
    props;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.mixins.KnowledgeBaseOpenSearchServerlessStorage", version: "2.274.0-alpha.0" };
    constructor(props) {
        super();
        this.props = props;
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_mixins_KnowledgeBaseOpenSearchServerlessStorageProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, KnowledgeBaseOpenSearchServerlessStorage);
            }
            throw error;
        }
    }
    supports(construct) {
        return aws_bedrock_1.CfnKnowledgeBase.isCfnKnowledgeBase(construct);
    }
    applyTo(construct) {
        if (!this.supports(construct)) {
            return;
        }
        if (construct.storageConfiguration !== undefined) {
            throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `KnowledgeBaseStorageAlreadyConfigured`, 'the knowledge base already has a storage configuration; only one vector store can be configured', construct);
        }
        const role = grantable_roles_1.GrantableRoles.of(construct).forRoleArn(construct.roleArn);
        addVectorTypeValidation(construct, 'VectorStore');
        const collectionArn = this.props.collection.collectionRef.collectionArn;
        construct.storageConfiguration = {
            type: OPENSEARCH_SERVERLESS_STORAGE_TYPE,
            opensearchServerlessConfiguration: {
                collectionArn,
                vectorIndexName: this.props.vectorIndexName,
                fieldMapping: {
                    vectorField: this.props.vectorField,
                    textField: this.props.textField,
                    metadataField: this.props.metadataField,
                },
            },
        };
        // Bedrock validates access to the collection when the knowledge base is
        // created, so the policy must exist before the knowledge base does.
        iam.Grant.addToPrincipal({
            grantee: role,
            actions: ['aoss:APIAccessAll'],
            resourceArns: [collectionArn],
        }).applyBefore(construct);
    }
}
exports.KnowledgeBaseOpenSearchServerlessStorage = KnowledgeBaseOpenSearchServerlessStorage;
/**
 * Configures the embeddings model of a vector knowledge base.
 *
 * Sets `EmbeddingModelArn`, `Dimensions` (only for models with a configurable
 * dimension; CloudFormation rejects it otherwise) and `EmbeddingDataType`.
 * Grants the role referenced by the knowledge base's `roleArn` `bedrock:InvokeModel*`
 * and `bedrock:GetFoundationModel` on the model and makes the knowledge base depend
 * on that policy.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/kb-permissions.html#kb-permissions-fm
 */
class KnowledgeBaseEmbeddingsModel extends aws_cdk_lib_1.Mixin {
    props;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.mixins.KnowledgeBaseEmbeddingsModel", version: "2.274.0-alpha.0" };
    constructor(props) {
        super();
        this.props = props;
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_mixins_KnowledgeBaseEmbeddingsModelProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, KnowledgeBaseEmbeddingsModel);
            }
            throw error;
        }
    }
    supports(construct) {
        return aws_bedrock_1.CfnKnowledgeBase.isCfnKnowledgeBase(construct);
    }
    applyTo(construct) {
        if (!this.supports(construct)) {
            return;
        }
        const { embeddingsModel } = this.props;
        if (!embeddingsModel.supportsKnowledgeBase) {
            throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `EmbeddingsModelNotSupported`, `embeddingsModel ${JSON.stringify(embeddingsModel.modelId)} cannot be used with knowledge bases; choose a vector embeddings model supported by Amazon Bedrock Knowledge Bases`, construct);
        }
        const vectorType = this.props.vectorType ?? models_1.VectorType.FLOATING_POINT;
        const supported = embeddingsModel.supportedVectorType;
        if (supported !== undefined && !supported.includes(vectorType)) {
            throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `UnsupportedVectorType`, `vectorType ${JSON.stringify(vectorType)} is not supported by embeddingsModel ${JSON.stringify(embeddingsModel.modelId)}; supported vector types are ${supported.map(type => JSON.stringify(type)).join(', ')}`, construct);
        }
        assertVectorConfigurationResolved(construct, 'EmbeddingsModel');
        const role = grantable_roles_1.GrantableRoles.of(construct).forRoleArn(construct.roleArn);
        addVectorTypeValidation(construct, 'EmbeddingsModel');
        const dimensions = embeddingsModel.supportsConfigurableDimensions ? embeddingsModel.vectorDimensions : undefined;
        aws_cdk_lib_1.Mixins.of(construct, aws_cdk_lib_1.ConstructSelector.onlyItself()).apply(new helpers_internal_1.CfnPropsMixin(aws_bedrock_1.CfnKnowledgeBase, {
            knowledgeBaseConfiguration: {
                vectorKnowledgeBaseConfiguration: {
                    embeddingModelArn: embeddingsModel.modelArn,
                    embeddingModelConfiguration: { bedrockEmbeddingModelConfiguration: { dimensions, embeddingDataType: vectorType } },
                },
            },
        }));
        // Bedrock validates access to the model when the knowledge base is created,
        // so the policy must exist before the knowledge base does.
        embeddingsModel.grantInvoke(role).applyBefore(construct);
    }
}
exports.KnowledgeBaseEmbeddingsModel = KnowledgeBaseEmbeddingsModel;
/**
 * Stores the images, audio and video a vector knowledge base extracts from
 * multimodal documents in an Amazon S3 bucket.
 *
 * Merges `SupplementalDataStorageConfiguration` into the existing vector
 * configuration, replacing any location already set. Grants the role referenced
 * by the knowledge base's `roleArn` `s3:ListBucket` on the bucket and
 * `s3:GetObject`, `s3:PutObject` and `s3:DeleteObject` on its objects, and makes
 * the knowledge base depend on that policy.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/kb-permissions.html#kb-permissions-multimodal
 */
class KnowledgeBaseSupplementalDataStorage extends aws_cdk_lib_1.Mixin {
    props;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.mixins.KnowledgeBaseSupplementalDataStorage", version: "2.274.0-alpha.0" };
    constructor(props) {
        super();
        this.props = props;
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_mixins_KnowledgeBaseSupplementalDataStorageProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, KnowledgeBaseSupplementalDataStorage);
            }
            throw error;
        }
    }
    supports(construct) {
        return aws_bedrock_1.CfnKnowledgeBase.isCfnKnowledgeBase(construct);
    }
    applyTo(construct) {
        if (!this.supports(construct)) {
            return;
        }
        assertVectorConfigurationResolved(construct, 'SupplementalDataStorage');
        const role = grantable_roles_1.GrantableRoles.of(construct).forRoleArn(construct.roleArn);
        addVectorTypeValidation(construct, 'SupplementalDataStorage');
        // `CfnPropsMixin` deep-merges into the existing configuration
        aws_cdk_lib_1.Mixins.of(construct, aws_cdk_lib_1.ConstructSelector.onlyItself()).apply(new helpers_internal_1.CfnPropsMixin(aws_bedrock_1.CfnKnowledgeBase, {
            knowledgeBaseConfiguration: {
                vectorKnowledgeBaseConfiguration: {
                    supplementalDataStorageConfiguration: {
                        supplementalDataStorageLocations: [{
                                supplementalDataStorageLocationType: 'S3',
                                s3Location: { uri: `s3://${this.props.bucket.bucketRef.bucketName}/` },
                            }],
                    },
                },
            },
        }));
        // Bedrock validates access to the bucket when the knowledge base is
        // created, so the policy must exist before the knowledge base does.
        s3.BucketGrants.fromBucket(this.props.bucket)
            .actionsOnBucketAndObjectKeys(role, '*', 's3:ListBucket', 's3:GetObject', 's3:PutObject', 's3:DeleteObject')
            .applyBefore(construct);
        construct.node.addDependency(role);
    }
}
exports.KnowledgeBaseSupplementalDataStorage = KnowledgeBaseSupplementalDataStorage;
/**
 * Configures a knowledge base as the given type.
 *
 * Applies the type-specific configuration, permissions and dependencies that the
 * `type` property of `KnowledgeBase` applies, so a `CfnKnowledgeBase` can be
 * configured from a `KnowledgeBaseType` without applying its individual mixins.
 */
class KnowledgeBaseTypeConfiguration extends aws_cdk_lib_1.Mixin {
    knowledgeBaseType;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.mixins.KnowledgeBaseTypeConfiguration", version: "2.274.0-alpha.0" };
    constructor(knowledgeBaseType) {
        super();
        this.knowledgeBaseType = knowledgeBaseType;
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_KnowledgeBaseType(knowledgeBaseType);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, KnowledgeBaseTypeConfiguration);
            }
            throw error;
        }
    }
    supports(construct) {
        return aws_bedrock_1.CfnKnowledgeBase.isCfnKnowledgeBase(construct);
    }
    applyTo(construct) {
        if (!this.supports(construct)) {
            return;
        }
        aws_cdk_lib_1.Mixins.of(construct, aws_cdk_lib_1.ConstructSelector.onlyItself()).apply(...this.knowledgeBaseType._mixins);
    }
}
exports.KnowledgeBaseTypeConfiguration = KnowledgeBaseTypeConfiguration;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia25vd2xlZGdlLWJhc2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJrbm93bGVkZ2UtYmFzZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDZDQUEyRztBQUMzRyx5REFBMkQ7QUFDM0QseURBQTJDO0FBQzNDLHVEQUF5QztBQUN6Qyw0RUFBMkU7QUFHM0UsZ0ZBQTRFO0FBQzVFLDhGQUErRjtBQUcvRixzQ0FBdUM7QUFFdkMsTUFBTSxrQ0FBa0MsR0FBRyx1QkFBdUIsQ0FBQztBQUVuRSxTQUFTLHVCQUF1QixDQUFDLFNBQTJCLEVBQUUsT0FBZTtJQUMzRSxTQUFTLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUMzQixRQUFRLEVBQUUsR0FBRyxFQUFFO1lBQ2IsTUFBTSxhQUFhLEdBQUcsU0FBUyxDQUFDLDBCQUEwQixDQUFDO1lBQzNELElBQUksSUFBQSxnQ0FBa0IsRUFBQyxhQUFhLENBQUMsSUFBSSxtQkFBSyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztnQkFDaEYsT0FBTyxFQUFFLENBQUM7WUFDWixDQUFDO1lBQ0QsT0FBTyxhQUFhLENBQUMsSUFBSSxLQUFLLG1EQUEwQjtnQkFDdEQsQ0FBQyxDQUFDLEVBQUU7Z0JBQ0osQ0FBQyxDQUFDLENBQUMsR0FBRyxPQUFPLHVEQUF1RCxtREFBMEIsU0FBUyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDakosQ0FBQztLQUNGLENBQUMsQ0FBQztBQUNMLENBQUM7QUFFRCxTQUFTLGlDQUFpQyxDQUFDLFNBQTJCLEVBQUUsT0FBZTtJQUNyRixNQUFNLGFBQWEsR0FBRyxTQUFTLENBQUMsMEJBQTBCLENBQUM7SUFDM0QsSUFBSSxJQUFBLGdDQUFrQixFQUFDLGFBQWEsQ0FBQztXQUM5QixJQUFBLGdDQUFrQixFQUFDLGFBQWEsQ0FBQyxnQ0FBZ0MsQ0FBQztXQUNsRSxJQUFBLGdDQUFrQixFQUFDLGFBQWEsQ0FBQyxnQ0FBZ0MsRUFBRSwyQkFBMkIsQ0FBQyxFQUFFLENBQUM7UUFDdkcsTUFBTSxJQUFJLDZCQUFlLENBQ3ZCLElBQUEsc0JBQUcsRUFBQSxzQ0FBc0MsRUFDekMsR0FBRyxPQUFPLGtHQUFrRyxFQUM1RyxTQUFTLENBQ1YsQ0FBQztJQUNKLENBQUM7QUFDSCxDQUFDO0FBUUQ7Ozs7Ozs7Ozs7Ozs7O0dBY0c7QUFDSCxNQUFhLHdDQUF5QyxTQUFRLG1CQUFLO0lBQ3BDOztJQUE3QixZQUE2QixLQUFvRDtRQUMvRSxLQUFLLEVBQUUsQ0FBQztRQURtQixVQUFLLEdBQUwsS0FBSyxDQUErQzs7Ozs7OytDQUR0RSx3Q0FBd0M7Ozs7S0FHbEQ7SUFFTSxRQUFRLENBQUMsU0FBcUI7UUFDbkMsT0FBTyw4QkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztLQUN2RDtJQUVNLE9BQU8sQ0FBQyxTQUFxQjtRQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO1lBQzlCLE9BQU87UUFDVCxDQUFDO1FBRUQsSUFBSSxTQUFTLENBQUMsb0JBQW9CLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDakQsTUFBTSxJQUFJLDZCQUFlLENBQ3ZCLElBQUEsc0JBQUcsRUFBQSx1Q0FBdUMsRUFDMUMsaUdBQWlHLEVBQ2pHLFNBQVMsQ0FDVixDQUFDO1FBQ0osQ0FBQztRQUVELE1BQU0sSUFBSSxHQUFHLGdDQUFjLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDeEUsdUJBQXVCLENBQUMsU0FBUyxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRWxELE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUM7UUFFeEUsU0FBUyxDQUFDLG9CQUFvQixHQUFHO1lBQy9CLElBQUksRUFBRSxrQ0FBa0M7WUFDeEMsaUNBQWlDLEVBQUU7Z0JBQ2pDLGFBQWE7Z0JBQ2IsZUFBZSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsZUFBZTtnQkFDM0MsWUFBWSxFQUFFO29CQUNaLFdBQVcsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVc7b0JBQ25DLFNBQVMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVM7b0JBQy9CLGFBQWEsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLGFBQWE7aUJBQ3hDO2FBQ0Y7U0FDRixDQUFDO1FBRUYsd0VBQXdFO1FBQ3hFLG9FQUFvRTtRQUNwRSxHQUFHLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQztZQUN2QixPQUFPLEVBQUUsSUFBSTtZQUNiLE9BQU8sRUFBRSxDQUFDLG1CQUFtQixDQUFDO1lBQzlCLFlBQVksRUFBRSxDQUFDLGFBQWEsQ0FBQztTQUM5QixDQUFDLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0tBQzNCOztBQS9DSCw0RkFnREM7QUFtQkQ7Ozs7Ozs7Ozs7R0FVRztBQUNILE1BQWEsNEJBQTZCLFNBQVEsbUJBQUs7SUFDeEI7O0lBQTdCLFlBQTZCLEtBQXdDO1FBQ25FLEtBQUssRUFBRSxDQUFDO1FBRG1CLFVBQUssR0FBTCxLQUFLLENBQW1DOzs7Ozs7K0NBRDFELDRCQUE0Qjs7OztLQUd0QztJQUVNLFFBQVEsQ0FBQyxTQUFxQjtRQUNuQyxPQUFPLDhCQUFnQixDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxDQUFDO0tBQ3ZEO0lBRU0sT0FBTyxDQUFDLFNBQXFCO1FBQ2xDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7WUFDOUIsT0FBTztRQUNULENBQUM7UUFFRCxNQUFNLEVBQUUsZUFBZSxFQUFFLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUN2QyxJQUFJLENBQUMsZUFBZSxDQUFDLHFCQUFxQixFQUFFLENBQUM7WUFDM0MsTUFBTSxJQUFJLDZCQUFlLENBQ3ZCLElBQUEsc0JBQUcsRUFBQSw2QkFBNkIsRUFDaEMsbUJBQW1CLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxvSEFBb0gsRUFDOUssU0FBUyxDQUNWLENBQUM7UUFDSixDQUFDO1FBQ0QsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLElBQUksbUJBQVUsQ0FBQyxjQUFjLENBQUM7UUFDdEUsTUFBTSxTQUFTLEdBQUcsZUFBZSxDQUFDLG1CQUFtQixDQUFDO1FBQ3RELElBQUksU0FBUyxLQUFLLFNBQVMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQztZQUMvRCxNQUFNLElBQUksNkJBQWUsQ0FDdkIsSUFBQSxzQkFBRyxFQUFBLHVCQUF1QixFQUMxQixjQUFjLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLHdDQUF3QyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsZ0NBQWdDLFNBQVMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQy9NLFNBQVMsQ0FDVixDQUFDO1FBQ0osQ0FBQztRQUVELGlDQUFpQyxDQUFDLFNBQVMsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO1FBQ2hFLE1BQU0sSUFBSSxHQUFHLGdDQUFjLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDeEUsdUJBQXVCLENBQUMsU0FBUyxFQUFFLGlCQUFpQixDQUFDLENBQUM7UUFFdEQsTUFBTSxVQUFVLEdBQUcsZUFBZSxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUNqSCxvQkFBTSxDQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUUsK0JBQWlCLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxnQ0FBYSxDQUFDLDhCQUFnQixFQUFFO1lBQzdGLDBCQUEwQixFQUFFO2dCQUMxQixnQ0FBZ0MsRUFBRTtvQkFDaEMsaUJBQWlCLEVBQUUsZUFBZSxDQUFDLFFBQVE7b0JBQzNDLDJCQUEyQixFQUFFLEVBQUUsa0NBQWtDLEVBQUUsRUFBRSxVQUFVLEVBQUUsaUJBQWlCLEVBQUUsVUFBVSxFQUFFLEVBQUU7aUJBQ25IO2FBQ0Y7U0FDRixDQUFDLENBQUMsQ0FBQztRQUVKLDRFQUE0RTtRQUM1RSwyREFBMkQ7UUFDM0QsZUFBZSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUM7S0FDMUQ7O0FBakRILG9FQWtEQztBQWdCRDs7Ozs7Ozs7Ozs7R0FXRztBQUNILE1BQWEsb0NBQXFDLFNBQVEsbUJBQUs7SUFDaEM7O0lBQTdCLFlBQTZCLEtBQWdEO1FBQzNFLEtBQUssRUFBRSxDQUFDO1FBRG1CLFVBQUssR0FBTCxLQUFLLENBQTJDOzs7Ozs7K0NBRGxFLG9DQUFvQzs7OztLQUc5QztJQUVNLFFBQVEsQ0FBQyxTQUFxQjtRQUNuQyxPQUFPLDhCQUFnQixDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxDQUFDO0tBQ3ZEO0lBRU0sT0FBTyxDQUFDLFNBQXFCO1FBQ2xDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7WUFDOUIsT0FBTztRQUNULENBQUM7UUFFRCxpQ0FBaUMsQ0FBQyxTQUFTLEVBQUUseUJBQXlCLENBQUMsQ0FBQztRQUN4RSxNQUFNLElBQUksR0FBRyxnQ0FBYyxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3hFLHVCQUF1QixDQUFDLFNBQVMsRUFBRSx5QkFBeUIsQ0FBQyxDQUFDO1FBRTlELDhEQUE4RDtRQUM5RCxvQkFBTSxDQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUUsK0JBQWlCLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxnQ0FBYSxDQUFDLDhCQUFnQixFQUFFO1lBQzdGLDBCQUEwQixFQUFFO2dCQUMxQixnQ0FBZ0MsRUFBRTtvQkFDaEMsb0NBQW9DLEVBQUU7d0JBQ3BDLGdDQUFnQyxFQUFFLENBQUM7Z0NBQ2pDLG1DQUFtQyxFQUFFLElBQUk7Z0NBQ3pDLFVBQVUsRUFBRSxFQUFFLEdBQUcsRUFBRSxRQUFRLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEdBQUcsRUFBRTs2QkFDdkUsQ0FBQztxQkFDSDtpQkFDRjthQUNGO1NBQ0YsQ0FBQyxDQUFDLENBQUM7UUFFSixvRUFBb0U7UUFDcEUsb0VBQW9FO1FBQ3BFLEVBQUUsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO2FBQzFDLDRCQUE0QixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsZUFBZSxFQUFFLGNBQWMsRUFBRSxjQUFjLEVBQUUsaUJBQWlCLENBQUM7YUFDM0csV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTFCLFNBQVMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ3BDOztBQXZDSCxvRkF3Q0M7QUFFRDs7Ozs7O0dBTUc7QUFDSCxNQUFhLDhCQUErQixTQUFRLG1CQUFLO0lBQzFCOztJQUE3QixZQUE2QixpQkFBb0M7UUFDL0QsS0FBSyxFQUFFLENBQUM7UUFEbUIsc0JBQWlCLEdBQWpCLGlCQUFpQixDQUFtQjs7Ozs7OytDQUR0RCw4QkFBOEI7Ozs7S0FHeEM7SUFFTSxRQUFRLENBQUMsU0FBcUI7UUFDbkMsT0FBTyw4QkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztLQUN2RDtJQUVNLE9BQU8sQ0FBQyxTQUFxQjtRQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO1lBQzlCLE9BQU87UUFDVCxDQUFDO1FBRUQsb0JBQU0sQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFLCtCQUFpQixDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0tBQy9GOztBQWZILHdFQWdCQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbnN0cnVjdFNlbGVjdG9yLCBpc1Jlc29sdmFibGVPYmplY3QsIE1peGluLCBNaXhpbnMsIFRva2VuLCBWYWxpZGF0aW9uRXJyb3IgfSBmcm9tICdhd3MtY2RrLWxpYic7XG5pbXBvcnQgeyBDZm5Lbm93bGVkZ2VCYXNlIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0ICogYXMgaWFtIGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0ICogYXMgczMgZnJvbSAnYXdzLWNkay1saWIvYXdzLXMzJztcbmltcG9ydCB7IENmblByb3BzTWl4aW4sIGxpdCB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2hlbHBlcnMtaW50ZXJuYWwnO1xuaW1wb3J0IHR5cGUgeyBJQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5pbXBvcnQgdHlwZSB7IEtub3dsZWRnZUJhc2VUeXBlIH0gZnJvbSAnLi4va25vd2xlZGdlLWJhc2VzL2tub3dsZWRnZS1iYXNlLXR5cGUnO1xuaW1wb3J0IHsgR3JhbnRhYmxlUm9sZXMgfSBmcm9tICcuLi9rbm93bGVkZ2UtYmFzZXMvcHJpdmF0ZS9ncmFudGFibGUtcm9sZXMnO1xuaW1wb3J0IHsgVkVDVE9SX0tOT1dMRURHRV9CQVNFX1RZUEUgfSBmcm9tICcuLi9rbm93bGVkZ2UtYmFzZXMvcHJpdmF0ZS9rbm93bGVkZ2UtYmFzZS1oZWxwZXJzJztcbmltcG9ydCB0eXBlIHsgT3BlblNlYXJjaFNlcnZlcmxlc3NWZWN0b3JTdG9yZVByb3BzIH0gZnJvbSAnLi4va25vd2xlZGdlLWJhc2VzL3ZlY3Rvci1zdG9yZSc7XG5pbXBvcnQgdHlwZSB7IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwgfSBmcm9tICcuLi9tb2RlbHMnO1xuaW1wb3J0IHsgVmVjdG9yVHlwZSB9IGZyb20gJy4uL21vZGVscyc7XG5cbmNvbnN0IE9QRU5TRUFSQ0hfU0VSVkVSTEVTU19TVE9SQUdFX1RZUEUgPSAnT1BFTlNFQVJDSF9TRVJWRVJMRVNTJztcblxuZnVuY3Rpb24gYWRkVmVjdG9yVHlwZVZhbGlkYXRpb24oY29uc3RydWN0OiBDZm5Lbm93bGVkZ2VCYXNlLCBmZWF0dXJlOiBzdHJpbmcpOiB2b2lkIHtcbiAgY29uc3RydWN0Lm5vZGUuYWRkVmFsaWRhdGlvbih7XG4gICAgdmFsaWRhdGU6ICgpID0+IHtcbiAgICAgIGNvbnN0IGNvbmZpZ3VyYXRpb24gPSBjb25zdHJ1Y3Qua25vd2xlZGdlQmFzZUNvbmZpZ3VyYXRpb247XG4gICAgICBpZiAoaXNSZXNvbHZhYmxlT2JqZWN0KGNvbmZpZ3VyYXRpb24pIHx8IFRva2VuLmlzVW5yZXNvbHZlZChjb25maWd1cmF0aW9uLnR5cGUpKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjb25maWd1cmF0aW9uLnR5cGUgPT09IFZFQ1RPUl9LTk9XTEVER0VfQkFTRV9UWVBFXG4gICAgICAgID8gW11cbiAgICAgICAgOiBbYCR7ZmVhdHVyZX0gY2FuIG9ubHkgYmUgY29uZmlndXJlZCBvbiBhIGtub3dsZWRnZSBiYXNlIG9mIHR5cGUgJHtWRUNUT1JfS05PV0xFREdFX0JBU0VfVFlQRX0sIGdvdCAke0pTT04uc3RyaW5naWZ5KGNvbmZpZ3VyYXRpb24udHlwZSl9YF07XG4gICAgfSxcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIGFzc2VydFZlY3RvckNvbmZpZ3VyYXRpb25SZXNvbHZlZChjb25zdHJ1Y3Q6IENmbktub3dsZWRnZUJhc2UsIGZlYXR1cmU6IHN0cmluZyk6IHZvaWQge1xuICBjb25zdCBjb25maWd1cmF0aW9uID0gY29uc3RydWN0Lmtub3dsZWRnZUJhc2VDb25maWd1cmF0aW9uO1xuICBpZiAoaXNSZXNvbHZhYmxlT2JqZWN0KGNvbmZpZ3VyYXRpb24pXG4gICAgICB8fCBpc1Jlc29sdmFibGVPYmplY3QoY29uZmlndXJhdGlvbi52ZWN0b3JLbm93bGVkZ2VCYXNlQ29uZmlndXJhdGlvbilcbiAgICAgIHx8IGlzUmVzb2x2YWJsZU9iamVjdChjb25maWd1cmF0aW9uLnZlY3Rvcktub3dsZWRnZUJhc2VDb25maWd1cmF0aW9uPy5lbWJlZGRpbmdNb2RlbENvbmZpZ3VyYXRpb24pKSB7XG4gICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihcbiAgICAgIGxpdGBLbm93bGVkZ2VCYXNlQ29uZmlndXJhdGlvblVucmVzb2x2ZWRgLFxuICAgICAgYCR7ZmVhdHVyZX0gY2Fubm90IGJlIGNvbmZpZ3VyZWQgb24gYSBrbm93bGVkZ2UgYmFzZSB3aG9zZSBjb25maWd1cmF0aW9uIGNvbnRhaW5zIGRlcGxveS10aW1lIG9iamVjdCB2YWx1ZXNgLFxuICAgICAgY29uc3RydWN0LFxuICAgICk7XG4gIH1cbn1cblxuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBgS25vd2xlZGdlQmFzZU9wZW5TZWFyY2hTZXJ2ZXJsZXNzU3RvcmFnZWAuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgS25vd2xlZGdlQmFzZU9wZW5TZWFyY2hTZXJ2ZXJsZXNzU3RvcmFnZVByb3BzIGV4dGVuZHMgT3BlblNlYXJjaFNlcnZlcmxlc3NWZWN0b3JTdG9yZVByb3BzIHtcbn1cblxuLyoqXG4gKiBTdG9yZXMgYSBrbm93bGVkZ2UgYmFzZSdzIHZlY3RvcnMgaW4gYW4gZXhpc3RpbmcgQW1hem9uIE9wZW5TZWFyY2ggU2VydmVybGVzc1xuICogdmVjdG9yIGluZGV4LlxuICpcbiAqIFNldHMgYFN0b3JhZ2VDb25maWd1cmF0aW9uYCB0byBgT1BFTlNFQVJDSF9TRVJWRVJMRVNTYCB3aXRoIHRoZSBnaXZlblxuICogY29sbGVjdGlvbiwgaW5kZXggYW5kIGZpZWxkIG1hcHBpbmcuIEdyYW50cyB0aGUgcm9sZSByZWZlcmVuY2VkIGJ5IHRoZSBrbm93bGVkZ2VcbiAqIGJhc2UncyBgcm9sZUFybmAgYGFvc3M6QVBJQWNjZXNzQWxsYCBvbiB0aGUgY29sbGVjdGlvbiBhbmQgbWFrZXMgdGhlIGtub3dsZWRnZVxuICogYmFzZSBkZXBlbmQgb24gdGhhdCBwb2xpY3kuXG4gKlxuICogVGhlIGluZGV4IG11c3QgYWxyZWFkeSBleGlzdCBhbmQgdGhlIGNvbGxlY3Rpb24ncyBkYXRhIGFjY2VzcyBwb2xpY3kgbXVzdFxuICogYWxsb3cgdGhlIHNlcnZpY2Ugcm9sZSB0byBkZXNjcmliZSwgcmVhZCBhbmQgd3JpdGUgaXQ7IG5laXRoZXIgaXMgY3JlYXRlZCBoZXJlLlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9rbm93bGVkZ2UtYmFzZS1zZXR1cC1vc3MuaHRtbFxuICogQHNlZSBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vYmVkcm9jay9sYXRlc3QvdXNlcmd1aWRlL2tiLXBlcm1pc3Npb25zLmh0bWwja2ItcGVybWlzc2lvbnMtb3NzXG4gKi9cbmV4cG9ydCBjbGFzcyBLbm93bGVkZ2VCYXNlT3BlblNlYXJjaFNlcnZlcmxlc3NTdG9yYWdlIGV4dGVuZHMgTWl4aW4ge1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJlYWRvbmx5IHByb3BzOiBLbm93bGVkZ2VCYXNlT3BlblNlYXJjaFNlcnZlcmxlc3NTdG9yYWdlUHJvcHMpIHtcbiAgICBzdXBlcigpO1xuICB9XG5cbiAgcHVibGljIHN1cHBvcnRzKGNvbnN0cnVjdDogSUNvbnN0cnVjdCk6IGNvbnN0cnVjdCBpcyBDZm5Lbm93bGVkZ2VCYXNlIHtcbiAgICByZXR1cm4gQ2ZuS25vd2xlZGdlQmFzZS5pc0Nmbktub3dsZWRnZUJhc2UoY29uc3RydWN0KTtcbiAgfVxuXG4gIHB1YmxpYyBhcHBseVRvKGNvbnN0cnVjdDogSUNvbnN0cnVjdCk6IHZvaWQge1xuICAgIGlmICghdGhpcy5zdXBwb3J0cyhjb25zdHJ1Y3QpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKGNvbnN0cnVjdC5zdG9yYWdlQ29uZmlndXJhdGlvbiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKFxuICAgICAgICBsaXRgS25vd2xlZGdlQmFzZVN0b3JhZ2VBbHJlYWR5Q29uZmlndXJlZGAsXG4gICAgICAgICd0aGUga25vd2xlZGdlIGJhc2UgYWxyZWFkeSBoYXMgYSBzdG9yYWdlIGNvbmZpZ3VyYXRpb247IG9ubHkgb25lIHZlY3RvciBzdG9yZSBjYW4gYmUgY29uZmlndXJlZCcsXG4gICAgICAgIGNvbnN0cnVjdCxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgY29uc3Qgcm9sZSA9IEdyYW50YWJsZVJvbGVzLm9mKGNvbnN0cnVjdCkuZm9yUm9sZUFybihjb25zdHJ1Y3Qucm9sZUFybik7XG4gICAgYWRkVmVjdG9yVHlwZVZhbGlkYXRpb24oY29uc3RydWN0LCAnVmVjdG9yU3RvcmUnKTtcblxuICAgIGNvbnN0IGNvbGxlY3Rpb25Bcm4gPSB0aGlzLnByb3BzLmNvbGxlY3Rpb24uY29sbGVjdGlvblJlZi5jb2xsZWN0aW9uQXJuO1xuXG4gICAgY29uc3RydWN0LnN0b3JhZ2VDb25maWd1cmF0aW9uID0ge1xuICAgICAgdHlwZTogT1BFTlNFQVJDSF9TRVJWRVJMRVNTX1NUT1JBR0VfVFlQRSxcbiAgICAgIG9wZW5zZWFyY2hTZXJ2ZXJsZXNzQ29uZmlndXJhdGlvbjoge1xuICAgICAgICBjb2xsZWN0aW9uQXJuLFxuICAgICAgICB2ZWN0b3JJbmRleE5hbWU6IHRoaXMucHJvcHMudmVjdG9ySW5kZXhOYW1lLFxuICAgICAgICBmaWVsZE1hcHBpbmc6IHtcbiAgICAgICAgICB2ZWN0b3JGaWVsZDogdGhpcy5wcm9wcy52ZWN0b3JGaWVsZCxcbiAgICAgICAgICB0ZXh0RmllbGQ6IHRoaXMucHJvcHMudGV4dEZpZWxkLFxuICAgICAgICAgIG1ldGFkYXRhRmllbGQ6IHRoaXMucHJvcHMubWV0YWRhdGFGaWVsZCxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfTtcblxuICAgIC8vIEJlZHJvY2sgdmFsaWRhdGVzIGFjY2VzcyB0byB0aGUgY29sbGVjdGlvbiB3aGVuIHRoZSBrbm93bGVkZ2UgYmFzZSBpc1xuICAgIC8vIGNyZWF0ZWQsIHNvIHRoZSBwb2xpY3kgbXVzdCBleGlzdCBiZWZvcmUgdGhlIGtub3dsZWRnZSBiYXNlIGRvZXMuXG4gICAgaWFtLkdyYW50LmFkZFRvUHJpbmNpcGFsKHtcbiAgICAgIGdyYW50ZWU6IHJvbGUsXG4gICAgICBhY3Rpb25zOiBbJ2Fvc3M6QVBJQWNjZXNzQWxsJ10sXG4gICAgICByZXNvdXJjZUFybnM6IFtjb2xsZWN0aW9uQXJuXSxcbiAgICB9KS5hcHBseUJlZm9yZShjb25zdHJ1Y3QpO1xuICB9XG59XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgYEtub3dsZWRnZUJhc2VFbWJlZGRpbmdzTW9kZWxgLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEtub3dsZWRnZUJhc2VFbWJlZGRpbmdzTW9kZWxQcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgbW9kZWwgdXNlZCB0byBjcmVhdGUgdmVjdG9yIGVtYmVkZGluZ3MgZm9yIHRoZSBrbm93bGVkZ2UgYmFzZS5cbiAgICovXG4gIHJlYWRvbmx5IGVtYmVkZGluZ3NNb2RlbDogQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbDtcblxuICAvKipcbiAgICogVGhlIGRhdGEgdHlwZSBvZiB0aGUgdmVjdG9yIGVtYmVkZGluZ3MuXG4gICAqXG4gICAqIEBkZWZhdWx0IFZlY3RvclR5cGUuRkxPQVRJTkdfUE9JTlRcbiAgICovXG4gIHJlYWRvbmx5IHZlY3RvclR5cGU/OiBWZWN0b3JUeXBlO1xufVxuXG4vKipcbiAqIENvbmZpZ3VyZXMgdGhlIGVtYmVkZGluZ3MgbW9kZWwgb2YgYSB2ZWN0b3Iga25vd2xlZGdlIGJhc2UuXG4gKlxuICogU2V0cyBgRW1iZWRkaW5nTW9kZWxBcm5gLCBgRGltZW5zaW9uc2AgKG9ubHkgZm9yIG1vZGVscyB3aXRoIGEgY29uZmlndXJhYmxlXG4gKiBkaW1lbnNpb247IENsb3VkRm9ybWF0aW9uIHJlamVjdHMgaXQgb3RoZXJ3aXNlKSBhbmQgYEVtYmVkZGluZ0RhdGFUeXBlYC5cbiAqIEdyYW50cyB0aGUgcm9sZSByZWZlcmVuY2VkIGJ5IHRoZSBrbm93bGVkZ2UgYmFzZSdzIGByb2xlQXJuYCBgYmVkcm9jazpJbnZva2VNb2RlbCpgXG4gKiBhbmQgYGJlZHJvY2s6R2V0Rm91bmRhdGlvbk1vZGVsYCBvbiB0aGUgbW9kZWwgYW5kIG1ha2VzIHRoZSBrbm93bGVkZ2UgYmFzZSBkZXBlbmRcbiAqIG9uIHRoYXQgcG9saWN5LlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9rYi1wZXJtaXNzaW9ucy5odG1sI2tiLXBlcm1pc3Npb25zLWZtXG4gKi9cbmV4cG9ydCBjbGFzcyBLbm93bGVkZ2VCYXNlRW1iZWRkaW5nc01vZGVsIGV4dGVuZHMgTWl4aW4ge1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJlYWRvbmx5IHByb3BzOiBLbm93bGVkZ2VCYXNlRW1iZWRkaW5nc01vZGVsUHJvcHMpIHtcbiAgICBzdXBlcigpO1xuICB9XG5cbiAgcHVibGljIHN1cHBvcnRzKGNvbnN0cnVjdDogSUNvbnN0cnVjdCk6IGNvbnN0cnVjdCBpcyBDZm5Lbm93bGVkZ2VCYXNlIHtcbiAgICByZXR1cm4gQ2ZuS25vd2xlZGdlQmFzZS5pc0Nmbktub3dsZWRnZUJhc2UoY29uc3RydWN0KTtcbiAgfVxuXG4gIHB1YmxpYyBhcHBseVRvKGNvbnN0cnVjdDogSUNvbnN0cnVjdCk6IHZvaWQge1xuICAgIGlmICghdGhpcy5zdXBwb3J0cyhjb25zdHJ1Y3QpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgeyBlbWJlZGRpbmdzTW9kZWwgfSA9IHRoaXMucHJvcHM7XG4gICAgaWYgKCFlbWJlZGRpbmdzTW9kZWwuc3VwcG9ydHNLbm93bGVkZ2VCYXNlKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKFxuICAgICAgICBsaXRgRW1iZWRkaW5nc01vZGVsTm90U3VwcG9ydGVkYCxcbiAgICAgICAgYGVtYmVkZGluZ3NNb2RlbCAke0pTT04uc3RyaW5naWZ5KGVtYmVkZGluZ3NNb2RlbC5tb2RlbElkKX0gY2Fubm90IGJlIHVzZWQgd2l0aCBrbm93bGVkZ2UgYmFzZXM7IGNob29zZSBhIHZlY3RvciBlbWJlZGRpbmdzIG1vZGVsIHN1cHBvcnRlZCBieSBBbWF6b24gQmVkcm9jayBLbm93bGVkZ2UgQmFzZXNgLFxuICAgICAgICBjb25zdHJ1Y3QsXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCB2ZWN0b3JUeXBlID0gdGhpcy5wcm9wcy52ZWN0b3JUeXBlID8/IFZlY3RvclR5cGUuRkxPQVRJTkdfUE9JTlQ7XG4gICAgY29uc3Qgc3VwcG9ydGVkID0gZW1iZWRkaW5nc01vZGVsLnN1cHBvcnRlZFZlY3RvclR5cGU7XG4gICAgaWYgKHN1cHBvcnRlZCAhPT0gdW5kZWZpbmVkICYmICFzdXBwb3J0ZWQuaW5jbHVkZXModmVjdG9yVHlwZSkpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoXG4gICAgICAgIGxpdGBVbnN1cHBvcnRlZFZlY3RvclR5cGVgLFxuICAgICAgICBgdmVjdG9yVHlwZSAke0pTT04uc3RyaW5naWZ5KHZlY3RvclR5cGUpfSBpcyBub3Qgc3VwcG9ydGVkIGJ5IGVtYmVkZGluZ3NNb2RlbCAke0pTT04uc3RyaW5naWZ5KGVtYmVkZGluZ3NNb2RlbC5tb2RlbElkKX07IHN1cHBvcnRlZCB2ZWN0b3IgdHlwZXMgYXJlICR7c3VwcG9ydGVkLm1hcCh0eXBlID0+IEpTT04uc3RyaW5naWZ5KHR5cGUpKS5qb2luKCcsICcpfWAsXG4gICAgICAgIGNvbnN0cnVjdCxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgYXNzZXJ0VmVjdG9yQ29uZmlndXJhdGlvblJlc29sdmVkKGNvbnN0cnVjdCwgJ0VtYmVkZGluZ3NNb2RlbCcpO1xuICAgIGNvbnN0IHJvbGUgPSBHcmFudGFibGVSb2xlcy5vZihjb25zdHJ1Y3QpLmZvclJvbGVBcm4oY29uc3RydWN0LnJvbGVBcm4pO1xuICAgIGFkZFZlY3RvclR5cGVWYWxpZGF0aW9uKGNvbnN0cnVjdCwgJ0VtYmVkZGluZ3NNb2RlbCcpO1xuXG4gICAgY29uc3QgZGltZW5zaW9ucyA9IGVtYmVkZGluZ3NNb2RlbC5zdXBwb3J0c0NvbmZpZ3VyYWJsZURpbWVuc2lvbnMgPyBlbWJlZGRpbmdzTW9kZWwudmVjdG9yRGltZW5zaW9ucyA6IHVuZGVmaW5lZDtcbiAgICBNaXhpbnMub2YoY29uc3RydWN0LCBDb25zdHJ1Y3RTZWxlY3Rvci5vbmx5SXRzZWxmKCkpLmFwcGx5KG5ldyBDZm5Qcm9wc01peGluKENmbktub3dsZWRnZUJhc2UsIHtcbiAgICAgIGtub3dsZWRnZUJhc2VDb25maWd1cmF0aW9uOiB7XG4gICAgICAgIHZlY3Rvcktub3dsZWRnZUJhc2VDb25maWd1cmF0aW9uOiB7XG4gICAgICAgICAgZW1iZWRkaW5nTW9kZWxBcm46IGVtYmVkZGluZ3NNb2RlbC5tb2RlbEFybixcbiAgICAgICAgICBlbWJlZGRpbmdNb2RlbENvbmZpZ3VyYXRpb246IHsgYmVkcm9ja0VtYmVkZGluZ01vZGVsQ29uZmlndXJhdGlvbjogeyBkaW1lbnNpb25zLCBlbWJlZGRpbmdEYXRhVHlwZTogdmVjdG9yVHlwZSB9IH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0pKTtcblxuICAgIC8vIEJlZHJvY2sgdmFsaWRhdGVzIGFjY2VzcyB0byB0aGUgbW9kZWwgd2hlbiB0aGUga25vd2xlZGdlIGJhc2UgaXMgY3JlYXRlZCxcbiAgICAvLyBzbyB0aGUgcG9saWN5IG11c3QgZXhpc3QgYmVmb3JlIHRoZSBrbm93bGVkZ2UgYmFzZSBkb2VzLlxuICAgIGVtYmVkZGluZ3NNb2RlbC5ncmFudEludm9rZShyb2xlKS5hcHBseUJlZm9yZShjb25zdHJ1Y3QpO1xuICB9XG59XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgYEtub3dsZWRnZUJhc2VTdXBwbGVtZW50YWxEYXRhU3RvcmFnZWAuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgS25vd2xlZGdlQmFzZVN1cHBsZW1lbnRhbERhdGFTdG9yYWdlUHJvcHMge1xuICAvKipcbiAgICogVGhlIFMzIGJ1Y2tldCBpbiB3aGljaCBtdWx0aW1lZGlhIGNvbnRlbnQgZXh0cmFjdGVkIGZyb20gbXVsdGltb2RhbFxuICAgKiBkb2N1bWVudHMgaXMgc3RvcmVkLlxuICAgKlxuICAgKiBBbWF6b24gQmVkcm9jayBtYW5hZ2VzIHRoZSBsYXlvdXQgb2YgdGhlIGV4dHJhY3RlZCBjb250ZW50IHdpdGhpbiB0aGVcbiAgICogYnVja2V0OyBhIGtleSBwcmVmaXggY2Fubm90IGJlIHNwZWNpZmllZC5cbiAgICovXG4gIHJlYWRvbmx5IGJ1Y2tldDogczMuSUJ1Y2tldFJlZjtcbn1cblxuLyoqXG4gKiBTdG9yZXMgdGhlIGltYWdlcywgYXVkaW8gYW5kIHZpZGVvIGEgdmVjdG9yIGtub3dsZWRnZSBiYXNlIGV4dHJhY3RzIGZyb21cbiAqIG11bHRpbW9kYWwgZG9jdW1lbnRzIGluIGFuIEFtYXpvbiBTMyBidWNrZXQuXG4gKlxuICogTWVyZ2VzIGBTdXBwbGVtZW50YWxEYXRhU3RvcmFnZUNvbmZpZ3VyYXRpb25gIGludG8gdGhlIGV4aXN0aW5nIHZlY3RvclxuICogY29uZmlndXJhdGlvbiwgcmVwbGFjaW5nIGFueSBsb2NhdGlvbiBhbHJlYWR5IHNldC4gR3JhbnRzIHRoZSByb2xlIHJlZmVyZW5jZWRcbiAqIGJ5IHRoZSBrbm93bGVkZ2UgYmFzZSdzIGByb2xlQXJuYCBgczM6TGlzdEJ1Y2tldGAgb24gdGhlIGJ1Y2tldCBhbmRcbiAqIGBzMzpHZXRPYmplY3RgLCBgczM6UHV0T2JqZWN0YCBhbmQgYHMzOkRlbGV0ZU9iamVjdGAgb24gaXRzIG9iamVjdHMsIGFuZCBtYWtlc1xuICogdGhlIGtub3dsZWRnZSBiYXNlIGRlcGVuZCBvbiB0aGF0IHBvbGljeS5cbiAqXG4gKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9iZWRyb2NrL2xhdGVzdC91c2VyZ3VpZGUva2ItcGVybWlzc2lvbnMuaHRtbCNrYi1wZXJtaXNzaW9ucy1tdWx0aW1vZGFsXG4gKi9cbmV4cG9ydCBjbGFzcyBLbm93bGVkZ2VCYXNlU3VwcGxlbWVudGFsRGF0YVN0b3JhZ2UgZXh0ZW5kcyBNaXhpbiB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgcHJvcHM6IEtub3dsZWRnZUJhc2VTdXBwbGVtZW50YWxEYXRhU3RvcmFnZVByb3BzKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHB1YmxpYyBzdXBwb3J0cyhjb25zdHJ1Y3Q6IElDb25zdHJ1Y3QpOiBjb25zdHJ1Y3QgaXMgQ2ZuS25vd2xlZGdlQmFzZSB7XG4gICAgcmV0dXJuIENmbktub3dsZWRnZUJhc2UuaXNDZm5Lbm93bGVkZ2VCYXNlKGNvbnN0cnVjdCk7XG4gIH1cblxuICBwdWJsaWMgYXBwbHlUbyhjb25zdHJ1Y3Q6IElDb25zdHJ1Y3QpOiB2b2lkIHtcbiAgICBpZiAoIXRoaXMuc3VwcG9ydHMoY29uc3RydWN0KSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGFzc2VydFZlY3RvckNvbmZpZ3VyYXRpb25SZXNvbHZlZChjb25zdHJ1Y3QsICdTdXBwbGVtZW50YWxEYXRhU3RvcmFnZScpO1xuICAgIGNvbnN0IHJvbGUgPSBHcmFudGFibGVSb2xlcy5vZihjb25zdHJ1Y3QpLmZvclJvbGVBcm4oY29uc3RydWN0LnJvbGVBcm4pO1xuICAgIGFkZFZlY3RvclR5cGVWYWxpZGF0aW9uKGNvbnN0cnVjdCwgJ1N1cHBsZW1lbnRhbERhdGFTdG9yYWdlJyk7XG5cbiAgICAvLyBgQ2ZuUHJvcHNNaXhpbmAgZGVlcC1tZXJnZXMgaW50byB0aGUgZXhpc3RpbmcgY29uZmlndXJhdGlvblxuICAgIE1peGlucy5vZihjb25zdHJ1Y3QsIENvbnN0cnVjdFNlbGVjdG9yLm9ubHlJdHNlbGYoKSkuYXBwbHkobmV3IENmblByb3BzTWl4aW4oQ2ZuS25vd2xlZGdlQmFzZSwge1xuICAgICAga25vd2xlZGdlQmFzZUNvbmZpZ3VyYXRpb246IHtcbiAgICAgICAgdmVjdG9yS25vd2xlZGdlQmFzZUNvbmZpZ3VyYXRpb246IHtcbiAgICAgICAgICBzdXBwbGVtZW50YWxEYXRhU3RvcmFnZUNvbmZpZ3VyYXRpb246IHtcbiAgICAgICAgICAgIHN1cHBsZW1lbnRhbERhdGFTdG9yYWdlTG9jYXRpb25zOiBbe1xuICAgICAgICAgICAgICBzdXBwbGVtZW50YWxEYXRhU3RvcmFnZUxvY2F0aW9uVHlwZTogJ1MzJyxcbiAgICAgICAgICAgICAgczNMb2NhdGlvbjogeyB1cmk6IGBzMzovLyR7dGhpcy5wcm9wcy5idWNrZXQuYnVja2V0UmVmLmJ1Y2tldE5hbWV9L2AgfSxcbiAgICAgICAgICAgIH1dLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0pKTtcblxuICAgIC8vIEJlZHJvY2sgdmFsaWRhdGVzIGFjY2VzcyB0byB0aGUgYnVja2V0IHdoZW4gdGhlIGtub3dsZWRnZSBiYXNlIGlzXG4gICAgLy8gY3JlYXRlZCwgc28gdGhlIHBvbGljeSBtdXN0IGV4aXN0IGJlZm9yZSB0aGUga25vd2xlZGdlIGJhc2UgZG9lcy5cbiAgICBzMy5CdWNrZXRHcmFudHMuZnJvbUJ1Y2tldCh0aGlzLnByb3BzLmJ1Y2tldClcbiAgICAgIC5hY3Rpb25zT25CdWNrZXRBbmRPYmplY3RLZXlzKHJvbGUsICcqJywgJ3MzOkxpc3RCdWNrZXQnLCAnczM6R2V0T2JqZWN0JywgJ3MzOlB1dE9iamVjdCcsICdzMzpEZWxldGVPYmplY3QnKVxuICAgICAgLmFwcGx5QmVmb3JlKGNvbnN0cnVjdCk7XG5cbiAgICBjb25zdHJ1Y3Qubm9kZS5hZGREZXBlbmRlbmN5KHJvbGUpO1xuICB9XG59XG5cbi8qKlxuICogQ29uZmlndXJlcyBhIGtub3dsZWRnZSBiYXNlIGFzIHRoZSBnaXZlbiB0eXBlLlxuICpcbiAqIEFwcGxpZXMgdGhlIHR5cGUtc3BlY2lmaWMgY29uZmlndXJhdGlvbiwgcGVybWlzc2lvbnMgYW5kIGRlcGVuZGVuY2llcyB0aGF0IHRoZVxuICogYHR5cGVgIHByb3BlcnR5IG9mIGBLbm93bGVkZ2VCYXNlYCBhcHBsaWVzLCBzbyBhIGBDZm5Lbm93bGVkZ2VCYXNlYCBjYW4gYmVcbiAqIGNvbmZpZ3VyZWQgZnJvbSBhIGBLbm93bGVkZ2VCYXNlVHlwZWAgd2l0aG91dCBhcHBseWluZyBpdHMgaW5kaXZpZHVhbCBtaXhpbnMuXG4gKi9cbmV4cG9ydCBjbGFzcyBLbm93bGVkZ2VCYXNlVHlwZUNvbmZpZ3VyYXRpb24gZXh0ZW5kcyBNaXhpbiB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkga25vd2xlZGdlQmFzZVR5cGU6IEtub3dsZWRnZUJhc2VUeXBlKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHB1YmxpYyBzdXBwb3J0cyhjb25zdHJ1Y3Q6IElDb25zdHJ1Y3QpOiBjb25zdHJ1Y3QgaXMgQ2ZuS25vd2xlZGdlQmFzZSB7XG4gICAgcmV0dXJuIENmbktub3dsZWRnZUJhc2UuaXNDZm5Lbm93bGVkZ2VCYXNlKGNvbnN0cnVjdCk7XG4gIH1cblxuICBwdWJsaWMgYXBwbHlUbyhjb25zdHJ1Y3Q6IElDb25zdHJ1Y3QpOiB2b2lkIHtcbiAgICBpZiAoIXRoaXMuc3VwcG9ydHMoY29uc3RydWN0KSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIE1peGlucy5vZihjb25zdHJ1Y3QsIENvbnN0cnVjdFNlbGVjdG9yLm9ubHlJdHNlbGYoKSkuYXBwbHkoLi4udGhpcy5rbm93bGVkZ2VCYXNlVHlwZS5fbWl4aW5zKTtcbiAgfVxufVxuIl19