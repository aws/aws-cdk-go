import * as bedrock from "aws-cdk-lib/aws-bedrock";
import * as iam from "aws-cdk-lib/aws-iam";
import * as cdk from "aws-cdk-lib/core";
/**
 * Collection of grant methods for a IKnowledgeBaseRef
 */
export declare class KnowledgeBaseGrants {
    /**
     * Creates grants for KnowledgeBaseGrants
     */
    static fromKnowledgeBase(resource: bedrock.IKnowledgeBaseRef): KnowledgeBaseGrants;
    protected readonly resource: bedrock.IKnowledgeBaseRef;
    private constructor();
    /**
     * Grant the given identity custom permissions
     */
    actions(grantee: iam.IGrantable, actions: Array<string>, options?: cdk.PermissionsOptions): iam.Grant;
    /**
     * Grant permissions to query this knowledge base and retrieve relevant chunks.
     *
     * This will grant the following permissions on the knowledge base:
     *
     *   - bedrock:Retrieve
     */
    retrieve(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant permissions to query a knowledge base and generate a response with a foundation model.
     *
     * `bedrock:RetrieveAndGenerate` does not support resource-level permissions, so it is granted on all resources (`*`). Access to a specific knowledge base is controlled by `bedrock:Retrieve`, so also call `retrieve()` on this knowledge base, and grant `bedrock:InvokeModel` on the generation model with `BedrockFoundationModel.grantInvoke()`.
     *
     * This will grant the following permissions:
     *
     *   - bedrock:RetrieveAndGenerate
     */
    retrieveAndGenerate(grantee: iam.IGrantable): iam.Grant;
    /**
     * Grant permissions to retrieve the original or extracted content of documents ingested into this knowledge base.
     *
     * `bedrock:GetDocumentContent` requires `bedrock:Retrieve` on the same knowledge base, so both are granted.
     *
     * This will grant the following permissions on the knowledge base:
     *
     *   - bedrock:Retrieve
     *   - bedrock:GetDocumentContent
     */
    getDocumentContent(grantee: iam.IGrantable): iam.Grant;
}
