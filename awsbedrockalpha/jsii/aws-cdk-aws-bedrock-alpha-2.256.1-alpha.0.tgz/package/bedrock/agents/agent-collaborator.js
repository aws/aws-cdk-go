"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentCollaborator = exports.AgentCollaboratorType = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
/**
 * Enum for collaborator's relay conversation history types.
 */
var AgentCollaboratorType;
(function (AgentCollaboratorType) {
    /**
     * Supervisor agent.
     */
    AgentCollaboratorType["SUPERVISOR"] = "SUPERVISOR";
    /**
     * Disabling collaboration.
     */
    AgentCollaboratorType["DISABLED"] = "DISABLED";
    /**
     * Supervisor router.
     */
    AgentCollaboratorType["SUPERVISOR_ROUTER"] = "SUPERVISOR_ROUTER";
})(AgentCollaboratorType || (exports.AgentCollaboratorType = AgentCollaboratorType = {}));
/**
 * Enum for collaborator's relay conversation history types.
 * @internal
 */
var RelayConversationHistoryType;
(function (RelayConversationHistoryType) {
    /**
     * Sending to the collaborator.
     */
    RelayConversationHistoryType["TO_COLLABORATOR"] = "TO_COLLABORATOR";
    /**
     * Disabling relay of conversation history to the collaborator.
     */
    RelayConversationHistoryType["DISABLED"] = "DISABLED";
})(RelayConversationHistoryType || (RelayConversationHistoryType = {}));
/******************************************************************************
 *                         Agent Collaborator Class
 *****************************************************************************/
class AgentCollaborator {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AgentCollaborator", version: "2.256.1-alpha.0" };
    /**
     * The agent alias that this collaborator represents.
     * This is the agent that will be called upon for collaboration.
     */
    agentAlias;
    /**
     * Instructions on how this agent should collaborate with the main agent.
     */
    collaborationInstruction;
    /**
     * A friendly name for the collaborator.
     */
    collaboratorName;
    /**
     * Whether to relay conversation history to this collaborator.
     *
     * @default - undefined (uses service default)
     */
    relayConversationHistory;
    constructor(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentCollaboratorProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, AgentCollaborator);
            }
            throw error;
        }
        // Validate Props
        this.validateProps(props);
        // ------------------------------------------------------
        // Set attributes or defaults
        // ------------------------------------------------------
        this.agentAlias = props.agentAlias;
        this.collaborationInstruction = props.collaborationInstruction;
        this.collaboratorName = props.collaboratorName;
        this.relayConversationHistory = props.relayConversationHistory;
    }
    validateProps(props) {
        if (props.agentAlias.aliasId === 'TSTALIASID') {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `TestAliasNotAllowed`, 'Agent cannot collaborate with TSTALIASID alias of another agent');
        }
    }
    /**
     * Format as CFN properties
     *
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            agentDescriptor: {
                aliasArn: this.agentAlias.aliasArn,
            },
            collaborationInstruction: this.collaborationInstruction,
            collaboratorName: this.collaboratorName,
            relayConversationHistory: this.relayConversationHistory ? RelayConversationHistoryType.TO_COLLABORATOR : RelayConversationHistoryType.DISABLED,
        };
    }
    /**
     * Grants the given identity permissions to collaborate with the agent
     * [disable-awslint:no-grants]
     * @param grantee The principal to grant permissions to
     * @returns The Grant object
     */
    grant(grantee) {
        const grant1 = this.agentAlias.grantInvoke(grantee);
        const combinedGrant = grant1.combine(this.agentAlias.grantGet(grantee));
        return combinedGrant;
    }
}
exports.AgentCollaborator = AgentCollaborator;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWdlbnQtY29sbGFib3JhdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYWdlbnQtY29sbGFib3JhdG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBRUEsd0RBQXNFO0FBQ3RFLDRFQUE0RDtBQUc1RDs7R0FFRztBQUNILElBQVkscUJBZVg7QUFmRCxXQUFZLHFCQUFxQjtJQUMvQjs7T0FFRztJQUNILGtEQUF5QixDQUFBO0lBRXpCOztPQUVHO0lBQ0gsOENBQXFCLENBQUE7SUFFckI7O09BRUc7SUFDSCxnRUFBdUMsQ0FBQTtBQUN6QyxDQUFDLEVBZlcscUJBQXFCLHFDQUFyQixxQkFBcUIsUUFlaEM7QUFFRDs7O0dBR0c7QUFDSCxJQUFLLDRCQVVKO0FBVkQsV0FBSyw0QkFBNEI7SUFDL0I7O09BRUc7SUFDSCxtRUFBbUMsQ0FBQTtJQUVuQzs7T0FFRztJQUNILHFEQUFxQixDQUFBO0FBQ3ZCLENBQUMsRUFWSSw0QkFBNEIsS0FBNUIsNEJBQTRCLFFBVWhDO0FBOEJEOzsrRUFFK0U7QUFFL0UsTUFBYSxpQkFBaUI7O0lBQzVCOzs7T0FHRztJQUNhLFVBQVUsQ0FBYztJQUV4Qzs7T0FFRztJQUNhLHdCQUF3QixDQUFTO0lBRWpEOztPQUVHO0lBQ2EsZ0JBQWdCLENBQVM7SUFFekM7Ozs7T0FJRztJQUNhLHdCQUF3QixDQUFXO0lBRW5ELFlBQW1CLEtBQTZCOzs7Ozs7K0NBeEJyQyxpQkFBaUI7Ozs7UUF5QjFCLGlCQUFpQjtRQUNqQixJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRTFCLHlEQUF5RDtRQUN6RCw2QkFBNkI7UUFDN0IseURBQXlEO1FBQ3pELElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQztRQUNuQyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsS0FBSyxDQUFDLHdCQUF3QixDQUFDO1FBQy9ELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7UUFDL0MsSUFBSSxDQUFDLHdCQUF3QixHQUFHLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQztLQUNoRTtJQUVPLGFBQWEsQ0FBQyxLQUE2QjtRQUNqRCxJQUFJLEtBQUssQ0FBQyxVQUFVLENBQUMsT0FBTyxLQUFLLFlBQVksRUFBRSxDQUFDO1lBQzlDLE1BQU0sSUFBSSxnQ0FBdUIsQ0FBQyxJQUFBLHNCQUFHLEVBQUEscUJBQXFCLEVBQUUsaUVBQWlFLENBQUMsQ0FBQztRQUNqSSxDQUFDO0tBQ0Y7SUFFRDs7OztPQUlHO0lBQ0ksT0FBTztRQUNaLE9BQU87WUFDTCxlQUFlLEVBQUU7Z0JBQ2YsUUFBUSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUTthQUNuQztZQUNELHdCQUF3QixFQUFFLElBQUksQ0FBQyx3QkFBd0I7WUFDdkQsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLGdCQUFnQjtZQUN2Qyx3QkFBd0IsRUFBRSxJQUFJLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsNEJBQTRCLENBQUMsUUFBUTtTQUMvSSxDQUFDO0tBQ0g7SUFFRDs7Ozs7T0FLRztJQUNJLEtBQUssQ0FBQyxPQUFtQjtRQUM5QixNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNwRCxNQUFNLGFBQWEsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDeEUsT0FBTyxhQUFhLENBQUM7S0FDdEI7O0FBckVILDhDQXNFQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgQ2ZuQWdlbnQgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgdHlwZSB7IElHcmFudGFibGUsIEdyYW50IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWlhbSc7XG5pbXBvcnQgeyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvciB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2Vycm9ycyc7XG5pbXBvcnQgeyBsaXQgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9oZWxwZXJzLWludGVybmFsJztcbmltcG9ydCB0eXBlIHsgSUFnZW50QWxpYXMgfSBmcm9tICcuL2FnZW50LWFsaWFzJztcblxuLyoqXG4gKiBFbnVtIGZvciBjb2xsYWJvcmF0b3IncyByZWxheSBjb252ZXJzYXRpb24gaGlzdG9yeSB0eXBlcy5cbiAqL1xuZXhwb3J0IGVudW0gQWdlbnRDb2xsYWJvcmF0b3JUeXBlIHtcbiAgLyoqXG4gICAqIFN1cGVydmlzb3IgYWdlbnQuXG4gICAqL1xuICBTVVBFUlZJU09SID0gJ1NVUEVSVklTT1InLFxuXG4gIC8qKlxuICAgKiBEaXNhYmxpbmcgY29sbGFib3JhdGlvbi5cbiAgICovXG4gIERJU0FCTEVEID0gJ0RJU0FCTEVEJyxcblxuICAvKipcbiAgICogU3VwZXJ2aXNvciByb3V0ZXIuXG4gICAqL1xuICBTVVBFUlZJU09SX1JPVVRFUiA9ICdTVVBFUlZJU09SX1JPVVRFUicsXG59XG5cbi8qKlxuICogRW51bSBmb3IgY29sbGFib3JhdG9yJ3MgcmVsYXkgY29udmVyc2F0aW9uIGhpc3RvcnkgdHlwZXMuXG4gKiBAaW50ZXJuYWxcbiAqL1xuZW51bSBSZWxheUNvbnZlcnNhdGlvbkhpc3RvcnlUeXBlIHtcbiAgLyoqXG4gICAqIFNlbmRpbmcgdG8gdGhlIGNvbGxhYm9yYXRvci5cbiAgICovXG4gIFRPX0NPTExBQk9SQVRPUiA9ICdUT19DT0xMQUJPUkFUT1InLFxuXG4gIC8qKlxuICAgKiBEaXNhYmxpbmcgcmVsYXkgb2YgY29udmVyc2F0aW9uIGhpc3RvcnkgdG8gdGhlIGNvbGxhYm9yYXRvci5cbiAgICovXG4gIERJU0FCTEVEID0gJ0RJU0FCTEVEJyxcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgIFBST1BTIC0gQWdlbnQgQ29sbGFib3JhdG9yIENsYXNzXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5leHBvcnQgaW50ZXJmYWNlIEFnZW50Q29sbGFib3JhdG9yUHJvcHMge1xuICAvKipcbiAgICogRGVzY3JpcHRvciBmb3IgdGhlIGNvbGxhYm9yYXRpbmcgYWdlbnQuXG4gICAqIFRoaXMgY2Fubm90IGJlIHRoZSBUU1RBTElBU0lEIChgYWdlbnQudGVzdEFsaWFzYCkuXG4gICAqL1xuICByZWFkb25seSBhZ2VudEFsaWFzOiBJQWdlbnRBbGlhcztcblxuICAvKipcbiAgICogSW5zdHJ1Y3Rpb25zIG9uIGhvdyB0aGlzIGFnZW50IHNob3VsZCBjb2xsYWJvcmF0ZSB3aXRoIHRoZSBtYWluIGFnZW50LlxuICAgKi9cbiAgcmVhZG9ubHkgY29sbGFib3JhdGlvbkluc3RydWN0aW9uOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEEgZnJpZW5kbHkgbmFtZSBmb3IgdGhlIGNvbGxhYm9yYXRvci5cbiAgICovXG4gIHJlYWRvbmx5IGNvbGxhYm9yYXRvck5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogV2hldGhlciB0byByZWxheSBjb252ZXJzYXRpb24gaGlzdG9yeSB0byB0aGlzIGNvbGxhYm9yYXRvci5cbiAgICpcbiAgICogQGRlZmF1bHQgLSB1bmRlZmluZWQgKHVzZXMgc2VydmljZSBkZWZhdWx0KVxuICAgKi9cbiAgcmVhZG9ubHkgcmVsYXlDb252ZXJzYXRpb25IaXN0b3J5PzogYm9vbGVhbjtcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgQWdlbnQgQ29sbGFib3JhdG9yIENsYXNzXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbmV4cG9ydCBjbGFzcyBBZ2VudENvbGxhYm9yYXRvciB7XG4gIC8qKlxuICAgKiBUaGUgYWdlbnQgYWxpYXMgdGhhdCB0aGlzIGNvbGxhYm9yYXRvciByZXByZXNlbnRzLlxuICAgKiBUaGlzIGlzIHRoZSBhZ2VudCB0aGF0IHdpbGwgYmUgY2FsbGVkIHVwb24gZm9yIGNvbGxhYm9yYXRpb24uXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgYWdlbnRBbGlhczogSUFnZW50QWxpYXM7XG5cbiAgLyoqXG4gICAqIEluc3RydWN0aW9ucyBvbiBob3cgdGhpcyBhZ2VudCBzaG91bGQgY29sbGFib3JhdGUgd2l0aCB0aGUgbWFpbiBhZ2VudC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBjb2xsYWJvcmF0aW9uSW5zdHJ1Y3Rpb246IHN0cmluZztcblxuICAvKipcbiAgICogQSBmcmllbmRseSBuYW1lIGZvciB0aGUgY29sbGFib3JhdG9yLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGNvbGxhYm9yYXRvck5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogV2hldGhlciB0byByZWxheSBjb252ZXJzYXRpb24gaGlzdG9yeSB0byB0aGlzIGNvbGxhYm9yYXRvci5cbiAgICpcbiAgICogQGRlZmF1bHQgLSB1bmRlZmluZWQgKHVzZXMgc2VydmljZSBkZWZhdWx0KVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHJlbGF5Q29udmVyc2F0aW9uSGlzdG9yeT86IGJvb2xlYW47XG5cbiAgcHVibGljIGNvbnN0cnVjdG9yKHByb3BzOiBBZ2VudENvbGxhYm9yYXRvclByb3BzKSB7XG4gICAgLy8gVmFsaWRhdGUgUHJvcHNcbiAgICB0aGlzLnZhbGlkYXRlUHJvcHMocHJvcHMpO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gU2V0IGF0dHJpYnV0ZXMgb3IgZGVmYXVsdHNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLmFnZW50QWxpYXMgPSBwcm9wcy5hZ2VudEFsaWFzO1xuICAgIHRoaXMuY29sbGFib3JhdGlvbkluc3RydWN0aW9uID0gcHJvcHMuY29sbGFib3JhdGlvbkluc3RydWN0aW9uO1xuICAgIHRoaXMuY29sbGFib3JhdG9yTmFtZSA9IHByb3BzLmNvbGxhYm9yYXRvck5hbWU7XG4gICAgdGhpcy5yZWxheUNvbnZlcnNhdGlvbkhpc3RvcnkgPSBwcm9wcy5yZWxheUNvbnZlcnNhdGlvbkhpc3Rvcnk7XG4gIH1cblxuICBwcml2YXRlIHZhbGlkYXRlUHJvcHMocHJvcHM6IEFnZW50Q29sbGFib3JhdG9yUHJvcHMpIHtcbiAgICBpZiAocHJvcHMuYWdlbnRBbGlhcy5hbGlhc0lkID09PSAnVFNUQUxJQVNJRCcpIHtcbiAgICAgIHRocm93IG5ldyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvcihsaXRgVGVzdEFsaWFzTm90QWxsb3dlZGAsICdBZ2VudCBjYW5ub3QgY29sbGFib3JhdGUgd2l0aCBUU1RBTElBU0lEIGFsaWFzIG9mIGFub3RoZXIgYWdlbnQnKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRm9ybWF0IGFzIENGTiBwcm9wZXJ0aWVzXG4gICAqXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIF9yZW5kZXIoKTogQ2ZuQWdlbnQuQWdlbnRDb2xsYWJvcmF0b3JQcm9wZXJ0eSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGFnZW50RGVzY3JpcHRvcjoge1xuICAgICAgICBhbGlhc0FybjogdGhpcy5hZ2VudEFsaWFzLmFsaWFzQXJuLFxuICAgICAgfSxcbiAgICAgIGNvbGxhYm9yYXRpb25JbnN0cnVjdGlvbjogdGhpcy5jb2xsYWJvcmF0aW9uSW5zdHJ1Y3Rpb24sXG4gICAgICBjb2xsYWJvcmF0b3JOYW1lOiB0aGlzLmNvbGxhYm9yYXRvck5hbWUsXG4gICAgICByZWxheUNvbnZlcnNhdGlvbkhpc3Rvcnk6IHRoaXMucmVsYXlDb252ZXJzYXRpb25IaXN0b3J5ID8gUmVsYXlDb252ZXJzYXRpb25IaXN0b3J5VHlwZS5UT19DT0xMQUJPUkFUT1IgOiBSZWxheUNvbnZlcnNhdGlvbkhpc3RvcnlUeXBlLkRJU0FCTEVELFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogR3JhbnRzIHRoZSBnaXZlbiBpZGVudGl0eSBwZXJtaXNzaW9ucyB0byBjb2xsYWJvcmF0ZSB3aXRoIHRoZSBhZ2VudFxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICogQHBhcmFtIGdyYW50ZWUgVGhlIHByaW5jaXBhbCB0byBncmFudCBwZXJtaXNzaW9ucyB0b1xuICAgKiBAcmV0dXJucyBUaGUgR3JhbnQgb2JqZWN0XG4gICAqL1xuICBwdWJsaWMgZ3JhbnQoZ3JhbnRlZTogSUdyYW50YWJsZSk6IEdyYW50IHtcbiAgICBjb25zdCBncmFudDEgPSB0aGlzLmFnZW50QWxpYXMuZ3JhbnRJbnZva2UoZ3JhbnRlZSk7XG4gICAgY29uc3QgY29tYmluZWRHcmFudCA9IGdyYW50MS5jb21iaW5lKHRoaXMuYWdlbnRBbGlhcy5ncmFudEdldChncmFudGVlKSk7XG4gICAgcmV0dXJuIGNvbWJpbmVkR3JhbnQ7XG4gIH1cbn1cbiJdfQ==