"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentCollaboration = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
/**
 * Class to manage agent collaboration configuration.
 */
class AgentCollaboration {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AgentCollaboration", version: "2.256.1-alpha.0" };
    /**
     * The collaboration type for the agent.
     */
    type;
    /**
     * Collaborators that this agent will work with.
     */
    collaborators;
    constructor(config) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentCollaborationConfig(config);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, AgentCollaboration);
            }
            throw error;
        }
        this.type = config.type;
        this.collaborators = config.collaborators;
    }
}
exports.AgentCollaboration = AgentCollaboration;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWdlbnQtY29sbGFib3JhdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImFnZW50LWNvbGxhYm9yYXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFpQkE7O0dBRUc7QUFDSCxNQUFhLGtCQUFrQjs7SUFDN0I7O09BRUc7SUFDYSxJQUFJLENBQXdCO0lBRTVDOztPQUVHO0lBQ2EsYUFBYSxDQUFzQjtJQUVuRCxZQUFZLE1BQWdDOzs7Ozs7K0NBWGpDLGtCQUFrQjs7OztRQVkzQixJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUM7UUFDeEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsYUFBYSxDQUFDO0tBQzNDOztBQWRILGdEQWVDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBBZ2VudENvbGxhYm9yYXRvciwgQWdlbnRDb2xsYWJvcmF0b3JUeXBlIH0gZnJvbSAnLi9hZ2VudC1jb2xsYWJvcmF0b3InO1xuXG4vKipcbiAqIENvbmZpZ3VyYXRpb24gZm9yIGFnZW50IGNvbGxhYm9yYXRpb24gc2V0dGluZ3MuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQWdlbnRDb2xsYWJvcmF0aW9uQ29uZmlnIHtcbiAgLyoqXG4gICAqIFRoZSBjb2xsYWJvcmF0aW9uIHR5cGUgZm9yIHRoZSBhZ2VudC5cbiAgICovXG4gIHJlYWRvbmx5IHR5cGU6IEFnZW50Q29sbGFib3JhdG9yVHlwZTtcblxuICAvKipcbiAgICogQ29sbGFib3JhdG9ycyB0aGF0IHRoaXMgYWdlbnQgd2lsbCB3b3JrIHdpdGguXG4gICAqL1xuICByZWFkb25seSBjb2xsYWJvcmF0b3JzOiBBZ2VudENvbGxhYm9yYXRvcltdO1xufVxuXG4vKipcbiAqIENsYXNzIHRvIG1hbmFnZSBhZ2VudCBjb2xsYWJvcmF0aW9uIGNvbmZpZ3VyYXRpb24uXG4gKi9cbmV4cG9ydCBjbGFzcyBBZ2VudENvbGxhYm9yYXRpb24ge1xuICAvKipcbiAgICogVGhlIGNvbGxhYm9yYXRpb24gdHlwZSBmb3IgdGhlIGFnZW50LlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHR5cGU6IEFnZW50Q29sbGFib3JhdG9yVHlwZTtcblxuICAvKipcbiAgICogQ29sbGFib3JhdG9ycyB0aGF0IHRoaXMgYWdlbnQgd2lsbCB3b3JrIHdpdGguXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgY29sbGFib3JhdG9yczogQWdlbnRDb2xsYWJvcmF0b3JbXTtcblxuICBjb25zdHJ1Y3Rvcihjb25maWc6IEFnZW50Q29sbGFib3JhdGlvbkNvbmZpZykge1xuICAgIHRoaXMudHlwZSA9IGNvbmZpZy50eXBlO1xuICAgIHRoaXMuY29sbGFib3JhdG9ycyA9IGNvbmZpZy5jb2xsYWJvcmF0b3JzO1xuICB9XG59XG4iXX0=