"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3ApiSchema = exports.InlineApiSchema = exports.AssetApiSchema = exports.ApiSchema = void 0;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const s3_assets = require("aws-cdk-lib/aws-s3-assets");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const schema_base_1 = require("./schema-base");
/******************************************************************************
 *                       API SCHEMA CLASS
 *****************************************************************************/
/**
 * Represents the concept of an API Schema for a Bedrock Agent Action Group.
 */
class ApiSchema extends schema_base_1.ActionGroupSchema {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ApiSchema", version: "2.256.1-alpha.0" };
    /**
     * Creates an API Schema from a local file.
     * @param path - the path to the local file containing the OpenAPI schema for the action group
     */
    static fromLocalAsset(path) {
        return new AssetApiSchema(path);
    }
    /**
     * Creates an API Schema from an inline string.
     * @param schema - the JSON or YAML payload defining the OpenAPI schema for the action group
     */
    static fromInline(schema) {
        return new InlineApiSchema(schema);
    }
    /**
     * Creates an API Schema from an S3 File
     * @param bucket - the bucket containing the local file containing the OpenAPI schema for the action group
     * @param objectKey - object key in the bucket
     */
    static fromS3File(bucket, objectKey) {
        return new S3ApiSchema({
            bucketName: bucket.bucketRef.bucketName,
            objectKey: objectKey,
        });
    }
    /**
     * The S3 location of the API schema file, if using an S3-based schema.
     * Contains the bucket name and object key information.
     */
    s3File;
    /**
     * The inline OpenAPI schema definition as a string, if using an inline schema.
     * Can be in JSON or YAML format.
     */
    inlineSchema;
    constructor(s3File, inlineSchema) {
        super();
        this.s3File = s3File;
        this.inlineSchema = inlineSchema;
    }
}
exports.ApiSchema = ApiSchema;
/**
 * API Schema from a local asset.
 *
 * The asset is uploaded to an S3 staging bucket, then moved to its final location
 * by CloudFormation during deployment.
 */
class AssetApiSchema extends ApiSchema {
    path;
    options;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AssetApiSchema", version: "2.256.1-alpha.0" };
    asset;
    constructor(path, options = {}) {
        super();
        this.path = path;
        this.options = options;
    }
    /**
     * Binds this API schema to a construct scope.
     * This method initializes the S3 asset if it hasn't been initialized yet.
     * Must be called before rendering the schema as CFN properties.
     *
     * @param scope - The construct scope to bind to
     */
    bind(scope) {
        // If the same AssetApiSchema is used multiple times, retain only the first instantiation
        if (!this.asset) {
            this.asset = new s3_assets.Asset(scope, 'Schema', {
                path: this.path,
                ...this.options,
            });
            // Note: Permissions will be granted by the Agent construct when adding the action group
        }
    }
    /**
     * Format as CFN properties
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        if (!this.asset) {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `SchemaNotBound`, 'ApiSchema must be bound to a scope before rendering. Call bind() first.');
        }
        return {
            s3: {
                s3BucketName: this.asset.s3BucketName,
                s3ObjectKey: this.asset.s3ObjectKey,
            },
        };
    }
}
exports.AssetApiSchema = AssetApiSchema;
// ------------------------------------------------------
/**
 * Class to define an API Schema from an inline string.
 * The schema can be provided directly as a string in either JSON or YAML format.
 */
class InlineApiSchema extends ApiSchema {
    schema;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.InlineApiSchema", version: "2.256.1-alpha.0" };
    constructor(schema) {
        super(undefined, schema);
        this.schema = schema;
    }
    /**
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            payload: this.schema,
        };
    }
}
exports.InlineApiSchema = InlineApiSchema;
// ------------------------------------------------------
// S3 File
// ------------------------------------------------------
/**
 * Class to define an API Schema from an S3 object.
 */
class S3ApiSchema extends ApiSchema {
    location;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.S3ApiSchema", version: "2.256.1-alpha.0" };
    constructor(location) {
        super(location, undefined);
        this.location = location;
    }
    /**
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            s3: {
                s3BucketName: this.location.bucketName,
                s3ObjectKey: this.location.objectKey,
            },
        };
    }
}
exports.S3ApiSchema = S3ApiSchema;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLXNjaGVtYS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImFwaS1zY2hlbWEudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUVBLHVEQUF1RDtBQUN2RCx3REFBc0U7QUFDdEUsNEVBQTREO0FBRTVELCtDQUFrRDtBQUVsRDs7K0VBRStFO0FBQy9FOztHQUVHO0FBQ0gsTUFBc0IsU0FBVSxTQUFRLCtCQUFpQjs7SUFDdkQ7OztPQUdHO0lBQ0ksTUFBTSxDQUFDLGNBQWMsQ0FBQyxJQUFZO1FBQ3ZDLE9BQU8sSUFBSSxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDakM7SUFFRDs7O09BR0c7SUFDSSxNQUFNLENBQUMsVUFBVSxDQUFDLE1BQWM7UUFDckMsT0FBTyxJQUFJLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUNwQztJQUVEOzs7O09BSUc7SUFDSSxNQUFNLENBQUMsVUFBVSxDQUFDLE1BQWtCLEVBQUUsU0FBaUI7UUFDNUQsT0FBTyxJQUFJLFdBQVcsQ0FBQztZQUNyQixVQUFVLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVO1lBQ3ZDLFNBQVMsRUFBRSxTQUFTO1NBQ3JCLENBQUMsQ0FBQztLQUNKO0lBRUQ7OztPQUdHO0lBQ2EsTUFBTSxDQUFZO0lBRWxDOzs7T0FHRztJQUNhLFlBQVksQ0FBVTtJQUV0QyxZQUFzQixNQUFpQixFQUFFLFlBQXFCO1FBQzVELEtBQUssRUFBRSxDQUFDO1FBQ1IsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDckIsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUM7S0FDbEM7O0FBN0NILDhCQXFEQztBQUVEOzs7OztHQUtHO0FBQ0gsTUFBYSxjQUFlLFNBQVEsU0FBUztJQUdkO0lBQStCOztJQUZwRCxLQUFLLENBQW1CO0lBRWhDLFlBQTZCLElBQVksRUFBbUIsVUFBa0MsRUFBRTtRQUM5RixLQUFLLEVBQUUsQ0FBQztRQURtQixTQUFJLEdBQUosSUFBSSxDQUFRO1FBQW1CLFlBQU8sR0FBUCxPQUFPLENBQTZCO0tBRS9GO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksSUFBSSxDQUFDLEtBQWdCO1FBQzFCLHlGQUF5RjtRQUN6RixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2hCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxRQUFRLEVBQUU7Z0JBQ2hELElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtnQkFDZixHQUFHLElBQUksQ0FBQyxPQUFPO2FBQ2hCLENBQUMsQ0FBQztZQUNILHdGQUF3RjtRQUMxRixDQUFDO0tBQ0Y7SUFFRDs7O09BR0c7SUFDSSxPQUFPO1FBQ1osSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNoQixNQUFNLElBQUksZ0NBQXVCLENBQUMsSUFBQSxzQkFBRyxFQUFBLGdCQUFnQixFQUFFLHlFQUF5RSxDQUFDLENBQUM7UUFDcEksQ0FBQztRQUVELE9BQU87WUFDTCxFQUFFLEVBQUU7Z0JBQ0YsWUFBWSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWTtnQkFDckMsV0FBVyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVzthQUNwQztTQUNGLENBQUM7S0FDSDs7QUF4Q0gsd0NBeUNDO0FBRUQseURBQXlEO0FBQ3pEOzs7R0FHRztBQUNILE1BQWEsZUFBZ0IsU0FBUSxTQUFTO0lBQ2Y7O0lBQTdCLFlBQTZCLE1BQWM7UUFDekMsS0FBSyxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQztRQURFLFdBQU0sR0FBTixNQUFNLENBQVE7S0FFMUM7SUFFRDs7T0FFRztJQUNJLE9BQU87UUFDWixPQUFPO1lBQ0wsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNO1NBQ3JCLENBQUM7S0FDSDs7QUFaSCwwQ0FhQztBQUVELHlEQUF5RDtBQUN6RCxVQUFVO0FBQ1YseURBQXlEO0FBQ3pEOztHQUVHO0FBQ0gsTUFBYSxXQUFZLFNBQVEsU0FBUztJQUNYOztJQUE3QixZQUE2QixRQUFrQjtRQUM3QyxLQUFLLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBREEsYUFBUSxHQUFSLFFBQVEsQ0FBVTtLQUU5QztJQUNEOztPQUVHO0lBQ0ksT0FBTztRQUNaLE9BQU87WUFDTCxFQUFFLEVBQUU7Z0JBQ0YsWUFBWSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVTtnQkFDdEMsV0FBVyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUzthQUNyQztTQUNGLENBQUM7S0FDSDs7QUFkSCxrQ0FlQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgQ2ZuQWdlbnQgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgdHlwZSB7IElCdWNrZXRSZWYsIExvY2F0aW9uIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLXMzJztcbmltcG9ydCAqIGFzIHMzX2Fzc2V0cyBmcm9tICdhd3MtY2RrLWxpYi9hd3MtczMtYXNzZXRzJztcbmltcG9ydCB7IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvZXJyb3JzJztcbmltcG9ydCB7IGxpdCB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2hlbHBlcnMtaW50ZXJuYWwnO1xuaW1wb3J0IHR5cGUgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcbmltcG9ydCB7IEFjdGlvbkdyb3VwU2NoZW1hIH0gZnJvbSAnLi9zY2hlbWEtYmFzZSc7XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICBBUEkgU0NIRU1BIENMQVNTXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIFJlcHJlc2VudHMgdGhlIGNvbmNlcHQgb2YgYW4gQVBJIFNjaGVtYSBmb3IgYSBCZWRyb2NrIEFnZW50IEFjdGlvbiBHcm91cC5cbiAqL1xuZXhwb3J0IGFic3RyYWN0IGNsYXNzIEFwaVNjaGVtYSBleHRlbmRzIEFjdGlvbkdyb3VwU2NoZW1hIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYW4gQVBJIFNjaGVtYSBmcm9tIGEgbG9jYWwgZmlsZS5cbiAgICogQHBhcmFtIHBhdGggLSB0aGUgcGF0aCB0byB0aGUgbG9jYWwgZmlsZSBjb250YWluaW5nIHRoZSBPcGVuQVBJIHNjaGVtYSBmb3IgdGhlIGFjdGlvbiBncm91cFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tTG9jYWxBc3NldChwYXRoOiBzdHJpbmcpOiBBc3NldEFwaVNjaGVtYSB7XG4gICAgcmV0dXJuIG5ldyBBc3NldEFwaVNjaGVtYShwYXRoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGFuIEFQSSBTY2hlbWEgZnJvbSBhbiBpbmxpbmUgc3RyaW5nLlxuICAgKiBAcGFyYW0gc2NoZW1hIC0gdGhlIEpTT04gb3IgWUFNTCBwYXlsb2FkIGRlZmluaW5nIHRoZSBPcGVuQVBJIHNjaGVtYSBmb3IgdGhlIGFjdGlvbiBncm91cFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tSW5saW5lKHNjaGVtYTogc3RyaW5nKTogSW5saW5lQXBpU2NoZW1hIHtcbiAgICByZXR1cm4gbmV3IElubGluZUFwaVNjaGVtYShzY2hlbWEpO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYW4gQVBJIFNjaGVtYSBmcm9tIGFuIFMzIEZpbGVcbiAgICogQHBhcmFtIGJ1Y2tldCAtIHRoZSBidWNrZXQgY29udGFpbmluZyB0aGUgbG9jYWwgZmlsZSBjb250YWluaW5nIHRoZSBPcGVuQVBJIHNjaGVtYSBmb3IgdGhlIGFjdGlvbiBncm91cFxuICAgKiBAcGFyYW0gb2JqZWN0S2V5IC0gb2JqZWN0IGtleSBpbiB0aGUgYnVja2V0XG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21TM0ZpbGUoYnVja2V0OiBJQnVja2V0UmVmLCBvYmplY3RLZXk6IHN0cmluZyk6IFMzQXBpU2NoZW1hIHtcbiAgICByZXR1cm4gbmV3IFMzQXBpU2NoZW1hKHtcbiAgICAgIGJ1Y2tldE5hbWU6IGJ1Y2tldC5idWNrZXRSZWYuYnVja2V0TmFtZSxcbiAgICAgIG9iamVjdEtleTogb2JqZWN0S2V5LFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBTMyBsb2NhdGlvbiBvZiB0aGUgQVBJIHNjaGVtYSBmaWxlLCBpZiB1c2luZyBhbiBTMy1iYXNlZCBzY2hlbWEuXG4gICAqIENvbnRhaW5zIHRoZSBidWNrZXQgbmFtZSBhbmQgb2JqZWN0IGtleSBpbmZvcm1hdGlvbi5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBzM0ZpbGU/OiBMb2NhdGlvbjtcblxuICAvKipcbiAgICogVGhlIGlubGluZSBPcGVuQVBJIHNjaGVtYSBkZWZpbml0aW9uIGFzIGEgc3RyaW5nLCBpZiB1c2luZyBhbiBpbmxpbmUgc2NoZW1hLlxuICAgKiBDYW4gYmUgaW4gSlNPTiBvciBZQU1MIGZvcm1hdC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBpbmxpbmVTY2hlbWE/OiBzdHJpbmc7XG5cbiAgcHJvdGVjdGVkIGNvbnN0cnVjdG9yKHMzRmlsZT86IExvY2F0aW9uLCBpbmxpbmVTY2hlbWE/OiBzdHJpbmcpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuczNGaWxlID0gczNGaWxlO1xuICAgIHRoaXMuaW5saW5lU2NoZW1hID0gaW5saW5lU2NoZW1hO1xuICB9XG5cbiAgLyoqXG4gICAqIEZvcm1hdCBhcyBDRk4gcHJvcGVydGllc1xuICAgKlxuICAgKiBAaW50ZXJuYWwgVGhpcyBpcyBhbiBpbnRlcm5hbCBjb3JlIGZ1bmN0aW9uIGFuZCBzaG91bGQgbm90IGJlIGNhbGxlZCBkaXJlY3RseS5cbiAgICovXG4gIHB1YmxpYyBhYnN0cmFjdCBfcmVuZGVyKCk6IENmbkFnZW50LkFQSVNjaGVtYVByb3BlcnR5O1xufVxuXG4vKipcbiAqIEFQSSBTY2hlbWEgZnJvbSBhIGxvY2FsIGFzc2V0LlxuICpcbiAqIFRoZSBhc3NldCBpcyB1cGxvYWRlZCB0byBhbiBTMyBzdGFnaW5nIGJ1Y2tldCwgdGhlbiBtb3ZlZCB0byBpdHMgZmluYWwgbG9jYXRpb25cbiAqIGJ5IENsb3VkRm9ybWF0aW9uIGR1cmluZyBkZXBsb3ltZW50LlxuICovXG5leHBvcnQgY2xhc3MgQXNzZXRBcGlTY2hlbWEgZXh0ZW5kcyBBcGlTY2hlbWEge1xuICBwcml2YXRlIGFzc2V0PzogczNfYXNzZXRzLkFzc2V0O1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgcGF0aDogc3RyaW5nLCBwcml2YXRlIHJlYWRvbmx5IG9wdGlvbnM6IHMzX2Fzc2V0cy5Bc3NldE9wdGlvbnMgPSB7fSkge1xuICAgIHN1cGVyKCk7XG4gIH1cblxuICAvKipcbiAgICogQmluZHMgdGhpcyBBUEkgc2NoZW1hIHRvIGEgY29uc3RydWN0IHNjb3BlLlxuICAgKiBUaGlzIG1ldGhvZCBpbml0aWFsaXplcyB0aGUgUzMgYXNzZXQgaWYgaXQgaGFzbid0IGJlZW4gaW5pdGlhbGl6ZWQgeWV0LlxuICAgKiBNdXN0IGJlIGNhbGxlZCBiZWZvcmUgcmVuZGVyaW5nIHRoZSBzY2hlbWEgYXMgQ0ZOIHByb3BlcnRpZXMuXG4gICAqXG4gICAqIEBwYXJhbSBzY29wZSAtIFRoZSBjb25zdHJ1Y3Qgc2NvcGUgdG8gYmluZCB0b1xuICAgKi9cbiAgcHVibGljIGJpbmQoc2NvcGU6IENvbnN0cnVjdCk6IHZvaWQge1xuICAgIC8vIElmIHRoZSBzYW1lIEFzc2V0QXBpU2NoZW1hIGlzIHVzZWQgbXVsdGlwbGUgdGltZXMsIHJldGFpbiBvbmx5IHRoZSBmaXJzdCBpbnN0YW50aWF0aW9uXG4gICAgaWYgKCF0aGlzLmFzc2V0KSB7XG4gICAgICB0aGlzLmFzc2V0ID0gbmV3IHMzX2Fzc2V0cy5Bc3NldChzY29wZSwgJ1NjaGVtYScsIHtcbiAgICAgICAgcGF0aDogdGhpcy5wYXRoLFxuICAgICAgICAuLi50aGlzLm9wdGlvbnMsXG4gICAgICB9KTtcbiAgICAgIC8vIE5vdGU6IFBlcm1pc3Npb25zIHdpbGwgYmUgZ3JhbnRlZCBieSB0aGUgQWdlbnQgY29uc3RydWN0IHdoZW4gYWRkaW5nIHRoZSBhY3Rpb24gZ3JvdXBcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRm9ybWF0IGFzIENGTiBwcm9wZXJ0aWVzXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIF9yZW5kZXIoKTogQ2ZuQWdlbnQuQVBJU2NoZW1hUHJvcGVydHkge1xuICAgIGlmICghdGhpcy5hc3NldCkge1xuICAgICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKGxpdGBTY2hlbWFOb3RCb3VuZGAsICdBcGlTY2hlbWEgbXVzdCBiZSBib3VuZCB0byBhIHNjb3BlIGJlZm9yZSByZW5kZXJpbmcuIENhbGwgYmluZCgpIGZpcnN0LicpO1xuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBzMzoge1xuICAgICAgICBzM0J1Y2tldE5hbWU6IHRoaXMuYXNzZXQuczNCdWNrZXROYW1lLFxuICAgICAgICBzM09iamVjdEtleTogdGhpcy5hc3NldC5zM09iamVjdEtleSxcbiAgICAgIH0sXG4gICAgfTtcbiAgfVxufVxuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8qKlxuICogQ2xhc3MgdG8gZGVmaW5lIGFuIEFQSSBTY2hlbWEgZnJvbSBhbiBpbmxpbmUgc3RyaW5nLlxuICogVGhlIHNjaGVtYSBjYW4gYmUgcHJvdmlkZWQgZGlyZWN0bHkgYXMgYSBzdHJpbmcgaW4gZWl0aGVyIEpTT04gb3IgWUFNTCBmb3JtYXQuXG4gKi9cbmV4cG9ydCBjbGFzcyBJbmxpbmVBcGlTY2hlbWEgZXh0ZW5kcyBBcGlTY2hlbWEge1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJlYWRvbmx5IHNjaGVtYTogc3RyaW5nKSB7XG4gICAgc3VwZXIodW5kZWZpbmVkLCBzY2hlbWEpO1xuICB9XG5cbiAgLyoqXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIF9yZW5kZXIoKTogQ2ZuQWdlbnQuQVBJU2NoZW1hUHJvcGVydHkge1xuICAgIHJldHVybiB7XG4gICAgICBwYXlsb2FkOiB0aGlzLnNjaGVtYSxcbiAgICB9O1xuICB9XG59XG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gUzMgRmlsZVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vKipcbiAqIENsYXNzIHRvIGRlZmluZSBhbiBBUEkgU2NoZW1hIGZyb20gYW4gUzMgb2JqZWN0LlxuICovXG5leHBvcnQgY2xhc3MgUzNBcGlTY2hlbWEgZXh0ZW5kcyBBcGlTY2hlbWEge1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJlYWRvbmx5IGxvY2F0aW9uOiBMb2NhdGlvbikge1xuICAgIHN1cGVyKGxvY2F0aW9uLCB1bmRlZmluZWQpO1xuICB9XG4gIC8qKlxuICAgKiBAaW50ZXJuYWwgVGhpcyBpcyBhbiBpbnRlcm5hbCBjb3JlIGZ1bmN0aW9uIGFuZCBzaG91bGQgbm90IGJlIGNhbGxlZCBkaXJlY3RseS5cbiAgICovXG4gIHB1YmxpYyBfcmVuZGVyKCk6IENmbkFnZW50LkFQSVNjaGVtYVByb3BlcnR5IHtcbiAgICByZXR1cm4ge1xuICAgICAgczM6IHtcbiAgICAgICAgczNCdWNrZXROYW1lOiB0aGlzLmxvY2F0aW9uLmJ1Y2tldE5hbWUsXG4gICAgICAgIHMzT2JqZWN0S2V5OiB0aGlzLmxvY2F0aW9uLm9iamVjdEtleSxcbiAgICAgIH0sXG4gICAgfTtcbiAgfVxufVxuIl19