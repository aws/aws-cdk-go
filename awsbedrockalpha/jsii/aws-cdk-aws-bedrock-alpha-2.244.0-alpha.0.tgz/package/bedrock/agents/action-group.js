"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentActionGroup = exports.ParentActionGroupSignature = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const crypto = require("crypto");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
/******************************************************************************
 *                           Signatures
 *****************************************************************************/
/**
 * AWS Defined signatures for enabling certain capabilities in your agent.
 */
class ParentActionGroupSignature {
    value;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ParentActionGroupSignature", version: "2.244.0-alpha.0" };
    /**
     * Signature that allows your agent to request the user for additional information when trying to complete a task.
     */
    static USER_INPUT = new ParentActionGroupSignature('AMAZON.UserInput');
    /**
     * Signature that allows your agent to generate, run, and troubleshoot code when trying to complete a task.
     */
    static CODE_INTERPRETER = new ParentActionGroupSignature('AMAZON.CodeInterpreter');
    /**
     * Constructor should be used as a temporary solution when a new signature is supported but its implementation in CDK hasn't been added yet.
     */
    constructor(
    /**
     * The AWS-defined signature value for this action group capability.
     */
    value) {
        this.value = value;
    }
    /**
     * Returns the string representation of the signature value.
     * Used when configuring the action group in CloudFormation.
     */
    toString() {
        return this.value;
    }
}
exports.ParentActionGroupSignature = ParentActionGroupSignature;
/******************************************************************************
 *                         DEF - Action Group Class
 *****************************************************************************/
class AgentActionGroup {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AgentActionGroup", version: "2.244.0-alpha.0" };
    // ------------------------------------------------------
    // Static Constructors
    // ------------------------------------------------------
    /**
     * Defines an action group that allows your agent to request the user for
     * additional information when trying to complete a task.
     * @param enabled Specifies whether the action group is available for the agent
     */
    static userInput(enabled) {
        return new AgentActionGroup({
            name: 'UserInputAction',
            enabled: enabled,
            parentActionGroupSignature: ParentActionGroupSignature.USER_INPUT,
        });
    }
    /**
     * Defines an action group that allows your agent to request the user for
     * additional information when trying to complete a task.
     * @param enabled Specifies whether the action group is available for the agent
     */
    static codeInterpreter(enabled) {
        return new AgentActionGroup({
            name: 'CodeInterpreterAction',
            enabled: enabled,
            parentActionGroupSignature: ParentActionGroupSignature.CODE_INTERPRETER,
        });
    }
    // ------------------------------------------------------
    // Attributes
    // ------------------------------------------------------
    /**
     * The name of the action group.
     */
    name;
    /**
     * A description of the action group.
     */
    description;
    /**
     * Whether this action group is available for the agent to invoke or not.
     */
    enabled;
    /**
     * The api schema for this action group (if defined).
     */
    apiSchema;
    /**
     * The action group executor for this action group (if defined).
     */
    executor;
    /**
     * Whether to delete the resource even if it's in use.
     */
    forceDelete;
    /**
     * The function schema for this action group (if defined).
     */
    functionSchema;
    /**
     * The AWS Defined signature (if defined).
     */
    parentActionGroupSignature;
    constructor(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentActionGroupProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, AgentActionGroup);
            }
            throw error;
        }
        // Validate Props
        this.validateProps(props);
        // ------------------------------------------------------
        // Set attributes or defaults
        // ------------------------------------------------------
        this.name = props.name ?? `action_group_quick_start_${crypto.randomUUID()}`;
        this.description = props.description;
        this.apiSchema = props.apiSchema;
        this.executor = props.executor;
        this.enabled = props.enabled ?? true;
        this.forceDelete = props.forceDelete ?? false;
        this.functionSchema = props.functionSchema;
        this.parentActionGroupSignature = props.parentActionGroupSignature;
    }
    validateProps(props) {
        if (props.parentActionGroupSignature && (props.description || props.apiSchema || props.executor)) {
            throw new errors_1.UnscopedValidationError('ParentActionGroupSignatureConflict', 'When parentActionGroupSignature is specified, you must leave the description, ' +
                'apiSchema, and actionGroupExecutor fields blank for this action group');
        }
    }
    /**
     * Format as CFN properties
     *
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            actionGroupExecutor: this.executor?._render(),
            actionGroupName: this.name,
            actionGroupState: this.enabled ? 'ENABLED' : 'DISABLED',
            apiSchema: this.apiSchema?._render(),
            description: this.description,
            functionSchema: this.functionSchema?._render(),
            parentActionGroupSignature: this.parentActionGroupSignature?.toString(),
            skipResourceInUseCheckOnDelete: this.forceDelete,
        };
    }
}
exports.AgentActionGroup = AgentActionGroup;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWN0aW9uLWdyb3VwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYWN0aW9uLWdyb3VwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsaUNBQWlDO0FBRWpDLHdEQUFzRTtBQUt0RTs7K0VBRStFO0FBQy9FOztHQUVHO0FBQ0gsTUFBYSwwQkFBMEI7SUFnQm5COztJQWZsQjs7T0FFRztJQUNJLE1BQU0sQ0FBVSxVQUFVLEdBQUcsSUFBSSwwQkFBMEIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3ZGOztPQUVHO0lBQ0ksTUFBTSxDQUFVLGdCQUFnQixHQUFHLElBQUksMEJBQTBCLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUNuRzs7T0FFRztJQUNIO0lBQ0U7O09BRUc7SUFDYSxLQUFhO1FBQWIsVUFBSyxHQUFMLEtBQUssQ0FBUTtLQUMzQjtJQUVKOzs7T0FHRztJQUNJLFFBQVE7UUFDYixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUM7S0FDbkI7O0FBekJILGdFQTBCQztBQWlFRDs7K0VBRStFO0FBRS9FLE1BQWEsZ0JBQWdCOztJQUMzQix5REFBeUQ7SUFDekQsc0JBQXNCO0lBQ3RCLHlEQUF5RDtJQUN6RDs7OztPQUlHO0lBQ0ksTUFBTSxDQUFDLFNBQVMsQ0FBQyxPQUFnQjtRQUN0QyxPQUFPLElBQUksZ0JBQWdCLENBQUM7WUFDMUIsSUFBSSxFQUFFLGlCQUFpQjtZQUN2QixPQUFPLEVBQUUsT0FBTztZQUNoQiwwQkFBMEIsRUFBRSwwQkFBMEIsQ0FBQyxVQUFVO1NBQ2xFLENBQUMsQ0FBQztLQUNKO0lBRUQ7Ozs7T0FJRztJQUNJLE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBZ0I7UUFDNUMsT0FBTyxJQUFJLGdCQUFnQixDQUFDO1lBQzFCLElBQUksRUFBRSx1QkFBdUI7WUFDN0IsT0FBTyxFQUFFLE9BQU87WUFDaEIsMEJBQTBCLEVBQUUsMEJBQTBCLENBQUMsZ0JBQWdCO1NBQ3hFLENBQUMsQ0FBQztLQUNKO0lBRUQseURBQXlEO0lBQ3pELGFBQWE7SUFDYix5REFBeUQ7SUFDekQ7O09BRUc7SUFDYSxJQUFJLENBQVM7SUFDN0I7O09BRUc7SUFDYSxXQUFXLENBQVU7SUFDckM7O09BRUc7SUFDYSxPQUFPLENBQVU7SUFDakM7O09BRUc7SUFDYSxTQUFTLENBQWE7SUFDdEM7O09BRUc7SUFDYSxRQUFRLENBQXVCO0lBQy9DOztPQUVHO0lBQ2EsV0FBVyxDQUFXO0lBQ3RDOztPQUVHO0lBQ2EsY0FBYyxDQUFrQjtJQUNoRDs7T0FFRztJQUNhLDBCQUEwQixDQUE4QjtJQUV4RSxZQUFtQixLQUE0Qjs7Ozs7OytDQWxFcEMsZ0JBQWdCOzs7O1FBbUV6QixpQkFBaUI7UUFDakIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUUxQix5REFBeUQ7UUFDekQsNkJBQTZCO1FBQzdCLHlEQUF5RDtRQUN6RCxJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLElBQUksNEJBQTRCLE1BQU0sQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDO1FBQzVFLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQztRQUNyQyxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7UUFDakMsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDO1FBQy9CLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUM7UUFDckMsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsV0FBVyxJQUFJLEtBQUssQ0FBQztRQUM5QyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUM7UUFDM0MsSUFBSSxDQUFDLDBCQUEwQixHQUFHLEtBQUssQ0FBQywwQkFBMEIsQ0FBQztLQUNwRTtJQUVPLGFBQWEsQ0FBQyxLQUE0QjtRQUNoRCxJQUFJLEtBQUssQ0FBQywwQkFBMEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLElBQUksS0FBSyxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQztZQUNqRyxNQUFNLElBQUksZ0NBQXVCLENBQy9CLG9DQUFvQyxFQUNwQyxnRkFBZ0Y7Z0JBQzlFLHVFQUF1RSxDQUMxRSxDQUFDO1FBQ0osQ0FBQztLQUNGO0lBRUQ7Ozs7T0FJRztJQUNJLE9BQU87UUFDWixPQUFPO1lBQ0wsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLEVBQUU7WUFDN0MsZUFBZSxFQUFFLElBQUksQ0FBQyxJQUFJO1lBQzFCLGdCQUFnQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsVUFBVTtZQUN2RCxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUU7WUFDcEMsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXO1lBQzdCLGNBQWMsRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFLE9BQU8sRUFBRTtZQUM5QywwQkFBMEIsRUFBRSxJQUFJLENBQUMsMEJBQTBCLEVBQUUsUUFBUSxFQUFFO1lBQ3ZFLDhCQUE4QixFQUFFLElBQUksQ0FBQyxXQUFXO1NBQ2pELENBQUM7S0FDSDs7QUE3R0gsNENBOEdDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgY3J5cHRvIGZyb20gJ2NyeXB0byc7XG5pbXBvcnQgdHlwZSB7IENmbkFnZW50IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHsgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9lcnJvcnMnO1xuaW1wb3J0IHR5cGUgeyBBY3Rpb25Hcm91cEV4ZWN1dG9yIH0gZnJvbSAnLi9hcGktZXhlY3V0b3InO1xuaW1wb3J0IHR5cGUgeyBBcGlTY2hlbWEgfSBmcm9tICcuL2FwaS1zY2hlbWEnO1xuaW1wb3J0IHR5cGUgeyBGdW5jdGlvblNjaGVtYSB9IGZyb20gJy4vZnVuY3Rpb24tc2NoZW1hJztcblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgICBTaWduYXR1cmVzXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIEFXUyBEZWZpbmVkIHNpZ25hdHVyZXMgZm9yIGVuYWJsaW5nIGNlcnRhaW4gY2FwYWJpbGl0aWVzIGluIHlvdXIgYWdlbnQuXG4gKi9cbmV4cG9ydCBjbGFzcyBQYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZSB7XG4gIC8qKlxuICAgKiBTaWduYXR1cmUgdGhhdCBhbGxvd3MgeW91ciBhZ2VudCB0byByZXF1ZXN0IHRoZSB1c2VyIGZvciBhZGRpdGlvbmFsIGluZm9ybWF0aW9uIHdoZW4gdHJ5aW5nIHRvIGNvbXBsZXRlIGEgdGFzay5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgVVNFUl9JTlBVVCA9IG5ldyBQYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZSgnQU1BWk9OLlVzZXJJbnB1dCcpO1xuICAvKipcbiAgICogU2lnbmF0dXJlIHRoYXQgYWxsb3dzIHlvdXIgYWdlbnQgdG8gZ2VuZXJhdGUsIHJ1biwgYW5kIHRyb3VibGVzaG9vdCBjb2RlIHdoZW4gdHJ5aW5nIHRvIGNvbXBsZXRlIGEgdGFzay5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQ09ERV9JTlRFUlBSRVRFUiA9IG5ldyBQYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZSgnQU1BWk9OLkNvZGVJbnRlcnByZXRlcicpO1xuICAvKipcbiAgICogQ29uc3RydWN0b3Igc2hvdWxkIGJlIHVzZWQgYXMgYSB0ZW1wb3Jhcnkgc29sdXRpb24gd2hlbiBhIG5ldyBzaWduYXR1cmUgaXMgc3VwcG9ydGVkIGJ1dCBpdHMgaW1wbGVtZW50YXRpb24gaW4gQ0RLIGhhc24ndCBiZWVuIGFkZGVkIHlldC5cbiAgICovXG4gIGNvbnN0cnVjdG9yKFxuICAgIC8qKlxuICAgICAqIFRoZSBBV1MtZGVmaW5lZCBzaWduYXR1cmUgdmFsdWUgZm9yIHRoaXMgYWN0aW9uIGdyb3VwIGNhcGFiaWxpdHkuXG4gICAgICovXG4gICAgcHVibGljIHJlYWRvbmx5IHZhbHVlOiBzdHJpbmcsXG4gICkge31cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgc3RyaW5nIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBzaWduYXR1cmUgdmFsdWUuXG4gICAqIFVzZWQgd2hlbiBjb25maWd1cmluZyB0aGUgYWN0aW9uIGdyb3VwIGluIENsb3VkRm9ybWF0aW9uLlxuICAgKi9cbiAgcHVibGljIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiB0aGlzLnZhbHVlO1xuICB9XG59XG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICBQUk9QUyAtIEFjdGlvbiBHcm91cCBDbGFzc1xuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuZXhwb3J0IGludGVyZmFjZSBBZ2VudEFjdGlvbkdyb3VwUHJvcHMge1xuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIGFjdGlvbiBncm91cC5cbiAgICogQGRlZmF1bHQgLSBBIHVuaXF1ZSBuYW1lIGlzIGdlbmVyYXRlZCBpbiB0aGUgZm9ybWF0ICdhY3Rpb25fZ3JvdXBfcXVpY2tfc3RhcnRfVVVJRCdcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEEgZGVzY3JpcHRpb24gb2YgdGhlIGFjdGlvbiBncm91cC5cbiAgICpcbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8gZGVzY3JpcHRpb24gaXMgcHJvdmlkZWRcbiAgICovXG4gIHJlYWRvbmx5IGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgQVBJIFNjaGVtYSBkZWZpbmluZyB0aGUgZnVuY3Rpb25zIGF2YWlsYWJsZSB0byB0aGUgYWdlbnQuXG4gICAqXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIEFQSSBTY2hlbWEgaXMgcHJvdmlkZWRcbiAgICovXG4gIHJlYWRvbmx5IGFwaVNjaGVtYT86IEFwaVNjaGVtYTtcblxuICAvKipcbiAgICogVGhlIGFjdGlvbiBncm91cCBleGVjdXRvciB0aGF0IGltcGxlbWVudHMgdGhlIEFQSSBmdW5jdGlvbnMuXG4gICAqXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIGV4ZWN1dG9yIGlzIHByb3ZpZGVkXG4gICAqL1xuICByZWFkb25seSBleGVjdXRvcj86IEFjdGlvbkdyb3VwRXhlY3V0b3I7XG5cbiAgLyoqXG4gICAqIFNwZWNpZmllcyB3aGV0aGVyIHRoZSBhY3Rpb24gZ3JvdXAgaXMgYXZhaWxhYmxlIGZvciB0aGUgYWdlbnQgdG8gaW52b2tlIG9yXG4gICAqIG5vdCB3aGVuIHNlbmRpbmcgYW4gSW52b2tlQWdlbnQgcmVxdWVzdC5cbiAgICpcbiAgICogQGRlZmF1bHQgdHJ1ZSAtIFRoZSBhY3Rpb24gZ3JvdXAgaXMgZW5hYmxlZFxuICAgKi9cbiAgcmVhZG9ubHkgZW5hYmxlZD86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIFNwZWNpZmllcyB3aGV0aGVyIHRvIGRlbGV0ZSB0aGUgcmVzb3VyY2UgZXZlbiBpZiBpdCdzIGluIHVzZS5cbiAgICpcbiAgICogQGRlZmF1bHQgZmFsc2UgLSBUaGUgcmVzb3VyY2Ugd2lsbCBub3QgYmUgZGVsZXRlZCBpZiBpdCdzIGluIHVzZVxuICAgKi9cbiAgcmVhZG9ubHkgZm9yY2VEZWxldGU/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGZ1bmN0aW9ucyB0aGF0IGVhY2ggZGVmaW5lIHBhcmFtZXRlcnMgdGhhdCB0aGUgYWdlbnQgbmVlZHMgdG8gaW52b2tlIGZyb20gdGhlIHVzZXIuXG4gICAqIE5PIEwyIHlldCBhcyB0aGlzIGRvZXNuJ3QgbWFrZSBtdWNoIHNlbnNlIElNSE8uXG4gICAqXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIGZ1bmN0aW9uIHNjaGVtYSBpcyBwcm92aWRlZFxuICAgKi9cbiAgcmVhZG9ubHkgZnVuY3Rpb25TY2hlbWE/OiBGdW5jdGlvblNjaGVtYTtcblxuICAvKipcbiAgICogVGhlIEFXUyBEZWZpbmVkIHNpZ25hdHVyZSBmb3IgZW5hYmxpbmcgY2VydGFpbiBjYXBhYmlsaXRpZXMgaW4geW91ciBhZ2VudC5cbiAgICogV2hlbiB0aGlzIHByb3BlcnR5IGlzIHNwZWNpZmllZCwgeW91IG11c3QgbGVhdmUgdGhlIGRlc2NyaXB0aW9uLCBhcGlTY2hlbWEsXG4gICAqIGFuZCBhY3Rpb25Hcm91cEV4ZWN1dG9yIGZpZWxkcyBibGFuayBmb3IgdGhpcyBhY3Rpb24gZ3JvdXAuXG4gICAqXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIHBhcmVudCBhY3Rpb24gZ3JvdXAgc2lnbmF0dXJlIGlzIHByb3ZpZGVkXG4gICAqL1xuICByZWFkb25seSBwYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZT86IFBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlO1xufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICBERUYgLSBBY3Rpb24gR3JvdXAgQ2xhc3NcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cblxuZXhwb3J0IGNsYXNzIEFnZW50QWN0aW9uR3JvdXAge1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gU3RhdGljIENvbnN0cnVjdG9yc1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIERlZmluZXMgYW4gYWN0aW9uIGdyb3VwIHRoYXQgYWxsb3dzIHlvdXIgYWdlbnQgdG8gcmVxdWVzdCB0aGUgdXNlciBmb3JcbiAgICogYWRkaXRpb25hbCBpbmZvcm1hdGlvbiB3aGVuIHRyeWluZyB0byBjb21wbGV0ZSBhIHRhc2suXG4gICAqIEBwYXJhbSBlbmFibGVkIFNwZWNpZmllcyB3aGV0aGVyIHRoZSBhY3Rpb24gZ3JvdXAgaXMgYXZhaWxhYmxlIGZvciB0aGUgYWdlbnRcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgdXNlcklucHV0KGVuYWJsZWQ6IGJvb2xlYW4pOiBBZ2VudEFjdGlvbkdyb3VwIHtcbiAgICByZXR1cm4gbmV3IEFnZW50QWN0aW9uR3JvdXAoe1xuICAgICAgbmFtZTogJ1VzZXJJbnB1dEFjdGlvbicsXG4gICAgICBlbmFibGVkOiBlbmFibGVkLFxuICAgICAgcGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmU6IFBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlLlVTRVJfSU5QVVQsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogRGVmaW5lcyBhbiBhY3Rpb24gZ3JvdXAgdGhhdCBhbGxvd3MgeW91ciBhZ2VudCB0byByZXF1ZXN0IHRoZSB1c2VyIGZvclxuICAgKiBhZGRpdGlvbmFsIGluZm9ybWF0aW9uIHdoZW4gdHJ5aW5nIHRvIGNvbXBsZXRlIGEgdGFzay5cbiAgICogQHBhcmFtIGVuYWJsZWQgU3BlY2lmaWVzIHdoZXRoZXIgdGhlIGFjdGlvbiBncm91cCBpcyBhdmFpbGFibGUgZm9yIHRoZSBhZ2VudFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBjb2RlSW50ZXJwcmV0ZXIoZW5hYmxlZDogYm9vbGVhbik6IEFnZW50QWN0aW9uR3JvdXAge1xuICAgIHJldHVybiBuZXcgQWdlbnRBY3Rpb25Hcm91cCh7XG4gICAgICBuYW1lOiAnQ29kZUludGVycHJldGVyQWN0aW9uJyxcbiAgICAgIGVuYWJsZWQ6IGVuYWJsZWQsXG4gICAgICBwYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZTogUGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmUuQ09ERV9JTlRFUlBSRVRFUixcbiAgICB9KTtcbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBBdHRyaWJ1dGVzXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIGFjdGlvbiBncm91cC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBuYW1lOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBBIGRlc2NyaXB0aW9uIG9mIHRoZSBhY3Rpb24gZ3JvdXAuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoaXMgYWN0aW9uIGdyb3VwIGlzIGF2YWlsYWJsZSBmb3IgdGhlIGFnZW50IHRvIGludm9rZSBvciBub3QuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZW5hYmxlZDogYm9vbGVhbjtcbiAgLyoqXG4gICAqIFRoZSBhcGkgc2NoZW1hIGZvciB0aGlzIGFjdGlvbiBncm91cCAoaWYgZGVmaW5lZCkuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgYXBpU2NoZW1hPzogQXBpU2NoZW1hO1xuICAvKipcbiAgICogVGhlIGFjdGlvbiBncm91cCBleGVjdXRvciBmb3IgdGhpcyBhY3Rpb24gZ3JvdXAgKGlmIGRlZmluZWQpLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGV4ZWN1dG9yPzogQWN0aW9uR3JvdXBFeGVjdXRvcjtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdG8gZGVsZXRlIHRoZSByZXNvdXJjZSBldmVuIGlmIGl0J3MgaW4gdXNlLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGZvcmNlRGVsZXRlPzogYm9vbGVhbjtcbiAgLyoqXG4gICAqIFRoZSBmdW5jdGlvbiBzY2hlbWEgZm9yIHRoaXMgYWN0aW9uIGdyb3VwIChpZiBkZWZpbmVkKS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBmdW5jdGlvblNjaGVtYT86IEZ1bmN0aW9uU2NoZW1hO1xuICAvKipcbiAgICogVGhlIEFXUyBEZWZpbmVkIHNpZ25hdHVyZSAoaWYgZGVmaW5lZCkuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgcGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmU/OiBQYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZTtcblxuICBwdWJsaWMgY29uc3RydWN0b3IocHJvcHM6IEFnZW50QWN0aW9uR3JvdXBQcm9wcykge1xuICAgIC8vIFZhbGlkYXRlIFByb3BzXG4gICAgdGhpcy52YWxpZGF0ZVByb3BzKHByb3BzKTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIFNldCBhdHRyaWJ1dGVzIG9yIGRlZmF1bHRzXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy5uYW1lID0gcHJvcHMubmFtZSA/PyBgYWN0aW9uX2dyb3VwX3F1aWNrX3N0YXJ0XyR7Y3J5cHRvLnJhbmRvbVVVSUQoKX1gO1xuICAgIHRoaXMuZGVzY3JpcHRpb24gPSBwcm9wcy5kZXNjcmlwdGlvbjtcbiAgICB0aGlzLmFwaVNjaGVtYSA9IHByb3BzLmFwaVNjaGVtYTtcbiAgICB0aGlzLmV4ZWN1dG9yID0gcHJvcHMuZXhlY3V0b3I7XG4gICAgdGhpcy5lbmFibGVkID0gcHJvcHMuZW5hYmxlZCA/PyB0cnVlO1xuICAgIHRoaXMuZm9yY2VEZWxldGUgPSBwcm9wcy5mb3JjZURlbGV0ZSA/PyBmYWxzZTtcbiAgICB0aGlzLmZ1bmN0aW9uU2NoZW1hID0gcHJvcHMuZnVuY3Rpb25TY2hlbWE7XG4gICAgdGhpcy5wYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZSA9IHByb3BzLnBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlO1xuICB9XG5cbiAgcHJpdmF0ZSB2YWxpZGF0ZVByb3BzKHByb3BzOiBBZ2VudEFjdGlvbkdyb3VwUHJvcHMpIHtcbiAgICBpZiAocHJvcHMucGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmUgJiYgKHByb3BzLmRlc2NyaXB0aW9uIHx8IHByb3BzLmFwaVNjaGVtYSB8fCBwcm9wcy5leGVjdXRvcikpIHtcbiAgICAgIHRocm93IG5ldyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvcihcbiAgICAgICAgJ1BhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlQ29uZmxpY3QnLFxuICAgICAgICAnV2hlbiBwYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZSBpcyBzcGVjaWZpZWQsIHlvdSBtdXN0IGxlYXZlIHRoZSBkZXNjcmlwdGlvbiwgJyArXG4gICAgICAgICAgJ2FwaVNjaGVtYSwgYW5kIGFjdGlvbkdyb3VwRXhlY3V0b3IgZmllbGRzIGJsYW5rIGZvciB0aGlzIGFjdGlvbiBncm91cCcsXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBGb3JtYXQgYXMgQ0ZOIHByb3BlcnRpZXNcbiAgICpcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBDZm5BZ2VudC5BZ2VudEFjdGlvbkdyb3VwUHJvcGVydHkge1xuICAgIHJldHVybiB7XG4gICAgICBhY3Rpb25Hcm91cEV4ZWN1dG9yOiB0aGlzLmV4ZWN1dG9yPy5fcmVuZGVyKCksXG4gICAgICBhY3Rpb25Hcm91cE5hbWU6IHRoaXMubmFtZSxcbiAgICAgIGFjdGlvbkdyb3VwU3RhdGU6IHRoaXMuZW5hYmxlZCA/ICdFTkFCTEVEJyA6ICdESVNBQkxFRCcsXG4gICAgICBhcGlTY2hlbWE6IHRoaXMuYXBpU2NoZW1hPy5fcmVuZGVyKCksXG4gICAgICBkZXNjcmlwdGlvbjogdGhpcy5kZXNjcmlwdGlvbixcbiAgICAgIGZ1bmN0aW9uU2NoZW1hOiB0aGlzLmZ1bmN0aW9uU2NoZW1hPy5fcmVuZGVyKCksXG4gICAgICBwYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZTogdGhpcy5wYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZT8udG9TdHJpbmcoKSxcbiAgICAgIHNraXBSZXNvdXJjZUluVXNlQ2hlY2tPbkRlbGV0ZTogdGhpcy5mb3JjZURlbGV0ZSxcbiAgICB9O1xuICB9XG59XG4iXX0=