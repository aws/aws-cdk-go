"use strict";
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Agent = exports.AgentBase = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const crypto = require("crypto");
const bedrock = require("aws-cdk-lib/aws-bedrock");
const cloudwatch = require("aws-cdk-lib/aws-cloudwatch");
const events = require("aws-cdk-lib/aws-events");
const iam = require("aws-cdk-lib/aws-iam");
const kms = require("aws-cdk-lib/aws-kms");
const s3 = require("aws-cdk-lib/aws-s3");
const core_1 = require("aws-cdk-lib/core");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
// Internal Libs
const action_group_1 = require("./action-group");
const agent_alias_1 = require("./agent-alias");
const api_schema_1 = require("./api-schema");
const orchestration_executor_1 = require("./orchestration-executor");
const validation = require("./validation-helpers");
/******************************************************************************
 *                              CONSTANTS
 *****************************************************************************/
/**
 * The minimum number of characters required for an agent instruction.
 * @internal
 */
const MIN_INSTRUCTION_LENGTH = 40;
/**
 * The maximum length for the node address in permission policy names.
 * @internal
 */
const MAX_POLICY_NAME_NODE_LENGTH = 16;
/******************************************************************************
 *                        ABSTRACT BASE CLASS
 *****************************************************************************/
/**
 * Abstract base class for an Agent.
 * Contains methods and attributes valid for Agents either created with CDK or imported.
 */
class AgentBase extends core_1.Resource {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AgentBase", version: "2.244.0-alpha.0" };
    /**
     * Grant invoke permissions on this agent to an IAM principal.
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant invoke permissions to
     * @default - Default grant configuration:
     * - actions: ['bedrock:InvokeAgent']
     * - resourceArns: [this.agentArn]
     * @returns An IAM Grant object representing the granted permissions
     */
    grantInvoke(grantee) {
        return iam.Grant.addToPrincipal({
            grantee,
            actions: ['bedrock:InvokeAgent'],
            resourceArns: [this.agentArn],
        });
    }
    /**
     * Creates an EventBridge rule for agent events.
     *
     * @param id - Unique identifier for the rule
     * @param options - Configuration options for the event rule
     * @default - Default event pattern:
     * - source: ['aws.bedrock']
     * - detail: { 'agent-id': [this.agentId] }
     * @returns An EventBridge Rule configured for agent events
     */
    onEvent(id, options = {}) {
        const rule = new events.Rule(this, id, options);
        rule.addEventPattern({
            source: ['aws.bedrock'],
            detail: {
                'agent-id': [this.agentId],
            },
        });
        rule.addTarget(options.target);
        return rule;
    }
    /**
     * Creates a CloudWatch metric for tracking agent invocations.
     *
     * @param props - Configuration options for the metric
     * @default - Default metric configuration:
     * - namespace: 'AWS/Bedrock'
     * - metricName: 'Invocations'
     * - dimensionsMap: { AgentId: this.agentId }
     * @returns A CloudWatch Metric configured for agent invocation counts
     */
    metricCount(props) {
        return new cloudwatch.Metric({
            namespace: 'AWS/Bedrock',
            metricName: 'Invocations',
            dimensionsMap: {
                AgentId: this.agentId,
            },
            ...props,
        }).attachTo(this);
    }
}
exports.AgentBase = AgentBase;
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create (or import) an Agent with CDK.
 * @cloudformationResource AWS::Bedrock::Agent
 */
let Agent = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = AgentBase;
    let _instanceExtraInitializers = [];
    let _addGuardrail_decorators;
    let _addActionGroup_decorators;
    let _addActionGroups_decorators;
    var Agent = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _addGuardrail_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addActionGroup_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addActionGroups_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            __esDecorate(this, null, _addGuardrail_decorators, { kind: "method", name: "addGuardrail", static: false, private: false, access: { has: obj => "addGuardrail" in obj, get: obj => obj.addGuardrail }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addActionGroup_decorators, { kind: "method", name: "addActionGroup", static: false, private: false, access: { has: obj => "addActionGroup" in obj, get: obj => obj.addActionGroup }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addActionGroups_decorators, { kind: "method", name: "addActionGroups", static: false, private: false, access: { has: obj => "addActionGroups" in obj, get: obj => obj.addActionGroups }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            Agent = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.Agent", version: "2.244.0-alpha.0" };
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.Agent';
        /**
         * Static Method for importing an existing Bedrock Agent.
         */
        /**
         * Creates an Agent reference from an existing agent's attributes.
         *
         * @param scope - The construct scope
         * @param id - Identifier of the construct
         * @param attrs - Attributes of the existing agent
         * @default - For attrs.agentVersion: 'DRAFT' if no explicit version is provided
         * @returns An IAgent reference to the existing agent
         */
        static fromAgentAttributes(scope, id, attrs) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentAttributes(attrs);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.fromAgentAttributes);
                }
                throw error;
            }
            class Import extends AgentBase {
                agentArn = attrs.agentArn;
                agentId = core_1.Arn.split(attrs.agentArn, core_1.ArnFormat.SLASH_RESOURCE_NAME).resourceName;
                role = iam.Role.fromRoleArn(scope, `${id}Role`, attrs.roleArn);
                kmsKey = attrs.kmsKeyArn ? kms.Key.fromKeyArn(scope, `${id}Key`, attrs.kmsKeyArn) : undefined;
                lastUpdated = attrs.lastUpdated;
                agentVersion = attrs.agentVersion ?? 'DRAFT';
                grantPrincipal = this.role;
            }
            // Return new Agent
            return new Import(scope, id);
        }
        // ------------------------------------------------------
        // Base attributes
        // ------------------------------------------------------
        /**
         * The unique identifier for the agent
         * @attribute
         */
        agentId = __runInitializers(this, _instanceExtraInitializers);
        /**
         * The ARN of the agent.
         * @attribute
         */
        agentArn;
        /**
         * The version of the agent.
         * @attribute
         */
        agentVersion;
        /**
         * The IAM role associated to the agent.
         */
        role;
        /**
         * Optional KMS encryption key associated with this agent
         */
        kmsKey;
        /**
         * When this agent was last updated.
         */
        lastUpdated;
        /**
         * The principal to grant permissions to
         */
        grantPrincipal;
        /**
         * Default alias of the agent
         */
        testAlias;
        /**
         * action groups associated with the ageny
         */
        actionGroups = [];
        /**
         * The guardrail that will be associated with the agent.
         */
        guardrail;
        // ------------------------------------------------------
        // CDK-only attributes
        // ------------------------------------------------------
        /**
         * The name of the agent.
         */
        name;
        // ------------------------------------------------------
        // Internal Only
        // ------------------------------------------------------
        ROLE_NAME_SUFFIX = '-bedrockagent';
        MAXLENGTH_FOR_ROLE_NAME = 64;
        idleSessionTTL;
        foundationModel;
        userInputEnabled;
        codeInterpreterEnabled;
        agentCollaboration;
        customOrchestrationExecutor;
        promptOverrideConfiguration;
        __resource;
        // ------------------------------------------------------
        // CONSTRUCTOR
        // ------------------------------------------------------
        constructor(scope, id, props) {
            super(scope, id);
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentProps(props);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, Agent);
                }
                throw error;
            }
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            // ------------------------------------------------------
            // Validate props
            // ------------------------------------------------------
            if (props.instruction !== undefined &&
                !core_1.Token.isUnresolved(props.instruction) &&
                props.instruction.length < MIN_INSTRUCTION_LENGTH) {
                throw new core_1.ValidationError('InstructionTooShort', `instruction must be at least ${MIN_INSTRUCTION_LENGTH} characters`, this);
            }
            // Validate idleSessionTTL
            if (props.idleSessionTTL !== undefined &&
                !core_1.Token.isUnresolved(props.idleSessionTTL) &&
                (props.idleSessionTTL.toMinutes() < 1 || props.idleSessionTTL.toMinutes() > 60)) {
                throw new core_1.ValidationError('IdleSessionTtlOutOfRange', 'idleSessionTTL must be between 1 and 60 minutes', this);
            }
            // ------------------------------------------------------
            // Set properties and defaults
            // ------------------------------------------------------
            this.name =
                props.agentName ?? this.generatePhysicalName() + this.ROLE_NAME_SUFFIX;
            this.idleSessionTTL = props.idleSessionTTL ?? core_1.Duration.minutes(10);
            this.userInputEnabled = props.userInputEnabled ?? false;
            this.codeInterpreterEnabled = props.codeInterpreterEnabled ?? false;
            this.foundationModel = props.foundationModel;
            // Optional
            this.promptOverrideConfiguration = props.promptOverrideConfiguration;
            this.kmsKey = props.kmsKey;
            this.customOrchestrationExecutor = props.customOrchestrationExecutor;
            // ------------------------------------------------------
            // Role
            // ------------------------------------------------------
            // If existing role is provided, use it.
            if (props.existingRole) {
                this.role = props.existingRole;
                this.grantPrincipal = this.role;
                // Otherwise, create a new one
            }
            else {
                this.role = new iam.Role(this, 'Role', {
                    // generate a role name
                    roleName: this.generatePhysicalName() + this.ROLE_NAME_SUFFIX,
                    // ensure the role has a trust policy that allows the Bedrock service to assume the role
                    assumedBy: new iam.ServicePrincipal('bedrock.amazonaws.com').withConditions({
                        StringEquals: {
                            'aws:SourceAccount': { Ref: 'AWS::AccountId' },
                        },
                        ArnLike: {
                            'aws:SourceArn': core_1.Stack.of(this).formatArn({
                                service: 'bedrock',
                                resource: 'agent',
                                resourceName: '*',
                                arnFormat: core_1.ArnFormat.SLASH_RESOURCE_NAME,
                            }),
                        },
                    }),
                });
                this.grantPrincipal = this.role;
            }
            // ------------------------------------------------------
            // Set Lazy Props initial values
            // ------------------------------------------------------
            // Add Default Action Groups
            this.addActionGroup(action_group_1.AgentActionGroup.userInput(this.userInputEnabled));
            this.addActionGroup(action_group_1.AgentActionGroup.codeInterpreter(this.codeInterpreterEnabled));
            // Add specified elems through methods to handle permissions
            // this needs to happen after role creation / assignment
            props.actionGroups?.forEach(ag => {
                this.addActionGroup(ag);
            });
            // Set agent collaboration configuration
            this.agentCollaboration = props.agentCollaboration;
            if (props.agentCollaboration) {
                props.agentCollaboration.collaborators.forEach(ac => {
                    this.grantPermissionToAgent(ac);
                });
            }
            if (props.guardrail) {
                this.addGuardrail(props.guardrail);
            }
            // Grant permissions for custom orchestration if provided
            if (this.customOrchestrationExecutor?.lambdaFunction) {
                this.customOrchestrationExecutor.lambdaFunction.grantInvoke(this.role);
                this.customOrchestrationExecutor.lambdaFunction.addPermission(`OrchestrationLambdaInvocationPolicy-${this.node.addr.slice(0, MAX_POLICY_NAME_NODE_LENGTH)}`, {
                    principal: new iam.ServicePrincipal('bedrock.amazonaws.com'),
                    sourceArn: core_1.Lazy.string({ produce: () => this.agentArn }),
                    sourceAccount: { Ref: 'AWS::AccountId' },
                });
            }
            // ------------------------------------------------------
            // CFN Props - With Lazy support
            // ------------------------------------------------------
            const cfnProps = {
                actionGroups: core_1.Lazy.any({ produce: () => this.renderActionGroups() }, { omitEmptyArray: true }),
                agentName: this.name,
                agentResourceRoleArn: this.role.roleArn,
                autoPrepare: props.shouldPrepareAgent ?? false,
                customerEncryptionKeyArn: props.kmsKey?.keyArn,
                description: props.description,
                foundationModel: this.foundationModel.invokableArn,
                guardrailConfiguration: core_1.Lazy.any({ produce: () => this.renderGuardrail() }),
                idleSessionTtlInSeconds: this.idleSessionTTL.toSeconds(),
                instruction: props.instruction,
                memoryConfiguration: props.memory?._render(),
                promptOverrideConfiguration: this.promptOverrideConfiguration?._render(),
                skipResourceInUseCheckOnDelete: props.forceDelete ?? false,
                agentCollaboration: props.agentCollaboration?.type,
                agentCollaborators: core_1.Lazy.any({ produce: () => this.renderAgentCollaborators() }, { omitEmptyArray: true }),
                customOrchestration: this.renderCustomOrchestration(),
                orchestrationType: this.customOrchestrationExecutor ? orchestration_executor_1.OrchestrationType.CUSTOM_ORCHESTRATION : orchestration_executor_1.OrchestrationType.DEFAULT,
            };
            // ------------------------------------------------------
            // L1 Instantiation
            // ------------------------------------------------------
            this.__resource = new bedrock.CfnAgent(this, 'Resource', cfnProps);
            this.agentId = this.__resource.attrAgentId;
            this.agentArn = this.__resource.attrAgentArn;
            this.agentVersion = this.__resource.attrAgentVersion;
            this.lastUpdated = this.__resource.attrUpdatedAt;
            // Add explicit dependency between the agent resource and the agent's role default policy
            // See https://github.com/awslabs/generative-ai-cdk-constructs/issues/899
            const grant = this.foundationModel.grantInvoke(this.role);
            grant.applyBefore(this.__resource);
            this.testAlias = agent_alias_1.AgentAlias.fromAttributes(this, 'DefaultAlias', {
                aliasId: 'TSTALIASID',
                aliasName: 'AgentTestAlias',
                agentVersion: 'DRAFT',
                agent: this,
            });
        }
        // ------------------------------------------------------
        // HELPER METHODS - addX()
        // ------------------------------------------------------
        /**
         * Add guardrail to the agent.
         */
        addGuardrail(guardrail) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_IGuardrail(guardrail);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addGuardrail);
                }
                throw error;
            }
            // Do some checks
            validation.throwIfInvalid(this.validateGuardrail, guardrail);
            // Add it to the construct
            this.guardrail = guardrail;
            // Handle permissions
            guardrail.grantApply(this.role);
        }
        /**
         * Adds an action group to the agent and configures necessary permissions.
         *
         * @param actionGroup - The action group to add
         * @default - Default permissions:
         * - Lambda function invoke permissions if executor is present
         * - S3 GetObject permissions if apiSchema.s3File is present
         */
        addActionGroup(actionGroup) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentActionGroup(actionGroup);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addActionGroup);
                }
                throw error;
            }
            validation.throwIfInvalid(this.validateActionGroup, actionGroup);
            this.actionGroups.push(actionGroup);
            // Handle permissions to invoke the lambda function
            actionGroup.executor?.lambdaFunction?.grantInvoke(this.role);
            actionGroup.executor?.lambdaFunction?.addPermission(`LambdaInvocationPolicy-${this.node.addr.slice(0, MAX_POLICY_NAME_NODE_LENGTH)}`, {
                principal: new iam.ServicePrincipal('bedrock.amazonaws.com'),
                sourceArn: this.agentArn,
                sourceAccount: { Ref: 'AWS::AccountId' },
            });
            // Handle permissions to access the schema file from S3
            if (actionGroup.apiSchema instanceof api_schema_1.AssetApiSchema) {
                const rendered = actionGroup.apiSchema._render();
                if (!('s3' in rendered) || !rendered.s3) {
                    throw new core_1.ValidationError('S3ConfigMissing', 'S3 configuration is missing in AssetApiSchema', this);
                }
                const s3Config = rendered.s3;
                if (!('s3BucketName' in s3Config) || !('s3ObjectKey' in s3Config)) {
                    throw new core_1.ValidationError('S3BucketOrKeyMissing', 'S3 bucket name and object key are required in AssetApiSchema', this);
                }
                const bucketName = s3Config.s3BucketName;
                const objectKey = s3Config.s3ObjectKey;
                if (!bucketName || bucketName.trim() === '') {
                    throw new core_1.ValidationError('S3BucketNameEmpty', 'S3 bucket name cannot be empty in AssetApiSchema', this);
                }
                if (!objectKey || objectKey.trim() === '') {
                    throw new core_1.ValidationError('S3ObjectKeyEmpty', 'S3 object key cannot be empty in AssetApiSchema', this);
                }
                const bucket = s3.Bucket.fromBucketName(this, `${actionGroup.name}SchemaBucket`, bucketName);
                bucket.grantRead(this.role, objectKey);
            }
            else if (actionGroup.apiSchema instanceof api_schema_1.S3ApiSchema) {
                const s3File = actionGroup.apiSchema.s3File;
                if (!s3File) {
                    throw new core_1.ValidationError('S3FileMissing', 'S3 file configuration is missing in S3ApiSchema', this);
                }
                if (!s3File.bucketName || s3File.bucketName.trim() === '') {
                    throw new core_1.ValidationError('S3BucketNameEmpty', 'S3 bucket name cannot be empty in S3ApiSchema', this);
                }
                if (!s3File.objectKey || s3File.objectKey.trim() === '') {
                    throw new core_1.ValidationError('S3ObjectKeyEmpty', 'S3 object key cannot be empty in S3ApiSchema', this);
                }
                const bucket = s3.Bucket.fromBucketName(this, `${actionGroup.name}SchemaBucket`, s3File.bucketName);
                bucket.grantRead(this.role, s3File.objectKey);
            }
        }
        /**
         * Grants permissions for an agent collaborator to this agent's role.
         * This method only grants IAM permissions and does not add the collaborator
         * to the agent's collaboration configuration. To add collaborators to the
         * agent configuration, include them in the AgentCollaboration when creating the agent.
         *
         * @param agentCollaborator - The collaborator to grant permissions for
         */
        grantPermissionToAgent(agentCollaborator) {
            agentCollaborator.grant(this.role);
        }
        /**
         * Configuration for agent collaboration.
         *
         * @default - No collaboration configuration.
         */
        addActionGroups(...actionGroups) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentActionGroup(actionGroups);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addActionGroups);
                }
                throw error;
            }
            actionGroups.forEach(ag => this.addActionGroup(ag));
        }
        // ------------------------------------------------------
        // Lazy Renderers
        // ------------------------------------------------------
        /**
         * Render the guardrail configuration.
         *
         * @internal This is an internal core function and should not be called directly.
         */
        renderGuardrail() {
            return this.guardrail
                ? {
                    guardrailIdentifier: this.guardrail.guardrailId,
                    guardrailVersion: this.guardrail.guardrailVersion,
                }
                : undefined;
        }
        /**
         * Render the action groups
         *
         * @returns Array of AgentActionGroupProperty objects in CloudFormation format
         * @default - Empty array if no action groups are defined
         * @internal This is an internal core function and should not be called directly.
         */
        renderActionGroups() {
            const actionGroupsCfn = [];
            // Build the associations in the CFN format
            this.actionGroups.forEach(ag => {
                actionGroupsCfn.push(ag._render());
            });
            return actionGroupsCfn;
        }
        /**
         * Render the agent collaborators.
         *
         * @returns Array of AgentCollaboratorProperty objects in CloudFormation format, or undefined if no collaborators
         * @default - undefined if no collaborators are defined or array is empty
         * @internal This is an internal core function and should not be called directly.
         */
        renderAgentCollaborators() {
            if (!this.agentCollaboration || !this.agentCollaboration.collaborators || this.agentCollaboration.collaborators.length === 0) {
                return undefined;
            }
            return this.agentCollaboration.collaborators.map(ac => ac._render());
        }
        /**
         * Render the custom orchestration.
         *
         * @returns CustomOrchestrationProperty object in CloudFormation format, or undefined if no custom orchestration
         * @default - undefined if no custom orchestration is defined
         * @internal This is an internal core function and should not be called directly.
         */
        renderCustomOrchestration() {
            if (!this.customOrchestrationExecutor) {
                return undefined;
            }
            return {
                executor: {
                    lambda: this.customOrchestrationExecutor.lambdaFunction.functionArn,
                },
            };
        }
        // ------------------------------------------------------
        // Validators
        // ------------------------------------------------------
        /**
         * Checks if the Guardrail is valid
         *
         * @param guardrail - The guardrail to validate
         * @returns Array of validation error messages, empty if valid
         */
        validateGuardrail = (guardrail) => {
            let errors = [];
            if (this.guardrail) {
                errors.push(`Cannot add Guardrail ${guardrail.guardrailId}. ` +
                    `Guardrail ${this.guardrail.guardrailId} has already been specified for this agent.`);
            }
            errors.push(...validation.validateFieldPattern(guardrail.guardrailVersion, 'version', /^(([0-9]{1,8})|(DRAFT))$/));
            return errors;
        };
        /**
         * Check if the action group is valid
         *
         * @param actionGroup - The action group to validate
         * @returns Array of validation error messages, empty if valid
         */
        validateActionGroup = (actionGroup) => {
            let errors = [];
            // Find if there is a conflicting action group name
            if (this.actionGroups?.find(ag => ag.name === actionGroup.name)) {
                errors.push('Action group already exists');
            }
            return errors;
        };
        /**
         * Generates a unique, deterministic name for AWS resources that includes a hash component.
         * This method ensures consistent naming while avoiding conflicts and adhering to AWS naming constraints.
         * @param scope - The construct scope used for generating unique names
         * @param prefix - The prefix to prepend to the generated name
         * @param options - Configuration options for name generation
         * @param options.maxLength - Maximum length of the generated name
         * @default - maxLength: 256
         * @param options.lower - Convert the generated name to lowercase
         * @default - lower: false
         * @param options.separator - Character(s) to use between name components
         * @default - separator: ''
         * @param options.allowedSpecialCharacters - String of allowed special characters
         * @default - undefined
         * @param options.destroyCreate - Object to include in hash generation for destroy/create operations
         * @default - undefined
         * @returns A string containing the generated name with format: prefix + hash + separator + uniqueName
         * @throws ValidationError if the generated name would exceed maxLength or if prefix is too long
         * @internal
         */
        generatePhysicalNameHash(scope, prefix, options) {
            const objectToHash = (obj) => {
                if (obj === undefined) {
                    return '';
                }
                const jsonString = JSON.stringify(obj);
                const hash = crypto.createHash('sha256');
                return hash.update(jsonString).digest('hex').slice(0, 7);
            };
            const { maxLength = 256, lower = false, separator = '', allowedSpecialCharacters = undefined, destroyCreate = undefined, } = options ?? {};
            const hash = objectToHash(destroyCreate);
            if (maxLength < (prefix + hash + separator).length) {
                throw new core_1.ValidationError('PrefixTooLong', 'The prefix is longer than the maximum length.', this);
            }
            const uniqueName = core_1.Names.uniqueResourceName(scope, { maxLength: maxLength - (prefix + hash + separator).length, separator, allowedSpecialCharacters });
            const name = `${prefix}${hash}${separator}${uniqueName}`;
            if (name.length > maxLength) {
                throw new core_1.ValidationError('GeneratedNameTooLong', `The generated name is longer than the maximum length of ${maxLength}`, this);
            }
            return lower ? name.toLowerCase() : name;
        }
        /**
         * Generates a physical name for the agent.
         * @returns A unique name for the agent with appropriate length constraints
         * @default - Generated name format: 'agent-{hash}-{uniqueName}' with:
         * - maxLength: MAXLENGTH_FOR_ROLE_NAME - '-bedrockagent'.length
         * - lower: true
         * - separator: '-'
         * @protected
         */
        generatePhysicalName() {
            const maxLength = this.MAXLENGTH_FOR_ROLE_NAME - this.ROLE_NAME_SUFFIX.length;
            return this.generatePhysicalNameHash(this, 'agent', {
                maxLength,
                lower: true,
                separator: '-',
            });
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return Agent = _classThis;
})();
exports.Agent = Agent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWdlbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhZ2VudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxpQ0FBaUM7QUFDakMsbURBQW1EO0FBQ25ELHlEQUF5RDtBQUN6RCxpREFBaUQ7QUFDakQsMkNBQTJDO0FBQzNDLDJDQUEyQztBQUMzQyx5Q0FBeUM7QUFFekMsMkNBQWtIO0FBQ2xILDhFQUE4RjtBQUM5RiwwRUFBMEU7QUFFMUUsZ0JBQWdCO0FBQ2hCLGlEQUFrRDtBQUVsRCwrQ0FBMkM7QUFHM0MsNkNBQTJEO0FBRzNELHFFQUE2RDtBQUU3RCxtREFBbUQ7QUFJbkQ7OytFQUUrRTtBQUMvRTs7O0dBR0c7QUFDSCxNQUFNLHNCQUFzQixHQUFHLEVBQUUsQ0FBQztBQUVsQzs7O0dBR0c7QUFDSCxNQUFNLDJCQUEyQixHQUFHLEVBQUUsQ0FBQztBQWtEdkM7OytFQUUrRTtBQUMvRTs7O0dBR0c7QUFDSCxNQUFzQixTQUFVLFNBQVEsZUFBUTs7SUFhOUM7Ozs7Ozs7OztPQVNHO0lBQ0ksV0FBVyxDQUFDLE9BQXVCO1FBQ3hDLE9BQU8sR0FBRyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUM7WUFDOUIsT0FBTztZQUNQLE9BQU8sRUFBRSxDQUFDLHFCQUFxQixDQUFDO1lBQ2hDLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7U0FDOUIsQ0FBQyxDQUFDO0tBQ0o7SUFFRDs7Ozs7Ozs7O09BU0c7SUFDSSxPQUFPLENBQUMsRUFBVSxFQUFFLFVBQWlDLEVBQUU7UUFDNUQsTUFBTSxJQUFJLEdBQUcsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLGVBQWUsQ0FBQztZQUNuQixNQUFNLEVBQUUsQ0FBQyxhQUFhLENBQUM7WUFDdkIsTUFBTSxFQUFFO2dCQUNOLFVBQVUsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7YUFDM0I7U0FDRixDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMvQixPQUFPLElBQUksQ0FBQztLQUNiO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0ksV0FBVyxDQUFDLEtBQWdDO1FBQ2pELE9BQU8sSUFBSSxVQUFVLENBQUMsTUFBTSxDQUFDO1lBQzNCLFNBQVMsRUFBRSxhQUFhO1lBQ3hCLFVBQVUsRUFBRSxhQUFhO1lBQ3pCLGFBQWEsRUFBRTtnQkFDYixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87YUFDdEI7WUFDRCxHQUFHLEtBQUs7U0FDVCxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ25COztBQXpFSCw4QkEwRUM7QUFpS0Q7OytFQUUrRTtBQUMvRTs7O0dBR0c7SUFFVSxLQUFLOzRCQURqQixvQ0FBa0I7Ozs7c0JBQ1EsU0FBUzs7Ozs7cUJBQWpCLFNBQVEsV0FBUzs7Ozt3Q0E2UGpDLElBQUEsa0NBQWMsR0FBRTswQ0FrQmhCLElBQUEsa0NBQWMsR0FBRTsyQ0FnRWhCLElBQUEsa0NBQWMsR0FBRTtZQWpGakIsdUxBQU8sWUFBWSw2REFPbEI7WUFXRCw2TEFBTyxjQUFjLDZEQTRDcEI7WUFvQkQsZ01BQU8sZUFBZSw2REFFckI7WUFsVkgsNktBMmdCQzs7Ozs7UUExZ0JDLHNDQUFzQztRQUMvQixNQUFNLENBQVUscUJBQXFCLEdBQVcsa0NBQWtDLENBQUM7UUFFMUY7O1dBRUc7UUFDSDs7Ozs7Ozs7V0FRRztRQUNJLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxLQUFnQixFQUFFLEVBQVUsRUFBRSxLQUFzQjs7Ozs7Ozs7OztZQUNwRixNQUFNLE1BQU8sU0FBUSxTQUFTO2dCQUNaLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDO2dCQUMxQixPQUFPLEdBQUcsVUFBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLGdCQUFTLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxZQUFhLENBQUM7Z0JBQ2pGLElBQUksR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQy9ELE1BQU0sR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztnQkFDOUYsV0FBVyxHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUM7Z0JBQ2hDLFlBQVksR0FBRyxLQUFLLENBQUMsWUFBWSxJQUFJLE9BQU8sQ0FBQztnQkFDN0MsY0FBYyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDNUM7WUFFRCxtQkFBbUI7WUFDbkIsT0FBTyxJQUFJLE1BQU0sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDOUI7UUFDRCx5REFBeUQ7UUFDekQsa0JBQWtCO1FBQ2xCLHlEQUF5RDtRQUN6RDs7O1dBR0c7UUFDYSxPQUFPLEdBckNaLG1EQUFLLENBcUNnQjtRQUNoQzs7O1dBR0c7UUFDYSxRQUFRLENBQVM7UUFDakM7OztXQUdHO1FBQ2EsWUFBWSxDQUFTO1FBQ3JDOztXQUVHO1FBQ2EsSUFBSSxDQUFZO1FBQ2hDOztXQUVHO1FBQ2EsTUFBTSxDQUFZO1FBQ2xDOztXQUVHO1FBQ2EsV0FBVyxDQUFVO1FBQ3JDOztXQUVHO1FBQ2EsY0FBYyxDQUFpQjtRQUMvQzs7V0FFRztRQUNhLFNBQVMsQ0FBYztRQUN2Qzs7V0FFRztRQUNhLFlBQVksR0FBdUIsRUFBRSxDQUFDO1FBQ3REOztXQUVHO1FBQ0ksU0FBUyxDQUFjO1FBQzlCLHlEQUF5RDtRQUN6RCxzQkFBc0I7UUFDdEIseURBQXlEO1FBQ3pEOztXQUVHO1FBQ2EsSUFBSSxDQUFTO1FBRTdCLHlEQUF5RDtRQUN6RCxnQkFBZ0I7UUFDaEIseURBQXlEO1FBQ3hDLGdCQUFnQixHQUFHLGVBQWUsQ0FBQztRQUNuQyx1QkFBdUIsR0FBRyxFQUFFLENBQUM7UUFDN0IsY0FBYyxDQUFXO1FBQ3pCLGVBQWUsQ0FBb0I7UUFDbkMsZ0JBQWdCLENBQVU7UUFDMUIsc0JBQXNCLENBQVU7UUFDaEMsa0JBQWtCLENBQXNCO1FBQ3hDLDJCQUEyQixDQUErQjtRQUMxRCwyQkFBMkIsQ0FBK0I7UUFDMUQsVUFBVSxDQUFtQjtRQUU5Qyx5REFBeUQ7UUFDekQsY0FBYztRQUNkLHlEQUF5RDtRQUN6RCxZQUFZLEtBQWdCLEVBQUUsRUFBVSxFQUFFLEtBQWlCO1lBQ3pELEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7Ozs7OzttREF0R1IsS0FBSzs7OztZQXVHZCxtQ0FBbUM7WUFDbkMsSUFBQSx3Q0FBb0IsRUFBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFbEMseURBQXlEO1lBQ3pELGlCQUFpQjtZQUNqQix5REFBeUQ7WUFDekQsSUFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLFNBQVM7Z0JBQy9CLENBQUMsWUFBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDO2dCQUN0QyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxzQkFBc0IsRUFBRSxDQUFDO2dCQUN0RCxNQUFNLElBQUksc0JBQWUsQ0FBQyxxQkFBcUIsRUFBRSxnQ0FBZ0Msc0JBQXNCLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUM5SCxDQUFDO1lBRUQsMEJBQTBCO1lBQzFCLElBQUksS0FBSyxDQUFDLGNBQWMsS0FBSyxTQUFTO2dCQUNsQyxDQUFDLFlBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQztnQkFDekMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsSUFBSSxLQUFLLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUM7Z0JBQ3BGLE1BQU0sSUFBSSxzQkFBZSxDQUFDLDBCQUEwQixFQUFFLGlEQUFpRCxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ2pILENBQUM7WUFFRCx5REFBeUQ7WUFDekQsOEJBQThCO1lBQzlCLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMsSUFBSTtnQkFDUCxLQUFLLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztZQUN6RSxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQyxjQUFjLElBQUksZUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNuRSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLGdCQUFnQixJQUFJLEtBQUssQ0FBQztZQUN4RCxJQUFJLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDLHNCQUFzQixJQUFJLEtBQUssQ0FBQztZQUNwRSxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQyxlQUFlLENBQUM7WUFDN0MsV0FBVztZQUNYLElBQUksQ0FBQywyQkFBMkIsR0FBRyxLQUFLLENBQUMsMkJBQTJCLENBQUM7WUFDckUsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBQzNCLElBQUksQ0FBQywyQkFBMkIsR0FBRyxLQUFLLENBQUMsMkJBQTJCLENBQUM7WUFFckUseURBQXlEO1lBQ3pELE9BQU87WUFDUCx5REFBeUQ7WUFDekQsd0NBQXdDO1lBQ3hDLElBQUksS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUN2QixJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUM7Z0JBQy9CLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFDaEMsOEJBQThCO1lBQ2hDLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFO29CQUNyQyx1QkFBdUI7b0JBQ3ZCLFFBQVEsRUFBRSxJQUFJLENBQUMsb0JBQW9CLEVBQUUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCO29CQUM3RCx3RkFBd0Y7b0JBQ3hGLFNBQVMsRUFBRSxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLGNBQWMsQ0FBQzt3QkFDMUUsWUFBWSxFQUFFOzRCQUNaLG1CQUFtQixFQUFFLEVBQUUsR0FBRyxFQUFFLGdCQUFnQixFQUFFO3lCQUMvQzt3QkFDRCxPQUFPLEVBQUU7NEJBQ1AsZUFBZSxFQUFFLFlBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDO2dDQUN4QyxPQUFPLEVBQUUsU0FBUztnQ0FDbEIsUUFBUSxFQUFFLE9BQU87Z0NBQ2pCLFlBQVksRUFBRSxHQUFHO2dDQUNqQixTQUFTLEVBQUUsZ0JBQVMsQ0FBQyxtQkFBbUI7NkJBQ3pDLENBQUM7eUJBQ0g7cUJBQ0YsQ0FBQztpQkFDSCxDQUFDLENBQUM7Z0JBQ0gsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ2xDLENBQUM7WUFDRCx5REFBeUQ7WUFDekQsZ0NBQWdDO1lBQ2hDLHlEQUF5RDtZQUN6RCw0QkFBNEI7WUFDNUIsSUFBSSxDQUFDLGNBQWMsQ0FBQywrQkFBZ0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztZQUN2RSxJQUFJLENBQUMsY0FBYyxDQUFDLCtCQUFnQixDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO1lBRW5GLDREQUE0RDtZQUM1RCx3REFBd0Q7WUFDeEQsS0FBSyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUU7Z0JBQy9CLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDMUIsQ0FBQyxDQUFDLENBQUM7WUFFSCx3Q0FBd0M7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQztZQUNuRCxJQUFJLEtBQUssQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO2dCQUM3QixLQUFLLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRTtvQkFDbEQsSUFBSSxDQUFDLHNCQUFzQixDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNsQyxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUM7WUFFRCxJQUFJLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDcEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDckMsQ0FBQztZQUVELHlEQUF5RDtZQUN6RCxJQUFJLElBQUksQ0FBQywyQkFBMkIsRUFBRSxjQUFjLEVBQUUsQ0FBQztnQkFDckQsSUFBSSxDQUFDLDJCQUEyQixDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN2RSxJQUFJLENBQUMsMkJBQTJCLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyx1Q0FBdUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSwyQkFBMkIsQ0FBQyxFQUFFLEVBQUU7b0JBQzNKLFNBQVMsRUFBRSxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQztvQkFDNUQsU0FBUyxFQUFFLFdBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUN4RCxhQUFhLEVBQUUsRUFBRSxHQUFHLEVBQUUsZ0JBQWdCLEVBQVM7aUJBQ2hELENBQUMsQ0FBQztZQUNMLENBQUM7WUFFRCx5REFBeUQ7WUFDekQsZ0NBQWdDO1lBQ2hDLHlEQUF5RDtZQUN6RCxNQUFNLFFBQVEsR0FBMEI7Z0JBQ3RDLFlBQVksRUFBRSxXQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLENBQUM7Z0JBQzlGLFNBQVMsRUFBRSxJQUFJLENBQUMsSUFBSTtnQkFDcEIsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPO2dCQUN2QyxXQUFXLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixJQUFJLEtBQUs7Z0JBQzlDLHdCQUF3QixFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTTtnQkFDOUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXO2dCQUM5QixlQUFlLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZO2dCQUNsRCxzQkFBc0IsRUFBRSxXQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsRUFBRSxDQUFDO2dCQUMzRSx1QkFBdUIsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRTtnQkFDeEQsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXO2dCQUM5QixtQkFBbUIsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRTtnQkFDNUMsMkJBQTJCLEVBQUUsSUFBSSxDQUFDLDJCQUEyQixFQUFFLE9BQU8sRUFBRTtnQkFDeEUsOEJBQThCLEVBQUUsS0FBSyxDQUFDLFdBQVcsSUFBSSxLQUFLO2dCQUMxRCxrQkFBa0IsRUFBRSxLQUFLLENBQUMsa0JBQWtCLEVBQUUsSUFBSTtnQkFDbEQsa0JBQWtCLEVBQUUsV0FBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsRUFBRSxFQUFFLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxDQUFDO2dCQUMxRyxtQkFBbUIsRUFBRSxJQUFJLENBQUMseUJBQXlCLEVBQUU7Z0JBQ3JELGlCQUFpQixFQUFFLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsMENBQWlCLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLDBDQUFpQixDQUFDLE9BQU87YUFDekgsQ0FBQztZQUVGLHlEQUF5RDtZQUN6RCxtQkFBbUI7WUFDbkIseURBQXlEO1lBQ3pELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFFbkUsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQztZQUMzQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDO1lBQzdDLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQztZQUNyRCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO1lBRWpELHlGQUF5RjtZQUN6Rix5RUFBeUU7WUFDekUsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzFELEtBQUssQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRW5DLElBQUksQ0FBQyxTQUFTLEdBQUcsd0JBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLGNBQWMsRUFBRTtnQkFDL0QsT0FBTyxFQUFFLFlBQVk7Z0JBQ3JCLFNBQVMsRUFBRSxnQkFBZ0I7Z0JBQzNCLFlBQVksRUFBRSxPQUFPO2dCQUNyQixLQUFLLEVBQUUsSUFBSTthQUNaLENBQUMsQ0FBQztTQUNKO1FBRUQseURBQXlEO1FBQ3pELDBCQUEwQjtRQUMxQix5REFBeUQ7UUFFekQ7O1dBRUc7UUFFSSxZQUFZLENBQUMsU0FBcUI7Ozs7Ozs7Ozs7WUFDdkMsaUJBQWlCO1lBQ2pCLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQzdELDBCQUEwQjtZQUMxQixJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztZQUMzQixxQkFBcUI7WUFDckIsU0FBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDakM7UUFFRDs7Ozs7OztXQU9HO1FBRUksY0FBYyxDQUFDLFdBQTZCOzs7Ozs7Ozs7O1lBQ2pELFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLFdBQVcsQ0FBQyxDQUFDO1lBQ2pFLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3BDLG1EQUFtRDtZQUNuRCxXQUFXLENBQUMsUUFBUSxFQUFFLGNBQWMsRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzdELFdBQVcsQ0FBQyxRQUFRLEVBQUUsY0FBYyxFQUFFLGFBQWEsQ0FBQywwQkFBMEIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSwyQkFBMkIsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3BJLFNBQVMsRUFBRSxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQztnQkFDNUQsU0FBUyxFQUFFLElBQUksQ0FBQyxRQUFRO2dCQUN4QixhQUFhLEVBQUUsRUFBRSxHQUFHLEVBQUUsZ0JBQWdCLEVBQVM7YUFDaEQsQ0FBQyxDQUFDO1lBQ0gsdURBQXVEO1lBQ3ZELElBQUksV0FBVyxDQUFDLFNBQVMsWUFBWSwyQkFBYyxFQUFFLENBQUM7Z0JBQ3BELE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ2pELElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQztvQkFDeEMsTUFBTSxJQUFJLHNCQUFlLENBQUMsaUJBQWlCLEVBQUUsK0NBQStDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3RHLENBQUM7Z0JBQ0QsTUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLEVBQUUsQ0FBQztnQkFDN0IsSUFBSSxDQUFDLENBQUMsY0FBYyxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxhQUFhLElBQUksUUFBUSxDQUFDLEVBQUUsQ0FBQztvQkFDbEUsTUFBTSxJQUFJLHNCQUFlLENBQUMsc0JBQXNCLEVBQUUsOERBQThELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzFILENBQUM7Z0JBQ0QsTUFBTSxVQUFVLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQztnQkFDekMsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQztnQkFDdkMsSUFBSSxDQUFDLFVBQVUsSUFBSSxVQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUM7b0JBQzVDLE1BQU0sSUFBSSxzQkFBZSxDQUFDLG1CQUFtQixFQUFFLGtEQUFrRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMzRyxDQUFDO2dCQUNELElBQUksQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDO29CQUMxQyxNQUFNLElBQUksc0JBQWUsQ0FBQyxrQkFBa0IsRUFBRSxpREFBaUQsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDekcsQ0FBQztnQkFDRCxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxXQUFXLENBQUMsSUFBSSxjQUFjLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBQzdGLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztZQUN6QyxDQUFDO2lCQUFNLElBQUksV0FBVyxDQUFDLFNBQVMsWUFBWSx3QkFBVyxFQUFFLENBQUM7Z0JBQ3hELE1BQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2dCQUM1QyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQ1osTUFBTSxJQUFJLHNCQUFlLENBQUMsZUFBZSxFQUFFLGlEQUFpRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN0RyxDQUFDO2dCQUNELElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxJQUFJLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUM7b0JBQzFELE1BQU0sSUFBSSxzQkFBZSxDQUFDLG1CQUFtQixFQUFFLCtDQUErQyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN4RyxDQUFDO2dCQUNELElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUM7b0JBQ3hELE1BQU0sSUFBSSxzQkFBZSxDQUFDLGtCQUFrQixFQUFFLDhDQUE4QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN0RyxDQUFDO2dCQUNELE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLElBQUksRUFBRSxHQUFHLFdBQVcsQ0FBQyxJQUFJLGNBQWMsRUFBRSxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3BHLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDaEQsQ0FBQztTQUNGO1FBRUQ7Ozs7Ozs7V0FPRztRQUNLLHNCQUFzQixDQUFDLGlCQUFvQztZQUNqRSxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3BDO1FBRUQ7Ozs7V0FJRztRQUVJLGVBQWUsQ0FBQyxHQUFHLFlBQWdDOzs7Ozs7Ozs7O1lBQ3hELFlBQVksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDckQ7UUFFRCx5REFBeUQ7UUFDekQsaUJBQWlCO1FBQ2pCLHlEQUF5RDtRQUV6RDs7OztXQUlHO1FBQ0ssZUFBZTtZQUNyQixPQUFPLElBQUksQ0FBQyxTQUFTO2dCQUNuQixDQUFDLENBQUM7b0JBQ0EsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXO29CQUMvQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQjtpQkFDbEQ7Z0JBQ0QsQ0FBQyxDQUFDLFNBQVMsQ0FBQztTQUNmO1FBRUQ7Ozs7OztXQU1HO1FBQ0ssa0JBQWtCO1lBQ3hCLE1BQU0sZUFBZSxHQUFnRCxFQUFFLENBQUM7WUFDeEUsMkNBQTJDO1lBQzNDLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFO2dCQUM3QixlQUFlLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQ3JDLENBQUMsQ0FBQyxDQUFDO1lBQ0gsT0FBTyxlQUFlLENBQUM7U0FDeEI7UUFFRDs7Ozs7O1dBTUc7UUFDSyx3QkFBd0I7WUFDOUIsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQzdILE9BQU8sU0FBUyxDQUFDO1lBQ25CLENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7U0FDdEU7UUFFRDs7Ozs7O1dBTUc7UUFDSyx5QkFBeUI7WUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFDO2dCQUN0QyxPQUFPLFNBQVMsQ0FBQztZQUNuQixDQUFDO1lBRUQsT0FBTztnQkFDTCxRQUFRLEVBQUU7b0JBQ1IsTUFBTSxFQUFFLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxjQUFjLENBQUMsV0FBVztpQkFDcEU7YUFDRixDQUFDO1NBQ0g7UUFFRCx5REFBeUQ7UUFDekQsYUFBYTtRQUNiLHlEQUF5RDtRQUN6RDs7Ozs7V0FLRztRQUNLLGlCQUFpQixHQUFHLENBQUMsU0FBcUIsRUFBRSxFQUFFO1lBQ3BELElBQUksTUFBTSxHQUFhLEVBQUUsQ0FBQztZQUMxQixJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDbkIsTUFBTSxDQUFDLElBQUksQ0FDVCx3QkFBd0IsU0FBUyxDQUFDLFdBQVcsSUFBSTtvQkFDL0MsYUFBYSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsNkNBQTZDLENBQ3ZGLENBQUM7WUFDSixDQUFDO1lBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyxFQUFFLDBCQUEwQixDQUFDLENBQUMsQ0FBQztZQUNuSCxPQUFPLE1BQU0sQ0FBQztRQUNoQixDQUFDLENBQUM7UUFFRjs7Ozs7V0FLRztRQUNLLG1CQUFtQixHQUFHLENBQUMsV0FBNkIsRUFBRSxFQUFFO1lBQzlELElBQUksTUFBTSxHQUFhLEVBQUUsQ0FBQztZQUMxQixtREFBbUQ7WUFDbkQsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQ2hFLE1BQU0sQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUMsQ0FBQztZQUM3QyxDQUFDO1lBQ0QsT0FBTyxNQUFNLENBQUM7UUFDaEIsQ0FBQyxDQUFDO1FBRUY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7V0FtQkc7UUFDSyx3QkFBd0IsQ0FDOUIsS0FBaUIsRUFDakIsTUFBYyxFQUNkLE9BTUM7WUFFRCxNQUFNLFlBQVksR0FBRyxDQUFDLEdBQVEsRUFBVSxFQUFFO2dCQUN4QyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFBQyxPQUFPLEVBQUUsQ0FBQztnQkFBQyxDQUFDO2dCQUNyQyxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN2QyxNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUN6QyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDM0QsQ0FBQyxDQUFDO1lBRUYsTUFBTSxFQUNKLFNBQVMsR0FBRyxHQUFHLEVBQ2YsS0FBSyxHQUFHLEtBQUssRUFDYixTQUFTLEdBQUcsRUFBRSxFQUNkLHdCQUF3QixHQUFHLFNBQVMsRUFDcEMsYUFBYSxHQUFHLFNBQVMsR0FDMUIsR0FBRyxPQUFPLElBQUksRUFBRSxDQUFDO1lBRWxCLE1BQU0sSUFBSSxHQUFHLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUN6QyxJQUFJLFNBQVMsR0FBRyxDQUFDLE1BQU0sR0FBRyxJQUFJLEdBQUcsU0FBUyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ25ELE1BQU0sSUFBSSxzQkFBZSxDQUFDLGVBQWUsRUFBRSwrQ0FBK0MsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNwRyxDQUFDO1lBRUQsTUFBTSxVQUFVLEdBQUcsWUFBSyxDQUFDLGtCQUFrQixDQUN6QyxLQUFLLEVBQ0wsRUFBRSxTQUFTLEVBQUUsU0FBUyxHQUFHLENBQUMsTUFBTSxHQUFHLElBQUksR0FBRyxTQUFTLENBQUMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLHdCQUF3QixFQUFFLENBQ25HLENBQUM7WUFDRixNQUFNLElBQUksR0FBRyxHQUFHLE1BQU0sR0FBRyxJQUFJLEdBQUcsU0FBUyxHQUFHLFVBQVUsRUFBRSxDQUFDO1lBQ3pELElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxTQUFTLEVBQUUsQ0FBQztnQkFDNUIsTUFBTSxJQUFJLHNCQUFlLENBQUMsc0JBQXNCLEVBQUUsMkRBQTJELFNBQVMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ2xJLENBQUM7WUFDRCxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7U0FDMUM7UUFFRDs7Ozs7Ozs7V0FRRztRQUNPLG9CQUFvQjtZQUM1QixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztZQUM5RSxPQUFPLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFO2dCQUNsRCxTQUFTO2dCQUNULEtBQUssRUFBRSxJQUFJO2dCQUNYLFNBQVMsRUFBRSxHQUFHO2FBQ2YsQ0FBQyxDQUFDO1NBQ0o7O1lBMWdCVSx1REFBSzs7Ozs7QUFBTCxzQkFBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGNyeXB0byBmcm9tICdjcnlwdG8nO1xuaW1wb3J0ICogYXMgYmVkcm9jayBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgKiBhcyBjbG91ZHdhdGNoIGZyb20gJ2F3cy1jZGstbGliL2F3cy1jbG91ZHdhdGNoJztcbmltcG9ydCAqIGFzIGV2ZW50cyBmcm9tICdhd3MtY2RrLWxpYi9hd3MtZXZlbnRzJztcbmltcG9ydCAqIGFzIGlhbSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCAqIGFzIGttcyBmcm9tICdhd3MtY2RrLWxpYi9hd3Mta21zJztcbmltcG9ydCAqIGFzIHMzIGZyb20gJ2F3cy1jZGstbGliL2F3cy1zMyc7XG5pbXBvcnQgdHlwZSB7IElSZXNvdXJjZSB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUnO1xuaW1wb3J0IHsgQXJuLCBBcm5Gb3JtYXQsIER1cmF0aW9uLCBMYXp5LCBOYW1lcywgUmVzb3VyY2UsIFN0YWNrLCBUb2tlbiwgVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZSc7XG5pbXBvcnQgeyBhZGRDb25zdHJ1Y3RNZXRhZGF0YSwgTWV0aG9kTWV0YWRhdGEgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9tZXRhZGF0YS1yZXNvdXJjZSc7XG5pbXBvcnQgeyBwcm9wZXJ0eUluamVjdGFibGUgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9wcm9wLWluamVjdGFibGUnO1xuaW1wb3J0IHR5cGUgeyBDb25zdHJ1Y3QsIElDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcbi8vIEludGVybmFsIExpYnNcbmltcG9ydCB7IEFnZW50QWN0aW9uR3JvdXAgfSBmcm9tICcuL2FjdGlvbi1ncm91cCc7XG5pbXBvcnQgdHlwZSB7IElBZ2VudEFsaWFzIH0gZnJvbSAnLi9hZ2VudC1hbGlhcyc7XG5pbXBvcnQgeyBBZ2VudEFsaWFzIH0gZnJvbSAnLi9hZ2VudC1hbGlhcyc7XG5pbXBvcnQgdHlwZSB7IEFnZW50Q29sbGFib3JhdGlvbiB9IGZyb20gJy4vYWdlbnQtY29sbGFib3JhdGlvbic7XG5pbXBvcnQgdHlwZSB7IEFnZW50Q29sbGFib3JhdG9yIH0gZnJvbSAnLi9hZ2VudC1jb2xsYWJvcmF0b3InO1xuaW1wb3J0IHsgQXNzZXRBcGlTY2hlbWEsIFMzQXBpU2NoZW1hIH0gZnJvbSAnLi9hcGktc2NoZW1hJztcbmltcG9ydCB0eXBlIHsgTWVtb3J5IH0gZnJvbSAnLi9tZW1vcnknO1xuaW1wb3J0IHR5cGUgeyBDdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3IgfSBmcm9tICcuL29yY2hlc3RyYXRpb24tZXhlY3V0b3InO1xuaW1wb3J0IHsgT3JjaGVzdHJhdGlvblR5cGUgfSBmcm9tICcuL29yY2hlc3RyYXRpb24tZXhlY3V0b3InO1xuaW1wb3J0IHR5cGUgeyBQcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb24gfSBmcm9tICcuL3Byb21wdC1vdmVycmlkZSc7XG5pbXBvcnQgKiBhcyB2YWxpZGF0aW9uIGZyb20gJy4vdmFsaWRhdGlvbi1oZWxwZXJzJztcbmltcG9ydCB0eXBlIHsgSUJlZHJvY2tJbnZva2FibGUgfSBmcm9tICcuLi8uL21vZGVscyc7XG5pbXBvcnQgdHlwZSB7IElHdWFyZHJhaWwgfSBmcm9tICcuLi9ndWFyZHJhaWxzL2d1YXJkcmFpbHMnO1xuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENPTlNUQU5UU1xuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBUaGUgbWluaW11bSBudW1iZXIgb2YgY2hhcmFjdGVycyByZXF1aXJlZCBmb3IgYW4gYWdlbnQgaW5zdHJ1Y3Rpb24uXG4gKiBAaW50ZXJuYWxcbiAqL1xuY29uc3QgTUlOX0lOU1RSVUNUSU9OX0xFTkdUSCA9IDQwO1xuXG4vKipcbiAqIFRoZSBtYXhpbXVtIGxlbmd0aCBmb3IgdGhlIG5vZGUgYWRkcmVzcyBpbiBwZXJtaXNzaW9uIHBvbGljeSBuYW1lcy5cbiAqIEBpbnRlcm5hbFxuICovXG5jb25zdCBNQVhfUE9MSUNZX05BTUVfTk9ERV9MRU5HVEggPSAxNjtcblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDT01NT05cbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogUmVwcmVzZW50cyBhbiBBZ2VudCwgZWl0aGVyIGNyZWF0ZWQgd2l0aCBDREsgb3IgaW1wb3J0ZWQuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSUFnZW50IGV4dGVuZHMgSVJlc291cmNlLCBpYW0uSUdyYW50YWJsZSB7XG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBhZ2VudC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcmVhZG9ubHkgYWdlbnRBcm46IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBJRCBvZiB0aGUgQWdlbnQuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHJlYWRvbmx5IGFnZW50SWQ6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBJQU0gcm9sZSBhc3NvY2lhdGVkIHRvIHRoZSBhZ2VudC5cbiAgICovXG4gIHJlYWRvbmx5IHJvbGU6IGlhbS5JUm9sZTtcbiAgLyoqXG4gICAqIE9wdGlvbmFsIEtNUyBlbmNyeXB0aW9uIGtleSBhc3NvY2lhdGVkIHdpdGggdGhpcyBhZ2VudFxuICAgKi9cbiAgcmVhZG9ubHkga21zS2V5Pzoga21zLklLZXk7XG4gIC8qKlxuICAgKiBXaGVuIHRoaXMgYWdlbnQgd2FzIGxhc3QgdXBkYXRlZC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcmVhZG9ubHkgbGFzdFVwZGF0ZWQ/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEdyYW50IGludm9rZSBwZXJtaXNzaW9ucyBvbiB0aGlzIGFnZW50IHRvIGFuIElBTSBwcmluY2lwYWwuXG4gICAqIE5vdGU6IFRoaXMgZ3JhbnQgd2lsbCBvbmx5IHdvcmsgd2hlbiB0aGUgZ3JhbnRlZSBpcyBpbiB0aGUgc2FtZSBBV1MgYWNjb3VudFxuICAgKiB3aGVyZSB0aGUgYWdlbnQgaXMgZGVmaW5lZC4gQ3Jvc3MtYWNjb3VudCBpbnZvY2F0aW9uIGlzIG5vdCBzdXBwb3J0ZWQuXG4gICAqL1xuICBncmFudEludm9rZShncmFudGVlOiBpYW0uSUdyYW50YWJsZSk6IGlhbS5HcmFudDtcblxuICAvKipcbiAgICogRGVmaW5lcyBhIENsb3VkV2F0Y2ggZXZlbnQgcnVsZSB0cmlnZ2VyZWQgYnkgYWdlbnQgZXZlbnRzLlxuICAgKi9cbiAgb25FdmVudChpZDogc3RyaW5nLCBvcHRpb25zPzogZXZlbnRzLk9uRXZlbnRPcHRpb25zKTogZXZlbnRzLlJ1bGU7XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgQ2xvdWRXYXRjaCBtZXRyaWMgZm9yIGFnZW50IGNvdW50LlxuICAgKi9cbiAgbWV0cmljQ291bnQocHJvcHM/OiBjbG91ZHdhdGNoLk1ldHJpY09wdGlvbnMpOiBjbG91ZHdhdGNoLk1ldHJpYztcbn1cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgQUJTVFJBQ1QgQkFTRSBDTEFTU1xuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBBYnN0cmFjdCBiYXNlIGNsYXNzIGZvciBhbiBBZ2VudC5cbiAqIENvbnRhaW5zIG1ldGhvZHMgYW5kIGF0dHJpYnV0ZXMgdmFsaWQgZm9yIEFnZW50cyBlaXRoZXIgY3JlYXRlZCB3aXRoIENESyBvciBpbXBvcnRlZC5cbiAqL1xuZXhwb3J0IGFic3RyYWN0IGNsYXNzIEFnZW50QmFzZSBleHRlbmRzIFJlc291cmNlIGltcGxlbWVudHMgSUFnZW50IHtcbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGFnZW50QXJuOiBzdHJpbmc7XG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSBhZ2VudElkOiBzdHJpbmc7XG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSByb2xlOiBpYW0uSVJvbGU7XG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSBrbXNLZXk/OiBrbXMuSUtleTtcbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGxhc3RVcGRhdGVkPzogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHZlcnNpb24gb2YgdGhlIGFnZW50LlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkgYWdlbnRWZXJzaW9uOiBzdHJpbmc7XG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSBncmFudFByaW5jaXBhbDogaWFtLklQcmluY2lwYWw7XG5cbiAgLyoqXG4gICAqIEdyYW50IGludm9rZSBwZXJtaXNzaW9ucyBvbiB0aGlzIGFnZW50IHRvIGFuIElBTSBwcmluY2lwYWwuXG4gICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgKlxuICAgKiBAcGFyYW0gZ3JhbnRlZSAtIFRoZSBJQU0gcHJpbmNpcGFsIHRvIGdyYW50IGludm9rZSBwZXJtaXNzaW9ucyB0b1xuICAgKiBAZGVmYXVsdCAtIERlZmF1bHQgZ3JhbnQgY29uZmlndXJhdGlvbjpcbiAgICogLSBhY3Rpb25zOiBbJ2JlZHJvY2s6SW52b2tlQWdlbnQnXVxuICAgKiAtIHJlc291cmNlQXJuczogW3RoaXMuYWdlbnRBcm5dXG4gICAqIEByZXR1cm5zIEFuIElBTSBHcmFudCBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSBncmFudGVkIHBlcm1pc3Npb25zXG4gICAqL1xuICBwdWJsaWMgZ3JhbnRJbnZva2UoZ3JhbnRlZTogaWFtLklHcmFudGFibGUpOiBpYW0uR3JhbnQge1xuICAgIHJldHVybiBpYW0uR3JhbnQuYWRkVG9QcmluY2lwYWwoe1xuICAgICAgZ3JhbnRlZSxcbiAgICAgIGFjdGlvbnM6IFsnYmVkcm9jazpJbnZva2VBZ2VudCddLFxuICAgICAgcmVzb3VyY2VBcm5zOiBbdGhpcy5hZ2VudEFybl0sXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBhbiBFdmVudEJyaWRnZSBydWxlIGZvciBhZ2VudCBldmVudHMuXG4gICAqXG4gICAqIEBwYXJhbSBpZCAtIFVuaXF1ZSBpZGVudGlmaWVyIGZvciB0aGUgcnVsZVxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIENvbmZpZ3VyYXRpb24gb3B0aW9ucyBmb3IgdGhlIGV2ZW50IHJ1bGVcbiAgICogQGRlZmF1bHQgLSBEZWZhdWx0IGV2ZW50IHBhdHRlcm46XG4gICAqIC0gc291cmNlOiBbJ2F3cy5iZWRyb2NrJ11cbiAgICogLSBkZXRhaWw6IHsgJ2FnZW50LWlkJzogW3RoaXMuYWdlbnRJZF0gfVxuICAgKiBAcmV0dXJucyBBbiBFdmVudEJyaWRnZSBSdWxlIGNvbmZpZ3VyZWQgZm9yIGFnZW50IGV2ZW50c1xuICAgKi9cbiAgcHVibGljIG9uRXZlbnQoaWQ6IHN0cmluZywgb3B0aW9uczogZXZlbnRzLk9uRXZlbnRPcHRpb25zID0ge30pOiBldmVudHMuUnVsZSB7XG4gICAgY29uc3QgcnVsZSA9IG5ldyBldmVudHMuUnVsZSh0aGlzLCBpZCwgb3B0aW9ucyk7XG4gICAgcnVsZS5hZGRFdmVudFBhdHRlcm4oe1xuICAgICAgc291cmNlOiBbJ2F3cy5iZWRyb2NrJ10sXG4gICAgICBkZXRhaWw6IHtcbiAgICAgICAgJ2FnZW50LWlkJzogW3RoaXMuYWdlbnRJZF0sXG4gICAgICB9LFxuICAgIH0pO1xuXG4gICAgcnVsZS5hZGRUYXJnZXQob3B0aW9ucy50YXJnZXQpO1xuICAgIHJldHVybiBydWxlO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBDbG91ZFdhdGNoIG1ldHJpYyBmb3IgdHJhY2tpbmcgYWdlbnQgaW52b2NhdGlvbnMuXG4gICAqXG4gICAqIEBwYXJhbSBwcm9wcyAtIENvbmZpZ3VyYXRpb24gb3B0aW9ucyBmb3IgdGhlIG1ldHJpY1xuICAgKiBAZGVmYXVsdCAtIERlZmF1bHQgbWV0cmljIGNvbmZpZ3VyYXRpb246XG4gICAqIC0gbmFtZXNwYWNlOiAnQVdTL0JlZHJvY2snXG4gICAqIC0gbWV0cmljTmFtZTogJ0ludm9jYXRpb25zJ1xuICAgKiAtIGRpbWVuc2lvbnNNYXA6IHsgQWdlbnRJZDogdGhpcy5hZ2VudElkIH1cbiAgICogQHJldHVybnMgQSBDbG91ZFdhdGNoIE1ldHJpYyBjb25maWd1cmVkIGZvciBhZ2VudCBpbnZvY2F0aW9uIGNvdW50c1xuICAgKi9cbiAgcHVibGljIG1ldHJpY0NvdW50KHByb3BzPzogY2xvdWR3YXRjaC5NZXRyaWNPcHRpb25zKTogY2xvdWR3YXRjaC5NZXRyaWMge1xuICAgIHJldHVybiBuZXcgY2xvdWR3YXRjaC5NZXRyaWMoe1xuICAgICAgbmFtZXNwYWNlOiAnQVdTL0JlZHJvY2snLFxuICAgICAgbWV0cmljTmFtZTogJ0ludm9jYXRpb25zJyxcbiAgICAgIGRpbWVuc2lvbnNNYXA6IHtcbiAgICAgICAgQWdlbnRJZDogdGhpcy5hZ2VudElkLFxuICAgICAgfSxcbiAgICAgIC4uLnByb3BzLFxuICAgIH0pLmF0dGFjaFRvKHRoaXMpO1xuICB9XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgUFJPUFMgRk9SIE5FVyBDT05TVFJVQ1RcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogUHJvcGVydGllcyBmb3IgY3JlYXRpbmcgYSBDREsgbWFuYWdlZCBCZWRyb2NrIEFnZW50LlxuICogVE9ETzogS25vd2xlZGdlIGJhc2VzIGNvbmZpZ3VyYXRpb24gd2lsbCBiZSBhZGRlZCBpbiBhIGZ1dHVyZSB1cGRhdGVcbiAqIFRPRE86IEluZmVyZW5jZSBwcm9maWxlIGNvbmZpZ3VyYXRpb24gd2lsbCBiZSBhZGRlZCBpbiBhIGZ1dHVyZSB1cGRhdGVcbiAqXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQWdlbnRQcm9wcyB7XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBhZ2VudC5cbiAgICogVGhpcyB3aWxsIGJlIHVzZWQgYXMgdGhlIHBoeXNpY2FsIG5hbWUgb2YgdGhlIGFnZW50LlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIEEgbmFtZSBpcyBnZW5lcmF0ZWQgYnkgQ0RLLlxuICAgKiBTdXBwb3J0ZWQgcGF0dGVybiA6IF4oWzAtOWEtekEtWl1bXy1dPyl7MSwxMDB9JFxuICAgKi9cbiAgcmVhZG9ubHkgYWdlbnROYW1lPzogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGluc3RydWN0aW9uIHVzZWQgYnkgdGhlIGFnZW50LiBUaGlzIGRldGVybWluZXMgaG93IHRoZSBhZ2VudCB3aWxsIHBlcmZvcm0gaGlzIHRhc2suXG4gICAqIFRoaXMgaW5zdHJ1Y3Rpb24gbXVzdCBoYXZlIGEgbWluaW11bSBvZiA0MCBjaGFyYWN0ZXJzLlxuICAgKi9cbiAgcmVhZG9ubHkgaW5zdHJ1Y3Rpb246IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBmb3VuZGF0aW9uIG1vZGVsIHVzZWQgZm9yIG9yY2hlc3RyYXRpb24gYnkgdGhlIGFnZW50LlxuICAgKi9cbiAgcmVhZG9ubHkgZm91bmRhdGlvbk1vZGVsOiBJQmVkcm9ja0ludm9rYWJsZTtcbiAgLyoqXG4gICAqIEFuIGV4aXN0aW5nIElBTSBSb2xlIHRvIGFzc29jaWF0ZSB3aXRoIHRoaXMgYWdlbnQuXG4gICAqIFVzZSB0aGlzIHByb3BlcnR5IHdoZW4geW91IHdhbnQgdG8gcmV1c2UgYW4gZXhpc3RpbmcgSUFNIHJvbGUgcmF0aGVyIHRoYW4gY3JlYXRlIGEgbmV3IG9uZS5cbiAgICogVGhlIHJvbGUgbXVzdCBoYXZlIGEgdHJ1c3QgcG9saWN5IHRoYXQgYWxsb3dzIHRoZSBCZWRyb2NrIHNlcnZpY2UgdG8gYXNzdW1lIGl0LlxuICAgKiBAZGVmYXVsdCAtIEEgbmV3IHJvbGUgaXMgY3JlYXRlZCBmb3IgeW91LlxuICAgKi9cbiAgcmVhZG9ubHkgZXhpc3RpbmdSb2xlPzogaWFtLklSb2xlO1xuICAvKipcbiAgICogU3BlY2lmaWVzIHdoZXRoZXIgdG8gYXV0b21hdGljYWxseSB1cGRhdGUgdGhlIGBEUkFGVGAgdmVyc2lvbiBvZiB0aGUgYWdlbnQgYWZ0ZXJcbiAgICogbWFraW5nIGNoYW5nZXMgdG8gdGhlIGFnZW50LiBUaGUgYERSQUZUYCB2ZXJzaW9uIGNhbiBiZSBjb250aW51YWxseSBpdGVyYXRlZFxuICAgKiB1cG9uIGR1cmluZyBpbnRlcm5hbCBkZXZlbG9wbWVudC5cbiAgICpcbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIHJlYWRvbmx5IHNob3VsZFByZXBhcmVBZ2VudD86IGJvb2xlYW47XG4gIC8qKlxuICAgKiBIb3cgbG9uZyBzZXNzaW9ucyBzaG91bGQgYmUga2VwdCBvcGVuIGZvciB0aGUgYWdlbnQuIElmIG5vIGNvbnZlcnNhdGlvbiBvY2N1cnNcbiAgICogZHVyaW5nIHRoaXMgdGltZSwgdGhlIHNlc3Npb24gZXhwaXJlcyBhbmQgQW1hem9uIEJlZHJvY2sgZGVsZXRlcyBhbnkgZGF0YVxuICAgKiBwcm92aWRlZCBiZWZvcmUgdGhlIHRpbWVvdXQuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gMTAgbWludXRlc1xuICAgKi9cbiAgcmVhZG9ubHkgaWRsZVNlc3Npb25UVEw/OiBEdXJhdGlvbjtcbiAgLyoqXG4gICAqIFRoZSBLTVMga2V5IG9mIHRoZSBhZ2VudCBpZiBjdXN0b20gZW5jcnlwdGlvbiBpcyBjb25maWd1cmVkLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIEFuIEFXUyBtYW5hZ2VkIGtleSBpcyB1c2VkLlxuICAgKi9cbiAgcmVhZG9ubHkga21zS2V5Pzoga21zLklLZXk7XG4gIC8qKlxuICAgKiBBIGRlc2NyaXB0aW9uIG9mIHRoZSBhZ2VudC5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyBkZXNjcmlwdGlvbiBpcyBwcm92aWRlZC5cbiAgICovXG4gIHJlYWRvbmx5IGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIEFjdGlvbiBHcm91cHMgYXNzb2NpYXRlZCB3aXRoIHRoZSBhZ2VudC5cbiAgICogQGRlZmF1bHQgLSBPbmx5IGRlZmF1bHQgYWN0aW9uIGdyb3VwcyAoVXNlcklucHV0IGFuZCBDb2RlSW50ZXJwcmV0ZXIpIGFyZSBhZGRlZFxuICAgKi9cbiAgcmVhZG9ubHkgYWN0aW9uR3JvdXBzPzogQWdlbnRBY3Rpb25Hcm91cFtdO1xuICAvKipcbiAgICogVGhlIGd1YXJkcmFpbCB0aGF0IHdpbGwgYmUgYXNzb2NpYXRlZCB3aXRoIHRoZSBhZ2VudC5cbiAgICogQGRlZmF1bHQgLSBObyBndWFyZHJhaWwgaXMgcHJvdmlkZWQuXG4gICAqL1xuICByZWFkb25seSBndWFyZHJhaWw/OiBJR3VhcmRyYWlsO1xuICAvKipcbiAgICogT3ZlcnJpZGVzIHNvbWUgcHJvbXB0IHRlbXBsYXRlcyBpbiBkaWZmZXJlbnQgcGFydHMgb2YgYW4gYWdlbnQgc2VxdWVuY2UgY29uZmlndXJhdGlvbi5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyBvdmVycmlkZXMgYXJlIHByb3ZpZGVkLlxuICAgKi9cbiAgcmVhZG9ubHkgcHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uPzogUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uO1xuICAvKipcbiAgICogU2VsZWN0IHdoZXRoZXIgdGhlIGFnZW50IGNhbiBwcm9tcHQgYWRkaXRpb25hbCBpbmZvcm1hdGlvbiBmcm9tIHRoZSB1c2VyIHdoZW4gaXQgZG9lcyBub3QgaGF2ZVxuICAgKiBlbm91Z2ggaW5mb3JtYXRpb24gdG8gcmVzcG9uZCB0byBhbiB1dHRlcmFuY2VcbiAgICpcbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIHJlYWRvbmx5IHVzZXJJbnB1dEVuYWJsZWQ/OiBib29sZWFuO1xuICAvKipcbiAgICogU2VsZWN0IHdoZXRoZXIgdGhlIGFnZW50IGNhbiBnZW5lcmF0ZSwgcnVuLCBhbmQgdHJvdWJsZXNob290IGNvZGUgd2hlbiB0cnlpbmcgdG8gY29tcGxldGUgYSB0YXNrXG4gICAqXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICByZWFkb25seSBjb2RlSW50ZXJwcmV0ZXJFbmFibGVkPzogYm9vbGVhbjtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdG8gZGVsZXRlIHRoZSByZXNvdXJjZSBldmVuIGlmIGl0J3MgaW4gdXNlLlxuICAgKlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgcmVhZG9ubHkgZm9yY2VEZWxldGU/OiBib29sZWFuO1xuICAvKipcbiAgICogVGhlIHR5cGUgYW5kIGNvbmZpZ3VyYXRpb24gb2YgdGhlIG1lbW9yeSB0byBtYWludGFpbiBjb250ZXh0IGFjcm9zcyBtdWx0aXBsZSBzZXNzaW9ucyBhbmQgcmVjYWxsIHBhc3QgaW50ZXJhY3Rpb25zLlxuICAgKiBUaGlzIGNhbiBiZSB1c2VmdWwgZm9yIG1haW50YWluaW5nIGNvbnRpbnVpdHkgaW4gbXVsdGktdHVybiBjb252ZXJzYXRpb25zIGFuZCByZWNhbGxpbmcgdXNlciBwcmVmZXJlbmNlc1xuICAgKiBvciBwYXN0IGludGVyYWN0aW9ucy5cbiAgICpcbiAgICogQHNlZSBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vYmVkcm9jay9sYXRlc3QvdXNlcmd1aWRlL2FnZW50cy1tZW1vcnkuaHRtbFxuICAgKiBAZGVmYXVsdCAtIE5vIG1lbW9yeSB3aWxsIGJlIHVzZWQuIEFnZW50cyB3aWxsIHJldGFpbiBjb250ZXh0IGZyb20gdGhlIGN1cnJlbnQgc2Vzc2lvbiBvbmx5LlxuICAgKi9cbiAgcmVhZG9ubHkgbWVtb3J5PzogTWVtb3J5O1xuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgYWdlbnQgY29sbGFib3JhdGlvbiBzZXR0aW5ncywgaW5jbHVkaW5nIEFnZW50Q29sbGFib3JhdG9yVHlwZSBhbmQgQWdlbnRDb2xsYWJvcmF0b3JzLlxuICAgKiBUaGlzIHByb3BlcnR5IGFsbG93cyB5b3UgdG8gZGVmaW5lIGhvdyB0aGUgYWdlbnQgY29sbGFib3JhdGVzIHdpdGggb3RoZXIgYWdlbnRzXG4gICAqIGFuZCB3aGF0IGNvbGxhYm9yYXRvcnMgaXQgY2FuIHdvcmsgd2l0aC5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyBhZ2VudCBjb2xsYWJvcmF0aW9uIGNvbmZpZ3VyYXRpb24uXG4gICAqL1xuICByZWFkb25seSBhZ2VudENvbGxhYm9yYXRpb24/OiBBZ2VudENvbGxhYm9yYXRpb247XG4gIC8qKlxuICAgKiBUaGUgTGFtYmRhIGZ1bmN0aW9uIHRvIHVzZSBmb3IgY3VzdG9tIG9yY2hlc3RyYXRpb24uXG4gICAqIElmIHByb3ZpZGVkLCBjdXN0b20gb3JjaGVzdHJhdGlvbiB3aWxsIGJlIHVzZWQuXG4gICAqIElmIG5vdCBwcm92aWRlZCwgZGVmYXVsdCBvcmNoZXN0cmF0aW9uIHdpbGwgYmUgdXNlZC5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBEZWZhdWx0IG9yY2hlc3RyYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IGN1c3RvbU9yY2hlc3RyYXRpb25FeGVjdXRvcj86IEN1c3RvbU9yY2hlc3RyYXRpb25FeGVjdXRvcjtcbn1cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgIEFUVFJTIEZPUiBJTVBPUlRFRCBDT05TVFJVQ1RcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogQXR0cmlidXRlcyBmb3Igc3BlY2lmeWluZyBhbiBpbXBvcnRlZCBCZWRyb2NrIEFnZW50LlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFnZW50QXR0cmlidXRlcyB7XG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBhZ2VudC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcmVhZG9ubHkgYWdlbnRBcm46IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBBUk4gb2YgdGhlIElBTSByb2xlIGFzc29jaWF0ZWQgdG8gdGhlIGFnZW50LlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICByZWFkb25seSByb2xlQXJuOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBPcHRpb25hbCBLTVMgZW5jcnlwdGlvbiBrZXkgYXNzb2NpYXRlZCB3aXRoIHRoaXMgYWdlbnRcbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gQW4gQVdTIG1hbmFnZWQga2V5IGlzIHVzZWRcbiAgICovXG4gIHJlYWRvbmx5IGttc0tleUFybj86IHN0cmluZztcbiAgLyoqXG4gICAqIFdoZW4gdGhpcyBhZ2VudCB3YXMgbGFzdCB1cGRhdGVkLlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBsYXN0IHVwZGF0ZWQgdGltZXN0YW1wIGlzIHByb3ZpZGVkXG4gICAqL1xuICByZWFkb25seSBsYXN0VXBkYXRlZD86IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBhZ2VudCB2ZXJzaW9uLiBJZiBubyBleHBsaWNpdCB2ZXJzaW9ucyBoYXZlIGJlZW4gY3JlYXRlZCxcbiAgICogbGVhdmUgdGhpcyBlbXB0eSB0byB1c2UgdGhlIERSQUZUIHZlcnNpb24uIE90aGVyd2lzZSwgdXNlIHRoZVxuICAgKiB2ZXJzaW9uIG51bWJlciAoZS5nLiAxKS5cbiAgICogQGRlZmF1bHQgJ0RSQUZUJ1xuICAgKi9cbiAgcmVhZG9ubHkgYWdlbnRWZXJzaW9uPzogc3RyaW5nO1xufVxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBORVcgQ09OU1RSVUNUIERFRklOSVRJT05cbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogQ2xhc3MgdG8gY3JlYXRlIChvciBpbXBvcnQpIGFuIEFnZW50IHdpdGggQ0RLLlxuICogQGNsb3VkZm9ybWF0aW9uUmVzb3VyY2UgQVdTOjpCZWRyb2NrOjpBZ2VudFxuICovXG5AcHJvcGVydHlJbmplY3RhYmxlXG5leHBvcnQgY2xhc3MgQWdlbnQgZXh0ZW5kcyBBZ2VudEJhc2UgaW1wbGVtZW50cyBJQWdlbnQge1xuICAvKiogVW5pcXVlbHkgaWRlbnRpZmllcyB0aGlzIGNsYXNzLiAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFBST1BFUlRZX0lOSkVDVElPTl9JRDogc3RyaW5nID0gJ0Bhd3MtY2RrLmF3cy1iZWRyb2NrLWFscGhhLkFnZW50JztcblxuICAvKipcbiAgICogU3RhdGljIE1ldGhvZCBmb3IgaW1wb3J0aW5nIGFuIGV4aXN0aW5nIEJlZHJvY2sgQWdlbnQuXG4gICAqL1xuICAvKipcbiAgICogQ3JlYXRlcyBhbiBBZ2VudCByZWZlcmVuY2UgZnJvbSBhbiBleGlzdGluZyBhZ2VudCdzIGF0dHJpYnV0ZXMuXG4gICAqXG4gICAqIEBwYXJhbSBzY29wZSAtIFRoZSBjb25zdHJ1Y3Qgc2NvcGVcbiAgICogQHBhcmFtIGlkIC0gSWRlbnRpZmllciBvZiB0aGUgY29uc3RydWN0XG4gICAqIEBwYXJhbSBhdHRycyAtIEF0dHJpYnV0ZXMgb2YgdGhlIGV4aXN0aW5nIGFnZW50XG4gICAqIEBkZWZhdWx0IC0gRm9yIGF0dHJzLmFnZW50VmVyc2lvbjogJ0RSQUZUJyBpZiBubyBleHBsaWNpdCB2ZXJzaW9uIGlzIHByb3ZpZGVkXG4gICAqIEByZXR1cm5zIEFuIElBZ2VudCByZWZlcmVuY2UgdG8gdGhlIGV4aXN0aW5nIGFnZW50XG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21BZ2VudEF0dHJpYnV0ZXMoc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgYXR0cnM6IEFnZW50QXR0cmlidXRlcyk6IElBZ2VudCB7XG4gICAgY2xhc3MgSW1wb3J0IGV4dGVuZHMgQWdlbnRCYXNlIHtcbiAgICAgIHB1YmxpYyByZWFkb25seSBhZ2VudEFybiA9IGF0dHJzLmFnZW50QXJuO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGFnZW50SWQgPSBBcm4uc3BsaXQoYXR0cnMuYWdlbnRBcm4sIEFybkZvcm1hdC5TTEFTSF9SRVNPVVJDRV9OQU1FKS5yZXNvdXJjZU5hbWUhO1xuICAgICAgcHVibGljIHJlYWRvbmx5IHJvbGUgPSBpYW0uUm9sZS5mcm9tUm9sZUFybihzY29wZSwgYCR7aWR9Um9sZWAsIGF0dHJzLnJvbGVBcm4pO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGttc0tleSA9IGF0dHJzLmttc0tleUFybiA/IGttcy5LZXkuZnJvbUtleUFybihzY29wZSwgYCR7aWR9S2V5YCwgYXR0cnMua21zS2V5QXJuKSA6IHVuZGVmaW5lZDtcbiAgICAgIHB1YmxpYyByZWFkb25seSBsYXN0VXBkYXRlZCA9IGF0dHJzLmxhc3RVcGRhdGVkO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGFnZW50VmVyc2lvbiA9IGF0dHJzLmFnZW50VmVyc2lvbiA/PyAnRFJBRlQnO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGdyYW50UHJpbmNpcGFsID0gdGhpcy5yb2xlO1xuICAgIH1cblxuICAgIC8vIFJldHVybiBuZXcgQWdlbnRcbiAgICByZXR1cm4gbmV3IEltcG9ydChzY29wZSwgaWQpO1xuICB9XG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBCYXNlIGF0dHJpYnV0ZXNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBUaGUgdW5pcXVlIGlkZW50aWZpZXIgZm9yIHRoZSBhZ2VudFxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgYWdlbnRJZDogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgYWdlbnQuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBhZ2VudEFybjogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHZlcnNpb24gb2YgdGhlIGFnZW50LlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgYWdlbnRWZXJzaW9uOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgSUFNIHJvbGUgYXNzb2NpYXRlZCB0byB0aGUgYWdlbnQuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgcm9sZTogaWFtLklSb2xlO1xuICAvKipcbiAgICogT3B0aW9uYWwgS01TIGVuY3J5cHRpb24ga2V5IGFzc29jaWF0ZWQgd2l0aCB0aGlzIGFnZW50XG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkga21zS2V5Pzoga21zLklLZXk7XG4gIC8qKlxuICAgKiBXaGVuIHRoaXMgYWdlbnQgd2FzIGxhc3QgdXBkYXRlZC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBsYXN0VXBkYXRlZD86IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBwcmluY2lwYWwgdG8gZ3JhbnQgcGVybWlzc2lvbnMgdG9cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBncmFudFByaW5jaXBhbDogaWFtLklQcmluY2lwYWw7XG4gIC8qKlxuICAgKiBEZWZhdWx0IGFsaWFzIG9mIHRoZSBhZ2VudFxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHRlc3RBbGlhczogSUFnZW50QWxpYXM7XG4gIC8qKlxuICAgKiBhY3Rpb24gZ3JvdXBzIGFzc29jaWF0ZWQgd2l0aCB0aGUgYWdlbnlcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBhY3Rpb25Hcm91cHM6IEFnZW50QWN0aW9uR3JvdXBbXSA9IFtdO1xuICAvKipcbiAgICogVGhlIGd1YXJkcmFpbCB0aGF0IHdpbGwgYmUgYXNzb2NpYXRlZCB3aXRoIHRoZSBhZ2VudC5cbiAgICovXG4gIHB1YmxpYyBndWFyZHJhaWw/OiBJR3VhcmRyYWlsO1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQ0RLLW9ubHkgYXR0cmlidXRlc1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBhZ2VudC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEludGVybmFsIE9ubHlcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIHByaXZhdGUgcmVhZG9ubHkgUk9MRV9OQU1FX1NVRkZJWCA9ICctYmVkcm9ja2FnZW50JztcbiAgcHJpdmF0ZSByZWFkb25seSBNQVhMRU5HVEhfRk9SX1JPTEVfTkFNRSA9IDY0O1xuICBwcml2YXRlIHJlYWRvbmx5IGlkbGVTZXNzaW9uVFRMOiBEdXJhdGlvbjtcbiAgcHJpdmF0ZSByZWFkb25seSBmb3VuZGF0aW9uTW9kZWw6IElCZWRyb2NrSW52b2thYmxlO1xuICBwcml2YXRlIHJlYWRvbmx5IHVzZXJJbnB1dEVuYWJsZWQ6IGJvb2xlYW47XG4gIHByaXZhdGUgcmVhZG9ubHkgY29kZUludGVycHJldGVyRW5hYmxlZDogYm9vbGVhbjtcbiAgcHJpdmF0ZSByZWFkb25seSBhZ2VudENvbGxhYm9yYXRpb24/OiBBZ2VudENvbGxhYm9yYXRpb247XG4gIHByaXZhdGUgcmVhZG9ubHkgY3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yPzogQ3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yO1xuICBwcml2YXRlIHJlYWRvbmx5IHByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbj86IFByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbjtcbiAgcHJpdmF0ZSByZWFkb25seSBfX3Jlc291cmNlOiBiZWRyb2NrLkNmbkFnZW50O1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBDT05TVFJVQ1RPUlxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM6IEFnZW50UHJvcHMpIHtcbiAgICBzdXBlcihzY29wZSwgaWQpO1xuICAgIC8vIEVuaGFuY2VkIENESyBBbmFseXRpY3MgVGVsZW1ldHJ5XG4gICAgYWRkQ29uc3RydWN0TWV0YWRhdGEodGhpcywgcHJvcHMpO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gVmFsaWRhdGUgcHJvcHNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBpZiAocHJvcHMuaW5zdHJ1Y3Rpb24gIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKHByb3BzLmluc3RydWN0aW9uKSAmJlxuICAgICAgICBwcm9wcy5pbnN0cnVjdGlvbi5sZW5ndGggPCBNSU5fSU5TVFJVQ1RJT05fTEVOR1RIKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnN0cnVjdGlvblRvb1Nob3J0JywgYGluc3RydWN0aW9uIG11c3QgYmUgYXQgbGVhc3QgJHtNSU5fSU5TVFJVQ1RJT05fTEVOR1RIfSBjaGFyYWN0ZXJzYCwgdGhpcyk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgaWRsZVNlc3Npb25UVExcbiAgICBpZiAocHJvcHMuaWRsZVNlc3Npb25UVEwgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKHByb3BzLmlkbGVTZXNzaW9uVFRMKSAmJlxuICAgICAgICAocHJvcHMuaWRsZVNlc3Npb25UVEwudG9NaW51dGVzKCkgPCAxIHx8IHByb3BzLmlkbGVTZXNzaW9uVFRMLnRvTWludXRlcygpID4gNjApKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJZGxlU2Vzc2lvblR0bE91dE9mUmFuZ2UnLCAnaWRsZVNlc3Npb25UVEwgbXVzdCBiZSBiZXR3ZWVuIDEgYW5kIDYwIG1pbnV0ZXMnLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBTZXQgcHJvcGVydGllcyBhbmQgZGVmYXVsdHNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLm5hbWUgPVxuICAgICAgcHJvcHMuYWdlbnROYW1lID8/IHRoaXMuZ2VuZXJhdGVQaHlzaWNhbE5hbWUoKSArIHRoaXMuUk9MRV9OQU1FX1NVRkZJWDtcbiAgICB0aGlzLmlkbGVTZXNzaW9uVFRMID0gcHJvcHMuaWRsZVNlc3Npb25UVEwgPz8gRHVyYXRpb24ubWludXRlcygxMCk7XG4gICAgdGhpcy51c2VySW5wdXRFbmFibGVkID0gcHJvcHMudXNlcklucHV0RW5hYmxlZCA/PyBmYWxzZTtcbiAgICB0aGlzLmNvZGVJbnRlcnByZXRlckVuYWJsZWQgPSBwcm9wcy5jb2RlSW50ZXJwcmV0ZXJFbmFibGVkID8/IGZhbHNlO1xuICAgIHRoaXMuZm91bmRhdGlvbk1vZGVsID0gcHJvcHMuZm91bmRhdGlvbk1vZGVsO1xuICAgIC8vIE9wdGlvbmFsXG4gICAgdGhpcy5wcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb24gPSBwcm9wcy5wcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb247XG4gICAgdGhpcy5rbXNLZXkgPSBwcm9wcy5rbXNLZXk7XG4gICAgdGhpcy5jdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3IgPSBwcm9wcy5jdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3I7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBSb2xlXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gSWYgZXhpc3Rpbmcgcm9sZSBpcyBwcm92aWRlZCwgdXNlIGl0LlxuICAgIGlmIChwcm9wcy5leGlzdGluZ1JvbGUpIHtcbiAgICAgIHRoaXMucm9sZSA9IHByb3BzLmV4aXN0aW5nUm9sZTtcbiAgICAgIHRoaXMuZ3JhbnRQcmluY2lwYWwgPSB0aGlzLnJvbGU7XG4gICAgICAvLyBPdGhlcndpc2UsIGNyZWF0ZSBhIG5ldyBvbmVcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5yb2xlID0gbmV3IGlhbS5Sb2xlKHRoaXMsICdSb2xlJywge1xuICAgICAgICAvLyBnZW5lcmF0ZSBhIHJvbGUgbmFtZVxuICAgICAgICByb2xlTmFtZTogdGhpcy5nZW5lcmF0ZVBoeXNpY2FsTmFtZSgpICsgdGhpcy5ST0xFX05BTUVfU1VGRklYLFxuICAgICAgICAvLyBlbnN1cmUgdGhlIHJvbGUgaGFzIGEgdHJ1c3QgcG9saWN5IHRoYXQgYWxsb3dzIHRoZSBCZWRyb2NrIHNlcnZpY2UgdG8gYXNzdW1lIHRoZSByb2xlXG4gICAgICAgIGFzc3VtZWRCeTogbmV3IGlhbS5TZXJ2aWNlUHJpbmNpcGFsKCdiZWRyb2NrLmFtYXpvbmF3cy5jb20nKS53aXRoQ29uZGl0aW9ucyh7XG4gICAgICAgICAgU3RyaW5nRXF1YWxzOiB7XG4gICAgICAgICAgICAnYXdzOlNvdXJjZUFjY291bnQnOiB7IFJlZjogJ0FXUzo6QWNjb3VudElkJyB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgQXJuTGlrZToge1xuICAgICAgICAgICAgJ2F3czpTb3VyY2VBcm4nOiBTdGFjay5vZih0aGlzKS5mb3JtYXRBcm4oe1xuICAgICAgICAgICAgICBzZXJ2aWNlOiAnYmVkcm9jaycsXG4gICAgICAgICAgICAgIHJlc291cmNlOiAnYWdlbnQnLFxuICAgICAgICAgICAgICByZXNvdXJjZU5hbWU6ICcqJyxcbiAgICAgICAgICAgICAgYXJuRm9ybWF0OiBBcm5Gb3JtYXQuU0xBU0hfUkVTT1VSQ0VfTkFNRSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmdyYW50UHJpbmNpcGFsID0gdGhpcy5yb2xlO1xuICAgIH1cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBTZXQgTGF6eSBQcm9wcyBpbml0aWFsIHZhbHVlc1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIEFkZCBEZWZhdWx0IEFjdGlvbiBHcm91cHNcbiAgICB0aGlzLmFkZEFjdGlvbkdyb3VwKEFnZW50QWN0aW9uR3JvdXAudXNlcklucHV0KHRoaXMudXNlcklucHV0RW5hYmxlZCkpO1xuICAgIHRoaXMuYWRkQWN0aW9uR3JvdXAoQWdlbnRBY3Rpb25Hcm91cC5jb2RlSW50ZXJwcmV0ZXIodGhpcy5jb2RlSW50ZXJwcmV0ZXJFbmFibGVkKSk7XG5cbiAgICAvLyBBZGQgc3BlY2lmaWVkIGVsZW1zIHRocm91Z2ggbWV0aG9kcyB0byBoYW5kbGUgcGVybWlzc2lvbnNcbiAgICAvLyB0aGlzIG5lZWRzIHRvIGhhcHBlbiBhZnRlciByb2xlIGNyZWF0aW9uIC8gYXNzaWdubWVudFxuICAgIHByb3BzLmFjdGlvbkdyb3Vwcz8uZm9yRWFjaChhZyA9PiB7XG4gICAgICB0aGlzLmFkZEFjdGlvbkdyb3VwKGFnKTtcbiAgICB9KTtcblxuICAgIC8vIFNldCBhZ2VudCBjb2xsYWJvcmF0aW9uIGNvbmZpZ3VyYXRpb25cbiAgICB0aGlzLmFnZW50Q29sbGFib3JhdGlvbiA9IHByb3BzLmFnZW50Q29sbGFib3JhdGlvbjtcbiAgICBpZiAocHJvcHMuYWdlbnRDb2xsYWJvcmF0aW9uKSB7XG4gICAgICBwcm9wcy5hZ2VudENvbGxhYm9yYXRpb24uY29sbGFib3JhdG9ycy5mb3JFYWNoKGFjID0+IHtcbiAgICAgICAgdGhpcy5ncmFudFBlcm1pc3Npb25Ub0FnZW50KGFjKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGlmIChwcm9wcy5ndWFyZHJhaWwpIHtcbiAgICAgIHRoaXMuYWRkR3VhcmRyYWlsKHByb3BzLmd1YXJkcmFpbCk7XG4gICAgfVxuXG4gICAgLy8gR3JhbnQgcGVybWlzc2lvbnMgZm9yIGN1c3RvbSBvcmNoZXN0cmF0aW9uIGlmIHByb3ZpZGVkXG4gICAgaWYgKHRoaXMuY3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yPy5sYW1iZGFGdW5jdGlvbikge1xuICAgICAgdGhpcy5jdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3IubGFtYmRhRnVuY3Rpb24uZ3JhbnRJbnZva2UodGhpcy5yb2xlKTtcbiAgICAgIHRoaXMuY3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yLmxhbWJkYUZ1bmN0aW9uLmFkZFBlcm1pc3Npb24oYE9yY2hlc3RyYXRpb25MYW1iZGFJbnZvY2F0aW9uUG9saWN5LSR7dGhpcy5ub2RlLmFkZHIuc2xpY2UoMCwgTUFYX1BPTElDWV9OQU1FX05PREVfTEVOR1RIKX1gLCB7XG4gICAgICAgIHByaW5jaXBhbDogbmV3IGlhbS5TZXJ2aWNlUHJpbmNpcGFsKCdiZWRyb2NrLmFtYXpvbmF3cy5jb20nKSxcbiAgICAgICAgc291cmNlQXJuOiBMYXp5LnN0cmluZyh7IHByb2R1Y2U6ICgpID0+IHRoaXMuYWdlbnRBcm4gfSksXG4gICAgICAgIHNvdXJjZUFjY291bnQ6IHsgUmVmOiAnQVdTOjpBY2NvdW50SWQnIH0gYXMgYW55LFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gQ0ZOIFByb3BzIC0gV2l0aCBMYXp5IHN1cHBvcnRcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBjb25zdCBjZm5Qcm9wczogYmVkcm9jay5DZm5BZ2VudFByb3BzID0ge1xuICAgICAgYWN0aW9uR3JvdXBzOiBMYXp5LmFueSh7IHByb2R1Y2U6ICgpID0+IHRoaXMucmVuZGVyQWN0aW9uR3JvdXBzKCkgfSwgeyBvbWl0RW1wdHlBcnJheTogdHJ1ZSB9KSxcbiAgICAgIGFnZW50TmFtZTogdGhpcy5uYW1lLFxuICAgICAgYWdlbnRSZXNvdXJjZVJvbGVBcm46IHRoaXMucm9sZS5yb2xlQXJuLFxuICAgICAgYXV0b1ByZXBhcmU6IHByb3BzLnNob3VsZFByZXBhcmVBZ2VudCA/PyBmYWxzZSxcbiAgICAgIGN1c3RvbWVyRW5jcnlwdGlvbktleUFybjogcHJvcHMua21zS2V5Py5rZXlBcm4sXG4gICAgICBkZXNjcmlwdGlvbjogcHJvcHMuZGVzY3JpcHRpb24sXG4gICAgICBmb3VuZGF0aW9uTW9kZWw6IHRoaXMuZm91bmRhdGlvbk1vZGVsLmludm9rYWJsZUFybixcbiAgICAgIGd1YXJkcmFpbENvbmZpZ3VyYXRpb246IExhenkuYW55KHsgcHJvZHVjZTogKCkgPT4gdGhpcy5yZW5kZXJHdWFyZHJhaWwoKSB9KSxcbiAgICAgIGlkbGVTZXNzaW9uVHRsSW5TZWNvbmRzOiB0aGlzLmlkbGVTZXNzaW9uVFRMLnRvU2Vjb25kcygpLFxuICAgICAgaW5zdHJ1Y3Rpb246IHByb3BzLmluc3RydWN0aW9uLFxuICAgICAgbWVtb3J5Q29uZmlndXJhdGlvbjogcHJvcHMubWVtb3J5Py5fcmVuZGVyKCksXG4gICAgICBwcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb246IHRoaXMucHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uPy5fcmVuZGVyKCksXG4gICAgICBza2lwUmVzb3VyY2VJblVzZUNoZWNrT25EZWxldGU6IHByb3BzLmZvcmNlRGVsZXRlID8/IGZhbHNlLFxuICAgICAgYWdlbnRDb2xsYWJvcmF0aW9uOiBwcm9wcy5hZ2VudENvbGxhYm9yYXRpb24/LnR5cGUsXG4gICAgICBhZ2VudENvbGxhYm9yYXRvcnM6IExhenkuYW55KHsgcHJvZHVjZTogKCkgPT4gdGhpcy5yZW5kZXJBZ2VudENvbGxhYm9yYXRvcnMoKSB9LCB7IG9taXRFbXB0eUFycmF5OiB0cnVlIH0pLFxuICAgICAgY3VzdG9tT3JjaGVzdHJhdGlvbjogdGhpcy5yZW5kZXJDdXN0b21PcmNoZXN0cmF0aW9uKCksXG4gICAgICBvcmNoZXN0cmF0aW9uVHlwZTogdGhpcy5jdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3IgPyBPcmNoZXN0cmF0aW9uVHlwZS5DVVNUT01fT1JDSEVTVFJBVElPTiA6IE9yY2hlc3RyYXRpb25UeXBlLkRFRkFVTFQsXG4gICAgfTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIEwxIEluc3RhbnRpYXRpb25cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLl9fcmVzb3VyY2UgPSBuZXcgYmVkcm9jay5DZm5BZ2VudCh0aGlzLCAnUmVzb3VyY2UnLCBjZm5Qcm9wcyk7XG5cbiAgICB0aGlzLmFnZW50SWQgPSB0aGlzLl9fcmVzb3VyY2UuYXR0ckFnZW50SWQ7XG4gICAgdGhpcy5hZ2VudEFybiA9IHRoaXMuX19yZXNvdXJjZS5hdHRyQWdlbnRBcm47XG4gICAgdGhpcy5hZ2VudFZlcnNpb24gPSB0aGlzLl9fcmVzb3VyY2UuYXR0ckFnZW50VmVyc2lvbjtcbiAgICB0aGlzLmxhc3RVcGRhdGVkID0gdGhpcy5fX3Jlc291cmNlLmF0dHJVcGRhdGVkQXQ7XG5cbiAgICAvLyBBZGQgZXhwbGljaXQgZGVwZW5kZW5jeSBiZXR3ZWVuIHRoZSBhZ2VudCByZXNvdXJjZSBhbmQgdGhlIGFnZW50J3Mgcm9sZSBkZWZhdWx0IHBvbGljeVxuICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vYXdzbGFicy9nZW5lcmF0aXZlLWFpLWNkay1jb25zdHJ1Y3RzL2lzc3Vlcy84OTlcbiAgICBjb25zdCBncmFudCA9IHRoaXMuZm91bmRhdGlvbk1vZGVsLmdyYW50SW52b2tlKHRoaXMucm9sZSk7XG4gICAgZ3JhbnQuYXBwbHlCZWZvcmUodGhpcy5fX3Jlc291cmNlKTtcblxuICAgIHRoaXMudGVzdEFsaWFzID0gQWdlbnRBbGlhcy5mcm9tQXR0cmlidXRlcyh0aGlzLCAnRGVmYXVsdEFsaWFzJywge1xuICAgICAgYWxpYXNJZDogJ1RTVEFMSUFTSUQnLFxuICAgICAgYWxpYXNOYW1lOiAnQWdlbnRUZXN0QWxpYXMnLFxuICAgICAgYWdlbnRWZXJzaW9uOiAnRFJBRlQnLFxuICAgICAgYWdlbnQ6IHRoaXMsXG4gICAgfSk7XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gSEVMUEVSIE1FVEhPRFMgLSBhZGRYKClcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgLyoqXG4gICAqIEFkZCBndWFyZHJhaWwgdG8gdGhlIGFnZW50LlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGFkZEd1YXJkcmFpbChndWFyZHJhaWw6IElHdWFyZHJhaWwpIHtcbiAgICAvLyBEbyBzb21lIGNoZWNrc1xuICAgIHZhbGlkYXRpb24udGhyb3dJZkludmFsaWQodGhpcy52YWxpZGF0ZUd1YXJkcmFpbCwgZ3VhcmRyYWlsKTtcbiAgICAvLyBBZGQgaXQgdG8gdGhlIGNvbnN0cnVjdFxuICAgIHRoaXMuZ3VhcmRyYWlsID0gZ3VhcmRyYWlsO1xuICAgIC8vIEhhbmRsZSBwZXJtaXNzaW9uc1xuICAgIGd1YXJkcmFpbC5ncmFudEFwcGx5KHRoaXMucm9sZSk7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhbiBhY3Rpb24gZ3JvdXAgdG8gdGhlIGFnZW50IGFuZCBjb25maWd1cmVzIG5lY2Vzc2FyeSBwZXJtaXNzaW9ucy5cbiAgICpcbiAgICogQHBhcmFtIGFjdGlvbkdyb3VwIC0gVGhlIGFjdGlvbiBncm91cCB0byBhZGRcbiAgICogQGRlZmF1bHQgLSBEZWZhdWx0IHBlcm1pc3Npb25zOlxuICAgKiAtIExhbWJkYSBmdW5jdGlvbiBpbnZva2UgcGVybWlzc2lvbnMgaWYgZXhlY3V0b3IgaXMgcHJlc2VudFxuICAgKiAtIFMzIEdldE9iamVjdCBwZXJtaXNzaW9ucyBpZiBhcGlTY2hlbWEuczNGaWxlIGlzIHByZXNlbnRcbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBhZGRBY3Rpb25Hcm91cChhY3Rpb25Hcm91cDogQWdlbnRBY3Rpb25Hcm91cCkge1xuICAgIHZhbGlkYXRpb24udGhyb3dJZkludmFsaWQodGhpcy52YWxpZGF0ZUFjdGlvbkdyb3VwLCBhY3Rpb25Hcm91cCk7XG4gICAgdGhpcy5hY3Rpb25Hcm91cHMucHVzaChhY3Rpb25Hcm91cCk7XG4gICAgLy8gSGFuZGxlIHBlcm1pc3Npb25zIHRvIGludm9rZSB0aGUgbGFtYmRhIGZ1bmN0aW9uXG4gICAgYWN0aW9uR3JvdXAuZXhlY3V0b3I/LmxhbWJkYUZ1bmN0aW9uPy5ncmFudEludm9rZSh0aGlzLnJvbGUpO1xuICAgIGFjdGlvbkdyb3VwLmV4ZWN1dG9yPy5sYW1iZGFGdW5jdGlvbj8uYWRkUGVybWlzc2lvbihgTGFtYmRhSW52b2NhdGlvblBvbGljeS0ke3RoaXMubm9kZS5hZGRyLnNsaWNlKDAsIE1BWF9QT0xJQ1lfTkFNRV9OT0RFX0xFTkdUSCl9YCwge1xuICAgICAgcHJpbmNpcGFsOiBuZXcgaWFtLlNlcnZpY2VQcmluY2lwYWwoJ2JlZHJvY2suYW1hem9uYXdzLmNvbScpLFxuICAgICAgc291cmNlQXJuOiB0aGlzLmFnZW50QXJuLFxuICAgICAgc291cmNlQWNjb3VudDogeyBSZWY6ICdBV1M6OkFjY291bnRJZCcgfSBhcyBhbnksXG4gICAgfSk7XG4gICAgLy8gSGFuZGxlIHBlcm1pc3Npb25zIHRvIGFjY2VzcyB0aGUgc2NoZW1hIGZpbGUgZnJvbSBTM1xuICAgIGlmIChhY3Rpb25Hcm91cC5hcGlTY2hlbWEgaW5zdGFuY2VvZiBBc3NldEFwaVNjaGVtYSkge1xuICAgICAgY29uc3QgcmVuZGVyZWQgPSBhY3Rpb25Hcm91cC5hcGlTY2hlbWEuX3JlbmRlcigpO1xuICAgICAgaWYgKCEoJ3MzJyBpbiByZW5kZXJlZCkgfHwgIXJlbmRlcmVkLnMzKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ1MzQ29uZmlnTWlzc2luZycsICdTMyBjb25maWd1cmF0aW9uIGlzIG1pc3NpbmcgaW4gQXNzZXRBcGlTY2hlbWEnLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHMzQ29uZmlnID0gcmVuZGVyZWQuczM7XG4gICAgICBpZiAoISgnczNCdWNrZXROYW1lJyBpbiBzM0NvbmZpZykgfHwgISgnczNPYmplY3RLZXknIGluIHMzQ29uZmlnKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdTM0J1Y2tldE9yS2V5TWlzc2luZycsICdTMyBidWNrZXQgbmFtZSBhbmQgb2JqZWN0IGtleSBhcmUgcmVxdWlyZWQgaW4gQXNzZXRBcGlTY2hlbWEnLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGJ1Y2tldE5hbWUgPSBzM0NvbmZpZy5zM0J1Y2tldE5hbWU7XG4gICAgICBjb25zdCBvYmplY3RLZXkgPSBzM0NvbmZpZy5zM09iamVjdEtleTtcbiAgICAgIGlmICghYnVja2V0TmFtZSB8fCBidWNrZXROYW1lLnRyaW0oKSA9PT0gJycpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignUzNCdWNrZXROYW1lRW1wdHknLCAnUzMgYnVja2V0IG5hbWUgY2Fubm90IGJlIGVtcHR5IGluIEFzc2V0QXBpU2NoZW1hJywgdGhpcyk7XG4gICAgICB9XG4gICAgICBpZiAoIW9iamVjdEtleSB8fCBvYmplY3RLZXkudHJpbSgpID09PSAnJykge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdTM09iamVjdEtleUVtcHR5JywgJ1MzIG9iamVjdCBrZXkgY2Fubm90IGJlIGVtcHR5IGluIEFzc2V0QXBpU2NoZW1hJywgdGhpcyk7XG4gICAgICB9XG4gICAgICBjb25zdCBidWNrZXQgPSBzMy5CdWNrZXQuZnJvbUJ1Y2tldE5hbWUodGhpcywgYCR7YWN0aW9uR3JvdXAubmFtZX1TY2hlbWFCdWNrZXRgLCBidWNrZXROYW1lKTtcbiAgICAgIGJ1Y2tldC5ncmFudFJlYWQodGhpcy5yb2xlLCBvYmplY3RLZXkpO1xuICAgIH0gZWxzZSBpZiAoYWN0aW9uR3JvdXAuYXBpU2NoZW1hIGluc3RhbmNlb2YgUzNBcGlTY2hlbWEpIHtcbiAgICAgIGNvbnN0IHMzRmlsZSA9IGFjdGlvbkdyb3VwLmFwaVNjaGVtYS5zM0ZpbGU7XG4gICAgICBpZiAoIXMzRmlsZSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdTM0ZpbGVNaXNzaW5nJywgJ1MzIGZpbGUgY29uZmlndXJhdGlvbiBpcyBtaXNzaW5nIGluIFMzQXBpU2NoZW1hJywgdGhpcyk7XG4gICAgICB9XG4gICAgICBpZiAoIXMzRmlsZS5idWNrZXROYW1lIHx8IHMzRmlsZS5idWNrZXROYW1lLnRyaW0oKSA9PT0gJycpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignUzNCdWNrZXROYW1lRW1wdHknLCAnUzMgYnVja2V0IG5hbWUgY2Fubm90IGJlIGVtcHR5IGluIFMzQXBpU2NoZW1hJywgdGhpcyk7XG4gICAgICB9XG4gICAgICBpZiAoIXMzRmlsZS5vYmplY3RLZXkgfHwgczNGaWxlLm9iamVjdEtleS50cmltKCkgPT09ICcnKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ1MzT2JqZWN0S2V5RW1wdHknLCAnUzMgb2JqZWN0IGtleSBjYW5ub3QgYmUgZW1wdHkgaW4gUzNBcGlTY2hlbWEnLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGJ1Y2tldCA9IHMzLkJ1Y2tldC5mcm9tQnVja2V0TmFtZSh0aGlzLCBgJHthY3Rpb25Hcm91cC5uYW1lfVNjaGVtYUJ1Y2tldGAsIHMzRmlsZS5idWNrZXROYW1lKTtcbiAgICAgIGJ1Y2tldC5ncmFudFJlYWQodGhpcy5yb2xlLCBzM0ZpbGUub2JqZWN0S2V5KTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogR3JhbnRzIHBlcm1pc3Npb25zIGZvciBhbiBhZ2VudCBjb2xsYWJvcmF0b3IgdG8gdGhpcyBhZ2VudCdzIHJvbGUuXG4gICAqIFRoaXMgbWV0aG9kIG9ubHkgZ3JhbnRzIElBTSBwZXJtaXNzaW9ucyBhbmQgZG9lcyBub3QgYWRkIHRoZSBjb2xsYWJvcmF0b3JcbiAgICogdG8gdGhlIGFnZW50J3MgY29sbGFib3JhdGlvbiBjb25maWd1cmF0aW9uLiBUbyBhZGQgY29sbGFib3JhdG9ycyB0byB0aGVcbiAgICogYWdlbnQgY29uZmlndXJhdGlvbiwgaW5jbHVkZSB0aGVtIGluIHRoZSBBZ2VudENvbGxhYm9yYXRpb24gd2hlbiBjcmVhdGluZyB0aGUgYWdlbnQuXG4gICAqXG4gICAqIEBwYXJhbSBhZ2VudENvbGxhYm9yYXRvciAtIFRoZSBjb2xsYWJvcmF0b3IgdG8gZ3JhbnQgcGVybWlzc2lvbnMgZm9yXG4gICAqL1xuICBwcml2YXRlIGdyYW50UGVybWlzc2lvblRvQWdlbnQoYWdlbnRDb2xsYWJvcmF0b3I6IEFnZW50Q29sbGFib3JhdG9yKSB7XG4gICAgYWdlbnRDb2xsYWJvcmF0b3IuZ3JhbnQodGhpcy5yb2xlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciBhZ2VudCBjb2xsYWJvcmF0aW9uLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIE5vIGNvbGxhYm9yYXRpb24gY29uZmlndXJhdGlvbi5cbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBhZGRBY3Rpb25Hcm91cHMoLi4uYWN0aW9uR3JvdXBzOiBBZ2VudEFjdGlvbkdyb3VwW10pIHtcbiAgICBhY3Rpb25Hcm91cHMuZm9yRWFjaChhZyA9PiB0aGlzLmFkZEFjdGlvbkdyb3VwKGFnKSk7XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gTGF6eSBSZW5kZXJlcnNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgLyoqXG4gICAqIFJlbmRlciB0aGUgZ3VhcmRyYWlsIGNvbmZpZ3VyYXRpb24uXG4gICAqXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHJpdmF0ZSByZW5kZXJHdWFyZHJhaWwoKTogYmVkcm9jay5DZm5BZ2VudC5HdWFyZHJhaWxDb25maWd1cmF0aW9uUHJvcGVydHkgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiB0aGlzLmd1YXJkcmFpbFxuICAgICAgPyB7XG4gICAgICAgIGd1YXJkcmFpbElkZW50aWZpZXI6IHRoaXMuZ3VhcmRyYWlsLmd1YXJkcmFpbElkLFxuICAgICAgICBndWFyZHJhaWxWZXJzaW9uOiB0aGlzLmd1YXJkcmFpbC5ndWFyZHJhaWxWZXJzaW9uLFxuICAgICAgfVxuICAgICAgOiB1bmRlZmluZWQ7XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVyIHRoZSBhY3Rpb24gZ3JvdXBzXG4gICAqXG4gICAqIEByZXR1cm5zIEFycmF5IG9mIEFnZW50QWN0aW9uR3JvdXBQcm9wZXJ0eSBvYmplY3RzIGluIENsb3VkRm9ybWF0aW9uIGZvcm1hdFxuICAgKiBAZGVmYXVsdCAtIEVtcHR5IGFycmF5IGlmIG5vIGFjdGlvbiBncm91cHMgYXJlIGRlZmluZWRcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwcml2YXRlIHJlbmRlckFjdGlvbkdyb3VwcygpOiBiZWRyb2NrLkNmbkFnZW50LkFnZW50QWN0aW9uR3JvdXBQcm9wZXJ0eVtdIHtcbiAgICBjb25zdCBhY3Rpb25Hcm91cHNDZm46IGJlZHJvY2suQ2ZuQWdlbnQuQWdlbnRBY3Rpb25Hcm91cFByb3BlcnR5W10gPSBbXTtcbiAgICAvLyBCdWlsZCB0aGUgYXNzb2NpYXRpb25zIGluIHRoZSBDRk4gZm9ybWF0XG4gICAgdGhpcy5hY3Rpb25Hcm91cHMuZm9yRWFjaChhZyA9PiB7XG4gICAgICBhY3Rpb25Hcm91cHNDZm4ucHVzaChhZy5fcmVuZGVyKCkpO1xuICAgIH0pO1xuICAgIHJldHVybiBhY3Rpb25Hcm91cHNDZm47XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVyIHRoZSBhZ2VudCBjb2xsYWJvcmF0b3JzLlxuICAgKlxuICAgKiBAcmV0dXJucyBBcnJheSBvZiBBZ2VudENvbGxhYm9yYXRvclByb3BlcnR5IG9iamVjdHMgaW4gQ2xvdWRGb3JtYXRpb24gZm9ybWF0LCBvciB1bmRlZmluZWQgaWYgbm8gY29sbGFib3JhdG9yc1xuICAgKiBAZGVmYXVsdCAtIHVuZGVmaW5lZCBpZiBubyBjb2xsYWJvcmF0b3JzIGFyZSBkZWZpbmVkIG9yIGFycmF5IGlzIGVtcHR5XG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHJpdmF0ZSByZW5kZXJBZ2VudENvbGxhYm9yYXRvcnMoKTogYmVkcm9jay5DZm5BZ2VudC5BZ2VudENvbGxhYm9yYXRvclByb3BlcnR5W10gfCB1bmRlZmluZWQge1xuICAgIGlmICghdGhpcy5hZ2VudENvbGxhYm9yYXRpb24gfHwgIXRoaXMuYWdlbnRDb2xsYWJvcmF0aW9uLmNvbGxhYm9yYXRvcnMgfHwgdGhpcy5hZ2VudENvbGxhYm9yYXRpb24uY29sbGFib3JhdG9ycy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuYWdlbnRDb2xsYWJvcmF0aW9uLmNvbGxhYm9yYXRvcnMubWFwKGFjID0+IGFjLl9yZW5kZXIoKSk7XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVyIHRoZSBjdXN0b20gb3JjaGVzdHJhdGlvbi5cbiAgICpcbiAgICogQHJldHVybnMgQ3VzdG9tT3JjaGVzdHJhdGlvblByb3BlcnR5IG9iamVjdCBpbiBDbG91ZEZvcm1hdGlvbiBmb3JtYXQsIG9yIHVuZGVmaW5lZCBpZiBubyBjdXN0b20gb3JjaGVzdHJhdGlvblxuICAgKiBAZGVmYXVsdCAtIHVuZGVmaW5lZCBpZiBubyBjdXN0b20gb3JjaGVzdHJhdGlvbiBpcyBkZWZpbmVkXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHJpdmF0ZSByZW5kZXJDdXN0b21PcmNoZXN0cmF0aW9uKCk6IGJlZHJvY2suQ2ZuQWdlbnQuQ3VzdG9tT3JjaGVzdHJhdGlvblByb3BlcnR5IHwgdW5kZWZpbmVkIHtcbiAgICBpZiAoIXRoaXMuY3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBleGVjdXRvcjoge1xuICAgICAgICBsYW1iZGE6IHRoaXMuY3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yLmxhbWJkYUZ1bmN0aW9uLmZ1bmN0aW9uQXJuLFxuICAgICAgfSxcbiAgICB9O1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIFZhbGlkYXRvcnNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBDaGVja3MgaWYgdGhlIEd1YXJkcmFpbCBpcyB2YWxpZFxuICAgKlxuICAgKiBAcGFyYW0gZ3VhcmRyYWlsIC0gVGhlIGd1YXJkcmFpbCB0byB2YWxpZGF0ZVxuICAgKiBAcmV0dXJucyBBcnJheSBvZiB2YWxpZGF0aW9uIGVycm9yIG1lc3NhZ2VzLCBlbXB0eSBpZiB2YWxpZFxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZUd1YXJkcmFpbCA9IChndWFyZHJhaWw6IElHdWFyZHJhaWwpID0+IHtcbiAgICBsZXQgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xuICAgIGlmICh0aGlzLmd1YXJkcmFpbCkge1xuICAgICAgZXJyb3JzLnB1c2goXG4gICAgICAgIGBDYW5ub3QgYWRkIEd1YXJkcmFpbCAke2d1YXJkcmFpbC5ndWFyZHJhaWxJZH0uIGAgK1xuICAgICAgICAgIGBHdWFyZHJhaWwgJHt0aGlzLmd1YXJkcmFpbC5ndWFyZHJhaWxJZH0gaGFzIGFscmVhZHkgYmVlbiBzcGVjaWZpZWQgZm9yIHRoaXMgYWdlbnQuYCxcbiAgICAgICk7XG4gICAgfVxuICAgIGVycm9ycy5wdXNoKC4uLnZhbGlkYXRpb24udmFsaWRhdGVGaWVsZFBhdHRlcm4oZ3VhcmRyYWlsLmd1YXJkcmFpbFZlcnNpb24sICd2ZXJzaW9uJywgL14oKFswLTldezEsOH0pfChEUkFGVCkpJC8pKTtcbiAgICByZXR1cm4gZXJyb3JzO1xuICB9O1xuXG4gIC8qKlxuICAgKiBDaGVjayBpZiB0aGUgYWN0aW9uIGdyb3VwIGlzIHZhbGlkXG4gICAqXG4gICAqIEBwYXJhbSBhY3Rpb25Hcm91cCAtIFRoZSBhY3Rpb24gZ3JvdXAgdG8gdmFsaWRhdGVcbiAgICogQHJldHVybnMgQXJyYXkgb2YgdmFsaWRhdGlvbiBlcnJvciBtZXNzYWdlcywgZW1wdHkgaWYgdmFsaWRcbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVBY3Rpb25Hcm91cCA9IChhY3Rpb25Hcm91cDogQWdlbnRBY3Rpb25Hcm91cCkgPT4ge1xuICAgIGxldCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG4gICAgLy8gRmluZCBpZiB0aGVyZSBpcyBhIGNvbmZsaWN0aW5nIGFjdGlvbiBncm91cCBuYW1lXG4gICAgaWYgKHRoaXMuYWN0aW9uR3JvdXBzPy5maW5kKGFnID0+IGFnLm5hbWUgPT09IGFjdGlvbkdyb3VwLm5hbWUpKSB7XG4gICAgICBlcnJvcnMucHVzaCgnQWN0aW9uIGdyb3VwIGFscmVhZHkgZXhpc3RzJyk7XG4gICAgfVxuICAgIHJldHVybiBlcnJvcnM7XG4gIH07XG5cbiAgLyoqXG4gICAqIEdlbmVyYXRlcyBhIHVuaXF1ZSwgZGV0ZXJtaW5pc3RpYyBuYW1lIGZvciBBV1MgcmVzb3VyY2VzIHRoYXQgaW5jbHVkZXMgYSBoYXNoIGNvbXBvbmVudC5cbiAgICogVGhpcyBtZXRob2QgZW5zdXJlcyBjb25zaXN0ZW50IG5hbWluZyB3aGlsZSBhdm9pZGluZyBjb25mbGljdHMgYW5kIGFkaGVyaW5nIHRvIEFXUyBuYW1pbmcgY29uc3RyYWludHMuXG4gICAqIEBwYXJhbSBzY29wZSAtIFRoZSBjb25zdHJ1Y3Qgc2NvcGUgdXNlZCBmb3IgZ2VuZXJhdGluZyB1bmlxdWUgbmFtZXNcbiAgICogQHBhcmFtIHByZWZpeCAtIFRoZSBwcmVmaXggdG8gcHJlcGVuZCB0byB0aGUgZ2VuZXJhdGVkIG5hbWVcbiAgICogQHBhcmFtIG9wdGlvbnMgLSBDb25maWd1cmF0aW9uIG9wdGlvbnMgZm9yIG5hbWUgZ2VuZXJhdGlvblxuICAgKiBAcGFyYW0gb3B0aW9ucy5tYXhMZW5ndGggLSBNYXhpbXVtIGxlbmd0aCBvZiB0aGUgZ2VuZXJhdGVkIG5hbWVcbiAgICogQGRlZmF1bHQgLSBtYXhMZW5ndGg6IDI1NlxuICAgKiBAcGFyYW0gb3B0aW9ucy5sb3dlciAtIENvbnZlcnQgdGhlIGdlbmVyYXRlZCBuYW1lIHRvIGxvd2VyY2FzZVxuICAgKiBAZGVmYXVsdCAtIGxvd2VyOiBmYWxzZVxuICAgKiBAcGFyYW0gb3B0aW9ucy5zZXBhcmF0b3IgLSBDaGFyYWN0ZXIocykgdG8gdXNlIGJldHdlZW4gbmFtZSBjb21wb25lbnRzXG4gICAqIEBkZWZhdWx0IC0gc2VwYXJhdG9yOiAnJ1xuICAgKiBAcGFyYW0gb3B0aW9ucy5hbGxvd2VkU3BlY2lhbENoYXJhY3RlcnMgLSBTdHJpbmcgb2YgYWxsb3dlZCBzcGVjaWFsIGNoYXJhY3RlcnNcbiAgICogQGRlZmF1bHQgLSB1bmRlZmluZWRcbiAgICogQHBhcmFtIG9wdGlvbnMuZGVzdHJveUNyZWF0ZSAtIE9iamVjdCB0byBpbmNsdWRlIGluIGhhc2ggZ2VuZXJhdGlvbiBmb3IgZGVzdHJveS9jcmVhdGUgb3BlcmF0aW9uc1xuICAgKiBAZGVmYXVsdCAtIHVuZGVmaW5lZFxuICAgKiBAcmV0dXJucyBBIHN0cmluZyBjb250YWluaW5nIHRoZSBnZW5lcmF0ZWQgbmFtZSB3aXRoIGZvcm1hdDogcHJlZml4ICsgaGFzaCArIHNlcGFyYXRvciArIHVuaXF1ZU5hbWVcbiAgICogQHRocm93cyBWYWxpZGF0aW9uRXJyb3IgaWYgdGhlIGdlbmVyYXRlZCBuYW1lIHdvdWxkIGV4Y2VlZCBtYXhMZW5ndGggb3IgaWYgcHJlZml4IGlzIHRvbyBsb25nXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgcHJpdmF0ZSBnZW5lcmF0ZVBoeXNpY2FsTmFtZUhhc2goXG4gICAgc2NvcGU6IElDb25zdHJ1Y3QsXG4gICAgcHJlZml4OiBzdHJpbmcsXG4gICAgb3B0aW9ucz86IHtcbiAgICAgIG1heExlbmd0aD86IG51bWJlcjtcbiAgICAgIGxvd2VyPzogYm9vbGVhbjtcbiAgICAgIHNlcGFyYXRvcj86IHN0cmluZztcbiAgICAgIGFsbG93ZWRTcGVjaWFsQ2hhcmFjdGVycz86IHN0cmluZztcbiAgICAgIGRlc3Ryb3lDcmVhdGU/OiBhbnk7XG4gICAgfSxcbiAgKTogc3RyaW5nIHtcbiAgICBjb25zdCBvYmplY3RUb0hhc2ggPSAob2JqOiBhbnkpOiBzdHJpbmcgPT4ge1xuICAgICAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiAnJzsgfVxuICAgICAgY29uc3QganNvblN0cmluZyA9IEpTT04uc3RyaW5naWZ5KG9iaik7XG4gICAgICBjb25zdCBoYXNoID0gY3J5cHRvLmNyZWF0ZUhhc2goJ3NoYTI1NicpO1xuICAgICAgcmV0dXJuIGhhc2gudXBkYXRlKGpzb25TdHJpbmcpLmRpZ2VzdCgnaGV4Jykuc2xpY2UoMCwgNyk7XG4gICAgfTtcblxuICAgIGNvbnN0IHtcbiAgICAgIG1heExlbmd0aCA9IDI1NixcbiAgICAgIGxvd2VyID0gZmFsc2UsXG4gICAgICBzZXBhcmF0b3IgPSAnJyxcbiAgICAgIGFsbG93ZWRTcGVjaWFsQ2hhcmFjdGVycyA9IHVuZGVmaW5lZCxcbiAgICAgIGRlc3Ryb3lDcmVhdGUgPSB1bmRlZmluZWQsXG4gICAgfSA9IG9wdGlvbnMgPz8ge307XG5cbiAgICBjb25zdCBoYXNoID0gb2JqZWN0VG9IYXNoKGRlc3Ryb3lDcmVhdGUpO1xuICAgIGlmIChtYXhMZW5ndGggPCAocHJlZml4ICsgaGFzaCArIHNlcGFyYXRvcikubGVuZ3RoKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdQcmVmaXhUb29Mb25nJywgJ1RoZSBwcmVmaXggaXMgbG9uZ2VyIHRoYW4gdGhlIG1heGltdW0gbGVuZ3RoLicsIHRoaXMpO1xuICAgIH1cblxuICAgIGNvbnN0IHVuaXF1ZU5hbWUgPSBOYW1lcy51bmlxdWVSZXNvdXJjZU5hbWUoXG4gICAgICBzY29wZSxcbiAgICAgIHsgbWF4TGVuZ3RoOiBtYXhMZW5ndGggLSAocHJlZml4ICsgaGFzaCArIHNlcGFyYXRvcikubGVuZ3RoLCBzZXBhcmF0b3IsIGFsbG93ZWRTcGVjaWFsQ2hhcmFjdGVycyB9LFxuICAgICk7XG4gICAgY29uc3QgbmFtZSA9IGAke3ByZWZpeH0ke2hhc2h9JHtzZXBhcmF0b3J9JHt1bmlxdWVOYW1lfWA7XG4gICAgaWYgKG5hbWUubGVuZ3RoID4gbWF4TGVuZ3RoKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdHZW5lcmF0ZWROYW1lVG9vTG9uZycsIGBUaGUgZ2VuZXJhdGVkIG5hbWUgaXMgbG9uZ2VyIHRoYW4gdGhlIG1heGltdW0gbGVuZ3RoIG9mICR7bWF4TGVuZ3RofWAsIHRoaXMpO1xuICAgIH1cbiAgICByZXR1cm4gbG93ZXIgPyBuYW1lLnRvTG93ZXJDYXNlKCkgOiBuYW1lO1xuICB9XG5cbiAgLyoqXG4gICAqIEdlbmVyYXRlcyBhIHBoeXNpY2FsIG5hbWUgZm9yIHRoZSBhZ2VudC5cbiAgICogQHJldHVybnMgQSB1bmlxdWUgbmFtZSBmb3IgdGhlIGFnZW50IHdpdGggYXBwcm9wcmlhdGUgbGVuZ3RoIGNvbnN0cmFpbnRzXG4gICAqIEBkZWZhdWx0IC0gR2VuZXJhdGVkIG5hbWUgZm9ybWF0OiAnYWdlbnQte2hhc2h9LXt1bmlxdWVOYW1lfScgd2l0aDpcbiAgICogLSBtYXhMZW5ndGg6IE1BWExFTkdUSF9GT1JfUk9MRV9OQU1FIC0gJy1iZWRyb2NrYWdlbnQnLmxlbmd0aFxuICAgKiAtIGxvd2VyOiB0cnVlXG4gICAqIC0gc2VwYXJhdG9yOiAnLSdcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgcHJvdGVjdGVkIGdlbmVyYXRlUGh5c2ljYWxOYW1lKCk6IHN0cmluZyB7XG4gICAgY29uc3QgbWF4TGVuZ3RoID0gdGhpcy5NQVhMRU5HVEhfRk9SX1JPTEVfTkFNRSAtIHRoaXMuUk9MRV9OQU1FX1NVRkZJWC5sZW5ndGg7XG4gICAgcmV0dXJuIHRoaXMuZ2VuZXJhdGVQaHlzaWNhbE5hbWVIYXNoKHRoaXMsICdhZ2VudCcsIHtcbiAgICAgIG1heExlbmd0aCxcbiAgICAgIGxvd2VyOiB0cnVlLFxuICAgICAgc2VwYXJhdG9yOiAnLScsXG4gICAgfSk7XG4gIH1cbn1cbiJdfQ==