"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptOverrideConfiguration = exports.AgentStepType = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const validation = require("./validation-helpers");
/**
 * The step in the agent sequence that this prompt configuration applies to.
 */
var AgentStepType;
(function (AgentStepType) {
    /**
     * Pre-processing step that prepares the user input for orchestration.
     */
    AgentStepType["PRE_PROCESSING"] = "PRE_PROCESSING";
    /**
     * Main orchestration step that determines the agent's actions.
     */
    AgentStepType["ORCHESTRATION"] = "ORCHESTRATION";
    /**
     * Post-processing step that refines the agent's response.
     */
    AgentStepType["POST_PROCESSING"] = "POST_PROCESSING";
    /**
     * Step that classifies and routes requests to appropriate collaborators.
     */
    AgentStepType["ROUTING_CLASSIFIER"] = "ROUTING_CLASSIFIER";
    /**
     * Step that summarizes conversation history for memory retention.
     */
    AgentStepType["MEMORY_SUMMARIZATION"] = "MEMORY_SUMMARIZATION";
    /**
     * Step that generates responses using knowledge base content.
     */
    AgentStepType["KNOWLEDGE_BASE_RESPONSE_GENERATION"] = "KNOWLEDGE_BASE_RESPONSE_GENERATION";
})(AgentStepType || (exports.AgentStepType = AgentStepType = {}));
/**
 * Configuration for overriding prompt templates and behaviors in different parts
 * of an agent's sequence. This allows customizing how the agent processes inputs,
 * makes decisions, and generates responses.
 */
class PromptOverrideConfiguration {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.PromptOverrideConfiguration", version: "2.244.0-alpha.0" };
    /**
     * Creates a PromptOverrideConfiguration from individual step configurations.
     * Use this method when you want to override prompts without using a custom parser.
     * @param steps The step configurations to use
     * @returns A new PromptOverrideConfiguration instance
     */
    static fromSteps(steps) {
        if (!steps || steps.length === 0) {
            throw new errors_1.UnscopedValidationError('EmptyStepsArray', 'Steps array cannot be empty');
        }
        // Convert steps array to props format
        const stepMap = steps.reduce((acc, step) => {
            switch (step.stepType) {
                case AgentStepType.PRE_PROCESSING:
                    return { ...acc, preProcessingStep: step };
                case AgentStepType.ORCHESTRATION:
                    return { ...acc, orchestrationStep: step };
                case AgentStepType.POST_PROCESSING:
                    return { ...acc, postProcessingStep: step };
                case AgentStepType.ROUTING_CLASSIFIER:
                    return { ...acc, routingClassifierStep: step };
                case AgentStepType.MEMORY_SUMMARIZATION:
                    return { ...acc, memorySummarizationStep: step };
                case AgentStepType.KNOWLEDGE_BASE_RESPONSE_GENERATION:
                    return { ...acc, knowledgeBaseResponseGenerationStep: step };
                default:
                    return acc;
            }
        }, {});
        return new PromptOverrideConfiguration(stepMap);
    }
    /**
     * Creates a PromptOverrideConfiguration with a custom Lambda parser function.
     * @param props Configuration including:
     *   - `parser`: Lambda function to use as custom parser
     *   - Individual step configurations. At least one of the steps must make use of the custom parser.
     */
    static withCustomParser(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_CustomParserProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.withCustomParser);
            }
            throw error;
        }
        return new PromptOverrideConfiguration(props);
    }
    /**
     * The custom Lambda parser function to use.
     * The Lambda parser processes and interprets the raw foundation model output.
     * It receives an input event with:
     * - messageVersion: Version of message format (1.0)
     * - agent: Info about the agent (name, id, alias, version)
     * - invokeModelRawResponse: Raw model output to parse
     * - promptType: Type of prompt being parsed
     * - overrideType: Type of override (OUTPUT_PARSER)
     *
     * The Lambda must return a response that the agent uses for next actions.
     * @see https://docs.aws.amazon.com/bedrock/latest/userguide/lambda-parser.html
     */
    parser;
    /**
     * Configuration for the pre-processing step.
     */
    preProcessingStep;
    /**
     * Configuration for the orchestration step.
     */
    orchestrationStep;
    /**
     * Configuration for the post-processing step.
     */
    postProcessingStep;
    /**
     * Configuration for the routing classifier step.
     */
    routingClassifierStep;
    /**
     * Configuration for the memory summarization step.
     */
    memorySummarizationStep;
    /**
     * Configuration for the knowledge base response generation step.
     */
    knowledgeBaseResponseGenerationStep;
    /**
     * Create a new PromptOverrideConfiguration.
     *
     * @internal - This is marked as private so end users leverage it only through static methods
     */
    constructor(props) {
        // Validate props
        validation.throwIfInvalid(this.validateSteps, props);
        if (props.parser) {
            validation.throwIfInvalid(this.validateCustomParser, props);
        }
        this.parser = props.parser;
        this.preProcessingStep = props.preProcessingStep;
        this.orchestrationStep = props.orchestrationStep;
        this.postProcessingStep = props.postProcessingStep;
        this.routingClassifierStep = props.routingClassifierStep;
        this.memorySummarizationStep = props.memorySummarizationStep;
        this.knowledgeBaseResponseGenerationStep = props.knowledgeBaseResponseGenerationStep;
    }
    /**
     * Format as CfnAgent.PromptOverrideConfigurationProperty
     *
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        const configurations = [];
        // Helper function to add configuration if step exists
        const addConfiguration = (step, type) => {
            if (step) {
                configurations.push({
                    promptType: type,
                    promptState: step.stepEnabled === undefined ? undefined : step.stepEnabled ? 'ENABLED' : 'DISABLED',
                    parserMode: step.useCustomParser === undefined ? undefined : step.useCustomParser ? 'OVERRIDDEN' : 'DEFAULT',
                    promptCreationMode: step.customPromptTemplate === undefined ? undefined : step.customPromptTemplate ? 'OVERRIDDEN' : 'DEFAULT',
                    basePromptTemplate: step.customPromptTemplate,
                    inferenceConfiguration: step.inferenceConfig,
                    // Include foundation model if it's a routing classifier step
                    foundationModel: type === AgentStepType.ROUTING_CLASSIFIER
                        ? step.foundationModel?.invokableArn
                        : undefined,
                });
            }
        };
        // Add configurations for each step type if defined
        addConfiguration(this.preProcessingStep, AgentStepType.PRE_PROCESSING);
        addConfiguration(this.orchestrationStep, AgentStepType.ORCHESTRATION);
        addConfiguration(this.postProcessingStep, AgentStepType.POST_PROCESSING);
        addConfiguration(this.routingClassifierStep, AgentStepType.ROUTING_CLASSIFIER);
        addConfiguration(this.memorySummarizationStep, AgentStepType.MEMORY_SUMMARIZATION);
        addConfiguration(this.knowledgeBaseResponseGenerationStep, AgentStepType.KNOWLEDGE_BASE_RESPONSE_GENERATION);
        return {
            overrideLambda: this.parser?.functionArn,
            promptConfigurations: configurations,
        };
    }
    validateInferenceConfig = (config) => {
        const errors = [];
        if (config) {
            if (config.temperature < 0 || config.temperature > 1) {
                errors.push('Temperature must be between 0 and 1');
            }
            if (config.topP < 0 || config.topP > 1) {
                errors.push('TopP must be between 0 and 1');
            }
            if (config.topK < 0 || config.topK > 500) {
                errors.push('TopK must be between 0 and 500');
            }
            if (config.stopSequences.length > 4) {
                errors.push('Maximum 4 stop sequences allowed');
            }
            if (config.maximumLength < 0 || config.maximumLength > 4096) {
                errors.push('MaximumLength must be between 0 and 4096');
            }
        }
        return errors;
    };
    validateSteps = (props) => {
        const errors = [];
        // Check if any steps are defined
        const hasSteps = [
            props.preProcessingStep,
            props.orchestrationStep,
            props.postProcessingStep,
            props.routingClassifierStep,
            props.memorySummarizationStep,
            props.knowledgeBaseResponseGenerationStep,
        ].some(step => step !== undefined);
        if (!hasSteps) {
            errors.push('Steps array cannot be empty');
        }
        // Helper function to validate a step's inference config
        const validateStep = (step, stepName) => {
            if (step) {
                // Check for foundation model in non-ROUTING_CLASSIFIER steps
                if ('foundationModel' in step && step.stepType !== AgentStepType.ROUTING_CLASSIFIER) {
                    errors.push('Foundation model can only be specified for ROUTING_CLASSIFIER step type');
                }
                const inferenceErrors = this.validateInferenceConfig(step.inferenceConfig);
                if (inferenceErrors.length > 0) {
                    errors.push(`${stepName} step: ${inferenceErrors.join(', ')}`);
                }
            }
        };
        // Validate each step's inference config
        validateStep(props.preProcessingStep, 'Pre-processing');
        validateStep(props.orchestrationStep, 'Orchestration');
        validateStep(props.postProcessingStep, 'Post-processing');
        validateStep(props.routingClassifierStep, 'Routing classifier');
        validateStep(props.memorySummarizationStep, 'Memory summarization');
        validateStep(props.knowledgeBaseResponseGenerationStep, 'Knowledge base response generation');
        // Validate routing classifier's foundation model if provided
        if (props.routingClassifierStep?.foundationModel) {
            if (!props.routingClassifierStep.foundationModel.invokableArn) {
                errors.push('Foundation model must be a valid IBedrockInvokable with an invokableArn');
            }
        }
        return errors;
    };
    validateCustomParser = (props) => {
        const errors = [];
        // Check if at least one step uses custom parser
        const hasCustomParser = [
            props.preProcessingStep?.useCustomParser,
            props.orchestrationStep?.useCustomParser,
            props.postProcessingStep?.useCustomParser,
            props.routingClassifierStep?.useCustomParser,
            props.memorySummarizationStep?.useCustomParser,
            props.knowledgeBaseResponseGenerationStep?.useCustomParser,
        ].some(useCustomParser => useCustomParser === true);
        if (!hasCustomParser) {
            errors.push('At least one step must use custom parser');
        }
        return errors;
    };
}
exports.PromptOverrideConfiguration = PromptOverrideConfiguration;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvbXB0LW92ZXJyaWRlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicHJvbXB0LW92ZXJyaWRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBRUEsd0RBQXNFO0FBQ3RFLG1EQUFtRDtBQUduRDs7R0FFRztBQUNILElBQVksYUE4Qlg7QUE5QkQsV0FBWSxhQUFhO0lBQ3ZCOztPQUVHO0lBQ0gsa0RBQWlDLENBQUE7SUFFakM7O09BRUc7SUFDSCxnREFBK0IsQ0FBQTtJQUUvQjs7T0FFRztJQUNILG9EQUFtQyxDQUFBO0lBRW5DOztPQUVHO0lBQ0gsMERBQXlDLENBQUE7SUFFekM7O09BRUc7SUFDSCw4REFBNkMsQ0FBQTtJQUU3Qzs7T0FFRztJQUNILDBGQUF5RSxDQUFBO0FBQzNFLENBQUMsRUE5QlcsYUFBYSw2QkFBYixhQUFhLFFBOEJ4QjtBQTRMRDs7OztHQUlHO0FBQ0gsTUFBYSwyQkFBMkI7O0lBQ3RDOzs7OztPQUtHO0lBQ0ksTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUE2QjtRQUNuRCxJQUFJLENBQUMsS0FBSyxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDakMsTUFBTSxJQUFJLGdDQUF1QixDQUFDLGlCQUFpQixFQUFFLDZCQUE2QixDQUFDLENBQUM7UUFDdEYsQ0FBQztRQUVELHNDQUFzQztRQUN0QyxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFO1lBQ3pDLFFBQVEsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO2dCQUN0QixLQUFLLGFBQWEsQ0FBQyxjQUFjO29CQUMvQixPQUFPLEVBQUUsR0FBRyxHQUFHLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLENBQUM7Z0JBQzdDLEtBQUssYUFBYSxDQUFDLGFBQWE7b0JBQzlCLE9BQU8sRUFBRSxHQUFHLEdBQUcsRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsQ0FBQztnQkFDN0MsS0FBSyxhQUFhLENBQUMsZUFBZTtvQkFDaEMsT0FBTyxFQUFFLEdBQUcsR0FBRyxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUFDO2dCQUM5QyxLQUFLLGFBQWEsQ0FBQyxrQkFBa0I7b0JBQ25DLE9BQU8sRUFBRSxHQUFHLEdBQUcsRUFBRSxxQkFBcUIsRUFBRSxJQUFpRCxFQUFFLENBQUM7Z0JBQzlGLEtBQUssYUFBYSxDQUFDLG9CQUFvQjtvQkFDckMsT0FBTyxFQUFFLEdBQUcsR0FBRyxFQUFFLHVCQUF1QixFQUFFLElBQUksRUFBRSxDQUFDO2dCQUNuRCxLQUFLLGFBQWEsQ0FBQyxrQ0FBa0M7b0JBQ25ELE9BQU8sRUFBRSxHQUFHLEdBQUcsRUFBRSxtQ0FBbUMsRUFBRSxJQUFJLEVBQUUsQ0FBQztnQkFDL0Q7b0JBQ0UsT0FBTyxHQUFHLENBQUM7WUFDZixDQUFDO1FBQ0gsQ0FBQyxFQUFFLEVBQXVCLENBQUMsQ0FBQztRQUU1QixPQUFPLElBQUksMkJBQTJCLENBQUMsT0FBTyxDQUFDLENBQUM7S0FDakQ7SUFFRDs7Ozs7T0FLRztJQUNJLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUF3Qjs7Ozs7Ozs7OztRQUNyRCxPQUFPLElBQUksMkJBQTJCLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDL0M7SUFFRDs7Ozs7Ozs7Ozs7O09BWUc7SUFDTSxNQUFNLENBQWE7SUFFNUI7O09BRUc7SUFDTSxpQkFBaUIsQ0FBeUM7SUFFbkU7O09BRUc7SUFDTSxpQkFBaUIsQ0FBeUM7SUFFbkU7O09BRUc7SUFDTSxrQkFBa0IsQ0FBMEM7SUFFckU7O09BRUc7SUFDTSxxQkFBcUIsQ0FBNkM7SUFFM0U7O09BRUc7SUFDTSx1QkFBdUIsQ0FBK0M7SUFFL0U7O09BRUc7SUFDTSxtQ0FBbUMsQ0FBMkQ7SUFFdkc7Ozs7T0FJRztJQUNILFlBQW9CLEtBQXdCO1FBQzFDLGlCQUFpQjtRQUNqQixVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDckQsSUFBSSxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDakIsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDOUQsQ0FBQztRQUNELElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUMzQixJQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixDQUFDO1FBQ2pELElBQUksQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUMsaUJBQWlCLENBQUM7UUFDakQsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQztRQUNuRCxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDLHFCQUFxQixDQUFDO1FBQ3pELElBQUksQ0FBQyx1QkFBdUIsR0FBRyxLQUFLLENBQUMsdUJBQXVCLENBQUM7UUFDN0QsSUFBSSxDQUFDLG1DQUFtQyxHQUFHLEtBQUssQ0FBQyxtQ0FBbUMsQ0FBQztLQUN0RjtJQUVEOzs7O09BSUc7SUFDSSxPQUFPO1FBQ1osTUFBTSxjQUFjLEdBQTJDLEVBQUUsQ0FBQztRQUVsRSxzREFBc0Q7UUFDdEQsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLElBQXNDLEVBQUUsSUFBbUIsRUFBRSxFQUFFO1lBQ3ZGLElBQUksSUFBSSxFQUFFLENBQUM7Z0JBQ1QsY0FBYyxDQUFDLElBQUksQ0FBQztvQkFDbEIsVUFBVSxFQUFFLElBQUk7b0JBQ2hCLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFVBQVU7b0JBQ25HLFVBQVUsRUFBRSxJQUFJLENBQUMsZUFBZSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFNBQVM7b0JBQzVHLGtCQUFrQixFQUFFLElBQUksQ0FBQyxvQkFBb0IsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFNBQVM7b0JBQzlILGtCQUFrQixFQUFFLElBQUksQ0FBQyxvQkFBb0I7b0JBQzdDLHNCQUFzQixFQUFFLElBQUksQ0FBQyxlQUFlO29CQUM1Qyw2REFBNkQ7b0JBQzdELGVBQWUsRUFBRSxJQUFJLEtBQUssYUFBYSxDQUFDLGtCQUFrQjt3QkFDeEQsQ0FBQyxDQUFFLElBQWtELENBQUMsZUFBZSxFQUFFLFlBQVk7d0JBQ25GLENBQUMsQ0FBQyxTQUFTO2lCQUNkLENBQUMsQ0FBQztZQUNMLENBQUM7UUFDSCxDQUFDLENBQUM7UUFFRixtREFBbUQ7UUFDbkQsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUN2RSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ3RFLGdCQUFnQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDekUsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLHFCQUFxQixFQUFFLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1FBQy9FLGdCQUFnQixDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxhQUFhLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUNuRixnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsbUNBQW1DLEVBQUUsYUFBYSxDQUFDLGtDQUFrQyxDQUFDLENBQUM7UUFFN0csT0FBTztZQUNMLGNBQWMsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLFdBQVc7WUFDeEMsb0JBQW9CLEVBQUUsY0FBYztTQUNyQyxDQUFDO0tBQ0g7SUFFTyx1QkFBdUIsR0FBRyxDQUFDLE1BQStCLEVBQVksRUFBRTtRQUM5RSxNQUFNLE1BQU0sR0FBYSxFQUFFLENBQUM7UUFDNUIsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUNYLElBQUksTUFBTSxDQUFDLFdBQVcsR0FBRyxDQUFDLElBQUksTUFBTSxDQUFDLFdBQVcsR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDckQsTUFBTSxDQUFDLElBQUksQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO1lBQ3JELENBQUM7WUFDRCxJQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUcsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZDLE1BQU0sQ0FBQyxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQztZQUM5QyxDQUFDO1lBQ0QsSUFBSSxNQUFNLENBQUMsSUFBSSxHQUFHLENBQUMsSUFBSSxNQUFNLENBQUMsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO2dCQUN6QyxNQUFNLENBQUMsSUFBSSxDQUFDLGdDQUFnQyxDQUFDLENBQUM7WUFDaEQsQ0FBQztZQUNELElBQUksTUFBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQ3BDLE1BQU0sQ0FBQyxJQUFJLENBQUMsa0NBQWtDLENBQUMsQ0FBQztZQUNsRCxDQUFDO1lBQ0QsSUFBSSxNQUFNLENBQUMsYUFBYSxHQUFHLENBQUMsSUFBSSxNQUFNLENBQUMsYUFBYSxHQUFHLElBQUksRUFBRSxDQUFDO2dCQUM1RCxNQUFNLENBQUMsSUFBSSxDQUFDLDBDQUEwQyxDQUFDLENBQUM7WUFDMUQsQ0FBQztRQUNILENBQUM7UUFDRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDLENBQUM7SUFFTSxhQUFhLEdBQUcsQ0FBQyxLQUF3QixFQUFZLEVBQUU7UUFDN0QsTUFBTSxNQUFNLEdBQWEsRUFBRSxDQUFDO1FBRTVCLGlDQUFpQztRQUNqQyxNQUFNLFFBQVEsR0FBRztZQUNmLEtBQUssQ0FBQyxpQkFBaUI7WUFDdkIsS0FBSyxDQUFDLGlCQUFpQjtZQUN2QixLQUFLLENBQUMsa0JBQWtCO1lBQ3hCLEtBQUssQ0FBQyxxQkFBcUI7WUFDM0IsS0FBSyxDQUFDLHVCQUF1QjtZQUM3QixLQUFLLENBQUMsbUNBQW1DO1NBQzFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxLQUFLLFNBQVMsQ0FBQyxDQUFDO1FBRW5DLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNkLE1BQU0sQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUMsQ0FBQztRQUM3QyxDQUFDO1FBRUQsd0RBQXdEO1FBQ3hELE1BQU0sWUFBWSxHQUFHLENBQUMsSUFBc0MsRUFBRSxRQUFnQixFQUFFLEVBQUU7WUFDaEYsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDVCw2REFBNkQ7Z0JBQzdELElBQUksaUJBQWlCLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxRQUFRLEtBQUssYUFBYSxDQUFDLGtCQUFrQixFQUFFLENBQUM7b0JBQ3BGLE1BQU0sQ0FBQyxJQUFJLENBQUMseUVBQXlFLENBQUMsQ0FBQztnQkFDekYsQ0FBQztnQkFFRCxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO2dCQUMzRSxJQUFJLGVBQWUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQy9CLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxRQUFRLFVBQVUsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ2pFLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQyxDQUFDO1FBRUYsd0NBQXdDO1FBQ3hDLFlBQVksQ0FBQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztRQUN4RCxZQUFZLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLGVBQWUsQ0FBQyxDQUFDO1FBQ3ZELFlBQVksQ0FBQyxLQUFLLENBQUMsa0JBQWtCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUMxRCxZQUFZLENBQUMsS0FBSyxDQUFDLHFCQUFxQixFQUFFLG9CQUFvQixDQUFDLENBQUM7UUFDaEUsWUFBWSxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO1FBQ3BFLFlBQVksQ0FBQyxLQUFLLENBQUMsbUNBQW1DLEVBQUUsb0NBQW9DLENBQUMsQ0FBQztRQUU5Riw2REFBNkQ7UUFDN0QsSUFBSSxLQUFLLENBQUMscUJBQXFCLEVBQUUsZUFBZSxFQUFFLENBQUM7WUFDakQsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxlQUFlLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQzlELE1BQU0sQ0FBQyxJQUFJLENBQUMseUVBQXlFLENBQUMsQ0FBQztZQUN6RixDQUFDO1FBQ0gsQ0FBQztRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUMsQ0FBQztJQUVNLG9CQUFvQixHQUFHLENBQUMsS0FBd0IsRUFBWSxFQUFFO1FBQ3BFLE1BQU0sTUFBTSxHQUFhLEVBQUUsQ0FBQztRQUU1QixnREFBZ0Q7UUFDaEQsTUFBTSxlQUFlLEdBQUc7WUFDdEIsS0FBSyxDQUFDLGlCQUFpQixFQUFFLGVBQWU7WUFDeEMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLGVBQWU7WUFDeEMsS0FBSyxDQUFDLGtCQUFrQixFQUFFLGVBQWU7WUFDekMsS0FBSyxDQUFDLHFCQUFxQixFQUFFLGVBQWU7WUFDNUMsS0FBSyxDQUFDLHVCQUF1QixFQUFFLGVBQWU7WUFDOUMsS0FBSyxDQUFDLG1DQUFtQyxFQUFFLGVBQWU7U0FDM0QsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxlQUFlLEtBQUssSUFBSSxDQUFDLENBQUM7UUFFcEQsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3JCLE1BQU0sQ0FBQyxJQUFJLENBQUMsMENBQTBDLENBQUMsQ0FBQztRQUMxRCxDQUFDO1FBRUQsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQyxDQUFDOztBQWhQSixrRUFpUEMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IENmbkFnZW50IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHR5cGUgeyBJRnVuY3Rpb24gfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtbGFtYmRhJztcbmltcG9ydCB7IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvZXJyb3JzJztcbmltcG9ydCAqIGFzIHZhbGlkYXRpb24gZnJvbSAnLi92YWxpZGF0aW9uLWhlbHBlcnMnO1xuaW1wb3J0IHR5cGUgeyBJQmVkcm9ja0ludm9rYWJsZSB9IGZyb20gJy4uL21vZGVscyc7XG5cbi8qKlxuICogVGhlIHN0ZXAgaW4gdGhlIGFnZW50IHNlcXVlbmNlIHRoYXQgdGhpcyBwcm9tcHQgY29uZmlndXJhdGlvbiBhcHBsaWVzIHRvLlxuICovXG5leHBvcnQgZW51bSBBZ2VudFN0ZXBUeXBlIHtcbiAgLyoqXG4gICAqIFByZS1wcm9jZXNzaW5nIHN0ZXAgdGhhdCBwcmVwYXJlcyB0aGUgdXNlciBpbnB1dCBmb3Igb3JjaGVzdHJhdGlvbi5cbiAgICovXG4gIFBSRV9QUk9DRVNTSU5HID0gJ1BSRV9QUk9DRVNTSU5HJyxcblxuICAvKipcbiAgICogTWFpbiBvcmNoZXN0cmF0aW9uIHN0ZXAgdGhhdCBkZXRlcm1pbmVzIHRoZSBhZ2VudCdzIGFjdGlvbnMuXG4gICAqL1xuICBPUkNIRVNUUkFUSU9OID0gJ09SQ0hFU1RSQVRJT04nLFxuXG4gIC8qKlxuICAgKiBQb3N0LXByb2Nlc3Npbmcgc3RlcCB0aGF0IHJlZmluZXMgdGhlIGFnZW50J3MgcmVzcG9uc2UuXG4gICAqL1xuICBQT1NUX1BST0NFU1NJTkcgPSAnUE9TVF9QUk9DRVNTSU5HJyxcblxuICAvKipcbiAgICogU3RlcCB0aGF0IGNsYXNzaWZpZXMgYW5kIHJvdXRlcyByZXF1ZXN0cyB0byBhcHByb3ByaWF0ZSBjb2xsYWJvcmF0b3JzLlxuICAgKi9cbiAgUk9VVElOR19DTEFTU0lGSUVSID0gJ1JPVVRJTkdfQ0xBU1NJRklFUicsXG5cbiAgLyoqXG4gICAqIFN0ZXAgdGhhdCBzdW1tYXJpemVzIGNvbnZlcnNhdGlvbiBoaXN0b3J5IGZvciBtZW1vcnkgcmV0ZW50aW9uLlxuICAgKi9cbiAgTUVNT1JZX1NVTU1BUklaQVRJT04gPSAnTUVNT1JZX1NVTU1BUklaQVRJT04nLFxuXG4gIC8qKlxuICAgKiBTdGVwIHRoYXQgZ2VuZXJhdGVzIHJlc3BvbnNlcyB1c2luZyBrbm93bGVkZ2UgYmFzZSBjb250ZW50LlxuICAgKi9cbiAgS05PV0xFREdFX0JBU0VfUkVTUE9OU0VfR0VORVJBVElPTiA9ICdLTk9XTEVER0VfQkFTRV9SRVNQT05TRV9HRU5FUkFUSU9OJyxcbn1cblxuLyoqXG4gKiBMTE0gaW5mZXJlbmNlIGNvbmZpZ3VyYXRpb25cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBJbmZlcmVuY2VDb25maWd1cmF0aW9uIHtcbiAgLyoqXG4gICAqIFRoZSBsaWtlbGlob29kIG9mIHRoZSBtb2RlbCBzZWxlY3RpbmcgaGlnaGVyLXByb2JhYmlsaXR5IG9wdGlvbnMgd2hpbGVcbiAgICogZ2VuZXJhdGluZyBhIHJlc3BvbnNlLiBBIGxvd2VyIHZhbHVlIG1ha2VzIHRoZSBtb2RlbCBtb3JlIGxpa2VseSB0byBjaG9vc2VcbiAgICogaGlnaGVyLXByb2JhYmlsaXR5IG9wdGlvbnMsIHdoaWxlIGEgaGlnaGVyIHZhbHVlIG1ha2VzIHRoZSBtb2RlbCBtb3JlXG4gICAqIGxpa2VseSB0byBjaG9vc2UgbG93ZXItcHJvYmFiaWxpdHkgb3B0aW9ucy5cbiAgICpcbiAgICogRmxvYXRpbmcgcG9pbnRcbiAgICpcbiAgICogbWluIDBcbiAgICogbWF4IDFcbiAgICovXG4gIHJlYWRvbmx5IHRlbXBlcmF0dXJlOiBudW1iZXI7XG4gIC8qKlxuICAgKiBXaGlsZSBnZW5lcmF0aW5nIGEgcmVzcG9uc2UsIHRoZSBtb2RlbCBkZXRlcm1pbmVzIHRoZSBwcm9iYWJpbGl0eSBvZiB0aGVcbiAgICogZm9sbG93aW5nIHRva2VuIGF0IGVhY2ggcG9pbnQgb2YgZ2VuZXJhdGlvbi4gVGhlIHZhbHVlIHRoYXQgeW91IHNldCBmb3JcbiAgICogVG9wIFAgZGV0ZXJtaW5lcyB0aGUgbnVtYmVyIG9mIG1vc3QtbGlrZWx5IGNhbmRpZGF0ZXMgZnJvbSB3aGljaCB0aGUgbW9kZWxcbiAgICogY2hvb3NlcyB0aGUgbmV4dCB0b2tlbiBpbiB0aGUgc2VxdWVuY2UuIEZvciBleGFtcGxlLCBpZiB5b3Ugc2V0IHRvcFAgdG9cbiAgICogODAsIHRoZSBtb2RlbCBvbmx5IHNlbGVjdHMgdGhlIG5leHQgdG9rZW4gZnJvbSB0aGUgdG9wIDgwJSBvZiB0aGVcbiAgICogcHJvYmFiaWxpdHkgZGlzdHJpYnV0aW9uIG9mIG5leHQgdG9rZW5zLlxuICAgKlxuICAgKiBGbG9hdGluZyBwb2ludFxuICAgKlxuICAgKiBtaW4gMFxuICAgKiBtYXggMVxuICAgKi9cbiAgcmVhZG9ubHkgdG9wUDogbnVtYmVyO1xuICAvKipcbiAgICogV2hpbGUgZ2VuZXJhdGluZyBhIHJlc3BvbnNlLCB0aGUgbW9kZWwgZGV0ZXJtaW5lcyB0aGUgcHJvYmFiaWxpdHkgb2YgdGhlXG4gICAqIGZvbGxvd2luZyB0b2tlbiBhdCBlYWNoIHBvaW50IG9mIGdlbmVyYXRpb24uIFRoZSB2YWx1ZSB0aGF0IHlvdSBzZXQgZm9yXG4gICAqIHRvcEsgaXMgdGhlIG51bWJlciBvZiBtb3N0LWxpa2VseSBjYW5kaWRhdGVzIGZyb20gd2hpY2ggdGhlIG1vZGVsIGNob29zZXNcbiAgICogdGhlIG5leHQgdG9rZW4gaW4gdGhlIHNlcXVlbmNlLiBGb3IgZXhhbXBsZSwgaWYgeW91IHNldCB0b3BLIHRvIDUwLCB0aGVcbiAgICogbW9kZWwgc2VsZWN0cyB0aGUgbmV4dCB0b2tlbiBmcm9tIGFtb25nIHRoZSB0b3AgNTAgbW9zdCBsaWtlbHkgY2hvaWNlcy5cbiAgICpcbiAgICogSW50ZWdlclxuICAgKlxuICAgKiBtaW4gMFxuICAgKiBtYXggNTAwXG4gICAqL1xuICByZWFkb25seSB0b3BLOiBudW1iZXI7XG4gIC8qKlxuICAgKiBBIGxpc3Qgb2Ygc3RvcCBzZXF1ZW5jZXMuIEEgc3RvcCBzZXF1ZW5jZSBpcyBhIHNlcXVlbmNlIG9mIGNoYXJhY3RlcnMgdGhhdFxuICAgKiBjYXVzZXMgdGhlIG1vZGVsIHRvIHN0b3AgZ2VuZXJhdGluZyB0aGUgcmVzcG9uc2UuXG4gICAqXG4gICAqIGxlbmd0aCAwLTRcbiAgICovXG4gIHJlYWRvbmx5IHN0b3BTZXF1ZW5jZXM6IHN0cmluZ1tdO1xuICAvKipcbiAgICogVGhlIG1heGltdW0gbnVtYmVyIG9mIHRva2VucyB0byBnZW5lcmF0ZSBpbiB0aGUgcmVzcG9uc2UuXG4gICAqXG4gICAqIEludGVnZXJcbiAgICpcbiAgICogbWluIDBcbiAgICogbWF4IDQwOTZcbiAgICovXG4gIHJlYWRvbmx5IG1heGltdW1MZW5ndGg6IG51bWJlcjtcbn1cblxuLyoqXG4gKiBCYXNlIGNvbmZpZ3VyYXRpb24gaW50ZXJmYWNlIGZvciBhbGwgcHJvbXB0IHN0ZXAgdHlwZXNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBQcm9tcHRTdGVwQ29uZmlnQmFzZSB7XG4gIC8qKlxuICAgKiBUaGUgdHlwZSBvZiBzdGVwIHRoaXMgY29uZmlndXJhdGlvbiBhcHBsaWVzIHRvLlxuICAgKi9cbiAgcmVhZG9ubHkgc3RlcFR5cGU6IEFnZW50U3RlcFR5cGU7XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdG8gZW5hYmxlIG9yIHNraXAgdGhpcyBzdGVwIGluIHRoZSBhZ2VudCBzZXF1ZW5jZS5cbiAgICogQGRlZmF1bHQgLSBUaGUgZGVmYXVsdCBzdGF0ZSBmb3IgZWFjaCBzdGVwIHR5cGUgaXMgYXMgZm9sbG93cy5cbiAgICpcbiAgICogICAgIFBSRV9QUk9DRVNTSU5HIOKAkyBFTkFCTEVEXG4gICAqICAgICBPUkNIRVNUUkFUSU9OIOKAkyBFTkFCTEVEXG4gICAqICAgICBLTk9XTEVER0VfQkFTRV9SRVNQT05TRV9HRU5FUkFUSU9OIOKAkyBFTkFCTEVEXG4gICAqICAgICBQT1NUX1BST0NFU1NJTkcg4oCTIERJU0FCTEVEXG4gICAqL1xuICByZWFkb25seSBzdGVwRW5hYmxlZD86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIFRoZSBjdXN0b20gcHJvbXB0IHRlbXBsYXRlIHRvIGJlIHVzZWQuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gVGhlIGRlZmF1bHQgcHJvbXB0IHRlbXBsYXRlIHdpbGwgYmUgdXNlZC5cbiAgICogQHNlZSBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vYmVkcm9jay9sYXRlc3QvdXNlcmd1aWRlL3Byb21wdC1wbGFjZWhvbGRlcnMuaHRtbFxuICAgKi9cbiAgcmVhZG9ubHkgY3VzdG9tUHJvbXB0VGVtcGxhdGU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBpbmZlcmVuY2UgY29uZmlndXJhdGlvbiBwYXJhbWV0ZXJzIHRvIHVzZS5cbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gRGVmYXVsdCBpbmZlcmVuY2UgY29uZmlndXJhdGlvbiB3aWxsIGJlIHVzZWRcbiAgICovXG4gIHJlYWRvbmx5IGluZmVyZW5jZUNvbmZpZz86IEluZmVyZW5jZUNvbmZpZ3VyYXRpb247XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdG8gdXNlIHRoZSBjdXN0b20gTGFtYmRhIHBhcnNlciBkZWZpbmVkIGZvciB0aGUgc2VxdWVuY2UuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gZmFsc2VcbiAgICovXG4gIHJlYWRvbmx5IHVzZUN1c3RvbVBhcnNlcj86IGJvb2xlYW47XG59XG5cbi8qKlxuICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIHByZS1wcm9jZXNzaW5nIHN0ZXBcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBQcm9tcHRQcmVQcm9jZXNzaW5nQ29uZmlnQ3VzdG9tUGFyc2VyIGV4dGVuZHMgUHJvbXB0U3RlcENvbmZpZ0Jhc2Uge31cblxuLyoqXG4gKiBDb25maWd1cmF0aW9uIGZvciB0aGUgb3JjaGVzdHJhdGlvbiBzdGVwXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0T3JjaGVzdHJhdGlvbkNvbmZpZ0N1c3RvbVBhcnNlciBleHRlbmRzIFByb21wdFN0ZXBDb25maWdCYXNlIHt9XG5cbi8qKlxuICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIHBvc3QtcHJvY2Vzc2luZyBzdGVwXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0UG9zdFByb2Nlc3NpbmdDb25maWdDdXN0b21QYXJzZXIgZXh0ZW5kcyBQcm9tcHRTdGVwQ29uZmlnQmFzZSB7fVxuXG4vKipcbiAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSByb3V0aW5nIGNsYXNzaWZpZXIgc3RlcFxuICovXG5leHBvcnQgaW50ZXJmYWNlIFByb21wdFJvdXRpbmdDbGFzc2lmaWVyQ29uZmlnQ3VzdG9tUGFyc2VyIGV4dGVuZHMgUHJvbXB0U3RlcENvbmZpZ0Jhc2Uge1xuICAvKipcbiAgICogVGhlIGZvdW5kYXRpb24gbW9kZWwgdG8gdXNlIGZvciB0aGUgcm91dGluZyBjbGFzc2lmaWVyIHN0ZXAuXG4gICAqIFRoaXMgaXMgcmVxdWlyZWQgZm9yIHRoZSByb3V0aW5nIGNsYXNzaWZpZXIgc3RlcC5cbiAgICovXG4gIHJlYWRvbmx5IGZvdW5kYXRpb25Nb2RlbDogSUJlZHJvY2tJbnZva2FibGU7XG59XG5cbi8qKlxuICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIG1lbW9yeSBzdW1tYXJpemF0aW9uIHN0ZXBcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBQcm9tcHRNZW1vcnlTdW1tYXJpemF0aW9uQ29uZmlnQ3VzdG9tUGFyc2VyIGV4dGVuZHMgUHJvbXB0U3RlcENvbmZpZ0Jhc2Uge31cblxuLyoqXG4gKiBDb25maWd1cmF0aW9uIGZvciB0aGUga25vd2xlZGdlIGJhc2UgcmVzcG9uc2UgZ2VuZXJhdGlvbiBzdGVwXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0S25vd2xlZGdlQmFzZVJlc3BvbnNlR2VuZXJhdGlvbkNvbmZpZ0N1c3RvbVBhcnNlciBleHRlbmRzIFByb21wdFN0ZXBDb25maWdCYXNlIHt9XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgY29uZmlndXJpbmcgYSBjdXN0b20gTGFtYmRhIHBhcnNlciBmb3IgcHJvbXB0IG92ZXJyaWRlcy5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDdXN0b21QYXJzZXJQcm9wcyB7XG4gIC8qKlxuICAgKiBMYW1iZGEgZnVuY3Rpb24gdG8gdXNlIGFzIGN1c3RvbSBwYXJzZXIuXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIGN1c3RvbSBwYXJzZXIgaXMgdXNlZFxuICAgKi9cbiAgcmVhZG9ubHkgcGFyc2VyPzogSUZ1bmN0aW9uO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUgcHJlLXByb2Nlc3Npbmcgc3RlcC5cbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8gcHJlLXByb2Nlc3NpbmcgY29uZmlndXJhdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgcHJlUHJvY2Vzc2luZ1N0ZXA/OiBQcm9tcHRQcmVQcm9jZXNzaW5nQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUgb3JjaGVzdHJhdGlvbiBzdGVwLlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBvcmNoZXN0cmF0aW9uIGNvbmZpZ3VyYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IG9yY2hlc3RyYXRpb25TdGVwPzogUHJvbXB0T3JjaGVzdHJhdGlvbkNvbmZpZ0N1c3RvbVBhcnNlcjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIHBvc3QtcHJvY2Vzc2luZyBzdGVwLlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBwb3N0LXByb2Nlc3NpbmcgY29uZmlndXJhdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgcG9zdFByb2Nlc3NpbmdTdGVwPzogUHJvbXB0UG9zdFByb2Nlc3NpbmdDb25maWdDdXN0b21QYXJzZXI7XG5cbiAgLyoqXG4gICAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSByb3V0aW5nIGNsYXNzaWZpZXIgc3RlcC5cbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8gcm91dGluZyBjbGFzc2lmaWVyIGNvbmZpZ3VyYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IHJvdXRpbmdDbGFzc2lmaWVyU3RlcD86IFByb21wdFJvdXRpbmdDbGFzc2lmaWVyQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUgbWVtb3J5IHN1bW1hcml6YXRpb24gc3RlcC5cbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8gbWVtb3J5IHN1bW1hcml6YXRpb24gY29uZmlndXJhdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgbWVtb3J5U3VtbWFyaXphdGlvblN0ZXA/OiBQcm9tcHRNZW1vcnlTdW1tYXJpemF0aW9uQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUga25vd2xlZGdlIGJhc2UgcmVzcG9uc2UgZ2VuZXJhdGlvbiBzdGVwLlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBrbm93bGVkZ2UgYmFzZSByZXNwb25zZSBnZW5lcmF0aW9uIGNvbmZpZ3VyYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IGtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25TdGVwPzogUHJvbXB0S25vd2xlZGdlQmFzZVJlc3BvbnNlR2VuZXJhdGlvbkNvbmZpZ0N1c3RvbVBhcnNlcjtcbn1cblxuLyoqXG4gKiBDb25maWd1cmF0aW9uIGZvciBvdmVycmlkaW5nIHByb21wdCB0ZW1wbGF0ZXMgYW5kIGJlaGF2aW9ycyBpbiBkaWZmZXJlbnQgcGFydHNcbiAqIG9mIGFuIGFnZW50J3Mgc2VxdWVuY2UuIFRoaXMgYWxsb3dzIGN1c3RvbWl6aW5nIGhvdyB0aGUgYWdlbnQgcHJvY2Vzc2VzIGlucHV0cyxcbiAqIG1ha2VzIGRlY2lzaW9ucywgYW5kIGdlbmVyYXRlcyByZXNwb25zZXMuXG4gKi9cbmV4cG9ydCBjbGFzcyBQcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb24ge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIFByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbiBmcm9tIGluZGl2aWR1YWwgc3RlcCBjb25maWd1cmF0aW9ucy5cbiAgICogVXNlIHRoaXMgbWV0aG9kIHdoZW4geW91IHdhbnQgdG8gb3ZlcnJpZGUgcHJvbXB0cyB3aXRob3V0IHVzaW5nIGEgY3VzdG9tIHBhcnNlci5cbiAgICogQHBhcmFtIHN0ZXBzIFRoZSBzdGVwIGNvbmZpZ3VyYXRpb25zIHRvIHVzZVxuICAgKiBAcmV0dXJucyBBIG5ldyBQcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb24gaW5zdGFuY2VcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbVN0ZXBzKHN0ZXBzOiBQcm9tcHRTdGVwQ29uZmlnQmFzZVtdKTogUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uIHtcbiAgICBpZiAoIXN0ZXBzIHx8IHN0ZXBzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKCdFbXB0eVN0ZXBzQXJyYXknLCAnU3RlcHMgYXJyYXkgY2Fubm90IGJlIGVtcHR5Jyk7XG4gICAgfVxuXG4gICAgLy8gQ29udmVydCBzdGVwcyBhcnJheSB0byBwcm9wcyBmb3JtYXRcbiAgICBjb25zdCBzdGVwTWFwID0gc3RlcHMucmVkdWNlKChhY2MsIHN0ZXApID0+IHtcbiAgICAgIHN3aXRjaCAoc3RlcC5zdGVwVHlwZSkge1xuICAgICAgICBjYXNlIEFnZW50U3RlcFR5cGUuUFJFX1BST0NFU1NJTkc6XG4gICAgICAgICAgcmV0dXJuIHsgLi4uYWNjLCBwcmVQcm9jZXNzaW5nU3RlcDogc3RlcCB9O1xuICAgICAgICBjYXNlIEFnZW50U3RlcFR5cGUuT1JDSEVTVFJBVElPTjpcbiAgICAgICAgICByZXR1cm4geyAuLi5hY2MsIG9yY2hlc3RyYXRpb25TdGVwOiBzdGVwIH07XG4gICAgICAgIGNhc2UgQWdlbnRTdGVwVHlwZS5QT1NUX1BST0NFU1NJTkc6XG4gICAgICAgICAgcmV0dXJuIHsgLi4uYWNjLCBwb3N0UHJvY2Vzc2luZ1N0ZXA6IHN0ZXAgfTtcbiAgICAgICAgY2FzZSBBZ2VudFN0ZXBUeXBlLlJPVVRJTkdfQ0xBU1NJRklFUjpcbiAgICAgICAgICByZXR1cm4geyAuLi5hY2MsIHJvdXRpbmdDbGFzc2lmaWVyU3RlcDogc3RlcCBhcyBQcm9tcHRSb3V0aW5nQ2xhc3NpZmllckNvbmZpZ0N1c3RvbVBhcnNlciB9O1xuICAgICAgICBjYXNlIEFnZW50U3RlcFR5cGUuTUVNT1JZX1NVTU1BUklaQVRJT046XG4gICAgICAgICAgcmV0dXJuIHsgLi4uYWNjLCBtZW1vcnlTdW1tYXJpemF0aW9uU3RlcDogc3RlcCB9O1xuICAgICAgICBjYXNlIEFnZW50U3RlcFR5cGUuS05PV0xFREdFX0JBU0VfUkVTUE9OU0VfR0VORVJBVElPTjpcbiAgICAgICAgICByZXR1cm4geyAuLi5hY2MsIGtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25TdGVwOiBzdGVwIH07XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgcmV0dXJuIGFjYztcbiAgICAgIH1cbiAgICB9LCB7fSBhcyBDdXN0b21QYXJzZXJQcm9wcyk7XG5cbiAgICByZXR1cm4gbmV3IFByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbihzdGVwTWFwKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uIHdpdGggYSBjdXN0b20gTGFtYmRhIHBhcnNlciBmdW5jdGlvbi5cbiAgICogQHBhcmFtIHByb3BzIENvbmZpZ3VyYXRpb24gaW5jbHVkaW5nOlxuICAgKiAgIC0gYHBhcnNlcmA6IExhbWJkYSBmdW5jdGlvbiB0byB1c2UgYXMgY3VzdG9tIHBhcnNlclxuICAgKiAgIC0gSW5kaXZpZHVhbCBzdGVwIGNvbmZpZ3VyYXRpb25zLiBBdCBsZWFzdCBvbmUgb2YgdGhlIHN0ZXBzIG11c3QgbWFrZSB1c2Ugb2YgdGhlIGN1c3RvbSBwYXJzZXIuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHdpdGhDdXN0b21QYXJzZXIocHJvcHM6IEN1c3RvbVBhcnNlclByb3BzKTogUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uIHtcbiAgICByZXR1cm4gbmV3IFByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbihwcm9wcyk7XG4gIH1cblxuICAvKipcbiAgICogVGhlIGN1c3RvbSBMYW1iZGEgcGFyc2VyIGZ1bmN0aW9uIHRvIHVzZS5cbiAgICogVGhlIExhbWJkYSBwYXJzZXIgcHJvY2Vzc2VzIGFuZCBpbnRlcnByZXRzIHRoZSByYXcgZm91bmRhdGlvbiBtb2RlbCBvdXRwdXQuXG4gICAqIEl0IHJlY2VpdmVzIGFuIGlucHV0IGV2ZW50IHdpdGg6XG4gICAqIC0gbWVzc2FnZVZlcnNpb246IFZlcnNpb24gb2YgbWVzc2FnZSBmb3JtYXQgKDEuMClcbiAgICogLSBhZ2VudDogSW5mbyBhYm91dCB0aGUgYWdlbnQgKG5hbWUsIGlkLCBhbGlhcywgdmVyc2lvbilcbiAgICogLSBpbnZva2VNb2RlbFJhd1Jlc3BvbnNlOiBSYXcgbW9kZWwgb3V0cHV0IHRvIHBhcnNlXG4gICAqIC0gcHJvbXB0VHlwZTogVHlwZSBvZiBwcm9tcHQgYmVpbmcgcGFyc2VkXG4gICAqIC0gb3ZlcnJpZGVUeXBlOiBUeXBlIG9mIG92ZXJyaWRlIChPVVRQVVRfUEFSU0VSKVxuICAgKlxuICAgKiBUaGUgTGFtYmRhIG11c3QgcmV0dXJuIGEgcmVzcG9uc2UgdGhhdCB0aGUgYWdlbnQgdXNlcyBmb3IgbmV4dCBhY3Rpb25zLlxuICAgKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9iZWRyb2NrL2xhdGVzdC91c2VyZ3VpZGUvbGFtYmRhLXBhcnNlci5odG1sXG4gICAqL1xuICByZWFkb25seSBwYXJzZXI/OiBJRnVuY3Rpb247XG5cbiAgLyoqXG4gICAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSBwcmUtcHJvY2Vzc2luZyBzdGVwLlxuICAgKi9cbiAgcmVhZG9ubHkgcHJlUHJvY2Vzc2luZ1N0ZXA/OiBQcm9tcHRQcmVQcm9jZXNzaW5nQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUgb3JjaGVzdHJhdGlvbiBzdGVwLlxuICAgKi9cbiAgcmVhZG9ubHkgb3JjaGVzdHJhdGlvblN0ZXA/OiBQcm9tcHRPcmNoZXN0cmF0aW9uQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUgcG9zdC1wcm9jZXNzaW5nIHN0ZXAuXG4gICAqL1xuICByZWFkb25seSBwb3N0UHJvY2Vzc2luZ1N0ZXA/OiBQcm9tcHRQb3N0UHJvY2Vzc2luZ0NvbmZpZ0N1c3RvbVBhcnNlcjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIHJvdXRpbmcgY2xhc3NpZmllciBzdGVwLlxuICAgKi9cbiAgcmVhZG9ubHkgcm91dGluZ0NsYXNzaWZpZXJTdGVwPzogUHJvbXB0Um91dGluZ0NsYXNzaWZpZXJDb25maWdDdXN0b21QYXJzZXI7XG5cbiAgLyoqXG4gICAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSBtZW1vcnkgc3VtbWFyaXphdGlvbiBzdGVwLlxuICAgKi9cbiAgcmVhZG9ubHkgbWVtb3J5U3VtbWFyaXphdGlvblN0ZXA/OiBQcm9tcHRNZW1vcnlTdW1tYXJpemF0aW9uQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUga25vd2xlZGdlIGJhc2UgcmVzcG9uc2UgZ2VuZXJhdGlvbiBzdGVwLlxuICAgKi9cbiAgcmVhZG9ubHkga25vd2xlZGdlQmFzZVJlc3BvbnNlR2VuZXJhdGlvblN0ZXA/OiBQcm9tcHRLbm93bGVkZ2VCYXNlUmVzcG9uc2VHZW5lcmF0aW9uQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDcmVhdGUgYSBuZXcgUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uLlxuICAgKlxuICAgKiBAaW50ZXJuYWwgLSBUaGlzIGlzIG1hcmtlZCBhcyBwcml2YXRlIHNvIGVuZCB1c2VycyBsZXZlcmFnZSBpdCBvbmx5IHRocm91Z2ggc3RhdGljIG1ldGhvZHNcbiAgICovXG4gIHByaXZhdGUgY29uc3RydWN0b3IocHJvcHM6IEN1c3RvbVBhcnNlclByb3BzKSB7XG4gICAgLy8gVmFsaWRhdGUgcHJvcHNcbiAgICB2YWxpZGF0aW9uLnRocm93SWZJbnZhbGlkKHRoaXMudmFsaWRhdGVTdGVwcywgcHJvcHMpO1xuICAgIGlmIChwcm9wcy5wYXJzZXIpIHtcbiAgICAgIHZhbGlkYXRpb24udGhyb3dJZkludmFsaWQodGhpcy52YWxpZGF0ZUN1c3RvbVBhcnNlciwgcHJvcHMpO1xuICAgIH1cbiAgICB0aGlzLnBhcnNlciA9IHByb3BzLnBhcnNlcjtcbiAgICB0aGlzLnByZVByb2Nlc3NpbmdTdGVwID0gcHJvcHMucHJlUHJvY2Vzc2luZ1N0ZXA7XG4gICAgdGhpcy5vcmNoZXN0cmF0aW9uU3RlcCA9IHByb3BzLm9yY2hlc3RyYXRpb25TdGVwO1xuICAgIHRoaXMucG9zdFByb2Nlc3NpbmdTdGVwID0gcHJvcHMucG9zdFByb2Nlc3NpbmdTdGVwO1xuICAgIHRoaXMucm91dGluZ0NsYXNzaWZpZXJTdGVwID0gcHJvcHMucm91dGluZ0NsYXNzaWZpZXJTdGVwO1xuICAgIHRoaXMubWVtb3J5U3VtbWFyaXphdGlvblN0ZXAgPSBwcm9wcy5tZW1vcnlTdW1tYXJpemF0aW9uU3RlcDtcbiAgICB0aGlzLmtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25TdGVwID0gcHJvcHMua25vd2xlZGdlQmFzZVJlc3BvbnNlR2VuZXJhdGlvblN0ZXA7XG4gIH1cblxuICAvKipcbiAgICogRm9ybWF0IGFzIENmbkFnZW50LlByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvblByb3BlcnR5XG4gICAqXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIF9yZW5kZXIoKTogQ2ZuQWdlbnQuUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uUHJvcGVydHkge1xuICAgIGNvbnN0IGNvbmZpZ3VyYXRpb25zOiBDZm5BZ2VudC5Qcm9tcHRDb25maWd1cmF0aW9uUHJvcGVydHlbXSA9IFtdO1xuXG4gICAgLy8gSGVscGVyIGZ1bmN0aW9uIHRvIGFkZCBjb25maWd1cmF0aW9uIGlmIHN0ZXAgZXhpc3RzXG4gICAgY29uc3QgYWRkQ29uZmlndXJhdGlvbiA9IChzdGVwOiBQcm9tcHRTdGVwQ29uZmlnQmFzZSB8IHVuZGVmaW5lZCwgdHlwZTogQWdlbnRTdGVwVHlwZSkgPT4ge1xuICAgICAgaWYgKHN0ZXApIHtcbiAgICAgICAgY29uZmlndXJhdGlvbnMucHVzaCh7XG4gICAgICAgICAgcHJvbXB0VHlwZTogdHlwZSxcbiAgICAgICAgICBwcm9tcHRTdGF0ZTogc3RlcC5zdGVwRW5hYmxlZCA9PT0gdW5kZWZpbmVkID8gdW5kZWZpbmVkIDogc3RlcC5zdGVwRW5hYmxlZCA/ICdFTkFCTEVEJyA6ICdESVNBQkxFRCcsXG4gICAgICAgICAgcGFyc2VyTW9kZTogc3RlcC51c2VDdXN0b21QYXJzZXIgPT09IHVuZGVmaW5lZCA/IHVuZGVmaW5lZCA6IHN0ZXAudXNlQ3VzdG9tUGFyc2VyID8gJ09WRVJSSURERU4nIDogJ0RFRkFVTFQnLFxuICAgICAgICAgIHByb21wdENyZWF0aW9uTW9kZTogc3RlcC5jdXN0b21Qcm9tcHRUZW1wbGF0ZSA9PT0gdW5kZWZpbmVkID8gdW5kZWZpbmVkIDogc3RlcC5jdXN0b21Qcm9tcHRUZW1wbGF0ZSA/ICdPVkVSUklEREVOJyA6ICdERUZBVUxUJyxcbiAgICAgICAgICBiYXNlUHJvbXB0VGVtcGxhdGU6IHN0ZXAuY3VzdG9tUHJvbXB0VGVtcGxhdGUsXG4gICAgICAgICAgaW5mZXJlbmNlQ29uZmlndXJhdGlvbjogc3RlcC5pbmZlcmVuY2VDb25maWcsXG4gICAgICAgICAgLy8gSW5jbHVkZSBmb3VuZGF0aW9uIG1vZGVsIGlmIGl0J3MgYSByb3V0aW5nIGNsYXNzaWZpZXIgc3RlcFxuICAgICAgICAgIGZvdW5kYXRpb25Nb2RlbDogdHlwZSA9PT0gQWdlbnRTdGVwVHlwZS5ST1VUSU5HX0NMQVNTSUZJRVJcbiAgICAgICAgICAgID8gKHN0ZXAgYXMgUHJvbXB0Um91dGluZ0NsYXNzaWZpZXJDb25maWdDdXN0b21QYXJzZXIpLmZvdW5kYXRpb25Nb2RlbD8uaW52b2thYmxlQXJuXG4gICAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIC8vIEFkZCBjb25maWd1cmF0aW9ucyBmb3IgZWFjaCBzdGVwIHR5cGUgaWYgZGVmaW5lZFxuICAgIGFkZENvbmZpZ3VyYXRpb24odGhpcy5wcmVQcm9jZXNzaW5nU3RlcCwgQWdlbnRTdGVwVHlwZS5QUkVfUFJPQ0VTU0lORyk7XG4gICAgYWRkQ29uZmlndXJhdGlvbih0aGlzLm9yY2hlc3RyYXRpb25TdGVwLCBBZ2VudFN0ZXBUeXBlLk9SQ0hFU1RSQVRJT04pO1xuICAgIGFkZENvbmZpZ3VyYXRpb24odGhpcy5wb3N0UHJvY2Vzc2luZ1N0ZXAsIEFnZW50U3RlcFR5cGUuUE9TVF9QUk9DRVNTSU5HKTtcbiAgICBhZGRDb25maWd1cmF0aW9uKHRoaXMucm91dGluZ0NsYXNzaWZpZXJTdGVwLCBBZ2VudFN0ZXBUeXBlLlJPVVRJTkdfQ0xBU1NJRklFUik7XG4gICAgYWRkQ29uZmlndXJhdGlvbih0aGlzLm1lbW9yeVN1bW1hcml6YXRpb25TdGVwLCBBZ2VudFN0ZXBUeXBlLk1FTU9SWV9TVU1NQVJJWkFUSU9OKTtcbiAgICBhZGRDb25maWd1cmF0aW9uKHRoaXMua25vd2xlZGdlQmFzZVJlc3BvbnNlR2VuZXJhdGlvblN0ZXAsIEFnZW50U3RlcFR5cGUuS05PV0xFREdFX0JBU0VfUkVTUE9OU0VfR0VORVJBVElPTik7XG5cbiAgICByZXR1cm4ge1xuICAgICAgb3ZlcnJpZGVMYW1iZGE6IHRoaXMucGFyc2VyPy5mdW5jdGlvbkFybixcbiAgICAgIHByb21wdENvbmZpZ3VyYXRpb25zOiBjb25maWd1cmF0aW9ucyxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSB2YWxpZGF0ZUluZmVyZW5jZUNvbmZpZyA9IChjb25maWc/OiBJbmZlcmVuY2VDb25maWd1cmF0aW9uKTogc3RyaW5nW10gPT4ge1xuICAgIGNvbnN0IGVycm9yczogc3RyaW5nW10gPSBbXTtcbiAgICBpZiAoY29uZmlnKSB7XG4gICAgICBpZiAoY29uZmlnLnRlbXBlcmF0dXJlIDwgMCB8fCBjb25maWcudGVtcGVyYXR1cmUgPiAxKSB7XG4gICAgICAgIGVycm9ycy5wdXNoKCdUZW1wZXJhdHVyZSBtdXN0IGJlIGJldHdlZW4gMCBhbmQgMScpO1xuICAgICAgfVxuICAgICAgaWYgKGNvbmZpZy50b3BQIDwgMCB8fCBjb25maWcudG9wUCA+IDEpIHtcbiAgICAgICAgZXJyb3JzLnB1c2goJ1RvcFAgbXVzdCBiZSBiZXR3ZWVuIDAgYW5kIDEnKTtcbiAgICAgIH1cbiAgICAgIGlmIChjb25maWcudG9wSyA8IDAgfHwgY29uZmlnLnRvcEsgPiA1MDApIHtcbiAgICAgICAgZXJyb3JzLnB1c2goJ1RvcEsgbXVzdCBiZSBiZXR3ZWVuIDAgYW5kIDUwMCcpO1xuICAgICAgfVxuICAgICAgaWYgKGNvbmZpZy5zdG9wU2VxdWVuY2VzLmxlbmd0aCA+IDQpIHtcbiAgICAgICAgZXJyb3JzLnB1c2goJ01heGltdW0gNCBzdG9wIHNlcXVlbmNlcyBhbGxvd2VkJyk7XG4gICAgICB9XG4gICAgICBpZiAoY29uZmlnLm1heGltdW1MZW5ndGggPCAwIHx8IGNvbmZpZy5tYXhpbXVtTGVuZ3RoID4gNDA5Nikge1xuICAgICAgICBlcnJvcnMucHVzaCgnTWF4aW11bUxlbmd0aCBtdXN0IGJlIGJldHdlZW4gMCBhbmQgNDA5NicpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZXJyb3JzO1xuICB9O1xuXG4gIHByaXZhdGUgdmFsaWRhdGVTdGVwcyA9IChwcm9wczogQ3VzdG9tUGFyc2VyUHJvcHMpOiBzdHJpbmdbXSA9PiB7XG4gICAgY29uc3QgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgLy8gQ2hlY2sgaWYgYW55IHN0ZXBzIGFyZSBkZWZpbmVkXG4gICAgY29uc3QgaGFzU3RlcHMgPSBbXG4gICAgICBwcm9wcy5wcmVQcm9jZXNzaW5nU3RlcCxcbiAgICAgIHByb3BzLm9yY2hlc3RyYXRpb25TdGVwLFxuICAgICAgcHJvcHMucG9zdFByb2Nlc3NpbmdTdGVwLFxuICAgICAgcHJvcHMucm91dGluZ0NsYXNzaWZpZXJTdGVwLFxuICAgICAgcHJvcHMubWVtb3J5U3VtbWFyaXphdGlvblN0ZXAsXG4gICAgICBwcm9wcy5rbm93bGVkZ2VCYXNlUmVzcG9uc2VHZW5lcmF0aW9uU3RlcCxcbiAgICBdLnNvbWUoc3RlcCA9PiBzdGVwICE9PSB1bmRlZmluZWQpO1xuXG4gICAgaWYgKCFoYXNTdGVwcykge1xuICAgICAgZXJyb3JzLnB1c2goJ1N0ZXBzIGFycmF5IGNhbm5vdCBiZSBlbXB0eScpO1xuICAgIH1cblxuICAgIC8vIEhlbHBlciBmdW5jdGlvbiB0byB2YWxpZGF0ZSBhIHN0ZXAncyBpbmZlcmVuY2UgY29uZmlnXG4gICAgY29uc3QgdmFsaWRhdGVTdGVwID0gKHN0ZXA6IFByb21wdFN0ZXBDb25maWdCYXNlIHwgdW5kZWZpbmVkLCBzdGVwTmFtZTogc3RyaW5nKSA9PiB7XG4gICAgICBpZiAoc3RlcCkge1xuICAgICAgICAvLyBDaGVjayBmb3IgZm91bmRhdGlvbiBtb2RlbCBpbiBub24tUk9VVElOR19DTEFTU0lGSUVSIHN0ZXBzXG4gICAgICAgIGlmICgnZm91bmRhdGlvbk1vZGVsJyBpbiBzdGVwICYmIHN0ZXAuc3RlcFR5cGUgIT09IEFnZW50U3RlcFR5cGUuUk9VVElOR19DTEFTU0lGSUVSKSB7XG4gICAgICAgICAgZXJyb3JzLnB1c2goJ0ZvdW5kYXRpb24gbW9kZWwgY2FuIG9ubHkgYmUgc3BlY2lmaWVkIGZvciBST1VUSU5HX0NMQVNTSUZJRVIgc3RlcCB0eXBlJyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBpbmZlcmVuY2VFcnJvcnMgPSB0aGlzLnZhbGlkYXRlSW5mZXJlbmNlQ29uZmlnKHN0ZXAuaW5mZXJlbmNlQ29uZmlnKTtcbiAgICAgICAgaWYgKGluZmVyZW5jZUVycm9ycy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgZXJyb3JzLnB1c2goYCR7c3RlcE5hbWV9IHN0ZXA6ICR7aW5mZXJlbmNlRXJyb3JzLmpvaW4oJywgJyl9YCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gVmFsaWRhdGUgZWFjaCBzdGVwJ3MgaW5mZXJlbmNlIGNvbmZpZ1xuICAgIHZhbGlkYXRlU3RlcChwcm9wcy5wcmVQcm9jZXNzaW5nU3RlcCwgJ1ByZS1wcm9jZXNzaW5nJyk7XG4gICAgdmFsaWRhdGVTdGVwKHByb3BzLm9yY2hlc3RyYXRpb25TdGVwLCAnT3JjaGVzdHJhdGlvbicpO1xuICAgIHZhbGlkYXRlU3RlcChwcm9wcy5wb3N0UHJvY2Vzc2luZ1N0ZXAsICdQb3N0LXByb2Nlc3NpbmcnKTtcbiAgICB2YWxpZGF0ZVN0ZXAocHJvcHMucm91dGluZ0NsYXNzaWZpZXJTdGVwLCAnUm91dGluZyBjbGFzc2lmaWVyJyk7XG4gICAgdmFsaWRhdGVTdGVwKHByb3BzLm1lbW9yeVN1bW1hcml6YXRpb25TdGVwLCAnTWVtb3J5IHN1bW1hcml6YXRpb24nKTtcbiAgICB2YWxpZGF0ZVN0ZXAocHJvcHMua25vd2xlZGdlQmFzZVJlc3BvbnNlR2VuZXJhdGlvblN0ZXAsICdLbm93bGVkZ2UgYmFzZSByZXNwb25zZSBnZW5lcmF0aW9uJyk7XG5cbiAgICAvLyBWYWxpZGF0ZSByb3V0aW5nIGNsYXNzaWZpZXIncyBmb3VuZGF0aW9uIG1vZGVsIGlmIHByb3ZpZGVkXG4gICAgaWYgKHByb3BzLnJvdXRpbmdDbGFzc2lmaWVyU3RlcD8uZm91bmRhdGlvbk1vZGVsKSB7XG4gICAgICBpZiAoIXByb3BzLnJvdXRpbmdDbGFzc2lmaWVyU3RlcC5mb3VuZGF0aW9uTW9kZWwuaW52b2thYmxlQXJuKSB7XG4gICAgICAgIGVycm9ycy5wdXNoKCdGb3VuZGF0aW9uIG1vZGVsIG11c3QgYmUgYSB2YWxpZCBJQmVkcm9ja0ludm9rYWJsZSB3aXRoIGFuIGludm9rYWJsZUFybicpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBlcnJvcnM7XG4gIH07XG5cbiAgcHJpdmF0ZSB2YWxpZGF0ZUN1c3RvbVBhcnNlciA9IChwcm9wczogQ3VzdG9tUGFyc2VyUHJvcHMpOiBzdHJpbmdbXSA9PiB7XG4gICAgY29uc3QgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgLy8gQ2hlY2sgaWYgYXQgbGVhc3Qgb25lIHN0ZXAgdXNlcyBjdXN0b20gcGFyc2VyXG4gICAgY29uc3QgaGFzQ3VzdG9tUGFyc2VyID0gW1xuICAgICAgcHJvcHMucHJlUHJvY2Vzc2luZ1N0ZXA/LnVzZUN1c3RvbVBhcnNlcixcbiAgICAgIHByb3BzLm9yY2hlc3RyYXRpb25TdGVwPy51c2VDdXN0b21QYXJzZXIsXG4gICAgICBwcm9wcy5wb3N0UHJvY2Vzc2luZ1N0ZXA/LnVzZUN1c3RvbVBhcnNlcixcbiAgICAgIHByb3BzLnJvdXRpbmdDbGFzc2lmaWVyU3RlcD8udXNlQ3VzdG9tUGFyc2VyLFxuICAgICAgcHJvcHMubWVtb3J5U3VtbWFyaXphdGlvblN0ZXA/LnVzZUN1c3RvbVBhcnNlcixcbiAgICAgIHByb3BzLmtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25TdGVwPy51c2VDdXN0b21QYXJzZXIsXG4gICAgXS5zb21lKHVzZUN1c3RvbVBhcnNlciA9PiB1c2VDdXN0b21QYXJzZXIgPT09IHRydWUpO1xuXG4gICAgaWYgKCFoYXNDdXN0b21QYXJzZXIpIHtcbiAgICAgIGVycm9ycy5wdXNoKCdBdCBsZWFzdCBvbmUgc3RlcCBtdXN0IHVzZSBjdXN0b20gcGFyc2VyJyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGVycm9ycztcbiAgfTtcbn1cbiJdfQ==