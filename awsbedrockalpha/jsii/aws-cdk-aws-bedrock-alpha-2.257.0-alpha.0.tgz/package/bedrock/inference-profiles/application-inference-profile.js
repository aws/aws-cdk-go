"use strict";
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationInferenceProfile = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const bedrock = require("aws-cdk-lib/aws-bedrock");
const aws_iam_1 = require("aws-cdk-lib/aws-iam");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
const inference_profile_1 = require("./inference-profile");
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create an Application Inference Profile with CDK.
 * These are inference profiles created by users (user defined).
 * This helps to track costs and model usage.
 *
 * Application inference profiles are user-defined profiles that help you track costs and model usage.
 * They can be created for a single region or for multiple regions using a cross-region inference profile.
 *
 * @cloudformationResource AWS::Bedrock::ApplicationInferenceProfile
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/inference-profiles-create.html
 */
let ApplicationInferenceProfile = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = inference_profile_1.InferenceProfileBase;
    let _instanceExtraInitializers = [];
    let _grantInvoke_decorators;
    let _grantProfileUsage_decorators;
    var ApplicationInferenceProfile = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _grantInvoke_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _grantProfileUsage_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            __esDecorate(this, null, _grantInvoke_decorators, { kind: "method", name: "grantInvoke", static: false, private: false, access: { has: obj => "grantInvoke" in obj, get: obj => obj.grantInvoke }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _grantProfileUsage_decorators, { kind: "method", name: "grantProfileUsage", static: false, private: false, access: { has: obj => "grantProfileUsage" in obj, get: obj => obj.grantProfileUsage }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            ApplicationInferenceProfile = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ApplicationInferenceProfile", version: "2.257.0-alpha.0" };
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.ApplicationInferenceProfile';
        /**
         * Import an Application Inference Profile given its attributes.
         * [disable-awslint:no-grants]
         *
         * @param scope - The construct scope
         * @param id - Identifier of the construct
         * @param attrs - Attributes of the existing application inference profile
         * @returns An IInferenceProfile reference to the existing application inference profile
         */
        static fromApplicationInferenceProfileAttributes(scope, id, attrs) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfileAttributes(attrs);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.fromApplicationInferenceProfileAttributes);
                }
                throw error;
            }
            class Import extends inference_profile_1.InferenceProfileBase {
                inferenceProfileArn = attrs.inferenceProfileArn;
                inferenceProfileId = aws_cdk_lib_1.Arn.split(attrs.inferenceProfileArn, aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME)
                    .resourceName;
                type = inference_profile_1.InferenceProfileType.APPLICATION;
                /**
                 * [disable-awslint:no-grants]
                 */
                grantProfileUsage(grantee) {
                    return aws_iam_1.Grant.addToPrincipal({
                        grantee: grantee,
                        actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel'],
                        resourceArns: [this.inferenceProfileArn],
                    });
                }
            }
            return new Import(scope, id);
        }
        /**
         * Import a low-level L1 Cfn Application Inference Profile.
         * [disable-awslint:no-grants]
         *
         * @param cfnApplicationInferenceProfile - The L1 CfnApplicationInferenceProfile to import
         * @returns An IInferenceProfile reference to the imported application inference profile
         */
        static fromCfnApplicationInferenceProfile(cfnApplicationInferenceProfile) {
            // Singleton pattern that will prevent creating 2 or more Inference Profiles from the same L1
            const id = '@FromCfnApplicationInferenceProfile';
            const existing = cfnApplicationInferenceProfile.node.tryFindChild(id);
            if (existing) {
                return existing;
            }
            return new (class extends inference_profile_1.InferenceProfileBase {
                inferenceProfileArn = cfnApplicationInferenceProfile.attrInferenceProfileArn;
                inferenceProfileId = cfnApplicationInferenceProfile.attrInferenceProfileId;
                type = inference_profile_1.InferenceProfileType.APPLICATION;
                /**
                 * [disable-awslint:no-grants]
                 */
                grantProfileUsage(grantee) {
                    return aws_iam_1.Grant.addToPrincipal({
                        grantee: grantee,
                        actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel'],
                        resourceArns: [this.inferenceProfileArn],
                    });
                }
            })(cfnApplicationInferenceProfile, id);
        }
        // ------------------------------------------------------
        // Base attributes
        // ------------------------------------------------------
        /**
         * The name of the application inference profile.
         */
        inferenceProfileName = __runInitializers(this, _instanceExtraInitializers);
        /**
         * The ARN of the application inference profile.
         * @attribute
         */
        inferenceProfileArn;
        /**
         * The unique identifier of the application inference profile.
         * @attribute
         */
        inferenceProfileId;
        /**
         * The underlying model/cross-region model used by the application inference profile.
         */
        inferenceProfileModel;
        /**
         * The status of the application inference profile. ACTIVE means that the inference profile is ready to be used.
         * @attribute
         */
        status;
        /**
         * The type of the inference profile. Always APPLICATION for application inference profiles.
         */
        type;
        /**
         * Time Stamp for Application Inference Profile creation.
         * @attribute
         */
        createdAt;
        /**
         * Time Stamp for Application Inference Profile update.
         * @attribute
         */
        updatedAt;
        /**
         * The ARN used for invoking this inference profile.
         * This equals to the inferenceProfileArn property, useful for implementing IBedrockInvokable interface.
         */
        invokableArn;
        // ------------------------------------------------------
        // Internal Only
        // ------------------------------------------------------
        /**
         * Instance of CfnApplicationInferenceProfile.
         * @internal
         */
        __resource;
        // ------------------------------------------------------
        // CONSTRUCTOR
        // ------------------------------------------------------
        constructor(scope, id, props) {
            super(scope, id);
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfileProps(props);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, ApplicationInferenceProfile);
                }
                throw error;
            }
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            // ------------------------------------------------------
            // Validate props
            // ------------------------------------------------------
            this.validateProps(props);
            // ------------------------------------------------------
            // Set properties
            // ------------------------------------------------------
            this.inferenceProfileModel = props.modelSource;
            this.type = inference_profile_1.InferenceProfileType.APPLICATION;
            // ------------------------------------------------------
            // L1 instantiation
            // ------------------------------------------------------
            this.__resource = new bedrock.CfnApplicationInferenceProfile(this, 'Resource', {
                description: props.description,
                inferenceProfileName: props.applicationInferenceProfileName,
                modelSource: {
                    copyFrom: props.modelSource.invokableArn,
                },
                tags: props.tags ? Object.entries(props.tags).map(([key, value]) => ({ key, value })) : undefined,
            });
            // ------------------------------------------------------
            // Build attributes
            // ------------------------------------------------------
            this.inferenceProfileArn = this.__resource.attrInferenceProfileArn;
            this.inferenceProfileId = this.__resource.attrInferenceProfileId;
            this.inferenceProfileName = this.__resource.inferenceProfileName;
            this.status = this.__resource.attrStatus;
            this.createdAt = this.__resource.attrCreatedAt;
            this.updatedAt = this.__resource.attrUpdatedAt;
            this.invokableArn = this.inferenceProfileArn;
        }
        // ------------------------------------------------------
        // METHODS
        // ------------------------------------------------------
        /**
         * Validates the properties for creating an Application Inference Profile.
         *
         * @param props - The properties to validate
         * @throws ValidationError if any validation fails
         */
        validateProps(props) {
            // Validate applicationInferenceProfileName is provided and not empty
            if (!props.applicationInferenceProfileName || props.applicationInferenceProfileName.trim() === '') {
                throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `ProfileNameRequired`, 'applicationInferenceProfileName is required and cannot be empty', this);
            }
            // Validate applicationInferenceProfileName length
            if (props.applicationInferenceProfileName.length > 64) {
                throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `ProfileNameTooLong`, 'applicationInferenceProfileName cannot exceed 64 characters', this);
            }
            // Validate applicationInferenceProfileName pattern
            const namePattern = /^([0-9a-zA-Z:.][ _-]?)+$/;
            if (!namePattern.test(props.applicationInferenceProfileName)) {
                throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `ProfileNameInvalidPattern`, 'applicationInferenceProfileName must match pattern ^([0-9a-zA-Z:.][ _-]?)+$', this);
            }
            // Validate modelSource is provided
            if (!props.modelSource) {
                throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `ModelSourceRequired`, 'modelSource is required', this);
            }
            // Validate description length if provided
            if (props.description !== undefined && props.description.length > 200) {
                throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `DescriptionTooLong`, 'description cannot exceed 200 characters', this);
            }
            // Validate description pattern if provided
            if (props.description !== undefined && props.description !== '') {
                const descriptionPattern = /^([0-9a-zA-Z:.][ _-]?)+$/;
                if (!descriptionPattern.test(props.description)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_1.lit) `DescriptionInvalidPattern`, 'description must match pattern ^([0-9a-zA-Z:.][ _-]?)+$', this);
                }
            }
        }
        /**
         * Gives the appropriate policies to invoke and use the application inference profile.
         * This method ensures the appropriate permissions are given to use either the inference profile
         * or the underlying foundation model/cross-region profile.
         * [disable-awslint:no-grants]
         *
         * @param grantee - The IAM principal to grant permissions to
         * @returns An IAM Grant object representing the granted permissions
         */
        grantInvoke(grantee) {
            // This method ensures the appropriate permissions are given
            // to use either the inference profile or the vanilla foundation model
            this.inferenceProfileModel.grantInvoke(grantee);
            // Plus we add permissions to now invoke the application inference profile itself
            return this.grantProfileUsage(grantee);
        }
        /**
         * Grants appropriate permissions to use the application inference profile (AIP).
         * This method adds the necessary IAM permissions to allow the grantee to:
         * - Get inference profile details (bedrock:GetInferenceProfile)
         * - Invoke the model through the inference profile (bedrock:InvokeModel)
         *
         * Note: This does not grant permissions to use the underlying model/cross-region profile in the AIP.
         * For comprehensive permissions, use grantInvoke() instead.
         * [disable-awslint:no-grants]
         *
         * @param grantee - The IAM principal to grant permissions to
         * @returns An IAM Grant object representing the granted permissions
         */
        grantProfileUsage(grantee) {
            return aws_iam_1.Grant.addToPrincipal({
                grantee: grantee,
                actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel'],
                resourceArns: [this.inferenceProfileArn],
            });
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return ApplicationInferenceProfile = _classThis;
})();
exports.ApplicationInferenceProfile = ApplicationInferenceProfile;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwbGljYXRpb24taW5mZXJlbmNlLXByb2ZpbGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhcHBsaWNhdGlvbi1pbmZlcmVuY2UtcHJvZmlsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSw2Q0FBOEQ7QUFDOUQsbURBQW1EO0FBRW5ELGlEQUE0QztBQUM1Qyw0RUFBNEQ7QUFDNUQsOEVBQThGO0FBQzlGLDBFQUEwRTtBQUcxRSwyREFBaUY7QUE0RWpGOzsrRUFFK0U7QUFDL0U7Ozs7Ozs7Ozs7R0FVRztJQUVVLDJCQUEyQjs0QkFEdkMsb0NBQWtCOzs7O3NCQUM4Qix3Q0FBb0I7Ozs7MkNBQTVCLFNBQVEsV0FBb0I7Ozs7dUNBbVBsRSxJQUFBLGtDQUFjLEdBQUU7NkNBdUJoQixJQUFBLGtDQUFjLEdBQUU7WUF0QmpCLG9MQUFPLFdBQVcsNkRBT2pCO1lBZ0JELHNNQUFPLGlCQUFpQiw2REFNdkI7WUFqUkgsNktBa1JDOzs7OztRQWpSQyxzQ0FBc0M7UUFDL0IsTUFBTSxDQUFVLHFCQUFxQixHQUFXLHdEQUF3RCxDQUFDO1FBRWhIOzs7Ozs7OztXQVFHO1FBQ0ksTUFBTSxDQUFDLHlDQUF5QyxDQUNyRCxLQUFnQixFQUNoQixFQUFVLEVBQ1YsS0FBNEM7Ozs7Ozs7Ozs7WUFFNUMsTUFBTSxNQUFPLFNBQVEsd0NBQW9CO2dCQUN2QixtQkFBbUIsR0FBRyxLQUFLLENBQUMsbUJBQW1CLENBQUM7Z0JBQ2hELGtCQUFrQixHQUFHLGlCQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSx1QkFBUyxDQUFDLG1CQUFtQixDQUFDO3FCQUNyRyxZQUFhLENBQUM7Z0JBQ0QsSUFBSSxHQUFHLHdDQUFvQixDQUFDLFdBQVcsQ0FBQztnQkFFeEQ7O21CQUVHO2dCQUNJLGlCQUFpQixDQUFDLE9BQW1CO29CQUMxQyxPQUFPLGVBQUssQ0FBQyxjQUFjLENBQUM7d0JBQzFCLE9BQU8sRUFBRSxPQUFPO3dCQUNoQixPQUFPLEVBQUUsQ0FBQyw2QkFBNkIsRUFBRSxxQkFBcUIsQ0FBQzt3QkFDL0QsWUFBWSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDO3FCQUN6QyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQzthQUNGO1lBRUQsT0FBTyxJQUFJLE1BQU0sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDOUI7UUFFRDs7Ozs7O1dBTUc7UUFDSSxNQUFNLENBQUMsa0NBQWtDLENBQzlDLDhCQUFzRTtZQUV0RSw2RkFBNkY7WUFDN0YsTUFBTSxFQUFFLEdBQUcscUNBQXFDLENBQUM7WUFDakQsTUFBTSxRQUFRLEdBQUcsOEJBQThCLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUN0RSxJQUFJLFFBQVEsRUFBRSxDQUFDO2dCQUNiLE9BQU8sUUFBd0MsQ0FBQztZQUNsRCxDQUFDO1lBRUQsT0FBTyxJQUFJLENBQUMsS0FBTSxTQUFRLHdDQUFvQjtnQkFDNUIsbUJBQW1CLEdBQUcsOEJBQThCLENBQUMsdUJBQXVCLENBQUM7Z0JBQzdFLGtCQUFrQixHQUFHLDhCQUE4QixDQUFDLHNCQUFzQixDQUFDO2dCQUMzRSxJQUFJLEdBQUcsd0NBQW9CLENBQUMsV0FBVyxDQUFDO2dCQUV4RDs7bUJBRUc7Z0JBQ0ksaUJBQWlCLENBQUMsT0FBbUI7b0JBQzFDLE9BQU8sZUFBSyxDQUFDLGNBQWMsQ0FBQzt3QkFDMUIsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLE9BQU8sRUFBRSxDQUFDLDZCQUE2QixFQUFFLHFCQUFxQixDQUFDO3dCQUMvRCxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7cUJBQ3pDLENBQUMsQ0FBQztnQkFDTCxDQUFDO2FBQ0YsQ0FBQyxDQUFDLDhCQUE4QixFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ3hDO1FBRUQseURBQXlEO1FBQ3pELGtCQUFrQjtRQUNsQix5REFBeUQ7UUFDekQ7O1dBRUc7UUFDYSxvQkFBb0IsR0FoRnpCLG1EQUEyQixDQWdGTztRQUU3Qzs7O1dBR0c7UUFDYSxtQkFBbUIsQ0FBUztRQUU1Qzs7O1dBR0c7UUFDYSxrQkFBa0IsQ0FBUztRQUUzQzs7V0FFRztRQUNhLHFCQUFxQixDQUFvQjtRQUV6RDs7O1dBR0c7UUFDYSxNQUFNLENBQVM7UUFFL0I7O1dBRUc7UUFDYSxJQUFJLENBQXVCO1FBRTNDOzs7V0FHRztRQUNhLFNBQVMsQ0FBUztRQUVsQzs7O1dBR0c7UUFDYSxTQUFTLENBQVM7UUFFbEM7OztXQUdHO1FBQ2EsWUFBWSxDQUFTO1FBRXJDLHlEQUF5RDtRQUN6RCxnQkFBZ0I7UUFDaEIseURBQXlEO1FBQ3pEOzs7V0FHRztRQUNjLFVBQVUsQ0FBeUM7UUFFcEUseURBQXlEO1FBQ3pELGNBQWM7UUFDZCx5REFBeUQ7UUFDekQsWUFBWSxLQUFnQixFQUFFLEVBQVUsRUFBRSxLQUF1QztZQUMvRSxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDOzs7Ozs7bURBN0lSLDJCQUEyQjs7OztZQThJcEMsbUNBQW1DO1lBQ25DLElBQUEsd0NBQW9CLEVBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRWxDLHlEQUF5RDtZQUN6RCxpQkFBaUI7WUFDakIseURBQXlEO1lBQ3pELElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFMUIseURBQXlEO1lBQ3pELGlCQUFpQjtZQUNqQix5REFBeUQ7WUFDekQsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUM7WUFDL0MsSUFBSSxDQUFDLElBQUksR0FBRyx3Q0FBb0IsQ0FBQyxXQUFXLENBQUM7WUFFN0MseURBQXlEO1lBQ3pELG1CQUFtQjtZQUNuQix5REFBeUQ7WUFDekQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLE9BQU8sQ0FBQyw4QkFBOEIsQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFO2dCQUM3RSxXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVc7Z0JBQzlCLG9CQUFvQixFQUFFLEtBQUssQ0FBQywrQkFBK0I7Z0JBQzNELFdBQVcsRUFBRTtvQkFDWCxRQUFRLEVBQUUsS0FBSyxDQUFDLFdBQVcsQ0FBQyxZQUFZO2lCQUN6QztnQkFDRCxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO2FBQ2xHLENBQUMsQ0FBQztZQUVILHlEQUF5RDtZQUN6RCxtQkFBbUI7WUFDbkIseURBQXlEO1lBQ3pELElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixDQUFDO1lBQ25FLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLHNCQUFzQixDQUFDO1lBQ2pFLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLG9CQUFxQixDQUFDO1lBQ2xFLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7WUFDekMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQztZQUMvQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO1lBQy9DLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDO1NBQzlDO1FBRUQseURBQXlEO1FBQ3pELFVBQVU7UUFDVix5REFBeUQ7UUFFekQ7Ozs7O1dBS0c7UUFDSyxhQUFhLENBQUMsS0FBdUM7WUFDM0QscUVBQXFFO1lBQ3JFLElBQUksQ0FBQyxLQUFLLENBQUMsK0JBQStCLElBQUksS0FBSyxDQUFDLCtCQUErQixDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDO2dCQUNsRyxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEscUJBQXFCLEVBQUUsaUVBQWlFLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDL0gsQ0FBQztZQUVELGtEQUFrRDtZQUNsRCxJQUFJLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxNQUFNLEdBQUcsRUFBRSxFQUFFLENBQUM7Z0JBQ3RELE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSxvQkFBb0IsRUFBRSw2REFBNkQsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUMxSCxDQUFDO1lBRUQsbURBQW1EO1lBQ25ELE1BQU0sV0FBVyxHQUFHLDBCQUEwQixDQUFDO1lBQy9DLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxFQUFFLENBQUM7Z0JBQzdELE1BQU0sSUFBSSw2QkFBZSxDQUN2QixJQUFBLHNCQUFHLEVBQUEsMkJBQTJCLEVBQzlCLDZFQUE2RSxFQUM3RSxJQUFJLENBQ0wsQ0FBQztZQUNKLENBQUM7WUFFRCxtQ0FBbUM7WUFDbkMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDdkIsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHFCQUFxQixFQUFFLHlCQUF5QixFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3ZGLENBQUM7WUFFRCwwQ0FBMEM7WUFDMUMsSUFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQztnQkFDdEUsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLG9CQUFvQixFQUFFLDBDQUEwQyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3ZHLENBQUM7WUFFRCwyQ0FBMkM7WUFDM0MsSUFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFBRSxDQUFDO2dCQUNoRSxNQUFNLGtCQUFrQixHQUFHLDBCQUEwQixDQUFDO2dCQUN0RCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDO29CQUNoRCxNQUFNLElBQUksNkJBQWUsQ0FDdkIsSUFBQSxzQkFBRyxFQUFBLDJCQUEyQixFQUM5Qix5REFBeUQsRUFDekQsSUFBSSxDQUNMLENBQUM7Z0JBQ0osQ0FBQztZQUNILENBQUM7U0FDRjtRQUVEOzs7Ozs7OztXQVFHO1FBRUksV0FBVyxDQUFDLE9BQW1CO1lBQ3BDLDREQUE0RDtZQUM1RCxzRUFBc0U7WUFDdEUsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUVoRCxpRkFBaUY7WUFDakYsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDeEM7UUFFRDs7Ozs7Ozs7Ozs7O1dBWUc7UUFFSSxpQkFBaUIsQ0FBQyxPQUFtQjtZQUMxQyxPQUFPLGVBQUssQ0FBQyxjQUFjLENBQUM7Z0JBQzFCLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixPQUFPLEVBQUUsQ0FBQyw2QkFBNkIsRUFBRSxxQkFBcUIsQ0FBQztnQkFDL0QsWUFBWSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDO2FBQ3pDLENBQUMsQ0FBQztTQUNKOztZQWpSVSx1REFBMkI7Ozs7O0FBQTNCLGtFQUEyQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFybiwgQXJuRm9ybWF0LCBWYWxpZGF0aW9uRXJyb3IgfSBmcm9tICdhd3MtY2RrLWxpYic7XG5pbXBvcnQgKiBhcyBiZWRyb2NrIGZyb20gJ2F3cy1jZGstbGliL2F3cy1iZWRyb2NrJztcbmltcG9ydCB0eXBlIHsgSUdyYW50YWJsZSB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0IHsgR3JhbnQgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCB7IGxpdCB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2hlbHBlcnMtaW50ZXJuYWwnO1xuaW1wb3J0IHsgYWRkQ29uc3RydWN0TWV0YWRhdGEsIE1ldGhvZE1ldGFkYXRhIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvbWV0YWRhdGEtcmVzb3VyY2UnO1xuaW1wb3J0IHsgcHJvcGVydHlJbmplY3RhYmxlIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvcHJvcC1pbmplY3RhYmxlJztcbmltcG9ydCB0eXBlIHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5pbXBvcnQgdHlwZSB7IElJbmZlcmVuY2VQcm9maWxlIH0gZnJvbSAnLi9pbmZlcmVuY2UtcHJvZmlsZSc7XG5pbXBvcnQgeyBJbmZlcmVuY2VQcm9maWxlQmFzZSwgSW5mZXJlbmNlUHJvZmlsZVR5cGUgfSBmcm9tICcuL2luZmVyZW5jZS1wcm9maWxlJztcbmltcG9ydCB0eXBlIHsgSUJlZHJvY2tJbnZva2FibGUgfSBmcm9tICcuLi9tb2RlbHMnO1xuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIFBST1BTIEZPUiBORVcgQ09OU1RSVUNUXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNyZWF0aW5nIGFuIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZVByb3BzIHtcbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogVGhpcyBuYW1lIHdpbGwgYmUgdXNlZCB0byBpZGVudGlmeSB0aGUgaW5mZXJlbmNlIHByb2ZpbGUgaW4gdGhlIEFXUyBjb25zb2xlIGFuZCBBUElzLlxuICAgKiAtIFJlcXVpcmVkOiAgWWVzXG4gICAqIC0gTWF4aW11bSBsZW5ndGg6IDY0IGNoYXJhY3RlcnNcbiAgICogLSBQYXR0ZXJuOiBgXihbMC05YS16QS1aOi5dWyBfLV0/KSskYFxuICAgKlxuICAgKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9BV1NDbG91ZEZvcm1hdGlvbi9sYXRlc3QvVXNlckd1aWRlL2F3cy1yZXNvdXJjZS1iZWRyb2NrLWFwcGxpY2F0aW9uaW5mZXJlbmNlcHJvZmlsZS5odG1sI2Nmbi1iZWRyb2NrLWFwcGxpY2F0aW9uaW5mZXJlbmNlcHJvZmlsZS1pbmZlcmVuY2Vwcm9maWxlbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBEZXNjcmlwdGlvbiBvZiB0aGUgaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFByb3ZpZGVzIGFkZGl0aW9uYWwgY29udGV4dCBhYm91dCB0aGUgcHVycG9zZSBhbmQgdXNhZ2Ugb2YgdGhpcyBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICpcbiAgICogLSBNYXhpbXVtIGxlbmd0aDogMjAwIGNoYXJhY3RlcnMgd2hlbiBwcm92aWRlZFxuICAgKiAtIFBhdHRlcm46IGBeKFswLTlhLXpBLVo6Ll1bIF8tXT8pKyRgXG4gICAqIEBkZWZhdWx0IC0gTm8gZGVzY3JpcHRpb24gaXMgcHJvdmlkZWRcbiAgICogQHNlZSBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vQVdTQ2xvdWRGb3JtYXRpb24vbGF0ZXN0L1VzZXJHdWlkZS9hd3MtcmVzb3VyY2UtYmVkcm9jay1hcHBsaWNhdGlvbmluZmVyZW5jZXByb2ZpbGUuaHRtbCNjZm4tYmVkcm9jay1hcHBsaWNhdGlvbmluZmVyZW5jZXByb2ZpbGUtZGVzY3JpcHRpb25cbiAgICovXG4gIHJlYWRvbmx5IGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbW9kZWwgc291cmNlIGZvciB0aGlzIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKlxuICAgKiBUbyBjcmVhdGUgYW4gYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUgZm9yIG9uZSBSZWdpb24sIHNwZWNpZnkgYSBmb3VuZGF0aW9uIG1vZGVsLlxuICAgKiBVc2FnZSBhbmQgY29zdHMgZm9yIHJlcXVlc3RzIG1hZGUgdG8gdGhhdCBSZWdpb24gd2l0aCB0aGF0IG1vZGVsIHdpbGwgYmUgdHJhY2tlZC5cbiAgICpcbiAgICogVG8gY3JlYXRlIGFuIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlIGZvciBtdWx0aXBsZSBSZWdpb25zLFxuICAgKiBzcGVjaWZ5IGEgY3Jvc3MgcmVnaW9uIChzeXN0ZW0tZGVmaW5lZCkgaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFRoZSBpbmZlcmVuY2UgcHJvZmlsZSB3aWxsIHJvdXRlIHJlcXVlc3RzIHRvIHRoZSBSZWdpb25zIGRlZmluZWQgaW5cbiAgICogdGhlIGNyb3NzIHJlZ2lvbiAoc3lzdGVtLWRlZmluZWQpIGluZmVyZW5jZSBwcm9maWxlIHRoYXQgeW91IGNob29zZS5cbiAgICogVXNhZ2UgYW5kIGNvc3RzIGZvciByZXF1ZXN0cyBtYWRlIHRvIHRoZSBSZWdpb25zIGluIHRoZSBpbmZlcmVuY2UgcHJvZmlsZSB3aWxsIGJlIHRyYWNrZWQuXG4gICAqXG4gICAqL1xuICByZWFkb25seSBtb2RlbFNvdXJjZTogSUJlZHJvY2tJbnZva2FibGU7XG4gIC8qKlxuICAgKiBBIGxpc3Qgb2YgdGFncyBhc3NvY2lhdGVkIHdpdGggdGhlIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKiBUYWdzIGhlbHAgeW91IG9yZ2FuaXplIGFuZCBjYXRlZ29yaXplIHlvdXIgQVdTIHJlc291cmNlcy5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyB0YWdzIGFyZSBhcHBsaWVkXG4gICAqL1xuICByZWFkb25seSB0YWdzPzogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfTtcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgQVRUUlMgRk9SIElNUE9SVEVEIENPTlNUUlVDVFxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBBdHRyaWJ1dGVzIGZvciBzcGVjaWZ5aW5nIGFuIGltcG9ydGVkIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZUF0dHJpYnV0ZXMge1xuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVBcm46IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIElEIG9yIEFtYXpvbiBSZXNvdXJjZSBOYW1lIChBUk4pIG9mIHRoZSBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogVGhpcyBjYW4gYmUgZWl0aGVyIHRoZSBwcm9maWxlIElEIG9yIHRoZSBmdWxsIEFSTi5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZUlkZW50aWZpZXI6IHN0cmluZztcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBORVcgQ09OU1RSVUNUIERFRklOSVRJT05cbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogQ2xhc3MgdG8gY3JlYXRlIGFuIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlIHdpdGggQ0RLLlxuICogVGhlc2UgYXJlIGluZmVyZW5jZSBwcm9maWxlcyBjcmVhdGVkIGJ5IHVzZXJzICh1c2VyIGRlZmluZWQpLlxuICogVGhpcyBoZWxwcyB0byB0cmFjayBjb3N0cyBhbmQgbW9kZWwgdXNhZ2UuXG4gKlxuICogQXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGVzIGFyZSB1c2VyLWRlZmluZWQgcHJvZmlsZXMgdGhhdCBoZWxwIHlvdSB0cmFjayBjb3N0cyBhbmQgbW9kZWwgdXNhZ2UuXG4gKiBUaGV5IGNhbiBiZSBjcmVhdGVkIGZvciBhIHNpbmdsZSByZWdpb24gb3IgZm9yIG11bHRpcGxlIHJlZ2lvbnMgdXNpbmcgYSBjcm9zcy1yZWdpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gKlxuICogQGNsb3VkZm9ybWF0aW9uUmVzb3VyY2UgQVdTOjpCZWRyb2NrOjpBcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVcbiAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9pbmZlcmVuY2UtcHJvZmlsZXMtY3JlYXRlLmh0bWxcbiAqL1xuQHByb3BlcnR5SW5qZWN0YWJsZVxuZXhwb3J0IGNsYXNzIEFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZSBleHRlbmRzIEluZmVyZW5jZVByb2ZpbGVCYXNlIGltcGxlbWVudHMgSUJlZHJvY2tJbnZva2FibGUge1xuICAvKiogVW5pcXVlbHkgaWRlbnRpZmllcyB0aGlzIGNsYXNzLiAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFBST1BFUlRZX0lOSkVDVElPTl9JRDogc3RyaW5nID0gJ0Bhd3MtY2RrLmF3cy1iZWRyb2NrLWFscGhhLkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZSc7XG5cbiAgLyoqXG4gICAqIEltcG9ydCBhbiBBcHBsaWNhdGlvbiBJbmZlcmVuY2UgUHJvZmlsZSBnaXZlbiBpdHMgYXR0cmlidXRlcy5cbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqXG4gICAqIEBwYXJhbSBzY29wZSAtIFRoZSBjb25zdHJ1Y3Qgc2NvcGVcbiAgICogQHBhcmFtIGlkIC0gSWRlbnRpZmllciBvZiB0aGUgY29uc3RydWN0XG4gICAqIEBwYXJhbSBhdHRycyAtIEF0dHJpYnV0ZXMgb2YgdGhlIGV4aXN0aW5nIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlXG4gICAqIEByZXR1cm5zIEFuIElJbmZlcmVuY2VQcm9maWxlIHJlZmVyZW5jZSB0byB0aGUgZXhpc3RpbmcgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGVcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZUF0dHJpYnV0ZXMoXG4gICAgc2NvcGU6IENvbnN0cnVjdCxcbiAgICBpZDogc3RyaW5nLFxuICAgIGF0dHJzOiBBcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVBdHRyaWJ1dGVzLFxuICApOiBJSW5mZXJlbmNlUHJvZmlsZSB7XG4gICAgY2xhc3MgSW1wb3J0IGV4dGVuZHMgSW5mZXJlbmNlUHJvZmlsZUJhc2Uge1xuICAgICAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVBcm4gPSBhdHRycy5pbmZlcmVuY2VQcm9maWxlQXJuO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVJZCA9IEFybi5zcGxpdChhdHRycy5pbmZlcmVuY2VQcm9maWxlQXJuLCBBcm5Gb3JtYXQuU0xBU0hfUkVTT1VSQ0VfTkFNRSlcbiAgICAgICAgLnJlc291cmNlTmFtZSE7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgdHlwZSA9IEluZmVyZW5jZVByb2ZpbGVUeXBlLkFQUExJQ0FUSU9OO1xuXG4gICAgICAvKipcbiAgICAgICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgICAgICovXG4gICAgICBwdWJsaWMgZ3JhbnRQcm9maWxlVXNhZ2UoZ3JhbnRlZTogSUdyYW50YWJsZSk6IEdyYW50IHtcbiAgICAgICAgcmV0dXJuIEdyYW50LmFkZFRvUHJpbmNpcGFsKHtcbiAgICAgICAgICBncmFudGVlOiBncmFudGVlLFxuICAgICAgICAgIGFjdGlvbnM6IFsnYmVkcm9jazpHZXRJbmZlcmVuY2VQcm9maWxlJywgJ2JlZHJvY2s6SW52b2tlTW9kZWwnXSxcbiAgICAgICAgICByZXNvdXJjZUFybnM6IFt0aGlzLmluZmVyZW5jZVByb2ZpbGVBcm5dLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IEltcG9ydChzY29wZSwgaWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIEltcG9ydCBhIGxvdy1sZXZlbCBMMSBDZm4gQXBwbGljYXRpb24gSW5mZXJlbmNlIFByb2ZpbGUuXG4gICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgKlxuICAgKiBAcGFyYW0gY2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlIC0gVGhlIEwxIENmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZSB0byBpbXBvcnRcbiAgICogQHJldHVybnMgQW4gSUluZmVyZW5jZVByb2ZpbGUgcmVmZXJlbmNlIHRvIHRoZSBpbXBvcnRlZCBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tQ2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlKFxuICAgIGNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZTogYmVkcm9jay5DZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUsXG4gICk6IElJbmZlcmVuY2VQcm9maWxlIHtcbiAgICAvLyBTaW5nbGV0b24gcGF0dGVybiB0aGF0IHdpbGwgcHJldmVudCBjcmVhdGluZyAyIG9yIG1vcmUgSW5mZXJlbmNlIFByb2ZpbGVzIGZyb20gdGhlIHNhbWUgTDFcbiAgICBjb25zdCBpZCA9ICdARnJvbUNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZSc7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBjZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUubm9kZS50cnlGaW5kQ2hpbGQoaWQpO1xuICAgIGlmIChleGlzdGluZykge1xuICAgICAgcmV0dXJuIGV4aXN0aW5nIGFzIHVua25vd24gYXMgSUluZmVyZW5jZVByb2ZpbGU7XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyAoY2xhc3MgZXh0ZW5kcyBJbmZlcmVuY2VQcm9maWxlQmFzZSB7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZUFybiA9IGNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZS5hdHRySW5mZXJlbmNlUHJvZmlsZUFybjtcbiAgICAgIHB1YmxpYyByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlSWQgPSBjZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUuYXR0ckluZmVyZW5jZVByb2ZpbGVJZDtcbiAgICAgIHB1YmxpYyByZWFkb25seSB0eXBlID0gSW5mZXJlbmNlUHJvZmlsZVR5cGUuQVBQTElDQVRJT047XG5cbiAgICAgIC8qKlxuICAgICAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAgICAgKi9cbiAgICAgIHB1YmxpYyBncmFudFByb2ZpbGVVc2FnZShncmFudGVlOiBJR3JhbnRhYmxlKTogR3JhbnQge1xuICAgICAgICByZXR1cm4gR3JhbnQuYWRkVG9QcmluY2lwYWwoe1xuICAgICAgICAgIGdyYW50ZWU6IGdyYW50ZWUsXG4gICAgICAgICAgYWN0aW9uczogWydiZWRyb2NrOkdldEluZmVyZW5jZVByb2ZpbGUnLCAnYmVkcm9jazpJbnZva2VNb2RlbCddLFxuICAgICAgICAgIHJlc291cmNlQXJuczogW3RoaXMuaW5mZXJlbmNlUHJvZmlsZUFybl0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pKGNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZSwgaWQpO1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEJhc2UgYXR0cmlidXRlc1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlTmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVBcm46IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHVuaXF1ZSBpZGVudGlmaWVyIG9mIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVJZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgdW5kZXJseWluZyBtb2RlbC9jcm9zcy1yZWdpb24gbW9kZWwgdXNlZCBieSB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZU1vZGVsOiBJQmVkcm9ja0ludm9rYWJsZTtcblxuICAvKipcbiAgICogVGhlIHN0YXR1cyBvZiB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUuIEFDVElWRSBtZWFucyB0aGF0IHRoZSBpbmZlcmVuY2UgcHJvZmlsZSBpcyByZWFkeSB0byBiZSB1c2VkLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgc3RhdHVzOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSB0eXBlIG9mIHRoZSBpbmZlcmVuY2UgcHJvZmlsZS4gQWx3YXlzIEFQUExJQ0FUSU9OIGZvciBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZXMuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgdHlwZTogSW5mZXJlbmNlUHJvZmlsZVR5cGU7XG5cbiAgLyoqXG4gICAqIFRpbWUgU3RhbXAgZm9yIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlIGNyZWF0aW9uLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgY3JlYXRlZEF0OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRpbWUgU3RhbXAgZm9yIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlIHVwZGF0ZS5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHVwZGF0ZWRBdDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgQVJOIHVzZWQgZm9yIGludm9raW5nIHRoaXMgaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFRoaXMgZXF1YWxzIHRvIHRoZSBpbmZlcmVuY2VQcm9maWxlQXJuIHByb3BlcnR5LCB1c2VmdWwgZm9yIGltcGxlbWVudGluZyBJQmVkcm9ja0ludm9rYWJsZSBpbnRlcmZhY2UuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgaW52b2thYmxlQXJuOiBzdHJpbmc7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEludGVybmFsIE9ubHlcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBJbnN0YW5jZSBvZiBDZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUuXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgcHJpdmF0ZSByZWFkb25seSBfX3Jlc291cmNlOiBiZWRyb2NrLkNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQ09OU1RSVUNUT1JcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzOiBBcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVQcm9wcykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCk7XG4gICAgLy8gRW5oYW5jZWQgQ0RLIEFuYWx5dGljcyBUZWxlbWV0cnlcbiAgICBhZGRDb25zdHJ1Y3RNZXRhZGF0YSh0aGlzLCBwcm9wcyk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBWYWxpZGF0ZSBwcm9wc1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMudmFsaWRhdGVQcm9wcyhwcm9wcyk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBTZXQgcHJvcGVydGllc1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMuaW5mZXJlbmNlUHJvZmlsZU1vZGVsID0gcHJvcHMubW9kZWxTb3VyY2U7XG4gICAgdGhpcy50eXBlID0gSW5mZXJlbmNlUHJvZmlsZVR5cGUuQVBQTElDQVRJT047XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBMMSBpbnN0YW50aWF0aW9uXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy5fX3Jlc291cmNlID0gbmV3IGJlZHJvY2suQ2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlKHRoaXMsICdSZXNvdXJjZScsIHtcbiAgICAgIGRlc2NyaXB0aW9uOiBwcm9wcy5kZXNjcmlwdGlvbixcbiAgICAgIGluZmVyZW5jZVByb2ZpbGVOYW1lOiBwcm9wcy5hcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lLFxuICAgICAgbW9kZWxTb3VyY2U6IHtcbiAgICAgICAgY29weUZyb206IHByb3BzLm1vZGVsU291cmNlLmludm9rYWJsZUFybixcbiAgICAgIH0sXG4gICAgICB0YWdzOiBwcm9wcy50YWdzID8gT2JqZWN0LmVudHJpZXMocHJvcHMudGFncykubWFwKChba2V5LCB2YWx1ZV0pID0+ICh7IGtleSwgdmFsdWUgfSkpIDogdW5kZWZpbmVkLFxuICAgIH0pO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gQnVpbGQgYXR0cmlidXRlc1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMuaW5mZXJlbmNlUHJvZmlsZUFybiA9IHRoaXMuX19yZXNvdXJjZS5hdHRySW5mZXJlbmNlUHJvZmlsZUFybjtcbiAgICB0aGlzLmluZmVyZW5jZVByb2ZpbGVJZCA9IHRoaXMuX19yZXNvdXJjZS5hdHRySW5mZXJlbmNlUHJvZmlsZUlkO1xuICAgIHRoaXMuaW5mZXJlbmNlUHJvZmlsZU5hbWUgPSB0aGlzLl9fcmVzb3VyY2UuaW5mZXJlbmNlUHJvZmlsZU5hbWUhO1xuICAgIHRoaXMuc3RhdHVzID0gdGhpcy5fX3Jlc291cmNlLmF0dHJTdGF0dXM7XG4gICAgdGhpcy5jcmVhdGVkQXQgPSB0aGlzLl9fcmVzb3VyY2UuYXR0ckNyZWF0ZWRBdDtcbiAgICB0aGlzLnVwZGF0ZWRBdCA9IHRoaXMuX19yZXNvdXJjZS5hdHRyVXBkYXRlZEF0O1xuICAgIHRoaXMuaW52b2thYmxlQXJuID0gdGhpcy5pbmZlcmVuY2VQcm9maWxlQXJuO1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIE1FVEhPRFNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyB0aGUgcHJvcGVydGllcyBmb3IgY3JlYXRpbmcgYW4gQXBwbGljYXRpb24gSW5mZXJlbmNlIFByb2ZpbGUuXG4gICAqXG4gICAqIEBwYXJhbSBwcm9wcyAtIFRoZSBwcm9wZXJ0aWVzIHRvIHZhbGlkYXRlXG4gICAqIEB0aHJvd3MgVmFsaWRhdGlvbkVycm9yIGlmIGFueSB2YWxpZGF0aW9uIGZhaWxzXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlUHJvcHMocHJvcHM6IEFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZVByb3BzKTogdm9pZCB7XG4gICAgLy8gVmFsaWRhdGUgYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZSBpcyBwcm92aWRlZCBhbmQgbm90IGVtcHR5XG4gICAgaWYgKCFwcm9wcy5hcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lIHx8IHByb3BzLmFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZU5hbWUudHJpbSgpID09PSAnJykge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgUHJvZmlsZU5hbWVSZXF1aXJlZGAsICdhcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lIGlzIHJlcXVpcmVkIGFuZCBjYW5ub3QgYmUgZW1wdHknLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBhcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lIGxlbmd0aFxuICAgIGlmIChwcm9wcy5hcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lLmxlbmd0aCA+IDY0KSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBQcm9maWxlTmFtZVRvb0xvbmdgLCAnYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZSBjYW5ub3QgZXhjZWVkIDY0IGNoYXJhY3RlcnMnLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBhcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lIHBhdHRlcm5cbiAgICBjb25zdCBuYW1lUGF0dGVybiA9IC9eKFswLTlhLXpBLVo6Ll1bIF8tXT8pKyQvO1xuICAgIGlmICghbmFtZVBhdHRlcm4udGVzdChwcm9wcy5hcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lKSkge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihcbiAgICAgICAgbGl0YFByb2ZpbGVOYW1lSW52YWxpZFBhdHRlcm5gLFxuICAgICAgICAnYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZSBtdXN0IG1hdGNoIHBhdHRlcm4gXihbMC05YS16QS1aOi5dWyBfLV0/KSskJyxcbiAgICAgICAgdGhpcyxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgbW9kZWxTb3VyY2UgaXMgcHJvdmlkZWRcbiAgICBpZiAoIXByb3BzLm1vZGVsU291cmNlKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBNb2RlbFNvdXJjZVJlcXVpcmVkYCwgJ21vZGVsU291cmNlIGlzIHJlcXVpcmVkJywgdGhpcyk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgZGVzY3JpcHRpb24gbGVuZ3RoIGlmIHByb3ZpZGVkXG4gICAgaWYgKHByb3BzLmRlc2NyaXB0aW9uICE9PSB1bmRlZmluZWQgJiYgcHJvcHMuZGVzY3JpcHRpb24ubGVuZ3RoID4gMjAwKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBEZXNjcmlwdGlvblRvb0xvbmdgLCAnZGVzY3JpcHRpb24gY2Fubm90IGV4Y2VlZCAyMDAgY2hhcmFjdGVycycsIHRoaXMpO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIGRlc2NyaXB0aW9uIHBhdHRlcm4gaWYgcHJvdmlkZWRcbiAgICBpZiAocHJvcHMuZGVzY3JpcHRpb24gIT09IHVuZGVmaW5lZCAmJiBwcm9wcy5kZXNjcmlwdGlvbiAhPT0gJycpIHtcbiAgICAgIGNvbnN0IGRlc2NyaXB0aW9uUGF0dGVybiA9IC9eKFswLTlhLXpBLVo6Ll1bIF8tXT8pKyQvO1xuICAgICAgaWYgKCFkZXNjcmlwdGlvblBhdHRlcm4udGVzdChwcm9wcy5kZXNjcmlwdGlvbikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihcbiAgICAgICAgICBsaXRgRGVzY3JpcHRpb25JbnZhbGlkUGF0dGVybmAsXG4gICAgICAgICAgJ2Rlc2NyaXB0aW9uIG11c3QgbWF0Y2ggcGF0dGVybiBeKFswLTlhLXpBLVo6Ll1bIF8tXT8pKyQnLFxuICAgICAgICAgIHRoaXMsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdpdmVzIHRoZSBhcHByb3ByaWF0ZSBwb2xpY2llcyB0byBpbnZva2UgYW5kIHVzZSB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFRoaXMgbWV0aG9kIGVuc3VyZXMgdGhlIGFwcHJvcHJpYXRlIHBlcm1pc3Npb25zIGFyZSBnaXZlbiB0byB1c2UgZWl0aGVyIHRoZSBpbmZlcmVuY2UgcHJvZmlsZVxuICAgKiBvciB0aGUgdW5kZXJseWluZyBmb3VuZGF0aW9uIG1vZGVsL2Nyb3NzLXJlZ2lvbiBwcm9maWxlLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICpcbiAgICogQHBhcmFtIGdyYW50ZWUgLSBUaGUgSUFNIHByaW5jaXBhbCB0byBncmFudCBwZXJtaXNzaW9ucyB0b1xuICAgKiBAcmV0dXJucyBBbiBJQU0gR3JhbnQgb2JqZWN0IHJlcHJlc2VudGluZyB0aGUgZ3JhbnRlZCBwZXJtaXNzaW9uc1xuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGdyYW50SW52b2tlKGdyYW50ZWU6IElHcmFudGFibGUpOiBHcmFudCB7XG4gICAgLy8gVGhpcyBtZXRob2QgZW5zdXJlcyB0aGUgYXBwcm9wcmlhdGUgcGVybWlzc2lvbnMgYXJlIGdpdmVuXG4gICAgLy8gdG8gdXNlIGVpdGhlciB0aGUgaW5mZXJlbmNlIHByb2ZpbGUgb3IgdGhlIHZhbmlsbGEgZm91bmRhdGlvbiBtb2RlbFxuICAgIHRoaXMuaW5mZXJlbmNlUHJvZmlsZU1vZGVsLmdyYW50SW52b2tlKGdyYW50ZWUpO1xuXG4gICAgLy8gUGx1cyB3ZSBhZGQgcGVybWlzc2lvbnMgdG8gbm93IGludm9rZSB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUgaXRzZWxmXG4gICAgcmV0dXJuIHRoaXMuZ3JhbnRQcm9maWxlVXNhZ2UoZ3JhbnRlZSk7XG4gIH1cblxuICAvKipcbiAgICogR3JhbnRzIGFwcHJvcHJpYXRlIHBlcm1pc3Npb25zIHRvIHVzZSB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUgKEFJUCkuXG4gICAqIFRoaXMgbWV0aG9kIGFkZHMgdGhlIG5lY2Vzc2FyeSBJQU0gcGVybWlzc2lvbnMgdG8gYWxsb3cgdGhlIGdyYW50ZWUgdG86XG4gICAqIC0gR2V0IGluZmVyZW5jZSBwcm9maWxlIGRldGFpbHMgKGJlZHJvY2s6R2V0SW5mZXJlbmNlUHJvZmlsZSlcbiAgICogLSBJbnZva2UgdGhlIG1vZGVsIHRocm91Z2ggdGhlIGluZmVyZW5jZSBwcm9maWxlIChiZWRyb2NrOkludm9rZU1vZGVsKVxuICAgKlxuICAgKiBOb3RlOiBUaGlzIGRvZXMgbm90IGdyYW50IHBlcm1pc3Npb25zIHRvIHVzZSB0aGUgdW5kZXJseWluZyBtb2RlbC9jcm9zcy1yZWdpb24gcHJvZmlsZSBpbiB0aGUgQUlQLlxuICAgKiBGb3IgY29tcHJlaGVuc2l2ZSBwZXJtaXNzaW9ucywgdXNlIGdyYW50SW52b2tlKCkgaW5zdGVhZC5cbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqXG4gICAqIEBwYXJhbSBncmFudGVlIC0gVGhlIElBTSBwcmluY2lwYWwgdG8gZ3JhbnQgcGVybWlzc2lvbnMgdG9cbiAgICogQHJldHVybnMgQW4gSUFNIEdyYW50IG9iamVjdCByZXByZXNlbnRpbmcgdGhlIGdyYW50ZWQgcGVybWlzc2lvbnNcbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBncmFudFByb2ZpbGVVc2FnZShncmFudGVlOiBJR3JhbnRhYmxlKTogR3JhbnQge1xuICAgIHJldHVybiBHcmFudC5hZGRUb1ByaW5jaXBhbCh7XG4gICAgICBncmFudGVlOiBncmFudGVlLFxuICAgICAgYWN0aW9uczogWydiZWRyb2NrOkdldEluZmVyZW5jZVByb2ZpbGUnLCAnYmVkcm9jazpJbnZva2VNb2RlbCddLFxuICAgICAgcmVzb3VyY2VBcm5zOiBbdGhpcy5pbmZlcmVuY2VQcm9maWxlQXJuXSxcbiAgICB9KTtcbiAgfVxufVxuIl19