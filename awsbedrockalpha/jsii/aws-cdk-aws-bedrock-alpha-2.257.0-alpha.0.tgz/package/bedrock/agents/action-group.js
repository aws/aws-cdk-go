"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentActionGroup = exports.ParentActionGroupSignature = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const crypto = require("crypto");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
/******************************************************************************
 *                           Signatures
 *****************************************************************************/
/**
 * AWS Defined signatures for enabling certain capabilities in your agent.
 */
class ParentActionGroupSignature {
    value;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ParentActionGroupSignature", version: "2.257.0-alpha.0" };
    /**
     * Signature that allows your agent to request the user for additional information when trying to complete a task.
     */
    static USER_INPUT = new ParentActionGroupSignature('AMAZON.UserInput');
    /**
     * Signature that allows your agent to generate, run, and troubleshoot code when trying to complete a task.
     */
    static CODE_INTERPRETER = new ParentActionGroupSignature('AMAZON.CodeInterpreter');
    /**
     * Constructor should be used as a temporary solution when a new signature is supported but its implementation in CDK hasn't been added yet.
     */
    constructor(
    /**
     * The AWS-defined signature value for this action group capability.
     */
    value) {
        this.value = value;
    }
    /**
     * Returns the string representation of the signature value.
     * Used when configuring the action group in CloudFormation.
     */
    toString() {
        return this.value;
    }
}
exports.ParentActionGroupSignature = ParentActionGroupSignature;
/******************************************************************************
 *                         DEF - Action Group Class
 *****************************************************************************/
class AgentActionGroup {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AgentActionGroup", version: "2.257.0-alpha.0" };
    // ------------------------------------------------------
    // Static Constructors
    // ------------------------------------------------------
    /**
     * Defines an action group that allows your agent to request the user for
     * additional information when trying to complete a task.
     * @param enabled Specifies whether the action group is available for the agent
     */
    static userInput(enabled) {
        return new AgentActionGroup({
            name: 'UserInputAction',
            enabled: enabled,
            parentActionGroupSignature: ParentActionGroupSignature.USER_INPUT,
        });
    }
    /**
     * Defines an action group that allows your agent to request the user for
     * additional information when trying to complete a task.
     * @param enabled Specifies whether the action group is available for the agent
     */
    static codeInterpreter(enabled) {
        return new AgentActionGroup({
            name: 'CodeInterpreterAction',
            enabled: enabled,
            parentActionGroupSignature: ParentActionGroupSignature.CODE_INTERPRETER,
        });
    }
    // ------------------------------------------------------
    // Attributes
    // ------------------------------------------------------
    /**
     * The name of the action group.
     */
    name;
    /**
     * A description of the action group.
     */
    description;
    /**
     * Whether this action group is available for the agent to invoke or not.
     */
    enabled;
    /**
     * The api schema for this action group (if defined).
     */
    apiSchema;
    /**
     * The action group executor for this action group (if defined).
     */
    executor;
    /**
     * Whether to delete the resource even if it's in use.
     */
    forceDelete;
    /**
     * The function schema for this action group (if defined).
     */
    functionSchema;
    /**
     * The AWS Defined signature (if defined).
     */
    parentActionGroupSignature;
    constructor(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentActionGroupProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, AgentActionGroup);
            }
            throw error;
        }
        // Validate Props
        this.validateProps(props);
        // ------------------------------------------------------
        // Set attributes or defaults
        // ------------------------------------------------------
        this.name = props.name ?? `action_group_quick_start_${crypto.randomUUID()}`;
        this.description = props.description;
        this.apiSchema = props.apiSchema;
        this.executor = props.executor;
        this.enabled = props.enabled ?? true;
        this.forceDelete = props.forceDelete ?? false;
        this.functionSchema = props.functionSchema;
        this.parentActionGroupSignature = props.parentActionGroupSignature;
    }
    validateProps(props) {
        if (props.parentActionGroupSignature && (props.description || props.apiSchema || props.executor)) {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `ParentActionGroupSignatureConflict`, 'When parentActionGroupSignature is specified, you must leave the description, ' +
                'apiSchema, and actionGroupExecutor fields blank for this action group');
        }
    }
    /**
     * Format as CFN properties
     *
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            actionGroupExecutor: this.executor?._render(),
            actionGroupName: this.name,
            actionGroupState: this.enabled ? 'ENABLED' : 'DISABLED',
            apiSchema: this.apiSchema?._render(),
            description: this.description,
            functionSchema: this.functionSchema?._render(),
            parentActionGroupSignature: this.parentActionGroupSignature?.toString(),
            skipResourceInUseCheckOnDelete: this.forceDelete,
        };
    }
}
exports.AgentActionGroup = AgentActionGroup;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWN0aW9uLWdyb3VwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYWN0aW9uLWdyb3VwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsaUNBQWlDO0FBRWpDLHdEQUFzRTtBQUN0RSw0RUFBNEQ7QUFLNUQ7OytFQUUrRTtBQUMvRTs7R0FFRztBQUNILE1BQWEsMEJBQTBCO0lBZ0JuQjs7SUFmbEI7O09BRUc7SUFDSSxNQUFNLENBQVUsVUFBVSxHQUFHLElBQUksMEJBQTBCLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUN2Rjs7T0FFRztJQUNJLE1BQU0sQ0FBVSxnQkFBZ0IsR0FBRyxJQUFJLDBCQUEwQixDQUFDLHdCQUF3QixDQUFDLENBQUM7SUFDbkc7O09BRUc7SUFDSDtJQUNFOztPQUVHO0lBQ2EsS0FBYTtRQUFiLFVBQUssR0FBTCxLQUFLLENBQVE7S0FDM0I7SUFFSjs7O09BR0c7SUFDSSxRQUFRO1FBQ2IsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDO0tBQ25COztBQXpCSCxnRUEwQkM7QUFpRUQ7OytFQUUrRTtBQUUvRSxNQUFhLGdCQUFnQjs7SUFDM0IseURBQXlEO0lBQ3pELHNCQUFzQjtJQUN0Qix5REFBeUQ7SUFDekQ7Ozs7T0FJRztJQUNJLE1BQU0sQ0FBQyxTQUFTLENBQUMsT0FBZ0I7UUFDdEMsT0FBTyxJQUFJLGdCQUFnQixDQUFDO1lBQzFCLElBQUksRUFBRSxpQkFBaUI7WUFDdkIsT0FBTyxFQUFFLE9BQU87WUFDaEIsMEJBQTBCLEVBQUUsMEJBQTBCLENBQUMsVUFBVTtTQUNsRSxDQUFDLENBQUM7S0FDSjtJQUVEOzs7O09BSUc7SUFDSSxNQUFNLENBQUMsZUFBZSxDQUFDLE9BQWdCO1FBQzVDLE9BQU8sSUFBSSxnQkFBZ0IsQ0FBQztZQUMxQixJQUFJLEVBQUUsdUJBQXVCO1lBQzdCLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLDBCQUEwQixFQUFFLDBCQUEwQixDQUFDLGdCQUFnQjtTQUN4RSxDQUFDLENBQUM7S0FDSjtJQUVELHlEQUF5RDtJQUN6RCxhQUFhO0lBQ2IseURBQXlEO0lBQ3pEOztPQUVHO0lBQ2EsSUFBSSxDQUFTO0lBQzdCOztPQUVHO0lBQ2EsV0FBVyxDQUFVO0lBQ3JDOztPQUVHO0lBQ2EsT0FBTyxDQUFVO0lBQ2pDOztPQUVHO0lBQ2EsU0FBUyxDQUFhO0lBQ3RDOztPQUVHO0lBQ2EsUUFBUSxDQUF1QjtJQUMvQzs7T0FFRztJQUNhLFdBQVcsQ0FBVztJQUN0Qzs7T0FFRztJQUNhLGNBQWMsQ0FBa0I7SUFDaEQ7O09BRUc7SUFDYSwwQkFBMEIsQ0FBOEI7SUFFeEUsWUFBbUIsS0FBNEI7Ozs7OzsrQ0FsRXBDLGdCQUFnQjs7OztRQW1FekIsaUJBQWlCO1FBQ2pCLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFMUIseURBQXlEO1FBQ3pELDZCQUE2QjtRQUM3Qix5REFBeUQ7UUFDekQsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsSUFBSSxJQUFJLDRCQUE0QixNQUFNLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQztRQUM1RSxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUM7UUFDckMsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO1FBQ2pDLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQztRQUMvQixJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDO1FBQ3JDLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDLFdBQVcsSUFBSSxLQUFLLENBQUM7UUFDOUMsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDO1FBQzNDLElBQUksQ0FBQywwQkFBMEIsR0FBRyxLQUFLLENBQUMsMEJBQTBCLENBQUM7S0FDcEU7SUFFTyxhQUFhLENBQUMsS0FBNEI7UUFDaEQsSUFBSSxLQUFLLENBQUMsMEJBQTBCLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxJQUFJLEtBQUssQ0FBQyxTQUFTLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7WUFDakcsTUFBTSxJQUFJLGdDQUF1QixDQUMvQixJQUFBLHNCQUFHLEVBQUEsb0NBQW9DLEVBQ3ZDLGdGQUFnRjtnQkFDOUUsdUVBQXVFLENBQzFFLENBQUM7UUFDSixDQUFDO0tBQ0Y7SUFFRDs7OztPQUlHO0lBQ0ksT0FBTztRQUNaLE9BQU87WUFDTCxtQkFBbUIsRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLE9BQU8sRUFBRTtZQUM3QyxlQUFlLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDMUIsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVO1lBQ3ZELFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRTtZQUNwQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVc7WUFDN0IsY0FBYyxFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsT0FBTyxFQUFFO1lBQzlDLDBCQUEwQixFQUFFLElBQUksQ0FBQywwQkFBMEIsRUFBRSxRQUFRLEVBQUU7WUFDdkUsOEJBQThCLEVBQUUsSUFBSSxDQUFDLFdBQVc7U0FDakQsQ0FBQztLQUNIOztBQTdHSCw0Q0E4R0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBjcnlwdG8gZnJvbSAnY3J5cHRvJztcbmltcG9ydCB0eXBlIHsgQ2ZuQWdlbnQgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgeyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvciB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2Vycm9ycyc7XG5pbXBvcnQgeyBsaXQgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9oZWxwZXJzLWludGVybmFsJztcbmltcG9ydCB0eXBlIHsgQWN0aW9uR3JvdXBFeGVjdXRvciB9IGZyb20gJy4vYXBpLWV4ZWN1dG9yJztcbmltcG9ydCB0eXBlIHsgQXBpU2NoZW1hIH0gZnJvbSAnLi9hcGktc2NoZW1hJztcbmltcG9ydCB0eXBlIHsgRnVuY3Rpb25TY2hlbWEgfSBmcm9tICcuL2Z1bmN0aW9uLXNjaGVtYSc7XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgU2lnbmF0dXJlc1xuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBBV1MgRGVmaW5lZCBzaWduYXR1cmVzIGZvciBlbmFibGluZyBjZXJ0YWluIGNhcGFiaWxpdGllcyBpbiB5b3VyIGFnZW50LlxuICovXG5leHBvcnQgY2xhc3MgUGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmUge1xuICAvKipcbiAgICogU2lnbmF0dXJlIHRoYXQgYWxsb3dzIHlvdXIgYWdlbnQgdG8gcmVxdWVzdCB0aGUgdXNlciBmb3IgYWRkaXRpb25hbCBpbmZvcm1hdGlvbiB3aGVuIHRyeWluZyB0byBjb21wbGV0ZSBhIHRhc2suXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFVTRVJfSU5QVVQgPSBuZXcgUGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmUoJ0FNQVpPTi5Vc2VySW5wdXQnKTtcbiAgLyoqXG4gICAqIFNpZ25hdHVyZSB0aGF0IGFsbG93cyB5b3VyIGFnZW50IHRvIGdlbmVyYXRlLCBydW4sIGFuZCB0cm91Ymxlc2hvb3QgY29kZSB3aGVuIHRyeWluZyB0byBjb21wbGV0ZSBhIHRhc2suXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IENPREVfSU5URVJQUkVURVIgPSBuZXcgUGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmUoJ0FNQVpPTi5Db2RlSW50ZXJwcmV0ZXInKTtcbiAgLyoqXG4gICAqIENvbnN0cnVjdG9yIHNob3VsZCBiZSB1c2VkIGFzIGEgdGVtcG9yYXJ5IHNvbHV0aW9uIHdoZW4gYSBuZXcgc2lnbmF0dXJlIGlzIHN1cHBvcnRlZCBidXQgaXRzIGltcGxlbWVudGF0aW9uIGluIENESyBoYXNuJ3QgYmVlbiBhZGRlZCB5ZXQuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihcbiAgICAvKipcbiAgICAgKiBUaGUgQVdTLWRlZmluZWQgc2lnbmF0dXJlIHZhbHVlIGZvciB0aGlzIGFjdGlvbiBncm91cCBjYXBhYmlsaXR5LlxuICAgICAqL1xuICAgIHB1YmxpYyByZWFkb25seSB2YWx1ZTogc3RyaW5nLFxuICApIHt9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiB0aGUgc2lnbmF0dXJlIHZhbHVlLlxuICAgKiBVc2VkIHdoZW4gY29uZmlndXJpbmcgdGhlIGFjdGlvbiBncm91cCBpbiBDbG91ZEZvcm1hdGlvbi5cbiAgICovXG4gIHB1YmxpYyB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gdGhpcy52YWx1ZTtcbiAgfVxufVxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgUFJPUFMgLSBBY3Rpb24gR3JvdXAgQ2xhc3NcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbmV4cG9ydCBpbnRlcmZhY2UgQWdlbnRBY3Rpb25Hcm91cFByb3BzIHtcbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBhY3Rpb24gZ3JvdXAuXG4gICAqIEBkZWZhdWx0IC0gQSB1bmlxdWUgbmFtZSBpcyBnZW5lcmF0ZWQgaW4gdGhlIGZvcm1hdCAnYWN0aW9uX2dyb3VwX3F1aWNrX3N0YXJ0X1VVSUQnXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBBIGRlc2NyaXB0aW9uIG9mIHRoZSBhY3Rpb24gZ3JvdXAuXG4gICAqXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIGRlc2NyaXB0aW9uIGlzIHByb3ZpZGVkXG4gICAqL1xuICByZWFkb25seSBkZXNjcmlwdGlvbj86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIEFQSSBTY2hlbWEgZGVmaW5pbmcgdGhlIGZ1bmN0aW9ucyBhdmFpbGFibGUgdG8gdGhlIGFnZW50LlxuICAgKlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBBUEkgU2NoZW1hIGlzIHByb3ZpZGVkXG4gICAqL1xuICByZWFkb25seSBhcGlTY2hlbWE/OiBBcGlTY2hlbWE7XG5cbiAgLyoqXG4gICAqIFRoZSBhY3Rpb24gZ3JvdXAgZXhlY3V0b3IgdGhhdCBpbXBsZW1lbnRzIHRoZSBBUEkgZnVuY3Rpb25zLlxuICAgKlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBleGVjdXRvciBpcyBwcm92aWRlZFxuICAgKi9cbiAgcmVhZG9ubHkgZXhlY3V0b3I/OiBBY3Rpb25Hcm91cEV4ZWN1dG9yO1xuXG4gIC8qKlxuICAgKiBTcGVjaWZpZXMgd2hldGhlciB0aGUgYWN0aW9uIGdyb3VwIGlzIGF2YWlsYWJsZSBmb3IgdGhlIGFnZW50IHRvIGludm9rZSBvclxuICAgKiBub3Qgd2hlbiBzZW5kaW5nIGFuIEludm9rZUFnZW50IHJlcXVlc3QuXG4gICAqXG4gICAqIEBkZWZhdWx0IHRydWUgLSBUaGUgYWN0aW9uIGdyb3VwIGlzIGVuYWJsZWRcbiAgICovXG4gIHJlYWRvbmx5IGVuYWJsZWQ/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBTcGVjaWZpZXMgd2hldGhlciB0byBkZWxldGUgdGhlIHJlc291cmNlIGV2ZW4gaWYgaXQncyBpbiB1c2UuXG4gICAqXG4gICAqIEBkZWZhdWx0IGZhbHNlIC0gVGhlIHJlc291cmNlIHdpbGwgbm90IGJlIGRlbGV0ZWQgaWYgaXQncyBpbiB1c2VcbiAgICovXG4gIHJlYWRvbmx5IGZvcmNlRGVsZXRlPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogRGVmaW5lcyBmdW5jdGlvbnMgdGhhdCBlYWNoIGRlZmluZSBwYXJhbWV0ZXJzIHRoYXQgdGhlIGFnZW50IG5lZWRzIHRvIGludm9rZSBmcm9tIHRoZSB1c2VyLlxuICAgKiBOTyBMMiB5ZXQgYXMgdGhpcyBkb2Vzbid0IG1ha2UgbXVjaCBzZW5zZSBJTUhPLlxuICAgKlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBmdW5jdGlvbiBzY2hlbWEgaXMgcHJvdmlkZWRcbiAgICovXG4gIHJlYWRvbmx5IGZ1bmN0aW9uU2NoZW1hPzogRnVuY3Rpb25TY2hlbWE7XG5cbiAgLyoqXG4gICAqIFRoZSBBV1MgRGVmaW5lZCBzaWduYXR1cmUgZm9yIGVuYWJsaW5nIGNlcnRhaW4gY2FwYWJpbGl0aWVzIGluIHlvdXIgYWdlbnQuXG4gICAqIFdoZW4gdGhpcyBwcm9wZXJ0eSBpcyBzcGVjaWZpZWQsIHlvdSBtdXN0IGxlYXZlIHRoZSBkZXNjcmlwdGlvbiwgYXBpU2NoZW1hLFxuICAgKiBhbmQgYWN0aW9uR3JvdXBFeGVjdXRvciBmaWVsZHMgYmxhbmsgZm9yIHRoaXMgYWN0aW9uIGdyb3VwLlxuICAgKlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBwYXJlbnQgYWN0aW9uIGdyb3VwIHNpZ25hdHVyZSBpcyBwcm92aWRlZFxuICAgKi9cbiAgcmVhZG9ubHkgcGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmU/OiBQYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZTtcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgREVGIC0gQWN0aW9uIEdyb3VwIENsYXNzXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbmV4cG9ydCBjbGFzcyBBZ2VudEFjdGlvbkdyb3VwIHtcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIFN0YXRpYyBDb25zdHJ1Y3RvcnNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBEZWZpbmVzIGFuIGFjdGlvbiBncm91cCB0aGF0IGFsbG93cyB5b3VyIGFnZW50IHRvIHJlcXVlc3QgdGhlIHVzZXIgZm9yXG4gICAqIGFkZGl0aW9uYWwgaW5mb3JtYXRpb24gd2hlbiB0cnlpbmcgdG8gY29tcGxldGUgYSB0YXNrLlxuICAgKiBAcGFyYW0gZW5hYmxlZCBTcGVjaWZpZXMgd2hldGhlciB0aGUgYWN0aW9uIGdyb3VwIGlzIGF2YWlsYWJsZSBmb3IgdGhlIGFnZW50XG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHVzZXJJbnB1dChlbmFibGVkOiBib29sZWFuKTogQWdlbnRBY3Rpb25Hcm91cCB7XG4gICAgcmV0dXJuIG5ldyBBZ2VudEFjdGlvbkdyb3VwKHtcbiAgICAgIG5hbWU6ICdVc2VySW5wdXRBY3Rpb24nLFxuICAgICAgZW5hYmxlZDogZW5hYmxlZCxcbiAgICAgIHBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlOiBQYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZS5VU0VSX0lOUFVULFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYW4gYWN0aW9uIGdyb3VwIHRoYXQgYWxsb3dzIHlvdXIgYWdlbnQgdG8gcmVxdWVzdCB0aGUgdXNlciBmb3JcbiAgICogYWRkaXRpb25hbCBpbmZvcm1hdGlvbiB3aGVuIHRyeWluZyB0byBjb21wbGV0ZSBhIHRhc2suXG4gICAqIEBwYXJhbSBlbmFibGVkIFNwZWNpZmllcyB3aGV0aGVyIHRoZSBhY3Rpb24gZ3JvdXAgaXMgYXZhaWxhYmxlIGZvciB0aGUgYWdlbnRcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgY29kZUludGVycHJldGVyKGVuYWJsZWQ6IGJvb2xlYW4pOiBBZ2VudEFjdGlvbkdyb3VwIHtcbiAgICByZXR1cm4gbmV3IEFnZW50QWN0aW9uR3JvdXAoe1xuICAgICAgbmFtZTogJ0NvZGVJbnRlcnByZXRlckFjdGlvbicsXG4gICAgICBlbmFibGVkOiBlbmFibGVkLFxuICAgICAgcGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmU6IFBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlLkNPREVfSU5URVJQUkVURVIsXG4gICAgfSk7XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQXR0cmlidXRlc1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBhY3Rpb24gZ3JvdXAuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuICAvKipcbiAgICogQSBkZXNjcmlwdGlvbiBvZiB0aGUgYWN0aW9uIGdyb3VwLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICAvKipcbiAgICogV2hldGhlciB0aGlzIGFjdGlvbiBncm91cCBpcyBhdmFpbGFibGUgZm9yIHRoZSBhZ2VudCB0byBpbnZva2Ugb3Igbm90LlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGVuYWJsZWQ6IGJvb2xlYW47XG4gIC8qKlxuICAgKiBUaGUgYXBpIHNjaGVtYSBmb3IgdGhpcyBhY3Rpb24gZ3JvdXAgKGlmIGRlZmluZWQpLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGFwaVNjaGVtYT86IEFwaVNjaGVtYTtcbiAgLyoqXG4gICAqIFRoZSBhY3Rpb24gZ3JvdXAgZXhlY3V0b3IgZm9yIHRoaXMgYWN0aW9uIGdyb3VwIChpZiBkZWZpbmVkKS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBleGVjdXRvcj86IEFjdGlvbkdyb3VwRXhlY3V0b3I7XG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIGRlbGV0ZSB0aGUgcmVzb3VyY2UgZXZlbiBpZiBpdCdzIGluIHVzZS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBmb3JjZURlbGV0ZT86IGJvb2xlYW47XG4gIC8qKlxuICAgKiBUaGUgZnVuY3Rpb24gc2NoZW1hIGZvciB0aGlzIGFjdGlvbiBncm91cCAoaWYgZGVmaW5lZCkuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZnVuY3Rpb25TY2hlbWE/OiBGdW5jdGlvblNjaGVtYTtcbiAgLyoqXG4gICAqIFRoZSBBV1MgRGVmaW5lZCBzaWduYXR1cmUgKGlmIGRlZmluZWQpLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlPzogUGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmU7XG5cbiAgcHVibGljIGNvbnN0cnVjdG9yKHByb3BzOiBBZ2VudEFjdGlvbkdyb3VwUHJvcHMpIHtcbiAgICAvLyBWYWxpZGF0ZSBQcm9wc1xuICAgIHRoaXMudmFsaWRhdGVQcm9wcyhwcm9wcyk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBTZXQgYXR0cmlidXRlcyBvciBkZWZhdWx0c1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMubmFtZSA9IHByb3BzLm5hbWUgPz8gYGFjdGlvbl9ncm91cF9xdWlja19zdGFydF8ke2NyeXB0by5yYW5kb21VVUlEKCl9YDtcbiAgICB0aGlzLmRlc2NyaXB0aW9uID0gcHJvcHMuZGVzY3JpcHRpb247XG4gICAgdGhpcy5hcGlTY2hlbWEgPSBwcm9wcy5hcGlTY2hlbWE7XG4gICAgdGhpcy5leGVjdXRvciA9IHByb3BzLmV4ZWN1dG9yO1xuICAgIHRoaXMuZW5hYmxlZCA9IHByb3BzLmVuYWJsZWQgPz8gdHJ1ZTtcbiAgICB0aGlzLmZvcmNlRGVsZXRlID0gcHJvcHMuZm9yY2VEZWxldGUgPz8gZmFsc2U7XG4gICAgdGhpcy5mdW5jdGlvblNjaGVtYSA9IHByb3BzLmZ1bmN0aW9uU2NoZW1hO1xuICAgIHRoaXMucGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmUgPSBwcm9wcy5wYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZTtcbiAgfVxuXG4gIHByaXZhdGUgdmFsaWRhdGVQcm9wcyhwcm9wczogQWdlbnRBY3Rpb25Hcm91cFByb3BzKSB7XG4gICAgaWYgKHByb3BzLnBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlICYmIChwcm9wcy5kZXNjcmlwdGlvbiB8fCBwcm9wcy5hcGlTY2hlbWEgfHwgcHJvcHMuZXhlY3V0b3IpKSB7XG4gICAgICB0aHJvdyBuZXcgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IoXG4gICAgICAgIGxpdGBQYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZUNvbmZsaWN0YCxcbiAgICAgICAgJ1doZW4gcGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmUgaXMgc3BlY2lmaWVkLCB5b3UgbXVzdCBsZWF2ZSB0aGUgZGVzY3JpcHRpb24sICcgK1xuICAgICAgICAgICdhcGlTY2hlbWEsIGFuZCBhY3Rpb25Hcm91cEV4ZWN1dG9yIGZpZWxkcyBibGFuayBmb3IgdGhpcyBhY3Rpb24gZ3JvdXAnLFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRm9ybWF0IGFzIENGTiBwcm9wZXJ0aWVzXG4gICAqXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIF9yZW5kZXIoKTogQ2ZuQWdlbnQuQWdlbnRBY3Rpb25Hcm91cFByb3BlcnR5IHtcbiAgICByZXR1cm4ge1xuICAgICAgYWN0aW9uR3JvdXBFeGVjdXRvcjogdGhpcy5leGVjdXRvcj8uX3JlbmRlcigpLFxuICAgICAgYWN0aW9uR3JvdXBOYW1lOiB0aGlzLm5hbWUsXG4gICAgICBhY3Rpb25Hcm91cFN0YXRlOiB0aGlzLmVuYWJsZWQgPyAnRU5BQkxFRCcgOiAnRElTQUJMRUQnLFxuICAgICAgYXBpU2NoZW1hOiB0aGlzLmFwaVNjaGVtYT8uX3JlbmRlcigpLFxuICAgICAgZGVzY3JpcHRpb246IHRoaXMuZGVzY3JpcHRpb24sXG4gICAgICBmdW5jdGlvblNjaGVtYTogdGhpcy5mdW5jdGlvblNjaGVtYT8uX3JlbmRlcigpLFxuICAgICAgcGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmU6IHRoaXMucGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmU/LnRvU3RyaW5nKCksXG4gICAgICBza2lwUmVzb3VyY2VJblVzZUNoZWNrT25EZWxldGU6IHRoaXMuZm9yY2VEZWxldGUsXG4gICAgfTtcbiAgfVxufVxuIl19