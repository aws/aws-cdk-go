"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Agent = exports.AgentBase = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const crypto = __importStar(require("crypto"));
const bedrock = __importStar(require("aws-cdk-lib/aws-bedrock"));
const cloudwatch = __importStar(require("aws-cdk-lib/aws-cloudwatch"));
const events = __importStar(require("aws-cdk-lib/aws-events"));
const iam = __importStar(require("aws-cdk-lib/aws-iam"));
const kms = __importStar(require("aws-cdk-lib/aws-kms"));
const s3 = __importStar(require("aws-cdk-lib/aws-s3"));
const core_1 = require("aws-cdk-lib/core");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
// Internal Libs
const action_group_1 = require("./action-group");
const agent_alias_1 = require("./agent-alias");
const api_schema_1 = require("./api-schema");
const orchestration_executor_1 = require("./orchestration-executor");
const validation = __importStar(require("./validation-helpers"));
/******************************************************************************
 *                              CONSTANTS
 *****************************************************************************/
/**
 * The minimum number of characters required for an agent instruction.
 * @internal
 */
const MIN_INSTRUCTION_LENGTH = 40;
/**
 * The maximum length for the node address in permission policy names.
 * @internal
 */
const MAX_POLICY_NAME_NODE_LENGTH = 16;
/******************************************************************************
 *                        ABSTRACT BASE CLASS
 *****************************************************************************/
/**
 * Abstract base class for an Agent.
 * Contains methods and attributes valid for Agents either created with CDK or imported.
 */
class AgentBase extends core_1.Resource {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AgentBase", version: "2.259.0-alpha.0" };
    /**
     * Grant invoke permissions on this agent to an IAM principal.
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant invoke permissions to
     * @default - Default grant configuration:
     * - actions: ['bedrock:InvokeAgent']
     * - resourceArns: [this.agentArn]
     * @returns An IAM Grant object representing the granted permissions
     */
    grantInvoke(grantee) {
        return iam.Grant.addToPrincipal({
            grantee,
            actions: ['bedrock:InvokeAgent'],
            resourceArns: [this.agentArn],
        });
    }
    /**
     * Creates an EventBridge rule for agent events.
     *
     * @param id - Unique identifier for the rule
     * @param options - Configuration options for the event rule
     * @default - Default event pattern:
     * - source: ['aws.bedrock']
     * - detail: { 'agent-id': [this.agentId] }
     * @returns An EventBridge Rule configured for agent events
     */
    onEvent(id, options = {}) {
        const rule = new events.Rule(this, id, options);
        rule.addEventPattern({
            source: ['aws.bedrock'],
            detail: {
                'agent-id': [this.agentId],
            },
        });
        rule.addTarget(options.target);
        return rule;
    }
    /**
     * Creates a CloudWatch metric for tracking agent invocations.
     *
     * @param props - Configuration options for the metric
     * @default - Default metric configuration:
     * - namespace: 'AWS/Bedrock'
     * - metricName: 'Invocations'
     * - dimensionsMap: { AgentId: this.agentId }
     * @returns A CloudWatch Metric configured for agent invocation counts
     */
    metricCount(props) {
        return new cloudwatch.Metric({
            namespace: 'AWS/Bedrock',
            metricName: 'Invocations',
            dimensionsMap: {
                AgentId: this.agentId,
            },
            ...props,
        }).attachTo(this);
    }
}
exports.AgentBase = AgentBase;
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create (or import) an Agent with CDK.
 * @cloudformationResource AWS::Bedrock::Agent
 */
let Agent = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = AgentBase;
    let _instanceExtraInitializers = [];
    let _addGuardrail_decorators;
    let _addActionGroup_decorators;
    let _addActionGroups_decorators;
    var Agent = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _addGuardrail_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addActionGroup_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addActionGroups_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            __esDecorate(this, null, _addGuardrail_decorators, { kind: "method", name: "addGuardrail", static: false, private: false, access: { has: obj => "addGuardrail" in obj, get: obj => obj.addGuardrail }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addActionGroup_decorators, { kind: "method", name: "addActionGroup", static: false, private: false, access: { has: obj => "addActionGroup" in obj, get: obj => obj.addActionGroup }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addActionGroups_decorators, { kind: "method", name: "addActionGroups", static: false, private: false, access: { has: obj => "addActionGroups" in obj, get: obj => obj.addActionGroups }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            Agent = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.Agent", version: "2.259.0-alpha.0" };
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.Agent';
        /**
         * Static Method for importing an existing Bedrock Agent.
         */
        /**
         * Creates an Agent reference from an existing agent's attributes.
         *
         * @param scope - The construct scope
         * @param id - Identifier of the construct
         * @param attrs - Attributes of the existing agent
         * @default - For attrs.agentVersion: 'DRAFT' if no explicit version is provided
         * @returns An IAgent reference to the existing agent
         */
        static fromAgentAttributes(scope, id, attrs) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentAttributes(attrs);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.fromAgentAttributes);
                }
                throw error;
            }
            class Import extends AgentBase {
                agentArn = attrs.agentArn;
                agentId = core_1.Arn.split(attrs.agentArn, core_1.ArnFormat.SLASH_RESOURCE_NAME).resourceName;
                role = iam.Role.fromRoleArn(scope, `${id}Role`, attrs.roleArn);
                kmsKey = attrs.kmsKeyArn ? kms.Key.fromKeyArn(scope, `${id}Key`, attrs.kmsKeyArn) : undefined;
                lastUpdated = attrs.lastUpdated;
                agentVersion = attrs.agentVersion ?? 'DRAFT';
                grantPrincipal = this.role;
            }
            // Return new Agent
            return new Import(scope, id);
        }
        // ------------------------------------------------------
        // Base attributes
        // ------------------------------------------------------
        /**
         * The unique identifier for the agent
         * @attribute
         */
        agentId = __runInitializers(this, _instanceExtraInitializers);
        /**
         * The ARN of the agent.
         * @attribute
         */
        agentArn;
        /**
         * The version of the agent.
         * @attribute
         */
        agentVersion;
        /**
         * The IAM role associated to the agent.
         */
        role;
        /**
         * Optional KMS encryption key associated with this agent
         */
        kmsKey;
        /**
         * When this agent was last updated.
         */
        lastUpdated;
        /**
         * The principal to grant permissions to
         */
        grantPrincipal;
        /**
         * Default alias of the agent
         */
        testAlias;
        /**
         * action groups associated with the ageny
         */
        actionGroups = [];
        /**
         * The guardrail that will be associated with the agent.
         */
        guardrail;
        // ------------------------------------------------------
        // CDK-only attributes
        // ------------------------------------------------------
        /**
         * The name of the agent.
         */
        name;
        // ------------------------------------------------------
        // Internal Only
        // ------------------------------------------------------
        ROLE_NAME_SUFFIX = '-bedrockagent';
        MAXLENGTH_FOR_ROLE_NAME = 64;
        idleSessionTTL;
        foundationModel;
        userInputEnabled;
        codeInterpreterEnabled;
        agentCollaboration;
        customOrchestrationExecutor;
        promptOverrideConfiguration;
        __resource;
        // ------------------------------------------------------
        // CONSTRUCTOR
        // ------------------------------------------------------
        constructor(scope, id, props) {
            super(scope, id);
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentProps(props);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, Agent);
                }
                throw error;
            }
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            // ------------------------------------------------------
            // Validate props
            // ------------------------------------------------------
            if (props.instruction !== undefined &&
                !core_1.Token.isUnresolved(props.instruction) &&
                props.instruction.length < MIN_INSTRUCTION_LENGTH) {
                throw new core_1.ValidationError((0, helpers_internal_1.lit) `InstructionTooShort`, `instruction must be at least ${MIN_INSTRUCTION_LENGTH} characters`, this);
            }
            // Validate idleSessionTTL
            if (props.idleSessionTTL !== undefined &&
                !core_1.Token.isUnresolved(props.idleSessionTTL) &&
                (props.idleSessionTTL.toMinutes() < 1 || props.idleSessionTTL.toMinutes() > 60)) {
                throw new core_1.ValidationError((0, helpers_internal_1.lit) `IdleSessionTtlOutOfRange`, 'idleSessionTTL must be between 1 and 60 minutes', this);
            }
            // ------------------------------------------------------
            // Set properties and defaults
            // ------------------------------------------------------
            this.name =
                props.agentName ?? this.generatePhysicalName() + this.ROLE_NAME_SUFFIX;
            this.idleSessionTTL = props.idleSessionTTL ?? core_1.Duration.minutes(10);
            this.userInputEnabled = props.userInputEnabled ?? false;
            this.codeInterpreterEnabled = props.codeInterpreterEnabled ?? false;
            this.foundationModel = props.foundationModel;
            // Optional
            this.promptOverrideConfiguration = props.promptOverrideConfiguration;
            this.kmsKey = props.kmsKey;
            this.customOrchestrationExecutor = props.customOrchestrationExecutor;
            // ------------------------------------------------------
            // Role
            // ------------------------------------------------------
            // If existing role is provided, use it.
            if (props.existingRole) {
                this.role = props.existingRole;
                this.grantPrincipal = this.role;
                // Otherwise, create a new one
            }
            else {
                this.role = new iam.Role(this, 'Role', {
                    // generate a role name
                    roleName: this.generatePhysicalName() + this.ROLE_NAME_SUFFIX,
                    // ensure the role has a trust policy that allows the Bedrock service to assume the role
                    assumedBy: new iam.ServicePrincipal('bedrock.amazonaws.com').withConditions({
                        StringEquals: {
                            'aws:SourceAccount': { Ref: 'AWS::AccountId' },
                        },
                        ArnLike: {
                            'aws:SourceArn': core_1.Stack.of(this).formatArn({
                                service: 'bedrock',
                                resource: 'agent',
                                resourceName: '*',
                                arnFormat: core_1.ArnFormat.SLASH_RESOURCE_NAME,
                            }),
                        },
                    }),
                });
                this.grantPrincipal = this.role;
            }
            // ------------------------------------------------------
            // Set Lazy Props initial values
            // ------------------------------------------------------
            // Add Default Action Groups
            this.addActionGroup(action_group_1.AgentActionGroup.userInput(this.userInputEnabled));
            this.addActionGroup(action_group_1.AgentActionGroup.codeInterpreter(this.codeInterpreterEnabled));
            // Add specified elems through methods to handle permissions
            // this needs to happen after role creation / assignment
            props.actionGroups?.forEach(ag => {
                this.addActionGroup(ag);
            });
            // Set agent collaboration configuration
            this.agentCollaboration = props.agentCollaboration;
            if (props.agentCollaboration) {
                props.agentCollaboration.collaborators.forEach(ac => {
                    this.grantPermissionToAgent(ac);
                });
            }
            if (props.guardrail) {
                this.addGuardrail(props.guardrail);
            }
            // Grant permissions for custom orchestration if provided
            if (this.customOrchestrationExecutor?.lambdaFunction) {
                this.customOrchestrationExecutor.lambdaFunction.grantInvoke(this.role);
                this.customOrchestrationExecutor.lambdaFunction.addPermission(`OrchestrationLambdaInvocationPolicy-${this.node.addr.slice(0, MAX_POLICY_NAME_NODE_LENGTH)}`, {
                    principal: new iam.ServicePrincipal('bedrock.amazonaws.com'),
                    sourceArn: core_1.Lazy.string({ produce: () => this.agentArn }),
                    sourceAccount: { Ref: 'AWS::AccountId' },
                });
            }
            // ------------------------------------------------------
            // CFN Props - With Lazy support
            // ------------------------------------------------------
            const cfnProps = {
                actionGroups: core_1.Lazy.any({ produce: () => this.renderActionGroups() }, { omitEmptyArray: true }),
                agentName: this.name,
                agentResourceRoleArn: this.role.roleArn,
                autoPrepare: props.shouldPrepareAgent ?? false,
                customerEncryptionKeyArn: props.kmsKey?.keyArn,
                description: props.description,
                foundationModel: this.foundationModel.invokableArn,
                guardrailConfiguration: core_1.Lazy.any({ produce: () => this.renderGuardrail() }),
                idleSessionTtlInSeconds: this.idleSessionTTL.toSeconds(),
                instruction: props.instruction,
                memoryConfiguration: props.memory?._render(),
                promptOverrideConfiguration: this.promptOverrideConfiguration?._render(),
                skipResourceInUseCheckOnDelete: props.forceDelete ?? false,
                agentCollaboration: props.agentCollaboration?.type,
                agentCollaborators: core_1.Lazy.any({ produce: () => this.renderAgentCollaborators() }, { omitEmptyArray: true }),
                customOrchestration: this.renderCustomOrchestration(),
                orchestrationType: this.customOrchestrationExecutor ? orchestration_executor_1.OrchestrationType.CUSTOM_ORCHESTRATION : orchestration_executor_1.OrchestrationType.DEFAULT,
            };
            // ------------------------------------------------------
            // L1 Instantiation
            // ------------------------------------------------------
            this.__resource = new bedrock.CfnAgent(this, 'Resource', cfnProps);
            this.agentId = this.__resource.attrAgentId;
            this.agentArn = this.__resource.attrAgentArn;
            this.agentVersion = this.__resource.attrAgentVersion;
            this.lastUpdated = this.__resource.attrUpdatedAt;
            // Add explicit dependency between the agent resource and the agent's role default policy
            // See https://github.com/awslabs/generative-ai-cdk-constructs/issues/899
            const grant = this.foundationModel.grantInvoke(this.role);
            grant.applyBefore(this.__resource);
            this.testAlias = agent_alias_1.AgentAlias.fromAttributes(this, 'DefaultAlias', {
                aliasId: 'TSTALIASID',
                aliasName: 'AgentTestAlias',
                agentVersion: 'DRAFT',
                agent: this,
            });
        }
        // ------------------------------------------------------
        // HELPER METHODS - addX()
        // ------------------------------------------------------
        /**
         * Add guardrail to the agent.
         */
        addGuardrail(guardrail) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_IGuardrail(guardrail);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addGuardrail);
                }
                throw error;
            }
            // Do some checks
            validation.throwIfInvalid(this.validateGuardrail, guardrail);
            // Add it to the construct
            this.guardrail = guardrail;
            // Handle permissions
            guardrail.grantApply(this.role);
        }
        /**
         * Adds an action group to the agent and configures necessary permissions.
         *
         * @param actionGroup - The action group to add
         * @default - Default permissions:
         * - Lambda function invoke permissions if executor is present
         * - S3 GetObject permissions if apiSchema.s3File is present
         */
        addActionGroup(actionGroup) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentActionGroup(actionGroup);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addActionGroup);
                }
                throw error;
            }
            validation.throwIfInvalid(this.validateActionGroup, actionGroup);
            this.actionGroups.push(actionGroup);
            // Handle permissions to invoke the lambda function
            actionGroup.executor?.lambdaFunction?.grantInvoke(this.role);
            actionGroup.executor?.lambdaFunction?.addPermission(`LambdaInvocationPolicy-${this.node.addr.slice(0, MAX_POLICY_NAME_NODE_LENGTH)}`, {
                principal: new iam.ServicePrincipal('bedrock.amazonaws.com'),
                sourceArn: this.agentArn,
                sourceAccount: { Ref: 'AWS::AccountId' },
            });
            // Handle permissions to access the schema file from S3
            if (actionGroup.apiSchema instanceof api_schema_1.AssetApiSchema) {
                const rendered = actionGroup.apiSchema._render();
                if (!('s3' in rendered) || !rendered.s3) {
                    throw new core_1.ValidationError((0, helpers_internal_1.lit) `S3ConfigMissing`, 'S3 configuration is missing in AssetApiSchema', this);
                }
                const s3Config = rendered.s3;
                if (!('s3BucketName' in s3Config) || !('s3ObjectKey' in s3Config)) {
                    throw new core_1.ValidationError((0, helpers_internal_1.lit) `S3BucketOrKeyMissing`, 'S3 bucket name and object key are required in AssetApiSchema', this);
                }
                const bucketName = s3Config.s3BucketName;
                const objectKey = s3Config.s3ObjectKey;
                if (!bucketName || bucketName.trim() === '') {
                    throw new core_1.ValidationError((0, helpers_internal_1.lit) `S3BucketNameEmpty`, 'S3 bucket name cannot be empty in AssetApiSchema', this);
                }
                if (!objectKey || objectKey.trim() === '') {
                    throw new core_1.ValidationError((0, helpers_internal_1.lit) `S3ObjectKeyEmpty`, 'S3 object key cannot be empty in AssetApiSchema', this);
                }
                const bucket = s3.Bucket.fromBucketName(this, `${actionGroup.name}SchemaBucket`, bucketName);
                bucket.grantRead(this.role, objectKey);
            }
            else if (actionGroup.apiSchema instanceof api_schema_1.S3ApiSchema) {
                const s3File = actionGroup.apiSchema.s3File;
                if (!s3File) {
                    throw new core_1.ValidationError((0, helpers_internal_1.lit) `S3FileMissing`, 'S3 file configuration is missing in S3ApiSchema', this);
                }
                if (!s3File.bucketName || s3File.bucketName.trim() === '') {
                    throw new core_1.ValidationError((0, helpers_internal_1.lit) `S3BucketNameEmpty`, 'S3 bucket name cannot be empty in S3ApiSchema', this);
                }
                if (!s3File.objectKey || s3File.objectKey.trim() === '') {
                    throw new core_1.ValidationError((0, helpers_internal_1.lit) `S3ObjectKeyEmpty`, 'S3 object key cannot be empty in S3ApiSchema', this);
                }
                const bucket = s3.Bucket.fromBucketName(this, `${actionGroup.name}SchemaBucket`, s3File.bucketName);
                bucket.grantRead(this.role, s3File.objectKey);
            }
        }
        /**
         * Grants permissions for an agent collaborator to this agent's role.
         * This method only grants IAM permissions and does not add the collaborator
         * to the agent's collaboration configuration. To add collaborators to the
         * agent configuration, include them in the AgentCollaboration when creating the agent.
         *
         * @param agentCollaborator - The collaborator to grant permissions for
         */
        grantPermissionToAgent(agentCollaborator) {
            agentCollaborator.grant(this.role);
        }
        /**
         * Configuration for agent collaboration.
         *
         * @default - No collaboration configuration.
         */
        addActionGroups(...actionGroups) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentActionGroup(actionGroups);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addActionGroups);
                }
                throw error;
            }
            actionGroups.forEach(ag => this.addActionGroup(ag));
        }
        // ------------------------------------------------------
        // Lazy Renderers
        // ------------------------------------------------------
        /**
         * Render the guardrail configuration.
         *
         * @internal This is an internal core function and should not be called directly.
         */
        renderGuardrail() {
            return this.guardrail
                ? {
                    guardrailIdentifier: this.guardrail.guardrailId,
                    guardrailVersion: this.guardrail.guardrailVersion,
                }
                : undefined;
        }
        /**
         * Render the action groups
         *
         * @returns Array of AgentActionGroupProperty objects in CloudFormation format
         * @default - Empty array if no action groups are defined
         * @internal This is an internal core function and should not be called directly.
         */
        renderActionGroups() {
            const actionGroupsCfn = [];
            // Build the associations in the CFN format
            this.actionGroups.forEach(ag => {
                actionGroupsCfn.push(ag._render());
            });
            return actionGroupsCfn;
        }
        /**
         * Render the agent collaborators.
         *
         * @returns Array of AgentCollaboratorProperty objects in CloudFormation format, or undefined if no collaborators
         * @default - undefined if no collaborators are defined or array is empty
         * @internal This is an internal core function and should not be called directly.
         */
        renderAgentCollaborators() {
            if (!this.agentCollaboration || !this.agentCollaboration.collaborators || this.agentCollaboration.collaborators.length === 0) {
                return undefined;
            }
            return this.agentCollaboration.collaborators.map(ac => ac._render());
        }
        /**
         * Render the custom orchestration.
         *
         * @returns CustomOrchestrationProperty object in CloudFormation format, or undefined if no custom orchestration
         * @default - undefined if no custom orchestration is defined
         * @internal This is an internal core function and should not be called directly.
         */
        renderCustomOrchestration() {
            if (!this.customOrchestrationExecutor) {
                return undefined;
            }
            return {
                executor: {
                    lambda: this.customOrchestrationExecutor.lambdaFunction.functionArn,
                },
            };
        }
        // ------------------------------------------------------
        // Validators
        // ------------------------------------------------------
        /**
         * Checks if the Guardrail is valid
         *
         * @param guardrail - The guardrail to validate
         * @returns Array of validation error messages, empty if valid
         */
        validateGuardrail = (guardrail) => {
            let errors = [];
            if (this.guardrail) {
                errors.push(`Cannot add Guardrail ${guardrail.guardrailId}. ` +
                    `Guardrail ${this.guardrail.guardrailId} has already been specified for this agent.`);
            }
            errors.push(...validation.validateFieldPattern(guardrail.guardrailVersion, 'version', /^(([0-9]{1,8})|(DRAFT))$/));
            return errors;
        };
        /**
         * Check if the action group is valid
         *
         * @param actionGroup - The action group to validate
         * @returns Array of validation error messages, empty if valid
         */
        validateActionGroup = (actionGroup) => {
            let errors = [];
            // Find if there is a conflicting action group name
            if (this.actionGroups?.find(ag => ag.name === actionGroup.name)) {
                errors.push('Action group already exists');
            }
            return errors;
        };
        /**
         * Generates a unique, deterministic name for AWS resources that includes a hash component.
         * This method ensures consistent naming while avoiding conflicts and adhering to AWS naming constraints.
         * @param scope - The construct scope used for generating unique names
         * @param prefix - The prefix to prepend to the generated name
         * @param options - Configuration options for name generation
         * @param options.maxLength - Maximum length of the generated name
         * @default - maxLength: 256
         * @param options.lower - Convert the generated name to lowercase
         * @default - lower: false
         * @param options.separator - Character(s) to use between name components
         * @default - separator: ''
         * @param options.allowedSpecialCharacters - String of allowed special characters
         * @default - undefined
         * @param options.destroyCreate - Object to include in hash generation for destroy/create operations
         * @default - undefined
         * @returns A string containing the generated name with format: prefix + hash + separator + uniqueName
         * @throws ValidationError if the generated name would exceed maxLength or if prefix is too long
         * @internal
         */
        generatePhysicalNameHash(scope, prefix, options) {
            const objectToHash = (obj) => {
                if (obj === undefined) {
                    return '';
                }
                const jsonString = JSON.stringify(obj);
                const hash = crypto.createHash('sha256');
                return hash.update(jsonString).digest('hex').slice(0, 7);
            };
            const { maxLength = 256, lower = false, separator = '', allowedSpecialCharacters = undefined, destroyCreate = undefined, } = options ?? {};
            const hash = objectToHash(destroyCreate);
            if (maxLength < (prefix + hash + separator).length) {
                throw new core_1.ValidationError((0, helpers_internal_1.lit) `PrefixTooLong`, 'The prefix is longer than the maximum length.', this);
            }
            const uniqueName = core_1.Names.uniqueResourceName(scope, { maxLength: maxLength - (prefix + hash + separator).length, separator, allowedSpecialCharacters });
            const name = `${prefix}${hash}${separator}${uniqueName}`;
            if (name.length > maxLength) {
                throw new core_1.ValidationError((0, helpers_internal_1.lit) `GeneratedNameTooLong`, `The generated name is longer than the maximum length of ${maxLength}`, this);
            }
            return lower ? name.toLowerCase() : name;
        }
        /**
         * Generates a physical name for the agent.
         * @returns A unique name for the agent with appropriate length constraints
         * @default - Generated name format: 'agent-{hash}-{uniqueName}' with:
         * - maxLength: MAXLENGTH_FOR_ROLE_NAME - '-bedrockagent'.length
         * - lower: true
         * - separator: '-'
         * @protected
         */
        generatePhysicalName() {
            const maxLength = this.MAXLENGTH_FOR_ROLE_NAME - this.ROLE_NAME_SUFFIX.length;
            return this.generatePhysicalNameHash(this, 'agent', {
                maxLength,
                lower: true,
                separator: '-',
            });
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return Agent = _classThis;
})();
exports.Agent = Agent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWdlbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhZ2VudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSwrQ0FBaUM7QUFDakMsaUVBQW1EO0FBQ25ELHVFQUF5RDtBQUN6RCwrREFBaUQ7QUFDakQseURBQTJDO0FBQzNDLHlEQUEyQztBQUMzQyx1REFBeUM7QUFFekMsMkNBQWtIO0FBQ2xILDRFQUE0RDtBQUM1RCw4RUFBOEY7QUFDOUYsMEVBQTBFO0FBRTFFLGdCQUFnQjtBQUNoQixpREFBa0Q7QUFFbEQsK0NBQTJDO0FBRzNDLDZDQUEyRDtBQUczRCxxRUFBNkQ7QUFFN0QsaUVBQW1EO0FBSW5EOzsrRUFFK0U7QUFDL0U7OztHQUdHO0FBQ0gsTUFBTSxzQkFBc0IsR0FBRyxFQUFFLENBQUM7QUFFbEM7OztHQUdHO0FBQ0gsTUFBTSwyQkFBMkIsR0FBRyxFQUFFLENBQUM7QUFrRHZDOzsrRUFFK0U7QUFDL0U7OztHQUdHO0FBQ0gsTUFBc0IsU0FBVSxTQUFRLGVBQVE7O0lBYTlDOzs7Ozs7Ozs7T0FTRztJQUNJLFdBQVcsQ0FBQyxPQUF1QjtRQUN4QyxPQUFPLEdBQUcsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDO1lBQzlCLE9BQU87WUFDUCxPQUFPLEVBQUUsQ0FBQyxxQkFBcUIsQ0FBQztZQUNoQyxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1NBQzlCLENBQUMsQ0FBQztLQUNKO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0ksT0FBTyxDQUFDLEVBQVUsRUFBRSxVQUFpQyxFQUFFO1FBQzVELE1BQU0sSUFBSSxHQUFHLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ2hELElBQUksQ0FBQyxlQUFlLENBQUM7WUFDbkIsTUFBTSxFQUFFLENBQUMsYUFBYSxDQUFDO1lBQ3ZCLE1BQU0sRUFBRTtnQkFDTixVQUFVLEVBQUUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO2FBQzNCO1NBQ0YsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDL0IsT0FBTyxJQUFJLENBQUM7S0FDYjtJQUVEOzs7Ozs7Ozs7T0FTRztJQUNJLFdBQVcsQ0FBQyxLQUFnQztRQUNqRCxPQUFPLElBQUksVUFBVSxDQUFDLE1BQU0sQ0FBQztZQUMzQixTQUFTLEVBQUUsYUFBYTtZQUN4QixVQUFVLEVBQUUsYUFBYTtZQUN6QixhQUFhLEVBQUU7Z0JBQ2IsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO2FBQ3RCO1lBQ0QsR0FBRyxLQUFLO1NBQ1QsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUNuQjs7QUF6RUgsOEJBMEVDO0FBaUtEOzsrRUFFK0U7QUFDL0U7OztHQUdHO0lBRVUsS0FBSzs0QkFEakIsb0NBQWtCOzs7O3NCQUNRLFNBQVM7Ozs7O3FCQUFqQixTQUFRLFdBQVM7Ozs7d0NBNlBqQyxJQUFBLGtDQUFjLEdBQUU7MENBa0JoQixJQUFBLGtDQUFjLEdBQUU7MkNBZ0VoQixJQUFBLGtDQUFjLEdBQUU7WUFqRmpCLHVMQUFPLFlBQVksNkRBT2xCO1lBV0QsNkxBQU8sY0FBYyw2REE0Q3BCO1lBb0JELGdNQUFPLGVBQWUsNkRBRXJCO1lBbFZILDZLQTJnQkM7Ozs7O1FBMWdCQyxzQ0FBc0M7UUFDL0IsTUFBTSxDQUFVLHFCQUFxQixHQUFXLGtDQUFrQyxDQUFDO1FBRTFGOztXQUVHO1FBQ0g7Ozs7Ozs7O1dBUUc7UUFDSSxNQUFNLENBQUMsbUJBQW1CLENBQUMsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsS0FBc0I7Ozs7Ozs7Ozs7WUFDcEYsTUFBTSxNQUFPLFNBQVEsU0FBUztnQkFDWixRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQztnQkFDMUIsT0FBTyxHQUFHLFVBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxnQkFBUyxDQUFDLG1CQUFtQixDQUFDLENBQUMsWUFBYSxDQUFDO2dCQUNqRixJQUFJLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMvRCxNQUFNLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0JBQzlGLFdBQVcsR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDO2dCQUNoQyxZQUFZLEdBQUcsS0FBSyxDQUFDLFlBQVksSUFBSSxPQUFPLENBQUM7Z0JBQzdDLGNBQWMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO2FBQzVDO1lBRUQsbUJBQW1CO1lBQ25CLE9BQU8sSUFBSSxNQUFNLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQzlCO1FBQ0QseURBQXlEO1FBQ3pELGtCQUFrQjtRQUNsQix5REFBeUQ7UUFDekQ7OztXQUdHO1FBQ2EsT0FBTyxHQXJDWixtREFBSyxDQXFDZ0I7UUFDaEM7OztXQUdHO1FBQ2EsUUFBUSxDQUFTO1FBQ2pDOzs7V0FHRztRQUNhLFlBQVksQ0FBUztRQUNyQzs7V0FFRztRQUNhLElBQUksQ0FBWTtRQUNoQzs7V0FFRztRQUNhLE1BQU0sQ0FBWTtRQUNsQzs7V0FFRztRQUNhLFdBQVcsQ0FBVTtRQUNyQzs7V0FFRztRQUNhLGNBQWMsQ0FBaUI7UUFDL0M7O1dBRUc7UUFDYSxTQUFTLENBQWM7UUFDdkM7O1dBRUc7UUFDYSxZQUFZLEdBQXVCLEVBQUUsQ0FBQztRQUN0RDs7V0FFRztRQUNJLFNBQVMsQ0FBYztRQUM5Qix5REFBeUQ7UUFDekQsc0JBQXNCO1FBQ3RCLHlEQUF5RDtRQUN6RDs7V0FFRztRQUNhLElBQUksQ0FBUztRQUU3Qix5REFBeUQ7UUFDekQsZ0JBQWdCO1FBQ2hCLHlEQUF5RDtRQUN4QyxnQkFBZ0IsR0FBRyxlQUFlLENBQUM7UUFDbkMsdUJBQXVCLEdBQUcsRUFBRSxDQUFDO1FBQzdCLGNBQWMsQ0FBVztRQUN6QixlQUFlLENBQW9CO1FBQ25DLGdCQUFnQixDQUFVO1FBQzFCLHNCQUFzQixDQUFVO1FBQ2hDLGtCQUFrQixDQUFzQjtRQUN4QywyQkFBMkIsQ0FBK0I7UUFDMUQsMkJBQTJCLENBQStCO1FBQzFELFVBQVUsQ0FBbUI7UUFFOUMseURBQXlEO1FBQ3pELGNBQWM7UUFDZCx5REFBeUQ7UUFDekQsWUFBWSxLQUFnQixFQUFFLEVBQVUsRUFBRSxLQUFpQjtZQUN6RCxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDOzs7Ozs7bURBdEdSLEtBQUs7Ozs7WUF1R2QsbUNBQW1DO1lBQ25DLElBQUEsd0NBQW9CLEVBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRWxDLHlEQUF5RDtZQUN6RCxpQkFBaUI7WUFDakIseURBQXlEO1lBQ3pELElBQUksS0FBSyxDQUFDLFdBQVcsS0FBSyxTQUFTO2dCQUMvQixDQUFDLFlBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQztnQkFDdEMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsc0JBQXNCLEVBQUUsQ0FBQztnQkFDdEQsTUFBTSxJQUFJLHNCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHFCQUFxQixFQUFFLGdDQUFnQyxzQkFBc0IsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ2pJLENBQUM7WUFFRCwwQkFBMEI7WUFDMUIsSUFBSSxLQUFLLENBQUMsY0FBYyxLQUFLLFNBQVM7Z0JBQ2xDLENBQUMsWUFBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDO2dCQUN6QyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxJQUFJLEtBQUssQ0FBQyxjQUFjLENBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQztnQkFDcEYsTUFBTSxJQUFJLHNCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLDBCQUEwQixFQUFFLGlEQUFpRCxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3BILENBQUM7WUFFRCx5REFBeUQ7WUFDekQsOEJBQThCO1lBQzlCLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMsSUFBSTtnQkFDUCxLQUFLLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztZQUN6RSxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQyxjQUFjLElBQUksZUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNuRSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLGdCQUFnQixJQUFJLEtBQUssQ0FBQztZQUN4RCxJQUFJLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDLHNCQUFzQixJQUFJLEtBQUssQ0FBQztZQUNwRSxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQyxlQUFlLENBQUM7WUFDN0MsV0FBVztZQUNYLElBQUksQ0FBQywyQkFBMkIsR0FBRyxLQUFLLENBQUMsMkJBQTJCLENBQUM7WUFDckUsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBQzNCLElBQUksQ0FBQywyQkFBMkIsR0FBRyxLQUFLLENBQUMsMkJBQTJCLENBQUM7WUFFckUseURBQXlEO1lBQ3pELE9BQU87WUFDUCx5REFBeUQ7WUFDekQsd0NBQXdDO1lBQ3hDLElBQUksS0FBSyxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUN2QixJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUM7Z0JBQy9CLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFDaEMsOEJBQThCO1lBQ2hDLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFO29CQUNyQyx1QkFBdUI7b0JBQ3ZCLFFBQVEsRUFBRSxJQUFJLENBQUMsb0JBQW9CLEVBQUUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCO29CQUM3RCx3RkFBd0Y7b0JBQ3hGLFNBQVMsRUFBRSxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLGNBQWMsQ0FBQzt3QkFDMUUsWUFBWSxFQUFFOzRCQUNaLG1CQUFtQixFQUFFLEVBQUUsR0FBRyxFQUFFLGdCQUFnQixFQUFFO3lCQUMvQzt3QkFDRCxPQUFPLEVBQUU7NEJBQ1AsZUFBZSxFQUFFLFlBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDO2dDQUN4QyxPQUFPLEVBQUUsU0FBUztnQ0FDbEIsUUFBUSxFQUFFLE9BQU87Z0NBQ2pCLFlBQVksRUFBRSxHQUFHO2dDQUNqQixTQUFTLEVBQUUsZ0JBQVMsQ0FBQyxtQkFBbUI7NkJBQ3pDLENBQUM7eUJBQ0g7cUJBQ0YsQ0FBQztpQkFDSCxDQUFDLENBQUM7Z0JBQ0gsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ2xDLENBQUM7WUFDRCx5REFBeUQ7WUFDekQsZ0NBQWdDO1lBQ2hDLHlEQUF5RDtZQUN6RCw0QkFBNEI7WUFDNUIsSUFBSSxDQUFDLGNBQWMsQ0FBQywrQkFBZ0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztZQUN2RSxJQUFJLENBQUMsY0FBYyxDQUFDLCtCQUFnQixDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO1lBRW5GLDREQUE0RDtZQUM1RCx3REFBd0Q7WUFDeEQsS0FBSyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUU7Z0JBQy9CLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDMUIsQ0FBQyxDQUFDLENBQUM7WUFFSCx3Q0FBd0M7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQztZQUNuRCxJQUFJLEtBQUssQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO2dCQUM3QixLQUFLLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRTtvQkFDbEQsSUFBSSxDQUFDLHNCQUFzQixDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNsQyxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUM7WUFFRCxJQUFJLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDcEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDckMsQ0FBQztZQUVELHlEQUF5RDtZQUN6RCxJQUFJLElBQUksQ0FBQywyQkFBMkIsRUFBRSxjQUFjLEVBQUUsQ0FBQztnQkFDckQsSUFBSSxDQUFDLDJCQUEyQixDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN2RSxJQUFJLENBQUMsMkJBQTJCLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyx1Q0FBdUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSwyQkFBMkIsQ0FBQyxFQUFFLEVBQUU7b0JBQzNKLFNBQVMsRUFBRSxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQztvQkFDNUQsU0FBUyxFQUFFLFdBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUN4RCxhQUFhLEVBQUUsRUFBRSxHQUFHLEVBQUUsZ0JBQWdCLEVBQVM7aUJBQ2hELENBQUMsQ0FBQztZQUNMLENBQUM7WUFFRCx5REFBeUQ7WUFDekQsZ0NBQWdDO1lBQ2hDLHlEQUF5RDtZQUN6RCxNQUFNLFFBQVEsR0FBMEI7Z0JBQ3RDLFlBQVksRUFBRSxXQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLENBQUM7Z0JBQzlGLFNBQVMsRUFBRSxJQUFJLENBQUMsSUFBSTtnQkFDcEIsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPO2dCQUN2QyxXQUFXLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixJQUFJLEtBQUs7Z0JBQzlDLHdCQUF3QixFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTTtnQkFDOUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXO2dCQUM5QixlQUFlLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZO2dCQUNsRCxzQkFBc0IsRUFBRSxXQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsRUFBRSxDQUFDO2dCQUMzRSx1QkFBdUIsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRTtnQkFDeEQsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXO2dCQUM5QixtQkFBbUIsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRTtnQkFDNUMsMkJBQTJCLEVBQUUsSUFBSSxDQUFDLDJCQUEyQixFQUFFLE9BQU8sRUFBRTtnQkFDeEUsOEJBQThCLEVBQUUsS0FBSyxDQUFDLFdBQVcsSUFBSSxLQUFLO2dCQUMxRCxrQkFBa0IsRUFBRSxLQUFLLENBQUMsa0JBQWtCLEVBQUUsSUFBSTtnQkFDbEQsa0JBQWtCLEVBQUUsV0FBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsRUFBRSxFQUFFLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxDQUFDO2dCQUMxRyxtQkFBbUIsRUFBRSxJQUFJLENBQUMseUJBQXlCLEVBQUU7Z0JBQ3JELGlCQUFpQixFQUFFLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsMENBQWlCLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLDBDQUFpQixDQUFDLE9BQU87YUFDekgsQ0FBQztZQUVGLHlEQUF5RDtZQUN6RCxtQkFBbUI7WUFDbkIseURBQXlEO1lBQ3pELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFFbkUsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQztZQUMzQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDO1lBQzdDLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQztZQUNyRCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO1lBRWpELHlGQUF5RjtZQUN6Rix5RUFBeUU7WUFDekUsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzFELEtBQUssQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRW5DLElBQUksQ0FBQyxTQUFTLEdBQUcsd0JBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLGNBQWMsRUFBRTtnQkFDL0QsT0FBTyxFQUFFLFlBQVk7Z0JBQ3JCLFNBQVMsRUFBRSxnQkFBZ0I7Z0JBQzNCLFlBQVksRUFBRSxPQUFPO2dCQUNyQixLQUFLLEVBQUUsSUFBSTthQUNaLENBQUMsQ0FBQztTQUNKO1FBRUQseURBQXlEO1FBQ3pELDBCQUEwQjtRQUMxQix5REFBeUQ7UUFFekQ7O1dBRUc7UUFFSSxZQUFZLENBQUMsU0FBcUI7Ozs7Ozs7Ozs7WUFDdkMsaUJBQWlCO1lBQ2pCLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQzdELDBCQUEwQjtZQUMxQixJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztZQUMzQixxQkFBcUI7WUFDckIsU0FBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDakM7UUFFRDs7Ozs7OztXQU9HO1FBRUksY0FBYyxDQUFDLFdBQTZCOzs7Ozs7Ozs7O1lBQ2pELFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLFdBQVcsQ0FBQyxDQUFDO1lBQ2pFLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3BDLG1EQUFtRDtZQUNuRCxXQUFXLENBQUMsUUFBUSxFQUFFLGNBQWMsRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzdELFdBQVcsQ0FBQyxRQUFRLEVBQUUsY0FBYyxFQUFFLGFBQWEsQ0FBQywwQkFBMEIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSwyQkFBMkIsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3BJLFNBQVMsRUFBRSxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQztnQkFDNUQsU0FBUyxFQUFFLElBQUksQ0FBQyxRQUFRO2dCQUN4QixhQUFhLEVBQUUsRUFBRSxHQUFHLEVBQUUsZ0JBQWdCLEVBQVM7YUFDaEQsQ0FBQyxDQUFDO1lBQ0gsdURBQXVEO1lBQ3ZELElBQUksV0FBVyxDQUFDLFNBQVMsWUFBWSwyQkFBYyxFQUFFLENBQUM7Z0JBQ3BELE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ2pELElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQztvQkFDeEMsTUFBTSxJQUFJLHNCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLGlCQUFpQixFQUFFLCtDQUErQyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN6RyxDQUFDO2dCQUNELE1BQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxFQUFFLENBQUM7Z0JBQzdCLElBQUksQ0FBQyxDQUFDLGNBQWMsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsYUFBYSxJQUFJLFFBQVEsQ0FBQyxFQUFFLENBQUM7b0JBQ2xFLE1BQU0sSUFBSSxzQkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSxzQkFBc0IsRUFBRSw4REFBOEQsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDN0gsQ0FBQztnQkFDRCxNQUFNLFVBQVUsR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDO2dCQUN6QyxNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDO2dCQUN2QyxJQUFJLENBQUMsVUFBVSxJQUFJLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQztvQkFDNUMsTUFBTSxJQUFJLHNCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLG1CQUFtQixFQUFFLGtEQUFrRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUM5RyxDQUFDO2dCQUNELElBQUksQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDO29CQUMxQyxNQUFNLElBQUksc0JBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsa0JBQWtCLEVBQUUsaURBQWlELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzVHLENBQUM7Z0JBQ0QsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLEdBQUcsV0FBVyxDQUFDLElBQUksY0FBYyxFQUFFLFVBQVUsQ0FBQyxDQUFDO2dCQUM3RixNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUM7WUFDekMsQ0FBQztpQkFBTSxJQUFJLFdBQVcsQ0FBQyxTQUFTLFlBQVksd0JBQVcsRUFBRSxDQUFDO2dCQUN4RCxNQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztnQkFDNUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO29CQUNaLE1BQU0sSUFBSSxzQkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSxlQUFlLEVBQUUsaURBQWlELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3pHLENBQUM7Z0JBQ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLElBQUksTUFBTSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQztvQkFDMUQsTUFBTSxJQUFJLHNCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLG1CQUFtQixFQUFFLCtDQUErQyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMzRyxDQUFDO2dCQUNELElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUM7b0JBQ3hELE1BQU0sSUFBSSxzQkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSxrQkFBa0IsRUFBRSw4Q0FBOEMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDekcsQ0FBQztnQkFDRCxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxXQUFXLENBQUMsSUFBSSxjQUFjLEVBQUUsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUNwRyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ2hELENBQUM7U0FDRjtRQUVEOzs7Ozs7O1dBT0c7UUFDSyxzQkFBc0IsQ0FBQyxpQkFBb0M7WUFDakUsaUJBQWlCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNwQztRQUVEOzs7O1dBSUc7UUFFSSxlQUFlLENBQUMsR0FBRyxZQUFnQzs7Ozs7Ozs7OztZQUN4RCxZQUFZLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQ3JEO1FBRUQseURBQXlEO1FBQ3pELGlCQUFpQjtRQUNqQix5REFBeUQ7UUFFekQ7Ozs7V0FJRztRQUNLLGVBQWU7WUFDckIsT0FBTyxJQUFJLENBQUMsU0FBUztnQkFDbkIsQ0FBQyxDQUFDO29CQUNBLG1CQUFtQixFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVztvQkFDL0MsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0I7aUJBQ2xEO2dCQUNELENBQUMsQ0FBQyxTQUFTLENBQUM7U0FDZjtRQUVEOzs7Ozs7V0FNRztRQUNLLGtCQUFrQjtZQUN4QixNQUFNLGVBQWUsR0FBZ0QsRUFBRSxDQUFDO1lBQ3hFLDJDQUEyQztZQUMzQyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRTtnQkFDN0IsZUFBZSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUNyQyxDQUFDLENBQUMsQ0FBQztZQUNILE9BQU8sZUFBZSxDQUFDO1NBQ3hCO1FBRUQ7Ozs7OztXQU1HO1FBQ0ssd0JBQXdCO1lBQzlCLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUM3SCxPQUFPLFNBQVMsQ0FBQztZQUNuQixDQUFDO1lBRUQsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1NBQ3RFO1FBRUQ7Ozs7OztXQU1HO1FBQ0sseUJBQXlCO1lBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztnQkFDdEMsT0FBTyxTQUFTLENBQUM7WUFDbkIsQ0FBQztZQUVELE9BQU87Z0JBQ0wsUUFBUSxFQUFFO29CQUNSLE1BQU0sRUFBRSxJQUFJLENBQUMsMkJBQTJCLENBQUMsY0FBYyxDQUFDLFdBQVc7aUJBQ3BFO2FBQ0YsQ0FBQztTQUNIO1FBRUQseURBQXlEO1FBQ3pELGFBQWE7UUFDYix5REFBeUQ7UUFDekQ7Ozs7O1dBS0c7UUFDSyxpQkFBaUIsR0FBRyxDQUFDLFNBQXFCLEVBQUUsRUFBRTtZQUNwRCxJQUFJLE1BQU0sR0FBYSxFQUFFLENBQUM7WUFDMUIsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQ25CLE1BQU0sQ0FBQyxJQUFJLENBQ1Qsd0JBQXdCLFNBQVMsQ0FBQyxXQUFXLElBQUk7b0JBQy9DLGFBQWEsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLDZDQUE2QyxDQUN2RixDQUFDO1lBQ0osQ0FBQztZQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxVQUFVLENBQUMsb0JBQW9CLENBQUMsU0FBUyxDQUFDLGdCQUFnQixFQUFFLFNBQVMsRUFBRSwwQkFBMEIsQ0FBQyxDQUFDLENBQUM7WUFDbkgsT0FBTyxNQUFNLENBQUM7UUFDaEIsQ0FBQyxDQUFDO1FBRUY7Ozs7O1dBS0c7UUFDSyxtQkFBbUIsR0FBRyxDQUFDLFdBQTZCLEVBQUUsRUFBRTtZQUM5RCxJQUFJLE1BQU0sR0FBYSxFQUFFLENBQUM7WUFDMUIsbURBQW1EO1lBQ25ELElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxLQUFLLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO2dCQUNoRSxNQUFNLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDLENBQUM7WUFDN0MsQ0FBQztZQUNELE9BQU8sTUFBTSxDQUFDO1FBQ2hCLENBQUMsQ0FBQztRQUVGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O1dBbUJHO1FBQ0ssd0JBQXdCLENBQzlCLEtBQWlCLEVBQ2pCLE1BQWMsRUFDZCxPQU1DO1lBRUQsTUFBTSxZQUFZLEdBQUcsQ0FBQyxHQUFRLEVBQVUsRUFBRTtnQkFDeEMsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQUMsQ0FBQztnQkFDckMsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDdkMsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDekMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzNELENBQUMsQ0FBQztZQUVGLE1BQU0sRUFDSixTQUFTLEdBQUcsR0FBRyxFQUNmLEtBQUssR0FBRyxLQUFLLEVBQ2IsU0FBUyxHQUFHLEVBQUUsRUFDZCx3QkFBd0IsR0FBRyxTQUFTLEVBQ3BDLGFBQWEsR0FBRyxTQUFTLEdBQzFCLEdBQUcsT0FBTyxJQUFJLEVBQUUsQ0FBQztZQUVsQixNQUFNLElBQUksR0FBRyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDekMsSUFBSSxTQUFTLEdBQUcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxHQUFHLFNBQVMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNuRCxNQUFNLElBQUksc0JBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsZUFBZSxFQUFFLCtDQUErQyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3ZHLENBQUM7WUFFRCxNQUFNLFVBQVUsR0FBRyxZQUFLLENBQUMsa0JBQWtCLENBQ3pDLEtBQUssRUFDTCxFQUFFLFNBQVMsRUFBRSxTQUFTLEdBQUcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxHQUFHLFNBQVMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsd0JBQXdCLEVBQUUsQ0FDbkcsQ0FBQztZQUNGLE1BQU0sSUFBSSxHQUFHLEdBQUcsTUFBTSxHQUFHLElBQUksR0FBRyxTQUFTLEdBQUcsVUFBVSxFQUFFLENBQUM7WUFDekQsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLFNBQVMsRUFBRSxDQUFDO2dCQUM1QixNQUFNLElBQUksc0JBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsc0JBQXNCLEVBQUUsMkRBQTJELFNBQVMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3JJLENBQUM7WUFDRCxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7U0FDMUM7UUFFRDs7Ozs7Ozs7V0FRRztRQUNPLG9CQUFvQjtZQUM1QixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztZQUM5RSxPQUFPLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFO2dCQUNsRCxTQUFTO2dCQUNULEtBQUssRUFBRSxJQUFJO2dCQUNYLFNBQVMsRUFBRSxHQUFHO2FBQ2YsQ0FBQyxDQUFDO1NBQ0o7O1lBMWdCVSx1REFBSzs7Ozs7QUFBTCxzQkFBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGNyeXB0byBmcm9tICdjcnlwdG8nO1xuaW1wb3J0ICogYXMgYmVkcm9jayBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgKiBhcyBjbG91ZHdhdGNoIGZyb20gJ2F3cy1jZGstbGliL2F3cy1jbG91ZHdhdGNoJztcbmltcG9ydCAqIGFzIGV2ZW50cyBmcm9tICdhd3MtY2RrLWxpYi9hd3MtZXZlbnRzJztcbmltcG9ydCAqIGFzIGlhbSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCAqIGFzIGttcyBmcm9tICdhd3MtY2RrLWxpYi9hd3Mta21zJztcbmltcG9ydCAqIGFzIHMzIGZyb20gJ2F3cy1jZGstbGliL2F3cy1zMyc7XG5pbXBvcnQgdHlwZSB7IElSZXNvdXJjZSB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUnO1xuaW1wb3J0IHsgQXJuLCBBcm5Gb3JtYXQsIER1cmF0aW9uLCBMYXp5LCBOYW1lcywgUmVzb3VyY2UsIFN0YWNrLCBUb2tlbiwgVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZSc7XG5pbXBvcnQgeyBsaXQgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9oZWxwZXJzLWludGVybmFsJztcbmltcG9ydCB7IGFkZENvbnN0cnVjdE1ldGFkYXRhLCBNZXRob2RNZXRhZGF0YSB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL21ldGFkYXRhLXJlc291cmNlJztcbmltcG9ydCB7IHByb3BlcnR5SW5qZWN0YWJsZSB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL3Byb3AtaW5qZWN0YWJsZSc7XG5pbXBvcnQgdHlwZSB7IENvbnN0cnVjdCwgSUNvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuLy8gSW50ZXJuYWwgTGlic1xuaW1wb3J0IHsgQWdlbnRBY3Rpb25Hcm91cCB9IGZyb20gJy4vYWN0aW9uLWdyb3VwJztcbmltcG9ydCB0eXBlIHsgSUFnZW50QWxpYXMgfSBmcm9tICcuL2FnZW50LWFsaWFzJztcbmltcG9ydCB7IEFnZW50QWxpYXMgfSBmcm9tICcuL2FnZW50LWFsaWFzJztcbmltcG9ydCB0eXBlIHsgQWdlbnRDb2xsYWJvcmF0aW9uIH0gZnJvbSAnLi9hZ2VudC1jb2xsYWJvcmF0aW9uJztcbmltcG9ydCB0eXBlIHsgQWdlbnRDb2xsYWJvcmF0b3IgfSBmcm9tICcuL2FnZW50LWNvbGxhYm9yYXRvcic7XG5pbXBvcnQgeyBBc3NldEFwaVNjaGVtYSwgUzNBcGlTY2hlbWEgfSBmcm9tICcuL2FwaS1zY2hlbWEnO1xuaW1wb3J0IHR5cGUgeyBNZW1vcnkgfSBmcm9tICcuL21lbW9yeSc7XG5pbXBvcnQgdHlwZSB7IEN1c3RvbU9yY2hlc3RyYXRpb25FeGVjdXRvciB9IGZyb20gJy4vb3JjaGVzdHJhdGlvbi1leGVjdXRvcic7XG5pbXBvcnQgeyBPcmNoZXN0cmF0aW9uVHlwZSB9IGZyb20gJy4vb3JjaGVzdHJhdGlvbi1leGVjdXRvcic7XG5pbXBvcnQgdHlwZSB7IFByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbiB9IGZyb20gJy4vcHJvbXB0LW92ZXJyaWRlJztcbmltcG9ydCAqIGFzIHZhbGlkYXRpb24gZnJvbSAnLi92YWxpZGF0aW9uLWhlbHBlcnMnO1xuaW1wb3J0IHR5cGUgeyBJQmVkcm9ja0ludm9rYWJsZSB9IGZyb20gJy4uLy4vbW9kZWxzJztcbmltcG9ydCB0eXBlIHsgSUd1YXJkcmFpbCB9IGZyb20gJy4uL2d1YXJkcmFpbHMvZ3VhcmRyYWlscyc7XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ09OU1RBTlRTXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIFRoZSBtaW5pbXVtIG51bWJlciBvZiBjaGFyYWN0ZXJzIHJlcXVpcmVkIGZvciBhbiBhZ2VudCBpbnN0cnVjdGlvbi5cbiAqIEBpbnRlcm5hbFxuICovXG5jb25zdCBNSU5fSU5TVFJVQ1RJT05fTEVOR1RIID0gNDA7XG5cbi8qKlxuICogVGhlIG1heGltdW0gbGVuZ3RoIGZvciB0aGUgbm9kZSBhZGRyZXNzIGluIHBlcm1pc3Npb24gcG9saWN5IG5hbWVzLlxuICogQGludGVybmFsXG4gKi9cbmNvbnN0IE1BWF9QT0xJQ1lfTkFNRV9OT0RFX0xFTkdUSCA9IDE2O1xuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENPTU1PTlxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBSZXByZXNlbnRzIGFuIEFnZW50LCBlaXRoZXIgY3JlYXRlZCB3aXRoIENESyBvciBpbXBvcnRlZC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBJQWdlbnQgZXh0ZW5kcyBJUmVzb3VyY2UsIGlhbS5JR3JhbnRhYmxlIHtcbiAgLyoqXG4gICAqIFRoZSBBUk4gb2YgdGhlIGFnZW50LlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICByZWFkb25seSBhZ2VudEFybjogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIElEIG9mIHRoZSBBZ2VudC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcmVhZG9ubHkgYWdlbnRJZDogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIElBTSByb2xlIGFzc29jaWF0ZWQgdG8gdGhlIGFnZW50LlxuICAgKi9cbiAgcmVhZG9ubHkgcm9sZTogaWFtLklSb2xlO1xuICAvKipcbiAgICogT3B0aW9uYWwgS01TIGVuY3J5cHRpb24ga2V5IGFzc29jaWF0ZWQgd2l0aCB0aGlzIGFnZW50XG4gICAqL1xuICByZWFkb25seSBrbXNLZXk/OiBrbXMuSUtleTtcbiAgLyoqXG4gICAqIFdoZW4gdGhpcyBhZ2VudCB3YXMgbGFzdCB1cGRhdGVkLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICByZWFkb25seSBsYXN0VXBkYXRlZD86IHN0cmluZztcblxuICAvKipcbiAgICogR3JhbnQgaW52b2tlIHBlcm1pc3Npb25zIG9uIHRoaXMgYWdlbnQgdG8gYW4gSUFNIHByaW5jaXBhbC5cbiAgICogTm90ZTogVGhpcyBncmFudCB3aWxsIG9ubHkgd29yayB3aGVuIHRoZSBncmFudGVlIGlzIGluIHRoZSBzYW1lIEFXUyBhY2NvdW50XG4gICAqIHdoZXJlIHRoZSBhZ2VudCBpcyBkZWZpbmVkLiBDcm9zcy1hY2NvdW50IGludm9jYXRpb24gaXMgbm90IHN1cHBvcnRlZC5cbiAgICovXG4gIGdyYW50SW52b2tlKGdyYW50ZWU6IGlhbS5JR3JhbnRhYmxlKTogaWFtLkdyYW50O1xuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgQ2xvdWRXYXRjaCBldmVudCBydWxlIHRyaWdnZXJlZCBieSBhZ2VudCBldmVudHMuXG4gICAqL1xuICBvbkV2ZW50KGlkOiBzdHJpbmcsIG9wdGlvbnM/OiBldmVudHMuT25FdmVudE9wdGlvbnMpOiBldmVudHMuUnVsZTtcblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBDbG91ZFdhdGNoIG1ldHJpYyBmb3IgYWdlbnQgY291bnQuXG4gICAqL1xuICBtZXRyaWNDb3VudChwcm9wcz86IGNsb3Vkd2F0Y2guTWV0cmljT3B0aW9ucyk6IGNsb3Vkd2F0Y2guTWV0cmljO1xufVxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBBQlNUUkFDVCBCQVNFIENMQVNTXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIEFic3RyYWN0IGJhc2UgY2xhc3MgZm9yIGFuIEFnZW50LlxuICogQ29udGFpbnMgbWV0aG9kcyBhbmQgYXR0cmlidXRlcyB2YWxpZCBmb3IgQWdlbnRzIGVpdGhlciBjcmVhdGVkIHdpdGggQ0RLIG9yIGltcG9ydGVkLlxuICovXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgQWdlbnRCYXNlIGV4dGVuZHMgUmVzb3VyY2UgaW1wbGVtZW50cyBJQWdlbnQge1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkgYWdlbnRBcm46IHN0cmluZztcbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGFnZW50SWQ6IHN0cmluZztcbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IHJvbGU6IGlhbS5JUm9sZTtcbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGttc0tleT86IGttcy5JS2V5O1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkgbGFzdFVwZGF0ZWQ/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgdmVyc2lvbiBvZiB0aGUgYWdlbnQuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSBhZ2VudFZlcnNpb246IHN0cmluZztcbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGdyYW50UHJpbmNpcGFsOiBpYW0uSVByaW5jaXBhbDtcblxuICAvKipcbiAgICogR3JhbnQgaW52b2tlIHBlcm1pc3Npb25zIG9uIHRoaXMgYWdlbnQgdG8gYW4gSUFNIHByaW5jaXBhbC5cbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqXG4gICAqIEBwYXJhbSBncmFudGVlIC0gVGhlIElBTSBwcmluY2lwYWwgdG8gZ3JhbnQgaW52b2tlIHBlcm1pc3Npb25zIHRvXG4gICAqIEBkZWZhdWx0IC0gRGVmYXVsdCBncmFudCBjb25maWd1cmF0aW9uOlxuICAgKiAtIGFjdGlvbnM6IFsnYmVkcm9jazpJbnZva2VBZ2VudCddXG4gICAqIC0gcmVzb3VyY2VBcm5zOiBbdGhpcy5hZ2VudEFybl1cbiAgICogQHJldHVybnMgQW4gSUFNIEdyYW50IG9iamVjdCByZXByZXNlbnRpbmcgdGhlIGdyYW50ZWQgcGVybWlzc2lvbnNcbiAgICovXG4gIHB1YmxpYyBncmFudEludm9rZShncmFudGVlOiBpYW0uSUdyYW50YWJsZSk6IGlhbS5HcmFudCB7XG4gICAgcmV0dXJuIGlhbS5HcmFudC5hZGRUb1ByaW5jaXBhbCh7XG4gICAgICBncmFudGVlLFxuICAgICAgYWN0aW9uczogWydiZWRyb2NrOkludm9rZUFnZW50J10sXG4gICAgICByZXNvdXJjZUFybnM6IFt0aGlzLmFnZW50QXJuXSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGFuIEV2ZW50QnJpZGdlIHJ1bGUgZm9yIGFnZW50IGV2ZW50cy5cbiAgICpcbiAgICogQHBhcmFtIGlkIC0gVW5pcXVlIGlkZW50aWZpZXIgZm9yIHRoZSBydWxlXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gQ29uZmlndXJhdGlvbiBvcHRpb25zIGZvciB0aGUgZXZlbnQgcnVsZVxuICAgKiBAZGVmYXVsdCAtIERlZmF1bHQgZXZlbnQgcGF0dGVybjpcbiAgICogLSBzb3VyY2U6IFsnYXdzLmJlZHJvY2snXVxuICAgKiAtIGRldGFpbDogeyAnYWdlbnQtaWQnOiBbdGhpcy5hZ2VudElkXSB9XG4gICAqIEByZXR1cm5zIEFuIEV2ZW50QnJpZGdlIFJ1bGUgY29uZmlndXJlZCBmb3IgYWdlbnQgZXZlbnRzXG4gICAqL1xuICBwdWJsaWMgb25FdmVudChpZDogc3RyaW5nLCBvcHRpb25zOiBldmVudHMuT25FdmVudE9wdGlvbnMgPSB7fSk6IGV2ZW50cy5SdWxlIHtcbiAgICBjb25zdCBydWxlID0gbmV3IGV2ZW50cy5SdWxlKHRoaXMsIGlkLCBvcHRpb25zKTtcbiAgICBydWxlLmFkZEV2ZW50UGF0dGVybih7XG4gICAgICBzb3VyY2U6IFsnYXdzLmJlZHJvY2snXSxcbiAgICAgIGRldGFpbDoge1xuICAgICAgICAnYWdlbnQtaWQnOiBbdGhpcy5hZ2VudElkXSxcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICBydWxlLmFkZFRhcmdldChvcHRpb25zLnRhcmdldCk7XG4gICAgcmV0dXJuIHJ1bGU7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBhIENsb3VkV2F0Y2ggbWV0cmljIGZvciB0cmFja2luZyBhZ2VudCBpbnZvY2F0aW9ucy5cbiAgICpcbiAgICogQHBhcmFtIHByb3BzIC0gQ29uZmlndXJhdGlvbiBvcHRpb25zIGZvciB0aGUgbWV0cmljXG4gICAqIEBkZWZhdWx0IC0gRGVmYXVsdCBtZXRyaWMgY29uZmlndXJhdGlvbjpcbiAgICogLSBuYW1lc3BhY2U6ICdBV1MvQmVkcm9jaydcbiAgICogLSBtZXRyaWNOYW1lOiAnSW52b2NhdGlvbnMnXG4gICAqIC0gZGltZW5zaW9uc01hcDogeyBBZ2VudElkOiB0aGlzLmFnZW50SWQgfVxuICAgKiBAcmV0dXJucyBBIENsb3VkV2F0Y2ggTWV0cmljIGNvbmZpZ3VyZWQgZm9yIGFnZW50IGludm9jYXRpb24gY291bnRzXG4gICAqL1xuICBwdWJsaWMgbWV0cmljQ291bnQocHJvcHM/OiBjbG91ZHdhdGNoLk1ldHJpY09wdGlvbnMpOiBjbG91ZHdhdGNoLk1ldHJpYyB7XG4gICAgcmV0dXJuIG5ldyBjbG91ZHdhdGNoLk1ldHJpYyh7XG4gICAgICBuYW1lc3BhY2U6ICdBV1MvQmVkcm9jaycsXG4gICAgICBtZXRyaWNOYW1lOiAnSW52b2NhdGlvbnMnLFxuICAgICAgZGltZW5zaW9uc01hcDoge1xuICAgICAgICBBZ2VudElkOiB0aGlzLmFnZW50SWQsXG4gICAgICB9LFxuICAgICAgLi4ucHJvcHMsXG4gICAgfSkuYXR0YWNoVG8odGhpcyk7XG4gIH1cbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBQUk9QUyBGT1IgTkVXIENPTlNUUlVDVFxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBjcmVhdGluZyBhIENESyBtYW5hZ2VkIEJlZHJvY2sgQWdlbnQuXG4gKiBUT0RPOiBLbm93bGVkZ2UgYmFzZXMgY29uZmlndXJhdGlvbiB3aWxsIGJlIGFkZGVkIGluIGEgZnV0dXJlIHVwZGF0ZVxuICogVE9ETzogSW5mZXJlbmNlIHByb2ZpbGUgY29uZmlndXJhdGlvbiB3aWxsIGJlIGFkZGVkIGluIGEgZnV0dXJlIHVwZGF0ZVxuICpcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBBZ2VudFByb3BzIHtcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIGFnZW50LlxuICAgKiBUaGlzIHdpbGwgYmUgdXNlZCBhcyB0aGUgcGh5c2ljYWwgbmFtZSBvZiB0aGUgYWdlbnQuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gQSBuYW1lIGlzIGdlbmVyYXRlZCBieSBDREsuXG4gICAqIFN1cHBvcnRlZCBwYXR0ZXJuIDogXihbMC05YS16QS1aXVtfLV0/KXsxLDEwMH0kXG4gICAqL1xuICByZWFkb25seSBhZ2VudE5hbWU/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgaW5zdHJ1Y3Rpb24gdXNlZCBieSB0aGUgYWdlbnQuIFRoaXMgZGV0ZXJtaW5lcyBob3cgdGhlIGFnZW50IHdpbGwgcGVyZm9ybSBoaXMgdGFzay5cbiAgICogVGhpcyBpbnN0cnVjdGlvbiBtdXN0IGhhdmUgYSBtaW5pbXVtIG9mIDQwIGNoYXJhY3RlcnMuXG4gICAqL1xuICByZWFkb25seSBpbnN0cnVjdGlvbjogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGZvdW5kYXRpb24gbW9kZWwgdXNlZCBmb3Igb3JjaGVzdHJhdGlvbiBieSB0aGUgYWdlbnQuXG4gICAqL1xuICByZWFkb25seSBmb3VuZGF0aW9uTW9kZWw6IElCZWRyb2NrSW52b2thYmxlO1xuICAvKipcbiAgICogQW4gZXhpc3RpbmcgSUFNIFJvbGUgdG8gYXNzb2NpYXRlIHdpdGggdGhpcyBhZ2VudC5cbiAgICogVXNlIHRoaXMgcHJvcGVydHkgd2hlbiB5b3Ugd2FudCB0byByZXVzZSBhbiBleGlzdGluZyBJQU0gcm9sZSByYXRoZXIgdGhhbiBjcmVhdGUgYSBuZXcgb25lLlxuICAgKiBUaGUgcm9sZSBtdXN0IGhhdmUgYSB0cnVzdCBwb2xpY3kgdGhhdCBhbGxvd3MgdGhlIEJlZHJvY2sgc2VydmljZSB0byBhc3N1bWUgaXQuXG4gICAqIEBkZWZhdWx0IC0gQSBuZXcgcm9sZSBpcyBjcmVhdGVkIGZvciB5b3UuXG4gICAqL1xuICByZWFkb25seSBleGlzdGluZ1JvbGU/OiBpYW0uSVJvbGU7XG4gIC8qKlxuICAgKiBTcGVjaWZpZXMgd2hldGhlciB0byBhdXRvbWF0aWNhbGx5IHVwZGF0ZSB0aGUgYERSQUZUYCB2ZXJzaW9uIG9mIHRoZSBhZ2VudCBhZnRlclxuICAgKiBtYWtpbmcgY2hhbmdlcyB0byB0aGUgYWdlbnQuIFRoZSBgRFJBRlRgIHZlcnNpb24gY2FuIGJlIGNvbnRpbnVhbGx5IGl0ZXJhdGVkXG4gICAqIHVwb24gZHVyaW5nIGludGVybmFsIGRldmVsb3BtZW50LlxuICAgKlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgcmVhZG9ubHkgc2hvdWxkUHJlcGFyZUFnZW50PzogYm9vbGVhbjtcbiAgLyoqXG4gICAqIEhvdyBsb25nIHNlc3Npb25zIHNob3VsZCBiZSBrZXB0IG9wZW4gZm9yIHRoZSBhZ2VudC4gSWYgbm8gY29udmVyc2F0aW9uIG9jY3Vyc1xuICAgKiBkdXJpbmcgdGhpcyB0aW1lLCB0aGUgc2Vzc2lvbiBleHBpcmVzIGFuZCBBbWF6b24gQmVkcm9jayBkZWxldGVzIGFueSBkYXRhXG4gICAqIHByb3ZpZGVkIGJlZm9yZSB0aGUgdGltZW91dC5cbiAgICpcbiAgICogQGRlZmF1bHQgLSAxMCBtaW51dGVzXG4gICAqL1xuICByZWFkb25seSBpZGxlU2Vzc2lvblRUTD86IER1cmF0aW9uO1xuICAvKipcbiAgICogVGhlIEtNUyBrZXkgb2YgdGhlIGFnZW50IGlmIGN1c3RvbSBlbmNyeXB0aW9uIGlzIGNvbmZpZ3VyZWQuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gQW4gQVdTIG1hbmFnZWQga2V5IGlzIHVzZWQuXG4gICAqL1xuICByZWFkb25seSBrbXNLZXk/OiBrbXMuSUtleTtcbiAgLyoqXG4gICAqIEEgZGVzY3JpcHRpb24gb2YgdGhlIGFnZW50LlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIE5vIGRlc2NyaXB0aW9uIGlzIHByb3ZpZGVkLlxuICAgKi9cbiAgcmVhZG9ubHkgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgQWN0aW9uIEdyb3VwcyBhc3NvY2lhdGVkIHdpdGggdGhlIGFnZW50LlxuICAgKiBAZGVmYXVsdCAtIE9ubHkgZGVmYXVsdCBhY3Rpb24gZ3JvdXBzIChVc2VySW5wdXQgYW5kIENvZGVJbnRlcnByZXRlcikgYXJlIGFkZGVkXG4gICAqL1xuICByZWFkb25seSBhY3Rpb25Hcm91cHM/OiBBZ2VudEFjdGlvbkdyb3VwW107XG4gIC8qKlxuICAgKiBUaGUgZ3VhcmRyYWlsIHRoYXQgd2lsbCBiZSBhc3NvY2lhdGVkIHdpdGggdGhlIGFnZW50LlxuICAgKiBAZGVmYXVsdCAtIE5vIGd1YXJkcmFpbCBpcyBwcm92aWRlZC5cbiAgICovXG4gIHJlYWRvbmx5IGd1YXJkcmFpbD86IElHdWFyZHJhaWw7XG4gIC8qKlxuICAgKiBPdmVycmlkZXMgc29tZSBwcm9tcHQgdGVtcGxhdGVzIGluIGRpZmZlcmVudCBwYXJ0cyBvZiBhbiBhZ2VudCBzZXF1ZW5jZSBjb25maWd1cmF0aW9uLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIE5vIG92ZXJyaWRlcyBhcmUgcHJvdmlkZWQuXG4gICAqL1xuICByZWFkb25seSBwcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb24/OiBQcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb247XG4gIC8qKlxuICAgKiBTZWxlY3Qgd2hldGhlciB0aGUgYWdlbnQgY2FuIHByb21wdCBhZGRpdGlvbmFsIGluZm9ybWF0aW9uIGZyb20gdGhlIHVzZXIgd2hlbiBpdCBkb2VzIG5vdCBoYXZlXG4gICAqIGVub3VnaCBpbmZvcm1hdGlvbiB0byByZXNwb25kIHRvIGFuIHV0dGVyYW5jZVxuICAgKlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgcmVhZG9ubHkgdXNlcklucHV0RW5hYmxlZD86IGJvb2xlYW47XG4gIC8qKlxuICAgKiBTZWxlY3Qgd2hldGhlciB0aGUgYWdlbnQgY2FuIGdlbmVyYXRlLCBydW4sIGFuZCB0cm91Ymxlc2hvb3QgY29kZSB3aGVuIHRyeWluZyB0byBjb21wbGV0ZSBhIHRhc2tcbiAgICpcbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIHJlYWRvbmx5IGNvZGVJbnRlcnByZXRlckVuYWJsZWQ/OiBib29sZWFuO1xuICAvKipcbiAgICogV2hldGhlciB0byBkZWxldGUgdGhlIHJlc291cmNlIGV2ZW4gaWYgaXQncyBpbiB1c2UuXG4gICAqXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICByZWFkb25seSBmb3JjZURlbGV0ZT86IGJvb2xlYW47XG4gIC8qKlxuICAgKiBUaGUgdHlwZSBhbmQgY29uZmlndXJhdGlvbiBvZiB0aGUgbWVtb3J5IHRvIG1haW50YWluIGNvbnRleHQgYWNyb3NzIG11bHRpcGxlIHNlc3Npb25zIGFuZCByZWNhbGwgcGFzdCBpbnRlcmFjdGlvbnMuXG4gICAqIFRoaXMgY2FuIGJlIHVzZWZ1bCBmb3IgbWFpbnRhaW5pbmcgY29udGludWl0eSBpbiBtdWx0aS10dXJuIGNvbnZlcnNhdGlvbnMgYW5kIHJlY2FsbGluZyB1c2VyIHByZWZlcmVuY2VzXG4gICAqIG9yIHBhc3QgaW50ZXJhY3Rpb25zLlxuICAgKlxuICAgKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9iZWRyb2NrL2xhdGVzdC91c2VyZ3VpZGUvYWdlbnRzLW1lbW9yeS5odG1sXG4gICAqIEBkZWZhdWx0IC0gTm8gbWVtb3J5IHdpbGwgYmUgdXNlZC4gQWdlbnRzIHdpbGwgcmV0YWluIGNvbnRleHQgZnJvbSB0aGUgY3VycmVudCBzZXNzaW9uIG9ubHkuXG4gICAqL1xuICByZWFkb25seSBtZW1vcnk/OiBNZW1vcnk7XG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciBhZ2VudCBjb2xsYWJvcmF0aW9uIHNldHRpbmdzLCBpbmNsdWRpbmcgQWdlbnRDb2xsYWJvcmF0b3JUeXBlIGFuZCBBZ2VudENvbGxhYm9yYXRvcnMuXG4gICAqIFRoaXMgcHJvcGVydHkgYWxsb3dzIHlvdSB0byBkZWZpbmUgaG93IHRoZSBhZ2VudCBjb2xsYWJvcmF0ZXMgd2l0aCBvdGhlciBhZ2VudHNcbiAgICogYW5kIHdoYXQgY29sbGFib3JhdG9ycyBpdCBjYW4gd29yayB3aXRoLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIE5vIGFnZW50IGNvbGxhYm9yYXRpb24gY29uZmlndXJhdGlvbi5cbiAgICovXG4gIHJlYWRvbmx5IGFnZW50Q29sbGFib3JhdGlvbj86IEFnZW50Q29sbGFib3JhdGlvbjtcbiAgLyoqXG4gICAqIFRoZSBMYW1iZGEgZnVuY3Rpb24gdG8gdXNlIGZvciBjdXN0b20gb3JjaGVzdHJhdGlvbi5cbiAgICogSWYgcHJvdmlkZWQsIGN1c3RvbSBvcmNoZXN0cmF0aW9uIHdpbGwgYmUgdXNlZC5cbiAgICogSWYgbm90IHByb3ZpZGVkLCBkZWZhdWx0IG9yY2hlc3RyYXRpb24gd2lsbCBiZSB1c2VkLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIERlZmF1bHQgb3JjaGVzdHJhdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgY3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yPzogQ3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yO1xufVxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgQVRUUlMgRk9SIElNUE9SVEVEIENPTlNUUlVDVFxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBBdHRyaWJ1dGVzIGZvciBzcGVjaWZ5aW5nIGFuIGltcG9ydGVkIEJlZHJvY2sgQWdlbnQuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQWdlbnRBdHRyaWJ1dGVzIHtcbiAgLyoqXG4gICAqIFRoZSBBUk4gb2YgdGhlIGFnZW50LlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICByZWFkb25seSBhZ2VudEFybjogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgSUFNIHJvbGUgYXNzb2NpYXRlZCB0byB0aGUgYWdlbnQuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHJlYWRvbmx5IHJvbGVBcm46IHN0cmluZztcbiAgLyoqXG4gICAqIE9wdGlvbmFsIEtNUyBlbmNyeXB0aW9uIGtleSBhc3NvY2lhdGVkIHdpdGggdGhpcyBhZ2VudFxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBBbiBBV1MgbWFuYWdlZCBrZXkgaXMgdXNlZFxuICAgKi9cbiAgcmVhZG9ubHkga21zS2V5QXJuPzogc3RyaW5nO1xuICAvKipcbiAgICogV2hlbiB0aGlzIGFnZW50IHdhcyBsYXN0IHVwZGF0ZWQuXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIGxhc3QgdXBkYXRlZCB0aW1lc3RhbXAgaXMgcHJvdmlkZWRcbiAgICovXG4gIHJlYWRvbmx5IGxhc3RVcGRhdGVkPzogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGFnZW50IHZlcnNpb24uIElmIG5vIGV4cGxpY2l0IHZlcnNpb25zIGhhdmUgYmVlbiBjcmVhdGVkLFxuICAgKiBsZWF2ZSB0aGlzIGVtcHR5IHRvIHVzZSB0aGUgRFJBRlQgdmVyc2lvbi4gT3RoZXJ3aXNlLCB1c2UgdGhlXG4gICAqIHZlcnNpb24gbnVtYmVyIChlLmcuIDEpLlxuICAgKiBAZGVmYXVsdCAnRFJBRlQnXG4gICAqL1xuICByZWFkb25seSBhZ2VudFZlcnNpb24/OiBzdHJpbmc7XG59XG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIE5FVyBDT05TVFJVQ1QgREVGSU5JVElPTlxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBDbGFzcyB0byBjcmVhdGUgKG9yIGltcG9ydCkgYW4gQWdlbnQgd2l0aCBDREsuXG4gKiBAY2xvdWRmb3JtYXRpb25SZXNvdXJjZSBBV1M6OkJlZHJvY2s6OkFnZW50XG4gKi9cbkBwcm9wZXJ0eUluamVjdGFibGVcbmV4cG9ydCBjbGFzcyBBZ2VudCBleHRlbmRzIEFnZW50QmFzZSBpbXBsZW1lbnRzIElBZ2VudCB7XG4gIC8qKiBVbmlxdWVseSBpZGVudGlmaWVzIHRoaXMgY2xhc3MuICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgUFJPUEVSVFlfSU5KRUNUSU9OX0lEOiBzdHJpbmcgPSAnQGF3cy1jZGsuYXdzLWJlZHJvY2stYWxwaGEuQWdlbnQnO1xuXG4gIC8qKlxuICAgKiBTdGF0aWMgTWV0aG9kIGZvciBpbXBvcnRpbmcgYW4gZXhpc3RpbmcgQmVkcm9jayBBZ2VudC5cbiAgICovXG4gIC8qKlxuICAgKiBDcmVhdGVzIGFuIEFnZW50IHJlZmVyZW5jZSBmcm9tIGFuIGV4aXN0aW5nIGFnZW50J3MgYXR0cmlidXRlcy5cbiAgICpcbiAgICogQHBhcmFtIHNjb3BlIC0gVGhlIGNvbnN0cnVjdCBzY29wZVxuICAgKiBAcGFyYW0gaWQgLSBJZGVudGlmaWVyIG9mIHRoZSBjb25zdHJ1Y3RcbiAgICogQHBhcmFtIGF0dHJzIC0gQXR0cmlidXRlcyBvZiB0aGUgZXhpc3RpbmcgYWdlbnRcbiAgICogQGRlZmF1bHQgLSBGb3IgYXR0cnMuYWdlbnRWZXJzaW9uOiAnRFJBRlQnIGlmIG5vIGV4cGxpY2l0IHZlcnNpb24gaXMgcHJvdmlkZWRcbiAgICogQHJldHVybnMgQW4gSUFnZW50IHJlZmVyZW5jZSB0byB0aGUgZXhpc3RpbmcgYWdlbnRcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUFnZW50QXR0cmlidXRlcyhzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBhdHRyczogQWdlbnRBdHRyaWJ1dGVzKTogSUFnZW50IHtcbiAgICBjbGFzcyBJbXBvcnQgZXh0ZW5kcyBBZ2VudEJhc2Uge1xuICAgICAgcHVibGljIHJlYWRvbmx5IGFnZW50QXJuID0gYXR0cnMuYWdlbnRBcm47XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgYWdlbnRJZCA9IEFybi5zcGxpdChhdHRycy5hZ2VudEFybiwgQXJuRm9ybWF0LlNMQVNIX1JFU09VUkNFX05BTUUpLnJlc291cmNlTmFtZSE7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgcm9sZSA9IGlhbS5Sb2xlLmZyb21Sb2xlQXJuKHNjb3BlLCBgJHtpZH1Sb2xlYCwgYXR0cnMucm9sZUFybik7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkga21zS2V5ID0gYXR0cnMua21zS2V5QXJuID8ga21zLktleS5mcm9tS2V5QXJuKHNjb3BlLCBgJHtpZH1LZXlgLCBhdHRycy5rbXNLZXlBcm4pIDogdW5kZWZpbmVkO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGxhc3RVcGRhdGVkID0gYXR0cnMubGFzdFVwZGF0ZWQ7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgYWdlbnRWZXJzaW9uID0gYXR0cnMuYWdlbnRWZXJzaW9uID8/ICdEUkFGVCc7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgZ3JhbnRQcmluY2lwYWwgPSB0aGlzLnJvbGU7XG4gICAgfVxuXG4gICAgLy8gUmV0dXJuIG5ldyBBZ2VudFxuICAgIHJldHVybiBuZXcgSW1wb3J0KHNjb3BlLCBpZCk7XG4gIH1cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEJhc2UgYXR0cmlidXRlc1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIFRoZSB1bmlxdWUgaWRlbnRpZmllciBmb3IgdGhlIGFnZW50XG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBhZ2VudElkOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBhZ2VudC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGFnZW50QXJuOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgdmVyc2lvbiBvZiB0aGUgYWdlbnQuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBhZ2VudFZlcnNpb246IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBJQU0gcm9sZSBhc3NvY2lhdGVkIHRvIHRoZSBhZ2VudC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSByb2xlOiBpYW0uSVJvbGU7XG4gIC8qKlxuICAgKiBPcHRpb25hbCBLTVMgZW5jcnlwdGlvbiBrZXkgYXNzb2NpYXRlZCB3aXRoIHRoaXMgYWdlbnRcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBrbXNLZXk/OiBrbXMuSUtleTtcbiAgLyoqXG4gICAqIFdoZW4gdGhpcyBhZ2VudCB3YXMgbGFzdCB1cGRhdGVkLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGxhc3RVcGRhdGVkPzogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHByaW5jaXBhbCB0byBncmFudCBwZXJtaXNzaW9ucyB0b1xuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGdyYW50UHJpbmNpcGFsOiBpYW0uSVByaW5jaXBhbDtcbiAgLyoqXG4gICAqIERlZmF1bHQgYWxpYXMgb2YgdGhlIGFnZW50XG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgdGVzdEFsaWFzOiBJQWdlbnRBbGlhcztcbiAgLyoqXG4gICAqIGFjdGlvbiBncm91cHMgYXNzb2NpYXRlZCB3aXRoIHRoZSBhZ2VueVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGFjdGlvbkdyb3VwczogQWdlbnRBY3Rpb25Hcm91cFtdID0gW107XG4gIC8qKlxuICAgKiBUaGUgZ3VhcmRyYWlsIHRoYXQgd2lsbCBiZSBhc3NvY2lhdGVkIHdpdGggdGhlIGFnZW50LlxuICAgKi9cbiAgcHVibGljIGd1YXJkcmFpbD86IElHdWFyZHJhaWw7XG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBDREstb25seSBhdHRyaWJ1dGVzXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIGFnZW50LlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gSW50ZXJuYWwgT25seVxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgcHJpdmF0ZSByZWFkb25seSBST0xFX05BTUVfU1VGRklYID0gJy1iZWRyb2NrYWdlbnQnO1xuICBwcml2YXRlIHJlYWRvbmx5IE1BWExFTkdUSF9GT1JfUk9MRV9OQU1FID0gNjQ7XG4gIHByaXZhdGUgcmVhZG9ubHkgaWRsZVNlc3Npb25UVEw6IER1cmF0aW9uO1xuICBwcml2YXRlIHJlYWRvbmx5IGZvdW5kYXRpb25Nb2RlbDogSUJlZHJvY2tJbnZva2FibGU7XG4gIHByaXZhdGUgcmVhZG9ubHkgdXNlcklucHV0RW5hYmxlZDogYm9vbGVhbjtcbiAgcHJpdmF0ZSByZWFkb25seSBjb2RlSW50ZXJwcmV0ZXJFbmFibGVkOiBib29sZWFuO1xuICBwcml2YXRlIHJlYWRvbmx5IGFnZW50Q29sbGFib3JhdGlvbj86IEFnZW50Q29sbGFib3JhdGlvbjtcbiAgcHJpdmF0ZSByZWFkb25seSBjdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3I/OiBDdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3I7XG4gIHByaXZhdGUgcmVhZG9ubHkgcHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uPzogUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uO1xuICBwcml2YXRlIHJlYWRvbmx5IF9fcmVzb3VyY2U6IGJlZHJvY2suQ2ZuQWdlbnQ7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIENPTlNUUlVDVE9SXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogQWdlbnRQcm9wcykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCk7XG4gICAgLy8gRW5oYW5jZWQgQ0RLIEFuYWx5dGljcyBUZWxlbWV0cnlcbiAgICBhZGRDb25zdHJ1Y3RNZXRhZGF0YSh0aGlzLCBwcm9wcyk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBWYWxpZGF0ZSBwcm9wc1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIGlmIChwcm9wcy5pbnN0cnVjdGlvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQocHJvcHMuaW5zdHJ1Y3Rpb24pICYmXG4gICAgICAgIHByb3BzLmluc3RydWN0aW9uLmxlbmd0aCA8IE1JTl9JTlNUUlVDVElPTl9MRU5HVEgpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YEluc3RydWN0aW9uVG9vU2hvcnRgLCBgaW5zdHJ1Y3Rpb24gbXVzdCBiZSBhdCBsZWFzdCAke01JTl9JTlNUUlVDVElPTl9MRU5HVEh9IGNoYXJhY3RlcnNgLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBpZGxlU2Vzc2lvblRUTFxuICAgIGlmIChwcm9wcy5pZGxlU2Vzc2lvblRUTCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQocHJvcHMuaWRsZVNlc3Npb25UVEwpICYmXG4gICAgICAgIChwcm9wcy5pZGxlU2Vzc2lvblRUTC50b01pbnV0ZXMoKSA8IDEgfHwgcHJvcHMuaWRsZVNlc3Npb25UVEwudG9NaW51dGVzKCkgPiA2MCkpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YElkbGVTZXNzaW9uVHRsT3V0T2ZSYW5nZWAsICdpZGxlU2Vzc2lvblRUTCBtdXN0IGJlIGJldHdlZW4gMSBhbmQgNjAgbWludXRlcycsIHRoaXMpO1xuICAgIH1cblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIFNldCBwcm9wZXJ0aWVzIGFuZCBkZWZhdWx0c1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMubmFtZSA9XG4gICAgICBwcm9wcy5hZ2VudE5hbWUgPz8gdGhpcy5nZW5lcmF0ZVBoeXNpY2FsTmFtZSgpICsgdGhpcy5ST0xFX05BTUVfU1VGRklYO1xuICAgIHRoaXMuaWRsZVNlc3Npb25UVEwgPSBwcm9wcy5pZGxlU2Vzc2lvblRUTCA/PyBEdXJhdGlvbi5taW51dGVzKDEwKTtcbiAgICB0aGlzLnVzZXJJbnB1dEVuYWJsZWQgPSBwcm9wcy51c2VySW5wdXRFbmFibGVkID8/IGZhbHNlO1xuICAgIHRoaXMuY29kZUludGVycHJldGVyRW5hYmxlZCA9IHByb3BzLmNvZGVJbnRlcnByZXRlckVuYWJsZWQgPz8gZmFsc2U7XG4gICAgdGhpcy5mb3VuZGF0aW9uTW9kZWwgPSBwcm9wcy5mb3VuZGF0aW9uTW9kZWw7XG4gICAgLy8gT3B0aW9uYWxcbiAgICB0aGlzLnByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbiA9IHByb3BzLnByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbjtcbiAgICB0aGlzLmttc0tleSA9IHByb3BzLmttc0tleTtcbiAgICB0aGlzLmN1c3RvbU9yY2hlc3RyYXRpb25FeGVjdXRvciA9IHByb3BzLmN1c3RvbU9yY2hlc3RyYXRpb25FeGVjdXRvcjtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIFJvbGVcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBJZiBleGlzdGluZyByb2xlIGlzIHByb3ZpZGVkLCB1c2UgaXQuXG4gICAgaWYgKHByb3BzLmV4aXN0aW5nUm9sZSkge1xuICAgICAgdGhpcy5yb2xlID0gcHJvcHMuZXhpc3RpbmdSb2xlO1xuICAgICAgdGhpcy5ncmFudFByaW5jaXBhbCA9IHRoaXMucm9sZTtcbiAgICAgIC8vIE90aGVyd2lzZSwgY3JlYXRlIGEgbmV3IG9uZVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnJvbGUgPSBuZXcgaWFtLlJvbGUodGhpcywgJ1JvbGUnLCB7XG4gICAgICAgIC8vIGdlbmVyYXRlIGEgcm9sZSBuYW1lXG4gICAgICAgIHJvbGVOYW1lOiB0aGlzLmdlbmVyYXRlUGh5c2ljYWxOYW1lKCkgKyB0aGlzLlJPTEVfTkFNRV9TVUZGSVgsXG4gICAgICAgIC8vIGVuc3VyZSB0aGUgcm9sZSBoYXMgYSB0cnVzdCBwb2xpY3kgdGhhdCBhbGxvd3MgdGhlIEJlZHJvY2sgc2VydmljZSB0byBhc3N1bWUgdGhlIHJvbGVcbiAgICAgICAgYXNzdW1lZEJ5OiBuZXcgaWFtLlNlcnZpY2VQcmluY2lwYWwoJ2JlZHJvY2suYW1hem9uYXdzLmNvbScpLndpdGhDb25kaXRpb25zKHtcbiAgICAgICAgICBTdHJpbmdFcXVhbHM6IHtcbiAgICAgICAgICAgICdhd3M6U291cmNlQWNjb3VudCc6IHsgUmVmOiAnQVdTOjpBY2NvdW50SWQnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBBcm5MaWtlOiB7XG4gICAgICAgICAgICAnYXdzOlNvdXJjZUFybic6IFN0YWNrLm9mKHRoaXMpLmZvcm1hdEFybih7XG4gICAgICAgICAgICAgIHNlcnZpY2U6ICdiZWRyb2NrJyxcbiAgICAgICAgICAgICAgcmVzb3VyY2U6ICdhZ2VudCcsXG4gICAgICAgICAgICAgIHJlc291cmNlTmFtZTogJyonLFxuICAgICAgICAgICAgICBhcm5Gb3JtYXQ6IEFybkZvcm1hdC5TTEFTSF9SRVNPVVJDRV9OQU1FLFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgfSxcbiAgICAgICAgfSksXG4gICAgICB9KTtcbiAgICAgIHRoaXMuZ3JhbnRQcmluY2lwYWwgPSB0aGlzLnJvbGU7XG4gICAgfVxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIFNldCBMYXp5IFByb3BzIGluaXRpYWwgdmFsdWVzXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gQWRkIERlZmF1bHQgQWN0aW9uIEdyb3Vwc1xuICAgIHRoaXMuYWRkQWN0aW9uR3JvdXAoQWdlbnRBY3Rpb25Hcm91cC51c2VySW5wdXQodGhpcy51c2VySW5wdXRFbmFibGVkKSk7XG4gICAgdGhpcy5hZGRBY3Rpb25Hcm91cChBZ2VudEFjdGlvbkdyb3VwLmNvZGVJbnRlcnByZXRlcih0aGlzLmNvZGVJbnRlcnByZXRlckVuYWJsZWQpKTtcblxuICAgIC8vIEFkZCBzcGVjaWZpZWQgZWxlbXMgdGhyb3VnaCBtZXRob2RzIHRvIGhhbmRsZSBwZXJtaXNzaW9uc1xuICAgIC8vIHRoaXMgbmVlZHMgdG8gaGFwcGVuIGFmdGVyIHJvbGUgY3JlYXRpb24gLyBhc3NpZ25tZW50XG4gICAgcHJvcHMuYWN0aW9uR3JvdXBzPy5mb3JFYWNoKGFnID0+IHtcbiAgICAgIHRoaXMuYWRkQWN0aW9uR3JvdXAoYWcpO1xuICAgIH0pO1xuXG4gICAgLy8gU2V0IGFnZW50IGNvbGxhYm9yYXRpb24gY29uZmlndXJhdGlvblxuICAgIHRoaXMuYWdlbnRDb2xsYWJvcmF0aW9uID0gcHJvcHMuYWdlbnRDb2xsYWJvcmF0aW9uO1xuICAgIGlmIChwcm9wcy5hZ2VudENvbGxhYm9yYXRpb24pIHtcbiAgICAgIHByb3BzLmFnZW50Q29sbGFib3JhdGlvbi5jb2xsYWJvcmF0b3JzLmZvckVhY2goYWMgPT4ge1xuICAgICAgICB0aGlzLmdyYW50UGVybWlzc2lvblRvQWdlbnQoYWMpO1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgaWYgKHByb3BzLmd1YXJkcmFpbCkge1xuICAgICAgdGhpcy5hZGRHdWFyZHJhaWwocHJvcHMuZ3VhcmRyYWlsKTtcbiAgICB9XG5cbiAgICAvLyBHcmFudCBwZXJtaXNzaW9ucyBmb3IgY3VzdG9tIG9yY2hlc3RyYXRpb24gaWYgcHJvdmlkZWRcbiAgICBpZiAodGhpcy5jdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3I/LmxhbWJkYUZ1bmN0aW9uKSB7XG4gICAgICB0aGlzLmN1c3RvbU9yY2hlc3RyYXRpb25FeGVjdXRvci5sYW1iZGFGdW5jdGlvbi5ncmFudEludm9rZSh0aGlzLnJvbGUpO1xuICAgICAgdGhpcy5jdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3IubGFtYmRhRnVuY3Rpb24uYWRkUGVybWlzc2lvbihgT3JjaGVzdHJhdGlvbkxhbWJkYUludm9jYXRpb25Qb2xpY3ktJHt0aGlzLm5vZGUuYWRkci5zbGljZSgwLCBNQVhfUE9MSUNZX05BTUVfTk9ERV9MRU5HVEgpfWAsIHtcbiAgICAgICAgcHJpbmNpcGFsOiBuZXcgaWFtLlNlcnZpY2VQcmluY2lwYWwoJ2JlZHJvY2suYW1hem9uYXdzLmNvbScpLFxuICAgICAgICBzb3VyY2VBcm46IExhenkuc3RyaW5nKHsgcHJvZHVjZTogKCkgPT4gdGhpcy5hZ2VudEFybiB9KSxcbiAgICAgICAgc291cmNlQWNjb3VudDogeyBSZWY6ICdBV1M6OkFjY291bnRJZCcgfSBhcyBhbnksXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBDRk4gUHJvcHMgLSBXaXRoIExhenkgc3VwcG9ydFxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIGNvbnN0IGNmblByb3BzOiBiZWRyb2NrLkNmbkFnZW50UHJvcHMgPSB7XG4gICAgICBhY3Rpb25Hcm91cHM6IExhenkuYW55KHsgcHJvZHVjZTogKCkgPT4gdGhpcy5yZW5kZXJBY3Rpb25Hcm91cHMoKSB9LCB7IG9taXRFbXB0eUFycmF5OiB0cnVlIH0pLFxuICAgICAgYWdlbnROYW1lOiB0aGlzLm5hbWUsXG4gICAgICBhZ2VudFJlc291cmNlUm9sZUFybjogdGhpcy5yb2xlLnJvbGVBcm4sXG4gICAgICBhdXRvUHJlcGFyZTogcHJvcHMuc2hvdWxkUHJlcGFyZUFnZW50ID8/IGZhbHNlLFxuICAgICAgY3VzdG9tZXJFbmNyeXB0aW9uS2V5QXJuOiBwcm9wcy5rbXNLZXk/LmtleUFybixcbiAgICAgIGRlc2NyaXB0aW9uOiBwcm9wcy5kZXNjcmlwdGlvbixcbiAgICAgIGZvdW5kYXRpb25Nb2RlbDogdGhpcy5mb3VuZGF0aW9uTW9kZWwuaW52b2thYmxlQXJuLFxuICAgICAgZ3VhcmRyYWlsQ29uZmlndXJhdGlvbjogTGF6eS5hbnkoeyBwcm9kdWNlOiAoKSA9PiB0aGlzLnJlbmRlckd1YXJkcmFpbCgpIH0pLFxuICAgICAgaWRsZVNlc3Npb25UdGxJblNlY29uZHM6IHRoaXMuaWRsZVNlc3Npb25UVEwudG9TZWNvbmRzKCksXG4gICAgICBpbnN0cnVjdGlvbjogcHJvcHMuaW5zdHJ1Y3Rpb24sXG4gICAgICBtZW1vcnlDb25maWd1cmF0aW9uOiBwcm9wcy5tZW1vcnk/Ll9yZW5kZXIoKSxcbiAgICAgIHByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbjogdGhpcy5wcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb24/Ll9yZW5kZXIoKSxcbiAgICAgIHNraXBSZXNvdXJjZUluVXNlQ2hlY2tPbkRlbGV0ZTogcHJvcHMuZm9yY2VEZWxldGUgPz8gZmFsc2UsXG4gICAgICBhZ2VudENvbGxhYm9yYXRpb246IHByb3BzLmFnZW50Q29sbGFib3JhdGlvbj8udHlwZSxcbiAgICAgIGFnZW50Q29sbGFib3JhdG9yczogTGF6eS5hbnkoeyBwcm9kdWNlOiAoKSA9PiB0aGlzLnJlbmRlckFnZW50Q29sbGFib3JhdG9ycygpIH0sIHsgb21pdEVtcHR5QXJyYXk6IHRydWUgfSksXG4gICAgICBjdXN0b21PcmNoZXN0cmF0aW9uOiB0aGlzLnJlbmRlckN1c3RvbU9yY2hlc3RyYXRpb24oKSxcbiAgICAgIG9yY2hlc3RyYXRpb25UeXBlOiB0aGlzLmN1c3RvbU9yY2hlc3RyYXRpb25FeGVjdXRvciA/IE9yY2hlc3RyYXRpb25UeXBlLkNVU1RPTV9PUkNIRVNUUkFUSU9OIDogT3JjaGVzdHJhdGlvblR5cGUuREVGQVVMVCxcbiAgICB9O1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gTDEgSW5zdGFudGlhdGlvblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMuX19yZXNvdXJjZSA9IG5ldyBiZWRyb2NrLkNmbkFnZW50KHRoaXMsICdSZXNvdXJjZScsIGNmblByb3BzKTtcblxuICAgIHRoaXMuYWdlbnRJZCA9IHRoaXMuX19yZXNvdXJjZS5hdHRyQWdlbnRJZDtcbiAgICB0aGlzLmFnZW50QXJuID0gdGhpcy5fX3Jlc291cmNlLmF0dHJBZ2VudEFybjtcbiAgICB0aGlzLmFnZW50VmVyc2lvbiA9IHRoaXMuX19yZXNvdXJjZS5hdHRyQWdlbnRWZXJzaW9uO1xuICAgIHRoaXMubGFzdFVwZGF0ZWQgPSB0aGlzLl9fcmVzb3VyY2UuYXR0clVwZGF0ZWRBdDtcblxuICAgIC8vIEFkZCBleHBsaWNpdCBkZXBlbmRlbmN5IGJldHdlZW4gdGhlIGFnZW50IHJlc291cmNlIGFuZCB0aGUgYWdlbnQncyByb2xlIGRlZmF1bHQgcG9saWN5XG4gICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9hd3NsYWJzL2dlbmVyYXRpdmUtYWktY2RrLWNvbnN0cnVjdHMvaXNzdWVzLzg5OVxuICAgIGNvbnN0IGdyYW50ID0gdGhpcy5mb3VuZGF0aW9uTW9kZWwuZ3JhbnRJbnZva2UodGhpcy5yb2xlKTtcbiAgICBncmFudC5hcHBseUJlZm9yZSh0aGlzLl9fcmVzb3VyY2UpO1xuXG4gICAgdGhpcy50ZXN0QWxpYXMgPSBBZ2VudEFsaWFzLmZyb21BdHRyaWJ1dGVzKHRoaXMsICdEZWZhdWx0QWxpYXMnLCB7XG4gICAgICBhbGlhc0lkOiAnVFNUQUxJQVNJRCcsXG4gICAgICBhbGlhc05hbWU6ICdBZ2VudFRlc3RBbGlhcycsXG4gICAgICBhZ2VudFZlcnNpb246ICdEUkFGVCcsXG4gICAgICBhZ2VudDogdGhpcyxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBIRUxQRVIgTUVUSE9EUyAtIGFkZFgoKVxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAvKipcbiAgICogQWRkIGd1YXJkcmFpbCB0byB0aGUgYWdlbnQuXG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgYWRkR3VhcmRyYWlsKGd1YXJkcmFpbDogSUd1YXJkcmFpbCkge1xuICAgIC8vIERvIHNvbWUgY2hlY2tzXG4gICAgdmFsaWRhdGlvbi50aHJvd0lmSW52YWxpZCh0aGlzLnZhbGlkYXRlR3VhcmRyYWlsLCBndWFyZHJhaWwpO1xuICAgIC8vIEFkZCBpdCB0byB0aGUgY29uc3RydWN0XG4gICAgdGhpcy5ndWFyZHJhaWwgPSBndWFyZHJhaWw7XG4gICAgLy8gSGFuZGxlIHBlcm1pc3Npb25zXG4gICAgZ3VhcmRyYWlsLmdyYW50QXBwbHkodGhpcy5yb2xlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGFuIGFjdGlvbiBncm91cCB0byB0aGUgYWdlbnQgYW5kIGNvbmZpZ3VyZXMgbmVjZXNzYXJ5IHBlcm1pc3Npb25zLlxuICAgKlxuICAgKiBAcGFyYW0gYWN0aW9uR3JvdXAgLSBUaGUgYWN0aW9uIGdyb3VwIHRvIGFkZFxuICAgKiBAZGVmYXVsdCAtIERlZmF1bHQgcGVybWlzc2lvbnM6XG4gICAqIC0gTGFtYmRhIGZ1bmN0aW9uIGludm9rZSBwZXJtaXNzaW9ucyBpZiBleGVjdXRvciBpcyBwcmVzZW50XG4gICAqIC0gUzMgR2V0T2JqZWN0IHBlcm1pc3Npb25zIGlmIGFwaVNjaGVtYS5zM0ZpbGUgaXMgcHJlc2VudFxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGFkZEFjdGlvbkdyb3VwKGFjdGlvbkdyb3VwOiBBZ2VudEFjdGlvbkdyb3VwKSB7XG4gICAgdmFsaWRhdGlvbi50aHJvd0lmSW52YWxpZCh0aGlzLnZhbGlkYXRlQWN0aW9uR3JvdXAsIGFjdGlvbkdyb3VwKTtcbiAgICB0aGlzLmFjdGlvbkdyb3Vwcy5wdXNoKGFjdGlvbkdyb3VwKTtcbiAgICAvLyBIYW5kbGUgcGVybWlzc2lvbnMgdG8gaW52b2tlIHRoZSBsYW1iZGEgZnVuY3Rpb25cbiAgICBhY3Rpb25Hcm91cC5leGVjdXRvcj8ubGFtYmRhRnVuY3Rpb24/LmdyYW50SW52b2tlKHRoaXMucm9sZSk7XG4gICAgYWN0aW9uR3JvdXAuZXhlY3V0b3I/LmxhbWJkYUZ1bmN0aW9uPy5hZGRQZXJtaXNzaW9uKGBMYW1iZGFJbnZvY2F0aW9uUG9saWN5LSR7dGhpcy5ub2RlLmFkZHIuc2xpY2UoMCwgTUFYX1BPTElDWV9OQU1FX05PREVfTEVOR1RIKX1gLCB7XG4gICAgICBwcmluY2lwYWw6IG5ldyBpYW0uU2VydmljZVByaW5jaXBhbCgnYmVkcm9jay5hbWF6b25hd3MuY29tJyksXG4gICAgICBzb3VyY2VBcm46IHRoaXMuYWdlbnRBcm4sXG4gICAgICBzb3VyY2VBY2NvdW50OiB7IFJlZjogJ0FXUzo6QWNjb3VudElkJyB9IGFzIGFueSxcbiAgICB9KTtcbiAgICAvLyBIYW5kbGUgcGVybWlzc2lvbnMgdG8gYWNjZXNzIHRoZSBzY2hlbWEgZmlsZSBmcm9tIFMzXG4gICAgaWYgKGFjdGlvbkdyb3VwLmFwaVNjaGVtYSBpbnN0YW5jZW9mIEFzc2V0QXBpU2NoZW1hKSB7XG4gICAgICBjb25zdCByZW5kZXJlZCA9IGFjdGlvbkdyb3VwLmFwaVNjaGVtYS5fcmVuZGVyKCk7XG4gICAgICBpZiAoISgnczMnIGluIHJlbmRlcmVkKSB8fCAhcmVuZGVyZWQuczMpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgUzNDb25maWdNaXNzaW5nYCwgJ1MzIGNvbmZpZ3VyYXRpb24gaXMgbWlzc2luZyBpbiBBc3NldEFwaVNjaGVtYScsIHRoaXMpO1xuICAgICAgfVxuICAgICAgY29uc3QgczNDb25maWcgPSByZW5kZXJlZC5zMztcbiAgICAgIGlmICghKCdzM0J1Y2tldE5hbWUnIGluIHMzQ29uZmlnKSB8fCAhKCdzM09iamVjdEtleScgaW4gczNDb25maWcpKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YFMzQnVja2V0T3JLZXlNaXNzaW5nYCwgJ1MzIGJ1Y2tldCBuYW1lIGFuZCBvYmplY3Qga2V5IGFyZSByZXF1aXJlZCBpbiBBc3NldEFwaVNjaGVtYScsIHRoaXMpO1xuICAgICAgfVxuICAgICAgY29uc3QgYnVja2V0TmFtZSA9IHMzQ29uZmlnLnMzQnVja2V0TmFtZTtcbiAgICAgIGNvbnN0IG9iamVjdEtleSA9IHMzQ29uZmlnLnMzT2JqZWN0S2V5O1xuICAgICAgaWYgKCFidWNrZXROYW1lIHx8IGJ1Y2tldE5hbWUudHJpbSgpID09PSAnJykge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBTM0J1Y2tldE5hbWVFbXB0eWAsICdTMyBidWNrZXQgbmFtZSBjYW5ub3QgYmUgZW1wdHkgaW4gQXNzZXRBcGlTY2hlbWEnLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGlmICghb2JqZWN0S2V5IHx8IG9iamVjdEtleS50cmltKCkgPT09ICcnKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YFMzT2JqZWN0S2V5RW1wdHlgLCAnUzMgb2JqZWN0IGtleSBjYW5ub3QgYmUgZW1wdHkgaW4gQXNzZXRBcGlTY2hlbWEnLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGJ1Y2tldCA9IHMzLkJ1Y2tldC5mcm9tQnVja2V0TmFtZSh0aGlzLCBgJHthY3Rpb25Hcm91cC5uYW1lfVNjaGVtYUJ1Y2tldGAsIGJ1Y2tldE5hbWUpO1xuICAgICAgYnVja2V0LmdyYW50UmVhZCh0aGlzLnJvbGUsIG9iamVjdEtleSk7XG4gICAgfSBlbHNlIGlmIChhY3Rpb25Hcm91cC5hcGlTY2hlbWEgaW5zdGFuY2VvZiBTM0FwaVNjaGVtYSkge1xuICAgICAgY29uc3QgczNGaWxlID0gYWN0aW9uR3JvdXAuYXBpU2NoZW1hLnMzRmlsZTtcbiAgICAgIGlmICghczNGaWxlKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YFMzRmlsZU1pc3NpbmdgLCAnUzMgZmlsZSBjb25maWd1cmF0aW9uIGlzIG1pc3NpbmcgaW4gUzNBcGlTY2hlbWEnLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGlmICghczNGaWxlLmJ1Y2tldE5hbWUgfHwgczNGaWxlLmJ1Y2tldE5hbWUudHJpbSgpID09PSAnJykge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBTM0J1Y2tldE5hbWVFbXB0eWAsICdTMyBidWNrZXQgbmFtZSBjYW5ub3QgYmUgZW1wdHkgaW4gUzNBcGlTY2hlbWEnLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGlmICghczNGaWxlLm9iamVjdEtleSB8fCBzM0ZpbGUub2JqZWN0S2V5LnRyaW0oKSA9PT0gJycpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgUzNPYmplY3RLZXlFbXB0eWAsICdTMyBvYmplY3Qga2V5IGNhbm5vdCBiZSBlbXB0eSBpbiBTM0FwaVNjaGVtYScsIHRoaXMpO1xuICAgICAgfVxuICAgICAgY29uc3QgYnVja2V0ID0gczMuQnVja2V0LmZyb21CdWNrZXROYW1lKHRoaXMsIGAke2FjdGlvbkdyb3VwLm5hbWV9U2NoZW1hQnVja2V0YCwgczNGaWxlLmJ1Y2tldE5hbWUpO1xuICAgICAgYnVja2V0LmdyYW50UmVhZCh0aGlzLnJvbGUsIHMzRmlsZS5vYmplY3RLZXkpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBHcmFudHMgcGVybWlzc2lvbnMgZm9yIGFuIGFnZW50IGNvbGxhYm9yYXRvciB0byB0aGlzIGFnZW50J3Mgcm9sZS5cbiAgICogVGhpcyBtZXRob2Qgb25seSBncmFudHMgSUFNIHBlcm1pc3Npb25zIGFuZCBkb2VzIG5vdCBhZGQgdGhlIGNvbGxhYm9yYXRvclxuICAgKiB0byB0aGUgYWdlbnQncyBjb2xsYWJvcmF0aW9uIGNvbmZpZ3VyYXRpb24uIFRvIGFkZCBjb2xsYWJvcmF0b3JzIHRvIHRoZVxuICAgKiBhZ2VudCBjb25maWd1cmF0aW9uLCBpbmNsdWRlIHRoZW0gaW4gdGhlIEFnZW50Q29sbGFib3JhdGlvbiB3aGVuIGNyZWF0aW5nIHRoZSBhZ2VudC5cbiAgICpcbiAgICogQHBhcmFtIGFnZW50Q29sbGFib3JhdG9yIC0gVGhlIGNvbGxhYm9yYXRvciB0byBncmFudCBwZXJtaXNzaW9ucyBmb3JcbiAgICovXG4gIHByaXZhdGUgZ3JhbnRQZXJtaXNzaW9uVG9BZ2VudChhZ2VudENvbGxhYm9yYXRvcjogQWdlbnRDb2xsYWJvcmF0b3IpIHtcbiAgICBhZ2VudENvbGxhYm9yYXRvci5ncmFudCh0aGlzLnJvbGUpO1xuICB9XG5cbiAgLyoqXG4gICAqIENvbmZpZ3VyYXRpb24gZm9yIGFnZW50IGNvbGxhYm9yYXRpb24uXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTm8gY29sbGFib3JhdGlvbiBjb25maWd1cmF0aW9uLlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGFkZEFjdGlvbkdyb3VwcyguLi5hY3Rpb25Hcm91cHM6IEFnZW50QWN0aW9uR3JvdXBbXSkge1xuICAgIGFjdGlvbkdyb3Vwcy5mb3JFYWNoKGFnID0+IHRoaXMuYWRkQWN0aW9uR3JvdXAoYWcpKTtcbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBMYXp5IFJlbmRlcmVyc1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAvKipcbiAgICogUmVuZGVyIHRoZSBndWFyZHJhaWwgY29uZmlndXJhdGlvbi5cbiAgICpcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwcml2YXRlIHJlbmRlckd1YXJkcmFpbCgpOiBiZWRyb2NrLkNmbkFnZW50Lkd1YXJkcmFpbENvbmZpZ3VyYXRpb25Qcm9wZXJ0eSB8IHVuZGVmaW5lZCB7XG4gICAgcmV0dXJuIHRoaXMuZ3VhcmRyYWlsXG4gICAgICA/IHtcbiAgICAgICAgZ3VhcmRyYWlsSWRlbnRpZmllcjogdGhpcy5ndWFyZHJhaWwuZ3VhcmRyYWlsSWQsXG4gICAgICAgIGd1YXJkcmFpbFZlcnNpb246IHRoaXMuZ3VhcmRyYWlsLmd1YXJkcmFpbFZlcnNpb24sXG4gICAgICB9XG4gICAgICA6IHVuZGVmaW5lZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXIgdGhlIGFjdGlvbiBncm91cHNcbiAgICpcbiAgICogQHJldHVybnMgQXJyYXkgb2YgQWdlbnRBY3Rpb25Hcm91cFByb3BlcnR5IG9iamVjdHMgaW4gQ2xvdWRGb3JtYXRpb24gZm9ybWF0XG4gICAqIEBkZWZhdWx0IC0gRW1wdHkgYXJyYXkgaWYgbm8gYWN0aW9uIGdyb3VwcyBhcmUgZGVmaW5lZFxuICAgKiBAaW50ZXJuYWwgVGhpcyBpcyBhbiBpbnRlcm5hbCBjb3JlIGZ1bmN0aW9uIGFuZCBzaG91bGQgbm90IGJlIGNhbGxlZCBkaXJlY3RseS5cbiAgICovXG4gIHByaXZhdGUgcmVuZGVyQWN0aW9uR3JvdXBzKCk6IGJlZHJvY2suQ2ZuQWdlbnQuQWdlbnRBY3Rpb25Hcm91cFByb3BlcnR5W10ge1xuICAgIGNvbnN0IGFjdGlvbkdyb3Vwc0NmbjogYmVkcm9jay5DZm5BZ2VudC5BZ2VudEFjdGlvbkdyb3VwUHJvcGVydHlbXSA9IFtdO1xuICAgIC8vIEJ1aWxkIHRoZSBhc3NvY2lhdGlvbnMgaW4gdGhlIENGTiBmb3JtYXRcbiAgICB0aGlzLmFjdGlvbkdyb3Vwcy5mb3JFYWNoKGFnID0+IHtcbiAgICAgIGFjdGlvbkdyb3Vwc0Nmbi5wdXNoKGFnLl9yZW5kZXIoKSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGFjdGlvbkdyb3Vwc0NmbjtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXIgdGhlIGFnZW50IGNvbGxhYm9yYXRvcnMuXG4gICAqXG4gICAqIEByZXR1cm5zIEFycmF5IG9mIEFnZW50Q29sbGFib3JhdG9yUHJvcGVydHkgb2JqZWN0cyBpbiBDbG91ZEZvcm1hdGlvbiBmb3JtYXQsIG9yIHVuZGVmaW5lZCBpZiBubyBjb2xsYWJvcmF0b3JzXG4gICAqIEBkZWZhdWx0IC0gdW5kZWZpbmVkIGlmIG5vIGNvbGxhYm9yYXRvcnMgYXJlIGRlZmluZWQgb3IgYXJyYXkgaXMgZW1wdHlcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwcml2YXRlIHJlbmRlckFnZW50Q29sbGFib3JhdG9ycygpOiBiZWRyb2NrLkNmbkFnZW50LkFnZW50Q29sbGFib3JhdG9yUHJvcGVydHlbXSB8IHVuZGVmaW5lZCB7XG4gICAgaWYgKCF0aGlzLmFnZW50Q29sbGFib3JhdGlvbiB8fCAhdGhpcy5hZ2VudENvbGxhYm9yYXRpb24uY29sbGFib3JhdG9ycyB8fCB0aGlzLmFnZW50Q29sbGFib3JhdGlvbi5jb2xsYWJvcmF0b3JzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5hZ2VudENvbGxhYm9yYXRpb24uY29sbGFib3JhdG9ycy5tYXAoYWMgPT4gYWMuX3JlbmRlcigpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXIgdGhlIGN1c3RvbSBvcmNoZXN0cmF0aW9uLlxuICAgKlxuICAgKiBAcmV0dXJucyBDdXN0b21PcmNoZXN0cmF0aW9uUHJvcGVydHkgb2JqZWN0IGluIENsb3VkRm9ybWF0aW9uIGZvcm1hdCwgb3IgdW5kZWZpbmVkIGlmIG5vIGN1c3RvbSBvcmNoZXN0cmF0aW9uXG4gICAqIEBkZWZhdWx0IC0gdW5kZWZpbmVkIGlmIG5vIGN1c3RvbSBvcmNoZXN0cmF0aW9uIGlzIGRlZmluZWRcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwcml2YXRlIHJlbmRlckN1c3RvbU9yY2hlc3RyYXRpb24oKTogYmVkcm9jay5DZm5BZ2VudC5DdXN0b21PcmNoZXN0cmF0aW9uUHJvcGVydHkgfCB1bmRlZmluZWQge1xuICAgIGlmICghdGhpcy5jdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3IpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIGV4ZWN1dG9yOiB7XG4gICAgICAgIGxhbWJkYTogdGhpcy5jdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3IubGFtYmRhRnVuY3Rpb24uZnVuY3Rpb25Bcm4sXG4gICAgICB9LFxuICAgIH07XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gVmFsaWRhdG9yc1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIENoZWNrcyBpZiB0aGUgR3VhcmRyYWlsIGlzIHZhbGlkXG4gICAqXG4gICAqIEBwYXJhbSBndWFyZHJhaWwgLSBUaGUgZ3VhcmRyYWlsIHRvIHZhbGlkYXRlXG4gICAqIEByZXR1cm5zIEFycmF5IG9mIHZhbGlkYXRpb24gZXJyb3IgbWVzc2FnZXMsIGVtcHR5IGlmIHZhbGlkXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlR3VhcmRyYWlsID0gKGd1YXJkcmFpbDogSUd1YXJkcmFpbCkgPT4ge1xuICAgIGxldCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG4gICAgaWYgKHRoaXMuZ3VhcmRyYWlsKSB7XG4gICAgICBlcnJvcnMucHVzaChcbiAgICAgICAgYENhbm5vdCBhZGQgR3VhcmRyYWlsICR7Z3VhcmRyYWlsLmd1YXJkcmFpbElkfS4gYCArXG4gICAgICAgICAgYEd1YXJkcmFpbCAke3RoaXMuZ3VhcmRyYWlsLmd1YXJkcmFpbElkfSBoYXMgYWxyZWFkeSBiZWVuIHNwZWNpZmllZCBmb3IgdGhpcyBhZ2VudC5gLFxuICAgICAgKTtcbiAgICB9XG4gICAgZXJyb3JzLnB1c2goLi4udmFsaWRhdGlvbi52YWxpZGF0ZUZpZWxkUGF0dGVybihndWFyZHJhaWwuZ3VhcmRyYWlsVmVyc2lvbiwgJ3ZlcnNpb24nLCAvXigoWzAtOV17MSw4fSl8KERSQUZUKSkkLykpO1xuICAgIHJldHVybiBlcnJvcnM7XG4gIH07XG5cbiAgLyoqXG4gICAqIENoZWNrIGlmIHRoZSBhY3Rpb24gZ3JvdXAgaXMgdmFsaWRcbiAgICpcbiAgICogQHBhcmFtIGFjdGlvbkdyb3VwIC0gVGhlIGFjdGlvbiBncm91cCB0byB2YWxpZGF0ZVxuICAgKiBAcmV0dXJucyBBcnJheSBvZiB2YWxpZGF0aW9uIGVycm9yIG1lc3NhZ2VzLCBlbXB0eSBpZiB2YWxpZFxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZUFjdGlvbkdyb3VwID0gKGFjdGlvbkdyb3VwOiBBZ2VudEFjdGlvbkdyb3VwKSA9PiB7XG4gICAgbGV0IGVycm9yczogc3RyaW5nW10gPSBbXTtcbiAgICAvLyBGaW5kIGlmIHRoZXJlIGlzIGEgY29uZmxpY3RpbmcgYWN0aW9uIGdyb3VwIG5hbWVcbiAgICBpZiAodGhpcy5hY3Rpb25Hcm91cHM/LmZpbmQoYWcgPT4gYWcubmFtZSA9PT0gYWN0aW9uR3JvdXAubmFtZSkpIHtcbiAgICAgIGVycm9ycy5wdXNoKCdBY3Rpb24gZ3JvdXAgYWxyZWFkeSBleGlzdHMnKTtcbiAgICB9XG4gICAgcmV0dXJuIGVycm9ycztcbiAgfTtcblxuICAvKipcbiAgICogR2VuZXJhdGVzIGEgdW5pcXVlLCBkZXRlcm1pbmlzdGljIG5hbWUgZm9yIEFXUyByZXNvdXJjZXMgdGhhdCBpbmNsdWRlcyBhIGhhc2ggY29tcG9uZW50LlxuICAgKiBUaGlzIG1ldGhvZCBlbnN1cmVzIGNvbnNpc3RlbnQgbmFtaW5nIHdoaWxlIGF2b2lkaW5nIGNvbmZsaWN0cyBhbmQgYWRoZXJpbmcgdG8gQVdTIG5hbWluZyBjb25zdHJhaW50cy5cbiAgICogQHBhcmFtIHNjb3BlIC0gVGhlIGNvbnN0cnVjdCBzY29wZSB1c2VkIGZvciBnZW5lcmF0aW5nIHVuaXF1ZSBuYW1lc1xuICAgKiBAcGFyYW0gcHJlZml4IC0gVGhlIHByZWZpeCB0byBwcmVwZW5kIHRvIHRoZSBnZW5lcmF0ZWQgbmFtZVxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIENvbmZpZ3VyYXRpb24gb3B0aW9ucyBmb3IgbmFtZSBnZW5lcmF0aW9uXG4gICAqIEBwYXJhbSBvcHRpb25zLm1heExlbmd0aCAtIE1heGltdW0gbGVuZ3RoIG9mIHRoZSBnZW5lcmF0ZWQgbmFtZVxuICAgKiBAZGVmYXVsdCAtIG1heExlbmd0aDogMjU2XG4gICAqIEBwYXJhbSBvcHRpb25zLmxvd2VyIC0gQ29udmVydCB0aGUgZ2VuZXJhdGVkIG5hbWUgdG8gbG93ZXJjYXNlXG4gICAqIEBkZWZhdWx0IC0gbG93ZXI6IGZhbHNlXG4gICAqIEBwYXJhbSBvcHRpb25zLnNlcGFyYXRvciAtIENoYXJhY3RlcihzKSB0byB1c2UgYmV0d2VlbiBuYW1lIGNvbXBvbmVudHNcbiAgICogQGRlZmF1bHQgLSBzZXBhcmF0b3I6ICcnXG4gICAqIEBwYXJhbSBvcHRpb25zLmFsbG93ZWRTcGVjaWFsQ2hhcmFjdGVycyAtIFN0cmluZyBvZiBhbGxvd2VkIHNwZWNpYWwgY2hhcmFjdGVyc1xuICAgKiBAZGVmYXVsdCAtIHVuZGVmaW5lZFxuICAgKiBAcGFyYW0gb3B0aW9ucy5kZXN0cm95Q3JlYXRlIC0gT2JqZWN0IHRvIGluY2x1ZGUgaW4gaGFzaCBnZW5lcmF0aW9uIGZvciBkZXN0cm95L2NyZWF0ZSBvcGVyYXRpb25zXG4gICAqIEBkZWZhdWx0IC0gdW5kZWZpbmVkXG4gICAqIEByZXR1cm5zIEEgc3RyaW5nIGNvbnRhaW5pbmcgdGhlIGdlbmVyYXRlZCBuYW1lIHdpdGggZm9ybWF0OiBwcmVmaXggKyBoYXNoICsgc2VwYXJhdG9yICsgdW5pcXVlTmFtZVxuICAgKiBAdGhyb3dzIFZhbGlkYXRpb25FcnJvciBpZiB0aGUgZ2VuZXJhdGVkIG5hbWUgd291bGQgZXhjZWVkIG1heExlbmd0aCBvciBpZiBwcmVmaXggaXMgdG9vIGxvbmdcbiAgICogQGludGVybmFsXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlUGh5c2ljYWxOYW1lSGFzaChcbiAgICBzY29wZTogSUNvbnN0cnVjdCxcbiAgICBwcmVmaXg6IHN0cmluZyxcbiAgICBvcHRpb25zPzoge1xuICAgICAgbWF4TGVuZ3RoPzogbnVtYmVyO1xuICAgICAgbG93ZXI/OiBib29sZWFuO1xuICAgICAgc2VwYXJhdG9yPzogc3RyaW5nO1xuICAgICAgYWxsb3dlZFNwZWNpYWxDaGFyYWN0ZXJzPzogc3RyaW5nO1xuICAgICAgZGVzdHJveUNyZWF0ZT86IGFueTtcbiAgICB9LFxuICApOiBzdHJpbmcge1xuICAgIGNvbnN0IG9iamVjdFRvSGFzaCA9IChvYmo6IGFueSk6IHN0cmluZyA9PiB7XG4gICAgICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuICcnOyB9XG4gICAgICBjb25zdCBqc29uU3RyaW5nID0gSlNPTi5zdHJpbmdpZnkob2JqKTtcbiAgICAgIGNvbnN0IGhhc2ggPSBjcnlwdG8uY3JlYXRlSGFzaCgnc2hhMjU2Jyk7XG4gICAgICByZXR1cm4gaGFzaC51cGRhdGUoanNvblN0cmluZykuZGlnZXN0KCdoZXgnKS5zbGljZSgwLCA3KTtcbiAgICB9O1xuXG4gICAgY29uc3Qge1xuICAgICAgbWF4TGVuZ3RoID0gMjU2LFxuICAgICAgbG93ZXIgPSBmYWxzZSxcbiAgICAgIHNlcGFyYXRvciA9ICcnLFxuICAgICAgYWxsb3dlZFNwZWNpYWxDaGFyYWN0ZXJzID0gdW5kZWZpbmVkLFxuICAgICAgZGVzdHJveUNyZWF0ZSA9IHVuZGVmaW5lZCxcbiAgICB9ID0gb3B0aW9ucyA/PyB7fTtcblxuICAgIGNvbnN0IGhhc2ggPSBvYmplY3RUb0hhc2goZGVzdHJveUNyZWF0ZSk7XG4gICAgaWYgKG1heExlbmd0aCA8IChwcmVmaXggKyBoYXNoICsgc2VwYXJhdG9yKS5sZW5ndGgpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YFByZWZpeFRvb0xvbmdgLCAnVGhlIHByZWZpeCBpcyBsb25nZXIgdGhhbiB0aGUgbWF4aW11bSBsZW5ndGguJywgdGhpcyk7XG4gICAgfVxuXG4gICAgY29uc3QgdW5pcXVlTmFtZSA9IE5hbWVzLnVuaXF1ZVJlc291cmNlTmFtZShcbiAgICAgIHNjb3BlLFxuICAgICAgeyBtYXhMZW5ndGg6IG1heExlbmd0aCAtIChwcmVmaXggKyBoYXNoICsgc2VwYXJhdG9yKS5sZW5ndGgsIHNlcGFyYXRvciwgYWxsb3dlZFNwZWNpYWxDaGFyYWN0ZXJzIH0sXG4gICAgKTtcbiAgICBjb25zdCBuYW1lID0gYCR7cHJlZml4fSR7aGFzaH0ke3NlcGFyYXRvcn0ke3VuaXF1ZU5hbWV9YDtcbiAgICBpZiAobmFtZS5sZW5ndGggPiBtYXhMZW5ndGgpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YEdlbmVyYXRlZE5hbWVUb29Mb25nYCwgYFRoZSBnZW5lcmF0ZWQgbmFtZSBpcyBsb25nZXIgdGhhbiB0aGUgbWF4aW11bSBsZW5ndGggb2YgJHttYXhMZW5ndGh9YCwgdGhpcyk7XG4gICAgfVxuICAgIHJldHVybiBsb3dlciA/IG5hbWUudG9Mb3dlckNhc2UoKSA6IG5hbWU7XG4gIH1cblxuICAvKipcbiAgICogR2VuZXJhdGVzIGEgcGh5c2ljYWwgbmFtZSBmb3IgdGhlIGFnZW50LlxuICAgKiBAcmV0dXJucyBBIHVuaXF1ZSBuYW1lIGZvciB0aGUgYWdlbnQgd2l0aCBhcHByb3ByaWF0ZSBsZW5ndGggY29uc3RyYWludHNcbiAgICogQGRlZmF1bHQgLSBHZW5lcmF0ZWQgbmFtZSBmb3JtYXQ6ICdhZ2VudC17aGFzaH0te3VuaXF1ZU5hbWV9JyB3aXRoOlxuICAgKiAtIG1heExlbmd0aDogTUFYTEVOR1RIX0ZPUl9ST0xFX05BTUUgLSAnLWJlZHJvY2thZ2VudCcubGVuZ3RoXG4gICAqIC0gbG93ZXI6IHRydWVcbiAgICogLSBzZXBhcmF0b3I6ICctJ1xuICAgKiBAcHJvdGVjdGVkXG4gICAqL1xuICBwcm90ZWN0ZWQgZ2VuZXJhdGVQaHlzaWNhbE5hbWUoKTogc3RyaW5nIHtcbiAgICBjb25zdCBtYXhMZW5ndGggPSB0aGlzLk1BWExFTkdUSF9GT1JfUk9MRV9OQU1FIC0gdGhpcy5ST0xFX05BTUVfU1VGRklYLmxlbmd0aDtcbiAgICByZXR1cm4gdGhpcy5nZW5lcmF0ZVBoeXNpY2FsTmFtZUhhc2godGhpcywgJ2FnZW50Jywge1xuICAgICAgbWF4TGVuZ3RoLFxuICAgICAgbG93ZXI6IHRydWUsXG4gICAgICBzZXBhcmF0b3I6ICctJyxcbiAgICB9KTtcbiAgfVxufVxuIl19