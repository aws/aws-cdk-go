"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomOrchestrationExecutor = exports.OrchestrationType = void 0;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
/**
 * Enum for orchestration types available for agents.
 */
var OrchestrationType;
(function (OrchestrationType) {
    /**
     * Default orchestration by the agent.
     */
    OrchestrationType["DEFAULT"] = "DEFAULT";
    /**
     * Custom orchestration using Lambda.
     */
    OrchestrationType["CUSTOM_ORCHESTRATION"] = "CUSTOM_ORCHESTRATION";
})(OrchestrationType || (exports.OrchestrationType = OrchestrationType = {}));
/******************************************************************************
 *                         Custom Orchestration Executor
 *****************************************************************************/
/**
 * Contains details about the Lambda function containing the orchestration logic carried
 * out upon invoking the custom orchestration.
 */
class CustomOrchestrationExecutor {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.CustomOrchestrationExecutor", version: "2.252.0-alpha.0" };
    /**
     * Defines an orchestration executor with a Lambda function containing the business logic.
     * @param lambdaFunction - Lambda function to be called by the orchestration.
     */
    static fromLambda(lambdaFunction) {
        return new CustomOrchestrationExecutor(lambdaFunction);
    }
    /**
     * The type of orchestration this executor performs.
     */
    type = OrchestrationType.CUSTOM_ORCHESTRATION;
    /**
     * The Lambda function that contains the custom orchestration logic.
     * This function is called when the agent needs to make decisions about action execution.
     */
    lambdaFunction;
    constructor(lambdaFunction) {
        this.lambdaFunction = lambdaFunction;
    }
    /**
     * Format as CFN properties
     *
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            lambda: this.lambdaFunction?.functionArn,
        };
    }
}
exports.CustomOrchestrationExecutor = CustomOrchestrationExecutor;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3JjaGVzdHJhdGlvbi1leGVjdXRvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIm9yY2hlc3RyYXRpb24tZXhlY3V0b3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUdBOztHQUVHO0FBQ0gsSUFBWSxpQkFVWDtBQVZELFdBQVksaUJBQWlCO0lBQzNCOztPQUVHO0lBQ0gsd0NBQW1CLENBQUE7SUFFbkI7O09BRUc7SUFDSCxrRUFBNkMsQ0FBQTtBQUMvQyxDQUFDLEVBVlcsaUJBQWlCLGlDQUFqQixpQkFBaUIsUUFVNUI7QUFFRDs7K0VBRStFO0FBQy9FOzs7R0FHRztBQUNILE1BQWEsMkJBQTJCOztJQUN0Qzs7O09BR0c7SUFDSSxNQUFNLENBQUMsVUFBVSxDQUFDLGNBQXlCO1FBQ2hELE9BQU8sSUFBSSwyQkFBMkIsQ0FBQyxjQUFjLENBQUMsQ0FBQztLQUN4RDtJQUVEOztPQUVHO0lBQ2EsSUFBSSxHQUFzQixpQkFBaUIsQ0FBQyxvQkFBb0IsQ0FBQztJQUVqRjs7O09BR0c7SUFDYSxjQUFjLENBQVk7SUFFMUMsWUFBb0IsY0FBeUI7UUFDM0MsSUFBSSxDQUFDLGNBQWMsR0FBRyxjQUFjLENBQUM7S0FDdEM7SUFFRDs7OztPQUlHO0lBQ0ksT0FBTztRQUNaLE9BQU87WUFDTCxNQUFNLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBRSxXQUFXO1NBQ3pDLENBQUM7S0FDSDs7QUFqQ0gsa0VBa0NDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgKiBhcyBiZWRyb2NrIGZyb20gJ2F3cy1jZGstbGliL2F3cy1iZWRyb2NrJztcbmltcG9ydCB0eXBlIHsgSUZ1bmN0aW9uIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWxhbWJkYSc7XG5cbi8qKlxuICogRW51bSBmb3Igb3JjaGVzdHJhdGlvbiB0eXBlcyBhdmFpbGFibGUgZm9yIGFnZW50cy5cbiAqL1xuZXhwb3J0IGVudW0gT3JjaGVzdHJhdGlvblR5cGUge1xuICAvKipcbiAgICogRGVmYXVsdCBvcmNoZXN0cmF0aW9uIGJ5IHRoZSBhZ2VudC5cbiAgICovXG4gIERFRkFVTFQgPSAnREVGQVVMVCcsXG5cbiAgLyoqXG4gICAqIEN1c3RvbSBvcmNoZXN0cmF0aW9uIHVzaW5nIExhbWJkYS5cbiAgICovXG4gIENVU1RPTV9PUkNIRVNUUkFUSU9OID0gJ0NVU1RPTV9PUkNIRVNUUkFUSU9OJyxcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tIE9yY2hlc3RyYXRpb24gRXhlY3V0b3JcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogQ29udGFpbnMgZGV0YWlscyBhYm91dCB0aGUgTGFtYmRhIGZ1bmN0aW9uIGNvbnRhaW5pbmcgdGhlIG9yY2hlc3RyYXRpb24gbG9naWMgY2FycmllZFxuICogb3V0IHVwb24gaW52b2tpbmcgdGhlIGN1c3RvbSBvcmNoZXN0cmF0aW9uLlxuICovXG5leHBvcnQgY2xhc3MgQ3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yIHtcbiAgLyoqXG4gICAqIERlZmluZXMgYW4gb3JjaGVzdHJhdGlvbiBleGVjdXRvciB3aXRoIGEgTGFtYmRhIGZ1bmN0aW9uIGNvbnRhaW5pbmcgdGhlIGJ1c2luZXNzIGxvZ2ljLlxuICAgKiBAcGFyYW0gbGFtYmRhRnVuY3Rpb24gLSBMYW1iZGEgZnVuY3Rpb24gdG8gYmUgY2FsbGVkIGJ5IHRoZSBvcmNoZXN0cmF0aW9uLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tTGFtYmRhKGxhbWJkYUZ1bmN0aW9uOiBJRnVuY3Rpb24pOiBDdXN0b21PcmNoZXN0cmF0aW9uRXhlY3V0b3Ige1xuICAgIHJldHVybiBuZXcgQ3VzdG9tT3JjaGVzdHJhdGlvbkV4ZWN1dG9yKGxhbWJkYUZ1bmN0aW9uKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgdHlwZSBvZiBvcmNoZXN0cmF0aW9uIHRoaXMgZXhlY3V0b3IgcGVyZm9ybXMuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgdHlwZTogT3JjaGVzdHJhdGlvblR5cGUgPSBPcmNoZXN0cmF0aW9uVHlwZS5DVVNUT01fT1JDSEVTVFJBVElPTjtcblxuICAvKipcbiAgICogVGhlIExhbWJkYSBmdW5jdGlvbiB0aGF0IGNvbnRhaW5zIHRoZSBjdXN0b20gb3JjaGVzdHJhdGlvbiBsb2dpYy5cbiAgICogVGhpcyBmdW5jdGlvbiBpcyBjYWxsZWQgd2hlbiB0aGUgYWdlbnQgbmVlZHMgdG8gbWFrZSBkZWNpc2lvbnMgYWJvdXQgYWN0aW9uIGV4ZWN1dGlvbi5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBsYW1iZGFGdW5jdGlvbjogSUZ1bmN0aW9uO1xuXG4gIHByaXZhdGUgY29uc3RydWN0b3IobGFtYmRhRnVuY3Rpb246IElGdW5jdGlvbikge1xuICAgIHRoaXMubGFtYmRhRnVuY3Rpb24gPSBsYW1iZGFGdW5jdGlvbjtcbiAgfVxuXG4gIC8qKlxuICAgKiBGb3JtYXQgYXMgQ0ZOIHByb3BlcnRpZXNcbiAgICpcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBiZWRyb2NrLkNmbkFnZW50Lk9yY2hlc3RyYXRpb25FeGVjdXRvclByb3BlcnR5IHtcbiAgICByZXR1cm4ge1xuICAgICAgbGFtYmRhOiB0aGlzLmxhbWJkYUZ1bmN0aW9uPy5mdW5jdGlvbkFybixcbiAgICB9O1xuICB9XG59XG4iXX0=