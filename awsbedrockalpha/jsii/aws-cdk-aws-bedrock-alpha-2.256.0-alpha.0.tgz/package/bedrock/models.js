"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BedrockFoundationModel = exports.VectorType = void 0;
const jsiiDeprecationWarnings = require("../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
const aws_cdk_lib_1 = require("aws-cdk-lib");
const aws_iam_1 = require("aws-cdk-lib/aws-iam");
/**
 * The data type for the vectors when using a model to convert text into vector embeddings.
 * The model must support the specified data type for vector embeddings. Floating-point (float32)
 * is the default data type, and is supported by most models for vector embeddings. See Supported
 * embeddings models for information on the available models and their vector data types.
 */
var VectorType;
(function (VectorType) {
    /**
     * `FLOATING_POINT` convert the data to floating-point (float32) vector embeddings (more precise, but more costly).
     */
    VectorType["FLOATING_POINT"] = "FLOAT32";
    /**
     * `BINARY` convert the data to binary vector embeddings (less precise, but less costly).
     */
    VectorType["BINARY"] = "BINARY";
})(VectorType || (exports.VectorType = VectorType = {}));
/**
 * Bedrock models.
 *
 * If you need to use a model name that doesn't exist as a static member, you
 * can instantiate a `BedrockFoundationModel` object, e.g: `new BedrockFoundationModel('my-model')`.
 */
class BedrockFoundationModel {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.BedrockFoundationModel", version: "2.256.0-alpha.0" };
    /****************************************************************************
     *                            AI21
     ***************************************************************************/
    /**
     * AI21's Jamba 1.5 Large model optimized for text generation tasks.
     * Suitable for complex language understanding and generation tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Optimized for natural language processing
     * - Best for: Content generation, summarization, and complex text analysis
     */
    static AI21_JAMBA_1_5_LARGE_V1 = new BedrockFoundationModel('ai21.jamba-1-5-large-v1:0', {
        supportsAgents: true,
    });
    /**
     * AI21's Jamba 1.5 Mini model, a lighter version optimized for faster processing.
     * Balances performance with efficiency for general text tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Faster response times compared to larger models
     * - Best for: Quick text processing, basic content generation
     */
    static AI21_JAMBA_1_5_MINI_V1 = new BedrockFoundationModel('ai21.jamba-1-5-mini-v1:0', {
        supportsAgents: true,
    });
    /**
     * AI21's Jamba Instruct model, specifically designed for instruction-following tasks.
     * Optimized for understanding and executing specific instructions.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Enhanced instruction understanding
     * - Best for: Task-specific instructions, command processing
     */
    static AI21_JAMBA_INSTRUCT_V1 = new BedrockFoundationModel('ai21.jamba-instruct-v1:0', {
        supportsAgents: true,
    });
    /****************************************************************************
     *                            AMAZON
     ***************************************************************************/
    /**
     * Amazon's Titan Text Express model, optimized for fast text generation.
     * Provides quick responses while maintaining good quality output.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Fast response times
     * - Best for: Real-time applications, chatbots, quick content generation
     */
    static AMAZON_TITAN_TEXT_EXPRESS_V1 = new BedrockFoundationModel('amazon.titan-text-express-v1', {
        supportsAgents: true,
    });
    /**
     * Amazon's Titan Text Premier model, designed for high-quality text generation.
     * Offers enhanced capabilities for complex language tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Advanced language understanding
     * - Best for: Complex content generation, detailed analysis
     */
    static AMAZON_TITAN_PREMIER_V1_0 = new BedrockFoundationModel('amazon.titan-text-premier-v1:0', {
        supportsAgents: true,
    });
    /**
     * Amazon's Nova Micro model, a lightweight model optimized for efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Quick processing tasks, basic language understanding
     */
    static AMAZON_NOVA_MICRO_V1 = new BedrockFoundationModel('amazon.nova-micro-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
        optimizedForAgents: true,
    });
    /**
     * Amazon's Nova Lite model, balancing performance with efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: General-purpose language tasks, moderate complexity
     */
    static AMAZON_NOVA_LITE_V1 = new BedrockFoundationModel('amazon.nova-lite-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
        optimizedForAgents: true,
    });
    /**
     * Amazon's Nova Pro model, offering advanced capabilities for complex tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Complex language tasks, professional applications
     */
    static AMAZON_NOVA_PRO_V1 = new BedrockFoundationModel('amazon.nova-pro-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
        optimizedForAgents: true,
    });
    /**
     * Amazon's Nova Premier model, the most advanced in the Nova series.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: High-end applications, complex analysis, premium performance
     */
    static AMAZON_NOVA_PREMIER_V1 = new BedrockFoundationModel('amazon.nova-premier-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
        optimizedForAgents: true,
    });
    /**
     * Amazon's Titan Embed Text V1 model for text embeddings.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 1536-dimensional vectors
     * - Floating-point vector type
     * - Best for: Text embeddings, semantic search, document similarity
     */
    static TITAN_EMBED_TEXT_V1 = new BedrockFoundationModel('amazon.titan-embed-text-v1', {
        supportsKnowledgeBase: true,
        vectorDimensions: 1536,
        supportedVectorType: [VectorType.FLOATING_POINT],
    });
    /**
     * Amazon's Titan Embed Text V2 model with 1024-dimensional vectors.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 1024-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: High-dimensional embeddings, advanced semantic search
     */
    static TITAN_EMBED_TEXT_V2_1024 = new BedrockFoundationModel('amazon.titan-embed-text-v2:0', {
        supportsKnowledgeBase: true,
        vectorDimensions: 1024,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /**
     * Amazon's Titan Embed Text V2 model with 512-dimensional vectors.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 512-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: Balanced performance and dimensionality
     */
    static TITAN_EMBED_TEXT_V2_512 = new BedrockFoundationModel('amazon.titan-embed-text-v2:0', {
        supportsKnowledgeBase: true,
        vectorDimensions: 512,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /**
     * Amazon's Titan Embed Text V2 model with 256-dimensional vectors.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 256-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: Efficient embeddings with lower dimensionality
     */
    static TITAN_EMBED_TEXT_V2_256 = new BedrockFoundationModel('amazon.titan-embed-text-v2:0', {
        supportsKnowledgeBase: true,
        vectorDimensions: 256,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /****************************************************************************
     *                            ANTHROPIC
     ***************************************************************************/
    /**
     * Anthropic's Claude Haiku 4.5 model, most cost-efficient and fastest.
     * Delivers near-frontier performance with substantially lower cost and faster speeds.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Large-scale deployments, budget-conscious applications, real-time customer service, latency-sensitive use cases
     */
    static ANTHROPIC_CLAUDE_HAIKU_4_5_V1_0 = new BedrockFoundationModel('anthropic.claude-haiku-4-5-20251001-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Sonnet 4.5 model, most intelligent in the Claude 4 series.
     * Demonstrates advancements in agent capabilities with enhanced performance in tool handling,
     * memory management, and context processing. Excels at autonomous long-horizon coding tasks.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Enhanced tool handling and memory management for long-running tasks
     * - Best for: Complex agents, coding, autonomous long-horizon tasks, research and analysis, cybersecurity and finance applications
     */
    static ANTHROPIC_CLAUDE_SONNET_4_5_V1_0 = new BedrockFoundationModel('anthropic.claude-sonnet-4-5-20250929-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4.6 model, the most intelligent model and the world's best model
     * for coding, enterprise agents, and professional work.
     * Supports both 200K and 1M context tokens (with the latter in preview).
     * Excels in agentic workflows, complex coding projects, and enterprise applications
     * requiring sophisticated reasoning.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Financial analysis, cybersecurity, computer use workflows, long-horizon development, multi-tool orchestration
     */
    static ANTHROPIC_CLAUDE_OPUS_4_6_V1 = new BedrockFoundationModel('anthropic.claude-opus-4-6-v1', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4.7 model, Anthropic's most capable generally available model,
     * advancing performance across coding, enterprise workflows, and long-running agentic tasks.
     * Features a 1M token context window, 128K max output tokens, and supports reasoning.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     */
    static ANTHROPIC_CLAUDE_OPUS_4_7 = new BedrockFoundationModel('anthropic.claude-opus-4-7', { supportsAgents: true, supportsCrossRegion: true });
    /**
     * Anthropic's Claude Sonnet 4.6 model.
     * Improved performance for coding, agentic workflows, and browser-based automation.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Coding, agentic workflows, browser-based automation, enterprise applications
     */
    static ANTHROPIC_CLAUDE_SONNET_4_6 = new BedrockFoundationModel('anthropic.claude-sonnet-4-6', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4.5 model, the flagship model released November 2025.
     * Excels at real-world programming tasks, scoring highest on SWE-bench Verified benchmarks.
     * Demonstrates superior performance in long-horizon, goal-directed agentic work with fewer dead-ends.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Software engineering, code migration, agentic workflows, financial modeling, deep research
     */
    static ANTHROPIC_CLAUDE_OPUS_4_5_V1_0 = new BedrockFoundationModel('anthropic.claude-opus-4-5-20251101-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4.1 model, most advanced for coding and agentic applications.
     * Excels at independently planning and executing complex development tasks end-to-end.
     * Drop-in replacement for Opus 4 with superior performance and precision.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Complex end-to-end development, agentic applications, research, advanced reasoning
     */
    static ANTHROPIC_CLAUDE_OPUS_4_1_V1_0 = new BedrockFoundationModel('anthropic.claude-opus-4-1-20250805-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4 model, next-generation frontier model.
     * High-performance model for advanced reasoning and complex multi-step tasks.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Advanced reasoning, complex workflows, enterprise applications
     */
    static ANTHROPIC_CLAUDE_OPUS_4_V1_0 = new BedrockFoundationModel('anthropic.claude-opus-4-20250514-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Sonnet 4 model, next-generation frontier model.
     * Advanced model with improved performance for production environments.
     * Balances quality, cost-effectiveness, and responsiveness.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Production applications, complex language tasks, balanced performance and cost
     */
    static ANTHROPIC_CLAUDE_SONNET_4_V1_0 = new BedrockFoundationModel('anthropic.claude-sonnet-4-20250514-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude 3.7 Sonnet model, latest in the Claude 3 series.
     * Advanced language model with enhanced capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Complex reasoning, analysis, and content generation
     */
    static ANTHROPIC_CLAUDE_3_7_SONNET_V1_0 = new BedrockFoundationModel('anthropic.claude-3-7-sonnet-20250219-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: false });
    /**
     * Anthropic's Claude 3.5 Sonnet V2 model, optimized for agent interactions.
     * Enhanced version with improved performance and capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Agent-based applications, complex dialogue
     */
    static ANTHROPIC_CLAUDE_3_5_SONNET_V2_0 = new BedrockFoundationModel('anthropic.claude-3-5-sonnet-20241022-v2:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude 3.5 Sonnet V1 model, balanced performance model.
     * Offers good balance between performance and efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: General language tasks, balanced performance
     */
    static ANTHROPIC_CLAUDE_3_5_SONNET_V1_0 = new BedrockFoundationModel('anthropic.claude-3-5-sonnet-20240620-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude 3.5 Haiku model, optimized for quick responses.
     * Lightweight model focused on speed and efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Fast responses, lightweight processing
     */
    static ANTHROPIC_CLAUDE_3_5_HAIKU_V1_0 = new BedrockFoundationModel('anthropic.claude-3-5-haiku-20241022-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus model, designed for advanced tasks.
     * High-performance model with extensive capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Optimized for agents
     * - Best for: Complex reasoning, research, and analysis
     */
    static ANTHROPIC_CLAUDE_OPUS_V1_0 = new BedrockFoundationModel('anthropic.claude-3-opus-20240229-v1:0', { supportsAgents: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Sonnet model, legacy version.
     * Balanced model for general-purpose tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Legacy model with EOL date
     * - Best for: General language tasks, standard applications
     */
    static ANTHROPIC_CLAUDE_SONNET_V1_0 = new BedrockFoundationModel('anthropic.claude-3-sonnet-20240229-v1:0', { supportsAgents: true, supportsCrossRegion: true, legacy: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Haiku model, optimized for efficiency.
     * Fast and efficient model for lightweight tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Quick responses, simple tasks
     */
    static ANTHROPIC_CLAUDE_HAIKU_V1_0 = new BedrockFoundationModel('anthropic.claude-3-haiku-20240307-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude V2.1 model, legacy version.
     * Improved version of Claude V2 with enhanced capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Legacy model with EOL date
     * - Optimized for agents
     * - Best for: General language tasks, legacy applications
     */
    static ANTHROPIC_CLAUDE_V2_1 = new BedrockFoundationModel('anthropic.claude-v2:1', {
        supportsAgents: true,
        legacy: true,
        optimizedForAgents: true,
    });
    /**
     * Anthropic's Claude V2 model, legacy version.
     * Original Claude V2 model with broad capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Legacy model with EOL date
     * - Optimized for agents
     * - Best for: General language tasks, legacy applications
     */
    static ANTHROPIC_CLAUDE_V2 = new BedrockFoundationModel('anthropic.claude-v2', {
        supportsAgents: true,
        legacy: true,
        optimizedForAgents: true,
    });
    /**
     * Anthropic's Claude Instant V1.2 model, legacy version.
     * Fast and efficient model optimized for quick responses.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Legacy model with EOL date
     * - Optimized for agents
     * - Best for: Quick responses, simple tasks, legacy applications
     */
    static ANTHROPIC_CLAUDE_INSTANT_V1_2 = new BedrockFoundationModel('anthropic.claude-instant-v1', {
        supportsAgents: true,
        legacy: true,
        optimizedForAgents: true,
    });
    /****************************************************************************
     *                            COHERE
     ***************************************************************************/
    /**
     * Cohere's English embedding model, optimized for English text embeddings.
     * Specialized for semantic understanding of English content.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 1024-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: English text embeddings, semantic search, content similarity
     */
    static COHERE_EMBED_ENGLISH_V3 = new BedrockFoundationModel('cohere.embed-english-v3', {
        supportsKnowledgeBase: true,
        vectorDimensions: 1024,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /**
     * Cohere's Multilingual embedding model, supporting multiple languages.
     * Enables semantic understanding across different languages.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 1024-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: Cross-lingual embeddings, multilingual semantic search
     */
    static COHERE_EMBED_MULTILINGUAL_V3 = new BedrockFoundationModel('cohere.embed-multilingual-v3', {
        supportsKnowledgeBase: true,
        vectorDimensions: 1024,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /****************************************************************************
     *                            DEEPSEEK
     ***************************************************************************/
    /**
     * Deepseek's R1 model, designed for general language understanding.
     * Balanced model for various language tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: General language tasks, content generation
     */
    static DEEPSEEK_R1_V1 = new BedrockFoundationModel('deepseek.r1-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /****************************************************************************
     *                            META
     ***************************************************************************/
    /**
     * Meta's Llama 3 1.8B Instruct model, compact instruction-following model.
     * Efficient model optimized for instruction-based tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Lightweight instruction processing, quick responses
     */
    static META_LLAMA_3_1_8B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-1-8b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3 70B Instruct model, large-scale instruction model.
     * High-capacity model for complex language understanding.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Complex instructions, advanced language tasks
     */
    static META_LLAMA_3_1_70B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-1-70b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3.2 11B Instruct model, mid-sized instruction model.
     * Balanced model for general instruction processing.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: General instruction tasks, balanced performance
     */
    static META_LLAMA_3_2_11B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-2-11b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3.2 3B Instruct model, compact efficient model.
     * Lightweight model for basic instruction processing.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Basic instructions, efficient processing
     */
    static META_LLAMA_3_2_3B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-2-3b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3.2 1B Instruct model, ultra-lightweight model.
     * Most compact model in the Llama 3.2 series.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Simple instructions, fastest response times
     */
    static META_LLAMA_3_2_1B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-2-1b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3.3 70B Instruct model, latest large-scale model.
     * Advanced model with enhanced capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Complex reasoning, advanced language tasks
     */
    static META_LLAMA_3_3_70B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-3-70b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 4 Maverick 17B Instruct model, innovative mid-sized model.
     * Specialized for creative and dynamic responses.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Creative tasks, innovative solutions
     */
    static META_LLAMA_4_MAVERICK_17B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama4-maverick-17b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 4 Scout 17B Instruct model, analytical mid-sized model.
     * Focused on precise and analytical responses.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Analytical tasks, precise responses
     */
    static META_LLAMA_4_SCOUT_17B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama4-scout-17b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /****************************************************************************
     *                            MISTRAL AI
     ***************************************************************************/
    /**
     * Mistral's 7B Instruct model, efficient instruction-following model.
     * Balanced performance for instruction processing.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Optimized for instruction tasks
     * - Best for: General instruction processing, balanced performance
     */
    static MISTRAL_7B_INSTRUCT_V0 = new BedrockFoundationModel('mistral.mistral-7b-instruct-v0:2', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Mixtral 8x7B Instruct model, mixture-of-experts architecture.
     * Advanced model combining multiple expert networks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Specialized expert networks
     * - Best for: Complex tasks, diverse language understanding
     */
    static MISTRAL_MIXTRAL_8X7B_INSTRUCT_V0 = new BedrockFoundationModel('mistral.mixtral-8x7b-instruct-v0:1', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Small 2402 model, compact efficient model.
     * Optimized for quick responses and efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Efficient processing
     * - Best for: Quick responses, basic language tasks
     */
    static MISTRAL_SMALL_2402_V1 = new BedrockFoundationModel('mistral.mistral-small-2402-v1:0', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Large 2402 model, high-capacity language model.
     * Advanced model for complex language understanding.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Enhanced language capabilities
     * - Best for: Complex reasoning, detailed analysis
     */
    static MISTRAL_LARGE_2402_V1 = new BedrockFoundationModel('mistral.mistral-large-2402-v1:0', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Large 2407 model, updated large-scale model.
     * Enhanced version with improved capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Advanced language processing
     * - Best for: Sophisticated language tasks, complex analysis
     */
    static MISTRAL_LARGE_2407_V1 = new BedrockFoundationModel('mistral.mistral-large-2407-v1:0', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Pixtral Large 2502 model, specialized large model.
     * Advanced model with cross-region support.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Advanced language tasks, distributed applications
     */
    static MISTRAL_PIXTRAL_LARGE_2502_V1 = new BedrockFoundationModel('mistral.pixtral-large-2502-v1:0', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: true,
    });
    /**
     * Creates a BedrockFoundationModel from a FoundationModelIdentifier.
     * Use this method when you have a model identifier from the CDK.
     * @param modelId - The foundation model identifier
     * @param props - Optional properties for the model
     * @returns A new BedrockFoundationModel instance
     */
    static fromCdkFoundationModelId(modelId, props = {}) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_BedrockFoundationModelProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.fromCdkFoundationModelId);
            }
            throw error;
        }
        return new BedrockFoundationModel(modelId.modelId, props);
    }
    /**
     * Creates a BedrockFoundationModel from a FoundationModel.
     * Use this method when you have a foundation model from the CDK.
     * @param modelId - The foundation model
     * @param props - Optional properties for the model
     * @returns A new BedrockFoundationModel instance
     */
    static fromCdkFoundationModel(modelId, props = {}) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_BedrockFoundationModelProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.fromCdkFoundationModel);
            }
            throw error;
        }
        return new BedrockFoundationModel(modelId.modelId, props);
    }
    /****************************************************************************
     *                            Constructor
     ***************************************************************************/
    /**
     * The unique identifier of the foundation model.
     */
    modelId;
    /**
     * The ARN of the foundation model.
     * Format: arn:${Partition}:bedrock:${Region}::foundation-model/${ResourceId}
     */
    modelArn;
    /**
     * The ARN used for invoking the model.
     * This is the same as modelArn for foundation models.
     */
    invokableArn;
    /**
     * Whether this model supports integration with Bedrock Agents.
     * When true, the model can be used with Bedrock Agents for automated task execution.
     */
    supportsAgents;
    /**
     * Whether this model supports cross-region inference.
     * When true, the model can be used with Cross-Region Inference Profiles.
     */
    supportsCrossRegion;
    /**
     * The dimensionality of the vector embeddings produced by this model.
     * Only applicable for embedding models.
     */
    vectorDimensions;
    /**
     * Whether this model supports integration with Bedrock Knowledge Base.
     * When true, the model can be used for knowledge base operations.
     */
    supportsKnowledgeBase;
    /**
     * The vector types supported by this model for embeddings.
     * Defines whether the model supports floating-point or binary vectors.
     */
    supportedVectorType;
    constructor(value, props = {}) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_BedrockFoundationModelProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, BedrockFoundationModel);
            }
            throw error;
        }
        this.modelId = value;
        this.modelArn = aws_cdk_lib_1.Arn.format({
            partition: aws_cdk_lib_1.Aws.PARTITION,
            service: 'bedrock',
            region: aws_cdk_lib_1.Aws.REGION,
            account: '',
            resource: 'foundation-model',
            resourceName: this.modelId,
            arnFormat: aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME,
        });
        this.invokableArn = this.modelArn;
        this.supportsCrossRegion = props.supportsCrossRegion ?? false;
        this.supportsAgents = props.supportsAgents ?? false;
        this.vectorDimensions = props.vectorDimensions;
        this.supportsKnowledgeBase = props.supportsKnowledgeBase ?? false;
        this.supportedVectorType = props.supportedVectorType;
    }
    toString() {
        return this.modelId;
    }
    /**
     * Returns the ARN of the foundation model in the following format:
     * `arn:${Partition}:bedrock:${Region}::foundation-model/${ResourceId}`
     */
    asArn() {
        return this.modelArn;
    }
    /**
     * Returns the IModel
     */
    asIModel() {
        return this;
    }
    /**
     * Gives the appropriate policies to invoke and use the Foundation Model in the stack region.
     * [disable-awslint:no-grants]
     */
    grantInvoke(grantee) {
        const grant = aws_iam_1.Grant.addToPrincipal({
            grantee: grantee,
            actions: ['bedrock:InvokeModel*', 'bedrock:GetFoundationModel'],
            resourceArns: [this.invokableArn],
        });
        return grant;
    }
    /**
     * Gives the appropriate policies to invoke and use the Foundation Model in all regions.
     * [disable-awslint:no-grants]
     */
    grantInvokeAllRegions(grantee) {
        const invokableArn = aws_cdk_lib_1.Arn.format({
            partition: aws_cdk_lib_1.Aws.PARTITION,
            service: 'bedrock',
            region: '*',
            account: '',
            resource: 'foundation-model',
            resourceName: this.modelId,
            arnFormat: aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME,
        });
        return aws_iam_1.Grant.addToPrincipal({
            grantee: grantee,
            actions: ['bedrock:InvokeModel*', 'bedrock:GetFoundationModel'],
            resourceArns: [invokableArn],
        });
    }
}
exports.BedrockFoundationModel = BedrockFoundationModel;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kZWxzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibW9kZWxzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCw2Q0FBa0Q7QUFHbEQsaURBQTRDO0FBRTVDOzs7OztHQUtHO0FBQ0gsSUFBWSxVQVNYO0FBVEQsV0FBWSxVQUFVO0lBQ3BCOztPQUVHO0lBQ0gsd0NBQTBCLENBQUE7SUFDMUI7O09BRUc7SUFDSCwrQkFBaUIsQ0FBQTtBQUNuQixDQUFDLEVBVFcsVUFBVSwwQkFBVixVQUFVLFFBU3JCO0FBa0ZEOzs7OztHQUtHO0FBQ0gsTUFBYSxzQkFBc0I7O0lBQ2pDOztpRkFFNkU7SUFFN0U7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsdUJBQXVCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDekUsMkJBQTJCLEVBQzNCO1FBQ0UsY0FBYyxFQUFFLElBQUk7S0FDckIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsc0JBQXNCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDeEUsMEJBQTBCLEVBQzFCO1FBQ0UsY0FBYyxFQUFFLElBQUk7S0FDckIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsc0JBQXNCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDeEUsMEJBQTBCLEVBQzFCO1FBQ0UsY0FBYyxFQUFFLElBQUk7S0FDckIsQ0FDRixDQUFDO0lBQ0Y7O2lGQUU2RTtJQUU3RTs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSw0QkFBNEIsR0FBRyxJQUFJLHNCQUFzQixDQUM5RSw4QkFBOEIsRUFDOUI7UUFDRSxjQUFjLEVBQUUsSUFBSTtLQUNyQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSx5QkFBeUIsR0FBRyxJQUFJLHNCQUFzQixDQUMzRSxnQ0FBZ0MsRUFDaEM7UUFDRSxjQUFjLEVBQUUsSUFBSTtLQUNyQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSxvQkFBb0IsR0FBRyxJQUFJLHNCQUFzQixDQUN0RSx3QkFBd0IsRUFDeEI7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO1FBQ3pCLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsbUJBQW1CLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQyx1QkFBdUIsRUFBRTtRQUMvRixjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO1FBQ3pCLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FBQyxDQUFDO0lBRUg7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsa0JBQWtCLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQyxzQkFBc0IsRUFBRTtRQUM3RixjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO1FBQ3pCLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FBQyxDQUFDO0lBRUg7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsc0JBQXNCLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQywwQkFBMEIsRUFBRTtRQUNyRyxjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO1FBQ3pCLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FBQyxDQUFDO0lBRUg7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsbUJBQW1CLEdBQUcsSUFBSSxzQkFBc0IsQ0FDckUsNEJBQTRCLEVBQzVCO1FBQ0UscUJBQXFCLEVBQUUsSUFBSTtRQUMzQixnQkFBZ0IsRUFBRSxJQUFJO1FBQ3RCLG1CQUFtQixFQUFFLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQztLQUNqRCxDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSx3QkFBd0IsR0FBRyxJQUFJLHNCQUFzQixDQUMxRSw4QkFBOEIsRUFDOUI7UUFDRSxxQkFBcUIsRUFBRSxJQUFJO1FBQzNCLGdCQUFnQixFQUFFLElBQUk7UUFDdEIsbUJBQW1CLEVBQUUsQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUM7S0FDcEUsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsdUJBQXVCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDekUsOEJBQThCLEVBQzlCO1FBQ0UscUJBQXFCLEVBQUUsSUFBSTtRQUMzQixnQkFBZ0IsRUFBRSxHQUFHO1FBQ3JCLG1CQUFtQixFQUFFLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDO0tBQ3BFLENBQ0YsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLHVCQUF1QixHQUFHLElBQUksc0JBQXNCLENBQ3pFLDhCQUE4QixFQUM5QjtRQUNFLHFCQUFxQixFQUFFLElBQUk7UUFDM0IsZ0JBQWdCLEVBQUUsR0FBRztRQUNyQixtQkFBbUIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQztLQUNwRSxDQUNGLENBQUM7SUFDRjs7aUZBRTZFO0lBRTdFOzs7Ozs7Ozs7T0FTRztJQUNJLE1BQU0sQ0FBVSwrQkFBK0IsR0FBRyxJQUFJLHNCQUFzQixDQUNqRiwwQ0FBMEMsRUFDMUMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FDOUUsQ0FBQztJQUVGOzs7Ozs7Ozs7OztPQVdHO0lBQ0ksTUFBTSxDQUFVLGdDQUFnQyxHQUFHLElBQUksc0JBQXNCLENBQ2xGLDJDQUEyQyxFQUMzQyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUM5RSxDQUFDO0lBRUY7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0ksTUFBTSxDQUFVLDRCQUE0QixHQUFHLElBQUksc0JBQXNCLENBQzlFLDhCQUE4QixFQUM5QixFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUM5RSxDQUFDO0lBRUY7Ozs7Ozs7OztPQVNHO0lBQ0ksTUFBTSxDQUFVLHlCQUF5QixHQUFHLElBQUksc0JBQXNCLENBQzNFLDJCQUEyQixFQUMzQixFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLENBQ3BELENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsMkJBQTJCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDN0UsNkJBQTZCLEVBQzdCLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7OztPQVVHO0lBQ0ksTUFBTSxDQUFVLDhCQUE4QixHQUFHLElBQUksc0JBQXNCLENBQ2hGLHlDQUF5QyxFQUN6QyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUM5RSxDQUFDO0lBRUY7Ozs7Ozs7Ozs7T0FVRztJQUNJLE1BQU0sQ0FBVSw4QkFBOEIsR0FBRyxJQUFJLHNCQUFzQixDQUNoRix5Q0FBeUMsRUFDekMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FDOUUsQ0FBQztJQUVGOzs7Ozs7Ozs7T0FTRztJQUNJLE1BQU0sQ0FBVSw0QkFBNEIsR0FBRyxJQUFJLHNCQUFzQixDQUM5RSx1Q0FBdUMsRUFDdkMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FDOUUsQ0FBQztJQUVGOzs7Ozs7Ozs7O09BVUc7SUFDSSxNQUFNLENBQVUsOEJBQThCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDaEYseUNBQXlDLEVBQ3pDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSxnQ0FBZ0MsR0FBRyxJQUFJLHNCQUFzQixDQUNsRiwyQ0FBMkMsRUFFM0MsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxLQUFLLEVBQUUsQ0FDL0UsQ0FBQztJQUVGOzs7Ozs7Ozs7T0FTRztJQUNJLE1BQU0sQ0FBVSxnQ0FBZ0MsR0FBRyxJQUFJLHNCQUFzQixDQUNsRiwyQ0FBMkMsRUFDM0MsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FDOUUsQ0FBQztJQUVGOzs7Ozs7Ozs7T0FTRztJQUNJLE1BQU0sQ0FBVSxnQ0FBZ0MsR0FBRyxJQUFJLHNCQUFzQixDQUNsRiwyQ0FBMkMsRUFDM0MsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FDOUUsQ0FBQztJQUVGOzs7Ozs7Ozs7T0FTRztJQUNJLE1BQU0sQ0FBVSwrQkFBK0IsR0FBRyxJQUFJLHNCQUFzQixDQUNqRiwwQ0FBMEMsRUFDMUMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FDOUUsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLDBCQUEwQixHQUFHLElBQUksc0JBQXNCLENBQzVFLHVDQUF1QyxFQUN2QyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQ25ELENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsNEJBQTRCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDOUUseUNBQXlDLEVBQ3pDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FDNUYsQ0FBQztJQUVGOzs7Ozs7Ozs7T0FTRztJQUNJLE1BQU0sQ0FBVSwyQkFBMkIsR0FBRyxJQUFJLHNCQUFzQixDQUM3RSx3Q0FBd0MsRUFDeEMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FDOUUsQ0FBQztJQUVGOzs7Ozs7Ozs7T0FTRztJQUNJLE1BQU0sQ0FBVSxxQkFBcUIsR0FBRyxJQUFJLHNCQUFzQixDQUN2RSx1QkFBdUIsRUFDdkI7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixNQUFNLEVBQUUsSUFBSTtRQUNaLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7OztPQVNHO0lBQ0ksTUFBTSxDQUFVLG1CQUFtQixHQUFHLElBQUksc0JBQXNCLENBQUMscUJBQXFCLEVBQUU7UUFDN0YsY0FBYyxFQUFFLElBQUk7UUFDcEIsTUFBTSxFQUFFLElBQUk7UUFDWixrQkFBa0IsRUFBRSxJQUFJO0tBQ3pCLENBQUMsQ0FBQztJQUVIOzs7Ozs7Ozs7T0FTRztJQUNJLE1BQU0sQ0FBVSw2QkFBNkIsR0FBRyxJQUFJLHNCQUFzQixDQUMvRSw2QkFBNkIsRUFDN0I7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixNQUFNLEVBQUUsSUFBSTtRQUNaLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FDRixDQUFDO0lBRUY7O2lGQUU2RTtJQUU3RTs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsdUJBQXVCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDekUseUJBQXlCLEVBQ3pCO1FBQ0UscUJBQXFCLEVBQUUsSUFBSTtRQUMzQixnQkFBZ0IsRUFBRSxJQUFJO1FBQ3RCLG1CQUFtQixFQUFFLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDO0tBQ3BFLENBQ0YsQ0FBQztJQUVGOzs7Ozs7Ozs7T0FTRztJQUNJLE1BQU0sQ0FBVSw0QkFBNEIsR0FBRyxJQUFJLHNCQUFzQixDQUM5RSw4QkFBOEIsRUFDOUI7UUFDRSxxQkFBcUIsRUFBRSxJQUFJO1FBQzNCLGdCQUFnQixFQUFFLElBQUk7UUFDdEIsbUJBQW1CLEVBQUUsQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUM7S0FDcEUsQ0FDRixDQUFDO0lBQ0Y7O2lGQUU2RTtJQUU3RTs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSxjQUFjLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQyxrQkFBa0IsRUFBRTtRQUNyRixjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO0tBQzFCLENBQUMsQ0FBQztJQUVIOztpRkFFNkU7SUFFN0U7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsNkJBQTZCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDL0UsZ0NBQWdDLEVBQ2hDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsbUJBQW1CLEVBQUUsSUFBSTtLQUMxQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSw4QkFBOEIsR0FBRyxJQUFJLHNCQUFzQixDQUNoRixpQ0FBaUMsRUFDakM7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO0tBQzFCLENBQ0YsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLDhCQUE4QixHQUFHLElBQUksc0JBQXNCLENBQ2hGLGlDQUFpQyxFQUNqQztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLG1CQUFtQixFQUFFLElBQUk7S0FDMUIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsNkJBQTZCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDL0UsZ0NBQWdDLEVBQ2hDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsbUJBQW1CLEVBQUUsSUFBSTtLQUMxQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSw2QkFBNkIsR0FBRyxJQUFJLHNCQUFzQixDQUMvRSxnQ0FBZ0MsRUFDaEM7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO0tBQzFCLENBQ0YsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLDhCQUE4QixHQUFHLElBQUksc0JBQXNCLENBQ2hGLGlDQUFpQyxFQUNqQztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLG1CQUFtQixFQUFFLElBQUk7S0FDMUIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUscUNBQXFDLEdBQUcsSUFBSSxzQkFBc0IsQ0FDdkYsd0NBQXdDLEVBQ3hDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsbUJBQW1CLEVBQUUsSUFBSTtLQUMxQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSxrQ0FBa0MsR0FBRyxJQUFJLHNCQUFzQixDQUNwRixxQ0FBcUMsRUFDckM7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO0tBQzFCLENBQ0YsQ0FBQztJQUNGOztpRkFFNkU7SUFFN0U7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsc0JBQXNCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDeEUsa0NBQWtDLEVBQ2xDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsa0JBQWtCLEVBQUUsS0FBSztRQUN6QixtQkFBbUIsRUFBRSxLQUFLO0tBQzNCLENBQ0YsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLGdDQUFnQyxHQUFHLElBQUksc0JBQXNCLENBQ2xGLG9DQUFvQyxFQUNwQztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLGtCQUFrQixFQUFFLEtBQUs7UUFDekIsbUJBQW1CLEVBQUUsS0FBSztLQUMzQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSxxQkFBcUIsR0FBRyxJQUFJLHNCQUFzQixDQUN2RSxpQ0FBaUMsRUFDakM7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixrQkFBa0IsRUFBRSxLQUFLO1FBQ3pCLG1CQUFtQixFQUFFLEtBQUs7S0FDM0IsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUscUJBQXFCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDdkUsaUNBQWlDLEVBQ2pDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsa0JBQWtCLEVBQUUsS0FBSztRQUN6QixtQkFBbUIsRUFBRSxLQUFLO0tBQzNCLENBQ0YsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLHFCQUFxQixHQUFHLElBQUksc0JBQXNCLENBQ3ZFLGlDQUFpQyxFQUNqQztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLGtCQUFrQixFQUFFLEtBQUs7UUFDekIsbUJBQW1CLEVBQUUsS0FBSztLQUMzQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSw2QkFBNkIsR0FBRyxJQUFJLHNCQUFzQixDQUMvRSxpQ0FBaUMsRUFDakM7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixrQkFBa0IsRUFBRSxLQUFLO1FBQ3pCLG1CQUFtQixFQUFFLElBQUk7S0FDMUIsQ0FDRixDQUFDO0lBRUY7Ozs7OztPQU1HO0lBQ0ksTUFBTSxDQUFDLHdCQUF3QixDQUNwQyxPQUFrQyxFQUNsQyxRQUFxQyxFQUFFOzs7Ozs7Ozs7O1FBRXZDLE9BQU8sSUFBSSxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQzNEO0lBQ0Q7Ozs7OztPQU1HO0lBQ0ksTUFBTSxDQUFDLHNCQUFzQixDQUNsQyxPQUF3QixFQUN4QixRQUFxQyxFQUFFOzs7Ozs7Ozs7O1FBRXZDLE9BQU8sSUFBSSxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQzNEO0lBRUQ7O2lGQUU2RTtJQUM3RTs7T0FFRztJQUNhLE9BQU8sQ0FBUztJQUVoQzs7O09BR0c7SUFDYSxRQUFRLENBQVM7SUFFakM7OztPQUdHO0lBQ2EsWUFBWSxDQUFTO0lBRXJDOzs7T0FHRztJQUNhLGNBQWMsQ0FBVTtJQUV4Qzs7O09BR0c7SUFDYSxtQkFBbUIsQ0FBVTtJQUU3Qzs7O09BR0c7SUFDYSxnQkFBZ0IsQ0FBVTtJQUUxQzs7O09BR0c7SUFDYSxxQkFBcUIsQ0FBVTtJQUUvQzs7O09BR0c7SUFDYSxtQkFBbUIsQ0FBZ0I7SUFDbkQsWUFBWSxLQUFhLEVBQUUsUUFBcUMsRUFBRTs7Ozs7OytDQWo1QnZELHNCQUFzQjs7OztRQWs1Qi9CLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxRQUFRLEdBQUcsaUJBQUcsQ0FBQyxNQUFNLENBQUM7WUFDekIsU0FBUyxFQUFFLGlCQUFHLENBQUMsU0FBUztZQUN4QixPQUFPLEVBQUUsU0FBUztZQUNsQixNQUFNLEVBQUUsaUJBQUcsQ0FBQyxNQUFNO1lBQ2xCLE9BQU8sRUFBRSxFQUFFO1lBQ1gsUUFBUSxFQUFFLGtCQUFrQjtZQUM1QixZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU87WUFDMUIsU0FBUyxFQUFFLHVCQUFTLENBQUMsbUJBQW1CO1NBQ3pDLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUNsQyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsS0FBSyxDQUFDLG1CQUFtQixJQUFJLEtBQUssQ0FBQztRQUM5RCxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQyxjQUFjLElBQUksS0FBSyxDQUFDO1FBQ3BELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7UUFDL0MsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQyxxQkFBcUIsSUFBSSxLQUFLLENBQUM7UUFDbEUsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQztLQUN0RDtJQUVELFFBQVE7UUFDTixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7S0FDckI7SUFFRDs7O09BR0c7SUFDSCxLQUFLO1FBQ0gsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0tBQ3RCO0lBRUQ7O09BRUc7SUFDSCxRQUFRO1FBQ04sT0FBTyxJQUFJLENBQUM7S0FDYjtJQUVEOzs7T0FHRztJQUNJLFdBQVcsQ0FBQyxPQUFtQjtRQUNwQyxNQUFNLEtBQUssR0FBRyxlQUFLLENBQUMsY0FBYyxDQUFDO1lBQ2pDLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLE9BQU8sRUFBRSxDQUFDLHNCQUFzQixFQUFFLDRCQUE0QixDQUFDO1lBQy9ELFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7U0FDbEMsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxLQUFLLENBQUM7S0FDZDtJQUVEOzs7T0FHRztJQUNJLHFCQUFxQixDQUFDLE9BQW1CO1FBQzlDLE1BQU0sWUFBWSxHQUFHLGlCQUFHLENBQUMsTUFBTSxDQUFDO1lBQzlCLFNBQVMsRUFBRSxpQkFBRyxDQUFDLFNBQVM7WUFDeEIsT0FBTyxFQUFFLFNBQVM7WUFDbEIsTUFBTSxFQUFFLEdBQUc7WUFDWCxPQUFPLEVBQUUsRUFBRTtZQUNYLFFBQVEsRUFBRSxrQkFBa0I7WUFDNUIsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPO1lBQzFCLFNBQVMsRUFBRSx1QkFBUyxDQUFDLG1CQUFtQjtTQUN6QyxDQUFDLENBQUM7UUFFSCxPQUFPLGVBQUssQ0FBQyxjQUFjLENBQUM7WUFDMUIsT0FBTyxFQUFFLE9BQU87WUFDaEIsT0FBTyxFQUFFLENBQUMsc0JBQXNCLEVBQUUsNEJBQTRCLENBQUM7WUFDL0QsWUFBWSxFQUFFLENBQUMsWUFBWSxDQUFDO1NBQzdCLENBQUMsQ0FBQztLQUNKOztBQXg5Qkgsd0RBeTlCQyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogIENvcHlyaWdodCBBbWF6b24uY29tLCBJbmMuIG9yIGl0cyBhZmZpbGlhdGVzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqICBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpLiBZb3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlXG4gKiAgd2l0aCB0aGUgTGljZW5zZS4gQSBjb3B5IG9mIHRoZSBMaWNlbnNlIGlzIGxvY2F0ZWQgYXRcbiAqXG4gKiAgICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqICBvciBpbiB0aGUgJ2xpY2Vuc2UnIGZpbGUgYWNjb21wYW55aW5nIHRoaXMgZmlsZS4gVGhpcyBmaWxlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuICdBUyBJUycgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFU1xuICogIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGV4cHJlc3Mgb3IgaW1wbGllZC4gU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zXG4gKiAgYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7IEFybiwgQXJuRm9ybWF0LCBBd3MgfSBmcm9tICdhd3MtY2RrLWxpYic7XG5pbXBvcnQgdHlwZSB7IElNb2RlbCwgRm91bmRhdGlvbk1vZGVsLCBGb3VuZGF0aW9uTW9kZWxJZGVudGlmaWVyIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHR5cGUgeyBJR3JhbnRhYmxlIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWlhbSc7XG5pbXBvcnQgeyBHcmFudCB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuXG4vKipcbiAqIFRoZSBkYXRhIHR5cGUgZm9yIHRoZSB2ZWN0b3JzIHdoZW4gdXNpbmcgYSBtb2RlbCB0byBjb252ZXJ0IHRleHQgaW50byB2ZWN0b3IgZW1iZWRkaW5ncy5cbiAqIFRoZSBtb2RlbCBtdXN0IHN1cHBvcnQgdGhlIHNwZWNpZmllZCBkYXRhIHR5cGUgZm9yIHZlY3RvciBlbWJlZGRpbmdzLiBGbG9hdGluZy1wb2ludCAoZmxvYXQzMilcbiAqIGlzIHRoZSBkZWZhdWx0IGRhdGEgdHlwZSwgYW5kIGlzIHN1cHBvcnRlZCBieSBtb3N0IG1vZGVscyBmb3IgdmVjdG9yIGVtYmVkZGluZ3MuIFNlZSBTdXBwb3J0ZWRcbiAqIGVtYmVkZGluZ3MgbW9kZWxzIGZvciBpbmZvcm1hdGlvbiBvbiB0aGUgYXZhaWxhYmxlIG1vZGVscyBhbmQgdGhlaXIgdmVjdG9yIGRhdGEgdHlwZXMuXG4gKi9cbmV4cG9ydCBlbnVtIFZlY3RvclR5cGUge1xuICAvKipcbiAgICogYEZMT0FUSU5HX1BPSU5UYCBjb252ZXJ0IHRoZSBkYXRhIHRvIGZsb2F0aW5nLXBvaW50IChmbG9hdDMyKSB2ZWN0b3IgZW1iZWRkaW5ncyAobW9yZSBwcmVjaXNlLCBidXQgbW9yZSBjb3N0bHkpLlxuICAgKi9cbiAgRkxPQVRJTkdfUE9JTlQgPSAnRkxPQVQzMicsXG4gIC8qKlxuICAgKiBgQklOQVJZYCBjb252ZXJ0IHRoZSBkYXRhIHRvIGJpbmFyeSB2ZWN0b3IgZW1iZWRkaW5ncyAobGVzcyBwcmVjaXNlLCBidXQgbGVzcyBjb3N0bHkpLlxuICAgKi9cbiAgQklOQVJZID0gJ0JJTkFSWScsXG59XG5cbi8qKlxuICogUmVwcmVzZW50cyBhbiBBbWF6b24gQmVkcm9jayBhYnN0cmFjdGlvbiBvbiB3aGljaCB5b3UgY2FuXG4gKiBydW4gdGhlIGBJbnZva2VgIEFQSS4gVGhpcyBjYW4gYmUgYSBGb3VuZGF0aW9uYWwgTW9kZWwsXG4gKiBhIEN1c3RvbSBNb2RlbCwgb3IgYW4gSW5mZXJlbmNlIFByb2ZpbGUuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSUJlZHJvY2tJbnZva2FibGUge1xuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgQmVkcm9jayBpbnZva2FibGUgYWJzdHJhY3Rpb24uXG4gICAqL1xuICByZWFkb25seSBpbnZva2FibGVBcm46IHN0cmluZztcblxuICAvKipcbiAgICogR2l2ZXMgdGhlIGFwcHJvcHJpYXRlIHBvbGljaWVzIHRvIGludm9rZSBhbmQgdXNlIHRoZSBpbnZva2FibGUgYWJzdHJhY3Rpb24uXG4gICAqL1xuICBncmFudEludm9rZShncmFudGVlOiBJR3JhbnRhYmxlKTogR3JhbnQ7XG59XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgY29uZmlndXJpbmcgYSBCZWRyb2NrIEZvdW5kYXRpb24gTW9kZWwuXG4gKiBUaGVzZSBwcm9wZXJ0aWVzIGRlZmluZSB0aGUgbW9kZWwncyBjYXBhYmlsaXRpZXMgYW5kIHN1cHBvcnRlZCBmZWF0dXJlcy5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBCZWRyb2NrRm91bmRhdGlvbk1vZGVsUHJvcHMge1xuICAvKipcbiAgICogQmVkcm9jayBBZ2VudHMgY2FuIHVzZSB0aGlzIG1vZGVsLlxuICAgKiBXaGVuIHRydWUsIHRoZSBtb2RlbCBjYW4gYmUgdXNlZCB3aXRoIEJlZHJvY2sgQWdlbnRzIGZvciBhdXRvbWF0ZWQgdGFzayBleGVjdXRpb24uXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gZmFsc2VcbiAgICovXG4gIHJlYWRvbmx5IHN1cHBvcnRzQWdlbnRzPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogQ3VycmVudGx5LCBzb21lIG9mIHRoZSBvZmZlcmVkIG1vZGVscyBhcmUgb3B0aW1pemVkIHdpdGggcHJvbXB0cy9wYXJzZXJzIGZpbmUtdHVuZWQgZm9yIGludGVncmF0aW5nIHdpdGggdGhlIGFnZW50cyBhcmNoaXRlY3R1cmUuXG4gICAqIFdoZW4gdHJ1ZSwgdGhlIG1vZGVsIGhhcyBiZWVuIHNwZWNpZmljYWxseSBvcHRpbWl6ZWQgZm9yIGFnZW50IGludGVyYWN0aW9ucy5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBmYWxzZVxuICAgKi9cbiAgcmVhZG9ubHkgb3B0aW1pemVkRm9yQWdlbnRzPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9tb2RlbC1saWZlY3ljbGUuaHRtbFxuICAgKiBBIHZlcnNpb24gaXMgbWFya2VkIExlZ2FjeSB3aGVuIHRoZXJlIGlzIGEgbW9yZSByZWNlbnQgdmVyc2lvbiB3aGljaCBwcm92aWRlcyBzdXBlcmlvciBwZXJmb3JtYW5jZS5cbiAgICogQW1hem9uIEJlZHJvY2sgc2V0cyBhbiBFT0wgZGF0ZSBmb3IgTGVnYWN5IHZlcnNpb25zLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIGZhbHNlXG4gICAqL1xuICByZWFkb25seSBsZWdhY3k/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBCZWRyb2NrIEtub3dsZWRnZSBCYXNlIGNhbiB1c2UgdGhpcyBtb2RlbC5cbiAgICogV2hlbiB0cnVlLCB0aGUgbW9kZWwgY2FuIGJlIHVzZWQgZm9yIGtub3dsZWRnZSBiYXNlIG9wZXJhdGlvbnMuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gZmFsc2VcbiAgICovXG4gIHJlYWRvbmx5IHN1cHBvcnRzS25vd2xlZGdlQmFzZT86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIENhbiBiZSB1c2VkIHdpdGggYSBDcm9zcy1SZWdpb24gSW5mZXJlbmNlIFByb2ZpbGUuXG4gICAqIFdoZW4gdHJ1ZSwgdGhlIG1vZGVsIHN1cHBvcnRzIGluZmVyZW5jZSBhY3Jvc3MgZGlmZmVyZW50IEFXUyByZWdpb25zLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIGZhbHNlXG4gICAqL1xuICByZWFkb25seSBzdXBwb3J0c0Nyb3NzUmVnaW9uPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogRW1iZWRkaW5nIG1vZGVscyBoYXZlIGRpZmZlcmVudCB2ZWN0b3IgZGltZW5zaW9ucy5cbiAgICogT25seSBhcHBsaWNhYmxlIGZvciBlbWJlZGRpbmcgbW9kZWxzLiBEZWZpbmVzIHRoZSBkaW1lbnNpb25hbGl0eSBvZiB0aGUgdmVjdG9yIGVtYmVkZGluZ3MuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gdW5kZWZpbmVkXG4gICAqL1xuICByZWFkb25seSB2ZWN0b3JEaW1lbnNpb25zPzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBFbWJlZGRpbmdzIG1vZGVscyBoYXZlIGRpZmZlcmVudCBzdXBwb3J0ZWQgdmVjdG9yIHR5cGVzLlxuICAgKiBEZWZpbmVzIHdoZXRoZXIgdGhlIG1vZGVsIHN1cHBvcnRzIGZsb2F0aW5nLXBvaW50IG9yIGJpbmFyeSB2ZWN0b3JzLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIHVuZGVmaW5lZFxuICAgKi9cbiAgcmVhZG9ubHkgc3VwcG9ydGVkVmVjdG9yVHlwZT86IFZlY3RvclR5cGVbXTtcbn1cblxuLyoqXG4gKiBCZWRyb2NrIG1vZGVscy5cbiAqXG4gKiBJZiB5b3UgbmVlZCB0byB1c2UgYSBtb2RlbCBuYW1lIHRoYXQgZG9lc24ndCBleGlzdCBhcyBhIHN0YXRpYyBtZW1iZXIsIHlvdVxuICogY2FuIGluc3RhbnRpYXRlIGEgYEJlZHJvY2tGb3VuZGF0aW9uTW9kZWxgIG9iamVjdCwgZS5nOiBgbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoJ215LW1vZGVsJylgLlxuICovXG5leHBvcnQgY2xhc3MgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCBpbXBsZW1lbnRzIElCZWRyb2NrSW52b2thYmxlIHtcbiAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgQUkyMVxuICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG4gIC8qKlxuICAgKiBBSTIxJ3MgSmFtYmEgMS41IExhcmdlIG1vZGVsIG9wdGltaXplZCBmb3IgdGV4dCBnZW5lcmF0aW9uIHRhc2tzLlxuICAgKiBTdWl0YWJsZSBmb3IgY29tcGxleCBsYW5ndWFnZSB1bmRlcnN0YW5kaW5nIGFuZCBnZW5lcmF0aW9uIHRhc2tzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIE9wdGltaXplZCBmb3IgbmF0dXJhbCBsYW5ndWFnZSBwcm9jZXNzaW5nXG4gICAqIC0gQmVzdCBmb3I6IENvbnRlbnQgZ2VuZXJhdGlvbiwgc3VtbWFyaXphdGlvbiwgYW5kIGNvbXBsZXggdGV4dCBhbmFseXNpc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBSTIxX0pBTUJBXzFfNV9MQVJHRV9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhaTIxLmphbWJhLTEtNS1sYXJnZS12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBSTIxJ3MgSmFtYmEgMS41IE1pbmkgbW9kZWwsIGEgbGlnaHRlciB2ZXJzaW9uIG9wdGltaXplZCBmb3IgZmFzdGVyIHByb2Nlc3NpbmcuXG4gICAqIEJhbGFuY2VzIHBlcmZvcm1hbmNlIHdpdGggZWZmaWNpZW5jeSBmb3IgZ2VuZXJhbCB0ZXh0IHRhc2tzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIEZhc3RlciByZXNwb25zZSB0aW1lcyBjb21wYXJlZCB0byBsYXJnZXIgbW9kZWxzXG4gICAqIC0gQmVzdCBmb3I6IFF1aWNrIHRleHQgcHJvY2Vzc2luZywgYmFzaWMgY29udGVudCBnZW5lcmF0aW9uXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFJMjFfSkFNQkFfMV81X01JTklfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYWkyMS5qYW1iYS0xLTUtbWluaS12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBSTIxJ3MgSmFtYmEgSW5zdHJ1Y3QgbW9kZWwsIHNwZWNpZmljYWxseSBkZXNpZ25lZCBmb3IgaW5zdHJ1Y3Rpb24tZm9sbG93aW5nIHRhc2tzLlxuICAgKiBPcHRpbWl6ZWQgZm9yIHVuZGVyc3RhbmRpbmcgYW5kIGV4ZWN1dGluZyBzcGVjaWZpYyBpbnN0cnVjdGlvbnMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gRW5oYW5jZWQgaW5zdHJ1Y3Rpb24gdW5kZXJzdGFuZGluZ1xuICAgKiAtIEJlc3QgZm9yOiBUYXNrLXNwZWNpZmljIGluc3RydWN0aW9ucywgY29tbWFuZCBwcm9jZXNzaW5nXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFJMjFfSkFNQkFfSU5TVFJVQ1RfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYWkyMS5qYW1iYS1pbnN0cnVjdC12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICB9LFxuICApO1xuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBTUFaT05cbiAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cblxuICAvKipcbiAgICogQW1hem9uJ3MgVGl0YW4gVGV4dCBFeHByZXNzIG1vZGVsLCBvcHRpbWl6ZWQgZm9yIGZhc3QgdGV4dCBnZW5lcmF0aW9uLlxuICAgKiBQcm92aWRlcyBxdWljayByZXNwb25zZXMgd2hpbGUgbWFpbnRhaW5pbmcgZ29vZCBxdWFsaXR5IG91dHB1dC5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBGYXN0IHJlc3BvbnNlIHRpbWVzXG4gICAqIC0gQmVzdCBmb3I6IFJlYWwtdGltZSBhcHBsaWNhdGlvbnMsIGNoYXRib3RzLCBxdWljayBjb250ZW50IGdlbmVyYXRpb25cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU1BWk9OX1RJVEFOX1RFWFRfRVhQUkVTU19WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbWF6b24udGl0YW4tdGV4dC1leHByZXNzLXYxJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbWF6b24ncyBUaXRhbiBUZXh0IFByZW1pZXIgbW9kZWwsIGRlc2lnbmVkIGZvciBoaWdoLXF1YWxpdHkgdGV4dCBnZW5lcmF0aW9uLlxuICAgKiBPZmZlcnMgZW5oYW5jZWQgY2FwYWJpbGl0aWVzIGZvciBjb21wbGV4IGxhbmd1YWdlIHRhc2tzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIEFkdmFuY2VkIGxhbmd1YWdlIHVuZGVyc3RhbmRpbmdcbiAgICogLSBCZXN0IGZvcjogQ29tcGxleCBjb250ZW50IGdlbmVyYXRpb24sIGRldGFpbGVkIGFuYWx5c2lzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFNQVpPTl9USVRBTl9QUkVNSUVSX1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW1hem9uLnRpdGFuLXRleHQtcHJlbWllci12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbWF6b24ncyBOb3ZhIE1pY3JvIG1vZGVsLCBhIGxpZ2h0d2VpZ2h0IG1vZGVsIG9wdGltaXplZCBmb3IgZWZmaWNpZW5jeS5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IFF1aWNrIHByb2Nlc3NpbmcgdGFza3MsIGJhc2ljIGxhbmd1YWdlIHVuZGVyc3RhbmRpbmdcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU1BWk9OX05PVkFfTUlDUk9fVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW1hem9uLm5vdmEtbWljcm8tdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgICAgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFtYXpvbidzIE5vdmEgTGl0ZSBtb2RlbCwgYmFsYW5jaW5nIHBlcmZvcm1hbmNlIHdpdGggZWZmaWNpZW5jeS5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IEdlbmVyYWwtcHVycG9zZSBsYW5ndWFnZSB0YXNrcywgbW9kZXJhdGUgY29tcGxleGl0eVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTUFaT05fTk9WQV9MSVRFX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoJ2FtYXpvbi5ub3ZhLWxpdGUtdjE6MCcsIHtcbiAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSxcbiAgfSk7XG5cbiAgLyoqXG4gICAqIEFtYXpvbidzIE5vdmEgUHJvIG1vZGVsLCBvZmZlcmluZyBhZHZhbmNlZCBjYXBhYmlsaXRpZXMgZm9yIGNvbXBsZXggdGFza3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBPcHRpbWl6ZWQgZm9yIGFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBDb21wbGV4IGxhbmd1YWdlIHRhc2tzLCBwcm9mZXNzaW9uYWwgYXBwbGljYXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFNQVpPTl9OT1ZBX1BST19WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKCdhbWF6b24ubm92YS1wcm8tdjE6MCcsIHtcbiAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSxcbiAgfSk7XG5cbiAgLyoqXG4gICAqIEFtYXpvbidzIE5vdmEgUHJlbWllciBtb2RlbCwgdGhlIG1vc3QgYWR2YW5jZWQgaW4gdGhlIE5vdmEgc2VyaWVzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gT3B0aW1pemVkIGZvciBhZ2VudHNcbiAgICogLSBCZXN0IGZvcjogSGlnaC1lbmQgYXBwbGljYXRpb25zLCBjb21wbGV4IGFuYWx5c2lzLCBwcmVtaXVtIHBlcmZvcm1hbmNlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFNQVpPTl9OT1ZBX1BSRU1JRVJfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCgnYW1hem9uLm5vdmEtcHJlbWllci12MTowJywge1xuICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsXG4gICAgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlLFxuICB9KTtcblxuICAvKipcbiAgICogQW1hem9uJ3MgVGl0YW4gRW1iZWQgVGV4dCBWMSBtb2RlbCBmb3IgdGV4dCBlbWJlZGRpbmdzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBLbm93bGVkZ2UgQmFzZSBpbnRlZ3JhdGlvblxuICAgKiAtIDE1MzYtZGltZW5zaW9uYWwgdmVjdG9yc1xuICAgKiAtIEZsb2F0aW5nLXBvaW50IHZlY3RvciB0eXBlXG4gICAqIC0gQmVzdCBmb3I6IFRleHQgZW1iZWRkaW5ncywgc2VtYW50aWMgc2VhcmNoLCBkb2N1bWVudCBzaW1pbGFyaXR5XG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFRJVEFOX0VNQkVEX1RFWFRfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW1hem9uLnRpdGFuLWVtYmVkLXRleHQtdjEnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzS25vd2xlZGdlQmFzZTogdHJ1ZSxcbiAgICAgIHZlY3RvckRpbWVuc2lvbnM6IDE1MzYsXG4gICAgICBzdXBwb3J0ZWRWZWN0b3JUeXBlOiBbVmVjdG9yVHlwZS5GTE9BVElOR19QT0lOVF0sXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW1hem9uJ3MgVGl0YW4gRW1iZWQgVGV4dCBWMiBtb2RlbCB3aXRoIDEwMjQtZGltZW5zaW9uYWwgdmVjdG9ycy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgS25vd2xlZGdlIEJhc2UgaW50ZWdyYXRpb25cbiAgICogLSAxMDI0LWRpbWVuc2lvbmFsIHZlY3RvcnNcbiAgICogLSBTdXBwb3J0cyBib3RoIGZsb2F0aW5nLXBvaW50IGFuZCBiaW5hcnkgdmVjdG9yc1xuICAgKiAtIEJlc3QgZm9yOiBIaWdoLWRpbWVuc2lvbmFsIGVtYmVkZGluZ3MsIGFkdmFuY2VkIHNlbWFudGljIHNlYXJjaFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBUSVRBTl9FTUJFRF9URVhUX1YyXzEwMjQgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW1hem9uLnRpdGFuLWVtYmVkLXRleHQtdjI6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNLbm93bGVkZ2VCYXNlOiB0cnVlLFxuICAgICAgdmVjdG9yRGltZW5zaW9uczogMTAyNCxcbiAgICAgIHN1cHBvcnRlZFZlY3RvclR5cGU6IFtWZWN0b3JUeXBlLkZMT0FUSU5HX1BPSU5ULCBWZWN0b3JUeXBlLkJJTkFSWV0sXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW1hem9uJ3MgVGl0YW4gRW1iZWQgVGV4dCBWMiBtb2RlbCB3aXRoIDUxMi1kaW1lbnNpb25hbCB2ZWN0b3JzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBLbm93bGVkZ2UgQmFzZSBpbnRlZ3JhdGlvblxuICAgKiAtIDUxMi1kaW1lbnNpb25hbCB2ZWN0b3JzXG4gICAqIC0gU3VwcG9ydHMgYm90aCBmbG9hdGluZy1wb2ludCBhbmQgYmluYXJ5IHZlY3RvcnNcbiAgICogLSBCZXN0IGZvcjogQmFsYW5jZWQgcGVyZm9ybWFuY2UgYW5kIGRpbWVuc2lvbmFsaXR5XG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFRJVEFOX0VNQkVEX1RFWFRfVjJfNTEyID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FtYXpvbi50aXRhbi1lbWJlZC10ZXh0LXYyOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzS25vd2xlZGdlQmFzZTogdHJ1ZSxcbiAgICAgIHZlY3RvckRpbWVuc2lvbnM6IDUxMixcbiAgICAgIHN1cHBvcnRlZFZlY3RvclR5cGU6IFtWZWN0b3JUeXBlLkZMT0FUSU5HX1BPSU5ULCBWZWN0b3JUeXBlLkJJTkFSWV0sXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW1hem9uJ3MgVGl0YW4gRW1iZWQgVGV4dCBWMiBtb2RlbCB3aXRoIDI1Ni1kaW1lbnNpb25hbCB2ZWN0b3JzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBLbm93bGVkZ2UgQmFzZSBpbnRlZ3JhdGlvblxuICAgKiAtIDI1Ni1kaW1lbnNpb25hbCB2ZWN0b3JzXG4gICAqIC0gU3VwcG9ydHMgYm90aCBmbG9hdGluZy1wb2ludCBhbmQgYmluYXJ5IHZlY3RvcnNcbiAgICogLSBCZXN0IGZvcjogRWZmaWNpZW50IGVtYmVkZGluZ3Mgd2l0aCBsb3dlciBkaW1lbnNpb25hbGl0eVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBUSVRBTl9FTUJFRF9URVhUX1YyXzI1NiA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbWF6b24udGl0YW4tZW1iZWQtdGV4dC12MjowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0tub3dsZWRnZUJhc2U6IHRydWUsXG4gICAgICB2ZWN0b3JEaW1lbnNpb25zOiAyNTYsXG4gICAgICBzdXBwb3J0ZWRWZWN0b3JUeXBlOiBbVmVjdG9yVHlwZS5GTE9BVElOR19QT0lOVCwgVmVjdG9yVHlwZS5CSU5BUlldLFxuICAgIH0sXG4gICk7XG4gIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFOVEhST1BJQ1xuICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgSGFpa3UgNC41IG1vZGVsLCBtb3N0IGNvc3QtZWZmaWNpZW50IGFuZCBmYXN0ZXN0LlxuICAgKiBEZWxpdmVycyBuZWFyLWZyb250aWVyIHBlcmZvcm1hbmNlIHdpdGggc3Vic3RhbnRpYWxseSBsb3dlciBjb3N0IGFuZCBmYXN0ZXIgc3BlZWRzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyB2aXNpb24gKEltYWdlIGlucHV0IG1vZGFsaXR5KVxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHNcbiAgICogLSBCZXN0IGZvcjogTGFyZ2Utc2NhbGUgZGVwbG95bWVudHMsIGJ1ZGdldC1jb25zY2lvdXMgYXBwbGljYXRpb25zLCByZWFsLXRpbWUgY3VzdG9tZXIgc2VydmljZSwgbGF0ZW5jeS1zZW5zaXRpdmUgdXNlIGNhc2VzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfSEFJS1VfNF81X1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1oYWlrdS00LTUtMjAyNTEwMDEtdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBTb25uZXQgNC41IG1vZGVsLCBtb3N0IGludGVsbGlnZW50IGluIHRoZSBDbGF1ZGUgNCBzZXJpZXMuXG4gICAqIERlbW9uc3RyYXRlcyBhZHZhbmNlbWVudHMgaW4gYWdlbnQgY2FwYWJpbGl0aWVzIHdpdGggZW5oYW5jZWQgcGVyZm9ybWFuY2UgaW4gdG9vbCBoYW5kbGluZyxcbiAgICogbWVtb3J5IG1hbmFnZW1lbnQsIGFuZCBjb250ZXh0IHByb2Nlc3NpbmcuIEV4Y2VscyBhdCBhdXRvbm9tb3VzIGxvbmctaG9yaXpvbiBjb2RpbmcgdGFza3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIHZpc2lvbiAoSW1hZ2UgaW5wdXQgbW9kYWxpdHkpXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50c1xuICAgKiAtIEVuaGFuY2VkIHRvb2wgaGFuZGxpbmcgYW5kIG1lbW9yeSBtYW5hZ2VtZW50IGZvciBsb25nLXJ1bm5pbmcgdGFza3NcbiAgICogLSBCZXN0IGZvcjogQ29tcGxleCBhZ2VudHMsIGNvZGluZywgYXV0b25vbW91cyBsb25nLWhvcml6b24gdGFza3MsIHJlc2VhcmNoIGFuZCBhbmFseXNpcywgY3liZXJzZWN1cml0eSBhbmQgZmluYW5jZSBhcHBsaWNhdGlvbnNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV9TT05ORVRfNF81X1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1zb25uZXQtNC01LTIwMjUwOTI5LXYxOjAnLFxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgT3B1cyA0LjYgbW9kZWwsIHRoZSBtb3N0IGludGVsbGlnZW50IG1vZGVsIGFuZCB0aGUgd29ybGQncyBiZXN0IG1vZGVsXG4gICAqIGZvciBjb2RpbmcsIGVudGVycHJpc2UgYWdlbnRzLCBhbmQgcHJvZmVzc2lvbmFsIHdvcmsuXG4gICAqIFN1cHBvcnRzIGJvdGggMjAwSyBhbmQgMU0gY29udGV4dCB0b2tlbnMgKHdpdGggdGhlIGxhdHRlciBpbiBwcmV2aWV3KS5cbiAgICogRXhjZWxzIGluIGFnZW50aWMgd29ya2Zsb3dzLCBjb21wbGV4IGNvZGluZyBwcm9qZWN0cywgYW5kIGVudGVycHJpc2UgYXBwbGljYXRpb25zXG4gICAqIHJlcXVpcmluZyBzb3BoaXN0aWNhdGVkIHJlYXNvbmluZy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgdmlzaW9uIChJbWFnZSBpbnB1dCBtb2RhbGl0eSlcbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IEZpbmFuY2lhbCBhbmFseXNpcywgY3liZXJzZWN1cml0eSwgY29tcHV0ZXIgdXNlIHdvcmtmbG93cywgbG9uZy1ob3Jpem9uIGRldmVsb3BtZW50LCBtdWx0aS10b29sIG9yY2hlc3RyYXRpb25cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV9PUFVTXzRfNl9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbnRocm9waWMuY2xhdWRlLW9wdXMtNC02LXYxJyxcbiAgICB7IHN1cHBvcnRzQWdlbnRzOiB0cnVlLCBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLCBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIE9wdXMgNC43IG1vZGVsLCBBbnRocm9waWMncyBtb3N0IGNhcGFibGUgZ2VuZXJhbGx5IGF2YWlsYWJsZSBtb2RlbCxcbiAgICogYWR2YW5jaW5nIHBlcmZvcm1hbmNlIGFjcm9zcyBjb2RpbmcsIGVudGVycHJpc2Ugd29ya2Zsb3dzLCBhbmQgbG9uZy1ydW5uaW5nIGFnZW50aWMgdGFza3MuXG4gICAqIEZlYXR1cmVzIGEgMU0gdG9rZW4gY29udGV4dCB3aW5kb3csIDEyOEsgbWF4IG91dHB1dCB0b2tlbnMsIGFuZCBzdXBwb3J0cyByZWFzb25pbmcuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIHZpc2lvbiAoSW1hZ2UgaW5wdXQgbW9kYWxpdHkpXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50c1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX09QVVNfNF83ID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtb3B1cy00LTcnLFxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIFNvbm5ldCA0LjYgbW9kZWwuXG4gICAqIEltcHJvdmVkIHBlcmZvcm1hbmNlIGZvciBjb2RpbmcsIGFnZW50aWMgd29ya2Zsb3dzLCBhbmQgYnJvd3Nlci1iYXNlZCBhdXRvbWF0aW9uLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyB2aXNpb24gKEltYWdlIGlucHV0IG1vZGFsaXR5KVxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHNcbiAgICogLSBCZXN0IGZvcjogQ29kaW5nLCBhZ2VudGljIHdvcmtmbG93cywgYnJvd3Nlci1iYXNlZCBhdXRvbWF0aW9uLCBlbnRlcnByaXNlIGFwcGxpY2F0aW9uc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX1NPTk5FVF80XzYgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1zb25uZXQtNC02JyxcbiAgICB7IHN1cHBvcnRzQWdlbnRzOiB0cnVlLCBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLCBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIE9wdXMgNC41IG1vZGVsLCB0aGUgZmxhZ3NoaXAgbW9kZWwgcmVsZWFzZWQgTm92ZW1iZXIgMjAyNS5cbiAgICogRXhjZWxzIGF0IHJlYWwtd29ybGQgcHJvZ3JhbW1pbmcgdGFza3MsIHNjb3JpbmcgaGlnaGVzdCBvbiBTV0UtYmVuY2ggVmVyaWZpZWQgYmVuY2htYXJrcy5cbiAgICogRGVtb25zdHJhdGVzIHN1cGVyaW9yIHBlcmZvcm1hbmNlIGluIGxvbmctaG9yaXpvbiwgZ29hbC1kaXJlY3RlZCBhZ2VudGljIHdvcmsgd2l0aCBmZXdlciBkZWFkLWVuZHMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIHZpc2lvbiAoSW1hZ2UgaW5wdXQgbW9kYWxpdHkpXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBTb2Z0d2FyZSBlbmdpbmVlcmluZywgY29kZSBtaWdyYXRpb24sIGFnZW50aWMgd29ya2Zsb3dzLCBmaW5hbmNpYWwgbW9kZWxpbmcsIGRlZXAgcmVzZWFyY2hcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV9PUFVTXzRfNV9WMV8wID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtb3B1cy00LTUtMjAyNTExMDEtdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBPcHVzIDQuMSBtb2RlbCwgbW9zdCBhZHZhbmNlZCBmb3IgY29kaW5nIGFuZCBhZ2VudGljIGFwcGxpY2F0aW9ucy5cbiAgICogRXhjZWxzIGF0IGluZGVwZW5kZW50bHkgcGxhbm5pbmcgYW5kIGV4ZWN1dGluZyBjb21wbGV4IGRldmVsb3BtZW50IHRhc2tzIGVuZC10by1lbmQuXG4gICAqIERyb3AtaW4gcmVwbGFjZW1lbnQgZm9yIE9wdXMgNCB3aXRoIHN1cGVyaW9yIHBlcmZvcm1hbmNlIGFuZCBwcmVjaXNpb24uXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIHZpc2lvbiAoSW1hZ2UgaW5wdXQgbW9kYWxpdHkpXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBDb21wbGV4IGVuZC10by1lbmQgZGV2ZWxvcG1lbnQsIGFnZW50aWMgYXBwbGljYXRpb25zLCByZXNlYXJjaCwgYWR2YW5jZWQgcmVhc29uaW5nXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfT1BVU180XzFfVjFfMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbnRocm9waWMuY2xhdWRlLW9wdXMtNC0xLTIwMjUwODA1LXYxOjAnLFxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgT3B1cyA0IG1vZGVsLCBuZXh0LWdlbmVyYXRpb24gZnJvbnRpZXIgbW9kZWwuXG4gICAqIEhpZ2gtcGVyZm9ybWFuY2UgbW9kZWwgZm9yIGFkdmFuY2VkIHJlYXNvbmluZyBhbmQgY29tcGxleCBtdWx0aS1zdGVwIHRhc2tzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyB2aXNpb24gKEltYWdlIGlucHV0IG1vZGFsaXR5KVxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHNcbiAgICogLSBCZXN0IGZvcjogQWR2YW5jZWQgcmVhc29uaW5nLCBjb21wbGV4IHdvcmtmbG93cywgZW50ZXJwcmlzZSBhcHBsaWNhdGlvbnNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV9PUFVTXzRfVjFfMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbnRocm9waWMuY2xhdWRlLW9wdXMtNC0yMDI1MDUxNC12MTowJyxcbiAgICB7IHN1cHBvcnRzQWdlbnRzOiB0cnVlLCBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLCBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIFNvbm5ldCA0IG1vZGVsLCBuZXh0LWdlbmVyYXRpb24gZnJvbnRpZXIgbW9kZWwuXG4gICAqIEFkdmFuY2VkIG1vZGVsIHdpdGggaW1wcm92ZWQgcGVyZm9ybWFuY2UgZm9yIHByb2R1Y3Rpb24gZW52aXJvbm1lbnRzLlxuICAgKiBCYWxhbmNlcyBxdWFsaXR5LCBjb3N0LWVmZmVjdGl2ZW5lc3MsIGFuZCByZXNwb25zaXZlbmVzcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgdmlzaW9uIChJbWFnZSBpbnB1dCBtb2RhbGl0eSlcbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IFByb2R1Y3Rpb24gYXBwbGljYXRpb25zLCBjb21wbGV4IGxhbmd1YWdlIHRhc2tzLCBiYWxhbmNlZCBwZXJmb3JtYW5jZSBhbmQgY29zdFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX1NPTk5FVF80X1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1zb25uZXQtNC0yMDI1MDUxNC12MTowJyxcbiAgICB7IHN1cHBvcnRzQWdlbnRzOiB0cnVlLCBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLCBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIDMuNyBTb25uZXQgbW9kZWwsIGxhdGVzdCBpbiB0aGUgQ2xhdWRlIDMgc2VyaWVzLlxuICAgKiBBZHZhbmNlZCBsYW5ndWFnZSBtb2RlbCB3aXRoIGVuaGFuY2VkIGNhcGFiaWxpdGllcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIEJlc3QgZm9yOiBDb21wbGV4IHJlYXNvbmluZywgYW5hbHlzaXMsIGFuZCBjb250ZW50IGdlbmVyYXRpb25cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV8zXzdfU09OTkVUX1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS0zLTctc29ubmV0LTIwMjUwMjE5LXYxOjAnLFxuXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiBmYWxzZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgMy41IFNvbm5ldCBWMiBtb2RlbCwgb3B0aW1pemVkIGZvciBhZ2VudCBpbnRlcmFjdGlvbnMuXG4gICAqIEVuaGFuY2VkIHZlcnNpb24gd2l0aCBpbXByb3ZlZCBwZXJmb3JtYW5jZSBhbmQgY2FwYWJpbGl0aWVzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gT3B0aW1pemVkIGZvciBhZ2VudHNcbiAgICogLSBCZXN0IGZvcjogQWdlbnQtYmFzZWQgYXBwbGljYXRpb25zLCBjb21wbGV4IGRpYWxvZ3VlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfM181X1NPTk5FVF9WMl8wID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtMy01LXNvbm5ldC0yMDI0MTAyMi12MjowJyxcbiAgICB7IHN1cHBvcnRzQWdlbnRzOiB0cnVlLCBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLCBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIDMuNSBTb25uZXQgVjEgbW9kZWwsIGJhbGFuY2VkIHBlcmZvcm1hbmNlIG1vZGVsLlxuICAgKiBPZmZlcnMgZ29vZCBiYWxhbmNlIGJldHdlZW4gcGVyZm9ybWFuY2UgYW5kIGVmZmljaWVuY3kuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBPcHRpbWl6ZWQgZm9yIGFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBHZW5lcmFsIGxhbmd1YWdlIHRhc2tzLCBiYWxhbmNlZCBwZXJmb3JtYW5jZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFXzNfNV9TT05ORVRfVjFfMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbnRocm9waWMuY2xhdWRlLTMtNS1zb25uZXQtMjAyNDA2MjAtdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSAzLjUgSGFpa3UgbW9kZWwsIG9wdGltaXplZCBmb3IgcXVpY2sgcmVzcG9uc2VzLlxuICAgKiBMaWdodHdlaWdodCBtb2RlbCBmb2N1c2VkIG9uIHNwZWVkIGFuZCBlZmZpY2llbmN5LlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gT3B0aW1pemVkIGZvciBhZ2VudHNcbiAgICogLSBCZXN0IGZvcjogRmFzdCByZXNwb25zZXMsIGxpZ2h0d2VpZ2h0IHByb2Nlc3NpbmdcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV8zXzVfSEFJS1VfVjFfMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbnRocm9waWMuY2xhdWRlLTMtNS1oYWlrdS0yMDI0MTAyMi12MTowJyxcbiAgICB7IHN1cHBvcnRzQWdlbnRzOiB0cnVlLCBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLCBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIE9wdXMgbW9kZWwsIGRlc2lnbmVkIGZvciBhZHZhbmNlZCB0YXNrcy5cbiAgICogSGlnaC1wZXJmb3JtYW5jZSBtb2RlbCB3aXRoIGV4dGVuc2l2ZSBjYXBhYmlsaXRpZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gT3B0aW1pemVkIGZvciBhZ2VudHNcbiAgICogLSBCZXN0IGZvcjogQ29tcGxleCByZWFzb25pbmcsIHJlc2VhcmNoLCBhbmQgYW5hbHlzaXNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV9PUFVTX1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS0zLW9wdXMtMjAyNDAyMjktdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBTb25uZXQgbW9kZWwsIGxlZ2FjeSB2ZXJzaW9uLlxuICAgKiBCYWxhbmNlZCBtb2RlbCBmb3IgZ2VuZXJhbC1wdXJwb3NlIHRhc2tzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gTGVnYWN5IG1vZGVsIHdpdGggRU9MIGRhdGVcbiAgICogLSBCZXN0IGZvcjogR2VuZXJhbCBsYW5ndWFnZSB0YXNrcywgc3RhbmRhcmQgYXBwbGljYXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfU09OTkVUX1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS0zLXNvbm5ldC0yMDI0MDIyOS12MTowJyxcbiAgICB7IHN1cHBvcnRzQWdlbnRzOiB0cnVlLCBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLCBsZWdhY3k6IHRydWUsIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgSGFpa3UgbW9kZWwsIG9wdGltaXplZCBmb3IgZWZmaWNpZW5jeS5cbiAgICogRmFzdCBhbmQgZWZmaWNpZW50IG1vZGVsIGZvciBsaWdodHdlaWdodCB0YXNrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IFF1aWNrIHJlc3BvbnNlcywgc2ltcGxlIHRhc2tzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfSEFJS1VfVjFfMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbnRocm9waWMuY2xhdWRlLTMtaGFpa3UtMjAyNDAzMDctdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBWMi4xIG1vZGVsLCBsZWdhY3kgdmVyc2lvbi5cbiAgICogSW1wcm92ZWQgdmVyc2lvbiBvZiBDbGF1ZGUgVjIgd2l0aCBlbmhhbmNlZCBjYXBhYmlsaXRpZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gTGVnYWN5IG1vZGVsIHdpdGggRU9MIGRhdGVcbiAgICogLSBPcHRpbWl6ZWQgZm9yIGFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBHZW5lcmFsIGxhbmd1YWdlIHRhc2tzLCBsZWdhY3kgYXBwbGljYXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfVjJfMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbnRocm9waWMuY2xhdWRlLXYyOjEnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgbGVnYWN5OiB0cnVlLFxuICAgICAgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBWMiBtb2RlbCwgbGVnYWN5IHZlcnNpb24uXG4gICAqIE9yaWdpbmFsIENsYXVkZSBWMiBtb2RlbCB3aXRoIGJyb2FkIGNhcGFiaWxpdGllcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBMZWdhY3kgbW9kZWwgd2l0aCBFT0wgZGF0ZVxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IEdlbmVyYWwgbGFuZ3VhZ2UgdGFza3MsIGxlZ2FjeSBhcHBsaWNhdGlvbnNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV9WMiA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKCdhbnRocm9waWMuY2xhdWRlLXYyJywge1xuICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgIGxlZ2FjeTogdHJ1ZSxcbiAgICBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUsXG4gIH0pO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgSW5zdGFudCBWMS4yIG1vZGVsLCBsZWdhY3kgdmVyc2lvbi5cbiAgICogRmFzdCBhbmQgZWZmaWNpZW50IG1vZGVsIG9wdGltaXplZCBmb3IgcXVpY2sgcmVzcG9uc2VzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIExlZ2FjeSBtb2RlbCB3aXRoIEVPTCBkYXRlXG4gICAqIC0gT3B0aW1pemVkIGZvciBhZ2VudHNcbiAgICogLSBCZXN0IGZvcjogUXVpY2sgcmVzcG9uc2VzLCBzaW1wbGUgdGFza3MsIGxlZ2FjeSBhcHBsaWNhdGlvbnNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV9JTlNUQU5UX1YxXzIgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1pbnN0YW50LXYxJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIGxlZ2FjeTogdHJ1ZSxcbiAgICAgIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgIENPSEVSRVxuICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG4gIC8qKlxuICAgKiBDb2hlcmUncyBFbmdsaXNoIGVtYmVkZGluZyBtb2RlbCwgb3B0aW1pemVkIGZvciBFbmdsaXNoIHRleHQgZW1iZWRkaW5ncy5cbiAgICogU3BlY2lhbGl6ZWQgZm9yIHNlbWFudGljIHVuZGVyc3RhbmRpbmcgb2YgRW5nbGlzaCBjb250ZW50LlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBLbm93bGVkZ2UgQmFzZSBpbnRlZ3JhdGlvblxuICAgKiAtIDEwMjQtZGltZW5zaW9uYWwgdmVjdG9yc1xuICAgKiAtIFN1cHBvcnRzIGJvdGggZmxvYXRpbmctcG9pbnQgYW5kIGJpbmFyeSB2ZWN0b3JzXG4gICAqIC0gQmVzdCBmb3I6IEVuZ2xpc2ggdGV4dCBlbWJlZGRpbmdzLCBzZW1hbnRpYyBzZWFyY2gsIGNvbnRlbnQgc2ltaWxhcml0eVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBDT0hFUkVfRU1CRURfRU5HTElTSF9WMyA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdjb2hlcmUuZW1iZWQtZW5nbGlzaC12MycsXG4gICAge1xuICAgICAgc3VwcG9ydHNLbm93bGVkZ2VCYXNlOiB0cnVlLFxuICAgICAgdmVjdG9yRGltZW5zaW9uczogMTAyNCxcbiAgICAgIHN1cHBvcnRlZFZlY3RvclR5cGU6IFtWZWN0b3JUeXBlLkZMT0FUSU5HX1BPSU5ULCBWZWN0b3JUeXBlLkJJTkFSWV0sXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogQ29oZXJlJ3MgTXVsdGlsaW5ndWFsIGVtYmVkZGluZyBtb2RlbCwgc3VwcG9ydGluZyBtdWx0aXBsZSBsYW5ndWFnZXMuXG4gICAqIEVuYWJsZXMgc2VtYW50aWMgdW5kZXJzdGFuZGluZyBhY3Jvc3MgZGlmZmVyZW50IGxhbmd1YWdlcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgS25vd2xlZGdlIEJhc2UgaW50ZWdyYXRpb25cbiAgICogLSAxMDI0LWRpbWVuc2lvbmFsIHZlY3RvcnNcbiAgICogLSBTdXBwb3J0cyBib3RoIGZsb2F0aW5nLXBvaW50IGFuZCBiaW5hcnkgdmVjdG9yc1xuICAgKiAtIEJlc3QgZm9yOiBDcm9zcy1saW5ndWFsIGVtYmVkZGluZ3MsIG11bHRpbGluZ3VhbCBzZW1hbnRpYyBzZWFyY2hcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQ09IRVJFX0VNQkVEX01VTFRJTElOR1VBTF9WMyA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdjb2hlcmUuZW1iZWQtbXVsdGlsaW5ndWFsLXYzJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0tub3dsZWRnZUJhc2U6IHRydWUsXG4gICAgICB2ZWN0b3JEaW1lbnNpb25zOiAxMDI0LFxuICAgICAgc3VwcG9ydGVkVmVjdG9yVHlwZTogW1ZlY3RvclR5cGUuRkxPQVRJTkdfUE9JTlQsIFZlY3RvclR5cGUuQklOQVJZXSxcbiAgICB9LFxuICApO1xuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBERUVQU0VFS1xuICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG4gIC8qKlxuICAgKiBEZWVwc2VlaydzIFIxIG1vZGVsLCBkZXNpZ25lZCBmb3IgZ2VuZXJhbCBsYW5ndWFnZSB1bmRlcnN0YW5kaW5nLlxuICAgKiBCYWxhbmNlZCBtb2RlbCBmb3IgdmFyaW91cyBsYW5ndWFnZSB0YXNrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIEJlc3QgZm9yOiBHZW5lcmFsIGxhbmd1YWdlIHRhc2tzLCBjb250ZW50IGdlbmVyYXRpb25cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgREVFUFNFRUtfUjFfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCgnZGVlcHNlZWsucjEtdjE6MCcsIHtcbiAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICB9KTtcblxuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBNRVRBXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbiAgLyoqXG4gICAqIE1ldGEncyBMbGFtYSAzIDEuOEIgSW5zdHJ1Y3QgbW9kZWwsIGNvbXBhY3QgaW5zdHJ1Y3Rpb24tZm9sbG93aW5nIG1vZGVsLlxuICAgKiBFZmZpY2llbnQgbW9kZWwgb3B0aW1pemVkIGZvciBpbnN0cnVjdGlvbi1iYXNlZCB0YXNrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIEJlc3QgZm9yOiBMaWdodHdlaWdodCBpbnN0cnVjdGlvbiBwcm9jZXNzaW5nLCBxdWljayByZXNwb25zZXNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUVUQV9MTEFNQV8zXzFfOEJfSU5TVFJVQ1RfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWV0YS5sbGFtYTMtMS04Yi1pbnN0cnVjdC12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogTWV0YSdzIExsYW1hIDMgNzBCIEluc3RydWN0IG1vZGVsLCBsYXJnZS1zY2FsZSBpbnN0cnVjdGlvbiBtb2RlbC5cbiAgICogSGlnaC1jYXBhY2l0eSBtb2RlbCBmb3IgY29tcGxleCBsYW5ndWFnZSB1bmRlcnN0YW5kaW5nLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gQmVzdCBmb3I6IENvbXBsZXggaW5zdHJ1Y3Rpb25zLCBhZHZhbmNlZCBsYW5ndWFnZSB0YXNrc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBNRVRBX0xMQU1BXzNfMV83MEJfSU5TVFJVQ1RfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWV0YS5sbGFtYTMtMS03MGItaW5zdHJ1Y3QtdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1ldGEncyBMbGFtYSAzLjIgMTFCIEluc3RydWN0IG1vZGVsLCBtaWQtc2l6ZWQgaW5zdHJ1Y3Rpb24gbW9kZWwuXG4gICAqIEJhbGFuY2VkIG1vZGVsIGZvciBnZW5lcmFsIGluc3RydWN0aW9uIHByb2Nlc3NpbmcuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogR2VuZXJhbCBpbnN0cnVjdGlvbiB0YXNrcywgYmFsYW5jZWQgcGVyZm9ybWFuY2VcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUVUQV9MTEFNQV8zXzJfMTFCX0lOU1RSVUNUX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ21ldGEubGxhbWEzLTItMTFiLWluc3RydWN0LXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBNZXRhJ3MgTGxhbWEgMy4yIDNCIEluc3RydWN0IG1vZGVsLCBjb21wYWN0IGVmZmljaWVudCBtb2RlbC5cbiAgICogTGlnaHR3ZWlnaHQgbW9kZWwgZm9yIGJhc2ljIGluc3RydWN0aW9uIHByb2Nlc3NpbmcuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogQmFzaWMgaW5zdHJ1Y3Rpb25zLCBlZmZpY2llbnQgcHJvY2Vzc2luZ1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBNRVRBX0xMQU1BXzNfMl8zQl9JTlNUUlVDVF9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdtZXRhLmxsYW1hMy0yLTNiLWluc3RydWN0LXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBNZXRhJ3MgTGxhbWEgMy4yIDFCIEluc3RydWN0IG1vZGVsLCB1bHRyYS1saWdodHdlaWdodCBtb2RlbC5cbiAgICogTW9zdCBjb21wYWN0IG1vZGVsIGluIHRoZSBMbGFtYSAzLjIgc2VyaWVzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gQmVzdCBmb3I6IFNpbXBsZSBpbnN0cnVjdGlvbnMsIGZhc3Rlc3QgcmVzcG9uc2UgdGltZXNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUVUQV9MTEFNQV8zXzJfMUJfSU5TVFJVQ1RfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWV0YS5sbGFtYTMtMi0xYi1pbnN0cnVjdC12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogTWV0YSdzIExsYW1hIDMuMyA3MEIgSW5zdHJ1Y3QgbW9kZWwsIGxhdGVzdCBsYXJnZS1zY2FsZSBtb2RlbC5cbiAgICogQWR2YW5jZWQgbW9kZWwgd2l0aCBlbmhhbmNlZCBjYXBhYmlsaXRpZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogQ29tcGxleCByZWFzb25pbmcsIGFkdmFuY2VkIGxhbmd1YWdlIHRhc2tzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1FVEFfTExBTUFfM18zXzcwQl9JTlNUUlVDVF9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdtZXRhLmxsYW1hMy0zLTcwYi1pbnN0cnVjdC12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogTWV0YSdzIExsYW1hIDQgTWF2ZXJpY2sgMTdCIEluc3RydWN0IG1vZGVsLCBpbm5vdmF0aXZlIG1pZC1zaXplZCBtb2RlbC5cbiAgICogU3BlY2lhbGl6ZWQgZm9yIGNyZWF0aXZlIGFuZCBkeW5hbWljIHJlc3BvbnNlcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIEJlc3QgZm9yOiBDcmVhdGl2ZSB0YXNrcywgaW5ub3ZhdGl2ZSBzb2x1dGlvbnNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUVUQV9MTEFNQV80X01BVkVSSUNLXzE3Ql9JTlNUUlVDVF9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdtZXRhLmxsYW1hNC1tYXZlcmljay0xN2ItaW5zdHJ1Y3QtdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1ldGEncyBMbGFtYSA0IFNjb3V0IDE3QiBJbnN0cnVjdCBtb2RlbCwgYW5hbHl0aWNhbCBtaWQtc2l6ZWQgbW9kZWwuXG4gICAqIEZvY3VzZWQgb24gcHJlY2lzZSBhbmQgYW5hbHl0aWNhbCByZXNwb25zZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogQW5hbHl0aWNhbCB0YXNrcywgcHJlY2lzZSByZXNwb25zZXNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUVUQV9MTEFNQV80X1NDT1VUXzE3Ql9JTlNUUlVDVF9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdtZXRhLmxsYW1hNC1zY291dC0xN2ItaW5zdHJ1Y3QtdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIH0sXG4gICk7XG4gIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1JU1RSQUwgQUlcbiAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cblxuICAvKipcbiAgICogTWlzdHJhbCdzIDdCIEluc3RydWN0IG1vZGVsLCBlZmZpY2llbnQgaW5zdHJ1Y3Rpb24tZm9sbG93aW5nIG1vZGVsLlxuICAgKiBCYWxhbmNlZCBwZXJmb3JtYW5jZSBmb3IgaW5zdHJ1Y3Rpb24gcHJvY2Vzc2luZy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBPcHRpbWl6ZWQgZm9yIGluc3RydWN0aW9uIHRhc2tzXG4gICAqIC0gQmVzdCBmb3I6IEdlbmVyYWwgaW5zdHJ1Y3Rpb24gcHJvY2Vzc2luZywgYmFsYW5jZWQgcGVyZm9ybWFuY2VcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUlTVFJBTF83Ql9JTlNUUlVDVF9WMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdtaXN0cmFsLm1pc3RyYWwtN2ItaW5zdHJ1Y3QtdjA6MicsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBvcHRpbWl6ZWRGb3JBZ2VudHM6IGZhbHNlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogZmFsc2UsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogTWlzdHJhbCdzIE1peHRyYWwgOHg3QiBJbnN0cnVjdCBtb2RlbCwgbWl4dHVyZS1vZi1leHBlcnRzIGFyY2hpdGVjdHVyZS5cbiAgICogQWR2YW5jZWQgbW9kZWwgY29tYmluaW5nIG11bHRpcGxlIGV4cGVydCBuZXR3b3Jrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBTcGVjaWFsaXplZCBleHBlcnQgbmV0d29ya3NcbiAgICogLSBCZXN0IGZvcjogQ29tcGxleCB0YXNrcywgZGl2ZXJzZSBsYW5ndWFnZSB1bmRlcnN0YW5kaW5nXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1JU1RSQUxfTUlYVFJBTF84WDdCX0lOU1RSVUNUX1YwID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ21pc3RyYWwubWl4dHJhbC04eDdiLWluc3RydWN0LXYwOjEnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgb3B0aW1pemVkRm9yQWdlbnRzOiBmYWxzZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IGZhbHNlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1pc3RyYWwncyBTbWFsbCAyNDAyIG1vZGVsLCBjb21wYWN0IGVmZmljaWVudCBtb2RlbC5cbiAgICogT3B0aW1pemVkIGZvciBxdWljayByZXNwb25zZXMgYW5kIGVmZmljaWVuY3kuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gRWZmaWNpZW50IHByb2Nlc3NpbmdcbiAgICogLSBCZXN0IGZvcjogUXVpY2sgcmVzcG9uc2VzLCBiYXNpYyBsYW5ndWFnZSB0YXNrc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBNSVNUUkFMX1NNQUxMXzI0MDJfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWlzdHJhbC5taXN0cmFsLXNtYWxsLTI0MDItdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBvcHRpbWl6ZWRGb3JBZ2VudHM6IGZhbHNlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogZmFsc2UsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogTWlzdHJhbCdzIExhcmdlIDI0MDIgbW9kZWwsIGhpZ2gtY2FwYWNpdHkgbGFuZ3VhZ2UgbW9kZWwuXG4gICAqIEFkdmFuY2VkIG1vZGVsIGZvciBjb21wbGV4IGxhbmd1YWdlIHVuZGVyc3RhbmRpbmcuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gRW5oYW5jZWQgbGFuZ3VhZ2UgY2FwYWJpbGl0aWVzXG4gICAqIC0gQmVzdCBmb3I6IENvbXBsZXggcmVhc29uaW5nLCBkZXRhaWxlZCBhbmFseXNpc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBNSVNUUkFMX0xBUkdFXzI0MDJfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWlzdHJhbC5taXN0cmFsLWxhcmdlLTI0MDItdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBvcHRpbWl6ZWRGb3JBZ2VudHM6IGZhbHNlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogZmFsc2UsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogTWlzdHJhbCdzIExhcmdlIDI0MDcgbW9kZWwsIHVwZGF0ZWQgbGFyZ2Utc2NhbGUgbW9kZWwuXG4gICAqIEVuaGFuY2VkIHZlcnNpb24gd2l0aCBpbXByb3ZlZCBjYXBhYmlsaXRpZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQWR2YW5jZWQgbGFuZ3VhZ2UgcHJvY2Vzc2luZ1xuICAgKiAtIEJlc3QgZm9yOiBTb3BoaXN0aWNhdGVkIGxhbmd1YWdlIHRhc2tzLCBjb21wbGV4IGFuYWx5c2lzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1JU1RSQUxfTEFSR0VfMjQwN19WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdtaXN0cmFsLm1pc3RyYWwtbGFyZ2UtMjQwNy12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIG9wdGltaXplZEZvckFnZW50czogZmFsc2UsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiBmYWxzZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBNaXN0cmFsJ3MgUGl4dHJhbCBMYXJnZSAyNTAyIG1vZGVsLCBzcGVjaWFsaXplZCBsYXJnZSBtb2RlbC5cbiAgICogQWR2YW5jZWQgbW9kZWwgd2l0aCBjcm9zcy1yZWdpb24gc3VwcG9ydC5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIEJlc3QgZm9yOiBBZHZhbmNlZCBsYW5ndWFnZSB0YXNrcywgZGlzdHJpYnV0ZWQgYXBwbGljYXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1JU1RSQUxfUElYVFJBTF9MQVJHRV8yNTAyX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ21pc3RyYWwucGl4dHJhbC1sYXJnZS0yNTAyLXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgb3B0aW1pemVkRm9yQWdlbnRzOiBmYWxzZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogQ3JlYXRlcyBhIEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwgZnJvbSBhIEZvdW5kYXRpb25Nb2RlbElkZW50aWZpZXIuXG4gICAqIFVzZSB0aGlzIG1ldGhvZCB3aGVuIHlvdSBoYXZlIGEgbW9kZWwgaWRlbnRpZmllciBmcm9tIHRoZSBDREsuXG4gICAqIEBwYXJhbSBtb2RlbElkIC0gVGhlIGZvdW5kYXRpb24gbW9kZWwgaWRlbnRpZmllclxuICAgKiBAcGFyYW0gcHJvcHMgLSBPcHRpb25hbCBwcm9wZXJ0aWVzIGZvciB0aGUgbW9kZWxcbiAgICogQHJldHVybnMgQSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCBpbnN0YW5jZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tQ2RrRm91bmRhdGlvbk1vZGVsSWQoXG4gICAgbW9kZWxJZDogRm91bmRhdGlvbk1vZGVsSWRlbnRpZmllcixcbiAgICBwcm9wczogQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbFByb3BzID0ge30sXG4gICk6IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwge1xuICAgIHJldHVybiBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChtb2RlbElkLm1vZGVsSWQsIHByb3BzKTtcbiAgfVxuICAvKipcbiAgICogQ3JlYXRlcyBhIEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwgZnJvbSBhIEZvdW5kYXRpb25Nb2RlbC5cbiAgICogVXNlIHRoaXMgbWV0aG9kIHdoZW4geW91IGhhdmUgYSBmb3VuZGF0aW9uIG1vZGVsIGZyb20gdGhlIENESy5cbiAgICogQHBhcmFtIG1vZGVsSWQgLSBUaGUgZm91bmRhdGlvbiBtb2RlbFxuICAgKiBAcGFyYW0gcHJvcHMgLSBPcHRpb25hbCBwcm9wZXJ0aWVzIGZvciB0aGUgbW9kZWxcbiAgICogQHJldHVybnMgQSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCBpbnN0YW5jZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tQ2RrRm91bmRhdGlvbk1vZGVsKFxuICAgIG1vZGVsSWQ6IEZvdW5kYXRpb25Nb2RlbCxcbiAgICBwcm9wczogQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbFByb3BzID0ge30sXG4gICk6IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwge1xuICAgIHJldHVybiBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChtb2RlbElkLm1vZGVsSWQsIHByb3BzKTtcbiAgfVxuXG4gIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbnN0cnVjdG9yXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gIC8qKlxuICAgKiBUaGUgdW5pcXVlIGlkZW50aWZpZXIgb2YgdGhlIGZvdW5kYXRpb24gbW9kZWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgbW9kZWxJZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBmb3VuZGF0aW9uIG1vZGVsLlxuICAgKiBGb3JtYXQ6IGFybjoke1BhcnRpdGlvbn06YmVkcm9jazoke1JlZ2lvbn06OmZvdW5kYXRpb24tbW9kZWwvJHtSZXNvdXJjZUlkfVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IG1vZGVsQXJuOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBBUk4gdXNlZCBmb3IgaW52b2tpbmcgdGhlIG1vZGVsLlxuICAgKiBUaGlzIGlzIHRoZSBzYW1lIGFzIG1vZGVsQXJuIGZvciBmb3VuZGF0aW9uIG1vZGVscy5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBpbnZva2FibGVBcm46IHN0cmluZztcblxuICAvKipcbiAgICogV2hldGhlciB0aGlzIG1vZGVsIHN1cHBvcnRzIGludGVncmF0aW9uIHdpdGggQmVkcm9jayBBZ2VudHMuXG4gICAqIFdoZW4gdHJ1ZSwgdGhlIG1vZGVsIGNhbiBiZSB1c2VkIHdpdGggQmVkcm9jayBBZ2VudHMgZm9yIGF1dG9tYXRlZCB0YXNrIGV4ZWN1dGlvbi5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBzdXBwb3J0c0FnZW50czogYm9vbGVhbjtcblxuICAvKipcbiAgICogV2hldGhlciB0aGlzIG1vZGVsIHN1cHBvcnRzIGNyb3NzLXJlZ2lvbiBpbmZlcmVuY2UuXG4gICAqIFdoZW4gdHJ1ZSwgdGhlIG1vZGVsIGNhbiBiZSB1c2VkIHdpdGggQ3Jvc3MtUmVnaW9uIEluZmVyZW5jZSBQcm9maWxlcy5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBzdXBwb3J0c0Nyb3NzUmVnaW9uOiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBUaGUgZGltZW5zaW9uYWxpdHkgb2YgdGhlIHZlY3RvciBlbWJlZGRpbmdzIHByb2R1Y2VkIGJ5IHRoaXMgbW9kZWwuXG4gICAqIE9ubHkgYXBwbGljYWJsZSBmb3IgZW1iZWRkaW5nIG1vZGVscy5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSB2ZWN0b3JEaW1lbnNpb25zPzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoaXMgbW9kZWwgc3VwcG9ydHMgaW50ZWdyYXRpb24gd2l0aCBCZWRyb2NrIEtub3dsZWRnZSBCYXNlLlxuICAgKiBXaGVuIHRydWUsIHRoZSBtb2RlbCBjYW4gYmUgdXNlZCBmb3Iga25vd2xlZGdlIGJhc2Ugb3BlcmF0aW9ucy5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBzdXBwb3J0c0tub3dsZWRnZUJhc2U6IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIFRoZSB2ZWN0b3IgdHlwZXMgc3VwcG9ydGVkIGJ5IHRoaXMgbW9kZWwgZm9yIGVtYmVkZGluZ3MuXG4gICAqIERlZmluZXMgd2hldGhlciB0aGUgbW9kZWwgc3VwcG9ydHMgZmxvYXRpbmctcG9pbnQgb3IgYmluYXJ5IHZlY3RvcnMuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgc3VwcG9ydGVkVmVjdG9yVHlwZT86IFZlY3RvclR5cGVbXTtcbiAgY29uc3RydWN0b3IodmFsdWU6IHN0cmluZywgcHJvcHM6IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWxQcm9wcyA9IHt9KSB7XG4gICAgdGhpcy5tb2RlbElkID0gdmFsdWU7XG4gICAgdGhpcy5tb2RlbEFybiA9IEFybi5mb3JtYXQoe1xuICAgICAgcGFydGl0aW9uOiBBd3MuUEFSVElUSU9OLFxuICAgICAgc2VydmljZTogJ2JlZHJvY2snLFxuICAgICAgcmVnaW9uOiBBd3MuUkVHSU9OLFxuICAgICAgYWNjb3VudDogJycsXG4gICAgICByZXNvdXJjZTogJ2ZvdW5kYXRpb24tbW9kZWwnLFxuICAgICAgcmVzb3VyY2VOYW1lOiB0aGlzLm1vZGVsSWQsXG4gICAgICBhcm5Gb3JtYXQ6IEFybkZvcm1hdC5TTEFTSF9SRVNPVVJDRV9OQU1FLFxuICAgIH0pO1xuICAgIHRoaXMuaW52b2thYmxlQXJuID0gdGhpcy5tb2RlbEFybjtcbiAgICB0aGlzLnN1cHBvcnRzQ3Jvc3NSZWdpb24gPSBwcm9wcy5zdXBwb3J0c0Nyb3NzUmVnaW9uID8/IGZhbHNlO1xuICAgIHRoaXMuc3VwcG9ydHNBZ2VudHMgPSBwcm9wcy5zdXBwb3J0c0FnZW50cyA/PyBmYWxzZTtcbiAgICB0aGlzLnZlY3RvckRpbWVuc2lvbnMgPSBwcm9wcy52ZWN0b3JEaW1lbnNpb25zO1xuICAgIHRoaXMuc3VwcG9ydHNLbm93bGVkZ2VCYXNlID0gcHJvcHMuc3VwcG9ydHNLbm93bGVkZ2VCYXNlID8/IGZhbHNlO1xuICAgIHRoaXMuc3VwcG9ydGVkVmVjdG9yVHlwZSA9IHByb3BzLnN1cHBvcnRlZFZlY3RvclR5cGU7XG4gIH1cblxuICB0b1N0cmluZygpOiBzdHJpbmcge1xuICAgIHJldHVybiB0aGlzLm1vZGVsSWQ7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgQVJOIG9mIHRoZSBmb3VuZGF0aW9uIG1vZGVsIGluIHRoZSBmb2xsb3dpbmcgZm9ybWF0OlxuICAgKiBgYXJuOiR7UGFydGl0aW9ufTpiZWRyb2NrOiR7UmVnaW9ufTo6Zm91bmRhdGlvbi1tb2RlbC8ke1Jlc291cmNlSWR9YFxuICAgKi9cbiAgYXNBcm4oKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy5tb2RlbEFybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBJTW9kZWxcbiAgICovXG4gIGFzSU1vZGVsKCk6IElNb2RlbCB7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKipcbiAgICogR2l2ZXMgdGhlIGFwcHJvcHJpYXRlIHBvbGljaWVzIHRvIGludm9rZSBhbmQgdXNlIHRoZSBGb3VuZGF0aW9uIE1vZGVsIGluIHRoZSBzdGFjayByZWdpb24uXG4gICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgKi9cbiAgcHVibGljIGdyYW50SW52b2tlKGdyYW50ZWU6IElHcmFudGFibGUpOiBHcmFudCB7XG4gICAgY29uc3QgZ3JhbnQgPSBHcmFudC5hZGRUb1ByaW5jaXBhbCh7XG4gICAgICBncmFudGVlOiBncmFudGVlLFxuICAgICAgYWN0aW9uczogWydiZWRyb2NrOkludm9rZU1vZGVsKicsICdiZWRyb2NrOkdldEZvdW5kYXRpb25Nb2RlbCddLFxuICAgICAgcmVzb3VyY2VBcm5zOiBbdGhpcy5pbnZva2FibGVBcm5dLFxuICAgIH0pO1xuICAgIHJldHVybiBncmFudDtcbiAgfVxuXG4gIC8qKlxuICAgKiBHaXZlcyB0aGUgYXBwcm9wcmlhdGUgcG9saWNpZXMgdG8gaW52b2tlIGFuZCB1c2UgdGhlIEZvdW5kYXRpb24gTW9kZWwgaW4gYWxsIHJlZ2lvbnMuXG4gICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgKi9cbiAgcHVibGljIGdyYW50SW52b2tlQWxsUmVnaW9ucyhncmFudGVlOiBJR3JhbnRhYmxlKTogR3JhbnQge1xuICAgIGNvbnN0IGludm9rYWJsZUFybiA9IEFybi5mb3JtYXQoe1xuICAgICAgcGFydGl0aW9uOiBBd3MuUEFSVElUSU9OLFxuICAgICAgc2VydmljZTogJ2JlZHJvY2snLFxuICAgICAgcmVnaW9uOiAnKicsXG4gICAgICBhY2NvdW50OiAnJyxcbiAgICAgIHJlc291cmNlOiAnZm91bmRhdGlvbi1tb2RlbCcsXG4gICAgICByZXNvdXJjZU5hbWU6IHRoaXMubW9kZWxJZCxcbiAgICAgIGFybkZvcm1hdDogQXJuRm9ybWF0LlNMQVNIX1JFU09VUkNFX05BTUUsXG4gICAgfSk7XG5cbiAgICByZXR1cm4gR3JhbnQuYWRkVG9QcmluY2lwYWwoe1xuICAgICAgZ3JhbnRlZTogZ3JhbnRlZSxcbiAgICAgIGFjdGlvbnM6IFsnYmVkcm9jazpJbnZva2VNb2RlbConLCAnYmVkcm9jazpHZXRGb3VuZGF0aW9uTW9kZWwnXSxcbiAgICAgIHJlc291cmNlQXJuczogW2ludm9rYWJsZUFybl0sXG4gICAgfSk7XG4gIH1cbn1cbiJdfQ==