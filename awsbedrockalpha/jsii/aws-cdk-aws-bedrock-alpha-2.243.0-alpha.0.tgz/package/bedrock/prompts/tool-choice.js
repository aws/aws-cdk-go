"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolChoice = exports.Tool = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
/**
 * Abstract base class for tools that can be used by the model.
 */
class Tool {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.Tool", version: "2.243.0-alpha.0" };
    /**
     * Creates a function tool.
     */
    static function(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_FunctionToolProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.function);
            }
            throw error;
        }
        return new FunctionTool(props);
    }
}
exports.Tool = Tool;
/**
 * A function tool that can be called by the model.
 */
class FunctionTool extends Tool {
    props;
    constructor(props) {
        super();
        this.props = props;
    }
    _render() {
        return {
            toolSpec: {
                name: this.props.name,
                description: this.props.description,
                inputSchema: {
                    json: this.props.inputSchema,
                },
            },
        };
    }
}
/**
 * Defines how the model should choose which tool to use.
 */
class ToolChoice {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ToolChoice", version: "2.243.0-alpha.0" };
    /**
     * The model must request at least one tool (no text is generated).
     */
    static ANY = new ToolChoice({}, undefined, undefined);
    /**
     * (Default). The Model automatically decides if a tool should be called or whether to generate text instead.
     */
    static AUTO = new ToolChoice(undefined, {}, undefined);
    /**
     * The Model must request the specified tool. Only supported by some models like Anthropic Claude 3 models.
     *
     * @param toolName - The name of the specific tool to use
     * @returns A ToolChoice instance configured for the specific tool
     */
    static specificTool(toolName) {
        return new ToolChoice(undefined, undefined, toolName);
    }
    /**
     * Configuration for ANY tool choice.
     */
    any;
    /**
     * Configuration for AUTO tool choice.
     */
    auto;
    /**
     * The specific tool name if using specific tool choice.
     */
    tool;
    constructor(any, auto, tool) {
        this.any = any;
        this.auto = auto;
        this.tool = tool;
    }
    /**
     * Renders the tool choice as a CloudFormation property.
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            any: this.any,
            auto: this.auto,
            tool: this.tool !== undefined ? { name: this.tool } : undefined,
        };
    }
}
exports.ToolChoice = ToolChoice;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidG9vbC1jaG9pY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ0b29sLWNob2ljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQXFDQTs7R0FFRztBQUNILE1BQXNCLElBQUk7O0lBQ3hCOztPQUVHO0lBQ0ksTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUF3Qjs7Ozs7Ozs7OztRQUM3QyxPQUFPLElBQUksWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO0tBQ2hDOztBQU5ILG9CQWFDO0FBRUQ7O0dBRUc7QUFDSCxNQUFNLFlBQWEsU0FBUSxJQUFJO0lBQ0E7SUFBN0IsWUFBNkIsS0FBd0I7UUFDbkQsS0FBSyxFQUFFLENBQUM7UUFEbUIsVUFBSyxHQUFMLEtBQUssQ0FBbUI7S0FFcEQ7SUFFTSxPQUFPO1FBQ1osT0FBTztZQUNMLFFBQVEsRUFBRTtnQkFDUixJQUFJLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJO2dCQUNyQixXQUFXLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXO2dCQUNuQyxXQUFXLEVBQUU7b0JBQ1gsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVztpQkFDN0I7YUFDRjtTQUNGLENBQUM7S0FDSDtDQUNGO0FBRUQ7O0dBRUc7QUFDSCxNQUFhLFVBQVU7O0lBQ3JCOztPQUVHO0lBQ0ksTUFBTSxDQUFVLEdBQUcsR0FBRyxJQUFJLFVBQVUsQ0FBQyxFQUFFLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBRXRFOztPQUVHO0lBQ0ksTUFBTSxDQUFVLElBQUksR0FBRyxJQUFJLFVBQVUsQ0FBQyxTQUFTLEVBQUUsRUFBRSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBRXZFOzs7OztPQUtHO0lBQ0ksTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFnQjtRQUN6QyxPQUFPLElBQUksVUFBVSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsUUFBUSxDQUFDLENBQUM7S0FDdkQ7SUFFRDs7T0FFRztJQUNhLEdBQUcsQ0FBTztJQUUxQjs7T0FFRztJQUNhLElBQUksQ0FBTztJQUUzQjs7T0FFRztJQUNhLElBQUksQ0FBVTtJQUU5QixZQUFZLEdBQVEsRUFBRSxJQUFTLEVBQUUsSUFBYTtRQUM1QyxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQztRQUNmLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0tBQ2xCO0lBRUQ7OztPQUdHO0lBQ0ksT0FBTztRQUNaLE9BQU87WUFDTCxHQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUc7WUFDYixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUztTQUNoRSxDQUFDO0tBQ0g7O0FBcERILGdDQXFEQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgQ2ZuUHJvbXB0IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuXG4vKipcbiAqIENvbmZpZ3VyYXRpb24gZm9yIHRvb2xzIGF2YWlsYWJsZSB0byB0aGUgbW9kZWwuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVG9vbENvbmZpZ3VyYXRpb24ge1xuICAvKipcbiAgICogSG93IHRoZSBtb2RlbCBzaG91bGQgY2hvb3NlIHdoaWNoIHRvb2wgdG8gdXNlLlxuICAgKi9cbiAgcmVhZG9ubHkgdG9vbENob2ljZTogVG9vbENob2ljZTtcblxuICAvKipcbiAgICogVGhlIHRvb2xzIGF2YWlsYWJsZSB0byB0aGUgbW9kZWwuXG4gICAqL1xuICByZWFkb25seSB0b29sczogVG9vbFtdO1xufVxuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNyZWF0aW5nIGEgZnVuY3Rpb24gdG9vbC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBGdW5jdGlvblRvb2xQcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgZnVuY3Rpb24uXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEEgZGVzY3JpcHRpb24gb2Ygd2hhdCB0aGUgZnVuY3Rpb24gZG9lcy5cbiAgICovXG4gIHJlYWRvbmx5IGRlc2NyaXB0aW9uOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBpbnB1dCBzY2hlbWEgZm9yIHRoZSBmdW5jdGlvbiBwYXJhbWV0ZXJzLlxuICAgKi9cbiAgcmVhZG9ubHkgaW5wdXRTY2hlbWE6IGFueTtcbn1cblxuLyoqXG4gKiBBYnN0cmFjdCBiYXNlIGNsYXNzIGZvciB0b29scyB0aGF0IGNhbiBiZSB1c2VkIGJ5IHRoZSBtb2RlbC5cbiAqL1xuZXhwb3J0IGFic3RyYWN0IGNsYXNzIFRvb2wge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIGZ1bmN0aW9uIHRvb2wuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZ1bmN0aW9uKHByb3BzOiBGdW5jdGlvblRvb2xQcm9wcyk6IFRvb2wge1xuICAgIHJldHVybiBuZXcgRnVuY3Rpb25Ub29sKHByb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSB0b29sIGFzIGEgQ2xvdWRGb3JtYXRpb24gcHJvcGVydHkuXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIGFic3RyYWN0IF9yZW5kZXIoKTogQ2ZuUHJvbXB0LlRvb2xQcm9wZXJ0eTtcbn1cblxuLyoqXG4gKiBBIGZ1bmN0aW9uIHRvb2wgdGhhdCBjYW4gYmUgY2FsbGVkIGJ5IHRoZSBtb2RlbC5cbiAqL1xuY2xhc3MgRnVuY3Rpb25Ub29sIGV4dGVuZHMgVG9vbCB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgcHJvcHM6IEZ1bmN0aW9uVG9vbFByb3BzKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHB1YmxpYyBfcmVuZGVyKCk6IENmblByb21wdC5Ub29sUHJvcGVydHkge1xuICAgIHJldHVybiB7XG4gICAgICB0b29sU3BlYzoge1xuICAgICAgICBuYW1lOiB0aGlzLnByb3BzLm5hbWUsXG4gICAgICAgIGRlc2NyaXB0aW9uOiB0aGlzLnByb3BzLmRlc2NyaXB0aW9uLFxuICAgICAgICBpbnB1dFNjaGVtYToge1xuICAgICAgICAgIGpzb246IHRoaXMucHJvcHMuaW5wdXRTY2hlbWEsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH07XG4gIH1cbn1cblxuLyoqXG4gKiBEZWZpbmVzIGhvdyB0aGUgbW9kZWwgc2hvdWxkIGNob29zZSB3aGljaCB0b29sIHRvIHVzZS5cbiAqL1xuZXhwb3J0IGNsYXNzIFRvb2xDaG9pY2Uge1xuICAvKipcbiAgICogVGhlIG1vZGVsIG11c3QgcmVxdWVzdCBhdCBsZWFzdCBvbmUgdG9vbCAobm8gdGV4dCBpcyBnZW5lcmF0ZWQpLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlkgPSBuZXcgVG9vbENob2ljZSh7fSwgdW5kZWZpbmVkLCB1bmRlZmluZWQpO1xuXG4gIC8qKlxuICAgKiAoRGVmYXVsdCkuIFRoZSBNb2RlbCBhdXRvbWF0aWNhbGx5IGRlY2lkZXMgaWYgYSB0b29sIHNob3VsZCBiZSBjYWxsZWQgb3Igd2hldGhlciB0byBnZW5lcmF0ZSB0ZXh0IGluc3RlYWQuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFVVE8gPSBuZXcgVG9vbENob2ljZSh1bmRlZmluZWQsIHt9LCB1bmRlZmluZWQpO1xuXG4gIC8qKlxuICAgKiBUaGUgTW9kZWwgbXVzdCByZXF1ZXN0IHRoZSBzcGVjaWZpZWQgdG9vbC4gT25seSBzdXBwb3J0ZWQgYnkgc29tZSBtb2RlbHMgbGlrZSBBbnRocm9waWMgQ2xhdWRlIDMgbW9kZWxzLlxuICAgKlxuICAgKiBAcGFyYW0gdG9vbE5hbWUgLSBUaGUgbmFtZSBvZiB0aGUgc3BlY2lmaWMgdG9vbCB0byB1c2VcbiAgICogQHJldHVybnMgQSBUb29sQ2hvaWNlIGluc3RhbmNlIGNvbmZpZ3VyZWQgZm9yIHRoZSBzcGVjaWZpYyB0b29sXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHNwZWNpZmljVG9vbCh0b29sTmFtZTogc3RyaW5nKTogVG9vbENob2ljZSB7XG4gICAgcmV0dXJuIG5ldyBUb29sQ2hvaWNlKHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB0b29sTmFtZSk7XG4gIH1cblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgQU5ZIHRvb2wgY2hvaWNlLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGFueT86IGFueTtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgQVVUTyB0b29sIGNob2ljZS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBhdXRvPzogYW55O1xuXG4gIC8qKlxuICAgKiBUaGUgc3BlY2lmaWMgdG9vbCBuYW1lIGlmIHVzaW5nIHNwZWNpZmljIHRvb2wgY2hvaWNlLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHRvb2w/OiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IoYW55OiBhbnksIGF1dG86IGFueSwgdG9vbD86IHN0cmluZykge1xuICAgIHRoaXMuYW55ID0gYW55O1xuICAgIHRoaXMuYXV0byA9IGF1dG87XG4gICAgdGhpcy50b29sID0gdG9vbDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSB0b29sIGNob2ljZSBhcyBhIENsb3VkRm9ybWF0aW9uIHByb3BlcnR5LlxuICAgKiBAaW50ZXJuYWwgVGhpcyBpcyBhbiBpbnRlcm5hbCBjb3JlIGZ1bmN0aW9uIGFuZCBzaG91bGQgbm90IGJlIGNhbGxlZCBkaXJlY3RseS5cbiAgICovXG4gIHB1YmxpYyBfcmVuZGVyKCk6IENmblByb21wdC5Ub29sQ2hvaWNlUHJvcGVydHkge1xuICAgIHJldHVybiB7XG4gICAgICBhbnk6IHRoaXMuYW55LFxuICAgICAgYXV0bzogdGhpcy5hdXRvLFxuICAgICAgdG9vbDogdGhpcy50b29sICE9PSB1bmRlZmluZWQgPyB7IG5hbWU6IHRoaXMudG9vbCB9IDogdW5kZWZpbmVkLFxuICAgIH07XG4gIH1cbn1cbiJdfQ==