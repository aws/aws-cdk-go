"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentActionGroup = exports.ParentActionGroupSignature = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const crypto = require("crypto");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
/******************************************************************************
 *                           Signatures
 *****************************************************************************/
/**
 * AWS Defined signatures for enabling certain capabilities in your agent.
 */
class ParentActionGroupSignature {
    value;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ParentActionGroupSignature", version: "2.243.0-alpha.0" };
    /**
     * Signature that allows your agent to request the user for additional information when trying to complete a task.
     */
    static USER_INPUT = new ParentActionGroupSignature('AMAZON.UserInput');
    /**
     * Signature that allows your agent to generate, run, and troubleshoot code when trying to complete a task.
     */
    static CODE_INTERPRETER = new ParentActionGroupSignature('AMAZON.CodeInterpreter');
    /**
     * Constructor should be used as a temporary solution when a new signature is supported but its implementation in CDK hasn't been added yet.
     */
    constructor(
    /**
     * The AWS-defined signature value for this action group capability.
     */
    value) {
        this.value = value;
    }
    /**
     * Returns the string representation of the signature value.
     * Used when configuring the action group in CloudFormation.
     */
    toString() {
        return this.value;
    }
}
exports.ParentActionGroupSignature = ParentActionGroupSignature;
/******************************************************************************
 *                         DEF - Action Group Class
 *****************************************************************************/
class AgentActionGroup {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AgentActionGroup", version: "2.243.0-alpha.0" };
    // ------------------------------------------------------
    // Static Constructors
    // ------------------------------------------------------
    /**
     * Defines an action group that allows your agent to request the user for
     * additional information when trying to complete a task.
     * @param enabled Specifies whether the action group is available for the agent
     */
    static userInput(enabled) {
        return new AgentActionGroup({
            name: 'UserInputAction',
            enabled: enabled,
            parentActionGroupSignature: ParentActionGroupSignature.USER_INPUT,
        });
    }
    /**
     * Defines an action group that allows your agent to request the user for
     * additional information when trying to complete a task.
     * @param enabled Specifies whether the action group is available for the agent
     */
    static codeInterpreter(enabled) {
        return new AgentActionGroup({
            name: 'CodeInterpreterAction',
            enabled: enabled,
            parentActionGroupSignature: ParentActionGroupSignature.CODE_INTERPRETER,
        });
    }
    // ------------------------------------------------------
    // Attributes
    // ------------------------------------------------------
    /**
     * The name of the action group.
     */
    name;
    /**
     * A description of the action group.
     */
    description;
    /**
     * Whether this action group is available for the agent to invoke or not.
     */
    enabled;
    /**
     * The api schema for this action group (if defined).
     */
    apiSchema;
    /**
     * The action group executor for this action group (if defined).
     */
    executor;
    /**
     * Whether to delete the resource even if it's in use.
     */
    forceDelete;
    /**
     * The function schema for this action group (if defined).
     */
    functionSchema;
    /**
     * The AWS Defined signature (if defined).
     */
    parentActionGroupSignature;
    constructor(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentActionGroupProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, AgentActionGroup);
            }
            throw error;
        }
        // Validate Props
        this.validateProps(props);
        // ------------------------------------------------------
        // Set attributes or defaults
        // ------------------------------------------------------
        this.name = props.name ?? `action_group_quick_start_${crypto.randomUUID()}`;
        this.description = props.description;
        this.apiSchema = props.apiSchema;
        this.executor = props.executor;
        this.enabled = props.enabled ?? true;
        this.forceDelete = props.forceDelete ?? false;
        this.functionSchema = props.functionSchema;
        this.parentActionGroupSignature = props.parentActionGroupSignature;
    }
    validateProps(props) {
        if (props.parentActionGroupSignature && (props.description || props.apiSchema || props.executor)) {
            throw new errors_1.UnscopedValidationError('When parentActionGroupSignature is specified, you must leave the description, ' +
                'apiSchema, and actionGroupExecutor fields blank for this action group');
        }
    }
    /**
     * Format as CFN properties
     *
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            actionGroupExecutor: this.executor?._render(),
            actionGroupName: this.name,
            actionGroupState: this.enabled ? 'ENABLED' : 'DISABLED',
            apiSchema: this.apiSchema?._render(),
            description: this.description,
            functionSchema: this.functionSchema?._render(),
            parentActionGroupSignature: this.parentActionGroupSignature?.toString(),
            skipResourceInUseCheckOnDelete: this.forceDelete,
        };
    }
}
exports.AgentActionGroup = AgentActionGroup;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWN0aW9uLWdyb3VwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYWN0aW9uLWdyb3VwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsaUNBQWlDO0FBRWpDLHdEQUFzRTtBQUt0RTs7K0VBRStFO0FBQy9FOztHQUVHO0FBQ0gsTUFBYSwwQkFBMEI7SUFnQm5COztJQWZsQjs7T0FFRztJQUNJLE1BQU0sQ0FBVSxVQUFVLEdBQUcsSUFBSSwwQkFBMEIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3ZGOztPQUVHO0lBQ0ksTUFBTSxDQUFVLGdCQUFnQixHQUFHLElBQUksMEJBQTBCLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUNuRzs7T0FFRztJQUNIO0lBQ0U7O09BRUc7SUFDYSxLQUFhO1FBQWIsVUFBSyxHQUFMLEtBQUssQ0FBUTtLQUMzQjtJQUVKOzs7T0FHRztJQUNJLFFBQVE7UUFDYixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUM7S0FDbkI7O0FBekJILGdFQTBCQztBQWlFRDs7K0VBRStFO0FBRS9FLE1BQWEsZ0JBQWdCOztJQUMzQix5REFBeUQ7SUFDekQsc0JBQXNCO0lBQ3RCLHlEQUF5RDtJQUN6RDs7OztPQUlHO0lBQ0ksTUFBTSxDQUFDLFNBQVMsQ0FBQyxPQUFnQjtRQUN0QyxPQUFPLElBQUksZ0JBQWdCLENBQUM7WUFDMUIsSUFBSSxFQUFFLGlCQUFpQjtZQUN2QixPQUFPLEVBQUUsT0FBTztZQUNoQiwwQkFBMEIsRUFBRSwwQkFBMEIsQ0FBQyxVQUFVO1NBQ2xFLENBQUMsQ0FBQztLQUNKO0lBRUQ7Ozs7T0FJRztJQUNJLE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBZ0I7UUFDNUMsT0FBTyxJQUFJLGdCQUFnQixDQUFDO1lBQzFCLElBQUksRUFBRSx1QkFBdUI7WUFDN0IsT0FBTyxFQUFFLE9BQU87WUFDaEIsMEJBQTBCLEVBQUUsMEJBQTBCLENBQUMsZ0JBQWdCO1NBQ3hFLENBQUMsQ0FBQztLQUNKO0lBRUQseURBQXlEO0lBQ3pELGFBQWE7SUFDYix5REFBeUQ7SUFDekQ7O09BRUc7SUFDYSxJQUFJLENBQVM7SUFDN0I7O09BRUc7SUFDYSxXQUFXLENBQVU7SUFDckM7O09BRUc7SUFDYSxPQUFPLENBQVU7SUFDakM7O09BRUc7SUFDYSxTQUFTLENBQWE7SUFDdEM7O09BRUc7SUFDYSxRQUFRLENBQXVCO0lBQy9DOztPQUVHO0lBQ2EsV0FBVyxDQUFXO0lBQ3RDOztPQUVHO0lBQ2EsY0FBYyxDQUFrQjtJQUNoRDs7T0FFRztJQUNhLDBCQUEwQixDQUE4QjtJQUV4RSxZQUFtQixLQUE0Qjs7Ozs7OytDQWxFcEMsZ0JBQWdCOzs7O1FBbUV6QixpQkFBaUI7UUFDakIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUUxQix5REFBeUQ7UUFDekQsNkJBQTZCO1FBQzdCLHlEQUF5RDtRQUN6RCxJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLElBQUksNEJBQTRCLE1BQU0sQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDO1FBQzVFLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQztRQUNyQyxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7UUFDakMsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDO1FBQy9CLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUM7UUFDckMsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsV0FBVyxJQUFJLEtBQUssQ0FBQztRQUM5QyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUM7UUFDM0MsSUFBSSxDQUFDLDBCQUEwQixHQUFHLEtBQUssQ0FBQywwQkFBMEIsQ0FBQztLQUNwRTtJQUVPLGFBQWEsQ0FBQyxLQUE0QjtRQUNoRCxJQUFJLEtBQUssQ0FBQywwQkFBMEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLElBQUksS0FBSyxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQztZQUNqRyxNQUFNLElBQUksZ0NBQXVCLENBQy9CLGdGQUFnRjtnQkFDOUUsdUVBQXVFLENBQzFFLENBQUM7UUFDSixDQUFDO0tBQ0Y7SUFFRDs7OztPQUlHO0lBQ0ksT0FBTztRQUNaLE9BQU87WUFDTCxtQkFBbUIsRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLE9BQU8sRUFBRTtZQUM3QyxlQUFlLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDMUIsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVO1lBQ3ZELFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRTtZQUNwQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVc7WUFDN0IsY0FBYyxFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsT0FBTyxFQUFFO1lBQzlDLDBCQUEwQixFQUFFLElBQUksQ0FBQywwQkFBMEIsRUFBRSxRQUFRLEVBQUU7WUFDdkUsOEJBQThCLEVBQUUsSUFBSSxDQUFDLFdBQVc7U0FDakQsQ0FBQztLQUNIOztBQTVHSCw0Q0E2R0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBjcnlwdG8gZnJvbSAnY3J5cHRvJztcbmltcG9ydCB0eXBlIHsgQ2ZuQWdlbnQgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgeyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvciB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2Vycm9ycyc7XG5pbXBvcnQgdHlwZSB7IEFjdGlvbkdyb3VwRXhlY3V0b3IgfSBmcm9tICcuL2FwaS1leGVjdXRvcic7XG5pbXBvcnQgdHlwZSB7IEFwaVNjaGVtYSB9IGZyb20gJy4vYXBpLXNjaGVtYSc7XG5pbXBvcnQgdHlwZSB7IEZ1bmN0aW9uU2NoZW1hIH0gZnJvbSAnLi9mdW5jdGlvbi1zY2hlbWEnO1xuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgIFNpZ25hdHVyZXNcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogQVdTIERlZmluZWQgc2lnbmF0dXJlcyBmb3IgZW5hYmxpbmcgY2VydGFpbiBjYXBhYmlsaXRpZXMgaW4geW91ciBhZ2VudC5cbiAqL1xuZXhwb3J0IGNsYXNzIFBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlIHtcbiAgLyoqXG4gICAqIFNpZ25hdHVyZSB0aGF0IGFsbG93cyB5b3VyIGFnZW50IHRvIHJlcXVlc3QgdGhlIHVzZXIgZm9yIGFkZGl0aW9uYWwgaW5mb3JtYXRpb24gd2hlbiB0cnlpbmcgdG8gY29tcGxldGUgYSB0YXNrLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBVU0VSX0lOUFVUID0gbmV3IFBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlKCdBTUFaT04uVXNlcklucHV0Jyk7XG4gIC8qKlxuICAgKiBTaWduYXR1cmUgdGhhdCBhbGxvd3MgeW91ciBhZ2VudCB0byBnZW5lcmF0ZSwgcnVuLCBhbmQgdHJvdWJsZXNob290IGNvZGUgd2hlbiB0cnlpbmcgdG8gY29tcGxldGUgYSB0YXNrLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBDT0RFX0lOVEVSUFJFVEVSID0gbmV3IFBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlKCdBTUFaT04uQ29kZUludGVycHJldGVyJyk7XG4gIC8qKlxuICAgKiBDb25zdHJ1Y3RvciBzaG91bGQgYmUgdXNlZCBhcyBhIHRlbXBvcmFyeSBzb2x1dGlvbiB3aGVuIGEgbmV3IHNpZ25hdHVyZSBpcyBzdXBwb3J0ZWQgYnV0IGl0cyBpbXBsZW1lbnRhdGlvbiBpbiBDREsgaGFzbid0IGJlZW4gYWRkZWQgeWV0LlxuICAgKi9cbiAgY29uc3RydWN0b3IoXG4gICAgLyoqXG4gICAgICogVGhlIEFXUy1kZWZpbmVkIHNpZ25hdHVyZSB2YWx1ZSBmb3IgdGhpcyBhY3Rpb24gZ3JvdXAgY2FwYWJpbGl0eS5cbiAgICAgKi9cbiAgICBwdWJsaWMgcmVhZG9ubHkgdmFsdWU6IHN0cmluZyxcbiAgKSB7fVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBzdHJpbmcgcmVwcmVzZW50YXRpb24gb2YgdGhlIHNpZ25hdHVyZSB2YWx1ZS5cbiAgICogVXNlZCB3aGVuIGNvbmZpZ3VyaW5nIHRoZSBhY3Rpb24gZ3JvdXAgaW4gQ2xvdWRGb3JtYXRpb24uXG4gICAqL1xuICBwdWJsaWMgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIHRoaXMudmFsdWU7XG4gIH1cbn1cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgIFBST1BTIC0gQWN0aW9uIEdyb3VwIENsYXNzXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5leHBvcnQgaW50ZXJmYWNlIEFnZW50QWN0aW9uR3JvdXBQcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgYWN0aW9uIGdyb3VwLlxuICAgKiBAZGVmYXVsdCAtIEEgdW5pcXVlIG5hbWUgaXMgZ2VuZXJhdGVkIGluIHRoZSBmb3JtYXQgJ2FjdGlvbl9ncm91cF9xdWlja19zdGFydF9VVUlEJ1xuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcblxuICAvKipcbiAgICogQSBkZXNjcmlwdGlvbiBvZiB0aGUgYWN0aW9uIGdyb3VwLlxuICAgKlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBkZXNjcmlwdGlvbiBpcyBwcm92aWRlZFxuICAgKi9cbiAgcmVhZG9ubHkgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBBUEkgU2NoZW1hIGRlZmluaW5nIHRoZSBmdW5jdGlvbnMgYXZhaWxhYmxlIHRvIHRoZSBhZ2VudC5cbiAgICpcbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8gQVBJIFNjaGVtYSBpcyBwcm92aWRlZFxuICAgKi9cbiAgcmVhZG9ubHkgYXBpU2NoZW1hPzogQXBpU2NoZW1hO1xuXG4gIC8qKlxuICAgKiBUaGUgYWN0aW9uIGdyb3VwIGV4ZWN1dG9yIHRoYXQgaW1wbGVtZW50cyB0aGUgQVBJIGZ1bmN0aW9ucy5cbiAgICpcbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8gZXhlY3V0b3IgaXMgcHJvdmlkZWRcbiAgICovXG4gIHJlYWRvbmx5IGV4ZWN1dG9yPzogQWN0aW9uR3JvdXBFeGVjdXRvcjtcblxuICAvKipcbiAgICogU3BlY2lmaWVzIHdoZXRoZXIgdGhlIGFjdGlvbiBncm91cCBpcyBhdmFpbGFibGUgZm9yIHRoZSBhZ2VudCB0byBpbnZva2Ugb3JcbiAgICogbm90IHdoZW4gc2VuZGluZyBhbiBJbnZva2VBZ2VudCByZXF1ZXN0LlxuICAgKlxuICAgKiBAZGVmYXVsdCB0cnVlIC0gVGhlIGFjdGlvbiBncm91cCBpcyBlbmFibGVkXG4gICAqL1xuICByZWFkb25seSBlbmFibGVkPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogU3BlY2lmaWVzIHdoZXRoZXIgdG8gZGVsZXRlIHRoZSByZXNvdXJjZSBldmVuIGlmIGl0J3MgaW4gdXNlLlxuICAgKlxuICAgKiBAZGVmYXVsdCBmYWxzZSAtIFRoZSByZXNvdXJjZSB3aWxsIG5vdCBiZSBkZWxldGVkIGlmIGl0J3MgaW4gdXNlXG4gICAqL1xuICByZWFkb25seSBmb3JjZURlbGV0ZT86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIERlZmluZXMgZnVuY3Rpb25zIHRoYXQgZWFjaCBkZWZpbmUgcGFyYW1ldGVycyB0aGF0IHRoZSBhZ2VudCBuZWVkcyB0byBpbnZva2UgZnJvbSB0aGUgdXNlci5cbiAgICogTk8gTDIgeWV0IGFzIHRoaXMgZG9lc24ndCBtYWtlIG11Y2ggc2Vuc2UgSU1ITy5cbiAgICpcbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8gZnVuY3Rpb24gc2NoZW1hIGlzIHByb3ZpZGVkXG4gICAqL1xuICByZWFkb25seSBmdW5jdGlvblNjaGVtYT86IEZ1bmN0aW9uU2NoZW1hO1xuXG4gIC8qKlxuICAgKiBUaGUgQVdTIERlZmluZWQgc2lnbmF0dXJlIGZvciBlbmFibGluZyBjZXJ0YWluIGNhcGFiaWxpdGllcyBpbiB5b3VyIGFnZW50LlxuICAgKiBXaGVuIHRoaXMgcHJvcGVydHkgaXMgc3BlY2lmaWVkLCB5b3UgbXVzdCBsZWF2ZSB0aGUgZGVzY3JpcHRpb24sIGFwaVNjaGVtYSxcbiAgICogYW5kIGFjdGlvbkdyb3VwRXhlY3V0b3IgZmllbGRzIGJsYW5rIGZvciB0aGlzIGFjdGlvbiBncm91cC5cbiAgICpcbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8gcGFyZW50IGFjdGlvbiBncm91cCBzaWduYXR1cmUgaXMgcHJvdmlkZWRcbiAgICovXG4gIHJlYWRvbmx5IHBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlPzogUGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmU7XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgIERFRiAtIEFjdGlvbiBHcm91cCBDbGFzc1xuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG5leHBvcnQgY2xhc3MgQWdlbnRBY3Rpb25Hcm91cCB7XG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBTdGF0aWMgQ29uc3RydWN0b3JzXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvKipcbiAgICogRGVmaW5lcyBhbiBhY3Rpb24gZ3JvdXAgdGhhdCBhbGxvd3MgeW91ciBhZ2VudCB0byByZXF1ZXN0IHRoZSB1c2VyIGZvclxuICAgKiBhZGRpdGlvbmFsIGluZm9ybWF0aW9uIHdoZW4gdHJ5aW5nIHRvIGNvbXBsZXRlIGEgdGFzay5cbiAgICogQHBhcmFtIGVuYWJsZWQgU3BlY2lmaWVzIHdoZXRoZXIgdGhlIGFjdGlvbiBncm91cCBpcyBhdmFpbGFibGUgZm9yIHRoZSBhZ2VudFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyB1c2VySW5wdXQoZW5hYmxlZDogYm9vbGVhbik6IEFnZW50QWN0aW9uR3JvdXAge1xuICAgIHJldHVybiBuZXcgQWdlbnRBY3Rpb25Hcm91cCh7XG4gICAgICBuYW1lOiAnVXNlcklucHV0QWN0aW9uJyxcbiAgICAgIGVuYWJsZWQ6IGVuYWJsZWQsXG4gICAgICBwYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZTogUGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmUuVVNFUl9JTlBVVCxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGFuIGFjdGlvbiBncm91cCB0aGF0IGFsbG93cyB5b3VyIGFnZW50IHRvIHJlcXVlc3QgdGhlIHVzZXIgZm9yXG4gICAqIGFkZGl0aW9uYWwgaW5mb3JtYXRpb24gd2hlbiB0cnlpbmcgdG8gY29tcGxldGUgYSB0YXNrLlxuICAgKiBAcGFyYW0gZW5hYmxlZCBTcGVjaWZpZXMgd2hldGhlciB0aGUgYWN0aW9uIGdyb3VwIGlzIGF2YWlsYWJsZSBmb3IgdGhlIGFnZW50XG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGNvZGVJbnRlcnByZXRlcihlbmFibGVkOiBib29sZWFuKTogQWdlbnRBY3Rpb25Hcm91cCB7XG4gICAgcmV0dXJuIG5ldyBBZ2VudEFjdGlvbkdyb3VwKHtcbiAgICAgIG5hbWU6ICdDb2RlSW50ZXJwcmV0ZXJBY3Rpb24nLFxuICAgICAgZW5hYmxlZDogZW5hYmxlZCxcbiAgICAgIHBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlOiBQYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZS5DT0RFX0lOVEVSUFJFVEVSLFxuICAgIH0pO1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEF0dHJpYnV0ZXNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgYWN0aW9uIGdyb3VwLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcbiAgLyoqXG4gICAqIEEgZGVzY3JpcHRpb24gb2YgdGhlIGFjdGlvbiBncm91cC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBkZXNjcmlwdGlvbj86IHN0cmluZztcbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhpcyBhY3Rpb24gZ3JvdXAgaXMgYXZhaWxhYmxlIGZvciB0aGUgYWdlbnQgdG8gaW52b2tlIG9yIG5vdC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBlbmFibGVkOiBib29sZWFuO1xuICAvKipcbiAgICogVGhlIGFwaSBzY2hlbWEgZm9yIHRoaXMgYWN0aW9uIGdyb3VwIChpZiBkZWZpbmVkKS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBhcGlTY2hlbWE/OiBBcGlTY2hlbWE7XG4gIC8qKlxuICAgKiBUaGUgYWN0aW9uIGdyb3VwIGV4ZWN1dG9yIGZvciB0aGlzIGFjdGlvbiBncm91cCAoaWYgZGVmaW5lZCkuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZXhlY3V0b3I/OiBBY3Rpb25Hcm91cEV4ZWN1dG9yO1xuICAvKipcbiAgICogV2hldGhlciB0byBkZWxldGUgdGhlIHJlc291cmNlIGV2ZW4gaWYgaXQncyBpbiB1c2UuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZm9yY2VEZWxldGU/OiBib29sZWFuO1xuICAvKipcbiAgICogVGhlIGZ1bmN0aW9uIHNjaGVtYSBmb3IgdGhpcyBhY3Rpb24gZ3JvdXAgKGlmIGRlZmluZWQpLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGZ1bmN0aW9uU2NoZW1hPzogRnVuY3Rpb25TY2hlbWE7XG4gIC8qKlxuICAgKiBUaGUgQVdTIERlZmluZWQgc2lnbmF0dXJlIChpZiBkZWZpbmVkKS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBwYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZT86IFBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlO1xuXG4gIHB1YmxpYyBjb25zdHJ1Y3Rvcihwcm9wczogQWdlbnRBY3Rpb25Hcm91cFByb3BzKSB7XG4gICAgLy8gVmFsaWRhdGUgUHJvcHNcbiAgICB0aGlzLnZhbGlkYXRlUHJvcHMocHJvcHMpO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gU2V0IGF0dHJpYnV0ZXMgb3IgZGVmYXVsdHNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLm5hbWUgPSBwcm9wcy5uYW1lID8/IGBhY3Rpb25fZ3JvdXBfcXVpY2tfc3RhcnRfJHtjcnlwdG8ucmFuZG9tVVVJRCgpfWA7XG4gICAgdGhpcy5kZXNjcmlwdGlvbiA9IHByb3BzLmRlc2NyaXB0aW9uO1xuICAgIHRoaXMuYXBpU2NoZW1hID0gcHJvcHMuYXBpU2NoZW1hO1xuICAgIHRoaXMuZXhlY3V0b3IgPSBwcm9wcy5leGVjdXRvcjtcbiAgICB0aGlzLmVuYWJsZWQgPSBwcm9wcy5lbmFibGVkID8/IHRydWU7XG4gICAgdGhpcy5mb3JjZURlbGV0ZSA9IHByb3BzLmZvcmNlRGVsZXRlID8/IGZhbHNlO1xuICAgIHRoaXMuZnVuY3Rpb25TY2hlbWEgPSBwcm9wcy5mdW5jdGlvblNjaGVtYTtcbiAgICB0aGlzLnBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlID0gcHJvcHMucGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmU7XG4gIH1cblxuICBwcml2YXRlIHZhbGlkYXRlUHJvcHMocHJvcHM6IEFnZW50QWN0aW9uR3JvdXBQcm9wcykge1xuICAgIGlmIChwcm9wcy5wYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZSAmJiAocHJvcHMuZGVzY3JpcHRpb24gfHwgcHJvcHMuYXBpU2NoZW1hIHx8IHByb3BzLmV4ZWN1dG9yKSkge1xuICAgICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKFxuICAgICAgICAnV2hlbiBwYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZSBpcyBzcGVjaWZpZWQsIHlvdSBtdXN0IGxlYXZlIHRoZSBkZXNjcmlwdGlvbiwgJyArXG4gICAgICAgICAgJ2FwaVNjaGVtYSwgYW5kIGFjdGlvbkdyb3VwRXhlY3V0b3IgZmllbGRzIGJsYW5rIGZvciB0aGlzIGFjdGlvbiBncm91cCcsXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBGb3JtYXQgYXMgQ0ZOIHByb3BlcnRpZXNcbiAgICpcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBDZm5BZ2VudC5BZ2VudEFjdGlvbkdyb3VwUHJvcGVydHkge1xuICAgIHJldHVybiB7XG4gICAgICBhY3Rpb25Hcm91cEV4ZWN1dG9yOiB0aGlzLmV4ZWN1dG9yPy5fcmVuZGVyKCksXG4gICAgICBhY3Rpb25Hcm91cE5hbWU6IHRoaXMubmFtZSxcbiAgICAgIGFjdGlvbkdyb3VwU3RhdGU6IHRoaXMuZW5hYmxlZCA/ICdFTkFCTEVEJyA6ICdESVNBQkxFRCcsXG4gICAgICBhcGlTY2hlbWE6IHRoaXMuYXBpU2NoZW1hPy5fcmVuZGVyKCksXG4gICAgICBkZXNjcmlwdGlvbjogdGhpcy5kZXNjcmlwdGlvbixcbiAgICAgIGZ1bmN0aW9uU2NoZW1hOiB0aGlzLmZ1bmN0aW9uU2NoZW1hPy5fcmVuZGVyKCksXG4gICAgICBwYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZTogdGhpcy5wYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZT8udG9TdHJpbmcoKSxcbiAgICAgIHNraXBSZXNvdXJjZUluVXNlQ2hlY2tPbkRlbGV0ZTogdGhpcy5mb3JjZURlbGV0ZSxcbiAgICB9O1xuICB9XG59XG4iXX0=