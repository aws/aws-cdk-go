"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentCollaborator = exports.AgentCollaboratorType = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
/**
 * Enum for collaborator's relay conversation history types.
 */
var AgentCollaboratorType;
(function (AgentCollaboratorType) {
    /**
     * Supervisor agent.
     */
    AgentCollaboratorType["SUPERVISOR"] = "SUPERVISOR";
    /**
     * Disabling collaboration.
     */
    AgentCollaboratorType["DISABLED"] = "DISABLED";
    /**
     * Supervisor router.
     */
    AgentCollaboratorType["SUPERVISOR_ROUTER"] = "SUPERVISOR_ROUTER";
})(AgentCollaboratorType || (exports.AgentCollaboratorType = AgentCollaboratorType = {}));
/**
 * Enum for collaborator's relay conversation history types.
 * @internal
 */
var RelayConversationHistoryType;
(function (RelayConversationHistoryType) {
    /**
     * Sending to the collaborator.
     */
    RelayConversationHistoryType["TO_COLLABORATOR"] = "TO_COLLABORATOR";
    /**
     * Disabling relay of conversation history to the collaborator.
     */
    RelayConversationHistoryType["DISABLED"] = "DISABLED";
})(RelayConversationHistoryType || (RelayConversationHistoryType = {}));
/******************************************************************************
 *                         Agent Collaborator Class
 *****************************************************************************/
class AgentCollaborator {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AgentCollaborator", version: "2.243.0-alpha.0" };
    /**
     * The agent alias that this collaborator represents.
     * This is the agent that will be called upon for collaboration.
     */
    agentAlias;
    /**
     * Instructions on how this agent should collaborate with the main agent.
     */
    collaborationInstruction;
    /**
     * A friendly name for the collaborator.
     */
    collaboratorName;
    /**
     * Whether to relay conversation history to this collaborator.
     *
     * @default - undefined (uses service default)
     */
    relayConversationHistory;
    constructor(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentCollaboratorProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, AgentCollaborator);
            }
            throw error;
        }
        // Validate Props
        this.validateProps(props);
        // ------------------------------------------------------
        // Set attributes or defaults
        // ------------------------------------------------------
        this.agentAlias = props.agentAlias;
        this.collaborationInstruction = props.collaborationInstruction;
        this.collaboratorName = props.collaboratorName;
        this.relayConversationHistory = props.relayConversationHistory;
    }
    validateProps(props) {
        if (props.agentAlias.aliasId === 'TSTALIASID') {
            throw new errors_1.UnscopedValidationError('Agent cannot collaborate with TSTALIASID alias of another agent');
        }
    }
    /**
     * Format as CFN properties
     *
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            agentDescriptor: {
                aliasArn: this.agentAlias.aliasArn,
            },
            collaborationInstruction: this.collaborationInstruction,
            collaboratorName: this.collaboratorName,
            relayConversationHistory: this.relayConversationHistory ? RelayConversationHistoryType.TO_COLLABORATOR : RelayConversationHistoryType.DISABLED,
        };
    }
    /**
     * Grants the given identity permissions to collaborate with the agent
     * [disable-awslint:no-grants]
     * @param grantee The principal to grant permissions to
     * @returns The Grant object
     */
    grant(grantee) {
        const grant1 = this.agentAlias.grantInvoke(grantee);
        const combinedGrant = grant1.combine(this.agentAlias.grantGet(grantee));
        return combinedGrant;
    }
}
exports.AgentCollaborator = AgentCollaborator;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWdlbnQtY29sbGFib3JhdG9yLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYWdlbnQtY29sbGFib3JhdG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBRUEsd0RBQXNFO0FBR3RFOztHQUVHO0FBQ0gsSUFBWSxxQkFlWDtBQWZELFdBQVkscUJBQXFCO0lBQy9COztPQUVHO0lBQ0gsa0RBQXlCLENBQUE7SUFFekI7O09BRUc7SUFDSCw4Q0FBcUIsQ0FBQTtJQUVyQjs7T0FFRztJQUNILGdFQUF1QyxDQUFBO0FBQ3pDLENBQUMsRUFmVyxxQkFBcUIscUNBQXJCLHFCQUFxQixRQWVoQztBQUVEOzs7R0FHRztBQUNILElBQUssNEJBVUo7QUFWRCxXQUFLLDRCQUE0QjtJQUMvQjs7T0FFRztJQUNILG1FQUFtQyxDQUFBO0lBRW5DOztPQUVHO0lBQ0gscURBQXFCLENBQUE7QUFDdkIsQ0FBQyxFQVZJLDRCQUE0QixLQUE1Qiw0QkFBNEIsUUFVaEM7QUE4QkQ7OytFQUUrRTtBQUUvRSxNQUFhLGlCQUFpQjs7SUFDNUI7OztPQUdHO0lBQ2EsVUFBVSxDQUFjO0lBRXhDOztPQUVHO0lBQ2Esd0JBQXdCLENBQVM7SUFFakQ7O09BRUc7SUFDYSxnQkFBZ0IsQ0FBUztJQUV6Qzs7OztPQUlHO0lBQ2Esd0JBQXdCLENBQVc7SUFFbkQsWUFBbUIsS0FBNkI7Ozs7OzsrQ0F4QnJDLGlCQUFpQjs7OztRQXlCMUIsaUJBQWlCO1FBQ2pCLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFMUIseURBQXlEO1FBQ3pELDZCQUE2QjtRQUM3Qix5REFBeUQ7UUFDekQsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUMsVUFBVSxDQUFDO1FBQ25DLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxLQUFLLENBQUMsd0JBQXdCLENBQUM7UUFDL0QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQztRQUMvQyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsS0FBSyxDQUFDLHdCQUF3QixDQUFDO0tBQ2hFO0lBRU8sYUFBYSxDQUFDLEtBQTZCO1FBQ2pELElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEtBQUssWUFBWSxFQUFFLENBQUM7WUFDOUMsTUFBTSxJQUFJLGdDQUF1QixDQUFDLGlFQUFpRSxDQUFDLENBQUM7UUFDdkcsQ0FBQztLQUNGO0lBRUQ7Ozs7T0FJRztJQUNJLE9BQU87UUFDWixPQUFPO1lBQ0wsZUFBZSxFQUFFO2dCQUNmLFFBQVEsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVE7YUFDbkM7WUFDRCx3QkFBd0IsRUFBRSxJQUFJLENBQUMsd0JBQXdCO1lBQ3ZELGdCQUFnQixFQUFFLElBQUksQ0FBQyxnQkFBZ0I7WUFDdkMsd0JBQXdCLEVBQUUsSUFBSSxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyw0QkFBNEIsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLFFBQVE7U0FDL0ksQ0FBQztLQUNIO0lBRUQ7Ozs7O09BS0c7SUFDSSxLQUFLLENBQUMsT0FBbUI7UUFDOUIsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDcEQsTUFBTSxhQUFhLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQ3hFLE9BQU8sYUFBYSxDQUFDO0tBQ3RCOztBQXJFSCw4Q0FzRUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IENmbkFnZW50IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHR5cGUgeyBJR3JhbnRhYmxlLCBHcmFudCB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0IHsgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9lcnJvcnMnO1xuaW1wb3J0IHR5cGUgeyBJQWdlbnRBbGlhcyB9IGZyb20gJy4vYWdlbnQtYWxpYXMnO1xuXG4vKipcbiAqIEVudW0gZm9yIGNvbGxhYm9yYXRvcidzIHJlbGF5IGNvbnZlcnNhdGlvbiBoaXN0b3J5IHR5cGVzLlxuICovXG5leHBvcnQgZW51bSBBZ2VudENvbGxhYm9yYXRvclR5cGUge1xuICAvKipcbiAgICogU3VwZXJ2aXNvciBhZ2VudC5cbiAgICovXG4gIFNVUEVSVklTT1IgPSAnU1VQRVJWSVNPUicsXG5cbiAgLyoqXG4gICAqIERpc2FibGluZyBjb2xsYWJvcmF0aW9uLlxuICAgKi9cbiAgRElTQUJMRUQgPSAnRElTQUJMRUQnLFxuXG4gIC8qKlxuICAgKiBTdXBlcnZpc29yIHJvdXRlci5cbiAgICovXG4gIFNVUEVSVklTT1JfUk9VVEVSID0gJ1NVUEVSVklTT1JfUk9VVEVSJyxcbn1cblxuLyoqXG4gKiBFbnVtIGZvciBjb2xsYWJvcmF0b3IncyByZWxheSBjb252ZXJzYXRpb24gaGlzdG9yeSB0eXBlcy5cbiAqIEBpbnRlcm5hbFxuICovXG5lbnVtIFJlbGF5Q29udmVyc2F0aW9uSGlzdG9yeVR5cGUge1xuICAvKipcbiAgICogU2VuZGluZyB0byB0aGUgY29sbGFib3JhdG9yLlxuICAgKi9cbiAgVE9fQ09MTEFCT1JBVE9SID0gJ1RPX0NPTExBQk9SQVRPUicsXG5cbiAgLyoqXG4gICAqIERpc2FibGluZyByZWxheSBvZiBjb252ZXJzYXRpb24gaGlzdG9yeSB0byB0aGUgY29sbGFib3JhdG9yLlxuICAgKi9cbiAgRElTQUJMRUQgPSAnRElTQUJMRUQnLFxufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgUFJPUFMgLSBBZ2VudCBDb2xsYWJvcmF0b3IgQ2xhc3NcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbmV4cG9ydCBpbnRlcmZhY2UgQWdlbnRDb2xsYWJvcmF0b3JQcm9wcyB7XG4gIC8qKlxuICAgKiBEZXNjcmlwdG9yIGZvciB0aGUgY29sbGFib3JhdGluZyBhZ2VudC5cbiAgICogVGhpcyBjYW5ub3QgYmUgdGhlIFRTVEFMSUFTSUQgKGBhZ2VudC50ZXN0QWxpYXNgKS5cbiAgICovXG4gIHJlYWRvbmx5IGFnZW50QWxpYXM6IElBZ2VudEFsaWFzO1xuXG4gIC8qKlxuICAgKiBJbnN0cnVjdGlvbnMgb24gaG93IHRoaXMgYWdlbnQgc2hvdWxkIGNvbGxhYm9yYXRlIHdpdGggdGhlIG1haW4gYWdlbnQuXG4gICAqL1xuICByZWFkb25seSBjb2xsYWJvcmF0aW9uSW5zdHJ1Y3Rpb246IHN0cmluZztcblxuICAvKipcbiAgICogQSBmcmllbmRseSBuYW1lIGZvciB0aGUgY29sbGFib3JhdG9yLlxuICAgKi9cbiAgcmVhZG9ubHkgY29sbGFib3JhdG9yTmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIHJlbGF5IGNvbnZlcnNhdGlvbiBoaXN0b3J5IHRvIHRoaXMgY29sbGFib3JhdG9yLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIHVuZGVmaW5lZCAodXNlcyBzZXJ2aWNlIGRlZmF1bHQpXG4gICAqL1xuICByZWFkb25seSByZWxheUNvbnZlcnNhdGlvbkhpc3Rvcnk/OiBib29sZWFuO1xufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICBBZ2VudCBDb2xsYWJvcmF0b3IgQ2xhc3NcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cblxuZXhwb3J0IGNsYXNzIEFnZW50Q29sbGFib3JhdG9yIHtcbiAgLyoqXG4gICAqIFRoZSBhZ2VudCBhbGlhcyB0aGF0IHRoaXMgY29sbGFib3JhdG9yIHJlcHJlc2VudHMuXG4gICAqIFRoaXMgaXMgdGhlIGFnZW50IHRoYXQgd2lsbCBiZSBjYWxsZWQgdXBvbiBmb3IgY29sbGFib3JhdGlvbi5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBhZ2VudEFsaWFzOiBJQWdlbnRBbGlhcztcblxuICAvKipcbiAgICogSW5zdHJ1Y3Rpb25zIG9uIGhvdyB0aGlzIGFnZW50IHNob3VsZCBjb2xsYWJvcmF0ZSB3aXRoIHRoZSBtYWluIGFnZW50LlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGNvbGxhYm9yYXRpb25JbnN0cnVjdGlvbjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBBIGZyaWVuZGx5IG5hbWUgZm9yIHRoZSBjb2xsYWJvcmF0b3IuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgY29sbGFib3JhdG9yTmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIHJlbGF5IGNvbnZlcnNhdGlvbiBoaXN0b3J5IHRvIHRoaXMgY29sbGFib3JhdG9yLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIHVuZGVmaW5lZCAodXNlcyBzZXJ2aWNlIGRlZmF1bHQpXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgcmVsYXlDb252ZXJzYXRpb25IaXN0b3J5PzogYm9vbGVhbjtcblxuICBwdWJsaWMgY29uc3RydWN0b3IocHJvcHM6IEFnZW50Q29sbGFib3JhdG9yUHJvcHMpIHtcbiAgICAvLyBWYWxpZGF0ZSBQcm9wc1xuICAgIHRoaXMudmFsaWRhdGVQcm9wcyhwcm9wcyk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBTZXQgYXR0cmlidXRlcyBvciBkZWZhdWx0c1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMuYWdlbnRBbGlhcyA9IHByb3BzLmFnZW50QWxpYXM7XG4gICAgdGhpcy5jb2xsYWJvcmF0aW9uSW5zdHJ1Y3Rpb24gPSBwcm9wcy5jb2xsYWJvcmF0aW9uSW5zdHJ1Y3Rpb247XG4gICAgdGhpcy5jb2xsYWJvcmF0b3JOYW1lID0gcHJvcHMuY29sbGFib3JhdG9yTmFtZTtcbiAgICB0aGlzLnJlbGF5Q29udmVyc2F0aW9uSGlzdG9yeSA9IHByb3BzLnJlbGF5Q29udmVyc2F0aW9uSGlzdG9yeTtcbiAgfVxuXG4gIHByaXZhdGUgdmFsaWRhdGVQcm9wcyhwcm9wczogQWdlbnRDb2xsYWJvcmF0b3JQcm9wcykge1xuICAgIGlmIChwcm9wcy5hZ2VudEFsaWFzLmFsaWFzSWQgPT09ICdUU1RBTElBU0lEJykge1xuICAgICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKCdBZ2VudCBjYW5ub3QgY29sbGFib3JhdGUgd2l0aCBUU1RBTElBU0lEIGFsaWFzIG9mIGFub3RoZXIgYWdlbnQnKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRm9ybWF0IGFzIENGTiBwcm9wZXJ0aWVzXG4gICAqXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIF9yZW5kZXIoKTogQ2ZuQWdlbnQuQWdlbnRDb2xsYWJvcmF0b3JQcm9wZXJ0eSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGFnZW50RGVzY3JpcHRvcjoge1xuICAgICAgICBhbGlhc0FybjogdGhpcy5hZ2VudEFsaWFzLmFsaWFzQXJuLFxuICAgICAgfSxcbiAgICAgIGNvbGxhYm9yYXRpb25JbnN0cnVjdGlvbjogdGhpcy5jb2xsYWJvcmF0aW9uSW5zdHJ1Y3Rpb24sXG4gICAgICBjb2xsYWJvcmF0b3JOYW1lOiB0aGlzLmNvbGxhYm9yYXRvck5hbWUsXG4gICAgICByZWxheUNvbnZlcnNhdGlvbkhpc3Rvcnk6IHRoaXMucmVsYXlDb252ZXJzYXRpb25IaXN0b3J5ID8gUmVsYXlDb252ZXJzYXRpb25IaXN0b3J5VHlwZS5UT19DT0xMQUJPUkFUT1IgOiBSZWxheUNvbnZlcnNhdGlvbkhpc3RvcnlUeXBlLkRJU0FCTEVELFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogR3JhbnRzIHRoZSBnaXZlbiBpZGVudGl0eSBwZXJtaXNzaW9ucyB0byBjb2xsYWJvcmF0ZSB3aXRoIHRoZSBhZ2VudFxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICogQHBhcmFtIGdyYW50ZWUgVGhlIHByaW5jaXBhbCB0byBncmFudCBwZXJtaXNzaW9ucyB0b1xuICAgKiBAcmV0dXJucyBUaGUgR3JhbnQgb2JqZWN0XG4gICAqL1xuICBwdWJsaWMgZ3JhbnQoZ3JhbnRlZTogSUdyYW50YWJsZSk6IEdyYW50IHtcbiAgICBjb25zdCBncmFudDEgPSB0aGlzLmFnZW50QWxpYXMuZ3JhbnRJbnZva2UoZ3JhbnRlZSk7XG4gICAgY29uc3QgY29tYmluZWRHcmFudCA9IGdyYW50MS5jb21iaW5lKHRoaXMuYWdlbnRBbGlhcy5ncmFudEdldChncmFudGVlKSk7XG4gICAgcmV0dXJuIGNvbWJpbmVkR3JhbnQ7XG4gIH1cbn1cbiJdfQ==