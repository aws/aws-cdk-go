"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatMessage = exports.ChatMessageRole = void 0;
exports.createChatPromptVariant = createChatPromptVariant;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const prompt_template_configuration_1 = require("./prompt-template-configuration");
const prompt_variant_1 = require("./prompt-variant");
const validation_helpers_1 = require("../agents/validation-helpers");
/**
 * The role of a message in a chat conversation.
 */
var ChatMessageRole;
(function (ChatMessageRole) {
    /**
     * This role represents the human user in the conversation. Inputs from the
     * user guide the conversation and prompt responses from the assistant.
     */
    ChatMessageRole["USER"] = "user";
    /**
     * This is the role of the model itself, responding to user inputs based on
     * the context set by the system.
     */
    ChatMessageRole["ASSISTANT"] = "assistant";
})(ChatMessageRole || (exports.ChatMessageRole = ChatMessageRole = {}));
/**
 * Represents a message in a chat conversation.
 */
class ChatMessage {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ChatMessage", version: "2.241.0-alpha.0" };
    /**
     * Creates a user message.
     *
     * @param text - The text content of the user message
     * @returns A ChatMessage instance representing a user message
     */
    static user(text) {
        return new ChatMessage(ChatMessageRole.USER, text);
    }
    /**
     * Creates an assistant message.
     *
     * @param text - The text content of the assistant message
     * @returns A ChatMessage instance representing an assistant message
     */
    static assistant(text) {
        return new ChatMessage(ChatMessageRole.ASSISTANT, text);
    }
    /**
     * The role of the message sender.
     */
    role;
    /**
     * The text content of the message.
     */
    text;
    constructor(role, text) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ChatMessageRole(role);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, ChatMessage);
            }
            throw error;
        }
        this.role = role;
        this.text = text;
    }
    /**
     * Renders the message as a CloudFormation property.
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            role: this.role,
            content: [
                {
                    text: this.text,
                },
            ],
        };
    }
}
exports.ChatMessage = ChatMessage;
/**
 * Creates a chat template variant. Use this template type when
 * the model supports the Converse API or the Anthropic Claude Messages API.
 * This allows you to include a System prompt and previous User messages
 * and Assistant messages for context.
 *
 * @param props - Properties for the chat prompt variant
 * @returns A PromptVariant configured for chat interactions
 */
function createChatPromptVariant(props) {
    // Validate that messages array is not empty
    if (!props.messages || props.messages.length === 0) {
        throw new validation_helpers_1.ValidationError('At least one message must be provided');
    }
    // Validate that the first message is a user message
    if (props.messages[0].role !== ChatMessageRole.USER) {
        throw new validation_helpers_1.ValidationError('The first message must be a User message');
    }
    // Validate that at least one user message exists
    const hasUserMessage = props.messages.some(message => message.role === ChatMessageRole.USER);
    if (!hasUserMessage) {
        throw new validation_helpers_1.ValidationError('At least one User message must be provided');
    }
    // Validate alternating pattern if more than one message
    if (props.messages.length > 1) {
        for (let i = 1; i < props.messages.length; i++) {
            const currentRole = props.messages[i].role;
            const previousRole = props.messages[i - 1].role;
            if (currentRole === previousRole) {
                throw new validation_helpers_1.ValidationError(`Messages must alternate between User and Assistant roles. Found consecutive ${currentRole} messages at positions ${i} and ${i + 1}`);
            }
        }
    }
    return {
        name: props.variantName,
        templateType: prompt_variant_1.PromptTemplateType.CHAT,
        modelId: props.model.invokableArn,
        inferenceConfiguration: props.inferenceConfiguration,
        templateConfiguration: prompt_template_configuration_1.PromptTemplateConfiguration.chat({
            inputVariables: props.promptVariables,
            messages: props.messages,
            system: props.system,
            toolConfiguration: props.toolConfiguration,
        }),
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hhdC1wcm9tcHQtdmFyaWFudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNoYXQtcHJvbXB0LXZhcmlhbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBMEhBLDBEQTJDQzs7O0FBbktELG1GQUE4RTtBQUU5RSxxREFBc0Q7QUFFdEQscUVBQStEO0FBbUMvRDs7R0FFRztBQUNILElBQVksZUFZWDtBQVpELFdBQVksZUFBZTtJQUN6Qjs7O09BR0c7SUFDSCxnQ0FBYSxDQUFBO0lBRWI7OztPQUdHO0lBQ0gsMENBQXVCLENBQUE7QUFDekIsQ0FBQyxFQVpXLGVBQWUsK0JBQWYsZUFBZSxRQVkxQjtBQUVEOztHQUVHO0FBQ0gsTUFBYSxXQUFXOztJQUN0Qjs7Ozs7T0FLRztJQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBWTtRQUM3QixPQUFPLElBQUksV0FBVyxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDcEQ7SUFFRDs7Ozs7T0FLRztJQUNJLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBWTtRQUNsQyxPQUFPLElBQUksV0FBVyxDQUFDLGVBQWUsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDekQ7SUFFRDs7T0FFRztJQUNhLElBQUksQ0FBa0I7SUFFdEM7O09BRUc7SUFDYSxJQUFJLENBQVM7SUFFN0IsWUFBWSxJQUFxQixFQUFFLElBQVk7Ozs7OzsrQ0EvQnBDLFdBQVc7Ozs7UUFnQ3BCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0tBQ2xCO0lBRUQ7OztPQUdHO0lBQ0ksT0FBTztRQUNaLE9BQU87WUFDTCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDZixPQUFPLEVBQUU7Z0JBQ1A7b0JBQ0UsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2lCQUNoQjthQUNGO1NBQ0YsQ0FBQztLQUNIOztBQWpESCxrQ0FrREM7QUFFRDs7Ozs7Ozs7R0FRRztBQUNILFNBQWdCLHVCQUF1QixDQUFDLEtBQTZCO0lBQ25FLDRDQUE0QztJQUM1QyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztRQUNuRCxNQUFNLElBQUksb0NBQWUsQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFRCxvREFBb0Q7SUFDcEQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxlQUFlLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDcEQsTUFBTSxJQUFJLG9DQUFlLENBQUMsMENBQTBDLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRUQsaURBQWlEO0lBQ2pELE1BQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDN0YsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3BCLE1BQU0sSUFBSSxvQ0FBZSxDQUFDLDRDQUE0QyxDQUFDLENBQUM7SUFDMUUsQ0FBQztJQUVELHdEQUF3RDtJQUN4RCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQzlCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQy9DLE1BQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzNDLE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUVoRCxJQUFJLFdBQVcsS0FBSyxZQUFZLEVBQUUsQ0FBQztnQkFDakMsTUFBTSxJQUFJLG9DQUFlLENBQ3ZCLCtFQUErRSxXQUFXLDBCQUEwQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUNySSxDQUFDO1lBQ0osQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsT0FBTztRQUNMLElBQUksRUFBRSxLQUFLLENBQUMsV0FBVztRQUN2QixZQUFZLEVBQUUsbUNBQWtCLENBQUMsSUFBSTtRQUNyQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZO1FBQ2pDLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxzQkFBc0I7UUFDcEQscUJBQXFCLEVBQUUsMkRBQTJCLENBQUMsSUFBSSxDQUFDO1lBQ3RELGNBQWMsRUFBRSxLQUFLLENBQUMsZUFBZTtZQUNyQyxRQUFRLEVBQUUsS0FBSyxDQUFDLFFBQVE7WUFDeEIsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNO1lBQ3BCLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxpQkFBaUI7U0FDM0MsQ0FBQztLQUNILENBQUM7QUFDSixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBDZm5Qcm9tcHQgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgdHlwZSB7IFByb21wdEluZmVyZW5jZUNvbmZpZ3VyYXRpb24gfSBmcm9tICcuL3Byb21wdC1pbmZlcmVuY2UtY29uZmlndXJhdGlvbic7XG5pbXBvcnQgeyBQcm9tcHRUZW1wbGF0ZUNvbmZpZ3VyYXRpb24gfSBmcm9tICcuL3Byb21wdC10ZW1wbGF0ZS1jb25maWd1cmF0aW9uJztcbmltcG9ydCB0eXBlIHsgQ29tbW9uUHJvbXB0VmFyaWFudFByb3BzLCBJUHJvbXB0VmFyaWFudCB9IGZyb20gJy4vcHJvbXB0LXZhcmlhbnQnO1xuaW1wb3J0IHsgUHJvbXB0VGVtcGxhdGVUeXBlIH0gZnJvbSAnLi9wcm9tcHQtdmFyaWFudCc7XG5pbXBvcnQgdHlwZSB7IFRvb2xDb25maWd1cmF0aW9uIH0gZnJvbSAnLi90b29sLWNob2ljZSc7XG5pbXBvcnQgeyBWYWxpZGF0aW9uRXJyb3IgfSBmcm9tICcuLi9hZ2VudHMvdmFsaWRhdGlvbi1oZWxwZXJzJztcblxuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBjcmVhdGluZyBhIGNoYXQgcHJvbXB0IHZhcmlhbnQuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ2hhdFByb21wdFZhcmlhbnRQcm9wcyBleHRlbmRzIENvbW1vblByb21wdFZhcmlhbnRQcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgbWVzc2FnZXMgaW4gdGhlIGNoYXQgcHJvbXB0LlxuICAgKiBNdXN0IGluY2x1ZGUgYXQgbGVhc3Qgb25lIFVzZXIgTWVzc2FnZS5cbiAgICogVGhlIG1lc3NhZ2VzIHNob3VsZCBhbHRlcm5hdGUgYmV0d2VlbiBVc2VyIGFuZCBBc3Npc3RhbnQuXG4gICAqL1xuICByZWFkb25seSBtZXNzYWdlczogQ2hhdE1lc3NhZ2VbXTtcblxuICAvKipcbiAgICogQ29udGV4dCBvciBpbnN0cnVjdGlvbnMgZm9yIHRoZSBtb2RlbCB0byBjb25zaWRlciBiZWZvcmUgZ2VuZXJhdGluZyBhIHJlc3BvbnNlLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIE5vIHN5c3RlbSBtZXNzYWdlIHByb3ZpZGVkLlxuICAgKi9cbiAgcmVhZG9ubHkgc3lzdGVtPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgY29uZmlndXJhdGlvbiB3aXRoIGF2YWlsYWJsZSB0b29scyB0byB0aGUgbW9kZWwgYW5kIGhvdyBpdCBtdXN0IHVzZSB0aGVtLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIE5vIHRvb2wgY29uZmlndXJhdGlvbiBwcm92aWRlZC5cbiAgICovXG4gIHJlYWRvbmx5IHRvb2xDb25maWd1cmF0aW9uPzogVG9vbENvbmZpZ3VyYXRpb247XG5cbiAgLyoqXG4gICAqIEluZmVyZW5jZSBjb25maWd1cmF0aW9uIGZvciB0aGUgQ2hhdCBQcm9tcHQuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTm8gaW5mZXJlbmNlIGNvbmZpZ3VyYXRpb24gcHJvdmlkZWQuXG4gICAqL1xuICByZWFkb25seSBpbmZlcmVuY2VDb25maWd1cmF0aW9uPzogUHJvbXB0SW5mZXJlbmNlQ29uZmlndXJhdGlvbjtcbn1cblxuLyoqXG4gKiBUaGUgcm9sZSBvZiBhIG1lc3NhZ2UgaW4gYSBjaGF0IGNvbnZlcnNhdGlvbi5cbiAqL1xuZXhwb3J0IGVudW0gQ2hhdE1lc3NhZ2VSb2xlIHtcbiAgLyoqXG4gICAqIFRoaXMgcm9sZSByZXByZXNlbnRzIHRoZSBodW1hbiB1c2VyIGluIHRoZSBjb252ZXJzYXRpb24uIElucHV0cyBmcm9tIHRoZVxuICAgKiB1c2VyIGd1aWRlIHRoZSBjb252ZXJzYXRpb24gYW5kIHByb21wdCByZXNwb25zZXMgZnJvbSB0aGUgYXNzaXN0YW50LlxuICAgKi9cbiAgVVNFUiA9ICd1c2VyJyxcblxuICAvKipcbiAgICogVGhpcyBpcyB0aGUgcm9sZSBvZiB0aGUgbW9kZWwgaXRzZWxmLCByZXNwb25kaW5nIHRvIHVzZXIgaW5wdXRzIGJhc2VkIG9uXG4gICAqIHRoZSBjb250ZXh0IHNldCBieSB0aGUgc3lzdGVtLlxuICAgKi9cbiAgQVNTSVNUQU5UID0gJ2Fzc2lzdGFudCcsXG59XG5cbi8qKlxuICogUmVwcmVzZW50cyBhIG1lc3NhZ2UgaW4gYSBjaGF0IGNvbnZlcnNhdGlvbi5cbiAqL1xuZXhwb3J0IGNsYXNzIENoYXRNZXNzYWdlIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSB1c2VyIG1lc3NhZ2UuXG4gICAqXG4gICAqIEBwYXJhbSB0ZXh0IC0gVGhlIHRleHQgY29udGVudCBvZiB0aGUgdXNlciBtZXNzYWdlXG4gICAqIEByZXR1cm5zIEEgQ2hhdE1lc3NhZ2UgaW5zdGFuY2UgcmVwcmVzZW50aW5nIGEgdXNlciBtZXNzYWdlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHVzZXIodGV4dDogc3RyaW5nKTogQ2hhdE1lc3NhZ2Uge1xuICAgIHJldHVybiBuZXcgQ2hhdE1lc3NhZ2UoQ2hhdE1lc3NhZ2VSb2xlLlVTRVIsIHRleHQpO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYW4gYXNzaXN0YW50IG1lc3NhZ2UuXG4gICAqXG4gICAqIEBwYXJhbSB0ZXh0IC0gVGhlIHRleHQgY29udGVudCBvZiB0aGUgYXNzaXN0YW50IG1lc3NhZ2VcbiAgICogQHJldHVybnMgQSBDaGF0TWVzc2FnZSBpbnN0YW5jZSByZXByZXNlbnRpbmcgYW4gYXNzaXN0YW50IG1lc3NhZ2VcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgYXNzaXN0YW50KHRleHQ6IHN0cmluZyk6IENoYXRNZXNzYWdlIHtcbiAgICByZXR1cm4gbmV3IENoYXRNZXNzYWdlKENoYXRNZXNzYWdlUm9sZS5BU1NJU1RBTlQsIHRleHQpO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSByb2xlIG9mIHRoZSBtZXNzYWdlIHNlbmRlci5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSByb2xlOiBDaGF0TWVzc2FnZVJvbGU7XG5cbiAgLyoqXG4gICAqIFRoZSB0ZXh0IGNvbnRlbnQgb2YgdGhlIG1lc3NhZ2UuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgdGV4dDogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKHJvbGU6IENoYXRNZXNzYWdlUm9sZSwgdGV4dDogc3RyaW5nKSB7XG4gICAgdGhpcy5yb2xlID0gcm9sZTtcbiAgICB0aGlzLnRleHQgPSB0ZXh0O1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgdGhlIG1lc3NhZ2UgYXMgYSBDbG91ZEZvcm1hdGlvbiBwcm9wZXJ0eS5cbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBDZm5Qcm9tcHQuTWVzc2FnZVByb3BlcnR5IHtcbiAgICByZXR1cm4ge1xuICAgICAgcm9sZTogdGhpcy5yb2xlLFxuICAgICAgY29udGVudDogW1xuICAgICAgICB7XG4gICAgICAgICAgdGV4dDogdGhpcy50ZXh0LFxuICAgICAgICB9LFxuICAgICAgXSxcbiAgICB9O1xuICB9XG59XG5cbi8qKlxuICogQ3JlYXRlcyBhIGNoYXQgdGVtcGxhdGUgdmFyaWFudC4gVXNlIHRoaXMgdGVtcGxhdGUgdHlwZSB3aGVuXG4gKiB0aGUgbW9kZWwgc3VwcG9ydHMgdGhlIENvbnZlcnNlIEFQSSBvciB0aGUgQW50aHJvcGljIENsYXVkZSBNZXNzYWdlcyBBUEkuXG4gKiBUaGlzIGFsbG93cyB5b3UgdG8gaW5jbHVkZSBhIFN5c3RlbSBwcm9tcHQgYW5kIHByZXZpb3VzIFVzZXIgbWVzc2FnZXNcbiAqIGFuZCBBc3Npc3RhbnQgbWVzc2FnZXMgZm9yIGNvbnRleHQuXG4gKlxuICogQHBhcmFtIHByb3BzIC0gUHJvcGVydGllcyBmb3IgdGhlIGNoYXQgcHJvbXB0IHZhcmlhbnRcbiAqIEByZXR1cm5zIEEgUHJvbXB0VmFyaWFudCBjb25maWd1cmVkIGZvciBjaGF0IGludGVyYWN0aW9uc1xuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlQ2hhdFByb21wdFZhcmlhbnQocHJvcHM6IENoYXRQcm9tcHRWYXJpYW50UHJvcHMpOiBJUHJvbXB0VmFyaWFudCB7XG4gIC8vIFZhbGlkYXRlIHRoYXQgbWVzc2FnZXMgYXJyYXkgaXMgbm90IGVtcHR5XG4gIGlmICghcHJvcHMubWVzc2FnZXMgfHwgcHJvcHMubWVzc2FnZXMubGVuZ3RoID09PSAwKSB7XG4gICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignQXQgbGVhc3Qgb25lIG1lc3NhZ2UgbXVzdCBiZSBwcm92aWRlZCcpO1xuICB9XG5cbiAgLy8gVmFsaWRhdGUgdGhhdCB0aGUgZmlyc3QgbWVzc2FnZSBpcyBhIHVzZXIgbWVzc2FnZVxuICBpZiAocHJvcHMubWVzc2FnZXNbMF0ucm9sZSAhPT0gQ2hhdE1lc3NhZ2VSb2xlLlVTRVIpIHtcbiAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdUaGUgZmlyc3QgbWVzc2FnZSBtdXN0IGJlIGEgVXNlciBtZXNzYWdlJyk7XG4gIH1cblxuICAvLyBWYWxpZGF0ZSB0aGF0IGF0IGxlYXN0IG9uZSB1c2VyIG1lc3NhZ2UgZXhpc3RzXG4gIGNvbnN0IGhhc1VzZXJNZXNzYWdlID0gcHJvcHMubWVzc2FnZXMuc29tZShtZXNzYWdlID0+IG1lc3NhZ2Uucm9sZSA9PT0gQ2hhdE1lc3NhZ2VSb2xlLlVTRVIpO1xuICBpZiAoIWhhc1VzZXJNZXNzYWdlKSB7XG4gICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignQXQgbGVhc3Qgb25lIFVzZXIgbWVzc2FnZSBtdXN0IGJlIHByb3ZpZGVkJyk7XG4gIH1cblxuICAvLyBWYWxpZGF0ZSBhbHRlcm5hdGluZyBwYXR0ZXJuIGlmIG1vcmUgdGhhbiBvbmUgbWVzc2FnZVxuICBpZiAocHJvcHMubWVzc2FnZXMubGVuZ3RoID4gMSkge1xuICAgIGZvciAobGV0IGkgPSAxOyBpIDwgcHJvcHMubWVzc2FnZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGN1cnJlbnRSb2xlID0gcHJvcHMubWVzc2FnZXNbaV0ucm9sZTtcbiAgICAgIGNvbnN0IHByZXZpb3VzUm9sZSA9IHByb3BzLm1lc3NhZ2VzW2kgLSAxXS5yb2xlO1xuXG4gICAgICBpZiAoY3VycmVudFJvbGUgPT09IHByZXZpb3VzUm9sZSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKFxuICAgICAgICAgIGBNZXNzYWdlcyBtdXN0IGFsdGVybmF0ZSBiZXR3ZWVuIFVzZXIgYW5kIEFzc2lzdGFudCByb2xlcy4gRm91bmQgY29uc2VjdXRpdmUgJHtjdXJyZW50Um9sZX0gbWVzc2FnZXMgYXQgcG9zaXRpb25zICR7aX0gYW5kICR7aSArIDF9YCxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICByZXR1cm4ge1xuICAgIG5hbWU6IHByb3BzLnZhcmlhbnROYW1lLFxuICAgIHRlbXBsYXRlVHlwZTogUHJvbXB0VGVtcGxhdGVUeXBlLkNIQVQsXG4gICAgbW9kZWxJZDogcHJvcHMubW9kZWwuaW52b2thYmxlQXJuLFxuICAgIGluZmVyZW5jZUNvbmZpZ3VyYXRpb246IHByb3BzLmluZmVyZW5jZUNvbmZpZ3VyYXRpb24sXG4gICAgdGVtcGxhdGVDb25maWd1cmF0aW9uOiBQcm9tcHRUZW1wbGF0ZUNvbmZpZ3VyYXRpb24uY2hhdCh7XG4gICAgICBpbnB1dFZhcmlhYmxlczogcHJvcHMucHJvbXB0VmFyaWFibGVzLFxuICAgICAgbWVzc2FnZXM6IHByb3BzLm1lc3NhZ2VzLFxuICAgICAgc3lzdGVtOiBwcm9wcy5zeXN0ZW0sXG4gICAgICB0b29sQ29uZmlndXJhdGlvbjogcHJvcHMudG9vbENvbmZpZ3VyYXRpb24sXG4gICAgfSksXG4gIH07XG59XG4iXX0=