"use strict";
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationInferenceProfile = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const bedrock = require("aws-cdk-lib/aws-bedrock");
const aws_iam_1 = require("aws-cdk-lib/aws-iam");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
const inference_profile_1 = require("./inference-profile");
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create an Application Inference Profile with CDK.
 * These are inference profiles created by users (user defined).
 * This helps to track costs and model usage.
 *
 * Application inference profiles are user-defined profiles that help you track costs and model usage.
 * They can be created for a single region or for multiple regions using a cross-region inference profile.
 *
 * @cloudformationResource AWS::Bedrock::ApplicationInferenceProfile
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/inference-profiles-create.html
 */
let ApplicationInferenceProfile = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = inference_profile_1.InferenceProfileBase;
    let _instanceExtraInitializers = [];
    let _grantInvoke_decorators;
    let _grantProfileUsage_decorators;
    var ApplicationInferenceProfile = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _grantInvoke_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _grantProfileUsage_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            __esDecorate(this, null, _grantInvoke_decorators, { kind: "method", name: "grantInvoke", static: false, private: false, access: { has: obj => "grantInvoke" in obj, get: obj => obj.grantInvoke }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _grantProfileUsage_decorators, { kind: "method", name: "grantProfileUsage", static: false, private: false, access: { has: obj => "grantProfileUsage" in obj, get: obj => obj.grantProfileUsage }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            ApplicationInferenceProfile = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ApplicationInferenceProfile", version: "2.241.0-alpha.0" };
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.ApplicationInferenceProfile';
        /**
         * Import an Application Inference Profile given its attributes.
         * [disable-awslint:no-grants]
         *
         * @param scope - The construct scope
         * @param id - Identifier of the construct
         * @param attrs - Attributes of the existing application inference profile
         * @returns An IInferenceProfile reference to the existing application inference profile
         */
        static fromApplicationInferenceProfileAttributes(scope, id, attrs) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfileAttributes(attrs);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.fromApplicationInferenceProfileAttributes);
                }
                throw error;
            }
            class Import extends inference_profile_1.InferenceProfileBase {
                inferenceProfileArn = attrs.inferenceProfileArn;
                inferenceProfileId = aws_cdk_lib_1.Arn.split(attrs.inferenceProfileArn, aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME)
                    .resourceName;
                type = inference_profile_1.InferenceProfileType.APPLICATION;
                /**
                 * [disable-awslint:no-grants]
                 */
                grantProfileUsage(grantee) {
                    return aws_iam_1.Grant.addToPrincipal({
                        grantee: grantee,
                        actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel'],
                        resourceArns: [this.inferenceProfileArn],
                    });
                }
            }
            return new Import(scope, id);
        }
        /**
         * Import a low-level L1 Cfn Application Inference Profile.
         * [disable-awslint:no-grants]
         *
         * @param cfnApplicationInferenceProfile - The L1 CfnApplicationInferenceProfile to import
         * @returns An IInferenceProfile reference to the imported application inference profile
         */
        static fromCfnApplicationInferenceProfile(cfnApplicationInferenceProfile) {
            // Singleton pattern that will prevent creating 2 or more Inference Profiles from the same L1
            const id = '@FromCfnApplicationInferenceProfile';
            const existing = cfnApplicationInferenceProfile.node.tryFindChild(id);
            if (existing) {
                return existing;
            }
            return new (class extends inference_profile_1.InferenceProfileBase {
                inferenceProfileArn = cfnApplicationInferenceProfile.attrInferenceProfileArn;
                inferenceProfileId = cfnApplicationInferenceProfile.attrInferenceProfileId;
                type = inference_profile_1.InferenceProfileType.APPLICATION;
                /**
                 * [disable-awslint:no-grants]
                 */
                grantProfileUsage(grantee) {
                    return aws_iam_1.Grant.addToPrincipal({
                        grantee: grantee,
                        actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel'],
                        resourceArns: [this.inferenceProfileArn],
                    });
                }
            })(cfnApplicationInferenceProfile, id);
        }
        // ------------------------------------------------------
        // Base attributes
        // ------------------------------------------------------
        /**
         * The name of the application inference profile.
         */
        inferenceProfileName = __runInitializers(this, _instanceExtraInitializers);
        /**
         * The ARN of the application inference profile.
         * @attribute
         */
        inferenceProfileArn;
        /**
         * The unique identifier of the application inference profile.
         * @attribute
         */
        inferenceProfileId;
        /**
         * The underlying model/cross-region model used by the application inference profile.
         */
        inferenceProfileModel;
        /**
         * The status of the application inference profile. ACTIVE means that the inference profile is ready to be used.
         * @attribute
         */
        status;
        /**
         * The type of the inference profile. Always APPLICATION for application inference profiles.
         */
        type;
        /**
         * Time Stamp for Application Inference Profile creation.
         * @attribute
         */
        createdAt;
        /**
         * Time Stamp for Application Inference Profile update.
         * @attribute
         */
        updatedAt;
        /**
         * The ARN used for invoking this inference profile.
         * This equals to the inferenceProfileArn property, useful for implementing IBedrockInvokable interface.
         */
        invokableArn;
        // ------------------------------------------------------
        // Internal Only
        // ------------------------------------------------------
        /**
         * Instance of CfnApplicationInferenceProfile.
         * @internal
         */
        __resource;
        // ------------------------------------------------------
        // CONSTRUCTOR
        // ------------------------------------------------------
        constructor(scope, id, props) {
            super(scope, id);
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfileProps(props);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, ApplicationInferenceProfile);
                }
                throw error;
            }
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            // ------------------------------------------------------
            // Validate props
            // ------------------------------------------------------
            this.validateProps(props);
            // ------------------------------------------------------
            // Set properties
            // ------------------------------------------------------
            this.inferenceProfileModel = props.modelSource;
            this.type = inference_profile_1.InferenceProfileType.APPLICATION;
            // ------------------------------------------------------
            // L1 instantiation
            // ------------------------------------------------------
            this.__resource = new bedrock.CfnApplicationInferenceProfile(this, 'Resource', {
                description: props.description,
                inferenceProfileName: props.applicationInferenceProfileName,
                modelSource: {
                    copyFrom: props.modelSource.invokableArn,
                },
                tags: props.tags ? Object.entries(props.tags).map(([key, value]) => ({ key, value })) : undefined,
            });
            // ------------------------------------------------------
            // Build attributes
            // ------------------------------------------------------
            this.inferenceProfileArn = this.__resource.attrInferenceProfileArn;
            this.inferenceProfileId = this.__resource.attrInferenceProfileId;
            this.inferenceProfileName = this.__resource.inferenceProfileName;
            this.status = this.__resource.attrStatus;
            this.createdAt = this.__resource.attrCreatedAt;
            this.updatedAt = this.__resource.attrUpdatedAt;
            this.invokableArn = this.inferenceProfileArn;
        }
        // ------------------------------------------------------
        // METHODS
        // ------------------------------------------------------
        /**
         * Validates the properties for creating an Application Inference Profile.
         *
         * @param props - The properties to validate
         * @throws ValidationError if any validation fails
         */
        validateProps(props) {
            // Validate applicationInferenceProfileName is provided and not empty
            if (!props.applicationInferenceProfileName || props.applicationInferenceProfileName.trim() === '') {
                throw new aws_cdk_lib_1.ValidationError('applicationInferenceProfileName is required and cannot be empty', this);
            }
            // Validate applicationInferenceProfileName length
            if (props.applicationInferenceProfileName.length > 64) {
                throw new aws_cdk_lib_1.ValidationError('applicationInferenceProfileName cannot exceed 64 characters', this);
            }
            // Validate applicationInferenceProfileName pattern
            const namePattern = /^([0-9a-zA-Z:.][ _-]?)+$/;
            if (!namePattern.test(props.applicationInferenceProfileName)) {
                throw new aws_cdk_lib_1.ValidationError('applicationInferenceProfileName must match pattern ^([0-9a-zA-Z:.][ _-]?)+$', this);
            }
            // Validate modelSource is provided
            if (!props.modelSource) {
                throw new aws_cdk_lib_1.ValidationError('modelSource is required', this);
            }
            // Validate description length if provided
            if (props.description !== undefined && props.description.length > 200) {
                throw new aws_cdk_lib_1.ValidationError('description cannot exceed 200 characters', this);
            }
            // Validate description pattern if provided
            if (props.description !== undefined && props.description !== '') {
                const descriptionPattern = /^([0-9a-zA-Z:.][ _-]?)+$/;
                if (!descriptionPattern.test(props.description)) {
                    throw new aws_cdk_lib_1.ValidationError('description must match pattern ^([0-9a-zA-Z:.][ _-]?)+$', this);
                }
            }
        }
        /**
         * Gives the appropriate policies to invoke and use the application inference profile.
         * This method ensures the appropriate permissions are given to use either the inference profile
         * or the underlying foundation model/cross-region profile.
         * [disable-awslint:no-grants]
         *
         * @param grantee - The IAM principal to grant permissions to
         * @returns An IAM Grant object representing the granted permissions
         */
        grantInvoke(grantee) {
            // This method ensures the appropriate permissions are given
            // to use either the inference profile or the vanilla foundation model
            this.inferenceProfileModel.grantInvoke(grantee);
            // Plus we add permissions to now invoke the application inference profile itself
            return this.grantProfileUsage(grantee);
        }
        /**
         * Grants appropriate permissions to use the application inference profile (AIP).
         * This method adds the necessary IAM permissions to allow the grantee to:
         * - Get inference profile details (bedrock:GetInferenceProfile)
         * - Invoke the model through the inference profile (bedrock:InvokeModel)
         *
         * Note: This does not grant permissions to use the underlying model/cross-region profile in the AIP.
         * For comprehensive permissions, use grantInvoke() instead.
         * [disable-awslint:no-grants]
         *
         * @param grantee - The IAM principal to grant permissions to
         * @returns An IAM Grant object representing the granted permissions
         */
        grantProfileUsage(grantee) {
            return aws_iam_1.Grant.addToPrincipal({
                grantee: grantee,
                actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel'],
                resourceArns: [this.inferenceProfileArn],
            });
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return ApplicationInferenceProfile = _classThis;
})();
exports.ApplicationInferenceProfile = ApplicationInferenceProfile;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwbGljYXRpb24taW5mZXJlbmNlLXByb2ZpbGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhcHBsaWNhdGlvbi1pbmZlcmVuY2UtcHJvZmlsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSw2Q0FBOEQ7QUFDOUQsbURBQW1EO0FBRW5ELGlEQUE0QztBQUM1Qyw4RUFBOEY7QUFDOUYsMEVBQTBFO0FBRzFFLDJEQUFpRjtBQTRFakY7OytFQUUrRTtBQUMvRTs7Ozs7Ozs7OztHQVVHO0lBRVUsMkJBQTJCOzRCQUR2QyxvQ0FBa0I7Ozs7c0JBQzhCLHdDQUFvQjs7OzsyQ0FBNUIsU0FBUSxXQUFvQjs7Ozt1Q0FpUGxFLElBQUEsa0NBQWMsR0FBRTs2Q0F1QmhCLElBQUEsa0NBQWMsR0FBRTtZQXRCakIsb0xBQU8sV0FBVyw2REFPakI7WUFnQkQsc01BQU8saUJBQWlCLDZEQU12QjtZQS9RSCw2S0FnUkM7Ozs7O1FBL1FDLHNDQUFzQztRQUMvQixNQUFNLENBQVUscUJBQXFCLEdBQVcsd0RBQXdELENBQUM7UUFFaEg7Ozs7Ozs7O1dBUUc7UUFDSSxNQUFNLENBQUMseUNBQXlDLENBQ3JELEtBQWdCLEVBQ2hCLEVBQVUsRUFDVixLQUE0Qzs7Ozs7Ozs7OztZQUU1QyxNQUFNLE1BQU8sU0FBUSx3Q0FBb0I7Z0JBQ3ZCLG1CQUFtQixHQUFHLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQztnQkFDaEQsa0JBQWtCLEdBQUcsaUJBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLG1CQUFtQixFQUFFLHVCQUFTLENBQUMsbUJBQW1CLENBQUM7cUJBQ3JHLFlBQWEsQ0FBQztnQkFDRCxJQUFJLEdBQUcsd0NBQW9CLENBQUMsV0FBVyxDQUFDO2dCQUV4RDs7bUJBRUc7Z0JBQ0ksaUJBQWlCLENBQUMsT0FBbUI7b0JBQzFDLE9BQU8sZUFBSyxDQUFDLGNBQWMsQ0FBQzt3QkFDMUIsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLE9BQU8sRUFBRSxDQUFDLDZCQUE2QixFQUFFLHFCQUFxQixDQUFDO3dCQUMvRCxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7cUJBQ3pDLENBQUMsQ0FBQztnQkFDTCxDQUFDO2FBQ0Y7WUFFRCxPQUFPLElBQUksTUFBTSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztTQUM5QjtRQUVEOzs7Ozs7V0FNRztRQUNJLE1BQU0sQ0FBQyxrQ0FBa0MsQ0FDOUMsOEJBQXNFO1lBRXRFLDZGQUE2RjtZQUM3RixNQUFNLEVBQUUsR0FBRyxxQ0FBcUMsQ0FBQztZQUNqRCxNQUFNLFFBQVEsR0FBRyw4QkFBOEIsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3RFLElBQUksUUFBUSxFQUFFLENBQUM7Z0JBQ2IsT0FBTyxRQUF3QyxDQUFDO1lBQ2xELENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxLQUFNLFNBQVEsd0NBQW9CO2dCQUM1QixtQkFBbUIsR0FBRyw4QkFBOEIsQ0FBQyx1QkFBdUIsQ0FBQztnQkFDN0Usa0JBQWtCLEdBQUcsOEJBQThCLENBQUMsc0JBQXNCLENBQUM7Z0JBQzNFLElBQUksR0FBRyx3Q0FBb0IsQ0FBQyxXQUFXLENBQUM7Z0JBRXhEOzttQkFFRztnQkFDSSxpQkFBaUIsQ0FBQyxPQUFtQjtvQkFDMUMsT0FBTyxlQUFLLENBQUMsY0FBYyxDQUFDO3dCQUMxQixPQUFPLEVBQUUsT0FBTzt3QkFDaEIsT0FBTyxFQUFFLENBQUMsNkJBQTZCLEVBQUUscUJBQXFCLENBQUM7d0JBQy9ELFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztxQkFDekMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7YUFDRixDQUFDLENBQUMsOEJBQThCLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDeEM7UUFFRCx5REFBeUQ7UUFDekQsa0JBQWtCO1FBQ2xCLHlEQUF5RDtRQUN6RDs7V0FFRztRQUNhLG9CQUFvQixHQWhGekIsbURBQTJCLENBZ0ZPO1FBRTdDOzs7V0FHRztRQUNhLG1CQUFtQixDQUFTO1FBRTVDOzs7V0FHRztRQUNhLGtCQUFrQixDQUFTO1FBRTNDOztXQUVHO1FBQ2EscUJBQXFCLENBQW9CO1FBRXpEOzs7V0FHRztRQUNhLE1BQU0sQ0FBUztRQUUvQjs7V0FFRztRQUNhLElBQUksQ0FBdUI7UUFFM0M7OztXQUdHO1FBQ2EsU0FBUyxDQUFTO1FBRWxDOzs7V0FHRztRQUNhLFNBQVMsQ0FBUztRQUVsQzs7O1dBR0c7UUFDYSxZQUFZLENBQVM7UUFFckMseURBQXlEO1FBQ3pELGdCQUFnQjtRQUNoQix5REFBeUQ7UUFDekQ7OztXQUdHO1FBQ2MsVUFBVSxDQUF5QztRQUVwRSx5REFBeUQ7UUFDekQsY0FBYztRQUNkLHlEQUF5RDtRQUN6RCxZQUFZLEtBQWdCLEVBQUUsRUFBVSxFQUFFLEtBQXVDO1lBQy9FLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7Ozs7OzttREE3SVIsMkJBQTJCOzs7O1lBOElwQyxtQ0FBbUM7WUFDbkMsSUFBQSx3Q0FBb0IsRUFBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFbEMseURBQXlEO1lBQ3pELGlCQUFpQjtZQUNqQix5REFBeUQ7WUFDekQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUUxQix5REFBeUQ7WUFDekQsaUJBQWlCO1lBQ2pCLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQztZQUMvQyxJQUFJLENBQUMsSUFBSSxHQUFHLHdDQUFvQixDQUFDLFdBQVcsQ0FBQztZQUU3Qyx5REFBeUQ7WUFDekQsbUJBQW1CO1lBQ25CLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksT0FBTyxDQUFDLDhCQUE4QixDQUFDLElBQUksRUFBRSxVQUFVLEVBQUU7Z0JBQzdFLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztnQkFDOUIsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLCtCQUErQjtnQkFDM0QsV0FBVyxFQUFFO29CQUNYLFFBQVEsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLFlBQVk7aUJBQ3pDO2dCQUNELElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7YUFDbEcsQ0FBQyxDQUFDO1lBRUgseURBQXlEO1lBQ3pELG1CQUFtQjtZQUNuQix5REFBeUQ7WUFDekQsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsdUJBQXVCLENBQUM7WUFDbkUsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsc0JBQXNCLENBQUM7WUFDakUsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsb0JBQXFCLENBQUM7WUFDbEUsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQztZQUN6QyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO1lBQy9DLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUM7WUFDL0MsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUM7U0FDOUM7UUFFRCx5REFBeUQ7UUFDekQsVUFBVTtRQUNWLHlEQUF5RDtRQUV6RDs7Ozs7V0FLRztRQUNLLGFBQWEsQ0FBQyxLQUF1QztZQUMzRCxxRUFBcUU7WUFDckUsSUFBSSxDQUFDLEtBQUssQ0FBQywrQkFBK0IsSUFBSSxLQUFLLENBQUMsK0JBQStCLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUM7Z0JBQ2xHLE1BQU0sSUFBSSw2QkFBZSxDQUFDLGlFQUFpRSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3JHLENBQUM7WUFFRCxrREFBa0Q7WUFDbEQsSUFBSSxLQUFLLENBQUMsK0JBQStCLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRSxDQUFDO2dCQUN0RCxNQUFNLElBQUksNkJBQWUsQ0FBQyw2REFBNkQsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNqRyxDQUFDO1lBRUQsbURBQW1EO1lBQ25ELE1BQU0sV0FBVyxHQUFHLDBCQUEwQixDQUFDO1lBQy9DLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxFQUFFLENBQUM7Z0JBQzdELE1BQU0sSUFBSSw2QkFBZSxDQUN2Qiw2RUFBNkUsRUFDN0UsSUFBSSxDQUNMLENBQUM7WUFDSixDQUFDO1lBRUQsbUNBQW1DO1lBQ25DLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ3ZCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHlCQUF5QixFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzdELENBQUM7WUFFRCwwQ0FBMEM7WUFDMUMsSUFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQztnQkFDdEUsTUFBTSxJQUFJLDZCQUFlLENBQUMsMENBQTBDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDOUUsQ0FBQztZQUVELDJDQUEyQztZQUMzQyxJQUFJLEtBQUssQ0FBQyxXQUFXLEtBQUssU0FBUyxJQUFJLEtBQUssQ0FBQyxXQUFXLEtBQUssRUFBRSxFQUFFLENBQUM7Z0JBQ2hFLE1BQU0sa0JBQWtCLEdBQUcsMEJBQTBCLENBQUM7Z0JBQ3RELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7b0JBQ2hELE1BQU0sSUFBSSw2QkFBZSxDQUN2Qix5REFBeUQsRUFDekQsSUFBSSxDQUNMLENBQUM7Z0JBQ0osQ0FBQztZQUNILENBQUM7U0FDRjtRQUVEOzs7Ozs7OztXQVFHO1FBRUksV0FBVyxDQUFDLE9BQW1CO1lBQ3BDLDREQUE0RDtZQUM1RCxzRUFBc0U7WUFDdEUsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUVoRCxpRkFBaUY7WUFDakYsT0FBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDeEM7UUFFRDs7Ozs7Ozs7Ozs7O1dBWUc7UUFFSSxpQkFBaUIsQ0FBQyxPQUFtQjtZQUMxQyxPQUFPLGVBQUssQ0FBQyxjQUFjLENBQUM7Z0JBQzFCLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixPQUFPLEVBQUUsQ0FBQyw2QkFBNkIsRUFBRSxxQkFBcUIsQ0FBQztnQkFDL0QsWUFBWSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDO2FBQ3pDLENBQUMsQ0FBQztTQUNKOztZQS9RVSx1REFBMkI7Ozs7O0FBQTNCLGtFQUEyQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFybiwgQXJuRm9ybWF0LCBWYWxpZGF0aW9uRXJyb3IgfSBmcm9tICdhd3MtY2RrLWxpYic7XG5pbXBvcnQgKiBhcyBiZWRyb2NrIGZyb20gJ2F3cy1jZGstbGliL2F3cy1iZWRyb2NrJztcbmltcG9ydCB0eXBlIHsgSUdyYW50YWJsZSB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0IHsgR3JhbnQgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCB7IGFkZENvbnN0cnVjdE1ldGFkYXRhLCBNZXRob2RNZXRhZGF0YSB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL21ldGFkYXRhLXJlc291cmNlJztcbmltcG9ydCB7IHByb3BlcnR5SW5qZWN0YWJsZSB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL3Byb3AtaW5qZWN0YWJsZSc7XG5pbXBvcnQgdHlwZSB7IENvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuaW1wb3J0IHR5cGUgeyBJSW5mZXJlbmNlUHJvZmlsZSB9IGZyb20gJy4vaW5mZXJlbmNlLXByb2ZpbGUnO1xuaW1wb3J0IHsgSW5mZXJlbmNlUHJvZmlsZUJhc2UsIEluZmVyZW5jZVByb2ZpbGVUeXBlIH0gZnJvbSAnLi9pbmZlcmVuY2UtcHJvZmlsZSc7XG5pbXBvcnQgdHlwZSB7IElCZWRyb2NrSW52b2thYmxlIH0gZnJvbSAnLi4vbW9kZWxzJztcblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBQUk9QUyBGT1IgTkVXIENPTlNUUlVDVFxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBjcmVhdGluZyBhbiBBcHBsaWNhdGlvbiBJbmZlcmVuY2UgUHJvZmlsZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBBcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVQcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFRoaXMgbmFtZSB3aWxsIGJlIHVzZWQgdG8gaWRlbnRpZnkgdGhlIGluZmVyZW5jZSBwcm9maWxlIGluIHRoZSBBV1MgY29uc29sZSBhbmQgQVBJcy5cbiAgICogLSBSZXF1aXJlZDogIFllc1xuICAgKiAtIE1heGltdW0gbGVuZ3RoOiA2NCBjaGFyYWN0ZXJzXG4gICAqIC0gUGF0dGVybjogYF4oWzAtOWEtekEtWjouXVsgXy1dPykrJGBcbiAgICpcbiAgICogQHNlZSBodHRwOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9BV1NDbG91ZEZvcm1hdGlvbi9sYXRlc3QvVXNlckd1aWRlL2F3cy1yZXNvdXJjZS1iZWRyb2NrLWFwcGxpY2F0aW9uaW5mZXJlbmNlcHJvZmlsZS5odG1sI2Nmbi1iZWRyb2NrLWFwcGxpY2F0aW9uaW5mZXJlbmNlcHJvZmlsZS1pbmZlcmVuY2Vwcm9maWxlbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBEZXNjcmlwdGlvbiBvZiB0aGUgaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFByb3ZpZGVzIGFkZGl0aW9uYWwgY29udGV4dCBhYm91dCB0aGUgcHVycG9zZSBhbmQgdXNhZ2Ugb2YgdGhpcyBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICpcbiAgICogLSBNYXhpbXVtIGxlbmd0aDogMjAwIGNoYXJhY3RlcnMgd2hlbiBwcm92aWRlZFxuICAgKiAtIFBhdHRlcm46IGBeKFswLTlhLXpBLVo6Ll1bIF8tXT8pKyRgXG4gICAqIEBkZWZhdWx0IC0gTm8gZGVzY3JpcHRpb24gaXMgcHJvdmlkZWRcbiAgICogQHNlZSBodHRwOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9BV1NDbG91ZEZvcm1hdGlvbi9sYXRlc3QvVXNlckd1aWRlL2F3cy1yZXNvdXJjZS1iZWRyb2NrLWFwcGxpY2F0aW9uaW5mZXJlbmNlcHJvZmlsZS5odG1sI2Nmbi1iZWRyb2NrLWFwcGxpY2F0aW9uaW5mZXJlbmNlcHJvZmlsZS1kZXNjcmlwdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBtb2RlbCBzb3VyY2UgZm9yIHRoaXMgaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqXG4gICAqIFRvIGNyZWF0ZSBhbiBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZSBmb3Igb25lIFJlZ2lvbiwgc3BlY2lmeSBhIGZvdW5kYXRpb24gbW9kZWwuXG4gICAqIFVzYWdlIGFuZCBjb3N0cyBmb3IgcmVxdWVzdHMgbWFkZSB0byB0aGF0IFJlZ2lvbiB3aXRoIHRoYXQgbW9kZWwgd2lsbCBiZSB0cmFja2VkLlxuICAgKlxuICAgKiBUbyBjcmVhdGUgYW4gYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUgZm9yIG11bHRpcGxlIFJlZ2lvbnMsXG4gICAqIHNwZWNpZnkgYSBjcm9zcyByZWdpb24gKHN5c3RlbS1kZWZpbmVkKSBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogVGhlIGluZmVyZW5jZSBwcm9maWxlIHdpbGwgcm91dGUgcmVxdWVzdHMgdG8gdGhlIFJlZ2lvbnMgZGVmaW5lZCBpblxuICAgKiB0aGUgY3Jvc3MgcmVnaW9uIChzeXN0ZW0tZGVmaW5lZCkgaW5mZXJlbmNlIHByb2ZpbGUgdGhhdCB5b3UgY2hvb3NlLlxuICAgKiBVc2FnZSBhbmQgY29zdHMgZm9yIHJlcXVlc3RzIG1hZGUgdG8gdGhlIFJlZ2lvbnMgaW4gdGhlIGluZmVyZW5jZSBwcm9maWxlIHdpbGwgYmUgdHJhY2tlZC5cbiAgICpcbiAgICovXG4gIHJlYWRvbmx5IG1vZGVsU291cmNlOiBJQmVkcm9ja0ludm9rYWJsZTtcbiAgLyoqXG4gICAqIEEgbGlzdCBvZiB0YWdzIGFzc29jaWF0ZWQgd2l0aCB0aGUgaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFRhZ3MgaGVscCB5b3Ugb3JnYW5pemUgYW5kIGNhdGVnb3JpemUgeW91ciBBV1MgcmVzb3VyY2VzLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIE5vIHRhZ3MgYXJlIGFwcGxpZWRcbiAgICovXG4gIHJlYWRvbmx5IHRhZ3M/OiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9O1xufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICBBVFRSUyBGT1IgSU1QT1JURUQgQ09OU1RSVUNUXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIEF0dHJpYnV0ZXMgZm9yIHNwZWNpZnlpbmcgYW4gaW1wb3J0ZWQgQXBwbGljYXRpb24gSW5mZXJlbmNlIFByb2ZpbGUuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlQXR0cmlidXRlcyB7XG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZUFybjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgSUQgb3IgQW1hem9uIFJlc291cmNlIE5hbWUgKEFSTikgb2YgdGhlIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKiBUaGlzIGNhbiBiZSBlaXRoZXIgdGhlIHByb2ZpbGUgSUQgb3IgdGhlIGZ1bGwgQVJOLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlSWRlbnRpZmllcjogc3RyaW5nO1xufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIE5FVyBDT05TVFJVQ1QgREVGSU5JVElPTlxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBDbGFzcyB0byBjcmVhdGUgYW4gQXBwbGljYXRpb24gSW5mZXJlbmNlIFByb2ZpbGUgd2l0aCBDREsuXG4gKiBUaGVzZSBhcmUgaW5mZXJlbmNlIHByb2ZpbGVzIGNyZWF0ZWQgYnkgdXNlcnMgKHVzZXIgZGVmaW5lZCkuXG4gKiBUaGlzIGhlbHBzIHRvIHRyYWNrIGNvc3RzIGFuZCBtb2RlbCB1c2FnZS5cbiAqXG4gKiBBcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZXMgYXJlIHVzZXItZGVmaW5lZCBwcm9maWxlcyB0aGF0IGhlbHAgeW91IHRyYWNrIGNvc3RzIGFuZCBtb2RlbCB1c2FnZS5cbiAqIFRoZXkgY2FuIGJlIGNyZWF0ZWQgZm9yIGEgc2luZ2xlIHJlZ2lvbiBvciBmb3IgbXVsdGlwbGUgcmVnaW9ucyB1c2luZyBhIGNyb3NzLXJlZ2lvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAqXG4gKiBAY2xvdWRmb3JtYXRpb25SZXNvdXJjZSBBV1M6OkJlZHJvY2s6OkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZVxuICogQHNlZSBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vYmVkcm9jay9sYXRlc3QvdXNlcmd1aWRlL2luZmVyZW5jZS1wcm9maWxlcy1jcmVhdGUuaHRtbFxuICovXG5AcHJvcGVydHlJbmplY3RhYmxlXG5leHBvcnQgY2xhc3MgQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlIGV4dGVuZHMgSW5mZXJlbmNlUHJvZmlsZUJhc2UgaW1wbGVtZW50cyBJQmVkcm9ja0ludm9rYWJsZSB7XG4gIC8qKiBVbmlxdWVseSBpZGVudGlmaWVzIHRoaXMgY2xhc3MuICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgUFJPUEVSVFlfSU5KRUNUSU9OX0lEOiBzdHJpbmcgPSAnQGF3cy1jZGsuYXdzLWJlZHJvY2stYWxwaGEuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlJztcblxuICAvKipcbiAgICogSW1wb3J0IGFuIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlIGdpdmVuIGl0cyBhdHRyaWJ1dGVzLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICpcbiAgICogQHBhcmFtIHNjb3BlIC0gVGhlIGNvbnN0cnVjdCBzY29wZVxuICAgKiBAcGFyYW0gaWQgLSBJZGVudGlmaWVyIG9mIHRoZSBjb25zdHJ1Y3RcbiAgICogQHBhcmFtIGF0dHJzIC0gQXR0cmlidXRlcyBvZiB0aGUgZXhpc3RpbmcgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGVcbiAgICogQHJldHVybnMgQW4gSUluZmVyZW5jZVByb2ZpbGUgcmVmZXJlbmNlIHRvIHRoZSBleGlzdGluZyBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlQXR0cmlidXRlcyhcbiAgICBzY29wZTogQ29uc3RydWN0LFxuICAgIGlkOiBzdHJpbmcsXG4gICAgYXR0cnM6IEFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZUF0dHJpYnV0ZXMsXG4gICk6IElJbmZlcmVuY2VQcm9maWxlIHtcbiAgICBjbGFzcyBJbXBvcnQgZXh0ZW5kcyBJbmZlcmVuY2VQcm9maWxlQmFzZSB7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZUFybiA9IGF0dHJzLmluZmVyZW5jZVByb2ZpbGVBcm47XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZUlkID0gQXJuLnNwbGl0KGF0dHJzLmluZmVyZW5jZVByb2ZpbGVBcm4sIEFybkZvcm1hdC5TTEFTSF9SRVNPVVJDRV9OQU1FKVxuICAgICAgICAucmVzb3VyY2VOYW1lITtcbiAgICAgIHB1YmxpYyByZWFkb25seSB0eXBlID0gSW5mZXJlbmNlUHJvZmlsZVR5cGUuQVBQTElDQVRJT047XG5cbiAgICAgIC8qKlxuICAgICAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAgICAgKi9cbiAgICAgIHB1YmxpYyBncmFudFByb2ZpbGVVc2FnZShncmFudGVlOiBJR3JhbnRhYmxlKTogR3JhbnQge1xuICAgICAgICByZXR1cm4gR3JhbnQuYWRkVG9QcmluY2lwYWwoe1xuICAgICAgICAgIGdyYW50ZWU6IGdyYW50ZWUsXG4gICAgICAgICAgYWN0aW9uczogWydiZWRyb2NrOkdldEluZmVyZW5jZVByb2ZpbGUnLCAnYmVkcm9jazpJbnZva2VNb2RlbCddLFxuICAgICAgICAgIHJlc291cmNlQXJuczogW3RoaXMuaW5mZXJlbmNlUHJvZmlsZUFybl0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBuZXcgSW1wb3J0KHNjb3BlLCBpZCk7XG4gIH1cblxuICAvKipcbiAgICogSW1wb3J0IGEgbG93LWxldmVsIEwxIENmbiBBcHBsaWNhdGlvbiBJbmZlcmVuY2UgUHJvZmlsZS5cbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqXG4gICAqIEBwYXJhbSBjZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUgLSBUaGUgTDEgQ2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlIHRvIGltcG9ydFxuICAgKiBAcmV0dXJucyBBbiBJSW5mZXJlbmNlUHJvZmlsZSByZWZlcmVuY2UgdG8gdGhlIGltcG9ydGVkIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21DZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUoXG4gICAgY2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlOiBiZWRyb2NrLkNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZSxcbiAgKTogSUluZmVyZW5jZVByb2ZpbGUge1xuICAgIC8vIFNpbmdsZXRvbiBwYXR0ZXJuIHRoYXQgd2lsbCBwcmV2ZW50IGNyZWF0aW5nIDIgb3IgbW9yZSBJbmZlcmVuY2UgUHJvZmlsZXMgZnJvbSB0aGUgc2FtZSBMMVxuICAgIGNvbnN0IGlkID0gJ0BGcm9tQ2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlJztcbiAgICBjb25zdCBleGlzdGluZyA9IGNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZS5ub2RlLnRyeUZpbmRDaGlsZChpZCk7XG4gICAgaWYgKGV4aXN0aW5nKSB7XG4gICAgICByZXR1cm4gZXhpc3RpbmcgYXMgdW5rbm93biBhcyBJSW5mZXJlbmNlUHJvZmlsZTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IChjbGFzcyBleHRlbmRzIEluZmVyZW5jZVByb2ZpbGVCYXNlIHtcbiAgICAgIHB1YmxpYyByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlQXJuID0gY2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlLmF0dHJJbmZlcmVuY2VQcm9maWxlQXJuO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVJZCA9IGNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZS5hdHRySW5mZXJlbmNlUHJvZmlsZUlkO1xuICAgICAgcHVibGljIHJlYWRvbmx5IHR5cGUgPSBJbmZlcmVuY2VQcm9maWxlVHlwZS5BUFBMSUNBVElPTjtcblxuICAgICAgLyoqXG4gICAgICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICAgICAqL1xuICAgICAgcHVibGljIGdyYW50UHJvZmlsZVVzYWdlKGdyYW50ZWU6IElHcmFudGFibGUpOiBHcmFudCB7XG4gICAgICAgIHJldHVybiBHcmFudC5hZGRUb1ByaW5jaXBhbCh7XG4gICAgICAgICAgZ3JhbnRlZTogZ3JhbnRlZSxcbiAgICAgICAgICBhY3Rpb25zOiBbJ2JlZHJvY2s6R2V0SW5mZXJlbmNlUHJvZmlsZScsICdiZWRyb2NrOkludm9rZU1vZGVsJ10sXG4gICAgICAgICAgcmVzb3VyY2VBcm5zOiBbdGhpcy5pbmZlcmVuY2VQcm9maWxlQXJuXSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSkoY2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlLCBpZCk7XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQmFzZSBhdHRyaWJ1dGVzXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVOYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBBUk4gb2YgdGhlIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZUFybjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgdW5pcXVlIGlkZW50aWZpZXIgb2YgdGhlIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZUlkOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSB1bmRlcmx5aW5nIG1vZGVsL2Nyb3NzLXJlZ2lvbiBtb2RlbCB1c2VkIGJ5IHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlTW9kZWw6IElCZWRyb2NrSW52b2thYmxlO1xuXG4gIC8qKlxuICAgKiBUaGUgc3RhdHVzIG9mIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZS4gQUNUSVZFIG1lYW5zIHRoYXQgdGhlIGluZmVyZW5jZSBwcm9maWxlIGlzIHJlYWR5IHRvIGJlIHVzZWQuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBzdGF0dXM6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHR5cGUgb2YgdGhlIGluZmVyZW5jZSBwcm9maWxlLiBBbHdheXMgQVBQTElDQVRJT04gZm9yIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlcy5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSB0eXBlOiBJbmZlcmVuY2VQcm9maWxlVHlwZTtcblxuICAvKipcbiAgICogVGltZSBTdGFtcCBmb3IgQXBwbGljYXRpb24gSW5mZXJlbmNlIFByb2ZpbGUgY3JlYXRpb24uXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBjcmVhdGVkQXQ6IHN0cmluZztcblxuICAvKipcbiAgICogVGltZSBTdGFtcCBmb3IgQXBwbGljYXRpb24gSW5mZXJlbmNlIFByb2ZpbGUgdXBkYXRlLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgdXBkYXRlZEF0OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBBUk4gdXNlZCBmb3IgaW52b2tpbmcgdGhpcyBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogVGhpcyBlcXVhbHMgdG8gdGhlIGluZmVyZW5jZVByb2ZpbGVBcm4gcHJvcGVydHksIHVzZWZ1bCBmb3IgaW1wbGVtZW50aW5nIElCZWRyb2NrSW52b2thYmxlIGludGVyZmFjZS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBpbnZva2FibGVBcm46IHN0cmluZztcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gSW50ZXJuYWwgT25seVxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIEluc3RhbmNlIG9mIENmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZS5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBwcml2YXRlIHJlYWRvbmx5IF9fcmVzb3VyY2U6IGJlZHJvY2suQ2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlO1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBDT05TVFJVQ1RPUlxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM6IEFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZVByb3BzKSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkKTtcbiAgICAvLyBFbmhhbmNlZCBDREsgQW5hbHl0aWNzIFRlbGVtZXRyeVxuICAgIGFkZENvbnN0cnVjdE1ldGFkYXRhKHRoaXMsIHByb3BzKTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIFZhbGlkYXRlIHByb3BzXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy52YWxpZGF0ZVByb3BzKHByb3BzKTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIFNldCBwcm9wZXJ0aWVzXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy5pbmZlcmVuY2VQcm9maWxlTW9kZWwgPSBwcm9wcy5tb2RlbFNvdXJjZTtcbiAgICB0aGlzLnR5cGUgPSBJbmZlcmVuY2VQcm9maWxlVHlwZS5BUFBMSUNBVElPTjtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIEwxIGluc3RhbnRpYXRpb25cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLl9fcmVzb3VyY2UgPSBuZXcgYmVkcm9jay5DZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUodGhpcywgJ1Jlc291cmNlJywge1xuICAgICAgZGVzY3JpcHRpb246IHByb3BzLmRlc2NyaXB0aW9uLFxuICAgICAgaW5mZXJlbmNlUHJvZmlsZU5hbWU6IHByb3BzLmFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZU5hbWUsXG4gICAgICBtb2RlbFNvdXJjZToge1xuICAgICAgICBjb3B5RnJvbTogcHJvcHMubW9kZWxTb3VyY2UuaW52b2thYmxlQXJuLFxuICAgICAgfSxcbiAgICAgIHRhZ3M6IHByb3BzLnRhZ3MgPyBPYmplY3QuZW50cmllcyhwcm9wcy50YWdzKS5tYXAoKFtrZXksIHZhbHVlXSkgPT4gKHsga2V5LCB2YWx1ZSB9KSkgOiB1bmRlZmluZWQsXG4gICAgfSk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBCdWlsZCBhdHRyaWJ1dGVzXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy5pbmZlcmVuY2VQcm9maWxlQXJuID0gdGhpcy5fX3Jlc291cmNlLmF0dHJJbmZlcmVuY2VQcm9maWxlQXJuO1xuICAgIHRoaXMuaW5mZXJlbmNlUHJvZmlsZUlkID0gdGhpcy5fX3Jlc291cmNlLmF0dHJJbmZlcmVuY2VQcm9maWxlSWQ7XG4gICAgdGhpcy5pbmZlcmVuY2VQcm9maWxlTmFtZSA9IHRoaXMuX19yZXNvdXJjZS5pbmZlcmVuY2VQcm9maWxlTmFtZSE7XG4gICAgdGhpcy5zdGF0dXMgPSB0aGlzLl9fcmVzb3VyY2UuYXR0clN0YXR1cztcbiAgICB0aGlzLmNyZWF0ZWRBdCA9IHRoaXMuX19yZXNvdXJjZS5hdHRyQ3JlYXRlZEF0O1xuICAgIHRoaXMudXBkYXRlZEF0ID0gdGhpcy5fX3Jlc291cmNlLmF0dHJVcGRhdGVkQXQ7XG4gICAgdGhpcy5pbnZva2FibGVBcm4gPSB0aGlzLmluZmVyZW5jZVByb2ZpbGVBcm47XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gTUVUSE9EU1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIHRoZSBwcm9wZXJ0aWVzIGZvciBjcmVhdGluZyBhbiBBcHBsaWNhdGlvbiBJbmZlcmVuY2UgUHJvZmlsZS5cbiAgICpcbiAgICogQHBhcmFtIHByb3BzIC0gVGhlIHByb3BlcnRpZXMgdG8gdmFsaWRhdGVcbiAgICogQHRocm93cyBWYWxpZGF0aW9uRXJyb3IgaWYgYW55IHZhbGlkYXRpb24gZmFpbHNcbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVQcm9wcyhwcm9wczogQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlUHJvcHMpOiB2b2lkIHtcbiAgICAvLyBWYWxpZGF0ZSBhcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lIGlzIHByb3ZpZGVkIGFuZCBub3QgZW1wdHlcbiAgICBpZiAoIXByb3BzLmFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZU5hbWUgfHwgcHJvcHMuYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZS50cmltKCkgPT09ICcnKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdhcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lIGlzIHJlcXVpcmVkIGFuZCBjYW5ub3QgYmUgZW1wdHknLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBhcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lIGxlbmd0aFxuICAgIGlmIChwcm9wcy5hcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lLmxlbmd0aCA+IDY0KSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdhcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lIGNhbm5vdCBleGNlZWQgNjQgY2hhcmFjdGVycycsIHRoaXMpO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIGFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZU5hbWUgcGF0dGVyblxuICAgIGNvbnN0IG5hbWVQYXR0ZXJuID0gL14oWzAtOWEtekEtWjouXVsgXy1dPykrJC87XG4gICAgaWYgKCFuYW1lUGF0dGVybi50ZXN0KHByb3BzLmFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZU5hbWUpKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKFxuICAgICAgICAnYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZSBtdXN0IG1hdGNoIHBhdHRlcm4gXihbMC05YS16QS1aOi5dWyBfLV0/KSskJyxcbiAgICAgICAgdGhpcyxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgbW9kZWxTb3VyY2UgaXMgcHJvdmlkZWRcbiAgICBpZiAoIXByb3BzLm1vZGVsU291cmNlKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdtb2RlbFNvdXJjZSBpcyByZXF1aXJlZCcsIHRoaXMpO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIGRlc2NyaXB0aW9uIGxlbmd0aCBpZiBwcm92aWRlZFxuICAgIGlmIChwcm9wcy5kZXNjcmlwdGlvbiAhPT0gdW5kZWZpbmVkICYmIHByb3BzLmRlc2NyaXB0aW9uLmxlbmd0aCA+IDIwMCkge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignZGVzY3JpcHRpb24gY2Fubm90IGV4Y2VlZCAyMDAgY2hhcmFjdGVycycsIHRoaXMpO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIGRlc2NyaXB0aW9uIHBhdHRlcm4gaWYgcHJvdmlkZWRcbiAgICBpZiAocHJvcHMuZGVzY3JpcHRpb24gIT09IHVuZGVmaW5lZCAmJiBwcm9wcy5kZXNjcmlwdGlvbiAhPT0gJycpIHtcbiAgICAgIGNvbnN0IGRlc2NyaXB0aW9uUGF0dGVybiA9IC9eKFswLTlhLXpBLVo6Ll1bIF8tXT8pKyQvO1xuICAgICAgaWYgKCFkZXNjcmlwdGlvblBhdHRlcm4udGVzdChwcm9wcy5kZXNjcmlwdGlvbikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihcbiAgICAgICAgICAnZGVzY3JpcHRpb24gbXVzdCBtYXRjaCBwYXR0ZXJuIF4oWzAtOWEtekEtWjouXVsgXy1dPykrJCcsXG4gICAgICAgICAgdGhpcyxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogR2l2ZXMgdGhlIGFwcHJvcHJpYXRlIHBvbGljaWVzIHRvIGludm9rZSBhbmQgdXNlIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogVGhpcyBtZXRob2QgZW5zdXJlcyB0aGUgYXBwcm9wcmlhdGUgcGVybWlzc2lvbnMgYXJlIGdpdmVuIHRvIHVzZSBlaXRoZXIgdGhlIGluZmVyZW5jZSBwcm9maWxlXG4gICAqIG9yIHRoZSB1bmRlcmx5aW5nIGZvdW5kYXRpb24gbW9kZWwvY3Jvc3MtcmVnaW9uIHByb2ZpbGUuXG4gICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgKlxuICAgKiBAcGFyYW0gZ3JhbnRlZSAtIFRoZSBJQU0gcHJpbmNpcGFsIHRvIGdyYW50IHBlcm1pc3Npb25zIHRvXG4gICAqIEByZXR1cm5zIEFuIElBTSBHcmFudCBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSBncmFudGVkIHBlcm1pc3Npb25zXG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgZ3JhbnRJbnZva2UoZ3JhbnRlZTogSUdyYW50YWJsZSk6IEdyYW50IHtcbiAgICAvLyBUaGlzIG1ldGhvZCBlbnN1cmVzIHRoZSBhcHByb3ByaWF0ZSBwZXJtaXNzaW9ucyBhcmUgZ2l2ZW5cbiAgICAvLyB0byB1c2UgZWl0aGVyIHRoZSBpbmZlcmVuY2UgcHJvZmlsZSBvciB0aGUgdmFuaWxsYSBmb3VuZGF0aW9uIG1vZGVsXG4gICAgdGhpcy5pbmZlcmVuY2VQcm9maWxlTW9kZWwuZ3JhbnRJbnZva2UoZ3JhbnRlZSk7XG5cbiAgICAvLyBQbHVzIHdlIGFkZCBwZXJtaXNzaW9ucyB0byBub3cgaW52b2tlIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZSBpdHNlbGZcbiAgICByZXR1cm4gdGhpcy5ncmFudFByb2ZpbGVVc2FnZShncmFudGVlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHcmFudHMgYXBwcm9wcmlhdGUgcGVybWlzc2lvbnMgdG8gdXNlIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZSAoQUlQKS5cbiAgICogVGhpcyBtZXRob2QgYWRkcyB0aGUgbmVjZXNzYXJ5IElBTSBwZXJtaXNzaW9ucyB0byBhbGxvdyB0aGUgZ3JhbnRlZSB0bzpcbiAgICogLSBHZXQgaW5mZXJlbmNlIHByb2ZpbGUgZGV0YWlscyAoYmVkcm9jazpHZXRJbmZlcmVuY2VQcm9maWxlKVxuICAgKiAtIEludm9rZSB0aGUgbW9kZWwgdGhyb3VnaCB0aGUgaW5mZXJlbmNlIHByb2ZpbGUgKGJlZHJvY2s6SW52b2tlTW9kZWwpXG4gICAqXG4gICAqIE5vdGU6IFRoaXMgZG9lcyBub3QgZ3JhbnQgcGVybWlzc2lvbnMgdG8gdXNlIHRoZSB1bmRlcmx5aW5nIG1vZGVsL2Nyb3NzLXJlZ2lvbiBwcm9maWxlIGluIHRoZSBBSVAuXG4gICAqIEZvciBjb21wcmVoZW5zaXZlIHBlcm1pc3Npb25zLCB1c2UgZ3JhbnRJbnZva2UoKSBpbnN0ZWFkLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICpcbiAgICogQHBhcmFtIGdyYW50ZWUgLSBUaGUgSUFNIHByaW5jaXBhbCB0byBncmFudCBwZXJtaXNzaW9ucyB0b1xuICAgKiBAcmV0dXJucyBBbiBJQU0gR3JhbnQgb2JqZWN0IHJlcHJlc2VudGluZyB0aGUgZ3JhbnRlZCBwZXJtaXNzaW9uc1xuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGdyYW50UHJvZmlsZVVzYWdlKGdyYW50ZWU6IElHcmFudGFibGUpOiBHcmFudCB7XG4gICAgcmV0dXJuIEdyYW50LmFkZFRvUHJpbmNpcGFsKHtcbiAgICAgIGdyYW50ZWU6IGdyYW50ZWUsXG4gICAgICBhY3Rpb25zOiBbJ2JlZHJvY2s6R2V0SW5mZXJlbmNlUHJvZmlsZScsICdiZWRyb2NrOkludm9rZU1vZGVsJ10sXG4gICAgICByZXNvdXJjZUFybnM6IFt0aGlzLmluZmVyZW5jZVByb2ZpbGVBcm5dLFxuICAgIH0pO1xuICB9XG59XG4iXX0=