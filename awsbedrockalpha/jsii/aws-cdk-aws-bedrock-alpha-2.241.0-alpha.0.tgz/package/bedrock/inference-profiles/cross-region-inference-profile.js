"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrossRegionInferenceProfile = exports.REGION_TO_GEO_AREA = exports.CrossRegionInferenceProfileRegion = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const aws_iam_1 = require("aws-cdk-lib/aws-iam");
const inference_profile_1 = require("./inference-profile");
/**
 * Error thrown when cross-region inference profile validation fails.
 */
class CrossRegionInferenceProfileError extends Error {
    constructor(message) {
        super(message);
        this.name = 'CrossRegionInferenceProfileError';
    }
}
/**
 * Geographic regions supported for cross-region inference profiles.
 * These regions help distribute traffic across multiple AWS regions for better
 * throughput and resilience during peak demands.
 */
var CrossRegionInferenceProfileRegion;
(function (CrossRegionInferenceProfileRegion) {
    /**
     * Global cross-region Inference Identifier.
     * Routes requests to any supported commercial AWS Region.
     */
    CrossRegionInferenceProfileRegion["GLOBAL"] = "global";
    /**
     * Cross-region Inference Identifier for the European area.
     * According to the model chosen, this might include:
     * - Frankfurt (`eu-central-1`)
     * - Ireland (`eu-west-1`)
     * - Paris (`eu-west-3`)
     * - London (`eu-west-2`)
     * - Stockholm (`eu-north-1`)
     * - Milan (`eu-south-1`)
     * - Spain (`eu-south-2`)
     * - Zurich (`eu-central-2`)
     */
    CrossRegionInferenceProfileRegion["EU"] = "eu";
    /**
     * Cross-region Inference Identifier for the United States area.
     * According to the model chosen, this might include:
     * - N. Virginia (`us-east-1`)
     * - Ohio (`us-east-2`)
     * - Oregon (`us-west-2`)
     */
    CrossRegionInferenceProfileRegion["US"] = "us";
    /**
     * Cross-region Inference Identifier for the US GovCloud area.
     * According to the model chosen, this might include:
     * - GovCloud US-East (`us-gov-east-1`)
     * - GovCloud US-West (`us-gov-west-1`)
     */
    CrossRegionInferenceProfileRegion["US_GOV"] = "us-gov";
    /**
     * Cross-region Inference Identifier for the Asia-Pacific area.
     * According to the model chosen, this might include:
     * - Tokyo (`ap-northeast-1`)
     * - Seoul (`ap-northeast-2`)
     * - Osaka (`ap-northeast-3`)
     * - Mumbai (`ap-south-1`)
     * - Hyderabad (`ap-south-2`)
     * - Singapore (`ap-southeast-1`)
     * - Sydney (`ap-southeast-2`)
     * - Jakarta (`ap-southeast-3`)
     * - Melbourne (`ap-southeast-4`)
     * - Malaysia (`ap-southeast-5`)
     * - Thailand (`ap-southeast-7`)
     * - Taipei (`ap-east-2`)
     * - Middle East (UAE) (`me-central-1`)
     */
    CrossRegionInferenceProfileRegion["APAC"] = "apac";
    /**
     * Cross-region Inference Identifier for the Japan area.
     * According to the model chosen, this might include:
     * - Tokyo (`ap-northeast-1`)
     * - Osaka (`ap-northeast-3`)
     */
    CrossRegionInferenceProfileRegion["JP"] = "jp";
    /**
     * Cross-region Inference Identifier for the Australia area.
     * According to the model chosen, this might include:
     * - Sydney (`ap-southeast-2`)
     * - Melbourne (`ap-southeast-4`)
     */
    CrossRegionInferenceProfileRegion["AU"] = "au";
})(CrossRegionInferenceProfileRegion || (exports.CrossRegionInferenceProfileRegion = CrossRegionInferenceProfileRegion = {}));
/**
 * Mapping of AWS regions to their corresponding geographic areas for cross-region inference.
 * This mapping is used to determine which cross-region inference profile to use based on the current region in prompt router.
 */
exports.REGION_TO_GEO_AREA = {
    // US Regions
    'us-east-1': CrossRegionInferenceProfileRegion.US, // N. Virginia
    'us-east-2': CrossRegionInferenceProfileRegion.US, // Ohio
    'us-west-2': CrossRegionInferenceProfileRegion.US, // Oregon
    // EU Regions
    'eu-central-1': CrossRegionInferenceProfileRegion.EU, // Frankfurt
    'eu-west-1': CrossRegionInferenceProfileRegion.EU, // Ireland
    'eu-west-3': CrossRegionInferenceProfileRegion.EU, // Paris
    // APAC Regions
    'ap-northeast-1': CrossRegionInferenceProfileRegion.APAC, // Tokyo
    'ap-northeast-2': CrossRegionInferenceProfileRegion.APAC, // Seoul
    'ap-south-1': CrossRegionInferenceProfileRegion.APAC, // Mumbai
    'ap-southeast-1': CrossRegionInferenceProfileRegion.APAC, // Singapore
    'ap-southeast-2': CrossRegionInferenceProfileRegion.APAC, // Sydney
};
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Cross-region inference enables you to seamlessly manage unplanned traffic
 * bursts by utilizing compute across different AWS Regions. With cross-region
 * inference, you can distribute traffic across multiple AWS Regions, enabling
 * higher throughput and enhanced resilience during periods of peak demands.
 *
 * This construct represents a system-defined inference profile that routes
 * requests across multiple regions based on availability and demand.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/cross-region-inference.html
 */
class CrossRegionInferenceProfile {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.CrossRegionInferenceProfile", version: "2.241.0-alpha.0" };
    /**
     * Creates a Cross-Region Inference Profile from the provided configuration.
     *
     * @param config - Configuration for the cross-region inference profile
     * @returns A new CrossRegionInferenceProfile instance
     * @throws ValidationError if the model doesn't support cross-region inference
     */
    static fromConfig(config) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_CrossRegionInferenceProfileProps(config);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.fromConfig);
            }
            throw error;
        }
        return new CrossRegionInferenceProfile(config);
    }
    /**
     * The unique identifier of the inference profile.
     * Format: {geoRegion}.{modelId}
     */
    inferenceProfileId;
    /**
     * The ARN of the inference profile.
     * @attribute
     */
    inferenceProfileArn;
    /**
     * The type of inference profile. Always SYSTEM_DEFINED for cross-region profiles.
     */
    type;
    /**
     * The underlying foundation model supporting cross-region inference.
     */
    inferenceProfileModel;
    /**
     * The ARN used for invoking this inference profile.
     * This equals to the inferenceProfileArn property, useful for implementing IBedrockInvokable interface.
     */
    invokableArn;
    constructor(props) {
        // Validate required properties
        if (!props.geoRegion) {
            throw new CrossRegionInferenceProfileError('geoRegion is required');
        }
        if (!props.model) {
            throw new CrossRegionInferenceProfileError('model is required');
        }
        // Validate that the model supports cross-region inference
        if (!props.model.supportsCrossRegion) {
            throw new CrossRegionInferenceProfileError(`Model ${props.model.modelId} does not support cross-region inference`);
        }
        this.type = inference_profile_1.InferenceProfileType.SYSTEM_DEFINED;
        this.inferenceProfileModel = props.model;
        this.inferenceProfileId = `${props.geoRegion}.${props.model.modelId}`;
        this.inferenceProfileArn = aws_cdk_lib_1.Arn.format({
            partition: aws_cdk_lib_1.Aws.PARTITION,
            service: 'bedrock',
            account: aws_cdk_lib_1.Aws.ACCOUNT_ID,
            region: aws_cdk_lib_1.Aws.REGION,
            resource: 'inference-profile',
            resourceName: this.inferenceProfileId,
            arnFormat: aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME,
        });
        this.invokableArn = this.inferenceProfileArn;
    }
    /**
     * Gives the appropriate policies to invoke and use the Foundation Model.
     * For cross-region inference profiles, this method grants permissions to:
     * - Invoke the model in all regions where the inference profile can route requests
     * - Use the inference profile itself
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantInvoke(grantee) {
        // For cross-region inference profiles, we need to provide permissions to invoke the model in all regions
        // where the inference profile can route requests
        this.inferenceProfileModel.grantInvokeAllRegions(grantee);
        // And we need to provide permissions to invoke the inference profile itself
        return this.grantProfileUsage(grantee);
    }
    /**
     * Grants appropriate permissions to use the cross-region inference profile.
     * This method adds the necessary IAM permissions to allow the grantee to:
     * - Get inference profile details (bedrock:GetInferenceProfile)
     * - Invoke the model through the inference profile (bedrock:InvokeModel*)
     *
     * Note: This does not grant permissions to use the underlying model directly.
     * For comprehensive permissions, use grantInvoke() instead.
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantProfileUsage(grantee) {
        return aws_iam_1.Grant.addToPrincipal({
            grantee: grantee,
            actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel*'],
            resourceArns: [this.inferenceProfileArn],
        });
    }
}
exports.CrossRegionInferenceProfile = CrossRegionInferenceProfile;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3Jvc3MtcmVnaW9uLWluZmVyZW5jZS1wcm9maWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY3Jvc3MtcmVnaW9uLWluZmVyZW5jZS1wcm9maWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsNkNBQWtEO0FBRWxELGlEQUE0QztBQUc1QywyREFBMkQ7QUFFM0Q7O0dBRUc7QUFDSCxNQUFNLGdDQUFpQyxTQUFRLEtBQUs7SUFDbEQsWUFBWSxPQUFlO1FBQ3pCLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNmLElBQUksQ0FBQyxJQUFJLEdBQUcsa0NBQWtDLENBQUM7S0FDaEQ7Q0FDRjtBQUVEOzs7O0dBSUc7QUFDSCxJQUFZLGlDQWtFWDtBQWxFRCxXQUFZLGlDQUFpQztJQUMzQzs7O09BR0c7SUFDSCxzREFBaUIsQ0FBQTtJQUNqQjs7Ozs7Ozs7Ozs7T0FXRztJQUNILDhDQUFTLENBQUE7SUFDVDs7Ozs7O09BTUc7SUFDSCw4Q0FBUyxDQUFBO0lBQ1Q7Ozs7O09BS0c7SUFDSCxzREFBaUIsQ0FBQTtJQUNqQjs7Ozs7Ozs7Ozs7Ozs7OztPQWdCRztJQUNILGtEQUFhLENBQUE7SUFDYjs7Ozs7T0FLRztJQUNILDhDQUFTLENBQUE7SUFDVDs7Ozs7T0FLRztJQUNILDhDQUFTLENBQUE7QUFDWCxDQUFDLEVBbEVXLGlDQUFpQyxpREFBakMsaUNBQWlDLFFBa0U1QztBQUVEOzs7R0FHRztBQUNVLFFBQUEsa0JBQWtCLEdBQXlEO0lBQ3RGLGFBQWE7SUFDYixXQUFXLEVBQUUsaUNBQWlDLENBQUMsRUFBRSxFQUFFLGNBQWM7SUFDakUsV0FBVyxFQUFFLGlDQUFpQyxDQUFDLEVBQUUsRUFBRSxPQUFPO0lBQzFELFdBQVcsRUFBRSxpQ0FBaUMsQ0FBQyxFQUFFLEVBQUUsU0FBUztJQUU1RCxhQUFhO0lBQ2IsY0FBYyxFQUFFLGlDQUFpQyxDQUFDLEVBQUUsRUFBRSxZQUFZO0lBQ2xFLFdBQVcsRUFBRSxpQ0FBaUMsQ0FBQyxFQUFFLEVBQUUsVUFBVTtJQUM3RCxXQUFXLEVBQUUsaUNBQWlDLENBQUMsRUFBRSxFQUFFLFFBQVE7SUFFM0QsZUFBZTtJQUNmLGdCQUFnQixFQUFFLGlDQUFpQyxDQUFDLElBQUksRUFBRSxRQUFRO0lBQ2xFLGdCQUFnQixFQUFFLGlDQUFpQyxDQUFDLElBQUksRUFBRSxRQUFRO0lBQ2xFLFlBQVksRUFBRSxpQ0FBaUMsQ0FBQyxJQUFJLEVBQUUsU0FBUztJQUMvRCxnQkFBZ0IsRUFBRSxpQ0FBaUMsQ0FBQyxJQUFJLEVBQUUsWUFBWTtJQUN0RSxnQkFBZ0IsRUFBRSxpQ0FBaUMsQ0FBQyxJQUFJLEVBQUUsU0FBUztDQUNwRSxDQUFDO0FBc0JGOzsrRUFFK0U7QUFDL0U7Ozs7Ozs7Ozs7R0FVRztBQUNILE1BQWEsMkJBQTJCOztJQUN0Qzs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsVUFBVSxDQUFDLE1BQXdDOzs7Ozs7Ozs7O1FBQy9ELE9BQU8sSUFBSSwyQkFBMkIsQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUNoRDtJQUVEOzs7T0FHRztJQUNhLGtCQUFrQixDQUFTO0lBRTNDOzs7T0FHRztJQUNhLG1CQUFtQixDQUFTO0lBRTVDOztPQUVHO0lBQ2EsSUFBSSxDQUF1QjtJQUUzQzs7T0FFRztJQUNhLHFCQUFxQixDQUF5QjtJQUU5RDs7O09BR0c7SUFDYSxZQUFZLENBQVM7SUFFckMsWUFBb0IsS0FBdUM7UUFDekQsK0JBQStCO1FBQy9CLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDckIsTUFBTSxJQUFJLGdDQUFnQyxDQUFDLHVCQUF1QixDQUFDLENBQUM7UUFDdEUsQ0FBQztRQUVELElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDakIsTUFBTSxJQUFJLGdDQUFnQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDbEUsQ0FBQztRQUVELDBEQUEwRDtRQUMxRCxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1lBQ3JDLE1BQU0sSUFBSSxnQ0FBZ0MsQ0FBQyxTQUFTLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTywwQ0FBMEMsQ0FBQyxDQUFDO1FBQ3JILENBQUM7UUFFRCxJQUFJLENBQUMsSUFBSSxHQUFHLHdDQUFvQixDQUFDLGNBQWMsQ0FBQztRQUNoRCxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUN6QyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsR0FBRyxLQUFLLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDdEUsSUFBSSxDQUFDLG1CQUFtQixHQUFHLGlCQUFHLENBQUMsTUFBTSxDQUFDO1lBQ3BDLFNBQVMsRUFBRSxpQkFBRyxDQUFDLFNBQVM7WUFDeEIsT0FBTyxFQUFFLFNBQVM7WUFDbEIsT0FBTyxFQUFFLGlCQUFHLENBQUMsVUFBVTtZQUN2QixNQUFNLEVBQUUsaUJBQUcsQ0FBQyxNQUFNO1lBQ2xCLFFBQVEsRUFBRSxtQkFBbUI7WUFDN0IsWUFBWSxFQUFFLElBQUksQ0FBQyxrQkFBa0I7WUFDckMsU0FBUyxFQUFFLHVCQUFTLENBQUMsbUJBQW1CO1NBQ3pDLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDO0tBQzlDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0ksV0FBVyxDQUFDLE9BQW1CO1FBQ3BDLHlHQUF5RztRQUN6RyxpREFBaUQ7UUFDakQsSUFBSSxDQUFDLHFCQUFxQixDQUFDLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRTFELDRFQUE0RTtRQUM1RSxPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztLQUN4QztJQUVEOzs7Ozs7Ozs7Ozs7T0FZRztJQUNJLGlCQUFpQixDQUFDLE9BQW1CO1FBQzFDLE9BQU8sZUFBSyxDQUFDLGNBQWMsQ0FBQztZQUMxQixPQUFPLEVBQUUsT0FBTztZQUNoQixPQUFPLEVBQUUsQ0FBQyw2QkFBNkIsRUFBRSxzQkFBc0IsQ0FBQztZQUNoRSxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7U0FDekMsQ0FBQyxDQUFDO0tBQ0o7O0FBNUdILGtFQTZHQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFybiwgQXJuRm9ybWF0LCBBd3MgfSBmcm9tICdhd3MtY2RrLWxpYic7XG5pbXBvcnQgdHlwZSB7IElHcmFudGFibGUgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCB7IEdyYW50IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWlhbSc7XG5pbXBvcnQgdHlwZSB7IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwsIElCZWRyb2NrSW52b2thYmxlIH0gZnJvbSAnLi4vbW9kZWxzJztcbmltcG9ydCB0eXBlIHsgSUluZmVyZW5jZVByb2ZpbGUgfSBmcm9tICcuL2luZmVyZW5jZS1wcm9maWxlJztcbmltcG9ydCB7IEluZmVyZW5jZVByb2ZpbGVUeXBlIH0gZnJvbSAnLi9pbmZlcmVuY2UtcHJvZmlsZSc7XG5cbi8qKlxuICogRXJyb3IgdGhyb3duIHdoZW4gY3Jvc3MtcmVnaW9uIGluZmVyZW5jZSBwcm9maWxlIHZhbGlkYXRpb24gZmFpbHMuXG4gKi9cbmNsYXNzIENyb3NzUmVnaW9uSW5mZXJlbmNlUHJvZmlsZUVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihtZXNzYWdlOiBzdHJpbmcpIHtcbiAgICBzdXBlcihtZXNzYWdlKTtcbiAgICB0aGlzLm5hbWUgPSAnQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlRXJyb3InO1xuICB9XG59XG5cbi8qKlxuICogR2VvZ3JhcGhpYyByZWdpb25zIHN1cHBvcnRlZCBmb3IgY3Jvc3MtcmVnaW9uIGluZmVyZW5jZSBwcm9maWxlcy5cbiAqIFRoZXNlIHJlZ2lvbnMgaGVscCBkaXN0cmlidXRlIHRyYWZmaWMgYWNyb3NzIG11bHRpcGxlIEFXUyByZWdpb25zIGZvciBiZXR0ZXJcbiAqIHRocm91Z2hwdXQgYW5kIHJlc2lsaWVuY2UgZHVyaW5nIHBlYWsgZGVtYW5kcy5cbiAqL1xuZXhwb3J0IGVudW0gQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlUmVnaW9uIHtcbiAgLyoqXG4gICAqIEdsb2JhbCBjcm9zcy1yZWdpb24gSW5mZXJlbmNlIElkZW50aWZpZXIuXG4gICAqIFJvdXRlcyByZXF1ZXN0cyB0byBhbnkgc3VwcG9ydGVkIGNvbW1lcmNpYWwgQVdTIFJlZ2lvbi5cbiAgICovXG4gIEdMT0JBTCA9ICdnbG9iYWwnLFxuICAvKipcbiAgICogQ3Jvc3MtcmVnaW9uIEluZmVyZW5jZSBJZGVudGlmaWVyIGZvciB0aGUgRXVyb3BlYW4gYXJlYS5cbiAgICogQWNjb3JkaW5nIHRvIHRoZSBtb2RlbCBjaG9zZW4sIHRoaXMgbWlnaHQgaW5jbHVkZTpcbiAgICogLSBGcmFua2Z1cnQgKGBldS1jZW50cmFsLTFgKVxuICAgKiAtIElyZWxhbmQgKGBldS13ZXN0LTFgKVxuICAgKiAtIFBhcmlzIChgZXUtd2VzdC0zYClcbiAgICogLSBMb25kb24gKGBldS13ZXN0LTJgKVxuICAgKiAtIFN0b2NraG9sbSAoYGV1LW5vcnRoLTFgKVxuICAgKiAtIE1pbGFuIChgZXUtc291dGgtMWApXG4gICAqIC0gU3BhaW4gKGBldS1zb3V0aC0yYClcbiAgICogLSBadXJpY2ggKGBldS1jZW50cmFsLTJgKVxuICAgKi9cbiAgRVUgPSAnZXUnLFxuICAvKipcbiAgICogQ3Jvc3MtcmVnaW9uIEluZmVyZW5jZSBJZGVudGlmaWVyIGZvciB0aGUgVW5pdGVkIFN0YXRlcyBhcmVhLlxuICAgKiBBY2NvcmRpbmcgdG8gdGhlIG1vZGVsIGNob3NlbiwgdGhpcyBtaWdodCBpbmNsdWRlOlxuICAgKiAtIE4uIFZpcmdpbmlhIChgdXMtZWFzdC0xYClcbiAgICogLSBPaGlvIChgdXMtZWFzdC0yYClcbiAgICogLSBPcmVnb24gKGB1cy13ZXN0LTJgKVxuICAgKi9cbiAgVVMgPSAndXMnLFxuICAvKipcbiAgICogQ3Jvc3MtcmVnaW9uIEluZmVyZW5jZSBJZGVudGlmaWVyIGZvciB0aGUgVVMgR292Q2xvdWQgYXJlYS5cbiAgICogQWNjb3JkaW5nIHRvIHRoZSBtb2RlbCBjaG9zZW4sIHRoaXMgbWlnaHQgaW5jbHVkZTpcbiAgICogLSBHb3ZDbG91ZCBVUy1FYXN0IChgdXMtZ292LWVhc3QtMWApXG4gICAqIC0gR292Q2xvdWQgVVMtV2VzdCAoYHVzLWdvdi13ZXN0LTFgKVxuICAgKi9cbiAgVVNfR09WID0gJ3VzLWdvdicsXG4gIC8qKlxuICAgKiBDcm9zcy1yZWdpb24gSW5mZXJlbmNlIElkZW50aWZpZXIgZm9yIHRoZSBBc2lhLVBhY2lmaWMgYXJlYS5cbiAgICogQWNjb3JkaW5nIHRvIHRoZSBtb2RlbCBjaG9zZW4sIHRoaXMgbWlnaHQgaW5jbHVkZTpcbiAgICogLSBUb2t5byAoYGFwLW5vcnRoZWFzdC0xYClcbiAgICogLSBTZW91bCAoYGFwLW5vcnRoZWFzdC0yYClcbiAgICogLSBPc2FrYSAoYGFwLW5vcnRoZWFzdC0zYClcbiAgICogLSBNdW1iYWkgKGBhcC1zb3V0aC0xYClcbiAgICogLSBIeWRlcmFiYWQgKGBhcC1zb3V0aC0yYClcbiAgICogLSBTaW5nYXBvcmUgKGBhcC1zb3V0aGVhc3QtMWApXG4gICAqIC0gU3lkbmV5IChgYXAtc291dGhlYXN0LTJgKVxuICAgKiAtIEpha2FydGEgKGBhcC1zb3V0aGVhc3QtM2ApXG4gICAqIC0gTWVsYm91cm5lIChgYXAtc291dGhlYXN0LTRgKVxuICAgKiAtIE1hbGF5c2lhIChgYXAtc291dGhlYXN0LTVgKVxuICAgKiAtIFRoYWlsYW5kIChgYXAtc291dGhlYXN0LTdgKVxuICAgKiAtIFRhaXBlaSAoYGFwLWVhc3QtMmApXG4gICAqIC0gTWlkZGxlIEVhc3QgKFVBRSkgKGBtZS1jZW50cmFsLTFgKVxuICAgKi9cbiAgQVBBQyA9ICdhcGFjJyxcbiAgLyoqXG4gICAqIENyb3NzLXJlZ2lvbiBJbmZlcmVuY2UgSWRlbnRpZmllciBmb3IgdGhlIEphcGFuIGFyZWEuXG4gICAqIEFjY29yZGluZyB0byB0aGUgbW9kZWwgY2hvc2VuLCB0aGlzIG1pZ2h0IGluY2x1ZGU6XG4gICAqIC0gVG9reW8gKGBhcC1ub3J0aGVhc3QtMWApXG4gICAqIC0gT3Nha2EgKGBhcC1ub3J0aGVhc3QtM2ApXG4gICAqL1xuICBKUCA9ICdqcCcsXG4gIC8qKlxuICAgKiBDcm9zcy1yZWdpb24gSW5mZXJlbmNlIElkZW50aWZpZXIgZm9yIHRoZSBBdXN0cmFsaWEgYXJlYS5cbiAgICogQWNjb3JkaW5nIHRvIHRoZSBtb2RlbCBjaG9zZW4sIHRoaXMgbWlnaHQgaW5jbHVkZTpcbiAgICogLSBTeWRuZXkgKGBhcC1zb3V0aGVhc3QtMmApXG4gICAqIC0gTWVsYm91cm5lIChgYXAtc291dGhlYXN0LTRgKVxuICAgKi9cbiAgQVUgPSAnYXUnLFxufVxuXG4vKipcbiAqIE1hcHBpbmcgb2YgQVdTIHJlZ2lvbnMgdG8gdGhlaXIgY29ycmVzcG9uZGluZyBnZW9ncmFwaGljIGFyZWFzIGZvciBjcm9zcy1yZWdpb24gaW5mZXJlbmNlLlxuICogVGhpcyBtYXBwaW5nIGlzIHVzZWQgdG8gZGV0ZXJtaW5lIHdoaWNoIGNyb3NzLXJlZ2lvbiBpbmZlcmVuY2UgcHJvZmlsZSB0byB1c2UgYmFzZWQgb24gdGhlIGN1cnJlbnQgcmVnaW9uIGluIHByb21wdCByb3V0ZXIuXG4gKi9cbmV4cG9ydCBjb25zdCBSRUdJT05fVE9fR0VPX0FSRUE6IHsgW2tleTogc3RyaW5nXTogQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlUmVnaW9uIH0gPSB7XG4gIC8vIFVTIFJlZ2lvbnNcbiAgJ3VzLWVhc3QtMSc6IENyb3NzUmVnaW9uSW5mZXJlbmNlUHJvZmlsZVJlZ2lvbi5VUywgLy8gTi4gVmlyZ2luaWFcbiAgJ3VzLWVhc3QtMic6IENyb3NzUmVnaW9uSW5mZXJlbmNlUHJvZmlsZVJlZ2lvbi5VUywgLy8gT2hpb1xuICAndXMtd2VzdC0yJzogQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlUmVnaW9uLlVTLCAvLyBPcmVnb25cblxuICAvLyBFVSBSZWdpb25zXG4gICdldS1jZW50cmFsLTEnOiBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGVSZWdpb24uRVUsIC8vIEZyYW5rZnVydFxuICAnZXUtd2VzdC0xJzogQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlUmVnaW9uLkVVLCAvLyBJcmVsYW5kXG4gICdldS13ZXN0LTMnOiBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGVSZWdpb24uRVUsIC8vIFBhcmlzXG5cbiAgLy8gQVBBQyBSZWdpb25zXG4gICdhcC1ub3J0aGVhc3QtMSc6IENyb3NzUmVnaW9uSW5mZXJlbmNlUHJvZmlsZVJlZ2lvbi5BUEFDLCAvLyBUb2t5b1xuICAnYXAtbm9ydGhlYXN0LTInOiBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGVSZWdpb24uQVBBQywgLy8gU2VvdWxcbiAgJ2FwLXNvdXRoLTEnOiBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGVSZWdpb24uQVBBQywgLy8gTXVtYmFpXG4gICdhcC1zb3V0aGVhc3QtMSc6IENyb3NzUmVnaW9uSW5mZXJlbmNlUHJvZmlsZVJlZ2lvbi5BUEFDLCAvLyBTaW5nYXBvcmVcbiAgJ2FwLXNvdXRoZWFzdC0yJzogQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlUmVnaW9uLkFQQUMsIC8vIFN5ZG5leVxufTtcblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBQUk9QUyBGT1IgTkVXIENPTlNUUlVDVFxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBjcmVhdGluZyBhIENyb3NzLVJlZ2lvbiBJbmZlcmVuY2UgUHJvZmlsZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGVQcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgZ2VvZ3JhcGhpYyByZWdpb24gd2hlcmUgdGhlIHRyYWZmaWMgaXMgZ29pbmcgdG8gYmUgZGlzdHJpYnV0ZWQuIFJvdXRpbmdcbiAgICogZmFjdG9ycyBpbiB1c2VyIHRyYWZmaWMsIGRlbWFuZCBhbmQgdXRpbGl6YXRpb24gb2YgcmVzb3VyY2VzLlxuICAgKi9cbiAgcmVhZG9ubHkgZ2VvUmVnaW9uOiBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGVSZWdpb247XG4gIC8qKlxuICAgKiBBIGZvdW5kYXRpb24gbW9kZWwgc3VwcG9ydGluZyBjcm9zcy1yZWdpb24gaW5mZXJlbmNlLlxuICAgKiBUaGUgbW9kZWwgbXVzdCBoYXZlIGNyb3NzLXJlZ2lvbiBzdXBwb3J0IGVuYWJsZWQuXG4gICAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9jcm9zcy1yZWdpb24taW5mZXJlbmNlLXN1cHBvcnQuaHRtbFxuICAgKi9cbiAgcmVhZG9ubHkgbW9kZWw6IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWw7XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgTkVXIENPTlNUUlVDVCBERUZJTklUSU9OXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIENyb3NzLXJlZ2lvbiBpbmZlcmVuY2UgZW5hYmxlcyB5b3UgdG8gc2VhbWxlc3NseSBtYW5hZ2UgdW5wbGFubmVkIHRyYWZmaWNcbiAqIGJ1cnN0cyBieSB1dGlsaXppbmcgY29tcHV0ZSBhY3Jvc3MgZGlmZmVyZW50IEFXUyBSZWdpb25zLiBXaXRoIGNyb3NzLXJlZ2lvblxuICogaW5mZXJlbmNlLCB5b3UgY2FuIGRpc3RyaWJ1dGUgdHJhZmZpYyBhY3Jvc3MgbXVsdGlwbGUgQVdTIFJlZ2lvbnMsIGVuYWJsaW5nXG4gKiBoaWdoZXIgdGhyb3VnaHB1dCBhbmQgZW5oYW5jZWQgcmVzaWxpZW5jZSBkdXJpbmcgcGVyaW9kcyBvZiBwZWFrIGRlbWFuZHMuXG4gKlxuICogVGhpcyBjb25zdHJ1Y3QgcmVwcmVzZW50cyBhIHN5c3RlbS1kZWZpbmVkIGluZmVyZW5jZSBwcm9maWxlIHRoYXQgcm91dGVzXG4gKiByZXF1ZXN0cyBhY3Jvc3MgbXVsdGlwbGUgcmVnaW9ucyBiYXNlZCBvbiBhdmFpbGFiaWxpdHkgYW5kIGRlbWFuZC5cbiAqXG4gKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9iZWRyb2NrL2xhdGVzdC91c2VyZ3VpZGUvY3Jvc3MtcmVnaW9uLWluZmVyZW5jZS5odG1sXG4gKi9cbmV4cG9ydCBjbGFzcyBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGUgaW1wbGVtZW50cyBJQmVkcm9ja0ludm9rYWJsZSwgSUluZmVyZW5jZVByb2ZpbGUge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIENyb3NzLVJlZ2lvbiBJbmZlcmVuY2UgUHJvZmlsZSBmcm9tIHRoZSBwcm92aWRlZCBjb25maWd1cmF0aW9uLlxuICAgKlxuICAgKiBAcGFyYW0gY29uZmlnIC0gQ29uZmlndXJhdGlvbiBmb3IgdGhlIGNyb3NzLXJlZ2lvbiBpbmZlcmVuY2UgcHJvZmlsZVxuICAgKiBAcmV0dXJucyBBIG5ldyBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGUgaW5zdGFuY2VcbiAgICogQHRocm93cyBWYWxpZGF0aW9uRXJyb3IgaWYgdGhlIG1vZGVsIGRvZXNuJ3Qgc3VwcG9ydCBjcm9zcy1yZWdpb24gaW5mZXJlbmNlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21Db25maWcoY29uZmlnOiBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGVQcm9wcyk6IENyb3NzUmVnaW9uSW5mZXJlbmNlUHJvZmlsZSB7XG4gICAgcmV0dXJuIG5ldyBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGUoY29uZmlnKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgdW5pcXVlIGlkZW50aWZpZXIgb2YgdGhlIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKiBGb3JtYXQ6IHtnZW9SZWdpb259Lnttb2RlbElkfVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVJZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVBcm46IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHR5cGUgb2YgaW5mZXJlbmNlIHByb2ZpbGUuIEFsd2F5cyBTWVNURU1fREVGSU5FRCBmb3IgY3Jvc3MtcmVnaW9uIHByb2ZpbGVzLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHR5cGU6IEluZmVyZW5jZVByb2ZpbGVUeXBlO1xuXG4gIC8qKlxuICAgKiBUaGUgdW5kZXJseWluZyBmb3VuZGF0aW9uIG1vZGVsIHN1cHBvcnRpbmcgY3Jvc3MtcmVnaW9uIGluZmVyZW5jZS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlTW9kZWw6IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWw7XG5cbiAgLyoqXG4gICAqIFRoZSBBUk4gdXNlZCBmb3IgaW52b2tpbmcgdGhpcyBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogVGhpcyBlcXVhbHMgdG8gdGhlIGluZmVyZW5jZVByb2ZpbGVBcm4gcHJvcGVydHksIHVzZWZ1bCBmb3IgaW1wbGVtZW50aW5nIElCZWRyb2NrSW52b2thYmxlIGludGVyZmFjZS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBpbnZva2FibGVBcm46IHN0cmluZztcblxuICBwcml2YXRlIGNvbnN0cnVjdG9yKHByb3BzOiBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGVQcm9wcykge1xuICAgIC8vIFZhbGlkYXRlIHJlcXVpcmVkIHByb3BlcnRpZXNcbiAgICBpZiAoIXByb3BzLmdlb1JlZ2lvbikge1xuICAgICAgdGhyb3cgbmV3IENyb3NzUmVnaW9uSW5mZXJlbmNlUHJvZmlsZUVycm9yKCdnZW9SZWdpb24gaXMgcmVxdWlyZWQnKTtcbiAgICB9XG5cbiAgICBpZiAoIXByb3BzLm1vZGVsKSB7XG4gICAgICB0aHJvdyBuZXcgQ3Jvc3NSZWdpb25JbmZlcmVuY2VQcm9maWxlRXJyb3IoJ21vZGVsIGlzIHJlcXVpcmVkJyk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgdGhhdCB0aGUgbW9kZWwgc3VwcG9ydHMgY3Jvc3MtcmVnaW9uIGluZmVyZW5jZVxuICAgIGlmICghcHJvcHMubW9kZWwuc3VwcG9ydHNDcm9zc1JlZ2lvbikge1xuICAgICAgdGhyb3cgbmV3IENyb3NzUmVnaW9uSW5mZXJlbmNlUHJvZmlsZUVycm9yKGBNb2RlbCAke3Byb3BzLm1vZGVsLm1vZGVsSWR9IGRvZXMgbm90IHN1cHBvcnQgY3Jvc3MtcmVnaW9uIGluZmVyZW5jZWApO1xuICAgIH1cblxuICAgIHRoaXMudHlwZSA9IEluZmVyZW5jZVByb2ZpbGVUeXBlLlNZU1RFTV9ERUZJTkVEO1xuICAgIHRoaXMuaW5mZXJlbmNlUHJvZmlsZU1vZGVsID0gcHJvcHMubW9kZWw7XG4gICAgdGhpcy5pbmZlcmVuY2VQcm9maWxlSWQgPSBgJHtwcm9wcy5nZW9SZWdpb259LiR7cHJvcHMubW9kZWwubW9kZWxJZH1gO1xuICAgIHRoaXMuaW5mZXJlbmNlUHJvZmlsZUFybiA9IEFybi5mb3JtYXQoe1xuICAgICAgcGFydGl0aW9uOiBBd3MuUEFSVElUSU9OLFxuICAgICAgc2VydmljZTogJ2JlZHJvY2snLFxuICAgICAgYWNjb3VudDogQXdzLkFDQ09VTlRfSUQsXG4gICAgICByZWdpb246IEF3cy5SRUdJT04sXG4gICAgICByZXNvdXJjZTogJ2luZmVyZW5jZS1wcm9maWxlJyxcbiAgICAgIHJlc291cmNlTmFtZTogdGhpcy5pbmZlcmVuY2VQcm9maWxlSWQsXG4gICAgICBhcm5Gb3JtYXQ6IEFybkZvcm1hdC5TTEFTSF9SRVNPVVJDRV9OQU1FLFxuICAgIH0pO1xuICAgIHRoaXMuaW52b2thYmxlQXJuID0gdGhpcy5pbmZlcmVuY2VQcm9maWxlQXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIEdpdmVzIHRoZSBhcHByb3ByaWF0ZSBwb2xpY2llcyB0byBpbnZva2UgYW5kIHVzZSB0aGUgRm91bmRhdGlvbiBNb2RlbC5cbiAgICogRm9yIGNyb3NzLXJlZ2lvbiBpbmZlcmVuY2UgcHJvZmlsZXMsIHRoaXMgbWV0aG9kIGdyYW50cyBwZXJtaXNzaW9ucyB0bzpcbiAgICogLSBJbnZva2UgdGhlIG1vZGVsIGluIGFsbCByZWdpb25zIHdoZXJlIHRoZSBpbmZlcmVuY2UgcHJvZmlsZSBjYW4gcm91dGUgcmVxdWVzdHNcbiAgICogLSBVc2UgdGhlIGluZmVyZW5jZSBwcm9maWxlIGl0c2VsZlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICpcbiAgICogQHBhcmFtIGdyYW50ZWUgLSBUaGUgSUFNIHByaW5jaXBhbCB0byBncmFudCBwZXJtaXNzaW9ucyB0b1xuICAgKiBAcmV0dXJucyBBbiBJQU0gR3JhbnQgb2JqZWN0IHJlcHJlc2VudGluZyB0aGUgZ3JhbnRlZCBwZXJtaXNzaW9uc1xuICAgKi9cbiAgcHVibGljIGdyYW50SW52b2tlKGdyYW50ZWU6IElHcmFudGFibGUpOiBHcmFudCB7XG4gICAgLy8gRm9yIGNyb3NzLXJlZ2lvbiBpbmZlcmVuY2UgcHJvZmlsZXMsIHdlIG5lZWQgdG8gcHJvdmlkZSBwZXJtaXNzaW9ucyB0byBpbnZva2UgdGhlIG1vZGVsIGluIGFsbCByZWdpb25zXG4gICAgLy8gd2hlcmUgdGhlIGluZmVyZW5jZSBwcm9maWxlIGNhbiByb3V0ZSByZXF1ZXN0c1xuICAgIHRoaXMuaW5mZXJlbmNlUHJvZmlsZU1vZGVsLmdyYW50SW52b2tlQWxsUmVnaW9ucyhncmFudGVlKTtcblxuICAgIC8vIEFuZCB3ZSBuZWVkIHRvIHByb3ZpZGUgcGVybWlzc2lvbnMgdG8gaW52b2tlIHRoZSBpbmZlcmVuY2UgcHJvZmlsZSBpdHNlbGZcbiAgICByZXR1cm4gdGhpcy5ncmFudFByb2ZpbGVVc2FnZShncmFudGVlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHcmFudHMgYXBwcm9wcmlhdGUgcGVybWlzc2lvbnMgdG8gdXNlIHRoZSBjcm9zcy1yZWdpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFRoaXMgbWV0aG9kIGFkZHMgdGhlIG5lY2Vzc2FyeSBJQU0gcGVybWlzc2lvbnMgdG8gYWxsb3cgdGhlIGdyYW50ZWUgdG86XG4gICAqIC0gR2V0IGluZmVyZW5jZSBwcm9maWxlIGRldGFpbHMgKGJlZHJvY2s6R2V0SW5mZXJlbmNlUHJvZmlsZSlcbiAgICogLSBJbnZva2UgdGhlIG1vZGVsIHRocm91Z2ggdGhlIGluZmVyZW5jZSBwcm9maWxlIChiZWRyb2NrOkludm9rZU1vZGVsKilcbiAgICpcbiAgICogTm90ZTogVGhpcyBkb2VzIG5vdCBncmFudCBwZXJtaXNzaW9ucyB0byB1c2UgdGhlIHVuZGVybHlpbmcgbW9kZWwgZGlyZWN0bHkuXG4gICAqIEZvciBjb21wcmVoZW5zaXZlIHBlcm1pc3Npb25zLCB1c2UgZ3JhbnRJbnZva2UoKSBpbnN0ZWFkLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICpcbiAgICogQHBhcmFtIGdyYW50ZWUgLSBUaGUgSUFNIHByaW5jaXBhbCB0byBncmFudCBwZXJtaXNzaW9ucyB0b1xuICAgKiBAcmV0dXJucyBBbiBJQU0gR3JhbnQgb2JqZWN0IHJlcHJlc2VudGluZyB0aGUgZ3JhbnRlZCBwZXJtaXNzaW9uc1xuICAgKi9cbiAgcHVibGljIGdyYW50UHJvZmlsZVVzYWdlKGdyYW50ZWU6IElHcmFudGFibGUpOiBHcmFudCB7XG4gICAgcmV0dXJuIEdyYW50LmFkZFRvUHJpbmNpcGFsKHtcbiAgICAgIGdyYW50ZWU6IGdyYW50ZWUsXG4gICAgICBhY3Rpb25zOiBbJ2JlZHJvY2s6R2V0SW5mZXJlbmNlUHJvZmlsZScsICdiZWRyb2NrOkludm9rZU1vZGVsKiddLFxuICAgICAgcmVzb3VyY2VBcm5zOiBbdGhpcy5pbmZlcmVuY2VQcm9maWxlQXJuXSxcbiAgICB9KTtcbiAgfVxufVxuIl19