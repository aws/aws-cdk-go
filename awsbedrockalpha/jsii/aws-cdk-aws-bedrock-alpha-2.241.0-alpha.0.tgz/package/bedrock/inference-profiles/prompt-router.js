"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptRouter = exports.DefaultPromptRouterIdentifier = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const aws_iam_1 = require("aws-cdk-lib/aws-iam");
const models_1 = require("../models");
const cross_region_inference_profile_1 = require("./cross-region-inference-profile");
/**
 * Represents identifiers for default prompt routers in Bedrock.
 * These are pre-configured routers provided by AWS that route between
 * different models in the same family for optimal performance and cost.
 */
class DefaultPromptRouterIdentifier {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.DefaultPromptRouterIdentifier", version: "2.241.0-alpha.0" };
    /**
     * Anthropic Claude V1 router configuration.
     * Routes between Claude Haiku and Claude 3.5 Sonnet models for optimal
     * balance between performance and cost.
     */
    static ANTHROPIC_CLAUDE_V1 = new DefaultPromptRouterIdentifier({
        promptRouterId: 'anthropic.claude:1',
        routingModels: [
            models_1.BedrockFoundationModel.ANTHROPIC_CLAUDE_HAIKU_V1_0,
            models_1.BedrockFoundationModel.ANTHROPIC_CLAUDE_3_5_SONNET_V1_0,
        ],
    });
    /**
     * Meta Llama 3.1 router configuration.
     * Routes between different sizes of Llama 3.1 models (8B and 70B)
     * for optimal performance based on request complexity.
     */
    static META_LLAMA_3_1 = new DefaultPromptRouterIdentifier({
        promptRouterId: 'meta.llama:1',
        routingModels: [
            models_1.BedrockFoundationModel.META_LLAMA_3_1_8B_INSTRUCT_V1,
            models_1.BedrockFoundationModel.META_LLAMA_3_1_70B_INSTRUCT_V1,
        ],
    });
    /**
     * The unique identifier for this prompt router.
     */
    promptRouterId;
    /**
     * The foundation models that this router can route between.
     */
    routingModels;
    constructor(props) {
        this.promptRouterId = props.promptRouterId;
        this.routingModels = props.routingModels;
    }
}
exports.DefaultPromptRouterIdentifier = DefaultPromptRouterIdentifier;
/**
 * Amazon Bedrock intelligent prompt routing provides a single serverless endpoint
 * for efficiently routing requests between different foundational models within
 * the same model family. It can help you optimize for response quality and cost.
 *
 * Intelligent prompt routing predicts the performance of each model for each request,
 * and dynamically routes each request to the model that it predicts is most likely
 * to give the desired response at the lowest cost.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/prompt-routing.html
 */
class PromptRouter {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.PromptRouter", version: "2.241.0-alpha.0" };
    /**
     * Creates a PromptRouter from a default router identifier.
     *
     * @param defaultRouter - The default router configuration to use
     * @param region - The AWS region where the router will be used
     * @returns A new PromptRouter instance configured with the default settings
     */
    static fromDefaultId(defaultRouter, region) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_DefaultPromptRouterIdentifier(defaultRouter);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.fromDefaultId);
            }
            throw error;
        }
        return new PromptRouter(defaultRouter, region);
    }
    /**
     * The ARN of the prompt router.
     * @attribute
     */
    promptRouterArn;
    /**
     * The ID of the prompt router.
     * @attribute
     */
    promptRouterId;
    /**
     * The ARN used for invoking this prompt router.
     * This equals to the promptRouterArn property, useful for implementing IBedrockInvokable interface.
     */
    invokableArn;
    /**
     * The inference endpoints (cross-region profiles) that this router will route to.
     * These are created automatically based on the routing models and region.
     */
    routingEndpoints;
    constructor(props, region) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_PromptRouterProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, PromptRouter);
            }
            throw error;
        }
        this.promptRouterId = props.promptRouterId;
        this.promptRouterArn = aws_cdk_lib_1.Arn.format({
            partition: aws_cdk_lib_1.Aws.PARTITION,
            service: 'bedrock',
            region: region,
            account: aws_cdk_lib_1.Aws.ACCOUNT_ID,
            resource: 'default-prompt-router',
            resourceName: this.promptRouterId,
            arnFormat: aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME,
        });
        // Needed to implement IBedrockInvokable
        this.invokableArn = this.promptRouterArn;
        // Build inference profiles from routing endpoints
        // Each routing model is wrapped in a cross-region inference profile
        // to enable routing across regions for better availability
        this.routingEndpoints = props.routingModels.flatMap(model => {
            const geoRegion = cross_region_inference_profile_1.REGION_TO_GEO_AREA[region];
            if (geoRegion) {
                return cross_region_inference_profile_1.CrossRegionInferenceProfile.fromConfig({
                    model: model,
                    geoRegion: geoRegion,
                });
            }
            else {
                // For unknown regions, fall back to using the model directly
                return model;
            }
        });
    }
    /**
     * Grants the necessary permissions to invoke this prompt router and all its routing endpoints.
     * This method grants permissions to:
     * - Get prompt router details (bedrock:GetPromptRouter)
     * - Invoke models through the router (bedrock:InvokeModel)
     * - Use all underlying models and cross-region profiles
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @returns An IAM Grant object representing the granted permissions
     */
    grantInvoke(grantee) {
        // Grant invoke permissions on every model endpoint of the router
        this.routingEndpoints.forEach(model => {
            model.grantInvoke(grantee);
        });
        // Grant invoke permissions to the prompt router itself
        return aws_iam_1.Grant.addToPrincipal({
            grantee,
            actions: ['bedrock:GetPromptRouter', 'bedrock:InvokeModel'],
            resourceArns: [this.promptRouterArn],
        });
    }
}
exports.PromptRouter = PromptRouter;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvbXB0LXJvdXRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInByb21wdC1yb3V0ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSw2Q0FBa0Q7QUFFbEQsaURBQTRDO0FBRTVDLHNDQUFtRDtBQUNuRCxxRkFHMEM7QUF3QzFDOzs7O0dBSUc7QUFDSCxNQUFhLDZCQUE2Qjs7SUFDeEM7Ozs7T0FJRztJQUNJLE1BQU0sQ0FBVSxtQkFBbUIsR0FBRyxJQUFJLDZCQUE2QixDQUFDO1FBQzdFLGNBQWMsRUFBRSxvQkFBb0I7UUFDcEMsYUFBYSxFQUFFO1lBQ2IsK0JBQXNCLENBQUMsMkJBQTJCO1lBQ2xELCtCQUFzQixDQUFDLGdDQUFnQztTQUN4RDtLQUNGLENBQUMsQ0FBQztJQUVIOzs7O09BSUc7SUFDSSxNQUFNLENBQVUsY0FBYyxHQUFHLElBQUksNkJBQTZCLENBQUM7UUFDeEUsY0FBYyxFQUFFLGNBQWM7UUFDOUIsYUFBYSxFQUFFO1lBQ2IsK0JBQXNCLENBQUMsNkJBQTZCO1lBQ3BELCtCQUFzQixDQUFDLDhCQUE4QjtTQUN0RDtLQUNGLENBQUMsQ0FBQztJQUVIOztPQUVHO0lBQ2EsY0FBYyxDQUFTO0lBRXZDOztPQUVHO0lBQ2EsYUFBYSxDQUEyQjtJQUV4RCxZQUFvQixLQUF3QjtRQUMxQyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUM7UUFDM0MsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDO0tBQzFDOztBQXhDSCxzRUF5Q0M7QUFFRDs7Ozs7Ozs7OztHQVVHO0FBQ0gsTUFBYSxZQUFZOztJQUN2Qjs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsYUFBYSxDQUFDLGFBQTRDLEVBQUUsTUFBYzs7Ozs7Ozs7OztRQUN0RixPQUFPLElBQUksWUFBWSxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztLQUNoRDtJQUVEOzs7T0FHRztJQUNhLGVBQWUsQ0FBUztJQUV4Qzs7O09BR0c7SUFDYSxjQUFjLENBQVM7SUFFdkM7OztPQUdHO0lBQ2EsWUFBWSxDQUFTO0lBRXJDOzs7T0FHRztJQUNhLGdCQUFnQixDQUFzQjtJQUV0RCxZQUFZLEtBQXdCLEVBQUUsTUFBYzs7Ozs7OytDQXBDekMsWUFBWTs7OztRQXFDckIsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDO1FBQzNDLElBQUksQ0FBQyxlQUFlLEdBQUcsaUJBQUcsQ0FBQyxNQUFNLENBQUM7WUFDaEMsU0FBUyxFQUFFLGlCQUFHLENBQUMsU0FBUztZQUN4QixPQUFPLEVBQUUsU0FBUztZQUNsQixNQUFNLEVBQUUsTUFBTTtZQUNkLE9BQU8sRUFBRSxpQkFBRyxDQUFDLFVBQVU7WUFDdkIsUUFBUSxFQUFFLHVCQUF1QjtZQUNqQyxZQUFZLEVBQUUsSUFBSSxDQUFDLGNBQWM7WUFDakMsU0FBUyxFQUFFLHVCQUFTLENBQUMsbUJBQW1CO1NBQ3pDLENBQUMsQ0FBQztRQUVILHdDQUF3QztRQUN4QyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUM7UUFFekMsa0RBQWtEO1FBQ2xELG9FQUFvRTtRQUNwRSwyREFBMkQ7UUFDM0QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzFELE1BQU0sU0FBUyxHQUFHLG1EQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzdDLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQ2QsT0FBTyw0REFBMkIsQ0FBQyxVQUFVLENBQUM7b0JBQzVDLEtBQUssRUFBRSxLQUFLO29CQUNaLFNBQVMsRUFBRSxTQUFTO2lCQUNyQixDQUFDLENBQUM7WUFDTCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sNkRBQTZEO2dCQUM3RCxPQUFPLEtBQUssQ0FBQztZQUNmLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztLQUNKO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNJLFdBQVcsQ0FBQyxPQUFtQjtRQUNwQyxpRUFBaUU7UUFDakUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNwQyxLQUFLLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzdCLENBQUMsQ0FBQyxDQUFDO1FBRUgsdURBQXVEO1FBQ3ZELE9BQU8sZUFBSyxDQUFDLGNBQWMsQ0FBQztZQUMxQixPQUFPO1lBQ1AsT0FBTyxFQUFFLENBQUMseUJBQXlCLEVBQUUscUJBQXFCLENBQUM7WUFDM0QsWUFBWSxFQUFFLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztTQUNyQyxDQUFDLENBQUM7S0FDSjs7QUEzRkgsb0NBNEZDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXJuLCBBcm5Gb3JtYXQsIEF3cyB9IGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCB0eXBlIHsgSUdyYW50YWJsZSB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0IHsgR3JhbnQgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCB0eXBlIHsgSUJlZHJvY2tJbnZva2FibGUgfSBmcm9tICcuLi9tb2RlbHMnO1xuaW1wb3J0IHsgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCB9IGZyb20gJy4uL21vZGVscyc7XG5pbXBvcnQge1xuICBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGUsXG4gIFJFR0lPTl9UT19HRU9fQVJFQSxcbn0gZnJvbSAnLi9jcm9zcy1yZWdpb24taW5mZXJlbmNlLXByb2ZpbGUnO1xuXG4vKipcbiAqIFJlcHJlc2VudHMgYSBQcm9tcHQgUm91dGVyLCB3aGljaCBwcm92aWRlcyBpbnRlbGxpZ2VudCByb3V0aW5nIGJldHdlZW4gZGlmZmVyZW50IG1vZGVscy5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBJUHJvbXB0Um91dGVyIHtcbiAgLyoqXG4gICAqIFRoZSBBUk4gb2YgdGhlIHByb21wdCByb3V0ZXIuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHJlYWRvbmx5IHByb21wdFJvdXRlckFybjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgSUQgb2YgdGhlIHByb21wdCByb3V0ZXIuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHJlYWRvbmx5IHByb21wdFJvdXRlcklkOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBmb3VuZGF0aW9uIG1vZGVscyAvIHByb2ZpbGVzIHRoaXMgcm91dGVyIHdpbGwgcm91dGUgdG8uXG4gICAqL1xuICByZWFkb25seSByb3V0aW5nRW5kcG9pbnRzOiBJQmVkcm9ja0ludm9rYWJsZVtdO1xufVxuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNvbmZpZ3VyaW5nIGEgUHJvbXB0IFJvdXRlci5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBQcm9tcHRSb3V0ZXJQcm9wcyB7XG4gIC8qKlxuICAgKiBQcm9tcHQgUm91dGVyIElEIHRoYXQgaWRlbnRpZmllcyB0aGUgcm91dGluZyBjb25maWd1cmF0aW9uLlxuICAgKi9cbiAgcmVhZG9ubHkgcHJvbXB0Um91dGVySWQ6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIGZvdW5kYXRpb24gbW9kZWxzIHRoaXMgcm91dGVyIHdpbGwgcm91dGUgdG8uXG4gICAqIFRoZSByb3V0ZXIgd2lsbCBpbnRlbGxpZ2VudGx5IHNlbGVjdCBiZXR3ZWVuIHRoZXNlIG1vZGVscyBiYXNlZCBvbiB0aGUgcmVxdWVzdC5cbiAgICovXG4gIHJlYWRvbmx5IHJvdXRpbmdNb2RlbHM6IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWxbXTtcbn1cblxuLyoqXG4gKiBSZXByZXNlbnRzIGlkZW50aWZpZXJzIGZvciBkZWZhdWx0IHByb21wdCByb3V0ZXJzIGluIEJlZHJvY2suXG4gKiBUaGVzZSBhcmUgcHJlLWNvbmZpZ3VyZWQgcm91dGVycyBwcm92aWRlZCBieSBBV1MgdGhhdCByb3V0ZSBiZXR3ZWVuXG4gKiBkaWZmZXJlbnQgbW9kZWxzIGluIHRoZSBzYW1lIGZhbWlseSBmb3Igb3B0aW1hbCBwZXJmb3JtYW5jZSBhbmQgY29zdC5cbiAqL1xuZXhwb3J0IGNsYXNzIERlZmF1bHRQcm9tcHRSb3V0ZXJJZGVudGlmaWVyIHtcbiAgLyoqXG4gICAqIEFudGhyb3BpYyBDbGF1ZGUgVjEgcm91dGVyIGNvbmZpZ3VyYXRpb24uXG4gICAqIFJvdXRlcyBiZXR3ZWVuIENsYXVkZSBIYWlrdSBhbmQgQ2xhdWRlIDMuNSBTb25uZXQgbW9kZWxzIGZvciBvcHRpbWFsXG4gICAqIGJhbGFuY2UgYmV0d2VlbiBwZXJmb3JtYW5jZSBhbmQgY29zdC5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV9WMSA9IG5ldyBEZWZhdWx0UHJvbXB0Um91dGVySWRlbnRpZmllcih7XG4gICAgcHJvbXB0Um91dGVySWQ6ICdhbnRocm9waWMuY2xhdWRlOjEnLFxuICAgIHJvdXRpbmdNb2RlbHM6IFtcbiAgICAgIEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwuQU5USFJPUElDX0NMQVVERV9IQUlLVV9WMV8wLFxuICAgICAgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbC5BTlRIUk9QSUNfQ0xBVURFXzNfNV9TT05ORVRfVjFfMCxcbiAgICBdLFxuICB9KTtcblxuICAvKipcbiAgICogTWV0YSBMbGFtYSAzLjEgcm91dGVyIGNvbmZpZ3VyYXRpb24uXG4gICAqIFJvdXRlcyBiZXR3ZWVuIGRpZmZlcmVudCBzaXplcyBvZiBMbGFtYSAzLjEgbW9kZWxzICg4QiBhbmQgNzBCKVxuICAgKiBmb3Igb3B0aW1hbCBwZXJmb3JtYW5jZSBiYXNlZCBvbiByZXF1ZXN0IGNvbXBsZXhpdHkuXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1FVEFfTExBTUFfM18xID0gbmV3IERlZmF1bHRQcm9tcHRSb3V0ZXJJZGVudGlmaWVyKHtcbiAgICBwcm9tcHRSb3V0ZXJJZDogJ21ldGEubGxhbWE6MScsXG4gICAgcm91dGluZ01vZGVsczogW1xuICAgICAgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbC5NRVRBX0xMQU1BXzNfMV84Ql9JTlNUUlVDVF9WMSxcbiAgICAgIEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwuTUVUQV9MTEFNQV8zXzFfNzBCX0lOU1RSVUNUX1YxLFxuICAgIF0sXG4gIH0pO1xuXG4gIC8qKlxuICAgKiBUaGUgdW5pcXVlIGlkZW50aWZpZXIgZm9yIHRoaXMgcHJvbXB0IHJvdXRlci5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBwcm9tcHRSb3V0ZXJJZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgZm91bmRhdGlvbiBtb2RlbHMgdGhhdCB0aGlzIHJvdXRlciBjYW4gcm91dGUgYmV0d2Vlbi5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSByb3V0aW5nTW9kZWxzOiBCZWRyb2NrRm91bmRhdGlvbk1vZGVsW107XG5cbiAgcHJpdmF0ZSBjb25zdHJ1Y3Rvcihwcm9wczogUHJvbXB0Um91dGVyUHJvcHMpIHtcbiAgICB0aGlzLnByb21wdFJvdXRlcklkID0gcHJvcHMucHJvbXB0Um91dGVySWQ7XG4gICAgdGhpcy5yb3V0aW5nTW9kZWxzID0gcHJvcHMucm91dGluZ01vZGVscztcbiAgfVxufVxuXG4vKipcbiAqIEFtYXpvbiBCZWRyb2NrIGludGVsbGlnZW50IHByb21wdCByb3V0aW5nIHByb3ZpZGVzIGEgc2luZ2xlIHNlcnZlcmxlc3MgZW5kcG9pbnRcbiAqIGZvciBlZmZpY2llbnRseSByb3V0aW5nIHJlcXVlc3RzIGJldHdlZW4gZGlmZmVyZW50IGZvdW5kYXRpb25hbCBtb2RlbHMgd2l0aGluXG4gKiB0aGUgc2FtZSBtb2RlbCBmYW1pbHkuIEl0IGNhbiBoZWxwIHlvdSBvcHRpbWl6ZSBmb3IgcmVzcG9uc2UgcXVhbGl0eSBhbmQgY29zdC5cbiAqXG4gKiBJbnRlbGxpZ2VudCBwcm9tcHQgcm91dGluZyBwcmVkaWN0cyB0aGUgcGVyZm9ybWFuY2Ugb2YgZWFjaCBtb2RlbCBmb3IgZWFjaCByZXF1ZXN0LFxuICogYW5kIGR5bmFtaWNhbGx5IHJvdXRlcyBlYWNoIHJlcXVlc3QgdG8gdGhlIG1vZGVsIHRoYXQgaXQgcHJlZGljdHMgaXMgbW9zdCBsaWtlbHlcbiAqIHRvIGdpdmUgdGhlIGRlc2lyZWQgcmVzcG9uc2UgYXQgdGhlIGxvd2VzdCBjb3N0LlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9wcm9tcHQtcm91dGluZy5odG1sXG4gKi9cbmV4cG9ydCBjbGFzcyBQcm9tcHRSb3V0ZXIgaW1wbGVtZW50cyBJQmVkcm9ja0ludm9rYWJsZSwgSVByb21wdFJvdXRlciB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgUHJvbXB0Um91dGVyIGZyb20gYSBkZWZhdWx0IHJvdXRlciBpZGVudGlmaWVyLlxuICAgKlxuICAgKiBAcGFyYW0gZGVmYXVsdFJvdXRlciAtIFRoZSBkZWZhdWx0IHJvdXRlciBjb25maWd1cmF0aW9uIHRvIHVzZVxuICAgKiBAcGFyYW0gcmVnaW9uIC0gVGhlIEFXUyByZWdpb24gd2hlcmUgdGhlIHJvdXRlciB3aWxsIGJlIHVzZWRcbiAgICogQHJldHVybnMgQSBuZXcgUHJvbXB0Um91dGVyIGluc3RhbmNlIGNvbmZpZ3VyZWQgd2l0aCB0aGUgZGVmYXVsdCBzZXR0aW5nc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tRGVmYXVsdElkKGRlZmF1bHRSb3V0ZXI6IERlZmF1bHRQcm9tcHRSb3V0ZXJJZGVudGlmaWVyLCByZWdpb246IHN0cmluZyk6IFByb21wdFJvdXRlciB7XG4gICAgcmV0dXJuIG5ldyBQcm9tcHRSb3V0ZXIoZGVmYXVsdFJvdXRlciwgcmVnaW9uKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBwcm9tcHQgcm91dGVyLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgcHJvbXB0Um91dGVyQXJuOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBJRCBvZiB0aGUgcHJvbXB0IHJvdXRlci5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHByb21wdFJvdXRlcklkOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBBUk4gdXNlZCBmb3IgaW52b2tpbmcgdGhpcyBwcm9tcHQgcm91dGVyLlxuICAgKiBUaGlzIGVxdWFscyB0byB0aGUgcHJvbXB0Um91dGVyQXJuIHByb3BlcnR5LCB1c2VmdWwgZm9yIGltcGxlbWVudGluZyBJQmVkcm9ja0ludm9rYWJsZSBpbnRlcmZhY2UuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgaW52b2thYmxlQXJuOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBpbmZlcmVuY2UgZW5kcG9pbnRzIChjcm9zcy1yZWdpb24gcHJvZmlsZXMpIHRoYXQgdGhpcyByb3V0ZXIgd2lsbCByb3V0ZSB0by5cbiAgICogVGhlc2UgYXJlIGNyZWF0ZWQgYXV0b21hdGljYWxseSBiYXNlZCBvbiB0aGUgcm91dGluZyBtb2RlbHMgYW5kIHJlZ2lvbi5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSByb3V0aW5nRW5kcG9pbnRzOiBJQmVkcm9ja0ludm9rYWJsZVtdO1xuXG4gIGNvbnN0cnVjdG9yKHByb3BzOiBQcm9tcHRSb3V0ZXJQcm9wcywgcmVnaW9uOiBzdHJpbmcpIHtcbiAgICB0aGlzLnByb21wdFJvdXRlcklkID0gcHJvcHMucHJvbXB0Um91dGVySWQ7XG4gICAgdGhpcy5wcm9tcHRSb3V0ZXJBcm4gPSBBcm4uZm9ybWF0KHtcbiAgICAgIHBhcnRpdGlvbjogQXdzLlBBUlRJVElPTixcbiAgICAgIHNlcnZpY2U6ICdiZWRyb2NrJyxcbiAgICAgIHJlZ2lvbjogcmVnaW9uLFxuICAgICAgYWNjb3VudDogQXdzLkFDQ09VTlRfSUQsXG4gICAgICByZXNvdXJjZTogJ2RlZmF1bHQtcHJvbXB0LXJvdXRlcicsXG4gICAgICByZXNvdXJjZU5hbWU6IHRoaXMucHJvbXB0Um91dGVySWQsXG4gICAgICBhcm5Gb3JtYXQ6IEFybkZvcm1hdC5TTEFTSF9SRVNPVVJDRV9OQU1FLFxuICAgIH0pO1xuXG4gICAgLy8gTmVlZGVkIHRvIGltcGxlbWVudCBJQmVkcm9ja0ludm9rYWJsZVxuICAgIHRoaXMuaW52b2thYmxlQXJuID0gdGhpcy5wcm9tcHRSb3V0ZXJBcm47XG5cbiAgICAvLyBCdWlsZCBpbmZlcmVuY2UgcHJvZmlsZXMgZnJvbSByb3V0aW5nIGVuZHBvaW50c1xuICAgIC8vIEVhY2ggcm91dGluZyBtb2RlbCBpcyB3cmFwcGVkIGluIGEgY3Jvc3MtcmVnaW9uIGluZmVyZW5jZSBwcm9maWxlXG4gICAgLy8gdG8gZW5hYmxlIHJvdXRpbmcgYWNyb3NzIHJlZ2lvbnMgZm9yIGJldHRlciBhdmFpbGFiaWxpdHlcbiAgICB0aGlzLnJvdXRpbmdFbmRwb2ludHMgPSBwcm9wcy5yb3V0aW5nTW9kZWxzLmZsYXRNYXAobW9kZWwgPT4ge1xuICAgICAgY29uc3QgZ2VvUmVnaW9uID0gUkVHSU9OX1RPX0dFT19BUkVBW3JlZ2lvbl07XG4gICAgICBpZiAoZ2VvUmVnaW9uKSB7XG4gICAgICAgIHJldHVybiBDcm9zc1JlZ2lvbkluZmVyZW5jZVByb2ZpbGUuZnJvbUNvbmZpZyh7XG4gICAgICAgICAgbW9kZWw6IG1vZGVsLFxuICAgICAgICAgIGdlb1JlZ2lvbjogZ2VvUmVnaW9uLFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEZvciB1bmtub3duIHJlZ2lvbnMsIGZhbGwgYmFjayB0byB1c2luZyB0aGUgbW9kZWwgZGlyZWN0bHlcbiAgICAgICAgcmV0dXJuIG1vZGVsO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEdyYW50cyB0aGUgbmVjZXNzYXJ5IHBlcm1pc3Npb25zIHRvIGludm9rZSB0aGlzIHByb21wdCByb3V0ZXIgYW5kIGFsbCBpdHMgcm91dGluZyBlbmRwb2ludHMuXG4gICAqIFRoaXMgbWV0aG9kIGdyYW50cyBwZXJtaXNzaW9ucyB0bzpcbiAgICogLSBHZXQgcHJvbXB0IHJvdXRlciBkZXRhaWxzIChiZWRyb2NrOkdldFByb21wdFJvdXRlcilcbiAgICogLSBJbnZva2UgbW9kZWxzIHRocm91Z2ggdGhlIHJvdXRlciAoYmVkcm9jazpJbnZva2VNb2RlbClcbiAgICogLSBVc2UgYWxsIHVuZGVybHlpbmcgbW9kZWxzIGFuZCBjcm9zcy1yZWdpb24gcHJvZmlsZXNcbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqXG4gICAqIEBwYXJhbSBncmFudGVlIC0gVGhlIElBTSBwcmluY2lwYWwgdG8gZ3JhbnQgcGVybWlzc2lvbnMgdG9cbiAgICogQHJldHVybnMgQW4gSUFNIEdyYW50IG9iamVjdCByZXByZXNlbnRpbmcgdGhlIGdyYW50ZWQgcGVybWlzc2lvbnNcbiAgICovXG4gIHB1YmxpYyBncmFudEludm9rZShncmFudGVlOiBJR3JhbnRhYmxlKTogR3JhbnQge1xuICAgIC8vIEdyYW50IGludm9rZSBwZXJtaXNzaW9ucyBvbiBldmVyeSBtb2RlbCBlbmRwb2ludCBvZiB0aGUgcm91dGVyXG4gICAgdGhpcy5yb3V0aW5nRW5kcG9pbnRzLmZvckVhY2gobW9kZWwgPT4ge1xuICAgICAgbW9kZWwuZ3JhbnRJbnZva2UoZ3JhbnRlZSk7XG4gICAgfSk7XG5cbiAgICAvLyBHcmFudCBpbnZva2UgcGVybWlzc2lvbnMgdG8gdGhlIHByb21wdCByb3V0ZXIgaXRzZWxmXG4gICAgcmV0dXJuIEdyYW50LmFkZFRvUHJpbmNpcGFsKHtcbiAgICAgIGdyYW50ZWUsXG4gICAgICBhY3Rpb25zOiBbJ2JlZHJvY2s6R2V0UHJvbXB0Um91dGVyJywgJ2JlZHJvY2s6SW52b2tlTW9kZWwnXSxcbiAgICAgIHJlc291cmNlQXJuczogW3RoaXMucHJvbXB0Um91dGVyQXJuXSxcbiAgICB9KTtcbiAgfVxufVxuIl19