"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentActionGroup = exports.ParentActionGroupSignature = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const crypto = require("crypto");
const validation_helpers_1 = require("./validation-helpers");
/******************************************************************************
 *                           Signatures
 *****************************************************************************/
/**
 * AWS Defined signatures for enabling certain capabilities in your agent.
 */
class ParentActionGroupSignature {
    value;
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ParentActionGroupSignature", version: "2.241.0-alpha.0" };
    /**
     * Signature that allows your agent to request the user for additional information when trying to complete a task.
     */
    static USER_INPUT = new ParentActionGroupSignature('AMAZON.UserInput');
    /**
     * Signature that allows your agent to generate, run, and troubleshoot code when trying to complete a task.
     */
    static CODE_INTERPRETER = new ParentActionGroupSignature('AMAZON.CodeInterpreter');
    /**
     * Constructor should be used as a temporary solution when a new signature is supported but its implementation in CDK hasn't been added yet.
     */
    constructor(
    /**
     * The AWS-defined signature value for this action group capability.
     */
    value) {
        this.value = value;
    }
    /**
     * Returns the string representation of the signature value.
     * Used when configuring the action group in CloudFormation.
     */
    toString() {
        return this.value;
    }
}
exports.ParentActionGroupSignature = ParentActionGroupSignature;
/******************************************************************************
 *                         DEF - Action Group Class
 *****************************************************************************/
class AgentActionGroup {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AgentActionGroup", version: "2.241.0-alpha.0" };
    // ------------------------------------------------------
    // Static Constructors
    // ------------------------------------------------------
    /**
     * Defines an action group that allows your agent to request the user for
     * additional information when trying to complete a task.
     * @param enabled Specifies whether the action group is available for the agent
     */
    static userInput(enabled) {
        return new AgentActionGroup({
            name: 'UserInputAction',
            enabled: enabled,
            parentActionGroupSignature: ParentActionGroupSignature.USER_INPUT,
        });
    }
    /**
     * Defines an action group that allows your agent to request the user for
     * additional information when trying to complete a task.
     * @param enabled Specifies whether the action group is available for the agent
     */
    static codeInterpreter(enabled) {
        return new AgentActionGroup({
            name: 'CodeInterpreterAction',
            enabled: enabled,
            parentActionGroupSignature: ParentActionGroupSignature.CODE_INTERPRETER,
        });
    }
    // ------------------------------------------------------
    // Attributes
    // ------------------------------------------------------
    /**
     * The name of the action group.
     */
    name;
    /**
     * A description of the action group.
     */
    description;
    /**
     * Whether this action group is available for the agent to invoke or not.
     */
    enabled;
    /**
     * The api schema for this action group (if defined).
     */
    apiSchema;
    /**
     * The action group executor for this action group (if defined).
     */
    executor;
    /**
     * Whether to delete the resource even if it's in use.
     */
    forceDelete;
    /**
     * The function schema for this action group (if defined).
     */
    functionSchema;
    /**
     * The AWS Defined signature (if defined).
     */
    parentActionGroupSignature;
    constructor(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentActionGroupProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, AgentActionGroup);
            }
            throw error;
        }
        // Validate Props
        this.validateProps(props);
        // ------------------------------------------------------
        // Set attributes or defaults
        // ------------------------------------------------------
        this.name = props.name ?? `action_group_quick_start_${crypto.randomUUID()}`;
        this.description = props.description;
        this.apiSchema = props.apiSchema;
        this.executor = props.executor;
        this.enabled = props.enabled ?? true;
        this.forceDelete = props.forceDelete ?? false;
        this.functionSchema = props.functionSchema;
        this.parentActionGroupSignature = props.parentActionGroupSignature;
    }
    validateProps(props) {
        if (props.parentActionGroupSignature && (props.description || props.apiSchema || props.executor)) {
            throw new validation_helpers_1.ValidationError('When parentActionGroupSignature is specified, you must leave the description, ' +
                'apiSchema, and actionGroupExecutor fields blank for this action group');
        }
    }
    /**
     * Format as CFN properties
     *
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            actionGroupExecutor: this.executor?._render(),
            actionGroupName: this.name,
            actionGroupState: this.enabled ? 'ENABLED' : 'DISABLED',
            apiSchema: this.apiSchema?._render(),
            description: this.description,
            functionSchema: this.functionSchema?._render(),
            parentActionGroupSignature: this.parentActionGroupSignature?.toString(),
            skipResourceInUseCheckOnDelete: this.forceDelete,
        };
    }
}
exports.AgentActionGroup = AgentActionGroup;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWN0aW9uLWdyb3VwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYWN0aW9uLWdyb3VwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsaUNBQWlDO0FBS2pDLDZEQUF1RDtBQUV2RDs7K0VBRStFO0FBQy9FOztHQUVHO0FBQ0gsTUFBYSwwQkFBMEI7SUFnQm5COztJQWZsQjs7T0FFRztJQUNJLE1BQU0sQ0FBVSxVQUFVLEdBQUcsSUFBSSwwQkFBMEIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3ZGOztPQUVHO0lBQ0ksTUFBTSxDQUFVLGdCQUFnQixHQUFHLElBQUksMEJBQTBCLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUNuRzs7T0FFRztJQUNIO0lBQ0U7O09BRUc7SUFDYSxLQUFhO1FBQWIsVUFBSyxHQUFMLEtBQUssQ0FBUTtLQUMzQjtJQUVKOzs7T0FHRztJQUNJLFFBQVE7UUFDYixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUM7S0FDbkI7O0FBekJILGdFQTBCQztBQWlFRDs7K0VBRStFO0FBRS9FLE1BQWEsZ0JBQWdCOztJQUMzQix5REFBeUQ7SUFDekQsc0JBQXNCO0lBQ3RCLHlEQUF5RDtJQUN6RDs7OztPQUlHO0lBQ0ksTUFBTSxDQUFDLFNBQVMsQ0FBQyxPQUFnQjtRQUN0QyxPQUFPLElBQUksZ0JBQWdCLENBQUM7WUFDMUIsSUFBSSxFQUFFLGlCQUFpQjtZQUN2QixPQUFPLEVBQUUsT0FBTztZQUNoQiwwQkFBMEIsRUFBRSwwQkFBMEIsQ0FBQyxVQUFVO1NBQ2xFLENBQUMsQ0FBQztLQUNKO0lBRUQ7Ozs7T0FJRztJQUNJLE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBZ0I7UUFDNUMsT0FBTyxJQUFJLGdCQUFnQixDQUFDO1lBQzFCLElBQUksRUFBRSx1QkFBdUI7WUFDN0IsT0FBTyxFQUFFLE9BQU87WUFDaEIsMEJBQTBCLEVBQUUsMEJBQTBCLENBQUMsZ0JBQWdCO1NBQ3hFLENBQUMsQ0FBQztLQUNKO0lBRUQseURBQXlEO0lBQ3pELGFBQWE7SUFDYix5REFBeUQ7SUFDekQ7O09BRUc7SUFDYSxJQUFJLENBQVM7SUFDN0I7O09BRUc7SUFDYSxXQUFXLENBQVU7SUFDckM7O09BRUc7SUFDYSxPQUFPLENBQVU7SUFDakM7O09BRUc7SUFDYSxTQUFTLENBQWE7SUFDdEM7O09BRUc7SUFDYSxRQUFRLENBQXVCO0lBQy9DOztPQUVHO0lBQ2EsV0FBVyxDQUFXO0lBQ3RDOztPQUVHO0lBQ2EsY0FBYyxDQUFrQjtJQUNoRDs7T0FFRztJQUNhLDBCQUEwQixDQUE4QjtJQUV4RSxZQUFtQixLQUE0Qjs7Ozs7OytDQWxFcEMsZ0JBQWdCOzs7O1FBbUV6QixpQkFBaUI7UUFDakIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUUxQix5REFBeUQ7UUFDekQsNkJBQTZCO1FBQzdCLHlEQUF5RDtRQUN6RCxJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLElBQUksNEJBQTRCLE1BQU0sQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDO1FBQzVFLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQztRQUNyQyxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7UUFDakMsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDO1FBQy9CLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUM7UUFDckMsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsV0FBVyxJQUFJLEtBQUssQ0FBQztRQUM5QyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUM7UUFDM0MsSUFBSSxDQUFDLDBCQUEwQixHQUFHLEtBQUssQ0FBQywwQkFBMEIsQ0FBQztLQUNwRTtJQUVPLGFBQWEsQ0FBQyxLQUE0QjtRQUNoRCxJQUFJLEtBQUssQ0FBQywwQkFBMEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLElBQUksS0FBSyxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQztZQUNqRyxNQUFNLElBQUksb0NBQWUsQ0FDdkIsZ0ZBQWdGO2dCQUM5RSx1RUFBdUUsQ0FDMUUsQ0FBQztRQUNKLENBQUM7S0FDRjtJQUVEOzs7O09BSUc7SUFDSSxPQUFPO1FBQ1osT0FBTztZQUNMLG1CQUFtQixFQUFFLElBQUksQ0FBQyxRQUFRLEVBQUUsT0FBTyxFQUFFO1lBQzdDLGVBQWUsRUFBRSxJQUFJLENBQUMsSUFBSTtZQUMxQixnQkFBZ0IsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFVBQVU7WUFDdkQsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFO1lBQ3BDLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVztZQUM3QixjQUFjLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBRSxPQUFPLEVBQUU7WUFDOUMsMEJBQTBCLEVBQUUsSUFBSSxDQUFDLDBCQUEwQixFQUFFLFFBQVEsRUFBRTtZQUN2RSw4QkFBOEIsRUFBRSxJQUFJLENBQUMsV0FBVztTQUNqRCxDQUFDO0tBQ0g7O0FBNUdILDRDQTZHQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGNyeXB0byBmcm9tICdjcnlwdG8nO1xuaW1wb3J0IHR5cGUgeyBDZm5BZ2VudCB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1iZWRyb2NrJztcbmltcG9ydCB0eXBlIHsgQWN0aW9uR3JvdXBFeGVjdXRvciB9IGZyb20gJy4vYXBpLWV4ZWN1dG9yJztcbmltcG9ydCB0eXBlIHsgQXBpU2NoZW1hIH0gZnJvbSAnLi9hcGktc2NoZW1hJztcbmltcG9ydCB0eXBlIHsgRnVuY3Rpb25TY2hlbWEgfSBmcm9tICcuL2Z1bmN0aW9uLXNjaGVtYSc7XG5pbXBvcnQgeyBWYWxpZGF0aW9uRXJyb3IgfSBmcm9tICcuL3ZhbGlkYXRpb24taGVscGVycyc7XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgU2lnbmF0dXJlc1xuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBBV1MgRGVmaW5lZCBzaWduYXR1cmVzIGZvciBlbmFibGluZyBjZXJ0YWluIGNhcGFiaWxpdGllcyBpbiB5b3VyIGFnZW50LlxuICovXG5leHBvcnQgY2xhc3MgUGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmUge1xuICAvKipcbiAgICogU2lnbmF0dXJlIHRoYXQgYWxsb3dzIHlvdXIgYWdlbnQgdG8gcmVxdWVzdCB0aGUgdXNlciBmb3IgYWRkaXRpb25hbCBpbmZvcm1hdGlvbiB3aGVuIHRyeWluZyB0byBjb21wbGV0ZSBhIHRhc2suXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFVTRVJfSU5QVVQgPSBuZXcgUGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmUoJ0FNQVpPTi5Vc2VySW5wdXQnKTtcbiAgLyoqXG4gICAqIFNpZ25hdHVyZSB0aGF0IGFsbG93cyB5b3VyIGFnZW50IHRvIGdlbmVyYXRlLCBydW4sIGFuZCB0cm91Ymxlc2hvb3QgY29kZSB3aGVuIHRyeWluZyB0byBjb21wbGV0ZSBhIHRhc2suXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IENPREVfSU5URVJQUkVURVIgPSBuZXcgUGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmUoJ0FNQVpPTi5Db2RlSW50ZXJwcmV0ZXInKTtcbiAgLyoqXG4gICAqIENvbnN0cnVjdG9yIHNob3VsZCBiZSB1c2VkIGFzIGEgdGVtcG9yYXJ5IHNvbHV0aW9uIHdoZW4gYSBuZXcgc2lnbmF0dXJlIGlzIHN1cHBvcnRlZCBidXQgaXRzIGltcGxlbWVudGF0aW9uIGluIENESyBoYXNuJ3QgYmVlbiBhZGRlZCB5ZXQuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihcbiAgICAvKipcbiAgICAgKiBUaGUgQVdTLWRlZmluZWQgc2lnbmF0dXJlIHZhbHVlIGZvciB0aGlzIGFjdGlvbiBncm91cCBjYXBhYmlsaXR5LlxuICAgICAqL1xuICAgIHB1YmxpYyByZWFkb25seSB2YWx1ZTogc3RyaW5nLFxuICApIHt9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHN0cmluZyByZXByZXNlbnRhdGlvbiBvZiB0aGUgc2lnbmF0dXJlIHZhbHVlLlxuICAgKiBVc2VkIHdoZW4gY29uZmlndXJpbmcgdGhlIGFjdGlvbiBncm91cCBpbiBDbG91ZEZvcm1hdGlvbi5cbiAgICovXG4gIHB1YmxpYyB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gdGhpcy52YWx1ZTtcbiAgfVxufVxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgUFJPUFMgLSBBY3Rpb24gR3JvdXAgQ2xhc3NcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbmV4cG9ydCBpbnRlcmZhY2UgQWdlbnRBY3Rpb25Hcm91cFByb3BzIHtcbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBhY3Rpb24gZ3JvdXAuXG4gICAqIEBkZWZhdWx0IC0gQSB1bmlxdWUgbmFtZSBpcyBnZW5lcmF0ZWQgaW4gdGhlIGZvcm1hdCAnYWN0aW9uX2dyb3VwX3F1aWNrX3N0YXJ0X1VVSUQnXG4gICAqL1xuICByZWFkb25seSBuYW1lPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBBIGRlc2NyaXB0aW9uIG9mIHRoZSBhY3Rpb24gZ3JvdXAuXG4gICAqXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIGRlc2NyaXB0aW9uIGlzIHByb3ZpZGVkXG4gICAqL1xuICByZWFkb25seSBkZXNjcmlwdGlvbj86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIEFQSSBTY2hlbWEgZGVmaW5pbmcgdGhlIGZ1bmN0aW9ucyBhdmFpbGFibGUgdG8gdGhlIGFnZW50LlxuICAgKlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBBUEkgU2NoZW1hIGlzIHByb3ZpZGVkXG4gICAqL1xuICByZWFkb25seSBhcGlTY2hlbWE/OiBBcGlTY2hlbWE7XG5cbiAgLyoqXG4gICAqIFRoZSBhY3Rpb24gZ3JvdXAgZXhlY3V0b3IgdGhhdCBpbXBsZW1lbnRzIHRoZSBBUEkgZnVuY3Rpb25zLlxuICAgKlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBleGVjdXRvciBpcyBwcm92aWRlZFxuICAgKi9cbiAgcmVhZG9ubHkgZXhlY3V0b3I/OiBBY3Rpb25Hcm91cEV4ZWN1dG9yO1xuXG4gIC8qKlxuICAgKiBTcGVjaWZpZXMgd2hldGhlciB0aGUgYWN0aW9uIGdyb3VwIGlzIGF2YWlsYWJsZSBmb3IgdGhlIGFnZW50IHRvIGludm9rZSBvclxuICAgKiBub3Qgd2hlbiBzZW5kaW5nIGFuIEludm9rZUFnZW50IHJlcXVlc3QuXG4gICAqXG4gICAqIEBkZWZhdWx0IHRydWUgLSBUaGUgYWN0aW9uIGdyb3VwIGlzIGVuYWJsZWRcbiAgICovXG4gIHJlYWRvbmx5IGVuYWJsZWQ/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBTcGVjaWZpZXMgd2hldGhlciB0byBkZWxldGUgdGhlIHJlc291cmNlIGV2ZW4gaWYgaXQncyBpbiB1c2UuXG4gICAqXG4gICAqIEBkZWZhdWx0IGZhbHNlIC0gVGhlIHJlc291cmNlIHdpbGwgbm90IGJlIGRlbGV0ZWQgaWYgaXQncyBpbiB1c2VcbiAgICovXG4gIHJlYWRvbmx5IGZvcmNlRGVsZXRlPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogRGVmaW5lcyBmdW5jdGlvbnMgdGhhdCBlYWNoIGRlZmluZSBwYXJhbWV0ZXJzIHRoYXQgdGhlIGFnZW50IG5lZWRzIHRvIGludm9rZSBmcm9tIHRoZSB1c2VyLlxuICAgKiBOTyBMMiB5ZXQgYXMgdGhpcyBkb2Vzbid0IG1ha2UgbXVjaCBzZW5zZSBJTUhPLlxuICAgKlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBmdW5jdGlvbiBzY2hlbWEgaXMgcHJvdmlkZWRcbiAgICovXG4gIHJlYWRvbmx5IGZ1bmN0aW9uU2NoZW1hPzogRnVuY3Rpb25TY2hlbWE7XG5cbiAgLyoqXG4gICAqIFRoZSBBV1MgRGVmaW5lZCBzaWduYXR1cmUgZm9yIGVuYWJsaW5nIGNlcnRhaW4gY2FwYWJpbGl0aWVzIGluIHlvdXIgYWdlbnQuXG4gICAqIFdoZW4gdGhpcyBwcm9wZXJ0eSBpcyBzcGVjaWZpZWQsIHlvdSBtdXN0IGxlYXZlIHRoZSBkZXNjcmlwdGlvbiwgYXBpU2NoZW1hLFxuICAgKiBhbmQgYWN0aW9uR3JvdXBFeGVjdXRvciBmaWVsZHMgYmxhbmsgZm9yIHRoaXMgYWN0aW9uIGdyb3VwLlxuICAgKlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBwYXJlbnQgYWN0aW9uIGdyb3VwIHNpZ25hdHVyZSBpcyBwcm92aWRlZFxuICAgKi9cbiAgcmVhZG9ubHkgcGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmU/OiBQYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZTtcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgREVGIC0gQWN0aW9uIEdyb3VwIENsYXNzXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbmV4cG9ydCBjbGFzcyBBZ2VudEFjdGlvbkdyb3VwIHtcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIFN0YXRpYyBDb25zdHJ1Y3RvcnNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBEZWZpbmVzIGFuIGFjdGlvbiBncm91cCB0aGF0IGFsbG93cyB5b3VyIGFnZW50IHRvIHJlcXVlc3QgdGhlIHVzZXIgZm9yXG4gICAqIGFkZGl0aW9uYWwgaW5mb3JtYXRpb24gd2hlbiB0cnlpbmcgdG8gY29tcGxldGUgYSB0YXNrLlxuICAgKiBAcGFyYW0gZW5hYmxlZCBTcGVjaWZpZXMgd2hldGhlciB0aGUgYWN0aW9uIGdyb3VwIGlzIGF2YWlsYWJsZSBmb3IgdGhlIGFnZW50XG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHVzZXJJbnB1dChlbmFibGVkOiBib29sZWFuKTogQWdlbnRBY3Rpb25Hcm91cCB7XG4gICAgcmV0dXJuIG5ldyBBZ2VudEFjdGlvbkdyb3VwKHtcbiAgICAgIG5hbWU6ICdVc2VySW5wdXRBY3Rpb24nLFxuICAgICAgZW5hYmxlZDogZW5hYmxlZCxcbiAgICAgIHBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlOiBQYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZS5VU0VSX0lOUFVULFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYW4gYWN0aW9uIGdyb3VwIHRoYXQgYWxsb3dzIHlvdXIgYWdlbnQgdG8gcmVxdWVzdCB0aGUgdXNlciBmb3JcbiAgICogYWRkaXRpb25hbCBpbmZvcm1hdGlvbiB3aGVuIHRyeWluZyB0byBjb21wbGV0ZSBhIHRhc2suXG4gICAqIEBwYXJhbSBlbmFibGVkIFNwZWNpZmllcyB3aGV0aGVyIHRoZSBhY3Rpb24gZ3JvdXAgaXMgYXZhaWxhYmxlIGZvciB0aGUgYWdlbnRcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgY29kZUludGVycHJldGVyKGVuYWJsZWQ6IGJvb2xlYW4pOiBBZ2VudEFjdGlvbkdyb3VwIHtcbiAgICByZXR1cm4gbmV3IEFnZW50QWN0aW9uR3JvdXAoe1xuICAgICAgbmFtZTogJ0NvZGVJbnRlcnByZXRlckFjdGlvbicsXG4gICAgICBlbmFibGVkOiBlbmFibGVkLFxuICAgICAgcGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmU6IFBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlLkNPREVfSU5URVJQUkVURVIsXG4gICAgfSk7XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQXR0cmlidXRlc1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBhY3Rpb24gZ3JvdXAuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuICAvKipcbiAgICogQSBkZXNjcmlwdGlvbiBvZiB0aGUgYWN0aW9uIGdyb3VwLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICAvKipcbiAgICogV2hldGhlciB0aGlzIGFjdGlvbiBncm91cCBpcyBhdmFpbGFibGUgZm9yIHRoZSBhZ2VudCB0byBpbnZva2Ugb3Igbm90LlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGVuYWJsZWQ6IGJvb2xlYW47XG4gIC8qKlxuICAgKiBUaGUgYXBpIHNjaGVtYSBmb3IgdGhpcyBhY3Rpb24gZ3JvdXAgKGlmIGRlZmluZWQpLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGFwaVNjaGVtYT86IEFwaVNjaGVtYTtcbiAgLyoqXG4gICAqIFRoZSBhY3Rpb24gZ3JvdXAgZXhlY3V0b3IgZm9yIHRoaXMgYWN0aW9uIGdyb3VwIChpZiBkZWZpbmVkKS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBleGVjdXRvcj86IEFjdGlvbkdyb3VwRXhlY3V0b3I7XG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIGRlbGV0ZSB0aGUgcmVzb3VyY2UgZXZlbiBpZiBpdCdzIGluIHVzZS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBmb3JjZURlbGV0ZT86IGJvb2xlYW47XG4gIC8qKlxuICAgKiBUaGUgZnVuY3Rpb24gc2NoZW1hIGZvciB0aGlzIGFjdGlvbiBncm91cCAoaWYgZGVmaW5lZCkuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZnVuY3Rpb25TY2hlbWE/OiBGdW5jdGlvblNjaGVtYTtcbiAgLyoqXG4gICAqIFRoZSBBV1MgRGVmaW5lZCBzaWduYXR1cmUgKGlmIGRlZmluZWQpLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlPzogUGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmU7XG5cbiAgcHVibGljIGNvbnN0cnVjdG9yKHByb3BzOiBBZ2VudEFjdGlvbkdyb3VwUHJvcHMpIHtcbiAgICAvLyBWYWxpZGF0ZSBQcm9wc1xuICAgIHRoaXMudmFsaWRhdGVQcm9wcyhwcm9wcyk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBTZXQgYXR0cmlidXRlcyBvciBkZWZhdWx0c1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMubmFtZSA9IHByb3BzLm5hbWUgPz8gYGFjdGlvbl9ncm91cF9xdWlja19zdGFydF8ke2NyeXB0by5yYW5kb21VVUlEKCl9YDtcbiAgICB0aGlzLmRlc2NyaXB0aW9uID0gcHJvcHMuZGVzY3JpcHRpb247XG4gICAgdGhpcy5hcGlTY2hlbWEgPSBwcm9wcy5hcGlTY2hlbWE7XG4gICAgdGhpcy5leGVjdXRvciA9IHByb3BzLmV4ZWN1dG9yO1xuICAgIHRoaXMuZW5hYmxlZCA9IHByb3BzLmVuYWJsZWQgPz8gdHJ1ZTtcbiAgICB0aGlzLmZvcmNlRGVsZXRlID0gcHJvcHMuZm9yY2VEZWxldGUgPz8gZmFsc2U7XG4gICAgdGhpcy5mdW5jdGlvblNjaGVtYSA9IHByb3BzLmZ1bmN0aW9uU2NoZW1hO1xuICAgIHRoaXMucGFyZW50QWN0aW9uR3JvdXBTaWduYXR1cmUgPSBwcm9wcy5wYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZTtcbiAgfVxuXG4gIHByaXZhdGUgdmFsaWRhdGVQcm9wcyhwcm9wczogQWdlbnRBY3Rpb25Hcm91cFByb3BzKSB7XG4gICAgaWYgKHByb3BzLnBhcmVudEFjdGlvbkdyb3VwU2lnbmF0dXJlICYmIChwcm9wcy5kZXNjcmlwdGlvbiB8fCBwcm9wcy5hcGlTY2hlbWEgfHwgcHJvcHMuZXhlY3V0b3IpKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKFxuICAgICAgICAnV2hlbiBwYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZSBpcyBzcGVjaWZpZWQsIHlvdSBtdXN0IGxlYXZlIHRoZSBkZXNjcmlwdGlvbiwgJyArXG4gICAgICAgICAgJ2FwaVNjaGVtYSwgYW5kIGFjdGlvbkdyb3VwRXhlY3V0b3IgZmllbGRzIGJsYW5rIGZvciB0aGlzIGFjdGlvbiBncm91cCcsXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBGb3JtYXQgYXMgQ0ZOIHByb3BlcnRpZXNcbiAgICpcbiAgICogQGludGVybmFsIFRoaXMgaXMgYW4gaW50ZXJuYWwgY29yZSBmdW5jdGlvbiBhbmQgc2hvdWxkIG5vdCBiZSBjYWxsZWQgZGlyZWN0bHkuXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBDZm5BZ2VudC5BZ2VudEFjdGlvbkdyb3VwUHJvcGVydHkge1xuICAgIHJldHVybiB7XG4gICAgICBhY3Rpb25Hcm91cEV4ZWN1dG9yOiB0aGlzLmV4ZWN1dG9yPy5fcmVuZGVyKCksXG4gICAgICBhY3Rpb25Hcm91cE5hbWU6IHRoaXMubmFtZSxcbiAgICAgIGFjdGlvbkdyb3VwU3RhdGU6IHRoaXMuZW5hYmxlZCA/ICdFTkFCTEVEJyA6ICdESVNBQkxFRCcsXG4gICAgICBhcGlTY2hlbWE6IHRoaXMuYXBpU2NoZW1hPy5fcmVuZGVyKCksXG4gICAgICBkZXNjcmlwdGlvbjogdGhpcy5kZXNjcmlwdGlvbixcbiAgICAgIGZ1bmN0aW9uU2NoZW1hOiB0aGlzLmZ1bmN0aW9uU2NoZW1hPy5fcmVuZGVyKCksXG4gICAgICBwYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZTogdGhpcy5wYXJlbnRBY3Rpb25Hcm91cFNpZ25hdHVyZT8udG9TdHJpbmcoKSxcbiAgICAgIHNraXBSZXNvdXJjZUluVXNlQ2hlY2tPbkRlbGV0ZTogdGhpcy5mb3JjZURlbGV0ZSxcbiAgICB9O1xuICB9XG59XG4iXX0=