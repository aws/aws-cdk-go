"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Memory = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const core_1 = require("aws-cdk-lib/core");
const validation = require("./validation-helpers");
/**
 * Memory options for agent conversational context retention.
 * Memory enables agents to maintain context across multiple sessions and recall past interactions.
 * By default, agents retain context from the current session only.
 */
var MemoryType;
(function (MemoryType) {
    /**
     * Your agent uses memory summarization to enhance accuracy using
     * advanced prompt templates in Amazon Bedrock to call the foundation model with guidelines
     * to summarize all your sessions. You can optionally modify the default prompt template
     * or provide your own custom parser to parse model output.
     *
     * Since the summarization process takes place in an asynchronous flow after a session ends,
     * logs for any failures in summarization due to overridden template or parser will be
     * published to your AWS accounts. For more information on enabling the logging, see
     * Enable memory summarization log delivery.
     */
    MemoryType["SESSION_SUMMARY"] = "SESSION_SUMMARY";
})(MemoryType || (MemoryType = {}));
/**
 * Memory class for managing Bedrock Agent memory configurations. Enables conversational context retention
 * across multiple sessions through session identifiers. Memory context is stored with unique
 * memory IDs per user, allowing access to conversation history and summaries. Supports viewing
 * stored sessions and clearing memory.
 *
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/agents-memory.html
 */
class Memory {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.Memory", version: "2.254.0-alpha.0" };
    /**
     * Returns session summary memory with default configuration.
     * @default memoryDuration=Duration.days(30), maxRecentSessions=20
     */
    static SESSION_SUMMARY = new Memory({ memoryDuration: core_1.Duration.days(30), maxRecentSessions: 20 });
    /**
     * Creates a session summary memory with custom configuration.
     * @param props Optional memory configuration properties
     * @returns Memory instance
     */
    static sessionSummary(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_SessionSummaryMemoryProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.sessionSummary);
            }
            throw error;
        }
        return new Memory(props);
    }
    memoryDuration;
    maxRecentSessions;
    constructor(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_SessionSummaryMemoryProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, Memory);
            }
            throw error;
        }
        // Validate props
        validation.throwIfInvalid((config) => {
            let errors = [];
            // Validate memory duration is between 1 and 365 days
            if (config.memoryDuration !== undefined) {
                const days = config.memoryDuration.toDays();
                if (days < 1 || days > 365) {
                    errors.push('memoryDuration must be between 1 and 365 days');
                }
            }
            if (config.maxRecentSessions !== undefined) {
                if (config.maxRecentSessions < 1) {
                    errors.push('maxRecentSessions must be greater than 0');
                }
            }
            return errors;
        }, props);
        this.memoryDuration = props.memoryDuration;
        this.maxRecentSessions = props.maxRecentSessions;
    }
    /**
     * Render the memory configuration to a CloudFormation property.
     * @internal
     */
    _render() {
        return {
            enabledMemoryTypes: [MemoryType.SESSION_SUMMARY],
            storageDays: this.memoryDuration?.toDays() ?? 30,
            sessionSummaryConfiguration: {
                maxRecentSessions: this.maxRecentSessions ?? 20,
            },
        };
    }
}
exports.Memory = Memory;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVtb3J5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibWVtb3J5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQ0EsMkNBQTRDO0FBQzVDLG1EQUFtRDtBQUVuRDs7OztHQUlHO0FBQ0gsSUFBSyxVQWFKO0FBYkQsV0FBSyxVQUFVO0lBQ2I7Ozs7Ozs7Ozs7T0FVRztJQUNILGlEQUFtQyxDQUFBO0FBQ3JDLENBQUMsRUFiSSxVQUFVLEtBQVYsVUFBVSxRQWFkO0FBbUJEOzs7Ozs7O0dBT0c7QUFDSCxNQUFhLE1BQU07O0lBQ2pCOzs7T0FHRztJQUNJLE1BQU0sQ0FBVSxlQUFlLEdBQUcsSUFBSSxNQUFNLENBQUMsRUFBRSxjQUFjLEVBQUUsZUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxpQkFBaUIsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBRWxIOzs7O09BSUc7SUFDSSxNQUFNLENBQUMsY0FBYyxDQUFDLEtBQWdDOzs7Ozs7Ozs7O1FBQzNELE9BQU8sSUFBSSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDMUI7SUFFZ0IsY0FBYyxDQUFZO0lBQzFCLGlCQUFpQixDQUFVO0lBRTVDLFlBQVksS0FBZ0M7Ozs7OzsrQ0FuQmpDLE1BQU07Ozs7UUFvQmYsaUJBQWlCO1FBQ2pCLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFpQyxFQUFFLEVBQUU7WUFDOUQsSUFBSSxNQUFNLEdBQWEsRUFBRSxDQUFDO1lBRTFCLHFEQUFxRDtZQUNyRCxJQUFJLE1BQU0sQ0FBQyxjQUFjLEtBQUssU0FBUyxFQUFFLENBQUM7Z0JBQ3hDLE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQzVDLElBQUksSUFBSSxHQUFHLENBQUMsSUFBSSxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7b0JBQzNCLE1BQU0sQ0FBQyxJQUFJLENBQUMsK0NBQStDLENBQUMsQ0FBQztnQkFDL0QsQ0FBQztZQUNILENBQUM7WUFDRCxJQUFJLE1BQU0sQ0FBQyxpQkFBaUIsS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDM0MsSUFBSSxNQUFNLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQ2pDLE1BQU0sQ0FBQyxJQUFJLENBQUMsMENBQTBDLENBQUMsQ0FBQztnQkFDMUQsQ0FBQztZQUNILENBQUM7WUFFRCxPQUFPLE1BQU0sQ0FBQztRQUNoQixDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFVixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUM7UUFDM0MsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztLQUNsRDtJQUVEOzs7T0FHRztJQUNJLE9BQU87UUFDWixPQUFPO1lBQ0wsa0JBQWtCLEVBQUUsQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDO1lBQ2hELFdBQVcsRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUU7WUFDaEQsMkJBQTJCLEVBQUU7Z0JBQzNCLGlCQUFpQixFQUFFLElBQUksQ0FBQyxpQkFBaUIsSUFBSSxFQUFFO2FBQ2hEO1NBQ0YsQ0FBQztLQUNIOztBQXhESCx3QkF5REMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IENmbkFnZW50IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHsgRHVyYXRpb24gfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlJztcbmltcG9ydCAqIGFzIHZhbGlkYXRpb24gZnJvbSAnLi92YWxpZGF0aW9uLWhlbHBlcnMnO1xuXG4vKipcbiAqIE1lbW9yeSBvcHRpb25zIGZvciBhZ2VudCBjb252ZXJzYXRpb25hbCBjb250ZXh0IHJldGVudGlvbi5cbiAqIE1lbW9yeSBlbmFibGVzIGFnZW50cyB0byBtYWludGFpbiBjb250ZXh0IGFjcm9zcyBtdWx0aXBsZSBzZXNzaW9ucyBhbmQgcmVjYWxsIHBhc3QgaW50ZXJhY3Rpb25zLlxuICogQnkgZGVmYXVsdCwgYWdlbnRzIHJldGFpbiBjb250ZXh0IGZyb20gdGhlIGN1cnJlbnQgc2Vzc2lvbiBvbmx5LlxuICovXG5lbnVtIE1lbW9yeVR5cGUge1xuICAvKipcbiAgICogWW91ciBhZ2VudCB1c2VzIG1lbW9yeSBzdW1tYXJpemF0aW9uIHRvIGVuaGFuY2UgYWNjdXJhY3kgdXNpbmdcbiAgICogYWR2YW5jZWQgcHJvbXB0IHRlbXBsYXRlcyBpbiBBbWF6b24gQmVkcm9jayB0byBjYWxsIHRoZSBmb3VuZGF0aW9uIG1vZGVsIHdpdGggZ3VpZGVsaW5lc1xuICAgKiB0byBzdW1tYXJpemUgYWxsIHlvdXIgc2Vzc2lvbnMuIFlvdSBjYW4gb3B0aW9uYWxseSBtb2RpZnkgdGhlIGRlZmF1bHQgcHJvbXB0IHRlbXBsYXRlXG4gICAqIG9yIHByb3ZpZGUgeW91ciBvd24gY3VzdG9tIHBhcnNlciB0byBwYXJzZSBtb2RlbCBvdXRwdXQuXG4gICAqXG4gICAqIFNpbmNlIHRoZSBzdW1tYXJpemF0aW9uIHByb2Nlc3MgdGFrZXMgcGxhY2UgaW4gYW4gYXN5bmNocm9ub3VzIGZsb3cgYWZ0ZXIgYSBzZXNzaW9uIGVuZHMsXG4gICAqIGxvZ3MgZm9yIGFueSBmYWlsdXJlcyBpbiBzdW1tYXJpemF0aW9uIGR1ZSB0byBvdmVycmlkZGVuIHRlbXBsYXRlIG9yIHBhcnNlciB3aWxsIGJlXG4gICAqIHB1Ymxpc2hlZCB0byB5b3VyIEFXUyBhY2NvdW50cy4gRm9yIG1vcmUgaW5mb3JtYXRpb24gb24gZW5hYmxpbmcgdGhlIGxvZ2dpbmcsIHNlZVxuICAgKiBFbmFibGUgbWVtb3J5IHN1bW1hcml6YXRpb24gbG9nIGRlbGl2ZXJ5LlxuICAgKi9cbiAgU0VTU0lPTl9TVU1NQVJZID0gJ1NFU1NJT05fU1VNTUFSWScsXG59XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgU2Vzc2lvblN1bW1hcnlDb25maWd1cmF0aW9uLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFNlc3Npb25TdW1tYXJ5TWVtb3J5UHJvcHMge1xuICAvKipcbiAgICogRHVyYXRpb24gZm9yIHdoaWNoIHNlc3Npb24gc3VtbWFyaWVzIGFyZSByZXRhaW5lZCAoYmV0d2VlbiAxIGFuZCAzNjUgZGF5cylcbiAgICogQGRlZmF1bHQgRHVyYXRpb24uZGF5cygzMClcbiAgICovXG4gIHJlYWRvbmx5IG1lbW9yeUR1cmF0aW9uPzogRHVyYXRpb247XG5cbiAgLyoqXG4gICAqIE1heGltdW0gbnVtYmVyIG9mIHJlY2VudCBzZXNzaW9uIHN1bW1hcmllcyB0byBpbmNsdWRlIChtaW4gMSlcbiAgICogQGRlZmF1bHQgMjBcbiAgICovXG4gIHJlYWRvbmx5IG1heFJlY2VudFNlc3Npb25zPzogbnVtYmVyO1xufVxuXG4vKipcbiAqIE1lbW9yeSBjbGFzcyBmb3IgbWFuYWdpbmcgQmVkcm9jayBBZ2VudCBtZW1vcnkgY29uZmlndXJhdGlvbnMuIEVuYWJsZXMgY29udmVyc2F0aW9uYWwgY29udGV4dCByZXRlbnRpb25cbiAqIGFjcm9zcyBtdWx0aXBsZSBzZXNzaW9ucyB0aHJvdWdoIHNlc3Npb24gaWRlbnRpZmllcnMuIE1lbW9yeSBjb250ZXh0IGlzIHN0b3JlZCB3aXRoIHVuaXF1ZVxuICogbWVtb3J5IElEcyBwZXIgdXNlciwgYWxsb3dpbmcgYWNjZXNzIHRvIGNvbnZlcnNhdGlvbiBoaXN0b3J5IGFuZCBzdW1tYXJpZXMuIFN1cHBvcnRzIHZpZXdpbmdcbiAqIHN0b3JlZCBzZXNzaW9ucyBhbmQgY2xlYXJpbmcgbWVtb3J5LlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9hZ2VudHMtbWVtb3J5Lmh0bWxcbiAqL1xuZXhwb3J0IGNsYXNzIE1lbW9yeSB7XG4gIC8qKlxuICAgKiBSZXR1cm5zIHNlc3Npb24gc3VtbWFyeSBtZW1vcnkgd2l0aCBkZWZhdWx0IGNvbmZpZ3VyYXRpb24uXG4gICAqIEBkZWZhdWx0IG1lbW9yeUR1cmF0aW9uPUR1cmF0aW9uLmRheXMoMzApLCBtYXhSZWNlbnRTZXNzaW9ucz0yMFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBTRVNTSU9OX1NVTU1BUlkgPSBuZXcgTWVtb3J5KHsgbWVtb3J5RHVyYXRpb246IER1cmF0aW9uLmRheXMoMzApLCBtYXhSZWNlbnRTZXNzaW9uczogMjAgfSk7XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBzZXNzaW9uIHN1bW1hcnkgbWVtb3J5IHdpdGggY3VzdG9tIGNvbmZpZ3VyYXRpb24uXG4gICAqIEBwYXJhbSBwcm9wcyBPcHRpb25hbCBtZW1vcnkgY29uZmlndXJhdGlvbiBwcm9wZXJ0aWVzXG4gICAqIEByZXR1cm5zIE1lbW9yeSBpbnN0YW5jZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBzZXNzaW9uU3VtbWFyeShwcm9wczogU2Vzc2lvblN1bW1hcnlNZW1vcnlQcm9wcyk6IE1lbW9yeSB7XG4gICAgcmV0dXJuIG5ldyBNZW1vcnkocHJvcHMpO1xuICB9XG5cbiAgcHJpdmF0ZSByZWFkb25seSBtZW1vcnlEdXJhdGlvbj86IER1cmF0aW9uO1xuICBwcml2YXRlIHJlYWRvbmx5IG1heFJlY2VudFNlc3Npb25zPzogbnVtYmVyO1xuXG4gIGNvbnN0cnVjdG9yKHByb3BzOiBTZXNzaW9uU3VtbWFyeU1lbW9yeVByb3BzKSB7XG4gICAgLy8gVmFsaWRhdGUgcHJvcHNcbiAgICB2YWxpZGF0aW9uLnRocm93SWZJbnZhbGlkKChjb25maWc6IFNlc3Npb25TdW1tYXJ5TWVtb3J5UHJvcHMpID0+IHtcbiAgICAgIGxldCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG5cbiAgICAgIC8vIFZhbGlkYXRlIG1lbW9yeSBkdXJhdGlvbiBpcyBiZXR3ZWVuIDEgYW5kIDM2NSBkYXlzXG4gICAgICBpZiAoY29uZmlnLm1lbW9yeUR1cmF0aW9uICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgY29uc3QgZGF5cyA9IGNvbmZpZy5tZW1vcnlEdXJhdGlvbi50b0RheXMoKTtcbiAgICAgICAgaWYgKGRheXMgPCAxIHx8IGRheXMgPiAzNjUpIHtcbiAgICAgICAgICBlcnJvcnMucHVzaCgnbWVtb3J5RHVyYXRpb24gbXVzdCBiZSBiZXR3ZWVuIDEgYW5kIDM2NSBkYXlzJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChjb25maWcubWF4UmVjZW50U2Vzc2lvbnMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBpZiAoY29uZmlnLm1heFJlY2VudFNlc3Npb25zIDwgMSkge1xuICAgICAgICAgIGVycm9ycy5wdXNoKCdtYXhSZWNlbnRTZXNzaW9ucyBtdXN0IGJlIGdyZWF0ZXIgdGhhbiAwJyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGVycm9ycztcbiAgICB9LCBwcm9wcyk7XG5cbiAgICB0aGlzLm1lbW9yeUR1cmF0aW9uID0gcHJvcHMubWVtb3J5RHVyYXRpb247XG4gICAgdGhpcy5tYXhSZWNlbnRTZXNzaW9ucyA9IHByb3BzLm1heFJlY2VudFNlc3Npb25zO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlciB0aGUgbWVtb3J5IGNvbmZpZ3VyYXRpb24gdG8gYSBDbG91ZEZvcm1hdGlvbiBwcm9wZXJ0eS5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBDZm5BZ2VudC5NZW1vcnlDb25maWd1cmF0aW9uUHJvcGVydHkge1xuICAgIHJldHVybiB7XG4gICAgICBlbmFibGVkTWVtb3J5VHlwZXM6IFtNZW1vcnlUeXBlLlNFU1NJT05fU1VNTUFSWV0sXG4gICAgICBzdG9yYWdlRGF5czogdGhpcy5tZW1vcnlEdXJhdGlvbj8udG9EYXlzKCkgPz8gMzAsXG4gICAgICBzZXNzaW9uU3VtbWFyeUNvbmZpZ3VyYXRpb246IHtcbiAgICAgICAgbWF4UmVjZW50U2Vzc2lvbnM6IHRoaXMubWF4UmVjZW50U2Vzc2lvbnMgPz8gMjAsXG4gICAgICB9LFxuICAgIH07XG4gIH1cbn1cbiJdfQ==