"use strict";
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentAlias = exports.AgentAliasBase = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const events = require("aws-cdk-lib/aws-events");
const iam = require("aws-cdk-lib/aws-iam");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
/******************************************************************************
 *                        ABSTRACT BASE CLASS
 *****************************************************************************/
/**
 * Abstract base class for an Agent.
 * Contains methods and attributes valid for Agents either created with CDK or imported.
 */
class AgentAliasBase extends aws_cdk_lib_1.Resource {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AgentAliasBase", version: "2.254.0-alpha.0" };
    /**
     * Grant the given principal identity permissions to perform actions on this agent alias.
     * Note: This grant will only work when the grantee is in the same AWS account
     * where the agent alias is defined. Cross-account grant is not supported.
     * [disable-awslint:no-grants]
     */
    grant(grantee, ...actions) {
        return iam.Grant.addToPrincipal({
            grantee,
            actions,
            resourceArns: [this.aliasArn],
        });
    }
    /**
     * Grant the given identity permissions to invoke the agent alias.
     * Note: This grant will only work when the grantee is in the same AWS account
     * where the agent alias is defined. Cross-account invocation is not supported.
     * [disable-awslint:no-grants]
     */
    grantInvoke(grantee) {
        return this.grant(grantee, 'bedrock:InvokeAgent');
    }
    /**
     * Grant the given identity permissions to get the agent alias.
     * Note: This grant will only work when the grantee is in the same AWS account
     * where the agent alias is defined. Cross-account agent read is not supported.
     * [disable-awslint:no-grants]
     */
    grantGet(grantee) {
        return this.grant(grantee, 'bedrock:GetAgentAlias');
    }
    /**
     * Define an EventBridge rule that triggers when something happens to this agent alias
     *
     * Requires that there exists at least one CloudTrail Trail in your account
     * that captures the event. This method will not create the Trail.
     *
     * @param id The id of the rule
     * @param options Options for adding the rule
     */
    onCloudTrailEvent(id, options = {}) {
        const rule = new events.Rule(this, id, options);
        rule.addTarget(options.target);
        rule.addEventPattern({
            source: ['aws.bedrock'],
            detailType: ['AWS API Call via CloudTrail'],
            detail: {
                requestParameters: {
                    agentAliasId: [this.aliasId],
                },
            },
        });
        return rule;
    }
}
exports.AgentAliasBase = AgentAliasBase;
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create an Agent Alias with CDK.
 * @cloudformationResource AWS::Bedrock::AgentAlias
 */
let AgentAlias = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = AgentAliasBase;
    var AgentAlias = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            AgentAlias = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.AgentAlias", version: "2.254.0-alpha.0" };
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.AgentAlias';
        // ------------------------------------------------------
        // Imports
        // ------------------------------------------------------
        /**
         * Brings an Agent Alias from an existing one created outside of CDK.
         */
        static fromAttributes(scope, id, attrs) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentAliasAttributes(attrs);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.fromAttributes);
                }
                throw error;
            }
            class Import extends AgentAliasBase {
                agent = attrs.agent;
                aliasId = attrs.aliasId;
                aliasName = attrs.aliasName;
                aliasArn = aws_cdk_lib_1.Stack.of(scope).formatArn({
                    resource: 'agent-alias',
                    service: 'bedrock',
                    resourceName: `${attrs.agent.agentId}/${attrs.aliasId}`,
                    arnFormat: aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME,
                });
            }
            return new Import(scope, id);
        }
        // ----------------------------------------
        // Inherited Attributes
        // ----------------------------------------
        agent;
        aliasId;
        aliasArn;
        /**
         * The name of the agent alias.
         * This is either provided by the user or generated from a hash.
         */
        aliasName;
        // ------------------------------------------------------
        // CONSTRUCTOR
        // ------------------------------------------------------
        constructor(scope, id, props) {
            super(scope, id);
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_AgentAliasProps(props);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, AgentAlias);
                }
                throw error;
            }
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            // ------------------------------------------------------
            // Set properties or defaults
            // ------------------------------------------------------
            // see https://github.com/awslabs/generative-ai-cdk-constructs/issues/947 - The default name without any version update may result in this error.
            // see https://github.com/awslabs/generative-ai-cdk-constructs/pull/1116 - If no agent version is provided then update the agent description for a new version.
            this.aliasName = props.agentAliasName ?? 'latest';
            this.agent = props.agent;
            // ------------------------------------------------------
            // L1 Instantiation
            // ------------------------------------------------------
            const alias = new aws_cdk_lib_1.aws_bedrock.CfnAgentAlias(this, 'Resource', {
                agentAliasName: this.aliasName,
                agentId: this.agent.agentId,
                description: props.description,
                routingConfiguration: props.agentVersion
                    ? [
                        {
                            agentVersion: props.agentVersion,
                        },
                    ]
                    : undefined,
            });
            this.aliasId = alias.attrAgentAliasId;
            this.aliasArn = alias.attrAgentAliasArn;
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return AgentAlias = _classThis;
})();
exports.AgentAlias = AgentAlias;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWdlbnQtYWxpYXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhZ2VudC1hbGlhcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSw2Q0FBaUY7QUFDakYsaURBQWlEO0FBQ2pELDJDQUEyQztBQUMzQyw4RUFBOEU7QUFDOUUsMEVBQTBFO0FBcUQxRTs7K0VBRStFO0FBQy9FOzs7R0FHRztBQUNILE1BQXNCLGNBQWUsU0FBUSxzQkFBUTs7SUFLbkQ7Ozs7O09BS0c7SUFDSSxLQUFLLENBQUMsT0FBdUIsRUFBRSxHQUFHLE9BQWlCO1FBQ3hELE9BQU8sR0FBRyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUM7WUFDOUIsT0FBTztZQUNQLE9BQU87WUFDUCxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1NBQzlCLENBQUMsQ0FBQztLQUNKO0lBRUQ7Ozs7O09BS0c7SUFDSSxXQUFXLENBQUMsT0FBdUI7UUFDeEMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO0tBQ25EO0lBRUQ7Ozs7O09BS0c7SUFDSSxRQUFRLENBQUMsT0FBdUI7UUFDckMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO0tBQ3JEO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSSxpQkFBaUIsQ0FBQyxFQUFVLEVBQUUsVUFBaUMsRUFBRTtRQUN0RSxNQUFNLElBQUksR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUNoRCxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMsZUFBZSxDQUFDO1lBQ25CLE1BQU0sRUFBRSxDQUFDLGFBQWEsQ0FBQztZQUN2QixVQUFVLEVBQUUsQ0FBQyw2QkFBNkIsQ0FBQztZQUMzQyxNQUFNLEVBQUU7Z0JBQ04saUJBQWlCLEVBQUU7b0JBQ2pCLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7aUJBQzdCO2FBQ0Y7U0FDRixDQUFDLENBQUM7UUFDSCxPQUFPLElBQUksQ0FBQztLQUNiOztBQTdESCx3Q0E4REM7QUEyREQ7OytFQUUrRTtBQUMvRTs7O0dBR0c7SUFFVSxVQUFVOzRCQUR0QixvQ0FBa0I7Ozs7c0JBQ2EsY0FBYzswQkFBdEIsU0FBUSxXQUFjOzs7O1lBQTlDLDZLQTJFQzs7Ozs7UUExRUMsc0NBQXNDO1FBQy9CLE1BQU0sQ0FBVSxxQkFBcUIsR0FBVyx1Q0FBdUMsQ0FBQztRQUMvRix5REFBeUQ7UUFDekQsVUFBVTtRQUNWLHlEQUF5RDtRQUN6RDs7V0FFRztRQUNJLE1BQU0sQ0FBQyxjQUFjLENBQzFCLEtBQWdCLEVBQ2hCLEVBQVUsRUFDVixLQUEyQjs7Ozs7Ozs7OztZQUUzQixNQUFNLE1BQU8sU0FBUSxjQUFjO2dCQUNqQixLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDcEIsT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQ3hCLFNBQVMsR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO2dCQUM1QixRQUFRLEdBQUcsbUJBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDO29CQUNuRCxRQUFRLEVBQUUsYUFBYTtvQkFDdkIsT0FBTyxFQUFFLFNBQVM7b0JBQ2xCLFlBQVksRUFBRSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUU7b0JBQ3ZELFNBQVMsRUFBRSx1QkFBUyxDQUFDLG1CQUFtQjtpQkFDekMsQ0FBQyxDQUFDO2FBQ0o7WUFDRCxPQUFPLElBQUksTUFBTSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztTQUM5QjtRQUVELDJDQUEyQztRQUMzQyx1QkFBdUI7UUFDdkIsMkNBQTJDO1FBQzNCLEtBQUssQ0FBUztRQUNkLE9BQU8sQ0FBUztRQUNoQixRQUFRLENBQVM7UUFDakM7OztXQUdHO1FBQ2EsU0FBUyxDQUFTO1FBRWxDLHlEQUF5RDtRQUN6RCxjQUFjO1FBQ2QseURBQXlEO1FBQ3pELFlBQVksS0FBZ0IsRUFBRSxFQUFVLEVBQUUsS0FBc0I7WUFDOUQsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQzs7Ozs7O21EQTVDUixVQUFVOzs7O1lBNkNuQixtQ0FBbUM7WUFDbkMsSUFBQSx3Q0FBb0IsRUFBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFbEMseURBQXlEO1lBQ3pELDZCQUE2QjtZQUM3Qix5REFBeUQ7WUFDekQsaUpBQWlKO1lBQ2pKLCtKQUErSjtZQUMvSixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxjQUFjLElBQUksUUFBUSxDQUFDO1lBQ2xELElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUV6Qix5REFBeUQ7WUFDekQsbUJBQW1CO1lBQ25CLHlEQUF5RDtZQUN6RCxNQUFNLEtBQUssR0FBRyxJQUFJLHlCQUFPLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxVQUFVLEVBQUU7Z0JBQ3hELGNBQWMsRUFBRSxJQUFJLENBQUMsU0FBUztnQkFDOUIsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTztnQkFDM0IsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXO2dCQUM5QixvQkFBb0IsRUFBRSxLQUFLLENBQUMsWUFBWTtvQkFDdEMsQ0FBQyxDQUFDO3dCQUNBOzRCQUNFLFlBQVksRUFBRSxLQUFLLENBQUMsWUFBWTt5QkFDakM7cUJBQ0Y7b0JBQ0QsQ0FBQyxDQUFDLFNBQVM7YUFDZCxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQztZQUN0QyxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztTQUN6Qzs7WUExRVUsdURBQVU7Ozs7O0FBQVYsZ0NBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IElSZXNvdXJjZSB9IGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCB7IEFybkZvcm1hdCwgYXdzX2JlZHJvY2sgYXMgYmVkcm9jaywgUmVzb3VyY2UsIFN0YWNrIH0gZnJvbSAnYXdzLWNkay1saWInO1xuaW1wb3J0ICogYXMgZXZlbnRzIGZyb20gJ2F3cy1jZGstbGliL2F3cy1ldmVudHMnO1xuaW1wb3J0ICogYXMgaWFtIGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0IHsgYWRkQ29uc3RydWN0TWV0YWRhdGEgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9tZXRhZGF0YS1yZXNvdXJjZSc7XG5pbXBvcnQgeyBwcm9wZXJ0eUluamVjdGFibGUgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9wcm9wLWluamVjdGFibGUnO1xuaW1wb3J0IHR5cGUgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcbmltcG9ydCB0eXBlIHsgSUFnZW50IH0gZnJvbSAnLi9hZ2VudCc7XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ09NTU9OXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIFJlcHJlc2VudHMgYW4gQWdlbnQgQWxpYXMsIGVpdGhlciBjcmVhdGVkIHdpdGggQ0RLIG9yIGltcG9ydGVkLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIElBZ2VudEFsaWFzIGV4dGVuZHMgSVJlc291cmNlIHtcbiAgLyoqXG4gICAqIFRoZSB1bmlxdWUgaWRlbnRpZmllciBvZiB0aGUgYWdlbnQgYWxpYXMuXG4gICAqIEBhdHRyaWJ1dGVzXG4gICAqL1xuICByZWFkb25seSBhbGlhc0lkOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBhZ2VudCBhbGlhcy5cbiAgICogQGF0dHJpYnV0ZXNcbiAgICovXG4gIHJlYWRvbmx5IGFsaWFzQXJuOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgdW5kZXJseWluZyBhZ2VudCBmb3IgdGhpcyBhbGlhcy5cbiAgICovXG4gIHJlYWRvbmx5IGFnZW50OiBJQWdlbnQ7XG5cbiAgLyoqXG4gICAqIEdyYW50IHRoZSBnaXZlbiBwcmluY2lwYWwgaWRlbnRpdHkgcGVybWlzc2lvbnMgdG8gcGVyZm9ybSBhY3Rpb25zIG9uIHRoaXMgYWdlbnQgYWxpYXMuXG4gICAqL1xuICBncmFudChncmFudGVlOiBpYW0uSUdyYW50YWJsZSwgLi4uYWN0aW9uczogc3RyaW5nW10pOiBpYW0uR3JhbnQ7XG5cbiAgLyoqXG4gICAqIEdyYW50IHRoZSBnaXZlbiBpZGVudGl0eSBwZXJtaXNzaW9ucyB0byBpbnZva2UgdGhlIGFnZW50IGFsaWFzLlxuICAgKi9cbiAgZ3JhbnRJbnZva2UoZ3JhbnRlZTogaWFtLklHcmFudGFibGUpOiBpYW0uR3JhbnQ7XG5cbiAgLyoqXG4gICAqIEdyYW50IHRoZSBnaXZlbiBpZGVudGl0eSBwZXJtaXNzaW9ucyB0byBnZXQgdGhlIGFnZW50IGFsaWFzLlxuICAgKi9cbiAgZ3JhbnRHZXQoZ3JhbnRlZTogaWFtLklHcmFudGFibGUpOiBpYW0uR3JhbnQ7XG5cbiAgLyoqXG4gICAqIERlZmluZSBhbiBFdmVudEJyaWRnZSBydWxlIHRoYXQgdHJpZ2dlcnMgd2hlbiBzb21ldGhpbmcgaGFwcGVucyB0byB0aGlzIGFnZW50IGFsaWFzXG4gICAqXG4gICAqIFJlcXVpcmVzIHRoYXQgdGhlcmUgZXhpc3RzIGF0IGxlYXN0IG9uZSBDbG91ZFRyYWlsIFRyYWlsIGluIHlvdXIgYWNjb3VudFxuICAgKiB0aGF0IGNhcHR1cmVzIHRoZSBldmVudC4gVGhpcyBtZXRob2Qgd2lsbCBub3QgY3JlYXRlIHRoZSBUcmFpbC5cbiAgICpcbiAgICogQHBhcmFtIGlkIFRoZSBpZCBvZiB0aGUgcnVsZVxuICAgKiBAcGFyYW0gb3B0aW9ucyBPcHRpb25zIGZvciBhZGRpbmcgdGhlIHJ1bGVcbiAgICovXG4gIG9uQ2xvdWRUcmFpbEV2ZW50KGlkOiBzdHJpbmcsIG9wdGlvbnM/OiBldmVudHMuT25FdmVudE9wdGlvbnMpOiBldmVudHMuUnVsZTtcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBBQlNUUkFDVCBCQVNFIENMQVNTXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIEFic3RyYWN0IGJhc2UgY2xhc3MgZm9yIGFuIEFnZW50LlxuICogQ29udGFpbnMgbWV0aG9kcyBhbmQgYXR0cmlidXRlcyB2YWxpZCBmb3IgQWdlbnRzIGVpdGhlciBjcmVhdGVkIHdpdGggQ0RLIG9yIGltcG9ydGVkLlxuICovXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgQWdlbnRBbGlhc0Jhc2UgZXh0ZW5kcyBSZXNvdXJjZSBpbXBsZW1lbnRzIElBZ2VudEFsaWFzIHtcbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGFsaWFzSWQ6IHN0cmluZztcbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGFsaWFzQXJuOiBzdHJpbmc7XG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSBhZ2VudDogSUFnZW50O1xuXG4gIC8qKlxuICAgKiBHcmFudCB0aGUgZ2l2ZW4gcHJpbmNpcGFsIGlkZW50aXR5IHBlcm1pc3Npb25zIHRvIHBlcmZvcm0gYWN0aW9ucyBvbiB0aGlzIGFnZW50IGFsaWFzLlxuICAgKiBOb3RlOiBUaGlzIGdyYW50IHdpbGwgb25seSB3b3JrIHdoZW4gdGhlIGdyYW50ZWUgaXMgaW4gdGhlIHNhbWUgQVdTIGFjY291bnRcbiAgICogd2hlcmUgdGhlIGFnZW50IGFsaWFzIGlzIGRlZmluZWQuIENyb3NzLWFjY291bnQgZ3JhbnQgaXMgbm90IHN1cHBvcnRlZC5cbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqL1xuICBwdWJsaWMgZ3JhbnQoZ3JhbnRlZTogaWFtLklHcmFudGFibGUsIC4uLmFjdGlvbnM6IHN0cmluZ1tdKTogaWFtLkdyYW50IHtcbiAgICByZXR1cm4gaWFtLkdyYW50LmFkZFRvUHJpbmNpcGFsKHtcbiAgICAgIGdyYW50ZWUsXG4gICAgICBhY3Rpb25zLFxuICAgICAgcmVzb3VyY2VBcm5zOiBbdGhpcy5hbGlhc0Fybl0sXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogR3JhbnQgdGhlIGdpdmVuIGlkZW50aXR5IHBlcm1pc3Npb25zIHRvIGludm9rZSB0aGUgYWdlbnQgYWxpYXMuXG4gICAqIE5vdGU6IFRoaXMgZ3JhbnQgd2lsbCBvbmx5IHdvcmsgd2hlbiB0aGUgZ3JhbnRlZSBpcyBpbiB0aGUgc2FtZSBBV1MgYWNjb3VudFxuICAgKiB3aGVyZSB0aGUgYWdlbnQgYWxpYXMgaXMgZGVmaW5lZC4gQ3Jvc3MtYWNjb3VudCBpbnZvY2F0aW9uIGlzIG5vdCBzdXBwb3J0ZWQuXG4gICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgKi9cbiAgcHVibGljIGdyYW50SW52b2tlKGdyYW50ZWU6IGlhbS5JR3JhbnRhYmxlKTogaWFtLkdyYW50IHtcbiAgICByZXR1cm4gdGhpcy5ncmFudChncmFudGVlLCAnYmVkcm9jazpJbnZva2VBZ2VudCcpO1xuICB9XG5cbiAgLyoqXG4gICAqIEdyYW50IHRoZSBnaXZlbiBpZGVudGl0eSBwZXJtaXNzaW9ucyB0byBnZXQgdGhlIGFnZW50IGFsaWFzLlxuICAgKiBOb3RlOiBUaGlzIGdyYW50IHdpbGwgb25seSB3b3JrIHdoZW4gdGhlIGdyYW50ZWUgaXMgaW4gdGhlIHNhbWUgQVdTIGFjY291bnRcbiAgICogd2hlcmUgdGhlIGFnZW50IGFsaWFzIGlzIGRlZmluZWQuIENyb3NzLWFjY291bnQgYWdlbnQgcmVhZCBpcyBub3Qgc3VwcG9ydGVkLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICovXG4gIHB1YmxpYyBncmFudEdldChncmFudGVlOiBpYW0uSUdyYW50YWJsZSk6IGlhbS5HcmFudCB7XG4gICAgcmV0dXJuIHRoaXMuZ3JhbnQoZ3JhbnRlZSwgJ2JlZHJvY2s6R2V0QWdlbnRBbGlhcycpO1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZSBhbiBFdmVudEJyaWRnZSBydWxlIHRoYXQgdHJpZ2dlcnMgd2hlbiBzb21ldGhpbmcgaGFwcGVucyB0byB0aGlzIGFnZW50IGFsaWFzXG4gICAqXG4gICAqIFJlcXVpcmVzIHRoYXQgdGhlcmUgZXhpc3RzIGF0IGxlYXN0IG9uZSBDbG91ZFRyYWlsIFRyYWlsIGluIHlvdXIgYWNjb3VudFxuICAgKiB0aGF0IGNhcHR1cmVzIHRoZSBldmVudC4gVGhpcyBtZXRob2Qgd2lsbCBub3QgY3JlYXRlIHRoZSBUcmFpbC5cbiAgICpcbiAgICogQHBhcmFtIGlkIFRoZSBpZCBvZiB0aGUgcnVsZVxuICAgKiBAcGFyYW0gb3B0aW9ucyBPcHRpb25zIGZvciBhZGRpbmcgdGhlIHJ1bGVcbiAgICovXG4gIHB1YmxpYyBvbkNsb3VkVHJhaWxFdmVudChpZDogc3RyaW5nLCBvcHRpb25zOiBldmVudHMuT25FdmVudE9wdGlvbnMgPSB7fSk6IGV2ZW50cy5SdWxlIHtcbiAgICBjb25zdCBydWxlID0gbmV3IGV2ZW50cy5SdWxlKHRoaXMsIGlkLCBvcHRpb25zKTtcbiAgICBydWxlLmFkZFRhcmdldChvcHRpb25zLnRhcmdldCk7XG4gICAgcnVsZS5hZGRFdmVudFBhdHRlcm4oe1xuICAgICAgc291cmNlOiBbJ2F3cy5iZWRyb2NrJ10sXG4gICAgICBkZXRhaWxUeXBlOiBbJ0FXUyBBUEkgQ2FsbCB2aWEgQ2xvdWRUcmFpbCddLFxuICAgICAgZGV0YWlsOiB7XG4gICAgICAgIHJlcXVlc3RQYXJhbWV0ZXJzOiB7XG4gICAgICAgICAgYWdlbnRBbGlhc0lkOiBbdGhpcy5hbGlhc0lkXSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgcmV0dXJuIHJ1bGU7XG4gIH1cbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBQUk9QUyBGT1IgTkVXIENPTlNUUlVDVFxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBjcmVhdGluZyBhIENESy1NYW5hZ2VkIEFnZW50IEFsaWFzLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFnZW50QWxpYXNQcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgbmFtZSBmb3IgdGhlIGFnZW50IGFsaWFzLlxuICAgKiBUaGlzIHdpbGwgYmUgdXNlZCBhcyB0aGUgcGh5c2ljYWwgbmFtZSBvZiB0aGUgYWdlbnQgYWxpYXMuXG4gICAqXG4gICAqIEBkZWZhdWx0IFwibGF0ZXN0XCJcbiAgICovXG4gIHJlYWRvbmx5IGFnZW50QWxpYXNOYW1lPzogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHZlcnNpb24gb2YgdGhlIGFnZW50IHRvIGFzc29jaWF0ZSB3aXRoIHRoZSBhZ2VudCBhbGlhcy5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBDcmVhdGVzIGEgbmV3IHZlcnNpb24gb2YgdGhlIGFnZW50LlxuICAgKi9cbiAgcmVhZG9ubHkgYWdlbnRWZXJzaW9uPzogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGFnZW50IGFzc29jaWF0ZWQgdG8gdGhpcyBhbGlhcy5cbiAgICovXG4gIHJlYWRvbmx5IGFnZW50OiBJQWdlbnQ7XG4gIC8qKlxuICAgKiBEZXNjcmlwdGlvbiBmb3IgdGhlIGFnZW50IGFsaWFzLlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBkZXNjcmlwdGlvbiBpcyBwcm92aWRlZFxuICAgKi9cbiAgcmVhZG9ubHkgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgIEFUVFJTIEZPUiBJTVBPUlRFRCBDT05TVFJVQ1RcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogQXR0cmlidXRlcyBuZWVkZWQgdG8gY3JlYXRlIGFuIGltcG9ydFxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFnZW50QWxpYXNBdHRyaWJ1dGVzIHtcbiAgLyoqXG4gICAqIFRoZSBJZCBvZiB0aGUgYWdlbnQgYWxpYXMuXG4gICAqL1xuICByZWFkb25seSBhbGlhc0lkOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgYWdlbnQgYWxpYXMuXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIGFsaWFzIG5hbWUgaXMgcHJvdmlkZWRcbiAgICovXG4gIHJlYWRvbmx5IGFsaWFzTmFtZT86IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSB1bmRlcmx5aW5nIGFnZW50IGZvciB0aGlzIGFsaWFzLlxuICAgKi9cbiAgcmVhZG9ubHkgYWdlbnQ6IElBZ2VudDtcbiAgLyoqXG4gICAqIFRoZSBhZ2VudCB2ZXJzaW9uIGZvciB0aGlzIGFsaWFzLlxuICAgKi9cbiAgcmVhZG9ubHkgYWdlbnRWZXJzaW9uOiBzdHJpbmc7XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgTkVXIENPTlNUUlVDVCBERUZJTklUSU9OXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIENsYXNzIHRvIGNyZWF0ZSBhbiBBZ2VudCBBbGlhcyB3aXRoIENESy5cbiAqIEBjbG91ZGZvcm1hdGlvblJlc291cmNlIEFXUzo6QmVkcm9jazo6QWdlbnRBbGlhc1xuICovXG5AcHJvcGVydHlJbmplY3RhYmxlXG5leHBvcnQgY2xhc3MgQWdlbnRBbGlhcyBleHRlbmRzIEFnZW50QWxpYXNCYXNlIHtcbiAgLyoqIFVuaXF1ZWx5IGlkZW50aWZpZXMgdGhpcyBjbGFzcy4gKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBQUk9QRVJUWV9JTkpFQ1RJT05fSUQ6IHN0cmluZyA9ICdAYXdzLWNkay5hd3MtYmVkcm9jay1hbHBoYS5BZ2VudEFsaWFzJztcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEltcG9ydHNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBCcmluZ3MgYW4gQWdlbnQgQWxpYXMgZnJvbSBhbiBleGlzdGluZyBvbmUgY3JlYXRlZCBvdXRzaWRlIG9mIENESy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUF0dHJpYnV0ZXMoXG4gICAgc2NvcGU6IENvbnN0cnVjdCxcbiAgICBpZDogc3RyaW5nLFxuICAgIGF0dHJzOiBBZ2VudEFsaWFzQXR0cmlidXRlcyxcbiAgKTogSUFnZW50QWxpYXMge1xuICAgIGNsYXNzIEltcG9ydCBleHRlbmRzIEFnZW50QWxpYXNCYXNlIHtcbiAgICAgIHB1YmxpYyByZWFkb25seSBhZ2VudCA9IGF0dHJzLmFnZW50O1xuICAgICAgcHVibGljIHJlYWRvbmx5IGFsaWFzSWQgPSBhdHRycy5hbGlhc0lkO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGFsaWFzTmFtZSA9IGF0dHJzLmFsaWFzTmFtZTtcbiAgICAgIHB1YmxpYyByZWFkb25seSBhbGlhc0FybiA9IFN0YWNrLm9mKHNjb3BlKS5mb3JtYXRBcm4oe1xuICAgICAgICByZXNvdXJjZTogJ2FnZW50LWFsaWFzJyxcbiAgICAgICAgc2VydmljZTogJ2JlZHJvY2snLFxuICAgICAgICByZXNvdXJjZU5hbWU6IGAke2F0dHJzLmFnZW50LmFnZW50SWR9LyR7YXR0cnMuYWxpYXNJZH1gLFxuICAgICAgICBhcm5Gb3JtYXQ6IEFybkZvcm1hdC5TTEFTSF9SRVNPVVJDRV9OQU1FLFxuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBuZXcgSW1wb3J0KHNjb3BlLCBpZCk7XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEluaGVyaXRlZCBBdHRyaWJ1dGVzXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgcHVibGljIHJlYWRvbmx5IGFnZW50OiBJQWdlbnQ7XG4gIHB1YmxpYyByZWFkb25seSBhbGlhc0lkOiBzdHJpbmc7XG4gIHB1YmxpYyByZWFkb25seSBhbGlhc0Fybjogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIGFnZW50IGFsaWFzLlxuICAgKiBUaGlzIGlzIGVpdGhlciBwcm92aWRlZCBieSB0aGUgdXNlciBvciBnZW5lcmF0ZWQgZnJvbSBhIGhhc2guXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgYWxpYXNOYW1lOiBzdHJpbmc7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIENPTlNUUlVDVE9SXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogQWdlbnRBbGlhc1Byb3BzKSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkKTtcbiAgICAvLyBFbmhhbmNlZCBDREsgQW5hbHl0aWNzIFRlbGVtZXRyeVxuICAgIGFkZENvbnN0cnVjdE1ldGFkYXRhKHRoaXMsIHByb3BzKTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIFNldCBwcm9wZXJ0aWVzIG9yIGRlZmF1bHRzXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9hd3NsYWJzL2dlbmVyYXRpdmUtYWktY2RrLWNvbnN0cnVjdHMvaXNzdWVzLzk0NyAtIFRoZSBkZWZhdWx0IG5hbWUgd2l0aG91dCBhbnkgdmVyc2lvbiB1cGRhdGUgbWF5IHJlc3VsdCBpbiB0aGlzIGVycm9yLlxuICAgIC8vIHNlZSBodHRwczovL2dpdGh1Yi5jb20vYXdzbGFicy9nZW5lcmF0aXZlLWFpLWNkay1jb25zdHJ1Y3RzL3B1bGwvMTExNiAtIElmIG5vIGFnZW50IHZlcnNpb24gaXMgcHJvdmlkZWQgdGhlbiB1cGRhdGUgdGhlIGFnZW50IGRlc2NyaXB0aW9uIGZvciBhIG5ldyB2ZXJzaW9uLlxuICAgIHRoaXMuYWxpYXNOYW1lID0gcHJvcHMuYWdlbnRBbGlhc05hbWUgPz8gJ2xhdGVzdCc7XG4gICAgdGhpcy5hZ2VudCA9IHByb3BzLmFnZW50O1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gTDEgSW5zdGFudGlhdGlvblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIGNvbnN0IGFsaWFzID0gbmV3IGJlZHJvY2suQ2ZuQWdlbnRBbGlhcyh0aGlzLCAnUmVzb3VyY2UnLCB7XG4gICAgICBhZ2VudEFsaWFzTmFtZTogdGhpcy5hbGlhc05hbWUsXG4gICAgICBhZ2VudElkOiB0aGlzLmFnZW50LmFnZW50SWQsXG4gICAgICBkZXNjcmlwdGlvbjogcHJvcHMuZGVzY3JpcHRpb24sXG4gICAgICByb3V0aW5nQ29uZmlndXJhdGlvbjogcHJvcHMuYWdlbnRWZXJzaW9uXG4gICAgICAgID8gW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGFnZW50VmVyc2lvbjogcHJvcHMuYWdlbnRWZXJzaW9uLFxuICAgICAgICAgIH0sXG4gICAgICAgIF1cbiAgICAgICAgOiB1bmRlZmluZWQsXG4gICAgfSk7XG5cbiAgICB0aGlzLmFsaWFzSWQgPSBhbGlhcy5hdHRyQWdlbnRBbGlhc0lkO1xuICAgIHRoaXMuYWxpYXNBcm4gPSBhbGlhcy5hdHRyQWdlbnRBbGlhc0FybjtcbiAgfVxufVxuIl19