"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatMessage = exports.ChatMessageRole = void 0;
exports.createChatPromptVariant = createChatPromptVariant;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const prompt_template_configuration_1 = require("./prompt-template-configuration");
const prompt_variant_1 = require("./prompt-variant");
/**
 * The role of a message in a chat conversation.
 */
var ChatMessageRole;
(function (ChatMessageRole) {
    /**
     * This role represents the human user in the conversation. Inputs from the
     * user guide the conversation and prompt responses from the assistant.
     */
    ChatMessageRole["USER"] = "user";
    /**
     * This is the role of the model itself, responding to user inputs based on
     * the context set by the system.
     */
    ChatMessageRole["ASSISTANT"] = "assistant";
})(ChatMessageRole || (exports.ChatMessageRole = ChatMessageRole = {}));
/**
 * Represents a message in a chat conversation.
 */
class ChatMessage {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ChatMessage", version: "2.254.0-alpha.0" };
    /**
     * Creates a user message.
     *
     * @param text - The text content of the user message
     * @returns A ChatMessage instance representing a user message
     */
    static user(text) {
        return new ChatMessage(ChatMessageRole.USER, text);
    }
    /**
     * Creates an assistant message.
     *
     * @param text - The text content of the assistant message
     * @returns A ChatMessage instance representing an assistant message
     */
    static assistant(text) {
        return new ChatMessage(ChatMessageRole.ASSISTANT, text);
    }
    /**
     * The role of the message sender.
     */
    role;
    /**
     * The text content of the message.
     */
    text;
    constructor(role, text) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ChatMessageRole(role);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, ChatMessage);
            }
            throw error;
        }
        this.role = role;
        this.text = text;
    }
    /**
     * Renders the message as a CloudFormation property.
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            role: this.role,
            content: [
                {
                    text: this.text,
                },
            ],
        };
    }
}
exports.ChatMessage = ChatMessage;
/**
 * Creates a chat template variant. Use this template type when
 * the model supports the Converse API or the Anthropic Claude Messages API.
 * This allows you to include a System prompt and previous User messages
 * and Assistant messages for context.
 *
 * @param props - Properties for the chat prompt variant
 * @returns A PromptVariant configured for chat interactions
 */
function createChatPromptVariant(props) {
    // Validate that messages array is not empty
    if (!props.messages || props.messages.length === 0) {
        throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `MessagesEmpty`, 'At least one message must be provided');
    }
    // Validate that the first message is a user message
    if (props.messages[0].role !== ChatMessageRole.USER) {
        throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `FirstMessageNotUser`, 'The first message must be a User message');
    }
    // Validate that at least one user message exists
    const hasUserMessage = props.messages.some(message => message.role === ChatMessageRole.USER);
    if (!hasUserMessage) {
        throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `UserMessageRequired`, 'At least one User message must be provided');
    }
    // Validate alternating pattern if more than one message
    if (props.messages.length > 1) {
        for (let i = 1; i < props.messages.length; i++) {
            const currentRole = props.messages[i].role;
            const previousRole = props.messages[i - 1].role;
            if (currentRole === previousRole) {
                throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `ConsecutiveRoles`, `Messages must alternate between User and Assistant roles. Found consecutive ${currentRole} messages at positions ${i} and ${i + 1}`);
            }
        }
    }
    return {
        name: props.variantName,
        templateType: prompt_variant_1.PromptTemplateType.CHAT,
        modelId: props.model.invokableArn,
        inferenceConfiguration: props.inferenceConfiguration,
        templateConfiguration: prompt_template_configuration_1.PromptTemplateConfiguration.chat({
            inputVariables: props.promptVariables,
            messages: props.messages,
            system: props.system,
            toolConfiguration: props.toolConfiguration,
        }),
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hhdC1wcm9tcHQtdmFyaWFudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNoYXQtcHJvbXB0LXZhcmlhbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBMkhBLDBEQTRDQzs7O0FBdEtELHdEQUFzRTtBQUN0RSw0RUFBNEQ7QUFFNUQsbUZBQThFO0FBRTlFLHFEQUFzRDtBQW9DdEQ7O0dBRUc7QUFDSCxJQUFZLGVBWVg7QUFaRCxXQUFZLGVBQWU7SUFDekI7OztPQUdHO0lBQ0gsZ0NBQWEsQ0FBQTtJQUViOzs7T0FHRztJQUNILDBDQUF1QixDQUFBO0FBQ3pCLENBQUMsRUFaVyxlQUFlLCtCQUFmLGVBQWUsUUFZMUI7QUFFRDs7R0FFRztBQUNILE1BQWEsV0FBVzs7SUFDdEI7Ozs7O09BS0c7SUFDSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQVk7UUFDN0IsT0FBTyxJQUFJLFdBQVcsQ0FBQyxlQUFlLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO0tBQ3BEO0lBRUQ7Ozs7O09BS0c7SUFDSSxNQUFNLENBQUMsU0FBUyxDQUFDLElBQVk7UUFDbEMsT0FBTyxJQUFJLFdBQVcsQ0FBQyxlQUFlLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO0tBQ3pEO0lBRUQ7O09BRUc7SUFDYSxJQUFJLENBQWtCO0lBRXRDOztPQUVHO0lBQ2EsSUFBSSxDQUFTO0lBRTdCLFlBQVksSUFBcUIsRUFBRSxJQUFZOzs7Ozs7K0NBL0JwQyxXQUFXOzs7O1FBZ0NwQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztLQUNsQjtJQUVEOzs7T0FHRztJQUNJLE9BQU87UUFDWixPQUFPO1lBQ0wsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO1lBQ2YsT0FBTyxFQUFFO2dCQUNQO29CQUNFLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtpQkFDaEI7YUFDRjtTQUNGLENBQUM7S0FDSDs7QUFqREgsa0NBa0RDO0FBRUQ7Ozs7Ozs7O0dBUUc7QUFDSCxTQUFnQix1QkFBdUIsQ0FBQyxLQUE2QjtJQUNuRSw0Q0FBNEM7SUFDNUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7UUFDbkQsTUFBTSxJQUFJLGdDQUF1QixDQUFDLElBQUEsc0JBQUcsRUFBQSxlQUFlLEVBQUUsdUNBQXVDLENBQUMsQ0FBQztJQUNqRyxDQUFDO0lBRUQsb0RBQW9EO0lBQ3BELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssZUFBZSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3BELE1BQU0sSUFBSSxnQ0FBdUIsQ0FBQyxJQUFBLHNCQUFHLEVBQUEscUJBQXFCLEVBQUUsMENBQTBDLENBQUMsQ0FBQztJQUMxRyxDQUFDO0lBRUQsaURBQWlEO0lBQ2pELE1BQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDN0YsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3BCLE1BQU0sSUFBSSxnQ0FBdUIsQ0FBQyxJQUFBLHNCQUFHLEVBQUEscUJBQXFCLEVBQUUsNENBQTRDLENBQUMsQ0FBQztJQUM1RyxDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDOUIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDL0MsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDM0MsTUFBTSxZQUFZLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBRWhELElBQUksV0FBVyxLQUFLLFlBQVksRUFBRSxDQUFDO2dCQUNqQyxNQUFNLElBQUksZ0NBQXVCLENBQy9CLElBQUEsc0JBQUcsRUFBQSxrQkFBa0IsRUFDckIsK0VBQStFLFdBQVcsMEJBQTBCLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQ3JJLENBQUM7WUFDSixDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRCxPQUFPO1FBQ0wsSUFBSSxFQUFFLEtBQUssQ0FBQyxXQUFXO1FBQ3ZCLFlBQVksRUFBRSxtQ0FBa0IsQ0FBQyxJQUFJO1FBQ3JDLE9BQU8sRUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVk7UUFDakMsc0JBQXNCLEVBQUUsS0FBSyxDQUFDLHNCQUFzQjtRQUNwRCxxQkFBcUIsRUFBRSwyREFBMkIsQ0FBQyxJQUFJLENBQUM7WUFDdEQsY0FBYyxFQUFFLEtBQUssQ0FBQyxlQUFlO1lBQ3JDLFFBQVEsRUFBRSxLQUFLLENBQUMsUUFBUTtZQUN4QixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU07WUFDcEIsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQjtTQUMzQyxDQUFDO0tBQ0gsQ0FBQztBQUNKLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IENmblByb21wdCB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1iZWRyb2NrJztcbmltcG9ydCB7IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvZXJyb3JzJztcbmltcG9ydCB7IGxpdCB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2hlbHBlcnMtaW50ZXJuYWwnO1xuaW1wb3J0IHR5cGUgeyBQcm9tcHRJbmZlcmVuY2VDb25maWd1cmF0aW9uIH0gZnJvbSAnLi9wcm9tcHQtaW5mZXJlbmNlLWNvbmZpZ3VyYXRpb24nO1xuaW1wb3J0IHsgUHJvbXB0VGVtcGxhdGVDb25maWd1cmF0aW9uIH0gZnJvbSAnLi9wcm9tcHQtdGVtcGxhdGUtY29uZmlndXJhdGlvbic7XG5pbXBvcnQgdHlwZSB7IENvbW1vblByb21wdFZhcmlhbnRQcm9wcywgSVByb21wdFZhcmlhbnQgfSBmcm9tICcuL3Byb21wdC12YXJpYW50JztcbmltcG9ydCB7IFByb21wdFRlbXBsYXRlVHlwZSB9IGZyb20gJy4vcHJvbXB0LXZhcmlhbnQnO1xuaW1wb3J0IHR5cGUgeyBUb29sQ29uZmlndXJhdGlvbiB9IGZyb20gJy4vdG9vbC1jaG9pY2UnO1xuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNyZWF0aW5nIGEgY2hhdCBwcm9tcHQgdmFyaWFudC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDaGF0UHJvbXB0VmFyaWFudFByb3BzIGV4dGVuZHMgQ29tbW9uUHJvbXB0VmFyaWFudFByb3BzIHtcbiAgLyoqXG4gICAqIFRoZSBtZXNzYWdlcyBpbiB0aGUgY2hhdCBwcm9tcHQuXG4gICAqIE11c3QgaW5jbHVkZSBhdCBsZWFzdCBvbmUgVXNlciBNZXNzYWdlLlxuICAgKiBUaGUgbWVzc2FnZXMgc2hvdWxkIGFsdGVybmF0ZSBiZXR3ZWVuIFVzZXIgYW5kIEFzc2lzdGFudC5cbiAgICovXG4gIHJlYWRvbmx5IG1lc3NhZ2VzOiBDaGF0TWVzc2FnZVtdO1xuXG4gIC8qKlxuICAgKiBDb250ZXh0IG9yIGluc3RydWN0aW9ucyBmb3IgdGhlIG1vZGVsIHRvIGNvbnNpZGVyIGJlZm9yZSBnZW5lcmF0aW5nIGEgcmVzcG9uc2UuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTm8gc3lzdGVtIG1lc3NhZ2UgcHJvdmlkZWQuXG4gICAqL1xuICByZWFkb25seSBzeXN0ZW0/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBjb25maWd1cmF0aW9uIHdpdGggYXZhaWxhYmxlIHRvb2xzIHRvIHRoZSBtb2RlbCBhbmQgaG93IGl0IG11c3QgdXNlIHRoZW0uXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTm8gdG9vbCBjb25maWd1cmF0aW9uIHByb3ZpZGVkLlxuICAgKi9cbiAgcmVhZG9ubHkgdG9vbENvbmZpZ3VyYXRpb24/OiBUb29sQ29uZmlndXJhdGlvbjtcblxuICAvKipcbiAgICogSW5mZXJlbmNlIGNvbmZpZ3VyYXRpb24gZm9yIHRoZSBDaGF0IFByb21wdC5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyBpbmZlcmVuY2UgY29uZmlndXJhdGlvbiBwcm92aWRlZC5cbiAgICovXG4gIHJlYWRvbmx5IGluZmVyZW5jZUNvbmZpZ3VyYXRpb24/OiBQcm9tcHRJbmZlcmVuY2VDb25maWd1cmF0aW9uO1xufVxuXG4vKipcbiAqIFRoZSByb2xlIG9mIGEgbWVzc2FnZSBpbiBhIGNoYXQgY29udmVyc2F0aW9uLlxuICovXG5leHBvcnQgZW51bSBDaGF0TWVzc2FnZVJvbGUge1xuICAvKipcbiAgICogVGhpcyByb2xlIHJlcHJlc2VudHMgdGhlIGh1bWFuIHVzZXIgaW4gdGhlIGNvbnZlcnNhdGlvbi4gSW5wdXRzIGZyb20gdGhlXG4gICAqIHVzZXIgZ3VpZGUgdGhlIGNvbnZlcnNhdGlvbiBhbmQgcHJvbXB0IHJlc3BvbnNlcyBmcm9tIHRoZSBhc3Npc3RhbnQuXG4gICAqL1xuICBVU0VSID0gJ3VzZXInLFxuXG4gIC8qKlxuICAgKiBUaGlzIGlzIHRoZSByb2xlIG9mIHRoZSBtb2RlbCBpdHNlbGYsIHJlc3BvbmRpbmcgdG8gdXNlciBpbnB1dHMgYmFzZWQgb25cbiAgICogdGhlIGNvbnRleHQgc2V0IGJ5IHRoZSBzeXN0ZW0uXG4gICAqL1xuICBBU1NJU1RBTlQgPSAnYXNzaXN0YW50Jyxcbn1cblxuLyoqXG4gKiBSZXByZXNlbnRzIGEgbWVzc2FnZSBpbiBhIGNoYXQgY29udmVyc2F0aW9uLlxuICovXG5leHBvcnQgY2xhc3MgQ2hhdE1lc3NhZ2Uge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIHVzZXIgbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHRleHQgLSBUaGUgdGV4dCBjb250ZW50IG9mIHRoZSB1c2VyIG1lc3NhZ2VcbiAgICogQHJldHVybnMgQSBDaGF0TWVzc2FnZSBpbnN0YW5jZSByZXByZXNlbnRpbmcgYSB1c2VyIG1lc3NhZ2VcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgdXNlcih0ZXh0OiBzdHJpbmcpOiBDaGF0TWVzc2FnZSB7XG4gICAgcmV0dXJuIG5ldyBDaGF0TWVzc2FnZShDaGF0TWVzc2FnZVJvbGUuVVNFUiwgdGV4dCk7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBhbiBhc3Npc3RhbnQgbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHRleHQgLSBUaGUgdGV4dCBjb250ZW50IG9mIHRoZSBhc3Npc3RhbnQgbWVzc2FnZVxuICAgKiBAcmV0dXJucyBBIENoYXRNZXNzYWdlIGluc3RhbmNlIHJlcHJlc2VudGluZyBhbiBhc3Npc3RhbnQgbWVzc2FnZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBhc3Npc3RhbnQodGV4dDogc3RyaW5nKTogQ2hhdE1lc3NhZ2Uge1xuICAgIHJldHVybiBuZXcgQ2hhdE1lc3NhZ2UoQ2hhdE1lc3NhZ2VSb2xlLkFTU0lTVEFOVCwgdGV4dCk7XG4gIH1cblxuICAvKipcbiAgICogVGhlIHJvbGUgb2YgdGhlIG1lc3NhZ2Ugc2VuZGVyLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHJvbGU6IENoYXRNZXNzYWdlUm9sZTtcblxuICAvKipcbiAgICogVGhlIHRleHQgY29udGVudCBvZiB0aGUgbWVzc2FnZS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSB0ZXh0OiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3Iocm9sZTogQ2hhdE1lc3NhZ2VSb2xlLCB0ZXh0OiBzdHJpbmcpIHtcbiAgICB0aGlzLnJvbGUgPSByb2xlO1xuICAgIHRoaXMudGV4dCA9IHRleHQ7XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyB0aGUgbWVzc2FnZSBhcyBhIENsb3VkRm9ybWF0aW9uIHByb3BlcnR5LlxuICAgKiBAaW50ZXJuYWwgVGhpcyBpcyBhbiBpbnRlcm5hbCBjb3JlIGZ1bmN0aW9uIGFuZCBzaG91bGQgbm90IGJlIGNhbGxlZCBkaXJlY3RseS5cbiAgICovXG4gIHB1YmxpYyBfcmVuZGVyKCk6IENmblByb21wdC5NZXNzYWdlUHJvcGVydHkge1xuICAgIHJldHVybiB7XG4gICAgICByb2xlOiB0aGlzLnJvbGUsXG4gICAgICBjb250ZW50OiBbXG4gICAgICAgIHtcbiAgICAgICAgICB0ZXh0OiB0aGlzLnRleHQsXG4gICAgICAgIH0sXG4gICAgICBdLFxuICAgIH07XG4gIH1cbn1cblxuLyoqXG4gKiBDcmVhdGVzIGEgY2hhdCB0ZW1wbGF0ZSB2YXJpYW50LiBVc2UgdGhpcyB0ZW1wbGF0ZSB0eXBlIHdoZW5cbiAqIHRoZSBtb2RlbCBzdXBwb3J0cyB0aGUgQ29udmVyc2UgQVBJIG9yIHRoZSBBbnRocm9waWMgQ2xhdWRlIE1lc3NhZ2VzIEFQSS5cbiAqIFRoaXMgYWxsb3dzIHlvdSB0byBpbmNsdWRlIGEgU3lzdGVtIHByb21wdCBhbmQgcHJldmlvdXMgVXNlciBtZXNzYWdlc1xuICogYW5kIEFzc2lzdGFudCBtZXNzYWdlcyBmb3IgY29udGV4dC5cbiAqXG4gKiBAcGFyYW0gcHJvcHMgLSBQcm9wZXJ0aWVzIGZvciB0aGUgY2hhdCBwcm9tcHQgdmFyaWFudFxuICogQHJldHVybnMgQSBQcm9tcHRWYXJpYW50IGNvbmZpZ3VyZWQgZm9yIGNoYXQgaW50ZXJhY3Rpb25zXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVDaGF0UHJvbXB0VmFyaWFudChwcm9wczogQ2hhdFByb21wdFZhcmlhbnRQcm9wcyk6IElQcm9tcHRWYXJpYW50IHtcbiAgLy8gVmFsaWRhdGUgdGhhdCBtZXNzYWdlcyBhcnJheSBpcyBub3QgZW1wdHlcbiAgaWYgKCFwcm9wcy5tZXNzYWdlcyB8fCBwcm9wcy5tZXNzYWdlcy5sZW5ndGggPT09IDApIHtcbiAgICB0aHJvdyBuZXcgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IobGl0YE1lc3NhZ2VzRW1wdHlgLCAnQXQgbGVhc3Qgb25lIG1lc3NhZ2UgbXVzdCBiZSBwcm92aWRlZCcpO1xuICB9XG5cbiAgLy8gVmFsaWRhdGUgdGhhdCB0aGUgZmlyc3QgbWVzc2FnZSBpcyBhIHVzZXIgbWVzc2FnZVxuICBpZiAocHJvcHMubWVzc2FnZXNbMF0ucm9sZSAhPT0gQ2hhdE1lc3NhZ2VSb2xlLlVTRVIpIHtcbiAgICB0aHJvdyBuZXcgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IobGl0YEZpcnN0TWVzc2FnZU5vdFVzZXJgLCAnVGhlIGZpcnN0IG1lc3NhZ2UgbXVzdCBiZSBhIFVzZXIgbWVzc2FnZScpO1xuICB9XG5cbiAgLy8gVmFsaWRhdGUgdGhhdCBhdCBsZWFzdCBvbmUgdXNlciBtZXNzYWdlIGV4aXN0c1xuICBjb25zdCBoYXNVc2VyTWVzc2FnZSA9IHByb3BzLm1lc3NhZ2VzLnNvbWUobWVzc2FnZSA9PiBtZXNzYWdlLnJvbGUgPT09IENoYXRNZXNzYWdlUm9sZS5VU0VSKTtcbiAgaWYgKCFoYXNVc2VyTWVzc2FnZSkge1xuICAgIHRocm93IG5ldyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvcihsaXRgVXNlck1lc3NhZ2VSZXF1aXJlZGAsICdBdCBsZWFzdCBvbmUgVXNlciBtZXNzYWdlIG11c3QgYmUgcHJvdmlkZWQnKTtcbiAgfVxuXG4gIC8vIFZhbGlkYXRlIGFsdGVybmF0aW5nIHBhdHRlcm4gaWYgbW9yZSB0aGFuIG9uZSBtZXNzYWdlXG4gIGlmIChwcm9wcy5tZXNzYWdlcy5sZW5ndGggPiAxKSB7XG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCBwcm9wcy5tZXNzYWdlcy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgY3VycmVudFJvbGUgPSBwcm9wcy5tZXNzYWdlc1tpXS5yb2xlO1xuICAgICAgY29uc3QgcHJldmlvdXNSb2xlID0gcHJvcHMubWVzc2FnZXNbaSAtIDFdLnJvbGU7XG5cbiAgICAgIGlmIChjdXJyZW50Um9sZSA9PT0gcHJldmlvdXNSb2xlKSB7XG4gICAgICAgIHRocm93IG5ldyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvcihcbiAgICAgICAgICBsaXRgQ29uc2VjdXRpdmVSb2xlc2AsXG4gICAgICAgICAgYE1lc3NhZ2VzIG11c3QgYWx0ZXJuYXRlIGJldHdlZW4gVXNlciBhbmQgQXNzaXN0YW50IHJvbGVzLiBGb3VuZCBjb25zZWN1dGl2ZSAke2N1cnJlbnRSb2xlfSBtZXNzYWdlcyBhdCBwb3NpdGlvbnMgJHtpfSBhbmQgJHtpICsgMX1gLFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiB7XG4gICAgbmFtZTogcHJvcHMudmFyaWFudE5hbWUsXG4gICAgdGVtcGxhdGVUeXBlOiBQcm9tcHRUZW1wbGF0ZVR5cGUuQ0hBVCxcbiAgICBtb2RlbElkOiBwcm9wcy5tb2RlbC5pbnZva2FibGVBcm4sXG4gICAgaW5mZXJlbmNlQ29uZmlndXJhdGlvbjogcHJvcHMuaW5mZXJlbmNlQ29uZmlndXJhdGlvbixcbiAgICB0ZW1wbGF0ZUNvbmZpZ3VyYXRpb246IFByb21wdFRlbXBsYXRlQ29uZmlndXJhdGlvbi5jaGF0KHtcbiAgICAgIGlucHV0VmFyaWFibGVzOiBwcm9wcy5wcm9tcHRWYXJpYWJsZXMsXG4gICAgICBtZXNzYWdlczogcHJvcHMubWVzc2FnZXMsXG4gICAgICBzeXN0ZW06IHByb3BzLnN5c3RlbSxcbiAgICAgIHRvb2xDb25maWd1cmF0aW9uOiBwcm9wcy50b29sQ29uZmlndXJhdGlvbixcbiAgICB9KSxcbiAgfTtcbn1cbiJdfQ==