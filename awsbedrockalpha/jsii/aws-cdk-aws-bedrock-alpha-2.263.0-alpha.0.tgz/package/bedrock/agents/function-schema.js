"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.FunctionSchema = exports.Function = exports.FunctionParameter = exports.RequireConfirmation = exports.ParameterType = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const schema_base_1 = require("./schema-base");
const validation = __importStar(require("./validation-helpers"));
/**
 * Enum for parameter types in function schemas
 */
var ParameterType;
(function (ParameterType) {
    /**
     * String parameter type
     */
    ParameterType["STRING"] = "string";
    /**
     * Number parameter type
     */
    ParameterType["NUMBER"] = "number";
    /**
     * Integer parameter type
     */
    ParameterType["INTEGER"] = "integer";
    /**
     * Boolean parameter type
     */
    ParameterType["BOOLEAN"] = "boolean";
    /**
     * Array parameter type
     */
    ParameterType["ARRAY"] = "array";
    /**
     * Object parameter type
     */
    ParameterType["OBJECT"] = "object";
})(ParameterType || (exports.ParameterType = ParameterType = {}));
/**
 * Enum for require confirmation state in function schemas
 */
var RequireConfirmation;
(function (RequireConfirmation) {
    /**
     * Confirmation is enabled
     */
    RequireConfirmation["ENABLED"] = "ENABLED";
    /**
     * Confirmation is disabled
     */
    RequireConfirmation["DISABLED"] = "DISABLED";
})(RequireConfirmation || (exports.RequireConfirmation = RequireConfirmation = {}));
/**
 * Represents a function parameter in a function schema
 */
class FunctionParameter {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.FunctionParameter", version: "2.263.0-alpha.0" };
    /**
     * The type of the parameter
     */
    type;
    /**
     * Whether the parameter is required
     */
    required;
    /**
     * Description of the parameter
     * @default undefined no description will be present
     */
    description;
    constructor(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_FunctionParameterProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, FunctionParameter);
            }
            throw error;
        }
        // Validate description if provided
        if (props.description) {
            const descErrors = validation.validateStringFieldLength({
                fieldName: 'parameter description',
                value: props.description,
                minLength: 1,
                maxLength: 500,
            });
            if (descErrors.length > 0) {
                throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `InvalidParameterDescription`, descErrors.join('\n'));
            }
        }
        this.type = props.type;
        this.required = props.required ?? true;
        this.description = props.description;
    }
    /**
     * Render the parameter as a CloudFormation property
     * @internal
     */
    _render() {
        return {
            type: this.type,
            required: this.required,
            description: this.description,
        };
    }
}
exports.FunctionParameter = FunctionParameter;
/**
 * Represents a function in a function schema
 */
class Function {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.Function", version: "2.263.0-alpha.0" };
    /**
     * The name of the function
     */
    name;
    /**
     * Description of the function
     */
    description;
    /**
     * Parameters for the function
     */
    parameters;
    /**
     * Whether to require confirmation before executing the function
     */
    requireConfirmation;
    constructor(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_FunctionProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, Function);
            }
            throw error;
        }
        // Validate function name
        const nameErrors = validation.validateStringFieldLength({
            fieldName: 'function name',
            value: props.name,
            minLength: 1,
            maxLength: 100,
        });
        if (nameErrors.length > 0) {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `InvalidFunctionName`, nameErrors.join('\n'));
        }
        // Validate function description
        const descErrors = validation.validateStringFieldLength({
            fieldName: 'function description',
            value: props.description,
            minLength: 1,
            maxLength: 500,
        });
        if (descErrors.length > 0) {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `InvalidFunctionDescription`, descErrors.join('\n'));
        }
        this.name = props.name;
        this.description = props.description;
        // Convert parameters object to a record of FunctionParameter instances
        this.parameters = {};
        if (props.parameters) {
            Object.entries(props.parameters).forEach(([name, paramProps]) => {
                // Validate parameter name
                const paramNameErrors = validation.validateStringFieldLength({
                    fieldName: 'parameter name',
                    value: name,
                    minLength: 1,
                    maxLength: 100,
                });
                if (paramNameErrors.length > 0) {
                    throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `InvalidParameterName`, paramNameErrors.join('\n'));
                }
                this.parameters[name] = new FunctionParameter(paramProps);
            });
        }
        this.requireConfirmation = props.requireConfirmation ?? RequireConfirmation.DISABLED;
    }
    /**
     * Render the function as a CloudFormation property
     * @internal
     */
    _render() {
        const parametersObj = {};
        Object.entries(this.parameters).forEach(([name, param]) => {
            parametersObj[name] = param._render();
        });
        return {
            name: this.name,
            description: this.description,
            parameters: parametersObj,
            requireConfirmation: this.requireConfirmation,
        };
    }
}
exports.Function = Function;
/**
 * Represents a function schema for a Bedrock Agent Action Group
 */
class FunctionSchema extends schema_base_1.ActionGroupSchema {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.FunctionSchema", version: "2.263.0-alpha.0" };
    /**
     * The functions defined in the schema
     */
    functions;
    constructor(props) {
        super();
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_FunctionSchemaProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, FunctionSchema);
            }
            throw error;
        }
        if (!props.functions || props.functions.length === 0) {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `EmptyFunctionSchema`, 'At least one function must be defined in the function schema');
        }
        this.functions = props.functions.map(f => new Function(f));
    }
    /**
     * Render the function schema as a CloudFormation property
     * @internal
     */
    _render() {
        return {
            functions: this.functions.map(f => f._render()),
        };
    }
}
exports.FunctionSchema = FunctionSchema;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnVuY3Rpb24tc2NoZW1hLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZnVuY3Rpb24tc2NoZW1hLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0Esd0RBQXNFO0FBQ3RFLDRFQUE0RDtBQUM1RCwrQ0FBa0Q7QUFDbEQsaUVBQW1EO0FBRW5EOztHQUVHO0FBQ0gsSUFBWSxhQThCWDtBQTlCRCxXQUFZLGFBQWE7SUFDdkI7O09BRUc7SUFDSCxrQ0FBaUIsQ0FBQTtJQUVqQjs7T0FFRztJQUNILGtDQUFpQixDQUFBO0lBRWpCOztPQUVHO0lBQ0gsb0NBQW1CLENBQUE7SUFFbkI7O09BRUc7SUFDSCxvQ0FBbUIsQ0FBQTtJQUVuQjs7T0FFRztJQUNILGdDQUFlLENBQUE7SUFFZjs7T0FFRztJQUNILGtDQUFpQixDQUFBO0FBQ25CLENBQUMsRUE5QlcsYUFBYSw2QkFBYixhQUFhLFFBOEJ4QjtBQUVEOztHQUVHO0FBQ0gsSUFBWSxtQkFVWDtBQVZELFdBQVksbUJBQW1CO0lBQzdCOztPQUVHO0lBQ0gsMENBQW1CLENBQUE7SUFFbkI7O09BRUc7SUFDSCw0Q0FBcUIsQ0FBQTtBQUN2QixDQUFDLEVBVlcsbUJBQW1CLG1DQUFuQixtQkFBbUIsUUFVOUI7QUE2REQ7O0dBRUc7QUFDSCxNQUFhLGlCQUFpQjs7SUFDNUI7O09BRUc7SUFDYSxJQUFJLENBQWdCO0lBRXBDOztPQUVHO0lBQ2EsUUFBUSxDQUFVO0lBRWxDOzs7T0FHRztJQUNhLFdBQVcsQ0FBVTtJQUVyQyxZQUFZLEtBQTZCOzs7Ozs7K0NBakI5QixpQkFBaUI7Ozs7UUFrQjFCLG1DQUFtQztRQUNuQyxJQUFJLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUN0QixNQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMseUJBQXlCLENBQUM7Z0JBQ3RELFNBQVMsRUFBRSx1QkFBdUI7Z0JBQ2xDLEtBQUssRUFBRSxLQUFLLENBQUMsV0FBVztnQkFDeEIsU0FBUyxFQUFFLENBQUM7Z0JBQ1osU0FBUyxFQUFFLEdBQUc7YUFDZixDQUFDLENBQUM7WUFFSCxJQUFJLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQzFCLE1BQU0sSUFBSSxnQ0FBdUIsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsNkJBQTZCLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQzdGLENBQUM7UUFDSCxDQUFDO1FBRUQsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUM7UUFDdkMsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDO0tBQ3RDO0lBRUQ7OztPQUdHO0lBQ0ksT0FBTztRQUNaLE9BQU87WUFDTCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDZixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7WUFDdkIsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXO1NBQzlCLENBQUM7S0FDSDs7QUEvQ0gsOENBZ0RDO0FBRUQ7O0dBRUc7QUFDSCxNQUFhLFFBQVE7O0lBQ25COztPQUVHO0lBQ2EsSUFBSSxDQUFTO0lBRTdCOztPQUVHO0lBQ2EsV0FBVyxDQUFTO0lBRXBDOztPQUVHO0lBQ2EsVUFBVSxDQUFvQztJQUU5RDs7T0FFRztJQUNhLG1CQUFtQixDQUFzQjtJQUV6RCxZQUFZLEtBQW9COzs7Ozs7K0NBckJyQixRQUFROzs7O1FBc0JqQix5QkFBeUI7UUFDekIsTUFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLHlCQUF5QixDQUFDO1lBQ3RELFNBQVMsRUFBRSxlQUFlO1lBQzFCLEtBQUssRUFBRSxLQUFLLENBQUMsSUFBSTtZQUNqQixTQUFTLEVBQUUsQ0FBQztZQUNaLFNBQVMsRUFBRSxHQUFHO1NBQ2YsQ0FBQyxDQUFDO1FBRUgsSUFBSSxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQzFCLE1BQU0sSUFBSSxnQ0FBdUIsQ0FBQyxJQUFBLHNCQUFHLEVBQUEscUJBQXFCLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ3JGLENBQUM7UUFFRCxnQ0FBZ0M7UUFDaEMsTUFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLHlCQUF5QixDQUFDO1lBQ3RELFNBQVMsRUFBRSxzQkFBc0I7WUFDakMsS0FBSyxFQUFFLEtBQUssQ0FBQyxXQUFXO1lBQ3hCLFNBQVMsRUFBRSxDQUFDO1lBQ1osU0FBUyxFQUFFLEdBQUc7U0FDZixDQUFDLENBQUM7UUFFSCxJQUFJLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDMUIsTUFBTSxJQUFJLGdDQUF1QixDQUFDLElBQUEsc0JBQUcsRUFBQSw0QkFBNEIsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDNUYsQ0FBQztRQUVELElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQztRQUN2QixJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUM7UUFFckMsdUVBQXVFO1FBQ3ZFLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO1FBQ3JCLElBQUksS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ3JCLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzlELDBCQUEwQjtnQkFDMUIsTUFBTSxlQUFlLEdBQUcsVUFBVSxDQUFDLHlCQUF5QixDQUFDO29CQUMzRCxTQUFTLEVBQUUsZ0JBQWdCO29CQUMzQixLQUFLLEVBQUUsSUFBSTtvQkFDWCxTQUFTLEVBQUUsQ0FBQztvQkFDWixTQUFTLEVBQUUsR0FBRztpQkFDZixDQUFDLENBQUM7Z0JBRUgsSUFBSSxlQUFlLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUMvQixNQUFNLElBQUksZ0NBQXVCLENBQUMsSUFBQSxzQkFBRyxFQUFBLHNCQUFzQixFQUFFLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDM0YsQ0FBQztnQkFFRCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksaUJBQWlCLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDNUQsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO1FBRUQsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQyxtQkFBbUIsSUFBSSxtQkFBbUIsQ0FBQyxRQUFRLENBQUM7S0FDdEY7SUFFRDs7O09BR0c7SUFDSSxPQUFPO1FBQ1osTUFBTSxhQUFhLEdBQXdCLEVBQUUsQ0FBQztRQUU5QyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFO1lBQ3hELGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPO1lBQ0wsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO1lBQ2YsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXO1lBQzdCLFVBQVUsRUFBRSxhQUFhO1lBQ3pCLG1CQUFtQixFQUFFLElBQUksQ0FBQyxtQkFBbUI7U0FDOUMsQ0FBQztLQUNIOztBQXhGSCw0QkF5RkM7QUFFRDs7R0FFRztBQUNILE1BQWEsY0FBZSxTQUFRLCtCQUFpQjs7SUFDbkQ7O09BRUc7SUFDYSxTQUFTLENBQWE7SUFFdEMsWUFBWSxLQUEwQjtRQUNwQyxLQUFLLEVBQUUsQ0FBQzs7Ozs7OytDQVBDLGNBQWM7Ozs7UUFTdkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLElBQUksS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDckQsTUFBTSxJQUFJLGdDQUF1QixDQUFDLElBQUEsc0JBQUcsRUFBQSxxQkFBcUIsRUFBRSw4REFBOEQsQ0FBQyxDQUFDO1FBQzlILENBQUM7UUFFRCxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUM1RDtJQUVEOzs7T0FHRztJQUNJLE9BQU87UUFDWixPQUFPO1lBQ0wsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQ2hELENBQUM7S0FDSDs7QUF4Qkgsd0NBeUJDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBDZm5BZ2VudCB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1iZWRyb2NrJztcbmltcG9ydCB7IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvZXJyb3JzJztcbmltcG9ydCB7IGxpdCB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2hlbHBlcnMtaW50ZXJuYWwnO1xuaW1wb3J0IHsgQWN0aW9uR3JvdXBTY2hlbWEgfSBmcm9tICcuL3NjaGVtYS1iYXNlJztcbmltcG9ydCAqIGFzIHZhbGlkYXRpb24gZnJvbSAnLi92YWxpZGF0aW9uLWhlbHBlcnMnO1xuXG4vKipcbiAqIEVudW0gZm9yIHBhcmFtZXRlciB0eXBlcyBpbiBmdW5jdGlvbiBzY2hlbWFzXG4gKi9cbmV4cG9ydCBlbnVtIFBhcmFtZXRlclR5cGUge1xuICAvKipcbiAgICogU3RyaW5nIHBhcmFtZXRlciB0eXBlXG4gICAqL1xuICBTVFJJTkcgPSAnc3RyaW5nJyxcblxuICAvKipcbiAgICogTnVtYmVyIHBhcmFtZXRlciB0eXBlXG4gICAqL1xuICBOVU1CRVIgPSAnbnVtYmVyJyxcblxuICAvKipcbiAgICogSW50ZWdlciBwYXJhbWV0ZXIgdHlwZVxuICAgKi9cbiAgSU5URUdFUiA9ICdpbnRlZ2VyJyxcblxuICAvKipcbiAgICogQm9vbGVhbiBwYXJhbWV0ZXIgdHlwZVxuICAgKi9cbiAgQk9PTEVBTiA9ICdib29sZWFuJyxcblxuICAvKipcbiAgICogQXJyYXkgcGFyYW1ldGVyIHR5cGVcbiAgICovXG4gIEFSUkFZID0gJ2FycmF5JyxcblxuICAvKipcbiAgICogT2JqZWN0IHBhcmFtZXRlciB0eXBlXG4gICAqL1xuICBPQkpFQ1QgPSAnb2JqZWN0Jyxcbn1cblxuLyoqXG4gKiBFbnVtIGZvciByZXF1aXJlIGNvbmZpcm1hdGlvbiBzdGF0ZSBpbiBmdW5jdGlvbiBzY2hlbWFzXG4gKi9cbmV4cG9ydCBlbnVtIFJlcXVpcmVDb25maXJtYXRpb24ge1xuICAvKipcbiAgICogQ29uZmlybWF0aW9uIGlzIGVuYWJsZWRcbiAgICovXG4gIEVOQUJMRUQgPSAnRU5BQkxFRCcsXG5cbiAgLyoqXG4gICAqIENvbmZpcm1hdGlvbiBpcyBkaXNhYmxlZFxuICAgKi9cbiAgRElTQUJMRUQgPSAnRElTQUJMRUQnLFxufVxuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGEgZnVuY3Rpb24gcGFyYW1ldGVyXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRnVuY3Rpb25QYXJhbWV0ZXJQcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgdHlwZSBvZiB0aGUgcGFyYW1ldGVyXG4gICAqL1xuICByZWFkb25seSB0eXBlOiBQYXJhbWV0ZXJUeXBlO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoZSBwYXJhbWV0ZXIgaXMgcmVxdWlyZWRcbiAgICogQGRlZmF1bHQgdHJ1ZVxuICAgKi9cbiAgcmVhZG9ubHkgcmVxdWlyZWQ/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBEZXNjcmlwdGlvbiBvZiB0aGUgcGFyYW1ldGVyXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCBubyBkZXNjcmlwdGlvbiB3aWxsIGJlIHByZXNlbnRcbiAgICovXG4gIHJlYWRvbmx5IGRlc2NyaXB0aW9uPzogc3RyaW5nO1xufVxuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGEgZnVuY3Rpb24gaW4gYSBmdW5jdGlvbiBzY2hlbWFcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBGdW5jdGlvblByb3BzIHtcbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBmdW5jdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBEZXNjcmlwdGlvbiBvZiB0aGUgZnVuY3Rpb25cbiAgICovXG4gIHJlYWRvbmx5IGRlc2NyaXB0aW9uOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFBhcmFtZXRlcnMgZm9yIHRoZSBmdW5jdGlvbiBhcyBhIHJlY29yZCBvZiBwYXJhbWV0ZXIgbmFtZSB0byBwYXJhbWV0ZXIgcHJvcGVydGllc1xuICAgKiBAZGVmYXVsdCB7fVxuICAgKi9cbiAgcmVhZG9ubHkgcGFyYW1ldGVycz86IFJlY29yZDxzdHJpbmcsIEZ1bmN0aW9uUGFyYW1ldGVyUHJvcHM+O1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIHJlcXVpcmUgY29uZmlybWF0aW9uIGJlZm9yZSBleGVjdXRpbmcgdGhlIGZ1bmN0aW9uXG4gICAqIEBkZWZhdWx0IFJlcXVpcmVDb25maXJtYXRpb24uRElTQUJMRURcbiAgICovXG4gIHJlYWRvbmx5IHJlcXVpcmVDb25maXJtYXRpb24/OiBSZXF1aXJlQ29uZmlybWF0aW9uO1xufVxuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGEgZnVuY3Rpb24gc2NoZW1hXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRnVuY3Rpb25TY2hlbWFQcm9wcyB7XG4gIC8qKlxuICAgKiBGdW5jdGlvbnMgZGVmaW5lZCBpbiB0aGUgc2NoZW1hXG4gICAqL1xuICByZWFkb25seSBmdW5jdGlvbnM6IEZ1bmN0aW9uUHJvcHNbXTtcbn1cblxuLyoqXG4gKiBSZXByZXNlbnRzIGEgZnVuY3Rpb24gcGFyYW1ldGVyIGluIGEgZnVuY3Rpb24gc2NoZW1hXG4gKi9cbmV4cG9ydCBjbGFzcyBGdW5jdGlvblBhcmFtZXRlciB7XG4gIC8qKlxuICAgKiBUaGUgdHlwZSBvZiB0aGUgcGFyYW1ldGVyXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgdHlwZTogUGFyYW1ldGVyVHlwZTtcblxuICAvKipcbiAgICogV2hldGhlciB0aGUgcGFyYW1ldGVyIGlzIHJlcXVpcmVkXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgcmVxdWlyZWQ6IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIERlc2NyaXB0aW9uIG9mIHRoZSBwYXJhbWV0ZXJcbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIG5vIGRlc2NyaXB0aW9uIHdpbGwgYmUgcHJlc2VudFxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKHByb3BzOiBGdW5jdGlvblBhcmFtZXRlclByb3BzKSB7XG4gICAgLy8gVmFsaWRhdGUgZGVzY3JpcHRpb24gaWYgcHJvdmlkZWRcbiAgICBpZiAocHJvcHMuZGVzY3JpcHRpb24pIHtcbiAgICAgIGNvbnN0IGRlc2NFcnJvcnMgPSB2YWxpZGF0aW9uLnZhbGlkYXRlU3RyaW5nRmllbGRMZW5ndGgoe1xuICAgICAgICBmaWVsZE5hbWU6ICdwYXJhbWV0ZXIgZGVzY3JpcHRpb24nLFxuICAgICAgICB2YWx1ZTogcHJvcHMuZGVzY3JpcHRpb24sXG4gICAgICAgIG1pbkxlbmd0aDogMSxcbiAgICAgICAgbWF4TGVuZ3RoOiA1MDAsXG4gICAgICB9KTtcblxuICAgICAgaWYgKGRlc2NFcnJvcnMubGVuZ3RoID4gMCkge1xuICAgICAgICB0aHJvdyBuZXcgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IobGl0YEludmFsaWRQYXJhbWV0ZXJEZXNjcmlwdGlvbmAsIGRlc2NFcnJvcnMuam9pbignXFxuJykpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMudHlwZSA9IHByb3BzLnR5cGU7XG4gICAgdGhpcy5yZXF1aXJlZCA9IHByb3BzLnJlcXVpcmVkID8/IHRydWU7XG4gICAgdGhpcy5kZXNjcmlwdGlvbiA9IHByb3BzLmRlc2NyaXB0aW9uO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlciB0aGUgcGFyYW1ldGVyIGFzIGEgQ2xvdWRGb3JtYXRpb24gcHJvcGVydHlcbiAgICogQGludGVybmFsXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBhbnkge1xuICAgIHJldHVybiB7XG4gICAgICB0eXBlOiB0aGlzLnR5cGUsXG4gICAgICByZXF1aXJlZDogdGhpcy5yZXF1aXJlZCxcbiAgICAgIGRlc2NyaXB0aW9uOiB0aGlzLmRlc2NyaXB0aW9uLFxuICAgIH07XG4gIH1cbn1cblxuLyoqXG4gKiBSZXByZXNlbnRzIGEgZnVuY3Rpb24gaW4gYSBmdW5jdGlvbiBzY2hlbWFcbiAqL1xuZXhwb3J0IGNsYXNzIEZ1bmN0aW9uIHtcbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBmdW5jdGlvblxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogRGVzY3JpcHRpb24gb2YgdGhlIGZ1bmN0aW9uXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZGVzY3JpcHRpb246IHN0cmluZztcblxuICAvKipcbiAgICogUGFyYW1ldGVycyBmb3IgdGhlIGZ1bmN0aW9uXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgcGFyYW1ldGVyczogUmVjb3JkPHN0cmluZywgRnVuY3Rpb25QYXJhbWV0ZXI+O1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIHJlcXVpcmUgY29uZmlybWF0aW9uIGJlZm9yZSBleGVjdXRpbmcgdGhlIGZ1bmN0aW9uXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgcmVxdWlyZUNvbmZpcm1hdGlvbjogUmVxdWlyZUNvbmZpcm1hdGlvbjtcblxuICBjb25zdHJ1Y3Rvcihwcm9wczogRnVuY3Rpb25Qcm9wcykge1xuICAgIC8vIFZhbGlkYXRlIGZ1bmN0aW9uIG5hbWVcbiAgICBjb25zdCBuYW1lRXJyb3JzID0gdmFsaWRhdGlvbi52YWxpZGF0ZVN0cmluZ0ZpZWxkTGVuZ3RoKHtcbiAgICAgIGZpZWxkTmFtZTogJ2Z1bmN0aW9uIG5hbWUnLFxuICAgICAgdmFsdWU6IHByb3BzLm5hbWUsXG4gICAgICBtaW5MZW5ndGg6IDEsXG4gICAgICBtYXhMZW5ndGg6IDEwMCxcbiAgICB9KTtcblxuICAgIGlmIChuYW1lRXJyb3JzLmxlbmd0aCA+IDApIHtcbiAgICAgIHRocm93IG5ldyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvcihsaXRgSW52YWxpZEZ1bmN0aW9uTmFtZWAsIG5hbWVFcnJvcnMuam9pbignXFxuJykpO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIGZ1bmN0aW9uIGRlc2NyaXB0aW9uXG4gICAgY29uc3QgZGVzY0Vycm9ycyA9IHZhbGlkYXRpb24udmFsaWRhdGVTdHJpbmdGaWVsZExlbmd0aCh7XG4gICAgICBmaWVsZE5hbWU6ICdmdW5jdGlvbiBkZXNjcmlwdGlvbicsXG4gICAgICB2YWx1ZTogcHJvcHMuZGVzY3JpcHRpb24sXG4gICAgICBtaW5MZW5ndGg6IDEsXG4gICAgICBtYXhMZW5ndGg6IDUwMCxcbiAgICB9KTtcblxuICAgIGlmIChkZXNjRXJyb3JzLmxlbmd0aCA+IDApIHtcbiAgICAgIHRocm93IG5ldyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvcihsaXRgSW52YWxpZEZ1bmN0aW9uRGVzY3JpcHRpb25gLCBkZXNjRXJyb3JzLmpvaW4oJ1xcbicpKTtcbiAgICB9XG5cbiAgICB0aGlzLm5hbWUgPSBwcm9wcy5uYW1lO1xuICAgIHRoaXMuZGVzY3JpcHRpb24gPSBwcm9wcy5kZXNjcmlwdGlvbjtcblxuICAgIC8vIENvbnZlcnQgcGFyYW1ldGVycyBvYmplY3QgdG8gYSByZWNvcmQgb2YgRnVuY3Rpb25QYXJhbWV0ZXIgaW5zdGFuY2VzXG4gICAgdGhpcy5wYXJhbWV0ZXJzID0ge307XG4gICAgaWYgKHByb3BzLnBhcmFtZXRlcnMpIHtcbiAgICAgIE9iamVjdC5lbnRyaWVzKHByb3BzLnBhcmFtZXRlcnMpLmZvckVhY2goKFtuYW1lLCBwYXJhbVByb3BzXSkgPT4ge1xuICAgICAgICAvLyBWYWxpZGF0ZSBwYXJhbWV0ZXIgbmFtZVxuICAgICAgICBjb25zdCBwYXJhbU5hbWVFcnJvcnMgPSB2YWxpZGF0aW9uLnZhbGlkYXRlU3RyaW5nRmllbGRMZW5ndGgoe1xuICAgICAgICAgIGZpZWxkTmFtZTogJ3BhcmFtZXRlciBuYW1lJyxcbiAgICAgICAgICB2YWx1ZTogbmFtZSxcbiAgICAgICAgICBtaW5MZW5ndGg6IDEsXG4gICAgICAgICAgbWF4TGVuZ3RoOiAxMDAsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmIChwYXJhbU5hbWVFcnJvcnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHRocm93IG5ldyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvcihsaXRgSW52YWxpZFBhcmFtZXRlck5hbWVgLCBwYXJhbU5hbWVFcnJvcnMuam9pbignXFxuJykpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5wYXJhbWV0ZXJzW25hbWVdID0gbmV3IEZ1bmN0aW9uUGFyYW1ldGVyKHBhcmFtUHJvcHMpO1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgdGhpcy5yZXF1aXJlQ29uZmlybWF0aW9uID0gcHJvcHMucmVxdWlyZUNvbmZpcm1hdGlvbiA/PyBSZXF1aXJlQ29uZmlybWF0aW9uLkRJU0FCTEVEO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlciB0aGUgZnVuY3Rpb24gYXMgYSBDbG91ZEZvcm1hdGlvbiBwcm9wZXJ0eVxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIHB1YmxpYyBfcmVuZGVyKCk6IGFueSB7XG4gICAgY29uc3QgcGFyYW1ldGVyc09iajogUmVjb3JkPHN0cmluZywgYW55PiA9IHt9O1xuXG4gICAgT2JqZWN0LmVudHJpZXModGhpcy5wYXJhbWV0ZXJzKS5mb3JFYWNoKChbbmFtZSwgcGFyYW1dKSA9PiB7XG4gICAgICBwYXJhbWV0ZXJzT2JqW25hbWVdID0gcGFyYW0uX3JlbmRlcigpO1xuICAgIH0pO1xuICAgIHJldHVybiB7XG4gICAgICBuYW1lOiB0aGlzLm5hbWUsXG4gICAgICBkZXNjcmlwdGlvbjogdGhpcy5kZXNjcmlwdGlvbixcbiAgICAgIHBhcmFtZXRlcnM6IHBhcmFtZXRlcnNPYmosXG4gICAgICByZXF1aXJlQ29uZmlybWF0aW9uOiB0aGlzLnJlcXVpcmVDb25maXJtYXRpb24sXG4gICAgfTtcbiAgfVxufVxuXG4vKipcbiAqIFJlcHJlc2VudHMgYSBmdW5jdGlvbiBzY2hlbWEgZm9yIGEgQmVkcm9jayBBZ2VudCBBY3Rpb24gR3JvdXBcbiAqL1xuZXhwb3J0IGNsYXNzIEZ1bmN0aW9uU2NoZW1hIGV4dGVuZHMgQWN0aW9uR3JvdXBTY2hlbWEge1xuICAvKipcbiAgICogVGhlIGZ1bmN0aW9ucyBkZWZpbmVkIGluIHRoZSBzY2hlbWFcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBmdW5jdGlvbnM6IEZ1bmN0aW9uW107XG5cbiAgY29uc3RydWN0b3IocHJvcHM6IEZ1bmN0aW9uU2NoZW1hUHJvcHMpIHtcbiAgICBzdXBlcigpO1xuXG4gICAgaWYgKCFwcm9wcy5mdW5jdGlvbnMgfHwgcHJvcHMuZnVuY3Rpb25zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKGxpdGBFbXB0eUZ1bmN0aW9uU2NoZW1hYCwgJ0F0IGxlYXN0IG9uZSBmdW5jdGlvbiBtdXN0IGJlIGRlZmluZWQgaW4gdGhlIGZ1bmN0aW9uIHNjaGVtYScpO1xuICAgIH1cblxuICAgIHRoaXMuZnVuY3Rpb25zID0gcHJvcHMuZnVuY3Rpb25zLm1hcChmID0+IG5ldyBGdW5jdGlvbihmKSk7XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVyIHRoZSBmdW5jdGlvbiBzY2hlbWEgYXMgYSBDbG91ZEZvcm1hdGlvbiBwcm9wZXJ0eVxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIHB1YmxpYyBfcmVuZGVyKCk6IENmbkFnZW50LkZ1bmN0aW9uU2NoZW1hUHJvcGVydHkge1xuICAgIHJldHVybiB7XG4gICAgICBmdW5jdGlvbnM6IHRoaXMuZnVuY3Rpb25zLm1hcChmID0+IGYuX3JlbmRlcigpKSxcbiAgICB9O1xuICB9XG59XG4iXX0=