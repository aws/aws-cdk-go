"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptOverrideConfiguration = exports.AgentStepType = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const validation = __importStar(require("./validation-helpers"));
/**
 * The step in the agent sequence that this prompt configuration applies to.
 */
var AgentStepType;
(function (AgentStepType) {
    /**
     * Pre-processing step that prepares the user input for orchestration.
     */
    AgentStepType["PRE_PROCESSING"] = "PRE_PROCESSING";
    /**
     * Main orchestration step that determines the agent's actions.
     */
    AgentStepType["ORCHESTRATION"] = "ORCHESTRATION";
    /**
     * Post-processing step that refines the agent's response.
     */
    AgentStepType["POST_PROCESSING"] = "POST_PROCESSING";
    /**
     * Step that classifies and routes requests to appropriate collaborators.
     */
    AgentStepType["ROUTING_CLASSIFIER"] = "ROUTING_CLASSIFIER";
    /**
     * Step that summarizes conversation history for memory retention.
     */
    AgentStepType["MEMORY_SUMMARIZATION"] = "MEMORY_SUMMARIZATION";
    /**
     * Step that generates responses using knowledge base content.
     */
    AgentStepType["KNOWLEDGE_BASE_RESPONSE_GENERATION"] = "KNOWLEDGE_BASE_RESPONSE_GENERATION";
})(AgentStepType || (exports.AgentStepType = AgentStepType = {}));
/**
 * Configuration for overriding prompt templates and behaviors in different parts
 * of an agent's sequence. This allows customizing how the agent processes inputs,
 * makes decisions, and generates responses.
 */
class PromptOverrideConfiguration {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.PromptOverrideConfiguration", version: "2.263.0-alpha.0" };
    /**
     * Creates a PromptOverrideConfiguration from individual step configurations.
     * Use this method when you want to override prompts without using a custom parser.
     * @param steps The step configurations to use
     * @returns A new PromptOverrideConfiguration instance
     */
    static fromSteps(steps) {
        if (!steps || steps.length === 0) {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `EmptyStepsArray`, 'Steps array cannot be empty');
        }
        // Convert steps array to props format
        const stepMap = steps.reduce((acc, step) => {
            switch (step.stepType) {
                case AgentStepType.PRE_PROCESSING:
                    return { ...acc, preProcessingStep: step };
                case AgentStepType.ORCHESTRATION:
                    return { ...acc, orchestrationStep: step };
                case AgentStepType.POST_PROCESSING:
                    return { ...acc, postProcessingStep: step };
                case AgentStepType.ROUTING_CLASSIFIER:
                    return { ...acc, routingClassifierStep: step };
                case AgentStepType.MEMORY_SUMMARIZATION:
                    return { ...acc, memorySummarizationStep: step };
                case AgentStepType.KNOWLEDGE_BASE_RESPONSE_GENERATION:
                    return { ...acc, knowledgeBaseResponseGenerationStep: step };
                default:
                    return acc;
            }
        }, {});
        return new PromptOverrideConfiguration(stepMap);
    }
    /**
     * Creates a PromptOverrideConfiguration with a custom Lambda parser function.
     * @param props Configuration including:
     *   - `parser`: Lambda function to use as custom parser
     *   - Individual step configurations. At least one of the steps must make use of the custom parser.
     */
    static withCustomParser(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_CustomParserProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.withCustomParser);
            }
            throw error;
        }
        return new PromptOverrideConfiguration(props);
    }
    /**
     * The custom Lambda parser function to use.
     * The Lambda parser processes and interprets the raw foundation model output.
     * It receives an input event with:
     * - messageVersion: Version of message format (1.0)
     * - agent: Info about the agent (name, id, alias, version)
     * - invokeModelRawResponse: Raw model output to parse
     * - promptType: Type of prompt being parsed
     * - overrideType: Type of override (OUTPUT_PARSER)
     *
     * The Lambda must return a response that the agent uses for next actions.
     * @see https://docs.aws.amazon.com/bedrock/latest/userguide/lambda-parser.html
     */
    parser;
    /**
     * Configuration for the pre-processing step.
     */
    preProcessingStep;
    /**
     * Configuration for the orchestration step.
     */
    orchestrationStep;
    /**
     * Configuration for the post-processing step.
     */
    postProcessingStep;
    /**
     * Configuration for the routing classifier step.
     */
    routingClassifierStep;
    /**
     * Configuration for the memory summarization step.
     */
    memorySummarizationStep;
    /**
     * Configuration for the knowledge base response generation step.
     */
    knowledgeBaseResponseGenerationStep;
    /**
     * Create a new PromptOverrideConfiguration.
     *
     * @internal - This is marked as private so end users leverage it only through static methods
     */
    constructor(props) {
        // Validate props
        validation.throwIfInvalid(this.validateSteps, props);
        if (props.parser) {
            validation.throwIfInvalid(this.validateCustomParser, props);
        }
        this.parser = props.parser;
        this.preProcessingStep = props.preProcessingStep;
        this.orchestrationStep = props.orchestrationStep;
        this.postProcessingStep = props.postProcessingStep;
        this.routingClassifierStep = props.routingClassifierStep;
        this.memorySummarizationStep = props.memorySummarizationStep;
        this.knowledgeBaseResponseGenerationStep = props.knowledgeBaseResponseGenerationStep;
    }
    /**
     * Format as CfnAgent.PromptOverrideConfigurationProperty
     *
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        const configurations = [];
        // Helper function to add configuration if step exists
        const addConfiguration = (step, type) => {
            if (step) {
                configurations.push({
                    promptType: type,
                    promptState: step.stepEnabled === undefined ? undefined : step.stepEnabled ? 'ENABLED' : 'DISABLED',
                    parserMode: step.useCustomParser === undefined ? undefined : step.useCustomParser ? 'OVERRIDDEN' : 'DEFAULT',
                    promptCreationMode: step.customPromptTemplate === undefined ? undefined : step.customPromptTemplate ? 'OVERRIDDEN' : 'DEFAULT',
                    basePromptTemplate: step.customPromptTemplate,
                    inferenceConfiguration: step.inferenceConfig,
                    // Include foundation model if it's a routing classifier step
                    foundationModel: type === AgentStepType.ROUTING_CLASSIFIER
                        ? step.foundationModel?.invokableArn
                        : undefined,
                });
            }
        };
        // Add configurations for each step type if defined
        addConfiguration(this.preProcessingStep, AgentStepType.PRE_PROCESSING);
        addConfiguration(this.orchestrationStep, AgentStepType.ORCHESTRATION);
        addConfiguration(this.postProcessingStep, AgentStepType.POST_PROCESSING);
        addConfiguration(this.routingClassifierStep, AgentStepType.ROUTING_CLASSIFIER);
        addConfiguration(this.memorySummarizationStep, AgentStepType.MEMORY_SUMMARIZATION);
        addConfiguration(this.knowledgeBaseResponseGenerationStep, AgentStepType.KNOWLEDGE_BASE_RESPONSE_GENERATION);
        return {
            overrideLambda: this.parser?.functionArn,
            promptConfigurations: configurations,
        };
    }
    validateInferenceConfig = (config) => {
        const errors = [];
        if (config) {
            if (config.temperature < 0 || config.temperature > 1) {
                errors.push('Temperature must be between 0 and 1');
            }
            if (config.topP < 0 || config.topP > 1) {
                errors.push('TopP must be between 0 and 1');
            }
            if (config.topK < 0 || config.topK > 500) {
                errors.push('TopK must be between 0 and 500');
            }
            if (config.stopSequences.length > 4) {
                errors.push('Maximum 4 stop sequences allowed');
            }
            if (config.maximumLength < 0 || config.maximumLength > 4096) {
                errors.push('MaximumLength must be between 0 and 4096');
            }
        }
        return errors;
    };
    validateSteps = (props) => {
        const errors = [];
        // Check if any steps are defined
        const hasSteps = [
            props.preProcessingStep,
            props.orchestrationStep,
            props.postProcessingStep,
            props.routingClassifierStep,
            props.memorySummarizationStep,
            props.knowledgeBaseResponseGenerationStep,
        ].some(step => step !== undefined);
        if (!hasSteps) {
            errors.push('Steps array cannot be empty');
        }
        // Helper function to validate a step's inference config
        const validateStep = (step, stepName) => {
            if (step) {
                // Check for foundation model in non-ROUTING_CLASSIFIER steps
                if ('foundationModel' in step && step.stepType !== AgentStepType.ROUTING_CLASSIFIER) {
                    errors.push('Foundation model can only be specified for ROUTING_CLASSIFIER step type');
                }
                const inferenceErrors = this.validateInferenceConfig(step.inferenceConfig);
                if (inferenceErrors.length > 0) {
                    errors.push(`${stepName} step: ${inferenceErrors.join(', ')}`);
                }
            }
        };
        // Validate each step's inference config
        validateStep(props.preProcessingStep, 'Pre-processing');
        validateStep(props.orchestrationStep, 'Orchestration');
        validateStep(props.postProcessingStep, 'Post-processing');
        validateStep(props.routingClassifierStep, 'Routing classifier');
        validateStep(props.memorySummarizationStep, 'Memory summarization');
        validateStep(props.knowledgeBaseResponseGenerationStep, 'Knowledge base response generation');
        // Validate routing classifier's foundation model if provided
        if (props.routingClassifierStep?.foundationModel) {
            if (!props.routingClassifierStep.foundationModel.invokableArn) {
                errors.push('Foundation model must be a valid IBedrockInvokable with an invokableArn');
            }
        }
        return errors;
    };
    validateCustomParser = (props) => {
        const errors = [];
        // Check if at least one step uses custom parser
        const hasCustomParser = [
            props.preProcessingStep?.useCustomParser,
            props.orchestrationStep?.useCustomParser,
            props.postProcessingStep?.useCustomParser,
            props.routingClassifierStep?.useCustomParser,
            props.memorySummarizationStep?.useCustomParser,
            props.knowledgeBaseResponseGenerationStep?.useCustomParser,
        ].some(useCustomParser => useCustomParser === true);
        if (!hasCustomParser) {
            errors.push('At least one step must use custom parser');
        }
        return errors;
    };
}
exports.PromptOverrideConfiguration = PromptOverrideConfiguration;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvbXB0LW92ZXJyaWRlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicHJvbXB0LW92ZXJyaWRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUEsd0RBQXNFO0FBQ3RFLDRFQUE0RDtBQUM1RCxpRUFBbUQ7QUFHbkQ7O0dBRUc7QUFDSCxJQUFZLGFBOEJYO0FBOUJELFdBQVksYUFBYTtJQUN2Qjs7T0FFRztJQUNILGtEQUFpQyxDQUFBO0lBRWpDOztPQUVHO0lBQ0gsZ0RBQStCLENBQUE7SUFFL0I7O09BRUc7SUFDSCxvREFBbUMsQ0FBQTtJQUVuQzs7T0FFRztJQUNILDBEQUF5QyxDQUFBO0lBRXpDOztPQUVHO0lBQ0gsOERBQTZDLENBQUE7SUFFN0M7O09BRUc7SUFDSCwwRkFBeUUsQ0FBQTtBQUMzRSxDQUFDLEVBOUJXLGFBQWEsNkJBQWIsYUFBYSxRQThCeEI7QUE0TEQ7Ozs7R0FJRztBQUNILE1BQWEsMkJBQTJCOztJQUN0Qzs7Ozs7T0FLRztJQUNJLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBNkI7UUFDbkQsSUFBSSxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ2pDLE1BQU0sSUFBSSxnQ0FBdUIsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsaUJBQWlCLEVBQUUsNkJBQTZCLENBQUMsQ0FBQztRQUN6RixDQUFDO1FBRUQsc0NBQXNDO1FBQ3RDLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDekMsUUFBUSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7Z0JBQ3RCLEtBQUssYUFBYSxDQUFDLGNBQWM7b0JBQy9CLE9BQU8sRUFBRSxHQUFHLEdBQUcsRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsQ0FBQztnQkFDN0MsS0FBSyxhQUFhLENBQUMsYUFBYTtvQkFDOUIsT0FBTyxFQUFFLEdBQUcsR0FBRyxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxDQUFDO2dCQUM3QyxLQUFLLGFBQWEsQ0FBQyxlQUFlO29CQUNoQyxPQUFPLEVBQUUsR0FBRyxHQUFHLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQUM7Z0JBQzlDLEtBQUssYUFBYSxDQUFDLGtCQUFrQjtvQkFDbkMsT0FBTyxFQUFFLEdBQUcsR0FBRyxFQUFFLHFCQUFxQixFQUFFLElBQWlELEVBQUUsQ0FBQztnQkFDOUYsS0FBSyxhQUFhLENBQUMsb0JBQW9CO29CQUNyQyxPQUFPLEVBQUUsR0FBRyxHQUFHLEVBQUUsdUJBQXVCLEVBQUUsSUFBSSxFQUFFLENBQUM7Z0JBQ25ELEtBQUssYUFBYSxDQUFDLGtDQUFrQztvQkFDbkQsT0FBTyxFQUFFLEdBQUcsR0FBRyxFQUFFLG1DQUFtQyxFQUFFLElBQUksRUFBRSxDQUFDO2dCQUMvRDtvQkFDRSxPQUFPLEdBQUcsQ0FBQztZQUNmLENBQUM7UUFDSCxDQUFDLEVBQUUsRUFBdUIsQ0FBQyxDQUFDO1FBRTVCLE9BQU8sSUFBSSwyQkFBMkIsQ0FBQyxPQUFPLENBQUMsQ0FBQztLQUNqRDtJQUVEOzs7OztPQUtHO0lBQ0ksTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQXdCOzs7Ozs7Ozs7O1FBQ3JELE9BQU8sSUFBSSwyQkFBMkIsQ0FBQyxLQUFLLENBQUMsQ0FBQztLQUMvQztJQUVEOzs7Ozs7Ozs7Ozs7T0FZRztJQUNNLE1BQU0sQ0FBYTtJQUU1Qjs7T0FFRztJQUNNLGlCQUFpQixDQUF5QztJQUVuRTs7T0FFRztJQUNNLGlCQUFpQixDQUF5QztJQUVuRTs7T0FFRztJQUNNLGtCQUFrQixDQUEwQztJQUVyRTs7T0FFRztJQUNNLHFCQUFxQixDQUE2QztJQUUzRTs7T0FFRztJQUNNLHVCQUF1QixDQUErQztJQUUvRTs7T0FFRztJQUNNLG1DQUFtQyxDQUEyRDtJQUV2Rzs7OztPQUlHO0lBQ0gsWUFBb0IsS0FBd0I7UUFDMUMsaUJBQWlCO1FBQ2pCLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNyRCxJQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNqQixVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUM5RCxDQUFDO1FBQ0QsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO1FBQzNCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUMsaUJBQWlCLENBQUM7UUFDakQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztRQUNqRCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDLGtCQUFrQixDQUFDO1FBQ25ELElBQUksQ0FBQyxxQkFBcUIsR0FBRyxLQUFLLENBQUMscUJBQXFCLENBQUM7UUFDekQsSUFBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQztRQUM3RCxJQUFJLENBQUMsbUNBQW1DLEdBQUcsS0FBSyxDQUFDLG1DQUFtQyxDQUFDO0tBQ3RGO0lBRUQ7Ozs7T0FJRztJQUNJLE9BQU87UUFDWixNQUFNLGNBQWMsR0FBMkMsRUFBRSxDQUFDO1FBRWxFLHNEQUFzRDtRQUN0RCxNQUFNLGdCQUFnQixHQUFHLENBQUMsSUFBc0MsRUFBRSxJQUFtQixFQUFFLEVBQUU7WUFDdkYsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDVCxjQUFjLENBQUMsSUFBSSxDQUFDO29CQUNsQixVQUFVLEVBQUUsSUFBSTtvQkFDaEIsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsVUFBVTtvQkFDbkcsVUFBVSxFQUFFLElBQUksQ0FBQyxlQUFlLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsU0FBUztvQkFDNUcsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsU0FBUztvQkFDOUgsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLG9CQUFvQjtvQkFDN0Msc0JBQXNCLEVBQUUsSUFBSSxDQUFDLGVBQWU7b0JBQzVDLDZEQUE2RDtvQkFDN0QsZUFBZSxFQUFFLElBQUksS0FBSyxhQUFhLENBQUMsa0JBQWtCO3dCQUN4RCxDQUFDLENBQUUsSUFBa0QsQ0FBQyxlQUFlLEVBQUUsWUFBWTt3QkFDbkYsQ0FBQyxDQUFDLFNBQVM7aUJBQ2QsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztRQUNILENBQUMsQ0FBQztRQUVGLG1EQUFtRDtRQUNuRCxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ3ZFLGdCQUFnQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDdEUsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLGFBQWEsQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUN6RSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMscUJBQXFCLEVBQUUsYUFBYSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDL0UsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQ25GLGdCQUFnQixDQUFDLElBQUksQ0FBQyxtQ0FBbUMsRUFBRSxhQUFhLENBQUMsa0NBQWtDLENBQUMsQ0FBQztRQUU3RyxPQUFPO1lBQ0wsY0FBYyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsV0FBVztZQUN4QyxvQkFBb0IsRUFBRSxjQUFjO1NBQ3JDLENBQUM7S0FDSDtJQUVPLHVCQUF1QixHQUFHLENBQUMsTUFBK0IsRUFBWSxFQUFFO1FBQzlFLE1BQU0sTUFBTSxHQUFhLEVBQUUsQ0FBQztRQUM1QixJQUFJLE1BQU0sRUFBRSxDQUFDO1lBQ1gsSUFBSSxNQUFNLENBQUMsV0FBVyxHQUFHLENBQUMsSUFBSSxNQUFNLENBQUMsV0FBVyxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUNyRCxNQUFNLENBQUMsSUFBSSxDQUFDLHFDQUFxQyxDQUFDLENBQUM7WUFDckQsQ0FBQztZQUNELElBQUksTUFBTSxDQUFDLElBQUksR0FBRyxDQUFDLElBQUksTUFBTSxDQUFDLElBQUksR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDdkMsTUFBTSxDQUFDLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1lBQzlDLENBQUM7WUFDRCxJQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUcsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7Z0JBQ3pDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztZQUNoRCxDQUFDO1lBQ0QsSUFBSSxNQUFNLENBQUMsYUFBYSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDcEMsTUFBTSxDQUFDLElBQUksQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO1lBQ2xELENBQUM7WUFDRCxJQUFJLE1BQU0sQ0FBQyxhQUFhLEdBQUcsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxhQUFhLEdBQUcsSUFBSSxFQUFFLENBQUM7Z0JBQzVELE1BQU0sQ0FBQyxJQUFJLENBQUMsMENBQTBDLENBQUMsQ0FBQztZQUMxRCxDQUFDO1FBQ0gsQ0FBQztRQUNELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUMsQ0FBQztJQUVNLGFBQWEsR0FBRyxDQUFDLEtBQXdCLEVBQVksRUFBRTtRQUM3RCxNQUFNLE1BQU0sR0FBYSxFQUFFLENBQUM7UUFFNUIsaUNBQWlDO1FBQ2pDLE1BQU0sUUFBUSxHQUFHO1lBQ2YsS0FBSyxDQUFDLGlCQUFpQjtZQUN2QixLQUFLLENBQUMsaUJBQWlCO1lBQ3ZCLEtBQUssQ0FBQyxrQkFBa0I7WUFDeEIsS0FBSyxDQUFDLHFCQUFxQjtZQUMzQixLQUFLLENBQUMsdUJBQXVCO1lBQzdCLEtBQUssQ0FBQyxtQ0FBbUM7U0FDMUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLEtBQUssU0FBUyxDQUFDLENBQUM7UUFFbkMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1FBQzdDLENBQUM7UUFFRCx3REFBd0Q7UUFDeEQsTUFBTSxZQUFZLEdBQUcsQ0FBQyxJQUFzQyxFQUFFLFFBQWdCLEVBQUUsRUFBRTtZQUNoRixJQUFJLElBQUksRUFBRSxDQUFDO2dCQUNULDZEQUE2RDtnQkFDN0QsSUFBSSxpQkFBaUIsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxhQUFhLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztvQkFDcEYsTUFBTSxDQUFDLElBQUksQ0FBQyx5RUFBeUUsQ0FBQyxDQUFDO2dCQUN6RixDQUFDO2dCQUVELE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7Z0JBQzNFLElBQUksZUFBZSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztvQkFDL0IsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLFFBQVEsVUFBVSxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDakUsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDLENBQUM7UUFFRix3Q0FBd0M7UUFDeEMsWUFBWSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3hELFlBQVksQ0FBQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFDdkQsWUFBWSxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO1FBQzFELFlBQVksQ0FBQyxLQUFLLENBQUMscUJBQXFCLEVBQUUsb0JBQW9CLENBQUMsQ0FBQztRQUNoRSxZQUFZLENBQUMsS0FBSyxDQUFDLHVCQUF1QixFQUFFLHNCQUFzQixDQUFDLENBQUM7UUFDcEUsWUFBWSxDQUFDLEtBQUssQ0FBQyxtQ0FBbUMsRUFBRSxvQ0FBb0MsQ0FBQyxDQUFDO1FBRTlGLDZEQUE2RDtRQUM3RCxJQUFJLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSxlQUFlLEVBQUUsQ0FBQztZQUNqRCxJQUFJLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDLGVBQWUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDOUQsTUFBTSxDQUFDLElBQUksQ0FBQyx5RUFBeUUsQ0FBQyxDQUFDO1lBQ3pGLENBQUM7UUFDSCxDQUFDO1FBRUQsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQyxDQUFDO0lBRU0sb0JBQW9CLEdBQUcsQ0FBQyxLQUF3QixFQUFZLEVBQUU7UUFDcEUsTUFBTSxNQUFNLEdBQWEsRUFBRSxDQUFDO1FBRTVCLGdEQUFnRDtRQUNoRCxNQUFNLGVBQWUsR0FBRztZQUN0QixLQUFLLENBQUMsaUJBQWlCLEVBQUUsZUFBZTtZQUN4QyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsZUFBZTtZQUN4QyxLQUFLLENBQUMsa0JBQWtCLEVBQUUsZUFBZTtZQUN6QyxLQUFLLENBQUMscUJBQXFCLEVBQUUsZUFBZTtZQUM1QyxLQUFLLENBQUMsdUJBQXVCLEVBQUUsZUFBZTtZQUM5QyxLQUFLLENBQUMsbUNBQW1DLEVBQUUsZUFBZTtTQUMzRCxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLGVBQWUsS0FBSyxJQUFJLENBQUMsQ0FBQztRQUVwRCxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDckIsTUFBTSxDQUFDLElBQUksQ0FBQywwQ0FBMEMsQ0FBQyxDQUFDO1FBQzFELENBQUM7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDLENBQUM7O0FBaFBKLGtFQWlQQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgQ2ZuQWdlbnQgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgdHlwZSB7IElGdW5jdGlvbiB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1sYW1iZGEnO1xuaW1wb3J0IHsgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9lcnJvcnMnO1xuaW1wb3J0IHsgbGl0IH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvaGVscGVycy1pbnRlcm5hbCc7XG5pbXBvcnQgKiBhcyB2YWxpZGF0aW9uIGZyb20gJy4vdmFsaWRhdGlvbi1oZWxwZXJzJztcbmltcG9ydCB0eXBlIHsgSUJlZHJvY2tJbnZva2FibGUgfSBmcm9tICcuLi9tb2RlbHMnO1xuXG4vKipcbiAqIFRoZSBzdGVwIGluIHRoZSBhZ2VudCBzZXF1ZW5jZSB0aGF0IHRoaXMgcHJvbXB0IGNvbmZpZ3VyYXRpb24gYXBwbGllcyB0by5cbiAqL1xuZXhwb3J0IGVudW0gQWdlbnRTdGVwVHlwZSB7XG4gIC8qKlxuICAgKiBQcmUtcHJvY2Vzc2luZyBzdGVwIHRoYXQgcHJlcGFyZXMgdGhlIHVzZXIgaW5wdXQgZm9yIG9yY2hlc3RyYXRpb24uXG4gICAqL1xuICBQUkVfUFJPQ0VTU0lORyA9ICdQUkVfUFJPQ0VTU0lORycsXG5cbiAgLyoqXG4gICAqIE1haW4gb3JjaGVzdHJhdGlvbiBzdGVwIHRoYXQgZGV0ZXJtaW5lcyB0aGUgYWdlbnQncyBhY3Rpb25zLlxuICAgKi9cbiAgT1JDSEVTVFJBVElPTiA9ICdPUkNIRVNUUkFUSU9OJyxcblxuICAvKipcbiAgICogUG9zdC1wcm9jZXNzaW5nIHN0ZXAgdGhhdCByZWZpbmVzIHRoZSBhZ2VudCdzIHJlc3BvbnNlLlxuICAgKi9cbiAgUE9TVF9QUk9DRVNTSU5HID0gJ1BPU1RfUFJPQ0VTU0lORycsXG5cbiAgLyoqXG4gICAqIFN0ZXAgdGhhdCBjbGFzc2lmaWVzIGFuZCByb3V0ZXMgcmVxdWVzdHMgdG8gYXBwcm9wcmlhdGUgY29sbGFib3JhdG9ycy5cbiAgICovXG4gIFJPVVRJTkdfQ0xBU1NJRklFUiA9ICdST1VUSU5HX0NMQVNTSUZJRVInLFxuXG4gIC8qKlxuICAgKiBTdGVwIHRoYXQgc3VtbWFyaXplcyBjb252ZXJzYXRpb24gaGlzdG9yeSBmb3IgbWVtb3J5IHJldGVudGlvbi5cbiAgICovXG4gIE1FTU9SWV9TVU1NQVJJWkFUSU9OID0gJ01FTU9SWV9TVU1NQVJJWkFUSU9OJyxcblxuICAvKipcbiAgICogU3RlcCB0aGF0IGdlbmVyYXRlcyByZXNwb25zZXMgdXNpbmcga25vd2xlZGdlIGJhc2UgY29udGVudC5cbiAgICovXG4gIEtOT1dMRURHRV9CQVNFX1JFU1BPTlNFX0dFTkVSQVRJT04gPSAnS05PV0xFREdFX0JBU0VfUkVTUE9OU0VfR0VORVJBVElPTicsXG59XG5cbi8qKlxuICogTExNIGluZmVyZW5jZSBjb25maWd1cmF0aW9uXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSW5mZXJlbmNlQ29uZmlndXJhdGlvbiB7XG4gIC8qKlxuICAgKiBUaGUgbGlrZWxpaG9vZCBvZiB0aGUgbW9kZWwgc2VsZWN0aW5nIGhpZ2hlci1wcm9iYWJpbGl0eSBvcHRpb25zIHdoaWxlXG4gICAqIGdlbmVyYXRpbmcgYSByZXNwb25zZS4gQSBsb3dlciB2YWx1ZSBtYWtlcyB0aGUgbW9kZWwgbW9yZSBsaWtlbHkgdG8gY2hvb3NlXG4gICAqIGhpZ2hlci1wcm9iYWJpbGl0eSBvcHRpb25zLCB3aGlsZSBhIGhpZ2hlciB2YWx1ZSBtYWtlcyB0aGUgbW9kZWwgbW9yZVxuICAgKiBsaWtlbHkgdG8gY2hvb3NlIGxvd2VyLXByb2JhYmlsaXR5IG9wdGlvbnMuXG4gICAqXG4gICAqIEZsb2F0aW5nIHBvaW50XG4gICAqXG4gICAqIG1pbiAwXG4gICAqIG1heCAxXG4gICAqL1xuICByZWFkb25seSB0ZW1wZXJhdHVyZTogbnVtYmVyO1xuICAvKipcbiAgICogV2hpbGUgZ2VuZXJhdGluZyBhIHJlc3BvbnNlLCB0aGUgbW9kZWwgZGV0ZXJtaW5lcyB0aGUgcHJvYmFiaWxpdHkgb2YgdGhlXG4gICAqIGZvbGxvd2luZyB0b2tlbiBhdCBlYWNoIHBvaW50IG9mIGdlbmVyYXRpb24uIFRoZSB2YWx1ZSB0aGF0IHlvdSBzZXQgZm9yXG4gICAqIFRvcCBQIGRldGVybWluZXMgdGhlIG51bWJlciBvZiBtb3N0LWxpa2VseSBjYW5kaWRhdGVzIGZyb20gd2hpY2ggdGhlIG1vZGVsXG4gICAqIGNob29zZXMgdGhlIG5leHQgdG9rZW4gaW4gdGhlIHNlcXVlbmNlLiBGb3IgZXhhbXBsZSwgaWYgeW91IHNldCB0b3BQIHRvXG4gICAqIDgwLCB0aGUgbW9kZWwgb25seSBzZWxlY3RzIHRoZSBuZXh0IHRva2VuIGZyb20gdGhlIHRvcCA4MCUgb2YgdGhlXG4gICAqIHByb2JhYmlsaXR5IGRpc3RyaWJ1dGlvbiBvZiBuZXh0IHRva2Vucy5cbiAgICpcbiAgICogRmxvYXRpbmcgcG9pbnRcbiAgICpcbiAgICogbWluIDBcbiAgICogbWF4IDFcbiAgICovXG4gIHJlYWRvbmx5IHRvcFA6IG51bWJlcjtcbiAgLyoqXG4gICAqIFdoaWxlIGdlbmVyYXRpbmcgYSByZXNwb25zZSwgdGhlIG1vZGVsIGRldGVybWluZXMgdGhlIHByb2JhYmlsaXR5IG9mIHRoZVxuICAgKiBmb2xsb3dpbmcgdG9rZW4gYXQgZWFjaCBwb2ludCBvZiBnZW5lcmF0aW9uLiBUaGUgdmFsdWUgdGhhdCB5b3Ugc2V0IGZvclxuICAgKiB0b3BLIGlzIHRoZSBudW1iZXIgb2YgbW9zdC1saWtlbHkgY2FuZGlkYXRlcyBmcm9tIHdoaWNoIHRoZSBtb2RlbCBjaG9vc2VzXG4gICAqIHRoZSBuZXh0IHRva2VuIGluIHRoZSBzZXF1ZW5jZS4gRm9yIGV4YW1wbGUsIGlmIHlvdSBzZXQgdG9wSyB0byA1MCwgdGhlXG4gICAqIG1vZGVsIHNlbGVjdHMgdGhlIG5leHQgdG9rZW4gZnJvbSBhbW9uZyB0aGUgdG9wIDUwIG1vc3QgbGlrZWx5IGNob2ljZXMuXG4gICAqXG4gICAqIEludGVnZXJcbiAgICpcbiAgICogbWluIDBcbiAgICogbWF4IDUwMFxuICAgKi9cbiAgcmVhZG9ubHkgdG9wSzogbnVtYmVyO1xuICAvKipcbiAgICogQSBsaXN0IG9mIHN0b3Agc2VxdWVuY2VzLiBBIHN0b3Agc2VxdWVuY2UgaXMgYSBzZXF1ZW5jZSBvZiBjaGFyYWN0ZXJzIHRoYXRcbiAgICogY2F1c2VzIHRoZSBtb2RlbCB0byBzdG9wIGdlbmVyYXRpbmcgdGhlIHJlc3BvbnNlLlxuICAgKlxuICAgKiBsZW5ndGggMC00XG4gICAqL1xuICByZWFkb25seSBzdG9wU2VxdWVuY2VzOiBzdHJpbmdbXTtcbiAgLyoqXG4gICAqIFRoZSBtYXhpbXVtIG51bWJlciBvZiB0b2tlbnMgdG8gZ2VuZXJhdGUgaW4gdGhlIHJlc3BvbnNlLlxuICAgKlxuICAgKiBJbnRlZ2VyXG4gICAqXG4gICAqIG1pbiAwXG4gICAqIG1heCA0MDk2XG4gICAqL1xuICByZWFkb25seSBtYXhpbXVtTGVuZ3RoOiBudW1iZXI7XG59XG5cbi8qKlxuICogQmFzZSBjb25maWd1cmF0aW9uIGludGVyZmFjZSBmb3IgYWxsIHByb21wdCBzdGVwIHR5cGVzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0U3RlcENvbmZpZ0Jhc2Uge1xuICAvKipcbiAgICogVGhlIHR5cGUgb2Ygc3RlcCB0aGlzIGNvbmZpZ3VyYXRpb24gYXBwbGllcyB0by5cbiAgICovXG4gIHJlYWRvbmx5IHN0ZXBUeXBlOiBBZ2VudFN0ZXBUeXBlO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIGVuYWJsZSBvciBza2lwIHRoaXMgc3RlcCBpbiB0aGUgYWdlbnQgc2VxdWVuY2UuXG4gICAqIEBkZWZhdWx0IC0gVGhlIGRlZmF1bHQgc3RhdGUgZm9yIGVhY2ggc3RlcCB0eXBlIGlzIGFzIGZvbGxvd3MuXG4gICAqXG4gICAqICAgICBQUkVfUFJPQ0VTU0lORyDigJMgRU5BQkxFRFxuICAgKiAgICAgT1JDSEVTVFJBVElPTiDigJMgRU5BQkxFRFxuICAgKiAgICAgS05PV0xFREdFX0JBU0VfUkVTUE9OU0VfR0VORVJBVElPTiDigJMgRU5BQkxFRFxuICAgKiAgICAgUE9TVF9QUk9DRVNTSU5HIOKAkyBESVNBQkxFRFxuICAgKi9cbiAgcmVhZG9ubHkgc3RlcEVuYWJsZWQ/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBUaGUgY3VzdG9tIHByb21wdCB0ZW1wbGF0ZSB0byBiZSB1c2VkLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIFRoZSBkZWZhdWx0IHByb21wdCB0ZW1wbGF0ZSB3aWxsIGJlIHVzZWQuXG4gICAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9wcm9tcHQtcGxhY2Vob2xkZXJzLmh0bWxcbiAgICovXG4gIHJlYWRvbmx5IGN1c3RvbVByb21wdFRlbXBsYXRlPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgaW5mZXJlbmNlIGNvbmZpZ3VyYXRpb24gcGFyYW1ldGVycyB0byB1c2UuXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIERlZmF1bHQgaW5mZXJlbmNlIGNvbmZpZ3VyYXRpb24gd2lsbCBiZSB1c2VkXG4gICAqL1xuICByZWFkb25seSBpbmZlcmVuY2VDb25maWc/OiBJbmZlcmVuY2VDb25maWd1cmF0aW9uO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIHVzZSB0aGUgY3VzdG9tIExhbWJkYSBwYXJzZXIgZGVmaW5lZCBmb3IgdGhlIHNlcXVlbmNlLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIGZhbHNlXG4gICAqL1xuICByZWFkb25seSB1c2VDdXN0b21QYXJzZXI/OiBib29sZWFuO1xufVxuXG4vKipcbiAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSBwcmUtcHJvY2Vzc2luZyBzdGVwXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0UHJlUHJvY2Vzc2luZ0NvbmZpZ0N1c3RvbVBhcnNlciBleHRlbmRzIFByb21wdFN0ZXBDb25maWdCYXNlIHt9XG5cbi8qKlxuICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIG9yY2hlc3RyYXRpb24gc3RlcFxuICovXG5leHBvcnQgaW50ZXJmYWNlIFByb21wdE9yY2hlc3RyYXRpb25Db25maWdDdXN0b21QYXJzZXIgZXh0ZW5kcyBQcm9tcHRTdGVwQ29uZmlnQmFzZSB7fVxuXG4vKipcbiAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSBwb3N0LXByb2Nlc3Npbmcgc3RlcFxuICovXG5leHBvcnQgaW50ZXJmYWNlIFByb21wdFBvc3RQcm9jZXNzaW5nQ29uZmlnQ3VzdG9tUGFyc2VyIGV4dGVuZHMgUHJvbXB0U3RlcENvbmZpZ0Jhc2Uge31cblxuLyoqXG4gKiBDb25maWd1cmF0aW9uIGZvciB0aGUgcm91dGluZyBjbGFzc2lmaWVyIHN0ZXBcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBQcm9tcHRSb3V0aW5nQ2xhc3NpZmllckNvbmZpZ0N1c3RvbVBhcnNlciBleHRlbmRzIFByb21wdFN0ZXBDb25maWdCYXNlIHtcbiAgLyoqXG4gICAqIFRoZSBmb3VuZGF0aW9uIG1vZGVsIHRvIHVzZSBmb3IgdGhlIHJvdXRpbmcgY2xhc3NpZmllciBzdGVwLlxuICAgKiBUaGlzIGlzIHJlcXVpcmVkIGZvciB0aGUgcm91dGluZyBjbGFzc2lmaWVyIHN0ZXAuXG4gICAqL1xuICByZWFkb25seSBmb3VuZGF0aW9uTW9kZWw6IElCZWRyb2NrSW52b2thYmxlO1xufVxuXG4vKipcbiAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSBtZW1vcnkgc3VtbWFyaXphdGlvbiBzdGVwXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0TWVtb3J5U3VtbWFyaXphdGlvbkNvbmZpZ0N1c3RvbVBhcnNlciBleHRlbmRzIFByb21wdFN0ZXBDb25maWdCYXNlIHt9XG5cbi8qKlxuICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIGtub3dsZWRnZSBiYXNlIHJlc3BvbnNlIGdlbmVyYXRpb24gc3RlcFxuICovXG5leHBvcnQgaW50ZXJmYWNlIFByb21wdEtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25Db25maWdDdXN0b21QYXJzZXIgZXh0ZW5kcyBQcm9tcHRTdGVwQ29uZmlnQmFzZSB7fVxuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNvbmZpZ3VyaW5nIGEgY3VzdG9tIExhbWJkYSBwYXJzZXIgZm9yIHByb21wdCBvdmVycmlkZXMuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ3VzdG9tUGFyc2VyUHJvcHMge1xuICAvKipcbiAgICogTGFtYmRhIGZ1bmN0aW9uIHRvIHVzZSBhcyBjdXN0b20gcGFyc2VyLlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBObyBjdXN0b20gcGFyc2VyIGlzIHVzZWRcbiAgICovXG4gIHJlYWRvbmx5IHBhcnNlcj86IElGdW5jdGlvbjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIHByZS1wcm9jZXNzaW5nIHN0ZXAuXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIHByZS1wcm9jZXNzaW5nIGNvbmZpZ3VyYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IHByZVByb2Nlc3NpbmdTdGVwPzogUHJvbXB0UHJlUHJvY2Vzc2luZ0NvbmZpZ0N1c3RvbVBhcnNlcjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIG9yY2hlc3RyYXRpb24gc3RlcC5cbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8gb3JjaGVzdHJhdGlvbiBjb25maWd1cmF0aW9uXG4gICAqL1xuICByZWFkb25seSBvcmNoZXN0cmF0aW9uU3RlcD86IFByb21wdE9yY2hlc3RyYXRpb25Db25maWdDdXN0b21QYXJzZXI7XG5cbiAgLyoqXG4gICAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSBwb3N0LXByb2Nlc3Npbmcgc3RlcC5cbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8gcG9zdC1wcm9jZXNzaW5nIGNvbmZpZ3VyYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IHBvc3RQcm9jZXNzaW5nU3RlcD86IFByb21wdFBvc3RQcm9jZXNzaW5nQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUgcm91dGluZyBjbGFzc2lmaWVyIHN0ZXAuXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIHJvdXRpbmcgY2xhc3NpZmllciBjb25maWd1cmF0aW9uXG4gICAqL1xuICByZWFkb25seSByb3V0aW5nQ2xhc3NpZmllclN0ZXA/OiBQcm9tcHRSb3V0aW5nQ2xhc3NpZmllckNvbmZpZ0N1c3RvbVBhcnNlcjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIG1lbW9yeSBzdW1tYXJpemF0aW9uIHN0ZXAuXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIE5vIG1lbW9yeSBzdW1tYXJpemF0aW9uIGNvbmZpZ3VyYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IG1lbW9yeVN1bW1hcml6YXRpb25TdGVwPzogUHJvbXB0TWVtb3J5U3VtbWFyaXphdGlvbkNvbmZpZ0N1c3RvbVBhcnNlcjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIGtub3dsZWRnZSBiYXNlIHJlc3BvbnNlIGdlbmVyYXRpb24gc3RlcC5cbiAgICogQGRlZmF1bHQgdW5kZWZpbmVkIC0gTm8ga25vd2xlZGdlIGJhc2UgcmVzcG9uc2UgZ2VuZXJhdGlvbiBjb25maWd1cmF0aW9uXG4gICAqL1xuICByZWFkb25seSBrbm93bGVkZ2VCYXNlUmVzcG9uc2VHZW5lcmF0aW9uU3RlcD86IFByb21wdEtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25Db25maWdDdXN0b21QYXJzZXI7XG59XG5cbi8qKlxuICogQ29uZmlndXJhdGlvbiBmb3Igb3ZlcnJpZGluZyBwcm9tcHQgdGVtcGxhdGVzIGFuZCBiZWhhdmlvcnMgaW4gZGlmZmVyZW50IHBhcnRzXG4gKiBvZiBhbiBhZ2VudCdzIHNlcXVlbmNlLiBUaGlzIGFsbG93cyBjdXN0b21pemluZyBob3cgdGhlIGFnZW50IHByb2Nlc3NlcyBpbnB1dHMsXG4gKiBtYWtlcyBkZWNpc2lvbnMsIGFuZCBnZW5lcmF0ZXMgcmVzcG9uc2VzLlxuICovXG5leHBvcnQgY2xhc3MgUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBQcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb24gZnJvbSBpbmRpdmlkdWFsIHN0ZXAgY29uZmlndXJhdGlvbnMuXG4gICAqIFVzZSB0aGlzIG1ldGhvZCB3aGVuIHlvdSB3YW50IHRvIG92ZXJyaWRlIHByb21wdHMgd2l0aG91dCB1c2luZyBhIGN1c3RvbSBwYXJzZXIuXG4gICAqIEBwYXJhbSBzdGVwcyBUaGUgc3RlcCBjb25maWd1cmF0aW9ucyB0byB1c2VcbiAgICogQHJldHVybnMgQSBuZXcgUHJvbXB0T3ZlcnJpZGVDb25maWd1cmF0aW9uIGluc3RhbmNlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21TdGVwcyhzdGVwczogUHJvbXB0U3RlcENvbmZpZ0Jhc2VbXSk6IFByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbiB7XG4gICAgaWYgKCFzdGVwcyB8fCBzdGVwcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IG5ldyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvcihsaXRgRW1wdHlTdGVwc0FycmF5YCwgJ1N0ZXBzIGFycmF5IGNhbm5vdCBiZSBlbXB0eScpO1xuICAgIH1cblxuICAgIC8vIENvbnZlcnQgc3RlcHMgYXJyYXkgdG8gcHJvcHMgZm9ybWF0XG4gICAgY29uc3Qgc3RlcE1hcCA9IHN0ZXBzLnJlZHVjZSgoYWNjLCBzdGVwKSA9PiB7XG4gICAgICBzd2l0Y2ggKHN0ZXAuc3RlcFR5cGUpIHtcbiAgICAgICAgY2FzZSBBZ2VudFN0ZXBUeXBlLlBSRV9QUk9DRVNTSU5HOlxuICAgICAgICAgIHJldHVybiB7IC4uLmFjYywgcHJlUHJvY2Vzc2luZ1N0ZXA6IHN0ZXAgfTtcbiAgICAgICAgY2FzZSBBZ2VudFN0ZXBUeXBlLk9SQ0hFU1RSQVRJT046XG4gICAgICAgICAgcmV0dXJuIHsgLi4uYWNjLCBvcmNoZXN0cmF0aW9uU3RlcDogc3RlcCB9O1xuICAgICAgICBjYXNlIEFnZW50U3RlcFR5cGUuUE9TVF9QUk9DRVNTSU5HOlxuICAgICAgICAgIHJldHVybiB7IC4uLmFjYywgcG9zdFByb2Nlc3NpbmdTdGVwOiBzdGVwIH07XG4gICAgICAgIGNhc2UgQWdlbnRTdGVwVHlwZS5ST1VUSU5HX0NMQVNTSUZJRVI6XG4gICAgICAgICAgcmV0dXJuIHsgLi4uYWNjLCByb3V0aW5nQ2xhc3NpZmllclN0ZXA6IHN0ZXAgYXMgUHJvbXB0Um91dGluZ0NsYXNzaWZpZXJDb25maWdDdXN0b21QYXJzZXIgfTtcbiAgICAgICAgY2FzZSBBZ2VudFN0ZXBUeXBlLk1FTU9SWV9TVU1NQVJJWkFUSU9OOlxuICAgICAgICAgIHJldHVybiB7IC4uLmFjYywgbWVtb3J5U3VtbWFyaXphdGlvblN0ZXA6IHN0ZXAgfTtcbiAgICAgICAgY2FzZSBBZ2VudFN0ZXBUeXBlLktOT1dMRURHRV9CQVNFX1JFU1BPTlNFX0dFTkVSQVRJT046XG4gICAgICAgICAgcmV0dXJuIHsgLi4uYWNjLCBrbm93bGVkZ2VCYXNlUmVzcG9uc2VHZW5lcmF0aW9uU3RlcDogc3RlcCB9O1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIHJldHVybiBhY2M7XG4gICAgICB9XG4gICAgfSwge30gYXMgQ3VzdG9tUGFyc2VyUHJvcHMpO1xuXG4gICAgcmV0dXJuIG5ldyBQcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb24oc3RlcE1hcCk7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBhIFByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbiB3aXRoIGEgY3VzdG9tIExhbWJkYSBwYXJzZXIgZnVuY3Rpb24uXG4gICAqIEBwYXJhbSBwcm9wcyBDb25maWd1cmF0aW9uIGluY2x1ZGluZzpcbiAgICogICAtIGBwYXJzZXJgOiBMYW1iZGEgZnVuY3Rpb24gdG8gdXNlIGFzIGN1c3RvbSBwYXJzZXJcbiAgICogICAtIEluZGl2aWR1YWwgc3RlcCBjb25maWd1cmF0aW9ucy4gQXQgbGVhc3Qgb25lIG9mIHRoZSBzdGVwcyBtdXN0IG1ha2UgdXNlIG9mIHRoZSBjdXN0b20gcGFyc2VyLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyB3aXRoQ3VzdG9tUGFyc2VyKHByb3BzOiBDdXN0b21QYXJzZXJQcm9wcyk6IFByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbiB7XG4gICAgcmV0dXJuIG5ldyBQcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb24ocHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBjdXN0b20gTGFtYmRhIHBhcnNlciBmdW5jdGlvbiB0byB1c2UuXG4gICAqIFRoZSBMYW1iZGEgcGFyc2VyIHByb2Nlc3NlcyBhbmQgaW50ZXJwcmV0cyB0aGUgcmF3IGZvdW5kYXRpb24gbW9kZWwgb3V0cHV0LlxuICAgKiBJdCByZWNlaXZlcyBhbiBpbnB1dCBldmVudCB3aXRoOlxuICAgKiAtIG1lc3NhZ2VWZXJzaW9uOiBWZXJzaW9uIG9mIG1lc3NhZ2UgZm9ybWF0ICgxLjApXG4gICAqIC0gYWdlbnQ6IEluZm8gYWJvdXQgdGhlIGFnZW50IChuYW1lLCBpZCwgYWxpYXMsIHZlcnNpb24pXG4gICAqIC0gaW52b2tlTW9kZWxSYXdSZXNwb25zZTogUmF3IG1vZGVsIG91dHB1dCB0byBwYXJzZVxuICAgKiAtIHByb21wdFR5cGU6IFR5cGUgb2YgcHJvbXB0IGJlaW5nIHBhcnNlZFxuICAgKiAtIG92ZXJyaWRlVHlwZTogVHlwZSBvZiBvdmVycmlkZSAoT1VUUFVUX1BBUlNFUilcbiAgICpcbiAgICogVGhlIExhbWJkYSBtdXN0IHJldHVybiBhIHJlc3BvbnNlIHRoYXQgdGhlIGFnZW50IHVzZXMgZm9yIG5leHQgYWN0aW9ucy5cbiAgICogQHNlZSBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vYmVkcm9jay9sYXRlc3QvdXNlcmd1aWRlL2xhbWJkYS1wYXJzZXIuaHRtbFxuICAgKi9cbiAgcmVhZG9ubHkgcGFyc2VyPzogSUZ1bmN0aW9uO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUgcHJlLXByb2Nlc3Npbmcgc3RlcC5cbiAgICovXG4gIHJlYWRvbmx5IHByZVByb2Nlc3NpbmdTdGVwPzogUHJvbXB0UHJlUHJvY2Vzc2luZ0NvbmZpZ0N1c3RvbVBhcnNlcjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIG9yY2hlc3RyYXRpb24gc3RlcC5cbiAgICovXG4gIHJlYWRvbmx5IG9yY2hlc3RyYXRpb25TdGVwPzogUHJvbXB0T3JjaGVzdHJhdGlvbkNvbmZpZ0N1c3RvbVBhcnNlcjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIHBvc3QtcHJvY2Vzc2luZyBzdGVwLlxuICAgKi9cbiAgcmVhZG9ubHkgcG9zdFByb2Nlc3NpbmdTdGVwPzogUHJvbXB0UG9zdFByb2Nlc3NpbmdDb25maWdDdXN0b21QYXJzZXI7XG5cbiAgLyoqXG4gICAqIENvbmZpZ3VyYXRpb24gZm9yIHRoZSByb3V0aW5nIGNsYXNzaWZpZXIgc3RlcC5cbiAgICovXG4gIHJlYWRvbmx5IHJvdXRpbmdDbGFzc2lmaWVyU3RlcD86IFByb21wdFJvdXRpbmdDbGFzc2lmaWVyQ29uZmlnQ3VzdG9tUGFyc2VyO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uIGZvciB0aGUgbWVtb3J5IHN1bW1hcml6YXRpb24gc3RlcC5cbiAgICovXG4gIHJlYWRvbmx5IG1lbW9yeVN1bW1hcml6YXRpb25TdGVwPzogUHJvbXB0TWVtb3J5U3VtbWFyaXphdGlvbkNvbmZpZ0N1c3RvbVBhcnNlcjtcblxuICAvKipcbiAgICogQ29uZmlndXJhdGlvbiBmb3IgdGhlIGtub3dsZWRnZSBiYXNlIHJlc3BvbnNlIGdlbmVyYXRpb24gc3RlcC5cbiAgICovXG4gIHJlYWRvbmx5IGtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25TdGVwPzogUHJvbXB0S25vd2xlZGdlQmFzZVJlc3BvbnNlR2VuZXJhdGlvbkNvbmZpZ0N1c3RvbVBhcnNlcjtcblxuICAvKipcbiAgICogQ3JlYXRlIGEgbmV3IFByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvbi5cbiAgICpcbiAgICogQGludGVybmFsIC0gVGhpcyBpcyBtYXJrZWQgYXMgcHJpdmF0ZSBzbyBlbmQgdXNlcnMgbGV2ZXJhZ2UgaXQgb25seSB0aHJvdWdoIHN0YXRpYyBtZXRob2RzXG4gICAqL1xuICBwcml2YXRlIGNvbnN0cnVjdG9yKHByb3BzOiBDdXN0b21QYXJzZXJQcm9wcykge1xuICAgIC8vIFZhbGlkYXRlIHByb3BzXG4gICAgdmFsaWRhdGlvbi50aHJvd0lmSW52YWxpZCh0aGlzLnZhbGlkYXRlU3RlcHMsIHByb3BzKTtcbiAgICBpZiAocHJvcHMucGFyc2VyKSB7XG4gICAgICB2YWxpZGF0aW9uLnRocm93SWZJbnZhbGlkKHRoaXMudmFsaWRhdGVDdXN0b21QYXJzZXIsIHByb3BzKTtcbiAgICB9XG4gICAgdGhpcy5wYXJzZXIgPSBwcm9wcy5wYXJzZXI7XG4gICAgdGhpcy5wcmVQcm9jZXNzaW5nU3RlcCA9IHByb3BzLnByZVByb2Nlc3NpbmdTdGVwO1xuICAgIHRoaXMub3JjaGVzdHJhdGlvblN0ZXAgPSBwcm9wcy5vcmNoZXN0cmF0aW9uU3RlcDtcbiAgICB0aGlzLnBvc3RQcm9jZXNzaW5nU3RlcCA9IHByb3BzLnBvc3RQcm9jZXNzaW5nU3RlcDtcbiAgICB0aGlzLnJvdXRpbmdDbGFzc2lmaWVyU3RlcCA9IHByb3BzLnJvdXRpbmdDbGFzc2lmaWVyU3RlcDtcbiAgICB0aGlzLm1lbW9yeVN1bW1hcml6YXRpb25TdGVwID0gcHJvcHMubWVtb3J5U3VtbWFyaXphdGlvblN0ZXA7XG4gICAgdGhpcy5rbm93bGVkZ2VCYXNlUmVzcG9uc2VHZW5lcmF0aW9uU3RlcCA9IHByb3BzLmtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25TdGVwO1xuICB9XG5cbiAgLyoqXG4gICAqIEZvcm1hdCBhcyBDZm5BZ2VudC5Qcm9tcHRPdmVycmlkZUNvbmZpZ3VyYXRpb25Qcm9wZXJ0eVxuICAgKlxuICAgKiBAaW50ZXJuYWwgVGhpcyBpcyBhbiBpbnRlcm5hbCBjb3JlIGZ1bmN0aW9uIGFuZCBzaG91bGQgbm90IGJlIGNhbGxlZCBkaXJlY3RseS5cbiAgICovXG4gIHB1YmxpYyBfcmVuZGVyKCk6IENmbkFnZW50LlByb21wdE92ZXJyaWRlQ29uZmlndXJhdGlvblByb3BlcnR5IHtcbiAgICBjb25zdCBjb25maWd1cmF0aW9uczogQ2ZuQWdlbnQuUHJvbXB0Q29uZmlndXJhdGlvblByb3BlcnR5W10gPSBbXTtcblxuICAgIC8vIEhlbHBlciBmdW5jdGlvbiB0byBhZGQgY29uZmlndXJhdGlvbiBpZiBzdGVwIGV4aXN0c1xuICAgIGNvbnN0IGFkZENvbmZpZ3VyYXRpb24gPSAoc3RlcDogUHJvbXB0U3RlcENvbmZpZ0Jhc2UgfCB1bmRlZmluZWQsIHR5cGU6IEFnZW50U3RlcFR5cGUpID0+IHtcbiAgICAgIGlmIChzdGVwKSB7XG4gICAgICAgIGNvbmZpZ3VyYXRpb25zLnB1c2goe1xuICAgICAgICAgIHByb21wdFR5cGU6IHR5cGUsXG4gICAgICAgICAgcHJvbXB0U3RhdGU6IHN0ZXAuc3RlcEVuYWJsZWQgPT09IHVuZGVmaW5lZCA/IHVuZGVmaW5lZCA6IHN0ZXAuc3RlcEVuYWJsZWQgPyAnRU5BQkxFRCcgOiAnRElTQUJMRUQnLFxuICAgICAgICAgIHBhcnNlck1vZGU6IHN0ZXAudXNlQ3VzdG9tUGFyc2VyID09PSB1bmRlZmluZWQgPyB1bmRlZmluZWQgOiBzdGVwLnVzZUN1c3RvbVBhcnNlciA/ICdPVkVSUklEREVOJyA6ICdERUZBVUxUJyxcbiAgICAgICAgICBwcm9tcHRDcmVhdGlvbk1vZGU6IHN0ZXAuY3VzdG9tUHJvbXB0VGVtcGxhdGUgPT09IHVuZGVmaW5lZCA/IHVuZGVmaW5lZCA6IHN0ZXAuY3VzdG9tUHJvbXB0VGVtcGxhdGUgPyAnT1ZFUlJJRERFTicgOiAnREVGQVVMVCcsXG4gICAgICAgICAgYmFzZVByb21wdFRlbXBsYXRlOiBzdGVwLmN1c3RvbVByb21wdFRlbXBsYXRlLFxuICAgICAgICAgIGluZmVyZW5jZUNvbmZpZ3VyYXRpb246IHN0ZXAuaW5mZXJlbmNlQ29uZmlnLFxuICAgICAgICAgIC8vIEluY2x1ZGUgZm91bmRhdGlvbiBtb2RlbCBpZiBpdCdzIGEgcm91dGluZyBjbGFzc2lmaWVyIHN0ZXBcbiAgICAgICAgICBmb3VuZGF0aW9uTW9kZWw6IHR5cGUgPT09IEFnZW50U3RlcFR5cGUuUk9VVElOR19DTEFTU0lGSUVSXG4gICAgICAgICAgICA/IChzdGVwIGFzIFByb21wdFJvdXRpbmdDbGFzc2lmaWVyQ29uZmlnQ3VzdG9tUGFyc2VyKS5mb3VuZGF0aW9uTW9kZWw/Lmludm9rYWJsZUFyblxuICAgICAgICAgICAgOiB1bmRlZmluZWQsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBBZGQgY29uZmlndXJhdGlvbnMgZm9yIGVhY2ggc3RlcCB0eXBlIGlmIGRlZmluZWRcbiAgICBhZGRDb25maWd1cmF0aW9uKHRoaXMucHJlUHJvY2Vzc2luZ1N0ZXAsIEFnZW50U3RlcFR5cGUuUFJFX1BST0NFU1NJTkcpO1xuICAgIGFkZENvbmZpZ3VyYXRpb24odGhpcy5vcmNoZXN0cmF0aW9uU3RlcCwgQWdlbnRTdGVwVHlwZS5PUkNIRVNUUkFUSU9OKTtcbiAgICBhZGRDb25maWd1cmF0aW9uKHRoaXMucG9zdFByb2Nlc3NpbmdTdGVwLCBBZ2VudFN0ZXBUeXBlLlBPU1RfUFJPQ0VTU0lORyk7XG4gICAgYWRkQ29uZmlndXJhdGlvbih0aGlzLnJvdXRpbmdDbGFzc2lmaWVyU3RlcCwgQWdlbnRTdGVwVHlwZS5ST1VUSU5HX0NMQVNTSUZJRVIpO1xuICAgIGFkZENvbmZpZ3VyYXRpb24odGhpcy5tZW1vcnlTdW1tYXJpemF0aW9uU3RlcCwgQWdlbnRTdGVwVHlwZS5NRU1PUllfU1VNTUFSSVpBVElPTik7XG4gICAgYWRkQ29uZmlndXJhdGlvbih0aGlzLmtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25TdGVwLCBBZ2VudFN0ZXBUeXBlLktOT1dMRURHRV9CQVNFX1JFU1BPTlNFX0dFTkVSQVRJT04pO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIG92ZXJyaWRlTGFtYmRhOiB0aGlzLnBhcnNlcj8uZnVuY3Rpb25Bcm4sXG4gICAgICBwcm9tcHRDb25maWd1cmF0aW9uczogY29uZmlndXJhdGlvbnMsXG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgdmFsaWRhdGVJbmZlcmVuY2VDb25maWcgPSAoY29uZmlnPzogSW5mZXJlbmNlQ29uZmlndXJhdGlvbik6IHN0cmluZ1tdID0+IHtcbiAgICBjb25zdCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG4gICAgaWYgKGNvbmZpZykge1xuICAgICAgaWYgKGNvbmZpZy50ZW1wZXJhdHVyZSA8IDAgfHwgY29uZmlnLnRlbXBlcmF0dXJlID4gMSkge1xuICAgICAgICBlcnJvcnMucHVzaCgnVGVtcGVyYXR1cmUgbXVzdCBiZSBiZXR3ZWVuIDAgYW5kIDEnKTtcbiAgICAgIH1cbiAgICAgIGlmIChjb25maWcudG9wUCA8IDAgfHwgY29uZmlnLnRvcFAgPiAxKSB7XG4gICAgICAgIGVycm9ycy5wdXNoKCdUb3BQIG11c3QgYmUgYmV0d2VlbiAwIGFuZCAxJyk7XG4gICAgICB9XG4gICAgICBpZiAoY29uZmlnLnRvcEsgPCAwIHx8IGNvbmZpZy50b3BLID4gNTAwKSB7XG4gICAgICAgIGVycm9ycy5wdXNoKCdUb3BLIG11c3QgYmUgYmV0d2VlbiAwIGFuZCA1MDAnKTtcbiAgICAgIH1cbiAgICAgIGlmIChjb25maWcuc3RvcFNlcXVlbmNlcy5sZW5ndGggPiA0KSB7XG4gICAgICAgIGVycm9ycy5wdXNoKCdNYXhpbXVtIDQgc3RvcCBzZXF1ZW5jZXMgYWxsb3dlZCcpO1xuICAgICAgfVxuICAgICAgaWYgKGNvbmZpZy5tYXhpbXVtTGVuZ3RoIDwgMCB8fCBjb25maWcubWF4aW11bUxlbmd0aCA+IDQwOTYpIHtcbiAgICAgICAgZXJyb3JzLnB1c2goJ01heGltdW1MZW5ndGggbXVzdCBiZSBiZXR3ZWVuIDAgYW5kIDQwOTYnKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGVycm9ycztcbiAgfTtcblxuICBwcml2YXRlIHZhbGlkYXRlU3RlcHMgPSAocHJvcHM6IEN1c3RvbVBhcnNlclByb3BzKTogc3RyaW5nW10gPT4ge1xuICAgIGNvbnN0IGVycm9yczogc3RyaW5nW10gPSBbXTtcblxuICAgIC8vIENoZWNrIGlmIGFueSBzdGVwcyBhcmUgZGVmaW5lZFxuICAgIGNvbnN0IGhhc1N0ZXBzID0gW1xuICAgICAgcHJvcHMucHJlUHJvY2Vzc2luZ1N0ZXAsXG4gICAgICBwcm9wcy5vcmNoZXN0cmF0aW9uU3RlcCxcbiAgICAgIHByb3BzLnBvc3RQcm9jZXNzaW5nU3RlcCxcbiAgICAgIHByb3BzLnJvdXRpbmdDbGFzc2lmaWVyU3RlcCxcbiAgICAgIHByb3BzLm1lbW9yeVN1bW1hcml6YXRpb25TdGVwLFxuICAgICAgcHJvcHMua25vd2xlZGdlQmFzZVJlc3BvbnNlR2VuZXJhdGlvblN0ZXAsXG4gICAgXS5zb21lKHN0ZXAgPT4gc3RlcCAhPT0gdW5kZWZpbmVkKTtcblxuICAgIGlmICghaGFzU3RlcHMpIHtcbiAgICAgIGVycm9ycy5wdXNoKCdTdGVwcyBhcnJheSBjYW5ub3QgYmUgZW1wdHknKTtcbiAgICB9XG5cbiAgICAvLyBIZWxwZXIgZnVuY3Rpb24gdG8gdmFsaWRhdGUgYSBzdGVwJ3MgaW5mZXJlbmNlIGNvbmZpZ1xuICAgIGNvbnN0IHZhbGlkYXRlU3RlcCA9IChzdGVwOiBQcm9tcHRTdGVwQ29uZmlnQmFzZSB8IHVuZGVmaW5lZCwgc3RlcE5hbWU6IHN0cmluZykgPT4ge1xuICAgICAgaWYgKHN0ZXApIHtcbiAgICAgICAgLy8gQ2hlY2sgZm9yIGZvdW5kYXRpb24gbW9kZWwgaW4gbm9uLVJPVVRJTkdfQ0xBU1NJRklFUiBzdGVwc1xuICAgICAgICBpZiAoJ2ZvdW5kYXRpb25Nb2RlbCcgaW4gc3RlcCAmJiBzdGVwLnN0ZXBUeXBlICE9PSBBZ2VudFN0ZXBUeXBlLlJPVVRJTkdfQ0xBU1NJRklFUikge1xuICAgICAgICAgIGVycm9ycy5wdXNoKCdGb3VuZGF0aW9uIG1vZGVsIGNhbiBvbmx5IGJlIHNwZWNpZmllZCBmb3IgUk9VVElOR19DTEFTU0lGSUVSIHN0ZXAgdHlwZScpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgaW5mZXJlbmNlRXJyb3JzID0gdGhpcy52YWxpZGF0ZUluZmVyZW5jZUNvbmZpZyhzdGVwLmluZmVyZW5jZUNvbmZpZyk7XG4gICAgICAgIGlmIChpbmZlcmVuY2VFcnJvcnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIGVycm9ycy5wdXNoKGAke3N0ZXBOYW1lfSBzdGVwOiAke2luZmVyZW5jZUVycm9ycy5qb2luKCcsICcpfWApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcblxuICAgIC8vIFZhbGlkYXRlIGVhY2ggc3RlcCdzIGluZmVyZW5jZSBjb25maWdcbiAgICB2YWxpZGF0ZVN0ZXAocHJvcHMucHJlUHJvY2Vzc2luZ1N0ZXAsICdQcmUtcHJvY2Vzc2luZycpO1xuICAgIHZhbGlkYXRlU3RlcChwcm9wcy5vcmNoZXN0cmF0aW9uU3RlcCwgJ09yY2hlc3RyYXRpb24nKTtcbiAgICB2YWxpZGF0ZVN0ZXAocHJvcHMucG9zdFByb2Nlc3NpbmdTdGVwLCAnUG9zdC1wcm9jZXNzaW5nJyk7XG4gICAgdmFsaWRhdGVTdGVwKHByb3BzLnJvdXRpbmdDbGFzc2lmaWVyU3RlcCwgJ1JvdXRpbmcgY2xhc3NpZmllcicpO1xuICAgIHZhbGlkYXRlU3RlcChwcm9wcy5tZW1vcnlTdW1tYXJpemF0aW9uU3RlcCwgJ01lbW9yeSBzdW1tYXJpemF0aW9uJyk7XG4gICAgdmFsaWRhdGVTdGVwKHByb3BzLmtub3dsZWRnZUJhc2VSZXNwb25zZUdlbmVyYXRpb25TdGVwLCAnS25vd2xlZGdlIGJhc2UgcmVzcG9uc2UgZ2VuZXJhdGlvbicpO1xuXG4gICAgLy8gVmFsaWRhdGUgcm91dGluZyBjbGFzc2lmaWVyJ3MgZm91bmRhdGlvbiBtb2RlbCBpZiBwcm92aWRlZFxuICAgIGlmIChwcm9wcy5yb3V0aW5nQ2xhc3NpZmllclN0ZXA/LmZvdW5kYXRpb25Nb2RlbCkge1xuICAgICAgaWYgKCFwcm9wcy5yb3V0aW5nQ2xhc3NpZmllclN0ZXAuZm91bmRhdGlvbk1vZGVsLmludm9rYWJsZUFybikge1xuICAgICAgICBlcnJvcnMucHVzaCgnRm91bmRhdGlvbiBtb2RlbCBtdXN0IGJlIGEgdmFsaWQgSUJlZHJvY2tJbnZva2FibGUgd2l0aCBhbiBpbnZva2FibGVBcm4nKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZXJyb3JzO1xuICB9O1xuXG4gIHByaXZhdGUgdmFsaWRhdGVDdXN0b21QYXJzZXIgPSAocHJvcHM6IEN1c3RvbVBhcnNlclByb3BzKTogc3RyaW5nW10gPT4ge1xuICAgIGNvbnN0IGVycm9yczogc3RyaW5nW10gPSBbXTtcblxuICAgIC8vIENoZWNrIGlmIGF0IGxlYXN0IG9uZSBzdGVwIHVzZXMgY3VzdG9tIHBhcnNlclxuICAgIGNvbnN0IGhhc0N1c3RvbVBhcnNlciA9IFtcbiAgICAgIHByb3BzLnByZVByb2Nlc3NpbmdTdGVwPy51c2VDdXN0b21QYXJzZXIsXG4gICAgICBwcm9wcy5vcmNoZXN0cmF0aW9uU3RlcD8udXNlQ3VzdG9tUGFyc2VyLFxuICAgICAgcHJvcHMucG9zdFByb2Nlc3NpbmdTdGVwPy51c2VDdXN0b21QYXJzZXIsXG4gICAgICBwcm9wcy5yb3V0aW5nQ2xhc3NpZmllclN0ZXA/LnVzZUN1c3RvbVBhcnNlcixcbiAgICAgIHByb3BzLm1lbW9yeVN1bW1hcml6YXRpb25TdGVwPy51c2VDdXN0b21QYXJzZXIsXG4gICAgICBwcm9wcy5rbm93bGVkZ2VCYXNlUmVzcG9uc2VHZW5lcmF0aW9uU3RlcD8udXNlQ3VzdG9tUGFyc2VyLFxuICAgIF0uc29tZSh1c2VDdXN0b21QYXJzZXIgPT4gdXNlQ3VzdG9tUGFyc2VyID09PSB0cnVlKTtcblxuICAgIGlmICghaGFzQ3VzdG9tUGFyc2VyKSB7XG4gICAgICBlcnJvcnMucHVzaCgnQXQgbGVhc3Qgb25lIHN0ZXAgbXVzdCB1c2UgY3VzdG9tIHBhcnNlcicpO1xuICAgIH1cblxuICAgIHJldHVybiBlcnJvcnM7XG4gIH07XG59XG4iXX0=