"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptInferenceConfiguration = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
/**
 * Abstract base class for prompt inference configurations.
 *
 * This provides a high-level abstraction over the underlying CloudFormation
 * inference configuration properties, offering a more developer-friendly interface
 * while maintaining full compatibility with the underlying AWS Bedrock service.
 */
class PromptInferenceConfiguration {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.PromptInferenceConfiguration", version: "2.263.0-alpha.0" };
    /**
     * Creates a text inference configuration.
     */
    static text(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_PromptInferenceConfigurationProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.text);
            }
            throw error;
        }
        return new TextInferenceConfiguration(props);
    }
}
exports.PromptInferenceConfiguration = PromptInferenceConfiguration;
/**
 * Text inference configuration for prompts.
 */
class TextInferenceConfiguration extends PromptInferenceConfiguration {
    props;
    constructor(props) {
        super();
        this.props = props;
        // Validate maxTokens if provided
        if (props.maxTokens !== undefined && props.maxTokens <= 0) {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `MaxTokensNotPositive`, 'maxTokens must be a positive number');
        }
        // Validate temperature range if provided
        if (props.temperature !== undefined && (props.temperature < 0.0 || props.temperature > 1.0)) {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `TemperatureOutOfRange`, 'temperature must be between 0.0 and 1.0');
        }
        // Validate topP range if provided
        if (props.topP !== undefined && (props.topP < 0.0 || props.topP > 1.0)) {
            throw new errors_1.UnscopedValidationError((0, helpers_internal_1.lit) `TopPOutOfRange`, 'topP must be between 0.0 and 1.0');
        }
    }
    _render() {
        return {
            text: {
                maxTokens: this.props.maxTokens,
                stopSequences: this.props.stopSequences,
                temperature: this.props.temperature,
                topP: this.props.topP,
            },
        };
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvbXB0LWluZmVyZW5jZS1jb25maWd1cmF0aW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicHJvbXB0LWluZmVyZW5jZS1jb25maWd1cmF0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQ0Esd0RBQXNFO0FBQ3RFLDRFQUE0RDtBQXNDNUQ7Ozs7OztHQU1HO0FBQ0gsTUFBc0IsNEJBQTRCOztJQUNoRDs7T0FFRztJQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBd0M7Ozs7Ozs7Ozs7UUFDekQsT0FBTyxJQUFJLDBCQUEwQixDQUFDLEtBQUssQ0FBQyxDQUFDO0tBQzlDOztBQU5ILG9FQWFDO0FBRUQ7O0dBRUc7QUFDSCxNQUFNLDBCQUEyQixTQUFRLDRCQUE0QjtJQUN0QztJQUE3QixZQUE2QixLQUF3QztRQUNuRSxLQUFLLEVBQUUsQ0FBQztRQURtQixVQUFLLEdBQUwsS0FBSyxDQUFtQztRQUduRSxpQ0FBaUM7UUFDakMsSUFBSSxLQUFLLENBQUMsU0FBUyxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsU0FBUyxJQUFJLENBQUMsRUFBRSxDQUFDO1lBQzFELE1BQU0sSUFBSSxnQ0FBdUIsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsc0JBQXNCLEVBQUUscUNBQXFDLENBQUMsQ0FBQztRQUN0RyxDQUFDO1FBRUQseUNBQXlDO1FBQ3pDLElBQUksS0FBSyxDQUFDLFdBQVcsS0FBSyxTQUFTLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsSUFBSSxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDNUYsTUFBTSxJQUFJLGdDQUF1QixDQUFDLElBQUEsc0JBQUcsRUFBQSx1QkFBdUIsRUFBRSx5Q0FBeUMsQ0FBQyxDQUFDO1FBQzNHLENBQUM7UUFFRCxrQ0FBa0M7UUFDbEMsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLFNBQVMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsR0FBRyxJQUFJLEtBQUssQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUN2RSxNQUFNLElBQUksZ0NBQXVCLENBQUMsSUFBQSxzQkFBRyxFQUFBLGdCQUFnQixFQUFFLGtDQUFrQyxDQUFDLENBQUM7UUFDN0YsQ0FBQztLQUNGO0lBRU0sT0FBTztRQUNaLE9BQU87WUFDTCxJQUFJLEVBQUU7Z0JBQ0osU0FBUyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUztnQkFDL0IsYUFBYSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYTtnQkFDdkMsV0FBVyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVztnQkFDbkMsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSTthQUN0QjtTQUNGLENBQUM7S0FDSDtDQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgKiBhcyBiZWRyb2NrIGZyb20gJ2F3cy1jZGstbGliL2F3cy1iZWRyb2NrJztcbmltcG9ydCB7IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvZXJyb3JzJztcbmltcG9ydCB7IGxpdCB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2hlbHBlcnMtaW50ZXJuYWwnO1xuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNyZWF0aW5nIGEgcHJvbXB0IGluZmVyZW5jZSBjb25maWd1cmF0aW9uLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFByb21wdEluZmVyZW5jZUNvbmZpZ3VyYXRpb25Qcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgbWF4aW11bSBudW1iZXIgb2YgdG9rZW5zIHRvIHJldHVybiBpbiB0aGUgcmVzcG9uc2UuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTm8gbGltaXQgc3BlY2lmaWVkXG4gICAqL1xuICByZWFkb25seSBtYXhUb2tlbnM/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIEEgbGlzdCBvZiBzdHJpbmdzIHRoYXQgZGVmaW5lIHNlcXVlbmNlcyBhZnRlciB3aGljaCB0aGUgbW9kZWwgd2lsbCBzdG9wIGdlbmVyYXRpbmcuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTm8gc3RvcCBzZXF1ZW5jZXNcbiAgICovXG4gIHJlYWRvbmx5IHN0b3BTZXF1ZW5jZXM/OiBzdHJpbmdbXTtcblxuICAvKipcbiAgICogQ29udHJvbHMgdGhlIHJhbmRvbW5lc3Mgb2YgdGhlIHJlc3BvbnNlLlxuICAgKiBIaWdoZXIgdmFsdWVzIG1ha2Ugb3V0cHV0IG1vcmUgcmFuZG9tLCBsb3dlciB2YWx1ZXMgbW9yZSBkZXRlcm1pbmlzdGljLlxuICAgKiBWYWxpZCByYW5nZSBpcyAwLjAgdG8gMS4wLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIE1vZGVsIGRlZmF1bHQgdGVtcGVyYXR1cmVcbiAgICovXG4gIHJlYWRvbmx5IHRlbXBlcmF0dXJlPzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBUaGUgcGVyY2VudGFnZSBvZiBtb3N0LWxpa2VseSBjYW5kaWRhdGVzIHRoYXQgdGhlIG1vZGVsIGNvbnNpZGVycyBmb3IgdGhlIG5leHQgdG9rZW4uXG4gICAqIFZhbGlkIHJhbmdlIGlzIDAuMCB0byAxLjAuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTW9kZWwgZGVmYXVsdCB0b3BQXG4gICAqL1xuICByZWFkb25seSB0b3BQPzogbnVtYmVyO1xufVxuXG4vKipcbiAqIEFic3RyYWN0IGJhc2UgY2xhc3MgZm9yIHByb21wdCBpbmZlcmVuY2UgY29uZmlndXJhdGlvbnMuXG4gKlxuICogVGhpcyBwcm92aWRlcyBhIGhpZ2gtbGV2ZWwgYWJzdHJhY3Rpb24gb3ZlciB0aGUgdW5kZXJseWluZyBDbG91ZEZvcm1hdGlvblxuICogaW5mZXJlbmNlIGNvbmZpZ3VyYXRpb24gcHJvcGVydGllcywgb2ZmZXJpbmcgYSBtb3JlIGRldmVsb3Blci1mcmllbmRseSBpbnRlcmZhY2VcbiAqIHdoaWxlIG1haW50YWluaW5nIGZ1bGwgY29tcGF0aWJpbGl0eSB3aXRoIHRoZSB1bmRlcmx5aW5nIEFXUyBCZWRyb2NrIHNlcnZpY2UuXG4gKi9cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBQcm9tcHRJbmZlcmVuY2VDb25maWd1cmF0aW9uIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSB0ZXh0IGluZmVyZW5jZSBjb25maWd1cmF0aW9uLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyB0ZXh0KHByb3BzOiBQcm9tcHRJbmZlcmVuY2VDb25maWd1cmF0aW9uUHJvcHMpOiBQcm9tcHRJbmZlcmVuY2VDb25maWd1cmF0aW9uIHtcbiAgICByZXR1cm4gbmV3IFRleHRJbmZlcmVuY2VDb25maWd1cmF0aW9uKHByb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSBpbmZlcmVuY2UgY29uZmlndXJhdGlvbiBhcyBhIENsb3VkRm9ybWF0aW9uIHByb3BlcnR5LlxuICAgKiBAaW50ZXJuYWwgVGhpcyBpcyBhbiBpbnRlcm5hbCBjb3JlIGZ1bmN0aW9uIGFuZCBzaG91bGQgbm90IGJlIGNhbGxlZCBkaXJlY3RseS5cbiAgICovXG4gIHB1YmxpYyBhYnN0cmFjdCBfcmVuZGVyKCk6IGJlZHJvY2suQ2ZuUHJvbXB0LlByb21wdEluZmVyZW5jZUNvbmZpZ3VyYXRpb25Qcm9wZXJ0eTtcbn1cblxuLyoqXG4gKiBUZXh0IGluZmVyZW5jZSBjb25maWd1cmF0aW9uIGZvciBwcm9tcHRzLlxuICovXG5jbGFzcyBUZXh0SW5mZXJlbmNlQ29uZmlndXJhdGlvbiBleHRlbmRzIFByb21wdEluZmVyZW5jZUNvbmZpZ3VyYXRpb24ge1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJlYWRvbmx5IHByb3BzOiBQcm9tcHRJbmZlcmVuY2VDb25maWd1cmF0aW9uUHJvcHMpIHtcbiAgICBzdXBlcigpO1xuXG4gICAgLy8gVmFsaWRhdGUgbWF4VG9rZW5zIGlmIHByb3ZpZGVkXG4gICAgaWYgKHByb3BzLm1heFRva2VucyAhPT0gdW5kZWZpbmVkICYmIHByb3BzLm1heFRva2VucyA8PSAwKSB7XG4gICAgICB0aHJvdyBuZXcgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IobGl0YE1heFRva2Vuc05vdFBvc2l0aXZlYCwgJ21heFRva2VucyBtdXN0IGJlIGEgcG9zaXRpdmUgbnVtYmVyJyk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgdGVtcGVyYXR1cmUgcmFuZ2UgaWYgcHJvdmlkZWRcbiAgICBpZiAocHJvcHMudGVtcGVyYXR1cmUgIT09IHVuZGVmaW5lZCAmJiAocHJvcHMudGVtcGVyYXR1cmUgPCAwLjAgfHwgcHJvcHMudGVtcGVyYXR1cmUgPiAxLjApKSB7XG4gICAgICB0aHJvdyBuZXcgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IobGl0YFRlbXBlcmF0dXJlT3V0T2ZSYW5nZWAsICd0ZW1wZXJhdHVyZSBtdXN0IGJlIGJldHdlZW4gMC4wIGFuZCAxLjAnKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSB0b3BQIHJhbmdlIGlmIHByb3ZpZGVkXG4gICAgaWYgKHByb3BzLnRvcFAgIT09IHVuZGVmaW5lZCAmJiAocHJvcHMudG9wUCA8IDAuMCB8fCBwcm9wcy50b3BQID4gMS4wKSkge1xuICAgICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKGxpdGBUb3BQT3V0T2ZSYW5nZWAsICd0b3BQIG11c3QgYmUgYmV0d2VlbiAwLjAgYW5kIDEuMCcpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBfcmVuZGVyKCk6IGJlZHJvY2suQ2ZuUHJvbXB0LlByb21wdEluZmVyZW5jZUNvbmZpZ3VyYXRpb25Qcm9wZXJ0eSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHRleHQ6IHtcbiAgICAgICAgbWF4VG9rZW5zOiB0aGlzLnByb3BzLm1heFRva2VucyxcbiAgICAgICAgc3RvcFNlcXVlbmNlczogdGhpcy5wcm9wcy5zdG9wU2VxdWVuY2VzLFxuICAgICAgICB0ZW1wZXJhdHVyZTogdGhpcy5wcm9wcy50ZW1wZXJhdHVyZSxcbiAgICAgICAgdG9wUDogdGhpcy5wcm9wcy50b3BQLFxuICAgICAgfSxcbiAgICB9O1xuICB9XG59XG4iXX0=