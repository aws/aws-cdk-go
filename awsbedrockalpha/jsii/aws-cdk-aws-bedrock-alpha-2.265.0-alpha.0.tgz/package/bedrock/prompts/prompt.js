"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Prompt = exports.PromptBase = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const bedrock = __importStar(require("aws-cdk-lib/aws-bedrock"));
const iam = __importStar(require("aws-cdk-lib/aws-iam"));
const core_1 = require("aws-cdk-lib/core");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
const prompt_version_1 = require("./prompt-version");
const validation = __importStar(require("../agents/validation-helpers"));
/******************************************************************************
 *                        ABSTRACT BASE CLASS
 *****************************************************************************/
/**
 * Abstract base class for a Prompt.
 * Contains methods and attributes valid for Prompts either created with CDK or imported.
 */
class PromptBase extends core_1.Resource {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.PromptBase", version: "2.265.0-alpha.0" };
    /**
     * Grant the given identity permissions to get the prompt.
     * [disable-awslint:no-grants]
     *
     * @param grantee - The IAM principal to grant permissions to
     * @default - Default grant configuration:
     * - actions: ['bedrock:GetPrompt']
     * - resourceArns: [this.promptArn]
     * @returns An IAM Grant object representing the granted permissions
     */
    grantGet(grantee) {
        return iam.Grant.addToPrincipal({
            grantee,
            resourceArns: [this.promptArn],
            actions: ['bedrock:GetPrompt'],
        });
    }
}
exports.PromptBase = PromptBase;
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create (or import) a Prompt with CDK.
 *
 * Prompts are a specific set of inputs that guide Foundation Models (FMs) on Amazon Bedrock to
 * generate an appropriate response or output for a given task or instruction.
 * You can optimize the prompt for specific use cases and models.
 *
 * @cloudformationResource AWS::Bedrock::Prompt
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/prompt-management.html
 */
let Prompt = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = PromptBase;
    let _instanceExtraInitializers = [];
    let _createVersion_decorators;
    let _addVariant_decorators;
    var Prompt = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _createVersion_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addVariant_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            __esDecorate(this, null, _createVersion_decorators, { kind: "method", name: "createVersion", static: false, private: false, access: { has: obj => "createVersion" in obj, get: obj => obj.createVersion }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addVariant_decorators, { kind: "method", name: "addVariant", static: false, private: false, access: { has: obj => "addVariant" in obj, get: obj => obj.addVariant }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            Prompt = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.Prompt", version: "2.265.0-alpha.0" };
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.Prompt';
        /******************************************************************************
         *                            IMPORT METHODS
         *****************************************************************************/
        /**
         * Creates a Prompt reference from an existing prompt's attributes.
         *
         * @param scope - The construct scope
         * @param id - Identifier of the construct
         * @param attrs - Attributes of the existing prompt
         * @default - For attrs.promptVersion: 'DRAFT' if no explicit version is provided
         * @returns An IPrompt reference to the existing prompt
         */
        static fromPromptAttributes(scope, id, attrs) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_PromptAttributes(attrs);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.fromPromptAttributes);
                }
                throw error;
            }
            const formattedArn = core_1.Arn.split(attrs.promptArn, core_1.ArnFormat.SLASH_RESOURCE_NAME);
            class Import extends PromptBase {
                promptArn = attrs.promptArn;
                promptId = formattedArn.resourceName;
                promptVersion = attrs.promptVersion ?? 'DRAFT';
                kmsKey = attrs.kmsKey;
            }
            return new Import(scope, id);
        }
        /**
         * The maximum number of variants allowed for a prompt.
         * @internal
         */
        static MAX_VARIANTS = 1;
        /**
         * The name of the prompt.
         * @attribute
         */
        promptName = __runInitializers(this, _instanceExtraInitializers);
        /**
         * The KMS key that the prompt is encrypted with.
         */
        kmsKey;
        /**
         * The ARN of the prompt.
         * @attribute
         * @example "arn:aws:bedrock:us-east-1:123456789012:prompt/PROMPT12345"
         */
        promptArn;
        /**
         * The ID of the prompt.
         * @attribute
         * @example "PROMPT12345"
         */
        promptId;
        /**
         * The version of the prompt.
         * @attribute
         */
        promptVersion;
        /**
         * The variants of the prompt.
         */
        variants;
        /**
         * The description of the prompt.
         */
        description;
        /******************************************************************************
         *                            INTERNAL ONLY
         *****************************************************************************/
        /**
         * The computed hash of the prompt properties.
         * @internal
         */
        _hash;
        /**
         * L1 resource
         * @internal
         */
        __resource;
        /******************************************************************************
         *                            CONSTRUCTOR
         *****************************************************************************/
        constructor(scope, id, props) {
            super(scope, id);
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_PromptProps(props);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, Prompt);
                }
                throw error;
            }
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            // ------------------------------------------------------
            // Set properties and defaults
            // ------------------------------------------------------
            this.promptName = props.promptName;
            this.description = props.description;
            this.kmsKey = props.kmsKey;
            this.variants = props.variants ?? [];
            // ------------------------------------------------------
            // Validation
            // ------------------------------------------------------
            this.validatePromptDefault(props);
            this.node.addValidation({ validate: () => this.validatePromptName() });
            this.node.addValidation({ validate: () => this.validatePromptVariants() });
            this.node.addValidation({ validate: () => this.validateDescription() });
            this.node.addValidation({ validate: () => this.validateVariantNames() });
            // ------------------------------------------------------
            // CFN Props - With Lazy support
            // ------------------------------------------------------
            const cfnProps = {
                customerEncryptionKeyArn: this.kmsKey?.keyArn,
                defaultVariant: props.defaultVariant?.name,
                description: props.description,
                name: props.promptName,
                variants: core_1.Lazy.any({
                    produce: () => this.variants.map(variant => {
                        const variantConfig = {
                            name: variant.name,
                            templateType: variant.templateType,
                            templateConfiguration: variant.templateConfiguration._render(),
                        };
                        if (variant.modelId) {
                            variantConfig.modelId = variant.modelId;
                        }
                        if (variant.inferenceConfiguration) {
                            variantConfig.inferenceConfiguration = variant.inferenceConfiguration._render();
                        }
                        if (variant.genAiResource) {
                            variantConfig.genAiResource = variant.genAiResource._render();
                        }
                        return variantConfig;
                    }),
                }),
                tags: props.tags,
            };
            // Hash calculation useful for versioning
            this._hash = (0, helpers_internal_1.md5hash)(JSON.stringify(cfnProps));
            // ------------------------------------------------------
            // L1 Instantiation
            // ------------------------------------------------------
            this.__resource = new bedrock.CfnPrompt(this, 'Resource', cfnProps);
            this.promptArn = this.__resource.attrArn;
            this.promptId = this.__resource.attrId;
            this.promptVersion = this.__resource.attrVersion;
        }
        /******************************************************************************
         *                            VALIDATION METHODS
         *****************************************************************************/
        /**
         * Validates whether the prompt name is valid according to the specification.
         * @see https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-prompt.html#cfn-bedrock-prompt-name
         * @returns Array of validation error messages, empty if valid
         */
        validatePromptName() {
            const errors = [];
            // Use existing validation helper for pattern validation
            const patternErrors = validation.validateFieldPattern(this.promptName, 'promptName', /^([0-9a-zA-Z][_-]?){1,100}$/, 'Valid characters are a-z, A-Z, 0-9, _ (underscore) and - (hyphen). Must not begin with a hyphen and must be 1-100 characters long.');
            errors.push(...patternErrors);
            return errors;
        }
        /**
         * Validates whether the number of prompt variants is respected.
         * @returns Array of validation error messages, empty if valid
         */
        validatePromptVariants() {
            const errors = [];
            if (this.variants.length > Prompt.MAX_VARIANTS) {
                errors.push(`Too many variants specified. The maximum allowed is ${Prompt.MAX_VARIANTS}, but you have provided ${this.variants.length} variants.`);
            }
            return errors;
        }
        /**
         * Validates that if the prompt has a default, it was also added to the variants array
         * @param props - The properties set in the constructor
         */
        validatePromptDefault(props) {
            if (props.defaultVariant && !props.variants?.includes(props.defaultVariant)) {
                throw new core_1.ValidationError((0, helpers_internal_1.lit) `DefaultVariantMissing`, 'The \'defaultVariant\' needs to be included in the \'variants\' array.', this);
            }
        }
        /**
         * Validates whether the description length is within the allowed limit.
         * @returns Array of validation error messages, empty if valid
         */
        validateDescription() {
            const errors = [];
            if (this.description && this.description.length > 200) {
                errors.push(`Description must be 200 characters or less, got ${this.description.length} characters.`);
            }
            return errors;
        }
        /**
         * Validates whether all variant names are unique.
         * @returns Array of validation error messages, empty if valid
         */
        validateVariantNames() {
            const errors = [];
            const names = this.variants.map(v => v.name);
            const duplicates = names.filter((name, index) => names.indexOf(name) !== index);
            if (duplicates.length > 0) {
                const uniqueDuplicates = [...new Set(duplicates)];
                errors.push(`Duplicate variant names found: ${uniqueDuplicates.join(', ')}. Each variant must have a unique name.`);
            }
            return errors;
        }
        /******************************************************************************
         *                            HELPER METHODS
         *****************************************************************************/
        /**
         * Creates a prompt version, a static snapshot of your prompt that can be
         * deployed to production.
         *
         * @param description - Optional description for the version
         * @default - No description provided
         * @returns A PromptVersion object containing the version details including ARN and version string
         */
        createVersion(description) {
            return new prompt_version_1.PromptVersion(this, `PromptVersion-${this._hash}`, {
                prompt: this,
                description,
            });
        }
        /**
         * Adds a prompt variant to the prompt.
         *
         * @param variant - The prompt variant to add
         * @throws ValidationError if adding the variant would exceed the maximum allowed variants
         */
        addVariant(variant) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_IPromptVariant(variant);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addVariant);
                }
                throw error;
            }
            validation.throwIfInvalid(this.validateVariantAddition, variant);
            this.variants.push(variant);
        }
        /**
         * Validates whether a variant can be added without exceeding limits.
         * @param variant - The variant to validate
         * @returns Array of validation error messages, empty if valid
         */
        validateVariantAddition = (variant) => {
            const errors = [];
            // Check if adding this variant would exceed the maximum
            if (this.variants.length >= Prompt.MAX_VARIANTS) {
                errors.push(`Cannot add variant to prompt '${this.promptName}'. Maximum of ${Prompt.MAX_VARIANTS} variants allowed, currently have ${this.variants.length}.`);
            }
            // Check for duplicate variant names
            if (this.variants.find(v => v.name === variant.name)) {
                errors.push(`Variant with name '${variant.name}' already exists.`);
            }
            return errors;
        };
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return Prompt = _classThis;
})();
exports.Prompt = Prompt;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvbXB0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicHJvbXB0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGlFQUFtRDtBQUNuRCx5REFBMkM7QUFHM0MsMkNBQW1GO0FBQ25GLDRFQUFxRTtBQUNyRSw4RUFBOEY7QUFDOUYsMEVBQTBFO0FBSzFFLHFEQUFpRDtBQUNqRCx5RUFBMkQ7QUF5QzNEOzsrRUFFK0U7QUFDL0U7OztHQUdHO0FBQ0gsTUFBc0IsVUFBVyxTQUFRLGVBQVE7O0lBTS9DOzs7Ozs7Ozs7T0FTRztJQUNJLFFBQVEsQ0FBQyxPQUF1QjtRQUNyQyxPQUFPLEdBQUcsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDO1lBQzlCLE9BQU87WUFDUCxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQzlCLE9BQU8sRUFBRSxDQUFDLG1CQUFtQixDQUFDO1NBQy9CLENBQUMsQ0FBQztLQUNKOztBQXRCSCxnQ0F1QkM7QUFrRkQ7OytFQUUrRTtBQUMvRTs7Ozs7Ozs7O0dBU0c7SUFFVSxNQUFNOzRCQURsQixvQ0FBa0I7Ozs7c0JBQ1MsVUFBVTs7OztzQkFBbEIsU0FBUSxXQUFVOzs7O3lDQWtRbkMsSUFBQSxrQ0FBYyxHQUFFO3NDQWNoQixJQUFBLGtDQUFjLEdBQUU7WUFiakIsMExBQU8sYUFBYSw2REFLbkI7WUFTRCxpTEFBTyxVQUFVLDZEQUdoQjtZQXBSSCw2S0E0U0M7Ozs7O1FBM1NDLHNDQUFzQztRQUMvQixNQUFNLENBQVUscUJBQXFCLEdBQVcsbUNBQW1DLENBQUM7UUFFM0Y7O3VGQUUrRTtRQUMvRTs7Ozs7Ozs7V0FRRztRQUNJLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxLQUFnQixFQUFFLEVBQVUsRUFBRSxLQUF1Qjs7Ozs7Ozs7OztZQUN0RixNQUFNLFlBQVksR0FBRyxVQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsZ0JBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBRS9FLE1BQU0sTUFBTyxTQUFRLFVBQVU7Z0JBQ2IsU0FBUyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7Z0JBQzVCLFFBQVEsR0FBRyxZQUFZLENBQUMsWUFBYSxDQUFDO2dCQUN0QyxhQUFhLEdBQUcsS0FBSyxDQUFDLGFBQWEsSUFBSSxPQUFPLENBQUM7Z0JBQy9DLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO2FBQ3ZDO1lBRUQsT0FBTyxJQUFJLE1BQU0sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDOUI7UUFFRDs7O1dBR0c7UUFDSyxNQUFNLENBQVUsWUFBWSxHQUFHLENBQUMsQ0FBQztRQUV6Qzs7O1dBR0c7UUFDYSxVQUFVLEdBdkNmLG1EQUFNLENBdUNrQjtRQUVuQzs7V0FFRztRQUNhLE1BQU0sQ0FBWTtRQUVsQzs7OztXQUlHO1FBQ2EsU0FBUyxDQUFTO1FBRWxDOzs7O1dBSUc7UUFDYSxRQUFRLENBQVM7UUFFakM7OztXQUdHO1FBQ2EsYUFBYSxDQUFTO1FBRXRDOztXQUVHO1FBQ2EsUUFBUSxDQUFtQjtRQUUzQzs7V0FFRztRQUNhLFdBQVcsQ0FBVTtRQUVyQzs7dUZBRStFO1FBQy9FOzs7V0FHRztRQUNnQixLQUFLLENBQVM7UUFFakM7OztXQUdHO1FBQ2MsVUFBVSxDQUFvQjtRQUUvQzs7dUZBRStFO1FBQy9FLFlBQVksS0FBZ0IsRUFBRSxFQUFVLEVBQUUsS0FBa0I7WUFDMUQsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQzs7Ozs7O21EQS9GUixNQUFNOzs7O1lBZ0dmLG1DQUFtQztZQUNuQyxJQUFBLHdDQUFvQixFQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztZQUVsQyx5REFBeUQ7WUFDekQsOEJBQThCO1lBQzlCLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQyxVQUFVLENBQUM7WUFDbkMsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDO1lBQ3JDLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQztZQUMzQixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLElBQUksRUFBRSxDQUFDO1lBRXJDLHlEQUF5RDtZQUN6RCxhQUFhO1lBQ2IseURBQXlEO1lBQ3pELElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLFFBQVEsRUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDdkUsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxRQUFRLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLHNCQUFzQixFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQzNFLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsUUFBUSxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUN4RSxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLFFBQVEsRUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFFekUseURBQXlEO1lBQ3pELGdDQUFnQztZQUNoQyx5REFBeUQ7WUFDekQsTUFBTSxRQUFRLEdBQTJCO2dCQUN2Qyx3QkFBd0IsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLE1BQU07Z0JBQzdDLGNBQWMsRUFBRSxLQUFLLENBQUMsY0FBYyxFQUFFLElBQUk7Z0JBQzFDLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztnQkFDOUIsSUFBSSxFQUFFLEtBQUssQ0FBQyxVQUFVO2dCQUN0QixRQUFRLEVBQUUsV0FBSSxDQUFDLEdBQUcsQ0FBQztvQkFDakIsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFO3dCQUN6QyxNQUFNLGFBQWEsR0FBUTs0QkFDekIsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJOzRCQUNsQixZQUFZLEVBQUUsT0FBTyxDQUFDLFlBQVk7NEJBQ2xDLHFCQUFxQixFQUFFLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxPQUFPLEVBQUU7eUJBQy9ELENBQUM7d0JBRUYsSUFBSSxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7NEJBQ3BCLGFBQWEsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQzt3QkFDMUMsQ0FBQzt3QkFFRCxJQUFJLE9BQU8sQ0FBQyxzQkFBc0IsRUFBRSxDQUFDOzRCQUNuQyxhQUFhLENBQUMsc0JBQXNCLEdBQUcsT0FBTyxDQUFDLHNCQUFzQixDQUFDLE9BQU8sRUFBRSxDQUFDO3dCQUNsRixDQUFDO3dCQUVELElBQUksT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDOzRCQUMxQixhQUFhLENBQUMsYUFBYSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUM7d0JBQ2hFLENBQUM7d0JBRUQsT0FBTyxhQUFhLENBQUM7b0JBQ3ZCLENBQUMsQ0FBQztpQkFDSCxDQUFDO2dCQUNGLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTthQUNqQixDQUFDO1lBRUYseUNBQXlDO1lBQ3pDLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBQSwwQkFBTyxFQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUUvQyx5REFBeUQ7WUFDekQsbUJBQW1CO1lBQ25CLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBRXBFLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7WUFDekMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQztZQUN2QyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDO1NBQ2xEO1FBRUQ7O3VGQUUrRTtRQUMvRTs7OztXQUlHO1FBQ0ssa0JBQWtCO1lBQ3hCLE1BQU0sTUFBTSxHQUFhLEVBQUUsQ0FBQztZQUU1Qix3REFBd0Q7WUFDeEQsTUFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLG9CQUFvQixDQUNuRCxJQUFJLENBQUMsVUFBVSxFQUNmLFlBQVksRUFDWiw2QkFBNkIsRUFDN0Isb0lBQW9JLENBQ3JJLENBQUM7WUFFRixNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsYUFBYSxDQUFDLENBQUM7WUFDOUIsT0FBTyxNQUFNLENBQUM7U0FDZjtRQUVEOzs7V0FHRztRQUNLLHNCQUFzQjtZQUM1QixNQUFNLE1BQU0sR0FBYSxFQUFFLENBQUM7WUFFNUIsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQy9DLE1BQU0sQ0FBQyxJQUFJLENBQ1QsdURBQXVELE1BQU0sQ0FBQyxZQUFZLDJCQUEyQixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sWUFBWSxDQUN0SSxDQUFDO1lBQ0osQ0FBQztZQUVELE9BQU8sTUFBTSxDQUFDO1NBQ2Y7UUFFRDs7O1dBR0c7UUFDSyxxQkFBcUIsQ0FBQyxLQUFrQjtZQUM5QyxJQUFJLEtBQUssQ0FBQyxjQUFjLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQztnQkFDNUUsTUFBTSxJQUFJLHNCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHVCQUF1QixFQUFFLHdFQUF3RSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3hJLENBQUM7U0FDRjtRQUVEOzs7V0FHRztRQUNLLG1CQUFtQjtZQUN6QixNQUFNLE1BQU0sR0FBYSxFQUFFLENBQUM7WUFFNUIsSUFBSSxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDO2dCQUN0RCxNQUFNLENBQUMsSUFBSSxDQUNULG1EQUFtRCxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sY0FBYyxDQUN6RixDQUFDO1lBQ0osQ0FBQztZQUVELE9BQU8sTUFBTSxDQUFDO1NBQ2Y7UUFFRDs7O1dBR0c7UUFDSyxvQkFBb0I7WUFDMUIsTUFBTSxNQUFNLEdBQWEsRUFBRSxDQUFDO1lBQzVCLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzdDLE1BQU0sVUFBVSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDO1lBRWhGLElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDMUIsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztnQkFDbEQsTUFBTSxDQUFDLElBQUksQ0FDVCxrQ0FBa0MsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyx5Q0FBeUMsQ0FDdkcsQ0FBQztZQUNKLENBQUM7WUFFRCxPQUFPLE1BQU0sQ0FBQztTQUNmO1FBRUQ7O3VGQUUrRTtRQUMvRTs7Ozs7OztXQU9HO1FBRUksYUFBYSxDQUFDLFdBQW9CO1lBQ3ZDLE9BQU8sSUFBSSw4QkFBYSxDQUFDLElBQUksRUFBRSxpQkFBaUIsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFFO2dCQUM1RCxNQUFNLEVBQUUsSUFBSTtnQkFDWixXQUFXO2FBQ1osQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7Ozs7V0FLRztRQUVJLFVBQVUsQ0FBQyxPQUF1Qjs7Ozs7Ozs7OztZQUN2QyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUNqRSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUM3QjtRQUVEOzs7O1dBSUc7UUFDSyx1QkFBdUIsR0FBRyxDQUFDLE9BQXVCLEVBQVksRUFBRTtZQUN0RSxNQUFNLE1BQU0sR0FBYSxFQUFFLENBQUM7WUFFNUIsd0RBQXdEO1lBQ3hELElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUNoRCxNQUFNLENBQUMsSUFBSSxDQUNULGlDQUFpQyxJQUFJLENBQUMsVUFBVSxpQkFBaUIsTUFBTSxDQUFDLFlBQVkscUNBQXFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQ2pKLENBQUM7WUFDSixDQUFDO1lBRUQsb0NBQW9DO1lBQ3BDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO2dCQUNyRCxNQUFNLENBQUMsSUFBSSxDQUFDLHNCQUFzQixPQUFPLENBQUMsSUFBSSxtQkFBbUIsQ0FBQyxDQUFDO1lBQ3JFLENBQUM7WUFFRCxPQUFPLE1BQU0sQ0FBQztRQUNoQixDQUFDLENBQUM7O1lBM1NTLHVEQUFNOzs7OztBQUFOLHdCQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgYmVkcm9jayBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgKiBhcyBpYW0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWlhbSc7XG5pbXBvcnQgdHlwZSAqIGFzIGttcyBmcm9tICdhd3MtY2RrLWxpYi9hd3Mta21zJztcbmltcG9ydCB0eXBlIHsgSVJlc291cmNlIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZSc7XG5pbXBvcnQgeyBBcm4sIEFybkZvcm1hdCwgTGF6eSwgUmVzb3VyY2UsIFZhbGlkYXRpb25FcnJvciB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUnO1xuaW1wb3J0IHsgbWQ1aGFzaCwgbGl0IH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvaGVscGVycy1pbnRlcm5hbCc7XG5pbXBvcnQgeyBhZGRDb25zdHJ1Y3RNZXRhZGF0YSwgTWV0aG9kTWV0YWRhdGEgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9tZXRhZGF0YS1yZXNvdXJjZSc7XG5pbXBvcnQgeyBwcm9wZXJ0eUluamVjdGFibGUgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9wcm9wLWluamVjdGFibGUnO1xuaW1wb3J0IHR5cGUgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcblxuLy8gSW50ZXJuYWwgTGlic1xuaW1wb3J0IHR5cGUgeyBJUHJvbXB0VmFyaWFudCB9IGZyb20gJy4vcHJvbXB0LXZhcmlhbnQnO1xuaW1wb3J0IHsgUHJvbXB0VmVyc2lvbiB9IGZyb20gJy4vcHJvbXB0LXZlcnNpb24nO1xuaW1wb3J0ICogYXMgdmFsaWRhdGlvbiBmcm9tICcuLi9hZ2VudHMvdmFsaWRhdGlvbi1oZWxwZXJzJztcblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDT01NT05cbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogUmVwcmVzZW50cyBhIFByb21wdCwgZWl0aGVyIGNyZWF0ZWQgd2l0aCBDREsgb3IgaW1wb3J0ZWQuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSVByb21wdCBleHRlbmRzIElSZXNvdXJjZSB7XG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBwcm9tcHQuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICogQGV4YW1wbGUgXCJhcm46YXdzOmJlZHJvY2s6dXMtZWFzdC0xOjEyMzQ1Njc4OTAxMjpwcm9tcHQvUFJPTVBUMTIzNDVcIlxuICAgKi9cbiAgcmVhZG9ubHkgcHJvbXB0QXJuOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBJRCBvZiB0aGUgcHJvbXB0LlxuICAgKiBAYXR0cmlidXRlXG4gICAqIEBleGFtcGxlIFwiUFJPTVBUMTIzNDVcIlxuICAgKi9cbiAgcmVhZG9ubHkgcHJvbXB0SWQ6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHZlcnNpb24gb2YgdGhlIHByb21wdC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKiBAZGVmYXVsdCBcIkRSQUZUXCJcbiAgICovXG4gIHJlYWRvbmx5IHByb21wdFZlcnNpb246IHN0cmluZztcblxuICAvKipcbiAgICogT3B0aW9uYWwgS01TIGVuY3J5cHRpb24ga2V5IGFzc29jaWF0ZWQgd2l0aCB0aGlzIHByb21wdC5cbiAgICovXG4gIHJlYWRvbmx5IGttc0tleT86IGttcy5JS2V5O1xuXG4gIC8qKlxuICAgKiBHcmFudCB0aGUgZ2l2ZW4gaWRlbnRpdHkgcGVybWlzc2lvbnMgdG8gZ2V0IHRoZSBwcm9tcHQuXG4gICAqL1xuICBncmFudEdldChncmFudGVlOiBpYW0uSUdyYW50YWJsZSk6IGlhbS5HcmFudDtcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBBQlNUUkFDVCBCQVNFIENMQVNTXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIEFic3RyYWN0IGJhc2UgY2xhc3MgZm9yIGEgUHJvbXB0LlxuICogQ29udGFpbnMgbWV0aG9kcyBhbmQgYXR0cmlidXRlcyB2YWxpZCBmb3IgUHJvbXB0cyBlaXRoZXIgY3JlYXRlZCB3aXRoIENESyBvciBpbXBvcnRlZC5cbiAqL1xuZXhwb3J0IGFic3RyYWN0IGNsYXNzIFByb21wdEJhc2UgZXh0ZW5kcyBSZXNvdXJjZSBpbXBsZW1lbnRzIElQcm9tcHQge1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkgcHJvbXB0QXJuOiBzdHJpbmc7XG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSBwcm9tcHRJZDogc3RyaW5nO1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkga21zS2V5Pzoga21zLklLZXk7XG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSBwcm9tcHRWZXJzaW9uOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEdyYW50IHRoZSBnaXZlbiBpZGVudGl0eSBwZXJtaXNzaW9ucyB0byBnZXQgdGhlIHByb21wdC5cbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqXG4gICAqIEBwYXJhbSBncmFudGVlIC0gVGhlIElBTSBwcmluY2lwYWwgdG8gZ3JhbnQgcGVybWlzc2lvbnMgdG9cbiAgICogQGRlZmF1bHQgLSBEZWZhdWx0IGdyYW50IGNvbmZpZ3VyYXRpb246XG4gICAqIC0gYWN0aW9uczogWydiZWRyb2NrOkdldFByb21wdCddXG4gICAqIC0gcmVzb3VyY2VBcm5zOiBbdGhpcy5wcm9tcHRBcm5dXG4gICAqIEByZXR1cm5zIEFuIElBTSBHcmFudCBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSBncmFudGVkIHBlcm1pc3Npb25zXG4gICAqL1xuICBwdWJsaWMgZ3JhbnRHZXQoZ3JhbnRlZTogaWFtLklHcmFudGFibGUpOiBpYW0uR3JhbnQge1xuICAgIHJldHVybiBpYW0uR3JhbnQuYWRkVG9QcmluY2lwYWwoe1xuICAgICAgZ3JhbnRlZSxcbiAgICAgIHJlc291cmNlQXJuczogW3RoaXMucHJvbXB0QXJuXSxcbiAgICAgIGFjdGlvbnM6IFsnYmVkcm9jazpHZXRQcm9tcHQnXSxcbiAgICB9KTtcbiAgfVxufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIFBST1BTIEZPUiBORVcgQ09OU1RSVUNUXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNyZWF0aW5nIGEgQ0RLIG1hbmFnZWQgQmVkcm9jayBQcm9tcHQuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0UHJvcHMge1xuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIHByb21wdC5cbiAgICogVGhpcyB3aWxsIGJlIHVzZWQgYXMgdGhlIHBoeXNpY2FsIG5hbWUgb2YgdGhlIHByb21wdC5cbiAgICogQWxsb3dlZCBQYXR0ZXJuOiBeKFswLTlhLXpBLVpdW18tXT8pezEsMTAwfSRcbiAgICovXG4gIHJlYWRvbmx5IHByb21wdE5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogQSBkZXNjcmlwdGlvbiBvZiB3aGF0IHRoZSBwcm9tcHQgZG9lcy5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyBkZXNjcmlwdGlvbiBwcm92aWRlZC5cbiAgICogTWF4aW11bSBMZW5ndGg6IDIwMFxuICAgKi9cbiAgcmVhZG9ubHkgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBLTVMga2V5IHRoYXQgdGhlIHByb21wdCBpcyBlbmNyeXB0ZWQgd2l0aC5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBBV1Mgb3duZWQgYW5kIG1hbmFnZWQga2V5LlxuICAgKi9cbiAgcmVhZG9ubHkga21zS2V5Pzoga21zLklLZXk7XG5cbiAgLyoqXG4gICAqIFRoZSBQcm9tcHQgVmFyaWFudCB0aGF0IHdpbGwgYmUgdXNlZCBieSBkZWZhdWx0LlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIE5vIGRlZmF1bHQgdmFyaWFudCBwcm92aWRlZC5cbiAgICovXG4gIHJlYWRvbmx5IGRlZmF1bHRWYXJpYW50PzogSVByb21wdFZhcmlhbnQ7XG5cbiAgLyoqXG4gICAqIFRoZSB2YXJpYW50cyBvZiB5b3VyIHByb21wdC4gVmFyaWFudHMgY2FuIHVzZSBkaWZmZXJlbnQgbWVzc2FnZXMsIG1vZGVscyxcbiAgICogb3IgY29uZmlndXJhdGlvbnMgc28gdGhhdCB5b3UgY2FuIGNvbXBhcmUgdGhlaXIgb3V0cHV0cyB0byBkZWNpZGUgdGhlIGJlc3RcbiAgICogdmFyaWFudCBmb3IgeW91ciB1c2UgY2FzZS4gTWF4aW11bSBvZiAxIHZhcmlhbnRzLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIE5vIGFkZGl0aW9uYWwgdmFyaWFudHMgcHJvdmlkZWQuXG4gICAqL1xuICByZWFkb25seSB2YXJpYW50cz86IElQcm9tcHRWYXJpYW50W107XG5cbiAgLyoqXG4gICAqIFRhZ3MgdG8gYXBwbHkgdG8gdGhlIHByb21wdC5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyB0YWdzIGFwcGxpZWQuXG4gICAqL1xuICByZWFkb25seSB0YWdzPzogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgQVRUUlMgRk9SIElNUE9SVEVEIENPTlNUUlVDVFxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBBdHRyaWJ1dGVzIGZvciBzcGVjaWZ5aW5nIGFuIGltcG9ydGVkIEJlZHJvY2sgUHJvbXB0LlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFByb21wdEF0dHJpYnV0ZXMge1xuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgcHJvbXB0LlxuICAgKiBAYXR0cmlidXRlXG4gICAqIEBleGFtcGxlIFwiYXJuOmF3czpiZWRyb2NrOnVzLWVhc3QtMToxMjM0NTY3ODkwMTI6cHJvbXB0L1BST01QVDEyMzQ1XCJcbiAgICovXG4gIHJlYWRvbmx5IHByb21wdEFybjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBPcHRpb25hbCBLTVMgZW5jcnlwdGlvbiBrZXkgYXNzb2NpYXRlZCB3aXRoIHRoaXMgcHJvbXB0LlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBBbiBBV1MgbWFuYWdlZCBrZXkgaXMgdXNlZFxuICAgKi9cbiAgcmVhZG9ubHkga21zS2V5Pzoga21zLklLZXk7XG5cbiAgLyoqXG4gICAqIFRoZSB2ZXJzaW9uIG9mIHRoZSBwcm9tcHQuXG4gICAqIEBkZWZhdWx0IFwiRFJBRlRcIlxuICAgKi9cbiAgcmVhZG9ubHkgcHJvbXB0VmVyc2lvbj86IHN0cmluZztcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBORVcgQ09OU1RSVUNUIERFRklOSVRJT05cbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogQ2xhc3MgdG8gY3JlYXRlIChvciBpbXBvcnQpIGEgUHJvbXB0IHdpdGggQ0RLLlxuICpcbiAqIFByb21wdHMgYXJlIGEgc3BlY2lmaWMgc2V0IG9mIGlucHV0cyB0aGF0IGd1aWRlIEZvdW5kYXRpb24gTW9kZWxzIChGTXMpIG9uIEFtYXpvbiBCZWRyb2NrIHRvXG4gKiBnZW5lcmF0ZSBhbiBhcHByb3ByaWF0ZSByZXNwb25zZSBvciBvdXRwdXQgZm9yIGEgZ2l2ZW4gdGFzayBvciBpbnN0cnVjdGlvbi5cbiAqIFlvdSBjYW4gb3B0aW1pemUgdGhlIHByb21wdCBmb3Igc3BlY2lmaWMgdXNlIGNhc2VzIGFuZCBtb2RlbHMuXG4gKlxuICogQGNsb3VkZm9ybWF0aW9uUmVzb3VyY2UgQVdTOjpCZWRyb2NrOjpQcm9tcHRcbiAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9wcm9tcHQtbWFuYWdlbWVudC5odG1sXG4gKi9cbkBwcm9wZXJ0eUluamVjdGFibGVcbmV4cG9ydCBjbGFzcyBQcm9tcHQgZXh0ZW5kcyBQcm9tcHRCYXNlIGltcGxlbWVudHMgSVByb21wdCB7XG4gIC8qKiBVbmlxdWVseSBpZGVudGlmaWVzIHRoaXMgY2xhc3MuICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgUFJPUEVSVFlfSU5KRUNUSU9OX0lEOiBzdHJpbmcgPSAnQGF3cy1jZGsuYXdzLWJlZHJvY2stYWxwaGEuUHJvbXB0JztcblxuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgIElNUE9SVCBNRVRIT0RTXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBQcm9tcHQgcmVmZXJlbmNlIGZyb20gYW4gZXhpc3RpbmcgcHJvbXB0J3MgYXR0cmlidXRlcy5cbiAgICpcbiAgICogQHBhcmFtIHNjb3BlIC0gVGhlIGNvbnN0cnVjdCBzY29wZVxuICAgKiBAcGFyYW0gaWQgLSBJZGVudGlmaWVyIG9mIHRoZSBjb25zdHJ1Y3RcbiAgICogQHBhcmFtIGF0dHJzIC0gQXR0cmlidXRlcyBvZiB0aGUgZXhpc3RpbmcgcHJvbXB0XG4gICAqIEBkZWZhdWx0IC0gRm9yIGF0dHJzLnByb21wdFZlcnNpb246ICdEUkFGVCcgaWYgbm8gZXhwbGljaXQgdmVyc2lvbiBpcyBwcm92aWRlZFxuICAgKiBAcmV0dXJucyBBbiBJUHJvbXB0IHJlZmVyZW5jZSB0byB0aGUgZXhpc3RpbmcgcHJvbXB0XG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21Qcm9tcHRBdHRyaWJ1dGVzKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIGF0dHJzOiBQcm9tcHRBdHRyaWJ1dGVzKTogSVByb21wdCB7XG4gICAgY29uc3QgZm9ybWF0dGVkQXJuID0gQXJuLnNwbGl0KGF0dHJzLnByb21wdEFybiwgQXJuRm9ybWF0LlNMQVNIX1JFU09VUkNFX05BTUUpO1xuXG4gICAgY2xhc3MgSW1wb3J0IGV4dGVuZHMgUHJvbXB0QmFzZSB7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgcHJvbXB0QXJuID0gYXR0cnMucHJvbXB0QXJuO1xuICAgICAgcHVibGljIHJlYWRvbmx5IHByb21wdElkID0gZm9ybWF0dGVkQXJuLnJlc291cmNlTmFtZSE7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgcHJvbXB0VmVyc2lvbiA9IGF0dHJzLnByb21wdFZlcnNpb24gPz8gJ0RSQUZUJztcbiAgICAgIHB1YmxpYyByZWFkb25seSBrbXNLZXkgPSBhdHRycy5rbXNLZXk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBJbXBvcnQoc2NvcGUsIGlkKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgbWF4aW11bSBudW1iZXIgb2YgdmFyaWFudHMgYWxsb3dlZCBmb3IgYSBwcm9tcHQuXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgcHJpdmF0ZSBzdGF0aWMgcmVhZG9ubHkgTUFYX1ZBUklBTlRTID0gMTtcblxuICAvKipcbiAgICogVGhlIG5hbWUgb2YgdGhlIHByb21wdC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHByb21wdE5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIEtNUyBrZXkgdGhhdCB0aGUgcHJvbXB0IGlzIGVuY3J5cHRlZCB3aXRoLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGttc0tleT86IGttcy5JS2V5O1xuXG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBwcm9tcHQuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICogQGV4YW1wbGUgXCJhcm46YXdzOmJlZHJvY2s6dXMtZWFzdC0xOjEyMzQ1Njc4OTAxMjpwcm9tcHQvUFJPTVBUMTIzNDVcIlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHByb21wdEFybjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgSUQgb2YgdGhlIHByb21wdC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKiBAZXhhbXBsZSBcIlBST01QVDEyMzQ1XCJcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBwcm9tcHRJZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgdmVyc2lvbiBvZiB0aGUgcHJvbXB0LlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgcHJvbXB0VmVyc2lvbjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgdmFyaWFudHMgb2YgdGhlIHByb21wdC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSB2YXJpYW50czogSVByb21wdFZhcmlhbnRbXTtcblxuICAvKipcbiAgICogVGhlIGRlc2NyaXB0aW9uIG9mIHRoZSBwcm9tcHQuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG5cbiAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBJTlRFUk5BTCBPTkxZXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbiAgLyoqXG4gICAqIFRoZSBjb21wdXRlZCBoYXNoIG9mIHRoZSBwcm9tcHQgcHJvcGVydGllcy5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBwcm90ZWN0ZWQgcmVhZG9ubHkgX2hhc2g6IHN0cmluZztcblxuICAvKipcbiAgICogTDEgcmVzb3VyY2VcbiAgICogQGludGVybmFsXG4gICAqL1xuICBwcml2YXRlIHJlYWRvbmx5IF9fcmVzb3VyY2U6IGJlZHJvY2suQ2ZuUHJvbXB0O1xuXG4gIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgQ09OU1RSVUNUT1JcbiAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogUHJvbXB0UHJvcHMpIHtcbiAgICBzdXBlcihzY29wZSwgaWQpO1xuICAgIC8vIEVuaGFuY2VkIENESyBBbmFseXRpY3MgVGVsZW1ldHJ5XG4gICAgYWRkQ29uc3RydWN0TWV0YWRhdGEodGhpcywgcHJvcHMpO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gU2V0IHByb3BlcnRpZXMgYW5kIGRlZmF1bHRzXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy5wcm9tcHROYW1lID0gcHJvcHMucHJvbXB0TmFtZTtcbiAgICB0aGlzLmRlc2NyaXB0aW9uID0gcHJvcHMuZGVzY3JpcHRpb247XG4gICAgdGhpcy5rbXNLZXkgPSBwcm9wcy5rbXNLZXk7XG4gICAgdGhpcy52YXJpYW50cyA9IHByb3BzLnZhcmlhbnRzID8/IFtdO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gVmFsaWRhdGlvblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMudmFsaWRhdGVQcm9tcHREZWZhdWx0KHByb3BzKTtcbiAgICB0aGlzLm5vZGUuYWRkVmFsaWRhdGlvbih7IHZhbGlkYXRlOiAoKSA9PiB0aGlzLnZhbGlkYXRlUHJvbXB0TmFtZSgpIH0pO1xuICAgIHRoaXMubm9kZS5hZGRWYWxpZGF0aW9uKHsgdmFsaWRhdGU6ICgpID0+IHRoaXMudmFsaWRhdGVQcm9tcHRWYXJpYW50cygpIH0pO1xuICAgIHRoaXMubm9kZS5hZGRWYWxpZGF0aW9uKHsgdmFsaWRhdGU6ICgpID0+IHRoaXMudmFsaWRhdGVEZXNjcmlwdGlvbigpIH0pO1xuICAgIHRoaXMubm9kZS5hZGRWYWxpZGF0aW9uKHsgdmFsaWRhdGU6ICgpID0+IHRoaXMudmFsaWRhdGVWYXJpYW50TmFtZXMoKSB9KTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIENGTiBQcm9wcyAtIFdpdGggTGF6eSBzdXBwb3J0XG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgY29uc3QgY2ZuUHJvcHM6IGJlZHJvY2suQ2ZuUHJvbXB0UHJvcHMgPSB7XG4gICAgICBjdXN0b21lckVuY3J5cHRpb25LZXlBcm46IHRoaXMua21zS2V5Py5rZXlBcm4sXG4gICAgICBkZWZhdWx0VmFyaWFudDogcHJvcHMuZGVmYXVsdFZhcmlhbnQ/Lm5hbWUsXG4gICAgICBkZXNjcmlwdGlvbjogcHJvcHMuZGVzY3JpcHRpb24sXG4gICAgICBuYW1lOiBwcm9wcy5wcm9tcHROYW1lLFxuICAgICAgdmFyaWFudHM6IExhenkuYW55KHtcbiAgICAgICAgcHJvZHVjZTogKCkgPT4gdGhpcy52YXJpYW50cy5tYXAodmFyaWFudCA9PiB7XG4gICAgICAgICAgY29uc3QgdmFyaWFudENvbmZpZzogYW55ID0ge1xuICAgICAgICAgICAgbmFtZTogdmFyaWFudC5uYW1lLFxuICAgICAgICAgICAgdGVtcGxhdGVUeXBlOiB2YXJpYW50LnRlbXBsYXRlVHlwZSxcbiAgICAgICAgICAgIHRlbXBsYXRlQ29uZmlndXJhdGlvbjogdmFyaWFudC50ZW1wbGF0ZUNvbmZpZ3VyYXRpb24uX3JlbmRlcigpLFxuICAgICAgICAgIH07XG5cbiAgICAgICAgICBpZiAodmFyaWFudC5tb2RlbElkKSB7XG4gICAgICAgICAgICB2YXJpYW50Q29uZmlnLm1vZGVsSWQgPSB2YXJpYW50Lm1vZGVsSWQ7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKHZhcmlhbnQuaW5mZXJlbmNlQ29uZmlndXJhdGlvbikge1xuICAgICAgICAgICAgdmFyaWFudENvbmZpZy5pbmZlcmVuY2VDb25maWd1cmF0aW9uID0gdmFyaWFudC5pbmZlcmVuY2VDb25maWd1cmF0aW9uLl9yZW5kZXIoKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAodmFyaWFudC5nZW5BaVJlc291cmNlKSB7XG4gICAgICAgICAgICB2YXJpYW50Q29uZmlnLmdlbkFpUmVzb3VyY2UgPSB2YXJpYW50LmdlbkFpUmVzb3VyY2UuX3JlbmRlcigpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiB2YXJpYW50Q29uZmlnO1xuICAgICAgICB9KSxcbiAgICAgIH0pLFxuICAgICAgdGFnczogcHJvcHMudGFncyxcbiAgICB9O1xuXG4gICAgLy8gSGFzaCBjYWxjdWxhdGlvbiB1c2VmdWwgZm9yIHZlcnNpb25pbmdcbiAgICB0aGlzLl9oYXNoID0gbWQ1aGFzaChKU09OLnN0cmluZ2lmeShjZm5Qcm9wcykpO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gTDEgSW5zdGFudGlhdGlvblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMuX19yZXNvdXJjZSA9IG5ldyBiZWRyb2NrLkNmblByb21wdCh0aGlzLCAnUmVzb3VyY2UnLCBjZm5Qcm9wcyk7XG5cbiAgICB0aGlzLnByb21wdEFybiA9IHRoaXMuX19yZXNvdXJjZS5hdHRyQXJuO1xuICAgIHRoaXMucHJvbXB0SWQgPSB0aGlzLl9fcmVzb3VyY2UuYXR0cklkO1xuICAgIHRoaXMucHJvbXB0VmVyc2lvbiA9IHRoaXMuX19yZXNvdXJjZS5hdHRyVmVyc2lvbjtcbiAgfVxuXG4gIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgVkFMSURBVElPTiBNRVRIT0RTXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyB3aGV0aGVyIHRoZSBwcm9tcHQgbmFtZSBpcyB2YWxpZCBhY2NvcmRpbmcgdG8gdGhlIHNwZWNpZmljYXRpb24uXG4gICAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL0FXU0Nsb3VkRm9ybWF0aW9uL2xhdGVzdC9Vc2VyR3VpZGUvYXdzLXJlc291cmNlLWJlZHJvY2stcHJvbXB0Lmh0bWwjY2ZuLWJlZHJvY2stcHJvbXB0LW5hbWVcbiAgICogQHJldHVybnMgQXJyYXkgb2YgdmFsaWRhdGlvbiBlcnJvciBtZXNzYWdlcywgZW1wdHkgaWYgdmFsaWRcbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVQcm9tcHROYW1lKCk6IHN0cmluZ1tdIHtcbiAgICBjb25zdCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG5cbiAgICAvLyBVc2UgZXhpc3RpbmcgdmFsaWRhdGlvbiBoZWxwZXIgZm9yIHBhdHRlcm4gdmFsaWRhdGlvblxuICAgIGNvbnN0IHBhdHRlcm5FcnJvcnMgPSB2YWxpZGF0aW9uLnZhbGlkYXRlRmllbGRQYXR0ZXJuKFxuICAgICAgdGhpcy5wcm9tcHROYW1lLFxuICAgICAgJ3Byb21wdE5hbWUnLFxuICAgICAgL14oWzAtOWEtekEtWl1bXy1dPyl7MSwxMDB9JC8sXG4gICAgICAnVmFsaWQgY2hhcmFjdGVycyBhcmUgYS16LCBBLVosIDAtOSwgXyAodW5kZXJzY29yZSkgYW5kIC0gKGh5cGhlbikuIE11c3Qgbm90IGJlZ2luIHdpdGggYSBoeXBoZW4gYW5kIG11c3QgYmUgMS0xMDAgY2hhcmFjdGVycyBsb25nLicsXG4gICAgKTtcblxuICAgIGVycm9ycy5wdXNoKC4uLnBhdHRlcm5FcnJvcnMpO1xuICAgIHJldHVybiBlcnJvcnM7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIHdoZXRoZXIgdGhlIG51bWJlciBvZiBwcm9tcHQgdmFyaWFudHMgaXMgcmVzcGVjdGVkLlxuICAgKiBAcmV0dXJucyBBcnJheSBvZiB2YWxpZGF0aW9uIGVycm9yIG1lc3NhZ2VzLCBlbXB0eSBpZiB2YWxpZFxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVByb21wdFZhcmlhbnRzKCk6IHN0cmluZ1tdIHtcbiAgICBjb25zdCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG5cbiAgICBpZiAodGhpcy52YXJpYW50cy5sZW5ndGggPiBQcm9tcHQuTUFYX1ZBUklBTlRTKSB7XG4gICAgICBlcnJvcnMucHVzaChcbiAgICAgICAgYFRvbyBtYW55IHZhcmlhbnRzIHNwZWNpZmllZC4gVGhlIG1heGltdW0gYWxsb3dlZCBpcyAke1Byb21wdC5NQVhfVkFSSUFOVFN9LCBidXQgeW91IGhhdmUgcHJvdmlkZWQgJHt0aGlzLnZhcmlhbnRzLmxlbmd0aH0gdmFyaWFudHMuYCxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGVycm9ycztcbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgdGhhdCBpZiB0aGUgcHJvbXB0IGhhcyBhIGRlZmF1bHQsIGl0IHdhcyBhbHNvIGFkZGVkIHRvIHRoZSB2YXJpYW50cyBhcnJheVxuICAgKiBAcGFyYW0gcHJvcHMgLSBUaGUgcHJvcGVydGllcyBzZXQgaW4gdGhlIGNvbnN0cnVjdG9yXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlUHJvbXB0RGVmYXVsdChwcm9wczogUHJvbXB0UHJvcHMpIHtcbiAgICBpZiAocHJvcHMuZGVmYXVsdFZhcmlhbnQgJiYgIXByb3BzLnZhcmlhbnRzPy5pbmNsdWRlcyhwcm9wcy5kZWZhdWx0VmFyaWFudCkpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YERlZmF1bHRWYXJpYW50TWlzc2luZ2AsICdUaGUgXFwnZGVmYXVsdFZhcmlhbnRcXCcgbmVlZHMgdG8gYmUgaW5jbHVkZWQgaW4gdGhlIFxcJ3ZhcmlhbnRzXFwnIGFycmF5LicsIHRoaXMpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgd2hldGhlciB0aGUgZGVzY3JpcHRpb24gbGVuZ3RoIGlzIHdpdGhpbiB0aGUgYWxsb3dlZCBsaW1pdC5cbiAgICogQHJldHVybnMgQXJyYXkgb2YgdmFsaWRhdGlvbiBlcnJvciBtZXNzYWdlcywgZW1wdHkgaWYgdmFsaWRcbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVEZXNjcmlwdGlvbigpOiBzdHJpbmdbXSB7XG4gICAgY29uc3QgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgaWYgKHRoaXMuZGVzY3JpcHRpb24gJiYgdGhpcy5kZXNjcmlwdGlvbi5sZW5ndGggPiAyMDApIHtcbiAgICAgIGVycm9ycy5wdXNoKFxuICAgICAgICBgRGVzY3JpcHRpb24gbXVzdCBiZSAyMDAgY2hhcmFjdGVycyBvciBsZXNzLCBnb3QgJHt0aGlzLmRlc2NyaXB0aW9uLmxlbmd0aH0gY2hhcmFjdGVycy5gLFxuICAgICAgKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZXJyb3JzO1xuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyB3aGV0aGVyIGFsbCB2YXJpYW50IG5hbWVzIGFyZSB1bmlxdWUuXG4gICAqIEByZXR1cm5zIEFycmF5IG9mIHZhbGlkYXRpb24gZXJyb3IgbWVzc2FnZXMsIGVtcHR5IGlmIHZhbGlkXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlVmFyaWFudE5hbWVzKCk6IHN0cmluZ1tdIHtcbiAgICBjb25zdCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG4gICAgY29uc3QgbmFtZXMgPSB0aGlzLnZhcmlhbnRzLm1hcCh2ID0+IHYubmFtZSk7XG4gICAgY29uc3QgZHVwbGljYXRlcyA9IG5hbWVzLmZpbHRlcigobmFtZSwgaW5kZXgpID0+IG5hbWVzLmluZGV4T2YobmFtZSkgIT09IGluZGV4KTtcblxuICAgIGlmIChkdXBsaWNhdGVzLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IHVuaXF1ZUR1cGxpY2F0ZXMgPSBbLi4ubmV3IFNldChkdXBsaWNhdGVzKV07XG4gICAgICBlcnJvcnMucHVzaChcbiAgICAgICAgYER1cGxpY2F0ZSB2YXJpYW50IG5hbWVzIGZvdW5kOiAke3VuaXF1ZUR1cGxpY2F0ZXMuam9pbignLCAnKX0uIEVhY2ggdmFyaWFudCBtdXN0IGhhdmUgYSB1bmlxdWUgbmFtZS5gLFxuICAgICAgKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZXJyb3JzO1xuICB9XG5cbiAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBIRUxQRVIgTUVUSE9EU1xuICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgcHJvbXB0IHZlcnNpb24sIGEgc3RhdGljIHNuYXBzaG90IG9mIHlvdXIgcHJvbXB0IHRoYXQgY2FuIGJlXG4gICAqIGRlcGxveWVkIHRvIHByb2R1Y3Rpb24uXG4gICAqXG4gICAqIEBwYXJhbSBkZXNjcmlwdGlvbiAtIE9wdGlvbmFsIGRlc2NyaXB0aW9uIGZvciB0aGUgdmVyc2lvblxuICAgKiBAZGVmYXVsdCAtIE5vIGRlc2NyaXB0aW9uIHByb3ZpZGVkXG4gICAqIEByZXR1cm5zIEEgUHJvbXB0VmVyc2lvbiBvYmplY3QgY29udGFpbmluZyB0aGUgdmVyc2lvbiBkZXRhaWxzIGluY2x1ZGluZyBBUk4gYW5kIHZlcnNpb24gc3RyaW5nXG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgY3JlYXRlVmVyc2lvbihkZXNjcmlwdGlvbj86IHN0cmluZyk6IFByb21wdFZlcnNpb24ge1xuICAgIHJldHVybiBuZXcgUHJvbXB0VmVyc2lvbih0aGlzLCBgUHJvbXB0VmVyc2lvbi0ke3RoaXMuX2hhc2h9YCwge1xuICAgICAgcHJvbXB0OiB0aGlzLFxuICAgICAgZGVzY3JpcHRpb24sXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhIHByb21wdCB2YXJpYW50IHRvIHRoZSBwcm9tcHQuXG4gICAqXG4gICAqIEBwYXJhbSB2YXJpYW50IC0gVGhlIHByb21wdCB2YXJpYW50IHRvIGFkZFxuICAgKiBAdGhyb3dzIFZhbGlkYXRpb25FcnJvciBpZiBhZGRpbmcgdGhlIHZhcmlhbnQgd291bGQgZXhjZWVkIHRoZSBtYXhpbXVtIGFsbG93ZWQgdmFyaWFudHNcbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBhZGRWYXJpYW50KHZhcmlhbnQ6IElQcm9tcHRWYXJpYW50KTogdm9pZCB7XG4gICAgdmFsaWRhdGlvbi50aHJvd0lmSW52YWxpZCh0aGlzLnZhbGlkYXRlVmFyaWFudEFkZGl0aW9uLCB2YXJpYW50KTtcbiAgICB0aGlzLnZhcmlhbnRzLnB1c2godmFyaWFudCk7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIHdoZXRoZXIgYSB2YXJpYW50IGNhbiBiZSBhZGRlZCB3aXRob3V0IGV4Y2VlZGluZyBsaW1pdHMuXG4gICAqIEBwYXJhbSB2YXJpYW50IC0gVGhlIHZhcmlhbnQgdG8gdmFsaWRhdGVcbiAgICogQHJldHVybnMgQXJyYXkgb2YgdmFsaWRhdGlvbiBlcnJvciBtZXNzYWdlcywgZW1wdHkgaWYgdmFsaWRcbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVWYXJpYW50QWRkaXRpb24gPSAodmFyaWFudDogSVByb21wdFZhcmlhbnQpOiBzdHJpbmdbXSA9PiB7XG4gICAgY29uc3QgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgLy8gQ2hlY2sgaWYgYWRkaW5nIHRoaXMgdmFyaWFudCB3b3VsZCBleGNlZWQgdGhlIG1heGltdW1cbiAgICBpZiAodGhpcy52YXJpYW50cy5sZW5ndGggPj0gUHJvbXB0Lk1BWF9WQVJJQU5UUykge1xuICAgICAgZXJyb3JzLnB1c2goXG4gICAgICAgIGBDYW5ub3QgYWRkIHZhcmlhbnQgdG8gcHJvbXB0ICcke3RoaXMucHJvbXB0TmFtZX0nLiBNYXhpbXVtIG9mICR7UHJvbXB0Lk1BWF9WQVJJQU5UU30gdmFyaWFudHMgYWxsb3dlZCwgY3VycmVudGx5IGhhdmUgJHt0aGlzLnZhcmlhbnRzLmxlbmd0aH0uYCxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgZm9yIGR1cGxpY2F0ZSB2YXJpYW50IG5hbWVzXG4gICAgaWYgKHRoaXMudmFyaWFudHMuZmluZCh2ID0+IHYubmFtZSA9PT0gdmFyaWFudC5uYW1lKSkge1xuICAgICAgZXJyb3JzLnB1c2goYFZhcmlhbnQgd2l0aCBuYW1lICcke3ZhcmlhbnQubmFtZX0nIGFscmVhZHkgZXhpc3RzLmApO1xuICAgIH1cblxuICAgIHJldHVybiBlcnJvcnM7XG4gIH07XG59XG4iXX0=