"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptTemplateConfiguration = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
/**
 * Abstract base class for prompt template configurations.
 *
 * This provides a high-level abstraction over the underlying CloudFormation
 * template configuration properties, offering a more developer-friendly interface
 * while maintaining full compatibility with the underlying AWS Bedrock service.
 */
class PromptTemplateConfiguration {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.PromptTemplateConfiguration", version: "2.265.0-alpha.0" };
    /**
     * Creates a text template configuration.
     */
    static text(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_TextTemplateConfigurationProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.text);
            }
            throw error;
        }
        return new TextTemplateConfiguration(props);
    }
    /**
     * Creates a chat template configuration.
     */
    static chat(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ChatTemplateConfigurationProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.chat);
            }
            throw error;
        }
        return new ChatTemplateConfiguration(props);
    }
}
exports.PromptTemplateConfiguration = PromptTemplateConfiguration;
/**
 * Text template configuration for prompts.
 */
class TextTemplateConfiguration extends PromptTemplateConfiguration {
    props;
    constructor(props) {
        super();
        this.props = props;
    }
    _render() {
        return {
            text: {
                inputVariables: this.props.inputVariables?.map((variable) => {
                    return { name: variable };
                }),
                text: this.props.text,
            },
        };
    }
}
/**
 * Chat template configuration for prompts.
 */
class ChatTemplateConfiguration extends PromptTemplateConfiguration {
    props;
    constructor(props) {
        super();
        this.props = props;
    }
    _render() {
        return {
            chat: {
                inputVariables: this.props.inputVariables?.map((variable) => {
                    return { name: variable };
                }),
                messages: this.props.messages?.flatMap(m => m._render()),
                system: this.props.system !== undefined ? [{ text: this.props.system }] : undefined,
                toolConfiguration: this.props.toolConfiguration
                    ? {
                        toolChoice: this.props.toolConfiguration.toolChoice._render(),
                        tools: this.props.toolConfiguration.tools.map(tool => tool._render()),
                    }
                    : undefined,
            },
        };
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvbXB0LXRlbXBsYXRlLWNvbmZpZ3VyYXRpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJwcm9tcHQtdGVtcGxhdGUtY29uZmlndXJhdGlvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQW9EQTs7Ozs7O0dBTUc7QUFDSCxNQUFzQiwyQkFBMkI7O0lBQy9DOztPQUVHO0lBQ0ksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFxQzs7Ozs7Ozs7OztRQUN0RCxPQUFPLElBQUkseUJBQXlCLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDN0M7SUFFRDs7T0FFRztJQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBcUM7Ozs7Ozs7Ozs7UUFDdEQsT0FBTyxJQUFJLHlCQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFDO0tBQzdDOztBQWJILGtFQW9CQztBQUVEOztHQUVHO0FBQ0gsTUFBTSx5QkFBMEIsU0FBUSwyQkFBMkI7SUFDcEM7SUFBN0IsWUFBNkIsS0FBcUM7UUFDaEUsS0FBSyxFQUFFLENBQUM7UUFEbUIsVUFBSyxHQUFMLEtBQUssQ0FBZ0M7S0FFakU7SUFFTSxPQUFPO1FBQ1osT0FBTztZQUNMLElBQUksRUFBRTtnQkFDSixjQUFjLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDLENBQUMsUUFBZ0IsRUFBRSxFQUFFO29CQUNsRSxPQUFPLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDO2dCQUM1QixDQUFDLENBQUM7Z0JBQ0YsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSTthQUN0QjtTQUNGLENBQUM7S0FDSDtDQUNGO0FBRUQ7O0dBRUc7QUFDSCxNQUFNLHlCQUEwQixTQUFRLDJCQUEyQjtJQUNwQztJQUE3QixZQUE2QixLQUFxQztRQUNoRSxLQUFLLEVBQUUsQ0FBQztRQURtQixVQUFLLEdBQUwsS0FBSyxDQUFnQztLQUVqRTtJQUVNLE9BQU87UUFDWixPQUFPO1lBQ0wsSUFBSSxFQUFFO2dCQUNKLGNBQWMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxHQUFHLENBQUMsQ0FBQyxRQUFnQixFQUFFLEVBQUU7b0JBQ2xFLE9BQU8sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUM7Z0JBQzVCLENBQUMsQ0FBQztnQkFDRixRQUFRLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUN4RCxNQUFNLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztnQkFDbkYsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUI7b0JBQzdDLENBQUMsQ0FBQzt3QkFDQSxVQUFVLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFO3dCQUM3RCxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO3FCQUN0RTtvQkFDRCxDQUFDLENBQUMsU0FBUzthQUNkO1NBQ0YsQ0FBQztLQUNIO0NBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSAqIGFzIGJlZHJvY2sgZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHR5cGUgeyBDaGF0TWVzc2FnZSB9IGZyb20gJy4vY2hhdC1wcm9tcHQtdmFyaWFudCc7XG5pbXBvcnQgdHlwZSB7IFRvb2xDb25maWd1cmF0aW9uIH0gZnJvbSAnLi90b29sLWNob2ljZSc7XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgY3JlYXRpbmcgYSB0ZXh0IHRlbXBsYXRlIGNvbmZpZ3VyYXRpb24uXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVGV4dFRlbXBsYXRlQ29uZmlndXJhdGlvblByb3BzIHtcbiAgLyoqXG4gICAqIFRoZSBpbnB1dCB2YXJpYWJsZXMgZm9yIHRoZSB0ZW1wbGF0ZS5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyBpbnB1dCB2YXJpYWJsZXNcbiAgICovXG4gIHJlYWRvbmx5IGlucHV0VmFyaWFibGVzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIFRoZSB0ZXh0IGNvbnRlbnQgb2YgdGhlIHRlbXBsYXRlLlxuICAgKi9cbiAgcmVhZG9ubHkgdGV4dDogc3RyaW5nO1xufVxuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNyZWF0aW5nIGEgY2hhdCB0ZW1wbGF0ZSBjb25maWd1cmF0aW9uLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENoYXRUZW1wbGF0ZUNvbmZpZ3VyYXRpb25Qcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgaW5wdXQgdmFyaWFibGVzIGZvciB0aGUgdGVtcGxhdGUuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTm8gaW5wdXQgdmFyaWFibGVzXG4gICAqL1xuICByZWFkb25seSBpbnB1dFZhcmlhYmxlcz86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBUaGUgbWVzc2FnZXMgaW4gdGhlIGNoYXQgdGVtcGxhdGUuXG4gICAqL1xuICByZWFkb25seSBtZXNzYWdlczogQ2hhdE1lc3NhZ2VbXTtcblxuICAvKipcbiAgICogVGhlIHN5c3RlbSBtZXNzYWdlIGZvciB0aGUgY2hhdCB0ZW1wbGF0ZS5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyBzeXN0ZW0gbWVzc2FnZVxuICAgKi9cbiAgcmVhZG9ubHkgc3lzdGVtPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgdG9vbCBjb25maWd1cmF0aW9uIGZvciB0aGUgY2hhdCB0ZW1wbGF0ZS5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyB0b29sIGNvbmZpZ3VyYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IHRvb2xDb25maWd1cmF0aW9uPzogVG9vbENvbmZpZ3VyYXRpb247XG59XG5cbi8qKlxuICogQWJzdHJhY3QgYmFzZSBjbGFzcyBmb3IgcHJvbXB0IHRlbXBsYXRlIGNvbmZpZ3VyYXRpb25zLlxuICpcbiAqIFRoaXMgcHJvdmlkZXMgYSBoaWdoLWxldmVsIGFic3RyYWN0aW9uIG92ZXIgdGhlIHVuZGVybHlpbmcgQ2xvdWRGb3JtYXRpb25cbiAqIHRlbXBsYXRlIGNvbmZpZ3VyYXRpb24gcHJvcGVydGllcywgb2ZmZXJpbmcgYSBtb3JlIGRldmVsb3Blci1mcmllbmRseSBpbnRlcmZhY2VcbiAqIHdoaWxlIG1haW50YWluaW5nIGZ1bGwgY29tcGF0aWJpbGl0eSB3aXRoIHRoZSB1bmRlcmx5aW5nIEFXUyBCZWRyb2NrIHNlcnZpY2UuXG4gKi9cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBQcm9tcHRUZW1wbGF0ZUNvbmZpZ3VyYXRpb24ge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIHRleHQgdGVtcGxhdGUgY29uZmlndXJhdGlvbi5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgdGV4dChwcm9wczogVGV4dFRlbXBsYXRlQ29uZmlndXJhdGlvblByb3BzKTogUHJvbXB0VGVtcGxhdGVDb25maWd1cmF0aW9uIHtcbiAgICByZXR1cm4gbmV3IFRleHRUZW1wbGF0ZUNvbmZpZ3VyYXRpb24ocHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBjaGF0IHRlbXBsYXRlIGNvbmZpZ3VyYXRpb24uXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGNoYXQocHJvcHM6IENoYXRUZW1wbGF0ZUNvbmZpZ3VyYXRpb25Qcm9wcyk6IFByb21wdFRlbXBsYXRlQ29uZmlndXJhdGlvbiB7XG4gICAgcmV0dXJuIG5ldyBDaGF0VGVtcGxhdGVDb25maWd1cmF0aW9uKHByb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSB0ZW1wbGF0ZSBjb25maWd1cmF0aW9uIGFzIGEgQ2xvdWRGb3JtYXRpb24gcHJvcGVydHkuXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIGFic3RyYWN0IF9yZW5kZXIoKTogYmVkcm9jay5DZm5Qcm9tcHQuUHJvbXB0VGVtcGxhdGVDb25maWd1cmF0aW9uUHJvcGVydHk7XG59XG5cbi8qKlxuICogVGV4dCB0ZW1wbGF0ZSBjb25maWd1cmF0aW9uIGZvciBwcm9tcHRzLlxuICovXG5jbGFzcyBUZXh0VGVtcGxhdGVDb25maWd1cmF0aW9uIGV4dGVuZHMgUHJvbXB0VGVtcGxhdGVDb25maWd1cmF0aW9uIHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSByZWFkb25seSBwcm9wczogVGV4dFRlbXBsYXRlQ29uZmlndXJhdGlvblByb3BzKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHB1YmxpYyBfcmVuZGVyKCk6IGJlZHJvY2suQ2ZuUHJvbXB0LlByb21wdFRlbXBsYXRlQ29uZmlndXJhdGlvblByb3BlcnR5IHtcbiAgICByZXR1cm4ge1xuICAgICAgdGV4dDoge1xuICAgICAgICBpbnB1dFZhcmlhYmxlczogdGhpcy5wcm9wcy5pbnB1dFZhcmlhYmxlcz8ubWFwKCh2YXJpYWJsZTogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHsgbmFtZTogdmFyaWFibGUgfTtcbiAgICAgICAgfSksXG4gICAgICAgIHRleHQ6IHRoaXMucHJvcHMudGV4dCxcbiAgICAgIH0sXG4gICAgfTtcbiAgfVxufVxuXG4vKipcbiAqIENoYXQgdGVtcGxhdGUgY29uZmlndXJhdGlvbiBmb3IgcHJvbXB0cy5cbiAqL1xuY2xhc3MgQ2hhdFRlbXBsYXRlQ29uZmlndXJhdGlvbiBleHRlbmRzIFByb21wdFRlbXBsYXRlQ29uZmlndXJhdGlvbiB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgcHJvcHM6IENoYXRUZW1wbGF0ZUNvbmZpZ3VyYXRpb25Qcm9wcykge1xuICAgIHN1cGVyKCk7XG4gIH1cblxuICBwdWJsaWMgX3JlbmRlcigpOiBiZWRyb2NrLkNmblByb21wdC5Qcm9tcHRUZW1wbGF0ZUNvbmZpZ3VyYXRpb25Qcm9wZXJ0eSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGNoYXQ6IHtcbiAgICAgICAgaW5wdXRWYXJpYWJsZXM6IHRoaXMucHJvcHMuaW5wdXRWYXJpYWJsZXM/Lm1hcCgodmFyaWFibGU6IHN0cmluZykgPT4ge1xuICAgICAgICAgIHJldHVybiB7IG5hbWU6IHZhcmlhYmxlIH07XG4gICAgICAgIH0pLFxuICAgICAgICBtZXNzYWdlczogdGhpcy5wcm9wcy5tZXNzYWdlcz8uZmxhdE1hcChtID0+IG0uX3JlbmRlcigpKSxcbiAgICAgICAgc3lzdGVtOiB0aGlzLnByb3BzLnN5c3RlbSAhPT0gdW5kZWZpbmVkID8gW3sgdGV4dDogdGhpcy5wcm9wcy5zeXN0ZW0gfV0gOiB1bmRlZmluZWQsXG4gICAgICAgIHRvb2xDb25maWd1cmF0aW9uOiB0aGlzLnByb3BzLnRvb2xDb25maWd1cmF0aW9uXG4gICAgICAgICAgPyB7XG4gICAgICAgICAgICB0b29sQ2hvaWNlOiB0aGlzLnByb3BzLnRvb2xDb25maWd1cmF0aW9uLnRvb2xDaG9pY2UuX3JlbmRlcigpLFxuICAgICAgICAgICAgdG9vbHM6IHRoaXMucHJvcHMudG9vbENvbmZpZ3VyYXRpb24udG9vbHMubWFwKHRvb2wgPT4gdG9vbC5fcmVuZGVyKCkpLFxuICAgICAgICAgIH1cbiAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgIH0sXG4gICAgfTtcbiAgfVxufVxuIl19