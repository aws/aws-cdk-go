const VALIDATORS = { _aws_cdk_aws_bedrock_alpha_mixins_KnowledgeBaseOpenSearchServerlessStorageProps: function _aws_cdk_aws_bedrock_alpha_mixins_KnowledgeBaseOpenSearchServerlessStorageProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.collection))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_opensearchserverless_ICollectionRef(p.collection);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_alpha_mixins_KnowledgeBaseSupplementalDataStorageProps: function _aws_cdk_aws_bedrock_alpha_mixins_KnowledgeBaseSupplementalDataStorageProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bucket))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_s3_IBucketRef(p.bucket);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_alpha_AgentProps: function _aws_cdk_aws_bedrock_alpha_AgentProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.actionGroups != null)
                for (const o of p.actionGroups)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_AgentActionGroup(o);
            if (!visitedObjects.has(p.existingRole))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.existingRole);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.idleSessionTTL))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.idleSessionTTL);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.kmsKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_kms_IKey(p.kmsKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_alpha_CustomParserProps: function _aws_cdk_aws_bedrock_alpha_CustomParserProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.parser))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_IFunction(p.parser);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_alpha_SessionSummaryMemoryProps: function _aws_cdk_aws_bedrock_alpha_SessionSummaryMemoryProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.memoryDuration))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.memoryDuration);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_alpha_GuardrailProps: function _aws_cdk_aws_bedrock_alpha_GuardrailProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.contentFilters != null)
                for (const o of p.contentFilters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_ContentFilter(o);
            if (p.contextualGroundingFilters != null)
                for (const o of p.contextualGroundingFilters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_ContextualGroundingFilter(o);
            if (p.deniedTopics != null)
                for (const o of p.deniedTopics)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_Topic(o);
            if (!visitedObjects.has(p.kmsKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_kms_IKey(p.kmsKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.managedWordListFilters != null)
                for (const o of p.managedWordListFilters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_ManagedWordFilter(o);
            if (p.piiFilters != null)
                for (const o of p.piiFilters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_PIIFilter(o);
            if (p.regexFilters != null)
                for (const o of p.regexFilters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_RegexFilter(o);
            if (p.wordFilters != null)
                for (const o of p.wordFilters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_WordFilter(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_alpha_GuardrailAttributes: function _aws_cdk_aws_bedrock_alpha_GuardrailAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.kmsKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_kms_IKey(p.kmsKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_alpha_PromptProps: function _aws_cdk_aws_bedrock_alpha_PromptProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.kmsKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_kms_IKey(p.kmsKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.variants != null)
                for (const o of p.variants)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_bedrock_alpha_IPromptVariant(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_alpha_PromptAttributes: function _aws_cdk_aws_bedrock_alpha_PromptAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.kmsKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_kms_IKey(p.kmsKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_alpha_VectorKnowledgeBaseTypeProps: function _aws_cdk_aws_bedrock_alpha_VectorKnowledgeBaseTypeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.supplementalDataStorageBucket))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_s3_IBucketRef(p.supplementalDataStorageBucket);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_bedrock_alpha_OpenSearchServerlessVectorStoreProps: function _aws_cdk_aws_bedrock_alpha_OpenSearchServerlessVectorStoreProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.collection))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_interfaces_aws_opensearchserverless_ICollectionRef(p.collection);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
