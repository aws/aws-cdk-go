"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptVersion = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const bedrock = __importStar(require("aws-cdk-lib/aws-bedrock"));
const constructs_1 = require("constructs");
const validation = __importStar(require("../agents/validation-helpers"));
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create a Prompt Version with CDK.
 *
 * Creates a version of the prompt. Use this to create a static snapshot of your
 * prompt that can be deployed to production. Versions allow you to easily switch
 * between different configurations for your prompt and update your application
 * with the most appropriate version for your use-case.
 *
 * @cloudformationResource AWS::Bedrock::PromptVersion
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/prompt-management-deploy.html
 */
class PromptVersion extends constructs_1.Construct {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.PromptVersion", version: "2.267.0-alpha.0" };
    /******************************************************************************
     *                              ATTRIBUTES
     *****************************************************************************/
    /**
     * The Amazon Resource Name (ARN) of the prompt version.
     * @attribute
     * @example "arn:aws:bedrock:us-east-1:123456789012:prompt/PROMPT12345:1"
     */
    versionArn;
    /**
     * The prompt used by this version.
     */
    prompt;
    /**
     * The version of the prompt that was created.
     * @attribute
     */
    version;
    /**
     * The description of the prompt version.
     */
    description;
    /******************************************************************************
     *                            INTERNAL ONLY
     *****************************************************************************/
    /**
     * Instance of prompt version.
     * @internal
     */
    __resource;
    /******************************************************************************
     *                            CONSTRUCTOR
     *****************************************************************************/
    constructor(scope, id, props) {
        super(scope, id);
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_PromptVersionProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, PromptVersion);
            }
            throw error;
        }
        this.prompt = props.prompt;
        // Store description for validation
        this.description = props.description;
        // ------------------------------------------------------
        // Immediate Validation (throws error at construction time)
        // ------------------------------------------------------
        if (props.description) {
            validation.throwIfInvalid(this.validateDescriptionImmediate, props.description);
        }
        // ------------------------------------------------------
        // Synthesis-time Validation
        // ------------------------------------------------------
        this.node.addValidation({ validate: () => this.validateDescription() });
        // ------------------------------------------------------
        // L1 Instantiation
        // ------------------------------------------------------
        this.__resource = new bedrock.CfnPromptVersion(this, 'Resource', {
            description: props.description,
            promptArn: props.prompt.promptArn,
        });
        this.versionArn = this.__resource.attrArn;
        this.version = this.__resource.attrVersion;
    }
    /******************************************************************************
     *                            VALIDATION METHODS
     *****************************************************************************/
    /**
     * Validates whether the description length is within the allowed limit (immediate validation).
     * @param description - The description to validate
     * @returns Array of validation error messages, empty if valid
     */
    validateDescriptionImmediate = (description) => {
        const errors = [];
        if (description && description.length > 200) {
            errors.push(`Description must be 200 characters or less, got ${description.length} characters.`);
        }
        return errors;
    };
    /**
     * Validates whether the description length is within the allowed limit.
     * @returns Array of validation error messages, empty if valid
     */
    validateDescription() {
        const errors = [];
        if (this.description && this.description.length > 200) {
            errors.push(`Description must be 200 characters or less, got ${this.description.length} characters.`);
        }
        return errors;
    }
}
exports.PromptVersion = PromptVersion;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvbXB0LXZlcnNpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJwcm9tcHQtdmVyc2lvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGlFQUFtRDtBQUNuRCwyQ0FBdUM7QUFHdkMseUVBQTJEO0FBdUIzRDs7K0VBRStFO0FBQy9FOzs7Ozs7Ozs7O0dBVUc7QUFDSCxNQUFhLGFBQWMsU0FBUSxzQkFBUzs7SUFDMUM7O21GQUUrRTtJQUMvRTs7OztPQUlHO0lBQ2EsVUFBVSxDQUFTO0lBRW5DOztPQUVHO0lBQ2EsTUFBTSxDQUFVO0lBRWhDOzs7T0FHRztJQUNhLE9BQU8sQ0FBUztJQUVoQzs7T0FFRztJQUNhLFdBQVcsQ0FBVTtJQUVyQzs7bUZBRStFO0lBQy9FOzs7T0FHRztJQUNjLFVBQVUsQ0FBMkI7SUFFdEQ7O21GQUUrRTtJQUMvRSxZQUFZLEtBQWdCLEVBQUUsRUFBVSxFQUFFLEtBQXlCO1FBQ2pFLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7Ozs7OzsrQ0F4Q1IsYUFBYTs7OztRQTBDdEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO1FBRTNCLG1DQUFtQztRQUNuQyxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUM7UUFFckMseURBQXlEO1FBQ3pELDJEQUEyRDtRQUMzRCx5REFBeUQ7UUFDekQsSUFBSSxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDdEIsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ2xGLENBQUM7UUFFRCx5REFBeUQ7UUFDekQsNEJBQTRCO1FBQzVCLHlEQUF5RDtRQUN6RCxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLFFBQVEsRUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFeEUseURBQXlEO1FBQ3pELG1CQUFtQjtRQUNuQix5REFBeUQ7UUFDekQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFO1lBQy9ELFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztZQUM5QixTQUFTLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxTQUFTO1NBQ2xDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7UUFDMUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQztLQUM1QztJQUVEOzttRkFFK0U7SUFDL0U7Ozs7T0FJRztJQUNLLDRCQUE0QixHQUFHLENBQUMsV0FBbUIsRUFBWSxFQUFFO1FBQ3ZFLE1BQU0sTUFBTSxHQUFhLEVBQUUsQ0FBQztRQUU1QixJQUFJLFdBQVcsSUFBSSxXQUFXLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDO1lBQzVDLE1BQU0sQ0FBQyxJQUFJLENBQ1QsbURBQW1ELFdBQVcsQ0FBQyxNQUFNLGNBQWMsQ0FDcEYsQ0FBQztRQUNKLENBQUM7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDLENBQUM7SUFFRjs7O09BR0c7SUFDSyxtQkFBbUI7UUFDekIsTUFBTSxNQUFNLEdBQWEsRUFBRSxDQUFDO1FBRTVCLElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQztZQUN0RCxNQUFNLENBQUMsSUFBSSxDQUNULG1EQUFtRCxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sY0FBYyxDQUN6RixDQUFDO1FBQ0osQ0FBQztRQUVELE9BQU8sTUFBTSxDQUFDO0tBQ2Y7O0FBekdILHNDQTBHQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGJlZHJvY2sgZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG4vLyBJbnRlcm5hbCBMaWJzXG5pbXBvcnQgdHlwZSB7IElQcm9tcHQgfSBmcm9tICcuL3Byb21wdCc7XG5pbXBvcnQgKiBhcyB2YWxpZGF0aW9uIGZyb20gJy4uL2FnZW50cy92YWxpZGF0aW9uLWhlbHBlcnMnO1xuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIFBST1BTIEZPUiBORVcgQ09OU1RSVUNUXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNyZWF0aW5nIGEgQ0RLIG1hbmFnZWQgQmVkcm9jayBQcm9tcHQgVmVyc2lvbi5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBQcm9tcHRWZXJzaW9uUHJvcHMge1xuICAvKipcbiAgICogVGhlIHByb21wdCB0byB1c2UgZm9yIHRoaXMgdmVyc2lvbi5cbiAgICovXG4gIHJlYWRvbmx5IHByb21wdDogSVByb21wdDtcblxuICAvKipcbiAgICogVGhlIGRlc2NyaXB0aW9uIG9mIHRoZSBwcm9tcHQgdmVyc2lvbi5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyBkZXNjcmlwdGlvbiBwcm92aWRlZC5cbiAgICogTWF4aW11bSBsZW5ndGg6IDIwMFxuICAgKi9cbiAgcmVhZG9ubHkgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgTkVXIENPTlNUUlVDVCBERUZJTklUSU9OXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIENsYXNzIHRvIGNyZWF0ZSBhIFByb21wdCBWZXJzaW9uIHdpdGggQ0RLLlxuICpcbiAqIENyZWF0ZXMgYSB2ZXJzaW9uIG9mIHRoZSBwcm9tcHQuIFVzZSB0aGlzIHRvIGNyZWF0ZSBhIHN0YXRpYyBzbmFwc2hvdCBvZiB5b3VyXG4gKiBwcm9tcHQgdGhhdCBjYW4gYmUgZGVwbG95ZWQgdG8gcHJvZHVjdGlvbi4gVmVyc2lvbnMgYWxsb3cgeW91IHRvIGVhc2lseSBzd2l0Y2hcbiAqIGJldHdlZW4gZGlmZmVyZW50IGNvbmZpZ3VyYXRpb25zIGZvciB5b3VyIHByb21wdCBhbmQgdXBkYXRlIHlvdXIgYXBwbGljYXRpb25cbiAqIHdpdGggdGhlIG1vc3QgYXBwcm9wcmlhdGUgdmVyc2lvbiBmb3IgeW91ciB1c2UtY2FzZS5cbiAqXG4gKiBAY2xvdWRmb3JtYXRpb25SZXNvdXJjZSBBV1M6OkJlZHJvY2s6OlByb21wdFZlcnNpb25cbiAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9wcm9tcHQtbWFuYWdlbWVudC1kZXBsb3kuaHRtbFxuICovXG5leHBvcnQgY2xhc3MgUHJvbXB0VmVyc2lvbiBleHRlbmRzIENvbnN0cnVjdCB7XG4gIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBVFRSSUJVVEVTXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbiAgLyoqXG4gICAqIFRoZSBBbWF6b24gUmVzb3VyY2UgTmFtZSAoQVJOKSBvZiB0aGUgcHJvbXB0IHZlcnNpb24uXG4gICAqIEBhdHRyaWJ1dGVcbiAgICogQGV4YW1wbGUgXCJhcm46YXdzOmJlZHJvY2s6dXMtZWFzdC0xOjEyMzQ1Njc4OTAxMjpwcm9tcHQvUFJPTVBUMTIzNDU6MVwiXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgdmVyc2lvbkFybjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgcHJvbXB0IHVzZWQgYnkgdGhpcyB2ZXJzaW9uLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHByb21wdDogSVByb21wdDtcblxuICAvKipcbiAgICogVGhlIHZlcnNpb24gb2YgdGhlIHByb21wdCB0aGF0IHdhcyBjcmVhdGVkLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgdmVyc2lvbjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgZGVzY3JpcHRpb24gb2YgdGhlIHByb21wdCB2ZXJzaW9uLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuXG4gIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgSU5URVJOQUwgT05MWVxuICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gIC8qKlxuICAgKiBJbnN0YW5jZSBvZiBwcm9tcHQgdmVyc2lvbi5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBwcml2YXRlIHJlYWRvbmx5IF9fcmVzb3VyY2U6IGJlZHJvY2suQ2ZuUHJvbXB0VmVyc2lvbjtcblxuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgIENPTlNUUlVDVE9SXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbiAgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM6IFByb21wdFZlcnNpb25Qcm9wcykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCk7XG5cbiAgICB0aGlzLnByb21wdCA9IHByb3BzLnByb21wdDtcblxuICAgIC8vIFN0b3JlIGRlc2NyaXB0aW9uIGZvciB2YWxpZGF0aW9uXG4gICAgdGhpcy5kZXNjcmlwdGlvbiA9IHByb3BzLmRlc2NyaXB0aW9uO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gSW1tZWRpYXRlIFZhbGlkYXRpb24gKHRocm93cyBlcnJvciBhdCBjb25zdHJ1Y3Rpb24gdGltZSlcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICBpZiAocHJvcHMuZGVzY3JpcHRpb24pIHtcbiAgICAgIHZhbGlkYXRpb24udGhyb3dJZkludmFsaWQodGhpcy52YWxpZGF0ZURlc2NyaXB0aW9uSW1tZWRpYXRlLCBwcm9wcy5kZXNjcmlwdGlvbik7XG4gICAgfVxuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gU3ludGhlc2lzLXRpbWUgVmFsaWRhdGlvblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMubm9kZS5hZGRWYWxpZGF0aW9uKHsgdmFsaWRhdGU6ICgpID0+IHRoaXMudmFsaWRhdGVEZXNjcmlwdGlvbigpIH0pO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gTDEgSW5zdGFudGlhdGlvblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMuX19yZXNvdXJjZSA9IG5ldyBiZWRyb2NrLkNmblByb21wdFZlcnNpb24odGhpcywgJ1Jlc291cmNlJywge1xuICAgICAgZGVzY3JpcHRpb246IHByb3BzLmRlc2NyaXB0aW9uLFxuICAgICAgcHJvbXB0QXJuOiBwcm9wcy5wcm9tcHQucHJvbXB0QXJuLFxuICAgIH0pO1xuXG4gICAgdGhpcy52ZXJzaW9uQXJuID0gdGhpcy5fX3Jlc291cmNlLmF0dHJBcm47XG4gICAgdGhpcy52ZXJzaW9uID0gdGhpcy5fX3Jlc291cmNlLmF0dHJWZXJzaW9uO1xuICB9XG5cbiAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBWQUxJREFUSU9OIE1FVEhPRFNcbiAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICAvKipcbiAgICogVmFsaWRhdGVzIHdoZXRoZXIgdGhlIGRlc2NyaXB0aW9uIGxlbmd0aCBpcyB3aXRoaW4gdGhlIGFsbG93ZWQgbGltaXQgKGltbWVkaWF0ZSB2YWxpZGF0aW9uKS5cbiAgICogQHBhcmFtIGRlc2NyaXB0aW9uIC0gVGhlIGRlc2NyaXB0aW9uIHRvIHZhbGlkYXRlXG4gICAqIEByZXR1cm5zIEFycmF5IG9mIHZhbGlkYXRpb24gZXJyb3IgbWVzc2FnZXMsIGVtcHR5IGlmIHZhbGlkXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlRGVzY3JpcHRpb25JbW1lZGlhdGUgPSAoZGVzY3JpcHRpb246IHN0cmluZyk6IHN0cmluZ1tdID0+IHtcbiAgICBjb25zdCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG5cbiAgICBpZiAoZGVzY3JpcHRpb24gJiYgZGVzY3JpcHRpb24ubGVuZ3RoID4gMjAwKSB7XG4gICAgICBlcnJvcnMucHVzaChcbiAgICAgICAgYERlc2NyaXB0aW9uIG11c3QgYmUgMjAwIGNoYXJhY3RlcnMgb3IgbGVzcywgZ290ICR7ZGVzY3JpcHRpb24ubGVuZ3RofSBjaGFyYWN0ZXJzLmAsXG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiBlcnJvcnM7XG4gIH07XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyB3aGV0aGVyIHRoZSBkZXNjcmlwdGlvbiBsZW5ndGggaXMgd2l0aGluIHRoZSBhbGxvd2VkIGxpbWl0LlxuICAgKiBAcmV0dXJucyBBcnJheSBvZiB2YWxpZGF0aW9uIGVycm9yIG1lc3NhZ2VzLCBlbXB0eSBpZiB2YWxpZFxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZURlc2NyaXB0aW9uKCk6IHN0cmluZ1tdIHtcbiAgICBjb25zdCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG5cbiAgICBpZiAodGhpcy5kZXNjcmlwdGlvbiAmJiB0aGlzLmRlc2NyaXB0aW9uLmxlbmd0aCA+IDIwMCkge1xuICAgICAgZXJyb3JzLnB1c2goXG4gICAgICAgIGBEZXNjcmlwdGlvbiBtdXN0IGJlIDIwMCBjaGFyYWN0ZXJzIG9yIGxlc3MsIGdvdCAke3RoaXMuZGVzY3JpcHRpb24ubGVuZ3RofSBjaGFyYWN0ZXJzLmAsXG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiBlcnJvcnM7XG4gIH1cbn1cbiJdfQ==