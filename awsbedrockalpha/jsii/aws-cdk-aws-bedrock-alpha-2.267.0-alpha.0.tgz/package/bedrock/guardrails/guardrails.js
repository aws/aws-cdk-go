"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Guardrail = exports.GuardrailBase = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const fs = __importStar(require("fs"));
const aws_cdk_lib_1 = require("aws-cdk-lib");
const bedrock = __importStar(require("aws-cdk-lib/aws-bedrock"));
const aws_cloudwatch_1 = require("aws-cdk-lib/aws-cloudwatch");
const iam = __importStar(require("aws-cdk-lib/aws-iam"));
const aws_kms_1 = require("aws-cdk-lib/aws-kms");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const helpers_internal_2 = require("aws-cdk-lib/core/lib/helpers-internal");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
// Internal Libs
const filters = __importStar(require("./guardrail-filters"));
const guardrail_version_1 = require("./guardrail-version");
/**
 * Abstract base class for a Guardrail.
 * Contains methods and attributes valid for Guardrails either created with CDK or imported.
 */
class GuardrailBase extends aws_cdk_lib_1.Resource {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.GuardrailBase", version: "2.267.0-alpha.0" };
    /**
     * Return the given named metric for all guardrails.
     *
     * By default, the metric will be calculated as a sum over a period of 5 minutes.
     * You can customize this by using the `statistic` and `period` properties.
     */
    static metricAll(metricName, props) {
        return new aws_cloudwatch_1.Metric({
            namespace: 'AWS/Bedrock/Guardrails',
            dimensionsMap: { Operation: 'ApplyGuardrail' },
            metricName,
            ...props,
        });
    }
    /**
     * Return the invocations metric for all guardrails.
     */
    static metricAllInvocations(props) {
        return this.metricAll('Invocations', props);
    }
    /**
     * Return the text unit count metric for all guardrails.
     */
    static metricAllTextUnitCount(props) {
        return this.metricAll('TextUnitCount', props);
    }
    /**
     * Return the invocations intervened metric for all guardrails.
     */
    static metricAllInvocationsIntervened(props) {
        return this.metricAll('InvocationsIntervened', props);
    }
    /**
     * Return the invocation latency metric for all guardrails.
     */
    static metricAllInvocationLatency(props) {
        return this.metricAll('InvocationLatency', props);
    }
    _version = 'DRAFT';
    /**
     * The version of the guardrail.
     * @attribute
     */
    get guardrailVersion() {
        return this._version;
    }
    updateVersion(version) {
        this._version = version;
    }
    /**
     * Grant the given principal identity permissions to perform actions on this guardrail.
     * [disable-awslint:no-grants]
     */
    grant(grantee, ...actions) {
        return iam.Grant.addToPrincipal({
            grantee,
            actions,
            resourceArns: [this.guardrailArn],
        });
    }
    /**
     * Grant the given identity permissions to apply the guardrail.
     * [disable-awslint:no-grants]
     */
    grantApply(grantee) {
        const baseGrant = this.grant(grantee, 'bedrock:ApplyGuardrail');
        if (this.kmsKey) {
            // If KMS key exists, create encryption grant and combine with base grant
            const kmsGrant = this.kmsKey.grantEncryptDecrypt(grantee);
            return kmsGrant.combine(baseGrant);
        }
        else {
            // If no KMS key exists, return only the base grant
            return baseGrant;
        }
    }
    /**
     * Return the given named metric for this guardrail.
     *
     * By default, the metric will be calculated as a sum over a period of 5 minutes.
     * You can customize this by using the `statistic` and `period` properties.
     */
    metric(metricName, props) {
        const metricProps = {
            namespace: 'AWS/Bedrock/Guardrails',
            metricName,
            dimensionsMap: { GuardrailArn: this.guardrailArn, GuardrailVersion: this.guardrailVersion },
            ...props,
        };
        return this.configureMetric(metricProps);
    }
    /**
     * Return the invocations metric for this guardrail.
     */
    metricInvocations(props) {
        return this.metric('Invocations', props);
    }
    /**
     * Return the invocation latency metric for this guardrail.
     */
    metricInvocationLatency(props) {
        return this.metric('InvocationLatency', props);
    }
    /**
     * Return the invocation client errors metric for this guardrail.
     */
    metricInvocationClientErrors(props) {
        return this.metric('InvocationClientErrors', props);
    }
    /**
     * Return the invocation server errors metric for this guardrail.
     */
    metricInvocationServerErrors(props) {
        return this.metric('InvocationServerErrors', props);
    }
    /**
     * Return the invocation throttles metric for this guardrail.
     */
    metricInvocationThrottles(props) {
        return this.metric('InvocationThrottles', props);
    }
    /**
     * Return the text unit count metric for this guardrail.
     */
    metricTextUnitCount(props) {
        return this.metric('TextUnitCount', props);
    }
    /**
     * Return the invocations intervened metric for this guardrail.
     */
    metricInvocationsIntervened(props) {
        return this.metric('InvocationsIntervened', props);
    }
    configureMetric(props) {
        return new aws_cloudwatch_1.Metric({
            ...props,
            region: props?.region ?? this.stack.region,
            account: props?.account ?? this.stack.account,
        });
    }
}
exports.GuardrailBase = GuardrailBase;
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create a Guardrail with CDK.
 * @cloudformationResource AWS::Bedrock::Guardrail
 */
let Guardrail = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = GuardrailBase;
    let _instanceExtraInitializers = [];
    let _addContentFilter_decorators;
    let _addPIIFilter_decorators;
    let _addRegexFilter_decorators;
    let _addDeniedTopicFilter_decorators;
    let _addContextualGroundingFilter_decorators;
    let _addWordFilter_decorators;
    let _addWordFilterFromFile_decorators;
    let _addManagedWordListFilter_decorators;
    let _createVersion_decorators;
    var Guardrail = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _addContentFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addPIIFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addRegexFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addDeniedTopicFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addContextualGroundingFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addWordFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addWordFilterFromFile_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addManagedWordListFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _createVersion_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            __esDecorate(this, null, _addContentFilter_decorators, { kind: "method", name: "addContentFilter", static: false, private: false, access: { has: obj => "addContentFilter" in obj, get: obj => obj.addContentFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addPIIFilter_decorators, { kind: "method", name: "addPIIFilter", static: false, private: false, access: { has: obj => "addPIIFilter" in obj, get: obj => obj.addPIIFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addRegexFilter_decorators, { kind: "method", name: "addRegexFilter", static: false, private: false, access: { has: obj => "addRegexFilter" in obj, get: obj => obj.addRegexFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addDeniedTopicFilter_decorators, { kind: "method", name: "addDeniedTopicFilter", static: false, private: false, access: { has: obj => "addDeniedTopicFilter" in obj, get: obj => obj.addDeniedTopicFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addContextualGroundingFilter_decorators, { kind: "method", name: "addContextualGroundingFilter", static: false, private: false, access: { has: obj => "addContextualGroundingFilter" in obj, get: obj => obj.addContextualGroundingFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addWordFilter_decorators, { kind: "method", name: "addWordFilter", static: false, private: false, access: { has: obj => "addWordFilter" in obj, get: obj => obj.addWordFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addWordFilterFromFile_decorators, { kind: "method", name: "addWordFilterFromFile", static: false, private: false, access: { has: obj => "addWordFilterFromFile" in obj, get: obj => obj.addWordFilterFromFile }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addManagedWordListFilter_decorators, { kind: "method", name: "addManagedWordListFilter", static: false, private: false, access: { has: obj => "addManagedWordListFilter" in obj, get: obj => obj.addManagedWordListFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _createVersion_decorators, { kind: "method", name: "createVersion", static: false, private: false, access: { has: obj => "createVersion" in obj, get: obj => obj.createVersion }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            Guardrail = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.Guardrail", version: "2.267.0-alpha.0" };
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.Guardrail';
        /**
         * Import a guardrail given its attributes
         */
        static fromGuardrailAttributes(scope, id, attrs) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_GuardrailAttributes(attrs);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.fromGuardrailAttributes);
                }
                throw error;
            }
            class Import extends GuardrailBase {
                guardrailArn = attrs.guardrailArn;
                guardrailId = aws_cdk_lib_1.Arn.split(attrs.guardrailArn, aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME).resourceName;
                kmsKey = attrs.kmsKey;
                lastUpdated = undefined;
                constructor() {
                    super(scope, id);
                    this.updateVersion(attrs.guardrailVersion ?? 'DRAFT');
                }
            }
            return new Import();
        }
        /**
         * Import a low-level L1 Cfn Guardrail
         */
        static fromCfnGuardrail(cfnGuardrail) {
            return new (class extends GuardrailBase {
                guardrailArn = cfnGuardrail.attrGuardrailArn;
                guardrailId = cfnGuardrail.attrGuardrailId;
                kmsKey = cfnGuardrail.kmsKeyArn
                    ? aws_kms_1.Key.fromKeyArn(this, '@FromCfnGuardrailKey', cfnGuardrail.kmsKeyArn)
                    : undefined;
                lastUpdated = cfnGuardrail.attrUpdatedAt;
                constructor() {
                    super(cfnGuardrail, '@FromCfnGuardrail');
                    this.updateVersion(cfnGuardrail.attrVersion);
                }
            })();
        }
        /**
         * The ARN of the guardrail.
         * @attribute
         */
        guardrailArn = __runInitializers(this, _instanceExtraInitializers);
        /**
         * The ID of the guardrail.
         * @attribute
         */
        guardrailId;
        /**
         * The name of the guardrail.
         */
        name;
        /**
         * The KMS key used to encrypt data.
         *
         * @default undefined - "Data is encrypted by default with a key that AWS owns and manages for you"
         */
        kmsKey;
        /**
         * The content filters applied by the guardrail.
         */
        contentFilters;
        /**
         * The PII filters applied by the guardrail.
         */
        piiFilters;
        /**
         * The regex filters applied by the guardrail.
         */
        regexFilters;
        /**
         * The denied topic filters applied by the guardrail.
         */
        deniedTopics;
        /**
         * The contextual grounding filters applied by the guardrail.
         */
        contextualGroundingFilters;
        /**
         * The word filters applied by the guardrail.
         */
        wordFilters;
        /**
         * The managed word list filters applied by the guardrail.
         */
        managedWordListFilters;
        /**
         * When this guardrail was last updated
         */
        lastUpdated;
        /**
         * The computed hash of the guardrail properties.
         */
        hash;
        /**
         * The L1 representation of the guardrail
         */
        __resource;
        /**
         * The tier that your guardrail uses for denied topic filters.
         * @default filters.TierConfig.CLASSIC
         */
        topicsTierConfig;
        /**
         * The tier that your guardrail uses for content filters.
         * Consider using a tier that balances performance, accuracy, and compatibility with your existing generative AI workflows.
         * @default filters.TierConfig.CLASSIC
         */
        contentFiltersTierConfig;
        /**
         * The cross-region configuration for the guardrail.
         */
        crossRegionConfig;
        /**
         * The message to return when the guardrail blocks a prompt.
         * @default "Sorry, your query violates our usage policy."
         */
        blockedInputMessaging;
        /**
         * The message to return when the guardrail blocks a model response.
         * @default "Sorry, I am unable to answer your question because of our usage policy."
         */
        blockedOutputsMessaging;
        constructor(scope, id, props) {
            super(scope, id, {
                physicalName: props.guardrailName,
            });
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_GuardrailProps(props);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, Guardrail);
                }
                throw error;
            }
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            // ------------------------------------------------------
            // Set properties or defaults
            // ------------------------------------------------------
            this.name = this.physicalName;
            this.contentFilters = props.contentFilters ?? [];
            this.piiFilters = props.piiFilters ?? [];
            this.regexFilters = props.regexFilters ?? [];
            this.deniedTopics = props.deniedTopics ?? [];
            this.contextualGroundingFilters = props.contextualGroundingFilters ?? [];
            this.wordFilters = props.wordFilters ?? [];
            this.managedWordListFilters = props.managedWordListFilters ?? [];
            this.topicsTierConfig = props.topicsTierConfig ?? filters.TierConfig.CLASSIC;
            this.contentFiltersTierConfig = props.contentFiltersTierConfig ?? filters.TierConfig.CLASSIC;
            this.crossRegionConfig = props.crossRegionConfig;
            this.blockedInputMessaging = props.blockedInputMessaging ?? 'Sorry, your query violates our usage policy.';
            this.blockedOutputsMessaging = props.blockedOutputsMessaging ?? 'Sorry, I am unable to answer your question because of our usage policy.';
            // ------------------------------------------------------
            // Validate all filter arrays
            // ------------------------------------------------------
            this.validateContentFilters(this.contentFilters);
            this.validatePiiFilters(this.piiFilters);
            this.validateRegexFilters(this.regexFilters);
            this.validateDeniedTopics(this.deniedTopics);
            this.validateContextualGroundingFilters(this.contextualGroundingFilters);
            this.validateWordFilters(this.wordFilters);
            this.validateManagedWordListFilters(this.managedWordListFilters);
            // ------------------------------------------------------
            // Validate messaging properties
            // ------------------------------------------------------
            this.validateMessagingProperty(this.blockedInputMessaging, 'blockedInputMessaging');
            this.validateMessagingProperty(this.blockedOutputsMessaging, 'blockedOutputsMessaging');
            // ------------------------------------------------------
            // Validate tier configuration requirements
            // ------------------------------------------------------
            this.validateTierConfiguration(props);
            // ------------------------------------------------------
            // CFN Props - With Lazy support
            // ------------------------------------------------------
            let cfnProps = {
                name: props.guardrailName,
                description: props.description,
                kmsKeyArn: props.kmsKey?.keyArn,
                blockedInputMessaging: this.blockedInputMessaging,
                blockedOutputsMessaging: this.blockedOutputsMessaging,
                // Lazy props
                crossRegionConfig: this.generateCfnCrossRegionConfig(),
                contentPolicyConfig: this.generateCfnContentPolicyConfig(),
                contextualGroundingPolicyConfig: this.generateCfnContextualPolicyConfig(),
                topicPolicyConfig: this.generateCfnTopicPolicy(),
                wordPolicyConfig: this.generateCfnWordPolicyConfig(),
                sensitiveInformationPolicyConfig: this.generateCfnSensitiveInformationPolicyConfig(),
            };
            // Hash calculation useful for versioning of the guardrail
            this.hash = (0, helpers_internal_1.md5hash)(JSON.stringify(cfnProps));
            // ------------------------------------------------------
            // L1 Instantiation
            // ------------------------------------------------------
            this.__resource = new bedrock.CfnGuardrail(this, 'MyGuardrail', cfnProps);
            this.guardrailId = this.__resource.attrGuardrailId;
            this.guardrailArn = this.__resource.attrGuardrailArn;
            this.updateVersion(this.__resource.attrVersion);
            this.lastUpdated = this.__resource.attrUpdatedAt;
        }
        // ------------------------------------------------------
        // METHODS
        // ------------------------------------------------------
        /**
         * Adds a content filter to the guardrail.
         * @param filter The content filter to add.
         */
        addContentFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ContentFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addContentFilter);
                }
                throw error;
            }
            this.validateSingleContentFilter(filter);
            this.contentFilters.push(filter);
        }
        /**
         * Adds a PII filter to the guardrail.
         * @param filter The PII filter to add.
         */
        addPIIFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_PIIFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addPIIFilter);
                }
                throw error;
            }
            this.validateSinglePiiFilter(filter);
            this.piiFilters.push(filter);
        }
        /**
         * Adds a regex filter to the guardrail.
         * @param filter The regex filter to add.
         */
        addRegexFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_RegexFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addRegexFilter);
                }
                throw error;
            }
            this.validateSingleRegexFilter(filter);
            this.regexFilters.push(filter);
        }
        /**
         * Adds a denied topic filter to the guardrail.
         * @param filter The denied topic filter to add.
         */
        addDeniedTopicFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_Topic(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addDeniedTopicFilter);
                }
                throw error;
            }
            this.validateSingleDeniedTopic(filter);
            this.deniedTopics.push(filter);
        }
        /**
         * Adds a contextual grounding filter to the guardrail.
         * @param filter The contextual grounding filter to add.
         */
        addContextualGroundingFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ContextualGroundingFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addContextualGroundingFilter);
                }
                throw error;
            }
            this.validateSingleContextualGroundingFilter(filter);
            this.contextualGroundingFilters.push(filter);
        }
        /**
         * Adds a word filter to the guardrail.
         * @param filter The word filter to add.
         */
        addWordFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_WordFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addWordFilter);
                }
                throw error;
            }
            this.validateSingleWordFilter(filter);
            this.wordFilters.push(filter);
        }
        /**
         * Adds a word filter to the guardrail.
         * @param filePath The location of the word filter file.
         */
        addWordFilterFromFile(filePath, inputAction, outputAction, inputEnabled, outputEnabled) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_GuardrailAction(inputAction);
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_GuardrailAction(outputAction);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addWordFilterFromFile);
                }
                throw error;
            }
            const fileContents = fs.readFileSync(filePath, 'utf8');
            const words = fileContents.trim().split(',');
            for (const word of words)
                this.addWordFilter({ text: word, inputAction, outputAction, inputEnabled, outputEnabled });
        }
        /**
         * Adds a managed word list filter to the guardrail.
         * @param filter The managed word list filter to add.
         */
        addManagedWordListFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ManagedWordFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addManagedWordListFilter);
                }
                throw error;
            }
            this.validateSingleManagedWordListFilter(filter);
            this.managedWordListFilters.push(filter);
        }
        /**
         * Create a version for the guardrail.
         * @param description The description of the version.
         * @returns The guardrail version.
         */
        createVersion(description) {
            const cfnVersion = new guardrail_version_1.GuardrailVersion(this, `GuardrailVersion-${this.hash.slice(0, 16)}`, {
                description: description,
                guardrail: this,
            });
            this.updateVersion(cfnVersion.guardrailVersion);
            return this.guardrailVersion;
        }
        // ------------------------------------------------------
        // CFN Generators
        // ------------------------------------------------------
        /**
         * Returns the content filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnContentPolicyConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.contentFilters.length > 0) {
                        const contentPolicyConfig = {
                            filtersConfig: this.contentFilters,
                            ...(this.contentFiltersTierConfig && {
                                contentFiltersTierConfig: {
                                    tierName: this.contentFiltersTierConfig,
                                },
                            }),
                        };
                        return contentPolicyConfig;
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Returns the topic filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnTopicPolicy() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.deniedTopics.length > 0) {
                        const topicPolicyConfig = {
                            topicsConfig: this.deniedTopics.flatMap((topic) => {
                                return {
                                    definition: topic.definition,
                                    name: topic.name,
                                    examples: topic.examples,
                                    type: 'DENY',
                                    inputAction: topic.inputAction,
                                    inputEnabled: topic.inputEnabled,
                                    outputAction: topic.outputAction,
                                    outputEnabled: topic.outputEnabled,
                                };
                            }),
                            ...(this.topicsTierConfig && {
                                topicsTierConfig: {
                                    tierName: this.topicsTierConfig,
                                },
                            }),
                        };
                        return topicPolicyConfig;
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Returns the contectual filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnContextualPolicyConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.contextualGroundingFilters.length > 0) {
                        return {
                            filtersConfig: this.contextualGroundingFilters.flatMap((filter) => {
                                return {
                                    type: filter.type,
                                    threshold: filter.threshold,
                                    action: filter.action,
                                    enabled: filter.enabled,
                                };
                            }),
                        };
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Returns the word config applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnWordPolicyConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.wordFilters.length > 0 || this.managedWordListFilters.length > 0) {
                        return {
                            wordsConfig: this.generateCfnWordConfig(),
                            managedWordListsConfig: this.generateCfnManagedWordListsConfig(),
                        };
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Returns the word filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnWordConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    return this.wordFilters.flatMap((word) => {
                        return {
                            text: word.text,
                            inputAction: word.inputAction,
                            inputEnabled: word.inputEnabled,
                            outputAction: word.outputAction,
                            outputEnabled: word.outputEnabled,
                        };
                    });
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the word filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnManagedWordListsConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    return this.managedWordListFilters.flatMap((filter) => {
                        return {
                            type: filter.type,
                            inputAction: filter.inputAction,
                            inputEnabled: filter.inputEnabled,
                            outputAction: filter.outputAction,
                            outputEnabled: filter.outputEnabled,
                        };
                    });
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the sensitive information config applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnSensitiveInformationPolicyConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.regexFilters.length > 0 || this.piiFilters.length > 0) {
                        return {
                            regexesConfig: this.generateCfnRegexesConfig(),
                            piiEntitiesConfig: this.generateCfnPiiEntitiesConfig(),
                        };
                    }
                    else {
                        return undefined;
                    }
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the regex filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnRegexesConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    return this.regexFilters.flatMap((regex) => {
                        return {
                            name: regex.name,
                            description: regex.description,
                            pattern: regex.pattern,
                            action: regex.action,
                            inputAction: regex.inputAction,
                            inputEnabled: regex.inputEnabled,
                            outputAction: regex.outputAction,
                            outputEnabled: regex.outputEnabled,
                        };
                    });
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the Pii filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnPiiEntitiesConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    return this.piiFilters.flatMap((filter) => {
                        return {
                            type: filter.type.value,
                            action: filter.action,
                            inputAction: filter.inputAction,
                            inputEnabled: filter.inputEnabled,
                            outputAction: filter.outputAction,
                            outputEnabled: filter.outputEnabled,
                        };
                    });
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the cross-region configuration for the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnCrossRegionConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.crossRegionConfig) {
                        return {
                            guardrailProfileArn: this.crossRegionConfig.guardrailProfileArn,
                        };
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Validates a RegexFilter object and applies default values for optional properties.
         * @param filter The regex filter to validate.
         * @param index Optional index for error messages when validating arrays.
         */
        validateRegexFilter(filter, index) {
            const prefix = index !== undefined ? `Invalid RegexFilter at index ${index}` : 'Invalid RegexFilter';
            // Validate name: between 1 and 100 characters
            if (filter.name !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.name)) {
                if (filter.name.length < 1) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `RegexFilterNameTooShort`, `${prefix}: The field name is ${filter.name.length} characters long but must be at least 1 characters`, this);
                }
                if (filter.name.length > 100) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `RegexFilterNameTooLong`, `${prefix}: The field name is ${filter.name.length} characters long but must be less than or equal to 100 characters`, this);
                }
            }
            // Validate description: between 1 and 1000 characters (if provided)
            if (filter.description !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.description)) {
                if (filter.description.length < 1) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `RegexFilterDescriptionTooShort`, `${prefix}: The field description is ${filter.description.length} characters long but must be at least 1 characters`, this);
                }
                if (filter.description.length > 1000) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `RegexFilterDescriptionTooLong`, `${prefix}: The field description is ${filter.description.length} characters long but must be less than or equal to 1000 characters`, this);
                }
            }
            // Validate pattern: at least one character
            if (filter.pattern !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.pattern)) {
                if (filter.pattern.length < 1) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `RegexFilterPatternEmpty`, `${prefix}: The field pattern is ${filter.pattern.length} characters long but must be at least 1 characters`, this);
                }
            }
            // Validate action: must be a valid GuardrailAction value
            if (filter.action !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.action) && !Object.values(filters.GuardrailAction).includes(filter.action)) {
                throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidGuardrailAction`, `${prefix}: action must be a valid GuardrailAction value`, this);
            }
            // Validate inputAction: must be a valid GuardrailAction value (if provided)
            if (filter.inputAction !== undefined &&
                !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidInputAction`, `${prefix}: inputAction must be a valid GuardrailAction value`, this);
            }
            // Validate outputAction: must be a valid GuardrailAction value (if provided)
            if (filter.outputAction !== undefined &&
                !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidOutputAction`, `${prefix}: outputAction must be a valid GuardrailAction value`, this);
            }
            // Validate inputEnabled: must be a boolean (if provided)
            if (filter.inputEnabled !== undefined &&
                !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                typeof filter.inputEnabled !== 'boolean') {
                throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InputEnabledNotBoolean`, `${prefix}: inputEnabled must be a boolean value`, this);
            }
            // Validate outputEnabled: must be a boolean (if provided)
            if (filter.outputEnabled !== undefined &&
                !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                typeof filter.outputEnabled !== 'boolean') {
                throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `OutputEnabledNotBoolean`, `${prefix}: outputEnabled must be a boolean value`, this);
            }
            // Apply default values for optional properties if not provided
            if (filter.inputAction === undefined) {
                filter.inputAction = filters.GuardrailAction.BLOCK;
            }
            if (filter.inputEnabled === undefined) {
                filter.inputEnabled = true;
            }
            if (filter.outputAction === undefined) {
                filter.outputAction = filters.GuardrailAction.BLOCK;
            }
            if (filter.outputEnabled === undefined) {
                filter.outputEnabled = true;
            }
        }
        /**
         * Validates a messaging property (blockedInputMessaging or blockedOutputsMessaging).
         * @param value The messaging value to validate.
         * @param propertyName The name of the property being validated.
         */
        validateMessagingProperty(value, propertyName) {
            if (value !== undefined && !aws_cdk_lib_1.Token.isUnresolved(value)) {
                if (value.length < 1) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `MessagingPropertyTooShort`, `Invalid ${propertyName}: The field ${propertyName} is ${value.length} characters long but must be at least 1 characters`, this);
                }
                if (value.length > 500) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `MessagingPropertyTooLong`, `Invalid ${propertyName}: The field ${propertyName} is ${value.length} characters long but must be less than or equal to 500 characters`, this);
                }
            }
        }
        /**
         * Validates that cross-region configuration is provided when STANDARD tier is used.
         * @param props The guardrail properties to validate.
         */
        validateTierConfiguration(props) {
            const contentTierConfig = props.contentFiltersTierConfig ?? filters.TierConfig.CLASSIC;
            const topicsTierConfig = props.topicsTierConfig ?? filters.TierConfig.CLASSIC;
            const hasCrossRegionConfig = props.crossRegionConfig !== undefined;
            // Check if STANDARD tier is used for content filters
            if (contentTierConfig === filters.TierConfig.STANDARD && !hasCrossRegionConfig) {
                throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `StandardTierRequiresCrossRegion`, 'Cross-region configuration is required when using STANDARD tier for content filters. ' +
                    'Please provide a crossRegionConfig property with a valid guardrailProfileArn.', this);
            }
            // Check if STANDARD tier is used for topic filters
            if (topicsTierConfig === filters.TierConfig.STANDARD && !hasCrossRegionConfig) {
                throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `StandardTierRequiresCrossRegion`, 'Cross-region configuration is required when using STANDARD tier for topic filters. ' +
                    'Please provide a crossRegionConfig property with a valid guardrailProfileArn.', this);
            }
        }
        /**
         * Validates content filters array and applies default values for optional properties.
         * @param contentFilters The content filters to validate.
         */
        validateContentFilters(contentFilters) {
            if (!contentFilters)
                return;
            contentFilters.forEach((filter, index) => {
                const prefix = `Invalid ContentFilter at index ${index}`;
                // Validate that the filter has required properties
                if (!filter.type) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `ContentFilterTypeMissing`, `${prefix}: type is required`, this);
                }
                // Validate input strength
                if (filter.inputStrength !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.inputStrength)) {
                    if (!Object.values(filters.ContentFilterStrength).includes(filter.inputStrength)) {
                        throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidInputStrength`, `${prefix}: inputStrength must be a valid ContentFilterStrength value`, this);
                    }
                }
                // Validate output strength
                if (filter.outputStrength !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.outputStrength)) {
                    if (!Object.values(filters.ContentFilterStrength).includes(filter.outputStrength)) {
                        throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidOutputStrength`, `${prefix}: outputStrength must be a valid ContentFilterStrength value`, this);
                    }
                }
                // Validate input modalities
                if (filter.inputModalities) {
                    filter.inputModalities.forEach((modality, modalityIndex) => {
                        if (!Object.values(filters.ModalityType).includes(modality)) {
                            throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidInputModality`, `${prefix}: inputModalities[${modalityIndex}] must be a valid ModalityType value`, this);
                        }
                    });
                }
                // Validate output modalities
                if (filter.outputModalities) {
                    filter.outputModalities.forEach((modality, modalityIndex) => {
                        if (!Object.values(filters.ModalityType).includes(modality)) {
                            throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidOutputModality`, `${prefix}: outputModalities[${modalityIndex}] must be a valid ModalityType value`, this);
                        }
                    });
                }
                // Validate inputAction: must be a valid GuardrailAction value (if provided)
                if (filter.inputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidInputAction`, `${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                // Validate outputAction: must be a valid GuardrailAction value (if provided)
                if (filter.outputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidOutputAction`, `${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (filter.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                    typeof filter.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InputEnabledNotBoolean`, `${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (filter.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                    typeof filter.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `OutputEnabledNotBoolean`, `${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.inputAction === undefined) {
                    filter.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.inputEnabled === undefined) {
                    filter.inputEnabled = true;
                }
                if (filter.outputAction === undefined) {
                    filter.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.outputEnabled === undefined) {
                    filter.outputEnabled = true;
                }
            });
        }
        /**
         * Validates PII filters array and applies default values for optional properties.
         * @param piiFilters The PII filters to validate.
         */
        validatePiiFilters(piiFilters) {
            if (!piiFilters)
                return;
            piiFilters.forEach((filter, index) => {
                const prefix = `Invalid PIIFilter at index ${index}`;
                // Validate that the filter has required properties
                if (!filter.type) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `PiiFilterTypeMissing`, `${prefix}: type is required`, this);
                }
                if (!filter.action) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `PiiFilterActionMissing`, `${prefix}: action is required`, this);
                }
                // Validate action values
                if (!aws_cdk_lib_1.Token.isUnresolved(filter.action) && !Object.values(filters.GuardrailAction).includes(filter.action)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidGuardrailAction`, `${prefix}: action must be a valid GuardrailAction value`, this);
                }
                if (filter.inputAction &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidInputAction`, `${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                if (filter.outputAction &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidOutputAction`, `${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (filter.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                    typeof filter.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InputEnabledNotBoolean`, `${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (filter.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                    typeof filter.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `OutputEnabledNotBoolean`, `${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.inputAction === undefined) {
                    filter.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.inputEnabled === undefined) {
                    filter.inputEnabled = true;
                }
                if (filter.outputAction === undefined) {
                    filter.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.outputEnabled === undefined) {
                    filter.outputEnabled = true;
                }
            });
        }
        /**
         * Validates regex filters array.
         * @param regexFilters The regex filters to validate.
         */
        validateRegexFilters(regexFilters) {
            if (!regexFilters)
                return;
            regexFilters.forEach((filter, index) => {
                this.validateRegexFilter(filter, index);
            });
        }
        /**
         * Validates denied topics array and applies default values for optional properties.
         * @param deniedTopics The denied topics to validate.
         */
        validateDeniedTopics(deniedTopics) {
            if (!deniedTopics)
                return;
            deniedTopics.forEach((topic, index) => {
                const prefix = `Invalid Topic at index ${index}`;
                // Validate that the topic has required properties
                if (!topic.name) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `TopicNameMissing`, `${prefix}: name is required`, this);
                }
                if (!topic.definition) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `TopicDefinitionMissing`, `${prefix}: definition is required`, this);
                }
                // Validate name length
                if (!aws_cdk_lib_1.Token.isUnresolved(topic.name) && topic.name.length > 100) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `TopicNameTooLong`, `${prefix}: name must be 100 characters or less`, this);
                }
                // Validate definition length
                if (!aws_cdk_lib_1.Token.isUnresolved(topic.definition) && topic.definition.length > 1000) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `TopicDefinitionTooLong`, `${prefix}: definition must be 1000 characters or less`, this);
                }
                // Validate examples if provided
                if (topic.examples) {
                    if (topic.examples.length > 100) {
                        throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `TopicExamplesTooMany`, `${prefix}: examples array cannot contain more than 100 examples`, this);
                    }
                    topic.examples.forEach((example, exampleIndex) => {
                        if (!aws_cdk_lib_1.Token.isUnresolved(example) && example.length > 100) {
                            throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `TopicExampleTooLong`, `${prefix}: examples[${exampleIndex}] must be 100 characters or less`, this);
                        }
                    });
                }
                // Validate inputAction: must be a valid GuardrailAction value (if provided)
                if (topic.inputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(topic.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(topic.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidInputAction`, `${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                // Validate outputAction: must be a valid GuardrailAction value (if provided)
                if (topic.outputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(topic.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(topic.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidOutputAction`, `${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (topic.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(topic.inputEnabled) &&
                    typeof topic.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InputEnabledNotBoolean`, `${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (topic.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(topic.outputEnabled) &&
                    typeof topic.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `OutputEnabledNotBoolean`, `${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (topic.inputAction === undefined) {
                    topic.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (topic.inputEnabled === undefined) {
                    topic.inputEnabled = true;
                }
                if (topic.outputAction === undefined) {
                    topic.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (topic.outputEnabled === undefined) {
                    topic.outputEnabled = true;
                }
            });
        }
        /**
         * Validates contextual grounding filters array and applies default values for optional properties.
         * @param contextualGroundingFilters The contextual grounding filters to validate.
         */
        validateContextualGroundingFilters(contextualGroundingFilters) {
            if (!contextualGroundingFilters)
                return;
            contextualGroundingFilters.forEach((filter, index) => {
                const prefix = `Invalid ContextualGroundingFilter at index ${index}`;
                // Validate that the filter has required properties
                if (!filter.type) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `ContextualGroundingFilterTypeMissing`, `${prefix}: type is required`, this);
                }
                if (filter.threshold === undefined) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `ContextualGroundingFilterThresholdMissing`, `${prefix}: threshold is required`, this);
                }
                // Validate type
                if (!Object.values(filters.ContextualGroundingFilterType).includes(filter.type)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidContextualGroundingFilterType`, `${prefix}: type must be a valid ContextualGroundingFilterType value`, this);
                }
                // Validate threshold range
                if (!aws_cdk_lib_1.Token.isUnresolved(filter.threshold)) {
                    if (filter.threshold < 0 || filter.threshold > 0.99) {
                        throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `ContextualGroundingFilterThresholdOutOfRange`, `${prefix}: threshold must be between 0 and 0.99`, this);
                    }
                }
                // Validate action: must be a valid GuardrailAction value (if provided)
                if (filter.action !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.action) &&
                    !Object.values(filters.GuardrailAction).includes(filter.action)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidGuardrailAction`, `${prefix}: action must be a valid GuardrailAction value`, this);
                }
                // Validate enabled: must be a boolean (if provided)
                if (filter.enabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.enabled) &&
                    typeof filter.enabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `EnabledNotBoolean`, `${prefix}: enabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.action === undefined) {
                    filter.action = filters.GuardrailAction.BLOCK;
                }
                if (filter.enabled === undefined) {
                    filter.enabled = true;
                }
            });
        }
        /**
         * Validates word filters array and applies default values for optional properties.
         * @param wordFilters The word filters to validate.
         */
        validateWordFilters(wordFilters) {
            if (!wordFilters)
                return;
            wordFilters.forEach((filter, index) => {
                const prefix = `Invalid WordFilter at index ${index}`;
                // Validate that the filter has required properties
                if (!filter.text) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `WordFilterTextMissing`, `${prefix}: text is required`, this);
                }
                // Validate text length
                if (!aws_cdk_lib_1.Token.isUnresolved(filter.text) && filter.text.length > 100) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `WordFilterTextTooLong`, `${prefix}: text must be 100 characters or less`, this);
                }
                // Validate inputAction: must be a valid GuardrailAction value (if provided)
                if (filter.inputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidInputAction`, `${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                // Validate outputAction: must be a valid GuardrailAction value (if provided)
                if (filter.outputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidOutputAction`, `${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (filter.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                    typeof filter.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InputEnabledNotBoolean`, `${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (filter.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                    typeof filter.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `OutputEnabledNotBoolean`, `${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.inputAction === undefined) {
                    filter.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.inputEnabled === undefined) {
                    filter.inputEnabled = true;
                }
                if (filter.outputAction === undefined) {
                    filter.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.outputEnabled === undefined) {
                    filter.outputEnabled = true;
                }
            });
        }
        /**
         * Validates managed word list filters array and applies default values for optional properties.
         * @param managedWordListFilters The managed word list filters to validate.
         */
        validateManagedWordListFilters(managedWordListFilters) {
            if (!managedWordListFilters)
                return;
            managedWordListFilters.forEach((filter, index) => {
                const prefix = `Invalid ManagedWordFilter at index ${index}`;
                // Validate type: must be a valid ManagedWordFilterType value (if provided)
                if (filter.type !== undefined && !Object.values(filters.ManagedWordFilterType).includes(filter.type)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidManagedWordFilterType`, `${prefix}: type must be a valid ManagedWordFilterType value`, this);
                }
                // Validate inputAction: must be a valid GuardrailAction value (if provided)
                if (filter.inputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidInputAction`, `${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                // Validate outputAction: must be a valid GuardrailAction value (if provided)
                if (filter.outputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InvalidOutputAction`, `${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (filter.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                    typeof filter.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `InputEnabledNotBoolean`, `${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (filter.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                    typeof filter.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError((0, helpers_internal_2.lit) `OutputEnabledNotBoolean`, `${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.type === undefined) {
                    filter.type = filters.ManagedWordFilterType.PROFANITY;
                }
                if (filter.inputAction === undefined) {
                    filter.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.inputEnabled === undefined) {
                    filter.inputEnabled = true;
                }
                if (filter.outputAction === undefined) {
                    filter.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.outputEnabled === undefined) {
                    filter.outputEnabled = true;
                }
            });
        }
        /**
         * Validates a single content filter and applies default values for optional properties.
         * @param filter The content filter to validate.
         */
        validateSingleContentFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateContentFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single PII filter and applies default values for optional properties.
         * @param filter The PII filter to validate.
         */
        validateSinglePiiFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validatePiiFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single regex filter and applies default values for optional properties.
         * @param filter The regex filter to validate.
         */
        validateSingleRegexFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateRegexFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single denied topic and applies default values for optional properties.
         * @param filter The denied topic to validate.
         */
        validateSingleDeniedTopic(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateDeniedTopics([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single contextual grounding filter and applies default values for optional properties.
         * @param filter The contextual grounding filter to validate.
         */
        validateSingleContextualGroundingFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateContextualGroundingFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single word filter and applies default values for optional properties.
         * @param filter The word filter to validate.
         */
        validateSingleWordFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateWordFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single managed word list filter and applies default values for optional properties.
         * @param filter The managed word list filter to validate.
         */
        validateSingleManagedWordListFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateManagedWordListFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return Guardrail = _classThis;
})();
exports.Guardrail = Guardrail;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3VhcmRyYWlscy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImd1YXJkcmFpbHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsdUNBQXlCO0FBRXpCLDZDQUFxRjtBQUNyRixpRUFBbUQ7QUFFbkQsK0RBQW9EO0FBQ3BELHlEQUEyQztBQUUzQyxpREFBMEM7QUFDMUMsNEVBQWdFO0FBQ2hFLDRFQUFnRjtBQUNoRiw4RUFBOEY7QUFDOUYsMEVBQTBFO0FBRTFFLGdCQUFnQjtBQUNoQiw2REFBK0M7QUFDL0MsMkRBQXVEO0FBaUd2RDs7O0dBR0c7QUFDSCxNQUFzQixhQUFjLFNBQVEsc0JBQVE7O0lBQ2xEOzs7OztPQUtHO0lBQ0ksTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFrQixFQUFFLEtBQXFCO1FBQy9ELE9BQU8sSUFBSSx1QkFBTSxDQUFDO1lBQ2hCLFNBQVMsRUFBRSx3QkFBd0I7WUFDbkMsYUFBYSxFQUFFLEVBQUUsU0FBUyxFQUFFLGdCQUFnQixFQUFFO1lBQzlDLFVBQVU7WUFDVixHQUFHLEtBQUs7U0FDVCxDQUFDLENBQUM7S0FDSjtJQUVEOztPQUVHO0lBQ0ksTUFBTSxDQUFDLG9CQUFvQixDQUFDLEtBQXFCO1FBQ3RELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDN0M7SUFFRDs7T0FFRztJQUNJLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxLQUFxQjtRQUN4RCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQy9DO0lBRUQ7O09BRUc7SUFDSSxNQUFNLENBQUMsOEJBQThCLENBQUMsS0FBcUI7UUFDaEUsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQ3ZEO0lBRUQ7O09BRUc7SUFDSSxNQUFNLENBQUMsMEJBQTBCLENBQUMsS0FBcUI7UUFDNUQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQ25EO0lBRU8sUUFBUSxHQUFXLE9BQU8sQ0FBQztJQXdCbkM7OztPQUdHO0lBQ0gsSUFBVyxnQkFBZ0I7UUFDekIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0tBQ3RCO0lBRVMsYUFBYSxDQUFDLE9BQWU7UUFDckMsSUFBSSxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUM7S0FDekI7SUFFRDs7O09BR0c7SUFDSSxLQUFLLENBQUMsT0FBdUIsRUFBRSxHQUFHLE9BQWlCO1FBQ3hELE9BQU8sR0FBRyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUM7WUFDOUIsT0FBTztZQUNQLE9BQU87WUFDUCxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO1NBQ2xDLENBQUMsQ0FBQztLQUNKO0lBRUQ7OztPQUdHO0lBQ0ksVUFBVSxDQUFDLE9BQXVCO1FBQ3ZDLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLHdCQUF3QixDQUFDLENBQUM7UUFFaEUsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDaEIseUVBQXlFO1lBQ3pFLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDMUQsT0FBTyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3JDLENBQUM7YUFBTSxDQUFDO1lBQ04sbURBQW1EO1lBQ25ELE9BQU8sU0FBUyxDQUFDO1FBQ25CLENBQUM7S0FDRjtJQUVEOzs7OztPQUtHO0lBQ0ksTUFBTSxDQUFDLFVBQWtCLEVBQUUsS0FBcUI7UUFDckQsTUFBTSxXQUFXLEdBQWdCO1lBQy9CLFNBQVMsRUFBRSx3QkFBd0I7WUFDbkMsVUFBVTtZQUNWLGFBQWEsRUFBRSxFQUFFLFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLGdCQUFnQixFQUFFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUMzRixHQUFHLEtBQUs7U0FDVCxDQUFDO1FBQ0YsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0tBQzFDO0lBRUQ7O09BRUc7SUFDSSxpQkFBaUIsQ0FBQyxLQUFxQjtRQUM1QyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQzFDO0lBRUQ7O09BRUc7SUFDSSx1QkFBdUIsQ0FBQyxLQUFxQjtRQUNsRCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDaEQ7SUFFRDs7T0FFRztJQUNJLDRCQUE0QixDQUFDLEtBQXFCO1FBQ3ZELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsRUFBRSxLQUFLLENBQUMsQ0FBQztLQUNyRDtJQUVEOztPQUVHO0lBQ0ksNEJBQTRCLENBQUMsS0FBcUI7UUFDdkQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLHdCQUF3QixFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQ3JEO0lBRUQ7O09BRUc7SUFDSSx5QkFBeUIsQ0FBQyxLQUFxQjtRQUNwRCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMscUJBQXFCLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDbEQ7SUFFRDs7T0FFRztJQUNJLG1CQUFtQixDQUFDLEtBQXFCO1FBQzlDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDNUM7SUFFRDs7T0FFRztJQUNJLDJCQUEyQixDQUFDLEtBQXFCO1FBQ3RELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLENBQUMsQ0FBQztLQUNwRDtJQUVPLGVBQWUsQ0FBQyxLQUFrQjtRQUN4QyxPQUFPLElBQUksdUJBQU0sQ0FBQztZQUNoQixHQUFHLEtBQUs7WUFDUixNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU07WUFDMUMsT0FBTyxFQUFFLEtBQUssRUFBRSxPQUFPLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPO1NBQzlDLENBQUMsQ0FBQztLQUNKOztBQXBMSCxzQ0FxTEM7QUFnSEQ7OytFQUUrRTtBQUMvRTs7O0dBR0c7SUFFVSxTQUFTOzRCQURyQixvQ0FBa0I7Ozs7c0JBQ1ksYUFBYTs7Ozs7Ozs7Ozs7eUJBQXJCLFNBQVEsV0FBYTs7Ozs0Q0F5TnpDLElBQUEsa0NBQWMsR0FBRTt3Q0FVaEIsSUFBQSxrQ0FBYyxHQUFFOzBDQVVoQixJQUFBLGtDQUFjLEdBQUU7Z0RBVWhCLElBQUEsa0NBQWMsR0FBRTt3REFVaEIsSUFBQSxrQ0FBYyxHQUFFO3lDQVVoQixJQUFBLGtDQUFjLEdBQUU7aURBVWhCLElBQUEsa0NBQWMsR0FBRTtvREFlaEIsSUFBQSxrQ0FBYyxHQUFFO3lDQVdoQixJQUFBLGtDQUFjLEdBQUU7WUFyRmpCLG1NQUFPLGdCQUFnQiw2REFHdEI7WUFPRCx1TEFBTyxZQUFZLDZEQUdsQjtZQU9ELDZMQUFPLGNBQWMsNkRBR3BCO1lBT0QsK01BQU8sb0JBQW9CLDZEQUcxQjtZQU9ELHVPQUFPLDRCQUE0Qiw2REFHbEM7WUFPRCwwTEFBTyxhQUFhLDZEQUduQjtZQU9ELGtOQUFPLHFCQUFxQiw2REFRM0I7WUFPRCwyTkFBTyx3QkFBd0IsNkRBRzlCO1lBUUQsMExBQU8sYUFBYSw2REFRbkI7WUF4VEgsNktBZ3VDQzs7Ozs7UUEvdENDLHNDQUFzQztRQUMvQixNQUFNLENBQVUscUJBQXFCLEdBQVcsc0NBQXNDLENBQUM7UUFFOUY7O1dBRUc7UUFDSSxNQUFNLENBQUMsdUJBQXVCLENBQUMsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsS0FBMEI7Ozs7Ozs7Ozs7WUFDNUYsTUFBTSxNQUFPLFNBQVEsYUFBYTtnQkFDaEIsWUFBWSxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUM7Z0JBQ2xDLFdBQVcsR0FBRyxpQkFBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLHVCQUFTLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxZQUFhLENBQUM7Z0JBQ3pGLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO2dCQUN0QixXQUFXLEdBQUcsU0FBUyxDQUFDO2dCQUV4QztvQkFDRSxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUNqQixJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsSUFBSSxPQUFPLENBQUMsQ0FBQztnQkFDeEQsQ0FBQzthQUNGO1lBRUQsT0FBTyxJQUFJLE1BQU0sRUFBRSxDQUFDO1NBQ3JCO1FBRUQ7O1dBRUc7UUFDSSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsWUFBa0M7WUFDL0QsT0FBTyxJQUFJLENBQUMsS0FBTSxTQUFRLGFBQWE7Z0JBQ3JCLFlBQVksR0FBRyxZQUFZLENBQUMsZ0JBQWdCLENBQUM7Z0JBQzdDLFdBQVcsR0FBRyxZQUFZLENBQUMsZUFBZSxDQUFDO2dCQUMzQyxNQUFNLEdBQUcsWUFBWSxDQUFDLFNBQVM7b0JBQzdDLENBQUMsQ0FBQyxhQUFHLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxzQkFBc0IsRUFBRSxZQUFZLENBQUMsU0FBUyxDQUFDO29CQUN0RSxDQUFDLENBQUMsU0FBUyxDQUFDO2dCQUNFLFdBQVcsR0FBRyxZQUFZLENBQUMsYUFBYSxDQUFDO2dCQUV6RDtvQkFDRSxLQUFLLENBQUMsWUFBWSxFQUFFLG1CQUFtQixDQUFDLENBQUM7b0JBQ3pDLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUMvQyxDQUFDO2FBQ0YsQ0FBQyxFQUFFLENBQUM7U0FDTjtRQUVEOzs7V0FHRztRQUNhLFlBQVksR0E5Q2pCLG1EQUFTLENBOENpQjtRQUNyQzs7O1dBR0c7UUFDYSxXQUFXLENBQVM7UUFDcEM7O1dBRUc7UUFDYSxJQUFJLENBQVM7UUFDN0I7Ozs7V0FJRztRQUNhLE1BQU0sQ0FBUTtRQUM5Qjs7V0FFRztRQUNhLGNBQWMsQ0FBMEI7UUFDeEQ7O1dBRUc7UUFDYSxVQUFVLENBQXNCO1FBQ2hEOztXQUVHO1FBQ2EsWUFBWSxDQUF3QjtRQUNwRDs7V0FFRztRQUNhLFlBQVksQ0FBa0I7UUFDOUM7O1dBRUc7UUFDYSwwQkFBMEIsQ0FBc0M7UUFDaEY7O1dBRUc7UUFDYSxXQUFXLENBQXVCO1FBQ2xEOztXQUVHO1FBQ2Esc0JBQXNCLENBQThCO1FBQ3BFOztXQUVHO1FBQ2EsV0FBVyxDQUFVO1FBQ3JDOztXQUVHO1FBQ2EsSUFBSSxDQUFTO1FBQzdCOztXQUVHO1FBQ2MsVUFBVSxDQUF1QjtRQUVsRDs7O1dBR0c7UUFDYSxnQkFBZ0IsQ0FBcUI7UUFFckQ7Ozs7V0FJRztRQUNhLHdCQUF3QixDQUFxQjtRQUM3RDs7V0FFRztRQUNhLGlCQUFpQixDQUFzQztRQUV2RTs7O1dBR0c7UUFDYSxxQkFBcUIsQ0FBUztRQUU5Qzs7O1dBR0c7UUFDYSx1QkFBdUIsQ0FBUztRQUVoRCxZQUFZLEtBQWdCLEVBQUUsRUFBVSxFQUFFLEtBQXFCO1lBQzdELEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFO2dCQUNmLFlBQVksRUFBRSxLQUFLLENBQUMsYUFBYTthQUNsQyxDQUFDLENBQUM7Ozs7OzttREF2SU0sU0FBUzs7OztZQXdJbEIsbUNBQW1DO1lBQ25DLElBQUEsd0NBQW9CLEVBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRWxDLHlEQUF5RDtZQUN6RCw2QkFBNkI7WUFDN0IseURBQXlEO1lBQ3pELElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztZQUM5QixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQyxjQUFjLElBQUksRUFBRSxDQUFDO1lBQ2pELElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUM7WUFDekMsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUMsWUFBWSxJQUFJLEVBQUUsQ0FBQztZQUM3QyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxZQUFZLElBQUksRUFBRSxDQUFDO1lBQzdDLElBQUksQ0FBQywwQkFBMEIsR0FBRyxLQUFLLENBQUMsMEJBQTBCLElBQUksRUFBRSxDQUFDO1lBQ3pFLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUM7WUFDM0MsSUFBSSxDQUFDLHNCQUFzQixHQUFHLEtBQUssQ0FBQyxzQkFBc0IsSUFBSSxFQUFFLENBQUM7WUFDakUsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxnQkFBZ0IsSUFBSSxPQUFPLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztZQUM3RSxJQUFJLENBQUMsd0JBQXdCLEdBQUcsS0FBSyxDQUFDLHdCQUF3QixJQUFJLE9BQU8sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO1lBQzdGLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUMsaUJBQWlCLENBQUM7WUFDakQsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQyxxQkFBcUIsSUFBSSw4Q0FBOEMsQ0FBQztZQUMzRyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDLHVCQUF1QixJQUFJLHlFQUF5RSxDQUFDO1lBRTFJLHlEQUF5RDtZQUN6RCw2QkFBNkI7WUFDN0IseURBQXlEO1lBQ3pELElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDakQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUN6QyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQzdDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDN0MsSUFBSSxDQUFDLGtDQUFrQyxDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO1lBQ3pFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDM0MsSUFBSSxDQUFDLDhCQUE4QixDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1lBRWpFLHlEQUF5RDtZQUN6RCxnQ0FBZ0M7WUFDaEMseURBQXlEO1lBQ3pELElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMscUJBQXFCLEVBQUUsdUJBQXVCLENBQUMsQ0FBQztZQUNwRixJQUFJLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLHlCQUF5QixDQUFDLENBQUM7WUFFeEYseURBQXlEO1lBQ3pELDJDQUEyQztZQUMzQyx5REFBeUQ7WUFDekQsSUFBSSxDQUFDLHlCQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRXRDLHlEQUF5RDtZQUN6RCxnQ0FBZ0M7WUFDaEMseURBQXlEO1lBQ3pELElBQUksUUFBUSxHQUE4QjtnQkFDeEMsSUFBSSxFQUFFLEtBQUssQ0FBQyxhQUFhO2dCQUN6QixXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVc7Z0JBQzlCLFNBQVMsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU07Z0JBQy9CLHFCQUFxQixFQUFFLElBQUksQ0FBQyxxQkFBcUI7Z0JBQ2pELHVCQUF1QixFQUFFLElBQUksQ0FBQyx1QkFBdUI7Z0JBQ3JELGFBQWE7Z0JBQ2IsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLDRCQUE0QixFQUFFO2dCQUN0RCxtQkFBbUIsRUFBRSxJQUFJLENBQUMsOEJBQThCLEVBQUU7Z0JBQzFELCtCQUErQixFQUFFLElBQUksQ0FBQyxpQ0FBaUMsRUFBRTtnQkFDekUsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLHNCQUFzQixFQUFFO2dCQUNoRCxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsMkJBQTJCLEVBQUU7Z0JBQ3BELGdDQUFnQyxFQUFFLElBQUksQ0FBQywyQ0FBMkMsRUFBRTthQUNyRixDQUFDO1lBRUYsMERBQTBEO1lBQzFELElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBQSwwQkFBTyxFQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUU5Qyx5REFBeUQ7WUFDekQsbUJBQW1CO1lBQ25CLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsYUFBYSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBRTFFLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUM7WUFDbkQsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDO1lBQ3JELElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUNoRCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO1NBQ2xEO1FBRUQseURBQXlEO1FBQ3pELFVBQVU7UUFDVix5REFBeUQ7UUFDekQ7OztXQUdHO1FBRUksZ0JBQWdCLENBQUMsTUFBNkI7Ozs7Ozs7Ozs7WUFDbkQsSUFBSSxDQUFDLDJCQUEyQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3pDLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ2xDO1FBRUQ7OztXQUdHO1FBRUksWUFBWSxDQUFDLE1BQXlCOzs7Ozs7Ozs7O1lBQzNDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM5QjtRQUVEOzs7V0FHRztRQUVJLGNBQWMsQ0FBQyxNQUEyQjs7Ozs7Ozs7OztZQUMvQyxJQUFJLENBQUMseUJBQXlCLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDdkMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDaEM7UUFFRDs7O1dBR0c7UUFFSSxvQkFBb0IsQ0FBQyxNQUFxQjs7Ozs7Ozs7OztZQUMvQyxJQUFJLENBQUMseUJBQXlCLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDdkMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDaEM7UUFFRDs7O1dBR0c7UUFFSSw0QkFBNEIsQ0FBQyxNQUF5Qzs7Ozs7Ozs7OztZQUMzRSxJQUFJLENBQUMsdUNBQXVDLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLDBCQUEwQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM5QztRQUVEOzs7V0FHRztRQUVJLGFBQWEsQ0FBQyxNQUEwQjs7Ozs7Ozs7OztZQUM3QyxJQUFJLENBQUMsd0JBQXdCLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDdEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDL0I7UUFFRDs7O1dBR0c7UUFFSSxxQkFBcUIsQ0FBQyxRQUFnQixFQUMzQyxXQUFxQyxFQUNyQyxZQUFzQyxFQUN0QyxZQUFzQixFQUN0QixhQUF1Qjs7Ozs7Ozs7Ozs7WUFDdkIsTUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDdkQsTUFBTSxLQUFLLEdBQUcsWUFBWSxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM3QyxLQUFLLE1BQU0sSUFBSSxJQUFJLEtBQUs7Z0JBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLFlBQVksRUFBRSxZQUFZLEVBQUUsYUFBYSxFQUFFLENBQUMsQ0FBQztTQUN0SDtRQUVEOzs7V0FHRztRQUVJLHdCQUF3QixDQUFDLE1BQWlDOzs7Ozs7Ozs7O1lBQy9ELElBQUksQ0FBQyxtQ0FBbUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNqRCxJQUFJLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQzFDO1FBRUQ7Ozs7V0FJRztRQUVJLGFBQWEsQ0FBQyxXQUFvQjtZQUN2QyxNQUFNLFVBQVUsR0FBRyxJQUFJLG9DQUFnQixDQUFDLElBQUksRUFBRSxvQkFBb0IsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzFGLFdBQVcsRUFBRSxXQUFXO2dCQUN4QixTQUFTLEVBQUUsSUFBSTthQUNoQixDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ2hELE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO1NBQzlCO1FBRUQseURBQXlEO1FBQ3pELGlCQUFpQjtRQUNqQix5REFBeUQ7UUFDekQ7OztXQUdHO1FBQ0ssOEJBQThCO1lBQ3BDLE9BQU8sa0JBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQ2QsT0FBTyxFQUFFLEdBQUcsRUFBRTtvQkFDWixJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO3dCQUNuQyxNQUFNLG1CQUFtQixHQUFxRDs0QkFDNUUsYUFBYSxFQUFFLElBQUksQ0FBQyxjQUFjOzRCQUNsQyxHQUFHLENBQUMsSUFBSSxDQUFDLHdCQUF3QixJQUFJO2dDQUNuQyx3QkFBd0IsRUFBRTtvQ0FDeEIsUUFBUSxFQUFFLElBQUksQ0FBQyx3QkFBd0I7aUNBQ2lCOzZCQUMzRCxDQUFDO3lCQUNILENBQUM7d0JBRUYsT0FBTyxtQkFBbUIsQ0FBQztvQkFDN0IsQ0FBQzt5QkFBTSxDQUFDO3dCQUNOLE9BQU8sU0FBUyxDQUFDO29CQUNuQixDQUFDO2dCQUNILENBQUM7YUFDRixDQUFDLENBQUM7U0FDSjtRQUVEOzs7V0FHRztRQUNLLHNCQUFzQjtZQUM1QixPQUFPLGtCQUFJLENBQUMsR0FBRyxDQUFDO2dCQUNkLE9BQU8sRUFBRSxHQUFHLEVBQUU7b0JBQ1osSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQzt3QkFDakMsTUFBTSxpQkFBaUIsR0FBbUQ7NEJBQ3hFLFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQW9CLEVBQUUsRUFBRTtnQ0FDL0QsT0FBTztvQ0FDTCxVQUFVLEVBQUUsS0FBSyxDQUFDLFVBQVU7b0NBQzVCLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTtvQ0FDaEIsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRO29DQUN4QixJQUFJLEVBQUUsTUFBTTtvQ0FDWixXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVc7b0NBQzlCLFlBQVksRUFBRSxLQUFLLENBQUMsWUFBWTtvQ0FDaEMsWUFBWSxFQUFFLEtBQUssQ0FBQyxZQUFZO29DQUNoQyxhQUFhLEVBQUUsS0FBSyxDQUFDLGFBQWE7aUNBQ1MsQ0FBQzs0QkFDaEQsQ0FBQyxDQUFDOzRCQUNGLEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLElBQUk7Z0NBQzNCLGdCQUFnQixFQUFFO29DQUNoQixRQUFRLEVBQUUsSUFBSSxDQUFDLGdCQUFnQjtpQ0FDaUI7NkJBQ25ELENBQUM7eUJBQ0gsQ0FBQzt3QkFFRixPQUFPLGlCQUFpQixDQUFDO29CQUMzQixDQUFDO3lCQUFNLENBQUM7d0JBQ04sT0FBTyxTQUFTLENBQUM7b0JBQ25CLENBQUM7Z0JBQ0gsQ0FBQzthQUNGLENBQUMsQ0FBQztTQUNKO1FBRUQ7OztXQUdHO1FBQ0ssaUNBQWlDO1lBQ3ZDLE9BQU8sa0JBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQ2QsT0FBTyxFQUFFLEdBQUcsRUFBRTtvQkFDWixJQUFJLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7d0JBQy9DLE9BQU87NEJBQ0wsYUFBYSxFQUFFLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUF5QyxFQUFFLEVBQUU7Z0NBQ25HLE9BQU87b0NBQ0wsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJO29DQUNqQixTQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7b0NBQzNCLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtvQ0FDckIsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO2lDQUN3QyxDQUFDOzRCQUNwRSxDQUFDLENBQUM7eUJBQ0gsQ0FBQztvQkFDSixDQUFDO3lCQUFNLENBQUM7d0JBQ04sT0FBTyxTQUFTLENBQUM7b0JBQ25CLENBQUM7Z0JBQ0gsQ0FBQzthQUNGLENBQUMsQ0FBQztTQUNKO1FBRUQ7OztXQUdHO1FBQ0ssMkJBQTJCO1lBQ2pDLE9BQU8sa0JBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQ2QsT0FBTyxFQUFFLEdBQUcsRUFBRTtvQkFDWixJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsc0JBQXNCLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO3dCQUMxRSxPQUFPOzRCQUNMLFdBQVcsRUFBRSxJQUFJLENBQUMscUJBQXFCLEVBQUU7NEJBQ3pDLHNCQUFzQixFQUFFLElBQUksQ0FBQyxpQ0FBaUMsRUFBRTt5QkFDaEIsQ0FBQztvQkFDckQsQ0FBQzt5QkFBTSxDQUFDO3dCQUNOLE9BQU8sU0FBUyxDQUFDO29CQUNuQixDQUFDO2dCQUNILENBQUM7YUFDRixDQUFDLENBQUM7U0FDSjtRQUVEOzs7V0FHRztRQUNLLHFCQUFxQjtZQUMzQixPQUFPLGtCQUFJLENBQUMsR0FBRyxDQUNiO2dCQUNFLE9BQU8sRUFBRSxHQUFHLEVBQUU7b0JBQ1osT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQXdCLEVBQUUsRUFBRTt3QkFDM0QsT0FBTzs0QkFDTCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7NEJBQ2YsV0FBVyxFQUFFLElBQUksQ0FBQyxXQUFXOzRCQUM3QixZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVk7NEJBQy9CLFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDL0IsYUFBYSxFQUFFLElBQUksQ0FBQyxhQUFhO3lCQUNTLENBQUM7b0JBQy9DLENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7YUFDRixFQUNELEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxDQUN6QixDQUFDO1NBQ0g7UUFFRDs7O1dBR0c7UUFDSyxpQ0FBaUM7WUFDdkMsT0FBTyxrQkFBSSxDQUFDLEdBQUcsQ0FDYjtnQkFDRSxPQUFPLEVBQUUsR0FBRyxFQUFFO29CQUNaLE9BQU8sSUFBSSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQWlDLEVBQUUsRUFBRTt3QkFDL0UsT0FBTzs0QkFDTCxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7NEJBQ2pCLFdBQVcsRUFBRSxNQUFNLENBQUMsV0FBVzs0QkFDL0IsWUFBWSxFQUFFLE1BQU0sQ0FBQyxZQUFZOzRCQUNqQyxZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7NEJBQ2pDLGFBQWEsRUFBRSxNQUFNLENBQUMsYUFBYTt5QkFDZSxDQUFDO29CQUN2RCxDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDO2FBQ0YsRUFDRCxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsQ0FDekIsQ0FBQztTQUNIO1FBRUQ7OztXQUdHO1FBQ0ssMkNBQTJDO1lBQ2pELE9BQU8sa0JBQUksQ0FBQyxHQUFHLENBQ2I7Z0JBQ0UsT0FBTyxFQUFFLEdBQUcsRUFBRTtvQkFDWixJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQzt3QkFDL0QsT0FBTzs0QkFDTCxhQUFhLEVBQUUsSUFBSSxDQUFDLHdCQUF3QixFQUFFOzRCQUM5QyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsNEJBQTRCLEVBQUU7eUJBQ3ZELENBQUM7b0JBQ0osQ0FBQzt5QkFBTSxDQUFDO3dCQUNOLE9BQU8sU0FBUyxDQUFDO29CQUNuQixDQUFDO2dCQUNILENBQUM7YUFDRixFQUNELEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxDQUN6QixDQUFDO1NBQ0g7UUFFRDs7O1dBR0c7UUFDSyx3QkFBd0I7WUFDOUIsT0FBTyxrQkFBSSxDQUFDLEdBQUcsQ0FDYjtnQkFDRSxPQUFPLEVBQUUsR0FBRyxFQUFFO29CQUNaLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUEwQixFQUFFLEVBQUU7d0JBQzlELE9BQU87NEJBQ0wsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJOzRCQUNoQixXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVc7NEJBQzlCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTzs0QkFDdEIsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNOzRCQUNwQixXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVc7NEJBQzlCLFlBQVksRUFBRSxLQUFLLENBQUMsWUFBWTs0QkFDaEMsWUFBWSxFQUFFLEtBQUssQ0FBQyxZQUFZOzRCQUNoQyxhQUFhLEVBQUUsS0FBSyxDQUFDLGFBQWE7eUJBQ1MsQ0FBQztvQkFDaEQsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQzthQUNGLEVBQ0QsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLENBQ3pCLENBQUM7U0FDSDtRQUVEOzs7V0FHRztRQUNLLDRCQUE0QjtZQUNsQyxPQUFPLGtCQUFJLENBQUMsR0FBRyxDQUNiO2dCQUNFLE9BQU8sRUFBRSxHQUFHLEVBQUU7b0JBQ1osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQXlCLEVBQUUsRUFBRTt3QkFDM0QsT0FBTzs0QkFDTCxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLOzRCQUN2QixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07NEJBQ3JCLFdBQVcsRUFBRSxNQUFNLENBQUMsV0FBVzs0QkFDL0IsWUFBWSxFQUFFLE1BQU0sQ0FBQyxZQUFZOzRCQUNqQyxZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7NEJBQ2pDLGFBQWEsRUFBRSxNQUFNLENBQUMsYUFBYTt5QkFDWSxDQUFDO29CQUNwRCxDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDO2FBQ0YsRUFDRCxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsQ0FDekIsQ0FBQztTQUNIO1FBRUQ7OztXQUdHO1FBQ0ssNEJBQTRCO1lBQ2xDLE9BQU8sa0JBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQ2QsT0FBTyxFQUFFLEdBQUcsRUFBRTtvQkFDWixJQUFJLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO3dCQUMzQixPQUFPOzRCQUNMLG1CQUFtQixFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxtQkFBbUI7eUJBQ0wsQ0FBQztvQkFDL0QsQ0FBQzt5QkFBTSxDQUFDO3dCQUNOLE9BQU8sU0FBUyxDQUFDO29CQUNuQixDQUFDO2dCQUNILENBQUM7YUFDRixDQUFDLENBQUM7U0FDSjtRQUVEOzs7O1dBSUc7UUFDSyxtQkFBbUIsQ0FBQyxNQUEyQixFQUFFLEtBQWM7WUFDckUsTUFBTSxNQUFNLEdBQUcsS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsZ0NBQWdDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQztZQUVyRyw4Q0FBOEM7WUFDOUMsSUFBSSxNQUFNLENBQUMsSUFBSSxLQUFLLFNBQVMsSUFBSSxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO2dCQUNsRSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUMzQixNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEseUJBQXlCLEVBQUUsR0FBRyxNQUFNLHVCQUF1QixNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sb0RBQW9ELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3hLLENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQztvQkFDN0IsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHdCQUF3QixFQUFFLEdBQUcsTUFBTSx1QkFBdUIsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLG1FQUFtRSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN0TCxDQUFDO1lBQ0gsQ0FBQztZQUVELG9FQUFvRTtZQUNwRSxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7Z0JBQ2hGLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQ2xDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSxnQ0FBZ0MsRUFBRSxHQUFHLE1BQU0sOEJBQThCLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxvREFBb0QsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDN0wsQ0FBQztnQkFDRCxJQUFJLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLElBQUksRUFBRSxDQUFDO29CQUNyQyxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsK0JBQStCLEVBQUUsR0FBRyxNQUFNLDhCQUE4QixNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sb0VBQW9FLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzVNLENBQUM7WUFDSCxDQUFDO1lBRUQsMkNBQTJDO1lBQzNDLElBQUksTUFBTSxDQUFDLE9BQU8sS0FBSyxTQUFTLElBQUksQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztnQkFDeEUsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztvQkFDOUIsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHlCQUF5QixFQUFFLEdBQUcsTUFBTSwwQkFBMEIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLG9EQUFvRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUM5SyxDQUFDO1lBQ0gsQ0FBQztZQUVELHlEQUF5RDtZQUN6RCxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO2dCQUN6SSxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsd0JBQXdCLEVBQUUsR0FBRyxNQUFNLGdEQUFnRCxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzFILENBQUM7WUFFRCw0RUFBNEU7WUFDNUUsSUFBSSxNQUFNLENBQUMsV0FBVyxLQUFLLFNBQVM7Z0JBQ2hDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztnQkFDdkMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7Z0JBQ3pFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSxvQkFBb0IsRUFBRSxHQUFHLE1BQU0scURBQXFELEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDM0gsQ0FBQztZQUVELDZFQUE2RTtZQUM3RSxJQUFJLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUztnQkFDakMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDO2dCQUN4QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztnQkFDMUUsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHFCQUFxQixFQUFFLEdBQUcsTUFBTSxzREFBc0QsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUM3SCxDQUFDO1lBRUQseURBQXlEO1lBQ3pELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTO2dCQUNqQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7Z0JBQ3hDLE9BQU8sTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDN0MsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHdCQUF3QixFQUFFLEdBQUcsTUFBTSx3Q0FBd0MsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNsSCxDQUFDO1lBRUQsMERBQTBEO1lBQzFELElBQUksTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTO2dCQUNsQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7Z0JBQ3pDLE9BQU8sTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDOUMsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHlCQUF5QixFQUFFLEdBQUcsTUFBTSx5Q0FBeUMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNwSCxDQUFDO1lBRUQsK0RBQStEO1lBQy9ELElBQUksTUFBTSxDQUFDLFdBQVcsS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDcEMsTUFBYyxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztZQUM5RCxDQUFDO1lBQ0QsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO2dCQUNyQyxNQUFjLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztZQUN0QyxDQUFDO1lBQ0QsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO2dCQUNyQyxNQUFjLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO1lBQy9ELENBQUM7WUFDRCxJQUFJLE1BQU0sQ0FBQyxhQUFhLEtBQUssU0FBUyxFQUFFLENBQUM7Z0JBQ3RDLE1BQWMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1lBQ3ZDLENBQUM7U0FDRjtRQUVEOzs7O1dBSUc7UUFDSyx5QkFBeUIsQ0FBQyxLQUF5QixFQUFFLFlBQW9CO1lBQy9FLElBQUksS0FBSyxLQUFLLFNBQVMsSUFBSSxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3RELElBQUksS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztvQkFDckIsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLDJCQUEyQixFQUFFLFdBQVcsWUFBWSxlQUFlLFlBQVksT0FBTyxLQUFLLENBQUMsTUFBTSxvREFBb0QsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDN0wsQ0FBQztnQkFDRCxJQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7b0JBQ3ZCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSwwQkFBMEIsRUFBRSxXQUFXLFlBQVksZUFBZSxZQUFZLE9BQU8sS0FBSyxDQUFDLE1BQU0sbUVBQW1FLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzNNLENBQUM7WUFDSCxDQUFDO1NBQ0Y7UUFFRDs7O1dBR0c7UUFDSyx5QkFBeUIsQ0FBQyxLQUFxQjtZQUNyRCxNQUFNLGlCQUFpQixHQUFHLEtBQUssQ0FBQyx3QkFBd0IsSUFBSSxPQUFPLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztZQUN2RixNQUFNLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxnQkFBZ0IsSUFBSSxPQUFPLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztZQUM5RSxNQUFNLG9CQUFvQixHQUFHLEtBQUssQ0FBQyxpQkFBaUIsS0FBSyxTQUFTLENBQUM7WUFFbkUscURBQXFEO1lBQ3JELElBQUksaUJBQWlCLEtBQUssT0FBTyxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2dCQUMvRSxNQUFNLElBQUksNkJBQWUsQ0FDdkIsSUFBQSxzQkFBRyxFQUFBLGlDQUFpQyxFQUNwQyx1RkFBdUY7b0JBQ3ZGLCtFQUErRSxFQUMvRSxJQUFJLENBQ0wsQ0FBQztZQUNKLENBQUM7WUFFRCxtREFBbUQ7WUFDbkQsSUFBSSxnQkFBZ0IsS0FBSyxPQUFPLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7Z0JBQzlFLE1BQU0sSUFBSSw2QkFBZSxDQUN2QixJQUFBLHNCQUFHLEVBQUEsaUNBQWlDLEVBQ3BDLHFGQUFxRjtvQkFDckYsK0VBQStFLEVBQy9FLElBQUksQ0FDTCxDQUFDO1lBQ0osQ0FBQztTQUNGO1FBRUQ7OztXQUdHO1FBQ0ssc0JBQXNCLENBQUMsY0FBd0M7WUFDckUsSUFBSSxDQUFDLGNBQWM7Z0JBQUUsT0FBTztZQUU1QixjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFO2dCQUN2QyxNQUFNLE1BQU0sR0FBRyxrQ0FBa0MsS0FBSyxFQUFFLENBQUM7Z0JBRXpELG1EQUFtRDtnQkFDbkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDakIsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLDBCQUEwQixFQUFFLEdBQUcsTUFBTSxvQkFBb0IsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDaEcsQ0FBQztnQkFFRCwwQkFBMEI7Z0JBQzFCLElBQUksTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTLElBQUksQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQztvQkFDcEYsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDO3dCQUNqRixNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsc0JBQXNCLEVBQUUsR0FBRyxNQUFNLDZEQUE2RCxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUNySSxDQUFDO2dCQUNILENBQUM7Z0JBRUQsMkJBQTJCO2dCQUMzQixJQUFJLE1BQU0sQ0FBQyxjQUFjLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUM7b0JBQ3RGLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQzt3QkFDbEYsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHVCQUF1QixFQUFFLEdBQUcsTUFBTSw4REFBOEQsRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDdkksQ0FBQztnQkFDSCxDQUFDO2dCQUVELDRCQUE0QjtnQkFDNUIsSUFBSSxNQUFNLENBQUMsZUFBZSxFQUFFLENBQUM7b0JBQzNCLE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxFQUFFLGFBQWEsRUFBRSxFQUFFO3dCQUN6RCxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7NEJBQzVELE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSxzQkFBc0IsRUFBRSxHQUFHLE1BQU0scUJBQXFCLGFBQWEsc0NBQXNDLEVBQUUsSUFBSSxDQUFDLENBQUM7d0JBQ2hKLENBQUM7b0JBQ0gsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQztnQkFFRCw2QkFBNkI7Z0JBQzdCLElBQUksTUFBTSxDQUFDLGdCQUFnQixFQUFFLENBQUM7b0JBQzVCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLEVBQUUsYUFBYSxFQUFFLEVBQUU7d0JBQzFELElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQzs0QkFDNUQsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHVCQUF1QixFQUFFLEdBQUcsTUFBTSxzQkFBc0IsYUFBYSxzQ0FBc0MsRUFBRSxJQUFJLENBQUMsQ0FBQzt3QkFDbEosQ0FBQztvQkFDSCxDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDO2dCQUVELDRFQUE0RTtnQkFDNUUsSUFBSSxNQUFNLENBQUMsV0FBVyxLQUFLLFNBQVM7b0JBQ2hDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztvQkFDdkMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7b0JBQ3pFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSxvQkFBb0IsRUFBRSxHQUFHLE1BQU0scURBQXFELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzNILENBQUM7Z0JBRUQsNkVBQTZFO2dCQUM3RSxJQUFJLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUztvQkFDakMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDO29CQUN4QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztvQkFDMUUsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHFCQUFxQixFQUFFLEdBQUcsTUFBTSxzREFBc0QsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDN0gsQ0FBQztnQkFFRCx5REFBeUQ7Z0JBQ3pELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTO29CQUNqQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7b0JBQ3hDLE9BQU8sTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDN0MsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHdCQUF3QixFQUFFLEdBQUcsTUFBTSx3Q0FBd0MsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDbEgsQ0FBQztnQkFFRCwwREFBMEQ7Z0JBQzFELElBQUksTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTO29CQUNsQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7b0JBQ3pDLE9BQU8sTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDOUMsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHlCQUF5QixFQUFFLEdBQUcsTUFBTSx5Q0FBeUMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDcEgsQ0FBQztnQkFFRCwrREFBK0Q7Z0JBQy9ELElBQUksTUFBTSxDQUFDLFdBQVcsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDcEMsTUFBYyxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztnQkFDOUQsQ0FBQztnQkFDRCxJQUFJLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3JDLE1BQWMsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO2dCQUN0QyxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDckMsTUFBYyxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztnQkFDL0QsQ0FBQztnQkFDRCxJQUFJLE1BQU0sQ0FBQyxhQUFhLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3RDLE1BQWMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO2dCQUN2QyxDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUVEOzs7V0FHRztRQUNLLGtCQUFrQixDQUFDLFVBQWdDO1lBQ3pELElBQUksQ0FBQyxVQUFVO2dCQUFFLE9BQU87WUFFeEIsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDbkMsTUFBTSxNQUFNLEdBQUcsOEJBQThCLEtBQUssRUFBRSxDQUFDO2dCQUVyRCxtREFBbUQ7Z0JBQ25ELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2pCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSxzQkFBc0IsRUFBRSxHQUFHLE1BQU0sb0JBQW9CLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzVGLENBQUM7Z0JBRUQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQztvQkFDbkIsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHdCQUF3QixFQUFFLEdBQUcsTUFBTSxzQkFBc0IsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDaEcsQ0FBQztnQkFFRCx5QkFBeUI7Z0JBQ3pCLElBQUksQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7b0JBQzFHLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSx3QkFBd0IsRUFBRSxHQUFHLE1BQU0sZ0RBQWdELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzFILENBQUM7Z0JBRUQsSUFBSSxNQUFNLENBQUMsV0FBVztvQkFDbEIsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO29CQUN2QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztvQkFDekUsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLG9CQUFvQixFQUFFLEdBQUcsTUFBTSxxREFBcUQsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDM0gsQ0FBQztnQkFFRCxJQUFJLE1BQU0sQ0FBQyxZQUFZO29CQUNuQixDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7b0JBQ3hDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO29CQUMxRSxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEscUJBQXFCLEVBQUUsR0FBRyxNQUFNLHNEQUFzRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUM3SCxDQUFDO2dCQUVELHlEQUF5RDtnQkFDekQsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVM7b0JBQ2pDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztvQkFDeEMsT0FBTyxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM3QyxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsd0JBQXdCLEVBQUUsR0FBRyxNQUFNLHdDQUF3QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNsSCxDQUFDO2dCQUVELDBEQUEwRDtnQkFDMUQsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVM7b0JBQ2xDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztvQkFDekMsT0FBTyxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM5QyxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEseUJBQXlCLEVBQUUsR0FBRyxNQUFNLHlDQUF5QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNwSCxDQUFDO2dCQUVELCtEQUErRDtnQkFDL0QsSUFBSSxNQUFNLENBQUMsV0FBVyxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNwQyxNQUFjLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO2dCQUM5RCxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDckMsTUFBYyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7Z0JBQ3RDLENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNyQyxNQUFjLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO2dCQUMvRCxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDdEMsTUFBYyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZDLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztTQUNKO1FBRUQ7OztXQUdHO1FBQ0ssb0JBQW9CLENBQUMsWUFBb0M7WUFDL0QsSUFBSSxDQUFDLFlBQVk7Z0JBQUUsT0FBTztZQUUxQixZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFO2dCQUNyQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzFDLENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7O1dBR0c7UUFDSyxvQkFBb0IsQ0FBQyxZQUE4QjtZQUN6RCxJQUFJLENBQUMsWUFBWTtnQkFBRSxPQUFPO1lBRTFCLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUU7Z0JBQ3BDLE1BQU0sTUFBTSxHQUFHLDBCQUEwQixLQUFLLEVBQUUsQ0FBQztnQkFFakQsa0RBQWtEO2dCQUNsRCxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNoQixNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsa0JBQWtCLEVBQUUsR0FBRyxNQUFNLG9CQUFvQixFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN4RixDQUFDO2dCQUVELElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7b0JBQ3RCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSx3QkFBd0IsRUFBRSxHQUFHLE1BQU0sMEJBQTBCLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3BHLENBQUM7Z0JBRUQsdUJBQXVCO2dCQUN2QixJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDO29CQUMvRCxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsa0JBQWtCLEVBQUUsR0FBRyxNQUFNLHVDQUF1QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMzRyxDQUFDO2dCQUVELDZCQUE2QjtnQkFDN0IsSUFBSSxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxJQUFJLEVBQUUsQ0FBQztvQkFDNUUsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHdCQUF3QixFQUFFLEdBQUcsTUFBTSw4Q0FBOEMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDeEgsQ0FBQztnQkFFRCxnQ0FBZ0M7Z0JBQ2hDLElBQUksS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUNuQixJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDO3dCQUNoQyxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsc0JBQXNCLEVBQUUsR0FBRyxNQUFNLHdEQUF3RCxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUNoSSxDQUFDO29CQUVELEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBRSxFQUFFO3dCQUMvQyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksT0FBTyxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQzs0QkFDekQsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHFCQUFxQixFQUFFLEdBQUcsTUFBTSxjQUFjLFlBQVksa0NBQWtDLEVBQUUsSUFBSSxDQUFDLENBQUM7d0JBQ25JLENBQUM7b0JBQ0gsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQztnQkFFRCw0RUFBNEU7Z0JBQzVFLElBQUksS0FBSyxDQUFDLFdBQVcsS0FBSyxTQUFTO29CQUMvQixDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUM7b0JBQ3RDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDO29CQUN4RSxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsb0JBQW9CLEVBQUUsR0FBRyxNQUFNLHFEQUFxRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMzSCxDQUFDO2dCQUVELDZFQUE2RTtnQkFDN0UsSUFBSSxLQUFLLENBQUMsWUFBWSxLQUFLLFNBQVM7b0JBQ2hDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQztvQkFDdkMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7b0JBQ3pFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSxxQkFBcUIsRUFBRSxHQUFHLE1BQU0sc0RBQXNELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzdILENBQUM7Z0JBRUQseURBQXlEO2dCQUN6RCxJQUFJLEtBQUssQ0FBQyxZQUFZLEtBQUssU0FBUztvQkFDaEMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDO29CQUN2QyxPQUFPLEtBQUssQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQzVDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSx3QkFBd0IsRUFBRSxHQUFHLE1BQU0sd0NBQXdDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2xILENBQUM7Z0JBRUQsMERBQTBEO2dCQUMxRCxJQUFJLEtBQUssQ0FBQyxhQUFhLEtBQUssU0FBUztvQkFDakMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDO29CQUN4QyxPQUFPLEtBQUssQ0FBQyxhQUFhLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQzdDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSx5QkFBeUIsRUFBRSxHQUFHLE1BQU0seUNBQXlDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3BILENBQUM7Z0JBRUQsK0RBQStEO2dCQUMvRCxJQUFJLEtBQUssQ0FBQyxXQUFXLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ25DLEtBQWEsQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7Z0JBQzdELENBQUM7Z0JBQ0QsSUFBSSxLQUFLLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNwQyxLQUFhLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztnQkFDckMsQ0FBQztnQkFDRCxJQUFJLEtBQUssQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3BDLEtBQWEsQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7Z0JBQzlELENBQUM7Z0JBQ0QsSUFBSSxLQUFLLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNyQyxLQUFhLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztnQkFDdEMsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7O1dBR0c7UUFDSyxrQ0FBa0MsQ0FBQywwQkFBZ0U7WUFDekcsSUFBSSxDQUFDLDBCQUEwQjtnQkFBRSxPQUFPO1lBRXhDLDBCQUEwQixDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDbkQsTUFBTSxNQUFNLEdBQUcsOENBQThDLEtBQUssRUFBRSxDQUFDO2dCQUVyRSxtREFBbUQ7Z0JBQ25ELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2pCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSxzQ0FBc0MsRUFBRSxHQUFHLE1BQU0sb0JBQW9CLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzVHLENBQUM7Z0JBRUQsSUFBSSxNQUFNLENBQUMsU0FBUyxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNuQyxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsMkNBQTJDLEVBQUUsR0FBRyxNQUFNLHlCQUF5QixFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN0SCxDQUFDO2dCQUVELGdCQUFnQjtnQkFDaEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLDZCQUE2QixDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO29CQUNoRixNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsc0NBQXNDLEVBQUUsR0FBRyxNQUFNLDREQUE0RCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNwSixDQUFDO2dCQUVELDJCQUEyQjtnQkFDM0IsSUFBSSxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO29CQUMxQyxJQUFJLE1BQU0sQ0FBQyxTQUFTLEdBQUcsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxTQUFTLEdBQUcsSUFBSSxFQUFFLENBQUM7d0JBQ3BELE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSw4Q0FBOEMsRUFBRSxHQUFHLE1BQU0sd0NBQXdDLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQ3hJLENBQUM7Z0JBQ0gsQ0FBQztnQkFFRCx1RUFBdUU7Z0JBQ3ZFLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxTQUFTO29CQUMzQixDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7b0JBQ2xDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO29CQUNwRSxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsd0JBQXdCLEVBQUUsR0FBRyxNQUFNLGdEQUFnRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMxSCxDQUFDO2dCQUVELG9EQUFvRDtnQkFDcEQsSUFBSSxNQUFNLENBQUMsT0FBTyxLQUFLLFNBQVM7b0JBQzVCLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztvQkFDbkMsT0FBTyxNQUFNLENBQUMsT0FBTyxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUN4QyxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsbUJBQW1CLEVBQUUsR0FBRyxNQUFNLG1DQUFtQyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN4RyxDQUFDO2dCQUVELCtEQUErRDtnQkFDL0QsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUMvQixNQUFjLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO2dCQUN6RCxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLE9BQU8sS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDaEMsTUFBYyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7Z0JBQ2pDLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztTQUNKO1FBRUQ7OztXQUdHO1FBQ0ssbUJBQW1CLENBQUMsV0FBa0M7WUFDNUQsSUFBSSxDQUFDLFdBQVc7Z0JBQUUsT0FBTztZQUV6QixXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFO2dCQUNwQyxNQUFNLE1BQU0sR0FBRywrQkFBK0IsS0FBSyxFQUFFLENBQUM7Z0JBRXRELG1EQUFtRDtnQkFDbkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDakIsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLHVCQUF1QixFQUFFLEdBQUcsTUFBTSxvQkFBb0IsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDN0YsQ0FBQztnQkFFRCx1QkFBdUI7Z0JBQ3ZCLElBQUksQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7b0JBQ2pFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSx1QkFBdUIsRUFBRSxHQUFHLE1BQU0sdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2hILENBQUM7Z0JBRUQsNEVBQTRFO2dCQUM1RSxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUztvQkFDaEMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO29CQUN2QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztvQkFDekUsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLG9CQUFvQixFQUFFLEdBQUcsTUFBTSxxREFBcUQsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDM0gsQ0FBQztnQkFFRCw2RUFBNkU7Z0JBQzdFLElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTO29CQUNqQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7b0JBQ3hDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO29CQUMxRSxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEscUJBQXFCLEVBQUUsR0FBRyxNQUFNLHNEQUFzRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUM3SCxDQUFDO2dCQUVELHlEQUF5RDtnQkFDekQsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVM7b0JBQ2pDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztvQkFDeEMsT0FBTyxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM3QyxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsd0JBQXdCLEVBQUUsR0FBRyxNQUFNLHdDQUF3QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNsSCxDQUFDO2dCQUVELDBEQUEwRDtnQkFDMUQsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVM7b0JBQ2xDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztvQkFDekMsT0FBTyxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM5QyxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEseUJBQXlCLEVBQUUsR0FBRyxNQUFNLHlDQUF5QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNwSCxDQUFDO2dCQUVELCtEQUErRDtnQkFDL0QsSUFBSSxNQUFNLENBQUMsV0FBVyxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNwQyxNQUFjLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO2dCQUM5RCxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDckMsTUFBYyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7Z0JBQ3RDLENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNyQyxNQUFjLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO2dCQUMvRCxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDdEMsTUFBYyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZDLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztTQUNKO1FBRUQ7OztXQUdHO1FBQ0ssOEJBQThCLENBQUMsc0JBQW9EO1lBQ3pGLElBQUksQ0FBQyxzQkFBc0I7Z0JBQUUsT0FBTztZQUVwQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUU7Z0JBQy9DLE1BQU0sTUFBTSxHQUFHLHNDQUFzQyxLQUFLLEVBQUUsQ0FBQztnQkFFN0QsMkVBQTJFO2dCQUMzRSxJQUFJLE1BQU0sQ0FBQyxJQUFJLEtBQUssU0FBUyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7b0JBQ3JHLE1BQU0sSUFBSSw2QkFBZSxDQUFDLElBQUEsc0JBQUcsRUFBQSw4QkFBOEIsRUFBRSxHQUFHLE1BQU0sb0RBQW9ELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3BJLENBQUM7Z0JBRUQsNEVBQTRFO2dCQUM1RSxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUztvQkFDaEMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO29CQUN2QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztvQkFDekUsTUFBTSxJQUFJLDZCQUFlLENBQUMsSUFBQSxzQkFBRyxFQUFBLG9CQUFvQixFQUFFLEdBQUcsTUFBTSxxREFBcUQsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDM0gsQ0FBQztnQkFFRCw2RUFBNkU7Z0JBQzdFLElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTO29CQUNqQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7b0JBQ3hDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO29CQUMxRSxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEscUJBQXFCLEVBQUUsR0FBRyxNQUFNLHNEQUFzRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUM3SCxDQUFDO2dCQUVELHlEQUF5RDtnQkFDekQsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVM7b0JBQ2pDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztvQkFDeEMsT0FBTyxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM3QyxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEsd0JBQXdCLEVBQUUsR0FBRyxNQUFNLHdDQUF3QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNsSCxDQUFDO2dCQUVELDBEQUEwRDtnQkFDMUQsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVM7b0JBQ2xDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztvQkFDekMsT0FBTyxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM5QyxNQUFNLElBQUksNkJBQWUsQ0FBQyxJQUFBLHNCQUFHLEVBQUEseUJBQXlCLEVBQUUsR0FBRyxNQUFNLHlDQUF5QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNwSCxDQUFDO2dCQUVELCtEQUErRDtnQkFDL0QsSUFBSSxNQUFNLENBQUMsSUFBSSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM3QixNQUFjLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxTQUFTLENBQUM7Z0JBQ2pFLENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsV0FBVyxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNwQyxNQUFjLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO2dCQUM5RCxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDckMsTUFBYyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7Z0JBQ3RDLENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNyQyxNQUFjLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO2dCQUMvRCxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDdEMsTUFBYyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZDLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztTQUNKO1FBRUQ7OztXQUdHO1FBQ0ssMkJBQTJCLENBQUMsTUFBNkI7WUFDL0Qsd0ZBQXdGO1lBQ3hGLElBQUksQ0FBQztnQkFDSCxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ3hDLENBQUM7WUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO2dCQUNmLElBQUksS0FBSyxZQUFZLDZCQUFlLEVBQUUsQ0FBQztvQkFDckMsMkVBQTJFO29CQUMzRSxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ3pELE1BQU0sSUFBSSw2QkFBZSxDQUFDLEtBQUssQ0FBQyxJQUFxQixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDeEUsQ0FBQztnQkFDRCxNQUFNLEtBQUssQ0FBQztZQUNkLENBQUM7U0FDRjtRQUVEOzs7V0FHRztRQUNLLHVCQUF1QixDQUFDLE1BQXlCO1lBQ3ZELHdGQUF3RjtZQUN4RixJQUFJLENBQUM7Z0JBQ0gsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUNwQyxDQUFDO1lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztnQkFDZixJQUFJLEtBQUssWUFBWSw2QkFBZSxFQUFFLENBQUM7b0JBQ3JDLDJFQUEyRTtvQkFDM0UsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUN6RCxNQUFNLElBQUksNkJBQWUsQ0FBQyxLQUFLLENBQUMsSUFBcUIsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3hFLENBQUM7Z0JBQ0QsTUFBTSxLQUFLLENBQUM7WUFDZCxDQUFDO1NBQ0Y7UUFFRDs7O1dBR0c7UUFDSyx5QkFBeUIsQ0FBQyxNQUEyQjtZQUMzRCx3RkFBd0Y7WUFDeEYsSUFBSSxDQUFDO2dCQUNILElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDdEMsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxLQUFLLFlBQVksNkJBQWUsRUFBRSxDQUFDO29CQUNyQywyRUFBMkU7b0JBQzNFLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDekQsTUFBTSxJQUFJLDZCQUFlLENBQUMsS0FBSyxDQUFDLElBQXFCLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN4RSxDQUFDO2dCQUNELE1BQU0sS0FBSyxDQUFDO1lBQ2QsQ0FBQztTQUNGO1FBRUQ7OztXQUdHO1FBQ0sseUJBQXlCLENBQUMsTUFBcUI7WUFDckQsd0ZBQXdGO1lBQ3hGLElBQUksQ0FBQztnQkFDSCxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ3RDLENBQUM7WUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO2dCQUNmLElBQUksS0FBSyxZQUFZLDZCQUFlLEVBQUUsQ0FBQztvQkFDckMsMkVBQTJFO29CQUMzRSxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ3pELE1BQU0sSUFBSSw2QkFBZSxDQUFDLEtBQUssQ0FBQyxJQUFxQixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDeEUsQ0FBQztnQkFDRCxNQUFNLEtBQUssQ0FBQztZQUNkLENBQUM7U0FDRjtRQUVEOzs7V0FHRztRQUNLLHVDQUF1QyxDQUFDLE1BQXlDO1lBQ3ZGLHdGQUF3RjtZQUN4RixJQUFJLENBQUM7Z0JBQ0gsSUFBSSxDQUFDLGtDQUFrQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUNwRCxDQUFDO1lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztnQkFDZixJQUFJLEtBQUssWUFBWSw2QkFBZSxFQUFFLENBQUM7b0JBQ3JDLDJFQUEyRTtvQkFDM0UsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUN6RCxNQUFNLElBQUksNkJBQWUsQ0FBQyxLQUFLLENBQUMsSUFBcUIsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3hFLENBQUM7Z0JBQ0QsTUFBTSxLQUFLLENBQUM7WUFDZCxDQUFDO1NBQ0Y7UUFFRDs7O1dBR0c7UUFDSyx3QkFBd0IsQ0FBQyxNQUEwQjtZQUN6RCx3RkFBd0Y7WUFDeEYsSUFBSSxDQUFDO2dCQUNILElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDckMsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxLQUFLLFlBQVksNkJBQWUsRUFBRSxDQUFDO29CQUNyQywyRUFBMkU7b0JBQzNFLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDekQsTUFBTSxJQUFJLDZCQUFlLENBQUMsS0FBSyxDQUFDLElBQXFCLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN4RSxDQUFDO2dCQUNELE1BQU0sS0FBSyxDQUFDO1lBQ2QsQ0FBQztTQUNGO1FBRUQ7OztXQUdHO1FBQ0ssbUNBQW1DLENBQUMsTUFBaUM7WUFDM0Usd0ZBQXdGO1lBQ3hGLElBQUksQ0FBQztnQkFDSCxJQUFJLENBQUMsOEJBQThCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ2hELENBQUM7WUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO2dCQUNmLElBQUksS0FBSyxZQUFZLDZCQUFlLEVBQUUsQ0FBQztvQkFDckMsMkVBQTJFO29CQUMzRSxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ3pELE1BQU0sSUFBSSw2QkFBZSxDQUFDLEtBQUssQ0FBQyxJQUFxQixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDeEUsQ0FBQztnQkFDRCxNQUFNLEtBQUssQ0FBQztZQUNkLENBQUM7U0FDRjs7WUEvdENVLHVEQUFTOzs7OztBQUFULDhCQUFTIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgZnMgZnJvbSAnZnMnO1xuaW1wb3J0IHR5cGUgeyBJUmVzb2x2YWJsZSwgSVJlc291cmNlIH0gZnJvbSAnYXdzLWNkay1saWInO1xuaW1wb3J0IHsgQXJuLCBBcm5Gb3JtYXQsIExhenksIFJlc291cmNlLCBUb2tlbiwgVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnYXdzLWNkay1saWInO1xuaW1wb3J0ICogYXMgYmVkcm9jayBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgdHlwZSB7IE1ldHJpY09wdGlvbnMsIE1ldHJpY1Byb3BzIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWNsb3Vkd2F0Y2gnO1xuaW1wb3J0IHsgTWV0cmljIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWNsb3Vkd2F0Y2gnO1xuaW1wb3J0ICogYXMgaWFtIGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0IHR5cGUgeyBJS2V5IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWttcyc7XG5pbXBvcnQgeyBLZXkgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3Mta21zJztcbmltcG9ydCB7IG1kNWhhc2ggfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9oZWxwZXJzLWludGVybmFsJztcbmltcG9ydCB7IGxpdCwgdHlwZSBMaXRlcmFsU3RyaW5nIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvaGVscGVycy1pbnRlcm5hbCc7XG5pbXBvcnQgeyBhZGRDb25zdHJ1Y3RNZXRhZGF0YSwgTWV0aG9kTWV0YWRhdGEgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9tZXRhZGF0YS1yZXNvdXJjZSc7XG5pbXBvcnQgeyBwcm9wZXJ0eUluamVjdGFibGUgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9wcm9wLWluamVjdGFibGUnO1xuaW1wb3J0IHR5cGUgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcbi8vIEludGVybmFsIExpYnNcbmltcG9ydCAqIGFzIGZpbHRlcnMgZnJvbSAnLi9ndWFyZHJhaWwtZmlsdGVycyc7XG5pbXBvcnQgeyBHdWFyZHJhaWxWZXJzaW9uIH0gZnJvbSAnLi9ndWFyZHJhaWwtdmVyc2lvbic7XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ09NTU9OXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIEd1YXJkcmFpbENyb3NzUmVnaW9uQ29uZmlnUHJvcGVydHlcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBHdWFyZHJhaWxDcm9zc1JlZ2lvbkNvbmZpZ1Byb3BlcnR5IHtcbiAgLyoqXG4gICAqIFRoZSBhcm4gb2YgdGhlc3lzdGVtLWRlZmluZWQgZ3VhcmRyYWlsIHByb2ZpbGUgdGhhdCB5b3UncmUgdXNpbmcgd2l0aCB5b3VyIGd1YXJkcmFpbC5cbiAgICogR3VhcmRyYWlsIHByb2ZpbGVzIGRlZmluZSB0aGUgZGVzdGluYXRpb24gQVdTIFJlZ2lvbnMgd2hlcmUgZ3VhcmRyYWlsIGluZmVyZW5jZSByZXF1ZXN0cyBjYW4gYmUgYXV0b21hdGljYWxseSByb3V0ZWQuXG4gICAqIFVzaW5nIGd1YXJkcmFpbCBwcm9maWxlcyBoZWxwcyBtYWludGFpbiBndWFyZHJhaWwgcGVyZm9ybWFuY2UgYW5kIHJlbGlhYmlsaXR5IHdoZW4gZGVtYW5kIGluY3JlYXNlcy5cbiAgICogQGRlZmF1bHQgLSBObyBjcm9zcy1yZWdpb24gY29uZmlndXJhdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgZ3VhcmRyYWlsUHJvZmlsZUFybjogc3RyaW5nO1xufVxuXG4vKipcbiAqIFJlcHJlc2VudHMgYSBHdWFyZHJhaWwsIGVpdGhlciBjcmVhdGVkIHdpdGggQ0RLIG9yIGltcG9ydGVkLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIElHdWFyZHJhaWwgZXh0ZW5kcyBJUmVzb3VyY2Uge1xuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICByZWFkb25seSBndWFyZHJhaWxBcm46IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBJRCBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICByZWFkb25seSBndWFyZHJhaWxJZDogc3RyaW5nO1xuICAvKipcbiAgICogT3B0aW9uYWwgS01TIGVuY3J5cHRpb24ga2V5IGFzc29jaWF0ZWQgd2l0aCB0aGlzIGd1YXJkcmFpbFxuICAgKi9cbiAgcmVhZG9ubHkga21zS2V5PzogSUtleTtcbiAgLyoqXG4gICAqIFdoZW4gdGhpcyBndWFyZHJhaWwgd2FzIGxhc3QgdXBkYXRlZC5cbiAgICovXG4gIHJlYWRvbmx5IGxhc3RVcGRhdGVkPzogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHZlcnNpb24gb2YgdGhlIGd1YXJkcmFpbC4gSWYgbm8gZXhwbGljaXQgdmVyc2lvbiBpcyBjcmVhdGVkLFxuICAgKiB0aGlzIHdpbGwgZGVmYXVsdCB0byBcIkRSQUZUXCJcbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcmVhZG9ubHkgZ3VhcmRyYWlsVmVyc2lvbjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBHcmFudCB0aGUgZ2l2ZW4gcHJpbmNpcGFsIGlkZW50aXR5IHBlcm1pc3Npb25zIHRvIHBlcmZvcm0gYWN0aW9ucyBvbiB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIGdyYW50KGdyYW50ZWU6IGlhbS5JR3JhbnRhYmxlLCAuLi5hY3Rpb25zOiBzdHJpbmdbXSk6IGlhbS5HcmFudDtcbiAgLyoqXG4gICAqIEdyYW50IHRoZSBnaXZlbiBpZGVudGl0eSBwZXJtaXNzaW9ucyB0byBhcHBseSB0aGUgZ3VhcmRyYWlsLlxuICAgKi9cbiAgZ3JhbnRBcHBseShncmFudGVlOiBpYW0uSUdyYW50YWJsZSk6IGlhbS5HcmFudDtcblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBnaXZlbiBuYW1lZCBtZXRyaWMgZm9yIHRoaXMgZ3VhcmRyYWlsLlxuICAgKi9cbiAgbWV0cmljKG1ldHJpY05hbWU6IHN0cmluZywgcHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljO1xuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb25zIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBtZXRyaWNJbnZvY2F0aW9ucyhwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWM7XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbiBsYXRlbmN5IG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBtZXRyaWNJbnZvY2F0aW9uTGF0ZW5jeShwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWM7XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbiBjbGllbnQgZXJyb3JzIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBtZXRyaWNJbnZvY2F0aW9uQ2xpZW50RXJyb3JzKHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYztcblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBpbnZvY2F0aW9uIHNlcnZlciBlcnJvcnMgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIG1ldHJpY0ludm9jYXRpb25TZXJ2ZXJFcnJvcnMocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljO1xuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb24gdGhyb3R0bGVzIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBtZXRyaWNJbnZvY2F0aW9uVGhyb3R0bGVzKHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYztcblxuICAvKipcbiAgICogUmV0dXJuIHRoZSB0ZXh0IHVuaXQgY291bnQgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIG1ldHJpY1RleHRVbml0Q291bnQocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljO1xuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb25zIGludGVydmVuZWQgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIG1ldHJpY0ludm9jYXRpb25zSW50ZXJ2ZW5lZChwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWM7XG59XG5cbi8qKlxuICogQWJzdHJhY3QgYmFzZSBjbGFzcyBmb3IgYSBHdWFyZHJhaWwuXG4gKiBDb250YWlucyBtZXRob2RzIGFuZCBhdHRyaWJ1dGVzIHZhbGlkIGZvciBHdWFyZHJhaWxzIGVpdGhlciBjcmVhdGVkIHdpdGggQ0RLIG9yIGltcG9ydGVkLlxuICovXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgR3VhcmRyYWlsQmFzZSBleHRlbmRzIFJlc291cmNlIGltcGxlbWVudHMgSUd1YXJkcmFpbCB7XG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGdpdmVuIG5hbWVkIG1ldHJpYyBmb3IgYWxsIGd1YXJkcmFpbHMuXG4gICAqXG4gICAqIEJ5IGRlZmF1bHQsIHRoZSBtZXRyaWMgd2lsbCBiZSBjYWxjdWxhdGVkIGFzIGEgc3VtIG92ZXIgYSBwZXJpb2Qgb2YgNSBtaW51dGVzLlxuICAgKiBZb3UgY2FuIGN1c3RvbWl6ZSB0aGlzIGJ5IHVzaW5nIHRoZSBgc3RhdGlzdGljYCBhbmQgYHBlcmlvZGAgcHJvcGVydGllcy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWV0cmljQWxsKG1ldHJpY05hbWU6IHN0cmluZywgcHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gbmV3IE1ldHJpYyh7XG4gICAgICBuYW1lc3BhY2U6ICdBV1MvQmVkcm9jay9HdWFyZHJhaWxzJyxcbiAgICAgIGRpbWVuc2lvbnNNYXA6IHsgT3BlcmF0aW9uOiAnQXBwbHlHdWFyZHJhaWwnIH0sXG4gICAgICBtZXRyaWNOYW1lLFxuICAgICAgLi4ucHJvcHMsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBpbnZvY2F0aW9ucyBtZXRyaWMgZm9yIGFsbCBndWFyZHJhaWxzLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBtZXRyaWNBbGxJbnZvY2F0aW9ucyhwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiB0aGlzLm1ldHJpY0FsbCgnSW52b2NhdGlvbnMnLCBwcm9wcyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSB0ZXh0IHVuaXQgY291bnQgbWV0cmljIGZvciBhbGwgZ3VhcmRyYWlscy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWV0cmljQWxsVGV4dFVuaXRDb3VudChwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiB0aGlzLm1ldHJpY0FsbCgnVGV4dFVuaXRDb3VudCcsIHByb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb25zIGludGVydmVuZWQgbWV0cmljIGZvciBhbGwgZ3VhcmRyYWlscy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWV0cmljQWxsSW52b2NhdGlvbnNJbnRlcnZlbmVkKHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYyB7XG4gICAgcmV0dXJuIHRoaXMubWV0cmljQWxsKCdJbnZvY2F0aW9uc0ludGVydmVuZWQnLCBwcm9wcyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBpbnZvY2F0aW9uIGxhdGVuY3kgbWV0cmljIGZvciBhbGwgZ3VhcmRyYWlscy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWV0cmljQWxsSW52b2NhdGlvbkxhdGVuY3kocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gdGhpcy5tZXRyaWNBbGwoJ0ludm9jYXRpb25MYXRlbmN5JywgcHJvcHMpO1xuICB9XG5cbiAgcHJpdmF0ZSBfdmVyc2lvbjogc3RyaW5nID0gJ0RSQUZUJztcblxuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkgZ3VhcmRyYWlsQXJuOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBJRCBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkgZ3VhcmRyYWlsSWQ6IHN0cmluZztcblxuICAvKipcbiAgICogT3B0aW9uYWwgS01TIGVuY3J5cHRpb24ga2V5IGFzc29jaWF0ZWQgd2l0aCB0aGlzIGd1YXJkcmFpbFxuICAgKi9cbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGttc0tleT86IElLZXk7XG5cbiAgLyoqXG4gICAqIFdoZW4gdGhpcyBndWFyZHJhaWwgd2FzIGxhc3QgdXBkYXRlZC5cbiAgICovXG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSBsYXN0VXBkYXRlZD86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHZlcnNpb24gb2YgdGhlIGd1YXJkcmFpbC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIGdldCBndWFyZHJhaWxWZXJzaW9uKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMuX3ZlcnNpb247XG4gIH1cblxuICBwcm90ZWN0ZWQgdXBkYXRlVmVyc2lvbih2ZXJzaW9uOiBzdHJpbmcpIHtcbiAgICB0aGlzLl92ZXJzaW9uID0gdmVyc2lvbjtcbiAgfVxuXG4gIC8qKlxuICAgKiBHcmFudCB0aGUgZ2l2ZW4gcHJpbmNpcGFsIGlkZW50aXR5IHBlcm1pc3Npb25zIHRvIHBlcmZvcm0gYWN0aW9ucyBvbiB0aGlzIGd1YXJkcmFpbC5cbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqL1xuICBwdWJsaWMgZ3JhbnQoZ3JhbnRlZTogaWFtLklHcmFudGFibGUsIC4uLmFjdGlvbnM6IHN0cmluZ1tdKSB7XG4gICAgcmV0dXJuIGlhbS5HcmFudC5hZGRUb1ByaW5jaXBhbCh7XG4gICAgICBncmFudGVlLFxuICAgICAgYWN0aW9ucyxcbiAgICAgIHJlc291cmNlQXJuczogW3RoaXMuZ3VhcmRyYWlsQXJuXSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHcmFudCB0aGUgZ2l2ZW4gaWRlbnRpdHkgcGVybWlzc2lvbnMgdG8gYXBwbHkgdGhlIGd1YXJkcmFpbC5cbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqL1xuICBwdWJsaWMgZ3JhbnRBcHBseShncmFudGVlOiBpYW0uSUdyYW50YWJsZSk6IGlhbS5HcmFudCB7XG4gICAgY29uc3QgYmFzZUdyYW50ID0gdGhpcy5ncmFudChncmFudGVlLCAnYmVkcm9jazpBcHBseUd1YXJkcmFpbCcpO1xuXG4gICAgaWYgKHRoaXMua21zS2V5KSB7XG4gICAgICAvLyBJZiBLTVMga2V5IGV4aXN0cywgY3JlYXRlIGVuY3J5cHRpb24gZ3JhbnQgYW5kIGNvbWJpbmUgd2l0aCBiYXNlIGdyYW50XG4gICAgICBjb25zdCBrbXNHcmFudCA9IHRoaXMua21zS2V5LmdyYW50RW5jcnlwdERlY3J5cHQoZ3JhbnRlZSk7XG4gICAgICByZXR1cm4ga21zR3JhbnQuY29tYmluZShiYXNlR3JhbnQpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBJZiBubyBLTVMga2V5IGV4aXN0cywgcmV0dXJuIG9ubHkgdGhlIGJhc2UgZ3JhbnRcbiAgICAgIHJldHVybiBiYXNlR3JhbnQ7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgZ2l2ZW4gbmFtZWQgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICpcbiAgICogQnkgZGVmYXVsdCwgdGhlIG1ldHJpYyB3aWxsIGJlIGNhbGN1bGF0ZWQgYXMgYSBzdW0gb3ZlciBhIHBlcmlvZCBvZiA1IG1pbnV0ZXMuXG4gICAqIFlvdSBjYW4gY3VzdG9taXplIHRoaXMgYnkgdXNpbmcgdGhlIGBzdGF0aXN0aWNgIGFuZCBgcGVyaW9kYCBwcm9wZXJ0aWVzLlxuICAgKi9cbiAgcHVibGljIG1ldHJpYyhtZXRyaWNOYW1lOiBzdHJpbmcsIHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYyB7XG4gICAgY29uc3QgbWV0cmljUHJvcHM6IE1ldHJpY1Byb3BzID0ge1xuICAgICAgbmFtZXNwYWNlOiAnQVdTL0JlZHJvY2svR3VhcmRyYWlscycsXG4gICAgICBtZXRyaWNOYW1lLFxuICAgICAgZGltZW5zaW9uc01hcDogeyBHdWFyZHJhaWxBcm46IHRoaXMuZ3VhcmRyYWlsQXJuLCBHdWFyZHJhaWxWZXJzaW9uOiB0aGlzLmd1YXJkcmFpbFZlcnNpb24gfSxcbiAgICAgIC4uLnByb3BzLFxuICAgIH07XG4gICAgcmV0dXJuIHRoaXMuY29uZmlndXJlTWV0cmljKG1ldHJpY1Byb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb25zIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgbWV0cmljSW52b2NhdGlvbnMocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMoJ0ludm9jYXRpb25zJywgcHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbiBsYXRlbmN5IG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgbWV0cmljSW52b2NhdGlvbkxhdGVuY3kocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMoJ0ludm9jYXRpb25MYXRlbmN5JywgcHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbiBjbGllbnQgZXJyb3JzIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgbWV0cmljSW52b2NhdGlvbkNsaWVudEVycm9ycyhwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiB0aGlzLm1ldHJpYygnSW52b2NhdGlvbkNsaWVudEVycm9ycycsIHByb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb24gc2VydmVyIGVycm9ycyBtZXRyaWMgZm9yIHRoaXMgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIG1ldHJpY0ludm9jYXRpb25TZXJ2ZXJFcnJvcnMocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMoJ0ludm9jYXRpb25TZXJ2ZXJFcnJvcnMnLCBwcm9wcyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBpbnZvY2F0aW9uIHRocm90dGxlcyBtZXRyaWMgZm9yIHRoaXMgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIG1ldHJpY0ludm9jYXRpb25UaHJvdHRsZXMocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMoJ0ludm9jYXRpb25UaHJvdHRsZXMnLCBwcm9wcyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSB0ZXh0IHVuaXQgY291bnQgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIHB1YmxpYyBtZXRyaWNUZXh0VW5pdENvdW50KHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYyB7XG4gICAgcmV0dXJuIHRoaXMubWV0cmljKCdUZXh0VW5pdENvdW50JywgcHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbnMgaW50ZXJ2ZW5lZCBtZXRyaWMgZm9yIHRoaXMgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIG1ldHJpY0ludm9jYXRpb25zSW50ZXJ2ZW5lZChwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiB0aGlzLm1ldHJpYygnSW52b2NhdGlvbnNJbnRlcnZlbmVkJywgcHJvcHMpO1xuICB9XG5cbiAgcHJpdmF0ZSBjb25maWd1cmVNZXRyaWMocHJvcHM6IE1ldHJpY1Byb3BzKSB7XG4gICAgcmV0dXJuIG5ldyBNZXRyaWMoe1xuICAgICAgLi4ucHJvcHMsXG4gICAgICByZWdpb246IHByb3BzPy5yZWdpb24gPz8gdGhpcy5zdGFjay5yZWdpb24sXG4gICAgICBhY2NvdW50OiBwcm9wcz8uYWNjb3VudCA/PyB0aGlzLnN0YWNrLmFjY291bnQsXG4gICAgfSk7XG4gIH1cbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBQUk9QUyBGT1IgTkVXIENPTlNUUlVDVFxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBjcmVhdGluZyBhIEd1YXJkcmFpbC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBHdWFyZHJhaWxQcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKiBUaGlzIHdpbGwgYmUgdXNlZCBhcyB0aGUgcGh5c2ljYWwgbmFtZSBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcmVhZG9ubHkgZ3VhcmRyYWlsTmFtZTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGRlc2NyaXB0aW9uIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IC0gTm8gZGVzY3JpcHRpb25cbiAgICovXG4gIHJlYWRvbmx5IGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIG1lc3NhZ2UgdG8gcmV0dXJuIHdoZW4gdGhlIGd1YXJkcmFpbCBibG9ja3MgYSBwcm9tcHQuXG4gICAqIE11c3QgYmUgYmV0d2VlbiAxIGFuZCA1MDAgY2hhcmFjdGVycy5cbiAgICogQGRlZmF1bHQgXCJTb3JyeSwgeW91ciBxdWVyeSB2aW9sYXRlcyBvdXIgdXNhZ2UgcG9saWN5LlwiXG4gICAqL1xuICByZWFkb25seSBibG9ja2VkSW5wdXRNZXNzYWdpbmc/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgbWVzc2FnZSB0byByZXR1cm4gd2hlbiB0aGUgZ3VhcmRyYWlsIGJsb2NrcyBhIG1vZGVsIHJlc3BvbnNlLlxuICAgKiBNdXN0IGJlIGJldHdlZW4gMSBhbmQgNTAwIGNoYXJhY3RlcnMuXG4gICAqIEBkZWZhdWx0IFwiU29ycnksIEkgYW0gdW5hYmxlIHRvIGFuc3dlciB5b3VyIHF1ZXN0aW9uIGJlY2F1c2Ugb2Ygb3VyIHVzYWdlIHBvbGljeS5cIlxuICAgKi9cbiAgcmVhZG9ubHkgYmxvY2tlZE91dHB1dHNNZXNzYWdpbmc/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBBIGN1c3RvbSBLTVMga2V5IHRvIHVzZSBmb3IgZW5jcnlwdGluZyBkYXRhLlxuICAgKiBAZGVmYXVsdCAtIERhdGEgaXMgZW5jcnlwdGVkIGJ5IGRlZmF1bHQgd2l0aCBhIGtleSB0aGF0IEFXUyBvd25zIGFuZCBtYW5hZ2VzIGZvciB5b3VcbiAgICovXG4gIHJlYWRvbmx5IGttc0tleT86IElLZXk7XG4gIC8qKlxuICAgKiBUaGUgY29udGVudCBmaWx0ZXJzIHRvIGFwcGx5IHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IFtdXG4gICAqL1xuICByZWFkb25seSBjb250ZW50RmlsdGVycz86IGZpbHRlcnMuQ29udGVudEZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIHRpZXIgY29uZmlndXJhdGlvbiB0byBhcHBseSB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAZGVmYXVsdCBmaWx0ZXJzLlRpZXJDb25maWcuQ0xBU1NJQ1xuICAgKi9cbiAgcmVhZG9ubHkgY29udGVudEZpbHRlcnNUaWVyQ29uZmlnPzogZmlsdGVycy5UaWVyQ29uZmlnO1xuICAvKipcbiAgICogQSBsaXN0IG9mIHBvbGljaWVzIHJlbGF0ZWQgdG8gdG9waWNzIHRoYXQgdGhlIGd1YXJkcmFpbCBzaG91bGQgZGVueS5cbiAgICogQGRlZmF1bHQgW11cbiAgICovXG4gIHJlYWRvbmx5IGRlbmllZFRvcGljcz86IGZpbHRlcnMuVG9waWNbXTtcbiAgLyoqXG4gICAqIFRoZSB0aWVyIGNvbmZpZ3VyYXRpb24gdG8gYXBwbHkgdG8gdGhlIGd1YXJkcmFpbC5cbiAgICogQGRlZmF1bHQgZmlsdGVycy5UaWVyQ29uZmlnLkNMQVNTSUNcbiAgICovXG4gIHJlYWRvbmx5IHRvcGljc1RpZXJDb25maWc/OiBmaWx0ZXJzLlRpZXJDb25maWc7XG4gIC8qKlxuICAgKiBUaGUgd29yZCBmaWx0ZXJzIHRvIGFwcGx5IHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IFtdXG4gICAqL1xuICByZWFkb25seSB3b3JkRmlsdGVycz86IGZpbHRlcnMuV29yZEZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIG1hbmFnZWQgd29yZCBmaWx0ZXJzIHRvIGFwcGx5IHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IFtdXG4gICAqL1xuICByZWFkb25seSBtYW5hZ2VkV29yZExpc3RGaWx0ZXJzPzogZmlsdGVycy5NYW5hZ2VkV29yZEZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIFBJSSBmaWx0ZXJzIHRvIGFwcGx5IHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IFtdXG4gICAqL1xuICByZWFkb25seSBwaWlGaWx0ZXJzPzogZmlsdGVycy5QSUlGaWx0ZXJbXTtcbiAgLyoqXG4gICAqIFRoZSByZWd1bGFyIGV4cHJlc3Npb24gKHJlZ2V4KSBmaWx0ZXJzIHRvIGFwcGx5IHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IFtdXG4gICAqL1xuICByZWFkb25seSByZWdleEZpbHRlcnM/OiBmaWx0ZXJzLlJlZ2V4RmlsdGVyW107XG4gIC8qKlxuICAgKiBUaGUgY29udGV4dHVhbCBncm91bmRpbmcgZmlsdGVycyB0byBhcHBseSB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAZGVmYXVsdCBbXVxuICAgKi9cbiAgcmVhZG9ubHkgY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnM/OiBmaWx0ZXJzLkNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJbXTtcbiAgLyoqXG4gICAqIFRoZSBjcm9zcy1yZWdpb24gY29uZmlndXJhdGlvbiBmb3IgdGhlIGd1YXJkcmFpbC5cbiAgICogVGhpcyBpcyBvcHRpb25hbCBhbmQgd2hlbiBwcm92aWRlZCwgaXQgc2hvdWxkIGJlIG9mIHR5cGUgR3VhcmRyYWlsQ3Jvc3NSZWdpb25Db25maWdQcm9wZXJ0eS5cbiAgICogQGRlZmF1bHQgLSBObyBjcm9zcy1yZWdpb24gY29uZmlndXJhdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgY3Jvc3NSZWdpb25Db25maWc/OiBHdWFyZHJhaWxDcm9zc1JlZ2lvbkNvbmZpZ1Byb3BlcnR5O1xufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICBBVFRSUyBGT1IgSU1QT1JURUQgQ09OU1RSVUNUXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5leHBvcnQgaW50ZXJmYWNlIEd1YXJkcmFpbEF0dHJpYnV0ZXMge1xuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgZ3VhcmRyYWlsLiBBdCBsZWFzdCBvbmUgb2YgZ3VhcmRyYWlsQXJuIG9yIGd1YXJkcmFpbElkIG11c3QgYmVcbiAgICogZGVmaW5lZCBpbiBvcmRlciB0byBpbml0aWFsaXplIGEgZ3VhcmRyYWlsIHJlZi5cbiAgICovXG4gIHJlYWRvbmx5IGd1YXJkcmFpbEFybjogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIEtNUyBrZXkgb2YgdGhlIGd1YXJkcmFpbCBpZiBjdXN0b20gZW5jcnlwdGlvbiBpcyBjb25maWd1cmVkLlxuICAgKlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBNZWFucyBkYXRhIGlzIGVuY3J5cHRlZCBieSBkZWZhdWx0IHdpdGggYSBBV1MtbWFuYWdlZCBrZXlcbiAgICovXG4gIHJlYWRvbmx5IGttc0tleT86IElLZXk7XG4gIC8qKlxuICAgKiBUaGUgdmVyc2lvbiBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKlxuICAgKiBAZGVmYXVsdCBcIkRSQUZUXCJcbiAgICovXG4gIHJlYWRvbmx5IGd1YXJkcmFpbFZlcnNpb24/OiBzdHJpbmc7XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgTkVXIENPTlNUUlVDVCBERUZJTklUSU9OXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIENsYXNzIHRvIGNyZWF0ZSBhIEd1YXJkcmFpbCB3aXRoIENESy5cbiAqIEBjbG91ZGZvcm1hdGlvblJlc291cmNlIEFXUzo6QmVkcm9jazo6R3VhcmRyYWlsXG4gKi9cbkBwcm9wZXJ0eUluamVjdGFibGVcbmV4cG9ydCBjbGFzcyBHdWFyZHJhaWwgZXh0ZW5kcyBHdWFyZHJhaWxCYXNlIHtcbiAgLyoqIFVuaXF1ZWx5IGlkZW50aWZpZXMgdGhpcyBjbGFzcy4gKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBQUk9QRVJUWV9JTkpFQ1RJT05fSUQ6IHN0cmluZyA9ICdAYXdzLWNkay5hd3MtYmVkcm9jay1hbHBoYS5HdWFyZHJhaWwnO1xuXG4gIC8qKlxuICAgKiBJbXBvcnQgYSBndWFyZHJhaWwgZ2l2ZW4gaXRzIGF0dHJpYnV0ZXNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUd1YXJkcmFpbEF0dHJpYnV0ZXMoc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgYXR0cnM6IEd1YXJkcmFpbEF0dHJpYnV0ZXMpOiBJR3VhcmRyYWlsIHtcbiAgICBjbGFzcyBJbXBvcnQgZXh0ZW5kcyBHdWFyZHJhaWxCYXNlIHtcbiAgICAgIHB1YmxpYyByZWFkb25seSBndWFyZHJhaWxBcm4gPSBhdHRycy5ndWFyZHJhaWxBcm47XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgZ3VhcmRyYWlsSWQgPSBBcm4uc3BsaXQoYXR0cnMuZ3VhcmRyYWlsQXJuLCBBcm5Gb3JtYXQuU0xBU0hfUkVTT1VSQ0VfTkFNRSkucmVzb3VyY2VOYW1lITtcbiAgICAgIHB1YmxpYyByZWFkb25seSBrbXNLZXkgPSBhdHRycy5rbXNLZXk7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgbGFzdFVwZGF0ZWQgPSB1bmRlZmluZWQ7XG5cbiAgICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihzY29wZSwgaWQpO1xuICAgICAgICB0aGlzLnVwZGF0ZVZlcnNpb24oYXR0cnMuZ3VhcmRyYWlsVmVyc2lvbiA/PyAnRFJBRlQnKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IEltcG9ydCgpO1xuICB9XG5cbiAgLyoqXG4gICAqIEltcG9ydCBhIGxvdy1sZXZlbCBMMSBDZm4gR3VhcmRyYWlsXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21DZm5HdWFyZHJhaWwoY2ZuR3VhcmRyYWlsOiBiZWRyb2NrLkNmbkd1YXJkcmFpbCk6IElHdWFyZHJhaWwge1xuICAgIHJldHVybiBuZXcgKGNsYXNzIGV4dGVuZHMgR3VhcmRyYWlsQmFzZSB7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgZ3VhcmRyYWlsQXJuID0gY2ZuR3VhcmRyYWlsLmF0dHJHdWFyZHJhaWxBcm47XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgZ3VhcmRyYWlsSWQgPSBjZm5HdWFyZHJhaWwuYXR0ckd1YXJkcmFpbElkO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGttc0tleSA9IGNmbkd1YXJkcmFpbC5rbXNLZXlBcm5cbiAgICAgICAgPyBLZXkuZnJvbUtleUFybih0aGlzLCAnQEZyb21DZm5HdWFyZHJhaWxLZXknLCBjZm5HdWFyZHJhaWwua21zS2V5QXJuKVxuICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICAgIHB1YmxpYyByZWFkb25seSBsYXN0VXBkYXRlZCA9IGNmbkd1YXJkcmFpbC5hdHRyVXBkYXRlZEF0O1xuXG4gICAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoY2ZuR3VhcmRyYWlsLCAnQEZyb21DZm5HdWFyZHJhaWwnKTtcbiAgICAgICAgdGhpcy51cGRhdGVWZXJzaW9uKGNmbkd1YXJkcmFpbC5hdHRyVmVyc2lvbik7XG4gICAgICB9XG4gICAgfSkoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBndWFyZHJhaWxBcm46IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBJRCBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZ3VhcmRyYWlsSWQ6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIEtNUyBrZXkgdXNlZCB0byBlbmNyeXB0IGRhdGEuXG4gICAqXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIFwiRGF0YSBpcyBlbmNyeXB0ZWQgYnkgZGVmYXVsdCB3aXRoIGEga2V5IHRoYXQgQVdTIG93bnMgYW5kIG1hbmFnZXMgZm9yIHlvdVwiXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkga21zS2V5PzogSUtleTtcbiAgLyoqXG4gICAqIFRoZSBjb250ZW50IGZpbHRlcnMgYXBwbGllZCBieSB0aGUgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGNvbnRlbnRGaWx0ZXJzOiBmaWx0ZXJzLkNvbnRlbnRGaWx0ZXJbXTtcbiAgLyoqXG4gICAqIFRoZSBQSUkgZmlsdGVycyBhcHBsaWVkIGJ5IHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgcGlpRmlsdGVyczogZmlsdGVycy5QSUlGaWx0ZXJbXTtcbiAgLyoqXG4gICAqIFRoZSByZWdleCBmaWx0ZXJzIGFwcGxpZWQgYnkgdGhlIGd1YXJkcmFpbC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSByZWdleEZpbHRlcnM6IGZpbHRlcnMuUmVnZXhGaWx0ZXJbXTtcbiAgLyoqXG4gICAqIFRoZSBkZW5pZWQgdG9waWMgZmlsdGVycyBhcHBsaWVkIGJ5IHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZGVuaWVkVG9waWNzOiBmaWx0ZXJzLlRvcGljW107XG4gIC8qKlxuICAgKiBUaGUgY29udGV4dHVhbCBncm91bmRpbmcgZmlsdGVycyBhcHBsaWVkIGJ5IHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnM6IGZpbHRlcnMuQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIHdvcmQgZmlsdGVycyBhcHBsaWVkIGJ5IHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgd29yZEZpbHRlcnM6IGZpbHRlcnMuV29yZEZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIG1hbmFnZWQgd29yZCBsaXN0IGZpbHRlcnMgYXBwbGllZCBieSB0aGUgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IG1hbmFnZWRXb3JkTGlzdEZpbHRlcnM6IGZpbHRlcnMuTWFuYWdlZFdvcmRGaWx0ZXJbXTtcbiAgLyoqXG4gICAqIFdoZW4gdGhpcyBndWFyZHJhaWwgd2FzIGxhc3QgdXBkYXRlZFxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGxhc3RVcGRhdGVkPzogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGNvbXB1dGVkIGhhc2ggb2YgdGhlIGd1YXJkcmFpbCBwcm9wZXJ0aWVzLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGhhc2g6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBMMSByZXByZXNlbnRhdGlvbiBvZiB0aGUgZ3VhcmRyYWlsXG4gICAqL1xuICBwcml2YXRlIHJlYWRvbmx5IF9fcmVzb3VyY2U6IGJlZHJvY2suQ2ZuR3VhcmRyYWlsO1xuXG4gIC8qKlxuICAgKiBUaGUgdGllciB0aGF0IHlvdXIgZ3VhcmRyYWlsIHVzZXMgZm9yIGRlbmllZCB0b3BpYyBmaWx0ZXJzLlxuICAgKiBAZGVmYXVsdCBmaWx0ZXJzLlRpZXJDb25maWcuQ0xBU1NJQ1xuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHRvcGljc1RpZXJDb25maWc6IGZpbHRlcnMuVGllckNvbmZpZztcblxuICAvKipcbiAgICogVGhlIHRpZXIgdGhhdCB5b3VyIGd1YXJkcmFpbCB1c2VzIGZvciBjb250ZW50IGZpbHRlcnMuXG4gICAqIENvbnNpZGVyIHVzaW5nIGEgdGllciB0aGF0IGJhbGFuY2VzIHBlcmZvcm1hbmNlLCBhY2N1cmFjeSwgYW5kIGNvbXBhdGliaWxpdHkgd2l0aCB5b3VyIGV4aXN0aW5nIGdlbmVyYXRpdmUgQUkgd29ya2Zsb3dzLlxuICAgKiBAZGVmYXVsdCBmaWx0ZXJzLlRpZXJDb25maWcuQ0xBU1NJQ1xuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZzogZmlsdGVycy5UaWVyQ29uZmlnO1xuICAvKipcbiAgICogVGhlIGNyb3NzLXJlZ2lvbiBjb25maWd1cmF0aW9uIGZvciB0aGUgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGNyb3NzUmVnaW9uQ29uZmlnPzogR3VhcmRyYWlsQ3Jvc3NSZWdpb25Db25maWdQcm9wZXJ0eTtcblxuICAvKipcbiAgICogVGhlIG1lc3NhZ2UgdG8gcmV0dXJuIHdoZW4gdGhlIGd1YXJkcmFpbCBibG9ja3MgYSBwcm9tcHQuXG4gICAqIEBkZWZhdWx0IFwiU29ycnksIHlvdXIgcXVlcnkgdmlvbGF0ZXMgb3VyIHVzYWdlIHBvbGljeS5cIlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGJsb2NrZWRJbnB1dE1lc3NhZ2luZzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbWVzc2FnZSB0byByZXR1cm4gd2hlbiB0aGUgZ3VhcmRyYWlsIGJsb2NrcyBhIG1vZGVsIHJlc3BvbnNlLlxuICAgKiBAZGVmYXVsdCBcIlNvcnJ5LCBJIGFtIHVuYWJsZSB0byBhbnN3ZXIgeW91ciBxdWVzdGlvbiBiZWNhdXNlIG9mIG91ciB1c2FnZSBwb2xpY3kuXCJcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBibG9ja2VkT3V0cHV0c01lc3NhZ2luZzogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzOiBHdWFyZHJhaWxQcm9wcykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwge1xuICAgICAgcGh5c2ljYWxOYW1lOiBwcm9wcy5ndWFyZHJhaWxOYW1lLFxuICAgIH0pO1xuICAgIC8vIEVuaGFuY2VkIENESyBBbmFseXRpY3MgVGVsZW1ldHJ5XG4gICAgYWRkQ29uc3RydWN0TWV0YWRhdGEodGhpcywgcHJvcHMpO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gU2V0IHByb3BlcnRpZXMgb3IgZGVmYXVsdHNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLm5hbWUgPSB0aGlzLnBoeXNpY2FsTmFtZTtcbiAgICB0aGlzLmNvbnRlbnRGaWx0ZXJzID0gcHJvcHMuY29udGVudEZpbHRlcnMgPz8gW107XG4gICAgdGhpcy5waWlGaWx0ZXJzID0gcHJvcHMucGlpRmlsdGVycyA/PyBbXTtcbiAgICB0aGlzLnJlZ2V4RmlsdGVycyA9IHByb3BzLnJlZ2V4RmlsdGVycyA/PyBbXTtcbiAgICB0aGlzLmRlbmllZFRvcGljcyA9IHByb3BzLmRlbmllZFRvcGljcyA/PyBbXTtcbiAgICB0aGlzLmNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJzID0gcHJvcHMuY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMgPz8gW107XG4gICAgdGhpcy53b3JkRmlsdGVycyA9IHByb3BzLndvcmRGaWx0ZXJzID8/IFtdO1xuICAgIHRoaXMubWFuYWdlZFdvcmRMaXN0RmlsdGVycyA9IHByb3BzLm1hbmFnZWRXb3JkTGlzdEZpbHRlcnMgPz8gW107XG4gICAgdGhpcy50b3BpY3NUaWVyQ29uZmlnID0gcHJvcHMudG9waWNzVGllckNvbmZpZyA/PyBmaWx0ZXJzLlRpZXJDb25maWcuQ0xBU1NJQztcbiAgICB0aGlzLmNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZyA9IHByb3BzLmNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZyA/PyBmaWx0ZXJzLlRpZXJDb25maWcuQ0xBU1NJQztcbiAgICB0aGlzLmNyb3NzUmVnaW9uQ29uZmlnID0gcHJvcHMuY3Jvc3NSZWdpb25Db25maWc7XG4gICAgdGhpcy5ibG9ja2VkSW5wdXRNZXNzYWdpbmcgPSBwcm9wcy5ibG9ja2VkSW5wdXRNZXNzYWdpbmcgPz8gJ1NvcnJ5LCB5b3VyIHF1ZXJ5IHZpb2xhdGVzIG91ciB1c2FnZSBwb2xpY3kuJztcbiAgICB0aGlzLmJsb2NrZWRPdXRwdXRzTWVzc2FnaW5nID0gcHJvcHMuYmxvY2tlZE91dHB1dHNNZXNzYWdpbmcgPz8gJ1NvcnJ5LCBJIGFtIHVuYWJsZSB0byBhbnN3ZXIgeW91ciBxdWVzdGlvbiBiZWNhdXNlIG9mIG91ciB1c2FnZSBwb2xpY3kuJztcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIFZhbGlkYXRlIGFsbCBmaWx0ZXIgYXJyYXlzXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy52YWxpZGF0ZUNvbnRlbnRGaWx0ZXJzKHRoaXMuY29udGVudEZpbHRlcnMpO1xuICAgIHRoaXMudmFsaWRhdGVQaWlGaWx0ZXJzKHRoaXMucGlpRmlsdGVycyk7XG4gICAgdGhpcy52YWxpZGF0ZVJlZ2V4RmlsdGVycyh0aGlzLnJlZ2V4RmlsdGVycyk7XG4gICAgdGhpcy52YWxpZGF0ZURlbmllZFRvcGljcyh0aGlzLmRlbmllZFRvcGljcyk7XG4gICAgdGhpcy52YWxpZGF0ZUNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJzKHRoaXMuY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMpO1xuICAgIHRoaXMudmFsaWRhdGVXb3JkRmlsdGVycyh0aGlzLndvcmRGaWx0ZXJzKTtcbiAgICB0aGlzLnZhbGlkYXRlTWFuYWdlZFdvcmRMaXN0RmlsdGVycyh0aGlzLm1hbmFnZWRXb3JkTGlzdEZpbHRlcnMpO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gVmFsaWRhdGUgbWVzc2FnaW5nIHByb3BlcnRpZXNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLnZhbGlkYXRlTWVzc2FnaW5nUHJvcGVydHkodGhpcy5ibG9ja2VkSW5wdXRNZXNzYWdpbmcsICdibG9ja2VkSW5wdXRNZXNzYWdpbmcnKTtcbiAgICB0aGlzLnZhbGlkYXRlTWVzc2FnaW5nUHJvcGVydHkodGhpcy5ibG9ja2VkT3V0cHV0c01lc3NhZ2luZywgJ2Jsb2NrZWRPdXRwdXRzTWVzc2FnaW5nJyk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBWYWxpZGF0ZSB0aWVyIGNvbmZpZ3VyYXRpb24gcmVxdWlyZW1lbnRzXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy52YWxpZGF0ZVRpZXJDb25maWd1cmF0aW9uKHByb3BzKTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIENGTiBQcm9wcyAtIFdpdGggTGF6eSBzdXBwb3J0XG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgbGV0IGNmblByb3BzOiBiZWRyb2NrLkNmbkd1YXJkcmFpbFByb3BzID0ge1xuICAgICAgbmFtZTogcHJvcHMuZ3VhcmRyYWlsTmFtZSxcbiAgICAgIGRlc2NyaXB0aW9uOiBwcm9wcy5kZXNjcmlwdGlvbixcbiAgICAgIGttc0tleUFybjogcHJvcHMua21zS2V5Py5rZXlBcm4sXG4gICAgICBibG9ja2VkSW5wdXRNZXNzYWdpbmc6IHRoaXMuYmxvY2tlZElucHV0TWVzc2FnaW5nLFxuICAgICAgYmxvY2tlZE91dHB1dHNNZXNzYWdpbmc6IHRoaXMuYmxvY2tlZE91dHB1dHNNZXNzYWdpbmcsXG4gICAgICAvLyBMYXp5IHByb3BzXG4gICAgICBjcm9zc1JlZ2lvbkNvbmZpZzogdGhpcy5nZW5lcmF0ZUNmbkNyb3NzUmVnaW9uQ29uZmlnKCksXG4gICAgICBjb250ZW50UG9saWN5Q29uZmlnOiB0aGlzLmdlbmVyYXRlQ2ZuQ29udGVudFBvbGljeUNvbmZpZygpLFxuICAgICAgY29udGV4dHVhbEdyb3VuZGluZ1BvbGljeUNvbmZpZzogdGhpcy5nZW5lcmF0ZUNmbkNvbnRleHR1YWxQb2xpY3lDb25maWcoKSxcbiAgICAgIHRvcGljUG9saWN5Q29uZmlnOiB0aGlzLmdlbmVyYXRlQ2ZuVG9waWNQb2xpY3koKSxcbiAgICAgIHdvcmRQb2xpY3lDb25maWc6IHRoaXMuZ2VuZXJhdGVDZm5Xb3JkUG9saWN5Q29uZmlnKCksXG4gICAgICBzZW5zaXRpdmVJbmZvcm1hdGlvblBvbGljeUNvbmZpZzogdGhpcy5nZW5lcmF0ZUNmblNlbnNpdGl2ZUluZm9ybWF0aW9uUG9saWN5Q29uZmlnKCksXG4gICAgfTtcblxuICAgIC8vIEhhc2ggY2FsY3VsYXRpb24gdXNlZnVsIGZvciB2ZXJzaW9uaW5nIG9mIHRoZSBndWFyZHJhaWxcbiAgICB0aGlzLmhhc2ggPSBtZDVoYXNoKEpTT04uc3RyaW5naWZ5KGNmblByb3BzKSk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBMMSBJbnN0YW50aWF0aW9uXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy5fX3Jlc291cmNlID0gbmV3IGJlZHJvY2suQ2ZuR3VhcmRyYWlsKHRoaXMsICdNeUd1YXJkcmFpbCcsIGNmblByb3BzKTtcblxuICAgIHRoaXMuZ3VhcmRyYWlsSWQgPSB0aGlzLl9fcmVzb3VyY2UuYXR0ckd1YXJkcmFpbElkO1xuICAgIHRoaXMuZ3VhcmRyYWlsQXJuID0gdGhpcy5fX3Jlc291cmNlLmF0dHJHdWFyZHJhaWxBcm47XG4gICAgdGhpcy51cGRhdGVWZXJzaW9uKHRoaXMuX19yZXNvdXJjZS5hdHRyVmVyc2lvbik7XG4gICAgdGhpcy5sYXN0VXBkYXRlZCA9IHRoaXMuX19yZXNvdXJjZS5hdHRyVXBkYXRlZEF0O1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIE1FVEhPRFNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBBZGRzIGEgY29udGVudCBmaWx0ZXIgdG8gdGhlIGd1YXJkcmFpbC5cbiAgICogQHBhcmFtIGZpbHRlciBUaGUgY29udGVudCBmaWx0ZXIgdG8gYWRkLlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGFkZENvbnRlbnRGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLkNvbnRlbnRGaWx0ZXIpOiB2b2lkIHtcbiAgICB0aGlzLnZhbGlkYXRlU2luZ2xlQ29udGVudEZpbHRlcihmaWx0ZXIpO1xuICAgIHRoaXMuY29udGVudEZpbHRlcnMucHVzaChmaWx0ZXIpO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgYSBQSUkgZmlsdGVyIHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIFBJSSBmaWx0ZXIgdG8gYWRkLlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGFkZFBJSUZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuUElJRmlsdGVyKTogdm9pZCB7XG4gICAgdGhpcy52YWxpZGF0ZVNpbmdsZVBpaUZpbHRlcihmaWx0ZXIpO1xuICAgIHRoaXMucGlpRmlsdGVycy5wdXNoKGZpbHRlcik7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhIHJlZ2V4IGZpbHRlciB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSByZWdleCBmaWx0ZXIgdG8gYWRkLlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGFkZFJlZ2V4RmlsdGVyKGZpbHRlcjogZmlsdGVycy5SZWdleEZpbHRlcik6IHZvaWQge1xuICAgIHRoaXMudmFsaWRhdGVTaW5nbGVSZWdleEZpbHRlcihmaWx0ZXIpO1xuICAgIHRoaXMucmVnZXhGaWx0ZXJzLnB1c2goZmlsdGVyKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGEgZGVuaWVkIHRvcGljIGZpbHRlciB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSBkZW5pZWQgdG9waWMgZmlsdGVyIHRvIGFkZC5cbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBhZGREZW5pZWRUb3BpY0ZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuVG9waWMpOiB2b2lkIHtcbiAgICB0aGlzLnZhbGlkYXRlU2luZ2xlRGVuaWVkVG9waWMoZmlsdGVyKTtcbiAgICB0aGlzLmRlbmllZFRvcGljcy5wdXNoKGZpbHRlcik7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhIGNvbnRleHR1YWwgZ3JvdW5kaW5nIGZpbHRlciB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSBjb250ZXh0dWFsIGdyb3VuZGluZyBmaWx0ZXIgdG8gYWRkLlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGFkZENvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLkNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXIpOiB2b2lkIHtcbiAgICB0aGlzLnZhbGlkYXRlU2luZ2xlQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcihmaWx0ZXIpO1xuICAgIHRoaXMuY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMucHVzaChmaWx0ZXIpO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgYSB3b3JkIGZpbHRlciB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSB3b3JkIGZpbHRlciB0byBhZGQuXG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgYWRkV29yZEZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuV29yZEZpbHRlcik6IHZvaWQge1xuICAgIHRoaXMudmFsaWRhdGVTaW5nbGVXb3JkRmlsdGVyKGZpbHRlcik7XG4gICAgdGhpcy53b3JkRmlsdGVycy5wdXNoKGZpbHRlcik7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhIHdvcmQgZmlsdGVyIHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBwYXJhbSBmaWxlUGF0aCBUaGUgbG9jYXRpb24gb2YgdGhlIHdvcmQgZmlsdGVyIGZpbGUuXG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgYWRkV29yZEZpbHRlckZyb21GaWxlKGZpbGVQYXRoOiBzdHJpbmcsXG4gICAgaW5wdXRBY3Rpb24/OiBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbixcbiAgICBvdXRwdXRBY3Rpb24/OiBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbixcbiAgICBpbnB1dEVuYWJsZWQ/OiBib29sZWFuLFxuICAgIG91dHB1dEVuYWJsZWQ/OiBib29sZWFuKTogdm9pZCB7XG4gICAgY29uc3QgZmlsZUNvbnRlbnRzID0gZnMucmVhZEZpbGVTeW5jKGZpbGVQYXRoLCAndXRmOCcpO1xuICAgIGNvbnN0IHdvcmRzID0gZmlsZUNvbnRlbnRzLnRyaW0oKS5zcGxpdCgnLCcpO1xuICAgIGZvciAoY29uc3Qgd29yZCBvZiB3b3JkcykgdGhpcy5hZGRXb3JkRmlsdGVyKHsgdGV4dDogd29yZCwgaW5wdXRBY3Rpb24sIG91dHB1dEFjdGlvbiwgaW5wdXRFbmFibGVkLCBvdXRwdXRFbmFibGVkIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgYSBtYW5hZ2VkIHdvcmQgbGlzdCBmaWx0ZXIgdG8gdGhlIGd1YXJkcmFpbC5cbiAgICogQHBhcmFtIGZpbHRlciBUaGUgbWFuYWdlZCB3b3JkIGxpc3QgZmlsdGVyIHRvIGFkZC5cbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBhZGRNYW5hZ2VkV29yZExpc3RGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLk1hbmFnZWRXb3JkRmlsdGVyKTogdm9pZCB7XG4gICAgdGhpcy52YWxpZGF0ZVNpbmdsZU1hbmFnZWRXb3JkTGlzdEZpbHRlcihmaWx0ZXIpO1xuICAgIHRoaXMubWFuYWdlZFdvcmRMaXN0RmlsdGVycy5wdXNoKGZpbHRlcik7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGEgdmVyc2lvbiBmb3IgdGhlIGd1YXJkcmFpbC5cbiAgICogQHBhcmFtIGRlc2NyaXB0aW9uIFRoZSBkZXNjcmlwdGlvbiBvZiB0aGUgdmVyc2lvbi5cbiAgICogQHJldHVybnMgVGhlIGd1YXJkcmFpbCB2ZXJzaW9uLlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGNyZWF0ZVZlcnNpb24oZGVzY3JpcHRpb24/OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGNvbnN0IGNmblZlcnNpb24gPSBuZXcgR3VhcmRyYWlsVmVyc2lvbih0aGlzLCBgR3VhcmRyYWlsVmVyc2lvbi0ke3RoaXMuaGFzaC5zbGljZSgwLCAxNil9YCwge1xuICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uLFxuICAgICAgZ3VhcmRyYWlsOiB0aGlzLFxuICAgIH0pO1xuXG4gICAgdGhpcy51cGRhdGVWZXJzaW9uKGNmblZlcnNpb24uZ3VhcmRyYWlsVmVyc2lvbik7XG4gICAgcmV0dXJuIHRoaXMuZ3VhcmRyYWlsVmVyc2lvbjtcbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBDRk4gR2VuZXJhdG9yc1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGNvbnRlbnQgZmlsdGVycyBhcHBsaWVkIHRvIHRoZSBndWFyZHJhaWwuIFRoaXMgbWV0aG9kIGRlZmVycyB0aGUgY29tcHV0YXRpb25cbiAgICogdG8gc3ludGggdGltZS5cbiAgICovXG4gIHByaXZhdGUgZ2VuZXJhdGVDZm5Db250ZW50UG9saWN5Q29uZmlnKCk6IElSZXNvbHZhYmxlIHtcbiAgICByZXR1cm4gTGF6eS5hbnkoe1xuICAgICAgcHJvZHVjZTogKCkgPT4ge1xuICAgICAgICBpZiAodGhpcy5jb250ZW50RmlsdGVycy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgY29uc3QgY29udGVudFBvbGljeUNvbmZpZzogYmVkcm9jay5DZm5HdWFyZHJhaWwuQ29udGVudFBvbGljeUNvbmZpZ1Byb3BlcnR5ID0ge1xuICAgICAgICAgICAgZmlsdGVyc0NvbmZpZzogdGhpcy5jb250ZW50RmlsdGVycyxcbiAgICAgICAgICAgIC4uLih0aGlzLmNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZyAmJiB7XG4gICAgICAgICAgICAgIGNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZzoge1xuICAgICAgICAgICAgICAgIHRpZXJOYW1lOiB0aGlzLmNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZyxcbiAgICAgICAgICAgICAgfSBhcyBiZWRyb2NrLkNmbkd1YXJkcmFpbC5Db250ZW50RmlsdGVyc1RpZXJDb25maWdQcm9wZXJ0eSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIH07XG5cbiAgICAgICAgICByZXR1cm4gY29udGVudFBvbGljeUNvbmZpZztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHRvcGljIGZpbHRlcnMgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuVG9waWNQb2xpY3koKTogSVJlc29sdmFibGUge1xuICAgIHJldHVybiBMYXp5LmFueSh7XG4gICAgICBwcm9kdWNlOiAoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLmRlbmllZFRvcGljcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgY29uc3QgdG9waWNQb2xpY3lDb25maWc6IGJlZHJvY2suQ2ZuR3VhcmRyYWlsLlRvcGljUG9saWN5Q29uZmlnUHJvcGVydHkgPSB7XG4gICAgICAgICAgICB0b3BpY3NDb25maWc6IHRoaXMuZGVuaWVkVG9waWNzLmZsYXRNYXAoKHRvcGljOiBmaWx0ZXJzLlRvcGljKSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgZGVmaW5pdGlvbjogdG9waWMuZGVmaW5pdGlvbixcbiAgICAgICAgICAgICAgICBuYW1lOiB0b3BpYy5uYW1lLFxuICAgICAgICAgICAgICAgIGV4YW1wbGVzOiB0b3BpYy5leGFtcGxlcyxcbiAgICAgICAgICAgICAgICB0eXBlOiAnREVOWScsXG4gICAgICAgICAgICAgICAgaW5wdXRBY3Rpb246IHRvcGljLmlucHV0QWN0aW9uLFxuICAgICAgICAgICAgICAgIGlucHV0RW5hYmxlZDogdG9waWMuaW5wdXRFbmFibGVkLFxuICAgICAgICAgICAgICAgIG91dHB1dEFjdGlvbjogdG9waWMub3V0cHV0QWN0aW9uLFxuICAgICAgICAgICAgICAgIG91dHB1dEVuYWJsZWQ6IHRvcGljLm91dHB1dEVuYWJsZWQsXG4gICAgICAgICAgICAgIH0gYXMgYmVkcm9jay5DZm5HdWFyZHJhaWwuVG9waWNDb25maWdQcm9wZXJ0eTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgLi4uKHRoaXMudG9waWNzVGllckNvbmZpZyAmJiB7XG4gICAgICAgICAgICAgIHRvcGljc1RpZXJDb25maWc6IHtcbiAgICAgICAgICAgICAgICB0aWVyTmFtZTogdGhpcy50b3BpY3NUaWVyQ29uZmlnLFxuICAgICAgICAgICAgICB9IGFzIGJlZHJvY2suQ2ZuR3VhcmRyYWlsLlRvcGljc1RpZXJDb25maWdQcm9wZXJ0eSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIH07XG5cbiAgICAgICAgICByZXR1cm4gdG9waWNQb2xpY3lDb25maWc7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBjb250ZWN0dWFsIGZpbHRlcnMgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuQ29udGV4dHVhbFBvbGljeUNvbmZpZygpOiBJUmVzb2x2YWJsZSB7XG4gICAgcmV0dXJuIExhenkuYW55KHtcbiAgICAgIHByb2R1Y2U6ICgpID0+IHtcbiAgICAgICAgaWYgKHRoaXMuY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBmaWx0ZXJzQ29uZmlnOiB0aGlzLmNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJzLmZsYXRNYXAoKGZpbHRlcjogZmlsdGVycy5Db250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyKSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgdHlwZTogZmlsdGVyLnR5cGUsXG4gICAgICAgICAgICAgICAgdGhyZXNob2xkOiBmaWx0ZXIudGhyZXNob2xkLFxuICAgICAgICAgICAgICAgIGFjdGlvbjogZmlsdGVyLmFjdGlvbixcbiAgICAgICAgICAgICAgICBlbmFibGVkOiBmaWx0ZXIuZW5hYmxlZCxcbiAgICAgICAgICAgICAgfSBhcyBiZWRyb2NrLkNmbkd1YXJkcmFpbC5Db250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyQ29uZmlnUHJvcGVydHk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICB9O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgd29yZCBjb25maWcgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuV29yZFBvbGljeUNvbmZpZygpOiBJUmVzb2x2YWJsZSB7XG4gICAgcmV0dXJuIExhenkuYW55KHtcbiAgICAgIHByb2R1Y2U6ICgpID0+IHtcbiAgICAgICAgaWYgKHRoaXMud29yZEZpbHRlcnMubGVuZ3RoID4gMCB8fCB0aGlzLm1hbmFnZWRXb3JkTGlzdEZpbHRlcnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB3b3Jkc0NvbmZpZzogdGhpcy5nZW5lcmF0ZUNmbldvcmRDb25maWcoKSxcbiAgICAgICAgICAgIG1hbmFnZWRXb3JkTGlzdHNDb25maWc6IHRoaXMuZ2VuZXJhdGVDZm5NYW5hZ2VkV29yZExpc3RzQ29uZmlnKCksXG4gICAgICAgICAgfSBhcyBiZWRyb2NrLkNmbkd1YXJkcmFpbC5Xb3JkUG9saWN5Q29uZmlnUHJvcGVydHk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSB3b3JkIGZpbHRlcnMgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuV29yZENvbmZpZygpOiBJUmVzb2x2YWJsZSB7XG4gICAgcmV0dXJuIExhenkuYW55KFxuICAgICAge1xuICAgICAgICBwcm9kdWNlOiAoKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMud29yZEZpbHRlcnMuZmxhdE1hcCgod29yZDogZmlsdGVycy5Xb3JkRmlsdGVyKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICB0ZXh0OiB3b3JkLnRleHQsXG4gICAgICAgICAgICAgIGlucHV0QWN0aW9uOiB3b3JkLmlucHV0QWN0aW9uLFxuICAgICAgICAgICAgICBpbnB1dEVuYWJsZWQ6IHdvcmQuaW5wdXRFbmFibGVkLFxuICAgICAgICAgICAgICBvdXRwdXRBY3Rpb246IHdvcmQub3V0cHV0QWN0aW9uLFxuICAgICAgICAgICAgICBvdXRwdXRFbmFibGVkOiB3b3JkLm91dHB1dEVuYWJsZWQsXG4gICAgICAgICAgICB9IGFzIGJlZHJvY2suQ2ZuR3VhcmRyYWlsLldvcmRDb25maWdQcm9wZXJ0eTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB7IG9taXRFbXB0eUFycmF5OiB0cnVlIH0sXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSB3b3JkIGZpbHRlcnMgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuTWFuYWdlZFdvcmRMaXN0c0NvbmZpZygpOiBJUmVzb2x2YWJsZSB7XG4gICAgcmV0dXJuIExhenkuYW55KFxuICAgICAge1xuICAgICAgICBwcm9kdWNlOiAoKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMubWFuYWdlZFdvcmRMaXN0RmlsdGVycy5mbGF0TWFwKChmaWx0ZXI6IGZpbHRlcnMuTWFuYWdlZFdvcmRGaWx0ZXIpID0+IHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIHR5cGU6IGZpbHRlci50eXBlLFxuICAgICAgICAgICAgICBpbnB1dEFjdGlvbjogZmlsdGVyLmlucHV0QWN0aW9uLFxuICAgICAgICAgICAgICBpbnB1dEVuYWJsZWQ6IGZpbHRlci5pbnB1dEVuYWJsZWQsXG4gICAgICAgICAgICAgIG91dHB1dEFjdGlvbjogZmlsdGVyLm91dHB1dEFjdGlvbixcbiAgICAgICAgICAgICAgb3V0cHV0RW5hYmxlZDogZmlsdGVyLm91dHB1dEVuYWJsZWQsXG4gICAgICAgICAgICB9IGFzIGJlZHJvY2suQ2ZuR3VhcmRyYWlsLk1hbmFnZWRXb3Jkc0NvbmZpZ1Byb3BlcnR5O1xuICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIHsgb21pdEVtcHR5QXJyYXk6IHRydWUgfSxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHNlbnNpdGl2ZSBpbmZvcm1hdGlvbiBjb25maWcgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuU2Vuc2l0aXZlSW5mb3JtYXRpb25Qb2xpY3lDb25maWcoKTogSVJlc29sdmFibGUge1xuICAgIHJldHVybiBMYXp5LmFueShcbiAgICAgIHtcbiAgICAgICAgcHJvZHVjZTogKCkgPT4ge1xuICAgICAgICAgIGlmICh0aGlzLnJlZ2V4RmlsdGVycy5sZW5ndGggPiAwIHx8IHRoaXMucGlpRmlsdGVycy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICByZWdleGVzQ29uZmlnOiB0aGlzLmdlbmVyYXRlQ2ZuUmVnZXhlc0NvbmZpZygpLFxuICAgICAgICAgICAgICBwaWlFbnRpdGllc0NvbmZpZzogdGhpcy5nZW5lcmF0ZUNmblBpaUVudGl0aWVzQ29uZmlnKCksXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB7IG9taXRFbXB0eUFycmF5OiB0cnVlIH0sXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSByZWdleCBmaWx0ZXJzIGFwcGxpZWQgdG8gdGhlIGd1YXJkcmFpbC4gVGhpcyBtZXRob2QgZGVmZXJzIHRoZSBjb21wdXRhdGlvblxuICAgKiB0byBzeW50aCB0aW1lLlxuICAgKi9cbiAgcHJpdmF0ZSBnZW5lcmF0ZUNmblJlZ2V4ZXNDb25maWcoKTogSVJlc29sdmFibGUge1xuICAgIHJldHVybiBMYXp5LmFueShcbiAgICAgIHtcbiAgICAgICAgcHJvZHVjZTogKCkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLnJlZ2V4RmlsdGVycy5mbGF0TWFwKChyZWdleDogZmlsdGVycy5SZWdleEZpbHRlcikgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgbmFtZTogcmVnZXgubmFtZSxcbiAgICAgICAgICAgICAgZGVzY3JpcHRpb246IHJlZ2V4LmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICBwYXR0ZXJuOiByZWdleC5wYXR0ZXJuLFxuICAgICAgICAgICAgICBhY3Rpb246IHJlZ2V4LmFjdGlvbixcbiAgICAgICAgICAgICAgaW5wdXRBY3Rpb246IHJlZ2V4LmlucHV0QWN0aW9uLFxuICAgICAgICAgICAgICBpbnB1dEVuYWJsZWQ6IHJlZ2V4LmlucHV0RW5hYmxlZCxcbiAgICAgICAgICAgICAgb3V0cHV0QWN0aW9uOiByZWdleC5vdXRwdXRBY3Rpb24sXG4gICAgICAgICAgICAgIG91dHB1dEVuYWJsZWQ6IHJlZ2V4Lm91dHB1dEVuYWJsZWQsXG4gICAgICAgICAgICB9IGFzIGJlZHJvY2suQ2ZuR3VhcmRyYWlsLlJlZ2V4Q29uZmlnUHJvcGVydHk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgeyBvbWl0RW1wdHlBcnJheTogdHJ1ZSB9LFxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgUGlpIGZpbHRlcnMgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuUGlpRW50aXRpZXNDb25maWcoKTogSVJlc29sdmFibGUge1xuICAgIHJldHVybiBMYXp5LmFueShcbiAgICAgIHtcbiAgICAgICAgcHJvZHVjZTogKCkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLnBpaUZpbHRlcnMuZmxhdE1hcCgoZmlsdGVyOiBmaWx0ZXJzLlBJSUZpbHRlcikgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgdHlwZTogZmlsdGVyLnR5cGUudmFsdWUsXG4gICAgICAgICAgICAgIGFjdGlvbjogZmlsdGVyLmFjdGlvbixcbiAgICAgICAgICAgICAgaW5wdXRBY3Rpb246IGZpbHRlci5pbnB1dEFjdGlvbixcbiAgICAgICAgICAgICAgaW5wdXRFbmFibGVkOiBmaWx0ZXIuaW5wdXRFbmFibGVkLFxuICAgICAgICAgICAgICBvdXRwdXRBY3Rpb246IGZpbHRlci5vdXRwdXRBY3Rpb24sXG4gICAgICAgICAgICAgIG91dHB1dEVuYWJsZWQ6IGZpbHRlci5vdXRwdXRFbmFibGVkLFxuICAgICAgICAgICAgfSBhcyBiZWRyb2NrLkNmbkd1YXJkcmFpbC5QaWlFbnRpdHlDb25maWdQcm9wZXJ0eTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB7IG9taXRFbXB0eUFycmF5OiB0cnVlIH0sXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBjcm9zcy1yZWdpb24gY29uZmlndXJhdGlvbiBmb3IgdGhlIGd1YXJkcmFpbC4gVGhpcyBtZXRob2QgZGVmZXJzIHRoZSBjb21wdXRhdGlvblxuICAgKiB0byBzeW50aCB0aW1lLlxuICAgKi9cbiAgcHJpdmF0ZSBnZW5lcmF0ZUNmbkNyb3NzUmVnaW9uQ29uZmlnKCk6IElSZXNvbHZhYmxlIHtcbiAgICByZXR1cm4gTGF6eS5hbnkoe1xuICAgICAgcHJvZHVjZTogKCkgPT4ge1xuICAgICAgICBpZiAodGhpcy5jcm9zc1JlZ2lvbkNvbmZpZykge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBndWFyZHJhaWxQcm9maWxlQXJuOiB0aGlzLmNyb3NzUmVnaW9uQ29uZmlnLmd1YXJkcmFpbFByb2ZpbGVBcm4sXG4gICAgICAgICAgfSBhcyBiZWRyb2NrLkNmbkd1YXJkcmFpbC5HdWFyZHJhaWxDcm9zc1JlZ2lvbkNvbmZpZ1Byb3BlcnR5O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGEgUmVnZXhGaWx0ZXIgb2JqZWN0IGFuZCBhcHBsaWVzIGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSByZWdleCBmaWx0ZXIgdG8gdmFsaWRhdGUuXG4gICAqIEBwYXJhbSBpbmRleCBPcHRpb25hbCBpbmRleCBmb3IgZXJyb3IgbWVzc2FnZXMgd2hlbiB2YWxpZGF0aW5nIGFycmF5cy5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVSZWdleEZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuUmVnZXhGaWx0ZXIsIGluZGV4PzogbnVtYmVyKTogdm9pZCB7XG4gICAgY29uc3QgcHJlZml4ID0gaW5kZXggIT09IHVuZGVmaW5lZCA/IGBJbnZhbGlkIFJlZ2V4RmlsdGVyIGF0IGluZGV4ICR7aW5kZXh9YCA6ICdJbnZhbGlkIFJlZ2V4RmlsdGVyJztcblxuICAgIC8vIFZhbGlkYXRlIG5hbWU6IGJldHdlZW4gMSBhbmQgMTAwIGNoYXJhY3RlcnNcbiAgICBpZiAoZmlsdGVyLm5hbWUgIT09IHVuZGVmaW5lZCAmJiAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5uYW1lKSkge1xuICAgICAgaWYgKGZpbHRlci5uYW1lLmxlbmd0aCA8IDEpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgUmVnZXhGaWx0ZXJOYW1lVG9vU2hvcnRgLCBgJHtwcmVmaXh9OiBUaGUgZmllbGQgbmFtZSBpcyAke2ZpbHRlci5uYW1lLmxlbmd0aH0gY2hhcmFjdGVycyBsb25nIGJ1dCBtdXN0IGJlIGF0IGxlYXN0IDEgY2hhcmFjdGVyc2AsIHRoaXMpO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5uYW1lLmxlbmd0aCA+IDEwMCkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBSZWdleEZpbHRlck5hbWVUb29Mb25nYCwgYCR7cHJlZml4fTogVGhlIGZpZWxkIG5hbWUgaXMgJHtmaWx0ZXIubmFtZS5sZW5ndGh9IGNoYXJhY3RlcnMgbG9uZyBidXQgbXVzdCBiZSBsZXNzIHRoYW4gb3IgZXF1YWwgdG8gMTAwIGNoYXJhY3RlcnNgLCB0aGlzKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBkZXNjcmlwdGlvbjogYmV0d2VlbiAxIGFuZCAxMDAwIGNoYXJhY3RlcnMgKGlmIHByb3ZpZGVkKVxuICAgIGlmIChmaWx0ZXIuZGVzY3JpcHRpb24gIT09IHVuZGVmaW5lZCAmJiAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5kZXNjcmlwdGlvbikpIHtcbiAgICAgIGlmIChmaWx0ZXIuZGVzY3JpcHRpb24ubGVuZ3RoIDwgMSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBSZWdleEZpbHRlckRlc2NyaXB0aW9uVG9vU2hvcnRgLCBgJHtwcmVmaXh9OiBUaGUgZmllbGQgZGVzY3JpcHRpb24gaXMgJHtmaWx0ZXIuZGVzY3JpcHRpb24ubGVuZ3RofSBjaGFyYWN0ZXJzIGxvbmcgYnV0IG11c3QgYmUgYXQgbGVhc3QgMSBjaGFyYWN0ZXJzYCwgdGhpcyk7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLmRlc2NyaXB0aW9uLmxlbmd0aCA+IDEwMDApIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgUmVnZXhGaWx0ZXJEZXNjcmlwdGlvblRvb0xvbmdgLCBgJHtwcmVmaXh9OiBUaGUgZmllbGQgZGVzY3JpcHRpb24gaXMgJHtmaWx0ZXIuZGVzY3JpcHRpb24ubGVuZ3RofSBjaGFyYWN0ZXJzIGxvbmcgYnV0IG11c3QgYmUgbGVzcyB0aGFuIG9yIGVxdWFsIHRvIDEwMDAgY2hhcmFjdGVyc2AsIHRoaXMpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIHBhdHRlcm46IGF0IGxlYXN0IG9uZSBjaGFyYWN0ZXJcbiAgICBpZiAoZmlsdGVyLnBhdHRlcm4gIT09IHVuZGVmaW5lZCAmJiAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5wYXR0ZXJuKSkge1xuICAgICAgaWYgKGZpbHRlci5wYXR0ZXJuLmxlbmd0aCA8IDEpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgUmVnZXhGaWx0ZXJQYXR0ZXJuRW1wdHlgLCBgJHtwcmVmaXh9OiBUaGUgZmllbGQgcGF0dGVybiBpcyAke2ZpbHRlci5wYXR0ZXJuLmxlbmd0aH0gY2hhcmFjdGVycyBsb25nIGJ1dCBtdXN0IGJlIGF0IGxlYXN0IDEgY2hhcmFjdGVyc2AsIHRoaXMpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIGFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZVxuICAgIGlmIChmaWx0ZXIuYWN0aW9uICE9PSB1bmRlZmluZWQgJiYgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuYWN0aW9uKSAmJiAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmFjdGlvbikpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YEludmFsaWRHdWFyZHJhaWxBY3Rpb25gLCBgJHtwcmVmaXh9OiBhY3Rpb24gbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZWAsIHRoaXMpO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIGlucHV0QWN0aW9uOiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlIChpZiBwcm92aWRlZClcbiAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRBY3Rpb24pICYmXG4gICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIuaW5wdXRBY3Rpb24pKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkSW5wdXRBY3Rpb25gLCBgJHtwcmVmaXh9OiBpbnB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgb3V0cHV0QWN0aW9uOiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlIChpZiBwcm92aWRlZClcbiAgICBpZiAoZmlsdGVyLm91dHB1dEFjdGlvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLm91dHB1dEFjdGlvbikgJiZcbiAgICAgICAgIU9iamVjdC52YWx1ZXMoZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24pLmluY2x1ZGVzKGZpbHRlci5vdXRwdXRBY3Rpb24pKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkT3V0cHV0QWN0aW9uYCwgYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBpbnB1dEVuYWJsZWQ6IG11c3QgYmUgYSBib29sZWFuIChpZiBwcm92aWRlZClcbiAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLmlucHV0RW5hYmxlZCkgJiZcbiAgICAgICAgdHlwZW9mIGZpbHRlci5pbnB1dEVuYWJsZWQgIT09ICdib29sZWFuJykge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgSW5wdXRFbmFibGVkTm90Qm9vbGVhbmAsIGAke3ByZWZpeH06IGlucHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIG91dHB1dEVuYWJsZWQ6IG11c3QgYmUgYSBib29sZWFuIChpZiBwcm92aWRlZClcbiAgICBpZiAoZmlsdGVyLm91dHB1dEVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5vdXRwdXRFbmFibGVkKSAmJlxuICAgICAgICB0eXBlb2YgZmlsdGVyLm91dHB1dEVuYWJsZWQgIT09ICdib29sZWFuJykge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgT3V0cHV0RW5hYmxlZE5vdEJvb2xlYW5gLCBgJHtwcmVmaXh9OiBvdXRwdXRFbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgfVxuXG4gICAgLy8gQXBwbHkgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMgaWYgbm90IHByb3ZpZGVkXG4gICAgaWYgKGZpbHRlci5pbnB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAoZmlsdGVyIGFzIGFueSkuaW5wdXRBY3Rpb24gPSBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbi5CTE9DSztcbiAgICB9XG4gICAgaWYgKGZpbHRlci5pbnB1dEVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgKGZpbHRlciBhcyBhbnkpLmlucHV0RW5hYmxlZCA9IHRydWU7XG4gICAgfVxuICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgIChmaWx0ZXIgYXMgYW55KS5vdXRwdXRBY3Rpb24gPSBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbi5CTE9DSztcbiAgICB9XG4gICAgaWYgKGZpbHRlci5vdXRwdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgIChmaWx0ZXIgYXMgYW55KS5vdXRwdXRFbmFibGVkID0gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGEgbWVzc2FnaW5nIHByb3BlcnR5IChibG9ja2VkSW5wdXRNZXNzYWdpbmcgb3IgYmxvY2tlZE91dHB1dHNNZXNzYWdpbmcpLlxuICAgKiBAcGFyYW0gdmFsdWUgVGhlIG1lc3NhZ2luZyB2YWx1ZSB0byB2YWxpZGF0ZS5cbiAgICogQHBhcmFtIHByb3BlcnR5TmFtZSBUaGUgbmFtZSBvZiB0aGUgcHJvcGVydHkgYmVpbmcgdmFsaWRhdGVkLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZU1lc3NhZ2luZ1Byb3BlcnR5KHZhbHVlOiBzdHJpbmcgfCB1bmRlZmluZWQsIHByb3BlcnR5TmFtZTogc3RyaW5nKTogdm9pZCB7XG4gICAgaWYgKHZhbHVlICE9PSB1bmRlZmluZWQgJiYgIVRva2VuLmlzVW5yZXNvbHZlZCh2YWx1ZSkpIHtcbiAgICAgIGlmICh2YWx1ZS5sZW5ndGggPCAxKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YE1lc3NhZ2luZ1Byb3BlcnR5VG9vU2hvcnRgLCBgSW52YWxpZCAke3Byb3BlcnR5TmFtZX06IFRoZSBmaWVsZCAke3Byb3BlcnR5TmFtZX0gaXMgJHt2YWx1ZS5sZW5ndGh9IGNoYXJhY3RlcnMgbG9uZyBidXQgbXVzdCBiZSBhdCBsZWFzdCAxIGNoYXJhY3RlcnNgLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGlmICh2YWx1ZS5sZW5ndGggPiA1MDApIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgTWVzc2FnaW5nUHJvcGVydHlUb29Mb25nYCwgYEludmFsaWQgJHtwcm9wZXJ0eU5hbWV9OiBUaGUgZmllbGQgJHtwcm9wZXJ0eU5hbWV9IGlzICR7dmFsdWUubGVuZ3RofSBjaGFyYWN0ZXJzIGxvbmcgYnV0IG11c3QgYmUgbGVzcyB0aGFuIG9yIGVxdWFsIHRvIDUwMCBjaGFyYWN0ZXJzYCwgdGhpcyk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyB0aGF0IGNyb3NzLXJlZ2lvbiBjb25maWd1cmF0aW9uIGlzIHByb3ZpZGVkIHdoZW4gU1RBTkRBUkQgdGllciBpcyB1c2VkLlxuICAgKiBAcGFyYW0gcHJvcHMgVGhlIGd1YXJkcmFpbCBwcm9wZXJ0aWVzIHRvIHZhbGlkYXRlLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVRpZXJDb25maWd1cmF0aW9uKHByb3BzOiBHdWFyZHJhaWxQcm9wcyk6IHZvaWQge1xuICAgIGNvbnN0IGNvbnRlbnRUaWVyQ29uZmlnID0gcHJvcHMuY29udGVudEZpbHRlcnNUaWVyQ29uZmlnID8/IGZpbHRlcnMuVGllckNvbmZpZy5DTEFTU0lDO1xuICAgIGNvbnN0IHRvcGljc1RpZXJDb25maWcgPSBwcm9wcy50b3BpY3NUaWVyQ29uZmlnID8/IGZpbHRlcnMuVGllckNvbmZpZy5DTEFTU0lDO1xuICAgIGNvbnN0IGhhc0Nyb3NzUmVnaW9uQ29uZmlnID0gcHJvcHMuY3Jvc3NSZWdpb25Db25maWcgIT09IHVuZGVmaW5lZDtcblxuICAgIC8vIENoZWNrIGlmIFNUQU5EQVJEIHRpZXIgaXMgdXNlZCBmb3IgY29udGVudCBmaWx0ZXJzXG4gICAgaWYgKGNvbnRlbnRUaWVyQ29uZmlnID09PSBmaWx0ZXJzLlRpZXJDb25maWcuU1RBTkRBUkQgJiYgIWhhc0Nyb3NzUmVnaW9uQ29uZmlnKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKFxuICAgICAgICBsaXRgU3RhbmRhcmRUaWVyUmVxdWlyZXNDcm9zc1JlZ2lvbmAsXG4gICAgICAgICdDcm9zcy1yZWdpb24gY29uZmlndXJhdGlvbiBpcyByZXF1aXJlZCB3aGVuIHVzaW5nIFNUQU5EQVJEIHRpZXIgZm9yIGNvbnRlbnQgZmlsdGVycy4gJyArXG4gICAgICAgICdQbGVhc2UgcHJvdmlkZSBhIGNyb3NzUmVnaW9uQ29uZmlnIHByb3BlcnR5IHdpdGggYSB2YWxpZCBndWFyZHJhaWxQcm9maWxlQXJuLicsXG4gICAgICAgIHRoaXMsXG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIENoZWNrIGlmIFNUQU5EQVJEIHRpZXIgaXMgdXNlZCBmb3IgdG9waWMgZmlsdGVyc1xuICAgIGlmICh0b3BpY3NUaWVyQ29uZmlnID09PSBmaWx0ZXJzLlRpZXJDb25maWcuU1RBTkRBUkQgJiYgIWhhc0Nyb3NzUmVnaW9uQ29uZmlnKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKFxuICAgICAgICBsaXRgU3RhbmRhcmRUaWVyUmVxdWlyZXNDcm9zc1JlZ2lvbmAsXG4gICAgICAgICdDcm9zcy1yZWdpb24gY29uZmlndXJhdGlvbiBpcyByZXF1aXJlZCB3aGVuIHVzaW5nIFNUQU5EQVJEIHRpZXIgZm9yIHRvcGljIGZpbHRlcnMuICcgK1xuICAgICAgICAnUGxlYXNlIHByb3ZpZGUgYSBjcm9zc1JlZ2lvbkNvbmZpZyBwcm9wZXJ0eSB3aXRoIGEgdmFsaWQgZ3VhcmRyYWlsUHJvZmlsZUFybi4nLFxuICAgICAgICB0aGlzLFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGNvbnRlbnQgZmlsdGVycyBhcnJheSBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIGNvbnRlbnRGaWx0ZXJzIFRoZSBjb250ZW50IGZpbHRlcnMgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlQ29udGVudEZpbHRlcnMoY29udGVudEZpbHRlcnM/OiBmaWx0ZXJzLkNvbnRlbnRGaWx0ZXJbXSk6IHZvaWQge1xuICAgIGlmICghY29udGVudEZpbHRlcnMpIHJldHVybjtcblxuICAgIGNvbnRlbnRGaWx0ZXJzLmZvckVhY2goKGZpbHRlciwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IHByZWZpeCA9IGBJbnZhbGlkIENvbnRlbnRGaWx0ZXIgYXQgaW5kZXggJHtpbmRleH1gO1xuXG4gICAgICAvLyBWYWxpZGF0ZSB0aGF0IHRoZSBmaWx0ZXIgaGFzIHJlcXVpcmVkIHByb3BlcnRpZXNcbiAgICAgIGlmICghZmlsdGVyLnR5cGUpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgQ29udGVudEZpbHRlclR5cGVNaXNzaW5nYCwgYCR7cHJlZml4fTogdHlwZSBpcyByZXF1aXJlZGAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBpbnB1dCBzdHJlbmd0aFxuICAgICAgaWYgKGZpbHRlci5pbnB1dFN0cmVuZ3RoICE9PSB1bmRlZmluZWQgJiYgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRTdHJlbmd0aCkpIHtcbiAgICAgICAgaWYgKCFPYmplY3QudmFsdWVzKGZpbHRlcnMuQ29udGVudEZpbHRlclN0cmVuZ3RoKS5pbmNsdWRlcyhmaWx0ZXIuaW5wdXRTdHJlbmd0aCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkSW5wdXRTdHJlbmd0aGAsIGAke3ByZWZpeH06IGlucHV0U3RyZW5ndGggbXVzdCBiZSBhIHZhbGlkIENvbnRlbnRGaWx0ZXJTdHJlbmd0aCB2YWx1ZWAsIHRoaXMpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIG91dHB1dCBzdHJlbmd0aFxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRTdHJlbmd0aCAhPT0gdW5kZWZpbmVkICYmICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLm91dHB1dFN0cmVuZ3RoKSkge1xuICAgICAgICBpZiAoIU9iamVjdC52YWx1ZXMoZmlsdGVycy5Db250ZW50RmlsdGVyU3RyZW5ndGgpLmluY2x1ZGVzKGZpbHRlci5vdXRwdXRTdHJlbmd0aCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkT3V0cHV0U3RyZW5ndGhgLCBgJHtwcmVmaXh9OiBvdXRwdXRTdHJlbmd0aCBtdXN0IGJlIGEgdmFsaWQgQ29udGVudEZpbHRlclN0cmVuZ3RoIHZhbHVlYCwgdGhpcyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXQgbW9kYWxpdGllc1xuICAgICAgaWYgKGZpbHRlci5pbnB1dE1vZGFsaXRpZXMpIHtcbiAgICAgICAgZmlsdGVyLmlucHV0TW9kYWxpdGllcy5mb3JFYWNoKChtb2RhbGl0eSwgbW9kYWxpdHlJbmRleCkgPT4ge1xuICAgICAgICAgIGlmICghT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLk1vZGFsaXR5VHlwZSkuaW5jbHVkZXMobW9kYWxpdHkpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkSW5wdXRNb2RhbGl0eWAsIGAke3ByZWZpeH06IGlucHV0TW9kYWxpdGllc1ske21vZGFsaXR5SW5kZXh9XSBtdXN0IGJlIGEgdmFsaWQgTW9kYWxpdHlUeXBlIHZhbHVlYCwgdGhpcyk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgb3V0cHV0IG1vZGFsaXRpZXNcbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0TW9kYWxpdGllcykge1xuICAgICAgICBmaWx0ZXIub3V0cHV0TW9kYWxpdGllcy5mb3JFYWNoKChtb2RhbGl0eSwgbW9kYWxpdHlJbmRleCkgPT4ge1xuICAgICAgICAgIGlmICghT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLk1vZGFsaXR5VHlwZSkuaW5jbHVkZXMobW9kYWxpdHkpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkT3V0cHV0TW9kYWxpdHlgLCBgJHtwcmVmaXh9OiBvdXRwdXRNb2RhbGl0aWVzWyR7bW9kYWxpdHlJbmRleH1dIG11c3QgYmUgYSB2YWxpZCBNb2RhbGl0eVR5cGUgdmFsdWVgLCB0aGlzKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBpbnB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5pbnB1dEFjdGlvbikgJiZcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmlucHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkSW5wdXRBY3Rpb25gLCBgJHtwcmVmaXh9OiBpbnB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIG91dHB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEFjdGlvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIub3V0cHV0QWN0aW9uKSAmJlxuICAgICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIub3V0cHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkT3V0cHV0QWN0aW9uYCwgYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIuaW5wdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgSW5wdXRFbmFibGVkTm90Qm9vbGVhbmAsIGAke3ByZWZpeH06IGlucHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBvdXRwdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLm91dHB1dEVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIGZpbHRlci5vdXRwdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgT3V0cHV0RW5hYmxlZE5vdEJvb2xlYW5gLCBgJHtwcmVmaXh9OiBvdXRwdXRFbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFwcGx5IGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzIGlmIG5vdCBwcm92aWRlZFxuICAgICAgaWYgKGZpbHRlci5pbnB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5pbnB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5pbnB1dEVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuaW5wdXRFbmFibGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEVuYWJsZWQgPSB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBQSUkgZmlsdGVycyBhcnJheSBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIHBpaUZpbHRlcnMgVGhlIFBJSSBmaWx0ZXJzIHRvIHZhbGlkYXRlLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVBpaUZpbHRlcnMocGlpRmlsdGVycz86IGZpbHRlcnMuUElJRmlsdGVyW10pOiB2b2lkIHtcbiAgICBpZiAoIXBpaUZpbHRlcnMpIHJldHVybjtcblxuICAgIHBpaUZpbHRlcnMuZm9yRWFjaCgoZmlsdGVyLCBpbmRleCkgPT4ge1xuICAgICAgY29uc3QgcHJlZml4ID0gYEludmFsaWQgUElJRmlsdGVyIGF0IGluZGV4ICR7aW5kZXh9YDtcblxuICAgICAgLy8gVmFsaWRhdGUgdGhhdCB0aGUgZmlsdGVyIGhhcyByZXF1aXJlZCBwcm9wZXJ0aWVzXG4gICAgICBpZiAoIWZpbHRlci50eXBlKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YFBpaUZpbHRlclR5cGVNaXNzaW5nYCwgYCR7cHJlZml4fTogdHlwZSBpcyByZXF1aXJlZGAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICBpZiAoIWZpbHRlci5hY3Rpb24pIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgUGlpRmlsdGVyQWN0aW9uTWlzc2luZ2AsIGAke3ByZWZpeH06IGFjdGlvbiBpcyByZXF1aXJlZGAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBhY3Rpb24gdmFsdWVzXG4gICAgICBpZiAoIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuYWN0aW9uKSAmJiAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmFjdGlvbikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgSW52YWxpZEd1YXJkcmFpbEFjdGlvbmAsIGAke3ByZWZpeH06IGFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIGlmIChmaWx0ZXIuaW5wdXRBY3Rpb24gJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5pbnB1dEFjdGlvbikgJiZcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmlucHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkSW5wdXRBY3Rpb25gLCBgJHtwcmVmaXh9OiBpbnB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIub3V0cHV0QWN0aW9uKSAmJlxuICAgICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIub3V0cHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkT3V0cHV0QWN0aW9uYCwgYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIuaW5wdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgSW5wdXRFbmFibGVkTm90Qm9vbGVhbmAsIGAke3ByZWZpeH06IGlucHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBvdXRwdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLm91dHB1dEVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIGZpbHRlci5vdXRwdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgT3V0cHV0RW5hYmxlZE5vdEJvb2xlYW5gLCBgJHtwcmVmaXh9OiBvdXRwdXRFbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFwcGx5IGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzIGlmIG5vdCBwcm92aWRlZFxuICAgICAgaWYgKGZpbHRlci5pbnB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5pbnB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5pbnB1dEVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuaW5wdXRFbmFibGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEVuYWJsZWQgPSB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyByZWdleCBmaWx0ZXJzIGFycmF5LlxuICAgKiBAcGFyYW0gcmVnZXhGaWx0ZXJzIFRoZSByZWdleCBmaWx0ZXJzIHRvIHZhbGlkYXRlLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVJlZ2V4RmlsdGVycyhyZWdleEZpbHRlcnM/OiBmaWx0ZXJzLlJlZ2V4RmlsdGVyW10pOiB2b2lkIHtcbiAgICBpZiAoIXJlZ2V4RmlsdGVycykgcmV0dXJuO1xuXG4gICAgcmVnZXhGaWx0ZXJzLmZvckVhY2goKGZpbHRlciwgaW5kZXgpID0+IHtcbiAgICAgIHRoaXMudmFsaWRhdGVSZWdleEZpbHRlcihmaWx0ZXIsIGluZGV4KTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgZGVuaWVkIHRvcGljcyBhcnJheSBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIGRlbmllZFRvcGljcyBUaGUgZGVuaWVkIHRvcGljcyB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVEZW5pZWRUb3BpY3MoZGVuaWVkVG9waWNzPzogZmlsdGVycy5Ub3BpY1tdKTogdm9pZCB7XG4gICAgaWYgKCFkZW5pZWRUb3BpY3MpIHJldHVybjtcblxuICAgIGRlbmllZFRvcGljcy5mb3JFYWNoKCh0b3BpYywgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IHByZWZpeCA9IGBJbnZhbGlkIFRvcGljIGF0IGluZGV4ICR7aW5kZXh9YDtcblxuICAgICAgLy8gVmFsaWRhdGUgdGhhdCB0aGUgdG9waWMgaGFzIHJlcXVpcmVkIHByb3BlcnRpZXNcbiAgICAgIGlmICghdG9waWMubmFtZSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBUb3BpY05hbWVNaXNzaW5nYCwgYCR7cHJlZml4fTogbmFtZSBpcyByZXF1aXJlZGAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICBpZiAoIXRvcGljLmRlZmluaXRpb24pIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgVG9waWNEZWZpbml0aW9uTWlzc2luZ2AsIGAke3ByZWZpeH06IGRlZmluaXRpb24gaXMgcmVxdWlyZWRgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgbmFtZSBsZW5ndGhcbiAgICAgIGlmICghVG9rZW4uaXNVbnJlc29sdmVkKHRvcGljLm5hbWUpICYmIHRvcGljLm5hbWUubGVuZ3RoID4gMTAwKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YFRvcGljTmFtZVRvb0xvbmdgLCBgJHtwcmVmaXh9OiBuYW1lIG11c3QgYmUgMTAwIGNoYXJhY3RlcnMgb3IgbGVzc2AsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBkZWZpbml0aW9uIGxlbmd0aFxuICAgICAgaWYgKCFUb2tlbi5pc1VucmVzb2x2ZWQodG9waWMuZGVmaW5pdGlvbikgJiYgdG9waWMuZGVmaW5pdGlvbi5sZW5ndGggPiAxMDAwKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YFRvcGljRGVmaW5pdGlvblRvb0xvbmdgLCBgJHtwcmVmaXh9OiBkZWZpbml0aW9uIG11c3QgYmUgMTAwMCBjaGFyYWN0ZXJzIG9yIGxlc3NgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgZXhhbXBsZXMgaWYgcHJvdmlkZWRcbiAgICAgIGlmICh0b3BpYy5leGFtcGxlcykge1xuICAgICAgICBpZiAodG9waWMuZXhhbXBsZXMubGVuZ3RoID4gMTAwKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgVG9waWNFeGFtcGxlc1Rvb01hbnlgLCBgJHtwcmVmaXh9OiBleGFtcGxlcyBhcnJheSBjYW5ub3QgY29udGFpbiBtb3JlIHRoYW4gMTAwIGV4YW1wbGVzYCwgdGhpcyk7XG4gICAgICAgIH1cblxuICAgICAgICB0b3BpYy5leGFtcGxlcy5mb3JFYWNoKChleGFtcGxlLCBleGFtcGxlSW5kZXgpID0+IHtcbiAgICAgICAgICBpZiAoIVRva2VuLmlzVW5yZXNvbHZlZChleGFtcGxlKSAmJiBleGFtcGxlLmxlbmd0aCA+IDEwMCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgVG9waWNFeGFtcGxlVG9vTG9uZ2AsIGAke3ByZWZpeH06IGV4YW1wbGVzWyR7ZXhhbXBsZUluZGV4fV0gbXVzdCBiZSAxMDAgY2hhcmFjdGVycyBvciBsZXNzYCwgdGhpcyk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRBY3Rpb246IG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWUgKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKHRvcGljLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKHRvcGljLmlucHV0QWN0aW9uKSAmJlxuICAgICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyh0b3BpYy5pbnB1dEFjdGlvbikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgSW52YWxpZElucHV0QWN0aW9uYCwgYCR7cHJlZml4fTogaW5wdXRBY3Rpb24gbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBvdXRwdXRBY3Rpb246IG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWUgKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKHRvcGljLm91dHB1dEFjdGlvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZCh0b3BpYy5vdXRwdXRBY3Rpb24pICYmXG4gICAgICAgICAgIU9iamVjdC52YWx1ZXMoZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24pLmluY2x1ZGVzKHRvcGljLm91dHB1dEFjdGlvbikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgSW52YWxpZE91dHB1dEFjdGlvbmAsIGAke3ByZWZpeH06IG91dHB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIGlucHV0RW5hYmxlZDogbXVzdCBiZSBhIGJvb2xlYW4gKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKHRvcGljLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZCh0b3BpYy5pbnB1dEVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIHRvcGljLmlucHV0RW5hYmxlZCAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YElucHV0RW5hYmxlZE5vdEJvb2xlYW5gLCBgJHtwcmVmaXh9OiBpbnB1dEVuYWJsZWQgbXVzdCBiZSBhIGJvb2xlYW4gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgb3V0cHV0RW5hYmxlZDogbXVzdCBiZSBhIGJvb2xlYW4gKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKHRvcGljLm91dHB1dEVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQodG9waWMub3V0cHV0RW5hYmxlZCkgJiZcbiAgICAgICAgICB0eXBlb2YgdG9waWMub3V0cHV0RW5hYmxlZCAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YE91dHB1dEVuYWJsZWROb3RCb29sZWFuYCwgYCR7cHJlZml4fTogb3V0cHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBBcHBseSBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcyBpZiBub3QgcHJvdmlkZWRcbiAgICAgIGlmICh0b3BpYy5pbnB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICh0b3BpYyBhcyBhbnkpLmlucHV0QWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgICB9XG4gICAgICBpZiAodG9waWMuaW5wdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKHRvcGljIGFzIGFueSkuaW5wdXRFbmFibGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmICh0b3BpYy5vdXRwdXRBY3Rpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAodG9waWMgYXMgYW55KS5vdXRwdXRBY3Rpb24gPSBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbi5CTE9DSztcbiAgICAgIH1cbiAgICAgIGlmICh0b3BpYy5vdXRwdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKHRvcGljIGFzIGFueSkub3V0cHV0RW5hYmxlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGNvbnRleHR1YWwgZ3JvdW5kaW5nIGZpbHRlcnMgYXJyYXkgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBjb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycyBUaGUgY29udGV4dHVhbCBncm91bmRpbmcgZmlsdGVycyB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVDb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycyhjb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycz86IGZpbHRlcnMuQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcltdKTogdm9pZCB7XG4gICAgaWYgKCFjb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycykgcmV0dXJuO1xuXG4gICAgY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMuZm9yRWFjaCgoZmlsdGVyLCBpbmRleCkgPT4ge1xuICAgICAgY29uc3QgcHJlZml4ID0gYEludmFsaWQgQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlciBhdCBpbmRleCAke2luZGV4fWA7XG5cbiAgICAgIC8vIFZhbGlkYXRlIHRoYXQgdGhlIGZpbHRlciBoYXMgcmVxdWlyZWQgcHJvcGVydGllc1xuICAgICAgaWYgKCFmaWx0ZXIudHlwZSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBDb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyVHlwZU1pc3NpbmdgLCBgJHtwcmVmaXh9OiB0eXBlIGlzIHJlcXVpcmVkYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIGlmIChmaWx0ZXIudGhyZXNob2xkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlclRocmVzaG9sZE1pc3NpbmdgLCBgJHtwcmVmaXh9OiB0aHJlc2hvbGQgaXMgcmVxdWlyZWRgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgdHlwZVxuICAgICAgaWYgKCFPYmplY3QudmFsdWVzKGZpbHRlcnMuQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlclR5cGUpLmluY2x1ZGVzKGZpbHRlci50eXBlKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlclR5cGVgLCBgJHtwcmVmaXh9OiB0eXBlIG11c3QgYmUgYSB2YWxpZCBDb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyVHlwZSB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSB0aHJlc2hvbGQgcmFuZ2VcbiAgICAgIGlmICghVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci50aHJlc2hvbGQpKSB7XG4gICAgICAgIGlmIChmaWx0ZXIudGhyZXNob2xkIDwgMCB8fCBmaWx0ZXIudGhyZXNob2xkID4gMC45OSkge1xuICAgICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YENvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJUaHJlc2hvbGRPdXRPZlJhbmdlYCwgYCR7cHJlZml4fTogdGhyZXNob2xkIG11c3QgYmUgYmV0d2VlbiAwIGFuZCAwLjk5YCwgdGhpcyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgYWN0aW9uOiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlIChpZiBwcm92aWRlZClcbiAgICAgIGlmIChmaWx0ZXIuYWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5hY3Rpb24pICYmXG4gICAgICAgICAgIU9iamVjdC52YWx1ZXMoZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24pLmluY2x1ZGVzKGZpbHRlci5hY3Rpb24pKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IobGl0YEludmFsaWRHdWFyZHJhaWxBY3Rpb25gLCBgJHtwcmVmaXh9OiBhY3Rpb24gbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBlbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLmVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIGZpbHRlci5lbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgRW5hYmxlZE5vdEJvb2xlYW5gLCBgJHtwcmVmaXh9OiBlbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFwcGx5IGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzIGlmIG5vdCBwcm92aWRlZFxuICAgICAgaWYgKGZpbHRlci5hY3Rpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuYWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLmVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuZW5hYmxlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIHdvcmQgZmlsdGVycyBhcnJheSBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIHdvcmRGaWx0ZXJzIFRoZSB3b3JkIGZpbHRlcnMgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlV29yZEZpbHRlcnMod29yZEZpbHRlcnM/OiBmaWx0ZXJzLldvcmRGaWx0ZXJbXSk6IHZvaWQge1xuICAgIGlmICghd29yZEZpbHRlcnMpIHJldHVybjtcblxuICAgIHdvcmRGaWx0ZXJzLmZvckVhY2goKGZpbHRlciwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IHByZWZpeCA9IGBJbnZhbGlkIFdvcmRGaWx0ZXIgYXQgaW5kZXggJHtpbmRleH1gO1xuXG4gICAgICAvLyBWYWxpZGF0ZSB0aGF0IHRoZSBmaWx0ZXIgaGFzIHJlcXVpcmVkIHByb3BlcnRpZXNcbiAgICAgIGlmICghZmlsdGVyLnRleHQpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgV29yZEZpbHRlclRleHRNaXNzaW5nYCwgYCR7cHJlZml4fTogdGV4dCBpcyByZXF1aXJlZGAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSB0ZXh0IGxlbmd0aFxuICAgICAgaWYgKCFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLnRleHQpICYmIGZpbHRlci50ZXh0Lmxlbmd0aCA+IDEwMCkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBXb3JkRmlsdGVyVGV4dFRvb0xvbmdgLCBgJHtwcmVmaXh9OiB0ZXh0IG11c3QgYmUgMTAwIGNoYXJhY3RlcnMgb3IgbGVzc2AsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBpbnB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5pbnB1dEFjdGlvbikgJiZcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmlucHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkSW5wdXRBY3Rpb25gLCBgJHtwcmVmaXh9OiBpbnB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIG91dHB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEFjdGlvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIub3V0cHV0QWN0aW9uKSAmJlxuICAgICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIub3V0cHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkT3V0cHV0QWN0aW9uYCwgYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIuaW5wdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgSW5wdXRFbmFibGVkTm90Qm9vbGVhbmAsIGAke3ByZWZpeH06IGlucHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBvdXRwdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLm91dHB1dEVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIGZpbHRlci5vdXRwdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgT3V0cHV0RW5hYmxlZE5vdEJvb2xlYW5gLCBgJHtwcmVmaXh9OiBvdXRwdXRFbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFwcGx5IGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzIGlmIG5vdCBwcm92aWRlZFxuICAgICAgaWYgKGZpbHRlci5pbnB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5pbnB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5pbnB1dEVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuaW5wdXRFbmFibGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEVuYWJsZWQgPSB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBtYW5hZ2VkIHdvcmQgbGlzdCBmaWx0ZXJzIGFycmF5IGFuZCBhcHBsaWVzIGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzLlxuICAgKiBAcGFyYW0gbWFuYWdlZFdvcmRMaXN0RmlsdGVycyBUaGUgbWFuYWdlZCB3b3JkIGxpc3QgZmlsdGVycyB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVNYW5hZ2VkV29yZExpc3RGaWx0ZXJzKG1hbmFnZWRXb3JkTGlzdEZpbHRlcnM/OiBmaWx0ZXJzLk1hbmFnZWRXb3JkRmlsdGVyW10pOiB2b2lkIHtcbiAgICBpZiAoIW1hbmFnZWRXb3JkTGlzdEZpbHRlcnMpIHJldHVybjtcblxuICAgIG1hbmFnZWRXb3JkTGlzdEZpbHRlcnMuZm9yRWFjaCgoZmlsdGVyLCBpbmRleCkgPT4ge1xuICAgICAgY29uc3QgcHJlZml4ID0gYEludmFsaWQgTWFuYWdlZFdvcmRGaWx0ZXIgYXQgaW5kZXggJHtpbmRleH1gO1xuXG4gICAgICAvLyBWYWxpZGF0ZSB0eXBlOiBtdXN0IGJlIGEgdmFsaWQgTWFuYWdlZFdvcmRGaWx0ZXJUeXBlIHZhbHVlIChpZiBwcm92aWRlZClcbiAgICAgIGlmIChmaWx0ZXIudHlwZSAhPT0gdW5kZWZpbmVkICYmICFPYmplY3QudmFsdWVzKGZpbHRlcnMuTWFuYWdlZFdvcmRGaWx0ZXJUeXBlKS5pbmNsdWRlcyhmaWx0ZXIudHlwZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgSW52YWxpZE1hbmFnZWRXb3JkRmlsdGVyVHlwZWAsIGAke3ByZWZpeH06IHR5cGUgbXVzdCBiZSBhIHZhbGlkIE1hbmFnZWRXb3JkRmlsdGVyVHlwZSB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBpbnB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5pbnB1dEFjdGlvbikgJiZcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmlucHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkSW5wdXRBY3Rpb25gLCBgJHtwcmVmaXh9OiBpbnB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIG91dHB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEFjdGlvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIub3V0cHV0QWN0aW9uKSAmJlxuICAgICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIub3V0cHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGxpdGBJbnZhbGlkT3V0cHV0QWN0aW9uYCwgYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIuaW5wdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgSW5wdXRFbmFibGVkTm90Qm9vbGVhbmAsIGAke3ByZWZpeH06IGlucHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBvdXRwdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLm91dHB1dEVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIGZpbHRlci5vdXRwdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihsaXRgT3V0cHV0RW5hYmxlZE5vdEJvb2xlYW5gLCBgJHtwcmVmaXh9OiBvdXRwdXRFbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFwcGx5IGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzIGlmIG5vdCBwcm92aWRlZFxuICAgICAgaWYgKGZpbHRlci50eXBlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLnR5cGUgPSBmaWx0ZXJzLk1hbmFnZWRXb3JkRmlsdGVyVHlwZS5QUk9GQU5JVFk7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLmlucHV0QWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5pbnB1dEVuYWJsZWQgPSB0cnVlO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRBY3Rpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkub3V0cHV0QWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkub3V0cHV0RW5hYmxlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGEgc2luZ2xlIGNvbnRlbnQgZmlsdGVyIGFuZCBhcHBsaWVzIGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSBjb250ZW50IGZpbHRlciB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVTaW5nbGVDb250ZW50RmlsdGVyKGZpbHRlcjogZmlsdGVycy5Db250ZW50RmlsdGVyKTogdm9pZCB7XG4gICAgLy8gVXNlIHRoZSBleGlzdGluZyB2YWxpZGF0aW9uIGxvZ2ljIGJ1dCBjYXRjaCBhbmQgcmUtdGhyb3cgd2l0aCBhIGNsZWFyZXIgZXJyb3IgbWVzc2FnZVxuICAgIHRyeSB7XG4gICAgICB0aGlzLnZhbGlkYXRlQ29udGVudEZpbHRlcnMoW2ZpbHRlcl0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBWYWxpZGF0aW9uRXJyb3IpIHtcbiAgICAgICAgLy8gUmVwbGFjZSBcImF0IGluZGV4IDBcIiB3aXRoIGEgY2xlYXJlciBtZXNzYWdlIGZvciBzaW5nbGUgZmlsdGVyIHZhbGlkYXRpb25cbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UucmVwbGFjZSgnIGF0IGluZGV4IDAnLCAnJyk7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoZXJyb3IubmFtZSBhcyBMaXRlcmFsU3RyaW5nLCBtZXNzYWdlLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgYSBzaW5nbGUgUElJIGZpbHRlciBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIGZpbHRlciBUaGUgUElJIGZpbHRlciB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVTaW5nbGVQaWlGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLlBJSUZpbHRlcik6IHZvaWQge1xuICAgIC8vIFVzZSB0aGUgZXhpc3RpbmcgdmFsaWRhdGlvbiBsb2dpYyBidXQgY2F0Y2ggYW5kIHJlLXRocm93IHdpdGggYSBjbGVhcmVyIGVycm9yIG1lc3NhZ2VcbiAgICB0cnkge1xuICAgICAgdGhpcy52YWxpZGF0ZVBpaUZpbHRlcnMoW2ZpbHRlcl0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBWYWxpZGF0aW9uRXJyb3IpIHtcbiAgICAgICAgLy8gUmVwbGFjZSBcImF0IGluZGV4IDBcIiB3aXRoIGEgY2xlYXJlciBtZXNzYWdlIGZvciBzaW5nbGUgZmlsdGVyIHZhbGlkYXRpb25cbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UucmVwbGFjZSgnIGF0IGluZGV4IDAnLCAnJyk7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoZXJyb3IubmFtZSBhcyBMaXRlcmFsU3RyaW5nLCBtZXNzYWdlLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgYSBzaW5nbGUgcmVnZXggZmlsdGVyIGFuZCBhcHBsaWVzIGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSByZWdleCBmaWx0ZXIgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlU2luZ2xlUmVnZXhGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLlJlZ2V4RmlsdGVyKTogdm9pZCB7XG4gICAgLy8gVXNlIHRoZSBleGlzdGluZyB2YWxpZGF0aW9uIGxvZ2ljIGJ1dCBjYXRjaCBhbmQgcmUtdGhyb3cgd2l0aCBhIGNsZWFyZXIgZXJyb3IgbWVzc2FnZVxuICAgIHRyeSB7XG4gICAgICB0aGlzLnZhbGlkYXRlUmVnZXhGaWx0ZXJzKFtmaWx0ZXJdKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgVmFsaWRhdGlvbkVycm9yKSB7XG4gICAgICAgIC8vIFJlcGxhY2UgXCJhdCBpbmRleCAwXCIgd2l0aCBhIGNsZWFyZXIgbWVzc2FnZSBmb3Igc2luZ2xlIGZpbHRlciB2YWxpZGF0aW9uXG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlLnJlcGxhY2UoJyBhdCBpbmRleCAwJywgJycpO1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGVycm9yLm5hbWUgYXMgTGl0ZXJhbFN0cmluZywgbWVzc2FnZSwgdGhpcyk7XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGEgc2luZ2xlIGRlbmllZCB0b3BpYyBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIGZpbHRlciBUaGUgZGVuaWVkIHRvcGljIHRvIHZhbGlkYXRlLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVNpbmdsZURlbmllZFRvcGljKGZpbHRlcjogZmlsdGVycy5Ub3BpYyk6IHZvaWQge1xuICAgIC8vIFVzZSB0aGUgZXhpc3RpbmcgdmFsaWRhdGlvbiBsb2dpYyBidXQgY2F0Y2ggYW5kIHJlLXRocm93IHdpdGggYSBjbGVhcmVyIGVycm9yIG1lc3NhZ2VcbiAgICB0cnkge1xuICAgICAgdGhpcy52YWxpZGF0ZURlbmllZFRvcGljcyhbZmlsdGVyXSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIFZhbGlkYXRpb25FcnJvcikge1xuICAgICAgICAvLyBSZXBsYWNlIFwiYXQgaW5kZXggMFwiIHdpdGggYSBjbGVhcmVyIG1lc3NhZ2UgZm9yIHNpbmdsZSBmaWx0ZXIgdmFsaWRhdGlvblxuICAgICAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IubWVzc2FnZS5yZXBsYWNlKCcgYXQgaW5kZXggMCcsICcnKTtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihlcnJvci5uYW1lIGFzIExpdGVyYWxTdHJpbmcsIG1lc3NhZ2UsIHRoaXMpO1xuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBhIHNpbmdsZSBjb250ZXh0dWFsIGdyb3VuZGluZyBmaWx0ZXIgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIGNvbnRleHR1YWwgZ3JvdW5kaW5nIGZpbHRlciB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVTaW5nbGVDb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyKGZpbHRlcjogZmlsdGVycy5Db250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyKTogdm9pZCB7XG4gICAgLy8gVXNlIHRoZSBleGlzdGluZyB2YWxpZGF0aW9uIGxvZ2ljIGJ1dCBjYXRjaCBhbmQgcmUtdGhyb3cgd2l0aCBhIGNsZWFyZXIgZXJyb3IgbWVzc2FnZVxuICAgIHRyeSB7XG4gICAgICB0aGlzLnZhbGlkYXRlQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMoW2ZpbHRlcl0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBWYWxpZGF0aW9uRXJyb3IpIHtcbiAgICAgICAgLy8gUmVwbGFjZSBcImF0IGluZGV4IDBcIiB3aXRoIGEgY2xlYXJlciBtZXNzYWdlIGZvciBzaW5nbGUgZmlsdGVyIHZhbGlkYXRpb25cbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UucmVwbGFjZSgnIGF0IGluZGV4IDAnLCAnJyk7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoZXJyb3IubmFtZSBhcyBMaXRlcmFsU3RyaW5nLCBtZXNzYWdlLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgYSBzaW5nbGUgd29yZCBmaWx0ZXIgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIHdvcmQgZmlsdGVyIHRvIHZhbGlkYXRlLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVNpbmdsZVdvcmRGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLldvcmRGaWx0ZXIpOiB2b2lkIHtcbiAgICAvLyBVc2UgdGhlIGV4aXN0aW5nIHZhbGlkYXRpb24gbG9naWMgYnV0IGNhdGNoIGFuZCByZS10aHJvdyB3aXRoIGEgY2xlYXJlciBlcnJvciBtZXNzYWdlXG4gICAgdHJ5IHtcbiAgICAgIHRoaXMudmFsaWRhdGVXb3JkRmlsdGVycyhbZmlsdGVyXSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIFZhbGlkYXRpb25FcnJvcikge1xuICAgICAgICAvLyBSZXBsYWNlIFwiYXQgaW5kZXggMFwiIHdpdGggYSBjbGVhcmVyIG1lc3NhZ2UgZm9yIHNpbmdsZSBmaWx0ZXIgdmFsaWRhdGlvblxuICAgICAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IubWVzc2FnZS5yZXBsYWNlKCcgYXQgaW5kZXggMCcsICcnKTtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihlcnJvci5uYW1lIGFzIExpdGVyYWxTdHJpbmcsIG1lc3NhZ2UsIHRoaXMpO1xuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBhIHNpbmdsZSBtYW5hZ2VkIHdvcmQgbGlzdCBmaWx0ZXIgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIG1hbmFnZWQgd29yZCBsaXN0IGZpbHRlciB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVTaW5nbGVNYW5hZ2VkV29yZExpc3RGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLk1hbmFnZWRXb3JkRmlsdGVyKTogdm9pZCB7XG4gICAgLy8gVXNlIHRoZSBleGlzdGluZyB2YWxpZGF0aW9uIGxvZ2ljIGJ1dCBjYXRjaCBhbmQgcmUtdGhyb3cgd2l0aCBhIGNsZWFyZXIgZXJyb3IgbWVzc2FnZVxuICAgIHRyeSB7XG4gICAgICB0aGlzLnZhbGlkYXRlTWFuYWdlZFdvcmRMaXN0RmlsdGVycyhbZmlsdGVyXSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIFZhbGlkYXRpb25FcnJvcikge1xuICAgICAgICAvLyBSZXBsYWNlIFwiYXQgaW5kZXggMFwiIHdpdGggYSBjbGVhcmVyIG1lc3NhZ2UgZm9yIHNpbmdsZSBmaWx0ZXIgdmFsaWRhdGlvblxuICAgICAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IubWVzc2FnZS5yZXBsYWNlKCcgYXQgaW5kZXggMCcsICcnKTtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihlcnJvci5uYW1lIGFzIExpdGVyYWxTdHJpbmcsIG1lc3NhZ2UsIHRoaXMpO1xuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG59XG4iXX0=