"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatMessage = exports.ChatMessageRole = void 0;
exports.createChatPromptVariant = createChatPromptVariant;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const prompt_template_configuration_1 = require("./prompt-template-configuration");
const prompt_variant_1 = require("./prompt-variant");
/**
 * The role of a message in a chat conversation.
 */
var ChatMessageRole;
(function (ChatMessageRole) {
    /**
     * This role represents the human user in the conversation. Inputs from the
     * user guide the conversation and prompt responses from the assistant.
     */
    ChatMessageRole["USER"] = "user";
    /**
     * This is the role of the model itself, responding to user inputs based on
     * the context set by the system.
     */
    ChatMessageRole["ASSISTANT"] = "assistant";
})(ChatMessageRole || (exports.ChatMessageRole = ChatMessageRole = {}));
/**
 * Represents a message in a chat conversation.
 */
class ChatMessage {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ChatMessage", version: "2.245.0-alpha.0" };
    /**
     * Creates a user message.
     *
     * @param text - The text content of the user message
     * @returns A ChatMessage instance representing a user message
     */
    static user(text) {
        return new ChatMessage(ChatMessageRole.USER, text);
    }
    /**
     * Creates an assistant message.
     *
     * @param text - The text content of the assistant message
     * @returns A ChatMessage instance representing an assistant message
     */
    static assistant(text) {
        return new ChatMessage(ChatMessageRole.ASSISTANT, text);
    }
    /**
     * The role of the message sender.
     */
    role;
    /**
     * The text content of the message.
     */
    text;
    constructor(role, text) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ChatMessageRole(role);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, ChatMessage);
            }
            throw error;
        }
        this.role = role;
        this.text = text;
    }
    /**
     * Renders the message as a CloudFormation property.
     * @internal This is an internal core function and should not be called directly.
     */
    _render() {
        return {
            role: this.role,
            content: [
                {
                    text: this.text,
                },
            ],
        };
    }
}
exports.ChatMessage = ChatMessage;
/**
 * Creates a chat template variant. Use this template type when
 * the model supports the Converse API or the Anthropic Claude Messages API.
 * This allows you to include a System prompt and previous User messages
 * and Assistant messages for context.
 *
 * @param props - Properties for the chat prompt variant
 * @returns A PromptVariant configured for chat interactions
 */
function createChatPromptVariant(props) {
    // Validate that messages array is not empty
    if (!props.messages || props.messages.length === 0) {
        throw new errors_1.UnscopedValidationError('MessagesEmpty', 'At least one message must be provided');
    }
    // Validate that the first message is a user message
    if (props.messages[0].role !== ChatMessageRole.USER) {
        throw new errors_1.UnscopedValidationError('FirstMessageNotUser', 'The first message must be a User message');
    }
    // Validate that at least one user message exists
    const hasUserMessage = props.messages.some(message => message.role === ChatMessageRole.USER);
    if (!hasUserMessage) {
        throw new errors_1.UnscopedValidationError('UserMessageRequired', 'At least one User message must be provided');
    }
    // Validate alternating pattern if more than one message
    if (props.messages.length > 1) {
        for (let i = 1; i < props.messages.length; i++) {
            const currentRole = props.messages[i].role;
            const previousRole = props.messages[i - 1].role;
            if (currentRole === previousRole) {
                throw new errors_1.UnscopedValidationError('ConsecutiveRoles', `Messages must alternate between User and Assistant roles. Found consecutive ${currentRole} messages at positions ${i} and ${i + 1}`);
            }
        }
    }
    return {
        name: props.variantName,
        templateType: prompt_variant_1.PromptTemplateType.CHAT,
        modelId: props.model.invokableArn,
        inferenceConfiguration: props.inferenceConfiguration,
        templateConfiguration: prompt_template_configuration_1.PromptTemplateConfiguration.chat({
            inputVariables: props.promptVariables,
            messages: props.messages,
            system: props.system,
            toolConfiguration: props.toolConfiguration,
        }),
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hhdC1wcm9tcHQtdmFyaWFudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNoYXQtcHJvbXB0LXZhcmlhbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBMEhBLDBEQTRDQzs7O0FBcktELHdEQUFzRTtBQUV0RSxtRkFBOEU7QUFFOUUscURBQXNEO0FBb0N0RDs7R0FFRztBQUNILElBQVksZUFZWDtBQVpELFdBQVksZUFBZTtJQUN6Qjs7O09BR0c7SUFDSCxnQ0FBYSxDQUFBO0lBRWI7OztPQUdHO0lBQ0gsMENBQXVCLENBQUE7QUFDekIsQ0FBQyxFQVpXLGVBQWUsK0JBQWYsZUFBZSxRQVkxQjtBQUVEOztHQUVHO0FBQ0gsTUFBYSxXQUFXOztJQUN0Qjs7Ozs7T0FLRztJQUNJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBWTtRQUM3QixPQUFPLElBQUksV0FBVyxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDcEQ7SUFFRDs7Ozs7T0FLRztJQUNJLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBWTtRQUNsQyxPQUFPLElBQUksV0FBVyxDQUFDLGVBQWUsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDekQ7SUFFRDs7T0FFRztJQUNhLElBQUksQ0FBa0I7SUFFdEM7O09BRUc7SUFDYSxJQUFJLENBQVM7SUFFN0IsWUFBWSxJQUFxQixFQUFFLElBQVk7Ozs7OzsrQ0EvQnBDLFdBQVc7Ozs7UUFnQ3BCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0tBQ2xCO0lBRUQ7OztPQUdHO0lBQ0ksT0FBTztRQUNaLE9BQU87WUFDTCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDZixPQUFPLEVBQUU7Z0JBQ1A7b0JBQ0UsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2lCQUNoQjthQUNGO1NBQ0YsQ0FBQztLQUNIOztBQWpESCxrQ0FrREM7QUFFRDs7Ozs7Ozs7R0FRRztBQUNILFNBQWdCLHVCQUF1QixDQUFDLEtBQTZCO0lBQ25FLDRDQUE0QztJQUM1QyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztRQUNuRCxNQUFNLElBQUksZ0NBQXVCLENBQUMsZUFBZSxFQUFFLHVDQUF1QyxDQUFDLENBQUM7SUFDOUYsQ0FBQztJQUVELG9EQUFvRDtJQUNwRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLGVBQWUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNwRCxNQUFNLElBQUksZ0NBQXVCLENBQUMscUJBQXFCLEVBQUUsMENBQTBDLENBQUMsQ0FBQztJQUN2RyxDQUFDO0lBRUQsaURBQWlEO0lBQ2pELE1BQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDN0YsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3BCLE1BQU0sSUFBSSxnQ0FBdUIsQ0FBQyxxQkFBcUIsRUFBRSw0Q0FBNEMsQ0FBQyxDQUFDO0lBQ3pHLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUM5QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUMvQyxNQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMzQyxNQUFNLFlBQVksR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFFaEQsSUFBSSxXQUFXLEtBQUssWUFBWSxFQUFFLENBQUM7Z0JBQ2pDLE1BQU0sSUFBSSxnQ0FBdUIsQ0FDL0Isa0JBQWtCLEVBQ2xCLCtFQUErRSxXQUFXLDBCQUEwQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUNySSxDQUFDO1lBQ0osQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsT0FBTztRQUNMLElBQUksRUFBRSxLQUFLLENBQUMsV0FBVztRQUN2QixZQUFZLEVBQUUsbUNBQWtCLENBQUMsSUFBSTtRQUNyQyxPQUFPLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZO1FBQ2pDLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxzQkFBc0I7UUFDcEQscUJBQXFCLEVBQUUsMkRBQTJCLENBQUMsSUFBSSxDQUFDO1lBQ3RELGNBQWMsRUFBRSxLQUFLLENBQUMsZUFBZTtZQUNyQyxRQUFRLEVBQUUsS0FBSyxDQUFDLFFBQVE7WUFDeEIsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNO1lBQ3BCLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxpQkFBaUI7U0FDM0MsQ0FBQztLQUNILENBQUM7QUFDSixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBDZm5Qcm9tcHQgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgeyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvciB9IGZyb20gJ2F3cy1jZGstbGliL2NvcmUvbGliL2Vycm9ycyc7XG5pbXBvcnQgdHlwZSB7IFByb21wdEluZmVyZW5jZUNvbmZpZ3VyYXRpb24gfSBmcm9tICcuL3Byb21wdC1pbmZlcmVuY2UtY29uZmlndXJhdGlvbic7XG5pbXBvcnQgeyBQcm9tcHRUZW1wbGF0ZUNvbmZpZ3VyYXRpb24gfSBmcm9tICcuL3Byb21wdC10ZW1wbGF0ZS1jb25maWd1cmF0aW9uJztcbmltcG9ydCB0eXBlIHsgQ29tbW9uUHJvbXB0VmFyaWFudFByb3BzLCBJUHJvbXB0VmFyaWFudCB9IGZyb20gJy4vcHJvbXB0LXZhcmlhbnQnO1xuaW1wb3J0IHsgUHJvbXB0VGVtcGxhdGVUeXBlIH0gZnJvbSAnLi9wcm9tcHQtdmFyaWFudCc7XG5pbXBvcnQgdHlwZSB7IFRvb2xDb25maWd1cmF0aW9uIH0gZnJvbSAnLi90b29sLWNob2ljZSc7XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgY3JlYXRpbmcgYSBjaGF0IHByb21wdCB2YXJpYW50LlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENoYXRQcm9tcHRWYXJpYW50UHJvcHMgZXh0ZW5kcyBDb21tb25Qcm9tcHRWYXJpYW50UHJvcHMge1xuICAvKipcbiAgICogVGhlIG1lc3NhZ2VzIGluIHRoZSBjaGF0IHByb21wdC5cbiAgICogTXVzdCBpbmNsdWRlIGF0IGxlYXN0IG9uZSBVc2VyIE1lc3NhZ2UuXG4gICAqIFRoZSBtZXNzYWdlcyBzaG91bGQgYWx0ZXJuYXRlIGJldHdlZW4gVXNlciBhbmQgQXNzaXN0YW50LlxuICAgKi9cbiAgcmVhZG9ubHkgbWVzc2FnZXM6IENoYXRNZXNzYWdlW107XG5cbiAgLyoqXG4gICAqIENvbnRleHQgb3IgaW5zdHJ1Y3Rpb25zIGZvciB0aGUgbW9kZWwgdG8gY29uc2lkZXIgYmVmb3JlIGdlbmVyYXRpbmcgYSByZXNwb25zZS5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyBzeXN0ZW0gbWVzc2FnZSBwcm92aWRlZC5cbiAgICovXG4gIHJlYWRvbmx5IHN5c3RlbT86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIGNvbmZpZ3VyYXRpb24gd2l0aCBhdmFpbGFibGUgdG9vbHMgdG8gdGhlIG1vZGVsIGFuZCBob3cgaXQgbXVzdCB1c2UgdGhlbS5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyB0b29sIGNvbmZpZ3VyYXRpb24gcHJvdmlkZWQuXG4gICAqL1xuICByZWFkb25seSB0b29sQ29uZmlndXJhdGlvbj86IFRvb2xDb25maWd1cmF0aW9uO1xuXG4gIC8qKlxuICAgKiBJbmZlcmVuY2UgY29uZmlndXJhdGlvbiBmb3IgdGhlIENoYXQgUHJvbXB0LlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIE5vIGluZmVyZW5jZSBjb25maWd1cmF0aW9uIHByb3ZpZGVkLlxuICAgKi9cbiAgcmVhZG9ubHkgaW5mZXJlbmNlQ29uZmlndXJhdGlvbj86IFByb21wdEluZmVyZW5jZUNvbmZpZ3VyYXRpb247XG59XG5cbi8qKlxuICogVGhlIHJvbGUgb2YgYSBtZXNzYWdlIGluIGEgY2hhdCBjb252ZXJzYXRpb24uXG4gKi9cbmV4cG9ydCBlbnVtIENoYXRNZXNzYWdlUm9sZSB7XG4gIC8qKlxuICAgKiBUaGlzIHJvbGUgcmVwcmVzZW50cyB0aGUgaHVtYW4gdXNlciBpbiB0aGUgY29udmVyc2F0aW9uLiBJbnB1dHMgZnJvbSB0aGVcbiAgICogdXNlciBndWlkZSB0aGUgY29udmVyc2F0aW9uIGFuZCBwcm9tcHQgcmVzcG9uc2VzIGZyb20gdGhlIGFzc2lzdGFudC5cbiAgICovXG4gIFVTRVIgPSAndXNlcicsXG5cbiAgLyoqXG4gICAqIFRoaXMgaXMgdGhlIHJvbGUgb2YgdGhlIG1vZGVsIGl0c2VsZiwgcmVzcG9uZGluZyB0byB1c2VyIGlucHV0cyBiYXNlZCBvblxuICAgKiB0aGUgY29udGV4dCBzZXQgYnkgdGhlIHN5c3RlbS5cbiAgICovXG4gIEFTU0lTVEFOVCA9ICdhc3Npc3RhbnQnLFxufVxuXG4vKipcbiAqIFJlcHJlc2VudHMgYSBtZXNzYWdlIGluIGEgY2hhdCBjb252ZXJzYXRpb24uXG4gKi9cbmV4cG9ydCBjbGFzcyBDaGF0TWVzc2FnZSB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgdXNlciBtZXNzYWdlLlxuICAgKlxuICAgKiBAcGFyYW0gdGV4dCAtIFRoZSB0ZXh0IGNvbnRlbnQgb2YgdGhlIHVzZXIgbWVzc2FnZVxuICAgKiBAcmV0dXJucyBBIENoYXRNZXNzYWdlIGluc3RhbmNlIHJlcHJlc2VudGluZyBhIHVzZXIgbWVzc2FnZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyB1c2VyKHRleHQ6IHN0cmluZyk6IENoYXRNZXNzYWdlIHtcbiAgICByZXR1cm4gbmV3IENoYXRNZXNzYWdlKENoYXRNZXNzYWdlUm9sZS5VU0VSLCB0ZXh0KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGFuIGFzc2lzdGFudCBtZXNzYWdlLlxuICAgKlxuICAgKiBAcGFyYW0gdGV4dCAtIFRoZSB0ZXh0IGNvbnRlbnQgb2YgdGhlIGFzc2lzdGFudCBtZXNzYWdlXG4gICAqIEByZXR1cm5zIEEgQ2hhdE1lc3NhZ2UgaW5zdGFuY2UgcmVwcmVzZW50aW5nIGFuIGFzc2lzdGFudCBtZXNzYWdlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGFzc2lzdGFudCh0ZXh0OiBzdHJpbmcpOiBDaGF0TWVzc2FnZSB7XG4gICAgcmV0dXJuIG5ldyBDaGF0TWVzc2FnZShDaGF0TWVzc2FnZVJvbGUuQVNTSVNUQU5ULCB0ZXh0KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgcm9sZSBvZiB0aGUgbWVzc2FnZSBzZW5kZXIuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgcm9sZTogQ2hhdE1lc3NhZ2VSb2xlO1xuXG4gIC8qKlxuICAgKiBUaGUgdGV4dCBjb250ZW50IG9mIHRoZSBtZXNzYWdlLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHRleHQ6IHN0cmluZztcblxuICBjb25zdHJ1Y3Rvcihyb2xlOiBDaGF0TWVzc2FnZVJvbGUsIHRleHQ6IHN0cmluZykge1xuICAgIHRoaXMucm9sZSA9IHJvbGU7XG4gICAgdGhpcy50ZXh0ID0gdGV4dDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSBtZXNzYWdlIGFzIGEgQ2xvdWRGb3JtYXRpb24gcHJvcGVydHkuXG4gICAqIEBpbnRlcm5hbCBUaGlzIGlzIGFuIGludGVybmFsIGNvcmUgZnVuY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2FsbGVkIGRpcmVjdGx5LlxuICAgKi9cbiAgcHVibGljIF9yZW5kZXIoKTogQ2ZuUHJvbXB0Lk1lc3NhZ2VQcm9wZXJ0eSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHJvbGU6IHRoaXMucm9sZSxcbiAgICAgIGNvbnRlbnQ6IFtcbiAgICAgICAge1xuICAgICAgICAgIHRleHQ6IHRoaXMudGV4dCxcbiAgICAgICAgfSxcbiAgICAgIF0sXG4gICAgfTtcbiAgfVxufVxuXG4vKipcbiAqIENyZWF0ZXMgYSBjaGF0IHRlbXBsYXRlIHZhcmlhbnQuIFVzZSB0aGlzIHRlbXBsYXRlIHR5cGUgd2hlblxuICogdGhlIG1vZGVsIHN1cHBvcnRzIHRoZSBDb252ZXJzZSBBUEkgb3IgdGhlIEFudGhyb3BpYyBDbGF1ZGUgTWVzc2FnZXMgQVBJLlxuICogVGhpcyBhbGxvd3MgeW91IHRvIGluY2x1ZGUgYSBTeXN0ZW0gcHJvbXB0IGFuZCBwcmV2aW91cyBVc2VyIG1lc3NhZ2VzXG4gKiBhbmQgQXNzaXN0YW50IG1lc3NhZ2VzIGZvciBjb250ZXh0LlxuICpcbiAqIEBwYXJhbSBwcm9wcyAtIFByb3BlcnRpZXMgZm9yIHRoZSBjaGF0IHByb21wdCB2YXJpYW50XG4gKiBAcmV0dXJucyBBIFByb21wdFZhcmlhbnQgY29uZmlndXJlZCBmb3IgY2hhdCBpbnRlcmFjdGlvbnNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUNoYXRQcm9tcHRWYXJpYW50KHByb3BzOiBDaGF0UHJvbXB0VmFyaWFudFByb3BzKTogSVByb21wdFZhcmlhbnQge1xuICAvLyBWYWxpZGF0ZSB0aGF0IG1lc3NhZ2VzIGFycmF5IGlzIG5vdCBlbXB0eVxuICBpZiAoIXByb3BzLm1lc3NhZ2VzIHx8IHByb3BzLm1lc3NhZ2VzLmxlbmd0aCA9PT0gMCkge1xuICAgIHRocm93IG5ldyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvcignTWVzc2FnZXNFbXB0eScsICdBdCBsZWFzdCBvbmUgbWVzc2FnZSBtdXN0IGJlIHByb3ZpZGVkJyk7XG4gIH1cblxuICAvLyBWYWxpZGF0ZSB0aGF0IHRoZSBmaXJzdCBtZXNzYWdlIGlzIGEgdXNlciBtZXNzYWdlXG4gIGlmIChwcm9wcy5tZXNzYWdlc1swXS5yb2xlICE9PSBDaGF0TWVzc2FnZVJvbGUuVVNFUikge1xuICAgIHRocm93IG5ldyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvcignRmlyc3RNZXNzYWdlTm90VXNlcicsICdUaGUgZmlyc3QgbWVzc2FnZSBtdXN0IGJlIGEgVXNlciBtZXNzYWdlJyk7XG4gIH1cblxuICAvLyBWYWxpZGF0ZSB0aGF0IGF0IGxlYXN0IG9uZSB1c2VyIG1lc3NhZ2UgZXhpc3RzXG4gIGNvbnN0IGhhc1VzZXJNZXNzYWdlID0gcHJvcHMubWVzc2FnZXMuc29tZShtZXNzYWdlID0+IG1lc3NhZ2Uucm9sZSA9PT0gQ2hhdE1lc3NhZ2VSb2xlLlVTRVIpO1xuICBpZiAoIWhhc1VzZXJNZXNzYWdlKSB7XG4gICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKCdVc2VyTWVzc2FnZVJlcXVpcmVkJywgJ0F0IGxlYXN0IG9uZSBVc2VyIG1lc3NhZ2UgbXVzdCBiZSBwcm92aWRlZCcpO1xuICB9XG5cbiAgLy8gVmFsaWRhdGUgYWx0ZXJuYXRpbmcgcGF0dGVybiBpZiBtb3JlIHRoYW4gb25lIG1lc3NhZ2VcbiAgaWYgKHByb3BzLm1lc3NhZ2VzLmxlbmd0aCA+IDEpIHtcbiAgICBmb3IgKGxldCBpID0gMTsgaSA8IHByb3BzLm1lc3NhZ2VzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBjdXJyZW50Um9sZSA9IHByb3BzLm1lc3NhZ2VzW2ldLnJvbGU7XG4gICAgICBjb25zdCBwcmV2aW91c1JvbGUgPSBwcm9wcy5tZXNzYWdlc1tpIC0gMV0ucm9sZTtcblxuICAgICAgaWYgKGN1cnJlbnRSb2xlID09PSBwcmV2aW91c1JvbGUpIHtcbiAgICAgICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKFxuICAgICAgICAgICdDb25zZWN1dGl2ZVJvbGVzJyxcbiAgICAgICAgICBgTWVzc2FnZXMgbXVzdCBhbHRlcm5hdGUgYmV0d2VlbiBVc2VyIGFuZCBBc3Npc3RhbnQgcm9sZXMuIEZvdW5kIGNvbnNlY3V0aXZlICR7Y3VycmVudFJvbGV9IG1lc3NhZ2VzIGF0IHBvc2l0aW9ucyAke2l9IGFuZCAke2kgKyAxfWAsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBuYW1lOiBwcm9wcy52YXJpYW50TmFtZSxcbiAgICB0ZW1wbGF0ZVR5cGU6IFByb21wdFRlbXBsYXRlVHlwZS5DSEFULFxuICAgIG1vZGVsSWQ6IHByb3BzLm1vZGVsLmludm9rYWJsZUFybixcbiAgICBpbmZlcmVuY2VDb25maWd1cmF0aW9uOiBwcm9wcy5pbmZlcmVuY2VDb25maWd1cmF0aW9uLFxuICAgIHRlbXBsYXRlQ29uZmlndXJhdGlvbjogUHJvbXB0VGVtcGxhdGVDb25maWd1cmF0aW9uLmNoYXQoe1xuICAgICAgaW5wdXRWYXJpYWJsZXM6IHByb3BzLnByb21wdFZhcmlhYmxlcyxcbiAgICAgIG1lc3NhZ2VzOiBwcm9wcy5tZXNzYWdlcyxcbiAgICAgIHN5c3RlbTogcHJvcHMuc3lzdGVtLFxuICAgICAgdG9vbENvbmZpZ3VyYXRpb246IHByb3BzLnRvb2xDb25maWd1cmF0aW9uLFxuICAgIH0pLFxuICB9O1xufVxuIl19