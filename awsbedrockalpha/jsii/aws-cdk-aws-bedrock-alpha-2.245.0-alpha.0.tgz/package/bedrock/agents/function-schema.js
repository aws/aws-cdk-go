"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FunctionSchema = exports.Function = exports.FunctionParameter = exports.RequireConfirmation = exports.ParameterType = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const errors_1 = require("aws-cdk-lib/core/lib/errors");
const schema_base_1 = require("./schema-base");
const validation = require("./validation-helpers");
/**
 * Enum for parameter types in function schemas
 */
var ParameterType;
(function (ParameterType) {
    /**
     * String parameter type
     */
    ParameterType["STRING"] = "string";
    /**
     * Number parameter type
     */
    ParameterType["NUMBER"] = "number";
    /**
     * Integer parameter type
     */
    ParameterType["INTEGER"] = "integer";
    /**
     * Boolean parameter type
     */
    ParameterType["BOOLEAN"] = "boolean";
    /**
     * Array parameter type
     */
    ParameterType["ARRAY"] = "array";
    /**
     * Object parameter type
     */
    ParameterType["OBJECT"] = "object";
})(ParameterType || (exports.ParameterType = ParameterType = {}));
/**
 * Enum for require confirmation state in function schemas
 */
var RequireConfirmation;
(function (RequireConfirmation) {
    /**
     * Confirmation is enabled
     */
    RequireConfirmation["ENABLED"] = "ENABLED";
    /**
     * Confirmation is disabled
     */
    RequireConfirmation["DISABLED"] = "DISABLED";
})(RequireConfirmation || (exports.RequireConfirmation = RequireConfirmation = {}));
/**
 * Represents a function parameter in a function schema
 */
class FunctionParameter {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.FunctionParameter", version: "2.245.0-alpha.0" };
    /**
     * The type of the parameter
     */
    type;
    /**
     * Whether the parameter is required
     */
    required;
    /**
     * Description of the parameter
     * @default undefined no description will be present
     */
    description;
    constructor(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_FunctionParameterProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, FunctionParameter);
            }
            throw error;
        }
        // Validate description if provided
        if (props.description) {
            const descErrors = validation.validateStringFieldLength({
                fieldName: 'parameter description',
                value: props.description,
                minLength: 1,
                maxLength: 500,
            });
            if (descErrors.length > 0) {
                throw new errors_1.UnscopedValidationError('InvalidParameterDescription', descErrors.join('\n'));
            }
        }
        this.type = props.type;
        this.required = props.required ?? true;
        this.description = props.description;
    }
    /**
     * Render the parameter as a CloudFormation property
     * @internal
     */
    _render() {
        return {
            type: this.type,
            required: this.required,
            description: this.description,
        };
    }
}
exports.FunctionParameter = FunctionParameter;
/**
 * Represents a function in a function schema
 */
class Function {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.Function", version: "2.245.0-alpha.0" };
    /**
     * The name of the function
     */
    name;
    /**
     * Description of the function
     */
    description;
    /**
     * Parameters for the function
     */
    parameters;
    /**
     * Whether to require confirmation before executing the function
     */
    requireConfirmation;
    constructor(props) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_FunctionProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, Function);
            }
            throw error;
        }
        // Validate function name
        const nameErrors = validation.validateStringFieldLength({
            fieldName: 'function name',
            value: props.name,
            minLength: 1,
            maxLength: 100,
        });
        if (nameErrors.length > 0) {
            throw new errors_1.UnscopedValidationError('InvalidFunctionName', nameErrors.join('\n'));
        }
        // Validate function description
        const descErrors = validation.validateStringFieldLength({
            fieldName: 'function description',
            value: props.description,
            minLength: 1,
            maxLength: 500,
        });
        if (descErrors.length > 0) {
            throw new errors_1.UnscopedValidationError('InvalidFunctionDescription', descErrors.join('\n'));
        }
        this.name = props.name;
        this.description = props.description;
        // Convert parameters object to a record of FunctionParameter instances
        this.parameters = {};
        if (props.parameters) {
            Object.entries(props.parameters).forEach(([name, paramProps]) => {
                // Validate parameter name
                const paramNameErrors = validation.validateStringFieldLength({
                    fieldName: 'parameter name',
                    value: name,
                    minLength: 1,
                    maxLength: 100,
                });
                if (paramNameErrors.length > 0) {
                    throw new errors_1.UnscopedValidationError('InvalidParameterName', paramNameErrors.join('\n'));
                }
                this.parameters[name] = new FunctionParameter(paramProps);
            });
        }
        this.requireConfirmation = props.requireConfirmation ?? RequireConfirmation.DISABLED;
    }
    /**
     * Render the function as a CloudFormation property
     * @internal
     */
    _render() {
        const parametersObj = {};
        Object.entries(this.parameters).forEach(([name, param]) => {
            parametersObj[name] = param._render();
        });
        return {
            name: this.name,
            description: this.description,
            parameters: parametersObj,
            requireConfirmation: this.requireConfirmation,
        };
    }
}
exports.Function = Function;
/**
 * Represents a function schema for a Bedrock Agent Action Group
 */
class FunctionSchema extends schema_base_1.ActionGroupSchema {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.FunctionSchema", version: "2.245.0-alpha.0" };
    /**
     * The functions defined in the schema
     */
    functions;
    constructor(props) {
        super();
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_FunctionSchemaProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, FunctionSchema);
            }
            throw error;
        }
        if (!props.functions || props.functions.length === 0) {
            throw new errors_1.UnscopedValidationError('EmptyFunctionSchema', 'At least one function must be defined in the function schema');
        }
        this.functions = props.functions.map(f => new Function(f));
    }
    /**
     * Render the function schema as a CloudFormation property
     * @internal
     */
    _render() {
        return {
            functions: this.functions.map(f => f._render()),
        };
    }
}
exports.FunctionSchema = FunctionSchema;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnVuY3Rpb24tc2NoZW1hLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZnVuY3Rpb24tc2NoZW1hLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQ0Esd0RBQXNFO0FBQ3RFLCtDQUFrRDtBQUNsRCxtREFBbUQ7QUFFbkQ7O0dBRUc7QUFDSCxJQUFZLGFBOEJYO0FBOUJELFdBQVksYUFBYTtJQUN2Qjs7T0FFRztJQUNILGtDQUFpQixDQUFBO0lBRWpCOztPQUVHO0lBQ0gsa0NBQWlCLENBQUE7SUFFakI7O09BRUc7SUFDSCxvQ0FBbUIsQ0FBQTtJQUVuQjs7T0FFRztJQUNILG9DQUFtQixDQUFBO0lBRW5COztPQUVHO0lBQ0gsZ0NBQWUsQ0FBQTtJQUVmOztPQUVHO0lBQ0gsa0NBQWlCLENBQUE7QUFDbkIsQ0FBQyxFQTlCVyxhQUFhLDZCQUFiLGFBQWEsUUE4QnhCO0FBRUQ7O0dBRUc7QUFDSCxJQUFZLG1CQVVYO0FBVkQsV0FBWSxtQkFBbUI7SUFDN0I7O09BRUc7SUFDSCwwQ0FBbUIsQ0FBQTtJQUVuQjs7T0FFRztJQUNILDRDQUFxQixDQUFBO0FBQ3ZCLENBQUMsRUFWVyxtQkFBbUIsbUNBQW5CLG1CQUFtQixRQVU5QjtBQTZERDs7R0FFRztBQUNILE1BQWEsaUJBQWlCOztJQUM1Qjs7T0FFRztJQUNhLElBQUksQ0FBZ0I7SUFFcEM7O09BRUc7SUFDYSxRQUFRLENBQVU7SUFFbEM7OztPQUdHO0lBQ2EsV0FBVyxDQUFVO0lBRXJDLFlBQVksS0FBNkI7Ozs7OzsrQ0FqQjlCLGlCQUFpQjs7OztRQWtCMUIsbUNBQW1DO1FBQ25DLElBQUksS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3RCLE1BQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyx5QkFBeUIsQ0FBQztnQkFDdEQsU0FBUyxFQUFFLHVCQUF1QjtnQkFDbEMsS0FBSyxFQUFFLEtBQUssQ0FBQyxXQUFXO2dCQUN4QixTQUFTLEVBQUUsQ0FBQztnQkFDWixTQUFTLEVBQUUsR0FBRzthQUNmLENBQUMsQ0FBQztZQUVILElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDMUIsTUFBTSxJQUFJLGdDQUF1QixDQUFDLDZCQUE2QixFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUMxRixDQUFDO1FBQ0gsQ0FBQztRQUVELElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQztRQUN2QixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDO1FBQ3ZDLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQztLQUN0QztJQUVEOzs7T0FHRztJQUNJLE9BQU87UUFDWixPQUFPO1lBQ0wsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO1lBQ2YsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO1lBQ3ZCLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVztTQUM5QixDQUFDO0tBQ0g7O0FBL0NILDhDQWdEQztBQUVEOztHQUVHO0FBQ0gsTUFBYSxRQUFROztJQUNuQjs7T0FFRztJQUNhLElBQUksQ0FBUztJQUU3Qjs7T0FFRztJQUNhLFdBQVcsQ0FBUztJQUVwQzs7T0FFRztJQUNhLFVBQVUsQ0FBb0M7SUFFOUQ7O09BRUc7SUFDYSxtQkFBbUIsQ0FBc0I7SUFFekQsWUFBWSxLQUFvQjs7Ozs7OytDQXJCckIsUUFBUTs7OztRQXNCakIseUJBQXlCO1FBQ3pCLE1BQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyx5QkFBeUIsQ0FBQztZQUN0RCxTQUFTLEVBQUUsZUFBZTtZQUMxQixLQUFLLEVBQUUsS0FBSyxDQUFDLElBQUk7WUFDakIsU0FBUyxFQUFFLENBQUM7WUFDWixTQUFTLEVBQUUsR0FBRztTQUNmLENBQUMsQ0FBQztRQUVILElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUMxQixNQUFNLElBQUksZ0NBQXVCLENBQUMscUJBQXFCLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ2xGLENBQUM7UUFFRCxnQ0FBZ0M7UUFDaEMsTUFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLHlCQUF5QixDQUFDO1lBQ3RELFNBQVMsRUFBRSxzQkFBc0I7WUFDakMsS0FBSyxFQUFFLEtBQUssQ0FBQyxXQUFXO1lBQ3hCLFNBQVMsRUFBRSxDQUFDO1lBQ1osU0FBUyxFQUFFLEdBQUc7U0FDZixDQUFDLENBQUM7UUFFSCxJQUFJLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDMUIsTUFBTSxJQUFJLGdDQUF1QixDQUFDLDRCQUE0QixFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUN6RixDQUFDO1FBRUQsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQztRQUVyQyx1RUFBdUU7UUFDdkUsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7UUFDckIsSUFBSSxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDckIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLEVBQUUsRUFBRTtnQkFDOUQsMEJBQTBCO2dCQUMxQixNQUFNLGVBQWUsR0FBRyxVQUFVLENBQUMseUJBQXlCLENBQUM7b0JBQzNELFNBQVMsRUFBRSxnQkFBZ0I7b0JBQzNCLEtBQUssRUFBRSxJQUFJO29CQUNYLFNBQVMsRUFBRSxDQUFDO29CQUNaLFNBQVMsRUFBRSxHQUFHO2lCQUNmLENBQUMsQ0FBQztnQkFFSCxJQUFJLGVBQWUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQy9CLE1BQU0sSUFBSSxnQ0FBdUIsQ0FBQyxzQkFBc0IsRUFBRSxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ3hGLENBQUM7Z0JBRUQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzVELENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVELElBQUksQ0FBQyxtQkFBbUIsR0FBRyxLQUFLLENBQUMsbUJBQW1CLElBQUksbUJBQW1CLENBQUMsUUFBUSxDQUFDO0tBQ3RGO0lBRUQ7OztPQUdHO0lBQ0ksT0FBTztRQUNaLE1BQU0sYUFBYSxHQUF3QixFQUFFLENBQUM7UUFFOUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRTtZQUN4RCxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ3hDLENBQUMsQ0FBQyxDQUFDO1FBQ0gsT0FBTztZQUNMLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtZQUNmLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVztZQUM3QixVQUFVLEVBQUUsYUFBYTtZQUN6QixtQkFBbUIsRUFBRSxJQUFJLENBQUMsbUJBQW1CO1NBQzlDLENBQUM7S0FDSDs7QUF4RkgsNEJBeUZDO0FBRUQ7O0dBRUc7QUFDSCxNQUFhLGNBQWUsU0FBUSwrQkFBaUI7O0lBQ25EOztPQUVHO0lBQ2EsU0FBUyxDQUFhO0lBRXRDLFlBQVksS0FBMEI7UUFDcEMsS0FBSyxFQUFFLENBQUM7Ozs7OzsrQ0FQQyxjQUFjOzs7O1FBU3ZCLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3JELE1BQU0sSUFBSSxnQ0FBdUIsQ0FBQyxxQkFBcUIsRUFBRSw4REFBOEQsQ0FBQyxDQUFDO1FBQzNILENBQUM7UUFFRCxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUM1RDtJQUVEOzs7T0FHRztJQUNJLE9BQU87UUFDWixPQUFPO1lBQ0wsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQ2hELENBQUM7S0FDSDs7QUF4Qkgsd0NBeUJDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBDZm5BZ2VudCB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1iZWRyb2NrJztcbmltcG9ydCB7IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvZXJyb3JzJztcbmltcG9ydCB7IEFjdGlvbkdyb3VwU2NoZW1hIH0gZnJvbSAnLi9zY2hlbWEtYmFzZSc7XG5pbXBvcnQgKiBhcyB2YWxpZGF0aW9uIGZyb20gJy4vdmFsaWRhdGlvbi1oZWxwZXJzJztcblxuLyoqXG4gKiBFbnVtIGZvciBwYXJhbWV0ZXIgdHlwZXMgaW4gZnVuY3Rpb24gc2NoZW1hc1xuICovXG5leHBvcnQgZW51bSBQYXJhbWV0ZXJUeXBlIHtcbiAgLyoqXG4gICAqIFN0cmluZyBwYXJhbWV0ZXIgdHlwZVxuICAgKi9cbiAgU1RSSU5HID0gJ3N0cmluZycsXG5cbiAgLyoqXG4gICAqIE51bWJlciBwYXJhbWV0ZXIgdHlwZVxuICAgKi9cbiAgTlVNQkVSID0gJ251bWJlcicsXG5cbiAgLyoqXG4gICAqIEludGVnZXIgcGFyYW1ldGVyIHR5cGVcbiAgICovXG4gIElOVEVHRVIgPSAnaW50ZWdlcicsXG5cbiAgLyoqXG4gICAqIEJvb2xlYW4gcGFyYW1ldGVyIHR5cGVcbiAgICovXG4gIEJPT0xFQU4gPSAnYm9vbGVhbicsXG5cbiAgLyoqXG4gICAqIEFycmF5IHBhcmFtZXRlciB0eXBlXG4gICAqL1xuICBBUlJBWSA9ICdhcnJheScsXG5cbiAgLyoqXG4gICAqIE9iamVjdCBwYXJhbWV0ZXIgdHlwZVxuICAgKi9cbiAgT0JKRUNUID0gJ29iamVjdCcsXG59XG5cbi8qKlxuICogRW51bSBmb3IgcmVxdWlyZSBjb25maXJtYXRpb24gc3RhdGUgaW4gZnVuY3Rpb24gc2NoZW1hc1xuICovXG5leHBvcnQgZW51bSBSZXF1aXJlQ29uZmlybWF0aW9uIHtcbiAgLyoqXG4gICAqIENvbmZpcm1hdGlvbiBpcyBlbmFibGVkXG4gICAqL1xuICBFTkFCTEVEID0gJ0VOQUJMRUQnLFxuXG4gIC8qKlxuICAgKiBDb25maXJtYXRpb24gaXMgZGlzYWJsZWRcbiAgICovXG4gIERJU0FCTEVEID0gJ0RJU0FCTEVEJyxcbn1cblxuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBhIGZ1bmN0aW9uIHBhcmFtZXRlclxuICovXG5leHBvcnQgaW50ZXJmYWNlIEZ1bmN0aW9uUGFyYW1ldGVyUHJvcHMge1xuICAvKipcbiAgICogVGhlIHR5cGUgb2YgdGhlIHBhcmFtZXRlclxuICAgKi9cbiAgcmVhZG9ubHkgdHlwZTogUGFyYW1ldGVyVHlwZTtcblxuICAvKipcbiAgICogV2hldGhlciB0aGUgcGFyYW1ldGVyIGlzIHJlcXVpcmVkXG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICovXG4gIHJlYWRvbmx5IHJlcXVpcmVkPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogRGVzY3JpcHRpb24gb2YgdGhlIHBhcmFtZXRlclxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgbm8gZGVzY3JpcHRpb24gd2lsbCBiZSBwcmVzZW50XG4gICAqL1xuICByZWFkb25seSBkZXNjcmlwdGlvbj86IHN0cmluZztcbn1cblxuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBhIGZ1bmN0aW9uIGluIGEgZnVuY3Rpb24gc2NoZW1hXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRnVuY3Rpb25Qcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgZnVuY3Rpb25cbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogRGVzY3JpcHRpb24gb2YgdGhlIGZ1bmN0aW9uXG4gICAqL1xuICByZWFkb25seSBkZXNjcmlwdGlvbjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBQYXJhbWV0ZXJzIGZvciB0aGUgZnVuY3Rpb24gYXMgYSByZWNvcmQgb2YgcGFyYW1ldGVyIG5hbWUgdG8gcGFyYW1ldGVyIHByb3BlcnRpZXNcbiAgICogQGRlZmF1bHQge31cbiAgICovXG4gIHJlYWRvbmx5IHBhcmFtZXRlcnM/OiBSZWNvcmQ8c3RyaW5nLCBGdW5jdGlvblBhcmFtZXRlclByb3BzPjtcblxuICAvKipcbiAgICogV2hldGhlciB0byByZXF1aXJlIGNvbmZpcm1hdGlvbiBiZWZvcmUgZXhlY3V0aW5nIHRoZSBmdW5jdGlvblxuICAgKiBAZGVmYXVsdCBSZXF1aXJlQ29uZmlybWF0aW9uLkRJU0FCTEVEXG4gICAqL1xuICByZWFkb25seSByZXF1aXJlQ29uZmlybWF0aW9uPzogUmVxdWlyZUNvbmZpcm1hdGlvbjtcbn1cblxuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBhIGZ1bmN0aW9uIHNjaGVtYVxuICovXG5leHBvcnQgaW50ZXJmYWNlIEZ1bmN0aW9uU2NoZW1hUHJvcHMge1xuICAvKipcbiAgICogRnVuY3Rpb25zIGRlZmluZWQgaW4gdGhlIHNjaGVtYVxuICAgKi9cbiAgcmVhZG9ubHkgZnVuY3Rpb25zOiBGdW5jdGlvblByb3BzW107XG59XG5cbi8qKlxuICogUmVwcmVzZW50cyBhIGZ1bmN0aW9uIHBhcmFtZXRlciBpbiBhIGZ1bmN0aW9uIHNjaGVtYVxuICovXG5leHBvcnQgY2xhc3MgRnVuY3Rpb25QYXJhbWV0ZXIge1xuICAvKipcbiAgICogVGhlIHR5cGUgb2YgdGhlIHBhcmFtZXRlclxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHR5cGU6IFBhcmFtZXRlclR5cGU7XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIHBhcmFtZXRlciBpcyByZXF1aXJlZFxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHJlcXVpcmVkOiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBEZXNjcmlwdGlvbiBvZiB0aGUgcGFyYW1ldGVyXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCBubyBkZXNjcmlwdGlvbiB3aWxsIGJlIHByZXNlbnRcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBkZXNjcmlwdGlvbj86IHN0cmluZztcblxuICBjb25zdHJ1Y3Rvcihwcm9wczogRnVuY3Rpb25QYXJhbWV0ZXJQcm9wcykge1xuICAgIC8vIFZhbGlkYXRlIGRlc2NyaXB0aW9uIGlmIHByb3ZpZGVkXG4gICAgaWYgKHByb3BzLmRlc2NyaXB0aW9uKSB7XG4gICAgICBjb25zdCBkZXNjRXJyb3JzID0gdmFsaWRhdGlvbi52YWxpZGF0ZVN0cmluZ0ZpZWxkTGVuZ3RoKHtcbiAgICAgICAgZmllbGROYW1lOiAncGFyYW1ldGVyIGRlc2NyaXB0aW9uJyxcbiAgICAgICAgdmFsdWU6IHByb3BzLmRlc2NyaXB0aW9uLFxuICAgICAgICBtaW5MZW5ndGg6IDEsXG4gICAgICAgIG1heExlbmd0aDogNTAwLFxuICAgICAgfSk7XG5cbiAgICAgIGlmIChkZXNjRXJyb3JzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IFVuc2NvcGVkVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkUGFyYW1ldGVyRGVzY3JpcHRpb24nLCBkZXNjRXJyb3JzLmpvaW4oJ1xcbicpKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICB0aGlzLnR5cGUgPSBwcm9wcy50eXBlO1xuICAgIHRoaXMucmVxdWlyZWQgPSBwcm9wcy5yZXF1aXJlZCA/PyB0cnVlO1xuICAgIHRoaXMuZGVzY3JpcHRpb24gPSBwcm9wcy5kZXNjcmlwdGlvbjtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXIgdGhlIHBhcmFtZXRlciBhcyBhIENsb3VkRm9ybWF0aW9uIHByb3BlcnR5XG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgcHVibGljIF9yZW5kZXIoKTogYW55IHtcbiAgICByZXR1cm4ge1xuICAgICAgdHlwZTogdGhpcy50eXBlLFxuICAgICAgcmVxdWlyZWQ6IHRoaXMucmVxdWlyZWQsXG4gICAgICBkZXNjcmlwdGlvbjogdGhpcy5kZXNjcmlwdGlvbixcbiAgICB9O1xuICB9XG59XG5cbi8qKlxuICogUmVwcmVzZW50cyBhIGZ1bmN0aW9uIGluIGEgZnVuY3Rpb24gc2NoZW1hXG4gKi9cbmV4cG9ydCBjbGFzcyBGdW5jdGlvbiB7XG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgZnVuY3Rpb25cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIERlc2NyaXB0aW9uIG9mIHRoZSBmdW5jdGlvblxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGRlc2NyaXB0aW9uOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFBhcmFtZXRlcnMgZm9yIHRoZSBmdW5jdGlvblxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHBhcmFtZXRlcnM6IFJlY29yZDxzdHJpbmcsIEZ1bmN0aW9uUGFyYW1ldGVyPjtcblxuICAvKipcbiAgICogV2hldGhlciB0byByZXF1aXJlIGNvbmZpcm1hdGlvbiBiZWZvcmUgZXhlY3V0aW5nIHRoZSBmdW5jdGlvblxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHJlcXVpcmVDb25maXJtYXRpb246IFJlcXVpcmVDb25maXJtYXRpb247XG5cbiAgY29uc3RydWN0b3IocHJvcHM6IEZ1bmN0aW9uUHJvcHMpIHtcbiAgICAvLyBWYWxpZGF0ZSBmdW5jdGlvbiBuYW1lXG4gICAgY29uc3QgbmFtZUVycm9ycyA9IHZhbGlkYXRpb24udmFsaWRhdGVTdHJpbmdGaWVsZExlbmd0aCh7XG4gICAgICBmaWVsZE5hbWU6ICdmdW5jdGlvbiBuYW1lJyxcbiAgICAgIHZhbHVlOiBwcm9wcy5uYW1lLFxuICAgICAgbWluTGVuZ3RoOiAxLFxuICAgICAgbWF4TGVuZ3RoOiAxMDAsXG4gICAgfSk7XG5cbiAgICBpZiAobmFtZUVycm9ycy5sZW5ndGggPiAwKSB7XG4gICAgICB0aHJvdyBuZXcgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IoJ0ludmFsaWRGdW5jdGlvbk5hbWUnLCBuYW1lRXJyb3JzLmpvaW4oJ1xcbicpKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBmdW5jdGlvbiBkZXNjcmlwdGlvblxuICAgIGNvbnN0IGRlc2NFcnJvcnMgPSB2YWxpZGF0aW9uLnZhbGlkYXRlU3RyaW5nRmllbGRMZW5ndGgoe1xuICAgICAgZmllbGROYW1lOiAnZnVuY3Rpb24gZGVzY3JpcHRpb24nLFxuICAgICAgdmFsdWU6IHByb3BzLmRlc2NyaXB0aW9uLFxuICAgICAgbWluTGVuZ3RoOiAxLFxuICAgICAgbWF4TGVuZ3RoOiA1MDAsXG4gICAgfSk7XG5cbiAgICBpZiAoZGVzY0Vycm9ycy5sZW5ndGggPiAwKSB7XG4gICAgICB0aHJvdyBuZXcgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IoJ0ludmFsaWRGdW5jdGlvbkRlc2NyaXB0aW9uJywgZGVzY0Vycm9ycy5qb2luKCdcXG4nKSk7XG4gICAgfVxuXG4gICAgdGhpcy5uYW1lID0gcHJvcHMubmFtZTtcbiAgICB0aGlzLmRlc2NyaXB0aW9uID0gcHJvcHMuZGVzY3JpcHRpb247XG5cbiAgICAvLyBDb252ZXJ0IHBhcmFtZXRlcnMgb2JqZWN0IHRvIGEgcmVjb3JkIG9mIEZ1bmN0aW9uUGFyYW1ldGVyIGluc3RhbmNlc1xuICAgIHRoaXMucGFyYW1ldGVycyA9IHt9O1xuICAgIGlmIChwcm9wcy5wYXJhbWV0ZXJzKSB7XG4gICAgICBPYmplY3QuZW50cmllcyhwcm9wcy5wYXJhbWV0ZXJzKS5mb3JFYWNoKChbbmFtZSwgcGFyYW1Qcm9wc10pID0+IHtcbiAgICAgICAgLy8gVmFsaWRhdGUgcGFyYW1ldGVyIG5hbWVcbiAgICAgICAgY29uc3QgcGFyYW1OYW1lRXJyb3JzID0gdmFsaWRhdGlvbi52YWxpZGF0ZVN0cmluZ0ZpZWxkTGVuZ3RoKHtcbiAgICAgICAgICBmaWVsZE5hbWU6ICdwYXJhbWV0ZXIgbmFtZScsXG4gICAgICAgICAgdmFsdWU6IG5hbWUsXG4gICAgICAgICAgbWluTGVuZ3RoOiAxLFxuICAgICAgICAgIG1heExlbmd0aDogMTAwLFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAocGFyYW1OYW1lRXJyb3JzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICB0aHJvdyBuZXcgVW5zY29wZWRWYWxpZGF0aW9uRXJyb3IoJ0ludmFsaWRQYXJhbWV0ZXJOYW1lJywgcGFyYW1OYW1lRXJyb3JzLmpvaW4oJ1xcbicpKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMucGFyYW1ldGVyc1tuYW1lXSA9IG5ldyBGdW5jdGlvblBhcmFtZXRlcihwYXJhbVByb3BzKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHRoaXMucmVxdWlyZUNvbmZpcm1hdGlvbiA9IHByb3BzLnJlcXVpcmVDb25maXJtYXRpb24gPz8gUmVxdWlyZUNvbmZpcm1hdGlvbi5ESVNBQkxFRDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXIgdGhlIGZ1bmN0aW9uIGFzIGEgQ2xvdWRGb3JtYXRpb24gcHJvcGVydHlcbiAgICogQGludGVybmFsXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBhbnkge1xuICAgIGNvbnN0IHBhcmFtZXRlcnNPYmo6IFJlY29yZDxzdHJpbmcsIGFueT4gPSB7fTtcblxuICAgIE9iamVjdC5lbnRyaWVzKHRoaXMucGFyYW1ldGVycykuZm9yRWFjaCgoW25hbWUsIHBhcmFtXSkgPT4ge1xuICAgICAgcGFyYW1ldGVyc09ialtuYW1lXSA9IHBhcmFtLl9yZW5kZXIoKTtcbiAgICB9KTtcbiAgICByZXR1cm4ge1xuICAgICAgbmFtZTogdGhpcy5uYW1lLFxuICAgICAgZGVzY3JpcHRpb246IHRoaXMuZGVzY3JpcHRpb24sXG4gICAgICBwYXJhbWV0ZXJzOiBwYXJhbWV0ZXJzT2JqLFxuICAgICAgcmVxdWlyZUNvbmZpcm1hdGlvbjogdGhpcy5yZXF1aXJlQ29uZmlybWF0aW9uLFxuICAgIH07XG4gIH1cbn1cblxuLyoqXG4gKiBSZXByZXNlbnRzIGEgZnVuY3Rpb24gc2NoZW1hIGZvciBhIEJlZHJvY2sgQWdlbnQgQWN0aW9uIEdyb3VwXG4gKi9cbmV4cG9ydCBjbGFzcyBGdW5jdGlvblNjaGVtYSBleHRlbmRzIEFjdGlvbkdyb3VwU2NoZW1hIHtcbiAgLyoqXG4gICAqIFRoZSBmdW5jdGlvbnMgZGVmaW5lZCBpbiB0aGUgc2NoZW1hXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZnVuY3Rpb25zOiBGdW5jdGlvbltdO1xuXG4gIGNvbnN0cnVjdG9yKHByb3BzOiBGdW5jdGlvblNjaGVtYVByb3BzKSB7XG4gICAgc3VwZXIoKTtcblxuICAgIGlmICghcHJvcHMuZnVuY3Rpb25zIHx8IHByb3BzLmZ1bmN0aW9ucy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IG5ldyBVbnNjb3BlZFZhbGlkYXRpb25FcnJvcignRW1wdHlGdW5jdGlvblNjaGVtYScsICdBdCBsZWFzdCBvbmUgZnVuY3Rpb24gbXVzdCBiZSBkZWZpbmVkIGluIHRoZSBmdW5jdGlvbiBzY2hlbWEnKTtcbiAgICB9XG5cbiAgICB0aGlzLmZ1bmN0aW9ucyA9IHByb3BzLmZ1bmN0aW9ucy5tYXAoZiA9PiBuZXcgRnVuY3Rpb24oZikpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlciB0aGUgZnVuY3Rpb24gc2NoZW1hIGFzIGEgQ2xvdWRGb3JtYXRpb24gcHJvcGVydHlcbiAgICogQGludGVybmFsXG4gICAqL1xuICBwdWJsaWMgX3JlbmRlcigpOiBDZm5BZ2VudC5GdW5jdGlvblNjaGVtYVByb3BlcnR5IHtcbiAgICByZXR1cm4ge1xuICAgICAgZnVuY3Rpb25zOiB0aGlzLmZ1bmN0aW9ucy5tYXAoZiA9PiBmLl9yZW5kZXIoKSksXG4gICAgfTtcbiAgfVxufVxuIl19