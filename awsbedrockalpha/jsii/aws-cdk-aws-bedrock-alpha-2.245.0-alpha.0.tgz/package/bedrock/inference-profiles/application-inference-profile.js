"use strict";
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationInferenceProfile = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const bedrock = require("aws-cdk-lib/aws-bedrock");
const aws_iam_1 = require("aws-cdk-lib/aws-iam");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
const inference_profile_1 = require("./inference-profile");
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create an Application Inference Profile with CDK.
 * These are inference profiles created by users (user defined).
 * This helps to track costs and model usage.
 *
 * Application inference profiles are user-defined profiles that help you track costs and model usage.
 * They can be created for a single region or for multiple regions using a cross-region inference profile.
 *
 * @cloudformationResource AWS::Bedrock::ApplicationInferenceProfile
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/inference-profiles-create.html
 */
let ApplicationInferenceProfile = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = inference_profile_1.InferenceProfileBase;
    let _instanceExtraInitializers = [];
    let _grantInvoke_decorators;
    let _grantProfileUsage_decorators;
    var ApplicationInferenceProfile = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _grantInvoke_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _grantProfileUsage_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            __esDecorate(this, null, _grantInvoke_decorators, { kind: "method", name: "grantInvoke", static: false, private: false, access: { has: obj => "grantInvoke" in obj, get: obj => obj.grantInvoke }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _grantProfileUsage_decorators, { kind: "method", name: "grantProfileUsage", static: false, private: false, access: { has: obj => "grantProfileUsage" in obj, get: obj => obj.grantProfileUsage }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            ApplicationInferenceProfile = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ApplicationInferenceProfile", version: "2.245.0-alpha.0" };
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.ApplicationInferenceProfile';
        /**
         * Import an Application Inference Profile given its attributes.
         * [disable-awslint:no-grants]
         *
         * @param scope - The construct scope
         * @param id - Identifier of the construct
         * @param attrs - Attributes of the existing application inference profile
         * @returns An IInferenceProfile reference to the existing application inference profile
         */
        static fromApplicationInferenceProfileAttributes(scope, id, attrs) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfileAttributes(attrs);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.fromApplicationInferenceProfileAttributes);
                }
                throw error;
            }
            class Import extends inference_profile_1.InferenceProfileBase {
                inferenceProfileArn = attrs.inferenceProfileArn;
                inferenceProfileId = aws_cdk_lib_1.Arn.split(attrs.inferenceProfileArn, aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME)
                    .resourceName;
                type = inference_profile_1.InferenceProfileType.APPLICATION;
                /**
                 * [disable-awslint:no-grants]
                 */
                grantProfileUsage(grantee) {
                    return aws_iam_1.Grant.addToPrincipal({
                        grantee: grantee,
                        actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel'],
                        resourceArns: [this.inferenceProfileArn],
                    });
                }
            }
            return new Import(scope, id);
        }
        /**
         * Import a low-level L1 Cfn Application Inference Profile.
         * [disable-awslint:no-grants]
         *
         * @param cfnApplicationInferenceProfile - The L1 CfnApplicationInferenceProfile to import
         * @returns An IInferenceProfile reference to the imported application inference profile
         */
        static fromCfnApplicationInferenceProfile(cfnApplicationInferenceProfile) {
            // Singleton pattern that will prevent creating 2 or more Inference Profiles from the same L1
            const id = '@FromCfnApplicationInferenceProfile';
            const existing = cfnApplicationInferenceProfile.node.tryFindChild(id);
            if (existing) {
                return existing;
            }
            return new (class extends inference_profile_1.InferenceProfileBase {
                inferenceProfileArn = cfnApplicationInferenceProfile.attrInferenceProfileArn;
                inferenceProfileId = cfnApplicationInferenceProfile.attrInferenceProfileId;
                type = inference_profile_1.InferenceProfileType.APPLICATION;
                /**
                 * [disable-awslint:no-grants]
                 */
                grantProfileUsage(grantee) {
                    return aws_iam_1.Grant.addToPrincipal({
                        grantee: grantee,
                        actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel'],
                        resourceArns: [this.inferenceProfileArn],
                    });
                }
            })(cfnApplicationInferenceProfile, id);
        }
        // ------------------------------------------------------
        // Base attributes
        // ------------------------------------------------------
        /**
         * The name of the application inference profile.
         */
        inferenceProfileName = __runInitializers(this, _instanceExtraInitializers);
        /**
         * The ARN of the application inference profile.
         * @attribute
         */
        inferenceProfileArn;
        /**
         * The unique identifier of the application inference profile.
         * @attribute
         */
        inferenceProfileId;
        /**
         * The underlying model/cross-region model used by the application inference profile.
         */
        inferenceProfileModel;
        /**
         * The status of the application inference profile. ACTIVE means that the inference profile is ready to be used.
         * @attribute
         */
        status;
        /**
         * The type of the inference profile. Always APPLICATION for application inference profiles.
         */
        type;
        /**
         * Time Stamp for Application Inference Profile creation.
         * @attribute
         */
        createdAt;
        /**
         * Time Stamp for Application Inference Profile update.
         * @attribute
         */
        updatedAt;
        /**
         * The ARN used for invoking this inference profile.
         * This equals to the inferenceProfileArn property, useful for implementing IBedrockInvokable interface.
         */
        invokableArn;
        // ------------------------------------------------------
        // Internal Only
        // ------------------------------------------------------
        /**
         * Instance of CfnApplicationInferenceProfile.
         * @internal
         */
        __resource;
        // ------------------------------------------------------
        // CONSTRUCTOR
        // ------------------------------------------------------
        constructor(scope, id, props) {
            super(scope, id);
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfileProps(props);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, ApplicationInferenceProfile);
                }
                throw error;
            }
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            // ------------------------------------------------------
            // Validate props
            // ------------------------------------------------------
            this.validateProps(props);
            // ------------------------------------------------------
            // Set properties
            // ------------------------------------------------------
            this.inferenceProfileModel = props.modelSource;
            this.type = inference_profile_1.InferenceProfileType.APPLICATION;
            // ------------------------------------------------------
            // L1 instantiation
            // ------------------------------------------------------
            this.__resource = new bedrock.CfnApplicationInferenceProfile(this, 'Resource', {
                description: props.description,
                inferenceProfileName: props.applicationInferenceProfileName,
                modelSource: {
                    copyFrom: props.modelSource.invokableArn,
                },
                tags: props.tags ? Object.entries(props.tags).map(([key, value]) => ({ key, value })) : undefined,
            });
            // ------------------------------------------------------
            // Build attributes
            // ------------------------------------------------------
            this.inferenceProfileArn = this.__resource.attrInferenceProfileArn;
            this.inferenceProfileId = this.__resource.attrInferenceProfileId;
            this.inferenceProfileName = this.__resource.inferenceProfileName;
            this.status = this.__resource.attrStatus;
            this.createdAt = this.__resource.attrCreatedAt;
            this.updatedAt = this.__resource.attrUpdatedAt;
            this.invokableArn = this.inferenceProfileArn;
        }
        // ------------------------------------------------------
        // METHODS
        // ------------------------------------------------------
        /**
         * Validates the properties for creating an Application Inference Profile.
         *
         * @param props - The properties to validate
         * @throws ValidationError if any validation fails
         */
        validateProps(props) {
            // Validate applicationInferenceProfileName is provided and not empty
            if (!props.applicationInferenceProfileName || props.applicationInferenceProfileName.trim() === '') {
                throw new aws_cdk_lib_1.ValidationError('ProfileNameRequired', 'applicationInferenceProfileName is required and cannot be empty', this);
            }
            // Validate applicationInferenceProfileName length
            if (props.applicationInferenceProfileName.length > 64) {
                throw new aws_cdk_lib_1.ValidationError('ProfileNameTooLong', 'applicationInferenceProfileName cannot exceed 64 characters', this);
            }
            // Validate applicationInferenceProfileName pattern
            const namePattern = /^([0-9a-zA-Z:.][ _-]?)+$/;
            if (!namePattern.test(props.applicationInferenceProfileName)) {
                throw new aws_cdk_lib_1.ValidationError('ProfileNameInvalidPattern', 'applicationInferenceProfileName must match pattern ^([0-9a-zA-Z:.][ _-]?)+$', this);
            }
            // Validate modelSource is provided
            if (!props.modelSource) {
                throw new aws_cdk_lib_1.ValidationError('ModelSourceRequired', 'modelSource is required', this);
            }
            // Validate description length if provided
            if (props.description !== undefined && props.description.length > 200) {
                throw new aws_cdk_lib_1.ValidationError('DescriptionTooLong', 'description cannot exceed 200 characters', this);
            }
            // Validate description pattern if provided
            if (props.description !== undefined && props.description !== '') {
                const descriptionPattern = /^([0-9a-zA-Z:.][ _-]?)+$/;
                if (!descriptionPattern.test(props.description)) {
                    throw new aws_cdk_lib_1.ValidationError('DescriptionInvalidPattern', 'description must match pattern ^([0-9a-zA-Z:.][ _-]?)+$', this);
                }
            }
        }
        /**
         * Gives the appropriate policies to invoke and use the application inference profile.
         * This method ensures the appropriate permissions are given to use either the inference profile
         * or the underlying foundation model/cross-region profile.
         * [disable-awslint:no-grants]
         *
         * @param grantee - The IAM principal to grant permissions to
         * @returns An IAM Grant object representing the granted permissions
         */
        grantInvoke(grantee) {
            // This method ensures the appropriate permissions are given
            // to use either the inference profile or the vanilla foundation model
            this.inferenceProfileModel.grantInvoke(grantee);
            // Plus we add permissions to now invoke the application inference profile itself
            return this.grantProfileUsage(grantee);
        }
        /**
         * Grants appropriate permissions to use the application inference profile (AIP).
         * This method adds the necessary IAM permissions to allow the grantee to:
         * - Get inference profile details (bedrock:GetInferenceProfile)
         * - Invoke the model through the inference profile (bedrock:InvokeModel)
         *
         * Note: This does not grant permissions to use the underlying model/cross-region profile in the AIP.
         * For comprehensive permissions, use grantInvoke() instead.
         * [disable-awslint:no-grants]
         *
         * @param grantee - The IAM principal to grant permissions to
         * @returns An IAM Grant object representing the granted permissions
         */
        grantProfileUsage(grantee) {
            return aws_iam_1.Grant.addToPrincipal({
                grantee: grantee,
                actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel'],
                resourceArns: [this.inferenceProfileArn],
            });
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return ApplicationInferenceProfile = _classThis;
})();
exports.ApplicationInferenceProfile = ApplicationInferenceProfile;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwbGljYXRpb24taW5mZXJlbmNlLXByb2ZpbGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhcHBsaWNhdGlvbi1pbmZlcmVuY2UtcHJvZmlsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSw2Q0FBOEQ7QUFDOUQsbURBQW1EO0FBRW5ELGlEQUE0QztBQUM1Qyw4RUFBOEY7QUFDOUYsMEVBQTBFO0FBRzFFLDJEQUFpRjtBQTRFakY7OytFQUUrRTtBQUMvRTs7Ozs7Ozs7OztHQVVHO0lBRVUsMkJBQTJCOzRCQUR2QyxvQ0FBa0I7Ozs7c0JBQzhCLHdDQUFvQjs7OzsyQ0FBNUIsU0FBUSxXQUFvQjs7Ozt1Q0FtUGxFLElBQUEsa0NBQWMsR0FBRTs2Q0F1QmhCLElBQUEsa0NBQWMsR0FBRTtZQXRCakIsb0xBQU8sV0FBVyw2REFPakI7WUFnQkQsc01BQU8saUJBQWlCLDZEQU12QjtZQWpSSCw2S0FrUkM7Ozs7O1FBalJDLHNDQUFzQztRQUMvQixNQUFNLENBQVUscUJBQXFCLEdBQVcsd0RBQXdELENBQUM7UUFFaEg7Ozs7Ozs7O1dBUUc7UUFDSSxNQUFNLENBQUMseUNBQXlDLENBQ3JELEtBQWdCLEVBQ2hCLEVBQVUsRUFDVixLQUE0Qzs7Ozs7Ozs7OztZQUU1QyxNQUFNLE1BQU8sU0FBUSx3Q0FBb0I7Z0JBQ3ZCLG1CQUFtQixHQUFHLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQztnQkFDaEQsa0JBQWtCLEdBQUcsaUJBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLG1CQUFtQixFQUFFLHVCQUFTLENBQUMsbUJBQW1CLENBQUM7cUJBQ3JHLFlBQWEsQ0FBQztnQkFDRCxJQUFJLEdBQUcsd0NBQW9CLENBQUMsV0FBVyxDQUFDO2dCQUV4RDs7bUJBRUc7Z0JBQ0ksaUJBQWlCLENBQUMsT0FBbUI7b0JBQzFDLE9BQU8sZUFBSyxDQUFDLGNBQWMsQ0FBQzt3QkFDMUIsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLE9BQU8sRUFBRSxDQUFDLDZCQUE2QixFQUFFLHFCQUFxQixDQUFDO3dCQUMvRCxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7cUJBQ3pDLENBQUMsQ0FBQztnQkFDTCxDQUFDO2FBQ0Y7WUFFRCxPQUFPLElBQUksTUFBTSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztTQUM5QjtRQUVEOzs7Ozs7V0FNRztRQUNJLE1BQU0sQ0FBQyxrQ0FBa0MsQ0FDOUMsOEJBQXNFO1lBRXRFLDZGQUE2RjtZQUM3RixNQUFNLEVBQUUsR0FBRyxxQ0FBcUMsQ0FBQztZQUNqRCxNQUFNLFFBQVEsR0FBRyw4QkFBOEIsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3RFLElBQUksUUFBUSxFQUFFLENBQUM7Z0JBQ2IsT0FBTyxRQUF3QyxDQUFDO1lBQ2xELENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxLQUFNLFNBQVEsd0NBQW9CO2dCQUM1QixtQkFBbUIsR0FBRyw4QkFBOEIsQ0FBQyx1QkFBdUIsQ0FBQztnQkFDN0Usa0JBQWtCLEdBQUcsOEJBQThCLENBQUMsc0JBQXNCLENBQUM7Z0JBQzNFLElBQUksR0FBRyx3Q0FBb0IsQ0FBQyxXQUFXLENBQUM7Z0JBRXhEOzttQkFFRztnQkFDSSxpQkFBaUIsQ0FBQyxPQUFtQjtvQkFDMUMsT0FBTyxlQUFLLENBQUMsY0FBYyxDQUFDO3dCQUMxQixPQUFPLEVBQUUsT0FBTzt3QkFDaEIsT0FBTyxFQUFFLENBQUMsNkJBQTZCLEVBQUUscUJBQXFCLENBQUM7d0JBQy9ELFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztxQkFDekMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7YUFDRixDQUFDLENBQUMsOEJBQThCLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDeEM7UUFFRCx5REFBeUQ7UUFDekQsa0JBQWtCO1FBQ2xCLHlEQUF5RDtRQUN6RDs7V0FFRztRQUNhLG9CQUFvQixHQWhGekIsbURBQTJCLENBZ0ZPO1FBRTdDOzs7V0FHRztRQUNhLG1CQUFtQixDQUFTO1FBRTVDOzs7V0FHRztRQUNhLGtCQUFrQixDQUFTO1FBRTNDOztXQUVHO1FBQ2EscUJBQXFCLENBQW9CO1FBRXpEOzs7V0FHRztRQUNhLE1BQU0sQ0FBUztRQUUvQjs7V0FFRztRQUNhLElBQUksQ0FBdUI7UUFFM0M7OztXQUdHO1FBQ2EsU0FBUyxDQUFTO1FBRWxDOzs7V0FHRztRQUNhLFNBQVMsQ0FBUztRQUVsQzs7O1dBR0c7UUFDYSxZQUFZLENBQVM7UUFFckMseURBQXlEO1FBQ3pELGdCQUFnQjtRQUNoQix5REFBeUQ7UUFDekQ7OztXQUdHO1FBQ2MsVUFBVSxDQUF5QztRQUVwRSx5REFBeUQ7UUFDekQsY0FBYztRQUNkLHlEQUF5RDtRQUN6RCxZQUFZLEtBQWdCLEVBQUUsRUFBVSxFQUFFLEtBQXVDO1lBQy9FLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7Ozs7OzttREE3SVIsMkJBQTJCOzs7O1lBOElwQyxtQ0FBbUM7WUFDbkMsSUFBQSx3Q0FBb0IsRUFBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFbEMseURBQXlEO1lBQ3pELGlCQUFpQjtZQUNqQix5REFBeUQ7WUFDekQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUUxQix5REFBeUQ7WUFDekQsaUJBQWlCO1lBQ2pCLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQztZQUMvQyxJQUFJLENBQUMsSUFBSSxHQUFHLHdDQUFvQixDQUFDLFdBQVcsQ0FBQztZQUU3Qyx5REFBeUQ7WUFDekQsbUJBQW1CO1lBQ25CLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksT0FBTyxDQUFDLDhCQUE4QixDQUFDLElBQUksRUFBRSxVQUFVLEVBQUU7Z0JBQzdFLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztnQkFDOUIsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLCtCQUErQjtnQkFDM0QsV0FBVyxFQUFFO29CQUNYLFFBQVEsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLFlBQVk7aUJBQ3pDO2dCQUNELElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7YUFDbEcsQ0FBQyxDQUFDO1lBRUgseURBQXlEO1lBQ3pELG1CQUFtQjtZQUNuQix5REFBeUQ7WUFDekQsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsdUJBQXVCLENBQUM7WUFDbkUsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsc0JBQXNCLENBQUM7WUFDakUsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsb0JBQXFCLENBQUM7WUFDbEUsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQztZQUN6QyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO1lBQy9DLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUM7WUFDL0MsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUM7U0FDOUM7UUFFRCx5REFBeUQ7UUFDekQsVUFBVTtRQUNWLHlEQUF5RDtRQUV6RDs7Ozs7V0FLRztRQUNLLGFBQWEsQ0FBQyxLQUF1QztZQUMzRCxxRUFBcUU7WUFDckUsSUFBSSxDQUFDLEtBQUssQ0FBQywrQkFBK0IsSUFBSSxLQUFLLENBQUMsK0JBQStCLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUM7Z0JBQ2xHLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHFCQUFxQixFQUFFLGlFQUFpRSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzVILENBQUM7WUFFRCxrREFBa0Q7WUFDbEQsSUFBSSxLQUFLLENBQUMsK0JBQStCLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRSxDQUFDO2dCQUN0RCxNQUFNLElBQUksNkJBQWUsQ0FBQyxvQkFBb0IsRUFBRSw2REFBNkQsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN2SCxDQUFDO1lBRUQsbURBQW1EO1lBQ25ELE1BQU0sV0FBVyxHQUFHLDBCQUEwQixDQUFDO1lBQy9DLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxFQUFFLENBQUM7Z0JBQzdELE1BQU0sSUFBSSw2QkFBZSxDQUN2QiwyQkFBMkIsRUFDM0IsNkVBQTZFLEVBQzdFLElBQUksQ0FDTCxDQUFDO1lBQ0osQ0FBQztZQUVELG1DQUFtQztZQUNuQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUN2QixNQUFNLElBQUksNkJBQWUsQ0FBQyxxQkFBcUIsRUFBRSx5QkFBeUIsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNwRixDQUFDO1lBRUQsMENBQTBDO1lBQzFDLElBQUksS0FBSyxDQUFDLFdBQVcsS0FBSyxTQUFTLElBQUksS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7Z0JBQ3RFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLG9CQUFvQixFQUFFLDBDQUEwQyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3BHLENBQUM7WUFFRCwyQ0FBMkM7WUFDM0MsSUFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFBRSxDQUFDO2dCQUNoRSxNQUFNLGtCQUFrQixHQUFHLDBCQUEwQixDQUFDO2dCQUN0RCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDO29CQUNoRCxNQUFNLElBQUksNkJBQWUsQ0FDdkIsMkJBQTJCLEVBQzNCLHlEQUF5RCxFQUN6RCxJQUFJLENBQ0wsQ0FBQztnQkFDSixDQUFDO1lBQ0gsQ0FBQztTQUNGO1FBRUQ7Ozs7Ozs7O1dBUUc7UUFFSSxXQUFXLENBQUMsT0FBbUI7WUFDcEMsNERBQTREO1lBQzVELHNFQUFzRTtZQUN0RSxJQUFJLENBQUMscUJBQXFCLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRWhELGlGQUFpRjtZQUNqRixPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUN4QztRQUVEOzs7Ozs7Ozs7Ozs7V0FZRztRQUVJLGlCQUFpQixDQUFDLE9BQW1CO1lBQzFDLE9BQU8sZUFBSyxDQUFDLGNBQWMsQ0FBQztnQkFDMUIsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLE9BQU8sRUFBRSxDQUFDLDZCQUE2QixFQUFFLHFCQUFxQixDQUFDO2dCQUMvRCxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7YUFDekMsQ0FBQyxDQUFDO1NBQ0o7O1lBalJVLHVEQUEyQjs7Ozs7QUFBM0Isa0VBQTJCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXJuLCBBcm5Gb3JtYXQsIFZhbGlkYXRpb25FcnJvciB9IGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCAqIGFzIGJlZHJvY2sgZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHR5cGUgeyBJR3JhbnRhYmxlIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWlhbSc7XG5pbXBvcnQgeyBHcmFudCB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0IHsgYWRkQ29uc3RydWN0TWV0YWRhdGEsIE1ldGhvZE1ldGFkYXRhIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvbWV0YWRhdGEtcmVzb3VyY2UnO1xuaW1wb3J0IHsgcHJvcGVydHlJbmplY3RhYmxlIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvcHJvcC1pbmplY3RhYmxlJztcbmltcG9ydCB0eXBlIHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5pbXBvcnQgdHlwZSB7IElJbmZlcmVuY2VQcm9maWxlIH0gZnJvbSAnLi9pbmZlcmVuY2UtcHJvZmlsZSc7XG5pbXBvcnQgeyBJbmZlcmVuY2VQcm9maWxlQmFzZSwgSW5mZXJlbmNlUHJvZmlsZVR5cGUgfSBmcm9tICcuL2luZmVyZW5jZS1wcm9maWxlJztcbmltcG9ydCB0eXBlIHsgSUJlZHJvY2tJbnZva2FibGUgfSBmcm9tICcuLi9tb2RlbHMnO1xuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIFBST1BTIEZPUiBORVcgQ09OU1RSVUNUXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNyZWF0aW5nIGFuIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZVByb3BzIHtcbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogVGhpcyBuYW1lIHdpbGwgYmUgdXNlZCB0byBpZGVudGlmeSB0aGUgaW5mZXJlbmNlIHByb2ZpbGUgaW4gdGhlIEFXUyBjb25zb2xlIGFuZCBBUElzLlxuICAgKiAtIFJlcXVpcmVkOiAgWWVzXG4gICAqIC0gTWF4aW11bSBsZW5ndGg6IDY0IGNoYXJhY3RlcnNcbiAgICogLSBQYXR0ZXJuOiBgXihbMC05YS16QS1aOi5dWyBfLV0/KSskYFxuICAgKlxuICAgKiBAc2VlIGh0dHA6Ly9kb2NzLmF3cy5hbWF6b24uY29tL0FXU0Nsb3VkRm9ybWF0aW9uL2xhdGVzdC9Vc2VyR3VpZGUvYXdzLXJlc291cmNlLWJlZHJvY2stYXBwbGljYXRpb25pbmZlcmVuY2Vwcm9maWxlLmh0bWwjY2ZuLWJlZHJvY2stYXBwbGljYXRpb25pbmZlcmVuY2Vwcm9maWxlLWluZmVyZW5jZXByb2ZpbGVuYW1lXG4gICAqL1xuICByZWFkb25seSBhcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIERlc2NyaXB0aW9uIG9mIHRoZSBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogUHJvdmlkZXMgYWRkaXRpb25hbCBjb250ZXh0IGFib3V0IHRoZSBwdXJwb3NlIGFuZCB1c2FnZSBvZiB0aGlzIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKlxuICAgKiAtIE1heGltdW0gbGVuZ3RoOiAyMDAgY2hhcmFjdGVycyB3aGVuIHByb3ZpZGVkXG4gICAqIC0gUGF0dGVybjogYF4oWzAtOWEtekEtWjouXVsgXy1dPykrJGBcbiAgICogQGRlZmF1bHQgLSBObyBkZXNjcmlwdGlvbiBpcyBwcm92aWRlZFxuICAgKiBAc2VlIGh0dHA6Ly9kb2NzLmF3cy5hbWF6b24uY29tL0FXU0Nsb3VkRm9ybWF0aW9uL2xhdGVzdC9Vc2VyR3VpZGUvYXdzLXJlc291cmNlLWJlZHJvY2stYXBwbGljYXRpb25pbmZlcmVuY2Vwcm9maWxlLmh0bWwjY2ZuLWJlZHJvY2stYXBwbGljYXRpb25pbmZlcmVuY2Vwcm9maWxlLWRlc2NyaXB0aW9uXG4gICAqL1xuICByZWFkb25seSBkZXNjcmlwdGlvbj86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIG1vZGVsIHNvdXJjZSBmb3IgdGhpcyBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICpcbiAgICogVG8gY3JlYXRlIGFuIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlIGZvciBvbmUgUmVnaW9uLCBzcGVjaWZ5IGEgZm91bmRhdGlvbiBtb2RlbC5cbiAgICogVXNhZ2UgYW5kIGNvc3RzIGZvciByZXF1ZXN0cyBtYWRlIHRvIHRoYXQgUmVnaW9uIHdpdGggdGhhdCBtb2RlbCB3aWxsIGJlIHRyYWNrZWQuXG4gICAqXG4gICAqIFRvIGNyZWF0ZSBhbiBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZSBmb3IgbXVsdGlwbGUgUmVnaW9ucyxcbiAgICogc3BlY2lmeSBhIGNyb3NzIHJlZ2lvbiAoc3lzdGVtLWRlZmluZWQpIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKiBUaGUgaW5mZXJlbmNlIHByb2ZpbGUgd2lsbCByb3V0ZSByZXF1ZXN0cyB0byB0aGUgUmVnaW9ucyBkZWZpbmVkIGluXG4gICAqIHRoZSBjcm9zcyByZWdpb24gKHN5c3RlbS1kZWZpbmVkKSBpbmZlcmVuY2UgcHJvZmlsZSB0aGF0IHlvdSBjaG9vc2UuXG4gICAqIFVzYWdlIGFuZCBjb3N0cyBmb3IgcmVxdWVzdHMgbWFkZSB0byB0aGUgUmVnaW9ucyBpbiB0aGUgaW5mZXJlbmNlIHByb2ZpbGUgd2lsbCBiZSB0cmFja2VkLlxuICAgKlxuICAgKi9cbiAgcmVhZG9ubHkgbW9kZWxTb3VyY2U6IElCZWRyb2NrSW52b2thYmxlO1xuICAvKipcbiAgICogQSBsaXN0IG9mIHRhZ3MgYXNzb2NpYXRlZCB3aXRoIHRoZSBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogVGFncyBoZWxwIHlvdSBvcmdhbml6ZSBhbmQgY2F0ZWdvcml6ZSB5b3VyIEFXUyByZXNvdXJjZXMuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gTm8gdGFncyBhcmUgYXBwbGllZFxuICAgKi9cbiAgcmVhZG9ubHkgdGFncz86IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH07XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgIEFUVFJTIEZPUiBJTVBPUlRFRCBDT05TVFJVQ1RcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogQXR0cmlidXRlcyBmb3Igc3BlY2lmeWluZyBhbiBpbXBvcnRlZCBBcHBsaWNhdGlvbiBJbmZlcmVuY2UgUHJvZmlsZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBBcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVBdHRyaWJ1dGVzIHtcbiAgLyoqXG4gICAqIFRoZSBBUk4gb2YgdGhlIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlQXJuOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBJRCBvciBBbWF6b24gUmVzb3VyY2UgTmFtZSAoQVJOKSBvZiB0aGUgaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFRoaXMgY2FuIGJlIGVpdGhlciB0aGUgcHJvZmlsZSBJRCBvciB0aGUgZnVsbCBBUk4uXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVJZGVudGlmaWVyOiBzdHJpbmc7XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgTkVXIENPTlNUUlVDVCBERUZJTklUSU9OXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIENsYXNzIHRvIGNyZWF0ZSBhbiBBcHBsaWNhdGlvbiBJbmZlcmVuY2UgUHJvZmlsZSB3aXRoIENESy5cbiAqIFRoZXNlIGFyZSBpbmZlcmVuY2UgcHJvZmlsZXMgY3JlYXRlZCBieSB1c2VycyAodXNlciBkZWZpbmVkKS5cbiAqIFRoaXMgaGVscHMgdG8gdHJhY2sgY29zdHMgYW5kIG1vZGVsIHVzYWdlLlxuICpcbiAqIEFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlcyBhcmUgdXNlci1kZWZpbmVkIHByb2ZpbGVzIHRoYXQgaGVscCB5b3UgdHJhY2sgY29zdHMgYW5kIG1vZGVsIHVzYWdlLlxuICogVGhleSBjYW4gYmUgY3JlYXRlZCBmb3IgYSBzaW5nbGUgcmVnaW9uIG9yIGZvciBtdWx0aXBsZSByZWdpb25zIHVzaW5nIGEgY3Jvc3MtcmVnaW9uIGluZmVyZW5jZSBwcm9maWxlLlxuICpcbiAqIEBjbG91ZGZvcm1hdGlvblJlc291cmNlIEFXUzo6QmVkcm9jazo6QXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlXG4gKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9iZWRyb2NrL2xhdGVzdC91c2VyZ3VpZGUvaW5mZXJlbmNlLXByb2ZpbGVzLWNyZWF0ZS5odG1sXG4gKi9cbkBwcm9wZXJ0eUluamVjdGFibGVcbmV4cG9ydCBjbGFzcyBBcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUgZXh0ZW5kcyBJbmZlcmVuY2VQcm9maWxlQmFzZSBpbXBsZW1lbnRzIElCZWRyb2NrSW52b2thYmxlIHtcbiAgLyoqIFVuaXF1ZWx5IGlkZW50aWZpZXMgdGhpcyBjbGFzcy4gKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBQUk9QRVJUWV9JTkpFQ1RJT05fSUQ6IHN0cmluZyA9ICdAYXdzLWNkay5hd3MtYmVkcm9jay1hbHBoYS5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUnO1xuXG4gIC8qKlxuICAgKiBJbXBvcnQgYW4gQXBwbGljYXRpb24gSW5mZXJlbmNlIFByb2ZpbGUgZ2l2ZW4gaXRzIGF0dHJpYnV0ZXMuXG4gICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgKlxuICAgKiBAcGFyYW0gc2NvcGUgLSBUaGUgY29uc3RydWN0IHNjb3BlXG4gICAqIEBwYXJhbSBpZCAtIElkZW50aWZpZXIgb2YgdGhlIGNvbnN0cnVjdFxuICAgKiBAcGFyYW0gYXR0cnMgLSBBdHRyaWJ1dGVzIG9mIHRoZSBleGlzdGluZyBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZVxuICAgKiBAcmV0dXJucyBBbiBJSW5mZXJlbmNlUHJvZmlsZSByZWZlcmVuY2UgdG8gdGhlIGV4aXN0aW5nIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVBdHRyaWJ1dGVzKFxuICAgIHNjb3BlOiBDb25zdHJ1Y3QsXG4gICAgaWQ6IHN0cmluZyxcbiAgICBhdHRyczogQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlQXR0cmlidXRlcyxcbiAgKTogSUluZmVyZW5jZVByb2ZpbGUge1xuICAgIGNsYXNzIEltcG9ydCBleHRlbmRzIEluZmVyZW5jZVByb2ZpbGVCYXNlIHtcbiAgICAgIHB1YmxpYyByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlQXJuID0gYXR0cnMuaW5mZXJlbmNlUHJvZmlsZUFybjtcbiAgICAgIHB1YmxpYyByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlSWQgPSBBcm4uc3BsaXQoYXR0cnMuaW5mZXJlbmNlUHJvZmlsZUFybiwgQXJuRm9ybWF0LlNMQVNIX1JFU09VUkNFX05BTUUpXG4gICAgICAgIC5yZXNvdXJjZU5hbWUhO1xuICAgICAgcHVibGljIHJlYWRvbmx5IHR5cGUgPSBJbmZlcmVuY2VQcm9maWxlVHlwZS5BUFBMSUNBVElPTjtcblxuICAgICAgLyoqXG4gICAgICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICAgICAqL1xuICAgICAgcHVibGljIGdyYW50UHJvZmlsZVVzYWdlKGdyYW50ZWU6IElHcmFudGFibGUpOiBHcmFudCB7XG4gICAgICAgIHJldHVybiBHcmFudC5hZGRUb1ByaW5jaXBhbCh7XG4gICAgICAgICAgZ3JhbnRlZTogZ3JhbnRlZSxcbiAgICAgICAgICBhY3Rpb25zOiBbJ2JlZHJvY2s6R2V0SW5mZXJlbmNlUHJvZmlsZScsICdiZWRyb2NrOkludm9rZU1vZGVsJ10sXG4gICAgICAgICAgcmVzb3VyY2VBcm5zOiBbdGhpcy5pbmZlcmVuY2VQcm9maWxlQXJuXSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBJbXBvcnQoc2NvcGUsIGlkKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbXBvcnQgYSBsb3ctbGV2ZWwgTDEgQ2ZuIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICpcbiAgICogQHBhcmFtIGNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZSAtIFRoZSBMMSBDZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUgdG8gaW1wb3J0XG4gICAqIEByZXR1cm5zIEFuIElJbmZlcmVuY2VQcm9maWxlIHJlZmVyZW5jZSB0byB0aGUgaW1wb3J0ZWQgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGVcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZShcbiAgICBjZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGU6IGJlZHJvY2suQ2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlLFxuICApOiBJSW5mZXJlbmNlUHJvZmlsZSB7XG4gICAgLy8gU2luZ2xldG9uIHBhdHRlcm4gdGhhdCB3aWxsIHByZXZlbnQgY3JlYXRpbmcgMiBvciBtb3JlIEluZmVyZW5jZSBQcm9maWxlcyBmcm9tIHRoZSBzYW1lIEwxXG4gICAgY29uc3QgaWQgPSAnQEZyb21DZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUnO1xuICAgIGNvbnN0IGV4aXN0aW5nID0gY2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlLm5vZGUudHJ5RmluZENoaWxkKGlkKTtcbiAgICBpZiAoZXhpc3RpbmcpIHtcbiAgICAgIHJldHVybiBleGlzdGluZyBhcyB1bmtub3duIGFzIElJbmZlcmVuY2VQcm9maWxlO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgKGNsYXNzIGV4dGVuZHMgSW5mZXJlbmNlUHJvZmlsZUJhc2Uge1xuICAgICAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVBcm4gPSBjZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUuYXR0ckluZmVyZW5jZVByb2ZpbGVBcm47XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZUlkID0gY2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlLmF0dHJJbmZlcmVuY2VQcm9maWxlSWQ7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgdHlwZSA9IEluZmVyZW5jZVByb2ZpbGVUeXBlLkFQUExJQ0FUSU9OO1xuXG4gICAgICAvKipcbiAgICAgICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgICAgICovXG4gICAgICBwdWJsaWMgZ3JhbnRQcm9maWxlVXNhZ2UoZ3JhbnRlZTogSUdyYW50YWJsZSk6IEdyYW50IHtcbiAgICAgICAgcmV0dXJuIEdyYW50LmFkZFRvUHJpbmNpcGFsKHtcbiAgICAgICAgICBncmFudGVlOiBncmFudGVlLFxuICAgICAgICAgIGFjdGlvbnM6IFsnYmVkcm9jazpHZXRJbmZlcmVuY2VQcm9maWxlJywgJ2JlZHJvY2s6SW52b2tlTW9kZWwnXSxcbiAgICAgICAgICByZXNvdXJjZUFybnM6IFt0aGlzLmluZmVyZW5jZVByb2ZpbGVBcm5dLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KShjZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUsIGlkKTtcbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBCYXNlIGF0dHJpYnV0ZXNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZU5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlQXJuOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSB1bmlxdWUgaWRlbnRpZmllciBvZiB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlSWQ6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHVuZGVybHlpbmcgbW9kZWwvY3Jvc3MtcmVnaW9uIG1vZGVsIHVzZWQgYnkgdGhlIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVNb2RlbDogSUJlZHJvY2tJbnZva2FibGU7XG5cbiAgLyoqXG4gICAqIFRoZSBzdGF0dXMgb2YgdGhlIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlLiBBQ1RJVkUgbWVhbnMgdGhhdCB0aGUgaW5mZXJlbmNlIHByb2ZpbGUgaXMgcmVhZHkgdG8gYmUgdXNlZC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHN0YXR1czogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgdHlwZSBvZiB0aGUgaW5mZXJlbmNlIHByb2ZpbGUuIEFsd2F5cyBBUFBMSUNBVElPTiBmb3IgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGVzLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHR5cGU6IEluZmVyZW5jZVByb2ZpbGVUeXBlO1xuXG4gIC8qKlxuICAgKiBUaW1lIFN0YW1wIGZvciBBcHBsaWNhdGlvbiBJbmZlcmVuY2UgUHJvZmlsZSBjcmVhdGlvbi5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGNyZWF0ZWRBdDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaW1lIFN0YW1wIGZvciBBcHBsaWNhdGlvbiBJbmZlcmVuY2UgUHJvZmlsZSB1cGRhdGUuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSB1cGRhdGVkQXQ6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIEFSTiB1c2VkIGZvciBpbnZva2luZyB0aGlzIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKiBUaGlzIGVxdWFscyB0byB0aGUgaW5mZXJlbmNlUHJvZmlsZUFybiBwcm9wZXJ0eSwgdXNlZnVsIGZvciBpbXBsZW1lbnRpbmcgSUJlZHJvY2tJbnZva2FibGUgaW50ZXJmYWNlLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGludm9rYWJsZUFybjogc3RyaW5nO1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBJbnRlcm5hbCBPbmx5XG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvKipcbiAgICogSW5zdGFuY2Ugb2YgQ2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlLlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIHByaXZhdGUgcmVhZG9ubHkgX19yZXNvdXJjZTogYmVkcm9jay5DZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGU7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIENPTlNUUlVDVE9SXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlUHJvcHMpIHtcbiAgICBzdXBlcihzY29wZSwgaWQpO1xuICAgIC8vIEVuaGFuY2VkIENESyBBbmFseXRpY3MgVGVsZW1ldHJ5XG4gICAgYWRkQ29uc3RydWN0TWV0YWRhdGEodGhpcywgcHJvcHMpO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gVmFsaWRhdGUgcHJvcHNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLnZhbGlkYXRlUHJvcHMocHJvcHMpO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gU2V0IHByb3BlcnRpZXNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLmluZmVyZW5jZVByb2ZpbGVNb2RlbCA9IHByb3BzLm1vZGVsU291cmNlO1xuICAgIHRoaXMudHlwZSA9IEluZmVyZW5jZVByb2ZpbGVUeXBlLkFQUExJQ0FUSU9OO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gTDEgaW5zdGFudGlhdGlvblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMuX19yZXNvdXJjZSA9IG5ldyBiZWRyb2NrLkNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZSh0aGlzLCAnUmVzb3VyY2UnLCB7XG4gICAgICBkZXNjcmlwdGlvbjogcHJvcHMuZGVzY3JpcHRpb24sXG4gICAgICBpbmZlcmVuY2VQcm9maWxlTmFtZTogcHJvcHMuYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZSxcbiAgICAgIG1vZGVsU291cmNlOiB7XG4gICAgICAgIGNvcHlGcm9tOiBwcm9wcy5tb2RlbFNvdXJjZS5pbnZva2FibGVBcm4sXG4gICAgICB9LFxuICAgICAgdGFnczogcHJvcHMudGFncyA/IE9iamVjdC5lbnRyaWVzKHByb3BzLnRhZ3MpLm1hcCgoW2tleSwgdmFsdWVdKSA9PiAoeyBrZXksIHZhbHVlIH0pKSA6IHVuZGVmaW5lZCxcbiAgICB9KTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIEJ1aWxkIGF0dHJpYnV0ZXNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLmluZmVyZW5jZVByb2ZpbGVBcm4gPSB0aGlzLl9fcmVzb3VyY2UuYXR0ckluZmVyZW5jZVByb2ZpbGVBcm47XG4gICAgdGhpcy5pbmZlcmVuY2VQcm9maWxlSWQgPSB0aGlzLl9fcmVzb3VyY2UuYXR0ckluZmVyZW5jZVByb2ZpbGVJZDtcbiAgICB0aGlzLmluZmVyZW5jZVByb2ZpbGVOYW1lID0gdGhpcy5fX3Jlc291cmNlLmluZmVyZW5jZVByb2ZpbGVOYW1lITtcbiAgICB0aGlzLnN0YXR1cyA9IHRoaXMuX19yZXNvdXJjZS5hdHRyU3RhdHVzO1xuICAgIHRoaXMuY3JlYXRlZEF0ID0gdGhpcy5fX3Jlc291cmNlLmF0dHJDcmVhdGVkQXQ7XG4gICAgdGhpcy51cGRhdGVkQXQgPSB0aGlzLl9fcmVzb3VyY2UuYXR0clVwZGF0ZWRBdDtcbiAgICB0aGlzLmludm9rYWJsZUFybiA9IHRoaXMuaW5mZXJlbmNlUHJvZmlsZUFybjtcbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBNRVRIT0RTXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgdGhlIHByb3BlcnRpZXMgZm9yIGNyZWF0aW5nIGFuIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlLlxuICAgKlxuICAgKiBAcGFyYW0gcHJvcHMgLSBUaGUgcHJvcGVydGllcyB0byB2YWxpZGF0ZVxuICAgKiBAdGhyb3dzIFZhbGlkYXRpb25FcnJvciBpZiBhbnkgdmFsaWRhdGlvbiBmYWlsc1xuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVByb3BzKHByb3BzOiBBcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVQcm9wcyk6IHZvaWQge1xuICAgIC8vIFZhbGlkYXRlIGFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZU5hbWUgaXMgcHJvdmlkZWQgYW5kIG5vdCBlbXB0eVxuICAgIGlmICghcHJvcHMuYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZSB8fCBwcm9wcy5hcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lLnRyaW0oKSA9PT0gJycpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ1Byb2ZpbGVOYW1lUmVxdWlyZWQnLCAnYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZSBpcyByZXF1aXJlZCBhbmQgY2Fubm90IGJlIGVtcHR5JywgdGhpcyk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZSBsZW5ndGhcbiAgICBpZiAocHJvcHMuYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZS5sZW5ndGggPiA2NCkge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignUHJvZmlsZU5hbWVUb29Mb25nJywgJ2FwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZU5hbWUgY2Fubm90IGV4Y2VlZCA2NCBjaGFyYWN0ZXJzJywgdGhpcyk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZSBwYXR0ZXJuXG4gICAgY29uc3QgbmFtZVBhdHRlcm4gPSAvXihbMC05YS16QS1aOi5dWyBfLV0/KSskLztcbiAgICBpZiAoIW5hbWVQYXR0ZXJuLnRlc3QocHJvcHMuYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZSkpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoXG4gICAgICAgICdQcm9maWxlTmFtZUludmFsaWRQYXR0ZXJuJyxcbiAgICAgICAgJ2FwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZU5hbWUgbXVzdCBtYXRjaCBwYXR0ZXJuIF4oWzAtOWEtekEtWjouXVsgXy1dPykrJCcsXG4gICAgICAgIHRoaXMsXG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIG1vZGVsU291cmNlIGlzIHByb3ZpZGVkXG4gICAgaWYgKCFwcm9wcy5tb2RlbFNvdXJjZSkge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignTW9kZWxTb3VyY2VSZXF1aXJlZCcsICdtb2RlbFNvdXJjZSBpcyByZXF1aXJlZCcsIHRoaXMpO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIGRlc2NyaXB0aW9uIGxlbmd0aCBpZiBwcm92aWRlZFxuICAgIGlmIChwcm9wcy5kZXNjcmlwdGlvbiAhPT0gdW5kZWZpbmVkICYmIHByb3BzLmRlc2NyaXB0aW9uLmxlbmd0aCA+IDIwMCkge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignRGVzY3JpcHRpb25Ub29Mb25nJywgJ2Rlc2NyaXB0aW9uIGNhbm5vdCBleGNlZWQgMjAwIGNoYXJhY3RlcnMnLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBkZXNjcmlwdGlvbiBwYXR0ZXJuIGlmIHByb3ZpZGVkXG4gICAgaWYgKHByb3BzLmRlc2NyaXB0aW9uICE9PSB1bmRlZmluZWQgJiYgcHJvcHMuZGVzY3JpcHRpb24gIT09ICcnKSB7XG4gICAgICBjb25zdCBkZXNjcmlwdGlvblBhdHRlcm4gPSAvXihbMC05YS16QS1aOi5dWyBfLV0/KSskLztcbiAgICAgIGlmICghZGVzY3JpcHRpb25QYXR0ZXJuLnRlc3QocHJvcHMuZGVzY3JpcHRpb24pKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoXG4gICAgICAgICAgJ0Rlc2NyaXB0aW9uSW52YWxpZFBhdHRlcm4nLFxuICAgICAgICAgICdkZXNjcmlwdGlvbiBtdXN0IG1hdGNoIHBhdHRlcm4gXihbMC05YS16QS1aOi5dWyBfLV0/KSskJyxcbiAgICAgICAgICB0aGlzLFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBHaXZlcyB0aGUgYXBwcm9wcmlhdGUgcG9saWNpZXMgdG8gaW52b2tlIGFuZCB1c2UgdGhlIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKiBUaGlzIG1ldGhvZCBlbnN1cmVzIHRoZSBhcHByb3ByaWF0ZSBwZXJtaXNzaW9ucyBhcmUgZ2l2ZW4gdG8gdXNlIGVpdGhlciB0aGUgaW5mZXJlbmNlIHByb2ZpbGVcbiAgICogb3IgdGhlIHVuZGVybHlpbmcgZm91bmRhdGlvbiBtb2RlbC9jcm9zcy1yZWdpb24gcHJvZmlsZS5cbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqXG4gICAqIEBwYXJhbSBncmFudGVlIC0gVGhlIElBTSBwcmluY2lwYWwgdG8gZ3JhbnQgcGVybWlzc2lvbnMgdG9cbiAgICogQHJldHVybnMgQW4gSUFNIEdyYW50IG9iamVjdCByZXByZXNlbnRpbmcgdGhlIGdyYW50ZWQgcGVybWlzc2lvbnNcbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBncmFudEludm9rZShncmFudGVlOiBJR3JhbnRhYmxlKTogR3JhbnQge1xuICAgIC8vIFRoaXMgbWV0aG9kIGVuc3VyZXMgdGhlIGFwcHJvcHJpYXRlIHBlcm1pc3Npb25zIGFyZSBnaXZlblxuICAgIC8vIHRvIHVzZSBlaXRoZXIgdGhlIGluZmVyZW5jZSBwcm9maWxlIG9yIHRoZSB2YW5pbGxhIGZvdW5kYXRpb24gbW9kZWxcbiAgICB0aGlzLmluZmVyZW5jZVByb2ZpbGVNb2RlbC5ncmFudEludm9rZShncmFudGVlKTtcblxuICAgIC8vIFBsdXMgd2UgYWRkIHBlcm1pc3Npb25zIHRvIG5vdyBpbnZva2UgdGhlIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlIGl0c2VsZlxuICAgIHJldHVybiB0aGlzLmdyYW50UHJvZmlsZVVzYWdlKGdyYW50ZWUpO1xuICB9XG5cbiAgLyoqXG4gICAqIEdyYW50cyBhcHByb3ByaWF0ZSBwZXJtaXNzaW9ucyB0byB1c2UgdGhlIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlIChBSVApLlxuICAgKiBUaGlzIG1ldGhvZCBhZGRzIHRoZSBuZWNlc3NhcnkgSUFNIHBlcm1pc3Npb25zIHRvIGFsbG93IHRoZSBncmFudGVlIHRvOlxuICAgKiAtIEdldCBpbmZlcmVuY2UgcHJvZmlsZSBkZXRhaWxzIChiZWRyb2NrOkdldEluZmVyZW5jZVByb2ZpbGUpXG4gICAqIC0gSW52b2tlIHRoZSBtb2RlbCB0aHJvdWdoIHRoZSBpbmZlcmVuY2UgcHJvZmlsZSAoYmVkcm9jazpJbnZva2VNb2RlbClcbiAgICpcbiAgICogTm90ZTogVGhpcyBkb2VzIG5vdCBncmFudCBwZXJtaXNzaW9ucyB0byB1c2UgdGhlIHVuZGVybHlpbmcgbW9kZWwvY3Jvc3MtcmVnaW9uIHByb2ZpbGUgaW4gdGhlIEFJUC5cbiAgICogRm9yIGNvbXByZWhlbnNpdmUgcGVybWlzc2lvbnMsIHVzZSBncmFudEludm9rZSgpIGluc3RlYWQuXG4gICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgKlxuICAgKiBAcGFyYW0gZ3JhbnRlZSAtIFRoZSBJQU0gcHJpbmNpcGFsIHRvIGdyYW50IHBlcm1pc3Npb25zIHRvXG4gICAqIEByZXR1cm5zIEFuIElBTSBHcmFudCBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSBncmFudGVkIHBlcm1pc3Npb25zXG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgZ3JhbnRQcm9maWxlVXNhZ2UoZ3JhbnRlZTogSUdyYW50YWJsZSk6IEdyYW50IHtcbiAgICByZXR1cm4gR3JhbnQuYWRkVG9QcmluY2lwYWwoe1xuICAgICAgZ3JhbnRlZTogZ3JhbnRlZSxcbiAgICAgIGFjdGlvbnM6IFsnYmVkcm9jazpHZXRJbmZlcmVuY2VQcm9maWxlJywgJ2JlZHJvY2s6SW52b2tlTW9kZWwnXSxcbiAgICAgIHJlc291cmNlQXJuczogW3RoaXMuaW5mZXJlbmNlUHJvZmlsZUFybl0sXG4gICAgfSk7XG4gIH1cbn1cbiJdfQ==