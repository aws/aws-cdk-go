"use strict";
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Guardrail = exports.GuardrailBase = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const fs = require("fs");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const bedrock = require("aws-cdk-lib/aws-bedrock");
const aws_cloudwatch_1 = require("aws-cdk-lib/aws-cloudwatch");
const iam = require("aws-cdk-lib/aws-iam");
const aws_kms_1 = require("aws-cdk-lib/aws-kms");
const helpers_internal_1 = require("aws-cdk-lib/core/lib/helpers-internal");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
// Internal Libs
const filters = require("./guardrail-filters");
const guardrail_version_1 = require("./guardrail-version");
/**
 * Abstract base class for a Guardrail.
 * Contains methods and attributes valid for Guardrails either created with CDK or imported.
 */
class GuardrailBase extends aws_cdk_lib_1.Resource {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.GuardrailBase", version: "2.245.0-alpha.0" };
    /**
     * Return the given named metric for all guardrails.
     *
     * By default, the metric will be calculated as a sum over a period of 5 minutes.
     * You can customize this by using the `statistic` and `period` properties.
     */
    static metricAll(metricName, props) {
        return new aws_cloudwatch_1.Metric({
            namespace: 'AWS/Bedrock/Guardrails',
            dimensionsMap: { Operation: 'ApplyGuardrail' },
            metricName,
            ...props,
        });
    }
    /**
     * Return the invocations metric for all guardrails.
     */
    static metricAllInvocations(props) {
        return this.metricAll('Invocations', props);
    }
    /**
     * Return the text unit count metric for all guardrails.
     */
    static metricAllTextUnitCount(props) {
        return this.metricAll('TextUnitCount', props);
    }
    /**
     * Return the invocations intervened metric for all guardrails.
     */
    static metricAllInvocationsIntervened(props) {
        return this.metricAll('InvocationsIntervened', props);
    }
    /**
     * Return the invocation latency metric for all guardrails.
     */
    static metricAllInvocationLatency(props) {
        return this.metricAll('InvocationLatency', props);
    }
    _version = 'DRAFT';
    /**
     * The version of the guardrail.
     * @attribute
     */
    get guardrailVersion() {
        return this._version;
    }
    updateVersion(version) {
        this._version = version;
    }
    /**
     * Grant the given principal identity permissions to perform actions on this guardrail.
     * [disable-awslint:no-grants]
     */
    grant(grantee, ...actions) {
        return iam.Grant.addToPrincipal({
            grantee,
            actions,
            resourceArns: [this.guardrailArn],
        });
    }
    /**
     * Grant the given identity permissions to apply the guardrail.
     * [disable-awslint:no-grants]
     */
    grantApply(grantee) {
        const baseGrant = this.grant(grantee, 'bedrock:ApplyGuardrail');
        if (this.kmsKey) {
            // If KMS key exists, create encryption grant and combine with base grant
            const kmsGrant = this.kmsKey.grantEncryptDecrypt(grantee);
            return kmsGrant.combine(baseGrant);
        }
        else {
            // If no KMS key exists, return only the base grant
            return baseGrant;
        }
    }
    /**
     * Return the given named metric for this guardrail.
     *
     * By default, the metric will be calculated as a sum over a period of 5 minutes.
     * You can customize this by using the `statistic` and `period` properties.
     */
    metric(metricName, props) {
        const metricProps = {
            namespace: 'AWS/Bedrock/Guardrails',
            metricName,
            dimensionsMap: { GuardrailArn: this.guardrailArn, GuardrailVersion: this.guardrailVersion },
            ...props,
        };
        return this.configureMetric(metricProps);
    }
    /**
     * Return the invocations metric for this guardrail.
     */
    metricInvocations(props) {
        return this.metric('Invocations', props);
    }
    /**
     * Return the invocation latency metric for this guardrail.
     */
    metricInvocationLatency(props) {
        return this.metric('InvocationLatency', props);
    }
    /**
     * Return the invocation client errors metric for this guardrail.
     */
    metricInvocationClientErrors(props) {
        return this.metric('InvocationClientErrors', props);
    }
    /**
     * Return the invocation server errors metric for this guardrail.
     */
    metricInvocationServerErrors(props) {
        return this.metric('InvocationServerErrors', props);
    }
    /**
     * Return the invocation throttles metric for this guardrail.
     */
    metricInvocationThrottles(props) {
        return this.metric('InvocationThrottles', props);
    }
    /**
     * Return the text unit count metric for this guardrail.
     */
    metricTextUnitCount(props) {
        return this.metric('TextUnitCount', props);
    }
    /**
     * Return the invocations intervened metric for this guardrail.
     */
    metricInvocationsIntervened(props) {
        return this.metric('InvocationsIntervened', props);
    }
    configureMetric(props) {
        return new aws_cloudwatch_1.Metric({
            ...props,
            region: props?.region ?? this.stack.region,
            account: props?.account ?? this.stack.account,
        });
    }
}
exports.GuardrailBase = GuardrailBase;
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create a Guardrail with CDK.
 * @cloudformationResource AWS::Bedrock::Guardrail
 */
let Guardrail = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = GuardrailBase;
    let _instanceExtraInitializers = [];
    let _addContentFilter_decorators;
    let _addPIIFilter_decorators;
    let _addRegexFilter_decorators;
    let _addDeniedTopicFilter_decorators;
    let _addContextualGroundingFilter_decorators;
    let _addWordFilter_decorators;
    let _addWordFilterFromFile_decorators;
    let _addManagedWordListFilter_decorators;
    let _createVersion_decorators;
    var Guardrail = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _addContentFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addPIIFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addRegexFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addDeniedTopicFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addContextualGroundingFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addWordFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addWordFilterFromFile_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _addManagedWordListFilter_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _createVersion_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            __esDecorate(this, null, _addContentFilter_decorators, { kind: "method", name: "addContentFilter", static: false, private: false, access: { has: obj => "addContentFilter" in obj, get: obj => obj.addContentFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addPIIFilter_decorators, { kind: "method", name: "addPIIFilter", static: false, private: false, access: { has: obj => "addPIIFilter" in obj, get: obj => obj.addPIIFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addRegexFilter_decorators, { kind: "method", name: "addRegexFilter", static: false, private: false, access: { has: obj => "addRegexFilter" in obj, get: obj => obj.addRegexFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addDeniedTopicFilter_decorators, { kind: "method", name: "addDeniedTopicFilter", static: false, private: false, access: { has: obj => "addDeniedTopicFilter" in obj, get: obj => obj.addDeniedTopicFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addContextualGroundingFilter_decorators, { kind: "method", name: "addContextualGroundingFilter", static: false, private: false, access: { has: obj => "addContextualGroundingFilter" in obj, get: obj => obj.addContextualGroundingFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addWordFilter_decorators, { kind: "method", name: "addWordFilter", static: false, private: false, access: { has: obj => "addWordFilter" in obj, get: obj => obj.addWordFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addWordFilterFromFile_decorators, { kind: "method", name: "addWordFilterFromFile", static: false, private: false, access: { has: obj => "addWordFilterFromFile" in obj, get: obj => obj.addWordFilterFromFile }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _addManagedWordListFilter_decorators, { kind: "method", name: "addManagedWordListFilter", static: false, private: false, access: { has: obj => "addManagedWordListFilter" in obj, get: obj => obj.addManagedWordListFilter }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _createVersion_decorators, { kind: "method", name: "createVersion", static: false, private: false, access: { has: obj => "createVersion" in obj, get: obj => obj.createVersion }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            Guardrail = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.Guardrail", version: "2.245.0-alpha.0" };
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.Guardrail';
        /**
         * Import a guardrail given its attributes
         */
        static fromGuardrailAttributes(scope, id, attrs) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_GuardrailAttributes(attrs);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.fromGuardrailAttributes);
                }
                throw error;
            }
            class Import extends GuardrailBase {
                guardrailArn = attrs.guardrailArn;
                guardrailId = aws_cdk_lib_1.Arn.split(attrs.guardrailArn, aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME).resourceName;
                kmsKey = attrs.kmsKey;
                lastUpdated = undefined;
                constructor() {
                    super(scope, id);
                    this.updateVersion(attrs.guardrailVersion ?? 'DRAFT');
                }
            }
            return new Import();
        }
        /**
         * Import a low-level L1 Cfn Guardrail
         */
        static fromCfnGuardrail(cfnGuardrail) {
            return new (class extends GuardrailBase {
                guardrailArn = cfnGuardrail.attrGuardrailArn;
                guardrailId = cfnGuardrail.attrGuardrailId;
                kmsKey = cfnGuardrail.kmsKeyArn
                    ? aws_kms_1.Key.fromKeyArn(this, '@FromCfnGuardrailKey', cfnGuardrail.kmsKeyArn)
                    : undefined;
                lastUpdated = cfnGuardrail.attrUpdatedAt;
                constructor() {
                    super(cfnGuardrail, '@FromCfnGuardrail');
                    this.updateVersion(cfnGuardrail.attrVersion);
                }
            })();
        }
        /**
         * The ARN of the guardrail.
         * @attribute
         */
        guardrailArn = __runInitializers(this, _instanceExtraInitializers);
        /**
         * The ID of the guardrail.
         * @attribute
         */
        guardrailId;
        /**
         * The name of the guardrail.
         */
        name;
        /**
         * The KMS key used to encrypt data.
         *
         * @default undefined - "Data is encrypted by default with a key that AWS owns and manages for you"
         */
        kmsKey;
        /**
         * The content filters applied by the guardrail.
         */
        contentFilters;
        /**
         * The PII filters applied by the guardrail.
         */
        piiFilters;
        /**
         * The regex filters applied by the guardrail.
         */
        regexFilters;
        /**
         * The denied topic filters applied by the guardrail.
         */
        deniedTopics;
        /**
         * The contextual grounding filters applied by the guardrail.
         */
        contextualGroundingFilters;
        /**
         * The word filters applied by the guardrail.
         */
        wordFilters;
        /**
         * The managed word list filters applied by the guardrail.
         */
        managedWordListFilters;
        /**
         * When this guardrail was last updated
         */
        lastUpdated;
        /**
         * The computed hash of the guardrail properties.
         */
        hash;
        /**
         * The L1 representation of the guardrail
         */
        __resource;
        /**
         * The tier that your guardrail uses for denied topic filters.
         * @default filters.TierConfig.CLASSIC
         */
        topicsTierConfig;
        /**
         * The tier that your guardrail uses for content filters.
         * Consider using a tier that balances performance, accuracy, and compatibility with your existing generative AI workflows.
         * @default filters.TierConfig.CLASSIC
         */
        contentFiltersTierConfig;
        /**
         * The cross-region configuration for the guardrail.
         */
        crossRegionConfig;
        /**
         * The message to return when the guardrail blocks a prompt.
         * @default "Sorry, your query violates our usage policy."
         */
        blockedInputMessaging;
        /**
         * The message to return when the guardrail blocks a model response.
         * @default "Sorry, I am unable to answer your question because of our usage policy."
         */
        blockedOutputsMessaging;
        constructor(scope, id, props) {
            super(scope, id, {
                physicalName: props.guardrailName,
            });
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_GuardrailProps(props);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, Guardrail);
                }
                throw error;
            }
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            // ------------------------------------------------------
            // Set properties or defaults
            // ------------------------------------------------------
            this.name = this.physicalName;
            this.contentFilters = props.contentFilters ?? [];
            this.piiFilters = props.piiFilters ?? [];
            this.regexFilters = props.regexFilters ?? [];
            this.deniedTopics = props.deniedTopics ?? [];
            this.contextualGroundingFilters = props.contextualGroundingFilters ?? [];
            this.wordFilters = props.wordFilters ?? [];
            this.managedWordListFilters = props.managedWordListFilters ?? [];
            this.topicsTierConfig = props.topicsTierConfig ?? filters.TierConfig.CLASSIC;
            this.contentFiltersTierConfig = props.contentFiltersTierConfig ?? filters.TierConfig.CLASSIC;
            this.crossRegionConfig = props.crossRegionConfig;
            this.blockedInputMessaging = props.blockedInputMessaging ?? 'Sorry, your query violates our usage policy.';
            this.blockedOutputsMessaging = props.blockedOutputsMessaging ?? 'Sorry, I am unable to answer your question because of our usage policy.';
            // ------------------------------------------------------
            // Validate all filter arrays
            // ------------------------------------------------------
            this.validateContentFilters(this.contentFilters);
            this.validatePiiFilters(this.piiFilters);
            this.validateRegexFilters(this.regexFilters);
            this.validateDeniedTopics(this.deniedTopics);
            this.validateContextualGroundingFilters(this.contextualGroundingFilters);
            this.validateWordFilters(this.wordFilters);
            this.validateManagedWordListFilters(this.managedWordListFilters);
            // ------------------------------------------------------
            // Validate messaging properties
            // ------------------------------------------------------
            this.validateMessagingProperty(this.blockedInputMessaging, 'blockedInputMessaging');
            this.validateMessagingProperty(this.blockedOutputsMessaging, 'blockedOutputsMessaging');
            // ------------------------------------------------------
            // Validate tier configuration requirements
            // ------------------------------------------------------
            this.validateTierConfiguration(props);
            // ------------------------------------------------------
            // CFN Props - With Lazy support
            // ------------------------------------------------------
            let cfnProps = {
                name: props.guardrailName,
                description: props.description,
                kmsKeyArn: props.kmsKey?.keyArn,
                blockedInputMessaging: this.blockedInputMessaging,
                blockedOutputsMessaging: this.blockedOutputsMessaging,
                // Lazy props
                crossRegionConfig: this.generateCfnCrossRegionConfig(),
                contentPolicyConfig: this.generateCfnContentPolicyConfig(),
                contextualGroundingPolicyConfig: this.generateCfnContextualPolicyConfig(),
                topicPolicyConfig: this.generateCfnTopicPolicy(),
                wordPolicyConfig: this.generateCfnWordPolicyConfig(),
                sensitiveInformationPolicyConfig: this.generateCfnSensitiveInformationPolicyConfig(),
            };
            // Hash calculation useful for versioning of the guardrail
            this.hash = (0, helpers_internal_1.md5hash)(JSON.stringify(cfnProps));
            // ------------------------------------------------------
            // L1 Instantiation
            // ------------------------------------------------------
            this.__resource = new bedrock.CfnGuardrail(this, 'MyGuardrail', cfnProps);
            this.guardrailId = this.__resource.attrGuardrailId;
            this.guardrailArn = this.__resource.attrGuardrailArn;
            this.updateVersion(this.__resource.attrVersion);
            this.lastUpdated = this.__resource.attrUpdatedAt;
        }
        // ------------------------------------------------------
        // METHODS
        // ------------------------------------------------------
        /**
         * Adds a content filter to the guardrail.
         * @param filter The content filter to add.
         */
        addContentFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ContentFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addContentFilter);
                }
                throw error;
            }
            this.validateSingleContentFilter(filter);
            this.contentFilters.push(filter);
        }
        /**
         * Adds a PII filter to the guardrail.
         * @param filter The PII filter to add.
         */
        addPIIFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_PIIFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addPIIFilter);
                }
                throw error;
            }
            this.validateSinglePiiFilter(filter);
            this.piiFilters.push(filter);
        }
        /**
         * Adds a regex filter to the guardrail.
         * @param filter The regex filter to add.
         */
        addRegexFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_RegexFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addRegexFilter);
                }
                throw error;
            }
            this.validateSingleRegexFilter(filter);
            this.regexFilters.push(filter);
        }
        /**
         * Adds a denied topic filter to the guardrail.
         * @param filter The denied topic filter to add.
         */
        addDeniedTopicFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_Topic(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addDeniedTopicFilter);
                }
                throw error;
            }
            this.validateSingleDeniedTopic(filter);
            this.deniedTopics.push(filter);
        }
        /**
         * Adds a contextual grounding filter to the guardrail.
         * @param filter The contextual grounding filter to add.
         */
        addContextualGroundingFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ContextualGroundingFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addContextualGroundingFilter);
                }
                throw error;
            }
            this.validateSingleContextualGroundingFilter(filter);
            this.contextualGroundingFilters.push(filter);
        }
        /**
         * Adds a word filter to the guardrail.
         * @param filter The word filter to add.
         */
        addWordFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_WordFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addWordFilter);
                }
                throw error;
            }
            this.validateSingleWordFilter(filter);
            this.wordFilters.push(filter);
        }
        /**
         * Adds a word filter to the guardrail.
         * @param filePath The location of the word filter file.
         */
        addWordFilterFromFile(filePath, inputAction, outputAction, inputEnabled, outputEnabled) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_GuardrailAction(inputAction);
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_GuardrailAction(outputAction);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addWordFilterFromFile);
                }
                throw error;
            }
            const fileContents = fs.readFileSync(filePath, 'utf8');
            const words = fileContents.trim().split(',');
            for (const word of words)
                this.addWordFilter({ text: word, inputAction, outputAction, inputEnabled, outputEnabled });
        }
        /**
         * Adds a managed word list filter to the guardrail.
         * @param filter The managed word list filter to add.
         */
        addManagedWordListFilter(filter) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ManagedWordFilter(filter);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.addManagedWordListFilter);
                }
                throw error;
            }
            this.validateSingleManagedWordListFilter(filter);
            this.managedWordListFilters.push(filter);
        }
        /**
         * Create a version for the guardrail.
         * @param description The description of the version.
         * @returns The guardrail version.
         */
        createVersion(description) {
            const cfnVersion = new guardrail_version_1.GuardrailVersion(this, `GuardrailVersion-${this.hash.slice(0, 16)}`, {
                description: description,
                guardrail: this,
            });
            this.updateVersion(cfnVersion.guardrailVersion);
            return this.guardrailVersion;
        }
        // ------------------------------------------------------
        // CFN Generators
        // ------------------------------------------------------
        /**
         * Returns the content filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnContentPolicyConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.contentFilters.length > 0) {
                        const contentPolicyConfig = {
                            filtersConfig: this.contentFilters,
                            ...(this.contentFiltersTierConfig && {
                                contentFiltersTierConfig: {
                                    tierName: this.contentFiltersTierConfig,
                                },
                            }),
                        };
                        return contentPolicyConfig;
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Returns the topic filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnTopicPolicy() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.deniedTopics.length > 0) {
                        const topicPolicyConfig = {
                            topicsConfig: this.deniedTopics.flatMap((topic) => {
                                return {
                                    definition: topic.definition,
                                    name: topic.name,
                                    examples: topic.examples,
                                    type: 'DENY',
                                    inputAction: topic.inputAction,
                                    inputEnabled: topic.inputEnabled,
                                    outputAction: topic.outputAction,
                                    outputEnabled: topic.outputEnabled,
                                };
                            }),
                            ...(this.topicsTierConfig && {
                                topicsTierConfig: {
                                    tierName: this.topicsTierConfig,
                                },
                            }),
                        };
                        return topicPolicyConfig;
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Returns the contectual filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnContextualPolicyConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.contextualGroundingFilters.length > 0) {
                        return {
                            filtersConfig: this.contextualGroundingFilters.flatMap((filter) => {
                                return {
                                    type: filter.type,
                                    threshold: filter.threshold,
                                    action: filter.action,
                                    enabled: filter.enabled,
                                };
                            }),
                        };
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Returns the word config applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnWordPolicyConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.wordFilters.length > 0 || this.managedWordListFilters.length > 0) {
                        return {
                            wordsConfig: this.generateCfnWordConfig(),
                            managedWordListsConfig: this.generateCfnManagedWordListsConfig(),
                        };
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Returns the word filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnWordConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    return this.wordFilters.flatMap((word) => {
                        return {
                            text: word.text,
                            inputAction: word.inputAction,
                            inputEnabled: word.inputEnabled,
                            outputAction: word.outputAction,
                            outputEnabled: word.outputEnabled,
                        };
                    });
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the word filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnManagedWordListsConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    return this.managedWordListFilters.flatMap((filter) => {
                        return {
                            type: filter.type,
                            inputAction: filter.inputAction,
                            inputEnabled: filter.inputEnabled,
                            outputAction: filter.outputAction,
                            outputEnabled: filter.outputEnabled,
                        };
                    });
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the sensitive information config applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnSensitiveInformationPolicyConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.regexFilters.length > 0 || this.piiFilters.length > 0) {
                        return {
                            regexesConfig: this.generateCfnRegexesConfig(),
                            piiEntitiesConfig: this.generateCfnPiiEntitiesConfig(),
                        };
                    }
                    else {
                        return undefined;
                    }
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the regex filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnRegexesConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    return this.regexFilters.flatMap((regex) => {
                        return {
                            name: regex.name,
                            description: regex.description,
                            pattern: regex.pattern,
                            action: regex.action,
                            inputAction: regex.inputAction,
                            inputEnabled: regex.inputEnabled,
                            outputAction: regex.outputAction,
                            outputEnabled: regex.outputEnabled,
                        };
                    });
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the Pii filters applied to the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnPiiEntitiesConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    return this.piiFilters.flatMap((filter) => {
                        return {
                            type: filter.type.value,
                            action: filter.action,
                            inputAction: filter.inputAction,
                            inputEnabled: filter.inputEnabled,
                            outputAction: filter.outputAction,
                            outputEnabled: filter.outputEnabled,
                        };
                    });
                },
            }, { omitEmptyArray: true });
        }
        /**
         * Returns the cross-region configuration for the guardrail. This method defers the computation
         * to synth time.
         */
        generateCfnCrossRegionConfig() {
            return aws_cdk_lib_1.Lazy.any({
                produce: () => {
                    if (this.crossRegionConfig) {
                        return {
                            guardrailProfileArn: this.crossRegionConfig.guardrailProfileArn,
                        };
                    }
                    else {
                        return undefined;
                    }
                },
            });
        }
        /**
         * Validates a RegexFilter object and applies default values for optional properties.
         * @param filter The regex filter to validate.
         * @param index Optional index for error messages when validating arrays.
         */
        validateRegexFilter(filter, index) {
            const prefix = index !== undefined ? `Invalid RegexFilter at index ${index}` : 'Invalid RegexFilter';
            // Validate name: between 1 and 100 characters
            if (filter.name !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.name)) {
                if (filter.name.length < 1) {
                    throw new aws_cdk_lib_1.ValidationError('RegexFilterNameTooShort', `${prefix}: The field name is ${filter.name.length} characters long but must be at least 1 characters`, this);
                }
                if (filter.name.length > 100) {
                    throw new aws_cdk_lib_1.ValidationError('RegexFilterNameTooLong', `${prefix}: The field name is ${filter.name.length} characters long but must be less than or equal to 100 characters`, this);
                }
            }
            // Validate description: between 1 and 1000 characters (if provided)
            if (filter.description !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.description)) {
                if (filter.description.length < 1) {
                    throw new aws_cdk_lib_1.ValidationError('RegexFilterDescriptionTooShort', `${prefix}: The field description is ${filter.description.length} characters long but must be at least 1 characters`, this);
                }
                if (filter.description.length > 1000) {
                    throw new aws_cdk_lib_1.ValidationError('RegexFilterDescriptionTooLong', `${prefix}: The field description is ${filter.description.length} characters long but must be less than or equal to 1000 characters`, this);
                }
            }
            // Validate pattern: at least one character
            if (filter.pattern !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.pattern)) {
                if (filter.pattern.length < 1) {
                    throw new aws_cdk_lib_1.ValidationError('RegexFilterPatternEmpty', `${prefix}: The field pattern is ${filter.pattern.length} characters long but must be at least 1 characters`, this);
                }
            }
            // Validate action: must be a valid GuardrailAction value
            if (filter.action !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.action) && !Object.values(filters.GuardrailAction).includes(filter.action)) {
                throw new aws_cdk_lib_1.ValidationError('InvalidGuardrailAction', `${prefix}: action must be a valid GuardrailAction value`, this);
            }
            // Validate inputAction: must be a valid GuardrailAction value (if provided)
            if (filter.inputAction !== undefined &&
                !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                throw new aws_cdk_lib_1.ValidationError('InvalidInputAction', `${prefix}: inputAction must be a valid GuardrailAction value`, this);
            }
            // Validate outputAction: must be a valid GuardrailAction value (if provided)
            if (filter.outputAction !== undefined &&
                !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                throw new aws_cdk_lib_1.ValidationError('InvalidOutputAction', `${prefix}: outputAction must be a valid GuardrailAction value`, this);
            }
            // Validate inputEnabled: must be a boolean (if provided)
            if (filter.inputEnabled !== undefined &&
                !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                typeof filter.inputEnabled !== 'boolean') {
                throw new aws_cdk_lib_1.ValidationError('InputEnabledNotBoolean', `${prefix}: inputEnabled must be a boolean value`, this);
            }
            // Validate outputEnabled: must be a boolean (if provided)
            if (filter.outputEnabled !== undefined &&
                !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                typeof filter.outputEnabled !== 'boolean') {
                throw new aws_cdk_lib_1.ValidationError('OutputEnabledNotBoolean', `${prefix}: outputEnabled must be a boolean value`, this);
            }
            // Apply default values for optional properties if not provided
            if (filter.inputAction === undefined) {
                filter.inputAction = filters.GuardrailAction.BLOCK;
            }
            if (filter.inputEnabled === undefined) {
                filter.inputEnabled = true;
            }
            if (filter.outputAction === undefined) {
                filter.outputAction = filters.GuardrailAction.BLOCK;
            }
            if (filter.outputEnabled === undefined) {
                filter.outputEnabled = true;
            }
        }
        /**
         * Validates a messaging property (blockedInputMessaging or blockedOutputsMessaging).
         * @param value The messaging value to validate.
         * @param propertyName The name of the property being validated.
         */
        validateMessagingProperty(value, propertyName) {
            if (value !== undefined && !aws_cdk_lib_1.Token.isUnresolved(value)) {
                if (value.length < 1) {
                    throw new aws_cdk_lib_1.ValidationError('MessagingPropertyTooShort', `Invalid ${propertyName}: The field ${propertyName} is ${value.length} characters long but must be at least 1 characters`, this);
                }
                if (value.length > 500) {
                    throw new aws_cdk_lib_1.ValidationError('MessagingPropertyTooLong', `Invalid ${propertyName}: The field ${propertyName} is ${value.length} characters long but must be less than or equal to 500 characters`, this);
                }
            }
        }
        /**
         * Validates that cross-region configuration is provided when STANDARD tier is used.
         * @param props The guardrail properties to validate.
         */
        validateTierConfiguration(props) {
            const contentTierConfig = props.contentFiltersTierConfig ?? filters.TierConfig.CLASSIC;
            const topicsTierConfig = props.topicsTierConfig ?? filters.TierConfig.CLASSIC;
            const hasCrossRegionConfig = props.crossRegionConfig !== undefined;
            // Check if STANDARD tier is used for content filters
            if (contentTierConfig === filters.TierConfig.STANDARD && !hasCrossRegionConfig) {
                throw new aws_cdk_lib_1.ValidationError('StandardTierRequiresCrossRegion', 'Cross-region configuration is required when using STANDARD tier for content filters. ' +
                    'Please provide a crossRegionConfig property with a valid guardrailProfileArn.', this);
            }
            // Check if STANDARD tier is used for topic filters
            if (topicsTierConfig === filters.TierConfig.STANDARD && !hasCrossRegionConfig) {
                throw new aws_cdk_lib_1.ValidationError('StandardTierRequiresCrossRegion', 'Cross-region configuration is required when using STANDARD tier for topic filters. ' +
                    'Please provide a crossRegionConfig property with a valid guardrailProfileArn.', this);
            }
        }
        /**
         * Validates content filters array and applies default values for optional properties.
         * @param contentFilters The content filters to validate.
         */
        validateContentFilters(contentFilters) {
            if (!contentFilters)
                return;
            contentFilters.forEach((filter, index) => {
                const prefix = `Invalid ContentFilter at index ${index}`;
                // Validate that the filter has required properties
                if (!filter.type) {
                    throw new aws_cdk_lib_1.ValidationError('ContentFilterTypeMissing', `${prefix}: type is required`, this);
                }
                // Validate input strength
                if (filter.inputStrength !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.inputStrength)) {
                    if (!Object.values(filters.ContentFilterStrength).includes(filter.inputStrength)) {
                        throw new aws_cdk_lib_1.ValidationError('InvalidInputStrength', `${prefix}: inputStrength must be a valid ContentFilterStrength value`, this);
                    }
                }
                // Validate output strength
                if (filter.outputStrength !== undefined && !aws_cdk_lib_1.Token.isUnresolved(filter.outputStrength)) {
                    if (!Object.values(filters.ContentFilterStrength).includes(filter.outputStrength)) {
                        throw new aws_cdk_lib_1.ValidationError('InvalidOutputStrength', `${prefix}: outputStrength must be a valid ContentFilterStrength value`, this);
                    }
                }
                // Validate input modalities
                if (filter.inputModalities) {
                    filter.inputModalities.forEach((modality, modalityIndex) => {
                        if (!Object.values(filters.ModalityType).includes(modality)) {
                            throw new aws_cdk_lib_1.ValidationError('InvalidInputModality', `${prefix}: inputModalities[${modalityIndex}] must be a valid ModalityType value`, this);
                        }
                    });
                }
                // Validate output modalities
                if (filter.outputModalities) {
                    filter.outputModalities.forEach((modality, modalityIndex) => {
                        if (!Object.values(filters.ModalityType).includes(modality)) {
                            throw new aws_cdk_lib_1.ValidationError('InvalidOutputModality', `${prefix}: outputModalities[${modalityIndex}] must be a valid ModalityType value`, this);
                        }
                    });
                }
                // Validate inputAction: must be a valid GuardrailAction value (if provided)
                if (filter.inputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidInputAction', `${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                // Validate outputAction: must be a valid GuardrailAction value (if provided)
                if (filter.outputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidOutputAction', `${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (filter.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                    typeof filter.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError('InputEnabledNotBoolean', `${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (filter.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                    typeof filter.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError('OutputEnabledNotBoolean', `${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.inputAction === undefined) {
                    filter.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.inputEnabled === undefined) {
                    filter.inputEnabled = true;
                }
                if (filter.outputAction === undefined) {
                    filter.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.outputEnabled === undefined) {
                    filter.outputEnabled = true;
                }
            });
        }
        /**
         * Validates PII filters array and applies default values for optional properties.
         * @param piiFilters The PII filters to validate.
         */
        validatePiiFilters(piiFilters) {
            if (!piiFilters)
                return;
            piiFilters.forEach((filter, index) => {
                const prefix = `Invalid PIIFilter at index ${index}`;
                // Validate that the filter has required properties
                if (!filter.type) {
                    throw new aws_cdk_lib_1.ValidationError('PiiFilterTypeMissing', `${prefix}: type is required`, this);
                }
                if (!filter.action) {
                    throw new aws_cdk_lib_1.ValidationError('PiiFilterActionMissing', `${prefix}: action is required`, this);
                }
                // Validate action values
                if (!aws_cdk_lib_1.Token.isUnresolved(filter.action) && !Object.values(filters.GuardrailAction).includes(filter.action)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidGuardrailAction', `${prefix}: action must be a valid GuardrailAction value`, this);
                }
                if (filter.inputAction &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidInputAction', `${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                if (filter.outputAction &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidOutputAction', `${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (filter.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                    typeof filter.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError('InputEnabledNotBoolean', `${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (filter.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                    typeof filter.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError('OutputEnabledNotBoolean', `${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.inputAction === undefined) {
                    filter.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.inputEnabled === undefined) {
                    filter.inputEnabled = true;
                }
                if (filter.outputAction === undefined) {
                    filter.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.outputEnabled === undefined) {
                    filter.outputEnabled = true;
                }
            });
        }
        /**
         * Validates regex filters array.
         * @param regexFilters The regex filters to validate.
         */
        validateRegexFilters(regexFilters) {
            if (!regexFilters)
                return;
            regexFilters.forEach((filter, index) => {
                this.validateRegexFilter(filter, index);
            });
        }
        /**
         * Validates denied topics array and applies default values for optional properties.
         * @param deniedTopics The denied topics to validate.
         */
        validateDeniedTopics(deniedTopics) {
            if (!deniedTopics)
                return;
            deniedTopics.forEach((topic, index) => {
                const prefix = `Invalid Topic at index ${index}`;
                // Validate that the topic has required properties
                if (!topic.name) {
                    throw new aws_cdk_lib_1.ValidationError('TopicNameMissing', `${prefix}: name is required`, this);
                }
                if (!topic.definition) {
                    throw new aws_cdk_lib_1.ValidationError('TopicDefinitionMissing', `${prefix}: definition is required`, this);
                }
                // Validate name length
                if (!aws_cdk_lib_1.Token.isUnresolved(topic.name) && topic.name.length > 100) {
                    throw new aws_cdk_lib_1.ValidationError('TopicNameTooLong', `${prefix}: name must be 100 characters or less`, this);
                }
                // Validate definition length
                if (!aws_cdk_lib_1.Token.isUnresolved(topic.definition) && topic.definition.length > 1000) {
                    throw new aws_cdk_lib_1.ValidationError('TopicDefinitionTooLong', `${prefix}: definition must be 1000 characters or less`, this);
                }
                // Validate examples if provided
                if (topic.examples) {
                    if (topic.examples.length > 100) {
                        throw new aws_cdk_lib_1.ValidationError('TopicExamplesTooMany', `${prefix}: examples array cannot contain more than 100 examples`, this);
                    }
                    topic.examples.forEach((example, exampleIndex) => {
                        if (!aws_cdk_lib_1.Token.isUnresolved(example) && example.length > 100) {
                            throw new aws_cdk_lib_1.ValidationError('TopicExampleTooLong', `${prefix}: examples[${exampleIndex}] must be 100 characters or less`, this);
                        }
                    });
                }
                // Validate inputAction: must be a valid GuardrailAction value (if provided)
                if (topic.inputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(topic.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(topic.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidInputAction', `${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                // Validate outputAction: must be a valid GuardrailAction value (if provided)
                if (topic.outputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(topic.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(topic.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidOutputAction', `${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (topic.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(topic.inputEnabled) &&
                    typeof topic.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError('InputEnabledNotBoolean', `${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (topic.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(topic.outputEnabled) &&
                    typeof topic.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError('OutputEnabledNotBoolean', `${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (topic.inputAction === undefined) {
                    topic.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (topic.inputEnabled === undefined) {
                    topic.inputEnabled = true;
                }
                if (topic.outputAction === undefined) {
                    topic.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (topic.outputEnabled === undefined) {
                    topic.outputEnabled = true;
                }
            });
        }
        /**
         * Validates contextual grounding filters array and applies default values for optional properties.
         * @param contextualGroundingFilters The contextual grounding filters to validate.
         */
        validateContextualGroundingFilters(contextualGroundingFilters) {
            if (!contextualGroundingFilters)
                return;
            contextualGroundingFilters.forEach((filter, index) => {
                const prefix = `Invalid ContextualGroundingFilter at index ${index}`;
                // Validate that the filter has required properties
                if (!filter.type) {
                    throw new aws_cdk_lib_1.ValidationError('ContextualGroundingFilterTypeMissing', `${prefix}: type is required`, this);
                }
                if (filter.threshold === undefined) {
                    throw new aws_cdk_lib_1.ValidationError('ContextualGroundingFilterThresholdMissing', `${prefix}: threshold is required`, this);
                }
                // Validate type
                if (!Object.values(filters.ContextualGroundingFilterType).includes(filter.type)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidContextualGroundingFilterType', `${prefix}: type must be a valid ContextualGroundingFilterType value`, this);
                }
                // Validate threshold range
                if (!aws_cdk_lib_1.Token.isUnresolved(filter.threshold)) {
                    if (filter.threshold < 0 || filter.threshold > 0.99) {
                        throw new aws_cdk_lib_1.ValidationError('ContextualGroundingFilterThresholdOutOfRange', `${prefix}: threshold must be between 0 and 0.99`, this);
                    }
                }
                // Validate action: must be a valid GuardrailAction value (if provided)
                if (filter.action !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.action) &&
                    !Object.values(filters.GuardrailAction).includes(filter.action)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidGuardrailAction', `${prefix}: action must be a valid GuardrailAction value`, this);
                }
                // Validate enabled: must be a boolean (if provided)
                if (filter.enabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.enabled) &&
                    typeof filter.enabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError('EnabledNotBoolean', `${prefix}: enabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.action === undefined) {
                    filter.action = filters.GuardrailAction.BLOCK;
                }
                if (filter.enabled === undefined) {
                    filter.enabled = true;
                }
            });
        }
        /**
         * Validates word filters array and applies default values for optional properties.
         * @param wordFilters The word filters to validate.
         */
        validateWordFilters(wordFilters) {
            if (!wordFilters)
                return;
            wordFilters.forEach((filter, index) => {
                const prefix = `Invalid WordFilter at index ${index}`;
                // Validate that the filter has required properties
                if (!filter.text) {
                    throw new aws_cdk_lib_1.ValidationError('WordFilterTextMissing', `${prefix}: text is required`, this);
                }
                // Validate text length
                if (!aws_cdk_lib_1.Token.isUnresolved(filter.text) && filter.text.length > 100) {
                    throw new aws_cdk_lib_1.ValidationError('WordFilterTextTooLong', `${prefix}: text must be 100 characters or less`, this);
                }
                // Validate inputAction: must be a valid GuardrailAction value (if provided)
                if (filter.inputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidInputAction', `${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                // Validate outputAction: must be a valid GuardrailAction value (if provided)
                if (filter.outputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidOutputAction', `${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (filter.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                    typeof filter.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError('InputEnabledNotBoolean', `${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (filter.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                    typeof filter.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError('OutputEnabledNotBoolean', `${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.inputAction === undefined) {
                    filter.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.inputEnabled === undefined) {
                    filter.inputEnabled = true;
                }
                if (filter.outputAction === undefined) {
                    filter.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.outputEnabled === undefined) {
                    filter.outputEnabled = true;
                }
            });
        }
        /**
         * Validates managed word list filters array and applies default values for optional properties.
         * @param managedWordListFilters The managed word list filters to validate.
         */
        validateManagedWordListFilters(managedWordListFilters) {
            if (!managedWordListFilters)
                return;
            managedWordListFilters.forEach((filter, index) => {
                const prefix = `Invalid ManagedWordFilter at index ${index}`;
                // Validate type: must be a valid ManagedWordFilterType value (if provided)
                if (filter.type !== undefined && !Object.values(filters.ManagedWordFilterType).includes(filter.type)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidManagedWordFilterType', `${prefix}: type must be a valid ManagedWordFilterType value`, this);
                }
                // Validate inputAction: must be a valid GuardrailAction value (if provided)
                if (filter.inputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.inputAction)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidInputAction', `${prefix}: inputAction must be a valid GuardrailAction value`, this);
                }
                // Validate outputAction: must be a valid GuardrailAction value (if provided)
                if (filter.outputAction !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputAction) &&
                    !Object.values(filters.GuardrailAction).includes(filter.outputAction)) {
                    throw new aws_cdk_lib_1.ValidationError('InvalidOutputAction', `${prefix}: outputAction must be a valid GuardrailAction value`, this);
                }
                // Validate inputEnabled: must be a boolean (if provided)
                if (filter.inputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.inputEnabled) &&
                    typeof filter.inputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError('InputEnabledNotBoolean', `${prefix}: inputEnabled must be a boolean value`, this);
                }
                // Validate outputEnabled: must be a boolean (if provided)
                if (filter.outputEnabled !== undefined &&
                    !aws_cdk_lib_1.Token.isUnresolved(filter.outputEnabled) &&
                    typeof filter.outputEnabled !== 'boolean') {
                    throw new aws_cdk_lib_1.ValidationError('OutputEnabledNotBoolean', `${prefix}: outputEnabled must be a boolean value`, this);
                }
                // Apply default values for optional properties if not provided
                if (filter.type === undefined) {
                    filter.type = filters.ManagedWordFilterType.PROFANITY;
                }
                if (filter.inputAction === undefined) {
                    filter.inputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.inputEnabled === undefined) {
                    filter.inputEnabled = true;
                }
                if (filter.outputAction === undefined) {
                    filter.outputAction = filters.GuardrailAction.BLOCK;
                }
                if (filter.outputEnabled === undefined) {
                    filter.outputEnabled = true;
                }
            });
        }
        /**
         * Validates a single content filter and applies default values for optional properties.
         * @param filter The content filter to validate.
         */
        validateSingleContentFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateContentFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single PII filter and applies default values for optional properties.
         * @param filter The PII filter to validate.
         */
        validateSinglePiiFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validatePiiFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single regex filter and applies default values for optional properties.
         * @param filter The regex filter to validate.
         */
        validateSingleRegexFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateRegexFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single denied topic and applies default values for optional properties.
         * @param filter The denied topic to validate.
         */
        validateSingleDeniedTopic(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateDeniedTopics([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single contextual grounding filter and applies default values for optional properties.
         * @param filter The contextual grounding filter to validate.
         */
        validateSingleContextualGroundingFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateContextualGroundingFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single word filter and applies default values for optional properties.
         * @param filter The word filter to validate.
         */
        validateSingleWordFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateWordFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        /**
         * Validates a single managed word list filter and applies default values for optional properties.
         * @param filter The managed word list filter to validate.
         */
        validateSingleManagedWordListFilter(filter) {
            // Use the existing validation logic but catch and re-throw with a clearer error message
            try {
                this.validateManagedWordListFilters([filter]);
            }
            catch (error) {
                if (error instanceof aws_cdk_lib_1.ValidationError) {
                    // Replace "at index 0" with a clearer message for single filter validation
                    const message = error.message.replace(' at index 0', '');
                    throw new aws_cdk_lib_1.ValidationError(error.name, message, this);
                }
                throw error;
            }
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return Guardrail = _classThis;
})();
exports.Guardrail = Guardrail;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3VhcmRyYWlscy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImd1YXJkcmFpbHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEseUJBQXlCO0FBRXpCLDZDQUFxRjtBQUNyRixtREFBbUQ7QUFFbkQsK0RBQW9EO0FBQ3BELDJDQUEyQztBQUUzQyxpREFBMEM7QUFDMUMsNEVBQWdFO0FBQ2hFLDhFQUE4RjtBQUM5RiwwRUFBMEU7QUFFMUUsZ0JBQWdCO0FBQ2hCLCtDQUErQztBQUMvQywyREFBdUQ7QUFpR3ZEOzs7R0FHRztBQUNILE1BQXNCLGFBQWMsU0FBUSxzQkFBUTs7SUFDbEQ7Ozs7O09BS0c7SUFDSSxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQWtCLEVBQUUsS0FBcUI7UUFDL0QsT0FBTyxJQUFJLHVCQUFNLENBQUM7WUFDaEIsU0FBUyxFQUFFLHdCQUF3QjtZQUNuQyxhQUFhLEVBQUUsRUFBRSxTQUFTLEVBQUUsZ0JBQWdCLEVBQUU7WUFDOUMsVUFBVTtZQUNWLEdBQUcsS0FBSztTQUNULENBQUMsQ0FBQztLQUNKO0lBRUQ7O09BRUc7SUFDSSxNQUFNLENBQUMsb0JBQW9CLENBQUMsS0FBcUI7UUFDdEQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztLQUM3QztJQUVEOztPQUVHO0lBQ0ksTUFBTSxDQUFDLHNCQUFzQixDQUFDLEtBQXFCO1FBQ3hELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDL0M7SUFFRDs7T0FFRztJQUNJLE1BQU0sQ0FBQyw4QkFBOEIsQ0FBQyxLQUFxQjtRQUNoRSxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDdkQ7SUFFRDs7T0FFRztJQUNJLE1BQU0sQ0FBQywwQkFBMEIsQ0FBQyxLQUFxQjtRQUM1RCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDbkQ7SUFFTyxRQUFRLEdBQVcsT0FBTyxDQUFDO0lBd0JuQzs7O09BR0c7SUFDSCxJQUFXLGdCQUFnQjtRQUN6QixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7S0FDdEI7SUFFUyxhQUFhLENBQUMsT0FBZTtRQUNyQyxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQztLQUN6QjtJQUVEOzs7T0FHRztJQUNJLEtBQUssQ0FBQyxPQUF1QixFQUFFLEdBQUcsT0FBaUI7UUFDeEQsT0FBTyxHQUFHLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQztZQUM5QixPQUFPO1lBQ1AsT0FBTztZQUNQLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7U0FDbEMsQ0FBQyxDQUFDO0tBQ0o7SUFFRDs7O09BR0c7SUFDSSxVQUFVLENBQUMsT0FBdUI7UUFDdkMsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztRQUVoRSxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNoQix5RUFBeUU7WUFDekUsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUMxRCxPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDckMsQ0FBQzthQUFNLENBQUM7WUFDTixtREFBbUQ7WUFDbkQsT0FBTyxTQUFTLENBQUM7UUFDbkIsQ0FBQztLQUNGO0lBRUQ7Ozs7O09BS0c7SUFDSSxNQUFNLENBQUMsVUFBa0IsRUFBRSxLQUFxQjtRQUNyRCxNQUFNLFdBQVcsR0FBZ0I7WUFDL0IsU0FBUyxFQUFFLHdCQUF3QjtZQUNuQyxVQUFVO1lBQ1YsYUFBYSxFQUFFLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZLEVBQUUsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQzNGLEdBQUcsS0FBSztTQUNULENBQUM7UUFDRixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLENBQUM7S0FDMUM7SUFFRDs7T0FFRztJQUNJLGlCQUFpQixDQUFDLEtBQXFCO1FBQzVDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDMUM7SUFFRDs7T0FFRztJQUNJLHVCQUF1QixDQUFDLEtBQXFCO1FBQ2xELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLENBQUMsQ0FBQztLQUNoRDtJQUVEOztPQUVHO0lBQ0ksNEJBQTRCLENBQUMsS0FBcUI7UUFDdkQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLHdCQUF3QixFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQ3JEO0lBRUQ7O09BRUc7SUFDSSw0QkFBNEIsQ0FBQyxLQUFxQjtRQUN2RCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsd0JBQXdCLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDckQ7SUFFRDs7T0FFRztJQUNJLHlCQUF5QixDQUFDLEtBQXFCO1FBQ3BELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsRUFBRSxLQUFLLENBQUMsQ0FBQztLQUNsRDtJQUVEOztPQUVHO0lBQ0ksbUJBQW1CLENBQUMsS0FBcUI7UUFDOUMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztLQUM1QztJQUVEOztPQUVHO0lBQ0ksMkJBQTJCLENBQUMsS0FBcUI7UUFDdEQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQ3BEO0lBRU8sZUFBZSxDQUFDLEtBQWtCO1FBQ3hDLE9BQU8sSUFBSSx1QkFBTSxDQUFDO1lBQ2hCLEdBQUcsS0FBSztZQUNSLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTTtZQUMxQyxPQUFPLEVBQUUsS0FBSyxFQUFFLE9BQU8sSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU87U0FDOUMsQ0FBQyxDQUFDO0tBQ0o7O0FBcExILHNDQXFMQztBQWdIRDs7K0VBRStFO0FBQy9FOzs7R0FHRztJQUVVLFNBQVM7NEJBRHJCLG9DQUFrQjs7OztzQkFDWSxhQUFhOzs7Ozs7Ozs7Ozt5QkFBckIsU0FBUSxXQUFhOzs7OzRDQXlOekMsSUFBQSxrQ0FBYyxHQUFFO3dDQVVoQixJQUFBLGtDQUFjLEdBQUU7MENBVWhCLElBQUEsa0NBQWMsR0FBRTtnREFVaEIsSUFBQSxrQ0FBYyxHQUFFO3dEQVVoQixJQUFBLGtDQUFjLEdBQUU7eUNBVWhCLElBQUEsa0NBQWMsR0FBRTtpREFVaEIsSUFBQSxrQ0FBYyxHQUFFO29EQWVoQixJQUFBLGtDQUFjLEdBQUU7eUNBV2hCLElBQUEsa0NBQWMsR0FBRTtZQXJGakIsbU1BQU8sZ0JBQWdCLDZEQUd0QjtZQU9ELHVMQUFPLFlBQVksNkRBR2xCO1lBT0QsNkxBQU8sY0FBYyw2REFHcEI7WUFPRCwrTUFBTyxvQkFBb0IsNkRBRzFCO1lBT0QsdU9BQU8sNEJBQTRCLDZEQUdsQztZQU9ELDBMQUFPLGFBQWEsNkRBR25CO1lBT0Qsa05BQU8scUJBQXFCLDZEQVEzQjtZQU9ELDJOQUFPLHdCQUF3Qiw2REFHOUI7WUFRRCwwTEFBTyxhQUFhLDZEQVFuQjtZQXhUSCw2S0FndUNDOzs7OztRQS90Q0Msc0NBQXNDO1FBQy9CLE1BQU0sQ0FBVSxxQkFBcUIsR0FBVyxzQ0FBc0MsQ0FBQztRQUU5Rjs7V0FFRztRQUNJLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQyxLQUFnQixFQUFFLEVBQVUsRUFBRSxLQUEwQjs7Ozs7Ozs7OztZQUM1RixNQUFNLE1BQU8sU0FBUSxhQUFhO2dCQUNoQixZQUFZLEdBQUcsS0FBSyxDQUFDLFlBQVksQ0FBQztnQkFDbEMsV0FBVyxHQUFHLGlCQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsdUJBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLFlBQWEsQ0FBQztnQkFDekYsTUFBTSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUM7Z0JBQ3RCLFdBQVcsR0FBRyxTQUFTLENBQUM7Z0JBRXhDO29CQUNFLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ2pCLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLGdCQUFnQixJQUFJLE9BQU8sQ0FBQyxDQUFDO2dCQUN4RCxDQUFDO2FBQ0Y7WUFFRCxPQUFPLElBQUksTUFBTSxFQUFFLENBQUM7U0FDckI7UUFFRDs7V0FFRztRQUNJLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFrQztZQUMvRCxPQUFPLElBQUksQ0FBQyxLQUFNLFNBQVEsYUFBYTtnQkFDckIsWUFBWSxHQUFHLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDN0MsV0FBVyxHQUFHLFlBQVksQ0FBQyxlQUFlLENBQUM7Z0JBQzNDLE1BQU0sR0FBRyxZQUFZLENBQUMsU0FBUztvQkFDN0MsQ0FBQyxDQUFDLGFBQUcsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLHNCQUFzQixFQUFFLFlBQVksQ0FBQyxTQUFTLENBQUM7b0JBQ3RFLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0JBQ0UsV0FBVyxHQUFHLFlBQVksQ0FBQyxhQUFhLENBQUM7Z0JBRXpEO29CQUNFLEtBQUssQ0FBQyxZQUFZLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztvQkFDekMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQy9DLENBQUM7YUFDRixDQUFDLEVBQUUsQ0FBQztTQUNOO1FBRUQ7OztXQUdHO1FBQ2EsWUFBWSxHQTlDakIsbURBQVMsQ0E4Q2lCO1FBQ3JDOzs7V0FHRztRQUNhLFdBQVcsQ0FBUztRQUNwQzs7V0FFRztRQUNhLElBQUksQ0FBUztRQUM3Qjs7OztXQUlHO1FBQ2EsTUFBTSxDQUFRO1FBQzlCOztXQUVHO1FBQ2EsY0FBYyxDQUEwQjtRQUN4RDs7V0FFRztRQUNhLFVBQVUsQ0FBc0I7UUFDaEQ7O1dBRUc7UUFDYSxZQUFZLENBQXdCO1FBQ3BEOztXQUVHO1FBQ2EsWUFBWSxDQUFrQjtRQUM5Qzs7V0FFRztRQUNhLDBCQUEwQixDQUFzQztRQUNoRjs7V0FFRztRQUNhLFdBQVcsQ0FBdUI7UUFDbEQ7O1dBRUc7UUFDYSxzQkFBc0IsQ0FBOEI7UUFDcEU7O1dBRUc7UUFDYSxXQUFXLENBQVU7UUFDckM7O1dBRUc7UUFDYSxJQUFJLENBQVM7UUFDN0I7O1dBRUc7UUFDYyxVQUFVLENBQXVCO1FBRWxEOzs7V0FHRztRQUNhLGdCQUFnQixDQUFxQjtRQUVyRDs7OztXQUlHO1FBQ2Esd0JBQXdCLENBQXFCO1FBQzdEOztXQUVHO1FBQ2EsaUJBQWlCLENBQXNDO1FBRXZFOzs7V0FHRztRQUNhLHFCQUFxQixDQUFTO1FBRTlDOzs7V0FHRztRQUNhLHVCQUF1QixDQUFTO1FBRWhELFlBQVksS0FBZ0IsRUFBRSxFQUFVLEVBQUUsS0FBcUI7WUFDN0QsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7Z0JBQ2YsWUFBWSxFQUFFLEtBQUssQ0FBQyxhQUFhO2FBQ2xDLENBQUMsQ0FBQzs7Ozs7O21EQXZJTSxTQUFTOzs7O1lBd0lsQixtQ0FBbUM7WUFDbkMsSUFBQSx3Q0FBb0IsRUFBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFbEMseURBQXlEO1lBQ3pELDZCQUE2QjtZQUM3Qix5REFBeUQ7WUFDekQsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1lBQzlCLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDLGNBQWMsSUFBSSxFQUFFLENBQUM7WUFDakQsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQztZQUN6QyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxZQUFZLElBQUksRUFBRSxDQUFDO1lBQzdDLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDLFlBQVksSUFBSSxFQUFFLENBQUM7WUFDN0MsSUFBSSxDQUFDLDBCQUEwQixHQUFHLEtBQUssQ0FBQywwQkFBMEIsSUFBSSxFQUFFLENBQUM7WUFDekUsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQztZQUMzQyxJQUFJLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDLHNCQUFzQixJQUFJLEVBQUUsQ0FBQztZQUNqRSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLGdCQUFnQixJQUFJLE9BQU8sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO1lBQzdFLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxLQUFLLENBQUMsd0JBQXdCLElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7WUFDN0YsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztZQUNqRCxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDLHFCQUFxQixJQUFJLDhDQUE4QyxDQUFDO1lBQzNHLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxLQUFLLENBQUMsdUJBQXVCLElBQUkseUVBQXlFLENBQUM7WUFFMUkseURBQXlEO1lBQ3pELDZCQUE2QjtZQUM3Qix5REFBeUQ7WUFDekQsSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUNqRCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3pDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDN0MsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUM3QyxJQUFJLENBQUMsa0NBQWtDLENBQUMsSUFBSSxDQUFDLDBCQUEwQixDQUFDLENBQUM7WUFDekUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUMzQyxJQUFJLENBQUMsOEJBQThCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLENBQUM7WUFFakUseURBQXlEO1lBQ3pELGdDQUFnQztZQUNoQyx5REFBeUQ7WUFDekQsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO1lBQ3BGLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUseUJBQXlCLENBQUMsQ0FBQztZQUV4Rix5REFBeUQ7WUFDekQsMkNBQTJDO1lBQzNDLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMseUJBQXlCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFdEMseURBQXlEO1lBQ3pELGdDQUFnQztZQUNoQyx5REFBeUQ7WUFDekQsSUFBSSxRQUFRLEdBQThCO2dCQUN4QyxJQUFJLEVBQUUsS0FBSyxDQUFDLGFBQWE7Z0JBQ3pCLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztnQkFDOUIsU0FBUyxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTTtnQkFDL0IscUJBQXFCLEVBQUUsSUFBSSxDQUFDLHFCQUFxQjtnQkFDakQsdUJBQXVCLEVBQUUsSUFBSSxDQUFDLHVCQUF1QjtnQkFDckQsYUFBYTtnQkFDYixpQkFBaUIsRUFBRSxJQUFJLENBQUMsNEJBQTRCLEVBQUU7Z0JBQ3RELG1CQUFtQixFQUFFLElBQUksQ0FBQyw4QkFBOEIsRUFBRTtnQkFDMUQsK0JBQStCLEVBQUUsSUFBSSxDQUFDLGlDQUFpQyxFQUFFO2dCQUN6RSxpQkFBaUIsRUFBRSxJQUFJLENBQUMsc0JBQXNCLEVBQUU7Z0JBQ2hELGdCQUFnQixFQUFFLElBQUksQ0FBQywyQkFBMkIsRUFBRTtnQkFDcEQsZ0NBQWdDLEVBQUUsSUFBSSxDQUFDLDJDQUEyQyxFQUFFO2FBQ3JGLENBQUM7WUFFRiwwREFBMEQ7WUFDMUQsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFBLDBCQUFPLEVBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBRTlDLHlEQUF5RDtZQUN6RCxtQkFBbUI7WUFDbkIseURBQXlEO1lBQ3pELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxhQUFhLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFFMUUsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQztZQUNuRCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLENBQUM7WUFDckQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ2hELElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUM7U0FDbEQ7UUFFRCx5REFBeUQ7UUFDekQsVUFBVTtRQUNWLHlEQUF5RDtRQUN6RDs7O1dBR0c7UUFFSSxnQkFBZ0IsQ0FBQyxNQUE2Qjs7Ozs7Ozs7OztZQUNuRCxJQUFJLENBQUMsMkJBQTJCLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDekMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDbEM7UUFFRDs7O1dBR0c7UUFFSSxZQUFZLENBQUMsTUFBeUI7Ozs7Ozs7Ozs7WUFDM0MsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3JDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQzlCO1FBRUQ7OztXQUdHO1FBRUksY0FBYyxDQUFDLE1BQTJCOzs7Ozs7Ozs7O1lBQy9DLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN2QyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNoQztRQUVEOzs7V0FHRztRQUVJLG9CQUFvQixDQUFDLE1BQXFCOzs7Ozs7Ozs7O1lBQy9DLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN2QyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNoQztRQUVEOzs7V0FHRztRQUVJLDRCQUE0QixDQUFDLE1BQXlDOzs7Ozs7Ozs7O1lBQzNFLElBQUksQ0FBQyx1Q0FBdUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNyRCxJQUFJLENBQUMsMEJBQTBCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQzlDO1FBRUQ7OztXQUdHO1FBRUksYUFBYSxDQUFDLE1BQTBCOzs7Ozs7Ozs7O1lBQzdDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN0QyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMvQjtRQUVEOzs7V0FHRztRQUVJLHFCQUFxQixDQUFDLFFBQWdCLEVBQzNDLFdBQXFDLEVBQ3JDLFlBQXNDLEVBQ3RDLFlBQXNCLEVBQ3RCLGFBQXVCOzs7Ozs7Ozs7OztZQUN2QixNQUFNLFlBQVksR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUN2RCxNQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzdDLEtBQUssTUFBTSxJQUFJLElBQUksS0FBSztnQkFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsQ0FBQyxDQUFDO1NBQ3RIO1FBRUQ7OztXQUdHO1FBRUksd0JBQXdCLENBQUMsTUFBaUM7Ozs7Ozs7Ozs7WUFDL0QsSUFBSSxDQUFDLG1DQUFtQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2pELElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDMUM7UUFFRDs7OztXQUlHO1FBRUksYUFBYSxDQUFDLFdBQW9CO1lBQ3ZDLE1BQU0sVUFBVSxHQUFHLElBQUksb0NBQWdCLENBQUMsSUFBSSxFQUFFLG9CQUFvQixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDMUYsV0FBVyxFQUFFLFdBQVc7Z0JBQ3hCLFNBQVMsRUFBRSxJQUFJO2FBQ2hCLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDaEQsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7U0FDOUI7UUFFRCx5REFBeUQ7UUFDekQsaUJBQWlCO1FBQ2pCLHlEQUF5RDtRQUN6RDs7O1dBR0c7UUFDSyw4QkFBOEI7WUFDcEMsT0FBTyxrQkFBSSxDQUFDLEdBQUcsQ0FBQztnQkFDZCxPQUFPLEVBQUUsR0FBRyxFQUFFO29CQUNaLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7d0JBQ25DLE1BQU0sbUJBQW1CLEdBQXFEOzRCQUM1RSxhQUFhLEVBQUUsSUFBSSxDQUFDLGNBQWM7NEJBQ2xDLEdBQUcsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLElBQUk7Z0NBQ25DLHdCQUF3QixFQUFFO29DQUN4QixRQUFRLEVBQUUsSUFBSSxDQUFDLHdCQUF3QjtpQ0FDaUI7NkJBQzNELENBQUM7eUJBQ0gsQ0FBQzt3QkFFRixPQUFPLG1CQUFtQixDQUFDO29CQUM3QixDQUFDO3lCQUFNLENBQUM7d0JBQ04sT0FBTyxTQUFTLENBQUM7b0JBQ25CLENBQUM7Z0JBQ0gsQ0FBQzthQUNGLENBQUMsQ0FBQztTQUNKO1FBRUQ7OztXQUdHO1FBQ0ssc0JBQXNCO1lBQzVCLE9BQU8sa0JBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQ2QsT0FBTyxFQUFFLEdBQUcsRUFBRTtvQkFDWixJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO3dCQUNqQyxNQUFNLGlCQUFpQixHQUFtRDs0QkFDeEUsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBb0IsRUFBRSxFQUFFO2dDQUMvRCxPQUFPO29DQUNMLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVTtvQ0FDNUIsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJO29DQUNoQixRQUFRLEVBQUUsS0FBSyxDQUFDLFFBQVE7b0NBQ3hCLElBQUksRUFBRSxNQUFNO29DQUNaLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztvQ0FDOUIsWUFBWSxFQUFFLEtBQUssQ0FBQyxZQUFZO29DQUNoQyxZQUFZLEVBQUUsS0FBSyxDQUFDLFlBQVk7b0NBQ2hDLGFBQWEsRUFBRSxLQUFLLENBQUMsYUFBYTtpQ0FDUyxDQUFDOzRCQUNoRCxDQUFDLENBQUM7NEJBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsSUFBSTtnQ0FDM0IsZ0JBQWdCLEVBQUU7b0NBQ2hCLFFBQVEsRUFBRSxJQUFJLENBQUMsZ0JBQWdCO2lDQUNpQjs2QkFDbkQsQ0FBQzt5QkFDSCxDQUFDO3dCQUVGLE9BQU8saUJBQWlCLENBQUM7b0JBQzNCLENBQUM7eUJBQU0sQ0FBQzt3QkFDTixPQUFPLFNBQVMsQ0FBQztvQkFDbkIsQ0FBQztnQkFDSCxDQUFDO2FBQ0YsQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7O1dBR0c7UUFDSyxpQ0FBaUM7WUFDdkMsT0FBTyxrQkFBSSxDQUFDLEdBQUcsQ0FBQztnQkFDZCxPQUFPLEVBQUUsR0FBRyxFQUFFO29CQUNaLElBQUksSUFBSSxDQUFDLDBCQUEwQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQzt3QkFDL0MsT0FBTzs0QkFDTCxhQUFhLEVBQUUsSUFBSSxDQUFDLDBCQUEwQixDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQXlDLEVBQUUsRUFBRTtnQ0FDbkcsT0FBTztvQ0FDTCxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7b0NBQ2pCLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztvQ0FDM0IsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO29DQUNyQixPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87aUNBQ3dDLENBQUM7NEJBQ3BFLENBQUMsQ0FBQzt5QkFDSCxDQUFDO29CQUNKLENBQUM7eUJBQU0sQ0FBQzt3QkFDTixPQUFPLFNBQVMsQ0FBQztvQkFDbkIsQ0FBQztnQkFDSCxDQUFDO2FBQ0YsQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7O1dBR0c7UUFDSywyQkFBMkI7WUFDakMsT0FBTyxrQkFBSSxDQUFDLEdBQUcsQ0FBQztnQkFDZCxPQUFPLEVBQUUsR0FBRyxFQUFFO29CQUNaLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7d0JBQzFFLE9BQU87NEJBQ0wsV0FBVyxFQUFFLElBQUksQ0FBQyxxQkFBcUIsRUFBRTs0QkFDekMsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLGlDQUFpQyxFQUFFO3lCQUNoQixDQUFDO29CQUNyRCxDQUFDO3lCQUFNLENBQUM7d0JBQ04sT0FBTyxTQUFTLENBQUM7b0JBQ25CLENBQUM7Z0JBQ0gsQ0FBQzthQUNGLENBQUMsQ0FBQztTQUNKO1FBRUQ7OztXQUdHO1FBQ0sscUJBQXFCO1lBQzNCLE9BQU8sa0JBQUksQ0FBQyxHQUFHLENBQ2I7Z0JBQ0UsT0FBTyxFQUFFLEdBQUcsRUFBRTtvQkFDWixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBd0IsRUFBRSxFQUFFO3dCQUMzRCxPQUFPOzRCQUNMLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTs0QkFDZixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVc7NEJBQzdCLFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWTs0QkFDL0IsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZOzRCQUMvQixhQUFhLEVBQUUsSUFBSSxDQUFDLGFBQWE7eUJBQ1MsQ0FBQztvQkFDL0MsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQzthQUNGLEVBQ0QsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLENBQ3pCLENBQUM7U0FDSDtRQUVEOzs7V0FHRztRQUNLLGlDQUFpQztZQUN2QyxPQUFPLGtCQUFJLENBQUMsR0FBRyxDQUNiO2dCQUNFLE9BQU8sRUFBRSxHQUFHLEVBQUU7b0JBQ1osT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBaUMsRUFBRSxFQUFFO3dCQUMvRSxPQUFPOzRCQUNMLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSTs0QkFDakIsV0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXOzRCQUMvQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7NEJBQ2pDLFlBQVksRUFBRSxNQUFNLENBQUMsWUFBWTs0QkFDakMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxhQUFhO3lCQUNlLENBQUM7b0JBQ3ZELENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7YUFDRixFQUNELEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxDQUN6QixDQUFDO1NBQ0g7UUFFRDs7O1dBR0c7UUFDSywyQ0FBMkM7WUFDakQsT0FBTyxrQkFBSSxDQUFDLEdBQUcsQ0FDYjtnQkFDRSxPQUFPLEVBQUUsR0FBRyxFQUFFO29CQUNaLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO3dCQUMvRCxPQUFPOzRCQUNMLGFBQWEsRUFBRSxJQUFJLENBQUMsd0JBQXdCLEVBQUU7NEJBQzlDLGlCQUFpQixFQUFFLElBQUksQ0FBQyw0QkFBNEIsRUFBRTt5QkFDdkQsQ0FBQztvQkFDSixDQUFDO3lCQUFNLENBQUM7d0JBQ04sT0FBTyxTQUFTLENBQUM7b0JBQ25CLENBQUM7Z0JBQ0gsQ0FBQzthQUNGLEVBQ0QsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLENBQ3pCLENBQUM7U0FDSDtRQUVEOzs7V0FHRztRQUNLLHdCQUF3QjtZQUM5QixPQUFPLGtCQUFJLENBQUMsR0FBRyxDQUNiO2dCQUNFLE9BQU8sRUFBRSxHQUFHLEVBQUU7b0JBQ1osT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQTBCLEVBQUUsRUFBRTt3QkFDOUQsT0FBTzs0QkFDTCxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7NEJBQ2hCLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVzs0QkFDOUIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPOzRCQUN0QixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU07NEJBQ3BCLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVzs0QkFDOUIsWUFBWSxFQUFFLEtBQUssQ0FBQyxZQUFZOzRCQUNoQyxZQUFZLEVBQUUsS0FBSyxDQUFDLFlBQVk7NEJBQ2hDLGFBQWEsRUFBRSxLQUFLLENBQUMsYUFBYTt5QkFDUyxDQUFDO29CQUNoRCxDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDO2FBQ0YsRUFDRCxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsQ0FDekIsQ0FBQztTQUNIO1FBRUQ7OztXQUdHO1FBQ0ssNEJBQTRCO1lBQ2xDLE9BQU8sa0JBQUksQ0FBQyxHQUFHLENBQ2I7Z0JBQ0UsT0FBTyxFQUFFLEdBQUcsRUFBRTtvQkFDWixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBeUIsRUFBRSxFQUFFO3dCQUMzRCxPQUFPOzRCQUNMLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUs7NEJBQ3ZCLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTTs0QkFDckIsV0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXOzRCQUMvQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7NEJBQ2pDLFlBQVksRUFBRSxNQUFNLENBQUMsWUFBWTs0QkFDakMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxhQUFhO3lCQUNZLENBQUM7b0JBQ3BELENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7YUFDRixFQUNELEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxDQUN6QixDQUFDO1NBQ0g7UUFFRDs7O1dBR0c7UUFDSyw0QkFBNEI7WUFDbEMsT0FBTyxrQkFBSSxDQUFDLEdBQUcsQ0FBQztnQkFDZCxPQUFPLEVBQUUsR0FBRyxFQUFFO29CQUNaLElBQUksSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7d0JBQzNCLE9BQU87NEJBQ0wsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLG1CQUFtQjt5QkFDTCxDQUFDO29CQUMvRCxDQUFDO3lCQUFNLENBQUM7d0JBQ04sT0FBTyxTQUFTLENBQUM7b0JBQ25CLENBQUM7Z0JBQ0gsQ0FBQzthQUNGLENBQUMsQ0FBQztTQUNKO1FBRUQ7Ozs7V0FJRztRQUNLLG1CQUFtQixDQUFDLE1BQTJCLEVBQUUsS0FBYztZQUNyRSxNQUFNLE1BQU0sR0FBRyxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxnQ0FBZ0MsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDO1lBRXJHLDhDQUE4QztZQUM5QyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQ2xFLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQzNCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHlCQUF5QixFQUFFLEdBQUcsTUFBTSx1QkFBdUIsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLG9EQUFvRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNySyxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7b0JBQzdCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHdCQUF3QixFQUFFLEdBQUcsTUFBTSx1QkFBdUIsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLG1FQUFtRSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNuTCxDQUFDO1lBQ0gsQ0FBQztZQUVELG9FQUFvRTtZQUNwRSxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7Z0JBQ2hGLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQ2xDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLGdDQUFnQyxFQUFFLEdBQUcsTUFBTSw4QkFBOEIsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLG9EQUFvRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMxTCxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxFQUFFLENBQUM7b0JBQ3JDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLCtCQUErQixFQUFFLEdBQUcsTUFBTSw4QkFBOEIsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLG9FQUFvRSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN6TSxDQUFDO1lBQ0gsQ0FBQztZQUVELDJDQUEyQztZQUMzQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7Z0JBQ3hFLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQzlCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHlCQUF5QixFQUFFLEdBQUcsTUFBTSwwQkFBMEIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLG9EQUFvRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMzSyxDQUFDO1lBQ0gsQ0FBQztZQUVELHlEQUF5RDtZQUN6RCxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO2dCQUN6SSxNQUFNLElBQUksNkJBQWUsQ0FBQyx3QkFBd0IsRUFBRSxHQUFHLE1BQU0sZ0RBQWdELEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDdkgsQ0FBQztZQUVELDRFQUE0RTtZQUM1RSxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUztnQkFDaEMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO2dCQUN2QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztnQkFDekUsTUFBTSxJQUFJLDZCQUFlLENBQUMsb0JBQW9CLEVBQUUsR0FBRyxNQUFNLHFEQUFxRCxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3hILENBQUM7WUFFRCw2RUFBNkU7WUFDN0UsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVM7Z0JBQ2pDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztnQkFDeEMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7Z0JBQzFFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHFCQUFxQixFQUFFLEdBQUcsTUFBTSxzREFBc0QsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUMxSCxDQUFDO1lBRUQseURBQXlEO1lBQ3pELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTO2dCQUNqQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7Z0JBQ3hDLE9BQU8sTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDN0MsTUFBTSxJQUFJLDZCQUFlLENBQUMsd0JBQXdCLEVBQUUsR0FBRyxNQUFNLHdDQUF3QyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQy9HLENBQUM7WUFFRCwwREFBMEQ7WUFDMUQsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVM7Z0JBQ2xDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztnQkFDekMsT0FBTyxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO2dCQUM5QyxNQUFNLElBQUksNkJBQWUsQ0FBQyx5QkFBeUIsRUFBRSxHQUFHLE1BQU0seUNBQXlDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDakgsQ0FBQztZQUVELCtEQUErRDtZQUMvRCxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUyxFQUFFLENBQUM7Z0JBQ3BDLE1BQWMsQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7WUFDOUQsQ0FBQztZQUNELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDckMsTUFBYyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDdEMsQ0FBQztZQUNELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDckMsTUFBYyxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztZQUMvRCxDQUFDO1lBQ0QsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO2dCQUN0QyxNQUFjLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztZQUN2QyxDQUFDO1NBQ0Y7UUFFRDs7OztXQUlHO1FBQ0sseUJBQXlCLENBQUMsS0FBeUIsRUFBRSxZQUFvQjtZQUMvRSxJQUFJLEtBQUssS0FBSyxTQUFTLElBQUksQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN0RCxJQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQ3JCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLDJCQUEyQixFQUFFLFdBQVcsWUFBWSxlQUFlLFlBQVksT0FBTyxLQUFLLENBQUMsTUFBTSxvREFBb0QsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDMUwsQ0FBQztnQkFDRCxJQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7b0JBQ3ZCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLDBCQUEwQixFQUFFLFdBQVcsWUFBWSxlQUFlLFlBQVksT0FBTyxLQUFLLENBQUMsTUFBTSxtRUFBbUUsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDeE0sQ0FBQztZQUNILENBQUM7U0FDRjtRQUVEOzs7V0FHRztRQUNLLHlCQUF5QixDQUFDLEtBQXFCO1lBQ3JELE1BQU0saUJBQWlCLEdBQUcsS0FBSyxDQUFDLHdCQUF3QixJQUFJLE9BQU8sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO1lBQ3ZGLE1BQU0sZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLGdCQUFnQixJQUFJLE9BQU8sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO1lBQzlFLE1BQU0sb0JBQW9CLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixLQUFLLFNBQVMsQ0FBQztZQUVuRSxxREFBcUQ7WUFDckQsSUFBSSxpQkFBaUIsS0FBSyxPQUFPLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7Z0JBQy9FLE1BQU0sSUFBSSw2QkFBZSxDQUN2QixpQ0FBaUMsRUFDakMsdUZBQXVGO29CQUN2RiwrRUFBK0UsRUFDL0UsSUFBSSxDQUNMLENBQUM7WUFDSixDQUFDO1lBRUQsbURBQW1EO1lBQ25ELElBQUksZ0JBQWdCLEtBQUssT0FBTyxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2dCQUM5RSxNQUFNLElBQUksNkJBQWUsQ0FDdkIsaUNBQWlDLEVBQ2pDLHFGQUFxRjtvQkFDckYsK0VBQStFLEVBQy9FLElBQUksQ0FDTCxDQUFDO1lBQ0osQ0FBQztTQUNGO1FBRUQ7OztXQUdHO1FBQ0ssc0JBQXNCLENBQUMsY0FBd0M7WUFDckUsSUFBSSxDQUFDLGNBQWM7Z0JBQUUsT0FBTztZQUU1QixjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFO2dCQUN2QyxNQUFNLE1BQU0sR0FBRyxrQ0FBa0MsS0FBSyxFQUFFLENBQUM7Z0JBRXpELG1EQUFtRDtnQkFDbkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDakIsTUFBTSxJQUFJLDZCQUFlLENBQUMsMEJBQTBCLEVBQUUsR0FBRyxNQUFNLG9CQUFvQixFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUM3RixDQUFDO2dCQUVELDBCQUEwQjtnQkFDMUIsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsSUFBSSxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDO29CQUNwRixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUM7d0JBQ2pGLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHNCQUFzQixFQUFFLEdBQUcsTUFBTSw2REFBNkQsRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDbEksQ0FBQztnQkFDSCxDQUFDO2dCQUVELDJCQUEyQjtnQkFDM0IsSUFBSSxNQUFNLENBQUMsY0FBYyxLQUFLLFNBQVMsSUFBSSxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDO29CQUN0RixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUM7d0JBQ2xGLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHVCQUF1QixFQUFFLEdBQUcsTUFBTSw4REFBOEQsRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDcEksQ0FBQztnQkFDSCxDQUFDO2dCQUVELDRCQUE0QjtnQkFDNUIsSUFBSSxNQUFNLENBQUMsZUFBZSxFQUFFLENBQUM7b0JBQzNCLE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxFQUFFLGFBQWEsRUFBRSxFQUFFO3dCQUN6RCxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7NEJBQzVELE1BQU0sSUFBSSw2QkFBZSxDQUFDLHNCQUFzQixFQUFFLEdBQUcsTUFBTSxxQkFBcUIsYUFBYSxzQ0FBc0MsRUFBRSxJQUFJLENBQUMsQ0FBQzt3QkFDN0ksQ0FBQztvQkFDSCxDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDO2dCQUVELDZCQUE2QjtnQkFDN0IsSUFBSSxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztvQkFDNUIsTUFBTSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsRUFBRSxhQUFhLEVBQUUsRUFBRTt3QkFDMUQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDOzRCQUM1RCxNQUFNLElBQUksNkJBQWUsQ0FBQyx1QkFBdUIsRUFBRSxHQUFHLE1BQU0sc0JBQXNCLGFBQWEsc0NBQXNDLEVBQUUsSUFBSSxDQUFDLENBQUM7d0JBQy9JLENBQUM7b0JBQ0gsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQztnQkFFRCw0RUFBNEU7Z0JBQzVFLElBQUksTUFBTSxDQUFDLFdBQVcsS0FBSyxTQUFTO29CQUNoQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUM7b0JBQ3ZDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDO29CQUN6RSxNQUFNLElBQUksNkJBQWUsQ0FBQyxvQkFBb0IsRUFBRSxHQUFHLE1BQU0scURBQXFELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3hILENBQUM7Z0JBRUQsNkVBQTZFO2dCQUM3RSxJQUFJLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUztvQkFDakMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDO29CQUN4QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztvQkFDMUUsTUFBTSxJQUFJLDZCQUFlLENBQUMscUJBQXFCLEVBQUUsR0FBRyxNQUFNLHNEQUFzRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMxSCxDQUFDO2dCQUVELHlEQUF5RDtnQkFDekQsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVM7b0JBQ2pDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztvQkFDeEMsT0FBTyxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM3QyxNQUFNLElBQUksNkJBQWUsQ0FBQyx3QkFBd0IsRUFBRSxHQUFHLE1BQU0sd0NBQXdDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQy9HLENBQUM7Z0JBRUQsMERBQTBEO2dCQUMxRCxJQUFJLE1BQU0sQ0FBQyxhQUFhLEtBQUssU0FBUztvQkFDbEMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDO29CQUN6QyxPQUFPLE1BQU0sQ0FBQyxhQUFhLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQzlDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHlCQUF5QixFQUFFLEdBQUcsTUFBTSx5Q0FBeUMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDakgsQ0FBQztnQkFFRCwrREFBK0Q7Z0JBQy9ELElBQUksTUFBTSxDQUFDLFdBQVcsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDcEMsTUFBYyxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztnQkFDOUQsQ0FBQztnQkFDRCxJQUFJLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3JDLE1BQWMsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO2dCQUN0QyxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDckMsTUFBYyxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztnQkFDL0QsQ0FBQztnQkFDRCxJQUFJLE1BQU0sQ0FBQyxhQUFhLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3RDLE1BQWMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO2dCQUN2QyxDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUVEOzs7V0FHRztRQUNLLGtCQUFrQixDQUFDLFVBQWdDO1lBQ3pELElBQUksQ0FBQyxVQUFVO2dCQUFFLE9BQU87WUFFeEIsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDbkMsTUFBTSxNQUFNLEdBQUcsOEJBQThCLEtBQUssRUFBRSxDQUFDO2dCQUVyRCxtREFBbUQ7Z0JBQ25ELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2pCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHNCQUFzQixFQUFFLEdBQUcsTUFBTSxvQkFBb0IsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDekYsQ0FBQztnQkFFRCxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO29CQUNuQixNQUFNLElBQUksNkJBQWUsQ0FBQyx3QkFBd0IsRUFBRSxHQUFHLE1BQU0sc0JBQXNCLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzdGLENBQUM7Z0JBRUQseUJBQXlCO2dCQUN6QixJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO29CQUMxRyxNQUFNLElBQUksNkJBQWUsQ0FBQyx3QkFBd0IsRUFBRSxHQUFHLE1BQU0sZ0RBQWdELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3ZILENBQUM7Z0JBRUQsSUFBSSxNQUFNLENBQUMsV0FBVztvQkFDbEIsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO29CQUN2QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztvQkFDekUsTUFBTSxJQUFJLDZCQUFlLENBQUMsb0JBQW9CLEVBQUUsR0FBRyxNQUFNLHFEQUFxRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN4SCxDQUFDO2dCQUVELElBQUksTUFBTSxDQUFDLFlBQVk7b0JBQ25CLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztvQkFDeEMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7b0JBQzFFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHFCQUFxQixFQUFFLEdBQUcsTUFBTSxzREFBc0QsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDMUgsQ0FBQztnQkFFRCx5REFBeUQ7Z0JBQ3pELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTO29CQUNqQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7b0JBQ3hDLE9BQU8sTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDN0MsTUFBTSxJQUFJLDZCQUFlLENBQUMsd0JBQXdCLEVBQUUsR0FBRyxNQUFNLHdDQUF3QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMvRyxDQUFDO2dCQUVELDBEQUEwRDtnQkFDMUQsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVM7b0JBQ2xDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztvQkFDekMsT0FBTyxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM5QyxNQUFNLElBQUksNkJBQWUsQ0FBQyx5QkFBeUIsRUFBRSxHQUFHLE1BQU0seUNBQXlDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2pILENBQUM7Z0JBRUQsK0RBQStEO2dCQUMvRCxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3BDLE1BQWMsQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7Z0JBQzlELENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNyQyxNQUFjLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztnQkFDdEMsQ0FBQztnQkFDRCxJQUFJLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3JDLE1BQWMsQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7Z0JBQy9ELENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUN0QyxNQUFjLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztnQkFDdkMsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7O1dBR0c7UUFDSyxvQkFBb0IsQ0FBQyxZQUFvQztZQUMvRCxJQUFJLENBQUMsWUFBWTtnQkFBRSxPQUFPO1lBRTFCLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUU7Z0JBQ3JDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDMUMsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUVEOzs7V0FHRztRQUNLLG9CQUFvQixDQUFDLFlBQThCO1lBQ3pELElBQUksQ0FBQyxZQUFZO2dCQUFFLE9BQU87WUFFMUIsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDcEMsTUFBTSxNQUFNLEdBQUcsMEJBQTBCLEtBQUssRUFBRSxDQUFDO2dCQUVqRCxrREFBa0Q7Z0JBQ2xELElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2hCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLGtCQUFrQixFQUFFLEdBQUcsTUFBTSxvQkFBb0IsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDckYsQ0FBQztnQkFFRCxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO29CQUN0QixNQUFNLElBQUksNkJBQWUsQ0FBQyx3QkFBd0IsRUFBRSxHQUFHLE1BQU0sMEJBQTBCLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2pHLENBQUM7Z0JBRUQsdUJBQXVCO2dCQUN2QixJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDO29CQUMvRCxNQUFNLElBQUksNkJBQWUsQ0FBQyxrQkFBa0IsRUFBRSxHQUFHLE1BQU0sdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3hHLENBQUM7Z0JBRUQsNkJBQTZCO2dCQUM3QixJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLElBQUksRUFBRSxDQUFDO29CQUM1RSxNQUFNLElBQUksNkJBQWUsQ0FBQyx3QkFBd0IsRUFBRSxHQUFHLE1BQU0sOENBQThDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3JILENBQUM7Z0JBRUQsZ0NBQWdDO2dCQUNoQyxJQUFJLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztvQkFDbkIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQzt3QkFDaEMsTUFBTSxJQUFJLDZCQUFlLENBQUMsc0JBQXNCLEVBQUUsR0FBRyxNQUFNLHdEQUF3RCxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUM3SCxDQUFDO29CQUVELEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBRSxFQUFFO3dCQUMvQyxJQUFJLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksT0FBTyxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQzs0QkFDekQsTUFBTSxJQUFJLDZCQUFlLENBQUMscUJBQXFCLEVBQUUsR0FBRyxNQUFNLGNBQWMsWUFBWSxrQ0FBa0MsRUFBRSxJQUFJLENBQUMsQ0FBQzt3QkFDaEksQ0FBQztvQkFDSCxDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDO2dCQUVELDRFQUE0RTtnQkFDNUUsSUFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLFNBQVM7b0JBQy9CLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQztvQkFDdEMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7b0JBQ3hFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLG9CQUFvQixFQUFFLEdBQUcsTUFBTSxxREFBcUQsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDeEgsQ0FBQztnQkFFRCw2RUFBNkU7Z0JBQzdFLElBQUksS0FBSyxDQUFDLFlBQVksS0FBSyxTQUFTO29CQUNoQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUM7b0JBQ3ZDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO29CQUN6RSxNQUFNLElBQUksNkJBQWUsQ0FBQyxxQkFBcUIsRUFBRSxHQUFHLE1BQU0sc0RBQXNELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzFILENBQUM7Z0JBRUQseURBQXlEO2dCQUN6RCxJQUFJLEtBQUssQ0FBQyxZQUFZLEtBQUssU0FBUztvQkFDaEMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDO29CQUN2QyxPQUFPLEtBQUssQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQzVDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHdCQUF3QixFQUFFLEdBQUcsTUFBTSx3Q0FBd0MsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDL0csQ0FBQztnQkFFRCwwREFBMEQ7Z0JBQzFELElBQUksS0FBSyxDQUFDLGFBQWEsS0FBSyxTQUFTO29CQUNqQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUM7b0JBQ3hDLE9BQU8sS0FBSyxDQUFDLGFBQWEsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDN0MsTUFBTSxJQUFJLDZCQUFlLENBQUMseUJBQXlCLEVBQUUsR0FBRyxNQUFNLHlDQUF5QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNqSCxDQUFDO2dCQUVELCtEQUErRDtnQkFDL0QsSUFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNuQyxLQUFhLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO2dCQUM3RCxDQUFDO2dCQUNELElBQUksS0FBSyxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDcEMsS0FBYSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7Z0JBQ3JDLENBQUM7Z0JBQ0QsSUFBSSxLQUFLLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNwQyxLQUFhLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO2dCQUM5RCxDQUFDO2dCQUNELElBQUksS0FBSyxDQUFDLGFBQWEsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDckMsS0FBYSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQ3RDLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztTQUNKO1FBRUQ7OztXQUdHO1FBQ0ssa0NBQWtDLENBQUMsMEJBQWdFO1lBQ3pHLElBQUksQ0FBQywwQkFBMEI7Z0JBQUUsT0FBTztZQUV4QywwQkFBMEIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUU7Z0JBQ25ELE1BQU0sTUFBTSxHQUFHLDhDQUE4QyxLQUFLLEVBQUUsQ0FBQztnQkFFckUsbURBQW1EO2dCQUNuRCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO29CQUNqQixNQUFNLElBQUksNkJBQWUsQ0FBQyxzQ0FBc0MsRUFBRSxHQUFHLE1BQU0sb0JBQW9CLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3pHLENBQUM7Z0JBRUQsSUFBSSxNQUFNLENBQUMsU0FBUyxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNuQyxNQUFNLElBQUksNkJBQWUsQ0FBQywyQ0FBMkMsRUFBRSxHQUFHLE1BQU0seUJBQXlCLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ25ILENBQUM7Z0JBRUQsZ0JBQWdCO2dCQUNoQixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsNkJBQTZCLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7b0JBQ2hGLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHNDQUFzQyxFQUFFLEdBQUcsTUFBTSw0REFBNEQsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDakosQ0FBQztnQkFFRCwyQkFBMkI7Z0JBQzNCLElBQUksQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztvQkFDMUMsSUFBSSxNQUFNLENBQUMsU0FBUyxHQUFHLENBQUMsSUFBSSxNQUFNLENBQUMsU0FBUyxHQUFHLElBQUksRUFBRSxDQUFDO3dCQUNwRCxNQUFNLElBQUksNkJBQWUsQ0FBQyw4Q0FBOEMsRUFBRSxHQUFHLE1BQU0sd0NBQXdDLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQ3JJLENBQUM7Z0JBQ0gsQ0FBQztnQkFFRCx1RUFBdUU7Z0JBQ3ZFLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxTQUFTO29CQUMzQixDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7b0JBQ2xDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO29CQUNwRSxNQUFNLElBQUksNkJBQWUsQ0FBQyx3QkFBd0IsRUFBRSxHQUFHLE1BQU0sZ0RBQWdELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3ZILENBQUM7Z0JBRUQsb0RBQW9EO2dCQUNwRCxJQUFJLE1BQU0sQ0FBQyxPQUFPLEtBQUssU0FBUztvQkFDNUIsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO29CQUNuQyxPQUFPLE1BQU0sQ0FBQyxPQUFPLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3hDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLG1CQUFtQixFQUFFLEdBQUcsTUFBTSxtQ0FBbUMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDckcsQ0FBQztnQkFFRCwrREFBK0Q7Z0JBQy9ELElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDL0IsTUFBYyxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztnQkFDekQsQ0FBQztnQkFDRCxJQUFJLE1BQU0sQ0FBQyxPQUFPLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ2hDLE1BQWMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO2dCQUNqQyxDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUVEOzs7V0FHRztRQUNLLG1CQUFtQixDQUFDLFdBQWtDO1lBQzVELElBQUksQ0FBQyxXQUFXO2dCQUFFLE9BQU87WUFFekIsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDcEMsTUFBTSxNQUFNLEdBQUcsK0JBQStCLEtBQUssRUFBRSxDQUFDO2dCQUV0RCxtREFBbUQ7Z0JBQ25ELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2pCLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHVCQUF1QixFQUFFLEdBQUcsTUFBTSxvQkFBb0IsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDMUYsQ0FBQztnQkFFRCx1QkFBdUI7Z0JBQ3ZCLElBQUksQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7b0JBQ2pFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHVCQUF1QixFQUFFLEdBQUcsTUFBTSx1Q0FBdUMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDN0csQ0FBQztnQkFFRCw0RUFBNEU7Z0JBQzVFLElBQUksTUFBTSxDQUFDLFdBQVcsS0FBSyxTQUFTO29CQUNoQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUM7b0JBQ3ZDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDO29CQUN6RSxNQUFNLElBQUksNkJBQWUsQ0FBQyxvQkFBb0IsRUFBRSxHQUFHLE1BQU0scURBQXFELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3hILENBQUM7Z0JBRUQsNkVBQTZFO2dCQUM3RSxJQUFJLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUztvQkFDakMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDO29CQUN4QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztvQkFDMUUsTUFBTSxJQUFJLDZCQUFlLENBQUMscUJBQXFCLEVBQUUsR0FBRyxNQUFNLHNEQUFzRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMxSCxDQUFDO2dCQUVELHlEQUF5RDtnQkFDekQsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVM7b0JBQ2pDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztvQkFDeEMsT0FBTyxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM3QyxNQUFNLElBQUksNkJBQWUsQ0FBQyx3QkFBd0IsRUFBRSxHQUFHLE1BQU0sd0NBQXdDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQy9HLENBQUM7Z0JBRUQsMERBQTBEO2dCQUMxRCxJQUFJLE1BQU0sQ0FBQyxhQUFhLEtBQUssU0FBUztvQkFDbEMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDO29CQUN6QyxPQUFPLE1BQU0sQ0FBQyxhQUFhLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQzlDLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHlCQUF5QixFQUFFLEdBQUcsTUFBTSx5Q0FBeUMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDakgsQ0FBQztnQkFFRCwrREFBK0Q7Z0JBQy9ELElBQUksTUFBTSxDQUFDLFdBQVcsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDcEMsTUFBYyxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztnQkFDOUQsQ0FBQztnQkFDRCxJQUFJLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3JDLE1BQWMsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO2dCQUN0QyxDQUFDO2dCQUNELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDckMsTUFBYyxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztnQkFDL0QsQ0FBQztnQkFDRCxJQUFJLE1BQU0sQ0FBQyxhQUFhLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3RDLE1BQWMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO2dCQUN2QyxDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7U0FDSjtRQUVEOzs7V0FHRztRQUNLLDhCQUE4QixDQUFDLHNCQUFvRDtZQUN6RixJQUFJLENBQUMsc0JBQXNCO2dCQUFFLE9BQU87WUFFcEMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFO2dCQUMvQyxNQUFNLE1BQU0sR0FBRyxzQ0FBc0MsS0FBSyxFQUFFLENBQUM7Z0JBRTdELDJFQUEyRTtnQkFDM0UsSUFBSSxNQUFNLENBQUMsSUFBSSxLQUFLLFNBQVMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO29CQUNyRyxNQUFNLElBQUksNkJBQWUsQ0FBQyw4QkFBOEIsRUFBRSxHQUFHLE1BQU0sb0RBQW9ELEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2pJLENBQUM7Z0JBRUQsNEVBQTRFO2dCQUM1RSxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUztvQkFDaEMsQ0FBQyxtQkFBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO29CQUN2QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztvQkFDekUsTUFBTSxJQUFJLDZCQUFlLENBQUMsb0JBQW9CLEVBQUUsR0FBRyxNQUFNLHFEQUFxRCxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUN4SCxDQUFDO2dCQUVELDZFQUE2RTtnQkFDN0UsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVM7b0JBQ2pDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztvQkFDeEMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUM7b0JBQzFFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHFCQUFxQixFQUFFLEdBQUcsTUFBTSxzREFBc0QsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDMUgsQ0FBQztnQkFFRCx5REFBeUQ7Z0JBQ3pELElBQUksTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTO29CQUNqQyxDQUFDLG1CQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7b0JBQ3hDLE9BQU8sTUFBTSxDQUFDLFlBQVksS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDN0MsTUFBTSxJQUFJLDZCQUFlLENBQUMsd0JBQXdCLEVBQUUsR0FBRyxNQUFNLHdDQUF3QyxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMvRyxDQUFDO2dCQUVELDBEQUEwRDtnQkFDMUQsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVM7b0JBQ2xDLENBQUMsbUJBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztvQkFDekMsT0FBTyxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUM5QyxNQUFNLElBQUksNkJBQWUsQ0FBQyx5QkFBeUIsRUFBRSxHQUFHLE1BQU0seUNBQXlDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2pILENBQUM7Z0JBRUQsK0RBQStEO2dCQUMvRCxJQUFJLE1BQU0sQ0FBQyxJQUFJLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQzdCLE1BQWMsQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLHFCQUFxQixDQUFDLFNBQVMsQ0FBQztnQkFDakUsQ0FBQztnQkFDRCxJQUFJLE1BQU0sQ0FBQyxXQUFXLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3BDLE1BQWMsQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7Z0JBQzlELENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUNyQyxNQUFjLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztnQkFDdEMsQ0FBQztnQkFDRCxJQUFJLE1BQU0sQ0FBQyxZQUFZLEtBQUssU0FBUyxFQUFFLENBQUM7b0JBQ3JDLE1BQWMsQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7Z0JBQy9ELENBQUM7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRSxDQUFDO29CQUN0QyxNQUFjLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztnQkFDdkMsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDO1NBQ0o7UUFFRDs7O1dBR0c7UUFDSywyQkFBMkIsQ0FBQyxNQUE2QjtZQUMvRCx3RkFBd0Y7WUFDeEYsSUFBSSxDQUFDO2dCQUNILElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDeEMsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxLQUFLLFlBQVksNkJBQWUsRUFBRSxDQUFDO29CQUNyQywyRUFBMkU7b0JBQzNFLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDekQsTUFBTSxJQUFJLDZCQUFlLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3ZELENBQUM7Z0JBQ0QsTUFBTSxLQUFLLENBQUM7WUFDZCxDQUFDO1NBQ0Y7UUFFRDs7O1dBR0c7UUFDSyx1QkFBdUIsQ0FBQyxNQUF5QjtZQUN2RCx3RkFBd0Y7WUFDeEYsSUFBSSxDQUFDO2dCQUNILElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDcEMsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxLQUFLLFlBQVksNkJBQWUsRUFBRSxDQUFDO29CQUNyQywyRUFBMkU7b0JBQzNFLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDekQsTUFBTSxJQUFJLDZCQUFlLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3ZELENBQUM7Z0JBQ0QsTUFBTSxLQUFLLENBQUM7WUFDZCxDQUFDO1NBQ0Y7UUFFRDs7O1dBR0c7UUFDSyx5QkFBeUIsQ0FBQyxNQUEyQjtZQUMzRCx3RkFBd0Y7WUFDeEYsSUFBSSxDQUFDO2dCQUNILElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDdEMsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxLQUFLLFlBQVksNkJBQWUsRUFBRSxDQUFDO29CQUNyQywyRUFBMkU7b0JBQzNFLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDekQsTUFBTSxJQUFJLDZCQUFlLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3ZELENBQUM7Z0JBQ0QsTUFBTSxLQUFLLENBQUM7WUFDZCxDQUFDO1NBQ0Y7UUFFRDs7O1dBR0c7UUFDSyx5QkFBeUIsQ0FBQyxNQUFxQjtZQUNyRCx3RkFBd0Y7WUFDeEYsSUFBSSxDQUFDO2dCQUNILElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDdEMsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxLQUFLLFlBQVksNkJBQWUsRUFBRSxDQUFDO29CQUNyQywyRUFBMkU7b0JBQzNFLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDekQsTUFBTSxJQUFJLDZCQUFlLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3ZELENBQUM7Z0JBQ0QsTUFBTSxLQUFLLENBQUM7WUFDZCxDQUFDO1NBQ0Y7UUFFRDs7O1dBR0c7UUFDSyx1Q0FBdUMsQ0FBQyxNQUF5QztZQUN2Rix3RkFBd0Y7WUFDeEYsSUFBSSxDQUFDO2dCQUNILElBQUksQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDcEQsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxLQUFLLFlBQVksNkJBQWUsRUFBRSxDQUFDO29CQUNyQywyRUFBMkU7b0JBQzNFLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDekQsTUFBTSxJQUFJLDZCQUFlLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3ZELENBQUM7Z0JBQ0QsTUFBTSxLQUFLLENBQUM7WUFDZCxDQUFDO1NBQ0Y7UUFFRDs7O1dBR0c7UUFDSyx3QkFBd0IsQ0FBQyxNQUEwQjtZQUN6RCx3RkFBd0Y7WUFDeEYsSUFBSSxDQUFDO2dCQUNILElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDckMsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxLQUFLLFlBQVksNkJBQWUsRUFBRSxDQUFDO29CQUNyQywyRUFBMkU7b0JBQzNFLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDekQsTUFBTSxJQUFJLDZCQUFlLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3ZELENBQUM7Z0JBQ0QsTUFBTSxLQUFLLENBQUM7WUFDZCxDQUFDO1NBQ0Y7UUFFRDs7O1dBR0c7UUFDSyxtQ0FBbUMsQ0FBQyxNQUFpQztZQUMzRSx3RkFBd0Y7WUFDeEYsSUFBSSxDQUFDO2dCQUNILElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDaEQsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsSUFBSSxLQUFLLFlBQVksNkJBQWUsRUFBRSxDQUFDO29CQUNyQywyRUFBMkU7b0JBQzNFLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDekQsTUFBTSxJQUFJLDZCQUFlLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3ZELENBQUM7Z0JBQ0QsTUFBTSxLQUFLLENBQUM7WUFDZCxDQUFDO1NBQ0Y7O1lBL3RDVSx1REFBUzs7Ozs7QUFBVCw4QkFBUyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGZzIGZyb20gJ2ZzJztcbmltcG9ydCB0eXBlIHsgSVJlc29sdmFibGUsIElSZXNvdXJjZSB9IGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCB7IEFybiwgQXJuRm9ybWF0LCBMYXp5LCBSZXNvdXJjZSwgVG9rZW4sIFZhbGlkYXRpb25FcnJvciB9IGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCAqIGFzIGJlZHJvY2sgZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHR5cGUgeyBNZXRyaWNPcHRpb25zLCBNZXRyaWNQcm9wcyB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1jbG91ZHdhdGNoJztcbmltcG9ydCB7IE1ldHJpYyB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1jbG91ZHdhdGNoJztcbmltcG9ydCAqIGFzIGlhbSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCB0eXBlIHsgSUtleSB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1rbXMnO1xuaW1wb3J0IHsgS2V5IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWttcyc7XG5pbXBvcnQgeyBtZDVoYXNoIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvaGVscGVycy1pbnRlcm5hbCc7XG5pbXBvcnQgeyBhZGRDb25zdHJ1Y3RNZXRhZGF0YSwgTWV0aG9kTWV0YWRhdGEgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9tZXRhZGF0YS1yZXNvdXJjZSc7XG5pbXBvcnQgeyBwcm9wZXJ0eUluamVjdGFibGUgfSBmcm9tICdhd3MtY2RrLWxpYi9jb3JlL2xpYi9wcm9wLWluamVjdGFibGUnO1xuaW1wb3J0IHR5cGUgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcbi8vIEludGVybmFsIExpYnNcbmltcG9ydCAqIGFzIGZpbHRlcnMgZnJvbSAnLi9ndWFyZHJhaWwtZmlsdGVycyc7XG5pbXBvcnQgeyBHdWFyZHJhaWxWZXJzaW9uIH0gZnJvbSAnLi9ndWFyZHJhaWwtdmVyc2lvbic7XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ09NTU9OXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIEd1YXJkcmFpbENyb3NzUmVnaW9uQ29uZmlnUHJvcGVydHlcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBHdWFyZHJhaWxDcm9zc1JlZ2lvbkNvbmZpZ1Byb3BlcnR5IHtcbiAgLyoqXG4gICAqIFRoZSBhcm4gb2YgdGhlc3lzdGVtLWRlZmluZWQgZ3VhcmRyYWlsIHByb2ZpbGUgdGhhdCB5b3UncmUgdXNpbmcgd2l0aCB5b3VyIGd1YXJkcmFpbC5cbiAgICogR3VhcmRyYWlsIHByb2ZpbGVzIGRlZmluZSB0aGUgZGVzdGluYXRpb24gQVdTIFJlZ2lvbnMgd2hlcmUgZ3VhcmRyYWlsIGluZmVyZW5jZSByZXF1ZXN0cyBjYW4gYmUgYXV0b21hdGljYWxseSByb3V0ZWQuXG4gICAqIFVzaW5nIGd1YXJkcmFpbCBwcm9maWxlcyBoZWxwcyBtYWludGFpbiBndWFyZHJhaWwgcGVyZm9ybWFuY2UgYW5kIHJlbGlhYmlsaXR5IHdoZW4gZGVtYW5kIGluY3JlYXNlcy5cbiAgICogQGRlZmF1bHQgLSBObyBjcm9zcy1yZWdpb24gY29uZmlndXJhdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgZ3VhcmRyYWlsUHJvZmlsZUFybjogc3RyaW5nO1xufVxuXG4vKipcbiAqIFJlcHJlc2VudHMgYSBHdWFyZHJhaWwsIGVpdGhlciBjcmVhdGVkIHdpdGggQ0RLIG9yIGltcG9ydGVkLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIElHdWFyZHJhaWwgZXh0ZW5kcyBJUmVzb3VyY2Uge1xuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICByZWFkb25seSBndWFyZHJhaWxBcm46IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBJRCBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICByZWFkb25seSBndWFyZHJhaWxJZDogc3RyaW5nO1xuICAvKipcbiAgICogT3B0aW9uYWwgS01TIGVuY3J5cHRpb24ga2V5IGFzc29jaWF0ZWQgd2l0aCB0aGlzIGd1YXJkcmFpbFxuICAgKi9cbiAgcmVhZG9ubHkga21zS2V5PzogSUtleTtcbiAgLyoqXG4gICAqIFdoZW4gdGhpcyBndWFyZHJhaWwgd2FzIGxhc3QgdXBkYXRlZC5cbiAgICovXG4gIHJlYWRvbmx5IGxhc3RVcGRhdGVkPzogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIHZlcnNpb24gb2YgdGhlIGd1YXJkcmFpbC4gSWYgbm8gZXhwbGljaXQgdmVyc2lvbiBpcyBjcmVhdGVkLFxuICAgKiB0aGlzIHdpbGwgZGVmYXVsdCB0byBcIkRSQUZUXCJcbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcmVhZG9ubHkgZ3VhcmRyYWlsVmVyc2lvbjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBHcmFudCB0aGUgZ2l2ZW4gcHJpbmNpcGFsIGlkZW50aXR5IHBlcm1pc3Npb25zIHRvIHBlcmZvcm0gYWN0aW9ucyBvbiB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIGdyYW50KGdyYW50ZWU6IGlhbS5JR3JhbnRhYmxlLCAuLi5hY3Rpb25zOiBzdHJpbmdbXSk6IGlhbS5HcmFudDtcbiAgLyoqXG4gICAqIEdyYW50IHRoZSBnaXZlbiBpZGVudGl0eSBwZXJtaXNzaW9ucyB0byBhcHBseSB0aGUgZ3VhcmRyYWlsLlxuICAgKi9cbiAgZ3JhbnRBcHBseShncmFudGVlOiBpYW0uSUdyYW50YWJsZSk6IGlhbS5HcmFudDtcblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBnaXZlbiBuYW1lZCBtZXRyaWMgZm9yIHRoaXMgZ3VhcmRyYWlsLlxuICAgKi9cbiAgbWV0cmljKG1ldHJpY05hbWU6IHN0cmluZywgcHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljO1xuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb25zIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBtZXRyaWNJbnZvY2F0aW9ucyhwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWM7XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbiBsYXRlbmN5IG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBtZXRyaWNJbnZvY2F0aW9uTGF0ZW5jeShwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWM7XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbiBjbGllbnQgZXJyb3JzIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBtZXRyaWNJbnZvY2F0aW9uQ2xpZW50RXJyb3JzKHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYztcblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBpbnZvY2F0aW9uIHNlcnZlciBlcnJvcnMgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIG1ldHJpY0ludm9jYXRpb25TZXJ2ZXJFcnJvcnMocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljO1xuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb24gdGhyb3R0bGVzIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBtZXRyaWNJbnZvY2F0aW9uVGhyb3R0bGVzKHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYztcblxuICAvKipcbiAgICogUmV0dXJuIHRoZSB0ZXh0IHVuaXQgY291bnQgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIG1ldHJpY1RleHRVbml0Q291bnQocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljO1xuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb25zIGludGVydmVuZWQgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIG1ldHJpY0ludm9jYXRpb25zSW50ZXJ2ZW5lZChwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWM7XG59XG5cbi8qKlxuICogQWJzdHJhY3QgYmFzZSBjbGFzcyBmb3IgYSBHdWFyZHJhaWwuXG4gKiBDb250YWlucyBtZXRob2RzIGFuZCBhdHRyaWJ1dGVzIHZhbGlkIGZvciBHdWFyZHJhaWxzIGVpdGhlciBjcmVhdGVkIHdpdGggQ0RLIG9yIGltcG9ydGVkLlxuICovXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgR3VhcmRyYWlsQmFzZSBleHRlbmRzIFJlc291cmNlIGltcGxlbWVudHMgSUd1YXJkcmFpbCB7XG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGdpdmVuIG5hbWVkIG1ldHJpYyBmb3IgYWxsIGd1YXJkcmFpbHMuXG4gICAqXG4gICAqIEJ5IGRlZmF1bHQsIHRoZSBtZXRyaWMgd2lsbCBiZSBjYWxjdWxhdGVkIGFzIGEgc3VtIG92ZXIgYSBwZXJpb2Qgb2YgNSBtaW51dGVzLlxuICAgKiBZb3UgY2FuIGN1c3RvbWl6ZSB0aGlzIGJ5IHVzaW5nIHRoZSBgc3RhdGlzdGljYCBhbmQgYHBlcmlvZGAgcHJvcGVydGllcy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWV0cmljQWxsKG1ldHJpY05hbWU6IHN0cmluZywgcHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gbmV3IE1ldHJpYyh7XG4gICAgICBuYW1lc3BhY2U6ICdBV1MvQmVkcm9jay9HdWFyZHJhaWxzJyxcbiAgICAgIGRpbWVuc2lvbnNNYXA6IHsgT3BlcmF0aW9uOiAnQXBwbHlHdWFyZHJhaWwnIH0sXG4gICAgICBtZXRyaWNOYW1lLFxuICAgICAgLi4ucHJvcHMsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBpbnZvY2F0aW9ucyBtZXRyaWMgZm9yIGFsbCBndWFyZHJhaWxzLlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBtZXRyaWNBbGxJbnZvY2F0aW9ucyhwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiB0aGlzLm1ldHJpY0FsbCgnSW52b2NhdGlvbnMnLCBwcm9wcyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSB0ZXh0IHVuaXQgY291bnQgbWV0cmljIGZvciBhbGwgZ3VhcmRyYWlscy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWV0cmljQWxsVGV4dFVuaXRDb3VudChwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiB0aGlzLm1ldHJpY0FsbCgnVGV4dFVuaXRDb3VudCcsIHByb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb25zIGludGVydmVuZWQgbWV0cmljIGZvciBhbGwgZ3VhcmRyYWlscy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWV0cmljQWxsSW52b2NhdGlvbnNJbnRlcnZlbmVkKHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYyB7XG4gICAgcmV0dXJuIHRoaXMubWV0cmljQWxsKCdJbnZvY2F0aW9uc0ludGVydmVuZWQnLCBwcm9wcyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBpbnZvY2F0aW9uIGxhdGVuY3kgbWV0cmljIGZvciBhbGwgZ3VhcmRyYWlscy5cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWV0cmljQWxsSW52b2NhdGlvbkxhdGVuY3kocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gdGhpcy5tZXRyaWNBbGwoJ0ludm9jYXRpb25MYXRlbmN5JywgcHJvcHMpO1xuICB9XG5cbiAgcHJpdmF0ZSBfdmVyc2lvbjogc3RyaW5nID0gJ0RSQUZUJztcblxuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkgZ3VhcmRyYWlsQXJuOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBJRCBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgYWJzdHJhY3QgcmVhZG9ubHkgZ3VhcmRyYWlsSWQ6IHN0cmluZztcblxuICAvKipcbiAgICogT3B0aW9uYWwgS01TIGVuY3J5cHRpb24ga2V5IGFzc29jaWF0ZWQgd2l0aCB0aGlzIGd1YXJkcmFpbFxuICAgKi9cbiAgcHVibGljIGFic3RyYWN0IHJlYWRvbmx5IGttc0tleT86IElLZXk7XG5cbiAgLyoqXG4gICAqIFdoZW4gdGhpcyBndWFyZHJhaWwgd2FzIGxhc3QgdXBkYXRlZC5cbiAgICovXG4gIHB1YmxpYyBhYnN0cmFjdCByZWFkb25seSBsYXN0VXBkYXRlZD86IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHZlcnNpb24gb2YgdGhlIGd1YXJkcmFpbC5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIGdldCBndWFyZHJhaWxWZXJzaW9uKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMuX3ZlcnNpb247XG4gIH1cblxuICBwcm90ZWN0ZWQgdXBkYXRlVmVyc2lvbih2ZXJzaW9uOiBzdHJpbmcpIHtcbiAgICB0aGlzLl92ZXJzaW9uID0gdmVyc2lvbjtcbiAgfVxuXG4gIC8qKlxuICAgKiBHcmFudCB0aGUgZ2l2ZW4gcHJpbmNpcGFsIGlkZW50aXR5IHBlcm1pc3Npb25zIHRvIHBlcmZvcm0gYWN0aW9ucyBvbiB0aGlzIGd1YXJkcmFpbC5cbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqL1xuICBwdWJsaWMgZ3JhbnQoZ3JhbnRlZTogaWFtLklHcmFudGFibGUsIC4uLmFjdGlvbnM6IHN0cmluZ1tdKSB7XG4gICAgcmV0dXJuIGlhbS5HcmFudC5hZGRUb1ByaW5jaXBhbCh7XG4gICAgICBncmFudGVlLFxuICAgICAgYWN0aW9ucyxcbiAgICAgIHJlc291cmNlQXJuczogW3RoaXMuZ3VhcmRyYWlsQXJuXSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHcmFudCB0aGUgZ2l2ZW4gaWRlbnRpdHkgcGVybWlzc2lvbnMgdG8gYXBwbHkgdGhlIGd1YXJkcmFpbC5cbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqL1xuICBwdWJsaWMgZ3JhbnRBcHBseShncmFudGVlOiBpYW0uSUdyYW50YWJsZSk6IGlhbS5HcmFudCB7XG4gICAgY29uc3QgYmFzZUdyYW50ID0gdGhpcy5ncmFudChncmFudGVlLCAnYmVkcm9jazpBcHBseUd1YXJkcmFpbCcpO1xuXG4gICAgaWYgKHRoaXMua21zS2V5KSB7XG4gICAgICAvLyBJZiBLTVMga2V5IGV4aXN0cywgY3JlYXRlIGVuY3J5cHRpb24gZ3JhbnQgYW5kIGNvbWJpbmUgd2l0aCBiYXNlIGdyYW50XG4gICAgICBjb25zdCBrbXNHcmFudCA9IHRoaXMua21zS2V5LmdyYW50RW5jcnlwdERlY3J5cHQoZ3JhbnRlZSk7XG4gICAgICByZXR1cm4ga21zR3JhbnQuY29tYmluZShiYXNlR3JhbnQpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBJZiBubyBLTVMga2V5IGV4aXN0cywgcmV0dXJuIG9ubHkgdGhlIGJhc2UgZ3JhbnRcbiAgICAgIHJldHVybiBiYXNlR3JhbnQ7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgZ2l2ZW4gbmFtZWQgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICpcbiAgICogQnkgZGVmYXVsdCwgdGhlIG1ldHJpYyB3aWxsIGJlIGNhbGN1bGF0ZWQgYXMgYSBzdW0gb3ZlciBhIHBlcmlvZCBvZiA1IG1pbnV0ZXMuXG4gICAqIFlvdSBjYW4gY3VzdG9taXplIHRoaXMgYnkgdXNpbmcgdGhlIGBzdGF0aXN0aWNgIGFuZCBgcGVyaW9kYCBwcm9wZXJ0aWVzLlxuICAgKi9cbiAgcHVibGljIG1ldHJpYyhtZXRyaWNOYW1lOiBzdHJpbmcsIHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYyB7XG4gICAgY29uc3QgbWV0cmljUHJvcHM6IE1ldHJpY1Byb3BzID0ge1xuICAgICAgbmFtZXNwYWNlOiAnQVdTL0JlZHJvY2svR3VhcmRyYWlscycsXG4gICAgICBtZXRyaWNOYW1lLFxuICAgICAgZGltZW5zaW9uc01hcDogeyBHdWFyZHJhaWxBcm46IHRoaXMuZ3VhcmRyYWlsQXJuLCBHdWFyZHJhaWxWZXJzaW9uOiB0aGlzLmd1YXJkcmFpbFZlcnNpb24gfSxcbiAgICAgIC4uLnByb3BzLFxuICAgIH07XG4gICAgcmV0dXJuIHRoaXMuY29uZmlndXJlTWV0cmljKG1ldHJpY1Byb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb25zIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgbWV0cmljSW52b2NhdGlvbnMocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMoJ0ludm9jYXRpb25zJywgcHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbiBsYXRlbmN5IG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgbWV0cmljSW52b2NhdGlvbkxhdGVuY3kocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMoJ0ludm9jYXRpb25MYXRlbmN5JywgcHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbiBjbGllbnQgZXJyb3JzIG1ldHJpYyBmb3IgdGhpcyBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgbWV0cmljSW52b2NhdGlvbkNsaWVudEVycm9ycyhwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiB0aGlzLm1ldHJpYygnSW52b2NhdGlvbkNsaWVudEVycm9ycycsIHByb3BzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gdGhlIGludm9jYXRpb24gc2VydmVyIGVycm9ycyBtZXRyaWMgZm9yIHRoaXMgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIG1ldHJpY0ludm9jYXRpb25TZXJ2ZXJFcnJvcnMocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMoJ0ludm9jYXRpb25TZXJ2ZXJFcnJvcnMnLCBwcm9wcyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSBpbnZvY2F0aW9uIHRocm90dGxlcyBtZXRyaWMgZm9yIHRoaXMgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIG1ldHJpY0ludm9jYXRpb25UaHJvdHRsZXMocHJvcHM/OiBNZXRyaWNPcHRpb25zKTogTWV0cmljIHtcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMoJ0ludm9jYXRpb25UaHJvdHRsZXMnLCBwcm9wcyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJuIHRoZSB0ZXh0IHVuaXQgY291bnQgbWV0cmljIGZvciB0aGlzIGd1YXJkcmFpbC5cbiAgICovXG4gIHB1YmxpYyBtZXRyaWNUZXh0VW5pdENvdW50KHByb3BzPzogTWV0cmljT3B0aW9ucyk6IE1ldHJpYyB7XG4gICAgcmV0dXJuIHRoaXMubWV0cmljKCdUZXh0VW5pdENvdW50JywgcHJvcHMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiB0aGUgaW52b2NhdGlvbnMgaW50ZXJ2ZW5lZCBtZXRyaWMgZm9yIHRoaXMgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIG1ldHJpY0ludm9jYXRpb25zSW50ZXJ2ZW5lZChwcm9wcz86IE1ldHJpY09wdGlvbnMpOiBNZXRyaWMge1xuICAgIHJldHVybiB0aGlzLm1ldHJpYygnSW52b2NhdGlvbnNJbnRlcnZlbmVkJywgcHJvcHMpO1xuICB9XG5cbiAgcHJpdmF0ZSBjb25maWd1cmVNZXRyaWMocHJvcHM6IE1ldHJpY1Byb3BzKSB7XG4gICAgcmV0dXJuIG5ldyBNZXRyaWMoe1xuICAgICAgLi4ucHJvcHMsXG4gICAgICByZWdpb246IHByb3BzPy5yZWdpb24gPz8gdGhpcy5zdGFjay5yZWdpb24sXG4gICAgICBhY2NvdW50OiBwcm9wcz8uYWNjb3VudCA/PyB0aGlzLnN0YWNrLmFjY291bnQsXG4gICAgfSk7XG4gIH1cbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBQUk9QUyBGT1IgTkVXIENPTlNUUlVDVFxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBjcmVhdGluZyBhIEd1YXJkcmFpbC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBHdWFyZHJhaWxQcm9wcyB7XG4gIC8qKlxuICAgKiBUaGUgbmFtZSBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKiBUaGlzIHdpbGwgYmUgdXNlZCBhcyB0aGUgcGh5c2ljYWwgbmFtZSBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcmVhZG9ubHkgZ3VhcmRyYWlsTmFtZTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGRlc2NyaXB0aW9uIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IC0gTm8gZGVzY3JpcHRpb25cbiAgICovXG4gIHJlYWRvbmx5IGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIG1lc3NhZ2UgdG8gcmV0dXJuIHdoZW4gdGhlIGd1YXJkcmFpbCBibG9ja3MgYSBwcm9tcHQuXG4gICAqIE11c3QgYmUgYmV0d2VlbiAxIGFuZCA1MDAgY2hhcmFjdGVycy5cbiAgICogQGRlZmF1bHQgXCJTb3JyeSwgeW91ciBxdWVyeSB2aW9sYXRlcyBvdXIgdXNhZ2UgcG9saWN5LlwiXG4gICAqL1xuICByZWFkb25seSBibG9ja2VkSW5wdXRNZXNzYWdpbmc/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgbWVzc2FnZSB0byByZXR1cm4gd2hlbiB0aGUgZ3VhcmRyYWlsIGJsb2NrcyBhIG1vZGVsIHJlc3BvbnNlLlxuICAgKiBNdXN0IGJlIGJldHdlZW4gMSBhbmQgNTAwIGNoYXJhY3RlcnMuXG4gICAqIEBkZWZhdWx0IFwiU29ycnksIEkgYW0gdW5hYmxlIHRvIGFuc3dlciB5b3VyIHF1ZXN0aW9uIGJlY2F1c2Ugb2Ygb3VyIHVzYWdlIHBvbGljeS5cIlxuICAgKi9cbiAgcmVhZG9ubHkgYmxvY2tlZE91dHB1dHNNZXNzYWdpbmc/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBBIGN1c3RvbSBLTVMga2V5IHRvIHVzZSBmb3IgZW5jcnlwdGluZyBkYXRhLlxuICAgKiBAZGVmYXVsdCAtIERhdGEgaXMgZW5jcnlwdGVkIGJ5IGRlZmF1bHQgd2l0aCBhIGtleSB0aGF0IEFXUyBvd25zIGFuZCBtYW5hZ2VzIGZvciB5b3VcbiAgICovXG4gIHJlYWRvbmx5IGttc0tleT86IElLZXk7XG4gIC8qKlxuICAgKiBUaGUgY29udGVudCBmaWx0ZXJzIHRvIGFwcGx5IHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IFtdXG4gICAqL1xuICByZWFkb25seSBjb250ZW50RmlsdGVycz86IGZpbHRlcnMuQ29udGVudEZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIHRpZXIgY29uZmlndXJhdGlvbiB0byBhcHBseSB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAZGVmYXVsdCBmaWx0ZXJzLlRpZXJDb25maWcuQ0xBU1NJQ1xuICAgKi9cbiAgcmVhZG9ubHkgY29udGVudEZpbHRlcnNUaWVyQ29uZmlnPzogZmlsdGVycy5UaWVyQ29uZmlnO1xuICAvKipcbiAgICogQSBsaXN0IG9mIHBvbGljaWVzIHJlbGF0ZWQgdG8gdG9waWNzIHRoYXQgdGhlIGd1YXJkcmFpbCBzaG91bGQgZGVueS5cbiAgICogQGRlZmF1bHQgW11cbiAgICovXG4gIHJlYWRvbmx5IGRlbmllZFRvcGljcz86IGZpbHRlcnMuVG9waWNbXTtcbiAgLyoqXG4gICAqIFRoZSB0aWVyIGNvbmZpZ3VyYXRpb24gdG8gYXBwbHkgdG8gdGhlIGd1YXJkcmFpbC5cbiAgICogQGRlZmF1bHQgZmlsdGVycy5UaWVyQ29uZmlnLkNMQVNTSUNcbiAgICovXG4gIHJlYWRvbmx5IHRvcGljc1RpZXJDb25maWc/OiBmaWx0ZXJzLlRpZXJDb25maWc7XG4gIC8qKlxuICAgKiBUaGUgd29yZCBmaWx0ZXJzIHRvIGFwcGx5IHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IFtdXG4gICAqL1xuICByZWFkb25seSB3b3JkRmlsdGVycz86IGZpbHRlcnMuV29yZEZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIG1hbmFnZWQgd29yZCBmaWx0ZXJzIHRvIGFwcGx5IHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IFtdXG4gICAqL1xuICByZWFkb25seSBtYW5hZ2VkV29yZExpc3RGaWx0ZXJzPzogZmlsdGVycy5NYW5hZ2VkV29yZEZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIFBJSSBmaWx0ZXJzIHRvIGFwcGx5IHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IFtdXG4gICAqL1xuICByZWFkb25seSBwaWlGaWx0ZXJzPzogZmlsdGVycy5QSUlGaWx0ZXJbXTtcbiAgLyoqXG4gICAqIFRoZSByZWd1bGFyIGV4cHJlc3Npb24gKHJlZ2V4KSBmaWx0ZXJzIHRvIGFwcGx5IHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBkZWZhdWx0IFtdXG4gICAqL1xuICByZWFkb25seSByZWdleEZpbHRlcnM/OiBmaWx0ZXJzLlJlZ2V4RmlsdGVyW107XG4gIC8qKlxuICAgKiBUaGUgY29udGV4dHVhbCBncm91bmRpbmcgZmlsdGVycyB0byBhcHBseSB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAZGVmYXVsdCBbXVxuICAgKi9cbiAgcmVhZG9ubHkgY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnM/OiBmaWx0ZXJzLkNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJbXTtcbiAgLyoqXG4gICAqIFRoZSBjcm9zcy1yZWdpb24gY29uZmlndXJhdGlvbiBmb3IgdGhlIGd1YXJkcmFpbC5cbiAgICogVGhpcyBpcyBvcHRpb25hbCBhbmQgd2hlbiBwcm92aWRlZCwgaXQgc2hvdWxkIGJlIG9mIHR5cGUgR3VhcmRyYWlsQ3Jvc3NSZWdpb25Db25maWdQcm9wZXJ0eS5cbiAgICogQGRlZmF1bHQgLSBObyBjcm9zcy1yZWdpb24gY29uZmlndXJhdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgY3Jvc3NSZWdpb25Db25maWc/OiBHdWFyZHJhaWxDcm9zc1JlZ2lvbkNvbmZpZ1Byb3BlcnR5O1xufVxuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICBBVFRSUyBGT1IgSU1QT1JURUQgQ09OU1RSVUNUXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5leHBvcnQgaW50ZXJmYWNlIEd1YXJkcmFpbEF0dHJpYnV0ZXMge1xuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgZ3VhcmRyYWlsLiBBdCBsZWFzdCBvbmUgb2YgZ3VhcmRyYWlsQXJuIG9yIGd1YXJkcmFpbElkIG11c3QgYmVcbiAgICogZGVmaW5lZCBpbiBvcmRlciB0byBpbml0aWFsaXplIGEgZ3VhcmRyYWlsIHJlZi5cbiAgICovXG4gIHJlYWRvbmx5IGd1YXJkcmFpbEFybjogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIEtNUyBrZXkgb2YgdGhlIGd1YXJkcmFpbCBpZiBjdXN0b20gZW5jcnlwdGlvbiBpcyBjb25maWd1cmVkLlxuICAgKlxuICAgKiBAZGVmYXVsdCB1bmRlZmluZWQgLSBNZWFucyBkYXRhIGlzIGVuY3J5cHRlZCBieSBkZWZhdWx0IHdpdGggYSBBV1MtbWFuYWdlZCBrZXlcbiAgICovXG4gIHJlYWRvbmx5IGttc0tleT86IElLZXk7XG4gIC8qKlxuICAgKiBUaGUgdmVyc2lvbiBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKlxuICAgKiBAZGVmYXVsdCBcIkRSQUZUXCJcbiAgICovXG4gIHJlYWRvbmx5IGd1YXJkcmFpbFZlcnNpb24/OiBzdHJpbmc7XG59XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqICAgICAgICAgICAgICAgICAgICAgICAgTkVXIENPTlNUUlVDVCBERUZJTklUSU9OXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIENsYXNzIHRvIGNyZWF0ZSBhIEd1YXJkcmFpbCB3aXRoIENESy5cbiAqIEBjbG91ZGZvcm1hdGlvblJlc291cmNlIEFXUzo6QmVkcm9jazo6R3VhcmRyYWlsXG4gKi9cbkBwcm9wZXJ0eUluamVjdGFibGVcbmV4cG9ydCBjbGFzcyBHdWFyZHJhaWwgZXh0ZW5kcyBHdWFyZHJhaWxCYXNlIHtcbiAgLyoqIFVuaXF1ZWx5IGlkZW50aWZpZXMgdGhpcyBjbGFzcy4gKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBQUk9QRVJUWV9JTkpFQ1RJT05fSUQ6IHN0cmluZyA9ICdAYXdzLWNkay5hd3MtYmVkcm9jay1hbHBoYS5HdWFyZHJhaWwnO1xuXG4gIC8qKlxuICAgKiBJbXBvcnQgYSBndWFyZHJhaWwgZ2l2ZW4gaXRzIGF0dHJpYnV0ZXNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUd1YXJkcmFpbEF0dHJpYnV0ZXMoc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgYXR0cnM6IEd1YXJkcmFpbEF0dHJpYnV0ZXMpOiBJR3VhcmRyYWlsIHtcbiAgICBjbGFzcyBJbXBvcnQgZXh0ZW5kcyBHdWFyZHJhaWxCYXNlIHtcbiAgICAgIHB1YmxpYyByZWFkb25seSBndWFyZHJhaWxBcm4gPSBhdHRycy5ndWFyZHJhaWxBcm47XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgZ3VhcmRyYWlsSWQgPSBBcm4uc3BsaXQoYXR0cnMuZ3VhcmRyYWlsQXJuLCBBcm5Gb3JtYXQuU0xBU0hfUkVTT1VSQ0VfTkFNRSkucmVzb3VyY2VOYW1lITtcbiAgICAgIHB1YmxpYyByZWFkb25seSBrbXNLZXkgPSBhdHRycy5rbXNLZXk7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgbGFzdFVwZGF0ZWQgPSB1bmRlZmluZWQ7XG5cbiAgICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcihzY29wZSwgaWQpO1xuICAgICAgICB0aGlzLnVwZGF0ZVZlcnNpb24oYXR0cnMuZ3VhcmRyYWlsVmVyc2lvbiA/PyAnRFJBRlQnKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IEltcG9ydCgpO1xuICB9XG5cbiAgLyoqXG4gICAqIEltcG9ydCBhIGxvdy1sZXZlbCBMMSBDZm4gR3VhcmRyYWlsXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIGZyb21DZm5HdWFyZHJhaWwoY2ZuR3VhcmRyYWlsOiBiZWRyb2NrLkNmbkd1YXJkcmFpbCk6IElHdWFyZHJhaWwge1xuICAgIHJldHVybiBuZXcgKGNsYXNzIGV4dGVuZHMgR3VhcmRyYWlsQmFzZSB7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgZ3VhcmRyYWlsQXJuID0gY2ZuR3VhcmRyYWlsLmF0dHJHdWFyZHJhaWxBcm47XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgZ3VhcmRyYWlsSWQgPSBjZm5HdWFyZHJhaWwuYXR0ckd1YXJkcmFpbElkO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGttc0tleSA9IGNmbkd1YXJkcmFpbC5rbXNLZXlBcm5cbiAgICAgICAgPyBLZXkuZnJvbUtleUFybih0aGlzLCAnQEZyb21DZm5HdWFyZHJhaWxLZXknLCBjZm5HdWFyZHJhaWwua21zS2V5QXJuKVxuICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICAgIHB1YmxpYyByZWFkb25seSBsYXN0VXBkYXRlZCA9IGNmbkd1YXJkcmFpbC5hdHRyVXBkYXRlZEF0O1xuXG4gICAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoY2ZuR3VhcmRyYWlsLCAnQEZyb21DZm5HdWFyZHJhaWwnKTtcbiAgICAgICAgdGhpcy51cGRhdGVWZXJzaW9uKGNmbkd1YXJkcmFpbC5hdHRyVmVyc2lvbik7XG4gICAgICB9XG4gICAgfSkoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBndWFyZHJhaWxBcm46IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBJRCBvZiB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZ3VhcmRyYWlsSWQ6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIEtNUyBrZXkgdXNlZCB0byBlbmNyeXB0IGRhdGEuXG4gICAqXG4gICAqIEBkZWZhdWx0IHVuZGVmaW5lZCAtIFwiRGF0YSBpcyBlbmNyeXB0ZWQgYnkgZGVmYXVsdCB3aXRoIGEga2V5IHRoYXQgQVdTIG93bnMgYW5kIG1hbmFnZXMgZm9yIHlvdVwiXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkga21zS2V5PzogSUtleTtcbiAgLyoqXG4gICAqIFRoZSBjb250ZW50IGZpbHRlcnMgYXBwbGllZCBieSB0aGUgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGNvbnRlbnRGaWx0ZXJzOiBmaWx0ZXJzLkNvbnRlbnRGaWx0ZXJbXTtcbiAgLyoqXG4gICAqIFRoZSBQSUkgZmlsdGVycyBhcHBsaWVkIGJ5IHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgcGlpRmlsdGVyczogZmlsdGVycy5QSUlGaWx0ZXJbXTtcbiAgLyoqXG4gICAqIFRoZSByZWdleCBmaWx0ZXJzIGFwcGxpZWQgYnkgdGhlIGd1YXJkcmFpbC5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSByZWdleEZpbHRlcnM6IGZpbHRlcnMuUmVnZXhGaWx0ZXJbXTtcbiAgLyoqXG4gICAqIFRoZSBkZW5pZWQgdG9waWMgZmlsdGVycyBhcHBsaWVkIGJ5IHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgZGVuaWVkVG9waWNzOiBmaWx0ZXJzLlRvcGljW107XG4gIC8qKlxuICAgKiBUaGUgY29udGV4dHVhbCBncm91bmRpbmcgZmlsdGVycyBhcHBsaWVkIGJ5IHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnM6IGZpbHRlcnMuQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIHdvcmQgZmlsdGVycyBhcHBsaWVkIGJ5IHRoZSBndWFyZHJhaWwuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgd29yZEZpbHRlcnM6IGZpbHRlcnMuV29yZEZpbHRlcltdO1xuICAvKipcbiAgICogVGhlIG1hbmFnZWQgd29yZCBsaXN0IGZpbHRlcnMgYXBwbGllZCBieSB0aGUgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IG1hbmFnZWRXb3JkTGlzdEZpbHRlcnM6IGZpbHRlcnMuTWFuYWdlZFdvcmRGaWx0ZXJbXTtcbiAgLyoqXG4gICAqIFdoZW4gdGhpcyBndWFyZHJhaWwgd2FzIGxhc3QgdXBkYXRlZFxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGxhc3RVcGRhdGVkPzogc3RyaW5nO1xuICAvKipcbiAgICogVGhlIGNvbXB1dGVkIGhhc2ggb2YgdGhlIGd1YXJkcmFpbCBwcm9wZXJ0aWVzLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGhhc2g6IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBMMSByZXByZXNlbnRhdGlvbiBvZiB0aGUgZ3VhcmRyYWlsXG4gICAqL1xuICBwcml2YXRlIHJlYWRvbmx5IF9fcmVzb3VyY2U6IGJlZHJvY2suQ2ZuR3VhcmRyYWlsO1xuXG4gIC8qKlxuICAgKiBUaGUgdGllciB0aGF0IHlvdXIgZ3VhcmRyYWlsIHVzZXMgZm9yIGRlbmllZCB0b3BpYyBmaWx0ZXJzLlxuICAgKiBAZGVmYXVsdCBmaWx0ZXJzLlRpZXJDb25maWcuQ0xBU1NJQ1xuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHRvcGljc1RpZXJDb25maWc6IGZpbHRlcnMuVGllckNvbmZpZztcblxuICAvKipcbiAgICogVGhlIHRpZXIgdGhhdCB5b3VyIGd1YXJkcmFpbCB1c2VzIGZvciBjb250ZW50IGZpbHRlcnMuXG4gICAqIENvbnNpZGVyIHVzaW5nIGEgdGllciB0aGF0IGJhbGFuY2VzIHBlcmZvcm1hbmNlLCBhY2N1cmFjeSwgYW5kIGNvbXBhdGliaWxpdHkgd2l0aCB5b3VyIGV4aXN0aW5nIGdlbmVyYXRpdmUgQUkgd29ya2Zsb3dzLlxuICAgKiBAZGVmYXVsdCBmaWx0ZXJzLlRpZXJDb25maWcuQ0xBU1NJQ1xuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZzogZmlsdGVycy5UaWVyQ29uZmlnO1xuICAvKipcbiAgICogVGhlIGNyb3NzLXJlZ2lvbiBjb25maWd1cmF0aW9uIGZvciB0aGUgZ3VhcmRyYWlsLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGNyb3NzUmVnaW9uQ29uZmlnPzogR3VhcmRyYWlsQ3Jvc3NSZWdpb25Db25maWdQcm9wZXJ0eTtcblxuICAvKipcbiAgICogVGhlIG1lc3NhZ2UgdG8gcmV0dXJuIHdoZW4gdGhlIGd1YXJkcmFpbCBibG9ja3MgYSBwcm9tcHQuXG4gICAqIEBkZWZhdWx0IFwiU29ycnksIHlvdXIgcXVlcnkgdmlvbGF0ZXMgb3VyIHVzYWdlIHBvbGljeS5cIlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGJsb2NrZWRJbnB1dE1lc3NhZ2luZzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbWVzc2FnZSB0byByZXR1cm4gd2hlbiB0aGUgZ3VhcmRyYWlsIGJsb2NrcyBhIG1vZGVsIHJlc3BvbnNlLlxuICAgKiBAZGVmYXVsdCBcIlNvcnJ5LCBJIGFtIHVuYWJsZSB0byBhbnN3ZXIgeW91ciBxdWVzdGlvbiBiZWNhdXNlIG9mIG91ciB1c2FnZSBwb2xpY3kuXCJcbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBibG9ja2VkT3V0cHV0c01lc3NhZ2luZzogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzOiBHdWFyZHJhaWxQcm9wcykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwge1xuICAgICAgcGh5c2ljYWxOYW1lOiBwcm9wcy5ndWFyZHJhaWxOYW1lLFxuICAgIH0pO1xuICAgIC8vIEVuaGFuY2VkIENESyBBbmFseXRpY3MgVGVsZW1ldHJ5XG4gICAgYWRkQ29uc3RydWN0TWV0YWRhdGEodGhpcywgcHJvcHMpO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gU2V0IHByb3BlcnRpZXMgb3IgZGVmYXVsdHNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLm5hbWUgPSB0aGlzLnBoeXNpY2FsTmFtZTtcbiAgICB0aGlzLmNvbnRlbnRGaWx0ZXJzID0gcHJvcHMuY29udGVudEZpbHRlcnMgPz8gW107XG4gICAgdGhpcy5waWlGaWx0ZXJzID0gcHJvcHMucGlpRmlsdGVycyA/PyBbXTtcbiAgICB0aGlzLnJlZ2V4RmlsdGVycyA9IHByb3BzLnJlZ2V4RmlsdGVycyA/PyBbXTtcbiAgICB0aGlzLmRlbmllZFRvcGljcyA9IHByb3BzLmRlbmllZFRvcGljcyA/PyBbXTtcbiAgICB0aGlzLmNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJzID0gcHJvcHMuY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMgPz8gW107XG4gICAgdGhpcy53b3JkRmlsdGVycyA9IHByb3BzLndvcmRGaWx0ZXJzID8/IFtdO1xuICAgIHRoaXMubWFuYWdlZFdvcmRMaXN0RmlsdGVycyA9IHByb3BzLm1hbmFnZWRXb3JkTGlzdEZpbHRlcnMgPz8gW107XG4gICAgdGhpcy50b3BpY3NUaWVyQ29uZmlnID0gcHJvcHMudG9waWNzVGllckNvbmZpZyA/PyBmaWx0ZXJzLlRpZXJDb25maWcuQ0xBU1NJQztcbiAgICB0aGlzLmNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZyA9IHByb3BzLmNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZyA/PyBmaWx0ZXJzLlRpZXJDb25maWcuQ0xBU1NJQztcbiAgICB0aGlzLmNyb3NzUmVnaW9uQ29uZmlnID0gcHJvcHMuY3Jvc3NSZWdpb25Db25maWc7XG4gICAgdGhpcy5ibG9ja2VkSW5wdXRNZXNzYWdpbmcgPSBwcm9wcy5ibG9ja2VkSW5wdXRNZXNzYWdpbmcgPz8gJ1NvcnJ5LCB5b3VyIHF1ZXJ5IHZpb2xhdGVzIG91ciB1c2FnZSBwb2xpY3kuJztcbiAgICB0aGlzLmJsb2NrZWRPdXRwdXRzTWVzc2FnaW5nID0gcHJvcHMuYmxvY2tlZE91dHB1dHNNZXNzYWdpbmcgPz8gJ1NvcnJ5LCBJIGFtIHVuYWJsZSB0byBhbnN3ZXIgeW91ciBxdWVzdGlvbiBiZWNhdXNlIG9mIG91ciB1c2FnZSBwb2xpY3kuJztcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIFZhbGlkYXRlIGFsbCBmaWx0ZXIgYXJyYXlzXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy52YWxpZGF0ZUNvbnRlbnRGaWx0ZXJzKHRoaXMuY29udGVudEZpbHRlcnMpO1xuICAgIHRoaXMudmFsaWRhdGVQaWlGaWx0ZXJzKHRoaXMucGlpRmlsdGVycyk7XG4gICAgdGhpcy52YWxpZGF0ZVJlZ2V4RmlsdGVycyh0aGlzLnJlZ2V4RmlsdGVycyk7XG4gICAgdGhpcy52YWxpZGF0ZURlbmllZFRvcGljcyh0aGlzLmRlbmllZFRvcGljcyk7XG4gICAgdGhpcy52YWxpZGF0ZUNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJzKHRoaXMuY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMpO1xuICAgIHRoaXMudmFsaWRhdGVXb3JkRmlsdGVycyh0aGlzLndvcmRGaWx0ZXJzKTtcbiAgICB0aGlzLnZhbGlkYXRlTWFuYWdlZFdvcmRMaXN0RmlsdGVycyh0aGlzLm1hbmFnZWRXb3JkTGlzdEZpbHRlcnMpO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gVmFsaWRhdGUgbWVzc2FnaW5nIHByb3BlcnRpZXNcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICB0aGlzLnZhbGlkYXRlTWVzc2FnaW5nUHJvcGVydHkodGhpcy5ibG9ja2VkSW5wdXRNZXNzYWdpbmcsICdibG9ja2VkSW5wdXRNZXNzYWdpbmcnKTtcbiAgICB0aGlzLnZhbGlkYXRlTWVzc2FnaW5nUHJvcGVydHkodGhpcy5ibG9ja2VkT3V0cHV0c01lc3NhZ2luZywgJ2Jsb2NrZWRPdXRwdXRzTWVzc2FnaW5nJyk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBWYWxpZGF0ZSB0aWVyIGNvbmZpZ3VyYXRpb24gcmVxdWlyZW1lbnRzXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy52YWxpZGF0ZVRpZXJDb25maWd1cmF0aW9uKHByb3BzKTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIENGTiBQcm9wcyAtIFdpdGggTGF6eSBzdXBwb3J0XG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgbGV0IGNmblByb3BzOiBiZWRyb2NrLkNmbkd1YXJkcmFpbFByb3BzID0ge1xuICAgICAgbmFtZTogcHJvcHMuZ3VhcmRyYWlsTmFtZSxcbiAgICAgIGRlc2NyaXB0aW9uOiBwcm9wcy5kZXNjcmlwdGlvbixcbiAgICAgIGttc0tleUFybjogcHJvcHMua21zS2V5Py5rZXlBcm4sXG4gICAgICBibG9ja2VkSW5wdXRNZXNzYWdpbmc6IHRoaXMuYmxvY2tlZElucHV0TWVzc2FnaW5nLFxuICAgICAgYmxvY2tlZE91dHB1dHNNZXNzYWdpbmc6IHRoaXMuYmxvY2tlZE91dHB1dHNNZXNzYWdpbmcsXG4gICAgICAvLyBMYXp5IHByb3BzXG4gICAgICBjcm9zc1JlZ2lvbkNvbmZpZzogdGhpcy5nZW5lcmF0ZUNmbkNyb3NzUmVnaW9uQ29uZmlnKCksXG4gICAgICBjb250ZW50UG9saWN5Q29uZmlnOiB0aGlzLmdlbmVyYXRlQ2ZuQ29udGVudFBvbGljeUNvbmZpZygpLFxuICAgICAgY29udGV4dHVhbEdyb3VuZGluZ1BvbGljeUNvbmZpZzogdGhpcy5nZW5lcmF0ZUNmbkNvbnRleHR1YWxQb2xpY3lDb25maWcoKSxcbiAgICAgIHRvcGljUG9saWN5Q29uZmlnOiB0aGlzLmdlbmVyYXRlQ2ZuVG9waWNQb2xpY3koKSxcbiAgICAgIHdvcmRQb2xpY3lDb25maWc6IHRoaXMuZ2VuZXJhdGVDZm5Xb3JkUG9saWN5Q29uZmlnKCksXG4gICAgICBzZW5zaXRpdmVJbmZvcm1hdGlvblBvbGljeUNvbmZpZzogdGhpcy5nZW5lcmF0ZUNmblNlbnNpdGl2ZUluZm9ybWF0aW9uUG9saWN5Q29uZmlnKCksXG4gICAgfTtcblxuICAgIC8vIEhhc2ggY2FsY3VsYXRpb24gdXNlZnVsIGZvciB2ZXJzaW9uaW5nIG9mIHRoZSBndWFyZHJhaWxcbiAgICB0aGlzLmhhc2ggPSBtZDVoYXNoKEpTT04uc3RyaW5naWZ5KGNmblByb3BzKSk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBMMSBJbnN0YW50aWF0aW9uXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy5fX3Jlc291cmNlID0gbmV3IGJlZHJvY2suQ2ZuR3VhcmRyYWlsKHRoaXMsICdNeUd1YXJkcmFpbCcsIGNmblByb3BzKTtcblxuICAgIHRoaXMuZ3VhcmRyYWlsSWQgPSB0aGlzLl9fcmVzb3VyY2UuYXR0ckd1YXJkcmFpbElkO1xuICAgIHRoaXMuZ3VhcmRyYWlsQXJuID0gdGhpcy5fX3Jlc291cmNlLmF0dHJHdWFyZHJhaWxBcm47XG4gICAgdGhpcy51cGRhdGVWZXJzaW9uKHRoaXMuX19yZXNvdXJjZS5hdHRyVmVyc2lvbik7XG4gICAgdGhpcy5sYXN0VXBkYXRlZCA9IHRoaXMuX19yZXNvdXJjZS5hdHRyVXBkYXRlZEF0O1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIE1FVEhPRFNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBBZGRzIGEgY29udGVudCBmaWx0ZXIgdG8gdGhlIGd1YXJkcmFpbC5cbiAgICogQHBhcmFtIGZpbHRlciBUaGUgY29udGVudCBmaWx0ZXIgdG8gYWRkLlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGFkZENvbnRlbnRGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLkNvbnRlbnRGaWx0ZXIpOiB2b2lkIHtcbiAgICB0aGlzLnZhbGlkYXRlU2luZ2xlQ29udGVudEZpbHRlcihmaWx0ZXIpO1xuICAgIHRoaXMuY29udGVudEZpbHRlcnMucHVzaChmaWx0ZXIpO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgYSBQSUkgZmlsdGVyIHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIFBJSSBmaWx0ZXIgdG8gYWRkLlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGFkZFBJSUZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuUElJRmlsdGVyKTogdm9pZCB7XG4gICAgdGhpcy52YWxpZGF0ZVNpbmdsZVBpaUZpbHRlcihmaWx0ZXIpO1xuICAgIHRoaXMucGlpRmlsdGVycy5wdXNoKGZpbHRlcik7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhIHJlZ2V4IGZpbHRlciB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSByZWdleCBmaWx0ZXIgdG8gYWRkLlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGFkZFJlZ2V4RmlsdGVyKGZpbHRlcjogZmlsdGVycy5SZWdleEZpbHRlcik6IHZvaWQge1xuICAgIHRoaXMudmFsaWRhdGVTaW5nbGVSZWdleEZpbHRlcihmaWx0ZXIpO1xuICAgIHRoaXMucmVnZXhGaWx0ZXJzLnB1c2goZmlsdGVyKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGEgZGVuaWVkIHRvcGljIGZpbHRlciB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSBkZW5pZWQgdG9waWMgZmlsdGVyIHRvIGFkZC5cbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBhZGREZW5pZWRUb3BpY0ZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuVG9waWMpOiB2b2lkIHtcbiAgICB0aGlzLnZhbGlkYXRlU2luZ2xlRGVuaWVkVG9waWMoZmlsdGVyKTtcbiAgICB0aGlzLmRlbmllZFRvcGljcy5wdXNoKGZpbHRlcik7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhIGNvbnRleHR1YWwgZ3JvdW5kaW5nIGZpbHRlciB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSBjb250ZXh0dWFsIGdyb3VuZGluZyBmaWx0ZXIgdG8gYWRkLlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGFkZENvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLkNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXIpOiB2b2lkIHtcbiAgICB0aGlzLnZhbGlkYXRlU2luZ2xlQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcihmaWx0ZXIpO1xuICAgIHRoaXMuY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMucHVzaChmaWx0ZXIpO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgYSB3b3JkIGZpbHRlciB0byB0aGUgZ3VhcmRyYWlsLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSB3b3JkIGZpbHRlciB0byBhZGQuXG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgYWRkV29yZEZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuV29yZEZpbHRlcik6IHZvaWQge1xuICAgIHRoaXMudmFsaWRhdGVTaW5nbGVXb3JkRmlsdGVyKGZpbHRlcik7XG4gICAgdGhpcy53b3JkRmlsdGVycy5wdXNoKGZpbHRlcik7XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhIHdvcmQgZmlsdGVyIHRvIHRoZSBndWFyZHJhaWwuXG4gICAqIEBwYXJhbSBmaWxlUGF0aCBUaGUgbG9jYXRpb24gb2YgdGhlIHdvcmQgZmlsdGVyIGZpbGUuXG4gICAqL1xuICBATWV0aG9kTWV0YWRhdGEoKVxuICBwdWJsaWMgYWRkV29yZEZpbHRlckZyb21GaWxlKGZpbGVQYXRoOiBzdHJpbmcsXG4gICAgaW5wdXRBY3Rpb24/OiBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbixcbiAgICBvdXRwdXRBY3Rpb24/OiBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbixcbiAgICBpbnB1dEVuYWJsZWQ/OiBib29sZWFuLFxuICAgIG91dHB1dEVuYWJsZWQ/OiBib29sZWFuKTogdm9pZCB7XG4gICAgY29uc3QgZmlsZUNvbnRlbnRzID0gZnMucmVhZEZpbGVTeW5jKGZpbGVQYXRoLCAndXRmOCcpO1xuICAgIGNvbnN0IHdvcmRzID0gZmlsZUNvbnRlbnRzLnRyaW0oKS5zcGxpdCgnLCcpO1xuICAgIGZvciAoY29uc3Qgd29yZCBvZiB3b3JkcykgdGhpcy5hZGRXb3JkRmlsdGVyKHsgdGV4dDogd29yZCwgaW5wdXRBY3Rpb24sIG91dHB1dEFjdGlvbiwgaW5wdXRFbmFibGVkLCBvdXRwdXRFbmFibGVkIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgYSBtYW5hZ2VkIHdvcmQgbGlzdCBmaWx0ZXIgdG8gdGhlIGd1YXJkcmFpbC5cbiAgICogQHBhcmFtIGZpbHRlciBUaGUgbWFuYWdlZCB3b3JkIGxpc3QgZmlsdGVyIHRvIGFkZC5cbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBhZGRNYW5hZ2VkV29yZExpc3RGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLk1hbmFnZWRXb3JkRmlsdGVyKTogdm9pZCB7XG4gICAgdGhpcy52YWxpZGF0ZVNpbmdsZU1hbmFnZWRXb3JkTGlzdEZpbHRlcihmaWx0ZXIpO1xuICAgIHRoaXMubWFuYWdlZFdvcmRMaXN0RmlsdGVycy5wdXNoKGZpbHRlcik7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGEgdmVyc2lvbiBmb3IgdGhlIGd1YXJkcmFpbC5cbiAgICogQHBhcmFtIGRlc2NyaXB0aW9uIFRoZSBkZXNjcmlwdGlvbiBvZiB0aGUgdmVyc2lvbi5cbiAgICogQHJldHVybnMgVGhlIGd1YXJkcmFpbCB2ZXJzaW9uLlxuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGNyZWF0ZVZlcnNpb24oZGVzY3JpcHRpb24/OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGNvbnN0IGNmblZlcnNpb24gPSBuZXcgR3VhcmRyYWlsVmVyc2lvbih0aGlzLCBgR3VhcmRyYWlsVmVyc2lvbi0ke3RoaXMuaGFzaC5zbGljZSgwLCAxNil9YCwge1xuICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uLFxuICAgICAgZ3VhcmRyYWlsOiB0aGlzLFxuICAgIH0pO1xuXG4gICAgdGhpcy51cGRhdGVWZXJzaW9uKGNmblZlcnNpb24uZ3VhcmRyYWlsVmVyc2lvbik7XG4gICAgcmV0dXJuIHRoaXMuZ3VhcmRyYWlsVmVyc2lvbjtcbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBDRk4gR2VuZXJhdG9yc1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGNvbnRlbnQgZmlsdGVycyBhcHBsaWVkIHRvIHRoZSBndWFyZHJhaWwuIFRoaXMgbWV0aG9kIGRlZmVycyB0aGUgY29tcHV0YXRpb25cbiAgICogdG8gc3ludGggdGltZS5cbiAgICovXG4gIHByaXZhdGUgZ2VuZXJhdGVDZm5Db250ZW50UG9saWN5Q29uZmlnKCk6IElSZXNvbHZhYmxlIHtcbiAgICByZXR1cm4gTGF6eS5hbnkoe1xuICAgICAgcHJvZHVjZTogKCkgPT4ge1xuICAgICAgICBpZiAodGhpcy5jb250ZW50RmlsdGVycy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgY29uc3QgY29udGVudFBvbGljeUNvbmZpZzogYmVkcm9jay5DZm5HdWFyZHJhaWwuQ29udGVudFBvbGljeUNvbmZpZ1Byb3BlcnR5ID0ge1xuICAgICAgICAgICAgZmlsdGVyc0NvbmZpZzogdGhpcy5jb250ZW50RmlsdGVycyxcbiAgICAgICAgICAgIC4uLih0aGlzLmNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZyAmJiB7XG4gICAgICAgICAgICAgIGNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZzoge1xuICAgICAgICAgICAgICAgIHRpZXJOYW1lOiB0aGlzLmNvbnRlbnRGaWx0ZXJzVGllckNvbmZpZyxcbiAgICAgICAgICAgICAgfSBhcyBiZWRyb2NrLkNmbkd1YXJkcmFpbC5Db250ZW50RmlsdGVyc1RpZXJDb25maWdQcm9wZXJ0eSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIH07XG5cbiAgICAgICAgICByZXR1cm4gY29udGVudFBvbGljeUNvbmZpZztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHRvcGljIGZpbHRlcnMgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuVG9waWNQb2xpY3koKTogSVJlc29sdmFibGUge1xuICAgIHJldHVybiBMYXp5LmFueSh7XG4gICAgICBwcm9kdWNlOiAoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLmRlbmllZFRvcGljcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgY29uc3QgdG9waWNQb2xpY3lDb25maWc6IGJlZHJvY2suQ2ZuR3VhcmRyYWlsLlRvcGljUG9saWN5Q29uZmlnUHJvcGVydHkgPSB7XG4gICAgICAgICAgICB0b3BpY3NDb25maWc6IHRoaXMuZGVuaWVkVG9waWNzLmZsYXRNYXAoKHRvcGljOiBmaWx0ZXJzLlRvcGljKSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgZGVmaW5pdGlvbjogdG9waWMuZGVmaW5pdGlvbixcbiAgICAgICAgICAgICAgICBuYW1lOiB0b3BpYy5uYW1lLFxuICAgICAgICAgICAgICAgIGV4YW1wbGVzOiB0b3BpYy5leGFtcGxlcyxcbiAgICAgICAgICAgICAgICB0eXBlOiAnREVOWScsXG4gICAgICAgICAgICAgICAgaW5wdXRBY3Rpb246IHRvcGljLmlucHV0QWN0aW9uLFxuICAgICAgICAgICAgICAgIGlucHV0RW5hYmxlZDogdG9waWMuaW5wdXRFbmFibGVkLFxuICAgICAgICAgICAgICAgIG91dHB1dEFjdGlvbjogdG9waWMub3V0cHV0QWN0aW9uLFxuICAgICAgICAgICAgICAgIG91dHB1dEVuYWJsZWQ6IHRvcGljLm91dHB1dEVuYWJsZWQsXG4gICAgICAgICAgICAgIH0gYXMgYmVkcm9jay5DZm5HdWFyZHJhaWwuVG9waWNDb25maWdQcm9wZXJ0eTtcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgLi4uKHRoaXMudG9waWNzVGllckNvbmZpZyAmJiB7XG4gICAgICAgICAgICAgIHRvcGljc1RpZXJDb25maWc6IHtcbiAgICAgICAgICAgICAgICB0aWVyTmFtZTogdGhpcy50b3BpY3NUaWVyQ29uZmlnLFxuICAgICAgICAgICAgICB9IGFzIGJlZHJvY2suQ2ZuR3VhcmRyYWlsLlRvcGljc1RpZXJDb25maWdQcm9wZXJ0eSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIH07XG5cbiAgICAgICAgICByZXR1cm4gdG9waWNQb2xpY3lDb25maWc7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBjb250ZWN0dWFsIGZpbHRlcnMgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuQ29udGV4dHVhbFBvbGljeUNvbmZpZygpOiBJUmVzb2x2YWJsZSB7XG4gICAgcmV0dXJuIExhenkuYW55KHtcbiAgICAgIHByb2R1Y2U6ICgpID0+IHtcbiAgICAgICAgaWYgKHRoaXMuY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBmaWx0ZXJzQ29uZmlnOiB0aGlzLmNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJzLmZsYXRNYXAoKGZpbHRlcjogZmlsdGVycy5Db250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyKSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgdHlwZTogZmlsdGVyLnR5cGUsXG4gICAgICAgICAgICAgICAgdGhyZXNob2xkOiBmaWx0ZXIudGhyZXNob2xkLFxuICAgICAgICAgICAgICAgIGFjdGlvbjogZmlsdGVyLmFjdGlvbixcbiAgICAgICAgICAgICAgICBlbmFibGVkOiBmaWx0ZXIuZW5hYmxlZCxcbiAgICAgICAgICAgICAgfSBhcyBiZWRyb2NrLkNmbkd1YXJkcmFpbC5Db250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyQ29uZmlnUHJvcGVydHk7XG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICB9O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgd29yZCBjb25maWcgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuV29yZFBvbGljeUNvbmZpZygpOiBJUmVzb2x2YWJsZSB7XG4gICAgcmV0dXJuIExhenkuYW55KHtcbiAgICAgIHByb2R1Y2U6ICgpID0+IHtcbiAgICAgICAgaWYgKHRoaXMud29yZEZpbHRlcnMubGVuZ3RoID4gMCB8fCB0aGlzLm1hbmFnZWRXb3JkTGlzdEZpbHRlcnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB3b3Jkc0NvbmZpZzogdGhpcy5nZW5lcmF0ZUNmbldvcmRDb25maWcoKSxcbiAgICAgICAgICAgIG1hbmFnZWRXb3JkTGlzdHNDb25maWc6IHRoaXMuZ2VuZXJhdGVDZm5NYW5hZ2VkV29yZExpc3RzQ29uZmlnKCksXG4gICAgICAgICAgfSBhcyBiZWRyb2NrLkNmbkd1YXJkcmFpbC5Xb3JkUG9saWN5Q29uZmlnUHJvcGVydHk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSB3b3JkIGZpbHRlcnMgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuV29yZENvbmZpZygpOiBJUmVzb2x2YWJsZSB7XG4gICAgcmV0dXJuIExhenkuYW55KFxuICAgICAge1xuICAgICAgICBwcm9kdWNlOiAoKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMud29yZEZpbHRlcnMuZmxhdE1hcCgod29yZDogZmlsdGVycy5Xb3JkRmlsdGVyKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICB0ZXh0OiB3b3JkLnRleHQsXG4gICAgICAgICAgICAgIGlucHV0QWN0aW9uOiB3b3JkLmlucHV0QWN0aW9uLFxuICAgICAgICAgICAgICBpbnB1dEVuYWJsZWQ6IHdvcmQuaW5wdXRFbmFibGVkLFxuICAgICAgICAgICAgICBvdXRwdXRBY3Rpb246IHdvcmQub3V0cHV0QWN0aW9uLFxuICAgICAgICAgICAgICBvdXRwdXRFbmFibGVkOiB3b3JkLm91dHB1dEVuYWJsZWQsXG4gICAgICAgICAgICB9IGFzIGJlZHJvY2suQ2ZuR3VhcmRyYWlsLldvcmRDb25maWdQcm9wZXJ0eTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB7IG9taXRFbXB0eUFycmF5OiB0cnVlIH0sXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSB3b3JkIGZpbHRlcnMgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuTWFuYWdlZFdvcmRMaXN0c0NvbmZpZygpOiBJUmVzb2x2YWJsZSB7XG4gICAgcmV0dXJuIExhenkuYW55KFxuICAgICAge1xuICAgICAgICBwcm9kdWNlOiAoKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMubWFuYWdlZFdvcmRMaXN0RmlsdGVycy5mbGF0TWFwKChmaWx0ZXI6IGZpbHRlcnMuTWFuYWdlZFdvcmRGaWx0ZXIpID0+IHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIHR5cGU6IGZpbHRlci50eXBlLFxuICAgICAgICAgICAgICBpbnB1dEFjdGlvbjogZmlsdGVyLmlucHV0QWN0aW9uLFxuICAgICAgICAgICAgICBpbnB1dEVuYWJsZWQ6IGZpbHRlci5pbnB1dEVuYWJsZWQsXG4gICAgICAgICAgICAgIG91dHB1dEFjdGlvbjogZmlsdGVyLm91dHB1dEFjdGlvbixcbiAgICAgICAgICAgICAgb3V0cHV0RW5hYmxlZDogZmlsdGVyLm91dHB1dEVuYWJsZWQsXG4gICAgICAgICAgICB9IGFzIGJlZHJvY2suQ2ZuR3VhcmRyYWlsLk1hbmFnZWRXb3Jkc0NvbmZpZ1Byb3BlcnR5O1xuICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIHsgb21pdEVtcHR5QXJyYXk6IHRydWUgfSxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHNlbnNpdGl2ZSBpbmZvcm1hdGlvbiBjb25maWcgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuU2Vuc2l0aXZlSW5mb3JtYXRpb25Qb2xpY3lDb25maWcoKTogSVJlc29sdmFibGUge1xuICAgIHJldHVybiBMYXp5LmFueShcbiAgICAgIHtcbiAgICAgICAgcHJvZHVjZTogKCkgPT4ge1xuICAgICAgICAgIGlmICh0aGlzLnJlZ2V4RmlsdGVycy5sZW5ndGggPiAwIHx8IHRoaXMucGlpRmlsdGVycy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICByZWdleGVzQ29uZmlnOiB0aGlzLmdlbmVyYXRlQ2ZuUmVnZXhlc0NvbmZpZygpLFxuICAgICAgICAgICAgICBwaWlFbnRpdGllc0NvbmZpZzogdGhpcy5nZW5lcmF0ZUNmblBpaUVudGl0aWVzQ29uZmlnKCksXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB7IG9taXRFbXB0eUFycmF5OiB0cnVlIH0sXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSByZWdleCBmaWx0ZXJzIGFwcGxpZWQgdG8gdGhlIGd1YXJkcmFpbC4gVGhpcyBtZXRob2QgZGVmZXJzIHRoZSBjb21wdXRhdGlvblxuICAgKiB0byBzeW50aCB0aW1lLlxuICAgKi9cbiAgcHJpdmF0ZSBnZW5lcmF0ZUNmblJlZ2V4ZXNDb25maWcoKTogSVJlc29sdmFibGUge1xuICAgIHJldHVybiBMYXp5LmFueShcbiAgICAgIHtcbiAgICAgICAgcHJvZHVjZTogKCkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLnJlZ2V4RmlsdGVycy5mbGF0TWFwKChyZWdleDogZmlsdGVycy5SZWdleEZpbHRlcikgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgbmFtZTogcmVnZXgubmFtZSxcbiAgICAgICAgICAgICAgZGVzY3JpcHRpb246IHJlZ2V4LmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICBwYXR0ZXJuOiByZWdleC5wYXR0ZXJuLFxuICAgICAgICAgICAgICBhY3Rpb246IHJlZ2V4LmFjdGlvbixcbiAgICAgICAgICAgICAgaW5wdXRBY3Rpb246IHJlZ2V4LmlucHV0QWN0aW9uLFxuICAgICAgICAgICAgICBpbnB1dEVuYWJsZWQ6IHJlZ2V4LmlucHV0RW5hYmxlZCxcbiAgICAgICAgICAgICAgb3V0cHV0QWN0aW9uOiByZWdleC5vdXRwdXRBY3Rpb24sXG4gICAgICAgICAgICAgIG91dHB1dEVuYWJsZWQ6IHJlZ2V4Lm91dHB1dEVuYWJsZWQsXG4gICAgICAgICAgICB9IGFzIGJlZHJvY2suQ2ZuR3VhcmRyYWlsLlJlZ2V4Q29uZmlnUHJvcGVydHk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgeyBvbWl0RW1wdHlBcnJheTogdHJ1ZSB9LFxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgUGlpIGZpbHRlcnMgYXBwbGllZCB0byB0aGUgZ3VhcmRyYWlsLiBUaGlzIG1ldGhvZCBkZWZlcnMgdGhlIGNvbXB1dGF0aW9uXG4gICAqIHRvIHN5bnRoIHRpbWUuXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ2ZuUGlpRW50aXRpZXNDb25maWcoKTogSVJlc29sdmFibGUge1xuICAgIHJldHVybiBMYXp5LmFueShcbiAgICAgIHtcbiAgICAgICAgcHJvZHVjZTogKCkgPT4ge1xuICAgICAgICAgIHJldHVybiB0aGlzLnBpaUZpbHRlcnMuZmxhdE1hcCgoZmlsdGVyOiBmaWx0ZXJzLlBJSUZpbHRlcikgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgdHlwZTogZmlsdGVyLnR5cGUudmFsdWUsXG4gICAgICAgICAgICAgIGFjdGlvbjogZmlsdGVyLmFjdGlvbixcbiAgICAgICAgICAgICAgaW5wdXRBY3Rpb246IGZpbHRlci5pbnB1dEFjdGlvbixcbiAgICAgICAgICAgICAgaW5wdXRFbmFibGVkOiBmaWx0ZXIuaW5wdXRFbmFibGVkLFxuICAgICAgICAgICAgICBvdXRwdXRBY3Rpb246IGZpbHRlci5vdXRwdXRBY3Rpb24sXG4gICAgICAgICAgICAgIG91dHB1dEVuYWJsZWQ6IGZpbHRlci5vdXRwdXRFbmFibGVkLFxuICAgICAgICAgICAgfSBhcyBiZWRyb2NrLkNmbkd1YXJkcmFpbC5QaWlFbnRpdHlDb25maWdQcm9wZXJ0eTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB7IG9taXRFbXB0eUFycmF5OiB0cnVlIH0sXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBjcm9zcy1yZWdpb24gY29uZmlndXJhdGlvbiBmb3IgdGhlIGd1YXJkcmFpbC4gVGhpcyBtZXRob2QgZGVmZXJzIHRoZSBjb21wdXRhdGlvblxuICAgKiB0byBzeW50aCB0aW1lLlxuICAgKi9cbiAgcHJpdmF0ZSBnZW5lcmF0ZUNmbkNyb3NzUmVnaW9uQ29uZmlnKCk6IElSZXNvbHZhYmxlIHtcbiAgICByZXR1cm4gTGF6eS5hbnkoe1xuICAgICAgcHJvZHVjZTogKCkgPT4ge1xuICAgICAgICBpZiAodGhpcy5jcm9zc1JlZ2lvbkNvbmZpZykge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBndWFyZHJhaWxQcm9maWxlQXJuOiB0aGlzLmNyb3NzUmVnaW9uQ29uZmlnLmd1YXJkcmFpbFByb2ZpbGVBcm4sXG4gICAgICAgICAgfSBhcyBiZWRyb2NrLkNmbkd1YXJkcmFpbC5HdWFyZHJhaWxDcm9zc1JlZ2lvbkNvbmZpZ1Byb3BlcnR5O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGEgUmVnZXhGaWx0ZXIgb2JqZWN0IGFuZCBhcHBsaWVzIGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSByZWdleCBmaWx0ZXIgdG8gdmFsaWRhdGUuXG4gICAqIEBwYXJhbSBpbmRleCBPcHRpb25hbCBpbmRleCBmb3IgZXJyb3IgbWVzc2FnZXMgd2hlbiB2YWxpZGF0aW5nIGFycmF5cy5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVSZWdleEZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuUmVnZXhGaWx0ZXIsIGluZGV4PzogbnVtYmVyKTogdm9pZCB7XG4gICAgY29uc3QgcHJlZml4ID0gaW5kZXggIT09IHVuZGVmaW5lZCA/IGBJbnZhbGlkIFJlZ2V4RmlsdGVyIGF0IGluZGV4ICR7aW5kZXh9YCA6ICdJbnZhbGlkIFJlZ2V4RmlsdGVyJztcblxuICAgIC8vIFZhbGlkYXRlIG5hbWU6IGJldHdlZW4gMSBhbmQgMTAwIGNoYXJhY3RlcnNcbiAgICBpZiAoZmlsdGVyLm5hbWUgIT09IHVuZGVmaW5lZCAmJiAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5uYW1lKSkge1xuICAgICAgaWYgKGZpbHRlci5uYW1lLmxlbmd0aCA8IDEpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignUmVnZXhGaWx0ZXJOYW1lVG9vU2hvcnQnLCBgJHtwcmVmaXh9OiBUaGUgZmllbGQgbmFtZSBpcyAke2ZpbHRlci5uYW1lLmxlbmd0aH0gY2hhcmFjdGVycyBsb25nIGJ1dCBtdXN0IGJlIGF0IGxlYXN0IDEgY2hhcmFjdGVyc2AsIHRoaXMpO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5uYW1lLmxlbmd0aCA+IDEwMCkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdSZWdleEZpbHRlck5hbWVUb29Mb25nJywgYCR7cHJlZml4fTogVGhlIGZpZWxkIG5hbWUgaXMgJHtmaWx0ZXIubmFtZS5sZW5ndGh9IGNoYXJhY3RlcnMgbG9uZyBidXQgbXVzdCBiZSBsZXNzIHRoYW4gb3IgZXF1YWwgdG8gMTAwIGNoYXJhY3RlcnNgLCB0aGlzKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBkZXNjcmlwdGlvbjogYmV0d2VlbiAxIGFuZCAxMDAwIGNoYXJhY3RlcnMgKGlmIHByb3ZpZGVkKVxuICAgIGlmIChmaWx0ZXIuZGVzY3JpcHRpb24gIT09IHVuZGVmaW5lZCAmJiAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5kZXNjcmlwdGlvbikpIHtcbiAgICAgIGlmIChmaWx0ZXIuZGVzY3JpcHRpb24ubGVuZ3RoIDwgMSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdSZWdleEZpbHRlckRlc2NyaXB0aW9uVG9vU2hvcnQnLCBgJHtwcmVmaXh9OiBUaGUgZmllbGQgZGVzY3JpcHRpb24gaXMgJHtmaWx0ZXIuZGVzY3JpcHRpb24ubGVuZ3RofSBjaGFyYWN0ZXJzIGxvbmcgYnV0IG11c3QgYmUgYXQgbGVhc3QgMSBjaGFyYWN0ZXJzYCwgdGhpcyk7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLmRlc2NyaXB0aW9uLmxlbmd0aCA+IDEwMDApIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignUmVnZXhGaWx0ZXJEZXNjcmlwdGlvblRvb0xvbmcnLCBgJHtwcmVmaXh9OiBUaGUgZmllbGQgZGVzY3JpcHRpb24gaXMgJHtmaWx0ZXIuZGVzY3JpcHRpb24ubGVuZ3RofSBjaGFyYWN0ZXJzIGxvbmcgYnV0IG11c3QgYmUgbGVzcyB0aGFuIG9yIGVxdWFsIHRvIDEwMDAgY2hhcmFjdGVyc2AsIHRoaXMpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIHBhdHRlcm46IGF0IGxlYXN0IG9uZSBjaGFyYWN0ZXJcbiAgICBpZiAoZmlsdGVyLnBhdHRlcm4gIT09IHVuZGVmaW5lZCAmJiAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5wYXR0ZXJuKSkge1xuICAgICAgaWYgKGZpbHRlci5wYXR0ZXJuLmxlbmd0aCA8IDEpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignUmVnZXhGaWx0ZXJQYXR0ZXJuRW1wdHknLCBgJHtwcmVmaXh9OiBUaGUgZmllbGQgcGF0dGVybiBpcyAke2ZpbHRlci5wYXR0ZXJuLmxlbmd0aH0gY2hhcmFjdGVycyBsb25nIGJ1dCBtdXN0IGJlIGF0IGxlYXN0IDEgY2hhcmFjdGVyc2AsIHRoaXMpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIGFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZVxuICAgIGlmIChmaWx0ZXIuYWN0aW9uICE9PSB1bmRlZmluZWQgJiYgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuYWN0aW9uKSAmJiAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmFjdGlvbikpIHtcbiAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ0ludmFsaWRHdWFyZHJhaWxBY3Rpb24nLCBgJHtwcmVmaXh9OiBhY3Rpb24gbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZWAsIHRoaXMpO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIGlucHV0QWN0aW9uOiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlIChpZiBwcm92aWRlZClcbiAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRBY3Rpb24pICYmXG4gICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIuaW5wdXRBY3Rpb24pKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkSW5wdXRBY3Rpb24nLCBgJHtwcmVmaXh9OiBpbnB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgb3V0cHV0QWN0aW9uOiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlIChpZiBwcm92aWRlZClcbiAgICBpZiAoZmlsdGVyLm91dHB1dEFjdGlvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLm91dHB1dEFjdGlvbikgJiZcbiAgICAgICAgIU9iamVjdC52YWx1ZXMoZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24pLmluY2x1ZGVzKGZpbHRlci5vdXRwdXRBY3Rpb24pKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkT3V0cHV0QWN0aW9uJywgYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBpbnB1dEVuYWJsZWQ6IG11c3QgYmUgYSBib29sZWFuIChpZiBwcm92aWRlZClcbiAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLmlucHV0RW5hYmxlZCkgJiZcbiAgICAgICAgdHlwZW9mIGZpbHRlci5pbnB1dEVuYWJsZWQgIT09ICdib29sZWFuJykge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignSW5wdXRFbmFibGVkTm90Qm9vbGVhbicsIGAke3ByZWZpeH06IGlucHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIG91dHB1dEVuYWJsZWQ6IG11c3QgYmUgYSBib29sZWFuIChpZiBwcm92aWRlZClcbiAgICBpZiAoZmlsdGVyLm91dHB1dEVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5vdXRwdXRFbmFibGVkKSAmJlxuICAgICAgICB0eXBlb2YgZmlsdGVyLm91dHB1dEVuYWJsZWQgIT09ICdib29sZWFuJykge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignT3V0cHV0RW5hYmxlZE5vdEJvb2xlYW4nLCBgJHtwcmVmaXh9OiBvdXRwdXRFbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgfVxuXG4gICAgLy8gQXBwbHkgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMgaWYgbm90IHByb3ZpZGVkXG4gICAgaWYgKGZpbHRlci5pbnB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAoZmlsdGVyIGFzIGFueSkuaW5wdXRBY3Rpb24gPSBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbi5CTE9DSztcbiAgICB9XG4gICAgaWYgKGZpbHRlci5pbnB1dEVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgKGZpbHRlciBhcyBhbnkpLmlucHV0RW5hYmxlZCA9IHRydWU7XG4gICAgfVxuICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgIChmaWx0ZXIgYXMgYW55KS5vdXRwdXRBY3Rpb24gPSBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbi5CTE9DSztcbiAgICB9XG4gICAgaWYgKGZpbHRlci5vdXRwdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgIChmaWx0ZXIgYXMgYW55KS5vdXRwdXRFbmFibGVkID0gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGEgbWVzc2FnaW5nIHByb3BlcnR5IChibG9ja2VkSW5wdXRNZXNzYWdpbmcgb3IgYmxvY2tlZE91dHB1dHNNZXNzYWdpbmcpLlxuICAgKiBAcGFyYW0gdmFsdWUgVGhlIG1lc3NhZ2luZyB2YWx1ZSB0byB2YWxpZGF0ZS5cbiAgICogQHBhcmFtIHByb3BlcnR5TmFtZSBUaGUgbmFtZSBvZiB0aGUgcHJvcGVydHkgYmVpbmcgdmFsaWRhdGVkLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZU1lc3NhZ2luZ1Byb3BlcnR5KHZhbHVlOiBzdHJpbmcgfCB1bmRlZmluZWQsIHByb3BlcnR5TmFtZTogc3RyaW5nKTogdm9pZCB7XG4gICAgaWYgKHZhbHVlICE9PSB1bmRlZmluZWQgJiYgIVRva2VuLmlzVW5yZXNvbHZlZCh2YWx1ZSkpIHtcbiAgICAgIGlmICh2YWx1ZS5sZW5ndGggPCAxKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ01lc3NhZ2luZ1Byb3BlcnR5VG9vU2hvcnQnLCBgSW52YWxpZCAke3Byb3BlcnR5TmFtZX06IFRoZSBmaWVsZCAke3Byb3BlcnR5TmFtZX0gaXMgJHt2YWx1ZS5sZW5ndGh9IGNoYXJhY3RlcnMgbG9uZyBidXQgbXVzdCBiZSBhdCBsZWFzdCAxIGNoYXJhY3RlcnNgLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIGlmICh2YWx1ZS5sZW5ndGggPiA1MDApIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignTWVzc2FnaW5nUHJvcGVydHlUb29Mb25nJywgYEludmFsaWQgJHtwcm9wZXJ0eU5hbWV9OiBUaGUgZmllbGQgJHtwcm9wZXJ0eU5hbWV9IGlzICR7dmFsdWUubGVuZ3RofSBjaGFyYWN0ZXJzIGxvbmcgYnV0IG11c3QgYmUgbGVzcyB0aGFuIG9yIGVxdWFsIHRvIDUwMCBjaGFyYWN0ZXJzYCwgdGhpcyk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyB0aGF0IGNyb3NzLXJlZ2lvbiBjb25maWd1cmF0aW9uIGlzIHByb3ZpZGVkIHdoZW4gU1RBTkRBUkQgdGllciBpcyB1c2VkLlxuICAgKiBAcGFyYW0gcHJvcHMgVGhlIGd1YXJkcmFpbCBwcm9wZXJ0aWVzIHRvIHZhbGlkYXRlLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVRpZXJDb25maWd1cmF0aW9uKHByb3BzOiBHdWFyZHJhaWxQcm9wcyk6IHZvaWQge1xuICAgIGNvbnN0IGNvbnRlbnRUaWVyQ29uZmlnID0gcHJvcHMuY29udGVudEZpbHRlcnNUaWVyQ29uZmlnID8/IGZpbHRlcnMuVGllckNvbmZpZy5DTEFTU0lDO1xuICAgIGNvbnN0IHRvcGljc1RpZXJDb25maWcgPSBwcm9wcy50b3BpY3NUaWVyQ29uZmlnID8/IGZpbHRlcnMuVGllckNvbmZpZy5DTEFTU0lDO1xuICAgIGNvbnN0IGhhc0Nyb3NzUmVnaW9uQ29uZmlnID0gcHJvcHMuY3Jvc3NSZWdpb25Db25maWcgIT09IHVuZGVmaW5lZDtcblxuICAgIC8vIENoZWNrIGlmIFNUQU5EQVJEIHRpZXIgaXMgdXNlZCBmb3IgY29udGVudCBmaWx0ZXJzXG4gICAgaWYgKGNvbnRlbnRUaWVyQ29uZmlnID09PSBmaWx0ZXJzLlRpZXJDb25maWcuU1RBTkRBUkQgJiYgIWhhc0Nyb3NzUmVnaW9uQ29uZmlnKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKFxuICAgICAgICAnU3RhbmRhcmRUaWVyUmVxdWlyZXNDcm9zc1JlZ2lvbicsXG4gICAgICAgICdDcm9zcy1yZWdpb24gY29uZmlndXJhdGlvbiBpcyByZXF1aXJlZCB3aGVuIHVzaW5nIFNUQU5EQVJEIHRpZXIgZm9yIGNvbnRlbnQgZmlsdGVycy4gJyArXG4gICAgICAgICdQbGVhc2UgcHJvdmlkZSBhIGNyb3NzUmVnaW9uQ29uZmlnIHByb3BlcnR5IHdpdGggYSB2YWxpZCBndWFyZHJhaWxQcm9maWxlQXJuLicsXG4gICAgICAgIHRoaXMsXG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIENoZWNrIGlmIFNUQU5EQVJEIHRpZXIgaXMgdXNlZCBmb3IgdG9waWMgZmlsdGVyc1xuICAgIGlmICh0b3BpY3NUaWVyQ29uZmlnID09PSBmaWx0ZXJzLlRpZXJDb25maWcuU1RBTkRBUkQgJiYgIWhhc0Nyb3NzUmVnaW9uQ29uZmlnKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKFxuICAgICAgICAnU3RhbmRhcmRUaWVyUmVxdWlyZXNDcm9zc1JlZ2lvbicsXG4gICAgICAgICdDcm9zcy1yZWdpb24gY29uZmlndXJhdGlvbiBpcyByZXF1aXJlZCB3aGVuIHVzaW5nIFNUQU5EQVJEIHRpZXIgZm9yIHRvcGljIGZpbHRlcnMuICcgK1xuICAgICAgICAnUGxlYXNlIHByb3ZpZGUgYSBjcm9zc1JlZ2lvbkNvbmZpZyBwcm9wZXJ0eSB3aXRoIGEgdmFsaWQgZ3VhcmRyYWlsUHJvZmlsZUFybi4nLFxuICAgICAgICB0aGlzLFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGNvbnRlbnQgZmlsdGVycyBhcnJheSBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIGNvbnRlbnRGaWx0ZXJzIFRoZSBjb250ZW50IGZpbHRlcnMgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlQ29udGVudEZpbHRlcnMoY29udGVudEZpbHRlcnM/OiBmaWx0ZXJzLkNvbnRlbnRGaWx0ZXJbXSk6IHZvaWQge1xuICAgIGlmICghY29udGVudEZpbHRlcnMpIHJldHVybjtcblxuICAgIGNvbnRlbnRGaWx0ZXJzLmZvckVhY2goKGZpbHRlciwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IHByZWZpeCA9IGBJbnZhbGlkIENvbnRlbnRGaWx0ZXIgYXQgaW5kZXggJHtpbmRleH1gO1xuXG4gICAgICAvLyBWYWxpZGF0ZSB0aGF0IHRoZSBmaWx0ZXIgaGFzIHJlcXVpcmVkIHByb3BlcnRpZXNcbiAgICAgIGlmICghZmlsdGVyLnR5cGUpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignQ29udGVudEZpbHRlclR5cGVNaXNzaW5nJywgYCR7cHJlZml4fTogdHlwZSBpcyByZXF1aXJlZGAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBpbnB1dCBzdHJlbmd0aFxuICAgICAgaWYgKGZpbHRlci5pbnB1dFN0cmVuZ3RoICE9PSB1bmRlZmluZWQgJiYgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRTdHJlbmd0aCkpIHtcbiAgICAgICAgaWYgKCFPYmplY3QudmFsdWVzKGZpbHRlcnMuQ29udGVudEZpbHRlclN0cmVuZ3RoKS5pbmNsdWRlcyhmaWx0ZXIuaW5wdXRTdHJlbmd0aCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkSW5wdXRTdHJlbmd0aCcsIGAke3ByZWZpeH06IGlucHV0U3RyZW5ndGggbXVzdCBiZSBhIHZhbGlkIENvbnRlbnRGaWx0ZXJTdHJlbmd0aCB2YWx1ZWAsIHRoaXMpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIG91dHB1dCBzdHJlbmd0aFxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRTdHJlbmd0aCAhPT0gdW5kZWZpbmVkICYmICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLm91dHB1dFN0cmVuZ3RoKSkge1xuICAgICAgICBpZiAoIU9iamVjdC52YWx1ZXMoZmlsdGVycy5Db250ZW50RmlsdGVyU3RyZW5ndGgpLmluY2x1ZGVzKGZpbHRlci5vdXRwdXRTdHJlbmd0aCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkT3V0cHV0U3RyZW5ndGgnLCBgJHtwcmVmaXh9OiBvdXRwdXRTdHJlbmd0aCBtdXN0IGJlIGEgdmFsaWQgQ29udGVudEZpbHRlclN0cmVuZ3RoIHZhbHVlYCwgdGhpcyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXQgbW9kYWxpdGllc1xuICAgICAgaWYgKGZpbHRlci5pbnB1dE1vZGFsaXRpZXMpIHtcbiAgICAgICAgZmlsdGVyLmlucHV0TW9kYWxpdGllcy5mb3JFYWNoKChtb2RhbGl0eSwgbW9kYWxpdHlJbmRleCkgPT4ge1xuICAgICAgICAgIGlmICghT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLk1vZGFsaXR5VHlwZSkuaW5jbHVkZXMobW9kYWxpdHkpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkSW5wdXRNb2RhbGl0eScsIGAke3ByZWZpeH06IGlucHV0TW9kYWxpdGllc1ske21vZGFsaXR5SW5kZXh9XSBtdXN0IGJlIGEgdmFsaWQgTW9kYWxpdHlUeXBlIHZhbHVlYCwgdGhpcyk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgb3V0cHV0IG1vZGFsaXRpZXNcbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0TW9kYWxpdGllcykge1xuICAgICAgICBmaWx0ZXIub3V0cHV0TW9kYWxpdGllcy5mb3JFYWNoKChtb2RhbGl0eSwgbW9kYWxpdHlJbmRleCkgPT4ge1xuICAgICAgICAgIGlmICghT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLk1vZGFsaXR5VHlwZSkuaW5jbHVkZXMobW9kYWxpdHkpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkT3V0cHV0TW9kYWxpdHknLCBgJHtwcmVmaXh9OiBvdXRwdXRNb2RhbGl0aWVzWyR7bW9kYWxpdHlJbmRleH1dIG11c3QgYmUgYSB2YWxpZCBNb2RhbGl0eVR5cGUgdmFsdWVgLCB0aGlzKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBpbnB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5pbnB1dEFjdGlvbikgJiZcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmlucHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkSW5wdXRBY3Rpb24nLCBgJHtwcmVmaXh9OiBpbnB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIG91dHB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEFjdGlvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIub3V0cHV0QWN0aW9uKSAmJlxuICAgICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIub3V0cHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkT3V0cHV0QWN0aW9uJywgYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIuaW5wdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignSW5wdXRFbmFibGVkTm90Qm9vbGVhbicsIGAke3ByZWZpeH06IGlucHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBvdXRwdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLm91dHB1dEVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIGZpbHRlci5vdXRwdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignT3V0cHV0RW5hYmxlZE5vdEJvb2xlYW4nLCBgJHtwcmVmaXh9OiBvdXRwdXRFbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFwcGx5IGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzIGlmIG5vdCBwcm92aWRlZFxuICAgICAgaWYgKGZpbHRlci5pbnB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5pbnB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5pbnB1dEVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuaW5wdXRFbmFibGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEVuYWJsZWQgPSB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBQSUkgZmlsdGVycyBhcnJheSBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIHBpaUZpbHRlcnMgVGhlIFBJSSBmaWx0ZXJzIHRvIHZhbGlkYXRlLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVBpaUZpbHRlcnMocGlpRmlsdGVycz86IGZpbHRlcnMuUElJRmlsdGVyW10pOiB2b2lkIHtcbiAgICBpZiAoIXBpaUZpbHRlcnMpIHJldHVybjtcblxuICAgIHBpaUZpbHRlcnMuZm9yRWFjaCgoZmlsdGVyLCBpbmRleCkgPT4ge1xuICAgICAgY29uc3QgcHJlZml4ID0gYEludmFsaWQgUElJRmlsdGVyIGF0IGluZGV4ICR7aW5kZXh9YDtcblxuICAgICAgLy8gVmFsaWRhdGUgdGhhdCB0aGUgZmlsdGVyIGhhcyByZXF1aXJlZCBwcm9wZXJ0aWVzXG4gICAgICBpZiAoIWZpbHRlci50eXBlKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ1BpaUZpbHRlclR5cGVNaXNzaW5nJywgYCR7cHJlZml4fTogdHlwZSBpcyByZXF1aXJlZGAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICBpZiAoIWZpbHRlci5hY3Rpb24pIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignUGlpRmlsdGVyQWN0aW9uTWlzc2luZycsIGAke3ByZWZpeH06IGFjdGlvbiBpcyByZXF1aXJlZGAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBhY3Rpb24gdmFsdWVzXG4gICAgICBpZiAoIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuYWN0aW9uKSAmJiAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmFjdGlvbikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignSW52YWxpZEd1YXJkcmFpbEFjdGlvbicsIGAke3ByZWZpeH06IGFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIGlmIChmaWx0ZXIuaW5wdXRBY3Rpb24gJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5pbnB1dEFjdGlvbikgJiZcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmlucHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkSW5wdXRBY3Rpb24nLCBgJHtwcmVmaXh9OiBpbnB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIub3V0cHV0QWN0aW9uKSAmJlxuICAgICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIub3V0cHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkT3V0cHV0QWN0aW9uJywgYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIuaW5wdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignSW5wdXRFbmFibGVkTm90Qm9vbGVhbicsIGAke3ByZWZpeH06IGlucHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBvdXRwdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLm91dHB1dEVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIGZpbHRlci5vdXRwdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignT3V0cHV0RW5hYmxlZE5vdEJvb2xlYW4nLCBgJHtwcmVmaXh9OiBvdXRwdXRFbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFwcGx5IGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzIGlmIG5vdCBwcm92aWRlZFxuICAgICAgaWYgKGZpbHRlci5pbnB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5pbnB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5pbnB1dEVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuaW5wdXRFbmFibGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEVuYWJsZWQgPSB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyByZWdleCBmaWx0ZXJzIGFycmF5LlxuICAgKiBAcGFyYW0gcmVnZXhGaWx0ZXJzIFRoZSByZWdleCBmaWx0ZXJzIHRvIHZhbGlkYXRlLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVJlZ2V4RmlsdGVycyhyZWdleEZpbHRlcnM/OiBmaWx0ZXJzLlJlZ2V4RmlsdGVyW10pOiB2b2lkIHtcbiAgICBpZiAoIXJlZ2V4RmlsdGVycykgcmV0dXJuO1xuXG4gICAgcmVnZXhGaWx0ZXJzLmZvckVhY2goKGZpbHRlciwgaW5kZXgpID0+IHtcbiAgICAgIHRoaXMudmFsaWRhdGVSZWdleEZpbHRlcihmaWx0ZXIsIGluZGV4KTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgZGVuaWVkIHRvcGljcyBhcnJheSBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIGRlbmllZFRvcGljcyBUaGUgZGVuaWVkIHRvcGljcyB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVEZW5pZWRUb3BpY3MoZGVuaWVkVG9waWNzPzogZmlsdGVycy5Ub3BpY1tdKTogdm9pZCB7XG4gICAgaWYgKCFkZW5pZWRUb3BpY3MpIHJldHVybjtcblxuICAgIGRlbmllZFRvcGljcy5mb3JFYWNoKCh0b3BpYywgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IHByZWZpeCA9IGBJbnZhbGlkIFRvcGljIGF0IGluZGV4ICR7aW5kZXh9YDtcblxuICAgICAgLy8gVmFsaWRhdGUgdGhhdCB0aGUgdG9waWMgaGFzIHJlcXVpcmVkIHByb3BlcnRpZXNcbiAgICAgIGlmICghdG9waWMubmFtZSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdUb3BpY05hbWVNaXNzaW5nJywgYCR7cHJlZml4fTogbmFtZSBpcyByZXF1aXJlZGAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICBpZiAoIXRvcGljLmRlZmluaXRpb24pIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignVG9waWNEZWZpbml0aW9uTWlzc2luZycsIGAke3ByZWZpeH06IGRlZmluaXRpb24gaXMgcmVxdWlyZWRgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgbmFtZSBsZW5ndGhcbiAgICAgIGlmICghVG9rZW4uaXNVbnJlc29sdmVkKHRvcGljLm5hbWUpICYmIHRvcGljLm5hbWUubGVuZ3RoID4gMTAwKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ1RvcGljTmFtZVRvb0xvbmcnLCBgJHtwcmVmaXh9OiBuYW1lIG11c3QgYmUgMTAwIGNoYXJhY3RlcnMgb3IgbGVzc2AsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBkZWZpbml0aW9uIGxlbmd0aFxuICAgICAgaWYgKCFUb2tlbi5pc1VucmVzb2x2ZWQodG9waWMuZGVmaW5pdGlvbikgJiYgdG9waWMuZGVmaW5pdGlvbi5sZW5ndGggPiAxMDAwKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ1RvcGljRGVmaW5pdGlvblRvb0xvbmcnLCBgJHtwcmVmaXh9OiBkZWZpbml0aW9uIG11c3QgYmUgMTAwMCBjaGFyYWN0ZXJzIG9yIGxlc3NgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgZXhhbXBsZXMgaWYgcHJvdmlkZWRcbiAgICAgIGlmICh0b3BpYy5leGFtcGxlcykge1xuICAgICAgICBpZiAodG9waWMuZXhhbXBsZXMubGVuZ3RoID4gMTAwKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignVG9waWNFeGFtcGxlc1Rvb01hbnknLCBgJHtwcmVmaXh9OiBleGFtcGxlcyBhcnJheSBjYW5ub3QgY29udGFpbiBtb3JlIHRoYW4gMTAwIGV4YW1wbGVzYCwgdGhpcyk7XG4gICAgICAgIH1cblxuICAgICAgICB0b3BpYy5leGFtcGxlcy5mb3JFYWNoKChleGFtcGxlLCBleGFtcGxlSW5kZXgpID0+IHtcbiAgICAgICAgICBpZiAoIVRva2VuLmlzVW5yZXNvbHZlZChleGFtcGxlKSAmJiBleGFtcGxlLmxlbmd0aCA+IDEwMCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignVG9waWNFeGFtcGxlVG9vTG9uZycsIGAke3ByZWZpeH06IGV4YW1wbGVzWyR7ZXhhbXBsZUluZGV4fV0gbXVzdCBiZSAxMDAgY2hhcmFjdGVycyBvciBsZXNzYCwgdGhpcyk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRBY3Rpb246IG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWUgKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKHRvcGljLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKHRvcGljLmlucHV0QWN0aW9uKSAmJlxuICAgICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyh0b3BpYy5pbnB1dEFjdGlvbikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignSW52YWxpZElucHV0QWN0aW9uJywgYCR7cHJlZml4fTogaW5wdXRBY3Rpb24gbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBvdXRwdXRBY3Rpb246IG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWUgKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKHRvcGljLm91dHB1dEFjdGlvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZCh0b3BpYy5vdXRwdXRBY3Rpb24pICYmXG4gICAgICAgICAgIU9iamVjdC52YWx1ZXMoZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24pLmluY2x1ZGVzKHRvcGljLm91dHB1dEFjdGlvbikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignSW52YWxpZE91dHB1dEFjdGlvbicsIGAke3ByZWZpeH06IG91dHB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIGlucHV0RW5hYmxlZDogbXVzdCBiZSBhIGJvb2xlYW4gKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKHRvcGljLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZCh0b3BpYy5pbnB1dEVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIHRvcGljLmlucHV0RW5hYmxlZCAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ0lucHV0RW5hYmxlZE5vdEJvb2xlYW4nLCBgJHtwcmVmaXh9OiBpbnB1dEVuYWJsZWQgbXVzdCBiZSBhIGJvb2xlYW4gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgb3V0cHV0RW5hYmxlZDogbXVzdCBiZSBhIGJvb2xlYW4gKGlmIHByb3ZpZGVkKVxuICAgICAgaWYgKHRvcGljLm91dHB1dEVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQodG9waWMub3V0cHV0RW5hYmxlZCkgJiZcbiAgICAgICAgICB0eXBlb2YgdG9waWMub3V0cHV0RW5hYmxlZCAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ091dHB1dEVuYWJsZWROb3RCb29sZWFuJywgYCR7cHJlZml4fTogb3V0cHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBBcHBseSBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcyBpZiBub3QgcHJvdmlkZWRcbiAgICAgIGlmICh0b3BpYy5pbnB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICh0b3BpYyBhcyBhbnkpLmlucHV0QWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgICB9XG4gICAgICBpZiAodG9waWMuaW5wdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKHRvcGljIGFzIGFueSkuaW5wdXRFbmFibGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmICh0b3BpYy5vdXRwdXRBY3Rpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAodG9waWMgYXMgYW55KS5vdXRwdXRBY3Rpb24gPSBmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbi5CTE9DSztcbiAgICAgIH1cbiAgICAgIGlmICh0b3BpYy5vdXRwdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKHRvcGljIGFzIGFueSkub3V0cHV0RW5hYmxlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGNvbnRleHR1YWwgZ3JvdW5kaW5nIGZpbHRlcnMgYXJyYXkgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBjb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycyBUaGUgY29udGV4dHVhbCBncm91bmRpbmcgZmlsdGVycyB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVDb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycyhjb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycz86IGZpbHRlcnMuQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcltdKTogdm9pZCB7XG4gICAgaWYgKCFjb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVycykgcmV0dXJuO1xuXG4gICAgY29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcnMuZm9yRWFjaCgoZmlsdGVyLCBpbmRleCkgPT4ge1xuICAgICAgY29uc3QgcHJlZml4ID0gYEludmFsaWQgQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlciBhdCBpbmRleCAke2luZGV4fWA7XG5cbiAgICAgIC8vIFZhbGlkYXRlIHRoYXQgdGhlIGZpbHRlciBoYXMgcmVxdWlyZWQgcHJvcGVydGllc1xuICAgICAgaWYgKCFmaWx0ZXIudHlwZSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdDb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyVHlwZU1pc3NpbmcnLCBgJHtwcmVmaXh9OiB0eXBlIGlzIHJlcXVpcmVkYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIGlmIChmaWx0ZXIudGhyZXNob2xkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlclRocmVzaG9sZE1pc3NpbmcnLCBgJHtwcmVmaXh9OiB0aHJlc2hvbGQgaXMgcmVxdWlyZWRgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgdHlwZVxuICAgICAgaWYgKCFPYmplY3QudmFsdWVzKGZpbHRlcnMuQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlclR5cGUpLmluY2x1ZGVzKGZpbHRlci50eXBlKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlclR5cGUnLCBgJHtwcmVmaXh9OiB0eXBlIG11c3QgYmUgYSB2YWxpZCBDb250ZXh0dWFsR3JvdW5kaW5nRmlsdGVyVHlwZSB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSB0aHJlc2hvbGQgcmFuZ2VcbiAgICAgIGlmICghVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci50aHJlc2hvbGQpKSB7XG4gICAgICAgIGlmIChmaWx0ZXIudGhyZXNob2xkIDwgMCB8fCBmaWx0ZXIudGhyZXNob2xkID4gMC45OSkge1xuICAgICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ0NvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJUaHJlc2hvbGRPdXRPZlJhbmdlJywgYCR7cHJlZml4fTogdGhyZXNob2xkIG11c3QgYmUgYmV0d2VlbiAwIGFuZCAwLjk5YCwgdGhpcyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgYWN0aW9uOiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlIChpZiBwcm92aWRlZClcbiAgICAgIGlmIChmaWx0ZXIuYWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5hY3Rpb24pICYmXG4gICAgICAgICAgIU9iamVjdC52YWx1ZXMoZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24pLmluY2x1ZGVzKGZpbHRlci5hY3Rpb24pKSB7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoJ0ludmFsaWRHdWFyZHJhaWxBY3Rpb24nLCBgJHtwcmVmaXh9OiBhY3Rpb24gbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBlbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLmVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIGZpbHRlci5lbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignRW5hYmxlZE5vdEJvb2xlYW4nLCBgJHtwcmVmaXh9OiBlbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFwcGx5IGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzIGlmIG5vdCBwcm92aWRlZFxuICAgICAgaWYgKGZpbHRlci5hY3Rpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuYWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLmVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuZW5hYmxlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIHdvcmQgZmlsdGVycyBhcnJheSBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIHdvcmRGaWx0ZXJzIFRoZSB3b3JkIGZpbHRlcnMgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlV29yZEZpbHRlcnMod29yZEZpbHRlcnM/OiBmaWx0ZXJzLldvcmRGaWx0ZXJbXSk6IHZvaWQge1xuICAgIGlmICghd29yZEZpbHRlcnMpIHJldHVybjtcblxuICAgIHdvcmRGaWx0ZXJzLmZvckVhY2goKGZpbHRlciwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IHByZWZpeCA9IGBJbnZhbGlkIFdvcmRGaWx0ZXIgYXQgaW5kZXggJHtpbmRleH1gO1xuXG4gICAgICAvLyBWYWxpZGF0ZSB0aGF0IHRoZSBmaWx0ZXIgaGFzIHJlcXVpcmVkIHByb3BlcnRpZXNcbiAgICAgIGlmICghZmlsdGVyLnRleHQpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignV29yZEZpbHRlclRleHRNaXNzaW5nJywgYCR7cHJlZml4fTogdGV4dCBpcyByZXF1aXJlZGAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSB0ZXh0IGxlbmd0aFxuICAgICAgaWYgKCFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLnRleHQpICYmIGZpbHRlci50ZXh0Lmxlbmd0aCA+IDEwMCkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdXb3JkRmlsdGVyVGV4dFRvb0xvbmcnLCBgJHtwcmVmaXh9OiB0ZXh0IG11c3QgYmUgMTAwIGNoYXJhY3RlcnMgb3IgbGVzc2AsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBpbnB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5pbnB1dEFjdGlvbikgJiZcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmlucHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkSW5wdXRBY3Rpb24nLCBgJHtwcmVmaXh9OiBpbnB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIG91dHB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEFjdGlvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIub3V0cHV0QWN0aW9uKSAmJlxuICAgICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIub3V0cHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkT3V0cHV0QWN0aW9uJywgYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIuaW5wdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignSW5wdXRFbmFibGVkTm90Qm9vbGVhbicsIGAke3ByZWZpeH06IGlucHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBvdXRwdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLm91dHB1dEVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIGZpbHRlci5vdXRwdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignT3V0cHV0RW5hYmxlZE5vdEJvb2xlYW4nLCBgJHtwcmVmaXh9OiBvdXRwdXRFbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFwcGx5IGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzIGlmIG5vdCBwcm92aWRlZFxuICAgICAgaWYgKGZpbHRlci5pbnB1dEFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5pbnB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5pbnB1dEVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkuaW5wdXRFbmFibGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChmaWx0ZXIub3V0cHV0QWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEFjdGlvbiA9IGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uLkJMT0NLO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRFbmFibGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLm91dHB1dEVuYWJsZWQgPSB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBtYW5hZ2VkIHdvcmQgbGlzdCBmaWx0ZXJzIGFycmF5IGFuZCBhcHBsaWVzIGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzLlxuICAgKiBAcGFyYW0gbWFuYWdlZFdvcmRMaXN0RmlsdGVycyBUaGUgbWFuYWdlZCB3b3JkIGxpc3QgZmlsdGVycyB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVNYW5hZ2VkV29yZExpc3RGaWx0ZXJzKG1hbmFnZWRXb3JkTGlzdEZpbHRlcnM/OiBmaWx0ZXJzLk1hbmFnZWRXb3JkRmlsdGVyW10pOiB2b2lkIHtcbiAgICBpZiAoIW1hbmFnZWRXb3JkTGlzdEZpbHRlcnMpIHJldHVybjtcblxuICAgIG1hbmFnZWRXb3JkTGlzdEZpbHRlcnMuZm9yRWFjaCgoZmlsdGVyLCBpbmRleCkgPT4ge1xuICAgICAgY29uc3QgcHJlZml4ID0gYEludmFsaWQgTWFuYWdlZFdvcmRGaWx0ZXIgYXQgaW5kZXggJHtpbmRleH1gO1xuXG4gICAgICAvLyBWYWxpZGF0ZSB0eXBlOiBtdXN0IGJlIGEgdmFsaWQgTWFuYWdlZFdvcmRGaWx0ZXJUeXBlIHZhbHVlIChpZiBwcm92aWRlZClcbiAgICAgIGlmIChmaWx0ZXIudHlwZSAhPT0gdW5kZWZpbmVkICYmICFPYmplY3QudmFsdWVzKGZpbHRlcnMuTWFuYWdlZFdvcmRGaWx0ZXJUeXBlKS5pbmNsdWRlcyhmaWx0ZXIudHlwZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignSW52YWxpZE1hbmFnZWRXb3JkRmlsdGVyVHlwZScsIGAke3ByZWZpeH06IHR5cGUgbXVzdCBiZSBhIHZhbGlkIE1hbmFnZWRXb3JkRmlsdGVyVHlwZSB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBpbnB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uICE9PSB1bmRlZmluZWQgJiZcbiAgICAgICAgICAhVG9rZW4uaXNVbnJlc29sdmVkKGZpbHRlci5pbnB1dEFjdGlvbikgJiZcbiAgICAgICAgICAhT2JqZWN0LnZhbHVlcyhmaWx0ZXJzLkd1YXJkcmFpbEFjdGlvbikuaW5jbHVkZXMoZmlsdGVyLmlucHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkSW5wdXRBY3Rpb24nLCBgJHtwcmVmaXh9OiBpbnB1dEFjdGlvbiBtdXN0IGJlIGEgdmFsaWQgR3VhcmRyYWlsQWN0aW9uIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIG91dHB1dEFjdGlvbjogbXVzdCBiZSBhIHZhbGlkIEd1YXJkcmFpbEFjdGlvbiB2YWx1ZSAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEFjdGlvbiAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIub3V0cHV0QWN0aW9uKSAmJlxuICAgICAgICAgICFPYmplY3QudmFsdWVzKGZpbHRlcnMuR3VhcmRyYWlsQWN0aW9uKS5pbmNsdWRlcyhmaWx0ZXIub3V0cHV0QWN0aW9uKSkge1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdJbnZhbGlkT3V0cHV0QWN0aW9uJywgYCR7cHJlZml4fTogb3V0cHV0QWN0aW9uIG11c3QgYmUgYSB2YWxpZCBHdWFyZHJhaWxBY3Rpb24gdmFsdWVgLCB0aGlzKTtcbiAgICAgIH1cblxuICAgICAgLy8gVmFsaWRhdGUgaW5wdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgIVRva2VuLmlzVW5yZXNvbHZlZChmaWx0ZXIuaW5wdXRFbmFibGVkKSAmJlxuICAgICAgICAgIHR5cGVvZiBmaWx0ZXIuaW5wdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignSW5wdXRFbmFibGVkTm90Qm9vbGVhbicsIGAke3ByZWZpeH06IGlucHV0RW5hYmxlZCBtdXN0IGJlIGEgYm9vbGVhbiB2YWx1ZWAsIHRoaXMpO1xuICAgICAgfVxuXG4gICAgICAvLyBWYWxpZGF0ZSBvdXRwdXRFbmFibGVkOiBtdXN0IGJlIGEgYm9vbGVhbiAoaWYgcHJvdmlkZWQpXG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEVuYWJsZWQgIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAgICFUb2tlbi5pc1VucmVzb2x2ZWQoZmlsdGVyLm91dHB1dEVuYWJsZWQpICYmXG4gICAgICAgICAgdHlwZW9mIGZpbHRlci5vdXRwdXRFbmFibGVkICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignT3V0cHV0RW5hYmxlZE5vdEJvb2xlYW4nLCBgJHtwcmVmaXh9OiBvdXRwdXRFbmFibGVkIG11c3QgYmUgYSBib29sZWFuIHZhbHVlYCwgdGhpcyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFwcGx5IGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzIGlmIG5vdCBwcm92aWRlZFxuICAgICAgaWYgKGZpbHRlci50eXBlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLnR5cGUgPSBmaWx0ZXJzLk1hbmFnZWRXb3JkRmlsdGVyVHlwZS5QUk9GQU5JVFk7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLmlucHV0QWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgKGZpbHRlciBhcyBhbnkpLmlucHV0QWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLmlucHV0RW5hYmxlZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIChmaWx0ZXIgYXMgYW55KS5pbnB1dEVuYWJsZWQgPSB0cnVlO1xuICAgICAgfVxuICAgICAgaWYgKGZpbHRlci5vdXRwdXRBY3Rpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkub3V0cHV0QWN0aW9uID0gZmlsdGVycy5HdWFyZHJhaWxBY3Rpb24uQkxPQ0s7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLm91dHB1dEVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAoZmlsdGVyIGFzIGFueSkub3V0cHV0RW5hYmxlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGEgc2luZ2xlIGNvbnRlbnQgZmlsdGVyIGFuZCBhcHBsaWVzIGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSBjb250ZW50IGZpbHRlciB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVTaW5nbGVDb250ZW50RmlsdGVyKGZpbHRlcjogZmlsdGVycy5Db250ZW50RmlsdGVyKTogdm9pZCB7XG4gICAgLy8gVXNlIHRoZSBleGlzdGluZyB2YWxpZGF0aW9uIGxvZ2ljIGJ1dCBjYXRjaCBhbmQgcmUtdGhyb3cgd2l0aCBhIGNsZWFyZXIgZXJyb3IgbWVzc2FnZVxuICAgIHRyeSB7XG4gICAgICB0aGlzLnZhbGlkYXRlQ29udGVudEZpbHRlcnMoW2ZpbHRlcl0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBWYWxpZGF0aW9uRXJyb3IpIHtcbiAgICAgICAgLy8gUmVwbGFjZSBcImF0IGluZGV4IDBcIiB3aXRoIGEgY2xlYXJlciBtZXNzYWdlIGZvciBzaW5nbGUgZmlsdGVyIHZhbGlkYXRpb25cbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UucmVwbGFjZSgnIGF0IGluZGV4IDAnLCAnJyk7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoZXJyb3IubmFtZSwgbWVzc2FnZSwgdGhpcyk7XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGEgc2luZ2xlIFBJSSBmaWx0ZXIgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIFBJSSBmaWx0ZXIgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlU2luZ2xlUGlpRmlsdGVyKGZpbHRlcjogZmlsdGVycy5QSUlGaWx0ZXIpOiB2b2lkIHtcbiAgICAvLyBVc2UgdGhlIGV4aXN0aW5nIHZhbGlkYXRpb24gbG9naWMgYnV0IGNhdGNoIGFuZCByZS10aHJvdyB3aXRoIGEgY2xlYXJlciBlcnJvciBtZXNzYWdlXG4gICAgdHJ5IHtcbiAgICAgIHRoaXMudmFsaWRhdGVQaWlGaWx0ZXJzKFtmaWx0ZXJdKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgVmFsaWRhdGlvbkVycm9yKSB7XG4gICAgICAgIC8vIFJlcGxhY2UgXCJhdCBpbmRleCAwXCIgd2l0aCBhIGNsZWFyZXIgbWVzc2FnZSBmb3Igc2luZ2xlIGZpbHRlciB2YWxpZGF0aW9uXG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlLnJlcGxhY2UoJyBhdCBpbmRleCAwJywgJycpO1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGVycm9yLm5hbWUsIG1lc3NhZ2UsIHRoaXMpO1xuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBhIHNpbmdsZSByZWdleCBmaWx0ZXIgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIHJlZ2V4IGZpbHRlciB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVTaW5nbGVSZWdleEZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuUmVnZXhGaWx0ZXIpOiB2b2lkIHtcbiAgICAvLyBVc2UgdGhlIGV4aXN0aW5nIHZhbGlkYXRpb24gbG9naWMgYnV0IGNhdGNoIGFuZCByZS10aHJvdyB3aXRoIGEgY2xlYXJlciBlcnJvciBtZXNzYWdlXG4gICAgdHJ5IHtcbiAgICAgIHRoaXMudmFsaWRhdGVSZWdleEZpbHRlcnMoW2ZpbHRlcl0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBWYWxpZGF0aW9uRXJyb3IpIHtcbiAgICAgICAgLy8gUmVwbGFjZSBcImF0IGluZGV4IDBcIiB3aXRoIGEgY2xlYXJlciBtZXNzYWdlIGZvciBzaW5nbGUgZmlsdGVyIHZhbGlkYXRpb25cbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UucmVwbGFjZSgnIGF0IGluZGV4IDAnLCAnJyk7XG4gICAgICAgIHRocm93IG5ldyBWYWxpZGF0aW9uRXJyb3IoZXJyb3IubmFtZSwgbWVzc2FnZSwgdGhpcyk7XG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGVzIGEgc2luZ2xlIGRlbmllZCB0b3BpYyBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIGZpbHRlciBUaGUgZGVuaWVkIHRvcGljIHRvIHZhbGlkYXRlLlxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVNpbmdsZURlbmllZFRvcGljKGZpbHRlcjogZmlsdGVycy5Ub3BpYyk6IHZvaWQge1xuICAgIC8vIFVzZSB0aGUgZXhpc3RpbmcgdmFsaWRhdGlvbiBsb2dpYyBidXQgY2F0Y2ggYW5kIHJlLXRocm93IHdpdGggYSBjbGVhcmVyIGVycm9yIG1lc3NhZ2VcbiAgICB0cnkge1xuICAgICAgdGhpcy52YWxpZGF0ZURlbmllZFRvcGljcyhbZmlsdGVyXSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIFZhbGlkYXRpb25FcnJvcikge1xuICAgICAgICAvLyBSZXBsYWNlIFwiYXQgaW5kZXggMFwiIHdpdGggYSBjbGVhcmVyIG1lc3NhZ2UgZm9yIHNpbmdsZSBmaWx0ZXIgdmFsaWRhdGlvblxuICAgICAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IubWVzc2FnZS5yZXBsYWNlKCcgYXQgaW5kZXggMCcsICcnKTtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihlcnJvci5uYW1lLCBtZXNzYWdlLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgYSBzaW5nbGUgY29udGV4dHVhbCBncm91bmRpbmcgZmlsdGVyIGFuZCBhcHBsaWVzIGRlZmF1bHQgdmFsdWVzIGZvciBvcHRpb25hbCBwcm9wZXJ0aWVzLlxuICAgKiBAcGFyYW0gZmlsdGVyIFRoZSBjb250ZXh0dWFsIGdyb3VuZGluZyBmaWx0ZXIgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlU2luZ2xlQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuQ29udGV4dHVhbEdyb3VuZGluZ0ZpbHRlcik6IHZvaWQge1xuICAgIC8vIFVzZSB0aGUgZXhpc3RpbmcgdmFsaWRhdGlvbiBsb2dpYyBidXQgY2F0Y2ggYW5kIHJlLXRocm93IHdpdGggYSBjbGVhcmVyIGVycm9yIG1lc3NhZ2VcbiAgICB0cnkge1xuICAgICAgdGhpcy52YWxpZGF0ZUNvbnRleHR1YWxHcm91bmRpbmdGaWx0ZXJzKFtmaWx0ZXJdKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgVmFsaWRhdGlvbkVycm9yKSB7XG4gICAgICAgIC8vIFJlcGxhY2UgXCJhdCBpbmRleCAwXCIgd2l0aCBhIGNsZWFyZXIgbWVzc2FnZSBmb3Igc2luZ2xlIGZpbHRlciB2YWxpZGF0aW9uXG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlLnJlcGxhY2UoJyBhdCBpbmRleCAwJywgJycpO1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGVycm9yLm5hbWUsIG1lc3NhZ2UsIHRoaXMpO1xuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBhIHNpbmdsZSB3b3JkIGZpbHRlciBhbmQgYXBwbGllcyBkZWZhdWx0IHZhbHVlcyBmb3Igb3B0aW9uYWwgcHJvcGVydGllcy5cbiAgICogQHBhcmFtIGZpbHRlciBUaGUgd29yZCBmaWx0ZXIgdG8gdmFsaWRhdGUuXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlU2luZ2xlV29yZEZpbHRlcihmaWx0ZXI6IGZpbHRlcnMuV29yZEZpbHRlcik6IHZvaWQge1xuICAgIC8vIFVzZSB0aGUgZXhpc3RpbmcgdmFsaWRhdGlvbiBsb2dpYyBidXQgY2F0Y2ggYW5kIHJlLXRocm93IHdpdGggYSBjbGVhcmVyIGVycm9yIG1lc3NhZ2VcbiAgICB0cnkge1xuICAgICAgdGhpcy52YWxpZGF0ZVdvcmRGaWx0ZXJzKFtmaWx0ZXJdKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgVmFsaWRhdGlvbkVycm9yKSB7XG4gICAgICAgIC8vIFJlcGxhY2UgXCJhdCBpbmRleCAwXCIgd2l0aCBhIGNsZWFyZXIgbWVzc2FnZSBmb3Igc2luZ2xlIGZpbHRlciB2YWxpZGF0aW9uXG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlLnJlcGxhY2UoJyBhdCBpbmRleCAwJywgJycpO1xuICAgICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKGVycm9yLm5hbWUsIG1lc3NhZ2UsIHRoaXMpO1xuICAgICAgfVxuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBhIHNpbmdsZSBtYW5hZ2VkIHdvcmQgbGlzdCBmaWx0ZXIgYW5kIGFwcGxpZXMgZGVmYXVsdCB2YWx1ZXMgZm9yIG9wdGlvbmFsIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBmaWx0ZXIgVGhlIG1hbmFnZWQgd29yZCBsaXN0IGZpbHRlciB0byB2YWxpZGF0ZS5cbiAgICovXG4gIHByaXZhdGUgdmFsaWRhdGVTaW5nbGVNYW5hZ2VkV29yZExpc3RGaWx0ZXIoZmlsdGVyOiBmaWx0ZXJzLk1hbmFnZWRXb3JkRmlsdGVyKTogdm9pZCB7XG4gICAgLy8gVXNlIHRoZSBleGlzdGluZyB2YWxpZGF0aW9uIGxvZ2ljIGJ1dCBjYXRjaCBhbmQgcmUtdGhyb3cgd2l0aCBhIGNsZWFyZXIgZXJyb3IgbWVzc2FnZVxuICAgIHRyeSB7XG4gICAgICB0aGlzLnZhbGlkYXRlTWFuYWdlZFdvcmRMaXN0RmlsdGVycyhbZmlsdGVyXSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIFZhbGlkYXRpb25FcnJvcikge1xuICAgICAgICAvLyBSZXBsYWNlIFwiYXQgaW5kZXggMFwiIHdpdGggYSBjbGVhcmVyIG1lc3NhZ2UgZm9yIHNpbmdsZSBmaWx0ZXIgdmFsaWRhdGlvblxuICAgICAgICBjb25zdCBtZXNzYWdlID0gZXJyb3IubWVzc2FnZS5yZXBsYWNlKCcgYXQgaW5kZXggMCcsICcnKTtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihlcnJvci5uYW1lLCBtZXNzYWdlLCB0aGlzKTtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxufVxuIl19