"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BedrockFoundationModel = exports.VectorType = void 0;
const jsiiDeprecationWarnings = require("../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
/**
 *  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance
 *  with the License. A copy of the License is located at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  or in the 'license' file accompanying this file. This file is distributed on an 'AS IS' BASIS, WITHOUT WARRANTIES
 *  OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions
 *  and limitations under the License.
 */
const aws_cdk_lib_1 = require("aws-cdk-lib");
const aws_iam_1 = require("aws-cdk-lib/aws-iam");
/**
 * The data type for the vectors when using a model to convert text into vector embeddings.
 * The model must support the specified data type for vector embeddings. Floating-point (float32)
 * is the default data type, and is supported by most models for vector embeddings. See Supported
 * embeddings models for information on the available models and their vector data types.
 */
var VectorType;
(function (VectorType) {
    /**
     * `FLOATING_POINT` convert the data to floating-point (float32) vector embeddings (more precise, but more costly).
     */
    VectorType["FLOATING_POINT"] = "FLOAT32";
    /**
     * `BINARY` convert the data to binary vector embeddings (less precise, but less costly).
     */
    VectorType["BINARY"] = "BINARY";
})(VectorType || (exports.VectorType = VectorType = {}));
/**
 * Bedrock models.
 *
 * If you need to use a model name that doesn't exist as a static member, you
 * can instantiate a `BedrockFoundationModel` object, e.g: `new BedrockFoundationModel('my-model')`.
 */
class BedrockFoundationModel {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.BedrockFoundationModel", version: "2.272.0-alpha.0" };
    /****************************************************************************
     *                            AI21
     ***************************************************************************/
    /**
     * AI21's Jamba 1.5 Large model optimized for text generation tasks.
     * Suitable for complex language understanding and generation tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Optimized for natural language processing
     * - Best for: Content generation, summarization, and complex text analysis
     */
    static AI21_JAMBA_1_5_LARGE_V1 = new BedrockFoundationModel('ai21.jamba-1-5-large-v1:0', {
        supportsAgents: true,
    });
    /**
     * AI21's Jamba 1.5 Mini model, a lighter version optimized for faster processing.
     * Balances performance with efficiency for general text tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Faster response times compared to larger models
     * - Best for: Quick text processing, basic content generation
     */
    static AI21_JAMBA_1_5_MINI_V1 = new BedrockFoundationModel('ai21.jamba-1-5-mini-v1:0', {
        supportsAgents: true,
    });
    /**
     * AI21's Jamba Instruct model, specifically designed for instruction-following tasks.
     * Optimized for understanding and executing specific instructions.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Enhanced instruction understanding
     * - Best for: Task-specific instructions, command processing
     */
    static AI21_JAMBA_INSTRUCT_V1 = new BedrockFoundationModel('ai21.jamba-instruct-v1:0', {
        supportsAgents: true,
    });
    /****************************************************************************
     *                            AMAZON
     ***************************************************************************/
    /**
     * Amazon's Titan Text Express model, optimized for fast text generation.
     * Provides quick responses while maintaining good quality output.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Fast response times
     * - Best for: Real-time applications, chatbots, quick content generation
     */
    static AMAZON_TITAN_TEXT_EXPRESS_V1 = new BedrockFoundationModel('amazon.titan-text-express-v1', {
        supportsAgents: true,
    });
    /**
     * Amazon's Titan Text Premier model, designed for high-quality text generation.
     * Offers enhanced capabilities for complex language tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Advanced language understanding
     * - Best for: Complex content generation, detailed analysis
     */
    static AMAZON_TITAN_PREMIER_V1_0 = new BedrockFoundationModel('amazon.titan-text-premier-v1:0', {
        supportsAgents: true,
    });
    /**
     * Amazon's Nova Micro model, a lightweight model optimized for efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Quick processing tasks, basic language understanding
     */
    static AMAZON_NOVA_MICRO_V1 = new BedrockFoundationModel('amazon.nova-micro-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
        optimizedForAgents: true,
    });
    /**
     * Amazon's Nova Lite model, balancing performance with efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: General-purpose language tasks, moderate complexity
     */
    static AMAZON_NOVA_LITE_V1 = new BedrockFoundationModel('amazon.nova-lite-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
        optimizedForAgents: true,
    });
    /**
     * Amazon's Nova Pro model, offering advanced capabilities for complex tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Complex language tasks, professional applications
     */
    static AMAZON_NOVA_PRO_V1 = new BedrockFoundationModel('amazon.nova-pro-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
        optimizedForAgents: true,
    });
    /**
     * Amazon's Nova Premier model, the most advanced in the Nova series.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: High-end applications, complex analysis, premium performance
     */
    static AMAZON_NOVA_PREMIER_V1 = new BedrockFoundationModel('amazon.nova-premier-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
        optimizedForAgents: true,
    });
    /**
     * Amazon's Titan Embed Text V1 model for text embeddings.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 1536-dimensional vectors
     * - Floating-point vector type
     * - Best for: Text embeddings, semantic search, document similarity
     */
    static TITAN_EMBED_TEXT_V1 = new BedrockFoundationModel('amazon.titan-embed-text-v1', {
        supportsKnowledgeBase: true,
        vectorDimensions: 1536,
        supportedVectorType: [VectorType.FLOATING_POINT],
    });
    /**
     * Amazon's Titan Embed Text V2 model with 1024-dimensional vectors.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 1024-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: High-dimensional embeddings, advanced semantic search
     */
    static TITAN_EMBED_TEXT_V2_1024 = new BedrockFoundationModel('amazon.titan-embed-text-v2:0', {
        supportsKnowledgeBase: true,
        vectorDimensions: 1024,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /**
     * Amazon's Titan Embed Text V2 model with 512-dimensional vectors.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 512-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: Balanced performance and dimensionality
     */
    static TITAN_EMBED_TEXT_V2_512 = new BedrockFoundationModel('amazon.titan-embed-text-v2:0', {
        supportsKnowledgeBase: true,
        vectorDimensions: 512,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /**
     * Amazon's Titan Embed Text V2 model with 256-dimensional vectors.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 256-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: Efficient embeddings with lower dimensionality
     */
    static TITAN_EMBED_TEXT_V2_256 = new BedrockFoundationModel('amazon.titan-embed-text-v2:0', {
        supportsKnowledgeBase: true,
        vectorDimensions: 256,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /****************************************************************************
     *                            ANTHROPIC
     ***************************************************************************/
    /**
     * Anthropic's Claude Haiku 4.5 model, most cost-efficient and fastest.
     * Delivers near-frontier performance with substantially lower cost and faster speeds.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Large-scale deployments, budget-conscious applications, real-time customer service, latency-sensitive use cases
     */
    static ANTHROPIC_CLAUDE_HAIKU_4_5_V1_0 = new BedrockFoundationModel('anthropic.claude-haiku-4-5-20251001-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Sonnet 4.5 model, most intelligent in the Claude 4 series.
     * Demonstrates advancements in agent capabilities with enhanced performance in tool handling,
     * memory management, and context processing. Excels at autonomous long-horizon coding tasks.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Enhanced tool handling and memory management for long-running tasks
     * - Best for: Complex agents, coding, autonomous long-horizon tasks, research and analysis, cybersecurity and finance applications
     */
    static ANTHROPIC_CLAUDE_SONNET_4_5_V1_0 = new BedrockFoundationModel('anthropic.claude-sonnet-4-5-20250929-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4.6 model, the most intelligent model and the world's best model
     * for coding, enterprise agents, and professional work.
     * Supports both 200K and 1M context tokens (with the latter in preview).
     * Excels in agentic workflows, complex coding projects, and enterprise applications
     * requiring sophisticated reasoning.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Financial analysis, cybersecurity, computer use workflows, long-horizon development, multi-tool orchestration
     */
    static ANTHROPIC_CLAUDE_OPUS_4_6_V1 = new BedrockFoundationModel('anthropic.claude-opus-4-6-v1', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4.7 model, Anthropic's most capable generally available model,
     * advancing performance across coding, enterprise workflows, and long-running agentic tasks.
     * Features a 1M token context window, 128K max output tokens, and supports reasoning.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     */
    static ANTHROPIC_CLAUDE_OPUS_4_7 = new BedrockFoundationModel('anthropic.claude-opus-4-7', { supportsAgents: true, supportsCrossRegion: true });
    /**
     * Anthropic's Claude Opus 4.8 model, Anthropic's most intelligent Opus model and
     * best generally available model for coding and agents, with deeper reasoning for
     * enterprise workflows.
     * Features a 1M token context window, 128K max output tokens, and supports reasoning.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     */
    static ANTHROPIC_CLAUDE_OPUS_4_8 = new BedrockFoundationModel('anthropic.claude-opus-4-8', { supportsAgents: true, supportsCrossRegion: true });
    /**
     * Anthropic's Claude Opus 5.5 model, Anthropic's most capable Opus model.
     * Better at coding, knowledge work, and long-running tasks.
     * Features a 1M token context window, 128K max output tokens, and supports reasoning.
     *
     * Only available through the `global`, `us`, `eu`, `au` and `jp` cross-region inference profiles.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     */
    static ANTHROPIC_CLAUDE_OPUS_5_5 = new BedrockFoundationModel('anthropic.claude-opus-5-5', { supportsAgents: true, supportsCrossRegion: true });
    /**
     * Anthropic's Claude Sonnet 5.5 model.
     * Improved coding and knowledge work over Claude Sonnet 5, at a lower cost per task.
     * Features a 1M token context window, 128K max output tokens, and supports reasoning.
     *
     * Only available through the `global` cross-region inference profile.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     */
    static ANTHROPIC_CLAUDE_SONNET_5_5 = new BedrockFoundationModel('anthropic.claude-sonnet-5-5', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Fable 5.1 model, Anthropic's frontier model for ambitious coding,
     * long-horizon agents, and enterprise knowledge work.
     * Features a 1M token context window, 128K max output tokens, and supports reasoning.
     *
     * Only available through the `global` and `us` cross-region inference profiles.
     *
     * Using this model requires opting in to the `aws_review` data
     * retention mode; see the Amazon Bedrock model card for details.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     */
    static ANTHROPIC_CLAUDE_FABLE_5_1 = new BedrockFoundationModel('anthropic.claude-fable-5-1', { supportsAgents: true, supportsCrossRegion: true });
    /**
     * Anthropic's Claude Sonnet 4.6 model.
     * Improved performance for coding, agentic workflows, and browser-based automation.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Coding, agentic workflows, browser-based automation, enterprise applications
     */
    static ANTHROPIC_CLAUDE_SONNET_4_6 = new BedrockFoundationModel('anthropic.claude-sonnet-4-6', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4.5 model, the flagship model released November 2025.
     * Excels at real-world programming tasks, scoring highest on SWE-bench Verified benchmarks.
     * Demonstrates superior performance in long-horizon, goal-directed agentic work with fewer dead-ends.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Software engineering, code migration, agentic workflows, financial modeling, deep research
     */
    static ANTHROPIC_CLAUDE_OPUS_4_5_V1_0 = new BedrockFoundationModel('anthropic.claude-opus-4-5-20251101-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4.1 model, most advanced for coding and agentic applications.
     * Excels at independently planning and executing complex development tasks end-to-end.
     * Drop-in replacement for Opus 4 with superior performance and precision.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Complex end-to-end development, agentic applications, research, advanced reasoning
     */
    static ANTHROPIC_CLAUDE_OPUS_4_1_V1_0 = new BedrockFoundationModel('anthropic.claude-opus-4-1-20250805-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus 4 model, next-generation frontier model.
     * High-performance model for advanced reasoning and complex multi-step tasks.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Advanced reasoning, complex workflows, enterprise applications
     */
    static ANTHROPIC_CLAUDE_OPUS_4_V1_0 = new BedrockFoundationModel('anthropic.claude-opus-4-20250514-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Sonnet 4 model, next-generation frontier model.
     * Advanced model with improved performance for production environments.
     * Balances quality, cost-effectiveness, and responsiveness.
     *
     * Features:
     * - Supports vision (Image input modality)
     * - Cross-region support
     * - Supports Bedrock Agents
     * - Best for: Production applications, complex language tasks, balanced performance and cost
     */
    static ANTHROPIC_CLAUDE_SONNET_4_V1_0 = new BedrockFoundationModel('anthropic.claude-sonnet-4-20250514-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude 3.7 Sonnet model, latest in the Claude 3 series.
     * Advanced language model with enhanced capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Complex reasoning, analysis, and content generation
     */
    static ANTHROPIC_CLAUDE_3_7_SONNET_V1_0 = new BedrockFoundationModel('anthropic.claude-3-7-sonnet-20250219-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: false });
    /**
     * Anthropic's Claude 3.5 Sonnet V2 model, optimized for agent interactions.
     * Enhanced version with improved performance and capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Agent-based applications, complex dialogue
     */
    static ANTHROPIC_CLAUDE_3_5_SONNET_V2_0 = new BedrockFoundationModel('anthropic.claude-3-5-sonnet-20241022-v2:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude 3.5 Sonnet V1 model, balanced performance model.
     * Offers good balance between performance and efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: General language tasks, balanced performance
     */
    static ANTHROPIC_CLAUDE_3_5_SONNET_V1_0 = new BedrockFoundationModel('anthropic.claude-3-5-sonnet-20240620-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude 3.5 Haiku model, optimized for quick responses.
     * Lightweight model focused on speed and efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Fast responses, lightweight processing
     */
    static ANTHROPIC_CLAUDE_3_5_HAIKU_V1_0 = new BedrockFoundationModel('anthropic.claude-3-5-haiku-20241022-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Opus model, designed for advanced tasks.
     * High-performance model with extensive capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Optimized for agents
     * - Best for: Complex reasoning, research, and analysis
     */
    static ANTHROPIC_CLAUDE_OPUS_V1_0 = new BedrockFoundationModel('anthropic.claude-3-opus-20240229-v1:0', { supportsAgents: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Sonnet model, legacy version.
     * Balanced model for general-purpose tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Legacy model with EOL date
     * - Best for: General language tasks, standard applications
     */
    static ANTHROPIC_CLAUDE_SONNET_V1_0 = new BedrockFoundationModel('anthropic.claude-3-sonnet-20240229-v1:0', { supportsAgents: true, supportsCrossRegion: true, legacy: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude Haiku model, optimized for efficiency.
     * Fast and efficient model for lightweight tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Optimized for agents
     * - Best for: Quick responses, simple tasks
     */
    static ANTHROPIC_CLAUDE_HAIKU_V1_0 = new BedrockFoundationModel('anthropic.claude-3-haiku-20240307-v1:0', { supportsAgents: true, supportsCrossRegion: true, optimizedForAgents: true });
    /**
     * Anthropic's Claude V2.1 model, legacy version.
     * Improved version of Claude V2 with enhanced capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Legacy model with EOL date
     * - Optimized for agents
     * - Best for: General language tasks, legacy applications
     */
    static ANTHROPIC_CLAUDE_V2_1 = new BedrockFoundationModel('anthropic.claude-v2:1', {
        supportsAgents: true,
        legacy: true,
        optimizedForAgents: true,
    });
    /**
     * Anthropic's Claude V2 model, legacy version.
     * Original Claude V2 model with broad capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Legacy model with EOL date
     * - Optimized for agents
     * - Best for: General language tasks, legacy applications
     */
    static ANTHROPIC_CLAUDE_V2 = new BedrockFoundationModel('anthropic.claude-v2', {
        supportsAgents: true,
        legacy: true,
        optimizedForAgents: true,
    });
    /**
     * Anthropic's Claude Instant V1.2 model, legacy version.
     * Fast and efficient model optimized for quick responses.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Legacy model with EOL date
     * - Optimized for agents
     * - Best for: Quick responses, simple tasks, legacy applications
     */
    static ANTHROPIC_CLAUDE_INSTANT_V1_2 = new BedrockFoundationModel('anthropic.claude-instant-v1', {
        supportsAgents: true,
        legacy: true,
        optimizedForAgents: true,
    });
    /****************************************************************************
     *                            COHERE
     ***************************************************************************/
    /**
     * Cohere's English embedding model, optimized for English text embeddings.
     * Specialized for semantic understanding of English content.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 1024-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: English text embeddings, semantic search, content similarity
     */
    static COHERE_EMBED_ENGLISH_V3 = new BedrockFoundationModel('cohere.embed-english-v3', {
        supportsKnowledgeBase: true,
        vectorDimensions: 1024,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /**
     * Cohere's Multilingual embedding model, supporting multiple languages.
     * Enables semantic understanding across different languages.
     *
     * Features:
     * - Supports Knowledge Base integration
     * - 1024-dimensional vectors
     * - Supports both floating-point and binary vectors
     * - Best for: Cross-lingual embeddings, multilingual semantic search
     */
    static COHERE_EMBED_MULTILINGUAL_V3 = new BedrockFoundationModel('cohere.embed-multilingual-v3', {
        supportsKnowledgeBase: true,
        vectorDimensions: 1024,
        supportedVectorType: [VectorType.FLOATING_POINT, VectorType.BINARY],
    });
    /****************************************************************************
     *                            DEEPSEEK
     ***************************************************************************/
    /**
     * Deepseek's R1 model, designed for general language understanding.
     * Balanced model for various language tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: General language tasks, content generation
     */
    static DEEPSEEK_R1_V1 = new BedrockFoundationModel('deepseek.r1-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /****************************************************************************
     *                            META
     ***************************************************************************/
    /**
     * Meta's Llama 3 1.8B Instruct model, compact instruction-following model.
     * Efficient model optimized for instruction-based tasks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Lightweight instruction processing, quick responses
     */
    static META_LLAMA_3_1_8B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-1-8b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3 70B Instruct model, large-scale instruction model.
     * High-capacity model for complex language understanding.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Complex instructions, advanced language tasks
     */
    static META_LLAMA_3_1_70B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-1-70b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3.2 11B Instruct model, mid-sized instruction model.
     * Balanced model for general instruction processing.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: General instruction tasks, balanced performance
     */
    static META_LLAMA_3_2_11B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-2-11b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3.2 3B Instruct model, compact efficient model.
     * Lightweight model for basic instruction processing.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Basic instructions, efficient processing
     */
    static META_LLAMA_3_2_3B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-2-3b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3.2 1B Instruct model, ultra-lightweight model.
     * Most compact model in the Llama 3.2 series.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Simple instructions, fastest response times
     */
    static META_LLAMA_3_2_1B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-2-1b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 3.3 70B Instruct model, latest large-scale model.
     * Advanced model with enhanced capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Complex reasoning, advanced language tasks
     */
    static META_LLAMA_3_3_70B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama3-3-70b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 4 Maverick 17B Instruct model, innovative mid-sized model.
     * Specialized for creative and dynamic responses.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Creative tasks, innovative solutions
     */
    static META_LLAMA_4_MAVERICK_17B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama4-maverick-17b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /**
     * Meta's Llama 4 Scout 17B Instruct model, analytical mid-sized model.
     * Focused on precise and analytical responses.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Analytical tasks, precise responses
     */
    static META_LLAMA_4_SCOUT_17B_INSTRUCT_V1 = new BedrockFoundationModel('meta.llama4-scout-17b-instruct-v1:0', {
        supportsAgents: true,
        supportsCrossRegion: true,
    });
    /****************************************************************************
     *                            MISTRAL AI
     ***************************************************************************/
    /**
     * Mistral's 7B Instruct model, efficient instruction-following model.
     * Balanced performance for instruction processing.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Optimized for instruction tasks
     * - Best for: General instruction processing, balanced performance
     */
    static MISTRAL_7B_INSTRUCT_V0 = new BedrockFoundationModel('mistral.mistral-7b-instruct-v0:2', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Mixtral 8x7B Instruct model, mixture-of-experts architecture.
     * Advanced model combining multiple expert networks.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Specialized expert networks
     * - Best for: Complex tasks, diverse language understanding
     */
    static MISTRAL_MIXTRAL_8X7B_INSTRUCT_V0 = new BedrockFoundationModel('mistral.mixtral-8x7b-instruct-v0:1', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Small 2402 model, compact efficient model.
     * Optimized for quick responses and efficiency.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Efficient processing
     * - Best for: Quick responses, basic language tasks
     */
    static MISTRAL_SMALL_2402_V1 = new BedrockFoundationModel('mistral.mistral-small-2402-v1:0', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Large 2402 model, high-capacity language model.
     * Advanced model for complex language understanding.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Enhanced language capabilities
     * - Best for: Complex reasoning, detailed analysis
     */
    static MISTRAL_LARGE_2402_V1 = new BedrockFoundationModel('mistral.mistral-large-2402-v1:0', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Large 2407 model, updated large-scale model.
     * Enhanced version with improved capabilities.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Advanced language processing
     * - Best for: Sophisticated language tasks, complex analysis
     */
    static MISTRAL_LARGE_2407_V1 = new BedrockFoundationModel('mistral.mistral-large-2407-v1:0', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Mistral's Pixtral Large 2502 model, specialized large model.
     * Advanced model with cross-region support.
     *
     * Features:
     * - Supports Bedrock Agents integration
     * - Cross-region support
     * - Best for: Advanced language tasks, distributed applications
     */
    static MISTRAL_PIXTRAL_LARGE_2502_V1 = new BedrockFoundationModel('mistral.pixtral-large-2502-v1:0', {
        supportsAgents: true,
        optimizedForAgents: false,
        supportsCrossRegion: true,
    });
    /****************************************************************************
     *                            OPENAI
     ***************************************************************************/
    /**
     * OpenAI's GPT-5.6 Sol model, the most capable OpenAI model on Bedrock.
     * Frontier reasoning and agentic performance across coding, cybersecurity,
     * and scientific research.
     *
     * Features:
     * - Cross-region support (us. and global. inference profiles only; no in-Region invocation)
     * - Not supported by Bedrock Agents
     * - Best for: Complex reasoning, coding, scientific research
     */
    static OPENAI_GPT_5_6_SOL = new BedrockFoundationModel('openai.gpt-5.6-sol', {
        supportsAgents: false,
        supportsCrossRegion: true,
    });
    /**
     * OpenAI's GPT-5.6 Terra model, balanced performance for production workloads.
     * Competitive with GPT-5.5 at half the cost.
     *
     * Features:
     * - Cross-region support (us., in. and global. inference profiles only; no in-Region invocation)
     * - Not supported by Bedrock Agents
     * - Best for: Everyday production workloads at scale
     */
    static OPENAI_GPT_5_6_TERRA = new BedrockFoundationModel('openai.gpt-5.6-terra', {
        supportsAgents: false,
        supportsCrossRegion: true,
    });
    /**
     * OpenAI's GPT-5.6 Luna model, fast and affordable inference.
     * OpenAI's lowest cost model, built for high-volume tasks.
     *
     * Features:
     * - Cross-region support (us., in. and global. inference profiles only; no in-Region invocation)
     * - Not supported by Bedrock Agents
     * - Best for: Classification, summarization, routing, real-time applications
     */
    static OPENAI_GPT_5_6_LUNA = new BedrockFoundationModel('openai.gpt-5.6-luna', {
        supportsAgents: false,
        supportsCrossRegion: true,
    });
    /**
     * OpenAI's gpt-oss-120b model, 120-billion parameter open-weight model.
     * General-purpose model for text generation, coding, and reasoning tasks.
     *
     * Features:
     * - In-Region invocation
     * - Not supported by Bedrock Agents
     * - Best for: Text generation, coding, reasoning
     */
    static OPENAI_GPT_OSS_120B_V1 = new BedrockFoundationModel('openai.gpt-oss-120b-1:0', {
        supportsAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * OpenAI's gpt-oss-20b model, 20-billion parameter open-weight model.
     * Efficient model for text generation and coding at lower compute cost.
     *
     * Features:
     * - In-Region invocation
     * - Not supported by Bedrock Agents
     * - Best for: Efficient text generation, coding
     */
    static OPENAI_GPT_OSS_20B_V1 = new BedrockFoundationModel('openai.gpt-oss-20b-1:0', {
        supportsAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * OpenAI's GPT OSS Safeguard 120B model, open-weight safety model.
     * Built for content moderation and guardrail enforcement in AI applications.
     *
     * Features:
     * - In-Region invocation
     * - Not supported by Bedrock Agents
     * - Best for: Content moderation, guardrail enforcement
     */
    static OPENAI_GPT_OSS_SAFEGUARD_120B = new BedrockFoundationModel('openai.gpt-oss-safeguard-120b', {
        supportsAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * OpenAI's GPT OSS Safeguard 20B model, compact open-weight safety model.
     * Built for lightweight content moderation and guardrail tasks.
     *
     * Features:
     * - In-Region invocation
     * - Not supported by Bedrock Agents
     * - Best for: Lightweight content moderation, guardrail tasks
     */
    static OPENAI_GPT_OSS_SAFEGUARD_20B = new BedrockFoundationModel('openai.gpt-oss-safeguard-20b', {
        supportsAgents: false,
        supportsCrossRegion: false,
    });
    /**
     * Creates a BedrockFoundationModel from a FoundationModelIdentifier.
     * Use this method when you have a model identifier from the CDK.
     * @param modelId - The foundation model identifier
     * @param props - Optional properties for the model
     * @returns A new BedrockFoundationModel instance
     */
    static fromCdkFoundationModelId(modelId, props = {}) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_BedrockFoundationModelProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.fromCdkFoundationModelId);
            }
            throw error;
        }
        return new BedrockFoundationModel(modelId.modelId, props);
    }
    /**
     * Creates a BedrockFoundationModel from a FoundationModel.
     * Use this method when you have a foundation model from the CDK.
     * @param modelId - The foundation model
     * @param props - Optional properties for the model
     * @returns A new BedrockFoundationModel instance
     */
    static fromCdkFoundationModel(modelId, props = {}) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_BedrockFoundationModelProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, this.fromCdkFoundationModel);
            }
            throw error;
        }
        return new BedrockFoundationModel(modelId.modelId, props);
    }
    /****************************************************************************
     *                            Constructor
     ***************************************************************************/
    /**
     * The unique identifier of the foundation model.
     */
    modelId;
    /**
     * The ARN of the foundation model.
     * Format: arn:${Partition}:bedrock:${Region}::foundation-model/${ResourceId}
     */
    modelArn;
    /**
     * The ARN used for invoking the model.
     * This is the same as modelArn for foundation models.
     */
    invokableArn;
    /**
     * Whether this model supports integration with Bedrock Agents.
     * When true, the model can be used with Bedrock Agents for automated task execution.
     */
    supportsAgents;
    /**
     * Whether this model supports cross-region inference.
     * When true, the model can be used with Cross-Region Inference Profiles.
     */
    supportsCrossRegion;
    /**
     * The dimensionality of the vector embeddings produced by this model.
     * Only applicable for embedding models.
     */
    vectorDimensions;
    /**
     * Whether this model supports integration with Bedrock Knowledge Base.
     * When true, the model can be used for knowledge base operations.
     */
    supportsKnowledgeBase;
    /**
     * The vector types supported by this model for embeddings.
     * Defines whether the model supports floating-point or binary vectors.
     */
    supportedVectorType;
    constructor(value, props = {}) {
        try {
            jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_BedrockFoundationModelProps(props);
        }
        catch (error) {
            if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                Error.captureStackTrace(error, BedrockFoundationModel);
            }
            throw error;
        }
        this.modelId = value;
        this.modelArn = aws_cdk_lib_1.Arn.format({
            partition: aws_cdk_lib_1.Aws.PARTITION,
            service: 'bedrock',
            region: aws_cdk_lib_1.Aws.REGION,
            account: '',
            resource: 'foundation-model',
            resourceName: this.modelId,
            arnFormat: aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME,
        });
        this.invokableArn = this.modelArn;
        this.supportsCrossRegion = props.supportsCrossRegion ?? false;
        this.supportsAgents = props.supportsAgents ?? false;
        this.vectorDimensions = props.vectorDimensions;
        this.supportsKnowledgeBase = props.supportsKnowledgeBase ?? false;
        this.supportedVectorType = props.supportedVectorType;
    }
    toString() {
        return this.modelId;
    }
    /**
     * Returns the ARN of the foundation model in the following format:
     * `arn:${Partition}:bedrock:${Region}::foundation-model/${ResourceId}`
     */
    asArn() {
        return this.modelArn;
    }
    /**
     * Returns the IModel
     */
    asIModel() {
        return this;
    }
    /**
     * Gives the appropriate policies to invoke and use the Foundation Model in the stack region.
     * [disable-awslint:no-grants]
     */
    grantInvoke(grantee) {
        const grant = aws_iam_1.Grant.addToPrincipal({
            grantee: grantee,
            actions: ['bedrock:InvokeModel*', 'bedrock:GetFoundationModel'],
            resourceArns: [this.invokableArn],
        });
        return grant;
    }
    /**
     * Gives the appropriate policies to invoke and use the Foundation Model in all regions.
     * [disable-awslint:no-grants]
     */
    grantInvokeAllRegions(grantee) {
        const invokableArn = aws_cdk_lib_1.Arn.format({
            partition: aws_cdk_lib_1.Aws.PARTITION,
            service: 'bedrock',
            region: '*',
            account: '',
            resource: 'foundation-model',
            resourceName: this.modelId,
            arnFormat: aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME,
        });
        return aws_iam_1.Grant.addToPrincipal({
            grantee: grantee,
            actions: ['bedrock:InvokeModel*', 'bedrock:GetFoundationModel'],
            resourceArns: [invokableArn],
        });
    }
}
exports.BedrockFoundationModel = BedrockFoundationModel;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kZWxzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibW9kZWxzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUE7Ozs7Ozs7Ozs7O0dBV0c7QUFFSCw2Q0FBa0Q7QUFHbEQsaURBQTRDO0FBRTVDOzs7OztHQUtHO0FBQ0gsSUFBWSxVQVNYO0FBVEQsV0FBWSxVQUFVO0lBQ3BCOztPQUVHO0lBQ0gsd0NBQTBCLENBQUE7SUFDMUI7O09BRUc7SUFDSCwrQkFBaUIsQ0FBQTtBQUNuQixDQUFDLEVBVFcsVUFBVSwwQkFBVixVQUFVLFFBU3JCO0FBa0ZEOzs7OztHQUtHO0FBQ0gsTUFBYSxzQkFBc0I7O0lBQ2pDOztpRkFFNkU7SUFFN0U7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsdUJBQXVCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDekUsMkJBQTJCLEVBQzNCO1FBQ0UsY0FBYyxFQUFFLElBQUk7S0FDckIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsc0JBQXNCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDeEUsMEJBQTBCLEVBQzFCO1FBQ0UsY0FBYyxFQUFFLElBQUk7S0FDckIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsc0JBQXNCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDeEUsMEJBQTBCLEVBQzFCO1FBQ0UsY0FBYyxFQUFFLElBQUk7S0FDckIsQ0FDRixDQUFDO0lBQ0Y7O2lGQUU2RTtJQUU3RTs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSw0QkFBNEIsR0FBRyxJQUFJLHNCQUFzQixDQUM5RSw4QkFBOEIsRUFDOUI7UUFDRSxjQUFjLEVBQUUsSUFBSTtLQUNyQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSx5QkFBeUIsR0FBRyxJQUFJLHNCQUFzQixDQUMzRSxnQ0FBZ0MsRUFDaEM7UUFDRSxjQUFjLEVBQUUsSUFBSTtLQUNyQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSxvQkFBb0IsR0FBRyxJQUFJLHNCQUFzQixDQUN0RSx3QkFBd0IsRUFDeEI7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO1FBQ3pCLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsbUJBQW1CLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQyx1QkFBdUIsRUFBRTtRQUMvRixjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO1FBQ3pCLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FBQyxDQUFDO0lBRUg7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsa0JBQWtCLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQyxzQkFBc0IsRUFBRTtRQUM3RixjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO1FBQ3pCLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FBQyxDQUFDO0lBRUg7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsc0JBQXNCLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQywwQkFBMEIsRUFBRTtRQUNyRyxjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO1FBQ3pCLGtCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FBQyxDQUFDO0lBRUg7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsbUJBQW1CLEdBQUcsSUFBSSxzQkFBc0IsQ0FDckUsNEJBQTRCLEVBQzVCO1FBQ0UscUJBQXFCLEVBQUUsSUFBSTtRQUMzQixnQkFBZ0IsRUFBRSxJQUFJO1FBQ3RCLG1CQUFtQixFQUFFLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQztLQUNqRCxDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSx3QkFBd0IsR0FBRyxJQUFJLHNCQUFzQixDQUMxRSw4QkFBOEIsRUFDOUI7UUFDRSxxQkFBcUIsRUFBRSxJQUFJO1FBQzNCLGdCQUFnQixFQUFFLElBQUk7UUFDdEIsbUJBQW1CLEVBQUUsQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUM7S0FDcEUsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsdUJBQXVCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDekUsOEJBQThCLEVBQzlCO1FBQ0UscUJBQXFCLEVBQUUsSUFBSTtRQUMzQixnQkFBZ0IsRUFBRSxHQUFHO1FBQ3JCLG1CQUFtQixFQUFFLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDO0tBQ3BFLENBQ0YsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLHVCQUF1QixHQUFHLElBQUksc0JBQXNCLENBQ3pFLDhCQUE4QixFQUM5QjtRQUNFLHFCQUFxQixFQUFFLElBQUk7UUFDM0IsZ0JBQWdCLEVBQUUsR0FBRztRQUNyQixtQkFBbUIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQztLQUNwRSxDQUNGLENBQUM7SUFDRjs7aUZBRTZFO0lBRTdFOzs7Ozs7Ozs7T0FTRztJQUNJLE1BQU0sQ0FBVSwrQkFBK0IsR0FBRyxJQUFJLHNCQUFzQixDQUNqRiwwQ0FBMEMsRUFDMUMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FDOUUsQ0FBQztJQUVGOzs7Ozs7Ozs7OztPQVdHO0lBQ0ksTUFBTSxDQUFVLGdDQUFnQyxHQUFHLElBQUksc0JBQXNCLENBQ2xGLDJDQUEyQyxFQUMzQyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUM5RSxDQUFDO0lBRUY7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0ksTUFBTSxDQUFVLDRCQUE0QixHQUFHLElBQUksc0JBQXNCLENBQzlFLDhCQUE4QixFQUM5QixFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUM5RSxDQUFDO0lBRUY7Ozs7Ozs7OztPQVNHO0lBQ0ksTUFBTSxDQUFVLHlCQUF5QixHQUFHLElBQUksc0JBQXNCLENBQzNFLDJCQUEyQixFQUMzQixFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLENBQ3BELENBQUM7SUFFRjs7Ozs7Ozs7OztPQVVHO0lBQ0ksTUFBTSxDQUFVLHlCQUF5QixHQUFHLElBQUksc0JBQXNCLENBQzNFLDJCQUEyQixFQUMzQixFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLENBQ3BELENBQUM7SUFFRjs7Ozs7Ozs7Ozs7T0FXRztJQUNJLE1BQU0sQ0FBVSx5QkFBeUIsR0FBRyxJQUFJLHNCQUFzQixDQUMzRSwyQkFBMkIsRUFDM0IsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxDQUNwRCxDQUFDO0lBRUY7Ozs7Ozs7Ozs7O09BV0c7SUFDSSxNQUFNLENBQVUsMkJBQTJCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDN0UsNkJBQTZCLEVBQzdCLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7Ozs7Ozs7T0FjRztJQUNJLE1BQU0sQ0FBVSwwQkFBMEIsR0FBRyxJQUFJLHNCQUFzQixDQUM1RSw0QkFBNEIsRUFDNUIsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxDQUNwRCxDQUFDO0lBRUY7Ozs7Ozs7OztPQVNHO0lBQ0ksTUFBTSxDQUFVLDJCQUEyQixHQUFHLElBQUksc0JBQXNCLENBQzdFLDZCQUE2QixFQUM3QixFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUM5RSxDQUFDO0lBRUY7Ozs7Ozs7Ozs7T0FVRztJQUNJLE1BQU0sQ0FBVSw4QkFBOEIsR0FBRyxJQUFJLHNCQUFzQixDQUNoRix5Q0FBeUMsRUFDekMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FDOUUsQ0FBQztJQUVGOzs7Ozs7Ozs7O09BVUc7SUFDSSxNQUFNLENBQVUsOEJBQThCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDaEYseUNBQXlDLEVBQ3pDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsNEJBQTRCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDOUUsdUNBQXVDLEVBQ3ZDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7OztPQVVHO0lBQ0ksTUFBTSxDQUFVLDhCQUE4QixHQUFHLElBQUksc0JBQXNCLENBQ2hGLHlDQUF5QyxFQUN6QyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUM5RSxDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsZ0NBQWdDLEdBQUcsSUFBSSxzQkFBc0IsQ0FDbEYsMkNBQTJDLEVBRTNDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsS0FBSyxFQUFFLENBQy9FLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsZ0NBQWdDLEdBQUcsSUFBSSxzQkFBc0IsQ0FDbEYsMkNBQTJDLEVBQzNDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsZ0NBQWdDLEdBQUcsSUFBSSxzQkFBc0IsQ0FDbEYsMkNBQTJDLEVBQzNDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsK0JBQStCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDakYsMENBQTBDLEVBQzFDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSwwQkFBMEIsR0FBRyxJQUFJLHNCQUFzQixDQUM1RSx1Q0FBdUMsRUFDdkMsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUNuRCxDQUFDO0lBRUY7Ozs7Ozs7OztPQVNHO0lBQ0ksTUFBTSxDQUFVLDRCQUE0QixHQUFHLElBQUksc0JBQXNCLENBQzlFLHlDQUF5QyxFQUN6QyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzVGLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsMkJBQTJCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDN0Usd0NBQXdDLEVBQ3hDLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQzlFLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUscUJBQXFCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDdkUsdUJBQXVCLEVBQ3ZCO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsTUFBTSxFQUFFLElBQUk7UUFDWixrQkFBa0IsRUFBRSxJQUFJO0tBQ3pCLENBQ0YsQ0FBQztJQUVGOzs7Ozs7Ozs7T0FTRztJQUNJLE1BQU0sQ0FBVSxtQkFBbUIsR0FBRyxJQUFJLHNCQUFzQixDQUFDLHFCQUFxQixFQUFFO1FBQzdGLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLE1BQU0sRUFBRSxJQUFJO1FBQ1osa0JBQWtCLEVBQUUsSUFBSTtLQUN6QixDQUFDLENBQUM7SUFFSDs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsNkJBQTZCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDL0UsNkJBQTZCLEVBQzdCO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsTUFBTSxFQUFFLElBQUk7UUFDWixrQkFBa0IsRUFBRSxJQUFJO0tBQ3pCLENBQ0YsQ0FBQztJQUVGOztpRkFFNkU7SUFFN0U7Ozs7Ozs7OztPQVNHO0lBQ0ksTUFBTSxDQUFVLHVCQUF1QixHQUFHLElBQUksc0JBQXNCLENBQ3pFLHlCQUF5QixFQUN6QjtRQUNFLHFCQUFxQixFQUFFLElBQUk7UUFDM0IsZ0JBQWdCLEVBQUUsSUFBSTtRQUN0QixtQkFBbUIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQztLQUNwRSxDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7O09BU0c7SUFDSSxNQUFNLENBQVUsNEJBQTRCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDOUUsOEJBQThCLEVBQzlCO1FBQ0UscUJBQXFCLEVBQUUsSUFBSTtRQUMzQixnQkFBZ0IsRUFBRSxJQUFJO1FBQ3RCLG1CQUFtQixFQUFFLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDO0tBQ3BFLENBQ0YsQ0FBQztJQUNGOztpRkFFNkU7SUFFN0U7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsY0FBYyxHQUFHLElBQUksc0JBQXNCLENBQUMsa0JBQWtCLEVBQUU7UUFDckYsY0FBYyxFQUFFLElBQUk7UUFDcEIsbUJBQW1CLEVBQUUsSUFBSTtLQUMxQixDQUFDLENBQUM7SUFFSDs7aUZBRTZFO0lBRTdFOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLDZCQUE2QixHQUFHLElBQUksc0JBQXNCLENBQy9FLGdDQUFnQyxFQUNoQztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLG1CQUFtQixFQUFFLElBQUk7S0FDMUIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsOEJBQThCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDaEYsaUNBQWlDLEVBQ2pDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsbUJBQW1CLEVBQUUsSUFBSTtLQUMxQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSw4QkFBOEIsR0FBRyxJQUFJLHNCQUFzQixDQUNoRixpQ0FBaUMsRUFDakM7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO0tBQzFCLENBQ0YsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLDZCQUE2QixHQUFHLElBQUksc0JBQXNCLENBQy9FLGdDQUFnQyxFQUNoQztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLG1CQUFtQixFQUFFLElBQUk7S0FDMUIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsNkJBQTZCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDL0UsZ0NBQWdDLEVBQ2hDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsbUJBQW1CLEVBQUUsSUFBSTtLQUMxQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSw4QkFBOEIsR0FBRyxJQUFJLHNCQUFzQixDQUNoRixpQ0FBaUMsRUFDakM7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixtQkFBbUIsRUFBRSxJQUFJO0tBQzFCLENBQ0YsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLHFDQUFxQyxHQUFHLElBQUksc0JBQXNCLENBQ3ZGLHdDQUF3QyxFQUN4QztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLG1CQUFtQixFQUFFLElBQUk7S0FDMUIsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsa0NBQWtDLEdBQUcsSUFBSSxzQkFBc0IsQ0FDcEYscUNBQXFDLEVBQ3JDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsbUJBQW1CLEVBQUUsSUFBSTtLQUMxQixDQUNGLENBQUM7SUFDRjs7aUZBRTZFO0lBRTdFOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLHNCQUFzQixHQUFHLElBQUksc0JBQXNCLENBQ3hFLGtDQUFrQyxFQUNsQztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLGtCQUFrQixFQUFFLEtBQUs7UUFDekIsbUJBQW1CLEVBQUUsS0FBSztLQUMzQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSxnQ0FBZ0MsR0FBRyxJQUFJLHNCQUFzQixDQUNsRixvQ0FBb0MsRUFDcEM7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixrQkFBa0IsRUFBRSxLQUFLO1FBQ3pCLG1CQUFtQixFQUFFLEtBQUs7S0FDM0IsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUscUJBQXFCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDdkUsaUNBQWlDLEVBQ2pDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsa0JBQWtCLEVBQUUsS0FBSztRQUN6QixtQkFBbUIsRUFBRSxLQUFLO0tBQzNCLENBQ0YsQ0FBQztJQUVGOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLHFCQUFxQixHQUFHLElBQUksc0JBQXNCLENBQ3ZFLGlDQUFpQyxFQUNqQztRQUNFLGNBQWMsRUFBRSxJQUFJO1FBQ3BCLGtCQUFrQixFQUFFLEtBQUs7UUFDekIsbUJBQW1CLEVBQUUsS0FBSztLQUMzQixDQUNGLENBQUM7SUFFRjs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSxxQkFBcUIsR0FBRyxJQUFJLHNCQUFzQixDQUN2RSxpQ0FBaUMsRUFDakM7UUFDRSxjQUFjLEVBQUUsSUFBSTtRQUNwQixrQkFBa0IsRUFBRSxLQUFLO1FBQ3pCLG1CQUFtQixFQUFFLEtBQUs7S0FDM0IsQ0FDRixDQUFDO0lBRUY7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsNkJBQTZCLEdBQUcsSUFBSSxzQkFBc0IsQ0FDL0UsaUNBQWlDLEVBQ2pDO1FBQ0UsY0FBYyxFQUFFLElBQUk7UUFDcEIsa0JBQWtCLEVBQUUsS0FBSztRQUN6QixtQkFBbUIsRUFBRSxJQUFJO0tBQzFCLENBQ0YsQ0FBQztJQUVGOztpRkFFNkU7SUFFN0U7Ozs7Ozs7OztPQVNHO0lBQ0ksTUFBTSxDQUFVLGtCQUFrQixHQUFHLElBQUksc0JBQXNCLENBQUMsb0JBQW9CLEVBQUU7UUFDM0YsY0FBYyxFQUFFLEtBQUs7UUFDckIsbUJBQW1CLEVBQUUsSUFBSTtLQUMxQixDQUFDLENBQUM7SUFFSDs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSxvQkFBb0IsR0FBRyxJQUFJLHNCQUFzQixDQUFDLHNCQUFzQixFQUFFO1FBQy9GLGNBQWMsRUFBRSxLQUFLO1FBQ3JCLG1CQUFtQixFQUFFLElBQUk7S0FDMUIsQ0FBQyxDQUFDO0lBRUg7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsbUJBQW1CLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQyxxQkFBcUIsRUFBRTtRQUM3RixjQUFjLEVBQUUsS0FBSztRQUNyQixtQkFBbUIsRUFBRSxJQUFJO0tBQzFCLENBQUMsQ0FBQztJQUVIOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLHNCQUFzQixHQUFHLElBQUksc0JBQXNCLENBQUMseUJBQXlCLEVBQUU7UUFDcEcsY0FBYyxFQUFFLEtBQUs7UUFDckIsbUJBQW1CLEVBQUUsS0FBSztLQUMzQixDQUFDLENBQUM7SUFFSDs7Ozs7Ozs7T0FRRztJQUNJLE1BQU0sQ0FBVSxxQkFBcUIsR0FBRyxJQUFJLHNCQUFzQixDQUFDLHdCQUF3QixFQUFFO1FBQ2xHLGNBQWMsRUFBRSxLQUFLO1FBQ3JCLG1CQUFtQixFQUFFLEtBQUs7S0FDM0IsQ0FBQyxDQUFDO0lBRUg7Ozs7Ozs7O09BUUc7SUFDSSxNQUFNLENBQVUsNkJBQTZCLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQywrQkFBK0IsRUFBRTtRQUNqSCxjQUFjLEVBQUUsS0FBSztRQUNyQixtQkFBbUIsRUFBRSxLQUFLO0tBQzNCLENBQUMsQ0FBQztJQUVIOzs7Ozs7OztPQVFHO0lBQ0ksTUFBTSxDQUFVLDRCQUE0QixHQUFHLElBQUksc0JBQXNCLENBQUMsOEJBQThCLEVBQUU7UUFDL0csY0FBYyxFQUFFLEtBQUs7UUFDckIsbUJBQW1CLEVBQUUsS0FBSztLQUMzQixDQUFDLENBQUM7SUFFSDs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsd0JBQXdCLENBQ3BDLE9BQWtDLEVBQ2xDLFFBQXFDLEVBQUU7Ozs7Ozs7Ozs7UUFFdkMsT0FBTyxJQUFJLHNCQUFzQixDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDM0Q7SUFDRDs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsc0JBQXNCLENBQ2xDLE9BQXdCLEVBQ3hCLFFBQXFDLEVBQUU7Ozs7Ozs7Ozs7UUFFdkMsT0FBTyxJQUFJLHNCQUFzQixDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDM0Q7SUFFRDs7aUZBRTZFO0lBQzdFOztPQUVHO0lBQ2EsT0FBTyxDQUFTO0lBRWhDOzs7T0FHRztJQUNhLFFBQVEsQ0FBUztJQUVqQzs7O09BR0c7SUFDYSxZQUFZLENBQVM7SUFFckM7OztPQUdHO0lBQ2EsY0FBYyxDQUFVO0lBRXhDOzs7T0FHRztJQUNhLG1CQUFtQixDQUFVO0lBRTdDOzs7T0FHRztJQUNhLGdCQUFnQixDQUFVO0lBRTFDOzs7T0FHRztJQUNhLHFCQUFxQixDQUFVO0lBRS9DOzs7T0FHRztJQUNhLG1CQUFtQixDQUFnQjtJQUNuRCxZQUFZLEtBQWEsRUFBRSxRQUFxQyxFQUFFOzs7Ozs7K0NBOWpDdkQsc0JBQXNCOzs7O1FBK2pDL0IsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7UUFDckIsSUFBSSxDQUFDLFFBQVEsR0FBRyxpQkFBRyxDQUFDLE1BQU0sQ0FBQztZQUN6QixTQUFTLEVBQUUsaUJBQUcsQ0FBQyxTQUFTO1lBQ3hCLE9BQU8sRUFBRSxTQUFTO1lBQ2xCLE1BQU0sRUFBRSxpQkFBRyxDQUFDLE1BQU07WUFDbEIsT0FBTyxFQUFFLEVBQUU7WUFDWCxRQUFRLEVBQUUsa0JBQWtCO1lBQzVCLFlBQVksRUFBRSxJQUFJLENBQUMsT0FBTztZQUMxQixTQUFTLEVBQUUsdUJBQVMsQ0FBQyxtQkFBbUI7U0FDekMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQ2xDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxLQUFLLENBQUMsbUJBQW1CLElBQUksS0FBSyxDQUFDO1FBQzlELElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDLGNBQWMsSUFBSSxLQUFLLENBQUM7UUFDcEQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQztRQUMvQyxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDLHFCQUFxQixJQUFJLEtBQUssQ0FBQztRQUNsRSxJQUFJLENBQUMsbUJBQW1CLEdBQUcsS0FBSyxDQUFDLG1CQUFtQixDQUFDO0tBQ3REO0lBRUQsUUFBUTtRQUNOLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQztLQUNyQjtJQUVEOzs7T0FHRztJQUNILEtBQUs7UUFDSCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7S0FDdEI7SUFFRDs7T0FFRztJQUNILFFBQVE7UUFDTixPQUFPLElBQUksQ0FBQztLQUNiO0lBRUQ7OztPQUdHO0lBQ0ksV0FBVyxDQUFDLE9BQW1CO1FBQ3BDLE1BQU0sS0FBSyxHQUFHLGVBQUssQ0FBQyxjQUFjLENBQUM7WUFDakMsT0FBTyxFQUFFLE9BQU87WUFDaEIsT0FBTyxFQUFFLENBQUMsc0JBQXNCLEVBQUUsNEJBQTRCLENBQUM7WUFDL0QsWUFBWSxFQUFFLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztTQUNsQyxDQUFDLENBQUM7UUFDSCxPQUFPLEtBQUssQ0FBQztLQUNkO0lBRUQ7OztPQUdHO0lBQ0kscUJBQXFCLENBQUMsT0FBbUI7UUFDOUMsTUFBTSxZQUFZLEdBQUcsaUJBQUcsQ0FBQyxNQUFNLENBQUM7WUFDOUIsU0FBUyxFQUFFLGlCQUFHLENBQUMsU0FBUztZQUN4QixPQUFPLEVBQUUsU0FBUztZQUNsQixNQUFNLEVBQUUsR0FBRztZQUNYLE9BQU8sRUFBRSxFQUFFO1lBQ1gsUUFBUSxFQUFFLGtCQUFrQjtZQUM1QixZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU87WUFDMUIsU0FBUyxFQUFFLHVCQUFTLENBQUMsbUJBQW1CO1NBQ3pDLENBQUMsQ0FBQztRQUVILE9BQU8sZUFBSyxDQUFDLGNBQWMsQ0FBQztZQUMxQixPQUFPLEVBQUUsT0FBTztZQUNoQixPQUFPLEVBQUUsQ0FBQyxzQkFBc0IsRUFBRSw0QkFBNEIsQ0FBQztZQUMvRCxZQUFZLEVBQUUsQ0FBQyxZQUFZLENBQUM7U0FDN0IsQ0FBQyxDQUFDO0tBQ0o7O0FBcm9DSCx3REFzb0NDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiAgQ29weXJpZ2h0IEFtYXpvbi5jb20sIEluYy4gb3IgaXRzIGFmZmlsaWF0ZXMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIikuIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2VcbiAqICB3aXRoIHRoZSBMaWNlbnNlLiBBIGNvcHkgb2YgdGhlIExpY2Vuc2UgaXMgbG9jYXRlZCBhdFxuICpcbiAqICAgICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogIG9yIGluIHRoZSAnbGljZW5zZScgZmlsZSBhY2NvbXBhbnlpbmcgdGhpcyBmaWxlLiBUaGlzIGZpbGUgaXMgZGlzdHJpYnV0ZWQgb24gYW4gJ0FTIElTJyBCQVNJUywgV0lUSE9VVCBXQVJSQU5USUVTXG4gKiAgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZXhwcmVzcyBvciBpbXBsaWVkLiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnNcbiAqICBhbmQgbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgQXJuLCBBcm5Gb3JtYXQsIEF3cyB9IGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCB0eXBlIHsgSU1vZGVsLCBGb3VuZGF0aW9uTW9kZWwsIEZvdW5kYXRpb25Nb2RlbElkZW50aWZpZXIgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYmVkcm9jayc7XG5pbXBvcnQgdHlwZSB7IElHcmFudGFibGUgfSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCB7IEdyYW50IH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWlhbSc7XG5cbi8qKlxuICogVGhlIGRhdGEgdHlwZSBmb3IgdGhlIHZlY3RvcnMgd2hlbiB1c2luZyBhIG1vZGVsIHRvIGNvbnZlcnQgdGV4dCBpbnRvIHZlY3RvciBlbWJlZGRpbmdzLlxuICogVGhlIG1vZGVsIG11c3Qgc3VwcG9ydCB0aGUgc3BlY2lmaWVkIGRhdGEgdHlwZSBmb3IgdmVjdG9yIGVtYmVkZGluZ3MuIEZsb2F0aW5nLXBvaW50IChmbG9hdDMyKVxuICogaXMgdGhlIGRlZmF1bHQgZGF0YSB0eXBlLCBhbmQgaXMgc3VwcG9ydGVkIGJ5IG1vc3QgbW9kZWxzIGZvciB2ZWN0b3IgZW1iZWRkaW5ncy4gU2VlIFN1cHBvcnRlZFxuICogZW1iZWRkaW5ncyBtb2RlbHMgZm9yIGluZm9ybWF0aW9uIG9uIHRoZSBhdmFpbGFibGUgbW9kZWxzIGFuZCB0aGVpciB2ZWN0b3IgZGF0YSB0eXBlcy5cbiAqL1xuZXhwb3J0IGVudW0gVmVjdG9yVHlwZSB7XG4gIC8qKlxuICAgKiBgRkxPQVRJTkdfUE9JTlRgIGNvbnZlcnQgdGhlIGRhdGEgdG8gZmxvYXRpbmctcG9pbnQgKGZsb2F0MzIpIHZlY3RvciBlbWJlZGRpbmdzIChtb3JlIHByZWNpc2UsIGJ1dCBtb3JlIGNvc3RseSkuXG4gICAqL1xuICBGTE9BVElOR19QT0lOVCA9ICdGTE9BVDMyJyxcbiAgLyoqXG4gICAqIGBCSU5BUllgIGNvbnZlcnQgdGhlIGRhdGEgdG8gYmluYXJ5IHZlY3RvciBlbWJlZGRpbmdzIChsZXNzIHByZWNpc2UsIGJ1dCBsZXNzIGNvc3RseSkuXG4gICAqL1xuICBCSU5BUlkgPSAnQklOQVJZJyxcbn1cblxuLyoqXG4gKiBSZXByZXNlbnRzIGFuIEFtYXpvbiBCZWRyb2NrIGFic3RyYWN0aW9uIG9uIHdoaWNoIHlvdSBjYW5cbiAqIHJ1biB0aGUgYEludm9rZWAgQVBJLiBUaGlzIGNhbiBiZSBhIEZvdW5kYXRpb25hbCBNb2RlbCxcbiAqIGEgQ3VzdG9tIE1vZGVsLCBvciBhbiBJbmZlcmVuY2UgUHJvZmlsZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBJQmVkcm9ja0ludm9rYWJsZSB7XG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBCZWRyb2NrIGludm9rYWJsZSBhYnN0cmFjdGlvbi5cbiAgICovXG4gIHJlYWRvbmx5IGludm9rYWJsZUFybjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBHaXZlcyB0aGUgYXBwcm9wcmlhdGUgcG9saWNpZXMgdG8gaW52b2tlIGFuZCB1c2UgdGhlIGludm9rYWJsZSBhYnN0cmFjdGlvbi5cbiAgICovXG4gIGdyYW50SW52b2tlKGdyYW50ZWU6IElHcmFudGFibGUpOiBHcmFudDtcbn1cblxuLyoqXG4gKiBQcm9wZXJ0aWVzIGZvciBjb25maWd1cmluZyBhIEJlZHJvY2sgRm91bmRhdGlvbiBNb2RlbC5cbiAqIFRoZXNlIHByb3BlcnRpZXMgZGVmaW5lIHRoZSBtb2RlbCdzIGNhcGFiaWxpdGllcyBhbmQgc3VwcG9ydGVkIGZlYXR1cmVzLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEJlZHJvY2tGb3VuZGF0aW9uTW9kZWxQcm9wcyB7XG4gIC8qKlxuICAgKiBCZWRyb2NrIEFnZW50cyBjYW4gdXNlIHRoaXMgbW9kZWwuXG4gICAqIFdoZW4gdHJ1ZSwgdGhlIG1vZGVsIGNhbiBiZSB1c2VkIHdpdGggQmVkcm9jayBBZ2VudHMgZm9yIGF1dG9tYXRlZCB0YXNrIGV4ZWN1dGlvbi5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBmYWxzZVxuICAgKi9cbiAgcmVhZG9ubHkgc3VwcG9ydHNBZ2VudHM/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBDdXJyZW50bHksIHNvbWUgb2YgdGhlIG9mZmVyZWQgbW9kZWxzIGFyZSBvcHRpbWl6ZWQgd2l0aCBwcm9tcHRzL3BhcnNlcnMgZmluZS10dW5lZCBmb3IgaW50ZWdyYXRpbmcgd2l0aCB0aGUgYWdlbnRzIGFyY2hpdGVjdHVyZS5cbiAgICogV2hlbiB0cnVlLCB0aGUgbW9kZWwgaGFzIGJlZW4gc3BlY2lmaWNhbGx5IG9wdGltaXplZCBmb3IgYWdlbnQgaW50ZXJhY3Rpb25zLlxuICAgKlxuICAgKiBAZGVmYXVsdCAtIGZhbHNlXG4gICAqL1xuICByZWFkb25seSBvcHRpbWl6ZWRGb3JBZ2VudHM/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vYmVkcm9jay9sYXRlc3QvdXNlcmd1aWRlL21vZGVsLWxpZmVjeWNsZS5odG1sXG4gICAqIEEgdmVyc2lvbiBpcyBtYXJrZWQgTGVnYWN5IHdoZW4gdGhlcmUgaXMgYSBtb3JlIHJlY2VudCB2ZXJzaW9uIHdoaWNoIHByb3ZpZGVzIHN1cGVyaW9yIHBlcmZvcm1hbmNlLlxuICAgKiBBbWF6b24gQmVkcm9jayBzZXRzIGFuIEVPTCBkYXRlIGZvciBMZWdhY3kgdmVyc2lvbnMuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gZmFsc2VcbiAgICovXG4gIHJlYWRvbmx5IGxlZ2FjeT86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIEJlZHJvY2sgS25vd2xlZGdlIEJhc2UgY2FuIHVzZSB0aGlzIG1vZGVsLlxuICAgKiBXaGVuIHRydWUsIHRoZSBtb2RlbCBjYW4gYmUgdXNlZCBmb3Iga25vd2xlZGdlIGJhc2Ugb3BlcmF0aW9ucy5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBmYWxzZVxuICAgKi9cbiAgcmVhZG9ubHkgc3VwcG9ydHNLbm93bGVkZ2VCYXNlPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogQ2FuIGJlIHVzZWQgd2l0aCBhIENyb3NzLVJlZ2lvbiBJbmZlcmVuY2UgUHJvZmlsZS5cbiAgICogV2hlbiB0cnVlLCB0aGUgbW9kZWwgc3VwcG9ydHMgaW5mZXJlbmNlIGFjcm9zcyBkaWZmZXJlbnQgQVdTIHJlZ2lvbnMuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gZmFsc2VcbiAgICovXG4gIHJlYWRvbmx5IHN1cHBvcnRzQ3Jvc3NSZWdpb24/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBFbWJlZGRpbmcgbW9kZWxzIGhhdmUgZGlmZmVyZW50IHZlY3RvciBkaW1lbnNpb25zLlxuICAgKiBPbmx5IGFwcGxpY2FibGUgZm9yIGVtYmVkZGluZyBtb2RlbHMuIERlZmluZXMgdGhlIGRpbWVuc2lvbmFsaXR5IG9mIHRoZSB2ZWN0b3IgZW1iZWRkaW5ncy5cbiAgICpcbiAgICogQGRlZmF1bHQgLSB1bmRlZmluZWRcbiAgICovXG4gIHJlYWRvbmx5IHZlY3RvckRpbWVuc2lvbnM/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIEVtYmVkZGluZ3MgbW9kZWxzIGhhdmUgZGlmZmVyZW50IHN1cHBvcnRlZCB2ZWN0b3IgdHlwZXMuXG4gICAqIERlZmluZXMgd2hldGhlciB0aGUgbW9kZWwgc3VwcG9ydHMgZmxvYXRpbmctcG9pbnQgb3IgYmluYXJ5IHZlY3RvcnMuXG4gICAqXG4gICAqIEBkZWZhdWx0IC0gdW5kZWZpbmVkXG4gICAqL1xuICByZWFkb25seSBzdXBwb3J0ZWRWZWN0b3JUeXBlPzogVmVjdG9yVHlwZVtdO1xufVxuXG4vKipcbiAqIEJlZHJvY2sgbW9kZWxzLlxuICpcbiAqIElmIHlvdSBuZWVkIHRvIHVzZSBhIG1vZGVsIG5hbWUgdGhhdCBkb2Vzbid0IGV4aXN0IGFzIGEgc3RhdGljIG1lbWJlciwgeW91XG4gKiBjYW4gaW5zdGFudGlhdGUgYSBgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbGAgb2JqZWN0LCBlLmc6IGBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCgnbXktbW9kZWwnKWAuXG4gKi9cbmV4cG9ydCBjbGFzcyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsIGltcGxlbWVudHMgSUJlZHJvY2tJbnZva2FibGUge1xuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBSTIxXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbiAgLyoqXG4gICAqIEFJMjEncyBKYW1iYSAxLjUgTGFyZ2UgbW9kZWwgb3B0aW1pemVkIGZvciB0ZXh0IGdlbmVyYXRpb24gdGFza3MuXG4gICAqIFN1aXRhYmxlIGZvciBjb21wbGV4IGxhbmd1YWdlIHVuZGVyc3RhbmRpbmcgYW5kIGdlbmVyYXRpb24gdGFza3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gT3B0aW1pemVkIGZvciBuYXR1cmFsIGxhbmd1YWdlIHByb2Nlc3NpbmdcbiAgICogLSBCZXN0IGZvcjogQ29udGVudCBnZW5lcmF0aW9uLCBzdW1tYXJpemF0aW9uLCBhbmQgY29tcGxleCB0ZXh0IGFuYWx5c2lzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFJMjFfSkFNQkFfMV81X0xBUkdFX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FpMjEuamFtYmEtMS01LWxhcmdlLXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFJMjEncyBKYW1iYSAxLjUgTWluaSBtb2RlbCwgYSBsaWdodGVyIHZlcnNpb24gb3B0aW1pemVkIGZvciBmYXN0ZXIgcHJvY2Vzc2luZy5cbiAgICogQmFsYW5jZXMgcGVyZm9ybWFuY2Ugd2l0aCBlZmZpY2llbmN5IGZvciBnZW5lcmFsIHRleHQgdGFza3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gRmFzdGVyIHJlc3BvbnNlIHRpbWVzIGNvbXBhcmVkIHRvIGxhcmdlciBtb2RlbHNcbiAgICogLSBCZXN0IGZvcjogUXVpY2sgdGV4dCBwcm9jZXNzaW5nLCBiYXNpYyBjb250ZW50IGdlbmVyYXRpb25cbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQUkyMV9KQU1CQV8xXzVfTUlOSV9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhaTIxLmphbWJhLTEtNS1taW5pLXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFJMjEncyBKYW1iYSBJbnN0cnVjdCBtb2RlbCwgc3BlY2lmaWNhbGx5IGRlc2lnbmVkIGZvciBpbnN0cnVjdGlvbi1mb2xsb3dpbmcgdGFza3MuXG4gICAqIE9wdGltaXplZCBmb3IgdW5kZXJzdGFuZGluZyBhbmQgZXhlY3V0aW5nIHNwZWNpZmljIGluc3RydWN0aW9ucy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBFbmhhbmNlZCBpbnN0cnVjdGlvbiB1bmRlcnN0YW5kaW5nXG4gICAqIC0gQmVzdCBmb3I6IFRhc2stc3BlY2lmaWMgaW5zdHJ1Y3Rpb25zLCBjb21tYW5kIHByb2Nlc3NpbmdcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQUkyMV9KQU1CQV9JTlNUUlVDVF9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhaTIxLmphbWJhLWluc3RydWN0LXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgIH0sXG4gICk7XG4gIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFNQVpPTlxuICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG4gIC8qKlxuICAgKiBBbWF6b24ncyBUaXRhbiBUZXh0IEV4cHJlc3MgbW9kZWwsIG9wdGltaXplZCBmb3IgZmFzdCB0ZXh0IGdlbmVyYXRpb24uXG4gICAqIFByb3ZpZGVzIHF1aWNrIHJlc3BvbnNlcyB3aGlsZSBtYWludGFpbmluZyBnb29kIHF1YWxpdHkgb3V0cHV0LlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIEZhc3QgcmVzcG9uc2UgdGltZXNcbiAgICogLSBCZXN0IGZvcjogUmVhbC10aW1lIGFwcGxpY2F0aW9ucywgY2hhdGJvdHMsIHF1aWNrIGNvbnRlbnQgZ2VuZXJhdGlvblxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTUFaT05fVElUQU5fVEVYVF9FWFBSRVNTX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FtYXpvbi50aXRhbi10ZXh0LWV4cHJlc3MtdjEnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFtYXpvbidzIFRpdGFuIFRleHQgUHJlbWllciBtb2RlbCwgZGVzaWduZWQgZm9yIGhpZ2gtcXVhbGl0eSB0ZXh0IGdlbmVyYXRpb24uXG4gICAqIE9mZmVycyBlbmhhbmNlZCBjYXBhYmlsaXRpZXMgZm9yIGNvbXBsZXggbGFuZ3VhZ2UgdGFza3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQWR2YW5jZWQgbGFuZ3VhZ2UgdW5kZXJzdGFuZGluZ1xuICAgKiAtIEJlc3QgZm9yOiBDb21wbGV4IGNvbnRlbnQgZ2VuZXJhdGlvbiwgZGV0YWlsZWQgYW5hbHlzaXNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU1BWk9OX1RJVEFOX1BSRU1JRVJfVjFfMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbWF6b24udGl0YW4tdGV4dC1wcmVtaWVyLXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFtYXpvbidzIE5vdmEgTWljcm8gbW9kZWwsIGEgbGlnaHR3ZWlnaHQgbW9kZWwgb3B0aW1pemVkIGZvciBlZmZpY2llbmN5LlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gT3B0aW1pemVkIGZvciBhZ2VudHNcbiAgICogLSBCZXN0IGZvcjogUXVpY2sgcHJvY2Vzc2luZyB0YXNrcywgYmFzaWMgbGFuZ3VhZ2UgdW5kZXJzdGFuZGluZ1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTUFaT05fTk9WQV9NSUNST19WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbWF6b24ubm92YS1taWNyby12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsXG4gICAgICBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW1hem9uJ3MgTm92YSBMaXRlIG1vZGVsLCBiYWxhbmNpbmcgcGVyZm9ybWFuY2Ugd2l0aCBlZmZpY2llbmN5LlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gT3B0aW1pemVkIGZvciBhZ2VudHNcbiAgICogLSBCZXN0IGZvcjogR2VuZXJhbC1wdXJwb3NlIGxhbmd1YWdlIHRhc2tzLCBtb2RlcmF0ZSBjb21wbGV4aXR5XG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFNQVpPTl9OT1ZBX0xJVEVfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCgnYW1hem9uLm5vdmEtbGl0ZS12MTowJywge1xuICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsXG4gICAgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlLFxuICB9KTtcblxuICAvKipcbiAgICogQW1hem9uJ3MgTm92YSBQcm8gbW9kZWwsIG9mZmVyaW5nIGFkdmFuY2VkIGNhcGFiaWxpdGllcyBmb3IgY29tcGxleCB0YXNrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IENvbXBsZXggbGFuZ3VhZ2UgdGFza3MsIHByb2Zlc3Npb25hbCBhcHBsaWNhdGlvbnNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU1BWk9OX05PVkFfUFJPX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoJ2FtYXpvbi5ub3ZhLXByby12MTowJywge1xuICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsXG4gICAgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlLFxuICB9KTtcblxuICAvKipcbiAgICogQW1hem9uJ3MgTm92YSBQcmVtaWVyIG1vZGVsLCB0aGUgbW9zdCBhZHZhbmNlZCBpbiB0aGUgTm92YSBzZXJpZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBPcHRpbWl6ZWQgZm9yIGFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBIaWdoLWVuZCBhcHBsaWNhdGlvbnMsIGNvbXBsZXggYW5hbHlzaXMsIHByZW1pdW0gcGVyZm9ybWFuY2VcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU1BWk9OX05PVkFfUFJFTUlFUl9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKCdhbWF6b24ubm92YS1wcmVtaWVyLXYxOjAnLCB7XG4gICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgICBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUsXG4gIH0pO1xuXG4gIC8qKlxuICAgKiBBbWF6b24ncyBUaXRhbiBFbWJlZCBUZXh0IFYxIG1vZGVsIGZvciB0ZXh0IGVtYmVkZGluZ3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEtub3dsZWRnZSBCYXNlIGludGVncmF0aW9uXG4gICAqIC0gMTUzNi1kaW1lbnNpb25hbCB2ZWN0b3JzXG4gICAqIC0gRmxvYXRpbmctcG9pbnQgdmVjdG9yIHR5cGVcbiAgICogLSBCZXN0IGZvcjogVGV4dCBlbWJlZGRpbmdzLCBzZW1hbnRpYyBzZWFyY2gsIGRvY3VtZW50IHNpbWlsYXJpdHlcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgVElUQU5fRU1CRURfVEVYVF9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbWF6b24udGl0YW4tZW1iZWQtdGV4dC12MScsXG4gICAge1xuICAgICAgc3VwcG9ydHNLbm93bGVkZ2VCYXNlOiB0cnVlLFxuICAgICAgdmVjdG9yRGltZW5zaW9uczogMTUzNixcbiAgICAgIHN1cHBvcnRlZFZlY3RvclR5cGU6IFtWZWN0b3JUeXBlLkZMT0FUSU5HX1BPSU5UXSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbWF6b24ncyBUaXRhbiBFbWJlZCBUZXh0IFYyIG1vZGVsIHdpdGggMTAyNC1kaW1lbnNpb25hbCB2ZWN0b3JzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBLbm93bGVkZ2UgQmFzZSBpbnRlZ3JhdGlvblxuICAgKiAtIDEwMjQtZGltZW5zaW9uYWwgdmVjdG9yc1xuICAgKiAtIFN1cHBvcnRzIGJvdGggZmxvYXRpbmctcG9pbnQgYW5kIGJpbmFyeSB2ZWN0b3JzXG4gICAqIC0gQmVzdCBmb3I6IEhpZ2gtZGltZW5zaW9uYWwgZW1iZWRkaW5ncywgYWR2YW5jZWQgc2VtYW50aWMgc2VhcmNoXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFRJVEFOX0VNQkVEX1RFWFRfVjJfMTAyNCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbWF6b24udGl0YW4tZW1iZWQtdGV4dC12MjowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0tub3dsZWRnZUJhc2U6IHRydWUsXG4gICAgICB2ZWN0b3JEaW1lbnNpb25zOiAxMDI0LFxuICAgICAgc3VwcG9ydGVkVmVjdG9yVHlwZTogW1ZlY3RvclR5cGUuRkxPQVRJTkdfUE9JTlQsIFZlY3RvclR5cGUuQklOQVJZXSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbWF6b24ncyBUaXRhbiBFbWJlZCBUZXh0IFYyIG1vZGVsIHdpdGggNTEyLWRpbWVuc2lvbmFsIHZlY3RvcnMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEtub3dsZWRnZSBCYXNlIGludGVncmF0aW9uXG4gICAqIC0gNTEyLWRpbWVuc2lvbmFsIHZlY3RvcnNcbiAgICogLSBTdXBwb3J0cyBib3RoIGZsb2F0aW5nLXBvaW50IGFuZCBiaW5hcnkgdmVjdG9yc1xuICAgKiAtIEJlc3QgZm9yOiBCYWxhbmNlZCBwZXJmb3JtYW5jZSBhbmQgZGltZW5zaW9uYWxpdHlcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgVElUQU5fRU1CRURfVEVYVF9WMl81MTIgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW1hem9uLnRpdGFuLWVtYmVkLXRleHQtdjI6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNLbm93bGVkZ2VCYXNlOiB0cnVlLFxuICAgICAgdmVjdG9yRGltZW5zaW9uczogNTEyLFxuICAgICAgc3VwcG9ydGVkVmVjdG9yVHlwZTogW1ZlY3RvclR5cGUuRkxPQVRJTkdfUE9JTlQsIFZlY3RvclR5cGUuQklOQVJZXSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbWF6b24ncyBUaXRhbiBFbWJlZCBUZXh0IFYyIG1vZGVsIHdpdGggMjU2LWRpbWVuc2lvbmFsIHZlY3RvcnMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEtub3dsZWRnZSBCYXNlIGludGVncmF0aW9uXG4gICAqIC0gMjU2LWRpbWVuc2lvbmFsIHZlY3RvcnNcbiAgICogLSBTdXBwb3J0cyBib3RoIGZsb2F0aW5nLXBvaW50IGFuZCBiaW5hcnkgdmVjdG9yc1xuICAgKiAtIEJlc3QgZm9yOiBFZmZpY2llbnQgZW1iZWRkaW5ncyB3aXRoIGxvd2VyIGRpbWVuc2lvbmFsaXR5XG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFRJVEFOX0VNQkVEX1RFWFRfVjJfMjU2ID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FtYXpvbi50aXRhbi1lbWJlZC10ZXh0LXYyOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzS25vd2xlZGdlQmFzZTogdHJ1ZSxcbiAgICAgIHZlY3RvckRpbWVuc2lvbnM6IDI1NixcbiAgICAgIHN1cHBvcnRlZFZlY3RvclR5cGU6IFtWZWN0b3JUeXBlLkZMT0FUSU5HX1BPSU5ULCBWZWN0b3JUeXBlLkJJTkFSWV0sXG4gICAgfSxcbiAgKTtcbiAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgQU5USFJPUElDXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBIYWlrdSA0LjUgbW9kZWwsIG1vc3QgY29zdC1lZmZpY2llbnQgYW5kIGZhc3Rlc3QuXG4gICAqIERlbGl2ZXJzIG5lYXItZnJvbnRpZXIgcGVyZm9ybWFuY2Ugd2l0aCBzdWJzdGFudGlhbGx5IGxvd2VyIGNvc3QgYW5kIGZhc3RlciBzcGVlZHMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIHZpc2lvbiAoSW1hZ2UgaW5wdXQgbW9kYWxpdHkpXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBMYXJnZS1zY2FsZSBkZXBsb3ltZW50cywgYnVkZ2V0LWNvbnNjaW91cyBhcHBsaWNhdGlvbnMsIHJlYWwtdGltZSBjdXN0b21lciBzZXJ2aWNlLCBsYXRlbmN5LXNlbnNpdGl2ZSB1c2UgY2FzZXNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV9IQUlLVV80XzVfVjFfMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbnRocm9waWMuY2xhdWRlLWhhaWt1LTQtNS0yMDI1MTAwMS12MTowJyxcbiAgICB7IHN1cHBvcnRzQWdlbnRzOiB0cnVlLCBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLCBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIFNvbm5ldCA0LjUgbW9kZWwsIG1vc3QgaW50ZWxsaWdlbnQgaW4gdGhlIENsYXVkZSA0IHNlcmllcy5cbiAgICogRGVtb25zdHJhdGVzIGFkdmFuY2VtZW50cyBpbiBhZ2VudCBjYXBhYmlsaXRpZXMgd2l0aCBlbmhhbmNlZCBwZXJmb3JtYW5jZSBpbiB0b29sIGhhbmRsaW5nLFxuICAgKiBtZW1vcnkgbWFuYWdlbWVudCwgYW5kIGNvbnRleHQgcHJvY2Vzc2luZy4gRXhjZWxzIGF0IGF1dG9ub21vdXMgbG9uZy1ob3Jpem9uIGNvZGluZyB0YXNrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgdmlzaW9uIChJbWFnZSBpbnB1dCBtb2RhbGl0eSlcbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzXG4gICAqIC0gRW5oYW5jZWQgdG9vbCBoYW5kbGluZyBhbmQgbWVtb3J5IG1hbmFnZW1lbnQgZm9yIGxvbmctcnVubmluZyB0YXNrc1xuICAgKiAtIEJlc3QgZm9yOiBDb21wbGV4IGFnZW50cywgY29kaW5nLCBhdXRvbm9tb3VzIGxvbmctaG9yaXpvbiB0YXNrcywgcmVzZWFyY2ggYW5kIGFuYWx5c2lzLCBjeWJlcnNlY3VyaXR5IGFuZCBmaW5hbmNlIGFwcGxpY2F0aW9uc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX1NPTk5FVF80XzVfVjFfMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbnRocm9waWMuY2xhdWRlLXNvbm5ldC00LTUtMjAyNTA5MjktdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBPcHVzIDQuNiBtb2RlbCwgdGhlIG1vc3QgaW50ZWxsaWdlbnQgbW9kZWwgYW5kIHRoZSB3b3JsZCdzIGJlc3QgbW9kZWxcbiAgICogZm9yIGNvZGluZywgZW50ZXJwcmlzZSBhZ2VudHMsIGFuZCBwcm9mZXNzaW9uYWwgd29yay5cbiAgICogU3VwcG9ydHMgYm90aCAyMDBLIGFuZCAxTSBjb250ZXh0IHRva2VucyAod2l0aCB0aGUgbGF0dGVyIGluIHByZXZpZXcpLlxuICAgKiBFeGNlbHMgaW4gYWdlbnRpYyB3b3JrZmxvd3MsIGNvbXBsZXggY29kaW5nIHByb2plY3RzLCBhbmQgZW50ZXJwcmlzZSBhcHBsaWNhdGlvbnNcbiAgICogcmVxdWlyaW5nIHNvcGhpc3RpY2F0ZWQgcmVhc29uaW5nLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyB2aXNpb24gKEltYWdlIGlucHV0IG1vZGFsaXR5KVxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHNcbiAgICogLSBCZXN0IGZvcjogRmluYW5jaWFsIGFuYWx5c2lzLCBjeWJlcnNlY3VyaXR5LCBjb21wdXRlciB1c2Ugd29ya2Zsb3dzLCBsb25nLWhvcml6b24gZGV2ZWxvcG1lbnQsIG11bHRpLXRvb2wgb3JjaGVzdHJhdGlvblxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX09QVVNfNF82X1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtb3B1cy00LTYtdjEnLFxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgT3B1cyA0LjcgbW9kZWwsIEFudGhyb3BpYydzIG1vc3QgY2FwYWJsZSBnZW5lcmFsbHkgYXZhaWxhYmxlIG1vZGVsLFxuICAgKiBhZHZhbmNpbmcgcGVyZm9ybWFuY2UgYWNyb3NzIGNvZGluZywgZW50ZXJwcmlzZSB3b3JrZmxvd3MsIGFuZCBsb25nLXJ1bm5pbmcgYWdlbnRpYyB0YXNrcy5cbiAgICogRmVhdHVyZXMgYSAxTSB0b2tlbiBjb250ZXh0IHdpbmRvdywgMTI4SyBtYXggb3V0cHV0IHRva2VucywgYW5kIHN1cHBvcnRzIHJlYXNvbmluZy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgdmlzaW9uIChJbWFnZSBpbnB1dCBtb2RhbGl0eSlcbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfT1BVU180XzcgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1vcHVzLTQtNycsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgT3B1cyA0LjggbW9kZWwsIEFudGhyb3BpYydzIG1vc3QgaW50ZWxsaWdlbnQgT3B1cyBtb2RlbCBhbmRcbiAgICogYmVzdCBnZW5lcmFsbHkgYXZhaWxhYmxlIG1vZGVsIGZvciBjb2RpbmcgYW5kIGFnZW50cywgd2l0aCBkZWVwZXIgcmVhc29uaW5nIGZvclxuICAgKiBlbnRlcnByaXNlIHdvcmtmbG93cy5cbiAgICogRmVhdHVyZXMgYSAxTSB0b2tlbiBjb250ZXh0IHdpbmRvdywgMTI4SyBtYXggb3V0cHV0IHRva2VucywgYW5kIHN1cHBvcnRzIHJlYXNvbmluZy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgdmlzaW9uIChJbWFnZSBpbnB1dCBtb2RhbGl0eSlcbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfT1BVU180XzggPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1vcHVzLTQtOCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgT3B1cyA1LjUgbW9kZWwsIEFudGhyb3BpYydzIG1vc3QgY2FwYWJsZSBPcHVzIG1vZGVsLlxuICAgKiBCZXR0ZXIgYXQgY29kaW5nLCBrbm93bGVkZ2Ugd29yaywgYW5kIGxvbmctcnVubmluZyB0YXNrcy5cbiAgICogRmVhdHVyZXMgYSAxTSB0b2tlbiBjb250ZXh0IHdpbmRvdywgMTI4SyBtYXggb3V0cHV0IHRva2VucywgYW5kIHN1cHBvcnRzIHJlYXNvbmluZy5cbiAgICpcbiAgICogT25seSBhdmFpbGFibGUgdGhyb3VnaCB0aGUgYGdsb2JhbGAsIGB1c2AsIGBldWAsIGBhdWAgYW5kIGBqcGAgY3Jvc3MtcmVnaW9uIGluZmVyZW5jZSBwcm9maWxlcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgdmlzaW9uIChJbWFnZSBpbnB1dCBtb2RhbGl0eSlcbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfT1BVU181XzUgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1vcHVzLTUtNScsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgU29ubmV0IDUuNSBtb2RlbC5cbiAgICogSW1wcm92ZWQgY29kaW5nIGFuZCBrbm93bGVkZ2Ugd29yayBvdmVyIENsYXVkZSBTb25uZXQgNSwgYXQgYSBsb3dlciBjb3N0IHBlciB0YXNrLlxuICAgKiBGZWF0dXJlcyBhIDFNIHRva2VuIGNvbnRleHQgd2luZG93LCAxMjhLIG1heCBvdXRwdXQgdG9rZW5zLCBhbmQgc3VwcG9ydHMgcmVhc29uaW5nLlxuICAgKlxuICAgKiBPbmx5IGF2YWlsYWJsZSB0aHJvdWdoIHRoZSBgZ2xvYmFsYCBjcm9zcy1yZWdpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIHZpc2lvbiAoSW1hZ2UgaW5wdXQgbW9kYWxpdHkpXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50c1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX1NPTk5FVF81XzUgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1zb25uZXQtNS01JyxcbiAgICB7IHN1cHBvcnRzQWdlbnRzOiB0cnVlLCBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLCBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIEZhYmxlIDUuMSBtb2RlbCwgQW50aHJvcGljJ3MgZnJvbnRpZXIgbW9kZWwgZm9yIGFtYml0aW91cyBjb2RpbmcsXG4gICAqIGxvbmctaG9yaXpvbiBhZ2VudHMsIGFuZCBlbnRlcnByaXNlIGtub3dsZWRnZSB3b3JrLlxuICAgKiBGZWF0dXJlcyBhIDFNIHRva2VuIGNvbnRleHQgd2luZG93LCAxMjhLIG1heCBvdXRwdXQgdG9rZW5zLCBhbmQgc3VwcG9ydHMgcmVhc29uaW5nLlxuICAgKlxuICAgKiBPbmx5IGF2YWlsYWJsZSB0aHJvdWdoIHRoZSBgZ2xvYmFsYCBhbmQgYHVzYCBjcm9zcy1yZWdpb24gaW5mZXJlbmNlIHByb2ZpbGVzLlxuICAgKlxuICAgKiBVc2luZyB0aGlzIG1vZGVsIHJlcXVpcmVzIG9wdGluZyBpbiB0byB0aGUgYGF3c19yZXZpZXdgIGRhdGFcbiAgICogcmV0ZW50aW9uIG1vZGU7IHNlZSB0aGUgQW1hem9uIEJlZHJvY2sgbW9kZWwgY2FyZCBmb3IgZGV0YWlscy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgdmlzaW9uIChJbWFnZSBpbnB1dCBtb2RhbGl0eSlcbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfRkFCTEVfNV8xID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtZmFibGUtNS0xJyxcbiAgICB7IHN1cHBvcnRzQWdlbnRzOiB0cnVlLCBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBTb25uZXQgNC42IG1vZGVsLlxuICAgKiBJbXByb3ZlZCBwZXJmb3JtYW5jZSBmb3IgY29kaW5nLCBhZ2VudGljIHdvcmtmbG93cywgYW5kIGJyb3dzZXItYmFzZWQgYXV0b21hdGlvbi5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgdmlzaW9uIChJbWFnZSBpbnB1dCBtb2RhbGl0eSlcbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IENvZGluZywgYWdlbnRpYyB3b3JrZmxvd3MsIGJyb3dzZXItYmFzZWQgYXV0b21hdGlvbiwgZW50ZXJwcmlzZSBhcHBsaWNhdGlvbnNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV9TT05ORVRfNF82ID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtc29ubmV0LTQtNicsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBPcHVzIDQuNSBtb2RlbCwgdGhlIGZsYWdzaGlwIG1vZGVsIHJlbGVhc2VkIE5vdmVtYmVyIDIwMjUuXG4gICAqIEV4Y2VscyBhdCByZWFsLXdvcmxkIHByb2dyYW1taW5nIHRhc2tzLCBzY29yaW5nIGhpZ2hlc3Qgb24gU1dFLWJlbmNoIFZlcmlmaWVkIGJlbmNobWFya3MuXG4gICAqIERlbW9uc3RyYXRlcyBzdXBlcmlvciBwZXJmb3JtYW5jZSBpbiBsb25nLWhvcml6b24sIGdvYWwtZGlyZWN0ZWQgYWdlbnRpYyB3b3JrIHdpdGggZmV3ZXIgZGVhZC1lbmRzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyB2aXNpb24gKEltYWdlIGlucHV0IG1vZGFsaXR5KVxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHNcbiAgICogLSBCZXN0IGZvcjogU29mdHdhcmUgZW5naW5lZXJpbmcsIGNvZGUgbWlncmF0aW9uLCBhZ2VudGljIHdvcmtmbG93cywgZmluYW5jaWFsIG1vZGVsaW5nLCBkZWVwIHJlc2VhcmNoXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfT1BVU180XzVfVjFfMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbnRocm9waWMuY2xhdWRlLW9wdXMtNC01LTIwMjUxMTAxLXYxOjAnLFxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgT3B1cyA0LjEgbW9kZWwsIG1vc3QgYWR2YW5jZWQgZm9yIGNvZGluZyBhbmQgYWdlbnRpYyBhcHBsaWNhdGlvbnMuXG4gICAqIEV4Y2VscyBhdCBpbmRlcGVuZGVudGx5IHBsYW5uaW5nIGFuZCBleGVjdXRpbmcgY29tcGxleCBkZXZlbG9wbWVudCB0YXNrcyBlbmQtdG8tZW5kLlxuICAgKiBEcm9wLWluIHJlcGxhY2VtZW50IGZvciBPcHVzIDQgd2l0aCBzdXBlcmlvciBwZXJmb3JtYW5jZSBhbmQgcHJlY2lzaW9uLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyB2aXNpb24gKEltYWdlIGlucHV0IG1vZGFsaXR5KVxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHNcbiAgICogLSBCZXN0IGZvcjogQ29tcGxleCBlbmQtdG8tZW5kIGRldmVsb3BtZW50LCBhZ2VudGljIGFwcGxpY2F0aW9ucywgcmVzZWFyY2gsIGFkdmFuY2VkIHJlYXNvbmluZ1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX09QVVNfNF8xX1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1vcHVzLTQtMS0yMDI1MDgwNS12MTowJyxcbiAgICB7IHN1cHBvcnRzQWdlbnRzOiB0cnVlLCBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLCBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIE9wdXMgNCBtb2RlbCwgbmV4dC1nZW5lcmF0aW9uIGZyb250aWVyIG1vZGVsLlxuICAgKiBIaWdoLXBlcmZvcm1hbmNlIG1vZGVsIGZvciBhZHZhbmNlZCByZWFzb25pbmcgYW5kIGNvbXBsZXggbXVsdGktc3RlcCB0YXNrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgdmlzaW9uIChJbWFnZSBpbnB1dCBtb2RhbGl0eSlcbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IEFkdmFuY2VkIHJlYXNvbmluZywgY29tcGxleCB3b3JrZmxvd3MsIGVudGVycHJpc2UgYXBwbGljYXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfT1BVU180X1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS1vcHVzLTQtMjAyNTA1MTQtdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBTb25uZXQgNCBtb2RlbCwgbmV4dC1nZW5lcmF0aW9uIGZyb250aWVyIG1vZGVsLlxuICAgKiBBZHZhbmNlZCBtb2RlbCB3aXRoIGltcHJvdmVkIHBlcmZvcm1hbmNlIGZvciBwcm9kdWN0aW9uIGVudmlyb25tZW50cy5cbiAgICogQmFsYW5jZXMgcXVhbGl0eSwgY29zdC1lZmZlY3RpdmVuZXNzLCBhbmQgcmVzcG9uc2l2ZW5lc3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIHZpc2lvbiAoSW1hZ2UgaW5wdXQgbW9kYWxpdHkpXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBQcm9kdWN0aW9uIGFwcGxpY2F0aW9ucywgY29tcGxleCBsYW5ndWFnZSB0YXNrcywgYmFsYW5jZWQgcGVyZm9ybWFuY2UgYW5kIGNvc3RcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV9TT05ORVRfNF9WMV8wID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtc29ubmV0LTQtMjAyNTA1MTQtdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSAzLjcgU29ubmV0IG1vZGVsLCBsYXRlc3QgaW4gdGhlIENsYXVkZSAzIHNlcmllcy5cbiAgICogQWR2YW5jZWQgbGFuZ3VhZ2UgbW9kZWwgd2l0aCBlbmhhbmNlZCBjYXBhYmlsaXRpZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogQ29tcGxleCByZWFzb25pbmcsIGFuYWx5c2lzLCBhbmQgY29udGVudCBnZW5lcmF0aW9uXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfM183X1NPTk5FVF9WMV8wID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtMy03LXNvbm5ldC0yMDI1MDIxOS12MTowJyxcblxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsIG9wdGltaXplZEZvckFnZW50czogZmFsc2UgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIDMuNSBTb25uZXQgVjIgbW9kZWwsIG9wdGltaXplZCBmb3IgYWdlbnQgaW50ZXJhY3Rpb25zLlxuICAgKiBFbmhhbmNlZCB2ZXJzaW9uIHdpdGggaW1wcm92ZWQgcGVyZm9ybWFuY2UgYW5kIGNhcGFiaWxpdGllcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IEFnZW50LWJhc2VkIGFwcGxpY2F0aW9ucywgY29tcGxleCBkaWFsb2d1ZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFXzNfNV9TT05ORVRfVjJfMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdhbnRocm9waWMuY2xhdWRlLTMtNS1zb25uZXQtMjAyNDEwMjItdjI6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSAzLjUgU29ubmV0IFYxIG1vZGVsLCBiYWxhbmNlZCBwZXJmb3JtYW5jZSBtb2RlbC5cbiAgICogT2ZmZXJzIGdvb2QgYmFsYW5jZSBiZXR3ZWVuIHBlcmZvcm1hbmNlIGFuZCBlZmZpY2llbmN5LlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gT3B0aW1pemVkIGZvciBhZ2VudHNcbiAgICogLSBCZXN0IGZvcjogR2VuZXJhbCBsYW5ndWFnZSB0YXNrcywgYmFsYW5jZWQgcGVyZm9ybWFuY2VcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQU5USFJPUElDX0NMQVVERV8zXzVfU09OTkVUX1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS0zLTUtc29ubmV0LTIwMjQwNjIwLXYxOjAnLFxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgMy41IEhhaWt1IG1vZGVsLCBvcHRpbWl6ZWQgZm9yIHF1aWNrIHJlc3BvbnNlcy5cbiAgICogTGlnaHR3ZWlnaHQgbW9kZWwgZm9jdXNlZCBvbiBzcGVlZCBhbmQgZWZmaWNpZW5jeS5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IEZhc3QgcmVzcG9uc2VzLCBsaWdodHdlaWdodCBwcm9jZXNzaW5nXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfM181X0hBSUtVX1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS0zLTUtaGFpa3UtMjAyNDEwMjItdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIEFudGhyb3BpYydzIENsYXVkZSBPcHVzIG1vZGVsLCBkZXNpZ25lZCBmb3IgYWR2YW5jZWQgdGFza3MuXG4gICAqIEhpZ2gtcGVyZm9ybWFuY2UgbW9kZWwgd2l0aCBleHRlbnNpdmUgY2FwYWJpbGl0aWVzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IENvbXBsZXggcmVhc29uaW5nLCByZXNlYXJjaCwgYW5kIGFuYWx5c2lzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfT1BVU19WMV8wID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtMy1vcHVzLTIwMjQwMjI5LXYxOjAnLFxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgU29ubmV0IG1vZGVsLCBsZWdhY3kgdmVyc2lvbi5cbiAgICogQmFsYW5jZWQgbW9kZWwgZm9yIGdlbmVyYWwtcHVycG9zZSB0YXNrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIExlZ2FjeSBtb2RlbCB3aXRoIEVPTCBkYXRlXG4gICAqIC0gQmVzdCBmb3I6IEdlbmVyYWwgbGFuZ3VhZ2UgdGFza3MsIHN0YW5kYXJkIGFwcGxpY2F0aW9uc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX1NPTk5FVF9WMV8wID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtMy1zb25uZXQtMjAyNDAyMjktdjE6MCcsXG4gICAgeyBzdXBwb3J0c0FnZW50czogdHJ1ZSwgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSwgbGVnYWN5OiB0cnVlLCBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUgfSxcbiAgKTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIEhhaWt1IG1vZGVsLCBvcHRpbWl6ZWQgZm9yIGVmZmljaWVuY3kuXG4gICAqIEZhc3QgYW5kIGVmZmljaWVudCBtb2RlbCBmb3IgbGlnaHR3ZWlnaHQgdGFza3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBPcHRpbWl6ZWQgZm9yIGFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBRdWljayByZXNwb25zZXMsIHNpbXBsZSB0YXNrc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX0hBSUtVX1YxXzAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS0zLWhhaWt1LTIwMjQwMzA3LXYxOjAnLFxuICAgIHsgc3VwcG9ydHNBZ2VudHM6IHRydWUsIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgVjIuMSBtb2RlbCwgbGVnYWN5IHZlcnNpb24uXG4gICAqIEltcHJvdmVkIHZlcnNpb24gb2YgQ2xhdWRlIFYyIHdpdGggZW5oYW5jZWQgY2FwYWJpbGl0aWVzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIExlZ2FjeSBtb2RlbCB3aXRoIEVPTCBkYXRlXG4gICAqIC0gT3B0aW1pemVkIGZvciBhZ2VudHNcbiAgICogLSBCZXN0IGZvcjogR2VuZXJhbCBsYW5ndWFnZSB0YXNrcywgbGVnYWN5IGFwcGxpY2F0aW9uc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBBTlRIUk9QSUNfQ0xBVURFX1YyXzEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnYW50aHJvcGljLmNsYXVkZS12MjoxJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIGxlZ2FjeTogdHJ1ZSxcbiAgICAgIG9wdGltaXplZEZvckFnZW50czogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBBbnRocm9waWMncyBDbGF1ZGUgVjIgbW9kZWwsIGxlZ2FjeSB2ZXJzaW9uLlxuICAgKiBPcmlnaW5hbCBDbGF1ZGUgVjIgbW9kZWwgd2l0aCBicm9hZCBjYXBhYmlsaXRpZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gTGVnYWN5IG1vZGVsIHdpdGggRU9MIGRhdGVcbiAgICogLSBPcHRpbWl6ZWQgZm9yIGFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBHZW5lcmFsIGxhbmd1YWdlIHRhc2tzLCBsZWdhY3kgYXBwbGljYXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfVjIgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCgnYW50aHJvcGljLmNsYXVkZS12MicsIHtcbiAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICBsZWdhY3k6IHRydWUsXG4gICAgb3B0aW1pemVkRm9yQWdlbnRzOiB0cnVlLFxuICB9KTtcblxuICAvKipcbiAgICogQW50aHJvcGljJ3MgQ2xhdWRlIEluc3RhbnQgVjEuMiBtb2RlbCwgbGVnYWN5IHZlcnNpb24uXG4gICAqIEZhc3QgYW5kIGVmZmljaWVudCBtb2RlbCBvcHRpbWl6ZWQgZm9yIHF1aWNrIHJlc3BvbnNlcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBMZWdhY3kgbW9kZWwgd2l0aCBFT0wgZGF0ZVxuICAgKiAtIE9wdGltaXplZCBmb3IgYWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IFF1aWNrIHJlc3BvbnNlcywgc2ltcGxlIHRhc2tzLCBsZWdhY3kgYXBwbGljYXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEFOVEhST1BJQ19DTEFVREVfSU5TVEFOVF9WMV8yID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ2FudGhyb3BpYy5jbGF1ZGUtaW5zdGFudC12MScsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBsZWdhY3k6IHRydWUsXG4gICAgICBvcHRpbWl6ZWRGb3JBZ2VudHM6IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDT0hFUkVcbiAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cblxuICAvKipcbiAgICogQ29oZXJlJ3MgRW5nbGlzaCBlbWJlZGRpbmcgbW9kZWwsIG9wdGltaXplZCBmb3IgRW5nbGlzaCB0ZXh0IGVtYmVkZGluZ3MuXG4gICAqIFNwZWNpYWxpemVkIGZvciBzZW1hbnRpYyB1bmRlcnN0YW5kaW5nIG9mIEVuZ2xpc2ggY29udGVudC5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgS25vd2xlZGdlIEJhc2UgaW50ZWdyYXRpb25cbiAgICogLSAxMDI0LWRpbWVuc2lvbmFsIHZlY3RvcnNcbiAgICogLSBTdXBwb3J0cyBib3RoIGZsb2F0aW5nLXBvaW50IGFuZCBiaW5hcnkgdmVjdG9yc1xuICAgKiAtIEJlc3QgZm9yOiBFbmdsaXNoIHRleHQgZW1iZWRkaW5ncywgc2VtYW50aWMgc2VhcmNoLCBjb250ZW50IHNpbWlsYXJpdHlcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgQ09IRVJFX0VNQkVEX0VOR0xJU0hfVjMgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnY29oZXJlLmVtYmVkLWVuZ2xpc2gtdjMnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzS25vd2xlZGdlQmFzZTogdHJ1ZSxcbiAgICAgIHZlY3RvckRpbWVuc2lvbnM6IDEwMjQsXG4gICAgICBzdXBwb3J0ZWRWZWN0b3JUeXBlOiBbVmVjdG9yVHlwZS5GTE9BVElOR19QT0lOVCwgVmVjdG9yVHlwZS5CSU5BUlldLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIENvaGVyZSdzIE11bHRpbGluZ3VhbCBlbWJlZGRpbmcgbW9kZWwsIHN1cHBvcnRpbmcgbXVsdGlwbGUgbGFuZ3VhZ2VzLlxuICAgKiBFbmFibGVzIHNlbWFudGljIHVuZGVyc3RhbmRpbmcgYWNyb3NzIGRpZmZlcmVudCBsYW5ndWFnZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEtub3dsZWRnZSBCYXNlIGludGVncmF0aW9uXG4gICAqIC0gMTAyNC1kaW1lbnNpb25hbCB2ZWN0b3JzXG4gICAqIC0gU3VwcG9ydHMgYm90aCBmbG9hdGluZy1wb2ludCBhbmQgYmluYXJ5IHZlY3RvcnNcbiAgICogLSBCZXN0IGZvcjogQ3Jvc3MtbGluZ3VhbCBlbWJlZGRpbmdzLCBtdWx0aWxpbmd1YWwgc2VtYW50aWMgc2VhcmNoXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IENPSEVSRV9FTUJFRF9NVUxUSUxJTkdVQUxfVjMgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnY29oZXJlLmVtYmVkLW11bHRpbGluZ3VhbC12MycsXG4gICAge1xuICAgICAgc3VwcG9ydHNLbm93bGVkZ2VCYXNlOiB0cnVlLFxuICAgICAgdmVjdG9yRGltZW5zaW9uczogMTAyNCxcbiAgICAgIHN1cHBvcnRlZFZlY3RvclR5cGU6IFtWZWN0b3JUeXBlLkZMT0FUSU5HX1BPSU5ULCBWZWN0b3JUeXBlLkJJTkFSWV0sXG4gICAgfSxcbiAgKTtcbiAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgREVFUFNFRUtcbiAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cblxuICAvKipcbiAgICogRGVlcHNlZWsncyBSMSBtb2RlbCwgZGVzaWduZWQgZm9yIGdlbmVyYWwgbGFuZ3VhZ2UgdW5kZXJzdGFuZGluZy5cbiAgICogQmFsYW5jZWQgbW9kZWwgZm9yIHZhcmlvdXMgbGFuZ3VhZ2UgdGFza3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogR2VuZXJhbCBsYW5ndWFnZSB0YXNrcywgY29udGVudCBnZW5lcmF0aW9uXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IERFRVBTRUVLX1IxX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoJ2RlZXBzZWVrLnIxLXYxOjAnLCB7XG4gICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgfSk7XG5cbiAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgTUVUQVxuICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuXG4gIC8qKlxuICAgKiBNZXRhJ3MgTGxhbWEgMyAxLjhCIEluc3RydWN0IG1vZGVsLCBjb21wYWN0IGluc3RydWN0aW9uLWZvbGxvd2luZyBtb2RlbC5cbiAgICogRWZmaWNpZW50IG1vZGVsIG9wdGltaXplZCBmb3IgaW5zdHJ1Y3Rpb24tYmFzZWQgdGFza3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogTGlnaHR3ZWlnaHQgaW5zdHJ1Y3Rpb24gcHJvY2Vzc2luZywgcXVpY2sgcmVzcG9uc2VzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1FVEFfTExBTUFfM18xXzhCX0lOU1RSVUNUX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ21ldGEubGxhbWEzLTEtOGItaW5zdHJ1Y3QtdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1ldGEncyBMbGFtYSAzIDcwQiBJbnN0cnVjdCBtb2RlbCwgbGFyZ2Utc2NhbGUgaW5zdHJ1Y3Rpb24gbW9kZWwuXG4gICAqIEhpZ2gtY2FwYWNpdHkgbW9kZWwgZm9yIGNvbXBsZXggbGFuZ3VhZ2UgdW5kZXJzdGFuZGluZy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIEJlc3QgZm9yOiBDb21wbGV4IGluc3RydWN0aW9ucywgYWR2YW5jZWQgbGFuZ3VhZ2UgdGFza3NcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUVUQV9MTEFNQV8zXzFfNzBCX0lOU1RSVUNUX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ21ldGEubGxhbWEzLTEtNzBiLWluc3RydWN0LXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBNZXRhJ3MgTGxhbWEgMy4yIDExQiBJbnN0cnVjdCBtb2RlbCwgbWlkLXNpemVkIGluc3RydWN0aW9uIG1vZGVsLlxuICAgKiBCYWxhbmNlZCBtb2RlbCBmb3IgZ2VuZXJhbCBpbnN0cnVjdGlvbiBwcm9jZXNzaW5nLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gQmVzdCBmb3I6IEdlbmVyYWwgaW5zdHJ1Y3Rpb24gdGFza3MsIGJhbGFuY2VkIHBlcmZvcm1hbmNlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1FVEFfTExBTUFfM18yXzExQl9JTlNUUlVDVF9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdtZXRhLmxsYW1hMy0yLTExYi1pbnN0cnVjdC12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogTWV0YSdzIExsYW1hIDMuMiAzQiBJbnN0cnVjdCBtb2RlbCwgY29tcGFjdCBlZmZpY2llbnQgbW9kZWwuXG4gICAqIExpZ2h0d2VpZ2h0IG1vZGVsIGZvciBiYXNpYyBpbnN0cnVjdGlvbiBwcm9jZXNzaW5nLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gQmVzdCBmb3I6IEJhc2ljIGluc3RydWN0aW9ucywgZWZmaWNpZW50IHByb2Nlc3NpbmdcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUVUQV9MTEFNQV8zXzJfM0JfSU5TVFJVQ1RfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWV0YS5sbGFtYTMtMi0zYi1pbnN0cnVjdC12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IHRydWUsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogTWV0YSdzIExsYW1hIDMuMiAxQiBJbnN0cnVjdCBtb2RlbCwgdWx0cmEtbGlnaHR3ZWlnaHQgbW9kZWwuXG4gICAqIE1vc3QgY29tcGFjdCBtb2RlbCBpbiB0aGUgTGxhbWEgMy4yIHNlcmllcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gU3VwcG9ydHMgQmVkcm9jayBBZ2VudHMgaW50ZWdyYXRpb25cbiAgICogLSBDcm9zcy1yZWdpb24gc3VwcG9ydFxuICAgKiAtIEJlc3QgZm9yOiBTaW1wbGUgaW5zdHJ1Y3Rpb25zLCBmYXN0ZXN0IHJlc3BvbnNlIHRpbWVzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1FVEFfTExBTUFfM18yXzFCX0lOU1RSVUNUX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ21ldGEubGxhbWEzLTItMWItaW5zdHJ1Y3QtdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1ldGEncyBMbGFtYSAzLjMgNzBCIEluc3RydWN0IG1vZGVsLCBsYXRlc3QgbGFyZ2Utc2NhbGUgbW9kZWwuXG4gICAqIEFkdmFuY2VkIG1vZGVsIHdpdGggZW5oYW5jZWQgY2FwYWJpbGl0aWVzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gQmVzdCBmb3I6IENvbXBsZXggcmVhc29uaW5nLCBhZHZhbmNlZCBsYW5ndWFnZSB0YXNrc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBNRVRBX0xMQU1BXzNfM183MEJfSU5TVFJVQ1RfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWV0YS5sbGFtYTMtMy03MGItaW5zdHJ1Y3QtdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1ldGEncyBMbGFtYSA0IE1hdmVyaWNrIDE3QiBJbnN0cnVjdCBtb2RlbCwgaW5ub3ZhdGl2ZSBtaWQtc2l6ZWQgbW9kZWwuXG4gICAqIFNwZWNpYWxpemVkIGZvciBjcmVhdGl2ZSBhbmQgZHluYW1pYyByZXNwb25zZXMuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogQ3JlYXRpdmUgdGFza3MsIGlubm92YXRpdmUgc29sdXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1FVEFfTExBTUFfNF9NQVZFUklDS18xN0JfSU5TVFJVQ1RfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWV0YS5sbGFtYTQtbWF2ZXJpY2stMTdiLWluc3RydWN0LXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBNZXRhJ3MgTGxhbWEgNCBTY291dCAxN0IgSW5zdHJ1Y3QgbW9kZWwsIGFuYWx5dGljYWwgbWlkLXNpemVkIG1vZGVsLlxuICAgKiBGb2N1c2VkIG9uIHByZWNpc2UgYW5kIGFuYWx5dGljYWwgcmVzcG9uc2VzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0XG4gICAqIC0gQmVzdCBmb3I6IEFuYWx5dGljYWwgdGFza3MsIHByZWNpc2UgcmVzcG9uc2VzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1FVEFfTExBTUFfNF9TQ09VVF8xN0JfSU5TVFJVQ1RfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWV0YS5sbGFtYTQtc2NvdXQtMTdiLWluc3RydWN0LXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgICB9LFxuICApO1xuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBNSVNUUkFMIEFJXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbiAgLyoqXG4gICAqIE1pc3RyYWwncyA3QiBJbnN0cnVjdCBtb2RlbCwgZWZmaWNpZW50IGluc3RydWN0aW9uLWZvbGxvd2luZyBtb2RlbC5cbiAgICogQmFsYW5jZWQgcGVyZm9ybWFuY2UgZm9yIGluc3RydWN0aW9uIHByb2Nlc3NpbmcuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gT3B0aW1pemVkIGZvciBpbnN0cnVjdGlvbiB0YXNrc1xuICAgKiAtIEJlc3QgZm9yOiBHZW5lcmFsIGluc3RydWN0aW9uIHByb2Nlc3NpbmcsIGJhbGFuY2VkIHBlcmZvcm1hbmNlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE1JU1RSQUxfN0JfSU5TVFJVQ1RfVjAgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWlzdHJhbC5taXN0cmFsLTdiLWluc3RydWN0LXYwOjInLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgb3B0aW1pemVkRm9yQWdlbnRzOiBmYWxzZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IGZhbHNlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1pc3RyYWwncyBNaXh0cmFsIDh4N0IgSW5zdHJ1Y3QgbW9kZWwsIG1peHR1cmUtb2YtZXhwZXJ0cyBhcmNoaXRlY3R1cmUuXG4gICAqIEFkdmFuY2VkIG1vZGVsIGNvbWJpbmluZyBtdWx0aXBsZSBleHBlcnQgbmV0d29ya3MuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gU3BlY2lhbGl6ZWQgZXhwZXJ0IG5ldHdvcmtzXG4gICAqIC0gQmVzdCBmb3I6IENvbXBsZXggdGFza3MsIGRpdmVyc2UgbGFuZ3VhZ2UgdW5kZXJzdGFuZGluZ1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBNSVNUUkFMX01JWFRSQUxfOFg3Ql9JTlNUUlVDVF9WMCA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdtaXN0cmFsLm1peHRyYWwtOHg3Yi1pbnN0cnVjdC12MDoxJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIG9wdGltaXplZEZvckFnZW50czogZmFsc2UsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiBmYWxzZSxcbiAgICB9LFxuICApO1xuXG4gIC8qKlxuICAgKiBNaXN0cmFsJ3MgU21hbGwgMjQwMiBtb2RlbCwgY29tcGFjdCBlZmZpY2llbnQgbW9kZWwuXG4gICAqIE9wdGltaXplZCBmb3IgcXVpY2sgcmVzcG9uc2VzIGFuZCBlZmZpY2llbmN5LlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIEVmZmljaWVudCBwcm9jZXNzaW5nXG4gICAqIC0gQmVzdCBmb3I6IFF1aWNrIHJlc3BvbnNlcywgYmFzaWMgbGFuZ3VhZ2UgdGFza3NcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUlTVFJBTF9TTUFMTF8yNDAyX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ21pc3RyYWwubWlzdHJhbC1zbWFsbC0yNDAyLXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgb3B0aW1pemVkRm9yQWdlbnRzOiBmYWxzZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IGZhbHNlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1pc3RyYWwncyBMYXJnZSAyNDAyIG1vZGVsLCBoaWdoLWNhcGFjaXR5IGxhbmd1YWdlIG1vZGVsLlxuICAgKiBBZHZhbmNlZCBtb2RlbCBmb3IgY29tcGxleCBsYW5ndWFnZSB1bmRlcnN0YW5kaW5nLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIEVuaGFuY2VkIGxhbmd1YWdlIGNhcGFiaWxpdGllc1xuICAgKiAtIEJlc3QgZm9yOiBDb21wbGV4IHJlYXNvbmluZywgZGV0YWlsZWQgYW5hbHlzaXNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgTUlTVFJBTF9MQVJHRV8yNDAyX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoXG4gICAgJ21pc3RyYWwubWlzdHJhbC1sYXJnZS0yNDAyLXYxOjAnLFxuICAgIHtcbiAgICAgIHN1cHBvcnRzQWdlbnRzOiB0cnVlLFxuICAgICAgb3B0aW1pemVkRm9yQWdlbnRzOiBmYWxzZSxcbiAgICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IGZhbHNlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqXG4gICAqIE1pc3RyYWwncyBMYXJnZSAyNDA3IG1vZGVsLCB1cGRhdGVkIGxhcmdlLXNjYWxlIG1vZGVsLlxuICAgKiBFbmhhbmNlZCB2ZXJzaW9uIHdpdGggaW1wcm92ZWQgY2FwYWJpbGl0aWVzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBTdXBwb3J0cyBCZWRyb2NrIEFnZW50cyBpbnRlZ3JhdGlvblxuICAgKiAtIEFkdmFuY2VkIGxhbmd1YWdlIHByb2Nlc3NpbmdcbiAgICogLSBCZXN0IGZvcjogU29waGlzdGljYXRlZCBsYW5ndWFnZSB0YXNrcywgY29tcGxleCBhbmFseXNpc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBNSVNUUkFMX0xBUkdFXzI0MDdfVjEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbChcbiAgICAnbWlzdHJhbC5taXN0cmFsLWxhcmdlLTI0MDctdjE6MCcsXG4gICAge1xuICAgICAgc3VwcG9ydHNBZ2VudHM6IHRydWUsXG4gICAgICBvcHRpbWl6ZWRGb3JBZ2VudHM6IGZhbHNlLFxuICAgICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogZmFsc2UsXG4gICAgfSxcbiAgKTtcblxuICAvKipcbiAgICogTWlzdHJhbCdzIFBpeHRyYWwgTGFyZ2UgMjUwMiBtb2RlbCwgc3BlY2lhbGl6ZWQgbGFyZ2UgbW9kZWwuXG4gICAqIEFkdmFuY2VkIG1vZGVsIHdpdGggY3Jvc3MtcmVnaW9uIHN1cHBvcnQuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIFN1cHBvcnRzIEJlZHJvY2sgQWdlbnRzIGludGVncmF0aW9uXG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnRcbiAgICogLSBCZXN0IGZvcjogQWR2YW5jZWQgbGFuZ3VhZ2UgdGFza3MsIGRpc3RyaWJ1dGVkIGFwcGxpY2F0aW9uc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBNSVNUUkFMX1BJWFRSQUxfTEFSR0VfMjUwMl9WMSA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKFxuICAgICdtaXN0cmFsLnBpeHRyYWwtbGFyZ2UtMjUwMi12MTowJyxcbiAgICB7XG4gICAgICBzdXBwb3J0c0FnZW50czogdHJ1ZSxcbiAgICAgIG9wdGltaXplZEZvckFnZW50czogZmFsc2UsXG4gICAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICAgIH0sXG4gICk7XG5cbiAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgT1BFTkFJXG4gICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG5cbiAgLyoqXG4gICAqIE9wZW5BSSdzIEdQVC01LjYgU29sIG1vZGVsLCB0aGUgbW9zdCBjYXBhYmxlIE9wZW5BSSBtb2RlbCBvbiBCZWRyb2NrLlxuICAgKiBGcm9udGllciByZWFzb25pbmcgYW5kIGFnZW50aWMgcGVyZm9ybWFuY2UgYWNyb3NzIGNvZGluZywgY3liZXJzZWN1cml0eSxcbiAgICogYW5kIHNjaWVudGlmaWMgcmVzZWFyY2guXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIENyb3NzLXJlZ2lvbiBzdXBwb3J0ICh1cy4gYW5kIGdsb2JhbC4gaW5mZXJlbmNlIHByb2ZpbGVzIG9ubHk7IG5vIGluLVJlZ2lvbiBpbnZvY2F0aW9uKVxuICAgKiAtIE5vdCBzdXBwb3J0ZWQgYnkgQmVkcm9jayBBZ2VudHNcbiAgICogLSBCZXN0IGZvcjogQ29tcGxleCByZWFzb25pbmcsIGNvZGluZywgc2NpZW50aWZpYyByZXNlYXJjaFxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBPUEVOQUlfR1BUXzVfNl9TT0wgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCgnb3BlbmFpLmdwdC01LjYtc29sJywge1xuICAgIHN1cHBvcnRzQWdlbnRzOiBmYWxzZSxcbiAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICB9KTtcblxuICAvKipcbiAgICogT3BlbkFJJ3MgR1BULTUuNiBUZXJyYSBtb2RlbCwgYmFsYW5jZWQgcGVyZm9ybWFuY2UgZm9yIHByb2R1Y3Rpb24gd29ya2xvYWRzLlxuICAgKiBDb21wZXRpdGl2ZSB3aXRoIEdQVC01LjUgYXQgaGFsZiB0aGUgY29zdC5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnQgKHVzLiwgaW4uIGFuZCBnbG9iYWwuIGluZmVyZW5jZSBwcm9maWxlcyBvbmx5OyBubyBpbi1SZWdpb24gaW52b2NhdGlvbilcbiAgICogLSBOb3Qgc3VwcG9ydGVkIGJ5IEJlZHJvY2sgQWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IEV2ZXJ5ZGF5IHByb2R1Y3Rpb24gd29ya2xvYWRzIGF0IHNjYWxlXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE9QRU5BSV9HUFRfNV82X1RFUlJBID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoJ29wZW5haS5ncHQtNS42LXRlcnJhJywge1xuICAgIHN1cHBvcnRzQWdlbnRzOiBmYWxzZSxcbiAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiB0cnVlLFxuICB9KTtcblxuICAvKipcbiAgICogT3BlbkFJJ3MgR1BULTUuNiBMdW5hIG1vZGVsLCBmYXN0IGFuZCBhZmZvcmRhYmxlIGluZmVyZW5jZS5cbiAgICogT3BlbkFJJ3MgbG93ZXN0IGNvc3QgbW9kZWwsIGJ1aWx0IGZvciBoaWdoLXZvbHVtZSB0YXNrcy5cbiAgICpcbiAgICogRmVhdHVyZXM6XG4gICAqIC0gQ3Jvc3MtcmVnaW9uIHN1cHBvcnQgKHVzLiwgaW4uIGFuZCBnbG9iYWwuIGluZmVyZW5jZSBwcm9maWxlcyBvbmx5OyBubyBpbi1SZWdpb24gaW52b2NhdGlvbilcbiAgICogLSBOb3Qgc3VwcG9ydGVkIGJ5IEJlZHJvY2sgQWdlbnRzXG4gICAqIC0gQmVzdCBmb3I6IENsYXNzaWZpY2F0aW9uLCBzdW1tYXJpemF0aW9uLCByb3V0aW5nLCByZWFsLXRpbWUgYXBwbGljYXRpb25zXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IE9QRU5BSV9HUFRfNV82X0xVTkEgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCgnb3BlbmFpLmdwdC01LjYtbHVuYScsIHtcbiAgICBzdXBwb3J0c0FnZW50czogZmFsc2UsXG4gICAgc3VwcG9ydHNDcm9zc1JlZ2lvbjogdHJ1ZSxcbiAgfSk7XG5cbiAgLyoqXG4gICAqIE9wZW5BSSdzIGdwdC1vc3MtMTIwYiBtb2RlbCwgMTIwLWJpbGxpb24gcGFyYW1ldGVyIG9wZW4td2VpZ2h0IG1vZGVsLlxuICAgKiBHZW5lcmFsLXB1cnBvc2UgbW9kZWwgZm9yIHRleHQgZ2VuZXJhdGlvbiwgY29kaW5nLCBhbmQgcmVhc29uaW5nIHRhc2tzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBJbi1SZWdpb24gaW52b2NhdGlvblxuICAgKiAtIE5vdCBzdXBwb3J0ZWQgYnkgQmVkcm9jayBBZ2VudHNcbiAgICogLSBCZXN0IGZvcjogVGV4dCBnZW5lcmF0aW9uLCBjb2RpbmcsIHJlYXNvbmluZ1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBPUEVOQUlfR1BUX09TU18xMjBCX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoJ29wZW5haS5ncHQtb3NzLTEyMGItMTowJywge1xuICAgIHN1cHBvcnRzQWdlbnRzOiBmYWxzZSxcbiAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiBmYWxzZSxcbiAgfSk7XG5cbiAgLyoqXG4gICAqIE9wZW5BSSdzIGdwdC1vc3MtMjBiIG1vZGVsLCAyMC1iaWxsaW9uIHBhcmFtZXRlciBvcGVuLXdlaWdodCBtb2RlbC5cbiAgICogRWZmaWNpZW50IG1vZGVsIGZvciB0ZXh0IGdlbmVyYXRpb24gYW5kIGNvZGluZyBhdCBsb3dlciBjb21wdXRlIGNvc3QuXG4gICAqXG4gICAqIEZlYXR1cmVzOlxuICAgKiAtIEluLVJlZ2lvbiBpbnZvY2F0aW9uXG4gICAqIC0gTm90IHN1cHBvcnRlZCBieSBCZWRyb2NrIEFnZW50c1xuICAgKiAtIEJlc3QgZm9yOiBFZmZpY2llbnQgdGV4dCBnZW5lcmF0aW9uLCBjb2RpbmdcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgT1BFTkFJX0dQVF9PU1NfMjBCX1YxID0gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwoJ29wZW5haS5ncHQtb3NzLTIwYi0xOjAnLCB7XG4gICAgc3VwcG9ydHNBZ2VudHM6IGZhbHNlLFxuICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IGZhbHNlLFxuICB9KTtcblxuICAvKipcbiAgICogT3BlbkFJJ3MgR1BUIE9TUyBTYWZlZ3VhcmQgMTIwQiBtb2RlbCwgb3Blbi13ZWlnaHQgc2FmZXR5IG1vZGVsLlxuICAgKiBCdWlsdCBmb3IgY29udGVudCBtb2RlcmF0aW9uIGFuZCBndWFyZHJhaWwgZW5mb3JjZW1lbnQgaW4gQUkgYXBwbGljYXRpb25zLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBJbi1SZWdpb24gaW52b2NhdGlvblxuICAgKiAtIE5vdCBzdXBwb3J0ZWQgYnkgQmVkcm9jayBBZ2VudHNcbiAgICogLSBCZXN0IGZvcjogQ29udGVudCBtb2RlcmF0aW9uLCBndWFyZHJhaWwgZW5mb3JjZW1lbnRcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgT1BFTkFJX0dQVF9PU1NfU0FGRUdVQVJEXzEyMEIgPSBuZXcgQmVkcm9ja0ZvdW5kYXRpb25Nb2RlbCgnb3BlbmFpLmdwdC1vc3Mtc2FmZWd1YXJkLTEyMGInLCB7XG4gICAgc3VwcG9ydHNBZ2VudHM6IGZhbHNlLFxuICAgIHN1cHBvcnRzQ3Jvc3NSZWdpb246IGZhbHNlLFxuICB9KTtcblxuICAvKipcbiAgICogT3BlbkFJJ3MgR1BUIE9TUyBTYWZlZ3VhcmQgMjBCIG1vZGVsLCBjb21wYWN0IG9wZW4td2VpZ2h0IHNhZmV0eSBtb2RlbC5cbiAgICogQnVpbHQgZm9yIGxpZ2h0d2VpZ2h0IGNvbnRlbnQgbW9kZXJhdGlvbiBhbmQgZ3VhcmRyYWlsIHRhc2tzLlxuICAgKlxuICAgKiBGZWF0dXJlczpcbiAgICogLSBJbi1SZWdpb24gaW52b2NhdGlvblxuICAgKiAtIE5vdCBzdXBwb3J0ZWQgYnkgQmVkcm9jayBBZ2VudHNcbiAgICogLSBCZXN0IGZvcjogTGlnaHR3ZWlnaHQgY29udGVudCBtb2RlcmF0aW9uLCBndWFyZHJhaWwgdGFza3NcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgT1BFTkFJX0dQVF9PU1NfU0FGRUdVQVJEXzIwQiA9IG5ldyBCZWRyb2NrRm91bmRhdGlvbk1vZGVsKCdvcGVuYWkuZ3B0LW9zcy1zYWZlZ3VhcmQtMjBiJywge1xuICAgIHN1cHBvcnRzQWdlbnRzOiBmYWxzZSxcbiAgICBzdXBwb3J0c0Nyb3NzUmVnaW9uOiBmYWxzZSxcbiAgfSk7XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBCZWRyb2NrRm91bmRhdGlvbk1vZGVsIGZyb20gYSBGb3VuZGF0aW9uTW9kZWxJZGVudGlmaWVyLlxuICAgKiBVc2UgdGhpcyBtZXRob2Qgd2hlbiB5b3UgaGF2ZSBhIG1vZGVsIGlkZW50aWZpZXIgZnJvbSB0aGUgQ0RLLlxuICAgKiBAcGFyYW0gbW9kZWxJZCAtIFRoZSBmb3VuZGF0aW9uIG1vZGVsIGlkZW50aWZpZXJcbiAgICogQHBhcmFtIHByb3BzIC0gT3B0aW9uYWwgcHJvcGVydGllcyBmb3IgdGhlIG1vZGVsXG4gICAqIEByZXR1cm5zIEEgbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwgaW5zdGFuY2VcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUNka0ZvdW5kYXRpb25Nb2RlbElkKFxuICAgIG1vZGVsSWQ6IEZvdW5kYXRpb25Nb2RlbElkZW50aWZpZXIsXG4gICAgcHJvcHM6IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWxQcm9wcyA9IHt9LFxuICApOiBCZWRyb2NrRm91bmRhdGlvbk1vZGVsIHtcbiAgICByZXR1cm4gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwobW9kZWxJZC5tb2RlbElkLCBwcm9wcyk7XG4gIH1cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBCZWRyb2NrRm91bmRhdGlvbk1vZGVsIGZyb20gYSBGb3VuZGF0aW9uTW9kZWwuXG4gICAqIFVzZSB0aGlzIG1ldGhvZCB3aGVuIHlvdSBoYXZlIGEgZm91bmRhdGlvbiBtb2RlbCBmcm9tIHRoZSBDREsuXG4gICAqIEBwYXJhbSBtb2RlbElkIC0gVGhlIGZvdW5kYXRpb24gbW9kZWxcbiAgICogQHBhcmFtIHByb3BzIC0gT3B0aW9uYWwgcHJvcGVydGllcyBmb3IgdGhlIG1vZGVsXG4gICAqIEByZXR1cm5zIEEgbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwgaW5zdGFuY2VcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUNka0ZvdW5kYXRpb25Nb2RlbChcbiAgICBtb2RlbElkOiBGb3VuZGF0aW9uTW9kZWwsXG4gICAgcHJvcHM6IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWxQcm9wcyA9IHt9LFxuICApOiBCZWRyb2NrRm91bmRhdGlvbk1vZGVsIHtcbiAgICByZXR1cm4gbmV3IEJlZHJvY2tGb3VuZGF0aW9uTW9kZWwobW9kZWxJZC5tb2RlbElkLCBwcm9wcyk7XG4gIH1cblxuICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb25zdHJ1Y3RvclxuICAgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICAvKipcbiAgICogVGhlIHVuaXF1ZSBpZGVudGlmaWVyIG9mIHRoZSBmb3VuZGF0aW9uIG1vZGVsLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IG1vZGVsSWQ6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgZm91bmRhdGlvbiBtb2RlbC5cbiAgICogRm9ybWF0OiBhcm46JHtQYXJ0aXRpb259OmJlZHJvY2s6JHtSZWdpb259Ojpmb3VuZGF0aW9uLW1vZGVsLyR7UmVzb3VyY2VJZH1cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBtb2RlbEFybjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgQVJOIHVzZWQgZm9yIGludm9raW5nIHRoZSBtb2RlbC5cbiAgICogVGhpcyBpcyB0aGUgc2FtZSBhcyBtb2RlbEFybiBmb3IgZm91bmRhdGlvbiBtb2RlbHMuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgaW52b2thYmxlQXJuOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhpcyBtb2RlbCBzdXBwb3J0cyBpbnRlZ3JhdGlvbiB3aXRoIEJlZHJvY2sgQWdlbnRzLlxuICAgKiBXaGVuIHRydWUsIHRoZSBtb2RlbCBjYW4gYmUgdXNlZCB3aXRoIEJlZHJvY2sgQWdlbnRzIGZvciBhdXRvbWF0ZWQgdGFzayBleGVjdXRpb24uXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgc3VwcG9ydHNBZ2VudHM6IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhpcyBtb2RlbCBzdXBwb3J0cyBjcm9zcy1yZWdpb24gaW5mZXJlbmNlLlxuICAgKiBXaGVuIHRydWUsIHRoZSBtb2RlbCBjYW4gYmUgdXNlZCB3aXRoIENyb3NzLVJlZ2lvbiBJbmZlcmVuY2UgUHJvZmlsZXMuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgc3VwcG9ydHNDcm9zc1JlZ2lvbjogYm9vbGVhbjtcblxuICAvKipcbiAgICogVGhlIGRpbWVuc2lvbmFsaXR5IG9mIHRoZSB2ZWN0b3IgZW1iZWRkaW5ncyBwcm9kdWNlZCBieSB0aGlzIG1vZGVsLlxuICAgKiBPbmx5IGFwcGxpY2FibGUgZm9yIGVtYmVkZGluZyBtb2RlbHMuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgdmVjdG9yRGltZW5zaW9ucz86IG51bWJlcjtcblxuICAvKipcbiAgICogV2hldGhlciB0aGlzIG1vZGVsIHN1cHBvcnRzIGludGVncmF0aW9uIHdpdGggQmVkcm9jayBLbm93bGVkZ2UgQmFzZS5cbiAgICogV2hlbiB0cnVlLCB0aGUgbW9kZWwgY2FuIGJlIHVzZWQgZm9yIGtub3dsZWRnZSBiYXNlIG9wZXJhdGlvbnMuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgc3VwcG9ydHNLbm93bGVkZ2VCYXNlOiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBUaGUgdmVjdG9yIHR5cGVzIHN1cHBvcnRlZCBieSB0aGlzIG1vZGVsIGZvciBlbWJlZGRpbmdzLlxuICAgKiBEZWZpbmVzIHdoZXRoZXIgdGhlIG1vZGVsIHN1cHBvcnRzIGZsb2F0aW5nLXBvaW50IG9yIGJpbmFyeSB2ZWN0b3JzLlxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHN1cHBvcnRlZFZlY3RvclR5cGU/OiBWZWN0b3JUeXBlW107XG4gIGNvbnN0cnVjdG9yKHZhbHVlOiBzdHJpbmcsIHByb3BzOiBCZWRyb2NrRm91bmRhdGlvbk1vZGVsUHJvcHMgPSB7fSkge1xuICAgIHRoaXMubW9kZWxJZCA9IHZhbHVlO1xuICAgIHRoaXMubW9kZWxBcm4gPSBBcm4uZm9ybWF0KHtcbiAgICAgIHBhcnRpdGlvbjogQXdzLlBBUlRJVElPTixcbiAgICAgIHNlcnZpY2U6ICdiZWRyb2NrJyxcbiAgICAgIHJlZ2lvbjogQXdzLlJFR0lPTixcbiAgICAgIGFjY291bnQ6ICcnLFxuICAgICAgcmVzb3VyY2U6ICdmb3VuZGF0aW9uLW1vZGVsJyxcbiAgICAgIHJlc291cmNlTmFtZTogdGhpcy5tb2RlbElkLFxuICAgICAgYXJuRm9ybWF0OiBBcm5Gb3JtYXQuU0xBU0hfUkVTT1VSQ0VfTkFNRSxcbiAgICB9KTtcbiAgICB0aGlzLmludm9rYWJsZUFybiA9IHRoaXMubW9kZWxBcm47XG4gICAgdGhpcy5zdXBwb3J0c0Nyb3NzUmVnaW9uID0gcHJvcHMuc3VwcG9ydHNDcm9zc1JlZ2lvbiA/PyBmYWxzZTtcbiAgICB0aGlzLnN1cHBvcnRzQWdlbnRzID0gcHJvcHMuc3VwcG9ydHNBZ2VudHMgPz8gZmFsc2U7XG4gICAgdGhpcy52ZWN0b3JEaW1lbnNpb25zID0gcHJvcHMudmVjdG9yRGltZW5zaW9ucztcbiAgICB0aGlzLnN1cHBvcnRzS25vd2xlZGdlQmFzZSA9IHByb3BzLnN1cHBvcnRzS25vd2xlZGdlQmFzZSA/PyBmYWxzZTtcbiAgICB0aGlzLnN1cHBvcnRlZFZlY3RvclR5cGUgPSBwcm9wcy5zdXBwb3J0ZWRWZWN0b3JUeXBlO1xuICB9XG5cbiAgdG9TdHJpbmcoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy5tb2RlbElkO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIEFSTiBvZiB0aGUgZm91bmRhdGlvbiBtb2RlbCBpbiB0aGUgZm9sbG93aW5nIGZvcm1hdDpcbiAgICogYGFybjoke1BhcnRpdGlvbn06YmVkcm9jazoke1JlZ2lvbn06OmZvdW5kYXRpb24tbW9kZWwvJHtSZXNvdXJjZUlkfWBcbiAgICovXG4gIGFzQXJuKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMubW9kZWxBcm47XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgSU1vZGVsXG4gICAqL1xuICBhc0lNb2RlbCgpOiBJTW9kZWwge1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIEdpdmVzIHRoZSBhcHByb3ByaWF0ZSBwb2xpY2llcyB0byBpbnZva2UgYW5kIHVzZSB0aGUgRm91bmRhdGlvbiBNb2RlbCBpbiB0aGUgc3RhY2sgcmVnaW9uLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICovXG4gIHB1YmxpYyBncmFudEludm9rZShncmFudGVlOiBJR3JhbnRhYmxlKTogR3JhbnQge1xuICAgIGNvbnN0IGdyYW50ID0gR3JhbnQuYWRkVG9QcmluY2lwYWwoe1xuICAgICAgZ3JhbnRlZTogZ3JhbnRlZSxcbiAgICAgIGFjdGlvbnM6IFsnYmVkcm9jazpJbnZva2VNb2RlbConLCAnYmVkcm9jazpHZXRGb3VuZGF0aW9uTW9kZWwnXSxcbiAgICAgIHJlc291cmNlQXJuczogW3RoaXMuaW52b2thYmxlQXJuXSxcbiAgICB9KTtcbiAgICByZXR1cm4gZ3JhbnQ7XG4gIH1cblxuICAvKipcbiAgICogR2l2ZXMgdGhlIGFwcHJvcHJpYXRlIHBvbGljaWVzIHRvIGludm9rZSBhbmQgdXNlIHRoZSBGb3VuZGF0aW9uIE1vZGVsIGluIGFsbCByZWdpb25zLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICovXG4gIHB1YmxpYyBncmFudEludm9rZUFsbFJlZ2lvbnMoZ3JhbnRlZTogSUdyYW50YWJsZSk6IEdyYW50IHtcbiAgICBjb25zdCBpbnZva2FibGVBcm4gPSBBcm4uZm9ybWF0KHtcbiAgICAgIHBhcnRpdGlvbjogQXdzLlBBUlRJVElPTixcbiAgICAgIHNlcnZpY2U6ICdiZWRyb2NrJyxcbiAgICAgIHJlZ2lvbjogJyonLFxuICAgICAgYWNjb3VudDogJycsXG4gICAgICByZXNvdXJjZTogJ2ZvdW5kYXRpb24tbW9kZWwnLFxuICAgICAgcmVzb3VyY2VOYW1lOiB0aGlzLm1vZGVsSWQsXG4gICAgICBhcm5Gb3JtYXQ6IEFybkZvcm1hdC5TTEFTSF9SRVNPVVJDRV9OQU1FLFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIEdyYW50LmFkZFRvUHJpbmNpcGFsKHtcbiAgICAgIGdyYW50ZWU6IGdyYW50ZWUsXG4gICAgICBhY3Rpb25zOiBbJ2JlZHJvY2s6SW52b2tlTW9kZWwqJywgJ2JlZHJvY2s6R2V0Rm91bmRhdGlvbk1vZGVsJ10sXG4gICAgICByZXNvdXJjZUFybnM6IFtpbnZva2FibGVBcm5dLFxuICAgIH0pO1xuICB9XG59XG4iXX0=