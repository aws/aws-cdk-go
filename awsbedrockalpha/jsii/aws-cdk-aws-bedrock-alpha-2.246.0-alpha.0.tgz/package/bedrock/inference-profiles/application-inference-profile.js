"use strict";
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApplicationInferenceProfile = void 0;
const jsiiDeprecationWarnings = require("../../.warnings.jsii.js");
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const aws_cdk_lib_1 = require("aws-cdk-lib");
const bedrock = require("aws-cdk-lib/aws-bedrock");
const aws_iam_1 = require("aws-cdk-lib/aws-iam");
const metadata_resource_1 = require("aws-cdk-lib/core/lib/metadata-resource");
const prop_injectable_1 = require("aws-cdk-lib/core/lib/prop-injectable");
const inference_profile_1 = require("./inference-profile");
/******************************************************************************
 *                        NEW CONSTRUCT DEFINITION
 *****************************************************************************/
/**
 * Class to create an Application Inference Profile with CDK.
 * These are inference profiles created by users (user defined).
 * This helps to track costs and model usage.
 *
 * Application inference profiles are user-defined profiles that help you track costs and model usage.
 * They can be created for a single region or for multiple regions using a cross-region inference profile.
 *
 * @cloudformationResource AWS::Bedrock::ApplicationInferenceProfile
 * @see https://docs.aws.amazon.com/bedrock/latest/userguide/inference-profiles-create.html
 */
let ApplicationInferenceProfile = (() => {
    let _classDecorators = [prop_injectable_1.propertyInjectable];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = inference_profile_1.InferenceProfileBase;
    let _instanceExtraInitializers = [];
    let _grantInvoke_decorators;
    let _grantProfileUsage_decorators;
    var ApplicationInferenceProfile = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _grantInvoke_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            _grantProfileUsage_decorators = [(0, metadata_resource_1.MethodMetadata)()];
            __esDecorate(this, null, _grantInvoke_decorators, { kind: "method", name: "grantInvoke", static: false, private: false, access: { has: obj => "grantInvoke" in obj, get: obj => obj.grantInvoke }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(this, null, _grantProfileUsage_decorators, { kind: "method", name: "grantProfileUsage", static: false, private: false, access: { has: obj => "grantProfileUsage" in obj, get: obj => obj.grantProfileUsage }, metadata: _metadata }, null, _instanceExtraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            ApplicationInferenceProfile = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        static [JSII_RTTI_SYMBOL_1] = { fqn: "@aws-cdk/aws-bedrock-alpha.ApplicationInferenceProfile", version: "2.246.0-alpha.0" };
        /** Uniquely identifies this class. */
        static PROPERTY_INJECTION_ID = '@aws-cdk.aws-bedrock-alpha.ApplicationInferenceProfile';
        /**
         * Import an Application Inference Profile given its attributes.
         * [disable-awslint:no-grants]
         *
         * @param scope - The construct scope
         * @param id - Identifier of the construct
         * @param attrs - Attributes of the existing application inference profile
         * @returns An IInferenceProfile reference to the existing application inference profile
         */
        static fromApplicationInferenceProfileAttributes(scope, id, attrs) {
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfileAttributes(attrs);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, this.fromApplicationInferenceProfileAttributes);
                }
                throw error;
            }
            class Import extends inference_profile_1.InferenceProfileBase {
                inferenceProfileArn = attrs.inferenceProfileArn;
                inferenceProfileId = aws_cdk_lib_1.Arn.split(attrs.inferenceProfileArn, aws_cdk_lib_1.ArnFormat.SLASH_RESOURCE_NAME)
                    .resourceName;
                type = inference_profile_1.InferenceProfileType.APPLICATION;
                /**
                 * [disable-awslint:no-grants]
                 */
                grantProfileUsage(grantee) {
                    return aws_iam_1.Grant.addToPrincipal({
                        grantee: grantee,
                        actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel'],
                        resourceArns: [this.inferenceProfileArn],
                    });
                }
            }
            return new Import(scope, id);
        }
        /**
         * Import a low-level L1 Cfn Application Inference Profile.
         * [disable-awslint:no-grants]
         *
         * @param cfnApplicationInferenceProfile - The L1 CfnApplicationInferenceProfile to import
         * @returns An IInferenceProfile reference to the imported application inference profile
         */
        static fromCfnApplicationInferenceProfile(cfnApplicationInferenceProfile) {
            // Singleton pattern that will prevent creating 2 or more Inference Profiles from the same L1
            const id = '@FromCfnApplicationInferenceProfile';
            const existing = cfnApplicationInferenceProfile.node.tryFindChild(id);
            if (existing) {
                return existing;
            }
            return new (class extends inference_profile_1.InferenceProfileBase {
                inferenceProfileArn = cfnApplicationInferenceProfile.attrInferenceProfileArn;
                inferenceProfileId = cfnApplicationInferenceProfile.attrInferenceProfileId;
                type = inference_profile_1.InferenceProfileType.APPLICATION;
                /**
                 * [disable-awslint:no-grants]
                 */
                grantProfileUsage(grantee) {
                    return aws_iam_1.Grant.addToPrincipal({
                        grantee: grantee,
                        actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel'],
                        resourceArns: [this.inferenceProfileArn],
                    });
                }
            })(cfnApplicationInferenceProfile, id);
        }
        // ------------------------------------------------------
        // Base attributes
        // ------------------------------------------------------
        /**
         * The name of the application inference profile.
         */
        inferenceProfileName = __runInitializers(this, _instanceExtraInitializers);
        /**
         * The ARN of the application inference profile.
         * @attribute
         */
        inferenceProfileArn;
        /**
         * The unique identifier of the application inference profile.
         * @attribute
         */
        inferenceProfileId;
        /**
         * The underlying model/cross-region model used by the application inference profile.
         */
        inferenceProfileModel;
        /**
         * The status of the application inference profile. ACTIVE means that the inference profile is ready to be used.
         * @attribute
         */
        status;
        /**
         * The type of the inference profile. Always APPLICATION for application inference profiles.
         */
        type;
        /**
         * Time Stamp for Application Inference Profile creation.
         * @attribute
         */
        createdAt;
        /**
         * Time Stamp for Application Inference Profile update.
         * @attribute
         */
        updatedAt;
        /**
         * The ARN used for invoking this inference profile.
         * This equals to the inferenceProfileArn property, useful for implementing IBedrockInvokable interface.
         */
        invokableArn;
        // ------------------------------------------------------
        // Internal Only
        // ------------------------------------------------------
        /**
         * Instance of CfnApplicationInferenceProfile.
         * @internal
         */
        __resource;
        // ------------------------------------------------------
        // CONSTRUCTOR
        // ------------------------------------------------------
        constructor(scope, id, props) {
            super(scope, id);
            try {
                jsiiDeprecationWarnings._aws_cdk_aws_bedrock_alpha_ApplicationInferenceProfileProps(props);
            }
            catch (error) {
                if (process.env.JSII_DEBUG !== "1" && error.name === "DeprecationError") {
                    Error.captureStackTrace(error, ApplicationInferenceProfile);
                }
                throw error;
            }
            // Enhanced CDK Analytics Telemetry
            (0, metadata_resource_1.addConstructMetadata)(this, props);
            // ------------------------------------------------------
            // Validate props
            // ------------------------------------------------------
            this.validateProps(props);
            // ------------------------------------------------------
            // Set properties
            // ------------------------------------------------------
            this.inferenceProfileModel = props.modelSource;
            this.type = inference_profile_1.InferenceProfileType.APPLICATION;
            // ------------------------------------------------------
            // L1 instantiation
            // ------------------------------------------------------
            this.__resource = new bedrock.CfnApplicationInferenceProfile(this, 'Resource', {
                description: props.description,
                inferenceProfileName: props.applicationInferenceProfileName,
                modelSource: {
                    copyFrom: props.modelSource.invokableArn,
                },
                tags: props.tags ? Object.entries(props.tags).map(([key, value]) => ({ key, value })) : undefined,
            });
            // ------------------------------------------------------
            // Build attributes
            // ------------------------------------------------------
            this.inferenceProfileArn = this.__resource.attrInferenceProfileArn;
            this.inferenceProfileId = this.__resource.attrInferenceProfileId;
            this.inferenceProfileName = this.__resource.inferenceProfileName;
            this.status = this.__resource.attrStatus;
            this.createdAt = this.__resource.attrCreatedAt;
            this.updatedAt = this.__resource.attrUpdatedAt;
            this.invokableArn = this.inferenceProfileArn;
        }
        // ------------------------------------------------------
        // METHODS
        // ------------------------------------------------------
        /**
         * Validates the properties for creating an Application Inference Profile.
         *
         * @param props - The properties to validate
         * @throws ValidationError if any validation fails
         */
        validateProps(props) {
            // Validate applicationInferenceProfileName is provided and not empty
            if (!props.applicationInferenceProfileName || props.applicationInferenceProfileName.trim() === '') {
                throw new aws_cdk_lib_1.ValidationError('ProfileNameRequired', 'applicationInferenceProfileName is required and cannot be empty', this);
            }
            // Validate applicationInferenceProfileName length
            if (props.applicationInferenceProfileName.length > 64) {
                throw new aws_cdk_lib_1.ValidationError('ProfileNameTooLong', 'applicationInferenceProfileName cannot exceed 64 characters', this);
            }
            // Validate applicationInferenceProfileName pattern
            const namePattern = /^([0-9a-zA-Z:.][ _-]?)+$/;
            if (!namePattern.test(props.applicationInferenceProfileName)) {
                throw new aws_cdk_lib_1.ValidationError('ProfileNameInvalidPattern', 'applicationInferenceProfileName must match pattern ^([0-9a-zA-Z:.][ _-]?)+$', this);
            }
            // Validate modelSource is provided
            if (!props.modelSource) {
                throw new aws_cdk_lib_1.ValidationError('ModelSourceRequired', 'modelSource is required', this);
            }
            // Validate description length if provided
            if (props.description !== undefined && props.description.length > 200) {
                throw new aws_cdk_lib_1.ValidationError('DescriptionTooLong', 'description cannot exceed 200 characters', this);
            }
            // Validate description pattern if provided
            if (props.description !== undefined && props.description !== '') {
                const descriptionPattern = /^([0-9a-zA-Z:.][ _-]?)+$/;
                if (!descriptionPattern.test(props.description)) {
                    throw new aws_cdk_lib_1.ValidationError('DescriptionInvalidPattern', 'description must match pattern ^([0-9a-zA-Z:.][ _-]?)+$', this);
                }
            }
        }
        /**
         * Gives the appropriate policies to invoke and use the application inference profile.
         * This method ensures the appropriate permissions are given to use either the inference profile
         * or the underlying foundation model/cross-region profile.
         * [disable-awslint:no-grants]
         *
         * @param grantee - The IAM principal to grant permissions to
         * @returns An IAM Grant object representing the granted permissions
         */
        grantInvoke(grantee) {
            // This method ensures the appropriate permissions are given
            // to use either the inference profile or the vanilla foundation model
            this.inferenceProfileModel.grantInvoke(grantee);
            // Plus we add permissions to now invoke the application inference profile itself
            return this.grantProfileUsage(grantee);
        }
        /**
         * Grants appropriate permissions to use the application inference profile (AIP).
         * This method adds the necessary IAM permissions to allow the grantee to:
         * - Get inference profile details (bedrock:GetInferenceProfile)
         * - Invoke the model through the inference profile (bedrock:InvokeModel)
         *
         * Note: This does not grant permissions to use the underlying model/cross-region profile in the AIP.
         * For comprehensive permissions, use grantInvoke() instead.
         * [disable-awslint:no-grants]
         *
         * @param grantee - The IAM principal to grant permissions to
         * @returns An IAM Grant object representing the granted permissions
         */
        grantProfileUsage(grantee) {
            return aws_iam_1.Grant.addToPrincipal({
                grantee: grantee,
                actions: ['bedrock:GetInferenceProfile', 'bedrock:InvokeModel'],
                resourceArns: [this.inferenceProfileArn],
            });
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return ApplicationInferenceProfile = _classThis;
})();
exports.ApplicationInferenceProfile = ApplicationInferenceProfile;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwbGljYXRpb24taW5mZXJlbmNlLXByb2ZpbGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhcHBsaWNhdGlvbi1pbmZlcmVuY2UtcHJvZmlsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSw2Q0FBOEQ7QUFDOUQsbURBQW1EO0FBRW5ELGlEQUE0QztBQUM1Qyw4RUFBOEY7QUFDOUYsMEVBQTBFO0FBRzFFLDJEQUFpRjtBQTRFakY7OytFQUUrRTtBQUMvRTs7Ozs7Ozs7OztHQVVHO0lBRVUsMkJBQTJCOzRCQUR2QyxvQ0FBa0I7Ozs7c0JBQzhCLHdDQUFvQjs7OzsyQ0FBNUIsU0FBUSxXQUFvQjs7Ozt1Q0FtUGxFLElBQUEsa0NBQWMsR0FBRTs2Q0F1QmhCLElBQUEsa0NBQWMsR0FBRTtZQXRCakIsb0xBQU8sV0FBVyw2REFPakI7WUFnQkQsc01BQU8saUJBQWlCLDZEQU12QjtZQWpSSCw2S0FrUkM7Ozs7O1FBalJDLHNDQUFzQztRQUMvQixNQUFNLENBQVUscUJBQXFCLEdBQVcsd0RBQXdELENBQUM7UUFFaEg7Ozs7Ozs7O1dBUUc7UUFDSSxNQUFNLENBQUMseUNBQXlDLENBQ3JELEtBQWdCLEVBQ2hCLEVBQVUsRUFDVixLQUE0Qzs7Ozs7Ozs7OztZQUU1QyxNQUFNLE1BQU8sU0FBUSx3Q0FBb0I7Z0JBQ3ZCLG1CQUFtQixHQUFHLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQztnQkFDaEQsa0JBQWtCLEdBQUcsaUJBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLG1CQUFtQixFQUFFLHVCQUFTLENBQUMsbUJBQW1CLENBQUM7cUJBQ3JHLFlBQWEsQ0FBQztnQkFDRCxJQUFJLEdBQUcsd0NBQW9CLENBQUMsV0FBVyxDQUFDO2dCQUV4RDs7bUJBRUc7Z0JBQ0ksaUJBQWlCLENBQUMsT0FBbUI7b0JBQzFDLE9BQU8sZUFBSyxDQUFDLGNBQWMsQ0FBQzt3QkFDMUIsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLE9BQU8sRUFBRSxDQUFDLDZCQUE2QixFQUFFLHFCQUFxQixDQUFDO3dCQUMvRCxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7cUJBQ3pDLENBQUMsQ0FBQztnQkFDTCxDQUFDO2FBQ0Y7WUFFRCxPQUFPLElBQUksTUFBTSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztTQUM5QjtRQUVEOzs7Ozs7V0FNRztRQUNJLE1BQU0sQ0FBQyxrQ0FBa0MsQ0FDOUMsOEJBQXNFO1lBRXRFLDZGQUE2RjtZQUM3RixNQUFNLEVBQUUsR0FBRyxxQ0FBcUMsQ0FBQztZQUNqRCxNQUFNLFFBQVEsR0FBRyw4QkFBOEIsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3RFLElBQUksUUFBUSxFQUFFLENBQUM7Z0JBQ2IsT0FBTyxRQUF3QyxDQUFDO1lBQ2xELENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxLQUFNLFNBQVEsd0NBQW9CO2dCQUM1QixtQkFBbUIsR0FBRyw4QkFBOEIsQ0FBQyx1QkFBdUIsQ0FBQztnQkFDN0Usa0JBQWtCLEdBQUcsOEJBQThCLENBQUMsc0JBQXNCLENBQUM7Z0JBQzNFLElBQUksR0FBRyx3Q0FBb0IsQ0FBQyxXQUFXLENBQUM7Z0JBRXhEOzttQkFFRztnQkFDSSxpQkFBaUIsQ0FBQyxPQUFtQjtvQkFDMUMsT0FBTyxlQUFLLENBQUMsY0FBYyxDQUFDO3dCQUMxQixPQUFPLEVBQUUsT0FBTzt3QkFDaEIsT0FBTyxFQUFFLENBQUMsNkJBQTZCLEVBQUUscUJBQXFCLENBQUM7d0JBQy9ELFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztxQkFDekMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7YUFDRixDQUFDLENBQUMsOEJBQThCLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDeEM7UUFFRCx5REFBeUQ7UUFDekQsa0JBQWtCO1FBQ2xCLHlEQUF5RDtRQUN6RDs7V0FFRztRQUNhLG9CQUFvQixHQWhGekIsbURBQTJCLENBZ0ZPO1FBRTdDOzs7V0FHRztRQUNhLG1CQUFtQixDQUFTO1FBRTVDOzs7V0FHRztRQUNhLGtCQUFrQixDQUFTO1FBRTNDOztXQUVHO1FBQ2EscUJBQXFCLENBQW9CO1FBRXpEOzs7V0FHRztRQUNhLE1BQU0sQ0FBUztRQUUvQjs7V0FFRztRQUNhLElBQUksQ0FBdUI7UUFFM0M7OztXQUdHO1FBQ2EsU0FBUyxDQUFTO1FBRWxDOzs7V0FHRztRQUNhLFNBQVMsQ0FBUztRQUVsQzs7O1dBR0c7UUFDYSxZQUFZLENBQVM7UUFFckMseURBQXlEO1FBQ3pELGdCQUFnQjtRQUNoQix5REFBeUQ7UUFDekQ7OztXQUdHO1FBQ2MsVUFBVSxDQUF5QztRQUVwRSx5REFBeUQ7UUFDekQsY0FBYztRQUNkLHlEQUF5RDtRQUN6RCxZQUFZLEtBQWdCLEVBQUUsRUFBVSxFQUFFLEtBQXVDO1lBQy9FLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7Ozs7OzttREE3SVIsMkJBQTJCOzs7O1lBOElwQyxtQ0FBbUM7WUFDbkMsSUFBQSx3Q0FBb0IsRUFBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFbEMseURBQXlEO1lBQ3pELGlCQUFpQjtZQUNqQix5REFBeUQ7WUFDekQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUUxQix5REFBeUQ7WUFDekQsaUJBQWlCO1lBQ2pCLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQztZQUMvQyxJQUFJLENBQUMsSUFBSSxHQUFHLHdDQUFvQixDQUFDLFdBQVcsQ0FBQztZQUU3Qyx5REFBeUQ7WUFDekQsbUJBQW1CO1lBQ25CLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksT0FBTyxDQUFDLDhCQUE4QixDQUFDLElBQUksRUFBRSxVQUFVLEVBQUU7Z0JBQzdFLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVztnQkFDOUIsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLCtCQUErQjtnQkFDM0QsV0FBVyxFQUFFO29CQUNYLFFBQVEsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLFlBQVk7aUJBQ3pDO2dCQUNELElBQUksRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7YUFDbEcsQ0FBQyxDQUFDO1lBRUgseURBQXlEO1lBQ3pELG1CQUFtQjtZQUNuQix5REFBeUQ7WUFDekQsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsdUJBQXVCLENBQUM7WUFDbkUsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsc0JBQXNCLENBQUM7WUFDakUsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsb0JBQXFCLENBQUM7WUFDbEUsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQztZQUN6QyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO1lBQy9DLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUM7WUFDL0MsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUM7U0FDOUM7UUFFRCx5REFBeUQ7UUFDekQsVUFBVTtRQUNWLHlEQUF5RDtRQUV6RDs7Ozs7V0FLRztRQUNLLGFBQWEsQ0FBQyxLQUF1QztZQUMzRCxxRUFBcUU7WUFDckUsSUFBSSxDQUFDLEtBQUssQ0FBQywrQkFBK0IsSUFBSSxLQUFLLENBQUMsK0JBQStCLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUM7Z0JBQ2xHLE1BQU0sSUFBSSw2QkFBZSxDQUFDLHFCQUFxQixFQUFFLGlFQUFpRSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzVILENBQUM7WUFFRCxrREFBa0Q7WUFDbEQsSUFBSSxLQUFLLENBQUMsK0JBQStCLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRSxDQUFDO2dCQUN0RCxNQUFNLElBQUksNkJBQWUsQ0FBQyxvQkFBb0IsRUFBRSw2REFBNkQsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN2SCxDQUFDO1lBRUQsbURBQW1EO1lBQ25ELE1BQU0sV0FBVyxHQUFHLDBCQUEwQixDQUFDO1lBQy9DLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxFQUFFLENBQUM7Z0JBQzdELE1BQU0sSUFBSSw2QkFBZSxDQUN2QiwyQkFBMkIsRUFDM0IsNkVBQTZFLEVBQzdFLElBQUksQ0FDTCxDQUFDO1lBQ0osQ0FBQztZQUVELG1DQUFtQztZQUNuQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUN2QixNQUFNLElBQUksNkJBQWUsQ0FBQyxxQkFBcUIsRUFBRSx5QkFBeUIsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNwRixDQUFDO1lBRUQsMENBQTBDO1lBQzFDLElBQUksS0FBSyxDQUFDLFdBQVcsS0FBSyxTQUFTLElBQUksS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUM7Z0JBQ3RFLE1BQU0sSUFBSSw2QkFBZSxDQUFDLG9CQUFvQixFQUFFLDBDQUEwQyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3BHLENBQUM7WUFFRCwyQ0FBMkM7WUFDM0MsSUFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLEVBQUUsRUFBRSxDQUFDO2dCQUNoRSxNQUFNLGtCQUFrQixHQUFHLDBCQUEwQixDQUFDO2dCQUN0RCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDO29CQUNoRCxNQUFNLElBQUksNkJBQWUsQ0FDdkIsMkJBQTJCLEVBQzNCLHlEQUF5RCxFQUN6RCxJQUFJLENBQ0wsQ0FBQztnQkFDSixDQUFDO1lBQ0gsQ0FBQztTQUNGO1FBRUQ7Ozs7Ozs7O1dBUUc7UUFFSSxXQUFXLENBQUMsT0FBbUI7WUFDcEMsNERBQTREO1lBQzVELHNFQUFzRTtZQUN0RSxJQUFJLENBQUMscUJBQXFCLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRWhELGlGQUFpRjtZQUNqRixPQUFPLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUN4QztRQUVEOzs7Ozs7Ozs7Ozs7V0FZRztRQUVJLGlCQUFpQixDQUFDLE9BQW1CO1lBQzFDLE9BQU8sZUFBSyxDQUFDLGNBQWMsQ0FBQztnQkFDMUIsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLE9BQU8sRUFBRSxDQUFDLDZCQUE2QixFQUFFLHFCQUFxQixDQUFDO2dCQUMvRCxZQUFZLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7YUFDekMsQ0FBQyxDQUFDO1NBQ0o7O1lBalJVLHVEQUEyQjs7Ozs7QUFBM0Isa0VBQTJCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXJuLCBBcm5Gb3JtYXQsIFZhbGlkYXRpb25FcnJvciB9IGZyb20gJ2F3cy1jZGstbGliJztcbmltcG9ydCAqIGFzIGJlZHJvY2sgZnJvbSAnYXdzLWNkay1saWIvYXdzLWJlZHJvY2snO1xuaW1wb3J0IHR5cGUgeyBJR3JhbnRhYmxlIH0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWlhbSc7XG5pbXBvcnQgeyBHcmFudCB9IGZyb20gJ2F3cy1jZGstbGliL2F3cy1pYW0nO1xuaW1wb3J0IHsgYWRkQ29uc3RydWN0TWV0YWRhdGEsIE1ldGhvZE1ldGFkYXRhIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvbWV0YWRhdGEtcmVzb3VyY2UnO1xuaW1wb3J0IHsgcHJvcGVydHlJbmplY3RhYmxlIH0gZnJvbSAnYXdzLWNkay1saWIvY29yZS9saWIvcHJvcC1pbmplY3RhYmxlJztcbmltcG9ydCB0eXBlIHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5pbXBvcnQgdHlwZSB7IElJbmZlcmVuY2VQcm9maWxlIH0gZnJvbSAnLi9pbmZlcmVuY2UtcHJvZmlsZSc7XG5pbXBvcnQgeyBJbmZlcmVuY2VQcm9maWxlQmFzZSwgSW5mZXJlbmNlUHJvZmlsZVR5cGUgfSBmcm9tICcuL2luZmVyZW5jZS1wcm9maWxlJztcbmltcG9ydCB0eXBlIHsgSUJlZHJvY2tJbnZva2FibGUgfSBmcm9tICcuLi9tb2RlbHMnO1xuXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgIFBST1BTIEZPUiBORVcgQ09OU1RSVUNUXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIGNyZWF0aW5nIGFuIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZVByb3BzIHtcbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogVGhpcyBuYW1lIHdpbGwgYmUgdXNlZCB0byBpZGVudGlmeSB0aGUgaW5mZXJlbmNlIHByb2ZpbGUgaW4gdGhlIEFXUyBjb25zb2xlIGFuZCBBUElzLlxuICAgKiAtIFJlcXVpcmVkOiAgWWVzXG4gICAqIC0gTWF4aW11bSBsZW5ndGg6IDY0IGNoYXJhY3RlcnNcbiAgICogLSBQYXR0ZXJuOiBgXihbMC05YS16QS1aOi5dWyBfLV0/KSskYFxuICAgKlxuICAgKiBAc2VlIGh0dHBzOi8vZG9jcy5hd3MuYW1hem9uLmNvbS9BV1NDbG91ZEZvcm1hdGlvbi9sYXRlc3QvVXNlckd1aWRlL2F3cy1yZXNvdXJjZS1iZWRyb2NrLWFwcGxpY2F0aW9uaW5mZXJlbmNlcHJvZmlsZS5odG1sI2Nmbi1iZWRyb2NrLWFwcGxpY2F0aW9uaW5mZXJlbmNlcHJvZmlsZS1pbmZlcmVuY2Vwcm9maWxlbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBEZXNjcmlwdGlvbiBvZiB0aGUgaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFByb3ZpZGVzIGFkZGl0aW9uYWwgY29udGV4dCBhYm91dCB0aGUgcHVycG9zZSBhbmQgdXNhZ2Ugb2YgdGhpcyBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICpcbiAgICogLSBNYXhpbXVtIGxlbmd0aDogMjAwIGNoYXJhY3RlcnMgd2hlbiBwcm92aWRlZFxuICAgKiAtIFBhdHRlcm46IGBeKFswLTlhLXpBLVo6Ll1bIF8tXT8pKyRgXG4gICAqIEBkZWZhdWx0IC0gTm8gZGVzY3JpcHRpb24gaXMgcHJvdmlkZWRcbiAgICogQHNlZSBodHRwczovL2RvY3MuYXdzLmFtYXpvbi5jb20vQVdTQ2xvdWRGb3JtYXRpb24vbGF0ZXN0L1VzZXJHdWlkZS9hd3MtcmVzb3VyY2UtYmVkcm9jay1hcHBsaWNhdGlvbmluZmVyZW5jZXByb2ZpbGUuaHRtbCNjZm4tYmVkcm9jay1hcHBsaWNhdGlvbmluZmVyZW5jZXByb2ZpbGUtZGVzY3JpcHRpb25cbiAgICovXG4gIHJlYWRvbmx5IGRlc2NyaXB0aW9uPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbW9kZWwgc291cmNlIGZvciB0aGlzIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKlxuICAgKiBUbyBjcmVhdGUgYW4gYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUgZm9yIG9uZSBSZWdpb24sIHNwZWNpZnkgYSBmb3VuZGF0aW9uIG1vZGVsLlxuICAgKiBVc2FnZSBhbmQgY29zdHMgZm9yIHJlcXVlc3RzIG1hZGUgdG8gdGhhdCBSZWdpb24gd2l0aCB0aGF0IG1vZGVsIHdpbGwgYmUgdHJhY2tlZC5cbiAgICpcbiAgICogVG8gY3JlYXRlIGFuIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlIGZvciBtdWx0aXBsZSBSZWdpb25zLFxuICAgKiBzcGVjaWZ5IGEgY3Jvc3MgcmVnaW9uIChzeXN0ZW0tZGVmaW5lZCkgaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFRoZSBpbmZlcmVuY2UgcHJvZmlsZSB3aWxsIHJvdXRlIHJlcXVlc3RzIHRvIHRoZSBSZWdpb25zIGRlZmluZWQgaW5cbiAgICogdGhlIGNyb3NzIHJlZ2lvbiAoc3lzdGVtLWRlZmluZWQpIGluZmVyZW5jZSBwcm9maWxlIHRoYXQgeW91IGNob29zZS5cbiAgICogVXNhZ2UgYW5kIGNvc3RzIGZvciByZXF1ZXN0cyBtYWRlIHRvIHRoZSBSZWdpb25zIGluIHRoZSBpbmZlcmVuY2UgcHJvZmlsZSB3aWxsIGJlIHRyYWNrZWQuXG4gICAqXG4gICAqL1xuICByZWFkb25seSBtb2RlbFNvdXJjZTogSUJlZHJvY2tJbnZva2FibGU7XG4gIC8qKlxuICAgKiBBIGxpc3Qgb2YgdGFncyBhc3NvY2lhdGVkIHdpdGggdGhlIGluZmVyZW5jZSBwcm9maWxlLlxuICAgKiBUYWdzIGhlbHAgeW91IG9yZ2FuaXplIGFuZCBjYXRlZ29yaXplIHlvdXIgQVdTIHJlc291cmNlcy5cbiAgICpcbiAgICogQGRlZmF1bHQgLSBObyB0YWdzIGFyZSBhcHBsaWVkXG4gICAqL1xuICByZWFkb25seSB0YWdzPzogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfTtcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgQVRUUlMgRk9SIElNUE9SVEVEIENPTlNUUlVDVFxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuLyoqXG4gKiBBdHRyaWJ1dGVzIGZvciBzcGVjaWZ5aW5nIGFuIGltcG9ydGVkIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZUF0dHJpYnV0ZXMge1xuICAvKipcbiAgICogVGhlIEFSTiBvZiB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIEBhdHRyaWJ1dGVcbiAgICovXG4gIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVBcm46IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIElEIG9yIEFtYXpvbiBSZXNvdXJjZSBOYW1lIChBUk4pIG9mIHRoZSBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogVGhpcyBjYW4gYmUgZWl0aGVyIHRoZSBwcm9maWxlIElEIG9yIHRoZSBmdWxsIEFSTi5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZUlkZW50aWZpZXI6IHN0cmluZztcbn1cblxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogICAgICAgICAgICAgICAgICAgICAgICBORVcgQ09OU1RSVUNUIERFRklOSVRJT05cbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbi8qKlxuICogQ2xhc3MgdG8gY3JlYXRlIGFuIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlIHdpdGggQ0RLLlxuICogVGhlc2UgYXJlIGluZmVyZW5jZSBwcm9maWxlcyBjcmVhdGVkIGJ5IHVzZXJzICh1c2VyIGRlZmluZWQpLlxuICogVGhpcyBoZWxwcyB0byB0cmFjayBjb3N0cyBhbmQgbW9kZWwgdXNhZ2UuXG4gKlxuICogQXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGVzIGFyZSB1c2VyLWRlZmluZWQgcHJvZmlsZXMgdGhhdCBoZWxwIHlvdSB0cmFjayBjb3N0cyBhbmQgbW9kZWwgdXNhZ2UuXG4gKiBUaGV5IGNhbiBiZSBjcmVhdGVkIGZvciBhIHNpbmdsZSByZWdpb24gb3IgZm9yIG11bHRpcGxlIHJlZ2lvbnMgdXNpbmcgYSBjcm9zcy1yZWdpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gKlxuICogQGNsb3VkZm9ybWF0aW9uUmVzb3VyY2UgQVdTOjpCZWRyb2NrOjpBcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVcbiAqIEBzZWUgaHR0cHM6Ly9kb2NzLmF3cy5hbWF6b24uY29tL2JlZHJvY2svbGF0ZXN0L3VzZXJndWlkZS9pbmZlcmVuY2UtcHJvZmlsZXMtY3JlYXRlLmh0bWxcbiAqL1xuQHByb3BlcnR5SW5qZWN0YWJsZVxuZXhwb3J0IGNsYXNzIEFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZSBleHRlbmRzIEluZmVyZW5jZVByb2ZpbGVCYXNlIGltcGxlbWVudHMgSUJlZHJvY2tJbnZva2FibGUge1xuICAvKiogVW5pcXVlbHkgaWRlbnRpZmllcyB0aGlzIGNsYXNzLiAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IFBST1BFUlRZX0lOSkVDVElPTl9JRDogc3RyaW5nID0gJ0Bhd3MtY2RrLmF3cy1iZWRyb2NrLWFscGhhLkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZSc7XG5cbiAgLyoqXG4gICAqIEltcG9ydCBhbiBBcHBsaWNhdGlvbiBJbmZlcmVuY2UgUHJvZmlsZSBnaXZlbiBpdHMgYXR0cmlidXRlcy5cbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqXG4gICAqIEBwYXJhbSBzY29wZSAtIFRoZSBjb25zdHJ1Y3Qgc2NvcGVcbiAgICogQHBhcmFtIGlkIC0gSWRlbnRpZmllciBvZiB0aGUgY29uc3RydWN0XG4gICAqIEBwYXJhbSBhdHRycyAtIEF0dHJpYnV0ZXMgb2YgdGhlIGV4aXN0aW5nIGFwcGxpY2F0aW9uIGluZmVyZW5jZSBwcm9maWxlXG4gICAqIEByZXR1cm5zIEFuIElJbmZlcmVuY2VQcm9maWxlIHJlZmVyZW5jZSB0byB0aGUgZXhpc3RpbmcgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGVcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgZnJvbUFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZUF0dHJpYnV0ZXMoXG4gICAgc2NvcGU6IENvbnN0cnVjdCxcbiAgICBpZDogc3RyaW5nLFxuICAgIGF0dHJzOiBBcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVBdHRyaWJ1dGVzLFxuICApOiBJSW5mZXJlbmNlUHJvZmlsZSB7XG4gICAgY2xhc3MgSW1wb3J0IGV4dGVuZHMgSW5mZXJlbmNlUHJvZmlsZUJhc2Uge1xuICAgICAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVBcm4gPSBhdHRycy5pbmZlcmVuY2VQcm9maWxlQXJuO1xuICAgICAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVJZCA9IEFybi5zcGxpdChhdHRycy5pbmZlcmVuY2VQcm9maWxlQXJuLCBBcm5Gb3JtYXQuU0xBU0hfUkVTT1VSQ0VfTkFNRSlcbiAgICAgICAgLnJlc291cmNlTmFtZSE7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgdHlwZSA9IEluZmVyZW5jZVByb2ZpbGVUeXBlLkFQUExJQ0FUSU9OO1xuXG4gICAgICAvKipcbiAgICAgICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgICAgICovXG4gICAgICBwdWJsaWMgZ3JhbnRQcm9maWxlVXNhZ2UoZ3JhbnRlZTogSUdyYW50YWJsZSk6IEdyYW50IHtcbiAgICAgICAgcmV0dXJuIEdyYW50LmFkZFRvUHJpbmNpcGFsKHtcbiAgICAgICAgICBncmFudGVlOiBncmFudGVlLFxuICAgICAgICAgIGFjdGlvbnM6IFsnYmVkcm9jazpHZXRJbmZlcmVuY2VQcm9maWxlJywgJ2JlZHJvY2s6SW52b2tlTW9kZWwnXSxcbiAgICAgICAgICByZXNvdXJjZUFybnM6IFt0aGlzLmluZmVyZW5jZVByb2ZpbGVBcm5dLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IEltcG9ydChzY29wZSwgaWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIEltcG9ydCBhIGxvdy1sZXZlbCBMMSBDZm4gQXBwbGljYXRpb24gSW5mZXJlbmNlIFByb2ZpbGUuXG4gICAqIFtkaXNhYmxlLWF3c2xpbnQ6bm8tZ3JhbnRzXVxuICAgKlxuICAgKiBAcGFyYW0gY2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlIC0gVGhlIEwxIENmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZSB0byBpbXBvcnRcbiAgICogQHJldHVybnMgQW4gSUluZmVyZW5jZVByb2ZpbGUgcmVmZXJlbmNlIHRvIHRoZSBpbXBvcnRlZCBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZVxuICAgKi9cbiAgcHVibGljIHN0YXRpYyBmcm9tQ2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlKFxuICAgIGNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZTogYmVkcm9jay5DZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUsXG4gICk6IElJbmZlcmVuY2VQcm9maWxlIHtcbiAgICAvLyBTaW5nbGV0b24gcGF0dGVybiB0aGF0IHdpbGwgcHJldmVudCBjcmVhdGluZyAyIG9yIG1vcmUgSW5mZXJlbmNlIFByb2ZpbGVzIGZyb20gdGhlIHNhbWUgTDFcbiAgICBjb25zdCBpZCA9ICdARnJvbUNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZSc7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBjZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUubm9kZS50cnlGaW5kQ2hpbGQoaWQpO1xuICAgIGlmIChleGlzdGluZykge1xuICAgICAgcmV0dXJuIGV4aXN0aW5nIGFzIHVua25vd24gYXMgSUluZmVyZW5jZVByb2ZpbGU7XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyAoY2xhc3MgZXh0ZW5kcyBJbmZlcmVuY2VQcm9maWxlQmFzZSB7XG4gICAgICBwdWJsaWMgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZUFybiA9IGNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZS5hdHRySW5mZXJlbmNlUHJvZmlsZUFybjtcbiAgICAgIHB1YmxpYyByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlSWQgPSBjZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUuYXR0ckluZmVyZW5jZVByb2ZpbGVJZDtcbiAgICAgIHB1YmxpYyByZWFkb25seSB0eXBlID0gSW5mZXJlbmNlUHJvZmlsZVR5cGUuQVBQTElDQVRJT047XG5cbiAgICAgIC8qKlxuICAgICAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAgICAgKi9cbiAgICAgIHB1YmxpYyBncmFudFByb2ZpbGVVc2FnZShncmFudGVlOiBJR3JhbnRhYmxlKTogR3JhbnQge1xuICAgICAgICByZXR1cm4gR3JhbnQuYWRkVG9QcmluY2lwYWwoe1xuICAgICAgICAgIGdyYW50ZWU6IGdyYW50ZWUsXG4gICAgICAgICAgYWN0aW9uczogWydiZWRyb2NrOkdldEluZmVyZW5jZVByb2ZpbGUnLCAnYmVkcm9jazpJbnZva2VNb2RlbCddLFxuICAgICAgICAgIHJlc291cmNlQXJuczogW3RoaXMuaW5mZXJlbmNlUHJvZmlsZUFybl0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pKGNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZSwgaWQpO1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEJhc2UgYXR0cmlidXRlc1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSBpbmZlcmVuY2VQcm9maWxlTmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgQVJOIG9mIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVBcm46IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHVuaXF1ZSBpZGVudGlmaWVyIG9mIHRoZSBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZS5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IGluZmVyZW5jZVByb2ZpbGVJZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgdW5kZXJseWluZyBtb2RlbC9jcm9zcy1yZWdpb24gbW9kZWwgdXNlZCBieSB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgaW5mZXJlbmNlUHJvZmlsZU1vZGVsOiBJQmVkcm9ja0ludm9rYWJsZTtcblxuICAvKipcbiAgICogVGhlIHN0YXR1cyBvZiB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUuIEFDVElWRSBtZWFucyB0aGF0IHRoZSBpbmZlcmVuY2UgcHJvZmlsZSBpcyByZWFkeSB0byBiZSB1c2VkLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgc3RhdHVzOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSB0eXBlIG9mIHRoZSBpbmZlcmVuY2UgcHJvZmlsZS4gQWx3YXlzIEFQUExJQ0FUSU9OIGZvciBhcHBsaWNhdGlvbiBpbmZlcmVuY2UgcHJvZmlsZXMuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgdHlwZTogSW5mZXJlbmNlUHJvZmlsZVR5cGU7XG5cbiAgLyoqXG4gICAqIFRpbWUgU3RhbXAgZm9yIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlIGNyZWF0aW9uLlxuICAgKiBAYXR0cmlidXRlXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgY3JlYXRlZEF0OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRpbWUgU3RhbXAgZm9yIEFwcGxpY2F0aW9uIEluZmVyZW5jZSBQcm9maWxlIHVwZGF0ZS5cbiAgICogQGF0dHJpYnV0ZVxuICAgKi9cbiAgcHVibGljIHJlYWRvbmx5IHVwZGF0ZWRBdDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgQVJOIHVzZWQgZm9yIGludm9raW5nIHRoaXMgaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFRoaXMgZXF1YWxzIHRvIHRoZSBpbmZlcmVuY2VQcm9maWxlQXJuIHByb3BlcnR5LCB1c2VmdWwgZm9yIGltcGxlbWVudGluZyBJQmVkcm9ja0ludm9rYWJsZSBpbnRlcmZhY2UuXG4gICAqL1xuICBwdWJsaWMgcmVhZG9ubHkgaW52b2thYmxlQXJuOiBzdHJpbmc7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEludGVybmFsIE9ubHlcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBJbnN0YW5jZSBvZiBDZm5BcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGUuXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgcHJpdmF0ZSByZWFkb25seSBfX3Jlc291cmNlOiBiZWRyb2NrLkNmbkFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQ09OU1RSVUNUT1JcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzOiBBcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVQcm9wcykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCk7XG4gICAgLy8gRW5oYW5jZWQgQ0RLIEFuYWx5dGljcyBUZWxlbWV0cnlcbiAgICBhZGRDb25zdHJ1Y3RNZXRhZGF0YSh0aGlzLCBwcm9wcyk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBWYWxpZGF0ZSBwcm9wc1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMudmFsaWRhdGVQcm9wcyhwcm9wcyk7XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBTZXQgcHJvcGVydGllc1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMuaW5mZXJlbmNlUHJvZmlsZU1vZGVsID0gcHJvcHMubW9kZWxTb3VyY2U7XG4gICAgdGhpcy50eXBlID0gSW5mZXJlbmNlUHJvZmlsZVR5cGUuQVBQTElDQVRJT047XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBMMSBpbnN0YW50aWF0aW9uXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy5fX3Jlc291cmNlID0gbmV3IGJlZHJvY2suQ2ZuQXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlKHRoaXMsICdSZXNvdXJjZScsIHtcbiAgICAgIGRlc2NyaXB0aW9uOiBwcm9wcy5kZXNjcmlwdGlvbixcbiAgICAgIGluZmVyZW5jZVByb2ZpbGVOYW1lOiBwcm9wcy5hcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lLFxuICAgICAgbW9kZWxTb3VyY2U6IHtcbiAgICAgICAgY29weUZyb206IHByb3BzLm1vZGVsU291cmNlLmludm9rYWJsZUFybixcbiAgICAgIH0sXG4gICAgICB0YWdzOiBwcm9wcy50YWdzID8gT2JqZWN0LmVudHJpZXMocHJvcHMudGFncykubWFwKChba2V5LCB2YWx1ZV0pID0+ICh7IGtleSwgdmFsdWUgfSkpIDogdW5kZWZpbmVkLFxuICAgIH0pO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gQnVpbGQgYXR0cmlidXRlc1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIHRoaXMuaW5mZXJlbmNlUHJvZmlsZUFybiA9IHRoaXMuX19yZXNvdXJjZS5hdHRySW5mZXJlbmNlUHJvZmlsZUFybjtcbiAgICB0aGlzLmluZmVyZW5jZVByb2ZpbGVJZCA9IHRoaXMuX19yZXNvdXJjZS5hdHRySW5mZXJlbmNlUHJvZmlsZUlkO1xuICAgIHRoaXMuaW5mZXJlbmNlUHJvZmlsZU5hbWUgPSB0aGlzLl9fcmVzb3VyY2UuaW5mZXJlbmNlUHJvZmlsZU5hbWUhO1xuICAgIHRoaXMuc3RhdHVzID0gdGhpcy5fX3Jlc291cmNlLmF0dHJTdGF0dXM7XG4gICAgdGhpcy5jcmVhdGVkQXQgPSB0aGlzLl9fcmVzb3VyY2UuYXR0ckNyZWF0ZWRBdDtcbiAgICB0aGlzLnVwZGF0ZWRBdCA9IHRoaXMuX19yZXNvdXJjZS5hdHRyVXBkYXRlZEF0O1xuICAgIHRoaXMuaW52b2thYmxlQXJuID0gdGhpcy5pbmZlcmVuY2VQcm9maWxlQXJuO1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIE1FVEhPRFNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyB0aGUgcHJvcGVydGllcyBmb3IgY3JlYXRpbmcgYW4gQXBwbGljYXRpb24gSW5mZXJlbmNlIFByb2ZpbGUuXG4gICAqXG4gICAqIEBwYXJhbSBwcm9wcyAtIFRoZSBwcm9wZXJ0aWVzIHRvIHZhbGlkYXRlXG4gICAqIEB0aHJvd3MgVmFsaWRhdGlvbkVycm9yIGlmIGFueSB2YWxpZGF0aW9uIGZhaWxzXG4gICAqL1xuICBwcml2YXRlIHZhbGlkYXRlUHJvcHMocHJvcHM6IEFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZVByb3BzKTogdm9pZCB7XG4gICAgLy8gVmFsaWRhdGUgYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZSBpcyBwcm92aWRlZCBhbmQgbm90IGVtcHR5XG4gICAgaWYgKCFwcm9wcy5hcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lIHx8IHByb3BzLmFwcGxpY2F0aW9uSW5mZXJlbmNlUHJvZmlsZU5hbWUudHJpbSgpID09PSAnJykge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcignUHJvZmlsZU5hbWVSZXF1aXJlZCcsICdhcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lIGlzIHJlcXVpcmVkIGFuZCBjYW5ub3QgYmUgZW1wdHknLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBhcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lIGxlbmd0aFxuICAgIGlmIChwcm9wcy5hcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lLmxlbmd0aCA+IDY0KSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdQcm9maWxlTmFtZVRvb0xvbmcnLCAnYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZSBjYW5ub3QgZXhjZWVkIDY0IGNoYXJhY3RlcnMnLCB0aGlzKTtcbiAgICB9XG5cbiAgICAvLyBWYWxpZGF0ZSBhcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lIHBhdHRlcm5cbiAgICBjb25zdCBuYW1lUGF0dGVybiA9IC9eKFswLTlhLXpBLVo6Ll1bIF8tXT8pKyQvO1xuICAgIGlmICghbmFtZVBhdHRlcm4udGVzdChwcm9wcy5hcHBsaWNhdGlvbkluZmVyZW5jZVByb2ZpbGVOYW1lKSkge1xuICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihcbiAgICAgICAgJ1Byb2ZpbGVOYW1lSW52YWxpZFBhdHRlcm4nLFxuICAgICAgICAnYXBwbGljYXRpb25JbmZlcmVuY2VQcm9maWxlTmFtZSBtdXN0IG1hdGNoIHBhdHRlcm4gXihbMC05YS16QS1aOi5dWyBfLV0/KSskJyxcbiAgICAgICAgdGhpcyxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgbW9kZWxTb3VyY2UgaXMgcHJvdmlkZWRcbiAgICBpZiAoIXByb3BzLm1vZGVsU291cmNlKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdNb2RlbFNvdXJjZVJlcXVpcmVkJywgJ21vZGVsU291cmNlIGlzIHJlcXVpcmVkJywgdGhpcyk7XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgZGVzY3JpcHRpb24gbGVuZ3RoIGlmIHByb3ZpZGVkXG4gICAgaWYgKHByb3BzLmRlc2NyaXB0aW9uICE9PSB1bmRlZmluZWQgJiYgcHJvcHMuZGVzY3JpcHRpb24ubGVuZ3RoID4gMjAwKSB7XG4gICAgICB0aHJvdyBuZXcgVmFsaWRhdGlvbkVycm9yKCdEZXNjcmlwdGlvblRvb0xvbmcnLCAnZGVzY3JpcHRpb24gY2Fubm90IGV4Y2VlZCAyMDAgY2hhcmFjdGVycycsIHRoaXMpO1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIGRlc2NyaXB0aW9uIHBhdHRlcm4gaWYgcHJvdmlkZWRcbiAgICBpZiAocHJvcHMuZGVzY3JpcHRpb24gIT09IHVuZGVmaW5lZCAmJiBwcm9wcy5kZXNjcmlwdGlvbiAhPT0gJycpIHtcbiAgICAgIGNvbnN0IGRlc2NyaXB0aW9uUGF0dGVybiA9IC9eKFswLTlhLXpBLVo6Ll1bIF8tXT8pKyQvO1xuICAgICAgaWYgKCFkZXNjcmlwdGlvblBhdHRlcm4udGVzdChwcm9wcy5kZXNjcmlwdGlvbikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFZhbGlkYXRpb25FcnJvcihcbiAgICAgICAgICAnRGVzY3JpcHRpb25JbnZhbGlkUGF0dGVybicsXG4gICAgICAgICAgJ2Rlc2NyaXB0aW9uIG11c3QgbWF0Y2ggcGF0dGVybiBeKFswLTlhLXpBLVo6Ll1bIF8tXT8pKyQnLFxuICAgICAgICAgIHRoaXMsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdpdmVzIHRoZSBhcHByb3ByaWF0ZSBwb2xpY2llcyB0byBpbnZva2UgYW5kIHVzZSB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUuXG4gICAqIFRoaXMgbWV0aG9kIGVuc3VyZXMgdGhlIGFwcHJvcHJpYXRlIHBlcm1pc3Npb25zIGFyZSBnaXZlbiB0byB1c2UgZWl0aGVyIHRoZSBpbmZlcmVuY2UgcHJvZmlsZVxuICAgKiBvciB0aGUgdW5kZXJseWluZyBmb3VuZGF0aW9uIG1vZGVsL2Nyb3NzLXJlZ2lvbiBwcm9maWxlLlxuICAgKiBbZGlzYWJsZS1hd3NsaW50Om5vLWdyYW50c11cbiAgICpcbiAgICogQHBhcmFtIGdyYW50ZWUgLSBUaGUgSUFNIHByaW5jaXBhbCB0byBncmFudCBwZXJtaXNzaW9ucyB0b1xuICAgKiBAcmV0dXJucyBBbiBJQU0gR3JhbnQgb2JqZWN0IHJlcHJlc2VudGluZyB0aGUgZ3JhbnRlZCBwZXJtaXNzaW9uc1xuICAgKi9cbiAgQE1ldGhvZE1ldGFkYXRhKClcbiAgcHVibGljIGdyYW50SW52b2tlKGdyYW50ZWU6IElHcmFudGFibGUpOiBHcmFudCB7XG4gICAgLy8gVGhpcyBtZXRob2QgZW5zdXJlcyB0aGUgYXBwcm9wcmlhdGUgcGVybWlzc2lvbnMgYXJlIGdpdmVuXG4gICAgLy8gdG8gdXNlIGVpdGhlciB0aGUgaW5mZXJlbmNlIHByb2ZpbGUgb3IgdGhlIHZhbmlsbGEgZm91bmRhdGlvbiBtb2RlbFxuICAgIHRoaXMuaW5mZXJlbmNlUHJvZmlsZU1vZGVsLmdyYW50SW52b2tlKGdyYW50ZWUpO1xuXG4gICAgLy8gUGx1cyB3ZSBhZGQgcGVybWlzc2lvbnMgdG8gbm93IGludm9rZSB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUgaXRzZWxmXG4gICAgcmV0dXJuIHRoaXMuZ3JhbnRQcm9maWxlVXNhZ2UoZ3JhbnRlZSk7XG4gIH1cblxuICAvKipcbiAgICogR3JhbnRzIGFwcHJvcHJpYXRlIHBlcm1pc3Npb25zIHRvIHVzZSB0aGUgYXBwbGljYXRpb24gaW5mZXJlbmNlIHByb2ZpbGUgKEFJUCkuXG4gICAqIFRoaXMgbWV0aG9kIGFkZHMgdGhlIG5lY2Vzc2FyeSBJQU0gcGVybWlzc2lvbnMgdG8gYWxsb3cgdGhlIGdyYW50ZWUgdG86XG4gICAqIC0gR2V0IGluZmVyZW5jZSBwcm9maWxlIGRldGFpbHMgKGJlZHJvY2s6R2V0SW5mZXJlbmNlUHJvZmlsZSlcbiAgICogLSBJbnZva2UgdGhlIG1vZGVsIHRocm91Z2ggdGhlIGluZmVyZW5jZSBwcm9maWxlIChiZWRyb2NrOkludm9rZU1vZGVsKVxuICAgKlxuICAgKiBOb3RlOiBUaGlzIGRvZXMgbm90IGdyYW50IHBlcm1pc3Npb25zIHRvIHVzZSB0aGUgdW5kZXJseWluZyBtb2RlbC9jcm9zcy1yZWdpb24gcHJvZmlsZSBpbiB0aGUgQUlQLlxuICAgKiBGb3IgY29tcHJlaGVuc2l2ZSBwZXJtaXNzaW9ucywgdXNlIGdyYW50SW52b2tlKCkgaW5zdGVhZC5cbiAgICogW2Rpc2FibGUtYXdzbGludDpuby1ncmFudHNdXG4gICAqXG4gICAqIEBwYXJhbSBncmFudGVlIC0gVGhlIElBTSBwcmluY2lwYWwgdG8gZ3JhbnQgcGVybWlzc2lvbnMgdG9cbiAgICogQHJldHVybnMgQW4gSUFNIEdyYW50IG9iamVjdCByZXByZXNlbnRpbmcgdGhlIGdyYW50ZWQgcGVybWlzc2lvbnNcbiAgICovXG4gIEBNZXRob2RNZXRhZGF0YSgpXG4gIHB1YmxpYyBncmFudFByb2ZpbGVVc2FnZShncmFudGVlOiBJR3JhbnRhYmxlKTogR3JhbnQge1xuICAgIHJldHVybiBHcmFudC5hZGRUb1ByaW5jaXBhbCh7XG4gICAgICBncmFudGVlOiBncmFudGVlLFxuICAgICAgYWN0aW9uczogWydiZWRyb2NrOkdldEluZmVyZW5jZVByb2ZpbGUnLCAnYmVkcm9jazpJbnZva2VNb2RlbCddLFxuICAgICAgcmVzb3VyY2VBcm5zOiBbdGhpcy5pbmZlcmVuY2VQcm9maWxlQXJuXSxcbiAgICB9KTtcbiAgfVxufVxuIl19