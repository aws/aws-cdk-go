const VALIDATORS = { _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationAttributes: function _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationProps: function _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.checkpointInterval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.checkpointInterval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.logGroup))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_logs_ILogGroup(p.logGroup);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.minPauseBetweenCheckpoints))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.minPauseBetweenCheckpoints);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.removalPolicy))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_RemovalPolicy(p.removalPolicy);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.vpc))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_IVpc(p.vpc);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.vpcSubnets))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_SubnetSelection(p.vpcSubnets);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationCodeConfig: function _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationCodeConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.applicationCodeConfigurationProperty))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_kinesisanalytics_CfnApplicationV2_ApplicationConfigurationProperty(p.applicationCodeConfigurationProperty);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.bucket))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_s3_IBucket(p.bucket);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
