function _aws_cdk_aws_kinesisanalytics_flink_alpha_IApplication(p) {
}
function _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationAttributes(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.code))
            _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationCode(p.code);
        if (!visitedObjects.has(p.runtime))
            _aws_cdk_aws_kinesisanalytics_flink_alpha_Runtime(p.runtime);
        if (!visitedObjects.has(p.logLevel))
            _aws_cdk_aws_kinesisanalytics_flink_alpha_LogLevel(p.logLevel);
        if (!visitedObjects.has(p.metricsLevel))
            _aws_cdk_aws_kinesisanalytics_flink_alpha_MetricsLevel(p.metricsLevel);
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_kinesisanalytics_flink_alpha_Application(p) {
}
function _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationCodeConfig(p) {
}
function _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationCode(p) {
}
function _aws_cdk_aws_kinesisanalytics_flink_alpha_LogLevel(p) {
}
function _aws_cdk_aws_kinesisanalytics_flink_alpha_MetricsLevel(p) {
}
function _aws_cdk_aws_kinesisanalytics_flink_alpha_PropertyGroups(p) {
}
function _aws_cdk_aws_kinesisanalytics_flink_alpha_Runtime(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_kinesisanalytics_flink_alpha_IApplication, _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationAttributes, _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationProps, _aws_cdk_aws_kinesisanalytics_flink_alpha_Application, _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationCodeConfig, _aws_cdk_aws_kinesisanalytics_flink_alpha_ApplicationCode, _aws_cdk_aws_kinesisanalytics_flink_alpha_LogLevel, _aws_cdk_aws_kinesisanalytics_flink_alpha_MetricsLevel, _aws_cdk_aws_kinesisanalytics_flink_alpha_PropertyGroups, _aws_cdk_aws_kinesisanalytics_flink_alpha_Runtime };
