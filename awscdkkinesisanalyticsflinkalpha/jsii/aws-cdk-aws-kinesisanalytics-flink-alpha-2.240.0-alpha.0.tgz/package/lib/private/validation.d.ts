import type * as ec2 from 'aws-cdk-lib/aws-ec2';
interface ValidatedProps {
    applicationName?: string;
    parallelism?: number;
    parallelismPerKpu?: number;
    vpc?: ec2.IVpc;
    vpcSubnets?: ec2.SubnetSelection;
    securityGroups?: ec2.ISecurityGroup[];
}
/**
 * Early validation for the props used to create FlinkApplications.
 */
export declare function validateFlinkApplicationProps(props: ValidatedProps): void;
export {};
