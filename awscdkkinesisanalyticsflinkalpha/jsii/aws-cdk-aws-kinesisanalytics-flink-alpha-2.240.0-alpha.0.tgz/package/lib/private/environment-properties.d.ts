import type * as ka from 'aws-cdk-lib/aws-kinesisanalytics';
export declare function environmentProperties(propertyGroups?: {
    readonly [propertyId: string]: {
        [mapKey: string]: string;
    };
}): ka.CfnApplicationV2.EnvironmentPropertiesProperty | undefined;
