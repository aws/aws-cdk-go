function _aws_cdk_integ_tests_alpha_IntegTestCaseProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.stacks != null)
            for (const o of p.stacks)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Stack(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_integ_tests_alpha_IntegTestCase(p) {
}
function _aws_cdk_integ_tests_alpha_IntegTestCaseStackProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.propertyInjectors != null)
            for (const o of p.propertyInjectors)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_IPropertyInjector(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_integ_tests_alpha_IntegTestCaseStack(p) {
}
function _aws_cdk_integ_tests_alpha_IntegTestProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.testCases != null)
            for (const o of p.testCases)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Stack(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_integ_tests_alpha_IntegTest(p) {
}
function _aws_cdk_integ_tests_alpha_IDeployAssert(p) {
}
function _aws_cdk_integ_tests_alpha_AwsApiCallOptions(p) {
}
function _aws_cdk_integ_tests_alpha_AwsApiCallProps(p) {
}
function _aws_cdk_integ_tests_alpha_AwsApiCall(p) {
}
function _aws_cdk_integ_tests_alpha_LogType(p) {
}
function _aws_cdk_integ_tests_alpha_InvocationType(p) {
}
function _aws_cdk_integ_tests_alpha_LambdaInvokeFunctionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.invocationType))
            _aws_cdk_integ_tests_alpha_InvocationType(p.invocationType);
        if (!visitedObjects.has(p.logType))
            _aws_cdk_integ_tests_alpha_LogType(p.logType);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_integ_tests_alpha_LambdaInvokeFunction(p) {
}
function _aws_cdk_integ_tests_alpha_EqualsAssertionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.actual))
            _aws_cdk_integ_tests_alpha_ActualResult(p.actual);
        if (!visitedObjects.has(p.expected))
            _aws_cdk_integ_tests_alpha_ExpectedResult(p.expected);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_integ_tests_alpha_EqualsAssertion(p) {
}
function _aws_cdk_integ_tests_alpha_HttpRequestParameters(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.fetchOptions))
            _aws_cdk_integ_tests_alpha_FetchOptions(p.fetchOptions);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_integ_tests_alpha_HttpRequest(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.parameters))
            _aws_cdk_integ_tests_alpha_HttpRequestParameters(p.parameters);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_integ_tests_alpha_FetchOptions(p) {
}
function _aws_cdk_integ_tests_alpha_HttpResponseWrapper(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.apiCallResponse))
            _aws_cdk_integ_tests_alpha_HttpResponse(p.apiCallResponse);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_integ_tests_alpha_HttpResponse(p) {
}
function _aws_cdk_integ_tests_alpha_AwsApiCallRequest(p) {
}
function _aws_cdk_integ_tests_alpha_AwsApiCallResult(p) {
}
function _aws_cdk_integ_tests_alpha_AssertionType(p) {
}
function _aws_cdk_integ_tests_alpha_AssertionRequest(p) {
}
function _aws_cdk_integ_tests_alpha_AssertionResult(p) {
}
function _aws_cdk_integ_tests_alpha_Status(p) {
}
function _aws_cdk_integ_tests_alpha_AssertionResultData(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.status))
            _aws_cdk_integ_tests_alpha_Status(p.status);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_integ_tests_alpha_LambdaFunctionProviderProps(p) {
}
function _aws_cdk_integ_tests_alpha_AssertionsProviderProps(p) {
}
function _aws_cdk_integ_tests_alpha_AssertionsProvider(p) {
}
function _aws_cdk_integ_tests_alpha_ActualResult(p) {
}
function _aws_cdk_integ_tests_alpha_ExpectedResult(p) {
}
function _aws_cdk_integ_tests_alpha_Match(p) {
}
function _aws_cdk_integ_tests_alpha_IApiCall(p) {
}
function _aws_cdk_integ_tests_alpha_ApiCallBase(p) {
}
function _aws_cdk_integ_tests_alpha_WaiterStateMachineOptions(p) {
}
function _aws_cdk_integ_tests_alpha_WaiterStateMachineProps(p) {
}
function _aws_cdk_integ_tests_alpha_WaiterStateMachine(p) {
}
function _aws_cdk_integ_tests_alpha_HttpCallProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.fetchOptions))
            _aws_cdk_integ_tests_alpha_FetchOptions(p.fetchOptions);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_integ_tests_alpha_HttpApiCall(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_integ_tests_alpha_IntegTestCaseProps, _aws_cdk_integ_tests_alpha_IntegTestCase, _aws_cdk_integ_tests_alpha_IntegTestCaseStackProps, _aws_cdk_integ_tests_alpha_IntegTestCaseStack, _aws_cdk_integ_tests_alpha_IntegTestProps, _aws_cdk_integ_tests_alpha_IntegTest, _aws_cdk_integ_tests_alpha_IDeployAssert, _aws_cdk_integ_tests_alpha_AwsApiCallOptions, _aws_cdk_integ_tests_alpha_AwsApiCallProps, _aws_cdk_integ_tests_alpha_AwsApiCall, _aws_cdk_integ_tests_alpha_LogType, _aws_cdk_integ_tests_alpha_InvocationType, _aws_cdk_integ_tests_alpha_LambdaInvokeFunctionProps, _aws_cdk_integ_tests_alpha_LambdaInvokeFunction, _aws_cdk_integ_tests_alpha_EqualsAssertionProps, _aws_cdk_integ_tests_alpha_EqualsAssertion, _aws_cdk_integ_tests_alpha_HttpRequestParameters, _aws_cdk_integ_tests_alpha_HttpRequest, _aws_cdk_integ_tests_alpha_FetchOptions, _aws_cdk_integ_tests_alpha_HttpResponseWrapper, _aws_cdk_integ_tests_alpha_HttpResponse, _aws_cdk_integ_tests_alpha_AwsApiCallRequest, _aws_cdk_integ_tests_alpha_AwsApiCallResult, _aws_cdk_integ_tests_alpha_AssertionType, _aws_cdk_integ_tests_alpha_AssertionRequest, _aws_cdk_integ_tests_alpha_AssertionResult, _aws_cdk_integ_tests_alpha_Status, _aws_cdk_integ_tests_alpha_AssertionResultData, _aws_cdk_integ_tests_alpha_LambdaFunctionProviderProps, _aws_cdk_integ_tests_alpha_AssertionsProviderProps, _aws_cdk_integ_tests_alpha_AssertionsProvider, _aws_cdk_integ_tests_alpha_ActualResult, _aws_cdk_integ_tests_alpha_ExpectedResult, _aws_cdk_integ_tests_alpha_Match, _aws_cdk_integ_tests_alpha_IApiCall, _aws_cdk_integ_tests_alpha_ApiCallBase, _aws_cdk_integ_tests_alpha_WaiterStateMachineOptions, _aws_cdk_integ_tests_alpha_WaiterStateMachineProps, _aws_cdk_integ_tests_alpha_WaiterStateMachine, _aws_cdk_integ_tests_alpha_HttpCallProps, _aws_cdk_integ_tests_alpha_HttpApiCall };
