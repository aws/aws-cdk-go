import { CustomResourceHandler } from './base';
import type { HttpRequest, HttpResponseWrapper } from './types';
export declare class HttpHandler extends CustomResourceHandler<HttpRequest, HttpResponseWrapper | {
    [key: string]: unknown;
}> {
    protected processEvent(request: HttpRequest): Promise<HttpResponseWrapper | {
        [key: string]: unknown;
    }>;
}
