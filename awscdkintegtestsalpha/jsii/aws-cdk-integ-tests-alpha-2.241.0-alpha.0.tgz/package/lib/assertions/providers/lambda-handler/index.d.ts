export declare function handler(event: AWSLambda.CloudFormationCustomResourceEvent, context: AWSLambda.Context): Promise<void>;
/**
 * Invoked by the waiter statemachine when the retry
 * attempts are exhausted
 */
export declare function onTimeout(timeoutEvent: any): Promise<void>;
/**
 * Invoked by the waiter statemachine when the user is waiting for a specific
 * result.
 *
 * If the result of the assertion is not successful then it will throw an error
 * which will cause the state machine to try again
 */
export declare function isComplete(event: AWSLambda.CloudFormationCustomResourceEvent, context: AWSLambda.Context): Promise<void>;
