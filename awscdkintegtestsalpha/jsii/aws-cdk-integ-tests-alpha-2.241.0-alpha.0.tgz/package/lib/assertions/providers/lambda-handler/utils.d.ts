/**
 * Recurse into the given object, trying to parse any string as JSON
 */
export declare function deepParseJson<A extends string>(x: A): unknown;
export declare function deepParseJson<A extends object>(x: A): A;
export declare function decodeParameters(obj: Record<string, any>): any;
