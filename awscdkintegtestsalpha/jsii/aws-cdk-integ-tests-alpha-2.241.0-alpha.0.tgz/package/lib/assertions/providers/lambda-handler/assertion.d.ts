import { CustomResourceHandler } from './base';
import type { AssertionResult, AssertionRequest } from './types';
export declare class AssertionHandler extends CustomResourceHandler<AssertionRequest, AssertionResult> {
    protected processEvent(request: AssertionRequest): Promise<AssertionResult | undefined>;
}
