import { CustomResourceHandler } from './base';
import type { AwsApiCallRequest, AwsApiCallResult } from './types';
export declare class AwsApiCallHandler extends CustomResourceHandler<AwsApiCallRequest, AwsApiCallResult | {
    [key: string]: unknown;
}> {
    protected processEvent(request: AwsApiCallRequest): Promise<AwsApiCallResult | {
        [key: string]: unknown;
    } | undefined>;
}
