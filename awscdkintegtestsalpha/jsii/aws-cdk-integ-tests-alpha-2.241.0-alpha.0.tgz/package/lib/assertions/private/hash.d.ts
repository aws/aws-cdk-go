export declare function md5hash(obj: any): string;
