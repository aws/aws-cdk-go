import type { ISynthesisSession } from 'aws-cdk-lib/core';
import type { IntegTestCase } from './test-case';
export declare class IntegManifestSynthesizer {
    private readonly testCases;
    private readonly enableLookups?;
    constructor(testCases: IntegTestCase[], enableLookups?: boolean | undefined);
    synthesize(session: ISynthesisSession): void;
}
