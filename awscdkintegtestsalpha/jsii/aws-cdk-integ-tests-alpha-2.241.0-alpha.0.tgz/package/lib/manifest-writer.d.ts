import type { IntegManifest } from 'aws-cdk-lib/cloud-assembly-schema';
export declare class IntegManifestWriter {
    static readonly DEFAULT_FILENAME = "integ.json";
    static write(manifest: IntegManifest, filePath: string): void;
}
