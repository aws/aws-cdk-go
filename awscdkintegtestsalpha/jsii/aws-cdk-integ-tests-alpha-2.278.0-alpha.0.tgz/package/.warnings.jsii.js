const VALIDATORS = { _aws_cdk_integ_tests_alpha_IntegTestCaseProps: function _aws_cdk_integ_tests_alpha_IntegTestCaseProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.stacks != null)
                for (const o of p.stacks)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Stack(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.assertionStack))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Stack(p.assertionStack);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.cdkCommandOptions))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_cloud_assembly_schema_CdkCommands(p.cdkCommandOptions);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.hooks))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_cloud_assembly_schema_Hooks(p.hooks);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.providerLogLevel))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ApplicationLogLevel(p.providerLogLevel);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_IntegTestCaseStackProps: function _aws_cdk_integ_tests_alpha_IntegTestCaseStackProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.cdkCommandOptions))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_cloud_assembly_schema_CdkCommands(p.cdkCommandOptions);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.hooks))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_cloud_assembly_schema_Hooks(p.hooks);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.env))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Environment(p.env);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.permissionsBoundary))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_PermissionsBoundary(p.permissionsBoundary);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.propertyInjectors != null)
                for (const o of p.propertyInjectors)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_IPropertyInjector(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.synthesizer))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_IStackSynthesizer(p.synthesizer);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_IntegTestProps: function _aws_cdk_integ_tests_alpha_IntegTestProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.testCases != null)
                for (const o of p.testCases)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Stack(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
            if (!visitedObjects.has(p.assertionStack))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Stack(p.assertionStack);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.cdkCommandOptions))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_cloud_assembly_schema_CdkCommands(p.cdkCommandOptions);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.hooks))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_cloud_assembly_schema_Hooks(p.hooks);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.providerLogLevel))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ApplicationLogLevel(p.providerLogLevel);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_AwsApiCallOptions: function _aws_cdk_integ_tests_alpha_AwsApiCallOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.providerLogLevel))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ApplicationLogLevel(p.providerLogLevel);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_AwsApiCallProps: function _aws_cdk_integ_tests_alpha_AwsApiCallProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.providerLogLevel))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ApplicationLogLevel(p.providerLogLevel);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_LambdaInvokeFunctionProps: function _aws_cdk_integ_tests_alpha_LambdaInvokeFunctionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.logRetention))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_logs_RetentionDays(p.logRetention);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_EqualsAssertionProps: function _aws_cdk_integ_tests_alpha_EqualsAssertionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.providerLogLevel))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ApplicationLogLevel(p.providerLogLevel);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_ProviderOptions: function _aws_cdk_integ_tests_alpha_ProviderOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.providerLogLevel))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ApplicationLogLevel(p.providerLogLevel);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_LambdaFunctionProviderProps: function _aws_cdk_integ_tests_alpha_LambdaFunctionProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.logRetention))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_logs_RetentionDays(p.logRetention);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.providerLogLevel))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ApplicationLogLevel(p.providerLogLevel);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_AssertionsProviderProps: function _aws_cdk_integ_tests_alpha_AssertionsProviderProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.logRetention))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_logs_RetentionDays(p.logRetention);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.providerLogLevel))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ApplicationLogLevel(p.providerLogLevel);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_WaiterStateMachineOptions: function _aws_cdk_integ_tests_alpha_WaiterStateMachineOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.interval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.interval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.totalTimeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.totalTimeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.providerLogLevel))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ApplicationLogLevel(p.providerLogLevel);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_WaiterStateMachineProps: function _aws_cdk_integ_tests_alpha_WaiterStateMachineProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.interval))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.interval);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.totalTimeout))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Duration(p.totalTimeout);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.providerLogLevel))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ApplicationLogLevel(p.providerLogLevel);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_HttpCallProps: function _aws_cdk_integ_tests_alpha_HttpCallProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.providerLogLevel))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_lambda_ApplicationLogLevel(p.providerLogLevel);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
