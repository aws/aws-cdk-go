import type { IntegManifest, TestOptions } from 'aws-cdk-lib/cloud-assembly-schema';
import type { StackProps } from 'aws-cdk-lib/core';
import { Stack } from 'aws-cdk-lib/core';
import { Construct } from 'constructs';
import type { IDeployAssert, ProviderOptions } from './assertions';
/**
 * Properties of an integration test case
 */
export interface IntegTestCaseProps extends TestOptions, ProviderOptions {
    /**
     * Stacks to be deployed during the test
     */
    readonly stacks: Stack[];
    /**
     * Specify a stack to use for assertions
     *
     * @default - a stack is created for you
     */
    readonly assertionStack?: Stack;
}
/**
 * An integration test case. Allows the definition of test properties that
 * apply to all stacks under this case.
 *
 * It is recommended that you use the IntegTest construct since that will create
 * a default IntegTestCase
 */
export declare class IntegTestCase extends Construct {
    private readonly props;
    /**
     * Make assertions on resources in this test case
     */
    readonly assertions: IDeployAssert;
    private readonly _assert;
    constructor(scope: Construct, id: string, props: IntegTestCaseProps);
    /**
     * The integration test manifest for this test case. Manifests are used
     * by the integration test runner.
     */
    get manifest(): IntegManifest;
    private toTestCase;
}
/**
 * Properties of an integration test case stack
 */
export interface IntegTestCaseStackProps extends TestOptions, StackProps {
}
/**
 * An integration test case stack. Allows the definition of test properties
 * that should apply to this stack.
 *
 * This should be used if there are multiple stacks in the integration test
 * and it is necessary to specify different test case option for each. Otherwise
 * normal stacks should be added to IntegTest
 */
export declare class IntegTestCaseStack extends Stack {
    /**
     * Returns whether the construct is a IntegTestCaseStack
     */
    static isIntegTestCaseStack(x: any): x is IntegTestCaseStack;
    /**
     * Make assertions on resources in this test case
     */
    readonly assertions: IDeployAssert;
    /**
     * The underlying IntegTestCase that is created
     * @internal
     */
    readonly _testCase: IntegTestCase;
    constructor(scope: Construct, id: string, props?: IntegTestCaseStackProps);
}
/**
 * Integration test properties
 */
export interface IntegTestProps extends TestOptions, ProviderOptions {
    /**
     * List of test cases that make up this test
     */
    readonly testCases: Stack[];
    /**
     * Enable lookups for this test. If lookups are enabled
     * then `stackUpdateWorkflow` must be set to false.
     * Lookups should only be enabled when you are explicitly testing
     * lookups.
     *
     * @default false
     */
    readonly enableLookups?: boolean;
    /**
     * Specify a stack to use for assertions
     *
     * @default - a stack is created for you
     */
    readonly assertionStack?: Stack;
}
/**
 * A collection of test cases. Each test case file should contain exactly one
 * instance of this class.
 */
export declare class IntegTest extends Construct {
    /**
     * Make assertions on resources in this test case
     */
    readonly assertions: IDeployAssert;
    private readonly testCases;
    private readonly enableLookups?;
    constructor(scope: Construct, id: string, props: IntegTestProps);
}
