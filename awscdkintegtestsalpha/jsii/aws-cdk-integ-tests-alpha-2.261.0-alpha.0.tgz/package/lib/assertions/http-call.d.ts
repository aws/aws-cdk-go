import { CustomResource } from 'aws-cdk-lib';
import type { Construct } from 'constructs';
import type { IApiCall } from './api-call-base';
import { ApiCallBase } from './api-call-base';
import type { ExpectedResult } from './common';
import type { HttpRequestParameters, ProviderOptions } from './providers';
import { AssertionsProvider } from './providers';
import type { WaiterStateMachineOptions } from './waiter-state-machine';
/**
 * Options for creating an HttpApiCall provider
 */
export interface HttpCallProps extends HttpRequestParameters, ProviderOptions {
}
/**
 * Construct that creates a custom resource that will perform
 * an HTTP API Call
 */
export declare class HttpApiCall extends ApiCallBase {
    protected readonly apiCallResource: CustomResource;
    readonly provider: AssertionsProvider;
    private readonly providerLogLevel?;
    constructor(scope: Construct, id: string, props: HttpCallProps);
    assertAtPath(_path: string, _expected: ExpectedResult): IApiCall;
    waitForAssertions(options?: WaiterStateMachineOptions | undefined): IApiCall;
}
