const VALIDATORS = { _aws_cdk_integ_tests_alpha_IntegTestCaseProps: function _aws_cdk_integ_tests_alpha_IntegTestCaseProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.stacks != null)
                for (const o of p.stacks)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Stack(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_IntegTestCaseStackProps: function _aws_cdk_integ_tests_alpha_IntegTestCaseStackProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.propertyInjectors != null)
                for (const o of p.propertyInjectors)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_IPropertyInjector(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_integ_tests_alpha_IntegTestProps: function _aws_cdk_integ_tests_alpha_IntegTestProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.testCases != null)
                for (const o of p.testCases)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_Stack(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
