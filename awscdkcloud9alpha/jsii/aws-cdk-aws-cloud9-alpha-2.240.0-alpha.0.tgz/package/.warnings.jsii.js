function _aws_cdk_aws_cloud9_alpha_IEc2Environment(p) {
}
function _aws_cdk_aws_cloud9_alpha_ConnectionType(p) {
}
function _aws_cdk_aws_cloud9_alpha_ImageId(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        const ns = require("./lib/environment.js");
        if (Object.values(ns.ImageId).filter(x => x === p).length > 1)
            return;
        if (p === ns.ImageId.UBUNTU_18_04)
            print("@aws-cdk/aws-cloud9-alpha.ImageId#UBUNTU_18_04", "Since Ubuntu 18.04 has ended standard support as of May 31, 2023, we recommend you choose Ubuntu 22.04.");
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_cloud9_alpha_Ec2EnvironmentProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.imageId))
            _aws_cdk_aws_cloud9_alpha_ImageId(p.imageId);
        if (p.clonedRepositories != null)
            for (const o of p.clonedRepositories)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_cloud9_alpha_CloneRepository(o);
        if (!visitedObjects.has(p.connectionType))
            _aws_cdk_aws_cloud9_alpha_ConnectionType(p.connectionType);
        if (!visitedObjects.has(p.owner))
            _aws_cdk_aws_cloud9_alpha_Owner(p.owner);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_cloud9_alpha_Ec2Environment(p) {
}
function _aws_cdk_aws_cloud9_alpha_CloneRepository(p) {
}
function _aws_cdk_aws_cloud9_alpha_Owner(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_cloud9_alpha_IEc2Environment, _aws_cdk_aws_cloud9_alpha_ConnectionType, _aws_cdk_aws_cloud9_alpha_ImageId, _aws_cdk_aws_cloud9_alpha_Ec2EnvironmentProps, _aws_cdk_aws_cloud9_alpha_Ec2Environment, _aws_cdk_aws_cloud9_alpha_CloneRepository, _aws_cdk_aws_cloud9_alpha_Owner };
