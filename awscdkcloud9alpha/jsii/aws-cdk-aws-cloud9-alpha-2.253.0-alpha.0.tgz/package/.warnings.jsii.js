const VALIDATORS = { _aws_cdk_aws_cloud9_alpha_ImageId: function _aws_cdk_aws_cloud9_alpha_ImageId(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p === "ubuntu-18.04-x86_64")
                print("@aws-cdk/aws-cloud9-alpha.ImageId#UBUNTU_18_04", "Since Ubuntu 18.04 has ended standard support as of May 31, 2023, we recommend you choose Ubuntu 22.04.");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_cloud9_alpha_Ec2EnvironmentProps: function _aws_cdk_aws_cloud9_alpha_Ec2EnvironmentProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.imageId))
                module.exports._aws_cdk_aws_cloud9_alpha_ImageId(p.imageId);
            if (p.clonedRepositories != null)
                for (const o of p.clonedRepositories)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_cloud9_alpha_CloneRepository(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
