const VALIDATORS = { _aws_cdk_aws_pipes_alpha_EnrichmentParametersConfig: function _aws_cdk_aws_pipes_alpha_EnrichmentParametersConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.enrichmentParameters))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_pipes_CfnPipe_PipeEnrichmentParametersProperty(p.enrichmentParameters);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_alpha_S3LogDestinationProps: function _aws_cdk_aws_pipes_alpha_S3LogDestinationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.bucket))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_s3_IBucket(p.bucket);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_alpha_LogDestinationParameters: function _aws_cdk_aws_pipes_alpha_LogDestinationParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.cloudwatchLogsLogDestination))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_pipes_CfnPipe_CloudwatchLogsLogDestinationProperty(p.cloudwatchLogsLogDestination);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.firehoseLogDestination))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_pipes_CfnPipe_FirehoseLogDestinationProperty(p.firehoseLogDestination);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.s3LogDestination))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_pipes_CfnPipe_S3LogDestinationProperty(p.s3LogDestination);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_alpha_LogDestinationConfig: function _aws_cdk_aws_pipes_alpha_LogDestinationConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.parameters))
                module.exports._aws_cdk_aws_pipes_alpha_LogDestinationParameters(p.parameters);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_alpha_PipeProps: function _aws_cdk_aws_pipes_alpha_PipeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.kmsKey))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_kms_IKey(p.kmsKey);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.logDestinations != null)
                for (const o of p.logDestinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_pipes_alpha_ILogDestination(o);
            if (p.logIncludeExecutionData != null)
                for (const o of p.logIncludeExecutionData)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_pipes_alpha_IncludeExecutionData(o);
            if (!visitedObjects.has(p.role))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(p.role);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_alpha_SourceParameters: function _aws_cdk_aws_pipes_alpha_SourceParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.activeMqBrokerParameters))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_pipes_CfnPipe_PipeSourceActiveMQBrokerParametersProperty(p.activeMqBrokerParameters);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.dynamoDbStreamParameters))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_pipes_CfnPipe_PipeSourceDynamoDBStreamParametersProperty(p.dynamoDbStreamParameters);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.kinesisStreamParameters))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_pipes_CfnPipe_PipeSourceKinesisStreamParametersProperty(p.kinesisStreamParameters);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.managedStreamingKafkaParameters))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_pipes_CfnPipe_PipeSourceManagedStreamingKafkaParametersProperty(p.managedStreamingKafkaParameters);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.rabbitMqBrokerParameters))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_pipes_CfnPipe_PipeSourceRabbitMQBrokerParametersProperty(p.rabbitMqBrokerParameters);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.selfManagedKafkaParameters))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_pipes_CfnPipe_PipeSourceSelfManagedKafkaParametersProperty(p.selfManagedKafkaParameters);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.sqsQueueParameters))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_pipes_CfnPipe_PipeSourceSqsQueueParametersProperty(p.sqsQueueParameters);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_alpha_SourceConfig: function _aws_cdk_aws_pipes_alpha_SourceConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.sourceParameters))
                module.exports._aws_cdk_aws_pipes_alpha_SourceParameters(p.sourceParameters);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_alpha_TargetConfig: function _aws_cdk_aws_pipes_alpha_TargetConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.targetParameters))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_pipes_CfnPipe_PipeTargetParametersProperty(p.targetParameters);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
