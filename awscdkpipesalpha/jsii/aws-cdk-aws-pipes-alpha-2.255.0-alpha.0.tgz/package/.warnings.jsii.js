const VALIDATORS = { _aws_cdk_aws_pipes_alpha_LogDestinationConfig: function _aws_cdk_aws_pipes_alpha_LogDestinationConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.parameters))
                module.exports._aws_cdk_aws_pipes_alpha_LogDestinationParameters(p.parameters);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_alpha_PipeProps: function _aws_cdk_aws_pipes_alpha_PipeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.logDestinations != null)
                for (const o of p.logDestinations)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_pipes_alpha_ILogDestination(o);
            if (p.logIncludeExecutionData != null)
                for (const o of p.logIncludeExecutionData)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_pipes_alpha_IncludeExecutionData(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_pipes_alpha_SourceConfig: function _aws_cdk_aws_pipes_alpha_SourceConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.sourceParameters))
                module.exports._aws_cdk_aws_pipes_alpha_SourceParameters(p.sourceParameters);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
