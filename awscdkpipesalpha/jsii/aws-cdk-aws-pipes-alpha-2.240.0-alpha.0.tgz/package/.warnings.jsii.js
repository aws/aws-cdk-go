function _aws_cdk_aws_pipes_alpha_EnrichmentParametersConfig(p) {
}
function _aws_cdk_aws_pipes_alpha_IEnrichment(p) {
}
function _aws_cdk_aws_pipes_alpha_InputTransformationConfig(p) {
}
function _aws_cdk_aws_pipes_alpha_IInputTransformation(p) {
}
function _aws_cdk_aws_pipes_alpha_InputTransformation(p) {
}
function _aws_cdk_aws_pipes_alpha_IncludeExecutionData(p) {
}
function _aws_cdk_aws_pipes_alpha_LogLevel(p) {
}
function _aws_cdk_aws_pipes_alpha_S3OutputFormat(p) {
}
function _aws_cdk_aws_pipes_alpha_S3LogDestinationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.outputFormat))
            _aws_cdk_aws_pipes_alpha_S3OutputFormat(p.outputFormat);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_pipes_alpha_LogDestinationParameters(p) {
}
function _aws_cdk_aws_pipes_alpha_LogDestinationConfig(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.parameters))
            _aws_cdk_aws_pipes_alpha_LogDestinationParameters(p.parameters);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_pipes_alpha_ILogDestination(p) {
}
function _aws_cdk_aws_pipes_alpha_CloudwatchLogsLogDestination(p) {
}
function _aws_cdk_aws_pipes_alpha_FirehoseLogDestination(p) {
}
function _aws_cdk_aws_pipes_alpha_S3LogDestination(p) {
}
function _aws_cdk_aws_pipes_alpha_IPipe(p) {
}
function _aws_cdk_aws_pipes_alpha_DesiredState(p) {
}
function _aws_cdk_aws_pipes_alpha_PipeProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.source))
            _aws_cdk_aws_pipes_alpha_ISource(p.source);
        if (!visitedObjects.has(p.target))
            _aws_cdk_aws_pipes_alpha_ITarget(p.target);
        if (!visitedObjects.has(p.desiredState))
            _aws_cdk_aws_pipes_alpha_DesiredState(p.desiredState);
        if (!visitedObjects.has(p.enrichment))
            _aws_cdk_aws_pipes_alpha_IEnrichment(p.enrichment);
        if (!visitedObjects.has(p.filter))
            _aws_cdk_aws_pipes_alpha_IFilter(p.filter);
        if (p.logDestinations != null)
            for (const o of p.logDestinations)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_pipes_alpha_ILogDestination(o);
        if (p.logIncludeExecutionData != null)
            for (const o of p.logIncludeExecutionData)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_pipes_alpha_IncludeExecutionData(o);
        if (!visitedObjects.has(p.logLevel))
            _aws_cdk_aws_pipes_alpha_LogLevel(p.logLevel);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_pipes_alpha_Pipe(p) {
}
function _aws_cdk_aws_pipes_alpha_PipeVariable(p) {
}
function _aws_cdk_aws_pipes_alpha_DynamicInput(p) {
}
function _aws_cdk_aws_pipes_alpha_SourceParameters(p) {
}
function _aws_cdk_aws_pipes_alpha_SourceConfig(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sourceParameters))
            _aws_cdk_aws_pipes_alpha_SourceParameters(p.sourceParameters);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_pipes_alpha_ISource(p) {
}
function _aws_cdk_aws_pipes_alpha_SourceWithDeadLetterTarget(p) {
}
function _aws_cdk_aws_pipes_alpha_IFilterPattern(p) {
}
function _aws_cdk_aws_pipes_alpha_IFilter(p) {
}
function _aws_cdk_aws_pipes_alpha_Filter(p) {
}
function _aws_cdk_aws_pipes_alpha_FilterPattern(p) {
}
function _aws_cdk_aws_pipes_alpha_TargetConfig(p) {
}
function _aws_cdk_aws_pipes_alpha_ITarget(p) {
}
function _aws_cdk_aws_pipes_alpha_TargetParameter(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_pipes_alpha_EnrichmentParametersConfig, _aws_cdk_aws_pipes_alpha_IEnrichment, _aws_cdk_aws_pipes_alpha_InputTransformationConfig, _aws_cdk_aws_pipes_alpha_IInputTransformation, _aws_cdk_aws_pipes_alpha_InputTransformation, _aws_cdk_aws_pipes_alpha_IncludeExecutionData, _aws_cdk_aws_pipes_alpha_LogLevel, _aws_cdk_aws_pipes_alpha_S3OutputFormat, _aws_cdk_aws_pipes_alpha_S3LogDestinationProps, _aws_cdk_aws_pipes_alpha_LogDestinationParameters, _aws_cdk_aws_pipes_alpha_LogDestinationConfig, _aws_cdk_aws_pipes_alpha_ILogDestination, _aws_cdk_aws_pipes_alpha_CloudwatchLogsLogDestination, _aws_cdk_aws_pipes_alpha_FirehoseLogDestination, _aws_cdk_aws_pipes_alpha_S3LogDestination, _aws_cdk_aws_pipes_alpha_IPipe, _aws_cdk_aws_pipes_alpha_DesiredState, _aws_cdk_aws_pipes_alpha_PipeProps, _aws_cdk_aws_pipes_alpha_Pipe, _aws_cdk_aws_pipes_alpha_PipeVariable, _aws_cdk_aws_pipes_alpha_DynamicInput, _aws_cdk_aws_pipes_alpha_SourceParameters, _aws_cdk_aws_pipes_alpha_SourceConfig, _aws_cdk_aws_pipes_alpha_ISource, _aws_cdk_aws_pipes_alpha_SourceWithDeadLetterTarget, _aws_cdk_aws_pipes_alpha_IFilterPattern, _aws_cdk_aws_pipes_alpha_IFilter, _aws_cdk_aws_pipes_alpha_Filter, _aws_cdk_aws_pipes_alpha_FilterPattern, _aws_cdk_aws_pipes_alpha_TargetConfig, _aws_cdk_aws_pipes_alpha_ITarget, _aws_cdk_aws_pipes_alpha_TargetParameter };
