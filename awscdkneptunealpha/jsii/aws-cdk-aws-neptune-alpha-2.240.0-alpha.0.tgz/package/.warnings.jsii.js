function _aws_cdk_aws_neptune_alpha_EngineVersion(p) {
}
function _aws_cdk_aws_neptune_alpha_LogType(p) {
}
function _aws_cdk_aws_neptune_alpha_ServerlessScalingConfiguration(p) {
}
function _aws_cdk_aws_neptune_alpha_DatabaseClusterProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.instanceType))
            _aws_cdk_aws_neptune_alpha_InstanceType(p.instanceType);
        if (p.associatedRoles != null)
            for (const o of p.associatedRoles)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(o);
        if (p.cloudwatchLogsExports != null)
            for (const o of p.cloudwatchLogsExports)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_neptune_alpha_LogType(o);
        if (!visitedObjects.has(p.clusterParameterGroup))
            _aws_cdk_aws_neptune_alpha_IClusterParameterGroup(p.clusterParameterGroup);
        if (!visitedObjects.has(p.engineVersion))
            _aws_cdk_aws_neptune_alpha_EngineVersion(p.engineVersion);
        if (!visitedObjects.has(p.parameterGroup))
            _aws_cdk_aws_neptune_alpha_IParameterGroup(p.parameterGroup);
        if (p.securityGroups != null)
            for (const o of p.securityGroups)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        if (!visitedObjects.has(p.serverlessScalingConfiguration))
            _aws_cdk_aws_neptune_alpha_ServerlessScalingConfiguration(p.serverlessScalingConfiguration);
        if (!visitedObjects.has(p.subnetGroup))
            _aws_cdk_aws_neptune_alpha_ISubnetGroup(p.subnetGroup);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_neptune_alpha_IDatabaseCluster(p) {
}
function _aws_cdk_aws_neptune_alpha_DatabaseClusterAttributes(p) {
}
function _aws_cdk_aws_neptune_alpha_DatabaseClusterBase(p) {
}
function _aws_cdk_aws_neptune_alpha_DatabaseCluster(p) {
}
function _aws_cdk_aws_neptune_alpha_InstanceType(p) {
}
function _aws_cdk_aws_neptune_alpha_IDatabaseInstance(p) {
}
function _aws_cdk_aws_neptune_alpha_DatabaseInstanceAttributes(p) {
}
function _aws_cdk_aws_neptune_alpha_DatabaseInstanceProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.cluster))
            _aws_cdk_aws_neptune_alpha_IDatabaseCluster(p.cluster);
        if (!visitedObjects.has(p.instanceType))
            _aws_cdk_aws_neptune_alpha_InstanceType(p.instanceType);
        if (!visitedObjects.has(p.parameterGroup))
            _aws_cdk_aws_neptune_alpha_IParameterGroup(p.parameterGroup);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_neptune_alpha_DatabaseInstanceBase(p) {
}
function _aws_cdk_aws_neptune_alpha_DatabaseInstance(p) {
}
function _aws_cdk_aws_neptune_alpha_Endpoint(p) {
}
function _aws_cdk_aws_neptune_alpha_ParameterGroupFamily(p) {
}
function _aws_cdk_aws_neptune_alpha_ClusterParameterGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.family))
            _aws_cdk_aws_neptune_alpha_ParameterGroupFamily(p.family);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_neptune_alpha_ParameterGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.family))
            _aws_cdk_aws_neptune_alpha_ParameterGroupFamily(p.family);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_neptune_alpha_IClusterParameterGroup(p) {
}
function _aws_cdk_aws_neptune_alpha_ClusterParameterGroup(p) {
}
function _aws_cdk_aws_neptune_alpha_IParameterGroup(p) {
}
function _aws_cdk_aws_neptune_alpha_ParameterGroup(p) {
}
function _aws_cdk_aws_neptune_alpha_ISubnetGroup(p) {
}
function _aws_cdk_aws_neptune_alpha_SubnetGroupProps(p) {
}
function _aws_cdk_aws_neptune_alpha_SubnetGroup(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_neptune_alpha_EngineVersion, _aws_cdk_aws_neptune_alpha_LogType, _aws_cdk_aws_neptune_alpha_ServerlessScalingConfiguration, _aws_cdk_aws_neptune_alpha_DatabaseClusterProps, _aws_cdk_aws_neptune_alpha_IDatabaseCluster, _aws_cdk_aws_neptune_alpha_DatabaseClusterAttributes, _aws_cdk_aws_neptune_alpha_DatabaseClusterBase, _aws_cdk_aws_neptune_alpha_DatabaseCluster, _aws_cdk_aws_neptune_alpha_InstanceType, _aws_cdk_aws_neptune_alpha_IDatabaseInstance, _aws_cdk_aws_neptune_alpha_DatabaseInstanceAttributes, _aws_cdk_aws_neptune_alpha_DatabaseInstanceProps, _aws_cdk_aws_neptune_alpha_DatabaseInstanceBase, _aws_cdk_aws_neptune_alpha_DatabaseInstance, _aws_cdk_aws_neptune_alpha_Endpoint, _aws_cdk_aws_neptune_alpha_ParameterGroupFamily, _aws_cdk_aws_neptune_alpha_ClusterParameterGroupProps, _aws_cdk_aws_neptune_alpha_ParameterGroupProps, _aws_cdk_aws_neptune_alpha_IClusterParameterGroup, _aws_cdk_aws_neptune_alpha_ClusterParameterGroup, _aws_cdk_aws_neptune_alpha_IParameterGroup, _aws_cdk_aws_neptune_alpha_ParameterGroup, _aws_cdk_aws_neptune_alpha_ISubnetGroup, _aws_cdk_aws_neptune_alpha_SubnetGroupProps, _aws_cdk_aws_neptune_alpha_SubnetGroup };
