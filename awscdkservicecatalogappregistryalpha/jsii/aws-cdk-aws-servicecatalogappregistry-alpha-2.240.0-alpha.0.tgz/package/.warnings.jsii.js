function _aws_cdk_aws_servicecatalogappregistry_alpha_AttributeGroupAssociationProps(p) {
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_IApplication(p) {
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_ApplicationProps(p) {
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_Application(p) {
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_IAttributeGroup(p) {
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_AttributeGroupProps(p) {
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_AttributeGroup(p) {
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_ApplicationAssociatorProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.applications != null)
            for (const o of p.applications)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_servicecatalogappregistry_alpha_TargetApplication(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_ApplicationAssociator(p) {
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_TargetApplicationCommonOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("stackId" in p)
            print("@aws-cdk/aws-servicecatalogappregistry-alpha.TargetApplicationCommonOptions#stackId", "- Use `stackName` instead to control the name and id of the stack");
        if (p.propertyInjectors != null)
            for (const o of p.propertyInjectors)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_IPropertyInjector(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_CreateTargetApplicationOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("stackId" in p)
            print("@aws-cdk/aws-servicecatalogappregistry-alpha.TargetApplicationCommonOptions#stackId", "- Use `stackName` instead to control the name and id of the stack");
        if (p.propertyInjectors != null)
            for (const o of p.propertyInjectors)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_IPropertyInjector(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_ExistingTargetApplicationOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if ("stackId" in p)
            print("@aws-cdk/aws-servicecatalogappregistry-alpha.TargetApplicationCommonOptions#stackId", "- Use `stackName` instead to control the name and id of the stack");
        if (p.propertyInjectors != null)
            for (const o of p.propertyInjectors)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_IPropertyInjector(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_TargetApplication(p) {
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_BindTargetApplicationResult(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.application))
            _aws_cdk_aws_servicecatalogappregistry_alpha_IApplication(p.application);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_SharePermission(p) {
}
function _aws_cdk_aws_servicecatalogappregistry_alpha_ShareOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.roles != null)
            for (const o of p.roles)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(o);
        if (p.users != null)
            for (const o of p.users)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IUser(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_servicecatalogappregistry_alpha_AttributeGroupAssociationProps, _aws_cdk_aws_servicecatalogappregistry_alpha_IApplication, _aws_cdk_aws_servicecatalogappregistry_alpha_ApplicationProps, _aws_cdk_aws_servicecatalogappregistry_alpha_Application, _aws_cdk_aws_servicecatalogappregistry_alpha_IAttributeGroup, _aws_cdk_aws_servicecatalogappregistry_alpha_AttributeGroupProps, _aws_cdk_aws_servicecatalogappregistry_alpha_AttributeGroup, _aws_cdk_aws_servicecatalogappregistry_alpha_ApplicationAssociatorProps, _aws_cdk_aws_servicecatalogappregistry_alpha_ApplicationAssociator, _aws_cdk_aws_servicecatalogappregistry_alpha_TargetApplicationCommonOptions, _aws_cdk_aws_servicecatalogappregistry_alpha_CreateTargetApplicationOptions, _aws_cdk_aws_servicecatalogappregistry_alpha_ExistingTargetApplicationOptions, _aws_cdk_aws_servicecatalogappregistry_alpha_TargetApplication, _aws_cdk_aws_servicecatalogappregistry_alpha_BindTargetApplicationResult, _aws_cdk_aws_servicecatalogappregistry_alpha_SharePermission, _aws_cdk_aws_servicecatalogappregistry_alpha_ShareOptions };
