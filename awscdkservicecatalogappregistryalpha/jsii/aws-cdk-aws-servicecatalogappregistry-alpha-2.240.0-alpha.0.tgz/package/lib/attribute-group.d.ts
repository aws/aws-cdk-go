import * as cdk from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import type { IApplication } from './application';
import type { ShareOptions } from './common';
/**
 * A Service Catalog AppRegistry Attribute Group.
 */
export interface IAttributeGroup extends cdk.IResource {
    /**
     * The ARN of the attribute group.
     * @attribute
     */
    readonly attributeGroupArn: string;
    /**
     * The ID of the attribute group.
     * @attribute
     */
    readonly attributeGroupId: string;
    /**
     * Share the attribute group resource with other IAM entities, accounts, or OUs.
     *
     * @param id The construct name for the share.
     * @param shareOptions The options for the share.
     */
    shareAttributeGroup(id: string, shareOptions: ShareOptions): void;
    /**
     * Associate an application with attribute group
     * If the attribute group is already associated, it will ignore duplicate request.
     */
    associateWith(application: IApplication): void;
}
/**
 * Properties for a Service Catalog AppRegistry Attribute Group
 */
export interface AttributeGroupProps {
    /**
     * Enforces a particular physical attribute group name.
     */
    readonly attributeGroupName: string;
    /**
     * Description for attribute group.
     * @default - No description provided
     */
    readonly description?: string;
    /**
     * A JSON of nested key-value pairs that represent the attributes in the group.
     * Attributes maybe an empty JSON '{}', but must be explicitly stated.
     */
    readonly attributes: {
        [key: string]: any;
    };
}
declare abstract class AttributeGroupBase extends cdk.Resource implements IAttributeGroup {
    abstract readonly attributeGroupArn: string;
    abstract readonly attributeGroupId: string;
    private readonly associatedApplications;
    associateWith(application: IApplication): void;
    shareAttributeGroup(id: string, shareOptions: ShareOptions): void;
    /**
     * Get the correct permission ARN based on the SharePermission
     */
    protected getAttributeGroupSharePermissionARN(shareOptions: ShareOptions): string;
    /**
     * Create a unique hash
     */
    protected abstract generateUniqueHash(resourceAddress: string): string;
}
/**
 * A Service Catalog AppRegistry Attribute Group.
 */
export declare class AttributeGroup extends AttributeGroupBase implements IAttributeGroup {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * Imports an attribute group construct that represents an external attribute group.
     *
     * @param scope The parent creating construct (usually `this`).
     * @param id The construct's name.
     * @param attributeGroupArn the Amazon Resource Name of the existing AppRegistry attribute group
     */
    static fromAttributeGroupArn(scope: Construct, id: string, attributeGroupArn: string): IAttributeGroup;
    readonly attributeGroupArn: string;
    readonly attributeGroupId: string;
    private readonly nodeAddress;
    constructor(scope: Construct, id: string, props: AttributeGroupProps);
    protected generateUniqueHash(resourceAddress: string): string;
    private validateAttributeGroupProps;
}
export {};
