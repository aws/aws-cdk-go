/**
 * Verifies if application or the visited node is region agnostic.
 *
 * @param applicationRegion Region of the application.
 * @param nodeRegion Region of the visited node.
 */
export declare function isRegionUnresolved(applicationRegion: string, nodeRegion: string): boolean;
/**
 * Verifies if application or the visited node is account agnostic.
 *
 * @param applicationAccount Account of the application.
 * @param nodeAccount Account of the visited node.
 */
export declare function isAccountUnresolved(applicationAccount: string, nodeAccount: string): boolean;
