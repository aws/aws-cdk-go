const VALIDATORS = { _aws_cdk_aws_servicecatalogappregistry_alpha_TargetApplicationCommonOptions: function _aws_cdk_aws_servicecatalogappregistry_alpha_TargetApplicationCommonOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("stackId" in p)
                print("@aws-cdk/aws-servicecatalogappregistry-alpha.TargetApplicationCommonOptions#stackId", "- Use `stackName` instead to control the name and id of the stack");
            if (p.propertyInjectors != null)
                for (const o of p.propertyInjectors)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_IPropertyInjector(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_servicecatalogappregistry_alpha_CreateTargetApplicationOptions: function _aws_cdk_aws_servicecatalogappregistry_alpha_CreateTargetApplicationOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("stackId" in p)
                print("@aws-cdk/aws-servicecatalogappregistry-alpha.TargetApplicationCommonOptions#stackId", "- Use `stackName` instead to control the name and id of the stack");
            if (p.propertyInjectors != null)
                for (const o of p.propertyInjectors)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_IPropertyInjector(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_servicecatalogappregistry_alpha_ExistingTargetApplicationOptions: function _aws_cdk_aws_servicecatalogappregistry_alpha_ExistingTargetApplicationOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("stackId" in p)
                print("@aws-cdk/aws-servicecatalogappregistry-alpha.TargetApplicationCommonOptions#stackId", "- Use `stackName` instead to control the name and id of the stack");
            if (p.propertyInjectors != null)
                for (const o of p.propertyInjectors)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_IPropertyInjector(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_servicecatalogappregistry_alpha_ShareOptions: function _aws_cdk_aws_servicecatalogappregistry_alpha_ShareOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.roles != null)
                for (const o of p.roles)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IRole(o);
            if (p.users != null)
                for (const o of p.users)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_iam_IUser(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
