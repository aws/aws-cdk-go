const VALIDATORS = { _aws_cdk_aws_mediapackagev2_alpha_FilterConfiguration: function _aws_cdk_aws_mediapackagev2_alpha_FilterConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.drmSettings != null)
                for (const o of p.drmSettings)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_DrmSettingsKey(o);
            if (p.manifestFilter != null)
                for (const o of p.manifestFilter)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_ManifestFilter(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_MssManifestConfiguration: function _aws_cdk_aws_mediapackagev2_alpha_MssManifestConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.filterConfiguration))
                module.exports._aws_cdk_aws_mediapackagev2_alpha_FilterConfiguration(p.filterConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_DashManifestConfiguration: function _aws_cdk_aws_mediapackagev2_alpha_DashManifestConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.baseUrls != null)
                for (const o of p.baseUrls)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_DashBaseUrlProperty(o);
            if (!visitedObjects.has(p.filterConfiguration))
                module.exports._aws_cdk_aws_mediapackagev2_alpha_FilterConfiguration(p.filterConfiguration);
            if (p.periodTriggers != null)
                for (const o of p.periodTriggers)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_DashPeriodTriggers(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_HlsManifestConfiguration: function _aws_cdk_aws_mediapackagev2_alpha_HlsManifestConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.filterConfiguration))
                module.exports._aws_cdk_aws_mediapackagev2_alpha_FilterConfiguration(p.filterConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_LowLatencyHlsManifestConfiguration: function _aws_cdk_aws_mediapackagev2_alpha_LowLatencyHlsManifestConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.filterConfiguration))
                module.exports._aws_cdk_aws_mediapackagev2_alpha_FilterConfiguration(p.filterConfiguration);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointOptions: function _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.manifests != null)
                for (const o of p.manifests)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_Manifest(o);
            if (!visitedObjects.has(p.segment))
                module.exports._aws_cdk_aws_mediapackagev2_alpha_SegmentConfiguration(p.segment);
            if (!visitedObjects.has(p.cdnAuth))
                module.exports._aws_cdk_aws_mediapackagev2_alpha_CdnAuthConfiguration(p.cdnAuth);
            if (p.forceEndpointConfigurationConditions != null)
                for (const o of p.forceEndpointConfigurationConditions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_EndpointErrorConfiguration(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointProps: function _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.manifests != null)
                for (const o of p.manifests)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_Manifest(o);
            if (!visitedObjects.has(p.segment))
                module.exports._aws_cdk_aws_mediapackagev2_alpha_SegmentConfiguration(p.segment);
            if (!visitedObjects.has(p.cdnAuth))
                module.exports._aws_cdk_aws_mediapackagev2_alpha_CdnAuthConfiguration(p.cdnAuth);
            if (p.forceEndpointConfigurationConditions != null)
                for (const o of p.forceEndpointConfigurationConditions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_EndpointErrorConfiguration(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_CmafSpekeEncryptionProps: function _aws_cdk_aws_mediapackagev2_alpha_CmafSpekeEncryptionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.drmSystems != null)
                for (const o of p.drmSystems)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_CmafDrmSystem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_TsSpekeEncryptionProps: function _aws_cdk_aws_mediapackagev2_alpha_TsSpekeEncryptionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.drmSystems != null)
                for (const o of p.drmSystems)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_TsDrmSystem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_IsmSpekeEncryptionProps: function _aws_cdk_aws_mediapackagev2_alpha_IsmSpekeEncryptionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.drmSystems != null)
                for (const o of p.drmSystems)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_IsmDrmSystem(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_SegmentConfiguration: function _aws_cdk_aws_mediapackagev2_alpha_SegmentConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.scteFilter != null)
                for (const o of p.scteFilter)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_ScteMessageType(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_TsSegmentProps: function _aws_cdk_aws_mediapackagev2_alpha_TsSegmentProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.scteFilter != null)
                for (const o of p.scteFilter)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_ScteMessageType(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_CmafSegmentProps: function _aws_cdk_aws_mediapackagev2_alpha_CmafSegmentProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.scteFilter != null)
                for (const o of p.scteFilter)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_mediapackagev2_alpha_ScteMessageType(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_CdnAuthConfiguration: function _aws_cdk_aws_mediapackagev2_alpha_CdnAuthConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.secrets != null)
                for (const o of p.secrets)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_secretsmanager_ISecret(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointPolicyProps: function _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointPolicyProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.cdnAuth))
                module.exports._aws_cdk_aws_mediapackagev2_alpha_CdnAuthConfiguration(p.cdnAuth);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_mediapackagev2_alpha_MediaPackageV2OriginProps: function _aws_cdk_aws_mediapackagev2_alpha_MediaPackageV2OriginProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.cdnAuth))
                module.exports._aws_cdk_aws_mediapackagev2_alpha_CdnAuthConfiguration(p.cdnAuth);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
