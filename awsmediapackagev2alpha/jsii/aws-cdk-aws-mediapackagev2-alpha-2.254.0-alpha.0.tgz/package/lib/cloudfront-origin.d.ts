import * as cloudfront from 'aws-cdk-lib/aws-cloudfront';
import type { Construct } from 'constructs';
import type { IOriginEndpoint } from './endpoint';
import type { IChannelGroup } from './group';
import type { CdnAuthConfiguration } from './origin-endpoint-policy';
/**
 * Properties for a MediaPackage V2 Origin with OAC.
 */
export interface MediaPackageV2OriginProps extends cloudfront.OriginProps {
    /**
     * The channel group that the origin endpoint belongs to.
     *
     * Used to derive the egress domain for the CloudFront origin.
     */
    readonly channelGroup: IChannelGroup;
    /**
     * An optional Origin Access Control.
     *
     * @default - an Origin Access Control will be created automatically.
     */
    readonly originAccessControl?: cloudfront.IOriginAccessControlRef;
    /**
     * Optional CDN authorization configuration.
     *
     * If you need CDN auth on this endpoint, provide it here so it is configured
     * on the first `addToResourcePolicy` call. If CDN auth is added separately
     * after this origin is bound, it will be ignored.
     *
     * @default - no CDN authorization
     */
    readonly cdnAuth?: CdnAuthConfiguration;
}
/**
 * A CloudFront Origin for AWS Elemental MediaPackage V2 endpoints.
 *
 * Automatically creates an OAC and wires the origin endpoint policy
 * to grant the CloudFront distribution access.
 *
 * Uses `addToResourcePolicy()` on the origin endpoint, which is compatible
 * with other policy statements added to the same endpoint. Do not use this
 * alongside a manually created `OriginEndpointPolicy` construct for the same endpoint.
 *
 * @example
 *
 *    declare const endpoint: OriginEndpoint;
 *    declare const group: ChannelGroup;
 *
 *    new cloudfront.Distribution(this, 'Dist', {
 *      defaultBehavior: {
 *        origin: new MediaPackageV2Origin(endpoint, {
 *          channelGroup: group,
 *        }),
 *      },
 *    });
 *
 * @see https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/private-content-restricting-access-to-mediapackage.html
 */
export declare class MediaPackageV2Origin extends cloudfront.OriginBase {
    private originAccessControl?;
    private readonly endpoint;
    private readonly cdnAuth?;
    constructor(endpoint: IOriginEndpoint, props: MediaPackageV2OriginProps);
    protected renderCustomOriginConfig(): cloudfront.CfnDistribution.CustomOriginConfigProperty | undefined;
    bind(scope: Construct, options: cloudfront.OriginBindOptions): cloudfront.OriginBindConfig;
}
