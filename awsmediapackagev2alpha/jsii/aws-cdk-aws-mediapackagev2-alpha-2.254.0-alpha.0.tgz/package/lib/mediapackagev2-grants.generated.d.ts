import * as mediapackagev2 from "aws-cdk-lib/aws-mediapackagev2";
import * as iam from "aws-cdk-lib/aws-iam";
import * as cdk from "aws-cdk-lib/core";
/**
 * Collection of grant methods for a IChannelRef
 */
export declare class ChannelGrants {
    /**
     * Creates grants for ChannelGrants
     */
    static fromChannel(resource: mediapackagev2.IChannelRef): ChannelGrants;
    protected readonly resource: mediapackagev2.IChannelRef;
    protected readonly policyResource?: iam.IResourceWithPolicyV2;
    private constructor();
    /**
     * Grant the given identity custom permissions
     */
    actions(grantee: iam.IGrantable, actions: Array<string>, options?: cdk.PermissionsOptions): iam.Grant;
    /**
     * Grant permissions to ingest content into this channel
     */
    ingest(grantee: iam.IGrantable): iam.Grant;
}
