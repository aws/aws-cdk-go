import type { Bitrate, IResource } from 'aws-cdk-lib';
import { RemovalPolicy, Duration, Resource } from 'aws-cdk-lib';
import type { ICertificate } from 'aws-cdk-lib/aws-certificatemanager';
import type { MetricOptions } from 'aws-cdk-lib/aws-cloudwatch';
import { Metric } from 'aws-cdk-lib/aws-cloudwatch';
import type { IRole, PolicyStatement, AddToResourcePolicyResult } from 'aws-cdk-lib/aws-iam';
import { CfnOriginEndpoint } from 'aws-cdk-lib/aws-mediapackagev2';
import type { IOriginEndpointRef, OriginEndpointReference } from 'aws-cdk-lib/aws-mediapackagev2';
import type { Construct } from 'constructs';
import type { IChannel } from './channel';
import type { CdnAuthConfiguration } from './origin-endpoint-policy';
import { OriginEndpointPolicy } from './origin-endpoint-policy';
/**
 * Accepted audio codec values for manifest filtering.
 *
 * @see https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
 */
export declare enum AudioCodec {
    /** AAC-LC audio codec */
    AACL = "AACL",
    /** HE-AAC audio codec */
    AACH = "AACH",
    /** Dolby Digital audio codec (include the hyphen) */
    AC_3 = "AC-3",
    /** Dolby Digital Plus audio codec (include the hyphen) */
    EC_3 = "EC-3"
}
/**
 * Accepted video codec values for manifest filtering.
 *
 * @see https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
 */
export declare enum VideoCodec {
    /** H.264/AVC */
    H264 = "H264",
    /** H.265/HEVC */
    H265 = "H265",
    /** AV1 */
    AV1 = "AV1"
}
/**
 * Accepted video dynamic range values for manifest filtering.
 *
 * @see https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
 */
export declare enum VideoDynamicRange {
    /** Dolby Vision */
    DV = "dv",
    /** HDR10 */
    HDR10 = "hdr10",
    /** Hybrid Log-Gamma */
    HLG = "hlg",
    /** Standard Dynamic Range */
    SDR = "sdr"
}
/**
 * Accepted trickplay type values for manifest filtering.
 *
 * @see https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
 */
export declare enum TrickplayType {
    /** I-frame only trick-play */
    IFRAME = "iframe",
    /** Image-based trick-play */
    IMAGE = "image",
    /** No trick-play */
    NONE = "none"
}
/**
 * Numeric manifest filter keys.
 *
 * Use with `ManifestFilter.numeric()`, `ManifestFilter.numericList()`, and `ManifestFilter.numericRange()`.
 *
 * Audio and video bitrate filters are not included here because they use the
 * `Bitrate` class directly via dedicated methods on `ManifestFilter`.
 *
 * @see https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
 */
export declare enum NumericFilterKey {
    /**
     * The number of audio channels.
     *
     * Accepted values: range 1–32767, or individual integers.
     */
    AUDIO_CHANNELS = "audio_channels",
    /**
     * The audio sample rate in Hz.
     *
     * Accepted values: range 0–2147483647, or individual integers.
     */
    AUDIO_SAMPLE_RATE = "audio_sample_rate",
    /**
     * The height of the trick-play image in pixels (I-frame and image-based trick-play).
     *
     * If using with I-frame only trick-play, `TRICKPLAY_HEIGHT` and `VIDEO_HEIGHT`
     * should have similar values. If they differ, I-frame only tracks might be
     * removed from the manifest.
     *
     * Accepted values: range 1–2147483647, or individual integers.
     */
    TRICKPLAY_HEIGHT = "trickplay_height",
    /**
     * The video frame rate range in NTSC format.
     *
     * When filtering for a single value, MediaPackage uses an approximate equals
     * comparison with an epsilon tolerance of 0.0005.
     *
     * Accepted values: range 1–999.999 (up to three decimal places), or individual values.
     */
    VIDEO_FRAMERATE = "video_framerate",
    /**
     * The height of the video in pixels.
     *
     * If using with I-frame only trick-play, `TRICKPLAY_HEIGHT` and `VIDEO_HEIGHT`
     * should have similar values. If they differ, I-frame only tracks might be
     * removed from the manifest.
     *
     * Accepted values: range 1–32767, or individual integers.
     */
    VIDEO_HEIGHT = "video_height"
}
/**
 * Text manifest filter keys for free-form string values.
 *
 * Use with `ManifestFilter.text()` and `ManifestFilter.textList()`.
 *
 * For keys with fixed accepted values, use the dedicated methods on `ManifestFilter` instead:
 * - Audio codec: `ManifestFilter.audioCodec()` / `ManifestFilter.audioCodecList()`
 * - Video codec: `ManifestFilter.videoCodec()` / `ManifestFilter.videoCodecList()`
 * - Video dynamic range: `ManifestFilter.videoDynamicRange()` / `ManifestFilter.videoDynamicRangeList()`
 * - Trickplay type: `ManifestFilter.trickplayType()` / `ManifestFilter.trickplayTypeList()`
 *
 * @see https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
 */
export declare enum TextFilterKey {
    /**
     * Audio languages or functional codes derived from encoder passthrough.
     *
     * Accepted values: arbitrary strings such as ISO-639-1 language codes (not case-sensitive).
     */
    AUDIO_LANGUAGE = "audio_language",
    /**
     * The subtitle language or functional codes derived from encoder passthrough.
     *
     * Accepted values: arbitrary strings such as ISO-639-1 language codes (not case-sensitive).
     */
    SUBTITLE_LANGUAGE = "subtitle_language"
}
/**
 * Bitrate manifest filter keys.
 *
 * Use with `ManifestFilter.bitrate()` and `ManifestFilter.bitrateRange()`.
 *
 * @see https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
 */
export declare enum BitrateFilterKey {
    /**
     * The audio bitrate in bits per second.
     *
     * Accepted values: range 0–2147483647, or individual integers.
     */
    AUDIO_BITRATE = "audio_bitrate",
    /**
     * The video bitrate in bits per second.
     *
     * We recommend using only this filter parameter to set the video bitrate.
     * Do not also set the minimum and maximum video bitrate via the MediaPackage
     * console or AWS CLI, as your output might be skewed.
     *
     * This parameter cannot be used with trick-play streams.
     *
     * Accepted values: range 0–2147483647, or individual integers.
     */
    VIDEO_BITRATE = "video_bitrate"
}
/**
 * Represents a numeric filter expression segment — either a single value or a range.
 *
 * Use with `ManifestFilter.numericCombo()` to build filters that combine
 * ranges and individual values (e.g. `video_height:240-360,720-1080,1440`).
 */
export declare class NumericExpression {
    /**
     * A single numeric value.
     */
    static value(v: number): NumericExpression;
    /**
     * An inclusive numeric range.
     */
    static range(start: number, end: number): NumericExpression;
    protected constructor(
    /** @internal */
    _expression: string, 
    /** @internal */
    _values: number[]);
}
/**
 * Represents a bitrate filter expression segment — either a single value or a range.
 *
 * Use with `ManifestFilter.bitrateCombo()` to build filters that combine
 * ranges and individual bitrate values.
 */
export declare class BitrateExpression {
    /**
     * A single bitrate value.
     */
    static value(v: Bitrate): BitrateExpression;
    /**
     * An inclusive bitrate range.
     */
    static range(start: Bitrate, end: Bitrate): BitrateExpression;
    protected constructor(
    /** @internal */
    _expression: string, 
    /** @internal */
    _values: number[]);
}
/**
 * Enables you to create filters for your Origin Endpoint.
 *
 * @see https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filtering.html
 */
export declare class ManifestFilter {
    readonly filterString: string;
    /**
     * Filter by a single bitrate value.
     */
    static bitrate(key: BitrateFilterKey, value: Bitrate): ManifestFilter;
    /**
     * Filter by a bitrate range (inclusive).
     */
    static bitrateRange(key: BitrateFilterKey, start: Bitrate, end: Bitrate): ManifestFilter;
    /**
     * Specify a single numeric filter value.
     */
    static numeric(key: NumericFilterKey, value: number): ManifestFilter;
    /**
     * Specify multiple numeric filter values.
     */
    static numericList(key: NumericFilterKey, values: number[]): ManifestFilter;
    /**
     * Specify a numeric filter range (inclusive).
     */
    static numericRange(key: NumericFilterKey, start: number, end: number): ManifestFilter;
    /**
     * Specify a free-form text filter value (for language keys).
     */
    static text(key: TextFilterKey, value: string): ManifestFilter;
    /**
     * Specify multiple free-form text filter values (for language keys).
     */
    static textList(key: TextFilterKey, values: string[]): ManifestFilter;
    /**
     * Filter by a single audio codec.
     */
    static audioCodec(value: AudioCodec): ManifestFilter;
    /**
     * Filter by multiple audio codecs.
     */
    static audioCodecList(values: AudioCodec[]): ManifestFilter;
    /**
     * Filter by a single video codec.
     */
    static videoCodec(value: VideoCodec): ManifestFilter;
    /**
     * Filter by multiple video codecs.
     */
    static videoCodecList(values: VideoCodec[]): ManifestFilter;
    /**
     * Filter by a single video dynamic range.
     */
    static videoDynamicRange(value: VideoDynamicRange): ManifestFilter;
    /**
     * Filter by multiple video dynamic ranges.
     */
    static videoDynamicRangeList(values: VideoDynamicRange[]): ManifestFilter;
    /**
     * Filter by a single trickplay type.
     */
    static trickplayType(value: TrickplayType): ManifestFilter;
    /**
     * Filter by multiple trickplay types.
     */
    static trickplayTypeList(values: TrickplayType[]): ManifestFilter;
    /**
     * Filter by a combination of numeric ranges and individual values.
     *
     * Use this for advanced patterns like `video_height:240-360,720-1080,1440`.
     *
     * @example
     * ManifestFilter.numericCombo(NumericFilterKey.VIDEO_HEIGHT, [
     *   NumericExpression.range(240, 360),
     *   NumericExpression.range(720, 1080),
     *   NumericExpression.value(1440),
     * ])
     */
    static numericCombo(key: NumericFilterKey, expressions: NumericExpression[]): ManifestFilter;
    /**
     * Filter by a combination of bitrate ranges and individual values.
     *
     * @example
     * ManifestFilter.bitrateCombo(BitrateFilterKey.VIDEO_BITRATE, [
     *   BitrateExpression.range(Bitrate.mbps(1), Bitrate.mbps(3)),
     *   BitrateExpression.value(Bitrate.mbps(5)),
     * ])
     */
    static bitrateCombo(key: BitrateFilterKey, expressions: BitrateExpression[]): ManifestFilter;
    /**
     * Specify a custom manifest filter string.
     */
    static custom(custom: string): ManifestFilter;
    /**
     * @param filterString Normalised manifest filter string
     */
    protected constructor(filterString: string);
}
/**
 * Manifest to add to Origin Endpoint
 */
export declare abstract class Manifest {
    /**
     * Specify a manifest configuration for Low Latency HLS.
     *
     * **Note:** Low Latency HLS manifests require TS or CMAF container type.
     * Use with `Segment.ts()` or `Segment.cmaf()`.
     */
    static lowLatencyHLS(manifest: LowLatencyHlsManifestConfiguration): Manifest;
    /**
     * Specify a manifest configuration for HLS.
     *
     * **Note:** HLS manifests require TS or CMAF container type.
     * Use with `Segment.ts()` or `Segment.cmaf()`.
     */
    static hls(manifest: HlsManifestConfiguration): Manifest;
    /**
     * Specify a manifest configuration for DASH.
     *
     * **Note:** DASH manifests require CMAF container type.
     * Use with `Segment.cmaf()`.
     */
    static dash(manifest: DashManifestConfiguration): Manifest;
    /**
     * Specify a manifest configuration for MSS.
     *
     * **Note:** MSS manifests require ISM container type.
     * Use with `Segment.ism()`.
     */
    static mss(manifest: MssManifestConfiguration): Manifest;
}
/**
 * The type of container to attach to this origin endpoint.
 * A container type is a file format that encapsulates one or more media streams, such as audio and video, into a single file. You can't change the container type after you create the endpoint.
 */
export declare enum ContainerType {
    /**
     * TS Container Type
     */
    TS = "TS",
    /**
     * CMAF Container Type
     */
    CMAF = "CMAF",
    /**
     * ISM Container Type (Microsoft Smooth Streaming)
     */
    ISM = "ISM"
}
/**
 * Encryption methods for CMAF container type.
 */
export declare enum CmafEncryptionMethod {
    /**
     * Common Encryption Scheme (CENC) - compatible with PlayReady, Widevine, and Irdeto DRM systems.
     */
    CENC = "CENC",
    /**
     * Common Encryption Scheme with CBCS mode - compatible with PlayReady, Widevine, and FairPlay DRM systems.
     */
    CBCS = "CBCS"
}
/**
 * Encryption methods for TS container type.
 */
export declare enum TsEncryptionMethod {
    /**
     * AES-128 encryption - requires Clear Key AES 128 DRM system.
     */
    AES_128 = "AES_128",
    /**
     * Sample-level AES encryption - requires FairPlay DRM system.
     */
    SAMPLE_AES = "SAMPLE_AES"
}
/**
 * A collection of audio encryption presets.
 */
export declare enum PresetSpeke20Audio {
    /**
     * Use one content key to encrypt all of the audio tracks in your stream.
     */
    PRESET_AUDIO_1 = "PRESET_AUDIO_1",
    /**
     * Use one content key to encrypt all of the stereo audio tracks and one content key to encrypt all of the multichannel audio tracks.
     */
    PRESET_AUDIO_2 = "PRESET_AUDIO_2",
    /**
     * Use one content key to encrypt all of the stereo audio tracks, one content key to encrypt all of the multichannel audio tracks with 3 to 6 channels,
     * and one content key to encrypt all of the multichannel audio tracks with more than 6 channels.
     */
    PRESET_AUDIO_3 = "PRESET_AUDIO_3",
    /**
     * Use the same content key for all of the audio and video tracks in your stream.
     */
    SHARED = "SHARED",
    /**
     * Don't encrypt any of the audio tracks in your stream.
     */
    UNENCRYPTED = "UNENCRYPTED"
}
/**
 * The SPEKE Version 2.0 preset video associated with the encryption contract configuration of the origin endpoint.
 *
 * A collection of video encryption presets.
 */
export declare enum PresetSpeke20Video {
    /**
     * Use one content key to encrypt all of the video tracks in your stream.
     */
    PRESET_VIDEO_1 = "PRESET_VIDEO_1",
    /**
     * Use one content key to encrypt all of the SD video tracks and one content key for all HD and higher resolutions video tracks.
     */
    PRESET_VIDEO_2 = "PRESET_VIDEO_2",
    /**
     * Use one content key to encrypt all of the SD video tracks, one content key for HD video tracks and one content key for all UHD video tracks.
     */
    PRESET_VIDEO_3 = "PRESET_VIDEO_3",
    /**
     * Use one content key to encrypt all of the SD video tracks, one content key for HD video tracks,
     * one content key for all UHD1 video tracks and one content key for all UHD2 video tracks.
     */
    PRESET_VIDEO_4 = "PRESET_VIDEO_4",
    /**
     * Use one content key to encrypt all of the SD video tracks, one content key for HD1 video tracks, one content key for HD2 video tracks,
     * one content key for all UHD1 video tracks and one content key for all UHD2 video tracks.
     */
    PRESET_VIDEO_5 = "PRESET_VIDEO_5",
    /**
     * Use one content key to encrypt all of the SD video tracks, one content key for HD1 video tracks, one content key for HD2 video tracks
     * and one content key for all UHD video tracks.
     */
    PRESET_VIDEO_6 = "PRESET_VIDEO_6",
    /**
     * Use one content key to encrypt all of the SD+HD1 video tracks, one content key for HD2 video tracks and one content key for all UHD video tracks.
     */
    PRESET_VIDEO_7 = "PRESET_VIDEO_7",
    /**
     * Use one content key to encrypt all of the SD+HD1 video tracks, one content key for HD2 video tracks, one content key for all UHD1
     * video tracks and one content key for all UHD2 video tracks.
     */
    PRESET_VIDEO_8 = "PRESET_VIDEO_8",
    /**
     * Use the same content key for all of the video and audio tracks in your stream.
     */
    SHARED = "SHARED",
    /**
     * Don't encrypt any of the video tracks in your stream.
     */
    UNENCRYPTED = "UNENCRYPTED"
}
/**
 * Endpoint error configuration options.
 */
export declare enum EndpointErrorConfiguration {
    /**
     * The manifest stalled and there are no new segments or parts.
     */
    STALE_MANIFEST = "STALE_MANIFEST",
    /**
     * There is a gap in the manifest.
     */
    INCOMPLETE_MANIFEST = "INCOMPLETE_MANIFEST",
    /**
     * Key rotation is enabled but we're unable to fetch the key for the current key period.
     */
    MISSING_DRM_KEY = "MISSING_DRM_KEY",
    /**
     * The segments which contain slate content are considered to be missing content.
     */
    SLATE_INPUT = "SLATE_INPUT"
}
/**
 * SCTE-35 message type options available.
 */
export declare enum ScteMessageType {
    /**
     * Option for SPLICE_INSERT.
     */
    SPLICE_INSERT = "SPLICE_INSERT",
    /**
     * Option for BREAK.
     */
    BREAK = "BREAK",
    /**
     * Option for PROVIDER_ADVERTISEMENT.
     */
    PROVIDER_ADVERTISEMENT = "PROVIDER_ADVERTISEMENT",
    /**
     * Option for DISTRIBUTOR_ADVERTISEMENT.
     */
    DISTRIBUTOR_ADVERTISEMENT = "DISTRIBUTOR_ADVERTISEMENT",
    /**
     * Option for PROVIDER_PLACEMENT_OPPORTUNITY.
     */
    PROVIDER_PLACEMENT_OPPORTUNITY = "PROVIDER_PLACEMENT_OPPORTUNITY",
    /**
     * Option for DISTRIBUTOR_PLACEMENT_OPPORTUNITY.
     */
    DISTRIBUTOR_PLACEMENT_OPPORTUNITY = "DISTRIBUTOR_PLACEMENT_OPPORTUNITY",
    /**
     * Option for PROVIDER_OVERLAY_PLACEMENT_OPPORTUNITY.
     */
    PROVIDER_OVERLAY_PLACEMENT_OPPORTUNITY = "PROVIDER_OVERLAY_PLACEMENT_OPPORTUNITY",
    /**
     * Option for DISTRIBUTOR_OVERLAY_PLACEMENT_OPPORTUNITY.
     */
    DISTRIBUTOR_OVERLAY_PLACEMENT_OPPORTUNITY = "DISTRIBUTOR_OVERLAY_PLACEMENT_OPPORTUNITY",
    /**
     * Option for PROGRAM.
     */
    PROGRAM = "PROGRAM"
}
/**
 * Controls whether SCTE-35 messages are included in segment files.
 */
export declare enum ScteInSegments {
    /**
     * SCTE-35 messages are not included in segments.
     */
    NONE = "NONE",
    /**
     * SCTE-35 messages are embedded in segment data.
     *
     * For DASH manifests, when set to ALL, an InbandEventStream tag signals
     * that SCTE messages are present in segments.
     */
    ALL = "ALL"
}
/**
 * Origin Endpoint interface
 */
export interface IOriginEndpoint extends IResource, IOriginEndpointRef {
    /**
     * The name of the channel group associated with the origin endpoint configuration.
     *
     * @attribute
     */
    readonly channelGroupName: string;
    /**
     * The channel name associated with the origin endpoint.
     *
     * @attribute
     */
    readonly channelName: string;
    /**
     * The name of the origin endpoint associated with the origin endpoint configuration.
     *
     * @attribute
     */
    readonly originEndpointName: string;
    /**
     * The Amazon Resource Name (ARN) of the origin endpoint.
     *
     * @attribute
     */
    readonly originEndpointArn: string;
    /**
     * The date and time the origin endpoint was created.
     *
     * @attribute
     */
    readonly createdAt?: string;
    /**
     * The date and time the origin endpoint was modified.
     *
     * @attribute
     */
    readonly modifiedAt?: string;
    /**
     * The HLS manifest URLs for the origin endpoint.
     *
     * @attribute
     */
    readonly hlsManifestUrls?: string[];
    /**
     * The Low Latency HLS manifest URLs for the origin endpoint.
     *
     * @attribute
     */
    readonly lowLatencyHlsManifestUrls?: string[];
    /**
     * The DASH manifest URLs for the origin endpoint.
     *
     * @attribute
     */
    readonly dashManifestUrls?: string[];
    /**
     * The MSS manifest URLs for the origin endpoint.
     *
     * @attribute
     */
    readonly mssManifestUrls?: string[];
    /**
     * Configure origin endpoint policy.
     *
     * You can only add 1 OriginEndpointPolicy to an OriginEndpoint.
     * If you have already defined one, it will append to the policy already created.
     *
     * @param statement - The policy statement to add
     * @param cdnAuth - Optional CDN authorization configuration. Only the first CDN auth configuration is used if provided multiple times.
     */
    addToResourcePolicy(statement: PolicyStatement, cdnAuth?: CdnAuthConfiguration): AddToResourcePolicyResult;
    /**
     * Create a CloudWatch metric.
     *
     * @param metricName name of the metric.
     * @param props metric options.
     */
    metric(metricName: string, props?: MetricOptions): Metric;
    /**
     * Returns Metric for Ingress Bytes
     *
     * @default - sum over 60 seconds
     */
    metricIngressBytes(options?: MetricOptions): Metric;
    /**
     * Returns Metric for Egress Bytes
     *
     * @default - sum over 60 seconds
     */
    metricEgressBytes(props?: MetricOptions): Metric;
    /**
     * Returns Metric for Ingress response time
     *
     * @default - average over 60 seconds
     */
    metricIngressResponseTime(props?: MetricOptions): Metric;
    /**
     * Returns Metric for Egress Response time
     *
     * @default - average over 60 seconds
     */
    metricEgressResponseTime(props?: MetricOptions): Metric;
    /**
     * Returns Metric for Egress Request Count
     *
     * @default - sum over 60 seconds
     */
    metricEgressRequestCount(props?: MetricOptions): Metric;
    /**
     * Returns Metric for Ingress Request Count
     *
     * @default - sum over 60 seconds
     */
    metricIngressRequestCount(props?: MetricOptions): Metric;
}
/**
 * DRM settings keys for manifest filter configuration.
 */
export declare enum DrmSettingsKey {
    /**
     * Exclude EXT-X-SESSION-KEY tags from HLS and LL-HLS multivariant playlists.
     *
     * This can improve compatibility with legacy HLS clients that have issues
     * processing session keys, or provide more granular access control when
     * using manifest filtering.
     */
    EXCLUDE_SESSION_KEYS = "exclude_session_keys"
}
/**
 * Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest.
 */
export interface FilterConfiguration {
    /**
     * Optionally specify the clip start time for all of your manifest egress requests.
     * When you include clip start time, note that you cannot use clip start time query parameters for this manifest's endpoint URL.
     *
     * This will be converted to a UTC timestamp.
     *
     * @default - No clip start time
     */
    readonly clipStartTime?: Date;
    /**
     * Optionally specify the end time for all of your manifest egress requests.
     * When you include end time, note that you cannot use end time query parameters for this manifest's endpoint URL.
     *
     * This will be converted to a UTC timestamp.
     *
     * @default - No end time
     */
    readonly end?: Date;
    /**
     * Optionally specify the start time for all of your manifest egress requests.
     * When you include start time, note that you cannot use start time query parameters for this manifest's endpoint URL.
     *
     * This will be converted to a UTC timestamp.
     *
     * @default - No start time
     */
    readonly start?: Date;
    /**
     * Optionally specify one or more manifest filters for all of your manifest egress requests.
     * When you include a manifest filter, note that you cannot use an identical manifest filter query parameter for this manifest's endpoint URL.
     *
     * @default - No manifest filters
     */
    readonly manifestFilter?: ManifestFilter[];
    /**
     * Optionally specify the time delay for all of your manifest egress requests. Enter a value that is smaller than your endpoint's startover window.
     * When you include time delay, note that you cannot use time delay query parameters for this manifest's endpoint URL.
     *
     * @default - No time delay
     */
    readonly timeDelay?: Duration;
    /**
     * DRM settings for manifest egress requests.
     *
     * When you include a DRM setting, note that you cannot use an identical
     * DRM setting query parameter for this manifest's endpoint URL.
     *
     * @default - No DRM settings
     */
    readonly drmSettings?: DrmSettingsKey[];
}
/**
 * Options for configuring a StartTag.
 */
export interface StartTagOptions {
    /**
     * Specify the value for PRECISE within your EXT-X-START tag.
     *
     * Leave blank, or choose false, to use the default value NO. Choose true to use the value YES.
     *
     * @default false
     */
    readonly precise?: boolean;
}
/**
 * Helper class for creating EXT-X-START tags in HLS playlists.
 *
 * The EXT-X-START tag indicates a preferred point at which to start playing a playlist.
 */
export declare class StartTag {
    /**
     * Create a start tag with a time offset.
     *
     * @param timeOffset The time offset in seconds. Can be positive (forward from start) or negative (back from live edge).
     *   - If positive: must be less than (manifest duration - 3 × segment duration)
     *   - If negative: absolute value must be greater than (3 × segment duration) and less than manifest duration
     * @param options Additional options
     */
    static of(timeOffset: number, options?: StartTagOptions): StartTag;
    /**
     * Create a start tag with precise positioning enabled (PRECISE=YES).
     *
     * @param timeOffset The time offset in seconds (positive or negative)
     */
    static withPrecise(timeOffset: number): StartTag;
}
/**
 * Configuration for EXT-X-START tag in HLS playlists.
 *
 * Use the `StartTag` helper class to create instances with validation.
 */
export interface StartTag {
    /**
     * Specify the value for PRECISE within your EXT-X-START tag.
     *
     * Leave blank, or choose false, to use the default value NO. Choose true to use the value YES.
     */
    readonly precise?: boolean;
    /**
     * Specify the value for TIME-OFFSET within your EXT-X-START tag.
     *
     * Enter a signed floating point value which, if positive, must be less than the configured
     * manifest duration minus three times the configured segment target duration. If negative,
     * the absolute value must be larger than three times the configured segment target duration,
     * and the absolute value must be smaller than the configured manifest duration.
     */
    readonly timeOffset: number;
}
/**
 * Base manifest configuration.
 */
interface ManifestConfigurationBase {
    /**
     * Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest.
     *
     * https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
     * @default - No filter configuration
     */
    readonly filterConfiguration?: FilterConfiguration;
    /**
     * The total duration (in seconds) of the manifest's content.
     *
     * @default 60
     */
    readonly manifestWindow?: Duration;
}
/**
 * Choose how ad markers are included in the packaged content.
 */
export declare enum AdMarkerDash {
    /**
     * Option for BINARY - The SCTE-35 marker is expressed as a hex-string (Base64 string) rather than full XML.
     */
    BINARY = "BINARY",
    /**
     * Option for XML - The SCTE marker is expressed fully in XML.
     */
    XML = "XML"
}
/**
 * Choose how SCTE-35 ad markers are included in HLS and LL-HLS manifests.
 */
export declare enum AdMarkerHls {
    /**
     * Insert EXT-X-DATERANGE tags to signal ad content.
     */
    DATERANGE = "DATERANGE",
    /**
     * Insert enhanced SCTE-35 tags for ad content.
     */
    SCTE35_ENHANCED = "SCTE35_ENHANCED"
}
/**
 * The type of variable that MediaPackage uses in the media attribute of the SegmentTemplate tag.
 */
export declare enum SegmentTemplateFormat {
    /**
     * Option for number with timeline.
     */
    NUMBER_WITH_TIMELINE = "NUMBER_WITH_TIMELINE"
}
/**
 * The UTC timing mode for DASH.
 */
export declare enum DashUtcTimingMode {
    /**
     * Option for HTTP_HEAD.
     */
    HTTP_HEAD = "HTTP_HEAD",
    /**
     * Option for HTTP_ISO.
     */
    HTTP_ISO = "HTTP_ISO",
    /**
     * Option for HTTP_XSDATE.
     */
    HTTP_XSDATE = "HTTP_XSDATE",
    /**
     * Option for UTC_DIRECT.
     */
    UTC_DIRECT = "UTC_DIRECT"
}
/**
 * Options for triggers which cause AWS Elemental MediaPackage to create media presentation description (MPD) periods in the output manifest.
 */
export declare enum DashPeriodTriggers {
    /**
     * Option for AVAILS.
     */
    AVAILS = "AVAILS",
    /**
     * Option for DRM_KEY_ROTATION.
     */
    DRM_KEY_ROTATION = "DRM_KEY_ROTATION",
    /**
     * Option for SOURCE_CHANGES.
     */
    SOURCE_CHANGES = "SOURCE_CHANGES",
    /**
     * Option for SOURCE_DISRUPTIONS.
     */
    SOURCE_DISRUPTIONS = "SOURCE_DISRUPTIONS",
    /**
     * Option for NONE.
     */
    NONE = "NONE"
}
/**
 * DRM signaling determines the way DASH manifest signals the DRM content.
 */
export declare enum DrmSignalling {
    /**
     * Option for INDIVIDUAL.
     */
    INDIVIDUAL = "INDIVIDUAL",
    /**
     * Option for REFERENCED.
     */
    REFERENCED = "REFERENCED"
}
/**
 * STANDARD indicates a default manifest, which is compacted. NONE indicates a full manifest.
 */
export declare enum DashManifestCompactness {
    /**
     * STANDARD
     */
    STANDARD = "STANDARD",
    /**
     * NONE
     */
    NONE = "NONE"
}
/**
 * The base URLs to use for retrieving segments. You can specify multiple locations and indicate the
 * priority and weight for when each should be used, for use in multi-CDN workflows.
 */
export interface DashBaseUrlProperty {
    /**
     * For use with DVB-DASH profiles only. The priority of this location for serving segments. The lower the number, the higher the priority.
     *
     * @default - No priority specified
     */
    readonly dvbPriority?: number;
    /**
     * For use with DVB-DASH profiles only. The weighting for source locations that have the same priority.
     *
     * @default - No weight specified
     */
    readonly dvbWeight?: number;
    /**
     * The name of the source location.
     *
     * @default - No service location specified
     */
    readonly serviceLocation?: string;
    /**
     * A source location for segments.
     */
    readonly url: string;
}
/**
 * For use with DVB-DASH profiles only. The settings for error reporting from the playback device
 * that you want AWS Elemental MediaPackage to pass through to the manifest.
 */
export interface DashDvbMetricsReporting {
    /**
     * The number of playback devices per 1000 that will send error reports to the reporting URL.
     * This represents the probability that a playback device will be a reporting player for this session.
     *
     * @default - No probability specified
     */
    readonly probability?: number;
    /**
     * The URL where playback devices send error reports.
     */
    readonly reportingUrl: string;
}
/**
 * For use with DVB-DASH profiles only. The settings for font downloads that you want AWS Elemental MediaPackage to pass through to the manifest.
 */
export interface DashDvbFontDownload {
    /**
     * The fontFamily name for subtitles, as described in EBU-TT-D Subtitling Distribution Format.
     * @external https://tech.ebu.ch/publications/tech3380
     *
     * @default - No font family specified
     */
    readonly fontFamily?: string;
    /**
     * The mimeType of the resource that's at the font download URL.
     * For information about font MIME types, see the MPEG-DASH Profile for Transport of ISO BMFF Based DVB Services over IP Based Networks document.
     *
     * @external https://dvb.org/wp-content/uploads/2021/06/A168r4_MPEG-DASH-Profile-for-Transport-of-ISO-BMFF-Based-DVB-Services_Draft-ts_103-285-v140_November_2021.pdf
     * @default - No MIME type specified
     */
    readonly mimeType?: string;
    /**
     * The URL for downloading fonts for subtitles.
     *
     * @default - No font download URL specified
     */
    readonly url?: string;
}
/**
 * The font download and error reporting information that you want MediaPackage to pass through to the manifest.
 */
export interface DashDvbSettings {
    /**
     * Playback device error reporting settings.
     *
     * @default - No error metrics configured
     */
    readonly errorMetrics?: DashDvbMetricsReporting[];
    /**
     * Subtitle font settings.
     *
     * @default - No font download configured
     */
    readonly fontDownload?: DashDvbFontDownload;
}
/**
 * Details about the content that you want MediaPackage to pass through in the manifest to the playback device.
 */
export interface DashProgramInformation {
    /**
     * A copyright statement about the content.
     *
     * @default - No copyright information
     */
    readonly copyright?: string;
    /**
     * The language code for this manifest.
     *
     * @default - No language code specified
     */
    readonly languageCode?: string;
    /**
     * An absolute URL that contains more information about this content.
     *
     * @default - No additional information URL
     */
    readonly moreInformationUrl?: string;
    /**
     * Information about the content provider.
     *
     * @default - No source information
     */
    readonly source?: string;
    /**
     * The title for the manifest.
     *
     * @default - No title specified
     */
    readonly title?: string;
}
/**
 * Options for TTML Profile
 */
export declare enum TtmlProfile {
    /**
     * IMSC_1
     */
    IMSC_1 = "IMSC_1",
    /**
     * EBU_TT_D_101
     */
    EBU_TT_D_101 = "EBU_TT_D_101"
}
/**
 * Configuration for TTML subtitles in DASH manifests.
 */
export interface DashTtmlConfiguration {
    /**
     * The profile that MediaPackage uses when signaling subtitles in the manifest. IMSC is the default profile. EBU-TT-D produces subtitles that are compliant with the EBU-TT-D TTML profile. MediaPackage passes through subtitle styles to the manifest.
     * For more information about EBU-TT-D subtitles, see EBU-TT-D Subtitling Distribution Format.
     *
     * @external https://tech.ebu.ch/publications/tech3380
     */
    readonly ttmlProfile: TtmlProfile;
}
/**
 * Configuration for subtitles in DASH manifests.
 */
export interface DashSubtitleConfiguration {
    /**
     * Settings for TTML subtitles.
     *
     * @default - No TTML configuration
     */
    readonly ttmlConfiguration?: DashTtmlConfiguration;
}
/**
 * The layout of the MSS manifest.
 */
export declare enum MssManifestLayout {
    /**
     * Full manifest layout.
     */
    FULL = "FULL",
    /**
     * Compact manifest layout.
     */
    COMPACT = "COMPACT"
}
/**
 * The MSS manifest configuration associated with the origin endpoint.
 */
export interface MssManifestConfiguration extends ManifestConfigurationBase {
    /**
     * The name of the manifest associated with the MSS manifest configuration.
     */
    readonly manifestName: string;
    /**
     * The layout of the MSS manifest.
     *
     * @default MssManifestLayout.FULL
     */
    readonly manifestLayout?: MssManifestLayout;
}
/**
 * The DASH manifest configuration associated with the origin endpoint.
 */
export interface DashManifestConfiguration extends ManifestConfigurationBase {
    /**
     * The base URLs to use for retrieving segments.
     *
     * @default - No base URLs specified
     */
    readonly baseUrls?: DashBaseUrlProperty[];
    /**
     * The layout of the DASH manifest that MediaPackage produces.
     *
     * @default DashManifestCompactness.STANDARD
     */
    readonly compactness?: DashManifestCompactness;
    /**
     * For endpoints that use the DVB-DASH profile only.
     *
     * @default - No DVB settings
     */
    readonly dvbSettings?: DashDvbSettings;
    /**
     * The profile that the output is compliant with.
     *
     * @default - No profiles specified
     */
    readonly profiles?: string[];
    /**
     * Details about the content that you want MediaPackage to pass through in the manifest to the playback device.
     *
     * @default - No program information
     */
    readonly programInformation?: DashProgramInformation;
    /**
     * The configuration for DASH subtitles.
     *
     * @default - No subtitle configuration
     */
    readonly subtitleConfiguration?: DashSubtitleConfiguration;
    /**
     * The name of the manifest associated with the DASH manifest configuration.
     */
    readonly manifestName: string;
    /**
     * DRM signaling determines the way DASH manifest signals the DRM content.
     *
     * @default - No DRM signaling specified
     */
    readonly drmSignalling?: DrmSignalling;
    /**
     * The minimum amount of content that the player must keep available in the buffer.
     *
     * @default 5
     */
    readonly minBufferTime?: Duration;
    /**
     * The minimum amount of time for the player to wait before requesting an updated manifest.
     *
     * @default 2
     */
    readonly minUpdatePeriod?: Duration;
    /**
     * Specify what triggers cause AWS Elemental MediaPackage to create media presentation description (MPD) periods in the output manifest.
     *
     * @default [DashPeriodTriggers.AVAILS, DashPeriodTriggers.DRM_KEY_ROTATION, DashPeriodTriggers.SOURCE_CHANGES, DashPeriodTriggers.SOURCE_DISRUPTIONS]
     */
    readonly periodTriggers?: DashPeriodTriggers[];
    /**
     * Choose how ad markers are included in the packaged content. If you include ad markers in the content stream in your upstream encoders,
     * then you need to inform MediaPackage what to do with the ad markers in the output.
     *
     * To choose this option STCE filtering needs to be enabled.
     *
     * @default AdMarkerDash.XML
     */
    readonly scteDashAdMarker?: AdMarkerDash;
    /**
     * The type of variable that MediaPackage uses in the media attribute of the SegmentTemplate tag.
     *
     * @default SegmentTemplateFormat.NUMBER_WITH_TIMELINE
     */
    readonly segmentTemplateFormat?: SegmentTemplateFormat;
    /**
     * The amount of time that the player should be from the end of the manifest.
     *
     * @default 10
     */
    readonly suggestedPresentationDelay?: Duration;
    /**
     * The UTC timing mode.
     *
     * @default DashUtcTimingMode.UTC_DIRECT
     */
    readonly utcTimingMode?: DashUtcTimingMode;
    /**
     * The method that the player uses to synchronize to coordinated universal time (UTC) wall clock time.
     *
     * @default undefined - No value is specified
     */
    readonly utcTimingSource?: string;
}
/**
 * The HLS manifest configuration associated with the origin endpoint.
 */
export interface HlsManifestConfiguration extends ManifestConfigurationBase {
    /**
     * The name of the manifest associated with the HLS manifest configuration.
     */
    readonly manifestName: string;
    /**
     * The name of the child manifest associated with the HLS manifest configuration.
     *
     * @default - No child manifest name specified
     */
    readonly childManifestName?: string;
    /**
     * Inserts EXT-X-PROGRAM-DATE-TIME tags in the output manifest at the interval that you specify.
     * If you don't enter an interval, EXT-X-PROGRAM-DATE-TIME tags aren't included in the manifest.
     * The tags sync the stream to the wall clock so that viewers can seek to a specific time in the playback timeline on the player.
     *
     * @default - No program date time interval
     */
    readonly programDateTimeInterval?: Duration;
    /**
     * The SCTE-35 HLS configuration associated with the HLS manifest configuration of the origin endpoint.
     *
     * @default - No SCTE ad marker configuration
     */
    readonly scteAdMarkerHls?: AdMarkerHls;
    /**
     * Insert EXT-X-START tag in the manifest with the configured settings
     *
     * @default - No start tag
     */
    readonly startTag?: StartTag;
    /**
     * When enabled, MediaPackage URL-encodes the query string for API requests for HLS child manifests to comply with AWS Signature Version 4 (SigV4) signature signing protocol.
     * For more information, see AWS Signature Version 4 for API requests in AWS Identity and Access Management User Guide.
     *
     * @external https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_sigv.html
     * @default false
     */
    readonly urlEncodeChildManifest?: boolean;
}
/**
 * Specify a low-latency HTTP live streaming (LL-HLS) manifest configuration.
 */
export interface LowLatencyHlsManifestConfiguration extends ManifestConfigurationBase {
    /**
     * A short string that's appended to the endpoint URL. The manifest name creates a unique path to this endpoint.
     * If you don't enter a value, MediaPackage uses the default manifest name, index. MediaPackage automatically inserts the format extension, such as .m3u8.
     * You can't use the same manifest name if you use HLS manifest and low-latency HLS manifest.
     * The manifestName on the HLSManifest object overrides the manifestName you provided on the originEndpoint object.
     */
    readonly manifestName: string;
    /**
     * The name of the child manifest associated with the low-latency HLS (LL-HLS) manifest configuration of the origin endpoint.
     *
     * @default - No child manifest name specified
     */
    readonly childManifestName?: string;
    /**
     * Inserts EXT-X-PROGRAM-DATE-TIME tags in the output manifest at the interval that you specify.
     * If you don't enter an interval, EXT-X-PROGRAM-DATE-TIME tags aren't included in the manifest.
     * The tags sync the stream to the wall clock so that viewers can seek to a specific time in the playback timeline on the player.
     *
     * @default - No program date time interval
     */
    readonly programDateTimeInterval?: Duration;
    /**
     * The SCTE-35 HLS configuration associated with the low-latency HLS (LL-HLS) manifest configuration of the origin endpoint.
     *
     * @default - No SCTE ad marker configuration
     */
    readonly scteAdMarkerHls?: AdMarkerHls;
    /**
     * Insert EXT-X-START tag in the manifest with the configured settings
     *
     * @default - No start tag
     */
    readonly startTag?: StartTag;
    /**
     * When enabled, MediaPackage URL-encodes the query string for API requests for LL-HLS child manifests to comply with AWS Signature Version 4 (SigV4) signature signing protocol.
     * For more information, see AWS Signature Version 4 for API requests in AWS Identity and Access Management User Guide.
     *
     * @external https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_sigv.html
     * @default false
     */
    readonly urlEncodeChildManifest?: boolean;
}
/**
 * Configuration parameters for an AWS Elemental MediaPackage V2 Origin Endpoint.
 */
export interface OriginEndpointOptions {
    /**
     * The name of the origin endpoint associated with the origin endpoint configuration.
     * @default autogenerated
     */
    readonly originEndpointName?: string;
    /**
     * The description associated with the origin endpoint.
     *
     * @default undefined - No description is added to Origin Endpoint
     */
    readonly description?: string;
    /**
     * The tags associated with the origin endpoint.
     *
     * @default - No tagging
     */
    readonly tags?: {
        [key: string]: string;
    };
    /**
     * Manifests configuration for HLS, Low Latency HLS and DASH.
     */
    readonly manifests: Manifest[];
    /**
     * The size of the window to specify a window of the live stream that's available for on-demand viewing. Viewers can start-over or catch-up on content that falls within the window.
     *
     * @default 900
     */
    readonly startoverWindow?: Duration;
    /**
     * The segment associated with the origin endpoint.
     *
     * Inside the segment configuration you can define options such as encryption, SPEKE parameters and other
     * general segment configurations.
     *
     * Use Segment.ts() or Segment.cmaf() to create the configuration.
     */
    readonly segment: SegmentConfiguration;
    /**
     * The failover settings for the endpoint.
     *
     * @default undefined - No force endpoint configuration is configured
     */
    readonly forceEndpointConfigurationConditions?: EndpointErrorConfiguration[];
    /**
     * Provide access to MediaPackage V2 Origin Endpoint via secret header.
     *
     * @default undefined - Not configured on endpoint
     */
    readonly cdnAuth?: CdnAuthConfiguration;
    /**
     * Policy to apply when the origin endpoint is removed from the stack
     *
     * Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful,
     * their contents are transient and it is common to add and remove these while rearchitecting your application.
     * The default is therefore `DESTROY`. Change it to `RETAIN` if the content (in a lookback window) are so
     * valuable that accidentally losing it would be unacceptable.
     *
     * @default RemovalPolicy.DESTROY
     */
    readonly removalPolicy?: RemovalPolicy;
}
/**
 * Properties to set on an Origin Endpoint.
 */
export interface OriginEndpointProps extends OriginEndpointOptions {
    /**
     * The channel associated with the origin endpoint.
     */
    readonly channel: IChannel;
}
/**
 * Represents an Origin Endpoint defined outside of this stack.
 */
export interface OriginEndpointAttributes {
    /**
     * The name that describes the channel group. The name is the primary identifier for the channel group.
     *
     * @attribute
     */
    readonly channelGroupName: string;
    /**
     * The name that describes the channel. The name is the primary identifier for the channel.
     *
     * @attribute
     */
    readonly channelName: string;
    /**
     * The name that describes the origin endpoint.
     *
     * @attribute
     */
    readonly originEndpointName: string;
    /**
     * The AWS region where the origin endpoint lives.
     *
     * Required for cross-region imports to construct the correct ARN.
     *
     * @default - the importing stack's region
     */
    readonly region?: string;
}
/**
 * DRM systems available for CMAF encryption.
 *
 * CENC supports PlayReady, Widevine, and Irdeto.
 * CBCS supports PlayReady, Widevine, and FairPlay.
 */
export declare enum CmafDrmSystem {
    /**
     * FairPlay DRM - used with CBCS encryption.
     */
    FAIRPLAY = "FAIRPLAY",
    /**
     * PlayReady DRM - used with CENC and CBCS encryption.
     */
    PLAYREADY = "PLAYREADY",
    /**
     * Widevine DRM - used with CENC and CBCS encryption.
     */
    WIDEVINE = "WIDEVINE",
    /**
     * Irdeto DRM - used with CENC encryption.
     */
    IRDETO = "IRDETO"
}
/**
 * DRM systems available for TS encryption.
 *
 * SAMPLE_AES uses FairPlay, AES_128 uses Clear Key AES 128.
 */
export declare enum TsDrmSystem {
    /**
     * FairPlay DRM - used with SAMPLE_AES encryption.
     */
    FAIRPLAY = "FAIRPLAY",
    /**
     * Clear Key AES 128 - used with AES_128 encryption.
     */
    CLEAR_KEY_AES_128 = "CLEAR_KEY_AES_128"
}
/**
 * DRM systems available for ISM encryption.
 *
 * ISM only supports PlayReady with CENC.
 */
export declare enum IsmDrmSystem {
    /**
     * PlayReady DRM.
     */
    PLAYREADY = "PLAYREADY"
}
/**
 * Base properties common to all SPEKE encryption configurations.
 */
interface SpekeEncryptionPropsBase {
    /**
     * The unique identifier for the content.
     *
     * The service sends this identifier to the key server to identify the current endpoint.
     * How unique you make this identifier depends on how fine-grained you want access controls to be.
     * The service does not permit you to use the same ID for two simultaneous encryption processes.
     */
    readonly resourceId: string;
    /**
     * IAM role for accessing the key provider API.
     *
     * This role must have a trust policy that allows MediaPackage to assume the role,
     * and it must have sufficient permissions to access the key retrieval URL.
     */
    readonly role: IRole;
    /**
     * URL of the SPEKE key provider.
     */
    readonly url: string;
    /**
     * The ARN of the certificate that you imported to AWS Certificate Manager
     * to add content key encryption to this endpoint.
     *
     * For this feature to work, your DRM key provider must support content key encryption.
     *
     * @default - no content key encryption
     */
    readonly certificate?: ICertificate;
    /**
     * Audio encryption preset.
     *
     * @default PresetSpeke20Audio.PRESET_AUDIO_1
     */
    readonly audioPreset?: PresetSpeke20Audio;
    /**
     * Video encryption preset.
     *
     * @default PresetSpeke20Video.PRESET_VIDEO_1
     */
    readonly videoPreset?: PresetSpeke20Video;
}
/**
 * Properties for CMAF SPEKE encryption configuration.
 */
export interface CmafSpekeEncryptionProps extends SpekeEncryptionPropsBase {
    /**
     * The encryption method to use.
     */
    readonly method: CmafEncryptionMethod;
    /**
     * The DRM systems to use for content protection.
     *
     * CENC supports PlayReady, Widevine, and Irdeto.
     * CBCS supports PlayReady, Widevine, and FairPlay.
     */
    readonly drmSystems: CmafDrmSystem[];
    /**
     * Constant initialization vector (32-character hex string).
     *
     * A 128-bit, 16-byte hex value represented by a 32-character string,
     * used in conjunction with the key for encrypting content.
     *
     * @default - MediaPackage generates the IV
     */
    readonly constantInitializationVector?: string;
    /**
     * Key rotation interval.
     *
     * @default - no rotation
     */
    readonly keyRotationInterval?: Duration;
    /**
     * When enabled, DRM metadata is excluded from CMAF segments.
     *
     * @default false
     */
    readonly excludeSegmentDrmMetadata?: boolean;
}
/**
 * Properties for TS SPEKE encryption configuration.
 */
export interface TsSpekeEncryptionProps extends SpekeEncryptionPropsBase {
    /**
     * The encryption method to use.
     */
    readonly method: TsEncryptionMethod;
    /**
     * The DRM systems to use for content protection.
     *
     * @default - FairPlay for SAMPLE_AES, Clear Key AES 128 for AES_128
     */
    readonly drmSystems?: TsDrmSystem[];
    /**
     * Constant initialization vector (32-character hex string).
     *
     * A 128-bit, 16-byte hex value represented by a 32-character string,
     * used in conjunction with the key for encrypting content.
     *
     * @default - MediaPackage generates the IV
     */
    readonly constantInitializationVector?: string;
    /**
     * Key rotation interval.
     *
     * @default - no rotation
     */
    readonly keyRotationInterval?: Duration;
}
/**
 * Properties for ISM SPEKE encryption configuration.
 *
 * ISM only supports CENC encryption with PlayReady DRM.
 * Key rotation and constant initialization vectors are not supported.
 * Audio and video presets default to SHARED.
 */
export interface IsmSpekeEncryptionProps {
    /**
     * The DRM systems to use for content protection.
     *
     * @default - [IsmDrmSystem.PLAYREADY]
     */
    readonly drmSystems?: IsmDrmSystem[];
    /**
     * The unique identifier for the content.
     */
    readonly resourceId: string;
    /**
     * IAM role for accessing the key provider API.
     */
    readonly role: IRole;
    /**
     * URL of the SPEKE key provider.
     */
    readonly url: string;
    /**
     * The ARN of the certificate that you imported to AWS Certificate Manager
     * to add content key encryption to this endpoint.
     *
     * @default - no content key encryption
     */
    readonly certificate?: ICertificate;
}
/**
 * Base class for encryption configurations.
 *
 * Use `CmafEncryption.speke()`, `TsEncryption.speke()`, or `IsmEncryption.speke()` to create instances.
 */
export declare abstract class EncryptionConfiguration {
}
/**
 * Encryption configuration for CMAF segments.
 *
 * Use `CmafEncryption.speke()` to create an instance.
 */
export declare class CmafEncryption extends EncryptionConfiguration {
    /**
     * Create a SPEKE-based encryption configuration for CMAF segments.
     */
    static speke(props: CmafSpekeEncryptionProps): CmafEncryption;
    private readonly config;
    private constructor();
}
/**
 * Encryption configuration for TS segments.
 *
 * Use `TsEncryption.speke()` to create an instance.
 */
export declare class TsEncryption extends EncryptionConfiguration {
    /**
     * Create a SPEKE-based encryption configuration for TS segments.
     */
    static speke(props: TsSpekeEncryptionProps): TsEncryption;
    private readonly config;
    private constructor();
}
/**
 * Encryption configuration for ISM (Microsoft Smooth Streaming) segments.
 *
 * ISM only supports CENC encryption with PlayReady DRM.
 * Audio and video presets are always SHARED.
 *
 * Use `IsmEncryption.speke()` to create an instance.
 */
export declare class IsmEncryption extends EncryptionConfiguration {
    /**
     * Create a SPEKE-based encryption configuration for ISM segments.
     */
    static speke(props: IsmSpekeEncryptionProps): IsmEncryption;
    private readonly config;
    private constructor();
}
/**
 * The segment configuration, including the segment name, duration, and other configuration values.
 */
export interface SegmentConfiguration {
    /**
     * The container type for this segment (TS or CMAF)
     */
    readonly containerType: ContainerType;
    /**
     * Whether the segment includes I-frame-only streams.
     *
     * @default undefined - Not specified.
     */
    readonly includeIframeOnlyStreams?: boolean;
    /**
     * The SCTE-35 configuration associated with the segment.
     *
     * The SCTE-35 message types that you want to be treated as ad markers in the output.
     *
     * @default - No SCTE filtering
     */
    readonly scteFilter?: ScteMessageType[];
    /**
     * Controls whether SCTE-35 messages are included in segment files.
     *
     * @default - SCTE-35 messages are not included in segments
     */
    readonly scteInSegments?: ScteInSegments;
    /**
     * The duration of the segments.
     *
     * @default 6
     */
    readonly segmentDuration?: Duration;
    /**
     * The name of the segment associated with the origin endpoint.
     *
     * @default segment
     */
    readonly segmentName?: string;
    /**
     * Whether the segment includes DVB subtitles.
     *
     * @default false
     */
    readonly tsIncludeDvbSubtitles?: boolean;
    /**
     * Whether the segment is an audio rendition group.
     *
     * @default false
     */
    readonly tsUseAudioRenditionGroup?: boolean;
    /**
     * Encryption configuration for the segment.
     *
     * @default - No encryption
     */
    readonly encryption?: EncryptionConfiguration;
}
/**
 * Base properties common to all segment configurations.
 */
export interface SegmentPropsBase {
    /**
     * Whether to include I-frame-only streams.
     *
     * @default false
     */
    readonly includeIframeOnlyStreams?: boolean;
    /**
     * Duration of each segment.
     *
     * @default Duration.seconds(6)
     */
    readonly duration?: Duration;
    /**
     * Name of the segment.
     *
     * @default 'segment'
     */
    readonly name?: string;
}
/**
 * Properties for TS (Transport Stream) segment configuration.
 */
export interface TsSegmentProps extends SegmentPropsBase {
    /**
     * SCTE-35 message types to treat as ad markers.
     *
     * @default - no filtering
     */
    readonly scteFilter?: ScteMessageType[];
    /**
     * Controls whether SCTE-35 messages are included in segment files.
     *
     * @default - SCTE-35 messages are not included in segments
     */
    readonly scteInSegments?: ScteInSegments;
    /**
     * Whether to include DVB subtitles.
     *
     * @default false
     */
    readonly includeDvbSubtitles?: boolean;
    /**
     * Whether to use audio rendition groups.
     *
     * @default false
     */
    readonly useAudioRenditionGroup?: boolean;
    /**
     * Encryption configuration for the TS segment.
     *
     * Use `TsEncryption.speke()` to create the configuration.
     *
     * @default - No encryption
     */
    readonly encryption?: TsEncryption;
}
/**
 * Properties for CMAF segment configuration.
 */
export interface CmafSegmentProps extends SegmentPropsBase {
    /**
     * SCTE-35 message types to treat as ad markers.
     *
     * @default - no filtering
     */
    readonly scteFilter?: ScteMessageType[];
    /**
     * Controls whether SCTE-35 messages are included in segment files.
     *
     * @default - SCTE-35 messages are not included in segments
     */
    readonly scteInSegments?: ScteInSegments;
    /**
     * Encryption configuration for the CMAF segment.
     *
     * Use `CmafEncryption.speke()` to create the configuration.
     *
     * @default - No encryption
     */
    readonly encryption?: CmafEncryption;
}
/**
 * Properties for ISM (Microsoft Smooth Streaming) segment configuration.
 */
export interface IsmSegmentProps extends SegmentPropsBase {
    /**
     * Encryption configuration for the ISM segment.
     *
     * Use `IsmEncryption.speke()` to create the configuration.
     *
     * @default - No encryption
     */
    readonly encryption?: IsmEncryption;
}
/**
 * Helper class for creating segment configurations.
 */
export declare class Segment {
    /**
     * Create a TS (Transport Stream) segment configuration.
     *
     * Use this for endpoints with ContainerType.TS.
     */
    static ts(props?: TsSegmentProps): SegmentConfiguration;
    /**
     * Create a CMAF segment configuration.
     *
     * Use this for endpoints with ContainerType.CMAF.
     */
    static cmaf(props?: CmafSegmentProps): SegmentConfiguration;
    /**
     * Create an ISM (Microsoft Smooth Streaming) segment configuration.
     *
     * Use this for endpoints with ContainerType.ISM.
     */
    static ism(props?: IsmSegmentProps): SegmentConfiguration;
}
declare abstract class OriginEndpointBase extends Resource implements IOriginEndpoint {
    /**
     * Creates an OriginEndpoint construct that represents an external (imported) Origin Endpoint from its ARN.
     *
     * The ARN is expected to be in the format:
     * `arn:<partition>:mediapackagev2:<region>:<account>:channelGroup/<groupName>/channel/<channelName>/originEndpoint/<endpointName>`
     */
    static fromOriginEndpointArn(scope: Construct, id: string, originEndpointArn: string): IOriginEndpoint;
    /**
     * Creates an OriginEndpoint construct that represents an external (imported) Origin Endpoint.
     */
    static fromOriginEndpointAttributes(scope: Construct, id: string, attrs: OriginEndpointAttributes): IOriginEndpoint;
    abstract readonly channelGroupName: string;
    abstract readonly channelName: string;
    abstract readonly originEndpointName: string;
    abstract readonly originEndpointArn: string;
    abstract readonly createdAt?: string;
    abstract readonly modifiedAt?: string;
    abstract readonly hlsManifestUrls?: string[];
    abstract readonly lowLatencyHlsManifestUrls?: string[];
    abstract readonly dashManifestUrls?: string[];
    abstract readonly mssManifestUrls?: string[];
    /**
     * A reference to this Origin Endpoint resource.
     * Required by the auto-generated IOriginEndpointRef interface.
     */
    get originEndpointRef(): OriginEndpointReference;
    protected abstract hlsManifests: CfnOriginEndpoint.HlsManifestConfigurationProperty[];
    protected abstract llHlsManifests: CfnOriginEndpoint.LowLatencyHlsManifestConfigurationProperty[];
    protected abstract dashManifests: CfnOriginEndpoint.DashManifestConfigurationProperty[];
    protected abstract mssManifests: CfnOriginEndpoint.MssManifestConfigurationProperty[];
    protected abstract segment?: SegmentConfiguration;
    /**
     * The resource policy associated with this origin endpoint.
     *
     * If `autoCreatePolicy` is true, an `OriginEndpointPolicy` will be created upon the
     * first call to addToResourcePolicy(s).
     */
    abstract policy?: OriginEndpointPolicy;
    /**
     * Indicates if an origin endpoint resource policy should automatically be created upon
     * the first call to `addToResourcePolicy`.
     */
    protected abstract autoCreatePolicy: boolean;
    /**
     * CDN authorization configuration to be applied when the policy is created.
     */
    private cdnAuthConfig?;
    /**
     * Configure origin endpoint policy.
     *
     * You can only add 1 OriginEndpointPolicy to an OriginEndpoint.
     * If you have already defined one, it will append to the policy already created.
     *
     * @param statement - The policy statement to add
     * @param cdnAuth - Optional CDN authorization configuration. If provided, the policy will be
     *                  created with CDN authentication enabled using secrets from AWS Secrets Manager.
     *                  If cdnAuth is provided multiple times, only the first configuration is used.
     */
    addToResourcePolicy(statement: PolicyStatement, cdnAuth?: CdnAuthConfiguration): AddToResourcePolicyResult;
    /**
     * Validate and modify Segment configuration for endpoint.
     */
    protected segmentValidation(segmentContainerType: ContainerType, segment?: SegmentConfiguration): CfnOriginEndpoint.SegmentProperty | undefined;
    /**
     * Create a CloudWatch metric.
     *
     * @param metricName name of the metric.
     * @param props metric options.
     */
    metric(metricName: string, props?: MetricOptions): Metric;
    /**
     * Returns Metric for Ingress Bytes
     *
     * @default - sum over 60 seconds
     */
    metricIngressBytes(props?: MetricOptions): Metric;
    /**
     * Returns Metric for Egress Bytes
     *
     * @default - sum over 60 seconds
     */
    metricEgressBytes(props?: MetricOptions): Metric;
    /**
     * Returns Metric for Ingress response time
     *
     * @default - average over 60 seconds
     */
    metricIngressResponseTime(props?: MetricOptions): Metric;
    /**
     * Returns Metric for Egress Response time
     *
     * @default - average over 60 seconds
     */
    metricEgressResponseTime(props?: MetricOptions): Metric;
    /**
     * Returns Metric for Egress Request Count
     *
     * @default - sum over 60 seconds
     */
    metricEgressRequestCount(props?: MetricOptions): Metric;
    /**
     * Returns Metric for Ingress Request Count
     *
     * @default - sum over 60 seconds
     */
    metricIngressRequestCount(props?: MetricOptions): Metric;
}
/**
 * Defines an AWS Elemental MediaPackage V2 Origin Endpoint
 */
export declare class OriginEndpoint extends OriginEndpointBase implements IOriginEndpoint {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    readonly channelGroupName: string;
    readonly channelName: string;
    readonly originEndpointName: string;
    readonly originEndpointArn: string;
    /**
     * The timestamp of the creation of the origin endpoint.
     */
    readonly createdAt?: string;
    /**
     * The timestamp of the modification of the origin endpoint.
     */
    readonly modifiedAt?: string;
    /**
     * Array containing Low Latency HLS Manifests created by the OriginEndpoint.
     */
    readonly lowLatencyHlsManifestUrls?: string[];
    /**
     * Array containing HLS Manifests created by the OriginEndpoint.
     */
    readonly hlsManifestUrls?: string[];
    /**
     * Array containing DASH Manifests created by the OriginEndpoint.
     */
    readonly dashManifestUrls?: string[];
    /**
     * Array containing MSS Manifests created by the OriginEndpoint.
     */
    readonly mssManifestUrls?: string[];
    /**
     * The resource policy associated with this origin endpoint.
     *
     * If `autoCreatePolicy` is true, an `OriginEndpointPolicy` will be created upon the
     * first call to addToResourcePolicy(s).
     */
    policy?: OriginEndpointPolicy;
    protected autoCreatePolicy: boolean;
    protected hlsManifests: CfnOriginEndpoint.HlsManifestConfigurationProperty[];
    protected llHlsManifests: CfnOriginEndpoint.LowLatencyHlsManifestConfigurationProperty[];
    protected dashManifests: CfnOriginEndpoint.DashManifestConfigurationProperty[];
    protected mssManifests: CfnOriginEndpoint.MssManifestConfigurationProperty[];
    protected segment?: SegmentConfiguration;
    constructor(scope: Construct, id: string, props: OriginEndpointProps);
}
export {};
