import { Resource } from 'aws-cdk-lib';
import { PolicyDocument } from 'aws-cdk-lib/aws-iam';
import type { Construct } from 'constructs';
import type { IChannel } from './channel';
/**
 * Properties for the Channel Policy
 */
export interface ChannelPolicyProps {
    /**
     * Channel to apply the Channel Policy to.
     */
    readonly channel: IChannel;
    /**
     * Initial policy document to apply.
     *
     * @default - empty policy document
     */
    readonly policyDocument?: PolicyDocument;
}
/**
 * The channel policy for an AWS Elemental MediaPackage V2 channel
 *
 * Policies define the operations that are allowed on this resource.
 *
 * You almost never need to define this construct directly.
 *
 * All AWS resources that support resource policies have a method called
 * `addToResourcePolicy()`, which will automatically create a new resource
 * policy if one doesn't exist yet, otherwise it will add to the existing
 * policy.
 *
 * The channel policy method is implemented differently than `addToResourcePolicy()`
 * as `ChannelPolicy` creates a new policy without knowing one earlier existed.
 * This will cause a resource conflict if both are invoked (or even multiple channel
 * policies are defined), so care is to be taken to ensure only 1 channel policy
 * is created per channel.
 *
 * Hence it's strongly recommended to use `addToResourcePolicy()`.
 */
export declare class ChannelPolicy extends Resource {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * A policy document containing permissions to add to the specified channel.
     */
    readonly document: PolicyDocument;
    constructor(scope: Construct, id: string, props: ChannelPolicyProps);
}
