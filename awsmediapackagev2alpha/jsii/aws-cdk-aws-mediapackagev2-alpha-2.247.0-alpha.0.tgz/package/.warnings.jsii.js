function _aws_cdk_aws_mediapackagev2_alpha_InputType(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_IChannel(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_IngestEndpoint(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_InputSwitchConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.preferredInput))
            _aws_cdk_aws_mediapackagev2_alpha_IngestEndpoint(p.preferredInput);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_HeadersCMSD(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_CmafInputProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.inputSwitchConfiguration))
            _aws_cdk_aws_mediapackagev2_alpha_InputSwitchConfiguration(p.inputSwitchConfiguration);
        if (p.outputHeaders != null)
            for (const o of p.outputHeaders)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_HeadersCMSD(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_InputConfiguration(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_ChannelOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.input))
            _aws_cdk_aws_mediapackagev2_alpha_InputConfiguration(p.input);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_ChannelProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.channelGroup))
            _aws_cdk_aws_mediapackagev2_alpha_IChannelGroup(p.channelGroup);
        if (!visitedObjects.has(p.input))
            _aws_cdk_aws_mediapackagev2_alpha_InputConfiguration(p.input);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_ChannelAttributes(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_Channel(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_AudioCodec(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_VideoCodec(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_VideoDynamicRange(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_TrickplayType(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_NumericFilterKey(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_TextFilterKey(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_BitrateFilterKey(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_NumericExpression(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_BitrateExpression(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_ManifestFilter(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_Manifest(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_ContainerType(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_CmafEncryptionMethod(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_TsEncryptionMethod(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_PresetSpeke20Audio(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_PresetSpeke20Video(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_EndpointErrorConfiguration(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_ScteMessageType(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_ScteInSegments(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_IOriginEndpoint(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_DrmSettingsKey(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_FilterConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.drmSettings != null)
            for (const o of p.drmSettings)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_DrmSettingsKey(o);
        if (p.manifestFilter != null)
            for (const o of p.manifestFilter)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_ManifestFilter(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_StartTagOptions(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_StartTag(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_AdMarkerDash(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_AdMarkerHls(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_SegmentTemplateFormat(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_DashUtcTimingMode(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_DashPeriodTriggers(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_DrmSignalling(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_DashManifestCompactness(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_DashBaseUrlProperty(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_DashDvbMetricsReporting(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_DashDvbFontDownload(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_DashDvbSettings(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.errorMetrics != null)
            for (const o of p.errorMetrics)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_DashDvbMetricsReporting(o);
        if (!visitedObjects.has(p.fontDownload))
            _aws_cdk_aws_mediapackagev2_alpha_DashDvbFontDownload(p.fontDownload);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_DashProgramInformation(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_TtmlProfile(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_DashTtmlConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.ttmlProfile))
            _aws_cdk_aws_mediapackagev2_alpha_TtmlProfile(p.ttmlProfile);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_DashSubtitleConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.ttmlConfiguration))
            _aws_cdk_aws_mediapackagev2_alpha_DashTtmlConfiguration(p.ttmlConfiguration);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_MssManifestLayout(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_MssManifestConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.filterConfiguration))
            _aws_cdk_aws_mediapackagev2_alpha_FilterConfiguration(p.filterConfiguration);
        if (!visitedObjects.has(p.manifestLayout))
            _aws_cdk_aws_mediapackagev2_alpha_MssManifestLayout(p.manifestLayout);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_DashManifestConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.baseUrls != null)
            for (const o of p.baseUrls)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_DashBaseUrlProperty(o);
        if (!visitedObjects.has(p.compactness))
            _aws_cdk_aws_mediapackagev2_alpha_DashManifestCompactness(p.compactness);
        if (!visitedObjects.has(p.drmSignalling))
            _aws_cdk_aws_mediapackagev2_alpha_DrmSignalling(p.drmSignalling);
        if (!visitedObjects.has(p.dvbSettings))
            _aws_cdk_aws_mediapackagev2_alpha_DashDvbSettings(p.dvbSettings);
        if (!visitedObjects.has(p.filterConfiguration))
            _aws_cdk_aws_mediapackagev2_alpha_FilterConfiguration(p.filterConfiguration);
        if (p.periodTriggers != null)
            for (const o of p.periodTriggers)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_DashPeriodTriggers(o);
        if (!visitedObjects.has(p.programInformation))
            _aws_cdk_aws_mediapackagev2_alpha_DashProgramInformation(p.programInformation);
        if (!visitedObjects.has(p.scteDashAdMarker))
            _aws_cdk_aws_mediapackagev2_alpha_AdMarkerDash(p.scteDashAdMarker);
        if (!visitedObjects.has(p.segmentTemplateFormat))
            _aws_cdk_aws_mediapackagev2_alpha_SegmentTemplateFormat(p.segmentTemplateFormat);
        if (!visitedObjects.has(p.subtitleConfiguration))
            _aws_cdk_aws_mediapackagev2_alpha_DashSubtitleConfiguration(p.subtitleConfiguration);
        if (!visitedObjects.has(p.utcTimingMode))
            _aws_cdk_aws_mediapackagev2_alpha_DashUtcTimingMode(p.utcTimingMode);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_HlsManifestConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.filterConfiguration))
            _aws_cdk_aws_mediapackagev2_alpha_FilterConfiguration(p.filterConfiguration);
        if (!visitedObjects.has(p.scteAdMarkerHls))
            _aws_cdk_aws_mediapackagev2_alpha_AdMarkerHls(p.scteAdMarkerHls);
        if (!visitedObjects.has(p.startTag))
            _aws_cdk_aws_mediapackagev2_alpha_StartTag(p.startTag);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_LowLatencyHlsManifestConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.filterConfiguration))
            _aws_cdk_aws_mediapackagev2_alpha_FilterConfiguration(p.filterConfiguration);
        if (!visitedObjects.has(p.scteAdMarkerHls))
            _aws_cdk_aws_mediapackagev2_alpha_AdMarkerHls(p.scteAdMarkerHls);
        if (!visitedObjects.has(p.startTag))
            _aws_cdk_aws_mediapackagev2_alpha_StartTag(p.startTag);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.manifests != null)
            for (const o of p.manifests)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_Manifest(o);
        if (!visitedObjects.has(p.segment))
            _aws_cdk_aws_mediapackagev2_alpha_SegmentConfiguration(p.segment);
        if (!visitedObjects.has(p.cdnAuth))
            _aws_cdk_aws_mediapackagev2_alpha_CdnAuthConfiguration(p.cdnAuth);
        if (p.forceEndpointConfigurationConditions != null)
            for (const o of p.forceEndpointConfigurationConditions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_EndpointErrorConfiguration(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.channel))
            _aws_cdk_aws_mediapackagev2_alpha_IChannel(p.channel);
        if (p.manifests != null)
            for (const o of p.manifests)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_Manifest(o);
        if (!visitedObjects.has(p.segment))
            _aws_cdk_aws_mediapackagev2_alpha_SegmentConfiguration(p.segment);
        if (!visitedObjects.has(p.cdnAuth))
            _aws_cdk_aws_mediapackagev2_alpha_CdnAuthConfiguration(p.cdnAuth);
        if (p.forceEndpointConfigurationConditions != null)
            for (const o of p.forceEndpointConfigurationConditions)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_EndpointErrorConfiguration(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointAttributes(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_CmafDrmSystem(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_TsDrmSystem(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_IsmDrmSystem(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_CmafSpekeEncryptionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.drmSystems != null)
            for (const o of p.drmSystems)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_CmafDrmSystem(o);
        if (!visitedObjects.has(p.method))
            _aws_cdk_aws_mediapackagev2_alpha_CmafEncryptionMethod(p.method);
        if (!visitedObjects.has(p.audioPreset))
            _aws_cdk_aws_mediapackagev2_alpha_PresetSpeke20Audio(p.audioPreset);
        if (!visitedObjects.has(p.videoPreset))
            _aws_cdk_aws_mediapackagev2_alpha_PresetSpeke20Video(p.videoPreset);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_TsSpekeEncryptionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.method))
            _aws_cdk_aws_mediapackagev2_alpha_TsEncryptionMethod(p.method);
        if (!visitedObjects.has(p.audioPreset))
            _aws_cdk_aws_mediapackagev2_alpha_PresetSpeke20Audio(p.audioPreset);
        if (p.drmSystems != null)
            for (const o of p.drmSystems)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_TsDrmSystem(o);
        if (!visitedObjects.has(p.videoPreset))
            _aws_cdk_aws_mediapackagev2_alpha_PresetSpeke20Video(p.videoPreset);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_IsmSpekeEncryptionProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.drmSystems != null)
            for (const o of p.drmSystems)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_IsmDrmSystem(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_EncryptionConfiguration(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_CmafEncryption(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_TsEncryption(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_IsmEncryption(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_SegmentConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.containerType))
            _aws_cdk_aws_mediapackagev2_alpha_ContainerType(p.containerType);
        if (!visitedObjects.has(p.encryption))
            _aws_cdk_aws_mediapackagev2_alpha_EncryptionConfiguration(p.encryption);
        if (p.scteFilter != null)
            for (const o of p.scteFilter)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_ScteMessageType(o);
        if (!visitedObjects.has(p.scteInSegments))
            _aws_cdk_aws_mediapackagev2_alpha_ScteInSegments(p.scteInSegments);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_SegmentPropsBase(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_TsSegmentProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.encryption))
            _aws_cdk_aws_mediapackagev2_alpha_TsEncryption(p.encryption);
        if (p.scteFilter != null)
            for (const o of p.scteFilter)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_ScteMessageType(o);
        if (!visitedObjects.has(p.scteInSegments))
            _aws_cdk_aws_mediapackagev2_alpha_ScteInSegments(p.scteInSegments);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_CmafSegmentProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.encryption))
            _aws_cdk_aws_mediapackagev2_alpha_CmafEncryption(p.encryption);
        if (p.scteFilter != null)
            for (const o of p.scteFilter)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_mediapackagev2_alpha_ScteMessageType(o);
        if (!visitedObjects.has(p.scteInSegments))
            _aws_cdk_aws_mediapackagev2_alpha_ScteInSegments(p.scteInSegments);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_IsmSegmentProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.encryption))
            _aws_cdk_aws_mediapackagev2_alpha_IsmEncryption(p.encryption);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_Segment(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_OriginEndpoint(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_IChannelGroup(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_ChannelGroupProps(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_ChannelGroupAttributes(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_ChannelGroup(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_ChannelPolicyProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.channel))
            _aws_cdk_aws_mediapackagev2_alpha_IChannel(p.channel);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_ChannelPolicy(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_CdnAuthConfiguration(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.secrets != null)
            for (const o of p.secrets)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_secretsmanager_ISecret(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointPolicyProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.originEndpoint))
            _aws_cdk_aws_mediapackagev2_alpha_IOriginEndpoint(p.originEndpoint);
        if (!visitedObjects.has(p.cdnAuth))
            _aws_cdk_aws_mediapackagev2_alpha_CdnAuthConfiguration(p.cdnAuth);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointPolicy(p) {
}
function _aws_cdk_aws_mediapackagev2_alpha_ChannelGrants(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_mediapackagev2_alpha_InputType, _aws_cdk_aws_mediapackagev2_alpha_IChannel, _aws_cdk_aws_mediapackagev2_alpha_IngestEndpoint, _aws_cdk_aws_mediapackagev2_alpha_InputSwitchConfiguration, _aws_cdk_aws_mediapackagev2_alpha_HeadersCMSD, _aws_cdk_aws_mediapackagev2_alpha_CmafInputProps, _aws_cdk_aws_mediapackagev2_alpha_InputConfiguration, _aws_cdk_aws_mediapackagev2_alpha_ChannelOptions, _aws_cdk_aws_mediapackagev2_alpha_ChannelProps, _aws_cdk_aws_mediapackagev2_alpha_ChannelAttributes, _aws_cdk_aws_mediapackagev2_alpha_Channel, _aws_cdk_aws_mediapackagev2_alpha_AudioCodec, _aws_cdk_aws_mediapackagev2_alpha_VideoCodec, _aws_cdk_aws_mediapackagev2_alpha_VideoDynamicRange, _aws_cdk_aws_mediapackagev2_alpha_TrickplayType, _aws_cdk_aws_mediapackagev2_alpha_NumericFilterKey, _aws_cdk_aws_mediapackagev2_alpha_TextFilterKey, _aws_cdk_aws_mediapackagev2_alpha_BitrateFilterKey, _aws_cdk_aws_mediapackagev2_alpha_NumericExpression, _aws_cdk_aws_mediapackagev2_alpha_BitrateExpression, _aws_cdk_aws_mediapackagev2_alpha_ManifestFilter, _aws_cdk_aws_mediapackagev2_alpha_Manifest, _aws_cdk_aws_mediapackagev2_alpha_ContainerType, _aws_cdk_aws_mediapackagev2_alpha_CmafEncryptionMethod, _aws_cdk_aws_mediapackagev2_alpha_TsEncryptionMethod, _aws_cdk_aws_mediapackagev2_alpha_PresetSpeke20Audio, _aws_cdk_aws_mediapackagev2_alpha_PresetSpeke20Video, _aws_cdk_aws_mediapackagev2_alpha_EndpointErrorConfiguration, _aws_cdk_aws_mediapackagev2_alpha_ScteMessageType, _aws_cdk_aws_mediapackagev2_alpha_ScteInSegments, _aws_cdk_aws_mediapackagev2_alpha_IOriginEndpoint, _aws_cdk_aws_mediapackagev2_alpha_DrmSettingsKey, _aws_cdk_aws_mediapackagev2_alpha_FilterConfiguration, _aws_cdk_aws_mediapackagev2_alpha_StartTagOptions, _aws_cdk_aws_mediapackagev2_alpha_StartTag, _aws_cdk_aws_mediapackagev2_alpha_AdMarkerDash, _aws_cdk_aws_mediapackagev2_alpha_AdMarkerHls, _aws_cdk_aws_mediapackagev2_alpha_SegmentTemplateFormat, _aws_cdk_aws_mediapackagev2_alpha_DashUtcTimingMode, _aws_cdk_aws_mediapackagev2_alpha_DashPeriodTriggers, _aws_cdk_aws_mediapackagev2_alpha_DrmSignalling, _aws_cdk_aws_mediapackagev2_alpha_DashManifestCompactness, _aws_cdk_aws_mediapackagev2_alpha_DashBaseUrlProperty, _aws_cdk_aws_mediapackagev2_alpha_DashDvbMetricsReporting, _aws_cdk_aws_mediapackagev2_alpha_DashDvbFontDownload, _aws_cdk_aws_mediapackagev2_alpha_DashDvbSettings, _aws_cdk_aws_mediapackagev2_alpha_DashProgramInformation, _aws_cdk_aws_mediapackagev2_alpha_TtmlProfile, _aws_cdk_aws_mediapackagev2_alpha_DashTtmlConfiguration, _aws_cdk_aws_mediapackagev2_alpha_DashSubtitleConfiguration, _aws_cdk_aws_mediapackagev2_alpha_MssManifestLayout, _aws_cdk_aws_mediapackagev2_alpha_MssManifestConfiguration, _aws_cdk_aws_mediapackagev2_alpha_DashManifestConfiguration, _aws_cdk_aws_mediapackagev2_alpha_HlsManifestConfiguration, _aws_cdk_aws_mediapackagev2_alpha_LowLatencyHlsManifestConfiguration, _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointOptions, _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointProps, _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointAttributes, _aws_cdk_aws_mediapackagev2_alpha_CmafDrmSystem, _aws_cdk_aws_mediapackagev2_alpha_TsDrmSystem, _aws_cdk_aws_mediapackagev2_alpha_IsmDrmSystem, _aws_cdk_aws_mediapackagev2_alpha_CmafSpekeEncryptionProps, _aws_cdk_aws_mediapackagev2_alpha_TsSpekeEncryptionProps, _aws_cdk_aws_mediapackagev2_alpha_IsmSpekeEncryptionProps, _aws_cdk_aws_mediapackagev2_alpha_EncryptionConfiguration, _aws_cdk_aws_mediapackagev2_alpha_CmafEncryption, _aws_cdk_aws_mediapackagev2_alpha_TsEncryption, _aws_cdk_aws_mediapackagev2_alpha_IsmEncryption, _aws_cdk_aws_mediapackagev2_alpha_SegmentConfiguration, _aws_cdk_aws_mediapackagev2_alpha_SegmentPropsBase, _aws_cdk_aws_mediapackagev2_alpha_TsSegmentProps, _aws_cdk_aws_mediapackagev2_alpha_CmafSegmentProps, _aws_cdk_aws_mediapackagev2_alpha_IsmSegmentProps, _aws_cdk_aws_mediapackagev2_alpha_Segment, _aws_cdk_aws_mediapackagev2_alpha_OriginEndpoint, _aws_cdk_aws_mediapackagev2_alpha_IChannelGroup, _aws_cdk_aws_mediapackagev2_alpha_ChannelGroupProps, _aws_cdk_aws_mediapackagev2_alpha_ChannelGroupAttributes, _aws_cdk_aws_mediapackagev2_alpha_ChannelGroup, _aws_cdk_aws_mediapackagev2_alpha_ChannelPolicyProps, _aws_cdk_aws_mediapackagev2_alpha_ChannelPolicy, _aws_cdk_aws_mediapackagev2_alpha_CdnAuthConfiguration, _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointPolicyProps, _aws_cdk_aws_mediapackagev2_alpha_OriginEndpointPolicy, _aws_cdk_aws_mediapackagev2_alpha_ChannelGrants };
