import type { IResource } from 'aws-cdk-lib';
import { RemovalPolicy, Resource } from 'aws-cdk-lib';
import type { MetricOptions } from 'aws-cdk-lib/aws-cloudwatch';
import { Metric } from 'aws-cdk-lib/aws-cloudwatch';
import type { PolicyStatement, AddToResourcePolicyResult } from 'aws-cdk-lib/aws-iam';
import type { IChannelRef, ChannelReference } from 'aws-cdk-lib/aws-mediapackagev2';
import type { Construct } from 'constructs';
import type { OriginEndpointOptions } from '.';
import { ChannelPolicy, OriginEndpoint } from '.';
import type { IChannelGroup } from './group';
import { ChannelGrants } from './mediapackagev2-grants.generated';
/**
 * The input type will be an immutable field which will be used to define whether the channel will allow CMAF ingest or HLS ingest.
 */
export declare enum InputType {
    /**
     * The DASH-IF CMAF Ingest specification (which defines CMAF segments with
     * optional DASH manifests).
     */
    CMAF = "CMAF",
    /**
     * The HLS streaming specification (which defines M3U8 manifests and TS segments).
     */
    HLS = "HLS"
}
/**
 * Represents a MediaPackage V2 Channel
 */
export interface IChannel extends IResource, IChannelRef {
    /**
     * The name that describes the channel group. The name is the primary identifier for the channel group.
     *
     * @attribute
     */
    readonly channelGroupName: string;
    /**
     * The name that describes the channel. The name is the primary identifier for the channel.
     *
     * @attribute
     */
    readonly channelName: string;
    /**
     * The Amazon Resource Name (ARN) associated with the resource.
     *
     * @attribute
     */
    readonly channelArn: string;
    /**
     * The date and time the channel was created.
     *
     * @attribute
     */
    readonly createdAt?: string;
    /**
     * The date and time the channel was modified.
     *
     * @attribute
     */
    readonly modifiedAt?: string;
    /**
     * The ingest endpoint URLs for the channel.
     *
     * @attribute
     */
    readonly ingestEndpointUrls: string[];
    /**
     * The channel group this channel belongs to.
     * Only available when the channel was created in the same stack.
     * Undefined for imported channels.
     *
     * @attribute
     */
    readonly channelGroup?: IChannelGroup;
    /**
     * Grants IAM resource policy to the role used to write to MediaPackage V2 Channel.
     */
    readonly grants: ChannelGrants;
    /**
     * Add Origin Endpoint for this Channel.
     */
    addOriginEndpoint(id: string, options: OriginEndpointOptions): OriginEndpoint;
    /**
     * Configure channel policy.
     *
     * You can only add 1 ChannelPolicy to a Channel.
     * If you have already defined one, function will append the policy already created.
     */
    addToResourcePolicy(statement: PolicyStatement): AddToResourcePolicyResult;
    /**
     * Create a CloudWatch metric.
     *
     * @param metricName name of the metric
     * @param props metric options.
     */
    metric(metricName: string, props?: MetricOptions): Metric;
    /**
     * Returns Metric for Ingress Bytes
     *
     * @default - sum over 60 seconds
     */
    metricIngressBytes(options?: MetricOptions): Metric;
    /**
     * Returns Metric for Egress Bytes
     *
     * @default - sum over 60 seconds
     */
    metricEgressBytes(options?: MetricOptions): Metric;
    /**
     * Returns Metric for Ingress response time
     *
     * @default - average over 60 seconds
     */
    metricIngressResponseTime(options?: MetricOptions): Metric;
    /**
     * Returns Metric for Egress Response time
     *
     * @default - average over 60 seconds
     */
    metricEgressResponseTime(options?: MetricOptions): Metric;
    /**
     * Returns Metric for Ingress Request Count
     *
     * @default - sum over 60 seconds
     */
    metricIngressRequestCount(options?: MetricOptions): Metric;
    /**
     * Returns Metric for Egress Request Count
     *
     * @default - sum over 60 seconds
     */
    metricEgressRequestCount(options?: MetricOptions): Metric;
}
/**
 * Ingest Endpoint options
 */
export declare enum IngestEndpoint {
    /**
     * First ingest endpoint
     */
    ENDPOINT_1 = 1,
    /**
     * Second ingest endpoint
     */
    ENDPOINT_2 = 2
}
/**
 * Input Switch Configuration
 */
export interface InputSwitchConfiguration {
    /**
     * When true, AWS Elemental MediaPackage performs input switching based on the MQCS.
     *
     * This setting is valid only when InputType is CMAF.
     *
     * @default false
     */
    readonly mqcsInputSwitching?: boolean;
    /**
     * For CMAF inputs, indicates which input MediaPackage should prefer when both inputs have equal MQCS scores.
     * Select 1 to prefer the first ingest endpoint, or 2 to prefer the second ingest endpoint.
     * If you don't specify a preferred input, MediaPackage uses its default switching behavior when MQCS scores are equal.
     *
     * @default - MediaPackage uses its default switching behavior
     */
    readonly preferredInput?: IngestEndpoint;
}
/**
 * The settings for what common media server data (CMSD) headers AWS Elemental MediaPackage includes in responses to the CDN.
 */
export declare class HeadersCMSD {
    /**
     * The string value of the CMSD header
     */
    readonly value: string;
    /**
     * Media Quality Confidence Score
     */
    static readonly MQCS: HeadersCMSD;
    /**
     * Escape hatch for new CMSD headers not yet supported by the construct.
     */
    static of(value: string): HeadersCMSD;
    private constructor();
}
/**
 * Properties for CMAF input configuration
 */
export interface CmafInputProps {
    /**
     * The configuration for input switching based on the media quality confidence score (MQCS) as provided from AWS Elemental MediaLive.
     *
     * @default No customized input switch configuration added
     */
    readonly inputSwitchConfiguration?: InputSwitchConfiguration;
    /**
     * The settings for what common media server data (CMSD) headers AWS Elemental MediaPackage includes in responses to the CDN.
     *
     * @default none
     */
    readonly outputHeaders?: HeadersCMSD[];
}
/**
 * Input configuration for a MediaPackage V2 Channel
 *
 * Use the static factory methods to create instances:
 * - InputConfiguration.hls() for HLS input
 * - InputConfiguration.cmaf() for CMAF input with optional CMAF-specific features
 */
export declare class InputConfiguration {
    /**
     * The input type (HLS or CMAF)
     */
    readonly inputType: InputType;
    /**
     * Input switch configuration (CMAF only)
     */
    readonly inputSwitchConfiguration?: InputSwitchConfiguration | undefined;
    /**
     * Output headers configuration (CMAF only)
     */
    readonly outputHeaders?: HeadersCMSD[] | undefined;
    /**
     * Create an HLS input configuration
     */
    static hls(): InputConfiguration;
    /**
     * Create a CMAF input configuration
     *
     * @param props CMAF-specific configuration including input switching and output headers
     */
    static cmaf(props?: CmafInputProps): InputConfiguration;
    private constructor();
}
/**
 * Configuration options for an AWS Elemental MediaPackage V2 Channel.
 *
 * Used when creating a channel via `ChannelGroup.addChannel()`.
 */
export interface ChannelOptions {
    /**
     * The name that describes the channel. The name is the primary identifier for the channel, and must be unique for your account in the AWS Region and channel group.
     *
     * @default autogenerated
     */
    readonly channelName?: string;
    /**
     * Input configuration for the channel.
     * Use InputConfiguration.hls() or InputConfiguration.cmaf() to create the configuration.
     *
     * @default InputConfiguration.cmaf()
     */
    readonly input?: InputConfiguration;
    /**
     * Enter any descriptive text that helps you to identify the channel.
     *
     * @default no description
     */
    readonly description?: string;
    /**
     * Tags to add to the Channel
     *
     * @default No tagging
     */
    readonly tags?: {
        [key: string]: string;
    };
    /**
     * Policy to apply when the channel is removed from the stack
     *
     * Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful,
     * their contents are transient and it is common to add and remove these while rearchitecting your application.
     * The default is therefore `DESTROY`. Change it to `RETAIN` if the content (in a lookback window) are so
     * valuable that accidentally losing it would be unacceptable.
     *
     * @default RemovalPolicy.DESTROY
     */
    readonly removalPolicy?: RemovalPolicy;
}
/**
 * Properties to set on a Channel.
 */
export interface ChannelProps extends ChannelOptions {
    /**
     * Channel Group to add this Channel to.
     */
    readonly channelGroup: IChannelGroup;
}
/**
 * Represents a Channel defined outside of this stack.
 */
export interface ChannelAttributes {
    /**
     * The name that describes the channel.
     *
     * @attribute
     */
    readonly channelName: string;
    /**
     * The name that describes the channel group.
     *
     * @attribute
     */
    readonly channelGroupName: string;
}
/**
 * A new or imported Channel.
 */
declare abstract class ChannelBase extends Resource implements IChannel {
    /**
     * Creates a Channel construct that represents an external (imported) Channel.
     */
    static fromChannelAttributes(scope: Construct, id: string, attrs: ChannelAttributes): IChannel;
    abstract readonly channelGroupName: string;
    abstract readonly channelName: string;
    abstract readonly channelArn: string;
    abstract readonly createdAt?: string;
    abstract readonly modifiedAt?: string;
    abstract readonly ingestEndpointUrls: string[];
    /**
     * A reference to this Channel resource
     */
    get channelRef(): ChannelReference;
    /**
     * The resource policy associated with this channel.
     *
     * If `autoCreatePolicy` is true, a `ChannelPolicy` will be created upon the
     * first call to addToResourcePolicy(s).
     */
    abstract policy?: ChannelPolicy;
    /**
     * Indicates if a channel resource policy should automatically created upon
     * the first call to `addToResourcePolicy`.
     */
    protected abstract autoCreatePolicy: boolean;
    /**
     * Collection of grant methods for this channel
     */
    readonly grants: ChannelGrants;
    /**
     * Add Origin Endpoint for this Channel.
     */
    addOriginEndpoint(id: string, options: OriginEndpointOptions): OriginEndpoint;
    /**
     * Configure channel policy.
     *
     * You can only add 1 ChannelPolicy to a Channel.
     * If you have already defined one, function will append the policy already created.
     */
    addToResourcePolicy(statement: PolicyStatement): AddToResourcePolicyResult;
    /**
     * Create a CloudWatch metric.
     *
     * @param metricName name of the metric
     * @param options metric options.
     */
    metric(metricName: string, options?: MetricOptions): Metric;
    /**
     * Returns Metric for Ingress Bytes
     *
     * @default - sum over 60 seconds
     */
    metricIngressBytes(options?: MetricOptions): Metric;
    /**
     * Returns Metric for Egress Bytes
     *
     * @default - sum over 60 seconds
     */
    metricEgressBytes(options?: MetricOptions): Metric;
    /**
     * Returns Metric for Ingress response time
     *
     * @default - average over 60 seconds
     */
    metricIngressResponseTime(options?: MetricOptions): Metric;
    /**
     * Returns Metric for Egress Response time
     *
     * @default - average over 60 seconds
     */
    metricEgressResponseTime(options?: MetricOptions): Metric;
    /**
     * Returns Metric for Ingress Request Count
     *
     * @default - sum over 60 seconds
     */
    metricIngressRequestCount(options?: MetricOptions): Metric;
    /**
     * Returns Metric for Egress Request Count
     *
     * @default - sum over 60 seconds
     */
    metricEgressRequestCount(options?: MetricOptions): Metric;
}
/**
 * Defines an AWS Elemental MediaPackage V2 Channel
 */
export declare class Channel extends ChannelBase implements IChannel {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    readonly channelGroupName: string;
    readonly channelName: string;
    readonly channelArn: string;
    readonly channelGroup?: IChannelGroup;
    /**
     * The date and time the channel was created.
     */
    readonly createdAt?: string;
    /**
     * The date and time the channel was modified.
     */
    readonly modifiedAt?: string;
    /**
     * The list of ingest endpoints.
     */
    readonly ingestEndpointUrls: string[];
    policy?: ChannelPolicy;
    protected autoCreatePolicy: boolean;
    constructor(scope: Construct, id: string, props: ChannelProps);
}
export {};
