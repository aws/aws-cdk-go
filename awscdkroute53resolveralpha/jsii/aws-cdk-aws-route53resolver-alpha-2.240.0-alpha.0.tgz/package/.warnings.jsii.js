function _aws_cdk_aws_route53resolver_alpha_IFirewallDomainList(p) {
}
function _aws_cdk_aws_route53resolver_alpha_FirewallDomainListProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.domains))
            _aws_cdk_aws_route53resolver_alpha_FirewallDomains(p.domains);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_route53resolver_alpha_FirewallDomains(p) {
}
function _aws_cdk_aws_route53resolver_alpha_DomainsConfig(p) {
}
function _aws_cdk_aws_route53resolver_alpha_FirewallDomainList(p) {
}
function _aws_cdk_aws_route53resolver_alpha_IFirewallRuleGroup(p) {
}
function _aws_cdk_aws_route53resolver_alpha_FirewallRuleGroupProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.rules != null)
            for (const o of p.rules)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_route53resolver_alpha_FirewallRule(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_route53resolver_alpha_FirewallRule(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.action))
            _aws_cdk_aws_route53resolver_alpha_FirewallRuleAction(p.action);
        if (!visitedObjects.has(p.firewallDomainList))
            _aws_cdk_aws_route53resolver_alpha_IFirewallDomainList(p.firewallDomainList);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_route53resolver_alpha_FirewallRuleAction(p) {
}
function _aws_cdk_aws_route53resolver_alpha_DnsBlockResponse(p) {
}
function _aws_cdk_aws_route53resolver_alpha_FirewallRuleGroup(p) {
}
function _aws_cdk_aws_route53resolver_alpha_FirewallRuleGroupAssociationOptions(p) {
}
function _aws_cdk_aws_route53resolver_alpha_FirewallRuleGroupAssociationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.firewallRuleGroup))
            _aws_cdk_aws_route53resolver_alpha_IFirewallRuleGroup(p.firewallRuleGroup);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_route53resolver_alpha_FirewallRuleGroupAssociation(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_route53resolver_alpha_IFirewallDomainList, _aws_cdk_aws_route53resolver_alpha_FirewallDomainListProps, _aws_cdk_aws_route53resolver_alpha_FirewallDomains, _aws_cdk_aws_route53resolver_alpha_DomainsConfig, _aws_cdk_aws_route53resolver_alpha_FirewallDomainList, _aws_cdk_aws_route53resolver_alpha_IFirewallRuleGroup, _aws_cdk_aws_route53resolver_alpha_FirewallRuleGroupProps, _aws_cdk_aws_route53resolver_alpha_FirewallRule, _aws_cdk_aws_route53resolver_alpha_FirewallRuleAction, _aws_cdk_aws_route53resolver_alpha_DnsBlockResponse, _aws_cdk_aws_route53resolver_alpha_FirewallRuleGroup, _aws_cdk_aws_route53resolver_alpha_FirewallRuleGroupAssociationOptions, _aws_cdk_aws_route53resolver_alpha_FirewallRuleGroupAssociationProps, _aws_cdk_aws_route53resolver_alpha_FirewallRuleGroupAssociation };
