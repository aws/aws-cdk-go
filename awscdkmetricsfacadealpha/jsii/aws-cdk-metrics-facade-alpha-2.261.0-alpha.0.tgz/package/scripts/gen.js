"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const node_fs_1 = require("node:fs");
const fs = __importStar(require("node:fs/promises"));
const path = __importStar(require("node:path"));
const spec2cdk_1 = require("@aws-cdk/spec2cdk");
const submodule_files_1 = require("@aws-cdk/spec2cdk/lib/util/submodule-files");
const config_1 = require("./config");
const GO_PREFIX = 'metricsfacadealpha';
main().catch(e => {
    console.error(e);
    process.exitCode = 1;
});
async function main() {
    const pkgPath = path.join(__dirname, '..');
    const outputPath = path.join(pkgPath, 'lib', 'services');
    const result = await spec2cdk_1.spec2metrics.generateAll({
        outputPath,
        packageBases: config_1.METRICS_FACADE_BASE_NAMES,
        moduleNamePrefix: '@aws-cdk/metrics-facade-alpha',
    });
    await setupSubmodules(result.moduleMap, result.contributions, outputPath);
    await updateExportsAndEntryPoints(result.moduleMap, pkgPath);
}
async function setupSubmodules(modules, contributions, outPath) {
    for (const submodule of Object.values(modules)) {
        await ensureSubmodule(submodule, contributions, outPath);
    }
}
async function ensureSubmodule(submodule, contributions, outPath) {
    const modulePath = path.join(outPath, submodule.name);
    if (!submodule.definition) {
        throw new Error(`Cannot infer path or namespace for submodule named "${submodule.name}". Manually create ${modulePath}/.jsiirc.json files.`);
    }
    const barrels = new Map();
    for (const c of contributions) {
        const hasFile = c.exportLines.some(line => {
            const match = line.match(/from\s+'\.\/(.+)'/);
            return match && submodule.files.some(f => f.includes(match[1]));
        });
        if (!hasFile)
            continue;
        const existing = barrels.get(c.barrelFile);
        if (existing) {
            existing.lines.push(...c.exportLines);
        }
        else {
            barrels.set(c.barrelFile, { lines: [...c.exportLines], jsiircNamespace: c.jsiircNamespace });
        }
    }
    const subModuleIndex = path.join(modulePath, 'index.ts');
    const indexLines = [];
    // Barrels targeting index.ts contribute their lines directly;
    // other barrels get a namespace re-export in index.ts.
    const indexBarrel = barrels.get('index.ts');
    if (indexBarrel) {
        indexLines.push(...indexBarrel.lines);
        barrels.delete('index.ts');
    }
    for (const barrel of barrels.keys()) {
        const ns = path.basename(barrel, '.ts');
        indexLines.push(`export * as ${ns} from './${ns}';`);
    }
    await (0, submodule_files_1.ensureFileContains)(subModuleIndex, indexLines);
    await (0, submodule_files_1.writeJsiiRc)((0, submodule_files_1.jsiiRcPathFor)(subModuleIndex), submodule.definition, { goPrefix: GO_PREFIX });
    for (const [barrelFile, { lines, jsiircNamespace }] of barrels) {
        const barrelPath = path.join(modulePath, barrelFile);
        await (0, submodule_files_1.ensureFileContains)(barrelPath, lines);
        await (0, submodule_files_1.writeJsiiRc)((0, submodule_files_1.jsiiRcPathFor)(barrelPath), submodule.definition, { goPrefix: GO_PREFIX, namespaceSuffix: jsiircNamespace });
    }
}
async function updateExportsAndEntryPoints(modules, pkgPath) {
    const servicesIndexFilePath = path.join(pkgPath, 'lib', 'services', 'index.ts');
    const serviceIndexExports = new Array();
    const pkgJsonPath = path.join(pkgPath, 'package.json');
    const pkgJson = JSON.parse((await fs.readFile(pkgJsonPath)).toString());
    const newExports = {};
    for (const [key, value] of Object.entries(pkgJson.exports)) {
        if (!key.startsWith('./aws-') && !key.startsWith('./alexa-')) {
            newExports[key] = value;
        }
    }
    for (const moduleName of Object.keys(modules)) {
        const moduleConfig = {
            name: moduleName,
            submodule: moduleName.replace(/-/g, '_'),
        };
        newExports[`./${moduleConfig.name}`] = `./lib/services/${moduleConfig.name}/index.js`;
        if (!serviceIndexExports.find(e => e.includes(moduleConfig.name))) {
            serviceIndexExports.push(`export * as ${moduleConfig.submodule} from './${moduleConfig.name}';`);
        }
        const metricsFilePath = path.join(pkgPath, 'lib', 'services', moduleConfig.name, 'metrics.ts');
        if ((0, node_fs_1.existsSync)(metricsFilePath)) {
            newExports[`./${moduleConfig.name}/metrics`] = `./lib/services/${moduleConfig.name}/metrics.js`;
        }
    }
    pkgJson.exports = Object.fromEntries(Object.entries(newExports).sort(([e1], [e2]) => e1.localeCompare(e2)));
    await fs.writeFile(pkgJsonPath, JSON.stringify(pkgJson, null, 2) + '\n');
    await fs.writeFile(servicesIndexFilePath, serviceIndexExports.sort((l1, l2) => l1.localeCompare(l2)).join('\n') + '\n');
}
