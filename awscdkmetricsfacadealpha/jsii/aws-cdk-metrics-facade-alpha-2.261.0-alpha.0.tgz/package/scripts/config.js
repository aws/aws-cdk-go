"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.METRICS_FACADE_BASE_NAMES = void 0;
exports.METRICS_FACADE_BASE_NAMES = {
    javascript: '@aws-cdk/metrics-facade-alpha',
    dotnet: 'Amazon.CDK.MetricsFacade.Alpha',
    java: 'software.amazon.awscdk.metricsfacade.alpha',
    python: 'aws-cdk.metrics-facade-alpha',
};
