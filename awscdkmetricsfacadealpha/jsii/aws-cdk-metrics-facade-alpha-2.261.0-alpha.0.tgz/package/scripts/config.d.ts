export declare const METRICS_FACADE_BASE_NAMES: {
    javascript: string;
    dotnet: string;
    java: string;
    python: string;
};
