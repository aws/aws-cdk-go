import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/SQS
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class SQSMetrics {
}
export declare namespace SQSMetrics {
    /**
     * Metrics for dimension set: Queue {QueueName}
     *
     * @stability external
     */
    class QueueMetrics {
        private readonly dimensions;
        constructor(props: SQSMetrics.QueueMetricsProps);
        /**
         * Average of the NumberOfMessagesSent metric
         *
         * @default - Average over 5 minutes
         */
        numberOfMessagesSent(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ApproximateNumberOfMessagesDelayed metric
         *
         * @default - Average over 5 minutes
         */
        approximateNumberOfMessagesDelayed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NumberOfMessagesReceived metric
         *
         * @default - Average over 5 minutes
         */
        numberOfMessagesReceived(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NumberOfMessagesDeleted metric
         *
         * @default - Average over 5 minutes
         */
        numberOfMessagesDeleted(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ApproximateNumberOfMessagesNotVisible metric
         *
         * @default - Average over 5 minutes
         */
        approximateNumberOfMessagesNotVisible(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ApproximateNumberOfMessagesVisible metric
         *
         * @default - Average over 5 minutes
         */
        approximateNumberOfMessagesVisible(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ApproximateAgeOfOldestMessage metric
         *
         * @default - Average over 5 minutes
         */
        approximateAgeOfOldestMessage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NumberOfEmptyReceives metric
         *
         * @default - Average over 5 minutes
         */
        numberOfEmptyReceives(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SentMessageSize metric
         *
         * @default - Average over 5 minutes
         */
        sentMessageSize(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for QueueMetrics
     *
     * @struct
     * @stability external
     */
    interface QueueMetricsProps {
        /**
         * The QueueName dimension
         */
        readonly queueName: string;
    }
}
