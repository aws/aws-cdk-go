import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/ElasticMapReduce
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class ElasticMapReduceMetrics {
}
export declare namespace ElasticMapReduceMetrics {
    /**
     * Metrics for dimension set: JobFlow {JobFlowId}
     *
     * @stability external
     */
    class JobFlowMetrics {
        private readonly dimensions;
        constructor(props: ElasticMapReduceMetrics.JobFlowMetricsProps);
        /**
         * Sum of the AppsCompleted metric
         *
         * @default - Sum over 5 minutes
         */
        appsCompleted(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the AppsFailed metric
         *
         * @default - Sum over 5 minutes
         */
        appsFailed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the AppsKilled metric
         *
         * @default - Sum over 5 minutes
         */
        appsKilled(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the AppsPending metric
         *
         * @default - Sum over 5 minutes
         */
        appsPending(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the AppsRunning metric
         *
         * @default - Sum over 5 minutes
         */
        appsRunning(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the AppsSubmitted metric
         *
         * @default - Sum over 5 minutes
         */
        appsSubmitted(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BackupFailed metric
         *
         * @default - Average over 5 minutes
         */
        backupFailed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CapacityRemainingGB metric
         *
         * @default - Sum over 5 minutes
         */
        capacityRemainingGb(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ContainerAllocated metric
         *
         * @default - Sum over 5 minutes
         */
        containerAllocated(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ContainerPending metric
         *
         * @default - Sum over 5 minutes
         */
        containerPending(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ContainerPendingRatio metric
         *
         * @default - Sum over 5 minutes
         */
        containerPendingRatio(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ContainerReserved metric
         *
         * @default - Sum over 5 minutes
         */
        containerReserved(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CoreNodesPending metric
         *
         * @default - Average over 5 minutes
         */
        coreNodesPending(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CoreNodesRunning metric
         *
         * @default - Average over 5 minutes
         */
        coreNodesRunning(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CorruptBlocks metric
         *
         * @default - Sum over 5 minutes
         */
        corruptBlocks(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HbaseBackupFailed metric
         *
         * @default - Sum over 5 minutes
         */
        hbaseBackupFailed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HDFSBytesRead metric
         *
         * @default - Sum over 5 minutes
         */
        hdfsBytesRead(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HDFSBytesWritten metric
         *
         * @default - Sum over 5 minutes
         */
        hdfsBytesWritten(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the HDFSUtilization metric
         *
         * @default - Average over 5 minutes
         */
        hdfsUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IsIdle metric
         *
         * @default - Average over 5 minutes
         */
        isIdle(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the JobsFailed metric
         *
         * @default - Average over 5 minutes
         */
        jobsFailed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the JobsRunning metric
         *
         * @default - Average over 5 minutes
         */
        jobsRunning(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the LiveDataNodes metric
         *
         * @default - Average over 5 minutes
         */
        liveDataNodes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the LiveTaskTrackers metric
         *
         * @default - Average over 5 minutes
         */
        liveTaskTrackers(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MapSlotsOpen metric
         *
         * @default - Average over 5 minutes
         */
        mapSlotsOpen(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MemoryAllocatedMB metric
         *
         * @default - Sum over 5 minutes
         */
        memoryAllocatedMb(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MemoryReservedMB metric
         *
         * @default - Sum over 5 minutes
         */
        memoryReservedMb(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MemoryTotalMB metric
         *
         * @default - Sum over 5 minutes
         */
        memoryTotalMb(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MissingBlocks metric
         *
         * @default - Average over 5 minutes
         */
        missingBlocks(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MostRecentBackupDuration metric
         *
         * @default - Average over 5 minutes
         */
        mostRecentBackupDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MRActiveNodes metric
         *
         * @default - Sum over 5 minutes
         */
        mrActiveNodes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MRDecommissionedNodes metric
         *
         * @default - Sum over 5 minutes
         */
        mrDecommissionedNodes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MRLostNodes metric
         *
         * @default - Sum over 5 minutes
         */
        mrLostNodes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MRRebootedNodes metric
         *
         * @default - Sum over 5 minutes
         */
        mrRebootedNodes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MRTotalNodes metric
         *
         * @default - Sum over 5 minutes
         */
        mrTotalNodes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MRUnhealthyNodes metric
         *
         * @default - Sum over 5 minutes
         */
        mrUnhealthyNodes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MultiMasterInstanceGroupNodesRequested metric
         *
         * @default - Sum over 5 minutes
         */
        multiMasterInstanceGroupNodesRequested(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MultiMasterInstanceGroupNodesRunning metric
         *
         * @default - Sum over 5 minutes
         */
        multiMasterInstanceGroupNodesRunning(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MultiMasterInstanceGroupNodesRunningPercentage metric
         *
         * @default - Average over 5 minutes
         */
        multiMasterInstanceGroupNodesRunningPercentage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PendingDeletionBlocks metric
         *
         * @default - Sum over 5 minutes
         */
        pendingDeletionBlocks(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReduceSlotsOpen metric
         *
         * @default - Average over 5 minutes
         */
        reduceSlotsOpen(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the RemainingMapTasksPerSlot metric
         *
         * @default - Average over 5 minutes
         */
        remainingMapTasksPerSlot(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the S3BytesRead metric
         *
         * @default - Sum over 5 minutes
         */
        s3BytesRead(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the S3BytesWritten metric
         *
         * @default - Sum over 5 minutes
         */
        s3BytesWritten(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TaskNodesPending metric
         *
         * @default - Average over 5 minutes
         */
        taskNodesPending(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TaskNodesRunning metric
         *
         * @default - Average over 5 minutes
         */
        taskNodesRunning(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TimeSinceLastSuccessfulBackup metric
         *
         * @default - Average over 5 minutes
         */
        timeSinceLastSuccessfulBackup(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TotalLoad metric
         *
         * @default - Average over 5 minutes
         */
        totalLoad(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the UnderReplicatedBlocks metric
         *
         * @default - Sum over 5 minutes
         */
        underReplicatedBlocks(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the YARNMemoryAvailablePercentage metric
         *
         * @default - Average over 5 minutes
         */
        yarnMemoryAvailablePercentage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for JobFlowMetrics
     *
     * @struct
     * @stability external
     */
    interface JobFlowMetricsProps {
        /**
         * The JobFlowId dimension
         */
        readonly jobFlowId: string;
    }
}
