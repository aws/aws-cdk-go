import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IFunctionRef } from "aws-cdk-lib/aws-lambda";
/**
 * CloudWatch metrics facade for AWS/Lambda
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class LambdaMetrics {
    /**
     * Create FunctionMetrics from a Function reference
     */
    static fromFunction(ref: IFunctionRef): LambdaMetrics.FunctionMetrics;
}
export declare namespace LambdaMetrics {
    /**
     * Metrics for dimension set: Function {FunctionName}
     *
     * @stability external
     */
    class FunctionMetrics {
        private readonly dimensions;
        constructor(props: LambdaMetrics.FunctionMetricsProps);
        /**
         * Maximum of the ConcurrentExecutions metric
         *
         * @default - Maximum over 5 minutes
         */
        concurrentExecutions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeadLetterErrors metric
         *
         * @default - Sum over 5 minutes
         */
        deadLetterErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DestinationDeliveryFailures metric
         *
         * @default - Sum over 5 minutes
         */
        destinationDeliveryFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Duration metric
         *
         * @default - Average over 5 minutes
         */
        duration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Errors metric
         *
         * @default - Sum over 5 minutes
         */
        errors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Invocations metric
         *
         * @default - Sum over 5 minutes
         */
        invocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IteratorAge metric
         *
         * @default - Average over 5 minutes
         */
        iteratorAge(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PostRuntimeExtensionsDuration metric
         *
         * @default - Average over 5 minutes
         */
        postRuntimeExtensionsDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProvisionedConcurrencyInvocations metric
         *
         * @default - Sum over 5 minutes
         */
        provisionedConcurrencyInvocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProvisionedConcurrencySpilloverInvocations metric
         *
         * @default - Sum over 5 minutes
         */
        provisionedConcurrencySpilloverInvocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the ProvisionedConcurrentExecutions metric
         *
         * @default - Maximum over 5 minutes
         */
        provisionedConcurrentExecutions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Throttles metric
         *
         * @default - Sum over 5 minutes
         */
        throttles(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for FunctionMetrics
     *
     * @struct
     * @stability external
     */
    interface FunctionMetricsProps {
        /**
         * The FunctionName dimension
         */
        readonly functionName: string;
    }
    /**
     * Metrics for dimension set: Resource {FunctionName, Resource}
     *
     * @stability external
     */
    class ResourceMetrics {
        private readonly dimensions;
        constructor(props: LambdaMetrics.ResourceMetricsProps);
        /**
         * Maximum of the ConcurrentExecutions metric
         *
         * @default - Maximum over 5 minutes
         */
        concurrentExecutions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeadLetterErrors metric
         *
         * @default - Sum over 5 minutes
         */
        deadLetterErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DestinationDeliveryFailures metric
         *
         * @default - Sum over 5 minutes
         */
        destinationDeliveryFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Duration metric
         *
         * @default - Average over 5 minutes
         */
        duration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Errors metric
         *
         * @default - Sum over 5 minutes
         */
        errors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Invocations metric
         *
         * @default - Sum over 5 minutes
         */
        invocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IteratorAge metric
         *
         * @default - Average over 5 minutes
         */
        iteratorAge(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PostRuntimeExtensionsDuration metric
         *
         * @default - Average over 5 minutes
         */
        postRuntimeExtensionsDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProvisionedConcurrencyInvocations metric
         *
         * @default - Sum over 5 minutes
         */
        provisionedConcurrencyInvocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProvisionedConcurrencySpilloverInvocations metric
         *
         * @default - Sum over 5 minutes
         */
        provisionedConcurrencySpilloverInvocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the ProvisionedConcurrentExecutions metric
         *
         * @default - Maximum over 5 minutes
         */
        provisionedConcurrentExecutions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Throttles metric
         *
         * @default - Sum over 5 minutes
         */
        throttles(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the ProvisionedConcurrencyUtilization metric
         *
         * @default - Maximum over 5 minutes
         */
        provisionedConcurrencyUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ResourceMetrics
     *
     * @struct
     * @stability external
     */
    interface ResourceMetricsProps {
        /**
         * The FunctionName dimension
         */
        readonly functionName: string;
        /**
         * The Resource dimension
         */
        readonly resource: string;
    }
    /**
     * Metrics for dimension set: ExecutedVersion {ExecutedVersion, FunctionName, Resource}
     *
     * @stability external
     */
    class ExecutedVersionMetrics {
        private readonly dimensions;
        constructor(props: LambdaMetrics.ExecutedVersionMetricsProps);
        /**
         * Maximum of the ConcurrentExecutions metric
         *
         * @default - Maximum over 5 minutes
         */
        concurrentExecutions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Duration metric
         *
         * @default - Average over 5 minutes
         */
        duration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Errors metric
         *
         * @default - Sum over 5 minutes
         */
        errors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Invocations metric
         *
         * @default - Sum over 5 minutes
         */
        invocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PostRuntimeExtensionsDuration metric
         *
         * @default - Average over 5 minutes
         */
        postRuntimeExtensionsDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProvisionedConcurrencyInvocations metric
         *
         * @default - Sum over 5 minutes
         */
        provisionedConcurrencyInvocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProvisionedConcurrencySpilloverInvocations metric
         *
         * @default - Sum over 5 minutes
         */
        provisionedConcurrencySpilloverInvocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the ProvisionedConcurrentExecutions metric
         *
         * @default - Maximum over 5 minutes
         */
        provisionedConcurrentExecutions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Throttles metric
         *
         * @default - Sum over 5 minutes
         */
        throttles(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the ProvisionedConcurrencyUtilization metric
         *
         * @default - Maximum over 5 minutes
         */
        provisionedConcurrencyUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ExecutedVersionMetrics
     *
     * @struct
     * @stability external
     */
    interface ExecutedVersionMetricsProps {
        /**
         * The ExecutedVersion dimension
         */
        readonly executedVersion: string;
        /**
         * The FunctionName dimension
         */
        readonly functionName: string;
        /**
         * The Resource dimension
         */
        readonly resource: string;
    }
    /**
     * Metrics for dimension set: Account {no dimensions}
     *
     * @stability external
     */
    class AccountMetrics {
        private readonly dimensions;
        constructor();
        /**
         * Maximum of the ConcurrentExecutions metric
         *
         * @default - Maximum over 5 minutes
         */
        concurrentExecutions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeadLetterErrors metric
         *
         * @default - Sum over 5 minutes
         */
        deadLetterErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DestinationDeliveryFailures metric
         *
         * @default - Sum over 5 minutes
         */
        destinationDeliveryFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Duration metric
         *
         * @default - Average over 5 minutes
         */
        duration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Errors metric
         *
         * @default - Sum over 5 minutes
         */
        errors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Invocations metric
         *
         * @default - Sum over 5 minutes
         */
        invocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IteratorAge metric
         *
         * @default - Average over 5 minutes
         */
        iteratorAge(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PostRuntimeExtensionsDuration metric
         *
         * @default - Average over 5 minutes
         */
        postRuntimeExtensionsDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProvisionedConcurrencyInvocations metric
         *
         * @default - Sum over 5 minutes
         */
        provisionedConcurrencyInvocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProvisionedConcurrencySpilloverInvocations metric
         *
         * @default - Sum over 5 minutes
         */
        provisionedConcurrencySpilloverInvocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the ProvisionedConcurrentExecutions metric
         *
         * @default - Maximum over 5 minutes
         */
        provisionedConcurrentExecutions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Throttles metric
         *
         * @default - Sum over 5 minutes
         */
        throttles(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the ProvisionedConcurrencyUtilization metric
         *
         * @default - Maximum over 5 minutes
         */
        provisionedConcurrencyUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the UnreservedConcurrentExecutions metric
         *
         * @default - Maximum over 5 minutes
         */
        unreservedConcurrentExecutions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
}
