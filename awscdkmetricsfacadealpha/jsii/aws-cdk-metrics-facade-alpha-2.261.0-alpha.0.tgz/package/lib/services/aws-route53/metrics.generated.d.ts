import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IHealthCheckRef } from "aws-cdk-lib/aws-route53";
/**
 * CloudWatch metrics facade for AWS/Route53
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class Route53Metrics {
    /**
     * Create HealthCheckMetrics from a HealthCheck reference
     */
    static fromHealthCheck(ref: IHealthCheckRef): Route53Metrics.HealthCheckMetrics;
}
export declare namespace Route53Metrics {
    /**
     * Metrics for dimension set: HealthCheck {HealthCheckId}
     *
     * @stability external
     */
    class HealthCheckMetrics {
        private readonly dimensions;
        constructor(props: Route53Metrics.HealthCheckMetricsProps);
        /**
         * Average of the HealthCheckPercentageHealthy metric
         *
         * @default - Average over 5 minutes
         */
        healthCheckPercentageHealthy(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ConnectionTime metric
         *
         * @default - Average over 5 minutes
         */
        connectionTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Minimum of the HealthCheckStatus metric
         *
         * @default - Minimum over 5 minutes
         */
        healthCheckStatus(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SSLHandshakeTime metric
         *
         * @default - Average over 5 minutes
         */
        sslHandshakeTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ChildHealthCheckHealthyCount metric
         *
         * @default - Average over 5 minutes
         */
        childHealthCheckHealthyCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TimeToFirstByte metric
         *
         * @default - Average over 5 minutes
         */
        timeToFirstByte(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for HealthCheckMetrics
     *
     * @struct
     * @stability external
     */
    interface HealthCheckMetricsProps {
        /**
         * The HealthCheckId dimension
         */
        readonly healthCheckId: string;
    }
}
