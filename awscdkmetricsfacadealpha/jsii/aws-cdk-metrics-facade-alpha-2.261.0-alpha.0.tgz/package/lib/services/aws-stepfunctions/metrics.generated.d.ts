import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IActivityRef, IStateMachineRef } from "aws-cdk-lib/aws-stepfunctions";
/**
 * CloudWatch metrics facade for AWS/States
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class StatesMetrics {
    /**
     * Create ActivityMetrics from a Activity reference
     */
    static fromActivity(ref: IActivityRef): StatesMetrics.ActivityMetrics;
    /**
     * Create StateMachineMetrics from a StateMachine reference
     */
    static fromStateMachine(ref: IStateMachineRef): StatesMetrics.StateMachineMetrics;
}
export declare namespace StatesMetrics {
    /**
     * Metrics for dimension set: StateMachine {StateMachineArn}
     *
     * @stability external
     */
    class StateMachineMetrics {
        private readonly dimensions;
        constructor(props: StatesMetrics.StateMachineMetricsProps);
        /**
         * Sum of the ExecutionsAborted metric
         *
         * @default - Sum over 5 minutes
         */
        executionsAborted(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ExecutionsFailed metric
         *
         * @default - Sum over 5 minutes
         */
        executionsFailed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ExecutionsStarted metric
         *
         * @default - Sum over 5 minutes
         */
        executionsStarted(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ExecutionsSucceeded metric
         *
         * @default - Sum over 5 minutes
         */
        executionsSucceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ExecutionThrottled metric
         *
         * @default - Sum over 5 minutes
         */
        executionThrottled(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ExecutionsTimedOut metric
         *
         * @default - Sum over 5 minutes
         */
        executionsTimedOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ExecutionTime metric
         *
         * @default - Average over 5 minutes
         */
        executionTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for StateMachineMetrics
     *
     * @struct
     * @stability external
     */
    interface StateMachineMetricsProps {
        /**
         * The StateMachineArn dimension
         */
        readonly stateMachineArn: string;
    }
    /**
     * Metrics for dimension set: Activity {ActivityArn}
     *
     * @stability external
     */
    class ActivityMetrics {
        private readonly dimensions;
        constructor(props: StatesMetrics.ActivityMetricsProps);
        /**
         * Sum of the ActivitiesFailed metric
         *
         * @default - Sum over 5 minutes
         */
        activitiesFailed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ActivitiesHeartbeatTimedOut metric
         *
         * @default - Sum over 5 minutes
         */
        activitiesHeartbeatTimedOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ActivitiesScheduled metric
         *
         * @default - Sum over 5 minutes
         */
        activitiesScheduled(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ActivitiesStarted metric
         *
         * @default - Sum over 5 minutes
         */
        activitiesStarted(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ActivitiesSucceeded metric
         *
         * @default - Sum over 5 minutes
         */
        activitiesSucceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ActivitiesTimedOut metric
         *
         * @default - Sum over 5 minutes
         */
        activitiesTimedOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ActivityRunTime metric
         *
         * @default - Average over 5 minutes
         */
        activityRunTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ActivityScheduleTime metric
         *
         * @default - Average over 5 minutes
         */
        activityScheduleTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ActivityTime metric
         *
         * @default - Average over 5 minutes
         */
        activityTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ActivityMetrics
     *
     * @struct
     * @stability external
     */
    interface ActivityMetricsProps {
        /**
         * The ActivityArn dimension
         */
        readonly activityArn: string;
    }
}
