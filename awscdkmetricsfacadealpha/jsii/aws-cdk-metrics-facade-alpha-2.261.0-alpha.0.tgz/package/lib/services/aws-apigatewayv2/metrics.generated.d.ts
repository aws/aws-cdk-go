import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IApiRef } from "aws-cdk-lib/aws-apigatewayv2";
/**
 * CloudWatch metrics facade for AWS/ApiGateway
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class ApiGatewayMetrics {
    /**
     * Create ApiIdMetrics from a Api reference
     */
    static fromApi(ref: IApiRef): ApiGatewayMetrics.ApiIdMetrics;
}
export declare namespace ApiGatewayMetrics {
    /**
     * Metrics for dimension set: ApiId {ApiId}
     *
     * @stability external
     */
    class ApiIdMetrics {
        private readonly dimensions;
        constructor(props: ApiGatewayMetrics.ApiIdMetricsProps);
        /**
         * Sum of the 4xx metric
         *
         * @default - Sum over 5 minutes
         */
        _4xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 5xx metric
         *
         * @default - Sum over 5 minutes
         */
        _5xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Count metric
         *
         * @default - Sum over 5 minutes
         */
        count(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IntegrationLatency metric
         *
         * @default - Average over 5 minutes
         */
        integrationLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Latency metric
         *
         * @default - Average over 5 minutes
         */
        latency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IntegrationError metric
         *
         * @default - Sum over 5 minutes
         */
        integrationError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DataProcessed metric
         *
         * @default - Sum over 5 minutes
         */
        dataProcessed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectCount metric
         *
         * @default - Sum over 5 minutes
         */
        connectCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MessageCount metric
         *
         * @default - Sum over 5 minutes
         */
        messageCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ClientError metric
         *
         * @default - Sum over 5 minutes
         */
        clientError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ExecutionError metric
         *
         * @default - Sum over 5 minutes
         */
        executionError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ApiIdMetrics
     *
     * @struct
     * @stability external
     */
    interface ApiIdMetricsProps {
        /**
         * The ApiId dimension
         */
        readonly apiId: string;
    }
    /**
     * Metrics for dimension set: Stage {ApiName, Stage}
     *
     * @stability external
     */
    class StageMetrics {
        private readonly dimensions;
        constructor(props: ApiGatewayMetrics.StageMetricsProps);
        /**
         * Sum of the Count metric
         *
         * @default - Sum over 5 minutes
         */
        count(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IntegrationLatency metric
         *
         * @default - Average over 5 minutes
         */
        integrationLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Latency metric
         *
         * @default - Average over 5 minutes
         */
        latency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 4XXError metric
         *
         * @default - Sum over 5 minutes
         */
        _4xxError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 5XXError metric
         *
         * @default - Sum over 5 minutes
         */
        _5xxError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheHitCount metric
         *
         * @default - Sum over 5 minutes
         */
        cacheHitCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheMissCount metric
         *
         * @default - Sum over 5 minutes
         */
        cacheMissCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for StageMetrics
     *
     * @struct
     * @stability external
     */
    interface StageMetricsProps {
        /**
         * The ApiName dimension
         */
        readonly apiName: string;
        /**
         * The Stage dimension
         */
        readonly stage: string;
    }
    /**
     * Metrics for dimension set: ApiName {ApiName}
     *
     * @stability external
     */
    class ApiNameMetrics {
        private readonly dimensions;
        constructor(props: ApiGatewayMetrics.ApiNameMetricsProps);
        /**
         * Sum of the Count metric
         *
         * @default - Sum over 5 minutes
         */
        count(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IntegrationLatency metric
         *
         * @default - Average over 5 minutes
         */
        integrationLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Latency metric
         *
         * @default - Average over 5 minutes
         */
        latency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 4XXError metric
         *
         * @default - Sum over 5 minutes
         */
        _4xxError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 5XXError metric
         *
         * @default - Sum over 5 minutes
         */
        _5xxError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheHitCount metric
         *
         * @default - Sum over 5 minutes
         */
        cacheHitCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheMissCount metric
         *
         * @default - Sum over 5 minutes
         */
        cacheMissCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ApiNameMetrics
     *
     * @struct
     * @stability external
     */
    interface ApiNameMetricsProps {
        /**
         * The ApiName dimension
         */
        readonly apiName: string;
    }
    /**
     * Metrics for dimension set: Method {ApiName, Method, Resource, Stage}
     *
     * @stability external
     */
    class MethodMetrics {
        private readonly dimensions;
        constructor(props: ApiGatewayMetrics.MethodMetricsProps);
        /**
         * Sum of the Count metric
         *
         * @default - Sum over 5 minutes
         */
        count(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IntegrationLatency metric
         *
         * @default - Average over 5 minutes
         */
        integrationLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Latency metric
         *
         * @default - Average over 5 minutes
         */
        latency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 4XXError metric
         *
         * @default - Sum over 5 minutes
         */
        _4xxError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 5XXError metric
         *
         * @default - Sum over 5 minutes
         */
        _5xxError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheHitCount metric
         *
         * @default - Sum over 5 minutes
         */
        cacheHitCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheMissCount metric
         *
         * @default - Sum over 5 minutes
         */
        cacheMissCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for MethodMetrics
     *
     * @struct
     * @stability external
     */
    interface MethodMetricsProps {
        /**
         * The ApiName dimension
         */
        readonly apiName: string;
        /**
         * The Method dimension
         */
        readonly method: string;
        /**
         * The Resource dimension
         */
        readonly resource: string;
        /**
         * The Stage dimension
         */
        readonly stage: string;
    }
    /**
     * Metrics for dimension set: StagePerApiId {ApiId, Stage}
     *
     * @stability external
     */
    class StagePerApiIdMetrics {
        private readonly dimensions;
        constructor(props: ApiGatewayMetrics.StagePerApiIdMetricsProps);
        /**
         * Sum of the Count metric
         *
         * @default - Sum over 5 minutes
         */
        count(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IntegrationLatency metric
         *
         * @default - Average over 5 minutes
         */
        integrationLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Latency metric
         *
         * @default - Average over 5 minutes
         */
        latency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 4XXError metric
         *
         * @default - Sum over 5 minutes
         */
        _4xxError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 5XXError metric
         *
         * @default - Sum over 5 minutes
         */
        _5xxError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheHitCount metric
         *
         * @default - Sum over 5 minutes
         */
        cacheHitCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheMissCount metric
         *
         * @default - Sum over 5 minutes
         */
        cacheMissCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for StagePerApiIdMetrics
     *
     * @struct
     * @stability external
     */
    interface StagePerApiIdMetricsProps {
        /**
         * The ApiId dimension
         */
        readonly apiId: string;
        /**
         * The Stage dimension
         */
        readonly stage: string;
    }
    /**
     * Metrics for dimension set: RoutePerApiId {ApiId, Stage, Route}
     *
     * @stability external
     */
    class RoutePerApiIdMetrics {
        private readonly dimensions;
        constructor(props: ApiGatewayMetrics.RoutePerApiIdMetricsProps);
        /**
         * Average of the IntegrationLatency metric
         *
         * @default - Average over 5 minutes
         */
        integrationLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IntegrationError metric
         *
         * @default - Sum over 5 minutes
         */
        integrationError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectCount metric
         *
         * @default - Sum over 5 minutes
         */
        connectCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MessageCount metric
         *
         * @default - Sum over 5 minutes
         */
        messageCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ClientError metric
         *
         * @default - Sum over 5 minutes
         */
        clientError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ExecutionError metric
         *
         * @default - Sum over 5 minutes
         */
        executionError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for RoutePerApiIdMetrics
     *
     * @struct
     * @stability external
     */
    interface RoutePerApiIdMetricsProps {
        /**
         * The ApiId dimension
         */
        readonly apiId: string;
        /**
         * The Stage dimension
         */
        readonly stage: string;
        /**
         * The Route dimension
         */
        readonly route: string;
    }
}
