import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/DAX
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class DAXMetrics {
}
export declare namespace DAXMetrics {
    /**
     * Metrics for dimension set: Account {no dimensions}
     *
     * @stability external
     */
    class AccountMetrics {
        private readonly dimensions;
        constructor();
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FailedRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        failedRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BatchGetItemRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        batchGetItemRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ErrorRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        errorRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EstimatedDbSize metric
         *
         * @default - Average over 5 minutes
         */
        estimatedDbSize(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EvictedSize metric
         *
         * @default - Average over 5 minutes
         */
        evictedSize(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FaultRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        faultRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetItemRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        getItemRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ItemCacheHits metric
         *
         * @default - Sum over 5 minutes
         */
        itemCacheHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ItemCacheMisses metric
         *
         * @default - Sum over 5 minutes
         */
        itemCacheMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the QueryCacheHits metric
         *
         * @default - Sum over 5 minutes
         */
        queryCacheHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the QueryRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        queryRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ScanCacheHits metric
         *
         * @default - Sum over 5 minutes
         */
        scanCacheHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TotalRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        totalRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
}
