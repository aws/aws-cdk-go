import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/DocDB
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class DocDBMetrics {
}
export declare namespace DocDBMetrics {
    /**
     * Metrics for dimension set: DatabaseInstance {DBInstanceIdentifier}
     *
     * @stability external
     */
    class DatabaseInstanceMetrics {
        private readonly dimensions;
        constructor(props: DocDBMetrics.DatabaseInstanceMetricsProps);
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DatabaseConnections metric
         *
         * @default - Average over 5 minutes
         */
        databaseConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EngineUptime metric
         *
         * @default - Average over 5 minutes
         */
        engineUptime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ReadThroughput metric
         *
         * @default - Sum over 5 minutes
         */
        readThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the WriteThroughput metric
         *
         * @default - Sum over 5 minutes
         */
        writeThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for DatabaseInstanceMetrics
     *
     * @struct
     * @stability external
     */
    interface DatabaseInstanceMetricsProps {
        /**
         * The DBInstanceIdentifier dimension
         */
        readonly dbInstanceIdentifier: string;
    }
}
