import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/SES
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class SESMetrics {
}
export declare namespace SESMetrics {
    /**
     * Metrics for dimension set: Account {no dimensions}
     *
     * @stability external
     */
    class AccountMetrics {
        private readonly dimensions;
        constructor();
        /**
         * Sum of the Bounce metric
         *
         * @default - Sum over 5 minutes
         */
        bounce(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Click metric
         *
         * @default - Sum over 5 minutes
         */
        click(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Complaint metric
         *
         * @default - Sum over 5 minutes
         */
        complaint(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Delivery metric
         *
         * @default - Sum over 5 minutes
         */
        delivery(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Open metric
         *
         * @default - Sum over 5 minutes
         */
        open(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Reject metric
         *
         * @default - Sum over 5 minutes
         */
        reject(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RenderingFailure metric
         *
         * @default - Sum over 5 minutes
         */
        renderingFailure(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Reputation.BounceRate metric
         *
         * @default - Average over 5 minutes
         */
        reputationBounceRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Reputation.ComplaintRate metric
         *
         * @default - Average over 5 minutes
         */
        reputationComplaintRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Send metric
         *
         * @default - Sum over 5 minutes
         */
        send(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Metrics for dimension set: ConfigurationSet {ses:configuration-set}
     *
     * @stability external
     */
    class ConfigurationSetMetrics {
        private readonly dimensions;
        constructor(props: SESMetrics.ConfigurationSetMetricsProps);
        /**
         * Sum of the Bounce metric
         *
         * @default - Sum over 5 minutes
         */
        bounce(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Click metric
         *
         * @default - Sum over 5 minutes
         */
        click(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Complaint metric
         *
         * @default - Sum over 5 minutes
         */
        complaint(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Delivery metric
         *
         * @default - Sum over 5 minutes
         */
        delivery(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Open metric
         *
         * @default - Sum over 5 minutes
         */
        open(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Reject metric
         *
         * @default - Sum over 5 minutes
         */
        reject(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RenderingFailure metric
         *
         * @default - Sum over 5 minutes
         */
        renderingFailure(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Send metric
         *
         * @default - Sum over 5 minutes
         */
        send(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Reputation.BounceRate metric
         *
         * @default - Sum over 5 minutes
         */
        reputationBounceRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Reputation.ComplaintRate metric
         *
         * @default - Sum over 5 minutes
         */
        reputationComplaintRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ConfigurationSetMetrics
     *
     * @struct
     * @stability external
     */
    interface ConfigurationSetMetricsProps {
        /**
         * The ses:configuration-set dimension
         */
        readonly sesConfigurationSet: string;
    }
}
