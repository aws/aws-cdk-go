import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IDBClusterRef } from "aws-cdk-lib/aws-neptune";
/**
 * CloudWatch metrics facade for AWS/Neptune
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class NeptuneMetrics {
    /**
     * Create ClusterMetrics from a DBCluster reference
     */
    static fromDBCluster(ref: IDBClusterRef): NeptuneMetrics.ClusterMetrics;
}
export declare namespace NeptuneMetrics {
    /**
     * Metrics for dimension set: Cluster {DBClusterIdentifier}
     *
     * @stability external
     */
    class ClusterMetrics {
        private readonly dimensions;
        constructor(props: NeptuneMetrics.ClusterMetricsProps);
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Minimum of the FreeLocalStorage metric
         *
         * @default - Minimum over 5 minutes
         */
        freeLocalStorage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Minimum of the FreeableMemory metric
         *
         * @default - Minimum over 5 minutes
         */
        freeableMemory(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GremlinErrors metric
         *
         * @default - Sum over 5 minutes
         */
        gremlinErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GremlinRequests metric
         *
         * @default - Sum over 5 minutes
         */
        gremlinRequests(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GremlinRequestsPerSec metric
         *
         * @default - Average over 5 minutes
         */
        gremlinRequestsPerSec(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the LoaderRequests metric
         *
         * @default - Sum over 5 minutes
         */
        loaderRequests(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NetworkReceiveThroughput metric
         *
         * @default - Sum over 5 minutes
         */
        networkReceiveThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SparqlErrors metric
         *
         * @default - Sum over 5 minutes
         */
        sparqlErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SparqlRequestsPerSec metric
         *
         * @default - Sum over 5 minutes
         */
        sparqlRequestsPerSec(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the VolumeBytesUsed metric
         *
         * @default - Sum over 5 minutes
         */
        volumeBytesUsed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the VolumeReadIOPs metric
         *
         * @default - Sum over 5 minutes
         */
        volumeReadIoPs(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the VolumeWriteIOPs metric
         *
         * @default - Sum over 5 minutes
         */
        volumeWriteIoPs(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ClusterMetrics
     *
     * @struct
     * @stability external
     */
    interface ClusterMetricsProps {
        /**
         * The DBClusterIdentifier dimension
         */
        readonly dbClusterIdentifier: string;
    }
}
