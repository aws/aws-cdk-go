import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/SNS
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class SNSMetrics {
}
export declare namespace SNSMetrics {
    /**
     * Metrics for dimension set: Topic {TopicName}
     *
     * @stability external
     */
    class TopicMetrics {
        private readonly dimensions;
        constructor(props: SNSMetrics.TopicMetricsProps);
        /**
         * Sum of the NumberOfNotificationsDelivered metric
         *
         * @default - Sum over 5 minutes
         */
        numberOfNotificationsDelivered(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NumberOfNotificationsFailed metric
         *
         * @default - Sum over 5 minutes
         */
        numberOfNotificationsFailed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NumberOfMessagesPublished metric
         *
         * @default - Sum over 5 minutes
         */
        numberOfMessagesPublished(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PublishSize metric
         *
         * @default - Average over 5 minutes
         */
        publishSize(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for TopicMetrics
     *
     * @struct
     * @stability external
     */
    interface TopicMetricsProps {
        /**
         * The TopicName dimension
         */
        readonly topicName: string;
    }
    /**
     * Metrics for dimension set: CountryPerSmsType {Country, SMSType}
     *
     * @stability external
     */
    class CountryPerSmsTypeMetrics {
        private readonly dimensions;
        constructor(props: SNSMetrics.CountryPerSmsTypeMetricsProps);
        /**
         * Sum of the SMSSuccessRate metric
         *
         * @default - Sum over 5 minutes
         */
        smsSuccessRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for CountryPerSmsTypeMetrics
     *
     * @struct
     * @stability external
     */
    interface CountryPerSmsTypeMetricsProps {
        /**
         * The Country dimension
         */
        readonly country: string;
        /**
         * The SMSType dimension
         */
        readonly smsType: string;
    }
    /**
     * Metrics for dimension set: PhoneNumber {PhoneNumber}
     *
     * @stability external
     */
    class PhoneNumberMetrics {
        private readonly dimensions;
        constructor(props: SNSMetrics.PhoneNumberMetricsProps);
        /**
         * Sum of the PhoneNumberDirect metric
         *
         * @default - Sum over 5 minutes
         */
        phoneNumberDirect(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for PhoneNumberMetrics
     *
     * @struct
     * @stability external
     */
    interface PhoneNumberMetricsProps {
        /**
         * The PhoneNumber dimension
         */
        readonly phoneNumber: string;
    }
    /**
     * Metrics for dimension set: Account {no dimensions}
     *
     * @stability external
     */
    class AccountMetrics {
        private readonly dimensions;
        constructor();
        /**
         * Sum of the SMSMonthToDateSpentUSD metric
         *
         * @default - Sum over 5 minutes
         */
        smsMonthToDateSpentUsd(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
}
