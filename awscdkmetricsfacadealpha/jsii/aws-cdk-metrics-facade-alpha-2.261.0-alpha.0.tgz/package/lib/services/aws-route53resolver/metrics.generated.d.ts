import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/Route53Resolver
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class Route53ResolverMetrics {
}
export declare namespace Route53ResolverMetrics {
    /**
     * Metrics for dimension set: Endpoint {EndpointId}
     *
     * @stability external
     */
    class EndpointMetrics {
        private readonly dimensions;
        constructor(props: Route53ResolverMetrics.EndpointMetricsProps);
        /**
         * Sum of the InboundQueryVolume metric
         *
         * @default - Sum over 5 minutes
         */
        inboundQueryVolume(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the OutboundQueryVolume metric
         *
         * @default - Sum over 5 minutes
         */
        outboundQueryVolume(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the OutboundQueryAggregateVolume metric
         *
         * @default - Sum over 5 minutes
         */
        outboundQueryAggregateVolume(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for EndpointMetrics
     *
     * @struct
     * @stability external
     */
    interface EndpointMetricsProps {
        /**
         * The EndpointId dimension
         */
        readonly endpointId: string;
    }
}
