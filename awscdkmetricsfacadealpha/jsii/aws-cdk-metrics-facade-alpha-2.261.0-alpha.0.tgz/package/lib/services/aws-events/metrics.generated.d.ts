import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/Events
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class EventsMetrics {
}
export declare namespace EventsMetrics {
    /**
     * Metrics for dimension set: Rule {RuleName}
     *
     * @stability external
     */
    class RuleMetrics {
        private readonly dimensions;
        constructor(props: EventsMetrics.RuleMetricsProps);
        /**
         * Sum of the Invocations metric
         *
         * @default - Sum over 5 minutes
         */
        invocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FailedInvocations metric
         *
         * @default - Sum over 5 minutes
         */
        failedInvocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeadLetterInvocations metric
         *
         * @default - Sum over 5 minutes
         */
        deadLetterInvocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TriggeredRules metric
         *
         * @default - Sum over 5 minutes
         */
        triggeredRules(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ThrottledRules metric
         *
         * @default - Sum over 5 minutes
         */
        throttledRules(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InvocationsFailedToBeSentToDlq metric
         *
         * @default - Sum over 5 minutes
         */
        invocationsFailedToBeSentToDlq(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InvocationsSentToDlq metric
         *
         * @default - Sum over 5 minutes
         */
        invocationsSentToDlq(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for RuleMetrics
     *
     * @struct
     * @stability external
     */
    interface RuleMetricsProps {
        /**
         * The RuleName dimension
         */
        readonly ruleName: string;
    }
}
