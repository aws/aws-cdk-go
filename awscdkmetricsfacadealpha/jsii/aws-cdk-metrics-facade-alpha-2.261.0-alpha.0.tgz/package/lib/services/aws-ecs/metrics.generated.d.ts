import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IClusterRef } from "aws-cdk-lib/aws-ecs";
/**
 * CloudWatch metrics facade for AWS/ECS
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class ECSMetrics {
    /**
     * Create ClusterMetrics from a Cluster reference
     */
    static fromCluster(ref: IClusterRef): ECSMetrics.ClusterMetrics;
}
export declare namespace ECSMetrics {
    /**
     * Metrics for dimension set: Service {ClusterName, ServiceName}
     *
     * @stability external
     */
    class ServiceMetrics {
        private readonly dimensions;
        constructor(props: ECSMetrics.ServiceMetricsProps);
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryUtilization metric
         *
         * @default - Average over 5 minutes
         */
        memoryUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ServiceMetrics
     *
     * @struct
     * @stability external
     */
    interface ServiceMetricsProps {
        /**
         * The ClusterName dimension
         */
        readonly clusterName: string;
        /**
         * The ServiceName dimension
         */
        readonly serviceName: string;
    }
    /**
     * Metrics for dimension set: Cluster {ClusterName}
     *
     * @stability external
     */
    class ClusterMetrics {
        private readonly dimensions;
        constructor(props: ECSMetrics.ClusterMetricsProps);
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryUtilization metric
         *
         * @default - Average over 5 minutes
         */
        memoryUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUReservation metric
         *
         * @default - Average over 5 minutes
         */
        cpuReservation(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryReservation metric
         *
         * @default - Average over 5 minutes
         */
        memoryReservation(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GPUReservation metric
         *
         * @default - Average over 5 minutes
         */
        gpuReservation(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ClusterMetrics
     *
     * @struct
     * @stability external
     */
    interface ClusterMetricsProps {
        /**
         * The ClusterName dimension
         */
        readonly clusterName: string;
    }
}
