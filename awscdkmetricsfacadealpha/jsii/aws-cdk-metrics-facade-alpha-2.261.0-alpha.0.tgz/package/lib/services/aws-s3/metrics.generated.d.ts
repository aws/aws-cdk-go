import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/S3
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class S3Metrics {
}
export declare namespace S3Metrics {
    /**
     * Metrics for dimension set: Storage {BucketName, StorageType}
     *
     * @stability external
     */
    class StorageMetrics {
        private readonly dimensions;
        constructor(props: S3Metrics.StorageMetricsProps);
        /**
         * Average of the BucketSizeBytes metric
         *
         * @default - Average over 5 minutes
         */
        bucketSizeBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NumberOfObjects metric
         *
         * @default - Average over 5 minutes
         */
        numberOfObjects(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for StorageMetrics
     *
     * @struct
     * @stability external
     */
    interface StorageMetricsProps {
        /**
         * The BucketName dimension
         */
        readonly bucketName: string;
        /**
         * The StorageType dimension
         */
        readonly storageType: S3Metrics.StorageMetricsStorageType;
    }
    /**
     * Known values for the StorageType dimension
     */
    enum StorageMetricsStorageType {
        /** StorageType = StandardStorage */
        STANDARD_STORAGE = "StandardStorage",
        /** StorageType = AllStorageTypes */
        ALL_STORAGE_TYPES = "AllStorageTypes"
    }
}
