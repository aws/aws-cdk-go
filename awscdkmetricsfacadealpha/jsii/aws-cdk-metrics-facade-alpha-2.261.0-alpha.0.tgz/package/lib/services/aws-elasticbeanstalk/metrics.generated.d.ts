import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IEnvironmentRef } from "aws-cdk-lib/aws-elasticbeanstalk";
/**
 * CloudWatch metrics facade for AWS/ElasticBeanstalk
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class ElasticBeanstalkMetrics {
    /**
     * Create EnvironmentMetrics from a Environment reference
     */
    static fromEnvironment(ref: IEnvironmentRef): ElasticBeanstalkMetrics.EnvironmentMetrics;
}
export declare namespace ElasticBeanstalkMetrics {
    /**
     * Metrics for dimension set: Environment {EnvironmentName}
     *
     * @stability external
     */
    class EnvironmentMetrics {
        private readonly dimensions;
        constructor(props: ElasticBeanstalkMetrics.EnvironmentMetricsProps);
        /**
         * Average of the EnvironmentHealth metric
         *
         * @default - Average over 5 minutes
         */
        environmentHealth(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ApplicationRequests5xx metric
         *
         * @default - Average over 5 minutes
         */
        applicationRequests5xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ApplicationRequests2xx metric
         *
         * @default - Average over 5 minutes
         */
        applicationRequests2xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ApplicationRequests3xx metric
         *
         * @default - Average over 5 minutes
         */
        applicationRequests3xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ApplicationRequests4xx metric
         *
         * @default - Average over 5 minutes
         */
        applicationRequests4xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for EnvironmentMetrics
     *
     * @struct
     * @stability external
     */
    interface EnvironmentMetricsProps {
        /**
         * The EnvironmentName dimension
         */
        readonly environmentName: string;
    }
}
