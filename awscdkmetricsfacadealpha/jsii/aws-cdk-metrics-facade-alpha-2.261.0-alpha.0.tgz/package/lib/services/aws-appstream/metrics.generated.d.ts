import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/AppStream
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class AppStreamMetrics {
}
export declare namespace AppStreamMetrics {
    /**
     * Metrics for dimension set: Fleet {Fleet}
     *
     * @stability external
     */
    class FleetMetrics {
        private readonly dimensions;
        constructor(props: AppStreamMetrics.FleetMetricsProps);
        /**
         * Average of the ActualCapacity metric
         *
         * @default - Average over 5 minutes
         */
        actualCapacity(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the AvailableCapacity metric
         *
         * @default - Average over 5 minutes
         */
        availableCapacity(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Bandwidth metric
         *
         * @default - Average over 5 minutes
         */
        bandwidth(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CapacityUtilization metric
         *
         * @default - Average over 5 minutes
         */
        capacityUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CpuUtilizationInstance metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilizationInstance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DesiredCapacity metric
         *
         * @default - Average over 5 minutes
         */
        desiredCapacity(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskReadOperations metric
         *
         * @default - Average over 5 minutes
         */
        diskReadOperations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskUtilizationInstance metric
         *
         * @default - Average over 5 minutes
         */
        diskUtilizationInstance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskWriteOperations metric
         *
         * @default - Average over 5 minutes
         */
        diskWriteOperations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FramesPerSecond metric
         *
         * @default - Average over 5 minutes
         */
        framesPerSecond(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the InSessionLatency metric
         *
         * @default - Average over 5 minutes
         */
        inSessionLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the InUseCapacity metric
         *
         * @default - Average over 5 minutes
         */
        inUseCapacity(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InsufficientCapacityError metric
         *
         * @default - Sum over 5 minutes
         */
        insufficientCapacityError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryUtilizationInstance metric
         *
         * @default - Average over 5 minutes
         */
        memoryUtilizationInstance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PagingFileUtilizationInstance metric
         *
         * @default - Average over 5 minutes
         */
        pagingFileUtilizationInstance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PendingCapacity metric
         *
         * @default - Average over 5 minutes
         */
        pendingCapacity(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the RunningCapacity metric
         *
         * @default - Average over 5 minutes
         */
        runningCapacity(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for FleetMetrics
     *
     * @struct
     * @stability external
     */
    interface FleetMetricsProps {
        /**
         * The Fleet dimension
         */
        readonly fleet: string;
    }
    /**
     * Metrics for dimension set: Session {FleetName, InstanceId, SessionId}
     *
     * @stability external
     */
    class SessionMetrics {
        private readonly dimensions;
        constructor(props: AppStreamMetrics.SessionMetricsProps);
        /**
         * Average of the Bandwidth metric
         *
         * @default - Average over 5 minutes
         */
        bandwidth(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FramesPerSecond metric
         *
         * @default - Average over 5 minutes
         */
        framesPerSecond(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the InSessionLatency metric
         *
         * @default - Average over 5 minutes
         */
        inSessionLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CpuUtilizationSession metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilizationSession(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryUtilizationSession metric
         *
         * @default - Average over 5 minutes
         */
        memoryUtilizationSession(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for SessionMetrics
     *
     * @struct
     * @stability external
     */
    interface SessionMetricsProps {
        /**
         * The FleetName dimension
         */
        readonly fleetName: string;
        /**
         * The InstanceId dimension
         */
        readonly instanceId: string;
        /**
         * The SessionId dimension
         */
        readonly sessionId: string;
    }
    /**
     * Metrics for dimension set: Instance {FleetName, InstanceId}
     *
     * @stability external
     */
    class InstanceMetrics {
        private readonly dimensions;
        constructor(props: AppStreamMetrics.InstanceMetricsProps);
        /**
         * Average of the CpuUtilizationInstance metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilizationInstance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskReadOperations metric
         *
         * @default - Average over 5 minutes
         */
        diskReadOperations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskUtilizationInstance metric
         *
         * @default - Average over 5 minutes
         */
        diskUtilizationInstance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskWriteOperations metric
         *
         * @default - Average over 5 minutes
         */
        diskWriteOperations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryUtilizationInstance metric
         *
         * @default - Average over 5 minutes
         */
        memoryUtilizationInstance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PagingFileUtilizationInstance metric
         *
         * @default - Average over 5 minutes
         */
        pagingFileUtilizationInstance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for InstanceMetrics
     *
     * @struct
     * @stability external
     */
    interface InstanceMetricsProps {
        /**
         * The FleetName dimension
         */
        readonly fleetName: string;
        /**
         * The InstanceId dimension
         */
        readonly instanceId: string;
    }
}
