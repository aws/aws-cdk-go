import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/Bedrock/Agents
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class BedrockAgentsMetrics {
}
export declare namespace BedrockAgentsMetrics {
    /**
     * Metrics for dimension set: Operation {Operation}
     *
     * @stability external
     */
    class OperationMetrics {
        private readonly dimensions;
        constructor(props: BedrockAgentsMetrics.OperationMetricsProps);
        /**
         * Sum of the InvocationCount metric
         *
         * @default - Sum over 5 minutes
         */
        invocationCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TotalTime metric
         *
         * @default - Average over 5 minutes
         */
        totalTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ModelInvocationCount metric
         *
         * @default - Sum over 5 minutes
         */
        modelInvocationCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ModelLatency metric
         *
         * @default - Average over 5 minutes
         */
        modelLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InputTokenCount metric
         *
         * @default - Sum over 5 minutes
         */
        inputTokenCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the OutputTokenCount metric
         *
         * @default - Sum over 5 minutes
         */
        outputTokenCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ModelInvocationThrottles metric
         *
         * @default - Sum over 5 minutes
         */
        modelInvocationThrottles(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ModelInvocationClientErrors metric
         *
         * @default - Sum over 5 minutes
         */
        modelInvocationClientErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ModelInvocationServerErrors metric
         *
         * @default - Sum over 5 minutes
         */
        modelInvocationServerErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InvocationThrottles metric
         *
         * @default - Sum over 5 minutes
         */
        invocationThrottles(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InvocationClientErrors metric
         *
         * @default - Sum over 5 minutes
         */
        invocationClientErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InvocationServerErrors metric
         *
         * @default - Sum over 5 minutes
         */
        invocationServerErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for OperationMetrics
     *
     * @struct
     * @stability external
     */
    interface OperationMetricsProps {
        /**
         * The Operation dimension
         */
        readonly operation: string;
    }
    /**
     * Metrics for dimension set: AgentAlias {Operation, AgentAliasArn, ModelId}
     *
     * @stability external
     */
    class AgentAliasMetrics {
        private readonly dimensions;
        constructor(props: BedrockAgentsMetrics.AgentAliasMetricsProps);
        /**
         * Sum of the InvocationCount metric
         *
         * @default - Sum over 5 minutes
         */
        invocationCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TotalTime metric
         *
         * @default - Average over 5 minutes
         */
        totalTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ModelInvocationCount metric
         *
         * @default - Sum over 5 minutes
         */
        modelInvocationCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ModelLatency metric
         *
         * @default - Average over 5 minutes
         */
        modelLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InputTokenCount metric
         *
         * @default - Sum over 5 minutes
         */
        inputTokenCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the OutputTokenCount metric
         *
         * @default - Sum over 5 minutes
         */
        outputTokenCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ModelInvocationThrottles metric
         *
         * @default - Sum over 5 minutes
         */
        modelInvocationThrottles(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ModelInvocationClientErrors metric
         *
         * @default - Sum over 5 minutes
         */
        modelInvocationClientErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ModelInvocationServerErrors metric
         *
         * @default - Sum over 5 minutes
         */
        modelInvocationServerErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InvocationThrottles metric
         *
         * @default - Sum over 5 minutes
         */
        invocationThrottles(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InvocationClientErrors metric
         *
         * @default - Sum over 5 minutes
         */
        invocationClientErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InvocationServerErrors metric
         *
         * @default - Sum over 5 minutes
         */
        invocationServerErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for AgentAliasMetrics
     *
     * @struct
     * @stability external
     */
    interface AgentAliasMetricsProps {
        /**
         * The Operation dimension
         */
        readonly operation: string;
        /**
         * The AgentAliasArn dimension
         */
        readonly agentAliasArn: string;
        /**
         * The ModelId dimension
         */
        readonly modelId: string;
    }
}
/**
 * CloudWatch metrics facade for AWS/Bedrock/Guardrails
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class BedrockGuardrailsMetrics {
}
export declare namespace BedrockGuardrailsMetrics {
    /**
     * Metrics for dimension set: GuardrailVersion {GuardrailArn, GuardrailVersion}
     *
     * @stability external
     */
    class GuardrailVersionMetrics {
        private readonly dimensions;
        constructor(props: BedrockGuardrailsMetrics.GuardrailVersionMetricsProps);
        /**
         * Sum of the Invocations metric
         *
         * @default - Sum over 5 minutes
         */
        invocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the InvocationLatency metric
         *
         * @default - Average over 5 minutes
         */
        invocationLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TextUnitCount metric
         *
         * @default - Sum over 5 minutes
         */
        textUnitCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InvocationsIntervened metric
         *
         * @default - Sum over 5 minutes
         */
        invocationsIntervened(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for GuardrailVersionMetrics
     *
     * @struct
     * @stability external
     */
    interface GuardrailVersionMetricsProps {
        /**
         * The GuardrailArn dimension
         */
        readonly guardrailArn: string;
        /**
         * The GuardrailVersion dimension
         */
        readonly guardrailVersion: string;
    }
    /**
     * Metrics for dimension set: Operation {Operation}
     *
     * @stability external
     */
    class OperationMetrics {
        private readonly dimensions;
        constructor(props: BedrockGuardrailsMetrics.OperationMetricsProps);
        /**
         * Sum of the InvocationThrottles metric
         *
         * @default - Sum over 5 minutes
         */
        invocationThrottles(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InvocationServerErrors metric
         *
         * @default - Sum over 5 minutes
         */
        invocationServerErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InvocationClientErrors metric
         *
         * @default - Sum over 5 minutes
         */
        invocationClientErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for OperationMetrics
     *
     * @struct
     * @stability external
     */
    interface OperationMetricsProps {
        /**
         * The Operation dimension
         */
        readonly operation: BedrockGuardrailsMetrics.OperationMetricsOperation;
    }
    /**
     * Known values for the Operation dimension
     */
    enum OperationMetricsOperation {
        /** Operation = ApplyGuardrail */
        APPLY_GUARDRAIL = "ApplyGuardrail"
    }
}
