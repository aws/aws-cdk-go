import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { ICapacityReservationRef, IInstanceRef, INatGatewayRef, IVolumeRef } from "aws-cdk-lib/aws-ec2";
/**
 * CloudWatch metrics facade for AWS/EC2CapacityReservations
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class EC2CapacityReservationsMetrics {
    /**
     * Create CapacityReservationMetrics from a CapacityReservation reference
     */
    static fromCapacityReservation(ref: ICapacityReservationRef): EC2CapacityReservationsMetrics.CapacityReservationMetrics;
}
export declare namespace EC2CapacityReservationsMetrics {
    /**
     * Metrics for dimension set: CapacityReservation {CapacityReservationId}
     *
     * @stability external
     */
    class CapacityReservationMetrics {
        private readonly dimensions;
        constructor(props: EC2CapacityReservationsMetrics.CapacityReservationMetricsProps);
        /**
         * Average of the InstanceUtilization metric
         *
         * @default - Average over 5 minutes
         */
        instanceUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UsedInstanceCount metric
         *
         * @default - Average over 5 minutes
         */
        usedInstanceCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the AvailableInstanceCount metric
         *
         * @default - Average over 5 minutes
         */
        availableInstanceCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TotalInstanceCount metric
         *
         * @default - Average over 5 minutes
         */
        totalInstanceCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for CapacityReservationMetrics
     *
     * @struct
     * @stability external
     */
    interface CapacityReservationMetricsProps {
        /**
         * The CapacityReservationId dimension
         */
        readonly capacityReservationId: string;
    }
}
/**
 * CloudWatch metrics facade for AWS/EBS
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class EBSMetrics {
    /**
     * Create VolumeMetrics from a Volume reference
     */
    static fromVolume(ref: IVolumeRef): EBSMetrics.VolumeMetrics;
}
export declare namespace EBSMetrics {
    /**
     * Metrics for dimension set: Volume {VolumeId}
     *
     * @stability external
     */
    class VolumeMetrics {
        private readonly dimensions;
        constructor(props: EBSMetrics.VolumeMetricsProps);
        /**
         * Sum of the VolumeReadBytes metric
         *
         * @default - Sum over 5 minutes
         */
        volumeReadBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the VolumeWriteBytes metric
         *
         * @default - Sum over 5 minutes
         */
        volumeWriteBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the VolumeReadOps metric
         *
         * @default - Sum over 5 minutes
         */
        volumeReadOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the VolumeTotalReadTime metric
         *
         * @default - Average over 5 minutes
         */
        volumeTotalReadTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the VolumeWriteOps metric
         *
         * @default - Sum over 5 minutes
         */
        volumeWriteOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the VolumeTotalWriteTime metric
         *
         * @default - Average over 5 minutes
         */
        volumeTotalWriteTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the VolumeIdleTime metric
         *
         * @default - Average over 5 minutes
         */
        volumeIdleTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the VolumeQueueLength metric
         *
         * @default - Average over 5 minutes
         */
        volumeQueueLength(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BurstBalance metric
         *
         * @default - Average over 5 minutes
         */
        burstBalance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for VolumeMetrics
     *
     * @struct
     * @stability external
     */
    interface VolumeMetricsProps {
        /**
         * The VolumeId dimension
         */
        readonly volumeId: string;
    }
}
/**
 * CloudWatch metrics facade for AWS/EC2
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class EC2Metrics {
    /**
     * Create InstanceMetrics from a Instance reference
     */
    static fromInstance(ref: IInstanceRef): EC2Metrics.InstanceMetrics;
}
export declare namespace EC2Metrics {
    /**
     * Metrics for dimension set: Instance {InstanceId}
     *
     * @stability external
     */
    class InstanceMetrics {
        private readonly dimensions;
        constructor(props: EC2Metrics.InstanceMetricsProps);
        /**
         * Average of the CPUCreditUsage metric
         *
         * @default - Average over 5 minutes
         */
        cpuCreditUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUCreditBalance metric
         *
         * @default - Average over 5 minutes
         */
        cpuCreditBalance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUSurplusCreditBalance metric
         *
         * @default - Average over 5 minutes
         */
        cpuSurplusCreditBalance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUSurplusCreditsCharged metric
         *
         * @default - Average over 5 minutes
         */
        cpuSurplusCreditsCharged(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskReadBytes metric
         *
         * @default - Average over 5 minutes
         */
        diskReadBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskReadOps metric
         *
         * @default - Average over 5 minutes
         */
        diskReadOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskWriteBytes metric
         *
         * @default - Average over 5 minutes
         */
        diskWriteBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskWriteOps metric
         *
         * @default - Average over 5 minutes
         */
        diskWriteOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MetadataNoToken metric
         *
         * @default - Sum over 5 minutes
         */
        metadataNoToken(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkIn metric
         *
         * @default - Average over 5 minutes
         */
        networkIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkOut metric
         *
         * @default - Average over 5 minutes
         */
        networkOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsIn metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsOut metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the StatusCheckFailed metric
         *
         * @default - Sum over 5 minutes
         */
        statusCheckFailed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the StatusCheckFailed_Instance metric
         *
         * @default - Sum over 5 minutes
         */
        statusCheckFailedInstance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the StatusCheckFailed_System metric
         *
         * @default - Sum over 5 minutes
         */
        statusCheckFailedSystem(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EBSReadOps metric
         *
         * @default - Average over 5 minutes
         */
        ebsReadOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EBSWriteOps metric
         *
         * @default - Average over 5 minutes
         */
        ebsWriteOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EBSReadBytes metric
         *
         * @default - Average over 5 minutes
         */
        ebsReadBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EBSWriteBytes metric
         *
         * @default - Average over 5 minutes
         */
        ebsWriteBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EBSIOBalance% metric
         *
         * @default - Average over 5 minutes
         */
        ebsioBalance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EBSByteBalance% metric
         *
         * @default - Average over 5 minutes
         */
        ebsByteBalance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for InstanceMetrics
     *
     * @struct
     * @stability external
     */
    interface InstanceMetricsProps {
        /**
         * The InstanceId dimension
         */
        readonly instanceId: string;
    }
    /**
     * Metrics for dimension set: Account {no dimensions}
     *
     * @stability external
     */
    class AccountMetrics {
        private readonly dimensions;
        constructor();
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskReadBytes metric
         *
         * @default - Average over 5 minutes
         */
        diskReadBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskReadOps metric
         *
         * @default - Average over 5 minutes
         */
        diskReadOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskWriteBytes metric
         *
         * @default - Average over 5 minutes
         */
        diskWriteBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskWriteOps metric
         *
         * @default - Average over 5 minutes
         */
        diskWriteOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MetadataNoToken metric
         *
         * @default - Sum over 5 minutes
         */
        metadataNoToken(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkIn metric
         *
         * @default - Average over 5 minutes
         */
        networkIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkOut metric
         *
         * @default - Average over 5 minutes
         */
        networkOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsIn metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsOut metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Metrics for dimension set: AutoScalingGroup {AutoScalingGroupName}
     *
     * @stability external
     */
    class AutoScalingGroupMetrics {
        private readonly dimensions;
        constructor(props: EC2Metrics.AutoScalingGroupMetricsProps);
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskReadBytes metric
         *
         * @default - Average over 5 minutes
         */
        diskReadBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskReadOps metric
         *
         * @default - Average over 5 minutes
         */
        diskReadOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskWriteBytes metric
         *
         * @default - Average over 5 minutes
         */
        diskWriteBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskWriteOps metric
         *
         * @default - Average over 5 minutes
         */
        diskWriteOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkIn metric
         *
         * @default - Average over 5 minutes
         */
        networkIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkOut metric
         *
         * @default - Average over 5 minutes
         */
        networkOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsIn metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsOut metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for AutoScalingGroupMetrics
     *
     * @struct
     * @stability external
     */
    interface AutoScalingGroupMetricsProps {
        /**
         * The AutoScalingGroupName dimension
         */
        readonly autoScalingGroupName: string;
    }
    /**
     * Metrics for dimension set: Image {ImageId}
     *
     * @stability external
     */
    class ImageMetrics {
        private readonly dimensions;
        constructor(props: EC2Metrics.ImageMetricsProps);
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskReadBytes metric
         *
         * @default - Average over 5 minutes
         */
        diskReadBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskReadOps metric
         *
         * @default - Average over 5 minutes
         */
        diskReadOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskWriteBytes metric
         *
         * @default - Average over 5 minutes
         */
        diskWriteBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskWriteOps metric
         *
         * @default - Average over 5 minutes
         */
        diskWriteOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkIn metric
         *
         * @default - Average over 5 minutes
         */
        networkIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkOut metric
         *
         * @default - Average over 5 minutes
         */
        networkOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ImageMetrics
     *
     * @struct
     * @stability external
     */
    interface ImageMetricsProps {
        /**
         * The ImageId dimension
         */
        readonly imageId: string;
    }
    /**
     * Metrics for dimension set: InstanceType {InstanceType}
     *
     * @stability external
     */
    class InstanceTypeMetrics {
        private readonly dimensions;
        constructor(props: EC2Metrics.InstanceTypeMetricsProps);
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskReadBytes metric
         *
         * @default - Average over 5 minutes
         */
        diskReadBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskReadOps metric
         *
         * @default - Average over 5 minutes
         */
        diskReadOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskWriteBytes metric
         *
         * @default - Average over 5 minutes
         */
        diskWriteBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskWriteOps metric
         *
         * @default - Average over 5 minutes
         */
        diskWriteOps(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkIn metric
         *
         * @default - Average over 5 minutes
         */
        networkIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkOut metric
         *
         * @default - Average over 5 minutes
         */
        networkOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for InstanceTypeMetrics
     *
     * @struct
     * @stability external
     */
    interface InstanceTypeMetricsProps {
        /**
         * The InstanceType dimension
         */
        readonly instanceType: string;
    }
}
/**
 * CloudWatch metrics facade for CWAgent
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class CWAgentMetrics {
}
export declare namespace CWAgentMetrics {
    /**
     * Metrics for dimension set: Instance {InstanceId}
     *
     * @stability external
     */
    class InstanceMetrics {
        private readonly dimensions;
        constructor(props: CWAgentMetrics.InstanceMetricsProps);
        /**
         * Average of the cpu_usage_idle metric
         *
         * @default - Average over 5 minutes
         */
        cpuUsageIdle(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_usage_iowait metric
         *
         * @default - Average over 5 minutes
         */
        cpuUsageIowait(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_usage_steal metric
         *
         * @default - Average over 5 minutes
         */
        cpuUsageSteal(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_usage_system metric
         *
         * @default - Average over 5 minutes
         */
        cpuUsageSystem(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_usage_user metric
         *
         * @default - Average over 5 minutes
         */
        cpuUsageUser(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the disk_inodes_free metric
         *
         * @default - Sum over 5 minutes
         */
        diskInodesFree(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the disk_inodes_total metric
         *
         * @default - Sum over 5 minutes
         */
        diskInodesTotal(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the disk_inodes_used metric
         *
         * @default - Sum over 5 minutes
         */
        diskInodesUsed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the disk_used_percent metric
         *
         * @default - Maximum over 5 minutes
         */
        diskUsedPercent(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the disk_used metric
         *
         * @default - Maximum over 5 minutes
         */
        diskUsed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the disk_total metric
         *
         * @default - Maximum over 5 minutes
         */
        diskTotal(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the diskio_io_time metric
         *
         * @default - Average over 5 minutes
         */
        diskioIoTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the diskio_read_bytes metric
         *
         * @default - Average over 5 minutes
         */
        diskioReadBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the diskio_reads metric
         *
         * @default - Average over 5 minutes
         */
        diskioReads(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the diskio_write_bytes metric
         *
         * @default - Average over 5 minutes
         */
        diskioWriteBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the diskio_writes metric
         *
         * @default - Average over 5 minutes
         */
        diskioWrites(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the mem_cached metric
         *
         * @default - Average over 5 minutes
         */
        memCached(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the mem_total metric
         *
         * @default - Average over 5 minutes
         */
        memTotal(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the mem_used metric
         *
         * @default - Average over 5 minutes
         */
        memUsed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the mem_used_percent metric
         *
         * @default - Average over 5 minutes
         */
        memUsedPercent(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the netstat_tcp_established metric
         *
         * @default - Sum over 5 minutes
         */
        netstatTcpEstablished(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the netstat_tcp_time_wait metric
         *
         * @default - Sum over 5 minutes
         */
        netstatTcpTimeWait(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the swap_used_percent metric
         *
         * @default - Average over 5 minutes
         */
        swapUsedPercent(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ethtool_bw_in_allowance_exceeded metric
         *
         * @default - Sum over 5 minutes
         */
        ethtoolBwInAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ethtool_bw_out_allowance_exceeded metric
         *
         * @default - Sum over 5 minutes
         */
        ethtoolBwOutAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ethtool_conntrack_allowance_available metric
         *
         * @default - Average over 5 minutes
         */
        ethtoolConntrackAllowanceAvailable(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ethtool_ena_srd_mode metric
         *
         * @default - Average over 5 minutes
         */
        ethtoolEnaSrdMode(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ethtool_ena_srd_eligible_tx_pkts metric
         *
         * @default - Sum over 5 minutes
         */
        ethtoolEnaSrdEligibleTxPkts(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ethtool_ena_srd_tx_pkts metric
         *
         * @default - Sum over 5 minutes
         */
        ethtoolEnaSrdTxPkts(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ethtool_ena_srd_rx_pkts metric
         *
         * @default - Sum over 5 minutes
         */
        ethtoolEnaSrdRxPkts(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ethtool_ena_srd_resource_utilization metric
         *
         * @default - Average over 5 minutes
         */
        ethtoolEnaSrdResourceUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ethtool_linklocal_allowance_exceeded metric
         *
         * @default - Sum over 5 minutes
         */
        ethtoolLinklocalAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ethtool_pps_allowance_exceeded metric
         *
         * @default - Sum over 5 minutes
         */
        ethtoolPpsAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ethtool_conntrack_allowance_exceeded metric
         *
         * @default - Sum over 5 minutes
         */
        ethtoolConntrackAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TCPv4 Connections Established metric
         *
         * @default - Sum over 5 minutes
         */
        tcPv4ConnectionsEstablished(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TCPv6 Connections Established metric
         *
         * @default - Sum over 5 minutes
         */
        tcPv6ConnectionsEstablished(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Memory % Committed Bytes In Use metric
         *
         * @default - Average over 5 minutes
         */
        memoryCommittedBytesInUse(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Processor % Idle Time metric
         *
         * @default - Average over 5 minutes
         */
        processorIdleTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Processor % Interrupt Time metric
         *
         * @default - Average over 5 minutes
         */
        processorInterruptTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Processor % User Time metric
         *
         * @default - Average over 5 minutes
         */
        processorUserTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the LogicalDisk % Free Space metric
         *
         * @default - Average over 5 minutes
         */
        logicalDiskFreeSpace(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Paging File % Usage metric
         *
         * @default - Average over 5 minutes
         */
        pagingFileUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PhysicalDisk % Disk Time metric
         *
         * @default - Average over 5 minutes
         */
        physicalDiskDiskTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PhysicalDisk Disk Read Bytes/sec metric
         *
         * @default - Average over 5 minutes
         */
        physicalDiskDiskReadBytesSec(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PhysicalDisk Disk Write Bytes/sec metric
         *
         * @default - Average over 5 minutes
         */
        physicalDiskDiskWriteBytesSec(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PhysicalDisk Disk Writes/sec metric
         *
         * @default - Average over 5 minutes
         */
        physicalDiskDiskWritesSec(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PhysicalDisk Disk Reads/sec metric
         *
         * @default - Average over 5 minutes
         */
        physicalDiskDiskReadsSec(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Aggregate inbound BW allowance exceeded metric
         *
         * @default - Sum over 5 minutes
         */
        aggregateInboundBwAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Aggregate outbound BW allowance exceeded metric
         *
         * @default - Sum over 5 minutes
         */
        aggregateOutboundBwAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Available connection tracking allowance metric
         *
         * @default - Average over 5 minutes
         */
        availableConnectionTrackingAllowance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ena srd mode metric
         *
         * @default - Average over 5 minutes
         */
        enaSrdMode(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ena srd eligible tx pkts metric
         *
         * @default - Sum over 5 minutes
         */
        enaSrdEligibleTxPkts(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ena srd tx pkts metric
         *
         * @default - Sum over 5 minutes
         */
        enaSrdTxPkts(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ena srd rx pkts metric
         *
         * @default - Sum over 5 minutes
         */
        enaSrdRxPkts(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ena srd resource utilization metric
         *
         * @default - Average over 5 minutes
         */
        enaSrdResourceUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Link local packet rate allowance exceeded metric
         *
         * @default - Sum over 5 minutes
         */
        linkLocalPacketRateAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PPS allowance exceeded metric
         *
         * @default - Sum over 5 minutes
         */
        ppsAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Connection tracking allowance exceeded metric
         *
         * @default - Sum over 5 minutes
         */
        connectionTrackingAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for InstanceMetrics
     *
     * @struct
     * @stability external
     */
    interface InstanceMetricsProps {
        /**
         * The InstanceId dimension
         */
        readonly instanceId: string;
    }
}
/**
 * CloudWatch metrics facade for AWS/NATGateway
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class NATGatewayMetrics {
    /**
     * Create NatGatewayMetrics from a NatGateway reference
     */
    static fromNatGateway(ref: INatGatewayRef): NATGatewayMetrics.NatGatewayMetrics;
}
export declare namespace NATGatewayMetrics {
    /**
     * Metrics for dimension set: NatGateway {NatGatewayId}
     *
     * @stability external
     */
    class NatGatewayMetrics {
        private readonly dimensions;
        constructor(props: NATGatewayMetrics.NatGatewayMetricsProps);
        /**
         * Maximum of the ActiveConnectionCount metric
         *
         * @default - Maximum over 5 minutes
         */
        activeConnectionCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PacketsDropCount metric
         *
         * @default - Sum over 5 minutes
         */
        packetsDropCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesInFromDestination metric
         *
         * @default - Sum over 5 minutes
         */
        bytesInFromDestination(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesInFromSource metric
         *
         * @default - Sum over 5 minutes
         */
        bytesInFromSource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesOutToDestination metric
         *
         * @default - Sum over 5 minutes
         */
        bytesOutToDestination(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesOutToSource metric
         *
         * @default - Sum over 5 minutes
         */
        bytesOutToSource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionAttemptCount metric
         *
         * @default - Sum over 5 minutes
         */
        connectionAttemptCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionEstablishedCount metric
         *
         * @default - Sum over 5 minutes
         */
        connectionEstablishedCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ErrorPortAllocation metric
         *
         * @default - Sum over 5 minutes
         */
        errorPortAllocation(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IdleTimeoutCount metric
         *
         * @default - Sum over 5 minutes
         */
        idleTimeoutCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PacketsInFromDestination metric
         *
         * @default - Sum over 5 minutes
         */
        packetsInFromDestination(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PacketsInFromSource metric
         *
         * @default - Sum over 5 minutes
         */
        packetsInFromSource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PacketsOutToDestination metric
         *
         * @default - Sum over 5 minutes
         */
        packetsOutToDestination(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PacketsOutToSource metric
         *
         * @default - Sum over 5 minutes
         */
        packetsOutToSource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the PeakBytesPerSecond metric
         *
         * @default - Maximum over 5 minutes
         */
        peakBytesPerSecond(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the PeakPacketsPerSecond metric
         *
         * @default - Maximum over 5 minutes
         */
        peakPacketsPerSecond(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for NatGatewayMetrics
     *
     * @struct
     * @stability external
     */
    interface NatGatewayMetricsProps {
        /**
         * The NatGatewayId dimension
         */
        readonly natGatewayId: string;
    }
}
/**
 * CloudWatch metrics facade for AWS/TransitGateway
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class TransitGatewayMetrics {
}
export declare namespace TransitGatewayMetrics {
    /**
     * Metrics for dimension set: TransitGateway {TransitGateway}
     *
     * @stability external
     */
    class TransitGatewayMetrics {
        private readonly dimensions;
        constructor(props: TransitGatewayMetrics.TransitGatewayMetricsProps);
        /**
         * Sum of the BytesIn metric
         *
         * @default - Sum over 5 minutes
         */
        bytesIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesOut metric
         *
         * @default - Sum over 5 minutes
         */
        bytesOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PacketDropCountBlackhole metric
         *
         * @default - Sum over 5 minutes
         */
        packetDropCountBlackhole(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PacketDropCountNoRoute metric
         *
         * @default - Sum over 5 minutes
         */
        packetDropCountNoRoute(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PacketsIn metric
         *
         * @default - Sum over 5 minutes
         */
        packetsIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PacketsOut metric
         *
         * @default - Sum over 5 minutes
         */
        packetsOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for TransitGatewayMetrics
     *
     * @struct
     * @stability external
     */
    interface TransitGatewayMetricsProps {
        /**
         * The TransitGateway dimension
         */
        readonly transitGateway: string;
    }
}
/**
 * CloudWatch metrics facade for AWS/VPN
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class VPNMetrics {
}
export declare namespace VPNMetrics {
    /**
     * Metrics for dimension set: VpnConnection {VpnId}
     *
     * @stability external
     */
    class VpnConnectionMetrics {
        private readonly dimensions;
        constructor(props: VPNMetrics.VpnConnectionMetricsProps);
        /**
         * Sum of the TunnelDataIn metric
         *
         * @default - Sum over 5 minutes
         */
        tunnelDataIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TunnelState metric
         *
         * @default - Average over 5 minutes
         */
        tunnelState(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TunnelDataOut metric
         *
         * @default - Sum over 5 minutes
         */
        tunnelDataOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for VpnConnectionMetrics
     *
     * @struct
     * @stability external
     */
    interface VpnConnectionMetricsProps {
        /**
         * The VpnId dimension
         */
        readonly vpnId: string;
    }
}
