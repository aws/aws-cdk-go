import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IDBClusterRef, IDBInstanceRef } from "aws-cdk-lib/aws-rds";
/**
 * CloudWatch metrics facade for AWS/RDS
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class RDSMetrics {
    /**
     * Create DatabaseClusterMetrics from a DBCluster reference
     */
    static fromDBCluster(ref: IDBClusterRef): RDSMetrics.DatabaseClusterMetrics;
    /**
     * Create DatabaseInstanceMetrics from a DBInstance reference
     */
    static fromDBInstance(ref: IDBInstanceRef): RDSMetrics.DatabaseInstanceMetrics;
}
export declare namespace RDSMetrics {
    /**
     * Metrics for dimension set: DatabaseInstance {DBInstanceIdentifier}
     *
     * @stability external
     */
    class DatabaseInstanceMetrics {
        private readonly dimensions;
        constructor(props: RDSMetrics.DatabaseInstanceMetricsProps);
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReadLatency metric
         *
         * @default - Average over 5 minutes
         */
        readLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DatabaseConnections metric
         *
         * @default - Sum over 5 minutes
         */
        databaseConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FreeStorageSpace metric
         *
         * @default - Average over 5 minutes
         */
        freeStorageSpace(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FreeableMemory metric
         *
         * @default - Average over 5 minutes
         */
        freeableMemory(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReadThroughput metric
         *
         * @default - Average over 5 minutes
         */
        readThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReadIOPS metric
         *
         * @default - Average over 5 minutes
         */
        readIops(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WriteLatency metric
         *
         * @default - Average over 5 minutes
         */
        writeLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WriteThroughput metric
         *
         * @default - Average over 5 minutes
         */
        writeThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WriteIOPS metric
         *
         * @default - Average over 5 minutes
         */
        writeIops(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ServerlessDatabaseCapacity metric
         *
         * @default - Average over 5 minutes
         */
        serverlessDatabaseCapacity(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for DatabaseInstanceMetrics
     *
     * @struct
     * @stability external
     */
    interface DatabaseInstanceMetricsProps {
        /**
         * The DBInstanceIdentifier dimension
         */
        readonly dbInstanceIdentifier: string;
    }
    /**
     * Metrics for dimension set: DatabaseCluster {DBClusterIdentifier}
     *
     * @stability external
     */
    class DatabaseClusterMetrics {
        private readonly dimensions;
        constructor(props: RDSMetrics.DatabaseClusterMetricsProps);
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReadLatency metric
         *
         * @default - Average over 5 minutes
         */
        readLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DatabaseConnections metric
         *
         * @default - Sum over 5 minutes
         */
        databaseConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FreeStorageSpace metric
         *
         * @default - Average over 5 minutes
         */
        freeStorageSpace(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FreeableMemory metric
         *
         * @default - Average over 5 minutes
         */
        freeableMemory(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReadThroughput metric
         *
         * @default - Average over 5 minutes
         */
        readThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReadIOPS metric
         *
         * @default - Average over 5 minutes
         */
        readIops(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WriteLatency metric
         *
         * @default - Average over 5 minutes
         */
        writeLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WriteThroughput metric
         *
         * @default - Average over 5 minutes
         */
        writeThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WriteIOPS metric
         *
         * @default - Average over 5 minutes
         */
        writeIops(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for DatabaseClusterMetrics
     *
     * @struct
     * @stability external
     */
    interface DatabaseClusterMetricsProps {
        /**
         * The DBClusterIdentifier dimension
         */
        readonly dbClusterIdentifier: string;
    }
}
