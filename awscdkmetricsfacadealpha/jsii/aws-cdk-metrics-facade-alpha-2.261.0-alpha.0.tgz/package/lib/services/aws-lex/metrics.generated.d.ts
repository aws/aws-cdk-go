import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/Lex
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class LexMetrics {
}
export declare namespace LexMetrics {
    /**
     * Metrics for dimension set: Operation {BotAlias, BotName, Operation}
     *
     * @stability external
     */
    class OperationMetrics {
        private readonly dimensions;
        constructor(props: LexMetrics.OperationMetricsProps);
        /**
         * Sum of the RuntimeRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        runtimeRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the RuntimeSuccessfulRequestLatency metric
         *
         * @default - Average over 5 minutes
         */
        runtimeSuccessfulRequestLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RuntimeInvalidLambdaResponses metric
         *
         * @default - Sum over 5 minutes
         */
        runtimeInvalidLambdaResponses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RuntimeLambdaErrors metric
         *
         * @default - Sum over 5 minutes
         */
        runtimeLambdaErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MissedUtteranceCount metric
         *
         * @default - Sum over 5 minutes
         */
        missedUtteranceCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RuntimePollyErrors metric
         *
         * @default - Sum over 5 minutes
         */
        runtimePollyErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RuntimeSystemErrors metric
         *
         * @default - Sum over 5 minutes
         */
        runtimeSystemErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RuntimeThrottledEvents metric
         *
         * @default - Sum over 5 minutes
         */
        runtimeThrottledEvents(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RuntimeUserErrors metric
         *
         * @default - Sum over 5 minutes
         */
        runtimeUserErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for OperationMetrics
     *
     * @struct
     * @stability external
     */
    interface OperationMetricsProps {
        /**
         * The BotAlias dimension
         */
        readonly botAlias: string;
        /**
         * The BotName dimension
         */
        readonly botName: string;
        /**
         * The Operation dimension
         */
        readonly operation: string;
    }
}
