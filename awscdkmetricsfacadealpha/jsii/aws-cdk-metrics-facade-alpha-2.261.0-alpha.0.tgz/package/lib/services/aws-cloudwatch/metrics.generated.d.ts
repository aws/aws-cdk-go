import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IMetricStreamRef } from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/CloudWatch/MetricStreams
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class CloudWatchMetricStreamsMetrics {
    /**
     * Create MetricStreamMetrics from a MetricStream reference
     */
    static fromMetricStream(ref: IMetricStreamRef): CloudWatchMetricStreamsMetrics.MetricStreamMetrics;
}
export declare namespace CloudWatchMetricStreamsMetrics {
    /**
     * Metrics for dimension set: MetricStream {MetricStreamName}
     *
     * @stability external
     */
    class MetricStreamMetrics {
        private readonly dimensions;
        constructor(props: CloudWatchMetricStreamsMetrics.MetricStreamMetricsProps);
        /**
         * Sum of the MetricUpdate metric
         *
         * @default - Sum over 5 minutes
         */
        metricUpdate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TotalMetricUpdate metric
         *
         * @default - Sum over 5 minutes
         */
        totalMetricUpdate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PublishErrorRate metric
         *
         * @default - Average over 5 minutes
         */
        publishErrorRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for MetricStreamMetrics
     *
     * @struct
     * @stability external
     */
    interface MetricStreamMetricsProps {
        /**
         * The MetricStreamName dimension
         */
        readonly metricStreamName: string;
    }
}
