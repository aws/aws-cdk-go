import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IStreamRef } from "aws-cdk-lib/aws-kinesis";
/**
 * CloudWatch metrics facade for AWS/Kinesis
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class KinesisMetrics {
    /**
     * Create StreamMetrics from a Stream reference
     */
    static fromStream(ref: IStreamRef): KinesisMetrics.StreamMetrics;
}
export declare namespace KinesisMetrics {
    /**
     * Metrics for dimension set: Stream {StreamName}
     *
     * @stability external
     */
    class StreamMetrics {
        private readonly dimensions;
        constructor(props: KinesisMetrics.StreamMetricsProps);
        /**
         * Sum of the ReadProvisionedThroughputExceeded metric
         *
         * @default - Sum over 5 minutes
         */
        readProvisionedThroughputExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the WriteProvisionedThroughputExceeded metric
         *
         * @default - Sum over 5 minutes
         */
        writeProvisionedThroughputExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the GetRecords.IteratorAgeMilliseconds metric
         *
         * @default - Maximum over 5 minutes
         */
        getRecordsIteratorAgeMilliseconds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PutRecord.Success metric
         *
         * @default - Sum over 5 minutes
         */
        putRecordSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PutRecords.Success metric
         *
         * @default - Sum over 5 minutes
         */
        putRecordsSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PutRecords.Bytes metric
         *
         * @default - Sum over 5 minutes
         */
        putRecordsBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetRecords.Success metric
         *
         * @default - Sum over 5 minutes
         */
        getRecordsSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetRecords.Bytes metric
         *
         * @default - Sum over 5 minutes
         */
        getRecordsBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetRecords.Records metric
         *
         * @default - Sum over 5 minutes
         */
        getRecordsRecords(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the GetRecords.Latency metric
         *
         * @default - Maximum over 5 minutes
         */
        getRecordsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IncomingBytes metric
         *
         * @default - Sum over 5 minutes
         */
        incomingBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IncomingRecords metric
         *
         * @default - Sum over 5 minutes
         */
        incomingRecords(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for StreamMetrics
     *
     * @struct
     * @stability external
     */
    interface StreamMetricsProps {
        /**
         * The StreamName dimension
         */
        readonly streamName: string;
    }
}
