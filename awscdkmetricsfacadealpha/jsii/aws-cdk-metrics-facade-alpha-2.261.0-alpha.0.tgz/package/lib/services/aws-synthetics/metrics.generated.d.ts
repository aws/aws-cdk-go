import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { ICanaryRef } from "aws-cdk-lib/aws-synthetics";
/**
 * CloudWatch metrics facade for CloudWatchSynthetics
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class CloudWatchSyntheticsMetrics {
    /**
     * Create CanaryMetrics from a Canary reference
     */
    static fromCanary(ref: ICanaryRef): CloudWatchSyntheticsMetrics.CanaryMetrics;
}
export declare namespace CloudWatchSyntheticsMetrics {
    /**
     * Metrics for dimension set: Canary {CanaryName}
     *
     * @stability external
     */
    class CanaryMetrics {
        private readonly dimensions;
        constructor(props: CloudWatchSyntheticsMetrics.CanaryMetricsProps);
        /**
         * Sum of the 2xx metric
         *
         * @default - Sum over 5 minutes
         */
        _2xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 4xx metric
         *
         * @default - Sum over 5 minutes
         */
        _4xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 5xx metric
         *
         * @default - Sum over 5 minutes
         */
        _5xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the Duration metric
         *
         * @default - Maximum over 5 minutes
         */
        duration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Failed metric
         *
         * @default - Sum over 5 minutes
         */
        failed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Failed requests metric
         *
         * @default - Sum over 5 minutes
         */
        failedRequests(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SuccessPercent metric
         *
         * @default - Average over 5 minutes
         */
        successPercent(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for CanaryMetrics
     *
     * @struct
     * @stability external
     */
    interface CanaryMetricsProps {
        /**
         * The CanaryName dimension
         */
        readonly canaryName: string;
    }
}
