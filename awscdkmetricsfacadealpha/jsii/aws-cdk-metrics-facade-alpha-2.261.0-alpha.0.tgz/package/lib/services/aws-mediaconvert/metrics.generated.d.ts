import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/MediaConvert
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class MediaConvertMetrics {
}
export declare namespace MediaConvertMetrics {
    /**
     * Metrics for dimension set: Queue {Queue}
     *
     * @stability external
     */
    class QueueMetrics {
        private readonly dimensions;
        constructor(props: MediaConvertMetrics.QueueMetricsProps);
        /**
         * Average of the TranscodingTime metric
         *
         * @default - Average over 5 minutes
         */
        transcodingTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the JobsCompletedCount metric
         *
         * @default - Sum over 5 minutes
         */
        jobsCompletedCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the 8KOutputDuration metric
         *
         * @default - Average over 5 minutes
         */
        _8KOutputDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the AudioOutputDuration metric
         *
         * @default - Average over 5 minutes
         */
        audioOutputDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the HDOutputDuration metric
         *
         * @default - Average over 5 minutes
         */
        hdOutputDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the JobsErroredCount metric
         *
         * @default - Sum over 5 minutes
         */
        jobsErroredCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SDOutputDuration metric
         *
         * @default - Average over 5 minutes
         */
        sdOutputDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the StandbyTime metric
         *
         * @default - Sum over 5 minutes
         */
        standbyTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UHDOutputDuration metric
         *
         * @default - Average over 5 minutes
         */
        uhdOutputDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for QueueMetrics
     *
     * @struct
     * @stability external
     */
    interface QueueMetricsProps {
        /**
         * The Queue dimension
         */
        readonly queue: string;
    }
}
