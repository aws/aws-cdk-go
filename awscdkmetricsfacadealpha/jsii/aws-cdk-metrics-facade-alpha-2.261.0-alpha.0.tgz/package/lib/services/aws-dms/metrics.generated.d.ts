import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/DMS
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class DMSMetrics {
}
export declare namespace DMSMetrics {
    /**
     * Metrics for dimension set: ReplicationTask {ReplicationInstanceIdentifier, ReplicationTaskIdentifier}
     *
     * @stability external
     */
    class ReplicationTaskMetrics {
        private readonly dimensions;
        constructor(props: DMSMetrics.ReplicationTaskMetricsProps);
        /**
         * Sum of the CPUAllocated metric
         *
         * @default - Sum over 5 minutes
         */
        cpuAllocated(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryUsage metric
         *
         * @default - Average over 5 minutes
         */
        memoryUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SwapUsage metric
         *
         * @default - Average over 5 minutes
         */
        swapUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CDCLatencyTarget metric
         *
         * @default - Sum over 5 minutes
         */
        cdcLatencyTarget(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CDCLatencySource metric
         *
         * @default - Sum over 5 minutes
         */
        cdcLatencySource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CDCChangesDiskTarget metric
         *
         * @default - Sum over 5 minutes
         */
        cdcChangesDiskTarget(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CDCChangesDiskSource metric
         *
         * @default - Sum over 5 minutes
         */
        cdcChangesDiskSource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CDCChangesMemorySource metric
         *
         * @default - Sum over 5 minutes
         */
        cdcChangesMemorySource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CDCChangesMemoryTarget metric
         *
         * @default - Sum over 5 minutes
         */
        cdcChangesMemoryTarget(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CDCIncomingChanges metric
         *
         * @default - Sum over 5 minutes
         */
        cdcIncomingChanges(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CDCThroughputBandwidthSource metric
         *
         * @default - Sum over 5 minutes
         */
        cdcThroughputBandwidthSource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CDCThroughputBandwidthTarget metric
         *
         * @default - Sum over 5 minutes
         */
        cdcThroughputBandwidthTarget(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CDCThroughputRowsSource metric
         *
         * @default - Sum over 5 minutes
         */
        cdcThroughputRowsSource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CDCThroughputRowsTarget metric
         *
         * @default - Sum over 5 minutes
         */
        cdcThroughputRowsTarget(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FullLoadThroughputBandwidthSource metric
         *
         * @default - Sum over 5 minutes
         */
        fullLoadThroughputBandwidthSource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FullLoadThroughputBandwidthTarget metric
         *
         * @default - Sum over 5 minutes
         */
        fullLoadThroughputBandwidthTarget(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FullLoadThroughputRowsSource metric
         *
         * @default - Sum over 5 minutes
         */
        fullLoadThroughputRowsSource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FullLoadThroughputRowsTarget metric
         *
         * @default - Sum over 5 minutes
         */
        fullLoadThroughputRowsTarget(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryAllocated metric
         *
         * @default - Average over 5 minutes
         */
        memoryAllocated(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ReplicationTaskMetrics
     *
     * @struct
     * @stability external
     */
    interface ReplicationTaskMetricsProps {
        /**
         * The ReplicationInstanceIdentifier dimension
         */
        readonly replicationInstanceIdentifier: string;
        /**
         * The ReplicationTaskIdentifier dimension
         */
        readonly replicationTaskIdentifier: string;
    }
    /**
     * Metrics for dimension set: ReplicationInstanceExternalResource {ReplicationInstanceExternalResourceId}
     *
     * @stability external
     */
    class ReplicationInstanceExternalResourceMetrics {
        private readonly dimensions;
        constructor(props: DMSMetrics.ReplicationInstanceExternalResourceMetricsProps);
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SwapUsage metric
         *
         * @default - Average over 5 minutes
         */
        swapUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the AvailableMemory metric
         *
         * @default - Sum over 5 minutes
         */
        availableMemory(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DiskQueueDepth metric
         *
         * @default - Sum over 5 minutes
         */
        diskQueueDepth(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FreeStorageSpace metric
         *
         * @default - Average over 5 minutes
         */
        freeStorageSpace(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FreeMemory metric
         *
         * @default - Average over 5 minutes
         */
        freeMemory(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FreeableMemory metric
         *
         * @default - Average over 5 minutes
         */
        freeableMemory(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WriteIOPS metric
         *
         * @default - Average over 5 minutes
         */
        writeIops(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReadIOPS metric
         *
         * @default - Average over 5 minutes
         */
        readIops(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WriteThroughput metric
         *
         * @default - Average over 5 minutes
         */
        writeThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReadThroughput metric
         *
         * @default - Average over 5 minutes
         */
        readThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WriteLatency metric
         *
         * @default - Average over 5 minutes
         */
        writeLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReadLatency metric
         *
         * @default - Average over 5 minutes
         */
        readLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkTransmitThroughput metric
         *
         * @default - Average over 5 minutes
         */
        networkTransmitThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkReceiveThroughput metric
         *
         * @default - Average over 5 minutes
         */
        networkReceiveThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ReplicationInstanceExternalResourceMetrics
     *
     * @struct
     * @stability external
     */
    interface ReplicationInstanceExternalResourceMetricsProps {
        /**
         * The ReplicationInstanceExternalResourceId dimension
         */
        readonly replicationInstanceExternalResourceId: string;
    }
}
