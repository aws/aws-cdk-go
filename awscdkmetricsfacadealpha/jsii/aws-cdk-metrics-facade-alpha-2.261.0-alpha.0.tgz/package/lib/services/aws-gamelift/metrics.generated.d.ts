import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IFleetRef } from "aws-cdk-lib/aws-gamelift";
/**
 * CloudWatch metrics facade for AWS/GameLift
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class GameLiftMetrics {
    /**
     * Create FleetMetrics from a Fleet reference
     */
    static fromFleet(ref: IFleetRef): GameLiftMetrics.FleetMetrics;
}
export declare namespace GameLiftMetrics {
    /**
     * Metrics for dimension set: Fleet {FleetId}
     *
     * @stability external
     */
    class FleetMetrics {
        private readonly dimensions;
        constructor(props: GameLiftMetrics.FleetMetricsProps);
        /**
         * Average of the ActiveInstances metric
         *
         * @default - Average over 5 minutes
         */
        activeInstances(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PercentIdleInstances metric
         *
         * @default - Average over 5 minutes
         */
        percentIdleInstances(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DesiredInstances metric
         *
         * @default - Average over 5 minutes
         */
        desiredInstances(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IdleInstances metric
         *
         * @default - Average over 5 minutes
         */
        idleInstances(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MaxInstances metric
         *
         * @default - Average over 5 minutes
         */
        maxInstances(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MinInstances metric
         *
         * @default - Average over 5 minutes
         */
        minInstances(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InstanceInterruptions metric
         *
         * @default - Sum over 5 minutes
         */
        instanceInterruptions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for FleetMetrics
     *
     * @struct
     * @stability external
     */
    interface FleetMetricsProps {
        /**
         * The FleetId dimension
         */
        readonly fleetId: string;
    }
}
