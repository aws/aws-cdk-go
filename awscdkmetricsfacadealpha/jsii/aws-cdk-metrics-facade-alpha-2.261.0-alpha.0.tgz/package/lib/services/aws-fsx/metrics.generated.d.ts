import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IFileSystemRef } from "aws-cdk-lib/aws-fsx";
/**
 * CloudWatch metrics facade for AWS/FSx
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class FSxMetrics {
    /**
     * Create FileSystemMetrics from a FileSystem reference
     */
    static fromFileSystem(ref: IFileSystemRef): FSxMetrics.FileSystemMetrics;
}
export declare namespace FSxMetrics {
    /**
     * Metrics for dimension set: FileSystem {FileSystemId}
     *
     * @stability external
     */
    class FileSystemMetrics {
        private readonly dimensions;
        constructor(props: FSxMetrics.FileSystemMetricsProps);
        /**
         * SampleCount of the ClientConnections metric
         *
         * @default - SampleCount over 5 minutes
         */
        clientConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DataReadBytes metric
         *
         * @default - Sum over 5 minutes
         */
        dataReadBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DataReadOperations metric
         *
         * @default - Sum over 5 minutes
         */
        dataReadOperations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DataWriteBytes metric
         *
         * @default - Sum over 5 minutes
         */
        dataWriteBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DataWriteOperations metric
         *
         * @default - Sum over 5 minutes
         */
        dataWriteOperations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskThroughputBalance metric
         *
         * @default - Average over 5 minutes
         */
        diskThroughputBalance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DiskThroughputUtilization metric
         *
         * @default - Average over 5 minutes
         */
        diskThroughputUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FileServerDiskIopsBalance metric
         *
         * @default - Average over 5 minutes
         */
        fileServerDiskIopsBalance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FileServerDiskIopsUtilization metric
         *
         * @default - Average over 5 minutes
         */
        fileServerDiskIopsUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FileServerDiskThroughputUtilization metric
         *
         * @default - Average over 5 minutes
         */
        fileServerDiskThroughputUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FreeDataStorageCapacity metric
         *
         * @default - Sum over 5 minutes
         */
        freeDataStorageCapacity(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FreeStorageCapacity metric
         *
         * @default - Average over 5 minutes
         */
        freeStorageCapacity(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryUtilization metric
         *
         * @default - Average over 5 minutes
         */
        memoryUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MetadataOperations metric
         *
         * @default - Sum over 5 minutes
         */
        metadataOperations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkThroughputUtilization metric
         *
         * @default - Average over 5 minutes
         */
        networkThroughputUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for FileSystemMetrics
     *
     * @struct
     * @stability external
     */
    interface FileSystemMetricsProps {
        /**
         * The FileSystemId dimension
         */
        readonly fileSystemId: string;
    }
}
