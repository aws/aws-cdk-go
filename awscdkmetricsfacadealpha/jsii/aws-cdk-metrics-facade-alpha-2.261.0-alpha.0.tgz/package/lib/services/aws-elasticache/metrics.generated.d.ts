import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/ElastiCache
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class ElastiCacheMetrics {
}
export declare namespace ElastiCacheMetrics {
    /**
     * Metrics for dimension set: CacheCluster {CacheClusterId}
     *
     * @stability external
     */
    class CacheClusterMetrics {
        private readonly dimensions;
        constructor(props: ElastiCacheMetrics.CacheClusterMetricsProps);
        /**
         * Sum of the ActiveDefragHits metric
         *
         * @default - Sum over 5 minutes
         */
        activeDefragHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the AuthenticationFailures metric
         *
         * @default - Sum over 5 minutes
         */
        authenticationFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesReadIntoMemcached metric
         *
         * @default - Average over 5 minutes
         */
        bytesReadIntoMemcached(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesUsedForCache metric
         *
         * @default - Average over 5 minutes
         */
        bytesUsedForCache(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesUsedForCacheItems metric
         *
         * @default - Average over 5 minutes
         */
        bytesUsedForCacheItems(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesUsedForHash metric
         *
         * @default - Average over 5 minutes
         */
        bytesUsedForHash(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesWrittenOutFromMemcached metric
         *
         * @default - Average over 5 minutes
         */
        bytesWrittenOutFromMemcached(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CacheHitRate metric
         *
         * @default - Average over 5 minutes
         */
        cacheHitRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheHits metric
         *
         * @default - Sum over 5 minutes
         */
        cacheHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheMisses metric
         *
         * @default - Sum over 5 minutes
         */
        cacheMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CasBadval metric
         *
         * @default - Sum over 5 minutes
         */
        casBadval(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CasHits metric
         *
         * @default - Sum over 5 minutes
         */
        casHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CasMisses metric
         *
         * @default - Sum over 5 minutes
         */
        casMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdConfigGet metric
         *
         * @default - Sum over 5 minutes
         */
        cmdConfigGet(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdConfigSet metric
         *
         * @default - Sum over 5 minutes
         */
        cmdConfigSet(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdFlush metric
         *
         * @default - Sum over 5 minutes
         */
        cmdFlush(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdGet metric
         *
         * @default - Sum over 5 minutes
         */
        cmdGet(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdSet metric
         *
         * @default - Sum over 5 minutes
         */
        cmdSet(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdTouch metric
         *
         * @default - Sum over 5 minutes
         */
        cmdTouch(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CommandAuthorizationFailures metric
         *
         * @default - Sum over 5 minutes
         */
        commandAuthorizationFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUCreditBalance metric
         *
         * @default - Average over 5 minutes
         */
        cpuCreditBalance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUCreditUsage metric
         *
         * @default - Average over 5 minutes
         */
        cpuCreditUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CurrConfig metric
         *
         * @default - Sum over 5 minutes
         */
        currConfig(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CurrConnections metric
         *
         * @default - Sum over 5 minutes
         */
        currConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CurrItems metric
         *
         * @default - Sum over 5 minutes
         */
        currItems(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DatabaseMemoryUsagePercentage metric
         *
         * @default - Average over 5 minutes
         */
        databaseMemoryUsagePercentage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DB0AverageTTL metric
         *
         * @default - Average over 5 minutes
         */
        db0AverageTtl(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DecrHits metric
         *
         * @default - Sum over 5 minutes
         */
        decrHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DecrMisses metric
         *
         * @default - Sum over 5 minutes
         */
        decrMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeleteHits metric
         *
         * @default - Sum over 5 minutes
         */
        deleteHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeleteMisses metric
         *
         * @default - Sum over 5 minutes
         */
        deleteMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EngineCPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        engineCpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the EvalBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        evalBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EvalBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        evalBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the EvictedUnfetched metric
         *
         * @default - Sum over 5 minutes
         */
        evictedUnfetched(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Evictions metric
         *
         * @default - Sum over 5 minutes
         */
        evictions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ExpiredUnfetched metric
         *
         * @default - Sum over 5 minutes
         */
        expiredUnfetched(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FreeableMemory metric
         *
         * @default - Average over 5 minutes
         */
        freeableMemory(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GeoSpatialBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        geoSpatialBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GeoSpatialBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        geoSpatialBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetHits metric
         *
         * @default - Sum over 5 minutes
         */
        getHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetMisses metric
         *
         * @default - Sum over 5 minutes
         */
        getMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetTypeCmds metric
         *
         * @default - Sum over 5 minutes
         */
        getTypeCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GetTypeCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        getTypeCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HashBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        hashBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the HashBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        hashBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HyperLogLogBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        hyperLogLogBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the HyperLogLogBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        hyperLogLogBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IncrHits metric
         *
         * @default - Sum over 5 minutes
         */
        incrHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IncrMisses metric
         *
         * @default - Sum over 5 minutes
         */
        incrMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IsMaster metric
         *
         * @default - Average over 5 minutes
         */
        isMaster(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the KeyAuthorizationFailures metric
         *
         * @default - Sum over 5 minutes
         */
        keyAuthorizationFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the KeyBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        keyBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the KeyBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        keyBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the KeysTracked metric
         *
         * @default - Sum over 5 minutes
         */
        keysTracked(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ListBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        listBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ListBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        listBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MasterLinkHealthStatus metric
         *
         * @default - Average over 5 minutes
         */
        masterLinkHealthStatus(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryFragmentationRatio metric
         *
         * @default - Average over 5 minutes
         */
        memoryFragmentationRatio(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBandwidthInAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkBandwidthInAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBandwidthOutAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkBandwidthOutAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBytesIn metric
         *
         * @default - Average over 5 minutes
         */
        networkBytesIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBytesOut metric
         *
         * @default - Average over 5 minutes
         */
        networkBytesOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkConntrackAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkConntrackAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkLinkLocalAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkLinkLocalAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsIn metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsOut metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsPerSecondAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsPerSecondAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewConnections metric
         *
         * @default - Sum over 5 minutes
         */
        newConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewItems metric
         *
         * @default - Sum over 5 minutes
         */
        newItems(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PubSubBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        pubSubBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PubSubBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        pubSubBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Reclaimed metric
         *
         * @default - Sum over 5 minutes
         */
        reclaimed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ReplicationBytes metric
         *
         * @default - Sum over 5 minutes
         */
        replicationBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReplicationLag metric
         *
         * @default - Average over 5 minutes
         */
        replicationLag(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SaveInProgress metric
         *
         * @default - Sum over 5 minutes
         */
        saveInProgress(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SetBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        setBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SetBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        setBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SetTypeCmds metric
         *
         * @default - Sum over 5 minutes
         */
        setTypeCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SetTypeCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        setTypeCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SlabsMoved metric
         *
         * @default - Sum over 5 minutes
         */
        slabsMoved(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SortedSetBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        sortedSetBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SortedSetBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        sortedSetBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the StreamBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        streamBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the StreamBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        streamBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the StringBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        stringBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the StringBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        stringBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SwapUsage metric
         *
         * @default - Average over 5 minutes
         */
        swapUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TouchHits metric
         *
         * @default - Sum over 5 minutes
         */
        touchHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TouchMisses metric
         *
         * @default - Sum over 5 minutes
         */
        touchMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UnusedMemory metric
         *
         * @default - Average over 5 minutes
         */
        unusedMemory(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for CacheClusterMetrics
     *
     * @struct
     * @stability external
     */
    interface CacheClusterMetricsProps {
        /**
         * The CacheClusterId dimension
         */
        readonly cacheClusterId: string;
    }
    /**
     * Metrics for dimension set: CacheNode {CacheClusterId, CacheNodeId}
     *
     * @stability external
     */
    class CacheNodeMetrics {
        private readonly dimensions;
        constructor(props: ElastiCacheMetrics.CacheNodeMetricsProps);
        /**
         * Sum of the ActiveDefragHits metric
         *
         * @default - Sum over 5 minutes
         */
        activeDefragHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the AuthenticationFailures metric
         *
         * @default - Sum over 5 minutes
         */
        authenticationFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesReadIntoMemcached metric
         *
         * @default - Average over 5 minutes
         */
        bytesReadIntoMemcached(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesUsedForCache metric
         *
         * @default - Average over 5 minutes
         */
        bytesUsedForCache(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesUsedForCacheItems metric
         *
         * @default - Average over 5 minutes
         */
        bytesUsedForCacheItems(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesUsedForHash metric
         *
         * @default - Average over 5 minutes
         */
        bytesUsedForHash(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesWrittenOutFromMemcached metric
         *
         * @default - Average over 5 minutes
         */
        bytesWrittenOutFromMemcached(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CacheHitRate metric
         *
         * @default - Average over 5 minutes
         */
        cacheHitRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheHits metric
         *
         * @default - Sum over 5 minutes
         */
        cacheHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheMisses metric
         *
         * @default - Sum over 5 minutes
         */
        cacheMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CasBadval metric
         *
         * @default - Sum over 5 minutes
         */
        casBadval(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CasHits metric
         *
         * @default - Sum over 5 minutes
         */
        casHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CasMisses metric
         *
         * @default - Sum over 5 minutes
         */
        casMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdConfigGet metric
         *
         * @default - Sum over 5 minutes
         */
        cmdConfigGet(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdConfigSet metric
         *
         * @default - Sum over 5 minutes
         */
        cmdConfigSet(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdFlush metric
         *
         * @default - Sum over 5 minutes
         */
        cmdFlush(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdGet metric
         *
         * @default - Sum over 5 minutes
         */
        cmdGet(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdSet metric
         *
         * @default - Sum over 5 minutes
         */
        cmdSet(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdTouch metric
         *
         * @default - Sum over 5 minutes
         */
        cmdTouch(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CommandAuthorizationFailures metric
         *
         * @default - Sum over 5 minutes
         */
        commandAuthorizationFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUCreditBalance metric
         *
         * @default - Average over 5 minutes
         */
        cpuCreditBalance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUCreditUsage metric
         *
         * @default - Average over 5 minutes
         */
        cpuCreditUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CurrConfig metric
         *
         * @default - Sum over 5 minutes
         */
        currConfig(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CurrConnections metric
         *
         * @default - Sum over 5 minutes
         */
        currConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CurrItems metric
         *
         * @default - Sum over 5 minutes
         */
        currItems(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DatabaseMemoryUsagePercentage metric
         *
         * @default - Average over 5 minutes
         */
        databaseMemoryUsagePercentage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DB0AverageTTL metric
         *
         * @default - Average over 5 minutes
         */
        db0AverageTtl(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DecrHits metric
         *
         * @default - Sum over 5 minutes
         */
        decrHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DecrMisses metric
         *
         * @default - Sum over 5 minutes
         */
        decrMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeleteHits metric
         *
         * @default - Sum over 5 minutes
         */
        deleteHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeleteMisses metric
         *
         * @default - Sum over 5 minutes
         */
        deleteMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EngineCPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        engineCpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the EvalBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        evalBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EvalBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        evalBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the EvictedUnfetched metric
         *
         * @default - Sum over 5 minutes
         */
        evictedUnfetched(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Evictions metric
         *
         * @default - Sum over 5 minutes
         */
        evictions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ExpiredUnfetched metric
         *
         * @default - Sum over 5 minutes
         */
        expiredUnfetched(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FreeableMemory metric
         *
         * @default - Average over 5 minutes
         */
        freeableMemory(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GeoSpatialBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        geoSpatialBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GeoSpatialBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        geoSpatialBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetHits metric
         *
         * @default - Sum over 5 minutes
         */
        getHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetMisses metric
         *
         * @default - Sum over 5 minutes
         */
        getMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetTypeCmds metric
         *
         * @default - Sum over 5 minutes
         */
        getTypeCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GetTypeCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        getTypeCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HashBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        hashBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the HashBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        hashBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HyperLogLogBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        hyperLogLogBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the HyperLogLogBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        hyperLogLogBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IncrHits metric
         *
         * @default - Sum over 5 minutes
         */
        incrHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IncrMisses metric
         *
         * @default - Sum over 5 minutes
         */
        incrMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IsMaster metric
         *
         * @default - Average over 5 minutes
         */
        isMaster(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the KeyAuthorizationFailures metric
         *
         * @default - Sum over 5 minutes
         */
        keyAuthorizationFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the KeyBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        keyBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the KeyBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        keyBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the KeysTracked metric
         *
         * @default - Sum over 5 minutes
         */
        keysTracked(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ListBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        listBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ListBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        listBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MasterLinkHealthStatus metric
         *
         * @default - Average over 5 minutes
         */
        masterLinkHealthStatus(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryFragmentationRatio metric
         *
         * @default - Average over 5 minutes
         */
        memoryFragmentationRatio(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBandwidthInAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkBandwidthInAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBandwidthOutAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkBandwidthOutAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBytesIn metric
         *
         * @default - Average over 5 minutes
         */
        networkBytesIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBytesOut metric
         *
         * @default - Average over 5 minutes
         */
        networkBytesOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkConntrackAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkConntrackAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkLinkLocalAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkLinkLocalAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsIn metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsOut metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsPerSecondAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsPerSecondAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewConnections metric
         *
         * @default - Sum over 5 minutes
         */
        newConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewItems metric
         *
         * @default - Sum over 5 minutes
         */
        newItems(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PubSubBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        pubSubBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PubSubBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        pubSubBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Reclaimed metric
         *
         * @default - Sum over 5 minutes
         */
        reclaimed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ReplicationBytes metric
         *
         * @default - Sum over 5 minutes
         */
        replicationBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReplicationLag metric
         *
         * @default - Average over 5 minutes
         */
        replicationLag(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SaveInProgress metric
         *
         * @default - Sum over 5 minutes
         */
        saveInProgress(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SetBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        setBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SetBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        setBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SetTypeCmds metric
         *
         * @default - Sum over 5 minutes
         */
        setTypeCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SetTypeCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        setTypeCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SlabsMoved metric
         *
         * @default - Sum over 5 minutes
         */
        slabsMoved(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SortedSetBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        sortedSetBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SortedSetBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        sortedSetBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the StreamBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        streamBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the StreamBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        streamBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the StringBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        stringBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the StringBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        stringBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SwapUsage metric
         *
         * @default - Average over 5 minutes
         */
        swapUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TouchHits metric
         *
         * @default - Sum over 5 minutes
         */
        touchHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TouchMisses metric
         *
         * @default - Sum over 5 minutes
         */
        touchMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UnusedMemory metric
         *
         * @default - Average over 5 minutes
         */
        unusedMemory(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for CacheNodeMetrics
     *
     * @struct
     * @stability external
     */
    interface CacheNodeMetricsProps {
        /**
         * The CacheClusterId dimension
         */
        readonly cacheClusterId: string;
        /**
         * The CacheNodeId dimension
         */
        readonly cacheNodeId: string;
    }
    /**
     * Metrics for dimension set: Account {no dimensions}
     *
     * @stability external
     */
    class AccountMetrics {
        private readonly dimensions;
        constructor();
        /**
         * Sum of the ActiveDefragHits metric
         *
         * @default - Sum over 5 minutes
         */
        activeDefragHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the AuthenticationFailures metric
         *
         * @default - Sum over 5 minutes
         */
        authenticationFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesReadIntoMemcached metric
         *
         * @default - Average over 5 minutes
         */
        bytesReadIntoMemcached(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesUsedForCache metric
         *
         * @default - Average over 5 minutes
         */
        bytesUsedForCache(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesUsedForCacheItems metric
         *
         * @default - Average over 5 minutes
         */
        bytesUsedForCacheItems(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesUsedForHash metric
         *
         * @default - Average over 5 minutes
         */
        bytesUsedForHash(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesWrittenOutFromMemcached metric
         *
         * @default - Average over 5 minutes
         */
        bytesWrittenOutFromMemcached(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CacheHitRate metric
         *
         * @default - Average over 5 minutes
         */
        cacheHitRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheHits metric
         *
         * @default - Sum over 5 minutes
         */
        cacheHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CacheMisses metric
         *
         * @default - Sum over 5 minutes
         */
        cacheMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CasBadval metric
         *
         * @default - Sum over 5 minutes
         */
        casBadval(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CasHits metric
         *
         * @default - Sum over 5 minutes
         */
        casHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CasMisses metric
         *
         * @default - Sum over 5 minutes
         */
        casMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdConfigGet metric
         *
         * @default - Sum over 5 minutes
         */
        cmdConfigGet(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdConfigSet metric
         *
         * @default - Sum over 5 minutes
         */
        cmdConfigSet(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdFlush metric
         *
         * @default - Sum over 5 minutes
         */
        cmdFlush(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdGet metric
         *
         * @default - Sum over 5 minutes
         */
        cmdGet(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdSet metric
         *
         * @default - Sum over 5 minutes
         */
        cmdSet(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CmdTouch metric
         *
         * @default - Sum over 5 minutes
         */
        cmdTouch(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CommandAuthorizationFailures metric
         *
         * @default - Sum over 5 minutes
         */
        commandAuthorizationFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUCreditBalance metric
         *
         * @default - Average over 5 minutes
         */
        cpuCreditBalance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUCreditUsage metric
         *
         * @default - Average over 5 minutes
         */
        cpuCreditUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CurrConfig metric
         *
         * @default - Sum over 5 minutes
         */
        currConfig(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CurrConnections metric
         *
         * @default - Sum over 5 minutes
         */
        currConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CurrItems metric
         *
         * @default - Sum over 5 minutes
         */
        currItems(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DatabaseMemoryUsagePercentage metric
         *
         * @default - Average over 5 minutes
         */
        databaseMemoryUsagePercentage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DB0AverageTTL metric
         *
         * @default - Average over 5 minutes
         */
        db0AverageTtl(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DecrHits metric
         *
         * @default - Sum over 5 minutes
         */
        decrHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DecrMisses metric
         *
         * @default - Sum over 5 minutes
         */
        decrMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeleteHits metric
         *
         * @default - Sum over 5 minutes
         */
        deleteHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeleteMisses metric
         *
         * @default - Sum over 5 minutes
         */
        deleteMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EngineCPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        engineCpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the EvalBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        evalBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EvalBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        evalBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the EvictedUnfetched metric
         *
         * @default - Sum over 5 minutes
         */
        evictedUnfetched(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Evictions metric
         *
         * @default - Sum over 5 minutes
         */
        evictions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ExpiredUnfetched metric
         *
         * @default - Sum over 5 minutes
         */
        expiredUnfetched(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FreeableMemory metric
         *
         * @default - Average over 5 minutes
         */
        freeableMemory(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GeoSpatialBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        geoSpatialBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GeoSpatialBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        geoSpatialBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetHits metric
         *
         * @default - Sum over 5 minutes
         */
        getHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetMisses metric
         *
         * @default - Sum over 5 minutes
         */
        getMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetTypeCmds metric
         *
         * @default - Sum over 5 minutes
         */
        getTypeCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GetTypeCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        getTypeCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HashBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        hashBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the HashBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        hashBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HyperLogLogBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        hyperLogLogBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the HyperLogLogBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        hyperLogLogBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IncrHits metric
         *
         * @default - Sum over 5 minutes
         */
        incrHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IncrMisses metric
         *
         * @default - Sum over 5 minutes
         */
        incrMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IsMaster metric
         *
         * @default - Average over 5 minutes
         */
        isMaster(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the KeyAuthorizationFailures metric
         *
         * @default - Sum over 5 minutes
         */
        keyAuthorizationFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the KeyBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        keyBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the KeyBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        keyBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the KeysTracked metric
         *
         * @default - Sum over 5 minutes
         */
        keysTracked(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ListBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        listBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ListBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        listBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MasterLinkHealthStatus metric
         *
         * @default - Average over 5 minutes
         */
        masterLinkHealthStatus(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryFragmentationRatio metric
         *
         * @default - Average over 5 minutes
         */
        memoryFragmentationRatio(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBandwidthInAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkBandwidthInAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBandwidthOutAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkBandwidthOutAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBytesIn metric
         *
         * @default - Average over 5 minutes
         */
        networkBytesIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBytesOut metric
         *
         * @default - Average over 5 minutes
         */
        networkBytesOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkConntrackAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkConntrackAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkLinkLocalAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkLinkLocalAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsIn metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsOut metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsPerSecondAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsPerSecondAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewConnections metric
         *
         * @default - Sum over 5 minutes
         */
        newConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewItems metric
         *
         * @default - Sum over 5 minutes
         */
        newItems(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PubSubBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        pubSubBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PubSubBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        pubSubBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Reclaimed metric
         *
         * @default - Sum over 5 minutes
         */
        reclaimed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ReplicationBytes metric
         *
         * @default - Sum over 5 minutes
         */
        replicationBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReplicationLag metric
         *
         * @default - Average over 5 minutes
         */
        replicationLag(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SaveInProgress metric
         *
         * @default - Sum over 5 minutes
         */
        saveInProgress(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SetBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        setBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SetBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        setBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SetTypeCmds metric
         *
         * @default - Sum over 5 minutes
         */
        setTypeCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SetTypeCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        setTypeCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SlabsMoved metric
         *
         * @default - Sum over 5 minutes
         */
        slabsMoved(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SortedSetBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        sortedSetBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SortedSetBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        sortedSetBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the StreamBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        streamBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the StreamBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        streamBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the StringBasedCmds metric
         *
         * @default - Sum over 5 minutes
         */
        stringBasedCmds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the StringBasedCmdsLatency metric
         *
         * @default - Average over 5 minutes
         */
        stringBasedCmdsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SwapUsage metric
         *
         * @default - Average over 5 minutes
         */
        swapUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TouchHits metric
         *
         * @default - Sum over 5 minutes
         */
        touchHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TouchMisses metric
         *
         * @default - Sum over 5 minutes
         */
        touchMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UnusedMemory metric
         *
         * @default - Average over 5 minutes
         */
        unusedMemory(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GlobalDatastoreReplicationLag metric
         *
         * @default - Average over 5 minutes
         */
        globalDatastoreReplicationLag(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
}
