import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/AppSync
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class AppSyncMetrics {
}
export declare namespace AppSyncMetrics {
    /**
     * Metrics for dimension set: GraphQLApi {GraphQLAPIId}
     *
     * @stability external
     */
    class GraphQlApiMetrics {
        private readonly dimensions;
        constructor(props: AppSyncMetrics.GraphQlApiMetricsProps);
        /**
         * Sum of the 4XXError metric
         *
         * @default - Sum over 5 minutes
         */
        _4xxError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 5XXError metric
         *
         * @default - Sum over 5 minutes
         */
        _5xxError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Latency metric
         *
         * @default - Average over 5 minutes
         */
        latency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for GraphQlApiMetrics
     *
     * @struct
     * @stability external
     */
    interface GraphQlApiMetricsProps {
        /**
         * The GraphQLAPIId dimension
         */
        readonly graphQlapiId: string;
    }
}
