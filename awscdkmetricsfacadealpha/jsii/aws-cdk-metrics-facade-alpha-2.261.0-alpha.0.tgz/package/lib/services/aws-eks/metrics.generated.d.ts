import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IClusterRef } from "aws-cdk-lib/aws-eks";
/**
 * CloudWatch metrics facade for AWS/EKS
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class EKSMetrics {
    /**
     * Create ClusterMetrics from a Cluster reference
     */
    static fromCluster(ref: IClusterRef): EKSMetrics.ClusterMetrics;
}
export declare namespace EKSMetrics {
    /**
     * Metrics for dimension set: Cluster {ClusterName}
     *
     * @stability external
     */
    class ClusterMetrics {
        private readonly dimensions;
        constructor(props: EKSMetrics.ClusterMetricsProps);
        /**
         * Sum of the scheduler_pending_pods metric
         *
         * @default - Sum over 5 minutes
         */
        schedulerPendingPods(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the scheduler_pending_pods_ACTIVEQ metric
         *
         * @default - Sum over 5 minutes
         */
        schedulerPendingPodsActiveq(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the scheduler_pending_pods_UNSCHEDULABLE metric
         *
         * @default - Sum over 5 minutes
         */
        schedulerPendingPodsUnschedulable(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the apiserver_request_total metric
         *
         * @default - Sum over 5 minutes
         */
        apiserverRequestTotal(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the apiserver_request_total_5XX metric
         *
         * @default - Sum over 5 minutes
         */
        apiserverRequestTotal5xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the apiserver_request_total_4XX metric
         *
         * @default - Sum over 5 minutes
         */
        apiserverRequestTotal4xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the apiserver_request_total_429 metric
         *
         * @default - Sum over 5 minutes
         */
        apiserverRequestTotal429(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the apiserver_request_duration_seconds_GET_P99 metric
         *
         * @default - Average over 5 minutes
         */
        apiserverRequestDurationSecondsGetP99(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the apiserver_request_duration_seconds_POST_P99 metric
         *
         * @default - Average over 5 minutes
         */
        apiserverRequestDurationSecondsPostP99(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the apiserver_request_duration_seconds_PUT_P99 metric
         *
         * @default - Average over 5 minutes
         */
        apiserverRequestDurationSecondsPutP99(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the apiserver_request_duration_seconds_DELETE_P99 metric
         *
         * @default - Average over 5 minutes
         */
        apiserverRequestDurationSecondsDeleteP99(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the apiserver_request_duration_seconds_PATCH_P99 metric
         *
         * @default - Average over 5 minutes
         */
        apiserverRequestDurationSecondsPatchP99(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the apiserver_request_duration_seconds_LIST_P99 metric
         *
         * @default - Average over 5 minutes
         */
        apiserverRequestDurationSecondsListP99(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the apiserver_current_inflight_requests_MUTATING metric
         *
         * @default - Average over 5 minutes
         */
        apiserverCurrentInflightRequestsMutating(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the apiserver_current_inflight_requests_READONLY metric
         *
         * @default - Average over 5 minutes
         */
        apiserverCurrentInflightRequestsReadonly(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the apiserver_admission_webhook_request_total metric
         *
         * @default - Sum over 5 minutes
         */
        apiserverAdmissionWebhookRequestTotal(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the apiserver_admission_webhook_request_total_VALIDATING metric
         *
         * @default - Sum over 5 minutes
         */
        apiserverAdmissionWebhookRequestTotalValidating(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the apiserver_admission_webhook_request_total_ADMIT metric
         *
         * @default - Sum over 5 minutes
         */
        apiserverAdmissionWebhookRequestTotalAdmit(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ClusterMetrics
     *
     * @struct
     * @stability external
     */
    interface ClusterMetricsProps {
        /**
         * The ClusterName dimension
         */
        readonly clusterName: string;
    }
}
