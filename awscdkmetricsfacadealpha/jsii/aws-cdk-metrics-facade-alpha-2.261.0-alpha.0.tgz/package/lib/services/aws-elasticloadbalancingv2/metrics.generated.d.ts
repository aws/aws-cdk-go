import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/ApplicationELB
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class ApplicationELBMetrics {
}
export declare namespace ApplicationELBMetrics {
    /**
     * Metrics for dimension set: LoadBalancer {LoadBalancer}
     *
     * @stability external
     */
    class LoadBalancerMetrics {
        private readonly dimensions;
        constructor(props: ApplicationELBMetrics.LoadBalancerMetricsProps);
        /**
         * Sum of the ActiveConnectionCount metric
         *
         * @default - Sum over 5 minutes
         */
        activeConnectionCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ClientTLSNegotiationErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        clientTlsNegotiationErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ConsumedLCUs metric
         *
         * @default - Average over 5 minutes
         */
        consumedLcUs(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DesyncMitigationMode_NonCompliant_Request_Count metric
         *
         * @default - Sum over 5 minutes
         */
        desyncMitigationModeNonCompliantRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ELBAuthError metric
         *
         * @default - Sum over 5 minutes
         */
        elbAuthError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ELBAuthFailure metric
         *
         * @default - Sum over 5 minutes
         */
        elbAuthFailure(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ELBAuthLatency metric
         *
         * @default - Sum over 5 minutes
         */
        elbAuthLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ELBAuthRefreshTokenSuccess metric
         *
         * @default - Sum over 5 minutes
         */
        elbAuthRefreshTokenSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ELBAuthSuccess metric
         *
         * @default - Sum over 5 minutes
         */
        elbAuthSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ELBAuthUserClaimsSizeExceeded metric
         *
         * @default - Sum over 5 minutes
         */
        elbAuthUserClaimsSizeExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GrpcRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        grpcRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTP_Fixed_Response_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpFixedResponseCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTP_Redirect_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpRedirectCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTP_Redirect_Url_Limit_Exceeded_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpRedirectUrlLimitExceededCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_3XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb3xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_4XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb4xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_5XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb5xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_500_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb500Count(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_502_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb502Count(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_503_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb503Count(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_504_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb504Count(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_2XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget2xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_3XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget3xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_4XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget4xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_5XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget5xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IPv6ProcessedBytes metric
         *
         * @default - Sum over 5 minutes
         */
        iPv6ProcessedBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IPv6RequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        iPv6RequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewConnectionCount metric
         *
         * @default - Sum over 5 minutes
         */
        newConnectionCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NonStickyRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        nonStickyRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProcessedBytes metric
         *
         * @default - Sum over 5 minutes
         */
        processedBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RejectedConnectionCount metric
         *
         * @default - Sum over 5 minutes
         */
        rejectedConnectionCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        requestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RuleEvaluations metric
         *
         * @default - Sum over 5 minutes
         */
        ruleEvaluations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TargetConnectionErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        targetConnectionErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TargetResponseTime metric
         *
         * @default - Average over 5 minutes
         */
        targetResponseTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TargetTLSNegotiationErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        targetTlsNegotiationErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the LambdaTargetProcessedBytes metric
         *
         * @default - Sum over 5 minutes
         */
        lambdaTargetProcessedBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for LoadBalancerMetrics
     *
     * @struct
     * @stability external
     */
    interface LoadBalancerMetricsProps {
        /**
         * The LoadBalancer dimension
         */
        readonly loadBalancer: string;
    }
    /**
     * Metrics for dimension set: AvailabilityZone {AvailabilityZone, LoadBalancer}
     *
     * @stability external
     */
    class AvailabilityZoneMetrics {
        private readonly dimensions;
        constructor(props: ApplicationELBMetrics.AvailabilityZoneMetricsProps);
        /**
         * Sum of the ClientTLSNegotiationErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        clientTlsNegotiationErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DesyncMitigationMode_NonCompliant_Request_Count metric
         *
         * @default - Sum over 5 minutes
         */
        desyncMitigationModeNonCompliantRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ELBAuthError metric
         *
         * @default - Sum over 5 minutes
         */
        elbAuthError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ELBAuthFailure metric
         *
         * @default - Sum over 5 minutes
         */
        elbAuthFailure(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ELBAuthLatency metric
         *
         * @default - Sum over 5 minutes
         */
        elbAuthLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ELBAuthRefreshTokenSuccess metric
         *
         * @default - Sum over 5 minutes
         */
        elbAuthRefreshTokenSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ELBAuthSuccess metric
         *
         * @default - Sum over 5 minutes
         */
        elbAuthSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ELBAuthUserClaimsSizeExceeded metric
         *
         * @default - Sum over 5 minutes
         */
        elbAuthUserClaimsSizeExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTP_Fixed_Response_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpFixedResponseCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTP_Redirect_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpRedirectCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTP_Redirect_Url_Limit_Exceeded_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpRedirectUrlLimitExceededCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_3XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb3xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_4XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb4xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_5XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb5xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_2XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget2xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_3XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget3xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_4XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget4xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_5XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget5xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NonStickyRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        nonStickyRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RejectedConnectionCount metric
         *
         * @default - Sum over 5 minutes
         */
        rejectedConnectionCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TargetConnectionErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        targetConnectionErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TargetResponseTime metric
         *
         * @default - Average over 5 minutes
         */
        targetResponseTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TargetTLSNegotiationErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        targetTlsNegotiationErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DroppedInvalidHeaderRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        droppedInvalidHeaderRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ForwardedInvalidHeaderRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        forwardedInvalidHeaderRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for AvailabilityZoneMetrics
     *
     * @struct
     * @stability external
     */
    interface AvailabilityZoneMetricsProps {
        /**
         * The AvailabilityZone dimension
         */
        readonly availabilityZone: string;
        /**
         * The LoadBalancer dimension
         */
        readonly loadBalancer: string;
    }
    /**
     * Metrics for dimension set: TargetGroupPerLoadBalancer {LoadBalancer, TargetGroup}
     *
     * @stability external
     */
    class TargetGroupPerLoadBalancerMetrics {
        private readonly dimensions;
        constructor(props: ApplicationELBMetrics.TargetGroupPerLoadBalancerMetricsProps);
        /**
         * Sum of the HTTPCode_Target_2XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget2xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_3XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget3xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_4XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget4xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_5XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget5xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        requestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TargetConnectionErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        targetConnectionErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TargetResponseTime metric
         *
         * @default - Average over 5 minutes
         */
        targetResponseTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TargetTLSNegotiationErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        targetTlsNegotiationErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RequestCountPerTarget metric
         *
         * @default - Sum over 5 minutes
         */
        requestCountPerTarget(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the LambdaInternalError metric
         *
         * @default - Sum over 5 minutes
         */
        lambdaInternalError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the LambdaUserError metric
         *
         * @default - Sum over 5 minutes
         */
        lambdaUserError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the HealthyHostCount metric
         *
         * @default - Average over 5 minutes
         */
        healthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UnHealthyHostCount metric
         *
         * @default - Average over 5 minutes
         */
        unHealthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for TargetGroupPerLoadBalancerMetrics
     *
     * @struct
     * @stability external
     */
    interface TargetGroupPerLoadBalancerMetricsProps {
        /**
         * The LoadBalancer dimension
         */
        readonly loadBalancer: string;
        /**
         * The TargetGroup dimension
         */
        readonly targetGroup: string;
    }
    /**
     * Metrics for dimension set: AvailabilityZonePerTargetGroup {AvailabilityZone, LoadBalancer, TargetGroup}
     *
     * @stability external
     */
    class AvailabilityZonePerTargetGroupMetrics {
        private readonly dimensions;
        constructor(props: ApplicationELBMetrics.AvailabilityZonePerTargetGroupMetricsProps);
        /**
         * Sum of the HTTPCode_Target_2XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget2xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_3XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget3xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_4XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget4xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Target_5XX_Count metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeTarget5xxCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TargetConnectionErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        targetConnectionErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TargetResponseTime metric
         *
         * @default - Average over 5 minutes
         */
        targetResponseTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TargetTLSNegotiationErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        targetTlsNegotiationErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the HealthyHostCount metric
         *
         * @default - Average over 5 minutes
         */
        healthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UnHealthyHostCount metric
         *
         * @default - Average over 5 minutes
         */
        unHealthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for AvailabilityZonePerTargetGroupMetrics
     *
     * @struct
     * @stability external
     */
    interface AvailabilityZonePerTargetGroupMetricsProps {
        /**
         * The AvailabilityZone dimension
         */
        readonly availabilityZone: string;
        /**
         * The LoadBalancer dimension
         */
        readonly loadBalancer: string;
        /**
         * The TargetGroup dimension
         */
        readonly targetGroup: string;
    }
    /**
     * Metrics for dimension set: TargetGroup {TargetGroup}
     *
     * @stability external
     */
    class TargetGroupMetrics {
        private readonly dimensions;
        constructor(props: ApplicationELBMetrics.TargetGroupMetricsProps);
        /**
         * Sum of the RequestCountPerTarget metric
         *
         * @default - Sum over 5 minutes
         */
        requestCountPerTarget(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the LambdaInternalError metric
         *
         * @default - Sum over 5 minutes
         */
        lambdaInternalError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the LambdaUserError metric
         *
         * @default - Sum over 5 minutes
         */
        lambdaUserError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for TargetGroupMetrics
     *
     * @struct
     * @stability external
     */
    interface TargetGroupMetricsProps {
        /**
         * The TargetGroup dimension
         */
        readonly targetGroup: string;
    }
}
/**
 * CloudWatch metrics facade for AWS/GatewayELB
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class GatewayELBMetrics {
}
export declare namespace GatewayELBMetrics {
    /**
     * Metrics for dimension set: LoadBalancer {LoadBalancer}
     *
     * @stability external
     */
    class LoadBalancerMetrics {
        private readonly dimensions;
        constructor(props: GatewayELBMetrics.LoadBalancerMetricsProps);
        /**
         * Average of the HealthyHostCount metric
         *
         * @default - Average over 5 minutes
         */
        healthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UnHealthyHostCount metric
         *
         * @default - Average over 5 minutes
         */
        unHealthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ActiveFlowCount metric
         *
         * @default - Sum over 5 minutes
         */
        activeFlowCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ConsumedLCUs metric
         *
         * @default - Average over 5 minutes
         */
        consumedLcUs(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewFlowCount metric
         *
         * @default - Sum over 5 minutes
         */
        newFlowCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProcessedBytes metric
         *
         * @default - Sum over 5 minutes
         */
        processedBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for LoadBalancerMetrics
     *
     * @struct
     * @stability external
     */
    interface LoadBalancerMetricsProps {
        /**
         * The LoadBalancer dimension
         */
        readonly loadBalancer: string;
    }
}
/**
 * CloudWatch metrics facade for AWS/NetworkELB
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class NetworkELBMetrics {
}
export declare namespace NetworkELBMetrics {
    /**
     * Metrics for dimension set: LoadBalancer {LoadBalancer}
     *
     * @stability external
     */
    class LoadBalancerMetrics {
        private readonly dimensions;
        constructor(props: NetworkELBMetrics.LoadBalancerMetricsProps);
        /**
         * Average of the ActiveFlowCount metric
         *
         * @default - Average over 5 minutes
         */
        activeFlowCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ActiveFlowCount_TCP metric
         *
         * @default - Average over 5 minutes
         */
        activeFlowCountTcp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ActiveFlowCount_TLS metric
         *
         * @default - Average over 5 minutes
         */
        activeFlowCountTls(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ActiveFlowCount_UDP metric
         *
         * @default - Average over 5 minutes
         */
        activeFlowCountUdp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ClientTLSNegotiationErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        clientTlsNegotiationErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ConsumedLCUs metric
         *
         * @default - Average over 5 minutes
         */
        consumedLcUs(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ConsumedLCUs_TCP metric
         *
         * @default - Average over 5 minutes
         */
        consumedLcUsTcp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ConsumedLCUs_TLS metric
         *
         * @default - Average over 5 minutes
         */
        consumedLcUsTls(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ConsumedLCUs_UDP metric
         *
         * @default - Average over 5 minutes
         */
        consumedLcUsUdp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewFlowCount metric
         *
         * @default - Sum over 5 minutes
         */
        newFlowCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewFlowCount_TCP metric
         *
         * @default - Sum over 5 minutes
         */
        newFlowCountTcp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewFlowCount_TLS metric
         *
         * @default - Sum over 5 minutes
         */
        newFlowCountTls(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewFlowCount_UDP metric
         *
         * @default - Sum over 5 minutes
         */
        newFlowCountUdp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProcessedBytes metric
         *
         * @default - Sum over 5 minutes
         */
        processedBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProcessedBytes_TCP metric
         *
         * @default - Sum over 5 minutes
         */
        processedBytesTcp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProcessedBytes_TLS metric
         *
         * @default - Sum over 5 minutes
         */
        processedBytesTls(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProcessedBytes_UDP metric
         *
         * @default - Sum over 5 minutes
         */
        processedBytesUdp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TargetTLSNegotiationErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        targetTlsNegotiationErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TCP_Client_Reset_Count metric
         *
         * @default - Sum over 5 minutes
         */
        tcpClientResetCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TCP_ELB_Reset_Count metric
         *
         * @default - Sum over 5 minutes
         */
        tcpElbResetCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TCP_Target_Reset_Count metric
         *
         * @default - Sum over 5 minutes
         */
        tcpTargetResetCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PeakPacketsPerSecond metric
         *
         * @default - Sum over 5 minutes
         */
        peakPacketsPerSecond(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProcessedPackets metric
         *
         * @default - Sum over 5 minutes
         */
        processedPackets(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PortAllocationErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        portAllocationErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for LoadBalancerMetrics
     *
     * @struct
     * @stability external
     */
    interface LoadBalancerMetricsProps {
        /**
         * The LoadBalancer dimension
         */
        readonly loadBalancer: string;
    }
    /**
     * Metrics for dimension set: AvailabilityZone {AvailabilityZone, LoadBalancer}
     *
     * @stability external
     */
    class AvailabilityZoneMetrics {
        private readonly dimensions;
        constructor(props: NetworkELBMetrics.AvailabilityZoneMetricsProps);
        /**
         * Average of the ActiveFlowCount metric
         *
         * @default - Average over 5 minutes
         */
        activeFlowCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ActiveFlowCount_TCP metric
         *
         * @default - Average over 5 minutes
         */
        activeFlowCountTcp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ActiveFlowCount_TLS metric
         *
         * @default - Average over 5 minutes
         */
        activeFlowCountTls(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ActiveFlowCount_UDP metric
         *
         * @default - Average over 5 minutes
         */
        activeFlowCountUdp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewFlowCount metric
         *
         * @default - Sum over 5 minutes
         */
        newFlowCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewFlowCount_TCP metric
         *
         * @default - Sum over 5 minutes
         */
        newFlowCountTcp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewFlowCount_TLS metric
         *
         * @default - Sum over 5 minutes
         */
        newFlowCountTls(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewFlowCount_UDP metric
         *
         * @default - Sum over 5 minutes
         */
        newFlowCountUdp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProcessedBytes metric
         *
         * @default - Sum over 5 minutes
         */
        processedBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProcessedBytes_TCP metric
         *
         * @default - Sum over 5 minutes
         */
        processedBytesTcp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProcessedBytes_TLS metric
         *
         * @default - Sum over 5 minutes
         */
        processedBytesTls(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProcessedBytes_UDP metric
         *
         * @default - Sum over 5 minutes
         */
        processedBytesUdp(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TCP_Client_Reset_Count metric
         *
         * @default - Sum over 5 minutes
         */
        tcpClientResetCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TCP_ELB_Reset_Count metric
         *
         * @default - Sum over 5 minutes
         */
        tcpElbResetCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TCP_Target_Reset_Count metric
         *
         * @default - Sum over 5 minutes
         */
        tcpTargetResetCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PeakPacketsPerSecond metric
         *
         * @default - Sum over 5 minutes
         */
        peakPacketsPerSecond(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ProcessedPackets metric
         *
         * @default - Sum over 5 minutes
         */
        processedPackets(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PortAllocationErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        portAllocationErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for AvailabilityZoneMetrics
     *
     * @struct
     * @stability external
     */
    interface AvailabilityZoneMetricsProps {
        /**
         * The AvailabilityZone dimension
         */
        readonly availabilityZone: string;
        /**
         * The LoadBalancer dimension
         */
        readonly loadBalancer: string;
    }
    /**
     * Metrics for dimension set: TargetGroup {LoadBalancer, TargetGroup}
     *
     * @stability external
     */
    class TargetGroupMetrics {
        private readonly dimensions;
        constructor(props: NetworkELBMetrics.TargetGroupMetricsProps);
        /**
         * Minimum of the HealthyHostCount metric
         *
         * @default - Minimum over 5 minutes
         */
        healthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the UnHealthyHostCount metric
         *
         * @default - Maximum over 5 minutes
         */
        unHealthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for TargetGroupMetrics
     *
     * @struct
     * @stability external
     */
    interface TargetGroupMetricsProps {
        /**
         * The LoadBalancer dimension
         */
        readonly loadBalancer: string;
        /**
         * The TargetGroup dimension
         */
        readonly targetGroup: string;
    }
    /**
     * Metrics for dimension set: TargetGroupPerAvailabilityZone {AvailabilityZone, LoadBalancer, TargetGroup}
     *
     * @stability external
     */
    class TargetGroupPerAvailabilityZoneMetrics {
        private readonly dimensions;
        constructor(props: NetworkELBMetrics.TargetGroupPerAvailabilityZoneMetricsProps);
        /**
         * Minimum of the HealthyHostCount metric
         *
         * @default - Minimum over 5 minutes
         */
        healthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the UnHealthyHostCount metric
         *
         * @default - Maximum over 5 minutes
         */
        unHealthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for TargetGroupPerAvailabilityZoneMetrics
     *
     * @struct
     * @stability external
     */
    interface TargetGroupPerAvailabilityZoneMetricsProps {
        /**
         * The AvailabilityZone dimension
         */
        readonly availabilityZone: string;
        /**
         * The LoadBalancer dimension
         */
        readonly loadBalancer: string;
        /**
         * The TargetGroup dimension
         */
        readonly targetGroup: string;
    }
}
