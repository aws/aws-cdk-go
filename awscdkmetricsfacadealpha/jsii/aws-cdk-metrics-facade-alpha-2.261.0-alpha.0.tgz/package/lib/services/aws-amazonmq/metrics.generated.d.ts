import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/AmazonMQ
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class AmazonMQMetrics {
}
export declare namespace AmazonMQMetrics {
    /**
     * Metrics for dimension set: Broker {Broker}
     *
     * @stability external
     */
    class BrokerMetrics {
        private readonly dimensions;
        constructor(props: AmazonMQMetrics.BrokerMetricsProps);
        /**
         * Average of the AckRate metric
         *
         * @default - Average over 5 minutes
         */
        ackRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ChannelCount metric
         *
         * @default - Sum over 5 minutes
         */
        channelCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ConfirmRate metric
         *
         * @default - Average over 5 minutes
         */
        confirmRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionCount metric
         *
         * @default - Sum over 5 minutes
         */
        connectionCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConsumerCount metric
         *
         * @default - Sum over 5 minutes
         */
        consumerCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CpuUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CurrentConnectionsCount metric
         *
         * @default - Sum over 5 minutes
         */
        currentConnectionsCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ExchangeCount metric
         *
         * @default - Sum over 5 minutes
         */
        exchangeCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MessageCount metric
         *
         * @default - Sum over 5 minutes
         */
        messageCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MessageReadyCount metric
         *
         * @default - Sum over 5 minutes
         */
        messageReadyCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MessageUnacknowledgedCount metric
         *
         * @default - Sum over 5 minutes
         */
        messageUnacknowledgedCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NetworkIn metric
         *
         * @default - Sum over 5 minutes
         */
        networkIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NetworkOut metric
         *
         * @default - Sum over 5 minutes
         */
        networkOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PublishRate metric
         *
         * @default - Average over 5 minutes
         */
        publishRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the QueueCount metric
         *
         * @default - Sum over 5 minutes
         */
        queueCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TotalConsumerCount metric
         *
         * @default - Sum over 5 minutes
         */
        totalConsumerCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TotalMessageCount metric
         *
         * @default - Sum over 5 minutes
         */
        totalMessageCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TotalProducerCount metric
         *
         * @default - Sum over 5 minutes
         */
        totalProducerCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for BrokerMetrics
     *
     * @struct
     * @stability external
     */
    interface BrokerMetricsProps {
        /**
         * The Broker dimension
         */
        readonly broker: string;
    }
}
