import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { ILoadBalancerRef } from "aws-cdk-lib/aws-elasticloadbalancing";
/**
 * CloudWatch metrics facade for AWS/ELB
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class ELBMetrics {
    /**
     * Create LoadBalancerMetrics from a LoadBalancer reference
     */
    static fromLoadBalancer(ref: ILoadBalancerRef): ELBMetrics.LoadBalancerMetrics;
}
export declare namespace ELBMetrics {
    /**
     * Metrics for dimension set: LoadBalancer {LoadBalancerName}
     *
     * @stability external
     */
    class LoadBalancerMetrics {
        private readonly dimensions;
        constructor(props: ELBMetrics.LoadBalancerMetricsProps);
        /**
         * Sum of the BackendConnectionErrors metric
         *
         * @default - Sum over 5 minutes
         */
        backendConnectionErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DesyncMitigationMode_NonCompliant_Request_Count metric
         *
         * @default - Sum over 5 minutes
         */
        desyncMitigationModeNonCompliantRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Backend_2XX metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeBackend2xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Backend_3XX metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeBackend3xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Backend_4XX metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeBackend4xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Backend_5XX metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeBackend5xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_4XX metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb4xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_5XX metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb5xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the HealthyHostCount metric
         *
         * @default - Average over 5 minutes
         */
        healthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Latency metric
         *
         * @default - Average over 5 minutes
         */
        latency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        requestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SpilloverCount metric
         *
         * @default - Sum over 5 minutes
         */
        spilloverCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SurgeQueueLength metric
         *
         * @default - Average over 5 minutes
         */
        surgeQueueLength(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UnHealthyHostCount metric
         *
         * @default - Average over 5 minutes
         */
        unHealthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for LoadBalancerMetrics
     *
     * @struct
     * @stability external
     */
    interface LoadBalancerMetricsProps {
        /**
         * The LoadBalancerName dimension
         */
        readonly loadBalancerName: string;
    }
    /**
     * Metrics for dimension set: AvailabilityZone {AvailabilityZone, LoadBalancerName}
     *
     * @stability external
     */
    class AvailabilityZoneMetrics {
        private readonly dimensions;
        constructor(props: ELBMetrics.AvailabilityZoneMetricsProps);
        /**
         * Sum of the BackendConnectionErrors metric
         *
         * @default - Sum over 5 minutes
         */
        backendConnectionErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DesyncMitigationMode_NonCompliant_Request_Count metric
         *
         * @default - Sum over 5 minutes
         */
        desyncMitigationModeNonCompliantRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Backend_2XX metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeBackend2xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Backend_3XX metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeBackend3xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Backend_4XX metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeBackend4xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_Backend_5XX metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeBackend5xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_4XX metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb4xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HTTPCode_ELB_5XX metric
         *
         * @default - Sum over 5 minutes
         */
        httpCodeElb5xx(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the HealthyHostCount metric
         *
         * @default - Average over 5 minutes
         */
        healthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Latency metric
         *
         * @default - Average over 5 minutes
         */
        latency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        requestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SpilloverCount metric
         *
         * @default - Sum over 5 minutes
         */
        spilloverCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SurgeQueueLength metric
         *
         * @default - Average over 5 minutes
         */
        surgeQueueLength(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UnHealthyHostCount metric
         *
         * @default - Average over 5 minutes
         */
        unHealthyHostCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for AvailabilityZoneMetrics
     *
     * @struct
     * @stability external
     */
    interface AvailabilityZoneMetricsProps {
        /**
         * The AvailabilityZone dimension
         */
        readonly availabilityZone: string;
        /**
         * The LoadBalancerName dimension
         */
        readonly loadBalancerName: string;
    }
}
