import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/CloudFront
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class CloudFrontMetrics {
}
export declare namespace CloudFrontMetrics {
    /**
     * Metrics for dimension set: Distribution {DistributionId, Region}
     *
     * @stability external
     */
    class DistributionMetrics {
        private readonly dimensions;
        constructor(props: CloudFrontMetrics.DistributionMetricsProps);
        /**
         * Sum of the Requests metric
         *
         * @default - Sum over 5 minutes
         */
        requests(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TotalErrorRate metric
         *
         * @default - Average over 5 minutes
         */
        totalErrorRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesDownloaded metric
         *
         * @default - Sum over 5 minutes
         */
        bytesDownloaded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesUploaded metric
         *
         * @default - Sum over 5 minutes
         */
        bytesUploaded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the 4xxErrorRate metric
         *
         * @default - Average over 5 minutes
         */
        _4xxErrorRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the 5xxErrorRate metric
         *
         * @default - Average over 5 minutes
         */
        _5xxErrorRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for DistributionMetrics
     *
     * @struct
     * @stability external
     */
    interface DistributionMetricsProps {
        /**
         * The DistributionId dimension
         */
        readonly distributionId: string;
        /**
         * The Region dimension
         */
        readonly region: CloudFrontMetrics.DistributionMetricsRegion;
    }
    /**
     * Known values for the Region dimension
     */
    enum DistributionMetricsRegion {
        /** Region = Global */
        GLOBAL = "Global"
    }
}
