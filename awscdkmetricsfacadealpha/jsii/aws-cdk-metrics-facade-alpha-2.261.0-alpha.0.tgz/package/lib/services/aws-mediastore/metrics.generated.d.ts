import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/MediaStore
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class MediaStoreMetrics {
}
export declare namespace MediaStoreMetrics {
    /**
     * Metrics for dimension set: Container {ContainerName, RequestType}
     *
     * @stability external
     */
    class ContainerMetrics {
        private readonly dimensions;
        constructor(props: MediaStoreMetrics.ContainerMetricsProps);
        /**
         * Sum of the RequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        requestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TurnaroundTime metric
         *
         * @default - Average over 5 minutes
         */
        turnaroundTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 4xxErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        _4xxErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the 5xxErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        _5xxErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesDownloaded metric
         *
         * @default - Sum over 5 minutes
         */
        bytesDownloaded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesUploaded metric
         *
         * @default - Sum over 5 minutes
         */
        bytesUploaded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TotalTime metric
         *
         * @default - Average over 5 minutes
         */
        totalTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ContainerMetrics
     *
     * @struct
     * @stability external
     */
    interface ContainerMetricsProps {
        /**
         * The ContainerName dimension
         */
        readonly containerName: string;
        /**
         * The RequestType dimension
         */
        readonly requestType: string;
    }
}
