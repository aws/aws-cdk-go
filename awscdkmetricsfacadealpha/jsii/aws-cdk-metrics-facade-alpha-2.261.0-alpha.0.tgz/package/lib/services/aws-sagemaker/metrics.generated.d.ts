import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/SageMaker
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class SageMakerMetrics {
}
export declare namespace SageMakerMetrics {
    /**
     * Metrics for dimension set: EndpointVariant {EndpointName, VariantName}
     *
     * @stability external
     */
    class EndpointVariantMetrics {
        private readonly dimensions;
        constructor(props: SageMakerMetrics.EndpointVariantMetricsProps);
        /**
         * Sum of the Invocations metric
         *
         * @default - Sum over 5 minutes
         */
        invocations(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Invocation5XXErrors metric
         *
         * @default - Sum over 5 minutes
         */
        invocation5xxErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Invocation4XXErrors metric
         *
         * @default - Sum over 5 minutes
         */
        invocation4xxErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InvocationsPerInstance metric
         *
         * @default - Sum over 5 minutes
         */
        invocationsPerInstance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ModelLatency metric
         *
         * @default - Sum over 5 minutes
         */
        modelLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the OverheadLatency metric
         *
         * @default - Sum over 5 minutes
         */
        overheadLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for EndpointVariantMetrics
     *
     * @struct
     * @stability external
     */
    interface EndpointVariantMetricsProps {
        /**
         * The EndpointName dimension
         */
        readonly endpointName: string;
        /**
         * The VariantName dimension
         */
        readonly variantName: string;
    }
}
