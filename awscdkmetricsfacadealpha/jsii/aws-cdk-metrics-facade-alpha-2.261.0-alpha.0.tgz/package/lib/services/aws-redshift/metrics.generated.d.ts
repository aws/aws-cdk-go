import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IClusterRef } from "aws-cdk-lib/aws-redshift";
/**
 * CloudWatch metrics facade for AWS/Redshift
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class RedshiftMetrics {
    /**
     * Create ClusterMetrics from a Cluster reference
     */
    static fromCluster(ref: IClusterRef): RedshiftMetrics.ClusterMetrics;
}
export declare namespace RedshiftMetrics {
    /**
     * Metrics for dimension set: Cluster {ClusterIdentifier}
     *
     * @stability external
     */
    class ClusterMetrics {
        private readonly dimensions;
        constructor(props: RedshiftMetrics.ClusterMetricsProps);
        /**
         * Average of the CommitQueueLength metric
         *
         * @default - Average over 5 minutes
         */
        commitQueueLength(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ConcurrencyScalingActiveClusters metric
         *
         * @default - Average over 5 minutes
         */
        concurrencyScalingActiveClusters(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ConcurrencyScalingSeconds metric
         *
         * @default - Average over 5 minutes
         */
        concurrencyScalingSeconds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DatabaseConnections metric
         *
         * @default - Average over 5 minutes
         */
        databaseConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HealthStatus metric
         *
         * @default - Sum over 5 minutes
         */
        healthStatus(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MaintenanceMode metric
         *
         * @default - Sum over 5 minutes
         */
        maintenanceMode(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the MaxConfiguredConcurrencyScalingClusters metric
         *
         * @default - Sum over 5 minutes
         */
        maxConfiguredConcurrencyScalingClusters(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NetworkReceiveThroughput metric
         *
         * @default - Sum over 5 minutes
         */
        networkReceiveThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NetworkTransmitThroughput metric
         *
         * @default - Sum over 5 minutes
         */
        networkTransmitThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NumExceededSchemaQuotas metric
         *
         * @default - Average over 5 minutes
         */
        numExceededSchemaQuotas(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PercentageDiskSpaceUsed metric
         *
         * @default - Average over 5 minutes
         */
        percentageDiskSpaceUsed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ReadIOPS metric
         *
         * @default - Sum over 5 minutes
         */
        readIops(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReadLatency metric
         *
         * @default - Average over 5 minutes
         */
        readLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ReadThroughput metric
         *
         * @default - Sum over 5 minutes
         */
        readThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the RedshiftManagedStorageTotalCapacity metric
         *
         * @default - Average over 5 minutes
         */
        redshiftManagedStorageTotalCapacity(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TotalTableCount metric
         *
         * @default - Average over 5 minutes
         */
        totalTableCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WLMQueueLength metric
         *
         * @default - Average over 5 minutes
         */
        wlmQueueLength(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the WriteIOPS metric
         *
         * @default - Sum over 5 minutes
         */
        writeIops(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WriteLatency metric
         *
         * @default - Average over 5 minutes
         */
        writeLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the WriteThroughput metric
         *
         * @default - Sum over 5 minutes
         */
        writeThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ClusterMetrics
     *
     * @struct
     * @stability external
     */
    interface ClusterMetricsProps {
        /**
         * The ClusterIdentifier dimension
         */
        readonly clusterIdentifier: string;
    }
    /**
     * Metrics for dimension set: Node {ClusterIdentifier, NodeID}
     *
     * @stability external
     */
    class NodeMetrics {
        private readonly dimensions;
        constructor(props: RedshiftMetrics.NodeMetricsProps);
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReadLatency metric
         *
         * @default - Average over 5 minutes
         */
        readLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WriteLatency metric
         *
         * @default - Average over 5 minutes
         */
        writeLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkReceiveThroughput metric
         *
         * @default - Average over 5 minutes
         */
        networkReceiveThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkTransmitThroughput metric
         *
         * @default - Average over 5 minutes
         */
        networkTransmitThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReadIOPS metric
         *
         * @default - Average over 5 minutes
         */
        readIops(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReadThroughput metric
         *
         * @default - Average over 5 minutes
         */
        readThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WriteIOPS metric
         *
         * @default - Average over 5 minutes
         */
        writeIops(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WriteThroughput metric
         *
         * @default - Average over 5 minutes
         */
        writeThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for NodeMetrics
     *
     * @struct
     * @stability external
     */
    interface NodeMetricsProps {
        /**
         * The ClusterIdentifier dimension
         */
        readonly clusterIdentifier: string;
        /**
         * The NodeID dimension
         */
        readonly nodeId: string;
    }
    /**
     * Metrics for dimension set: Queue {ClusterIdentifier, QueueName}
     *
     * @stability external
     */
    class QueueMetrics {
        private readonly dimensions;
        constructor(props: RedshiftMetrics.QueueMetricsProps);
        /**
         * Average of the WLMQueueLength metric
         *
         * @default - Average over 5 minutes
         */
        wlmQueueLength(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WLMQueriesCompletedPerSecond metric
         *
         * @default - Average over 5 minutes
         */
        wlmQueriesCompletedPerSecond(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WLMQueryDuration metric
         *
         * @default - Average over 5 minutes
         */
        wlmQueryDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WLMQueueWaitTime metric
         *
         * @default - Average over 5 minutes
         */
        wlmQueueWaitTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WLMRunningQueries metric
         *
         * @default - Average over 5 minutes
         */
        wlmRunningQueries(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for QueueMetrics
     *
     * @struct
     * @stability external
     */
    interface QueueMetricsProps {
        /**
         * The ClusterIdentifier dimension
         */
        readonly clusterIdentifier: string;
        /**
         * The QueueName dimension
         */
        readonly queueName: string;
    }
    /**
     * Metrics for dimension set: ServiceClass {ClusterIdentifier, service class}
     *
     * @stability external
     */
    class ServiceClassMetrics {
        private readonly dimensions;
        constructor(props: RedshiftMetrics.ServiceClassMetricsProps);
        /**
         * Average of the WLMQueueLength metric
         *
         * @default - Average over 5 minutes
         */
        wlmQueueLength(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ServiceClassMetrics
     *
     * @struct
     * @stability external
     */
    interface ServiceClassMetricsProps {
        /**
         * The ClusterIdentifier dimension
         */
        readonly clusterIdentifier: string;
        /**
         * The service class dimension
         */
        readonly serviceClass: string;
    }
    /**
     * Metrics for dimension set: WorkloadManagement {ClusterIdentifier, wlmid}
     *
     * @stability external
     */
    class WorkloadManagementMetrics {
        private readonly dimensions;
        constructor(props: RedshiftMetrics.WorkloadManagementMetricsProps);
        /**
         * Average of the WLMQueriesCompletedPerSecond metric
         *
         * @default - Average over 5 minutes
         */
        wlmQueriesCompletedPerSecond(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WLMQueryDuration metric
         *
         * @default - Average over 5 minutes
         */
        wlmQueryDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WLMQueueWaitTime metric
         *
         * @default - Average over 5 minutes
         */
        wlmQueueWaitTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WLMRunningQueries metric
         *
         * @default - Average over 5 minutes
         */
        wlmRunningQueries(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for WorkloadManagementMetrics
     *
     * @struct
     * @stability external
     */
    interface WorkloadManagementMetricsProps {
        /**
         * The ClusterIdentifier dimension
         */
        readonly clusterIdentifier: string;
        /**
         * The wlmid dimension
         */
        readonly wlmid: string;
    }
    /**
     * Metrics for dimension set: WorkloadManagementPerNode {ClusterIdentifier, wlmid, NodeID}
     *
     * @stability external
     */
    class WorkloadManagementPerNodeMetrics {
        private readonly dimensions;
        constructor(props: RedshiftMetrics.WorkloadManagementPerNodeMetricsProps);
        /**
         * Average of the WLMQueriesCompletedPerSecond metric
         *
         * @default - Average over 5 minutes
         */
        wlmQueriesCompletedPerSecond(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the WLMQueryDuration metric
         *
         * @default - Average over 5 minutes
         */
        wlmQueryDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for WorkloadManagementPerNodeMetrics
     *
     * @struct
     * @stability external
     */
    interface WorkloadManagementPerNodeMetricsProps {
        /**
         * The ClusterIdentifier dimension
         */
        readonly clusterIdentifier: string;
        /**
         * The wlmid dimension
         */
        readonly wlmid: string;
        /**
         * The NodeID dimension
         */
        readonly nodeId: string;
    }
    /**
     * Metrics for dimension set: QueryPriority {ClusterIdentifier, QueryPriority}
     *
     * @stability external
     */
    class QueryPriorityMetrics {
        private readonly dimensions;
        constructor(props: RedshiftMetrics.QueryPriorityMetricsProps);
        /**
         * Average of the WLMQueueWaitTime metric
         *
         * @default - Average over 5 minutes
         */
        wlmQueueWaitTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for QueryPriorityMetrics
     *
     * @struct
     * @stability external
     */
    interface QueryPriorityMetricsProps {
        /**
         * The ClusterIdentifier dimension
         */
        readonly clusterIdentifier: string;
        /**
         * The QueryPriority dimension
         */
        readonly queryPriority: string;
    }
    /**
     * Metrics for dimension set: StagePerNode {ClusterIdentifier, stage, NodeID}
     *
     * @stability external
     */
    class StagePerNodeMetrics {
        private readonly dimensions;
        constructor(props: RedshiftMetrics.StagePerNodeMetricsProps);
        /**
         * Average of the QueryRuntimeBreakdown metric
         *
         * @default - Average over 5 minutes
         */
        queryRuntimeBreakdown(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for StagePerNodeMetrics
     *
     * @struct
     * @stability external
     */
    interface StagePerNodeMetricsProps {
        /**
         * The ClusterIdentifier dimension
         */
        readonly clusterIdentifier: string;
        /**
         * The stage dimension
         */
        readonly stage: string;
        /**
         * The NodeID dimension
         */
        readonly nodeId: string;
    }
    /**
     * Metrics for dimension set: Stage {ClusterIdentifier, stage}
     *
     * @stability external
     */
    class StageMetrics {
        private readonly dimensions;
        constructor(props: RedshiftMetrics.StageMetricsProps);
        /**
         * Average of the QueryRuntimeBreakdown metric
         *
         * @default - Average over 5 minutes
         */
        queryRuntimeBreakdown(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for StageMetrics
     *
     * @struct
     * @stability external
     */
    interface StageMetricsProps {
        /**
         * The ClusterIdentifier dimension
         */
        readonly clusterIdentifier: string;
        /**
         * The stage dimension
         */
        readonly stage: string;
    }
    /**
     * Metrics for dimension set: Latency {ClusterIdentifier, latency}
     *
     * @stability external
     */
    class LatencyMetrics {
        private readonly dimensions;
        constructor(props: RedshiftMetrics.LatencyMetricsProps);
        /**
         * Average of the QueriesCompletedPerSecond metric
         *
         * @default - Average over 5 minutes
         */
        queriesCompletedPerSecond(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the QueryDuration metric
         *
         * @default - Average over 5 minutes
         */
        queryDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for LatencyMetrics
     *
     * @struct
     * @stability external
     */
    interface LatencyMetricsProps {
        /**
         * The ClusterIdentifier dimension
         */
        readonly clusterIdentifier: string;
        /**
         * The latency dimension
         */
        readonly latency: string;
    }
    /**
     * Metrics for dimension set: LatencyPerNode {ClusterIdentifier, latency, NodeID}
     *
     * @stability external
     */
    class LatencyPerNodeMetrics {
        private readonly dimensions;
        constructor(props: RedshiftMetrics.LatencyPerNodeMetricsProps);
        /**
         * Average of the QueriesCompletedPerSecond metric
         *
         * @default - Average over 5 minutes
         */
        queriesCompletedPerSecond(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the QueryDuration metric
         *
         * @default - Average over 5 minutes
         */
        queryDuration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for LatencyPerNodeMetrics
     *
     * @struct
     * @stability external
     */
    interface LatencyPerNodeMetricsProps {
        /**
         * The ClusterIdentifier dimension
         */
        readonly clusterIdentifier: string;
        /**
         * The latency dimension
         */
        readonly latency: string;
        /**
         * The NodeID dimension
         */
        readonly nodeId: string;
    }
}
