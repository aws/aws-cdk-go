import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IProjectRef } from "aws-cdk-lib/aws-codebuild";
/**
 * CloudWatch metrics facade for AWS/CodeBuild
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class CodeBuildMetrics {
    /**
     * Create ProjectMetrics from a Project reference
     */
    static fromProject(ref: IProjectRef): CodeBuildMetrics.ProjectMetrics;
}
export declare namespace CodeBuildMetrics {
    /**
     * Metrics for dimension set: Project {ProjectName}
     *
     * @stability external
     */
    class ProjectMetrics {
        private readonly dimensions;
        constructor(props: CodeBuildMetrics.ProjectMetricsProps);
        /**
         * Sum of the SucceededBuilds metric
         *
         * @default - Sum over 5 minutes
         */
        succeededBuilds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FailedBuilds metric
         *
         * @default - Sum over 5 minutes
         */
        failedBuilds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Builds metric
         *
         * @default - Sum over 5 minutes
         */
        builds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the Duration metric
         *
         * @default - Average over 5 minutes
         */
        duration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ProjectMetrics
     *
     * @struct
     * @stability external
     */
    interface ProjectMetricsProps {
        /**
         * The ProjectName dimension
         */
        readonly projectName: string;
    }
}
