import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IStreamRef } from "aws-cdk-lib/aws-kinesisvideo";
/**
 * CloudWatch metrics facade for AWS/KinesisVideo
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class KinesisVideoMetrics {
    /**
     * Create StreamMetrics from a Stream reference
     */
    static fromStream(ref: IStreamRef): KinesisVideoMetrics.StreamMetrics;
}
export declare namespace KinesisVideoMetrics {
    /**
     * Metrics for dimension set: Stream {StreamName}
     *
     * @stability external
     */
    class StreamMetrics {
        private readonly dimensions;
        constructor(props: KinesisVideoMetrics.StreamMetricsProps);
        /**
         * Sum of the GetMedia.Success metric
         *
         * @default - Sum over 5 minutes
         */
        getMediaSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PutMedia.Success metric
         *
         * @default - Sum over 5 minutes
         */
        putMediaSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the GetMedia.MillisBehindNow metric
         *
         * @default - Sum over 5 minutes
         */
        getMediaMillisBehindNow(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ListFragments.Latency metric
         *
         * @default - Sum over 5 minutes
         */
        listFragmentsLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PutMedia.FragmentIngestionLatency metric
         *
         * @default - Sum over 5 minutes
         */
        putMediaFragmentIngestionLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PutMedia.FragmentPersistLatency metric
         *
         * @default - Sum over 5 minutes
         */
        putMediaFragmentPersistLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PutMedia.IncomingBytes metric
         *
         * @default - Sum over 5 minutes
         */
        putMediaIncomingBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the PutMedia.IncomingFrames metric
         *
         * @default - Sum over 5 minutes
         */
        putMediaIncomingFrames(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for StreamMetrics
     *
     * @struct
     * @stability external
     */
    interface StreamMetricsProps {
        /**
         * The StreamName dimension
         */
        readonly streamName: string;
    }
}
