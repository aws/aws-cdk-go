import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IFileSystemRef } from "aws-cdk-lib/aws-efs";
/**
 * CloudWatch metrics facade for AWS/EFS
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class EFSMetrics {
    /**
     * Create FileSystemMetrics from a FileSystem reference
     */
    static fromFileSystem(ref: IFileSystemRef): EFSMetrics.FileSystemMetrics;
}
export declare namespace EFSMetrics {
    /**
     * Metrics for dimension set: FileSystem {FileSystemId}
     *
     * @stability external
     */
    class FileSystemMetrics {
        private readonly dimensions;
        constructor(props: EFSMetrics.FileSystemMetricsProps);
        /**
         * Average of the BurstCreditBalance metric
         *
         * @default - Average over 5 minutes
         */
        burstCreditBalance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ClientConnections metric
         *
         * @default - Sum over 5 minutes
         */
        clientConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DataReadIOBytes metric
         *
         * @default - Average over 5 minutes
         */
        dataReadIoBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DataWriteIOBytes metric
         *
         * @default - Average over 5 minutes
         */
        dataWriteIoBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MetadataIOBytes metric
         *
         * @default - Average over 5 minutes
         */
        metadataIoBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MeteredIOBytes metric
         *
         * @default - Average over 5 minutes
         */
        meteredIoBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PercentIOLimit metric
         *
         * @default - Average over 5 minutes
         */
        percentIoLimit(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PermittedThroughput metric
         *
         * @default - Average over 5 minutes
         */
        permittedThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TotalIOBytes metric
         *
         * @default - Sum over 5 minutes
         */
        totalIoBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for FileSystemMetrics
     *
     * @struct
     * @stability external
     */
    interface FileSystemMetricsProps {
        /**
         * The FileSystemId dimension
         */
        readonly fileSystemId: string;
    }
    /**
     * Metrics for dimension set: StorageClass {FileSystemId, StorageClass}
     *
     * @stability external
     */
    class StorageClassMetrics {
        private readonly dimensions;
        constructor(props: EFSMetrics.StorageClassMetricsProps);
        /**
         * Average of the StorageBytes metric
         *
         * @default - Average over 5 minutes
         */
        storageBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for StorageClassMetrics
     *
     * @struct
     * @stability external
     */
    interface StorageClassMetricsProps {
        /**
         * The FileSystemId dimension
         */
        readonly fileSystemId: string;
        /**
         * The StorageClass dimension
         */
        readonly storageClass: EFSMetrics.StorageClassMetricsStorageClass;
    }
    /**
     * Known values for the StorageClass dimension
     */
    enum StorageClassMetricsStorageClass {
        /** StorageClass = Total */
        TOTAL = "Total"
    }
}
