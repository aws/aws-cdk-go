import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/MediaLive
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class MediaLiveMetrics {
}
export declare namespace MediaLiveMetrics {
    /**
     * Metrics for dimension set: Pipeline {ChannelId, Pipeline}
     *
     * @stability external
     */
    class PipelineMetrics {
        private readonly dimensions;
        constructor(props: MediaLiveMetrics.PipelineMetricsProps);
        /**
         * Maximum of the ActiveAlerts metric
         *
         * @default - Maximum over 5 minutes
         */
        activeAlerts(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the InputVideoFrameRate metric
         *
         * @default - Average over 5 minutes
         */
        inputVideoFrameRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FillMsec metric
         *
         * @default - Average over 5 minutes
         */
        fillMsec(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InputLossSeconds metric
         *
         * @default - Sum over 5 minutes
         */
        inputLossSeconds(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RtpPacketsReceived metric
         *
         * @default - Sum over 5 minutes
         */
        rtpPacketsReceived(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RtpPacketsRecoveredViaFec metric
         *
         * @default - Sum over 5 minutes
         */
        rtpPacketsRecoveredViaFec(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RtpPacketsLost metric
         *
         * @default - Sum over 5 minutes
         */
        rtpPacketsLost(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FecRowPacketsReceived metric
         *
         * @default - Sum over 5 minutes
         */
        fecRowPacketsReceived(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FecColumnPacketsReceived metric
         *
         * @default - Sum over 5 minutes
         */
        fecColumnPacketsReceived(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Minimum of the PrimaryInputActive metric
         *
         * @default - Minimum over 5 minutes
         */
        primaryInputActive(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkIn metric
         *
         * @default - Average over 5 minutes
         */
        networkIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkOut metric
         *
         * @default - Average over 5 minutes
         */
        networkOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Minimum of the PipelinesLocked metric
         *
         * @default - Minimum over 5 minutes
         */
        pipelinesLocked(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Minimum of the InputTimecodesPresent metric
         *
         * @default - Minimum over 5 minutes
         */
        inputTimecodesPresent(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for PipelineMetrics
     *
     * @struct
     * @stability external
     */
    interface PipelineMetricsProps {
        /**
         * The ChannelId dimension
         */
        readonly channelId: string;
        /**
         * The Pipeline dimension
         */
        readonly pipeline: string;
    }
}
