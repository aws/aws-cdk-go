import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IDeliveryStreamRef } from "aws-cdk-lib/aws-kinesisfirehose";
/**
 * CloudWatch metrics facade for AWS/Firehose
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class FirehoseMetrics {
    /**
     * Create DeliveryStreamMetrics from a DeliveryStream reference
     */
    static fromDeliveryStream(ref: IDeliveryStreamRef): FirehoseMetrics.DeliveryStreamMetrics;
}
export declare namespace FirehoseMetrics {
    /**
     * Metrics for dimension set: DeliveryStream {DeliveryStreamName}
     *
     * @stability external
     */
    class DeliveryStreamMetrics {
        private readonly dimensions;
        constructor(props: FirehoseMetrics.DeliveryStreamMetricsProps);
        /**
         * Sum of the IncomingBytes metric
         *
         * @default - Sum over 5 minutes
         */
        incomingBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IncomingRecords metric
         *
         * @default - Sum over 5 minutes
         */
        incomingRecords(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BackupToS3.Bytes metric
         *
         * @default - Sum over 5 minutes
         */
        backupToS3Bytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BackupToS3.DataFreshness metric
         *
         * @default - Average over 5 minutes
         */
        backupToS3DataFreshness(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BackupToS3.Records metric
         *
         * @default - Sum over 5 minutes
         */
        backupToS3Records(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BackupToS3.Success metric
         *
         * @default - Sum over 5 minutes
         */
        backupToS3Success(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DataReadFromKinesisStream.Bytes metric
         *
         * @default - Sum over 5 minutes
         */
        dataReadFromKinesisStreamBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DataReadFromKinesisStream.Records metric
         *
         * @default - Sum over 5 minutes
         */
        dataReadFromKinesisStreamRecords(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryToElasticsearch.Bytes metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryToElasticsearchBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryToElasticsearch.Records metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryToElasticsearchRecords(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryToElasticsearch.Success metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryToElasticsearchSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryToRedshift.Bytes metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryToRedshiftBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryToRedshift.Records metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryToRedshiftRecords(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryToRedshift.Success metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryToRedshiftSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryToS3.Bytes metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryToS3Bytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DeliveryToS3.DataFreshness metric
         *
         * @default - Average over 5 minutes
         */
        deliveryToS3DataFreshness(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryToS3.Records metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryToS3Records(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryToS3.Success metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryToS3Success(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryToSplunk.Bytes metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryToSplunkBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DeliveryToSplunk.DataAckLatency metric
         *
         * @default - Average over 5 minutes
         */
        deliveryToSplunkDataAckLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DeliveryToSplunk.DataFreshness metric
         *
         * @default - Average over 5 minutes
         */
        deliveryToSplunkDataFreshness(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryToSplunk.Records metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryToSplunkRecords(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryToSplunk.Success metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryToSplunkSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the KinesisMillisBehindLatest metric
         *
         * @default - Average over 5 minutes
         */
        kinesisMillisBehindLatest(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for DeliveryStreamMetrics
     *
     * @struct
     * @stability external
     */
    interface DeliveryStreamMetricsProps {
        /**
         * The DeliveryStreamName dimension
         */
        readonly deliveryStreamName: string;
    }
}
