import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/Transfer
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class TransferMetrics {
}
export declare namespace TransferMetrics {
    /**
     * Metrics for dimension set: Server {ServerId}
     *
     * @stability external
     */
    class ServerMetrics {
        private readonly dimensions;
        constructor(props: TransferMetrics.ServerMetricsProps);
        /**
         * Sum of the BytesIn metric
         *
         * @default - Sum over 5 minutes
         */
        bytesIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesOut metric
         *
         * @default - Sum over 5 minutes
         */
        bytesOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ServerMetrics
     *
     * @struct
     * @stability external
     */
    interface ServerMetricsProps {
        /**
         * The ServerId dimension
         */
        readonly serverId: string;
    }
}
