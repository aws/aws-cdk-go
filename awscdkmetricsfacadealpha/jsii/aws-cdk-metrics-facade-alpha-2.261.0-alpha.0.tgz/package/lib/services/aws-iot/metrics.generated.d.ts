import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { ITopicRuleRef } from "aws-cdk-lib/aws-iot";
/**
 * CloudWatch metrics facade for AWS/IoT
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class IoTMetrics {
    /**
     * Create RuleMetrics from a TopicRule reference
     */
    static fromTopicRule(ref: ITopicRuleRef): IoTMetrics.RuleMetrics;
}
export declare namespace IoTMetrics {
    /**
     * Metrics for dimension set: Rule {RuleName}
     *
     * @stability external
     */
    class RuleMetrics {
        private readonly dimensions;
        constructor(props: IoTMetrics.RuleMetricsProps);
        /**
         * Sum of the TopicMatch metric
         *
         * @default - Sum over 5 minutes
         */
        topicMatch(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ParseError metric
         *
         * @default - Sum over 5 minutes
         */
        parseError(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RuleEvaluationThrottled metric
         *
         * @default - Sum over 5 minutes
         */
        ruleEvaluationThrottled(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the RuleNotFound metric
         *
         * @default - Sum over 5 minutes
         */
        ruleNotFound(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for RuleMetrics
     *
     * @struct
     * @stability external
     */
    interface RuleMetricsProps {
        /**
         * The RuleName dimension
         */
        readonly ruleName: string;
    }
}
