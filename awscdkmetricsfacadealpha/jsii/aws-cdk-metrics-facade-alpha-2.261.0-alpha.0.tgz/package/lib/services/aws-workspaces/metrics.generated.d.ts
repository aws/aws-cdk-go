import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IWorkspaceRef } from "aws-cdk-lib/aws-workspaces";
/**
 * CloudWatch metrics facade for AWS/WorkSpaces
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class WorkSpacesMetrics {
    /**
     * Create WorkspaceMetrics from a Workspace reference
     */
    static fromWorkspace(ref: IWorkspaceRef): WorkSpacesMetrics.WorkspaceMetrics;
}
export declare namespace WorkSpacesMetrics {
    /**
     * Metrics for dimension set: Workspace {WorkspaceId}
     *
     * @stability external
     */
    class WorkspaceMetrics {
        private readonly dimensions;
        constructor(props: WorkSpacesMetrics.WorkspaceMetricsProps);
        /**
         * Sum of the Available metric
         *
         * @default - Sum over 5 minutes
         */
        available(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Unhealthy metric
         *
         * @default - Sum over 5 minutes
         */
        unhealthy(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionAttempt metric
         *
         * @default - Sum over 5 minutes
         */
        connectionAttempt(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionSuccess metric
         *
         * @default - Sum over 5 minutes
         */
        connectionSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionFailure metric
         *
         * @default - Sum over 5 minutes
         */
        connectionFailure(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SessionLaunchTime metric
         *
         * @default - Average over 5 minutes
         */
        sessionLaunchTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the InSessionLatency metric
         *
         * @default - Average over 5 minutes
         */
        inSessionLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SessionDisconnect metric
         *
         * @default - Sum over 5 minutes
         */
        sessionDisconnect(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the UserConnected metric
         *
         * @default - Sum over 5 minutes
         */
        userConnected(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Stopped metric
         *
         * @default - Sum over 5 minutes
         */
        stopped(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Maintenance metric
         *
         * @default - Sum over 5 minutes
         */
        maintenance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Restoring metric
         *
         * @default - Sum over 5 minutes
         */
        restoring(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUsage metric
         *
         * @default - Average over 5 minutes
         */
        cpuUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryUsage metric
         *
         * @default - Average over 5 minutes
         */
        memoryUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the RootVolumeDiskUsage metric
         *
         * @default - Average over 5 minutes
         */
        rootVolumeDiskUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UserVolumeDiskUsage metric
         *
         * @default - Average over 5 minutes
         */
        userVolumeDiskUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UDPPacketLossRate metric
         *
         * @default - Average over 5 minutes
         */
        udpPacketLossRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the UpTime metric
         *
         * @default - Maximum over 5 minutes
         */
        upTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for WorkspaceMetrics
     *
     * @struct
     * @stability external
     */
    interface WorkspaceMetricsProps {
        /**
         * The WorkspaceId dimension
         */
        readonly workspaceId: string;
    }
    /**
     * Metrics for dimension set: RunningMode {RunningMode}
     *
     * @stability external
     */
    class RunningModeMetrics {
        private readonly dimensions;
        constructor(props: WorkSpacesMetrics.RunningModeMetricsProps);
        /**
         * Sum of the Available metric
         *
         * @default - Sum over 5 minutes
         */
        available(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Unhealthy metric
         *
         * @default - Sum over 5 minutes
         */
        unhealthy(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionAttempt metric
         *
         * @default - Sum over 5 minutes
         */
        connectionAttempt(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionSuccess metric
         *
         * @default - Sum over 5 minutes
         */
        connectionSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionFailure metric
         *
         * @default - Sum over 5 minutes
         */
        connectionFailure(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SessionLaunchTime metric
         *
         * @default - Average over 5 minutes
         */
        sessionLaunchTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the InSessionLatency metric
         *
         * @default - Average over 5 minutes
         */
        inSessionLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SessionDisconnect metric
         *
         * @default - Sum over 5 minutes
         */
        sessionDisconnect(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the UserConnected metric
         *
         * @default - Sum over 5 minutes
         */
        userConnected(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Stopped metric
         *
         * @default - Sum over 5 minutes
         */
        stopped(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Maintenance metric
         *
         * @default - Sum over 5 minutes
         */
        maintenance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Restoring metric
         *
         * @default - Sum over 5 minutes
         */
        restoring(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUsage metric
         *
         * @default - Average over 5 minutes
         */
        cpuUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryUsage metric
         *
         * @default - Average over 5 minutes
         */
        memoryUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the RootVolumeDiskUsage metric
         *
         * @default - Average over 5 minutes
         */
        rootVolumeDiskUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UserVolumeDiskUsage metric
         *
         * @default - Average over 5 minutes
         */
        userVolumeDiskUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UDPPacketLossRate metric
         *
         * @default - Average over 5 minutes
         */
        udpPacketLossRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the UpTime metric
         *
         * @default - Maximum over 5 minutes
         */
        upTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for RunningModeMetrics
     *
     * @struct
     * @stability external
     */
    interface RunningModeMetricsProps {
        /**
         * The RunningMode dimension
         */
        readonly runningMode: string;
    }
    /**
     * Metrics for dimension set: Protocol {Protocol}
     *
     * @stability external
     */
    class ProtocolMetrics {
        private readonly dimensions;
        constructor(props: WorkSpacesMetrics.ProtocolMetricsProps);
        /**
         * Sum of the Available metric
         *
         * @default - Sum over 5 minutes
         */
        available(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Unhealthy metric
         *
         * @default - Sum over 5 minutes
         */
        unhealthy(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionAttempt metric
         *
         * @default - Sum over 5 minutes
         */
        connectionAttempt(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionSuccess metric
         *
         * @default - Sum over 5 minutes
         */
        connectionSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionFailure metric
         *
         * @default - Sum over 5 minutes
         */
        connectionFailure(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SessionLaunchTime metric
         *
         * @default - Average over 5 minutes
         */
        sessionLaunchTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the InSessionLatency metric
         *
         * @default - Average over 5 minutes
         */
        inSessionLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SessionDisconnect metric
         *
         * @default - Sum over 5 minutes
         */
        sessionDisconnect(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the UserConnected metric
         *
         * @default - Sum over 5 minutes
         */
        userConnected(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Stopped metric
         *
         * @default - Sum over 5 minutes
         */
        stopped(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Maintenance metric
         *
         * @default - Sum over 5 minutes
         */
        maintenance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Restoring metric
         *
         * @default - Sum over 5 minutes
         */
        restoring(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUsage metric
         *
         * @default - Average over 5 minutes
         */
        cpuUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryUsage metric
         *
         * @default - Average over 5 minutes
         */
        memoryUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the RootVolumeDiskUsage metric
         *
         * @default - Average over 5 minutes
         */
        rootVolumeDiskUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UserVolumeDiskUsage metric
         *
         * @default - Average over 5 minutes
         */
        userVolumeDiskUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UDPPacketLossRate metric
         *
         * @default - Average over 5 minutes
         */
        udpPacketLossRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the UpTime metric
         *
         * @default - Maximum over 5 minutes
         */
        upTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ProtocolMetrics
     *
     * @struct
     * @stability external
     */
    interface ProtocolMetricsProps {
        /**
         * The Protocol dimension
         */
        readonly protocol: string;
    }
    /**
     * Metrics for dimension set: ComputeType {ComputeType}
     *
     * @stability external
     */
    class ComputeTypeMetrics {
        private readonly dimensions;
        constructor(props: WorkSpacesMetrics.ComputeTypeMetricsProps);
        /**
         * Sum of the Available metric
         *
         * @default - Sum over 5 minutes
         */
        available(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Unhealthy metric
         *
         * @default - Sum over 5 minutes
         */
        unhealthy(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionAttempt metric
         *
         * @default - Sum over 5 minutes
         */
        connectionAttempt(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionSuccess metric
         *
         * @default - Sum over 5 minutes
         */
        connectionSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionFailure metric
         *
         * @default - Sum over 5 minutes
         */
        connectionFailure(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SessionLaunchTime metric
         *
         * @default - Average over 5 minutes
         */
        sessionLaunchTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the InSessionLatency metric
         *
         * @default - Average over 5 minutes
         */
        inSessionLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SessionDisconnect metric
         *
         * @default - Sum over 5 minutes
         */
        sessionDisconnect(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the UserConnected metric
         *
         * @default - Sum over 5 minutes
         */
        userConnected(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Stopped metric
         *
         * @default - Sum over 5 minutes
         */
        stopped(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Maintenance metric
         *
         * @default - Sum over 5 minutes
         */
        maintenance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Restoring metric
         *
         * @default - Sum over 5 minutes
         */
        restoring(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUsage metric
         *
         * @default - Average over 5 minutes
         */
        cpuUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryUsage metric
         *
         * @default - Average over 5 minutes
         */
        memoryUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the RootVolumeDiskUsage metric
         *
         * @default - Average over 5 minutes
         */
        rootVolumeDiskUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UserVolumeDiskUsage metric
         *
         * @default - Average over 5 minutes
         */
        userVolumeDiskUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UDPPacketLossRate metric
         *
         * @default - Average over 5 minutes
         */
        udpPacketLossRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the UpTime metric
         *
         * @default - Maximum over 5 minutes
         */
        upTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ComputeTypeMetrics
     *
     * @struct
     * @stability external
     */
    interface ComputeTypeMetricsProps {
        /**
         * The ComputeType dimension
         */
        readonly computeType: string;
    }
    /**
     * Metrics for dimension set: Directory {DirectoryId}
     *
     * @stability external
     */
    class DirectoryMetrics {
        private readonly dimensions;
        constructor(props: WorkSpacesMetrics.DirectoryMetricsProps);
        /**
         * Sum of the Available metric
         *
         * @default - Sum over 5 minutes
         */
        available(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Unhealthy metric
         *
         * @default - Sum over 5 minutes
         */
        unhealthy(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionAttempt metric
         *
         * @default - Sum over 5 minutes
         */
        connectionAttempt(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionSuccess metric
         *
         * @default - Sum over 5 minutes
         */
        connectionSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionFailure metric
         *
         * @default - Sum over 5 minutes
         */
        connectionFailure(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SessionLaunchTime metric
         *
         * @default - Average over 5 minutes
         */
        sessionLaunchTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the InSessionLatency metric
         *
         * @default - Average over 5 minutes
         */
        inSessionLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SessionDisconnect metric
         *
         * @default - Sum over 5 minutes
         */
        sessionDisconnect(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the UserConnected metric
         *
         * @default - Sum over 5 minutes
         */
        userConnected(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Stopped metric
         *
         * @default - Sum over 5 minutes
         */
        stopped(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Maintenance metric
         *
         * @default - Sum over 5 minutes
         */
        maintenance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Restoring metric
         *
         * @default - Sum over 5 minutes
         */
        restoring(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUsage metric
         *
         * @default - Average over 5 minutes
         */
        cpuUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryUsage metric
         *
         * @default - Average over 5 minutes
         */
        memoryUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the RootVolumeDiskUsage metric
         *
         * @default - Average over 5 minutes
         */
        rootVolumeDiskUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UserVolumeDiskUsage metric
         *
         * @default - Average over 5 minutes
         */
        userVolumeDiskUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UDPPacketLossRate metric
         *
         * @default - Average over 5 minutes
         */
        udpPacketLossRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the UpTime metric
         *
         * @default - Maximum over 5 minutes
         */
        upTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TrustedDeviceValidationAttempt metric
         *
         * @default - Sum over 5 minutes
         */
        trustedDeviceValidationAttempt(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TrustedDeviceValidationSuccess metric
         *
         * @default - Sum over 5 minutes
         */
        trustedDeviceValidationSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TrustedDeviceValidationFailure metric
         *
         * @default - Sum over 5 minutes
         */
        trustedDeviceValidationFailure(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for DirectoryMetrics
     *
     * @struct
     * @stability external
     */
    interface DirectoryMetricsProps {
        /**
         * The DirectoryId dimension
         */
        readonly directoryId: string;
    }
    /**
     * Metrics for dimension set: Bundle {BundleId}
     *
     * @stability external
     */
    class BundleMetrics {
        private readonly dimensions;
        constructor(props: WorkSpacesMetrics.BundleMetricsProps);
        /**
         * Sum of the Available metric
         *
         * @default - Sum over 5 minutes
         */
        available(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Unhealthy metric
         *
         * @default - Sum over 5 minutes
         */
        unhealthy(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionAttempt metric
         *
         * @default - Sum over 5 minutes
         */
        connectionAttempt(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionSuccess metric
         *
         * @default - Sum over 5 minutes
         */
        connectionSuccess(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConnectionFailure metric
         *
         * @default - Sum over 5 minutes
         */
        connectionFailure(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SessionLaunchTime metric
         *
         * @default - Average over 5 minutes
         */
        sessionLaunchTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the InSessionLatency metric
         *
         * @default - Average over 5 minutes
         */
        inSessionLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SessionDisconnect metric
         *
         * @default - Sum over 5 minutes
         */
        sessionDisconnect(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the UserConnected metric
         *
         * @default - Sum over 5 minutes
         */
        userConnected(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Stopped metric
         *
         * @default - Sum over 5 minutes
         */
        stopped(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Maintenance metric
         *
         * @default - Sum over 5 minutes
         */
        maintenance(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Restoring metric
         *
         * @default - Sum over 5 minutes
         */
        restoring(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUsage metric
         *
         * @default - Average over 5 minutes
         */
        cpuUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryUsage metric
         *
         * @default - Average over 5 minutes
         */
        memoryUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the RootVolumeDiskUsage metric
         *
         * @default - Average over 5 minutes
         */
        rootVolumeDiskUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UserVolumeDiskUsage metric
         *
         * @default - Average over 5 minutes
         */
        userVolumeDiskUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the UDPPacketLossRate metric
         *
         * @default - Average over 5 minutes
         */
        udpPacketLossRate(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the UpTime metric
         *
         * @default - Maximum over 5 minutes
         */
        upTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for BundleMetrics
     *
     * @struct
     * @stability external
     */
    interface BundleMetricsProps {
        /**
         * The BundleId dimension
         */
        readonly bundleId: string;
    }
    /**
     * Metrics for dimension set: Certificate {CertificateId}
     *
     * @stability external
     */
    class CertificateMetrics {
        private readonly dimensions;
        constructor(props: WorkSpacesMetrics.CertificateMetricsProps);
        /**
         * Sum of the TrustedDeviceCertificateDaysBeforeExpiration metric
         *
         * @default - Sum over 5 minutes
         */
        trustedDeviceCertificateDaysBeforeExpiration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for CertificateMetrics
     *
     * @struct
     * @stability external
     */
    interface CertificateMetricsProps {
        /**
         * The CertificateId dimension
         */
        readonly certificateId: string;
    }
}
