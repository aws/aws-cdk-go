import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/Timestream
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class TimestreamMetrics {
}
export declare namespace TimestreamMetrics {
    /**
     * Metrics for dimension set: Table {Operation, DatabaseName, TableName}
     *
     * @stability external
     */
    class TableMetrics {
        private readonly dimensions;
        constructor(props: TimestreamMetrics.TableMetricsProps);
        /**
         * SampleCount of the SuccessfulRequestLatency metric
         *
         * @default - SampleCount over 5 minutes
         */
        successfulRequestLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for TableMetrics
     *
     * @struct
     * @stability external
     */
    interface TableMetricsProps {
        /**
         * The Operation dimension
         */
        readonly operation: TimestreamMetrics.TableMetricsOperation;
        /**
         * The DatabaseName dimension
         */
        readonly databaseName: string;
        /**
         * The TableName dimension
         */
        readonly tableName: string;
    }
    /**
     * Known values for the Operation dimension
     */
    enum TableMetricsOperation {
        /** Operation = WriteRecords */
        WRITE_RECORDS = "WriteRecords"
    }
}
