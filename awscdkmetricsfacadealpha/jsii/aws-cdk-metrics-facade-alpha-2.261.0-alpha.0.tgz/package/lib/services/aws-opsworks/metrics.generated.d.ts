import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IInstanceRef, ILayerRef, IStackRef } from "aws-cdk-lib/aws-opsworks";
/**
 * CloudWatch metrics facade for AWS/OpsWorks
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class OpsWorksMetrics {
    /**
     * Create InstanceMetrics from a Instance reference
     */
    static fromInstance(ref: IInstanceRef): OpsWorksMetrics.InstanceMetrics;
    /**
     * Create LayerMetrics from a Layer reference
     */
    static fromLayer(ref: ILayerRef): OpsWorksMetrics.LayerMetrics;
    /**
     * Create StackMetrics from a Stack reference
     */
    static fromStack(ref: IStackRef): OpsWorksMetrics.StackMetrics;
}
export declare namespace OpsWorksMetrics {
    /**
     * Metrics for dimension set: Instance {InstanceId}
     *
     * @stability external
     */
    class InstanceMetrics {
        private readonly dimensions;
        constructor(props: OpsWorksMetrics.InstanceMetricsProps);
        /**
         * Average of the procs metric
         *
         * @default - Average over 5 minutes
         */
        procs(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_used metric
         *
         * @default - Average over 5 minutes
         */
        memoryUsed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_idle metric
         *
         * @default - Average over 5 minutes
         */
        cpuIdle(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_nice metric
         *
         * @default - Average over 5 minutes
         */
        cpuNice(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_steal metric
         *
         * @default - Average over 5 minutes
         */
        cpuSteal(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_system metric
         *
         * @default - Average over 5 minutes
         */
        cpuSystem(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_user metric
         *
         * @default - Average over 5 minutes
         */
        cpuUser(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_waitio metric
         *
         * @default - Average over 5 minutes
         */
        cpuWaitio(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the load_1 metric
         *
         * @default - Average over 5 minutes
         */
        load1(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the load_15 metric
         *
         * @default - Average over 5 minutes
         */
        load15(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the load_5 metric
         *
         * @default - Average over 5 minutes
         */
        load5(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_buffers metric
         *
         * @default - Average over 5 minutes
         */
        memoryBuffers(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_cached metric
         *
         * @default - Average over 5 minutes
         */
        memoryCached(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_free metric
         *
         * @default - Average over 5 minutes
         */
        memoryFree(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_swap metric
         *
         * @default - Average over 5 minutes
         */
        memorySwap(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_total metric
         *
         * @default - Average over 5 minutes
         */
        memoryTotal(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for InstanceMetrics
     *
     * @struct
     * @stability external
     */
    interface InstanceMetricsProps {
        /**
         * The InstanceId dimension
         */
        readonly instanceId: string;
    }
    /**
     * Metrics for dimension set: Layer {LayerId}
     *
     * @stability external
     */
    class LayerMetrics {
        private readonly dimensions;
        constructor(props: OpsWorksMetrics.LayerMetricsProps);
        /**
         * Average of the procs metric
         *
         * @default - Average over 5 minutes
         */
        procs(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_used metric
         *
         * @default - Average over 5 minutes
         */
        memoryUsed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_idle metric
         *
         * @default - Average over 5 minutes
         */
        cpuIdle(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_nice metric
         *
         * @default - Average over 5 minutes
         */
        cpuNice(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_steal metric
         *
         * @default - Average over 5 minutes
         */
        cpuSteal(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_system metric
         *
         * @default - Average over 5 minutes
         */
        cpuSystem(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_user metric
         *
         * @default - Average over 5 minutes
         */
        cpuUser(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_waitio metric
         *
         * @default - Average over 5 minutes
         */
        cpuWaitio(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the load_1 metric
         *
         * @default - Average over 5 minutes
         */
        load1(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the load_15 metric
         *
         * @default - Average over 5 minutes
         */
        load15(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the load_5 metric
         *
         * @default - Average over 5 minutes
         */
        load5(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_buffers metric
         *
         * @default - Average over 5 minutes
         */
        memoryBuffers(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_cached metric
         *
         * @default - Average over 5 minutes
         */
        memoryCached(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_free metric
         *
         * @default - Average over 5 minutes
         */
        memoryFree(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_swap metric
         *
         * @default - Average over 5 minutes
         */
        memorySwap(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_total metric
         *
         * @default - Average over 5 minutes
         */
        memoryTotal(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for LayerMetrics
     *
     * @struct
     * @stability external
     */
    interface LayerMetricsProps {
        /**
         * The LayerId dimension
         */
        readonly layerId: string;
    }
    /**
     * Metrics for dimension set: Stack {StackId}
     *
     * @stability external
     */
    class StackMetrics {
        private readonly dimensions;
        constructor(props: OpsWorksMetrics.StackMetricsProps);
        /**
         * Average of the procs metric
         *
         * @default - Average over 5 minutes
         */
        procs(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_used metric
         *
         * @default - Average over 5 minutes
         */
        memoryUsed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_idle metric
         *
         * @default - Average over 5 minutes
         */
        cpuIdle(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_nice metric
         *
         * @default - Average over 5 minutes
         */
        cpuNice(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_steal metric
         *
         * @default - Average over 5 minutes
         */
        cpuSteal(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_system metric
         *
         * @default - Average over 5 minutes
         */
        cpuSystem(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_user metric
         *
         * @default - Average over 5 minutes
         */
        cpuUser(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the cpu_waitio metric
         *
         * @default - Average over 5 minutes
         */
        cpuWaitio(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the load_1 metric
         *
         * @default - Average over 5 minutes
         */
        load1(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the load_15 metric
         *
         * @default - Average over 5 minutes
         */
        load15(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the load_5 metric
         *
         * @default - Average over 5 minutes
         */
        load5(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_buffers metric
         *
         * @default - Average over 5 minutes
         */
        memoryBuffers(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_cached metric
         *
         * @default - Average over 5 minutes
         */
        memoryCached(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_free metric
         *
         * @default - Average over 5 minutes
         */
        memoryFree(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_swap metric
         *
         * @default - Average over 5 minutes
         */
        memorySwap(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the memory_total metric
         *
         * @default - Average over 5 minutes
         */
        memoryTotal(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for StackMetrics
     *
     * @struct
     * @stability external
     */
    interface StackMetricsProps {
        /**
         * The StackId dimension
         */
        readonly stackId: string;
    }
}
