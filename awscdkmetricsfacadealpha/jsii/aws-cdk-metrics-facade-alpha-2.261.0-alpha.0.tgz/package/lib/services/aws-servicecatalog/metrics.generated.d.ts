import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/ServiceCatalog
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class ServiceCatalogMetrics {
}
export declare namespace ServiceCatalogMetrics {
    /**
     * Metrics for dimension set: Product {ProductId}
     *
     * @stability external
     */
    class ProductMetrics {
        private readonly dimensions;
        constructor(props: ServiceCatalogMetrics.ProductMetricsProps);
        /**
         * Sum of the ProvisionedProductLaunch metric
         *
         * @default - Sum over 5 minutes
         */
        provisionedProductLaunch(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ProductMetrics
     *
     * @struct
     * @stability external
     */
    interface ProductMetricsProps {
        /**
         * The ProductId dimension
         */
        readonly productId: string;
    }
}
