import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/QLDB
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class QLDBMetrics {
}
export declare namespace QLDBMetrics {
    /**
     * Metrics for dimension set: Ledger {LedgerName}
     *
     * @stability external
     */
    class LedgerMetrics {
        private readonly dimensions;
        constructor(props: QLDBMetrics.LedgerMetricsProps);
        /**
         * Average of the CommandLatency metric
         *
         * @default - Average over 5 minutes
         */
        commandLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the JournalStorage metric
         *
         * @default - Sum over 5 minutes
         */
        journalStorage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IndexedStorage metric
         *
         * @default - Sum over 5 minutes
         */
        indexedStorage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IsImpaired metric
         *
         * @default - Sum over 5 minutes
         */
        isImpaired(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the OccConflictExceptions metric
         *
         * @default - Sum over 5 minutes
         */
        occConflictExceptions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ReadIOs metric
         *
         * @default - Sum over 5 minutes
         */
        readIOs(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Session4xxExceptions metric
         *
         * @default - Sum over 5 minutes
         */
        session4xxExceptions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Session5xxExceptions metric
         *
         * @default - Sum over 5 minutes
         */
        session5xxExceptions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SessionRateExceededExceptions metric
         *
         * @default - Sum over 5 minutes
         */
        sessionRateExceededExceptions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the WriteIOs metric
         *
         * @default - Sum over 5 minutes
         */
        writeIOs(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for LedgerMetrics
     *
     * @struct
     * @stability external
     */
    interface LedgerMetricsProps {
        /**
         * The LedgerName dimension
         */
        readonly ledgerName: string;
    }
}
