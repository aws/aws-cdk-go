import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IDashboardRef } from "aws-cdk-lib/aws-quicksight";
/**
 * CloudWatch metrics facade for AWS/QuickSight
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class QuickSightMetrics {
    /**
     * Create DashboardMetrics from a Dashboard reference
     */
    static fromDashboard(ref: IDashboardRef): QuickSightMetrics.DashboardMetrics;
}
export declare namespace QuickSightMetrics {
    /**
     * Metrics for dimension set: Account {no dimensions}
     *
     * @stability external
     */
    class AccountMetrics {
        private readonly dimensions;
        constructor();
        /**
         * Sum of the DashboardViewCount metric
         *
         * @default - Sum over 5 minutes
         */
        dashboardViewCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DashboardViewLoadTime metric
         *
         * @default - Average over 5 minutes
         */
        dashboardViewLoadTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IngestionErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        ingestionErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IngestionInvocationCount metric
         *
         * @default - Sum over 5 minutes
         */
        ingestionInvocationCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IngestionLatency metric
         *
         * @default - Average over 5 minutes
         */
        ingestionLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IngestionRowCount metric
         *
         * @default - Sum over 5 minutes
         */
        ingestionRowCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SPICECapacityConsumedInMB metric
         *
         * @default - Average over 5 minutes
         */
        spiceCapacityConsumedInMb(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SPICECapacityLimitInMB metric
         *
         * @default - Average over 5 minutes
         */
        spiceCapacityLimitInMb(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the VisualLoadTime metric
         *
         * @default - Average over 5 minutes
         */
        visualLoadTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the VisualLoadErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        visualLoadErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Metrics for dimension set: Dashboard {DashboardId}
     *
     * @stability external
     */
    class DashboardMetrics {
        private readonly dimensions;
        constructor(props: QuickSightMetrics.DashboardMetricsProps);
        /**
         * Sum of the DashboardViewCount metric
         *
         * @default - Sum over 5 minutes
         */
        dashboardViewCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DashboardViewLoadTime metric
         *
         * @default - Average over 5 minutes
         */
        dashboardViewLoadTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the VisualLoadTime metric
         *
         * @default - Average over 5 minutes
         */
        visualLoadTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the VisualLoadErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        visualLoadErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for DashboardMetrics
     *
     * @struct
     * @stability external
     */
    interface DashboardMetricsProps {
        /**
         * The DashboardId dimension
         */
        readonly dashboardId: string;
    }
    /**
     * Metrics for dimension set: Ingestion {DatasetId}
     *
     * @stability external
     */
    class IngestionMetrics {
        private readonly dimensions;
        constructor(props: QuickSightMetrics.IngestionMetricsProps);
        /**
         * Sum of the IngestionErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        ingestionErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IngestionInvocationCount metric
         *
         * @default - Sum over 5 minutes
         */
        ingestionInvocationCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IngestionLatency metric
         *
         * @default - Average over 5 minutes
         */
        ingestionLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IngestionRowCount metric
         *
         * @default - Sum over 5 minutes
         */
        ingestionRowCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for IngestionMetrics
     *
     * @struct
     * @stability external
     */
    interface IngestionMetricsProps {
        /**
         * The DatasetId dimension
         */
        readonly datasetId: string;
    }
    /**
     * Metrics for dimension set: Visual {DashboardId, SheetId, VisualId}
     *
     * @stability external
     */
    class VisualMetrics {
        private readonly dimensions;
        constructor(props: QuickSightMetrics.VisualMetricsProps);
        /**
         * Average of the VisualLoadTime metric
         *
         * @default - Average over 5 minutes
         */
        visualLoadTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the VisualLoadErrorCount metric
         *
         * @default - Sum over 5 minutes
         */
        visualLoadErrorCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for VisualMetrics
     *
     * @struct
     * @stability external
     */
    interface VisualMetricsProps {
        /**
         * The DashboardId dimension
         */
        readonly dashboardId: string;
        /**
         * The SheetId dimension
         */
        readonly sheetId: string;
        /**
         * The VisualId dimension
         */
        readonly visualId: string;
    }
}
