import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/MediaPackage
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class MediaPackageMetrics {
}
export declare namespace MediaPackageMetrics {
    /**
     * Metrics for dimension set: Channel {Channel}
     *
     * @stability external
     */
    class ChannelMetrics {
        private readonly dimensions;
        constructor(props: MediaPackageMetrics.ChannelMetricsProps);
        /**
         * Sum of the EgressRequestCount metric
         *
         * @default - Sum over 5 minutes
         */
        egressRequestCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EgressResponseTime metric
         *
         * @default - Average over 5 minutes
         */
        egressResponseTime(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the EgressBytes metric
         *
         * @default - Sum over 5 minutes
         */
        egressBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ChannelMetrics
     *
     * @struct
     * @stability external
     */
    interface ChannelMetricsProps {
        /**
         * The Channel dimension
         */
        readonly channel: string;
    }
}
