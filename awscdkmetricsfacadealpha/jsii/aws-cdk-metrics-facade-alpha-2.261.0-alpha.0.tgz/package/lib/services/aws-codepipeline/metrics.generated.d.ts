import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/CodePipeline
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class CodePipelineMetrics {
}
export declare namespace CodePipelineMetrics {
    /**
     * Metrics for dimension set: Account {no dimensions}
     *
     * @stability external
     */
    class AccountMetrics {
        private readonly dimensions;
        constructor();
        /**
         * Sum of the FailedPipelineExecutions metric
         *
         * @default - Sum over 5 minutes
         */
        failedPipelineExecutions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
}
