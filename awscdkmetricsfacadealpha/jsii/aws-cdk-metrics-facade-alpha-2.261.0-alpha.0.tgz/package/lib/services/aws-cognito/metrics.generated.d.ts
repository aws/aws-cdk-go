import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/Cognito
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class CognitoMetrics {
}
export declare namespace CognitoMetrics {
    /**
     * Metrics for dimension set: RequestClassification {Operation, UserPoolId}
     *
     * @stability external
     */
    class RequestClassificationMetrics {
        private readonly dimensions;
        constructor(props: CognitoMetrics.RequestClassificationMetricsProps);
        /**
         * Sum of the NoRisk metric
         *
         * @default - Sum over 5 minutes
         */
        noRisk(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Risk metric
         *
         * @default - Sum over 5 minutes
         */
        risk(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for RequestClassificationMetrics
     *
     * @struct
     * @stability external
     */
    interface RequestClassificationMetricsProps {
        /**
         * The Operation dimension
         */
        readonly operation: string;
        /**
         * The UserPoolId dimension
         */
        readonly userPoolId: string;
    }
}
