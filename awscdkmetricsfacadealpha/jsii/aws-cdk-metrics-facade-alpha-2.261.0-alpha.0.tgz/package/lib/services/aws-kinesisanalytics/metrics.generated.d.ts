import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/KinesisAnalytics
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class KinesisAnalyticsMetrics {
}
export declare namespace KinesisAnalyticsMetrics {
    /**
     * Metrics for dimension set: Application {Application}
     *
     * @stability external
     */
    class ApplicationMetrics {
        private readonly dimensions;
        constructor(props: KinesisAnalyticsMetrics.ApplicationMetricsProps);
        /**
         * Average of the KPUs metric
         *
         * @default - Average over 5 minutes
         */
        kpUs(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ApplicationMetrics
     *
     * @struct
     * @stability external
     */
    interface ApplicationMetricsProps {
        /**
         * The Application dimension
         */
        readonly application: string;
    }
}
