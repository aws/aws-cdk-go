import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IKeyRef } from "aws-cdk-lib/aws-kms";
/**
 * CloudWatch metrics facade for AWS/KMS
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class KMSMetrics {
    /**
     * Create KeyMetrics from a Key reference
     */
    static fromKey(ref: IKeyRef): KMSMetrics.KeyMetrics;
}
export declare namespace KMSMetrics {
    /**
     * Metrics for dimension set: Key {KeyId}
     *
     * @stability external
     */
    class KeyMetrics {
        private readonly dimensions;
        constructor(props: KMSMetrics.KeyMetricsProps);
        /**
         * Average of the SecondsUntilKeyMaterialExpiration metric
         *
         * @default - Average over 5 minutes
         */
        secondsUntilKeyMaterialExpiration(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for KeyMetrics
     *
     * @struct
     * @stability external
     */
    interface KeyMetricsProps {
        /**
         * The KeyId dimension
         */
        readonly keyId: string;
    }
}
