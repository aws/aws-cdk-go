import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { ITableRef } from "aws-cdk-lib/aws-dynamodb";
/**
 * CloudWatch metrics facade for AWS/DynamoDB
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class DynamoDBMetrics {
    /**
     * Create TableMetrics from a Table reference
     */
    static fromTable(ref: ITableRef): DynamoDBMetrics.TableMetrics;
}
export declare namespace DynamoDBMetrics {
    /**
     * Metrics for dimension set: Table {TableName}
     *
     * @stability external
     */
    class TableMetrics {
        private readonly dimensions;
        constructor(props: DynamoDBMetrics.TableMetricsProps);
        /**
         * Sum of the ConditionalCheckFailedRequests metric
         *
         * @default - Sum over 5 minutes
         */
        conditionalCheckFailedRequests(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConsumedReadCapacityUnits metric
         *
         * @default - Sum over 5 minutes
         */
        consumedReadCapacityUnits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConsumedWriteCapacityUnits metric
         *
         * @default - Sum over 5 minutes
         */
        consumedWriteCapacityUnits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ProvisionedReadCapacityUnits metric
         *
         * @default - Average over 5 minutes
         */
        provisionedReadCapacityUnits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ProvisionedWriteCapacityUnits metric
         *
         * @default - Average over 5 minutes
         */
        provisionedWriteCapacityUnits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ReadThrottleEvents metric
         *
         * @default - Sum over 5 minutes
         */
        readThrottleEvents(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TimeToLiveDeletedItemCount metric
         *
         * @default - Sum over 5 minutes
         */
        timeToLiveDeletedItemCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the TransactionConflict metric
         *
         * @default - Average over 5 minutes
         */
        transactionConflict(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the WriteThrottleEvents metric
         *
         * @default - Sum over 5 minutes
         */
        writeThrottleEvents(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for TableMetrics
     *
     * @struct
     * @stability external
     */
    interface TableMetricsProps {
        /**
         * The TableName dimension
         */
        readonly tableName: string;
    }
    /**
     * Metrics for dimension set: GlobalSecondaryIndex {TableName, GlobalSecondaryIndexName}
     *
     * @stability external
     */
    class GlobalSecondaryIndexMetrics {
        private readonly dimensions;
        constructor(props: DynamoDBMetrics.GlobalSecondaryIndexMetricsProps);
        /**
         * Sum of the ConsumedReadCapacityUnits metric
         *
         * @default - Sum over 5 minutes
         */
        consumedReadCapacityUnits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ConsumedWriteCapacityUnits metric
         *
         * @default - Sum over 5 minutes
         */
        consumedWriteCapacityUnits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ProvisionedReadCapacityUnits metric
         *
         * @default - Average over 5 minutes
         */
        provisionedReadCapacityUnits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ProvisionedWriteCapacityUnits metric
         *
         * @default - Average over 5 minutes
         */
        provisionedWriteCapacityUnits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ReadThrottleEvents metric
         *
         * @default - Sum over 5 minutes
         */
        readThrottleEvents(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the WriteThrottleEvents metric
         *
         * @default - Sum over 5 minutes
         */
        writeThrottleEvents(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the OnlineIndexConsumedWriteCapacity metric
         *
         * @default - Sum over 5 minutes
         */
        onlineIndexConsumedWriteCapacity(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the OnlineIndexPercentageProgress metric
         *
         * @default - Average over 5 minutes
         */
        onlineIndexPercentageProgress(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the OnlineIndexThrottleEvents metric
         *
         * @default - Sum over 5 minutes
         */
        onlineIndexThrottleEvents(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for GlobalSecondaryIndexMetrics
     *
     * @struct
     * @stability external
     */
    interface GlobalSecondaryIndexMetricsProps {
        /**
         * The TableName dimension
         */
        readonly tableName: string;
        /**
         * The GlobalSecondaryIndexName dimension
         */
        readonly globalSecondaryIndexName: DynamoDBMetrics.GlobalSecondaryIndexMetricsGlobalSecondaryIndexName;
    }
    /**
     * Known values for the GlobalSecondaryIndexName dimension
     */
    enum GlobalSecondaryIndexMetricsGlobalSecondaryIndexName {
        /** GlobalSecondaryIndexName = GlobalSecondaryIndexName */
        GLOBAL_SECONDARY_INDEX_NAME = "GlobalSecondaryIndexName"
    }
    /**
     * Metrics for dimension set: Operation {TableName, Operation}
     *
     * @stability external
     */
    class OperationMetrics {
        private readonly dimensions;
        constructor(props: DynamoDBMetrics.OperationMetricsProps);
        /**
         * Sum of the ReturnedItemCount metric
         *
         * @default - Sum over 5 minutes
         */
        returnedItemCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SuccessfulRequestLatency metric
         *
         * @default - Average over 5 minutes
         */
        successfulRequestLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the SystemErrors metric
         *
         * @default - Sum over 5 minutes
         */
        systemErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ThrottledRequests metric
         *
         * @default - Sum over 5 minutes
         */
        throttledRequests(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for OperationMetrics
     *
     * @struct
     * @stability external
     */
    interface OperationMetricsProps {
        /**
         * The TableName dimension
         */
        readonly tableName: string;
        /**
         * The Operation dimension
         */
        readonly operation: DynamoDBMetrics.OperationMetricsOperation;
    }
    /**
     * Known values for the Operation dimension
     */
    enum OperationMetricsOperation {
        /** Operation = GetItem */
        GET_ITEM = "GetItem",
        /** Operation = PutItem */
        PUT_ITEM = "PutItem",
        /** Operation = Scan */
        SCAN = "Scan",
        /** Operation = BatchExecuteStatement */
        BATCH_EXECUTE_STATEMENT = "BatchExecuteStatement",
        /** Operation = BatchGetItem */
        BATCH_GET_ITEM = "BatchGetItem",
        /** Operation = BatchWriteItem */
        BATCH_WRITE_ITEM = "BatchWriteItem",
        /** Operation = DeleteItem */
        DELETE_ITEM = "DeleteItem",
        /** Operation = ExecuteStatement */
        EXECUTE_STATEMENT = "ExecuteStatement",
        /** Operation = ExecuteTransaction */
        EXECUTE_TRANSACTION = "ExecuteTransaction",
        /** Operation = Query */
        QUERY = "Query",
        /** Operation = TransactGetItems */
        TRANSACT_GET_ITEMS = "TransactGetItems",
        /** Operation = TransactWriteItems */
        TRANSACT_WRITE_ITEMS = "TransactWriteItems",
        /** Operation = UpdateItem */
        UPDATE_ITEM = "UpdateItem",
        /** Operation = GetRecords */
        GET_RECORDS = "GetRecords"
    }
    /**
     * Metrics for dimension set: DelegatedOperation {TableName, DelegatedOperation}
     *
     * @stability external
     */
    class DelegatedOperationMetrics {
        private readonly dimensions;
        constructor(props: DynamoDBMetrics.DelegatedOperationMetricsProps);
        /**
         * Average of the AgeOfOldestUnreplicatedRecord metric
         *
         * @default - Average over 5 minutes
         */
        ageOfOldestUnreplicatedRecord(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ConsumedChangeDataCaptureUnits metric
         *
         * @default - Average over 5 minutes
         */
        consumedChangeDataCaptureUnits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ThrottledPutRecordCount metric
         *
         * @default - Average over 5 minutes
         */
        throttledPutRecordCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for DelegatedOperationMetrics
     *
     * @struct
     * @stability external
     */
    interface DelegatedOperationMetricsProps {
        /**
         * The TableName dimension
         */
        readonly tableName: string;
        /**
         * The DelegatedOperation dimension
         */
        readonly delegatedOperation: string;
    }
    /**
     * Metrics for dimension set: ReceivingRegion {TableName, ReceivingRegion}
     *
     * @stability external
     */
    class ReceivingRegionMetrics {
        private readonly dimensions;
        constructor(props: DynamoDBMetrics.ReceivingRegionMetricsProps);
        /**
         * Average of the PendingReplicationCount metric
         *
         * @default - Average over 5 minutes
         */
        pendingReplicationCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReplicationLatency metric
         *
         * @default - Average over 5 minutes
         */
        replicationLatency(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ReceivingRegionMetrics
     *
     * @struct
     * @stability external
     */
    interface ReceivingRegionMetricsProps {
        /**
         * The TableName dimension
         */
        readonly tableName: string;
        /**
         * The ReceivingRegion dimension
         */
        readonly receivingRegion: string;
    }
    /**
     * Metrics for dimension set: OperationPerStream {TableName, StreamLabel, Operation}
     *
     * @stability external
     */
    class OperationPerStreamMetrics {
        private readonly dimensions;
        constructor(props: DynamoDBMetrics.OperationPerStreamMetricsProps);
        /**
         * Average of the ReturnedBytes metric
         *
         * @default - Average over 5 minutes
         */
        returnedBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReturnedRecordsCount metric
         *
         * @default - Average over 5 minutes
         */
        returnedRecordsCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for OperationPerStreamMetrics
     *
     * @struct
     * @stability external
     */
    interface OperationPerStreamMetricsProps {
        /**
         * The TableName dimension
         */
        readonly tableName: string;
        /**
         * The StreamLabel dimension
         */
        readonly streamLabel: string;
        /**
         * The Operation dimension
         */
        readonly operation: string;
    }
    /**
     * Metrics for dimension set: Account {no dimensions}
     *
     * @stability external
     */
    class AccountMetrics {
        private readonly dimensions;
        constructor();
        /**
         * Maximum of the AccountMaxReads metric
         *
         * @default - Maximum over 5 minutes
         */
        accountMaxReads(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the AccountMaxTableLevelReads metric
         *
         * @default - Maximum over 5 minutes
         */
        accountMaxTableLevelReads(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the AccountMaxTableLevelWrites metric
         *
         * @default - Maximum over 5 minutes
         */
        accountMaxTableLevelWrites(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the AccountMaxWrites metric
         *
         * @default - Maximum over 5 minutes
         */
        accountMaxWrites(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the AccountProvisionedReadCapacityUtilization metric
         *
         * @default - Average over 5 minutes
         */
        accountProvisionedReadCapacityUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the AccountProvisionedWriteCapacityUtilization metric
         *
         * @default - Average over 5 minutes
         */
        accountProvisionedWriteCapacityUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MaxProvisionedTableReadCapacityUtilization metric
         *
         * @default - Average over 5 minutes
         */
        maxProvisionedTableReadCapacityUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MaxProvisionedTableWriteCapacityUtilization metric
         *
         * @default - Average over 5 minutes
         */
        maxProvisionedTableWriteCapacityUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the UserErrors metric
         *
         * @default - Sum over 5 minutes
         */
        userErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
}
