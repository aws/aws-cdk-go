import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { ILogGroupRef } from "aws-cdk-lib/aws-logs";
/**
 * CloudWatch metrics facade for AWS/Logs
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class LogsMetrics {
    /**
     * Create LogGroupMetrics from a LogGroup reference
     */
    static fromLogGroup(ref: ILogGroupRef): LogsMetrics.LogGroupMetrics;
}
export declare namespace LogsMetrics {
    /**
     * Metrics for dimension set: LogGroup {LogGroupName}
     *
     * @stability external
     */
    class LogGroupMetrics {
        private readonly dimensions;
        constructor(props: LogsMetrics.LogGroupMetricsProps);
        /**
         * Sum of the IncomingLogEvents metric
         *
         * @default - Sum over 5 minutes
         */
        incomingLogEvents(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the IncomingBytes metric
         *
         * @default - Sum over 5 minutes
         */
        incomingBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the EMFValidationErrors metric
         *
         * @default - Sum over 5 minutes
         */
        emfValidationErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the EMFParsingErrors metric
         *
         * @default - Sum over 5 minutes
         */
        emfParsingErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TransformedLogEvents metric
         *
         * @default - Sum over 5 minutes
         */
        transformedLogEvents(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TransformedBytes metric
         *
         * @default - Sum over 5 minutes
         */
        transformedBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the TransformationErrors metric
         *
         * @default - Sum over 5 minutes
         */
        transformationErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ForwardedLogEvents metric
         *
         * @default - Sum over 5 minutes
         */
        forwardedLogEvents(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryErrors metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryErrors(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the DeliveryThrottling metric
         *
         * @default - Sum over 5 minutes
         */
        deliveryThrottling(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the LogEventsWithFindings metric
         *
         * @default - Sum over 5 minutes
         */
        logEventsWithFindings(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the AnomalyCount metric
         *
         * @default - Sum over 5 minutes
         */
        anomalyCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for LogGroupMetrics
     *
     * @struct
     * @stability external
     */
    interface LogGroupMetricsProps {
        /**
         * The LogGroupName dimension
         */
        readonly logGroupName: string;
    }
}
