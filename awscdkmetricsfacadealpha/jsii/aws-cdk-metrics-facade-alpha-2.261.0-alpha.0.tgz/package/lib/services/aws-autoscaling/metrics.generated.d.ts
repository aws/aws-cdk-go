import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IAutoScalingGroupRef } from "aws-cdk-lib/aws-autoscaling";
/**
 * CloudWatch metrics facade for AWS/AutoScaling
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class AutoScalingMetrics {
    /**
     * Create AutoScalingGroupMetrics from a AutoScalingGroup reference
     */
    static fromAutoScalingGroup(ref: IAutoScalingGroupRef): AutoScalingMetrics.AutoScalingGroupMetrics;
}
export declare namespace AutoScalingMetrics {
    /**
     * Metrics for dimension set: AutoScalingGroup {AutoScalingGroupName}
     *
     * @stability external
     */
    class AutoScalingGroupMetrics {
        private readonly dimensions;
        constructor(props: AutoScalingMetrics.AutoScalingGroupMetricsProps);
        /**
         * Average of the GroupTotalInstances metric
         *
         * @default - Average over 5 minutes
         */
        groupTotalInstances(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GroupDesiredCapacity metric
         *
         * @default - Average over 5 minutes
         */
        groupDesiredCapacity(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GroupMaxSize metric
         *
         * @default - Average over 5 minutes
         */
        groupMaxSize(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GroupMinSize metric
         *
         * @default - Average over 5 minutes
         */
        groupMinSize(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GroupTerminatingInstances metric
         *
         * @default - Average over 5 minutes
         */
        groupTerminatingInstances(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GroupPendingInstances metric
         *
         * @default - Average over 5 minutes
         */
        groupPendingInstances(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GroupInServiceInstances metric
         *
         * @default - Average over 5 minutes
         */
        groupInServiceInstances(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the GroupStandbyInstances metric
         *
         * @default - Average over 5 minutes
         */
        groupStandbyInstances(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for AutoScalingGroupMetrics
     *
     * @struct
     * @stability external
     */
    interface AutoScalingGroupMetricsProps {
        /**
         * The AutoScalingGroupName dimension
         */
        readonly autoScalingGroupName: string;
    }
}
