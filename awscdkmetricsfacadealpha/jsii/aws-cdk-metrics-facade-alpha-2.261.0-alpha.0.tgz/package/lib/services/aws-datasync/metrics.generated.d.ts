import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/DataSync
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class DataSyncMetrics {
}
export declare namespace DataSyncMetrics {
    /**
     * Metrics for dimension set: Agent {AgentId}
     *
     * @stability external
     */
    class AgentMetrics {
        private readonly dimensions;
        constructor(props: DataSyncMetrics.AgentMetricsProps);
        /**
         * Sum of the FilesTransferred metric
         *
         * @default - Sum over 5 minutes
         */
        filesTransferred(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesTransferred metric
         *
         * @default - Sum over 5 minutes
         */
        bytesTransferred(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesWritten metric
         *
         * @default - Sum over 5 minutes
         */
        bytesWritten(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for AgentMetrics
     *
     * @struct
     * @stability external
     */
    interface AgentMetricsProps {
        /**
         * The AgentId dimension
         */
        readonly agentId: string;
    }
    /**
     * Metrics for dimension set: Task {TaskId}
     *
     * @stability external
     */
    class TaskMetrics {
        private readonly dimensions;
        constructor(props: DataSyncMetrics.TaskMetricsProps);
        /**
         * Sum of the FilesTransferred metric
         *
         * @default - Sum over 5 minutes
         */
        filesTransferred(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesTransferred metric
         *
         * @default - Sum over 5 minutes
         */
        bytesTransferred(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesWritten metric
         *
         * @default - Sum over 5 minutes
         */
        bytesWritten(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesPreparedDestination metric
         *
         * @default - Sum over 5 minutes
         */
        bytesPreparedDestination(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesPreparedSource metric
         *
         * @default - Sum over 5 minutes
         */
        bytesPreparedSource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesVerifiedDestination metric
         *
         * @default - Sum over 5 minutes
         */
        bytesVerifiedDestination(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the BytesVerifiedSource metric
         *
         * @default - Sum over 5 minutes
         */
        bytesVerifiedSource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FilesPreparedDestination metric
         *
         * @default - Sum over 5 minutes
         */
        filesPreparedDestination(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FilesPreparedSource metric
         *
         * @default - Sum over 5 minutes
         */
        filesPreparedSource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FilesVerifiedDestination metric
         *
         * @default - Sum over 5 minutes
         */
        filesVerifiedDestination(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the FilesVerifiedSource metric
         *
         * @default - Sum over 5 minutes
         */
        filesVerifiedSource(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for TaskMetrics
     *
     * @struct
     * @stability external
     */
    interface TaskMetricsProps {
        /**
         * The TaskId dimension
         */
        readonly taskId: string;
    }
}
