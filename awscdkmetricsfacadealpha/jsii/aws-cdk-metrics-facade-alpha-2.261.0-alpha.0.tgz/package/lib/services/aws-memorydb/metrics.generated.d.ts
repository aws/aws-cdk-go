import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
import { IClusterRef } from "aws-cdk-lib/aws-memorydb";
/**
 * CloudWatch metrics facade for AWS/MemoryDB
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class MemoryDBMetrics {
    /**
     * Create ClusterMetrics from a Cluster reference
     */
    static fromCluster(ref: IClusterRef): MemoryDBMetrics.ClusterMetrics;
}
export declare namespace MemoryDBMetrics {
    /**
     * Metrics for dimension set: Cluster {ClusterName}
     *
     * @stability external
     */
    class ClusterMetrics {
        private readonly dimensions;
        constructor(props: MemoryDBMetrics.ClusterMetricsProps);
        /**
         * Sum of the ActiveDefragHits metric
         *
         * @default - Sum over 5 minutes
         */
        activeDefragHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the AuthenticationFailures metric
         *
         * @default - Sum over 5 minutes
         */
        authenticationFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the BytesUsedForMemoryDB metric
         *
         * @default - Average over 5 minutes
         */
        bytesUsedForMemoryDb(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CommandAuthorizationFailures metric
         *
         * @default - Sum over 5 minutes
         */
        commandAuthorizationFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the CPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        cpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CurrConnections metric
         *
         * @default - Sum over 5 minutes
         */
        currConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CurrItems metric
         *
         * @default - Sum over 5 minutes
         */
        currItems(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the DatabaseMemoryUsagePercentage metric
         *
         * @default - Average over 5 minutes
         */
        databaseMemoryUsagePercentage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the EngineCPUUtilization metric
         *
         * @default - Average over 5 minutes
         */
        engineCpuUtilization(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Evictions metric
         *
         * @default - Sum over 5 minutes
         */
        evictions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the FreeableMemory metric
         *
         * @default - Average over 5 minutes
         */
        freeableMemory(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the IsPrimary metric
         *
         * @default - Average over 5 minutes
         */
        isPrimary(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the KeyAuthorizationFailures metric
         *
         * @default - Sum over 5 minutes
         */
        keyAuthorizationFailures(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the KeyspaceHits metric
         *
         * @default - Sum over 5 minutes
         */
        keyspaceHits(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the KeyspaceMisses metric
         *
         * @default - Sum over 5 minutes
         */
        keyspaceMisses(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the KeysTracked metric
         *
         * @default - Sum over 5 minutes
         */
        keysTracked(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MaxReplicationThroughput metric
         *
         * @default - Average over 5 minutes
         */
        maxReplicationThroughput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the MemoryFragmentationRatio metric
         *
         * @default - Average over 5 minutes
         */
        memoryFragmentationRatio(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBandwidthInAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkBandwidthInAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBandwidthOutAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkBandwidthOutAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBytesIn metric
         *
         * @default - Average over 5 minutes
         */
        networkBytesIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkBytesOut metric
         *
         * @default - Average over 5 minutes
         */
        networkBytesOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkConntrackAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkConntrackAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsIn metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsIn(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsOut metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsOut(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the NetworkPacketsPerSecondAllowanceExceeded metric
         *
         * @default - Average over 5 minutes
         */
        networkPacketsPerSecondAllowanceExceeded(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the NewConnections metric
         *
         * @default - Sum over 5 minutes
         */
        newConnections(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the PrimaryLinkHealthStatus metric
         *
         * @default - Average over 5 minutes
         */
        primaryLinkHealthStatus(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the Reclaimed metric
         *
         * @default - Sum over 5 minutes
         */
        reclaimed(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ReplicationBytes metric
         *
         * @default - Sum over 5 minutes
         */
        replicationBytes(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the ReplicationDelayedWriteCommands metric
         *
         * @default - Sum over 5 minutes
         */
        replicationDelayedWriteCommands(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the ReplicationLag metric
         *
         * @default - Average over 5 minutes
         */
        replicationLag(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the SwapUsage metric
         *
         * @default - Average over 5 minutes
         */
        swapUsage(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for ClusterMetrics
     *
     * @struct
     * @stability external
     */
    interface ClusterMetricsProps {
        /**
         * The ClusterName dimension
         */
        readonly clusterName: string;
    }
}
