import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/CloudHSM
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class CloudHSMMetrics {
}
export declare namespace CloudHSMMetrics {
    /**
     * Metrics for dimension set: HardwareSecurityModule {ClusterId, HsmId}
     *
     * @stability external
     */
    class HardwareSecurityModuleMetrics {
        private readonly dimensions;
        constructor(props: CloudHSMMetrics.HardwareSecurityModuleMetricsProps);
        /**
         * Sum of the HsmKeysSessionOccupied metric
         *
         * @default - Sum over 5 minutes
         */
        hsmKeysSessionOccupied(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HsmKeysTokenOccupied metric
         *
         * @default - Sum over 5 minutes
         */
        hsmKeysTokenOccupied(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HsmSessionCount metric
         *
         * @default - Sum over 5 minutes
         */
        hsmSessionCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Average of the HsmTemperature metric
         *
         * @default - Average over 5 minutes
         */
        hsmTemperature(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HsmUnhealthy metric
         *
         * @default - Sum over 5 minutes
         */
        hsmUnhealthy(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the HsmUsersAvailable metric
         *
         * @default - Sum over 5 minutes
         */
        hsmUsersAvailable(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Maximum of the HsmUsersMax metric
         *
         * @default - Maximum over 5 minutes
         */
        hsmUsersMax(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InterfaceEth2OctetsInput metric
         *
         * @default - Sum over 5 minutes
         */
        interfaceEth2OctetsInput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the InterfaceEth2OctetsOutput metric
         *
         * @default - Sum over 5 minutes
         */
        interfaceEth2OctetsOutput(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for HardwareSecurityModuleMetrics
     *
     * @struct
     * @stability external
     */
    interface HardwareSecurityModuleMetricsProps {
        /**
         * The ClusterId dimension
         */
        readonly clusterId: string;
        /**
         * The HsmId dimension
         */
        readonly hsmId: string;
    }
}
