import * as cloudwatch from "aws-cdk-lib/aws-cloudwatch";
/**
 * CloudWatch metrics facade for AWS/Outposts
 * This class contains helper functions to initialize the dimension-sets classes
 * for selected resources if available.
 *
 * @stability external
 */
export declare abstract class OutpostsMetrics {
}
export declare namespace OutpostsMetrics {
    /**
     * Metrics for dimension set: InstanceTypePerOutpost {OutpostId, InstanceType}
     *
     * @stability external
     */
    class InstanceTypePerOutpostMetrics {
        private readonly dimensions;
        constructor(props: OutpostsMetrics.InstanceTypePerOutpostMetricsProps);
        /**
         * Sum of the AvailableInstanceType_Count metric
         *
         * @default - Sum over 5 minutes
         */
        availableInstanceTypeCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the UsedInstanceType_Count metric
         *
         * @default - Sum over 5 minutes
         */
        usedInstanceTypeCount(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
        /**
         * Sum of the CapacityExceptions metric
         *
         * @default - Sum over 5 minutes
         */
        capacityExceptions(options?: cloudwatch.MetricOptions): cloudwatch.IMetric;
    }
    /**
     * Dimensions for InstanceTypePerOutpostMetrics
     *
     * @struct
     * @stability external
     */
    interface InstanceTypePerOutpostMetricsProps {
        /**
         * The OutpostId dimension
         */
        readonly outpostId: string;
        /**
         * The InstanceType dimension
         */
        readonly instanceType: string;
    }
}
