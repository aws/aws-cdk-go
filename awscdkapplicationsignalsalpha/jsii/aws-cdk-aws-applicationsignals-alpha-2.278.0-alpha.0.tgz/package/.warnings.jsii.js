const VALIDATORS = { _aws_cdk_aws_applicationsignals_alpha_InstrumentationProps: function _aws_cdk_aws_applicationsignals_alpha_InstrumentationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.runtimePlatform))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecs_RuntimePlatform(p.runtimePlatform);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_applicationsignals_alpha_ApplicationSignalsIntegrationProps: function _aws_cdk_aws_applicationsignals_alpha_ApplicationSignalsIntegrationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.instrumentation))
                module.exports._aws_cdk_aws_applicationsignals_alpha_InstrumentationProps(p.instrumentation);
            if (!visitedObjects.has(p.taskDefinition))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecs_TaskDefinition(p.taskDefinition);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.cloudWatchAgentSidecar))
                module.exports._aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentOptions(p.cloudWatchAgentSidecar);
            if (p.overrideEnvironments != null)
                for (const o of p.overrideEnvironments)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_applicationsignals_alpha_EnvironmentExtension(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentOptions: function _aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.operatingSystemFamily))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecs_OperatingSystemFamily(p.operatingSystemFamily);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.portMappings != null)
                for (const o of p.portMappings)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecs_PortMapping(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentIntegrationProps: function _aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentIntegrationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.taskDefinition))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecs_TaskDefinition(p.taskDefinition);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (!visitedObjects.has(p.operatingSystemFamily))
                try {
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecs_OperatingSystemFamily(p.operatingSystemFamily);
                }
                catch (error) {
                    if (error?.name === "DeprecationError")
                        throw error;
                }
            if (p.portMappings != null)
                for (const o of p.portMappings)
                    if (!visitedObjects.has(o))
                        try {
                            require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecs_PortMapping(o);
                        }
                        catch (error) {
                            if (error?.name === "DeprecationError")
                                throw error;
                        }
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    if (ALREADY_WARNED.has(name)) {
        return;
    }
    ALREADY_WARNED.add(name);
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated, and will be removed in the next major release.\n  ${deprecationMessage.trim()}`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
const ALREADY_WARNED = new Set();
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
