function _aws_cdk_aws_applicationsignals_alpha_InstrumentationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.sdkVersion))
            _aws_cdk_aws_applicationsignals_alpha_InstrumentationVersion(p.sdkVersion);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_applicationsignals_alpha_ApplicationSignalsIntegrationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (!visitedObjects.has(p.instrumentation))
            _aws_cdk_aws_applicationsignals_alpha_InstrumentationProps(p.instrumentation);
        if (!visitedObjects.has(p.cloudWatchAgentSidecar))
            _aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentOptions(p.cloudWatchAgentSidecar);
        if (p.overrideEnvironments != null)
            for (const o of p.overrideEnvironments)
                if (!visitedObjects.has(o))
                    _aws_cdk_aws_applicationsignals_alpha_EnvironmentExtension(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_applicationsignals_alpha_ApplicationSignalsIntegration(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_CommonExporting(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_LogsExporting(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_MetricsExporting(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_TraceExporting(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_JavaInstrumentation(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_PythonInstrumentation(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_DotnetInstrumentation(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_NodeInstrumentation(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_InstrumentationVersion(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_JavaInstrumentationVersion(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_PythonInstrumentationVersion(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_DotnetInstrumentationVersion(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_NodeInstrumentationVersion(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentVersion(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentOptions(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.portMappings != null)
            for (const o of p.portMappings)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecs_PortMapping(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentIntegrationProps(p) {
    if (p == null)
        return;
    visitedObjects.add(p);
    try {
        if (p.portMappings != null)
            for (const o of p.portMappings)
                if (!visitedObjects.has(o))
                    require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ecs_PortMapping(o);
    }
    finally {
        visitedObjects.delete(p);
    }
}
function _aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentIntegration(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_EnvironmentExtension(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_Injector(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_JavaInjector(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_PythonInjector(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_DotNetInjector(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_DotNetLinuxInjector(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_DotNetWindowsInjector(p) {
}
function _aws_cdk_aws_applicationsignals_alpha_NodeInjector(p) {
}
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
module.exports = { print, getPropertyDescriptor, DeprecationError, _aws_cdk_aws_applicationsignals_alpha_InstrumentationProps, _aws_cdk_aws_applicationsignals_alpha_ApplicationSignalsIntegrationProps, _aws_cdk_aws_applicationsignals_alpha_ApplicationSignalsIntegration, _aws_cdk_aws_applicationsignals_alpha_CommonExporting, _aws_cdk_aws_applicationsignals_alpha_LogsExporting, _aws_cdk_aws_applicationsignals_alpha_MetricsExporting, _aws_cdk_aws_applicationsignals_alpha_TraceExporting, _aws_cdk_aws_applicationsignals_alpha_JavaInstrumentation, _aws_cdk_aws_applicationsignals_alpha_PythonInstrumentation, _aws_cdk_aws_applicationsignals_alpha_DotnetInstrumentation, _aws_cdk_aws_applicationsignals_alpha_NodeInstrumentation, _aws_cdk_aws_applicationsignals_alpha_InstrumentationVersion, _aws_cdk_aws_applicationsignals_alpha_JavaInstrumentationVersion, _aws_cdk_aws_applicationsignals_alpha_PythonInstrumentationVersion, _aws_cdk_aws_applicationsignals_alpha_DotnetInstrumentationVersion, _aws_cdk_aws_applicationsignals_alpha_NodeInstrumentationVersion, _aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentVersion, _aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentOptions, _aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentIntegrationProps, _aws_cdk_aws_applicationsignals_alpha_CloudWatchAgentIntegration, _aws_cdk_aws_applicationsignals_alpha_EnvironmentExtension, _aws_cdk_aws_applicationsignals_alpha_Injector, _aws_cdk_aws_applicationsignals_alpha_JavaInjector, _aws_cdk_aws_applicationsignals_alpha_PythonInjector, _aws_cdk_aws_applicationsignals_alpha_DotNetInjector, _aws_cdk_aws_applicationsignals_alpha_DotNetLinuxInjector, _aws_cdk_aws_applicationsignals_alpha_DotNetWindowsInjector, _aws_cdk_aws_applicationsignals_alpha_NodeInjector };
