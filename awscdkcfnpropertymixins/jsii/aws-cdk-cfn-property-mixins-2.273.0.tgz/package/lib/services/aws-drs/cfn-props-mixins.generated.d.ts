import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-drs";
/**
 * Account level Launch Configuration Template for AWS Elastic Disaster Recovery.
 *
 * @cloudformationResource AWS::DRS::LaunchConfigurationTemplate
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-launchconfigurationtemplate.html
 */
export declare class CfnLaunchConfigurationTemplatePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnLaunchConfigurationTemplateMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DRS::LaunchConfigurationTemplate`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnLaunchConfigurationTemplateMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnLaunchConfigurationTemplate;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnLaunchConfigurationTemplatePropsMixin {
    /**
     * Configuration of a machine's license.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-drs-launchconfigurationtemplate-licensing.html
     */
    interface LicensingProperty {
        /**
         * Whether to enable Bring your own license or not.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-drs-launchconfigurationtemplate-licensing.html#cfn-drs-launchconfigurationtemplate-licensing-osbyol
         */
        readonly osByol?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnLaunchConfigurationTemplatePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-launchconfigurationtemplate.html
 */
export interface CfnLaunchConfigurationTemplateMixinProps {
    /**
     * Copy private IP.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-launchconfigurationtemplate.html#cfn-drs-launchconfigurationtemplate-copyprivateip
     */
    readonly copyPrivateIp?: boolean | cdk.IResolvable;
    /**
     * Copy tags.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-launchconfigurationtemplate.html#cfn-drs-launchconfigurationtemplate-copytags
     */
    readonly copyTags?: boolean | cdk.IResolvable;
    /**
     * S3 bucket ARN to export Source Network templates.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-launchconfigurationtemplate.html#cfn-drs-launchconfigurationtemplate-exportbucketarn
     */
    readonly exportBucketArn?: string;
    /**
     * Launch disposition.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-launchconfigurationtemplate.html#cfn-drs-launchconfigurationtemplate-launchdisposition
     */
    readonly launchDisposition?: string;
    /**
     * DRS will set the 'launch into instance ID' of any source server when performing a drill, recovery or failback to the previous region or availability zone, using the instance ID of the source instance.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-launchconfigurationtemplate.html#cfn-drs-launchconfigurationtemplate-launchintosourceinstance
     */
    readonly launchIntoSourceInstance?: boolean | cdk.IResolvable;
    /**
     * Configuration of a machine's license.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-launchconfigurationtemplate.html#cfn-drs-launchconfigurationtemplate-licensing
     */
    readonly licensing?: cdk.IResolvable | CfnLaunchConfigurationTemplatePropsMixin.LicensingProperty;
    /**
     * Whether we want to activate post-launch actions.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-launchconfigurationtemplate.html#cfn-drs-launchconfigurationtemplate-postlaunchenabled
     */
    readonly postLaunchEnabled?: boolean | cdk.IResolvable;
    /**
     * A set of tags associated with the Launch Configuration Template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-launchconfigurationtemplate.html#cfn-drs-launchconfigurationtemplate-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Target instance type right-sizing method.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-launchconfigurationtemplate.html#cfn-drs-launchconfigurationtemplate-targetinstancetyperightsizingmethod
     */
    readonly targetInstanceTypeRightSizingMethod?: string;
}
/**
 * A replication configuration template for AWS Elastic Disaster Recovery Service.
 *
 * @cloudformationResource AWS::DRS::ReplicationConfigurationTemplate
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html
 */
export declare class CfnReplicationConfigurationTemplatePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnReplicationConfigurationTemplateMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DRS::ReplicationConfigurationTemplate`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnReplicationConfigurationTemplateMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnReplicationConfigurationTemplate;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnReplicationConfigurationTemplatePropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-drs-replicationconfigurationtemplate-pitpolicyrule.html
     */
    interface PITPolicyRuleProperty {
        /**
         * Whether this rule is enabled or not.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-drs-replicationconfigurationtemplate-pitpolicyrule.html#cfn-drs-replicationconfigurationtemplate-pitpolicyrule-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
        /**
         * How often, in the chosen units, a snapshot should be taken.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-drs-replicationconfigurationtemplate-pitpolicyrule.html#cfn-drs-replicationconfigurationtemplate-pitpolicyrule-interval
         */
        readonly interval?: number;
        /**
         * The duration to retain a snapshot for, in the chosen units.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-drs-replicationconfigurationtemplate-pitpolicyrule.html#cfn-drs-replicationconfigurationtemplate-pitpolicyrule-retentionduration
         */
        readonly retentionDuration?: number;
        /**
         * The ID of the rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-drs-replicationconfigurationtemplate-pitpolicyrule.html#cfn-drs-replicationconfigurationtemplate-pitpolicyrule-ruleid
         */
        readonly ruleId?: number;
        /**
         * The units used to measure the interval and retentionDuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-drs-replicationconfigurationtemplate-pitpolicyrule.html#cfn-drs-replicationconfigurationtemplate-pitpolicyrule-units
         */
        readonly units?: string;
    }
}
/**
 * Properties for CfnReplicationConfigurationTemplatePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html
 */
export interface CfnReplicationConfigurationTemplateMixinProps {
    /**
     * Whether to associate the default Elastic Disaster Recovery Security group with the Replication Configuration Template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-associatedefaultsecuritygroup
     */
    readonly associateDefaultSecurityGroup?: boolean | cdk.IResolvable;
    /**
     * Whether to allow the AWS replication agent to automatically replicate newly added disks.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-autoreplicatenewdisks
     */
    readonly autoReplicateNewDisks?: boolean | cdk.IResolvable;
    /**
     * Configure bandwidth throttling for the outbound data transfer rate of the Source Server in Mbps.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-bandwidththrottling
     */
    readonly bandwidthThrottling?: number;
    /**
     * Whether to create a Public IP for the Recovery Instance by default.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-createpublicip
     */
    readonly createPublicIp?: boolean | cdk.IResolvable;
    /**
     * The data plane routing mechanism that will be used for replication.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-dataplanerouting
     */
    readonly dataPlaneRouting?: string;
    /**
     * The Staging Disk EBS volume type to be used during replication.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-defaultlargestagingdisktype
     */
    readonly defaultLargeStagingDiskType?: string;
    /**
     * The type of EBS encryption to be used during replication.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-ebsencryption
     */
    readonly ebsEncryption?: string;
    /**
     * The ARN of the EBS encryption key to be used during replication.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-ebsencryptionkeyarn
     */
    readonly ebsEncryptionKeyArn?: string;
    /**
     * Which version of the Internet Protocol to use for replication of data.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-internetprotocol
     */
    readonly internetProtocol?: string;
    /**
     * The Point in time (PIT) policy to manage snapshots taken during replication.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-pitpolicy
     */
    readonly pitPolicy?: Array<cdk.IResolvable | CfnReplicationConfigurationTemplatePropsMixin.PITPolicyRuleProperty> | cdk.IResolvable;
    /**
     * The instance type to be used for the replication server.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-replicationserverinstancetype
     */
    readonly replicationServerInstanceType?: string;
    /**
     * The security group IDs that will be used by the replication server.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-replicationserverssecuritygroupsids
     */
    readonly replicationServersSecurityGroupsIDs?: Array<string>;
    /**
     * The subnet to be used by the replication staging area.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-stagingareasubnetid
     */
    readonly stagingAreaSubnetId?: string;
    /**
     * A set of tags to be associated with all resources created in the replication staging area: EC2 replication server, EBS volumes, EBS snapshots, etc.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-stagingareatags
     */
    readonly stagingAreaTags?: cdk.IResolvable | Record<string, string>;
    /**
     * A set of tags to be associated with the Replication Configuration Template resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Whether to use a dedicated Replication Server in the replication staging area.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-replicationconfigurationtemplate.html#cfn-drs-replicationconfigurationtemplate-usededicatedreplicationserver
     */
    readonly useDedicatedReplicationServer?: boolean | cdk.IResolvable;
}
/**
 * A Source Network resource represents a VPC that is protected by AWS Elastic Disaster Recovery.
 *
 * @cloudformationResource AWS::DRS::SourceNetwork
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-sourcenetwork.html
 */
export declare class CfnSourceNetworkPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSourceNetworkMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DRS::SourceNetwork`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSourceNetworkMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSourceNetwork;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnSourceNetworkPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-sourcenetwork.html
 */
export interface CfnSourceNetworkMixinProps {
    /**
     * The account ID containing the VPC to protect.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-sourcenetwork.html#cfn-drs-sourcenetwork-originaccountid
     */
    readonly originAccountId?: string;
    /**
     * The region containing the VPC to protect.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-sourcenetwork.html#cfn-drs-sourcenetwork-originregion
     */
    readonly originRegion?: string;
    /**
     * A set of tags associated with the Source Network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-sourcenetwork.html#cfn-drs-sourcenetwork-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The VPC ID to protect.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-drs-sourcenetwork.html#cfn-drs-sourcenetwork-vpcid
     */
    readonly vpcId?: string;
}
