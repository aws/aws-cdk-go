import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-bcm";
/**
 * Definition of AWS::BCM::Dashboard Resource Type.
 *
 * @cloudformationResource AWS::BCM::Dashboard
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-dashboard.html
 */
export declare class CfnDashboardPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnDashboardMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::BCM::Dashboard`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnDashboardMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDashboard;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnDashboardPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html
     */
    interface WidgetProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html#cfn-bcm-dashboard-widget-configs
         */
        readonly configs?: Array<cdk.IResolvable | CfnDashboardPropsMixin.WidgetConfigProperty> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html#cfn-bcm-dashboard-widget-description
         */
        readonly description?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html#cfn-bcm-dashboard-widget-height
         */
        readonly height?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html#cfn-bcm-dashboard-widget-horizontaloffset
         */
        readonly horizontalOffset?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html#cfn-bcm-dashboard-widget-title
         */
        readonly title?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html#cfn-bcm-dashboard-widget-width
         */
        readonly width?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widgetconfig.html
     */
    interface WidgetConfigProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widgetconfig.html#cfn-bcm-dashboard-widgetconfig-displayconfig
         */
        readonly displayConfig?: CfnDashboardPropsMixin.DisplayConfigProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widgetconfig.html#cfn-bcm-dashboard-widgetconfig-queryparameters
         */
        readonly queryParameters?: cdk.IResolvable | CfnDashboardPropsMixin.QueryParametersProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-queryparameters.html
     */
    interface QueryParametersProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-queryparameters.html#cfn-bcm-dashboard-queryparameters-costandusage
         */
        readonly costAndUsage?: CfnDashboardPropsMixin.CostAndUsageQueryProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-queryparameters.html#cfn-bcm-dashboard-queryparameters-reservationcoverage
         */
        readonly reservationCoverage?: cdk.IResolvable | CfnDashboardPropsMixin.ReservationCoverageQueryProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-queryparameters.html#cfn-bcm-dashboard-queryparameters-reservationutilization
         */
        readonly reservationUtilization?: cdk.IResolvable | CfnDashboardPropsMixin.ReservationUtilizationQueryProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-queryparameters.html#cfn-bcm-dashboard-queryparameters-savingsplanscoverage
         */
        readonly savingsPlansCoverage?: cdk.IResolvable | CfnDashboardPropsMixin.SavingsPlansCoverageQueryProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-queryparameters.html#cfn-bcm-dashboard-queryparameters-savingsplansutilization
         */
        readonly savingsPlansUtilization?: cdk.IResolvable | CfnDashboardPropsMixin.SavingsPlansUtilizationQueryProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusagequery.html
     */
    interface CostAndUsageQueryProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusagequery.html#cfn-bcm-dashboard-costandusagequery-filter
         */
        readonly filter?: CfnDashboardPropsMixin.CostAndUsageExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusagequery.html#cfn-bcm-dashboard-costandusagequery-granularity
         */
        readonly granularity?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusagequery.html#cfn-bcm-dashboard-costandusagequery-groupby
         */
        readonly groupBy?: Array<CfnDashboardPropsMixin.GroupDefinitionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusagequery.html#cfn-bcm-dashboard-costandusagequery-metrics
         */
        readonly metrics?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusagequery.html#cfn-bcm-dashboard-costandusagequery-timerange
         */
        readonly timeRange?: CfnDashboardPropsMixin.DateTimeRangeProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-datetimerange.html
     */
    interface DateTimeRangeProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-datetimerange.html#cfn-bcm-dashboard-datetimerange-endtime
         */
        readonly endTime?: CfnDashboardPropsMixin.DateTimeValueProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-datetimerange.html#cfn-bcm-dashboard-datetimerange-starttime
         */
        readonly startTime?: CfnDashboardPropsMixin.DateTimeValueProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-datetimevalue.html
     */
    interface DateTimeValueProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-datetimevalue.html#cfn-bcm-dashboard-datetimevalue-type
         */
        readonly type?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-datetimevalue.html#cfn-bcm-dashboard-datetimevalue-value
         */
        readonly value?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-groupdefinition.html
     */
    interface GroupDefinitionProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-groupdefinition.html#cfn-bcm-dashboard-groupdefinition-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-groupdefinition.html#cfn-bcm-dashboard-groupdefinition-type
         */
        readonly type?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html
     */
    interface CostAndUsageExpressionProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html#cfn-bcm-dashboard-costandusageexpression-and
         */
        readonly and?: Array<CfnDashboardPropsMixin.CostAndUsageExpressionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html#cfn-bcm-dashboard-costandusageexpression-costcategories
         */
        readonly costCategories?: CfnDashboardPropsMixin.CostCategoryValuesProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html#cfn-bcm-dashboard-costandusageexpression-dimensions
         */
        readonly dimensions?: CfnDashboardPropsMixin.DimensionValuesProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html#cfn-bcm-dashboard-costandusageexpression-not
         */
        readonly not?: CfnDashboardPropsMixin.CostAndUsageExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html#cfn-bcm-dashboard-costandusageexpression-or
         */
        readonly or?: Array<CfnDashboardPropsMixin.CostAndUsageExpressionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html#cfn-bcm-dashboard-costandusageexpression-tags
         */
        readonly tags?: CfnDashboardPropsMixin.TagValuesProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-dimensionvalues.html
     */
    interface DimensionValuesProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-dimensionvalues.html#cfn-bcm-dashboard-dimensionvalues-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-dimensionvalues.html#cfn-bcm-dashboard-dimensionvalues-matchoptions
         */
        readonly matchOptions?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-dimensionvalues.html#cfn-bcm-dashboard-dimensionvalues-values
         */
        readonly values?: Array<string>;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-tagvalues.html
     */
    interface TagValuesProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-tagvalues.html#cfn-bcm-dashboard-tagvalues-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-tagvalues.html#cfn-bcm-dashboard-tagvalues-matchoptions
         */
        readonly matchOptions?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-tagvalues.html#cfn-bcm-dashboard-tagvalues-values
         */
        readonly values?: Array<string>;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costcategoryvalues.html
     */
    interface CostCategoryValuesProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costcategoryvalues.html#cfn-bcm-dashboard-costcategoryvalues-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costcategoryvalues.html#cfn-bcm-dashboard-costcategoryvalues-matchoptions
         */
        readonly matchOptions?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costcategoryvalues.html#cfn-bcm-dashboard-costcategoryvalues-values
         */
        readonly values?: Array<string>;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplanscoveragequery.html
     */
    interface SavingsPlansCoverageQueryProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplanscoveragequery.html#cfn-bcm-dashboard-savingsplanscoveragequery-filter
         */
        readonly filter?: CfnDashboardPropsMixin.ExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplanscoveragequery.html#cfn-bcm-dashboard-savingsplanscoveragequery-granularity
         */
        readonly granularity?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplanscoveragequery.html#cfn-bcm-dashboard-savingsplanscoveragequery-groupby
         */
        readonly groupBy?: Array<CfnDashboardPropsMixin.GroupDefinitionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplanscoveragequery.html#cfn-bcm-dashboard-savingsplanscoveragequery-metrics
         */
        readonly metrics?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplanscoveragequery.html#cfn-bcm-dashboard-savingsplanscoveragequery-timerange
         */
        readonly timeRange?: CfnDashboardPropsMixin.DateTimeRangeProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-expression.html
     */
    interface ExpressionProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-expression.html#cfn-bcm-dashboard-expression-and
         */
        readonly and?: Array<CfnDashboardPropsMixin.ExpressionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-expression.html#cfn-bcm-dashboard-expression-costcategories
         */
        readonly costCategories?: CfnDashboardPropsMixin.CostCategoryValuesProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-expression.html#cfn-bcm-dashboard-expression-dimensions
         */
        readonly dimensions?: CfnDashboardPropsMixin.DimensionValuesProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-expression.html#cfn-bcm-dashboard-expression-not
         */
        readonly not?: CfnDashboardPropsMixin.ExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-expression.html#cfn-bcm-dashboard-expression-tags
         */
        readonly tags?: CfnDashboardPropsMixin.TagValuesProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplansutilizationquery.html
     */
    interface SavingsPlansUtilizationQueryProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplansutilizationquery.html#cfn-bcm-dashboard-savingsplansutilizationquery-filter
         */
        readonly filter?: CfnDashboardPropsMixin.ExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplansutilizationquery.html#cfn-bcm-dashboard-savingsplansutilizationquery-granularity
         */
        readonly granularity?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplansutilizationquery.html#cfn-bcm-dashboard-savingsplansutilizationquery-timerange
         */
        readonly timeRange?: CfnDashboardPropsMixin.DateTimeRangeProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationcoveragequery.html
     */
    interface ReservationCoverageQueryProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationcoveragequery.html#cfn-bcm-dashboard-reservationcoveragequery-filter
         */
        readonly filter?: CfnDashboardPropsMixin.ExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationcoveragequery.html#cfn-bcm-dashboard-reservationcoveragequery-granularity
         */
        readonly granularity?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationcoveragequery.html#cfn-bcm-dashboard-reservationcoveragequery-groupby
         */
        readonly groupBy?: Array<CfnDashboardPropsMixin.GroupDefinitionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationcoveragequery.html#cfn-bcm-dashboard-reservationcoveragequery-metrics
         */
        readonly metrics?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationcoveragequery.html#cfn-bcm-dashboard-reservationcoveragequery-timerange
         */
        readonly timeRange?: CfnDashboardPropsMixin.DateTimeRangeProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationutilizationquery.html
     */
    interface ReservationUtilizationQueryProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationutilizationquery.html#cfn-bcm-dashboard-reservationutilizationquery-filter
         */
        readonly filter?: CfnDashboardPropsMixin.ExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationutilizationquery.html#cfn-bcm-dashboard-reservationutilizationquery-granularity
         */
        readonly granularity?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationutilizationquery.html#cfn-bcm-dashboard-reservationutilizationquery-groupby
         */
        readonly groupBy?: Array<CfnDashboardPropsMixin.GroupDefinitionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationutilizationquery.html#cfn-bcm-dashboard-reservationutilizationquery-timerange
         */
        readonly timeRange?: CfnDashboardPropsMixin.DateTimeRangeProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-displayconfig.html
     */
    interface DisplayConfigProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-displayconfig.html#cfn-bcm-dashboard-displayconfig-graph
         */
        readonly graph?: cdk.IResolvable | Record<string, CfnDashboardPropsMixin.GraphDisplayConfigProperty | cdk.IResolvable>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-displayconfig.html#cfn-bcm-dashboard-displayconfig-table
         */
        readonly table?: any | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-graphdisplayconfig.html
     */
    interface GraphDisplayConfigProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-graphdisplayconfig.html#cfn-bcm-dashboard-graphdisplayconfig-visualtype
         */
        readonly visualType?: string;
    }
}
/**
 * Properties for CfnDashboardPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-dashboard.html
 */
export interface CfnDashboardMixinProps {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-dashboard.html#cfn-bcm-dashboard-description
     */
    readonly description?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-dashboard.html#cfn-bcm-dashboard-name
     */
    readonly name?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-dashboard.html#cfn-bcm-dashboard-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-dashboard.html#cfn-bcm-dashboard-widgets
     */
    readonly widgets?: Array<cdk.IResolvable | CfnDashboardPropsMixin.WidgetProperty> | cdk.IResolvable;
}
/**
 * Creates and manages a scheduled report for an AWS Billing and Cost Management Dashboards dashboard.
 *
 * A scheduled report renders a snapshot of the dashboard on a cron schedule, using an IAM role that the service assumes to read the underlying cost and usage data.
 *
 * @cloudformationResource AWS::BCM::ScheduledReport
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-scheduledreport.html
 */
export declare class CfnScheduledReportPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnScheduledReportMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::BCM::ScheduledReport`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnScheduledReportMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnScheduledReport;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnScheduledReportPropsMixin {
    /**
     * Defines when and how often a scheduled report runs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-scheduleconfig.html
     */
    interface ScheduleConfigProperty {
        /**
         * The schedule expression that specifies when to trigger the scheduled report run.
         *
         * This value must be a cron expression consisting of six fields separated by white spaces: cron(minutes hours day_of_month month day_of_week year).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-scheduleconfig.html#cfn-bcm-scheduledreport-scheduleconfig-scheduleexpression
         */
        readonly scheduleExpression?: string;
        /**
         * The time zone for the schedule expression, for example, UTC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-scheduleconfig.html#cfn-bcm-scheduledreport-scheduleconfig-scheduleexpressiontimezone
         */
        readonly scheduleExpressionTimeZone?: string;
        /**
         * The window during which the schedule is active.
         *
         * When omitted the service defaults it. EndTime must be within three years of the time of the request.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-scheduleconfig.html#cfn-bcm-scheduledreport-scheduleconfig-scheduleperiod
         */
        readonly schedulePeriod?: cdk.IResolvable | CfnScheduledReportPropsMixin.SchedulePeriodProperty;
        /**
         * Whether the schedule is active.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-scheduleconfig.html#cfn-bcm-scheduledreport-scheduleconfig-state
         */
        readonly state?: string;
    }
    /**
     * The window during which the schedule is active.
     *
     * When omitted the service defaults it. EndTime must be within three years of the time of the request.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-scheduleperiod.html
     */
    interface SchedulePeriodProperty {
        /**
         * The time at which the schedule stops being active.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-scheduleperiod.html#cfn-bcm-scheduledreport-scheduleperiod-endtime
         */
        readonly endTime?: string;
        /**
         * The time at which the schedule becomes active.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-scheduleperiod.html#cfn-bcm-scheduledreport-scheduleperiod-starttime
         */
        readonly startTime?: string;
    }
    /**
     * An absolute or relative date range.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-datetimerange.html
     */
    interface DateTimeRangeProperty {
        /**
         * A date expressed either as an absolute instant or as an offset from now.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-datetimerange.html#cfn-bcm-scheduledreport-datetimerange-endtime
         */
        readonly endTime?: CfnScheduledReportPropsMixin.DateTimeValueProperty | cdk.IResolvable;
        /**
         * A date expressed either as an absolute instant or as an offset from now.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-datetimerange.html#cfn-bcm-scheduledreport-datetimerange-starttime
         */
        readonly startTime?: CfnScheduledReportPropsMixin.DateTimeValueProperty | cdk.IResolvable;
    }
    /**
     * A date expressed either as an absolute instant or as an offset from now.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-datetimevalue.html
     */
    interface DateTimeValueProperty {
        /**
         * Whether a date value is absolute or relative.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-datetimevalue.html#cfn-bcm-scheduledreport-datetimevalue-type
         */
        readonly type?: string;
        /**
         * The date, or an ISO 8601 duration when Type is RELATIVE.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-datetimevalue.html#cfn-bcm-scheduledreport-datetimevalue-value
         */
        readonly value?: string;
    }
    /**
     * The health of the scheduled report as of its last refresh.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-healthstatus.html
     */
    interface HealthStatusProperty {
        /**
         * The time at which the health status was last refreshed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-healthstatus.html#cfn-bcm-scheduledreport-healthstatus-lastrefreshedat
         */
        readonly lastRefreshedAt?: string;
        /**
         * The health status of a scheduled report.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-scheduledreport-healthstatus.html#cfn-bcm-scheduledreport-healthstatus-statuscode
         */
        readonly statusCode?: string;
    }
}
/**
 * Properties for CfnScheduledReportPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-scheduledreport.html
 */
export interface CfnScheduledReportMixinProps {
    /**
     * The ARN of the dashboard associated with the scheduled report.
     *
     * Managed dashboards cannot be used.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-scheduledreport.html#cfn-bcm-scheduledreport-dashboardarn
     */
    readonly dashboardArn?: string;
    /**
     * A description of the scheduled report's purpose or contents.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-scheduledreport.html#cfn-bcm-scheduledreport-description
     */
    readonly description?: string;
    /**
     * The name of the scheduled report.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-scheduledreport.html#cfn-bcm-scheduledreport-name
     */
    readonly name?: string;
    /**
     * Defines when and how often a scheduled report runs.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-scheduledreport.html#cfn-bcm-scheduledreport-scheduleconfig
     */
    readonly scheduleConfig?: cdk.IResolvable | CfnScheduledReportPropsMixin.ScheduleConfigProperty;
    /**
     * The ARN of the IAM role that the scheduled report uses to execute.
     *
     * AWS Billing and Cost Management Dashboards assumes this IAM role while executing the scheduled report.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-scheduledreport.html#cfn-bcm-scheduledreport-scheduledreportexecutionrolearn
     */
    readonly scheduledReportExecutionRoleArn?: string;
    /**
     * The tags applied to the scheduled report.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-scheduledreport.html#cfn-bcm-scheduledreport-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * An absolute or relative date range.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-scheduledreport.html#cfn-bcm-scheduledreport-widgetdaterangeoverride
     */
    readonly widgetDateRangeOverride?: CfnScheduledReportPropsMixin.DateTimeRangeProperty | cdk.IResolvable;
    /**
     * The list of widget identifiers included in the scheduled report.
     *
     * If not specified, all widgets in the dashboard are included.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-scheduledreport.html#cfn-bcm-scheduledreport-widgetids
     */
    readonly widgetIds?: Array<string>;
}
