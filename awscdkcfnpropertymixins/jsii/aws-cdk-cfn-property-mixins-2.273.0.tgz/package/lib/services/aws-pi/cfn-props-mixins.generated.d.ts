import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-pi";
/**
 * Creates and manages a Performance Insights performance analysis report for a specified DB instance.
 *
 * @cloudformationResource AWS::PI::PerfReports
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pi-perfreports.html
 */
export declare class CfnPerfReportsPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPerfReportsMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::PI::PerfReports`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPerfReportsMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPerfReports;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnPerfReportsPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pi-perfreports.html
 */
export interface CfnPerfReportsMixinProps {
    /**
     * The end time defined for the analysis report in ISO 8601 format.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pi-perfreports.html#cfn-pi-perfreports-endtime
     */
    readonly endTime?: string;
    /**
     * An immutable, AWS Region-unique identifier for a data source.
     *
     * Performance Insights gathers metrics from this data source. To use an Amazon RDS instance as a data source, specify its DbiResourceId value.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pi-perfreports.html#cfn-pi-perfreports-identifier
     */
    readonly identifier?: string;
    /**
     * The AWS service for which Performance Insights returns metrics.
     *
     * Valid values are RDS and DOCDB.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pi-perfreports.html#cfn-pi-perfreports-servicetype
     */
    readonly serviceType?: string;
    /**
     * The start time defined for the analysis report in ISO 8601 format.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pi-perfreports.html#cfn-pi-perfreports-starttime
     */
    readonly startTime?: string;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pi-perfreports.html#cfn-pi-perfreports-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
