import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-translate";
/**
 * A parallel data resource in Amazon Translate used to customize machine translation output.
 *
 * @cloudformationResource AWS::Translate::ParallelData
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html
 */
export declare class CfnParallelDataPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnParallelDataMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Translate::ParallelData`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnParallelDataMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnParallelData;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnParallelDataPropsMixin {
    /**
     * Specifies the format and S3 location of the parallel data input file.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-paralleldataconfig.html
     */
    interface ParallelDataConfigProperty {
        /**
         * The format of the parallel data input file.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-paralleldataconfig.html#cfn-translate-paralleldata-paralleldataconfig-format
         */
        readonly format?: string;
        /**
         * The URI of the Amazon S3 folder that contains the parallel data input file.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-paralleldataconfig.html#cfn-translate-paralleldata-paralleldataconfig-s3uri
         */
        readonly s3Uri?: string;
    }
    /**
     * The encryption key used to encrypt this object.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-encryptionkey.html
     */
    interface EncryptionKeyProperty {
        /**
         * The Amazon Resource Name (ARN) of the encryption key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-encryptionkey.html#cfn-translate-paralleldata-encryptionkey-id
         */
        readonly id?: string;
        /**
         * The type of encryption key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-encryptionkey.html#cfn-translate-paralleldata-encryptionkey-type
         */
        readonly type?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-tagsitems.html
     */
    interface TagsItemsProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-tagsitems.html#cfn-translate-paralleldata-tagsitems-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-tagsitems.html#cfn-translate-paralleldata-tagsitems-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnParallelDataPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html
 */
export interface CfnParallelDataMixinProps {
    /**
     * A custom description for the parallel data resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html#cfn-translate-paralleldata-description
     */
    readonly description?: string;
    /**
     * The encryption key used to encrypt this object.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html#cfn-translate-paralleldata-encryptionkey
     */
    readonly encryptionKey?: CfnParallelDataPropsMixin.EncryptionKeyProperty | cdk.IResolvable;
    /**
     * A custom name for the parallel data resource.
     *
     * Must be unique in the account and region.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html#cfn-translate-paralleldata-name
     */
    readonly name?: string;
    /**
     * Specifies the format and S3 location of the parallel data input file.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html#cfn-translate-paralleldata-paralleldataconfig
     */
    readonly parallelDataConfig?: cdk.IResolvable | CfnParallelDataPropsMixin.ParallelDataConfigProperty;
    /**
     * Tags associated with the parallel data resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html#cfn-translate-paralleldata-tags
     */
    readonly tags?: Array<CfnParallelDataPropsMixin.TagsItemsProperty>;
}
/**
 * A custom terminology resource for Amazon Translate that enables customized translations.
 *
 * @cloudformationResource AWS::Translate::Terminology
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-terminology.html
 */
export declare class CfnTerminologyPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTerminologyMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Translate::Terminology`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTerminologyMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTerminology;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnTerminologyPropsMixin {
    /**
     * The terminology data for the custom terminology being imported.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-terminology-terminologydata.html
     */
    interface TerminologyDataProperty {
        /**
         * The directionality of the terminology resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-terminology-terminologydata.html#cfn-translate-terminology-terminologydata-directionality
         */
        readonly directionality?: string;
        /**
         * The file containing the custom terminology data, base64-encoded.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-terminology-terminologydata.html#cfn-translate-terminology-terminologydata-file
         */
        readonly file?: string;
        /**
         * The data format of the custom terminology.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-terminology-terminologydata.html#cfn-translate-terminology-terminologydata-format
         */
        readonly format?: string;
    }
    /**
     * The encryption key for the custom terminology.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-terminology-encryptionkey.html
     */
    interface EncryptionKeyProperty {
        /**
         * The Amazon Resource Name (ARN) of the encryption key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-terminology-encryptionkey.html#cfn-translate-terminology-encryptionkey-id
         */
        readonly id?: string;
        /**
         * The type of encryption key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-terminology-encryptionkey.html#cfn-translate-terminology-encryptionkey-type
         */
        readonly type?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-terminology-tagsitems.html
     */
    interface TagsItemsProperty {
        /**
         * The key of the tag.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-terminology-tagsitems.html#cfn-translate-terminology-tagsitems-key
         */
        readonly key?: string;
        /**
         * The value of the tag.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-terminology-tagsitems.html#cfn-translate-terminology-tagsitems-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnTerminologyPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-terminology.html
 */
export interface CfnTerminologyMixinProps {
    /**
     * The description of the custom terminology.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-terminology.html#cfn-translate-terminology-description
     */
    readonly description?: string;
    /**
     * The encryption key for the custom terminology.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-terminology.html#cfn-translate-terminology-encryptionkey
     */
    readonly encryptionKey?: CfnTerminologyPropsMixin.EncryptionKeyProperty | cdk.IResolvable;
    /**
     * The merge strategy for the custom terminology.
     *
     * Currently only OVERWRITE is supported.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-terminology.html#cfn-translate-terminology-mergestrategy
     */
    readonly mergeStrategy?: string;
    /**
     * The name of the custom terminology.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-terminology.html#cfn-translate-terminology-name
     */
    readonly name?: string;
    /**
     * Tags associated with the terminology.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-terminology.html#cfn-translate-terminology-tags
     */
    readonly tags?: Array<CfnTerminologyPropsMixin.TagsItemsProperty>;
    /**
     * The terminology data for the custom terminology being imported.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-terminology.html#cfn-translate-terminology-terminologydata
     */
    readonly terminologyData?: cdk.IResolvable | CfnTerminologyPropsMixin.TerminologyDataProperty;
}
