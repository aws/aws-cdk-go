import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-mgn";
/**
 * Resource schema for AWS::MGN::Connector.
 *
 * A Connector provides connectivity between a source environment and Application Migration Service (MGN) via AWS Systems Manager (SSM).
 *
 * @cloudformationResource AWS::MGN::Connector
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-connector.html
 */
export declare class CfnConnectorPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnConnectorMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MGN::Connector`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnConnectorMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnConnector;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnConnectorPropsMixin {
    /**
     * SSM command configuration for the connector.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-connector-connectorssmcommandconfig.html
     */
    interface ConnectorSsmCommandConfigProperty {
        /**
         * The CloudWatch Logs group name for SSM command output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-connector-connectorssmcommandconfig.html#cfn-mgn-connector-connectorssmcommandconfig-cloudwatchloggroupname
         */
        readonly cloudWatchLogGroupName?: string;
        /**
         * Whether SSM command output is sent to CloudWatch Logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-connector-connectorssmcommandconfig.html#cfn-mgn-connector-connectorssmcommandconfig-cloudwatchoutputenabled
         */
        readonly cloudWatchOutputEnabled?: boolean | cdk.IResolvable;
        /**
         * The S3 bucket name for SSM command output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-connector-connectorssmcommandconfig.html#cfn-mgn-connector-connectorssmcommandconfig-outputs3bucketname
         */
        readonly outputS3BucketName?: string;
        /**
         * Whether SSM command output is stored in S3.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-connector-connectorssmcommandconfig.html#cfn-mgn-connector-connectorssmcommandconfig-s3outputenabled
         */
        readonly s3OutputEnabled?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnConnectorPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-connector.html
 */
export interface CfnConnectorMixinProps {
    /**
     * The name of the connector.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-connector.html#cfn-mgn-connector-name
     */
    readonly name?: string;
    /**
     * SSM command configuration for the connector.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-connector.html#cfn-mgn-connector-ssmcommandconfig
     */
    readonly ssmCommandConfig?: CfnConnectorPropsMixin.ConnectorSsmCommandConfigProperty | cdk.IResolvable;
    /**
     * The SSM instance ID associated with this connector.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-connector.html#cfn-mgn-connector-ssminstanceid
     */
    readonly ssmInstanceId?: string;
    /**
     * Tags to assign to the connector.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-connector.html#cfn-mgn-connector-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Account level Launch Configuration Template for AWS Application Migration Service.
 *
 * @cloudformationResource AWS::MGN::LaunchConfigurationTemplate
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html
 */
export declare class CfnLaunchConfigurationTemplatePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnLaunchConfigurationTemplateMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MGN::LaunchConfigurationTemplate`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnLaunchConfigurationTemplateMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnLaunchConfigurationTemplate;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnLaunchConfigurationTemplatePropsMixin {
    /**
     * Post launch actions to execute on the Test or Cutover instance.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-postlaunchactions.html
     */
    interface PostLaunchActionsProperty {
        /**
         * AWS Systems Manager Command's CloudWatch log group name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-postlaunchactions.html#cfn-mgn-launchconfigurationtemplate-postlaunchactions-cloudwatchloggroupname
         */
        readonly cloudWatchLogGroupName?: string;
        /**
         * Deployment type in which AWS Systems Manager Documents will be executed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-postlaunchactions.html#cfn-mgn-launchconfigurationtemplate-postlaunchactions-deployment
         */
        readonly deployment?: string;
        /**
         * AWS Systems Manager Command's logs S3 log bucket.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-postlaunchactions.html#cfn-mgn-launchconfigurationtemplate-postlaunchactions-s3logbucket
         */
        readonly s3LogBucket?: string;
        /**
         * AWS Systems Manager Command's logs S3 output key prefix.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-postlaunchactions.html#cfn-mgn-launchconfigurationtemplate-postlaunchactions-s3outputkeyprefix
         */
        readonly s3OutputKeyPrefix?: string;
        /**
         * AWS Systems Manager Documents to execute, in order.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-postlaunchactions.html#cfn-mgn-launchconfigurationtemplate-postlaunchactions-ssmdocuments
         */
        readonly ssmDocuments?: Array<cdk.IResolvable | CfnLaunchConfigurationTemplatePropsMixin.SsmDocumentProperty> | cdk.IResolvable;
    }
    /**
     * An AWS Systems Manager Document to execute as a post launch action.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-ssmdocument.html
     */
    interface SsmDocumentProperty {
        /**
         * User-friendly name for the AWS Systems Manager Document.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-ssmdocument.html#cfn-mgn-launchconfigurationtemplate-ssmdocument-actionname
         */
        readonly actionName?: string;
        /**
         * AWS Systems Manager Document external parameters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-ssmdocument.html#cfn-mgn-launchconfigurationtemplate-ssmdocument-externalparameters
         */
        readonly externalParameters?: cdk.IResolvable | Record<string, cdk.IResolvable | CfnLaunchConfigurationTemplatePropsMixin.SsmExternalParameterProperty>;
        /**
         * Whether Cutover is blocked when the document has failed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-ssmdocument.html#cfn-mgn-launchconfigurationtemplate-ssmdocument-mustsucceedforcutover
         */
        readonly mustSucceedForCutover?: boolean | cdk.IResolvable;
        /**
         * AWS Systems Manager Document parameters, each resolved from AWS Systems Manager Parameter Store.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-ssmdocument.html#cfn-mgn-launchconfigurationtemplate-ssmdocument-parameters
         */
        readonly parameters?: cdk.IResolvable | Record<string, Array<cdk.IResolvable | CfnLaunchConfigurationTemplatePropsMixin.SsmParameterStoreParameterProperty> | cdk.IResolvable>;
        /**
         * AWS Systems Manager Document name or full ARN.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-ssmdocument.html#cfn-mgn-launchconfigurationtemplate-ssmdocument-ssmdocumentname
         */
        readonly ssmDocumentName?: string;
        /**
         * AWS Systems Manager Document timeout, in seconds.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-ssmdocument.html#cfn-mgn-launchconfigurationtemplate-ssmdocument-timeoutseconds
         */
        readonly timeoutSeconds?: number;
    }
    /**
     * An AWS Systems Manager Parameter Store parameter.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-ssmparameterstoreparameter.html
     */
    interface SsmParameterStoreParameterProperty {
        /**
         * AWS Systems Manager Parameter Store parameter name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-ssmparameterstoreparameter.html#cfn-mgn-launchconfigurationtemplate-ssmparameterstoreparameter-parametername
         */
        readonly parameterName?: string;
        /**
         * AWS Systems Manager Parameter Store parameter type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-ssmparameterstoreparameter.html#cfn-mgn-launchconfigurationtemplate-ssmparameterstoreparameter-parametertype
         */
        readonly parameterType?: string;
    }
    /**
     * An AWS Systems Manager Document external parameter.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-ssmexternalparameter.html
     */
    interface SsmExternalParameterProperty {
        /**
         * AWS Systems Manager Document external parameter dynamic path.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-ssmexternalparameter.html#cfn-mgn-launchconfigurationtemplate-ssmexternalparameter-dynamicpath
         */
        readonly dynamicPath?: string;
    }
    /**
     * Configuration of a machine's license.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-licensing.html
     */
    interface LicensingProperty {
        /**
         * Whether to configure BYOL OS licensing.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-licensing.html#cfn-mgn-launchconfigurationtemplate-licensing-osbyol
         */
        readonly osByol?: boolean | cdk.IResolvable;
    }
    /**
     * Launch template disk configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-launchtemplatediskconf.html
     */
    interface LaunchTemplateDiskConfProperty {
        /**
         * Launch template disk IOPS configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-launchtemplatediskconf.html#cfn-mgn-launchconfigurationtemplate-launchtemplatediskconf-iops
         */
        readonly iops?: number;
        /**
         * Launch template disk throughput configuration, in MiB/s.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-launchtemplatediskconf.html#cfn-mgn-launchconfigurationtemplate-launchtemplatediskconf-throughput
         */
        readonly throughput?: number;
        /**
         * Launch template disk volume type configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-launchconfigurationtemplate-launchtemplatediskconf.html#cfn-mgn-launchconfigurationtemplate-launchtemplatediskconf-volumetype
         */
        readonly volumeType?: string;
    }
}
/**
 * Properties for CfnLaunchConfigurationTemplatePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html
 */
export interface CfnLaunchConfigurationTemplateMixinProps {
    /**
     * Whether to associate a public IP address with the launched instance.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-associatepublicipaddress
     */
    readonly associatePublicIpAddress?: boolean | cdk.IResolvable;
    /**
     * Launch configuration template boot mode.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-bootmode
     */
    readonly bootMode?: string;
    /**
     * Whether to copy the private IP of the source server.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-copyprivateip
     */
    readonly copyPrivateIp?: boolean | cdk.IResolvable;
    /**
     * Whether to copy the tags of the source server.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-copytags
     */
    readonly copyTags?: boolean | cdk.IResolvable;
    /**
     * Whether to enable map auto tagging.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-enablemapautotagging
     */
    readonly enableMapAutoTagging?: boolean | cdk.IResolvable;
    /**
     * Whether to enable encryption of the AWS Systems Manager parameters used by post launch actions.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-enableparametersencryption
     */
    readonly enableParametersEncryption?: boolean | cdk.IResolvable;
    /**
     * Launch template disk configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-largevolumeconf
     */
    readonly largeVolumeConf?: cdk.IResolvable | CfnLaunchConfigurationTemplatePropsMixin.LaunchTemplateDiskConfProperty;
    /**
     * Launch disposition.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-launchdisposition
     */
    readonly launchDisposition?: string;
    /**
     * Configuration of a machine's license.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-licensing
     */
    readonly licensing?: cdk.IResolvable | CfnLaunchConfigurationTemplatePropsMixin.LicensingProperty;
    /**
     * Launch configuration template map auto tagging MPE ID.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-mapautotaggingmpeid
     */
    readonly mapAutoTaggingMpeId?: string;
    /**
     * ARN of the KMS key used to encrypt the AWS Systems Manager parameters used by post launch actions.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-parametersencryptionkey
     */
    readonly parametersEncryptionKey?: string;
    /**
     * Post launch actions to execute on the Test or Cutover instance.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-postlaunchactions
     */
    readonly postLaunchActions?: cdk.IResolvable | CfnLaunchConfigurationTemplatePropsMixin.PostLaunchActionsProperty;
    /**
     * Launch template disk configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-smallvolumeconf
     */
    readonly smallVolumeConf?: cdk.IResolvable | CfnLaunchConfigurationTemplatePropsMixin.LaunchTemplateDiskConfProperty;
    /**
     * Small volume maximum size, in GiB.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-smallvolumemaxsize
     */
    readonly smallVolumeMaxSize?: number;
    /**
     * A set of tags to be associated with the Launch Configuration Template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Target instance type right-sizing method.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-launchconfigurationtemplate.html#cfn-mgn-launchconfigurationtemplate-targetinstancetyperightsizingmethod
     */
    readonly targetInstanceTypeRightSizingMethod?: string;
}
/**
 * Resource schema for AWS::MGN::NetworkMigrationDefinition.
 *
 * @cloudformationResource AWS::MGN::NetworkMigrationDefinition
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html
 */
export declare class CfnNetworkMigrationDefinitionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnNetworkMigrationDefinitionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MGN::NetworkMigrationDefinition`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnNetworkMigrationDefinitionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnNetworkMigrationDefinition;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnNetworkMigrationDefinitionPropsMixin {
    /**
     * Configuration for a migration source environment.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sourceconfiguration.html
     */
    interface SourceConfigurationProperty {
        /**
         * The source environment type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sourceconfiguration.html#cfn-mgn-networkmigrationdefinition-sourceconfiguration-sourceenvironment
         */
        readonly sourceEnvironment?: string;
        /**
         * S3 configuration for source network data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sourceconfiguration.html#cfn-mgn-networkmigrationdefinition-sourceconfiguration-sources3configuration
         */
        readonly sourceS3Configuration?: cdk.IResolvable | CfnNetworkMigrationDefinitionPropsMixin.SourceS3ConfigurationProperty;
    }
    /**
     * S3 configuration for source network data.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sources3configuration.html
     */
    interface SourceS3ConfigurationProperty {
        /**
         * The name of the S3 bucket containing source data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sources3configuration.html#cfn-mgn-networkmigrationdefinition-sources3configuration-s3bucket
         */
        readonly s3Bucket?: string;
        /**
         * The AWS account ID of the S3 bucket owner.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sources3configuration.html#cfn-mgn-networkmigrationdefinition-sources3configuration-s3bucketowner
         */
        readonly s3BucketOwner?: string;
        /**
         * The S3 key (path) for the source data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sources3configuration.html#cfn-mgn-networkmigrationdefinition-sources3configuration-s3key
         */
        readonly s3Key?: string;
    }
    /**
     * S3 configuration for storing target network artifacts.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targets3configuration.html
     */
    interface TargetS3ConfigurationProperty {
        /**
         * The name of the S3 bucket for target artifacts.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targets3configuration.html#cfn-mgn-networkmigrationdefinition-targets3configuration-s3bucket
         */
        readonly s3Bucket?: string;
        /**
         * The AWS account ID of the S3 bucket owner.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targets3configuration.html#cfn-mgn-networkmigrationdefinition-targets3configuration-s3bucketowner
         */
        readonly s3BucketOwner?: string;
    }
    /**
     * Configuration for the target network topology and addressing.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targetnetwork.html
     */
    interface TargetNetworkProperty {
        /**
         * The CIDR block for inbound traffic in the target network.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targetnetwork.html#cfn-mgn-networkmigrationdefinition-targetnetwork-inboundcidr
         */
        readonly inboundCidr?: string;
        /**
         * The CIDR block for inspection traffic in the target network.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targetnetwork.html#cfn-mgn-networkmigrationdefinition-targetnetwork-inspectioncidr
         */
        readonly inspectionCidr?: string;
        /**
         * The CIDR block for outbound traffic in the target network.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targetnetwork.html#cfn-mgn-networkmigrationdefinition-targetnetwork-outboundcidr
         */
        readonly outboundCidr?: string;
        /**
         * The network topology type for the target environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targetnetwork.html#cfn-mgn-networkmigrationdefinition-targetnetwork-topology
         */
        readonly topology?: string;
    }
}
/**
 * Properties for CfnNetworkMigrationDefinitionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html
 */
export interface CfnNetworkMigrationDefinitionMixinProps {
    /**
     * A description of the network migration definition.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-description
     */
    readonly description?: string;
    /**
     * The name of the network migration definition.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-name
     */
    readonly name?: string;
    /**
     * Scope tags map for the network migration definition.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-scopetags
     */
    readonly scopeTags?: cdk.IResolvable | Record<string, string>;
    /**
     * A list of source configurations for the network migration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-sourceconfigurations
     */
    readonly sourceConfigurations?: Array<cdk.IResolvable | CfnNetworkMigrationDefinitionPropsMixin.SourceConfigurationProperty> | cdk.IResolvable;
    /**
     * Tags to assign to the network migration definition.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The target deployment configuration for the migrated network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-targetdeployment
     */
    readonly targetDeployment?: string;
    /**
     * Configuration for the target network topology and addressing.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-targetnetwork
     */
    readonly targetNetwork?: cdk.IResolvable | CfnNetworkMigrationDefinitionPropsMixin.TargetNetworkProperty;
    /**
     * S3 configuration for storing target network artifacts.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-targets3configuration
     */
    readonly targetS3Configuration?: cdk.IResolvable | CfnNetworkMigrationDefinitionPropsMixin.TargetS3ConfigurationProperty;
}
