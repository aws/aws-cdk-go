import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-transcribe";
/**
 * Resource type definition for AWS::Transcribe::CallAnalyticsCategory.
 *
 * @cloudformationResource AWS::Transcribe::CallAnalyticsCategory
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-callanalyticscategory.html
 */
export declare class CfnCallAnalyticsCategoryPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnCallAnalyticsCategoryMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Transcribe::CallAnalyticsCategory`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnCallAnalyticsCategoryMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCallAnalyticsCategory;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnCallAnalyticsCategoryPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-rule.html
     */
    interface RuleProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-rule.html#cfn-transcribe-callanalyticscategory-rule-interruptionfilter
         */
        readonly interruptionFilter?: CfnCallAnalyticsCategoryPropsMixin.InterruptionFilterProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-rule.html#cfn-transcribe-callanalyticscategory-rule-nontalktimefilter
         */
        readonly nonTalkTimeFilter?: cdk.IResolvable | CfnCallAnalyticsCategoryPropsMixin.NonTalkTimeFilterProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-rule.html#cfn-transcribe-callanalyticscategory-rule-sentimentfilter
         */
        readonly sentimentFilter?: cdk.IResolvable | CfnCallAnalyticsCategoryPropsMixin.SentimentFilterProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-rule.html#cfn-transcribe-callanalyticscategory-rule-transcriptfilter
         */
        readonly transcriptFilter?: cdk.IResolvable | CfnCallAnalyticsCategoryPropsMixin.TranscriptFilterProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-nontalktimefilter.html
     */
    interface NonTalkTimeFilterProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-nontalktimefilter.html#cfn-transcribe-callanalyticscategory-nontalktimefilter-absolutetimerange
         */
        readonly absoluteTimeRange?: CfnCallAnalyticsCategoryPropsMixin.AbsoluteTimeRangeProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-nontalktimefilter.html#cfn-transcribe-callanalyticscategory-nontalktimefilter-negate
         */
        readonly negate?: boolean | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-nontalktimefilter.html#cfn-transcribe-callanalyticscategory-nontalktimefilter-relativetimerange
         */
        readonly relativeTimeRange?: cdk.IResolvable | CfnCallAnalyticsCategoryPropsMixin.RelativeTimeRangeProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-nontalktimefilter.html#cfn-transcribe-callanalyticscategory-nontalktimefilter-threshold
         */
        readonly threshold?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-absolutetimerange.html
     */
    interface AbsoluteTimeRangeProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-absolutetimerange.html#cfn-transcribe-callanalyticscategory-absolutetimerange-endtime
         */
        readonly endTime?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-absolutetimerange.html#cfn-transcribe-callanalyticscategory-absolutetimerange-first
         */
        readonly first?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-absolutetimerange.html#cfn-transcribe-callanalyticscategory-absolutetimerange-last
         */
        readonly last?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-absolutetimerange.html#cfn-transcribe-callanalyticscategory-absolutetimerange-starttime
         */
        readonly startTime?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-relativetimerange.html
     */
    interface RelativeTimeRangeProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-relativetimerange.html#cfn-transcribe-callanalyticscategory-relativetimerange-endpercentage
         */
        readonly endPercentage?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-relativetimerange.html#cfn-transcribe-callanalyticscategory-relativetimerange-first
         */
        readonly first?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-relativetimerange.html#cfn-transcribe-callanalyticscategory-relativetimerange-last
         */
        readonly last?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-relativetimerange.html#cfn-transcribe-callanalyticscategory-relativetimerange-startpercentage
         */
        readonly startPercentage?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-interruptionfilter.html
     */
    interface InterruptionFilterProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-interruptionfilter.html#cfn-transcribe-callanalyticscategory-interruptionfilter-absolutetimerange
         */
        readonly absoluteTimeRange?: CfnCallAnalyticsCategoryPropsMixin.AbsoluteTimeRangeProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-interruptionfilter.html#cfn-transcribe-callanalyticscategory-interruptionfilter-negate
         */
        readonly negate?: boolean | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-interruptionfilter.html#cfn-transcribe-callanalyticscategory-interruptionfilter-participantrole
         */
        readonly participantRole?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-interruptionfilter.html#cfn-transcribe-callanalyticscategory-interruptionfilter-relativetimerange
         */
        readonly relativeTimeRange?: cdk.IResolvable | CfnCallAnalyticsCategoryPropsMixin.RelativeTimeRangeProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-interruptionfilter.html#cfn-transcribe-callanalyticscategory-interruptionfilter-threshold
         */
        readonly threshold?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-transcriptfilter.html
     */
    interface TranscriptFilterProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-transcriptfilter.html#cfn-transcribe-callanalyticscategory-transcriptfilter-absolutetimerange
         */
        readonly absoluteTimeRange?: CfnCallAnalyticsCategoryPropsMixin.AbsoluteTimeRangeProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-transcriptfilter.html#cfn-transcribe-callanalyticscategory-transcriptfilter-negate
         */
        readonly negate?: boolean | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-transcriptfilter.html#cfn-transcribe-callanalyticscategory-transcriptfilter-participantrole
         */
        readonly participantRole?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-transcriptfilter.html#cfn-transcribe-callanalyticscategory-transcriptfilter-relativetimerange
         */
        readonly relativeTimeRange?: cdk.IResolvable | CfnCallAnalyticsCategoryPropsMixin.RelativeTimeRangeProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-transcriptfilter.html#cfn-transcribe-callanalyticscategory-transcriptfilter-targets
         */
        readonly targets?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-transcriptfilter.html#cfn-transcribe-callanalyticscategory-transcriptfilter-transcriptfiltertype
         */
        readonly transcriptFilterType?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-sentimentfilter.html
     */
    interface SentimentFilterProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-sentimentfilter.html#cfn-transcribe-callanalyticscategory-sentimentfilter-absolutetimerange
         */
        readonly absoluteTimeRange?: CfnCallAnalyticsCategoryPropsMixin.AbsoluteTimeRangeProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-sentimentfilter.html#cfn-transcribe-callanalyticscategory-sentimentfilter-negate
         */
        readonly negate?: boolean | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-sentimentfilter.html#cfn-transcribe-callanalyticscategory-sentimentfilter-participantrole
         */
        readonly participantRole?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-sentimentfilter.html#cfn-transcribe-callanalyticscategory-sentimentfilter-relativetimerange
         */
        readonly relativeTimeRange?: cdk.IResolvable | CfnCallAnalyticsCategoryPropsMixin.RelativeTimeRangeProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-callanalyticscategory-sentimentfilter.html#cfn-transcribe-callanalyticscategory-sentimentfilter-sentiments
         */
        readonly sentiments?: Array<string>;
    }
}
/**
 * Properties for CfnCallAnalyticsCategoryPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-callanalyticscategory.html
 */
export interface CfnCallAnalyticsCategoryMixinProps {
    /**
     * A unique name, chosen by you, for your Call Analytics category.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-callanalyticscategory.html#cfn-transcribe-callanalyticscategory-categoryname
     */
    readonly categoryName?: string;
    /**
     * The input type associated with the specified category.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-callanalyticscategory.html#cfn-transcribe-callanalyticscategory-inputtype
     */
    readonly inputType?: string;
    /**
     * Rules define a Call Analytics category.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-callanalyticscategory.html#cfn-transcribe-callanalyticscategory-rules
     */
    readonly rules?: Array<cdk.IResolvable | CfnCallAnalyticsCategoryPropsMixin.RuleProperty> | cdk.IResolvable;
    /**
     * Tags associated with the Call Analytics category.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-callanalyticscategory.html#cfn-transcribe-callanalyticscategory-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource type definition for AWS::Transcribe::MedicalVocabulary.
 *
 * @cloudformationResource AWS::Transcribe::MedicalVocabulary
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicalvocabulary.html
 */
export declare class CfnMedicalVocabularyPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnMedicalVocabularyMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Transcribe::MedicalVocabulary`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnMedicalVocabularyMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnMedicalVocabulary;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnMedicalVocabularyPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicalvocabulary.html
 */
export interface CfnMedicalVocabularyMixinProps {
    /**
     * The language code of the vocabulary entries.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicalvocabulary.html#cfn-transcribe-medicalvocabulary-languagecode
     */
    readonly languageCode?: string;
    /**
     * Tags associated with the medical vocabulary.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicalvocabulary.html#cfn-transcribe-medicalvocabulary-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The Amazon S3 location of the text file that contains the medical vocabulary.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicalvocabulary.html#cfn-transcribe-medicalvocabulary-vocabularyfileuri
     */
    readonly vocabularyFileUri?: string;
    /**
     * The name of the medical vocabulary.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicalvocabulary.html#cfn-transcribe-medicalvocabulary-vocabularyname
     */
    readonly vocabularyName?: string;
}
/**
 * Creates a custom vocabulary that you can use to improve the transcription accuracy of domain-specific words and phrases.
 *
 * @cloudformationResource AWS::Transcribe::Vocabulary
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabulary.html
 */
export declare class CfnVocabularyPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnVocabularyMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Transcribe::Vocabulary`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnVocabularyMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnVocabulary;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnVocabularyPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabulary.html
 */
export interface CfnVocabularyMixinProps {
    /**
     * The Amazon Resource Name (ARN) of an IAM role that has permissions to access the Amazon S3 bucket that contains your input file.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabulary.html#cfn-transcribe-vocabulary-dataaccessrolearn
     */
    readonly dataAccessRoleArn?: string;
    /**
     * The language code that represents the language of the entries in your custom vocabulary.
     *
     * Each custom vocabulary must contain terms in only one language.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabulary.html#cfn-transcribe-vocabulary-languagecode
     */
    readonly languageCode?: string;
    /**
     * Use this parameter if you want to create your custom vocabulary by including all desired terms, as comma-separated values, within your request.
     *
     * You cannot use this parameter together with VocabularyFileUri.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabulary.html#cfn-transcribe-vocabulary-phrases
     */
    readonly phrases?: Array<string>;
    /**
     * Adds one or more custom tags, each in the form of a key:value pair, to the custom vocabulary.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabulary.html#cfn-transcribe-vocabulary-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The Amazon S3 location of the text file that contains your custom vocabulary.
     *
     * You cannot use this parameter together with Phrases.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabulary.html#cfn-transcribe-vocabulary-vocabularyfileuri
     */
    readonly vocabularyFileUri?: string;
    /**
     * A unique name, chosen by you, for your custom vocabulary.
     *
     * This name is case sensitive, cannot contain spaces, and must be unique within an AWS account.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabulary.html#cfn-transcribe-vocabulary-vocabularyname
     */
    readonly vocabularyName?: string;
}
/**
 * Creates a custom vocabulary filter that you can use to mask, delete, or flag specific words from your transcript.
 *
 * @cloudformationResource AWS::Transcribe::VocabularyFilter
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html
 */
export declare class CfnVocabularyFilterPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnVocabularyFilterMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Transcribe::VocabularyFilter`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnVocabularyFilterMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnVocabularyFilter;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnVocabularyFilterPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html
 */
export interface CfnVocabularyFilterMixinProps {
    /**
     * The Amazon Resource Name (ARN) of an IAM role that has permissions to access the Amazon S3 bucket that contains your input files.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html#cfn-transcribe-vocabularyfilter-dataaccessrolearn
     */
    readonly dataAccessRoleArn?: string;
    /**
     * The language code that represents the language of the entries in your vocabulary filter.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html#cfn-transcribe-vocabularyfilter-languagecode
     */
    readonly languageCode?: string;
    /**
     * Tags associated with the vocabulary filter.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html#cfn-transcribe-vocabularyfilter-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The Amazon S3 location of the text file that contains your custom vocabulary filter terms.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html#cfn-transcribe-vocabularyfilter-vocabularyfilterfileuri
     */
    readonly vocabularyFilterFileUri?: string;
    /**
     * A unique name, chosen by you, for your custom vocabulary filter.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html#cfn-transcribe-vocabularyfilter-vocabularyfiltername
     */
    readonly vocabularyFilterName?: string;
    /**
     * Use this parameter if you want to create your custom vocabulary filter by including all desired terms, as comma-separated values, within your request.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html#cfn-transcribe-vocabularyfilter-words
     */
    readonly words?: Array<string>;
}
