import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-storagegateway";
/**
 * Creates a virtual tape with a user-defined barcode on a Tape Gateway (VTL).
 *
 * A virtual tape is stored in Amazon S3 and can be archived to S3 Glacier or S3 Glacier Deep Archive.
 *
 * @cloudformationResource AWS::StorageGateway::Tape
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html
 */
export declare class CfnTapePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTapeMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::StorageGateway::Tape`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTapeMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTape;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnTapePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html
 */
export interface CfnTapeMixinProps {
    /**
     * The Amazon Resource Name (ARN) of the Tape Gateway that hosts the virtual tape.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-gatewayarn
     */
    readonly gatewayArn?: string;
    /**
     * Set to true to use Amazon S3 server-side encryption with your own KMS key, or false to use a key managed by Amazon S3.
     *
     * Optional.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-kmsencrypted
     */
    readonly kmsEncrypted?: boolean | cdk.IResolvable;
    /**
     * The Amazon Resource Name (ARN) of a symmetric customer master key (CMK) used for Amazon S3 server-side encryption.
     *
     * This value must be set if KMSEncrypted is true.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-kmskey
     */
    readonly kmsKey?: string;
    /**
     * The ID of the pool that you want to add your tape to for archiving.
     *
     * Tapes in this pool are archived in the S3 storage class that is associated with the pool.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-poolid
     */
    readonly poolId?: string;
    /**
     * A list of up to 50 tags to assign to the virtual tape.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The barcode that you want to assign to the virtual tape.
     *
     * Barcodes cannot be reused, even after a tape is deleted.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-tapebarcode
     */
    readonly tapeBarcode?: string;
    /**
     * The size, in bytes, of the virtual tape that you want to create.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-tapesizeinbytes
     */
    readonly tapeSizeInBytes?: number;
    /**
     * Set to true to create a write-once-read-many (WORM) virtual tape.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-worm
     */
    readonly worm?: boolean | cdk.IResolvable;
}
/**
 * Creates a custom tape pool for archiving virtual tapes with optional retention lock.
 *
 * @cloudformationResource AWS::StorageGateway::TapePool
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html
 */
export declare class CfnTapePoolPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTapePoolMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::StorageGateway::TapePool`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTapePoolMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTapePool;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnTapePoolPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html
 */
export interface CfnTapePoolMixinProps {
    /**
     * The name of the custom tape pool.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html#cfn-storagegateway-tapepool-poolname
     */
    readonly poolName?: string;
    /**
     * Tape retention lock time in days (up to 36,500 days / 100 years).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html#cfn-storagegateway-tapepool-retentionlocktimeindays
     */
    readonly retentionLockTimeInDays?: number;
    /**
     * Tape retention lock type.
     *
     * Governance mode allows authorized removal; compliance mode prevents all removal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html#cfn-storagegateway-tapepool-retentionlocktype
     */
    readonly retentionLockType?: string;
    /**
     * The storage class associated with the custom pool (S3 Glacier or S3 Glacier Deep Archive).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html#cfn-storagegateway-tapepool-storageclass
     */
    readonly storageClass?: string;
    /**
     * A list of up to 50 tags for the tape pool.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html#cfn-storagegateway-tapepool-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a cached iSCSI volume on a Storage Gateway.
 *
 * A cached volume stores data in Amazon S3 and retains a copy of frequently accessed data subsets locally.
 *
 * @cloudformationResource AWS::StorageGateway::Volume
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html
 */
export declare class CfnVolumePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnVolumeMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::StorageGateway::Volume`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnVolumeMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnVolume;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnVolumePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html
 */
export interface CfnVolumeMixinProps {
    /**
     * The Amazon Resource Name (ARN) of the gateway on which to create the volume.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-gatewayarn
     */
    readonly gatewayArn?: string;
    /**
     * Set to true to use Amazon S3 server-side encryption with your own KMS key, or false to use a key managed by Amazon S3.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-kmsencrypted
     */
    readonly kmsEncrypted?: boolean | cdk.IResolvable;
    /**
     * The Amazon Resource Name (ARN) of a symmetric customer master key (CMK) used for Amazon S3 server-side encryption.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-kmskey
     */
    readonly kmsKey?: string;
    /**
     * The network interface of the gateway on which to expose the iSCSI target.
     *
     * Only IPv4 addresses are accepted.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-networkinterfaceid
     */
    readonly networkInterfaceId?: string;
    /**
     * The snapshot ID of the snapshot to restore as the new cached volume (e.g., snap-1122aabb).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-snapshotid
     */
    readonly snapshotId?: string;
    /**
     * The ARN of an existing volume from which to create the new volume.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-sourcevolumearn
     */
    readonly sourceVolumeArn?: string;
    /**
     * A list of up to 50 tags to assign to the volume.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The name of the iSCSI target used by an initiator to connect to a volume and used as a suffix for the target ARN.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-targetname
     */
    readonly targetName?: string;
    /**
     * The size of the volume in bytes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-volumesizeinbytes
     */
    readonly volumeSizeInBytes?: number;
}
