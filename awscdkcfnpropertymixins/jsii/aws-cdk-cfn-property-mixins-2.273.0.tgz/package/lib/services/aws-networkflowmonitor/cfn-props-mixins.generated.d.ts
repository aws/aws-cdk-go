import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-networkflowmonitor";
/**
 * Creates a monitor for specific network flows between local and remote resources to monitor network performance for workloads.
 *
 * @cloudformationResource AWS::NetworkFlowMonitor::Monitor
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkflowmonitor-monitor.html
 */
export declare class CfnMonitorPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnMonitorMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::NetworkFlowMonitor::Monitor`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnMonitorMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnMonitor;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnMonitorPropsMixin {
    /**
     * A local resource is the host where the agent is installed.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-monitor-monitorlocalresource.html
     */
    interface MonitorLocalResourceProperty {
        /**
         * The identifier of the local resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-monitor-monitorlocalresource.html#cfn-networkflowmonitor-monitor-monitorlocalresource-identifier
         */
        readonly identifier?: string;
        /**
         * The type of the local resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-monitor-monitorlocalresource.html#cfn-networkflowmonitor-monitor-monitorlocalresource-type
         */
        readonly type?: string;
    }
    /**
     * A remote resource is the other endpoint in a network flow.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-monitor-monitorremoteresource.html
     */
    interface MonitorRemoteResourceProperty {
        /**
         * The identifier of the remote resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-monitor-monitorremoteresource.html#cfn-networkflowmonitor-monitor-monitorremoteresource-identifier
         */
        readonly identifier?: string;
        /**
         * The type of the remote resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-monitor-monitorremoteresource.html#cfn-networkflowmonitor-monitor-monitorremoteresource-type
         */
        readonly type?: string;
    }
}
/**
 * Properties for CfnMonitorPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkflowmonitor-monitor.html
 */
export interface CfnMonitorMixinProps {
    /**
     * The local resources to monitor.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkflowmonitor-monitor.html#cfn-networkflowmonitor-monitor-localresources
     */
    readonly localResources?: Array<cdk.IResolvable | CfnMonitorPropsMixin.MonitorLocalResourceProperty> | cdk.IResolvable;
    /**
     * The name of the monitor.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkflowmonitor-monitor.html#cfn-networkflowmonitor-monitor-monitorname
     */
    readonly monitorName?: string;
    /**
     * The remote resources to monitor.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkflowmonitor-monitor.html#cfn-networkflowmonitor-monitor-remoteresources
     */
    readonly remoteResources?: Array<cdk.IResolvable | CfnMonitorPropsMixin.MonitorRemoteResourceProperty> | cdk.IResolvable;
    /**
     * The Amazon Resource Name (ARN) of the scope for the monitor.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkflowmonitor-monitor.html#cfn-networkflowmonitor-monitor-scopearn
     */
    readonly scopeArn?: string;
    /**
     * The tags for the monitor.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkflowmonitor-monitor.html#cfn-networkflowmonitor-monitor-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for AWS::NetworkFlowMonitor::Scope.
 *
 * Creates a scope to define the resources that Network Flow Monitor monitors for network performance.
 *
 * @cloudformationResource AWS::NetworkFlowMonitor::Scope
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkflowmonitor-scope.html
 */
export declare class CfnScopePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnScopeMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::NetworkFlowMonitor::Scope`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnScopeMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnScope;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnScopePropsMixin {
    /**
     * A target resource in a scope, identified by a Region and target identifier.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-scope-targetresource.html
     */
    interface TargetResourceProperty {
        /**
         * The AWS Region for the target resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-scope-targetresource.html#cfn-networkflowmonitor-scope-targetresource-region
         */
        readonly region?: string;
        /**
         * A target identifier is a pair of identifying information for a scope target.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-scope-targetresource.html#cfn-networkflowmonitor-scope-targetresource-targetidentifier
         */
        readonly targetIdentifier?: cdk.IResolvable | CfnScopePropsMixin.TargetIdentifierProperty;
    }
    /**
     * A target identifier is a pair of identifying information for a scope target.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-scope-targetidentifier.html
     */
    interface TargetIdentifierProperty {
        /**
         * A target ID is an internally-generated identifier for a target.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-scope-targetidentifier.html#cfn-networkflowmonitor-scope-targetidentifier-targetid
         */
        readonly targetId?: cdk.IResolvable | CfnScopePropsMixin.TargetIdProperty;
        /**
         * The type of the target.
         *
         * Currently always ACCOUNT.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-scope-targetidentifier.html#cfn-networkflowmonitor-scope-targetidentifier-targettype
         */
        readonly targetType?: string;
    }
    /**
     * A target ID is an internally-generated identifier for a target.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-scope-targetid.html
     */
    interface TargetIdProperty {
        /**
         * The account ID for the target.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-networkflowmonitor-scope-targetid.html#cfn-networkflowmonitor-scope-targetid-accountid
         */
        readonly accountId?: string;
    }
}
/**
 * Properties for CfnScopePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkflowmonitor-scope.html
 */
export interface CfnScopeMixinProps {
    /**
     * The tags for the scope.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkflowmonitor-scope.html#cfn-networkflowmonitor-scope-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The targets for the scope.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkflowmonitor-scope.html#cfn-networkflowmonitor-scope-targets
     */
    readonly targets?: Array<cdk.IResolvable | CfnScopePropsMixin.TargetResourceProperty> | cdk.IResolvable;
}
