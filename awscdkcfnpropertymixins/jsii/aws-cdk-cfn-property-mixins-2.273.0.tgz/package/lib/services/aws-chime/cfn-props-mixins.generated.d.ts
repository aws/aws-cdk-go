import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-chime";
/**
 * Resource Type definition for AWS::Chime::AppInstance.
 *
 * @cloudformationResource AWS::Chime::AppInstance
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstance.html
 */
export declare class CfnAppInstancePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnAppInstanceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Chime::AppInstance`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnAppInstanceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAppInstance;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnAppInstancePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstance.html
 */
export interface CfnAppInstanceMixinProps {
    /**
     * The metadata of the AppInstance.
     *
     * Limited to a 1KB string in UTF-8.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstance.html#cfn-chime-appinstance-metadata
     */
    readonly metadata?: string;
    /**
     * The name of the AppInstance.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstance.html#cfn-chime-appinstance-name
     */
    readonly name?: string;
    /**
     * Tags assigned to the AppInstance.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstance.html#cfn-chime-appinstance-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for AWS::Chime::AppInstanceBot.
 *
 * @cloudformationResource AWS::Chime::AppInstanceBot
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstancebot.html
 */
export declare class CfnAppInstanceBotPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnAppInstanceBotMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Chime::AppInstanceBot`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnAppInstanceBotMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAppInstanceBot;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnAppInstanceBotPropsMixin {
    /**
     * A structure that contains configuration data.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstancebot-configuration.html
     */
    interface ConfigurationProperty {
        /**
         * The configuration for an Amazon Lex V2 bot.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstancebot-configuration.html#cfn-chime-appinstancebot-configuration-lex
         */
        readonly lex?: cdk.IResolvable | CfnAppInstanceBotPropsMixin.LexConfigurationProperty;
    }
    /**
     * The configuration for an Amazon Lex V2 bot.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstancebot-lexconfiguration.html
     */
    interface LexConfigurationProperty {
        /**
         * Specifies the type of message that triggers a bot.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstancebot-lexconfiguration.html#cfn-chime-appinstancebot-lexconfiguration-invokedby
         */
        readonly invokedBy?: CfnAppInstanceBotPropsMixin.InvokedByProperty | cdk.IResolvable;
        /**
         * The ARN of the Amazon Lex V2 bot's alias.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstancebot-lexconfiguration.html#cfn-chime-appinstancebot-lexconfiguration-lexbotaliasarn
         */
        readonly lexBotAliasArn?: string;
        /**
         * Identifies the Amazon Lex V2 bot's language and locale.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstancebot-lexconfiguration.html#cfn-chime-appinstancebot-lexconfiguration-localeid
         */
        readonly localeId?: string;
        /**
         * Determines whether the Amazon Lex V2 bot responds to all standard messages.
         *
         * Control messages are not supported.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstancebot-lexconfiguration.html#cfn-chime-appinstancebot-lexconfiguration-respondsto
         */
        readonly respondsTo?: string;
        /**
         * The name of the welcome intent configured in the Amazon Lex V2 bot.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstancebot-lexconfiguration.html#cfn-chime-appinstancebot-lexconfiguration-welcomeintent
         */
        readonly welcomeIntent?: string;
    }
    /**
     * Specifies the type of message that triggers a bot.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstancebot-invokedby.html
     */
    interface InvokedByProperty {
        /**
         * Sets standard messages as the bot trigger.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstancebot-invokedby.html#cfn-chime-appinstancebot-invokedby-standardmessages
         */
        readonly standardMessages?: string;
        /**
         * Sets targeted messages as the bot trigger.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstancebot-invokedby.html#cfn-chime-appinstancebot-invokedby-targetedmessages
         */
        readonly targetedMessages?: string;
    }
}
/**
 * Properties for CfnAppInstanceBotPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstancebot.html
 */
export interface CfnAppInstanceBotMixinProps {
    /**
     * The ARN of the AppInstance.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstancebot.html#cfn-chime-appinstancebot-appinstancearn
     */
    readonly appInstanceArn?: string;
    /**
     * A structure that contains configuration data.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstancebot.html#cfn-chime-appinstancebot-configuration
     */
    readonly configuration?: CfnAppInstanceBotPropsMixin.ConfigurationProperty | cdk.IResolvable;
    /**
     * The metadata of the AppInstanceBot.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstancebot.html#cfn-chime-appinstancebot-metadata
     */
    readonly metadata?: string;
    /**
     * The name of the AppInstanceBot.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstancebot.html#cfn-chime-appinstancebot-name
     */
    readonly name?: string;
    /**
     * The tags assigned to the AppInstanceBot.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstancebot.html#cfn-chime-appinstancebot-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for AWS::Chime::AppInstanceUser.
 *
 * @cloudformationResource AWS::Chime::AppInstanceUser
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstanceuser.html
 */
export declare class CfnAppInstanceUserPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnAppInstanceUserMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Chime::AppInstanceUser`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnAppInstanceUserMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAppInstanceUser;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnAppInstanceUserPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstanceuser-expirationsettings.html
     */
    interface ExpirationSettingsProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstanceuser-expirationsettings.html#cfn-chime-appinstanceuser-expirationsettings-expirationcriterion
         */
        readonly expirationCriterion?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-appinstanceuser-expirationsettings.html#cfn-chime-appinstanceuser-expirationsettings-expirationdays
         */
        readonly expirationDays?: number;
    }
}
/**
 * Properties for CfnAppInstanceUserPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstanceuser.html
 */
export interface CfnAppInstanceUserMixinProps {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstanceuser.html#cfn-chime-appinstanceuser-appinstancearn
     */
    readonly appInstanceArn?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstanceuser.html#cfn-chime-appinstanceuser-appinstanceuserid
     */
    readonly appInstanceUserId?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstanceuser.html#cfn-chime-appinstanceuser-expirationsettings
     */
    readonly expirationSettings?: CfnAppInstanceUserPropsMixin.ExpirationSettingsProperty | cdk.IResolvable;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstanceuser.html#cfn-chime-appinstanceuser-metadata
     */
    readonly metadata?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstanceuser.html#cfn-chime-appinstanceuser-name
     */
    readonly name?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-appinstanceuser.html#cfn-chime-appinstanceuser-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a channel in an Amazon Chime SDK Messaging AppInstance.
 *
 * Members of a channel exchange messages within it. Every channel operation is performed on behalf of an AppInstanceUser or AppInstanceBot, whose ARN is supplied as ChimeBearer and forms part of the channel's CloudFormation identifier.
 *
 * @cloudformationResource AWS::Chime::Channel
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html
 */
export declare class CfnChannelPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnChannelMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Chime::Channel`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnChannelMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnChannel;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnChannelPropsMixin {
    /**
     * The attributes required to configure and create an elastic channel.
     *
     * An elastic channel must use RESTRICTED mode, cannot be created with MemberArns, and is available only in some regions.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channel-elasticchannelconfiguration.html
     */
    interface ElasticChannelConfigurationProperty {
        /**
         * The maximum number of SubChannels allowed in the elastic channel.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channel-elasticchannelconfiguration.html#cfn-chime-channel-elasticchannelconfiguration-maximumsubchannels
         */
        readonly maximumSubChannels?: number;
        /**
         * The minimum allowed percentage of TargetMembershipsPerSubChannel users, used to balance members across SubChannels.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channel-elasticchannelconfiguration.html#cfn-chime-channel-elasticchannelconfiguration-minimummembershippercentage
         */
        readonly minimumMembershipPercentage?: number;
        /**
         * The maximum number of members allowed in a SubChannel.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channel-elasticchannelconfiguration.html#cfn-chime-channel-elasticchannelconfiguration-targetmembershipspersubchannel
         */
        readonly targetMembershipsPerSubChannel?: number;
    }
    /**
     * Settings that control the interval after which the channel is automatically deleted.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channel-expirationsettings.html
     */
    interface ExpirationSettingsProperty {
        /**
         * The condition the expiration period is measured from.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channel-expirationsettings.html#cfn-chime-channel-expirationsettings-expirationcriterion
         */
        readonly expirationCriterion?: string;
        /**
         * The period in days after which the system automatically deletes the channel.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channel-expirationsettings.html#cfn-chime-channel-expirationsettings-expirationdays
         */
        readonly expirationDays?: number;
    }
    /**
     * The AppInstanceUser or AppInstanceBot that created the channel.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channel-identity.html
     */
    interface IdentityProperty {
        /**
         * The ARN in an identity.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channel-identity.html#cfn-chime-channel-identity-arn
         */
        readonly arn?: string;
        /**
         * The name in an identity.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channel-identity.html#cfn-chime-channel-identity-name
         */
        readonly name?: string;
    }
}
/**
 * Properties for CfnChannelPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html
 */
export interface CfnChannelMixinProps {
    /**
     * The ARN of the AppInstance that contains the channel.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html#cfn-chime-channel-appinstancearn
     */
    readonly appInstanceArn?: string;
    /**
     * The ID of the channel.
     *
     * When omitted, the service generates a UUID.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html#cfn-chime-channel-channelid
     */
    readonly channelId?: string;
    /**
     * The ARN of the AppInstanceUser or AppInstanceBot that performs every operation on this channel.
     *
     * Whichever of the two creates a channel automatically becomes one of its moderators, so the same ARN can subsequently read, update and delete the channel.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html#cfn-chime-channel-chimebearer
     */
    readonly chimeBearer?: string;
    /**
     * The attributes required to configure and create an elastic channel.
     *
     * An elastic channel must use RESTRICTED mode, cannot be created with MemberArns, and is available only in some regions.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html#cfn-chime-channel-elasticchannelconfiguration
     */
    readonly elasticChannelConfiguration?: CfnChannelPropsMixin.ElasticChannelConfigurationProperty | cdk.IResolvable;
    /**
     * Settings that control the interval after which the channel is automatically deleted.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html#cfn-chime-channel-expirationsettings
     */
    readonly expirationSettings?: CfnChannelPropsMixin.ExpirationSettingsProperty | cdk.IResolvable;
    /**
     * The ARNs of the AppInstanceUsers to add to the channel as members when it is created.
     *
     * Cannot be combined with ElasticChannelConfiguration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html#cfn-chime-channel-memberarns
     */
    readonly memberArns?: Array<string>;
    /**
     * The metadata of the channel.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html#cfn-chime-channel-metadata
     */
    readonly metadata?: string;
    /**
     * The channel mode.
     *
     * In an UNRESTRICTED channel, members can add themselves and other members; in a RESTRICTED channel, only administrators and moderators can add members. An elastic channel must be RESTRICTED.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html#cfn-chime-channel-mode
     */
    readonly mode?: string;
    /**
     * The ARNs of the AppInstanceUsers to add to the channel as moderators when it is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html#cfn-chime-channel-moderatorarns
     */
    readonly moderatorArns?: Array<string>;
    /**
     * The name of the channel.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html#cfn-chime-channel-name
     */
    readonly name?: string;
    /**
     * The channel's privacy level.
     *
     * A PUBLIC channel is discoverable by anyone in the AppInstance; a PRIVATE channel is not. Privacy cannot be changed after creation.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html#cfn-chime-channel-privacy
     */
    readonly privacy?: string;
    /**
     * The tags for the channel.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channel.html#cfn-chime-channel-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a channel flow in the Amazon Chime SDK Messaging service.
 *
 * A channel flow is a container for processors (Lambda functions) that perform actions on chat messages.
 *
 * @cloudformationResource AWS::Chime::ChannelFlow
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channelflow.html
 */
export declare class CfnChannelFlowPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnChannelFlowMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Chime::ChannelFlow`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnChannelFlowMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnChannelFlow;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnChannelFlowPropsMixin {
    /**
     * Information about a processor in a channel flow.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channelflow-processor.html
     */
    interface ProcessorProperty {
        /**
         * A processor's metadata.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channelflow-processor.html#cfn-chime-channelflow-processor-configuration
         */
        readonly configuration?: cdk.IResolvable | CfnChannelFlowPropsMixin.ProcessorConfigurationProperty;
        /**
         * The sequence in which processors run.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channelflow-processor.html#cfn-chime-channelflow-processor-executionorder
         */
        readonly executionOrder?: number;
        /**
         * Determines whether to continue or stop processing when communication with a processor fails.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channelflow-processor.html#cfn-chime-channelflow-processor-fallbackaction
         */
        readonly fallbackAction?: string;
        /**
         * The name of the processor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channelflow-processor.html#cfn-chime-channelflow-processor-name
         */
        readonly name?: string;
    }
    /**
     * A processor's metadata.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channelflow-processorconfiguration.html
     */
    interface ProcessorConfigurationProperty {
        /**
         * Stores metadata about a Lambda processor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channelflow-processorconfiguration.html#cfn-chime-channelflow-processorconfiguration-lambda
         */
        readonly lambda?: cdk.IResolvable | CfnChannelFlowPropsMixin.LambdaConfigurationProperty;
    }
    /**
     * Stores metadata about a Lambda processor.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channelflow-lambdaconfiguration.html
     */
    interface LambdaConfigurationProperty {
        /**
         * Controls how the Lambda function is invoked.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channelflow-lambdaconfiguration.html#cfn-chime-channelflow-lambdaconfiguration-invocationtype
         */
        readonly invocationType?: string;
        /**
         * The ARN of the Lambda message processing function.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-channelflow-lambdaconfiguration.html#cfn-chime-channelflow-lambdaconfiguration-resourcearn
         */
        readonly resourceArn?: string;
    }
}
/**
 * Properties for CfnChannelFlowPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channelflow.html
 */
export interface CfnChannelFlowMixinProps {
    /**
     * The ARN of the app instance.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channelflow.html#cfn-chime-channelflow-appinstancearn
     */
    readonly appInstanceArn?: string;
    /**
     * The name of the channel flow.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channelflow.html#cfn-chime-channelflow-name
     */
    readonly name?: string;
    /**
     * Information about the processor Lambda functions.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channelflow.html#cfn-chime-channelflow-processors
     */
    readonly processors?: Array<cdk.IResolvable | CfnChannelFlowPropsMixin.ProcessorProperty> | cdk.IResolvable;
    /**
     * The tags for the channel flow.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-channelflow.html#cfn-chime-channelflow-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for an Amazon Chime SDK Media Insights Pipeline Configuration.
 *
 * @cloudformationResource AWS::Chime::MediaInsightsPipelineConfiguration
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-mediainsightspipelineconfiguration.html
 */
export declare class CfnMediaInsightsPipelineConfigurationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnMediaInsightsPipelineConfigurationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Chime::MediaInsightsPipelineConfiguration`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnMediaInsightsPipelineConfigurationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnMediaInsightsPipelineConfiguration;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnMediaInsightsPipelineConfigurationPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-realtimealertconfiguration.html
     */
    interface RealTimeAlertConfigurationProperty {
        /**
         * Turns off real-time alerts.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-realtimealertconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-realtimealertconfiguration-disabled
         */
        readonly disabled?: boolean | cdk.IResolvable;
        /**
         * The rules in the alert.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-realtimealertconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-realtimealertconfiguration-rules
         */
        readonly rules?: Array<cdk.IResolvable | CfnMediaInsightsPipelineConfigurationPropsMixin.RealTimeAlertRuleProperty> | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-realtimealertrule.html
     */
    interface RealTimeAlertRuleProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-realtimealertrule.html#cfn-chime-mediainsightspipelineconfiguration-realtimealertrule-issuedetectionconfiguration
         */
        readonly issueDetectionConfiguration?: cdk.IResolvable | CfnMediaInsightsPipelineConfigurationPropsMixin.IssueDetectionConfigurationProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-realtimealertrule.html#cfn-chime-mediainsightspipelineconfiguration-realtimealertrule-keywordmatchconfiguration
         */
        readonly keywordMatchConfiguration?: cdk.IResolvable | CfnMediaInsightsPipelineConfigurationPropsMixin.KeywordMatchConfigurationProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-realtimealertrule.html#cfn-chime-mediainsightspipelineconfiguration-realtimealertrule-sentimentconfiguration
         */
        readonly sentimentConfiguration?: cdk.IResolvable | CfnMediaInsightsPipelineConfigurationPropsMixin.SentimentConfigurationProperty;
        /**
         * The type of alert rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-realtimealertrule.html#cfn-chime-mediainsightspipelineconfiguration-realtimealertrule-type
         */
        readonly type?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-keywordmatchconfiguration.html
     */
    interface KeywordMatchConfigurationProperty {
        /**
         * The keywords or phrases to match.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-keywordmatchconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-keywordmatchconfiguration-keywords
         */
        readonly keywords?: Array<string>;
        /**
         * Matches keywords on their presence or absence.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-keywordmatchconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-keywordmatchconfiguration-negate
         */
        readonly negate?: boolean | cdk.IResolvable;
        /**
         * The name of the keyword match rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-keywordmatchconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-keywordmatchconfiguration-rulename
         */
        readonly ruleName?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-sentimentconfiguration.html
     */
    interface SentimentConfigurationProperty {
        /**
         * The name of the sentiment rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-sentimentconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-sentimentconfiguration-rulename
         */
        readonly ruleName?: string;
        /**
         * The type of sentiment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-sentimentconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-sentimentconfiguration-sentimenttype
         */
        readonly sentimentType?: string;
        /**
         * The analysis interval in seconds.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-sentimentconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-sentimentconfiguration-timeperiod
         */
        readonly timePeriod?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-issuedetectionconfiguration.html
     */
    interface IssueDetectionConfigurationProperty {
        /**
         * The name of the issue detection rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-issuedetectionconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-issuedetectionconfiguration-rulename
         */
        readonly ruleName?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-mediainsightspipelineconfigurationelement.html
     */
    interface MediaInsightsPipelineConfigurationElementProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-mediainsightspipelineconfigurationelement.html#cfn-chime-mediainsightspipelineconfiguration-mediainsightspipelineconfigurationelement-amazontranscribecallanalyticsprocessorconfiguration
         */
        readonly amazonTranscribeCallAnalyticsProcessorConfiguration?: CfnMediaInsightsPipelineConfigurationPropsMixin.AmazonTranscribeCallAnalyticsProcessorConfigurationProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-mediainsightspipelineconfigurationelement.html#cfn-chime-mediainsightspipelineconfiguration-mediainsightspipelineconfigurationelement-amazontranscribeprocessorconfiguration
         */
        readonly amazonTranscribeProcessorConfiguration?: CfnMediaInsightsPipelineConfigurationPropsMixin.AmazonTranscribeProcessorConfigurationProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-mediainsightspipelineconfigurationelement.html#cfn-chime-mediainsightspipelineconfiguration-mediainsightspipelineconfigurationelement-kinesisdatastreamsinkconfiguration
         */
        readonly kinesisDataStreamSinkConfiguration?: cdk.IResolvable | CfnMediaInsightsPipelineConfigurationPropsMixin.KinesisDataStreamSinkConfigurationProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-mediainsightspipelineconfigurationelement.html#cfn-chime-mediainsightspipelineconfiguration-mediainsightspipelineconfigurationelement-s3recordingsinkconfiguration
         */
        readonly s3RecordingSinkConfiguration?: cdk.IResolvable | CfnMediaInsightsPipelineConfigurationPropsMixin.S3RecordingSinkConfigurationProperty;
        /**
         * The element type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-mediainsightspipelineconfigurationelement.html#cfn-chime-mediainsightspipelineconfiguration-mediainsightspipelineconfigurationelement-type
         */
        readonly type?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html
     */
    interface AmazonTranscribeCallAnalyticsProcessorConfigurationProperty {
        /**
         * The categories to send to the insights target.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration-callanalyticsstreamcategories
         */
        readonly callAnalyticsStreamCategories?: Array<string>;
        /**
         * Labels all PII identified in the transcript.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration-contentidentificationtype
         */
        readonly contentIdentificationType?: string;
        /**
         * Redacts all PII identified in the transcript.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration-contentredactiontype
         */
        readonly contentRedactionType?: string;
        /**
         * Enables partial result stabilization.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration-enablepartialresultsstabilization
         */
        readonly enablePartialResultsStabilization?: boolean | cdk.IResolvable;
        /**
         * If true, partial results are filtered out.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration-filterpartialresults
         */
        readonly filterPartialResults?: boolean | cdk.IResolvable;
        /**
         * The language code in the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration-languagecode
         */
        readonly languageCode?: string;
        /**
         * The name of the custom language model.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration-languagemodelname
         */
        readonly languageModelName?: string;
        /**
         * The level of stability for partial results.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration-partialresultsstability
         */
        readonly partialResultsStability?: string;
        /**
         * The types of PII to redact.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration-piientitytypes
         */
        readonly piiEntityTypes?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration-postcallanalyticssettings
         */
        readonly postCallAnalyticsSettings?: cdk.IResolvable | CfnMediaInsightsPipelineConfigurationPropsMixin.PostCallAnalyticsSettingsProperty;
        /**
         * The vocabulary filtering method.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration-vocabularyfiltermethod
         */
        readonly vocabularyFilterMethod?: string;
        /**
         * The name of the custom vocabulary filter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration-vocabularyfiltername
         */
        readonly vocabularyFilterName?: string;
        /**
         * The name of the custom vocabulary.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribecallanalyticsprocessorconfiguration-vocabularyname
         */
        readonly vocabularyName?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-postcallanalyticssettings.html
     */
    interface PostCallAnalyticsSettingsProperty {
        /**
         * The content redaction output settings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-postcallanalyticssettings.html#cfn-chime-mediainsightspipelineconfiguration-postcallanalyticssettings-contentredactionoutput
         */
        readonly contentRedactionOutput?: string;
        /**
         * The ARN of the role used by Transcribe to upload post-call analysis.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-postcallanalyticssettings.html#cfn-chime-mediainsightspipelineconfiguration-postcallanalyticssettings-dataaccessrolearn
         */
        readonly dataAccessRoleArn?: string;
        /**
         * The ID of the KMS key used to encrypt the output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-postcallanalyticssettings.html#cfn-chime-mediainsightspipelineconfiguration-postcallanalyticssettings-outputencryptionkmskeyid
         */
        readonly outputEncryptionKmsKeyId?: string;
        /**
         * The URL of the Amazon S3 bucket for post-call data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-postcallanalyticssettings.html#cfn-chime-mediainsightspipelineconfiguration-postcallanalyticssettings-outputlocation
         */
        readonly outputLocation?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html
     */
    interface AmazonTranscribeProcessorConfigurationProperty {
        /**
         * Labels all PII identified in the transcript.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-contentidentificationtype
         */
        readonly contentIdentificationType?: string;
        /**
         * Redacts all PII identified in the transcript.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-contentredactiontype
         */
        readonly contentRedactionType?: string;
        /**
         * Enables partial result stabilization.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-enablepartialresultsstabilization
         */
        readonly enablePartialResultsStabilization?: boolean | cdk.IResolvable;
        /**
         * If true, partial results are filtered out.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-filterpartialresults
         */
        readonly filterPartialResults?: boolean | cdk.IResolvable;
        /**
         * Turns language identification on or off.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-identifylanguage
         */
        readonly identifyLanguage?: boolean | cdk.IResolvable;
        /**
         * Turns multiple language identification on or off.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-identifymultiplelanguages
         */
        readonly identifyMultipleLanguages?: boolean | cdk.IResolvable;
        /**
         * The language code.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-languagecode
         */
        readonly languageCode?: string;
        /**
         * The name of the custom language model.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-languagemodelname
         */
        readonly languageModelName?: string;
        /**
         * The language options for transcription.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-languageoptions
         */
        readonly languageOptions?: string;
        /**
         * The level of stability for partial results.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-partialresultsstability
         */
        readonly partialResultsStability?: string;
        /**
         * The types of PII to redact.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-piientitytypes
         */
        readonly piiEntityTypes?: string;
        /**
         * The preferred language for transcription.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-preferredlanguage
         */
        readonly preferredLanguage?: string;
        /**
         * Enables speaker partitioning.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-showspeakerlabel
         */
        readonly showSpeakerLabel?: boolean | cdk.IResolvable;
        /**
         * The vocabulary filtering method.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-vocabularyfiltermethod
         */
        readonly vocabularyFilterMethod?: string;
        /**
         * The name of the custom vocabulary filter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-vocabularyfiltername
         */
        readonly vocabularyFilterName?: string;
        /**
         * The names of the custom vocabulary filters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-vocabularyfilternames
         */
        readonly vocabularyFilterNames?: string;
        /**
         * The name of the custom vocabulary.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-vocabularyname
         */
        readonly vocabularyName?: string;
        /**
         * The names of the custom vocabularies.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-amazontranscribeprocessorconfiguration-vocabularynames
         */
        readonly vocabularyNames?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-kinesisdatastreamsinkconfiguration.html
     */
    interface KinesisDataStreamSinkConfigurationProperty {
        /**
         * The ARN of the Kinesis Data Stream sink.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-kinesisdatastreamsinkconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-kinesisdatastreamsinkconfiguration-insightstarget
         */
        readonly insightsTarget?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-s3recordingsinkconfiguration.html
     */
    interface S3RecordingSinkConfigurationProperty {
        /**
         * The default URI of the Amazon S3 bucket.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-s3recordingsinkconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-s3recordingsinkconfiguration-destination
         */
        readonly destination?: string;
        /**
         * The recording file format.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediainsightspipelineconfiguration-s3recordingsinkconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-s3recordingsinkconfiguration-recordingfileformat
         */
        readonly recordingFileFormat?: string;
    }
}
/**
 * Properties for CfnMediaInsightsPipelineConfigurationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-mediainsightspipelineconfiguration.html
 */
export interface CfnMediaInsightsPipelineConfigurationMixinProps {
    /**
     * The elements in the configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-mediainsightspipelineconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-elements
     */
    readonly elements?: Array<cdk.IResolvable | CfnMediaInsightsPipelineConfigurationPropsMixin.MediaInsightsPipelineConfigurationElementProperty> | cdk.IResolvable;
    /**
     * The name of the media insights pipeline configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-mediainsightspipelineconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-mediainsightspipelineconfigurationname
     */
    readonly mediaInsightsPipelineConfigurationName?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-mediainsightspipelineconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-realtimealertconfiguration
     */
    readonly realTimeAlertConfiguration?: cdk.IResolvable | CfnMediaInsightsPipelineConfigurationPropsMixin.RealTimeAlertConfigurationProperty;
    /**
     * The ARN of the role used by the service to access Amazon Web Services resources.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-mediainsightspipelineconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-resourceaccessrolearn
     */
    readonly resourceAccessRoleArn?: string;
    /**
     * The tags associated with the configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-mediainsightspipelineconfiguration.html#cfn-chime-mediainsightspipelineconfiguration-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for an Amazon Chime SDK Media Pipeline Kinesis Video Stream Pool.
 *
 * @cloudformationResource AWS::Chime::MediaPipelineKinesisVideoStreamPool
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-mediapipelinekinesisvideostreampool.html
 */
export declare class CfnMediaPipelineKinesisVideoStreamPoolPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnMediaPipelineKinesisVideoStreamPoolMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Chime::MediaPipelineKinesisVideoStreamPool`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnMediaPipelineKinesisVideoStreamPoolMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnMediaPipelineKinesisVideoStreamPool;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnMediaPipelineKinesisVideoStreamPoolPropsMixin {
    /**
     * The configuration settings for the Kinesis video stream.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediapipelinekinesisvideostreampool-streamconfiguration.html
     */
    interface StreamConfigurationProperty {
        /**
         * The amount of time that data is retained, in hours.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediapipelinekinesisvideostreampool-streamconfiguration.html#cfn-chime-mediapipelinekinesisvideostreampool-streamconfiguration-dataretentioninhours
         */
        readonly dataRetentionInHours?: number;
        /**
         * The AWS Region of the video stream.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediapipelinekinesisvideostreampool-streamconfiguration.html#cfn-chime-mediapipelinekinesisvideostreampool-streamconfiguration-region
         */
        readonly region?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediapipelinekinesisvideostreampool-tagsitems.html
     */
    interface TagsItemsProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediapipelinekinesisvideostreampool-tagsitems.html#cfn-chime-mediapipelinekinesisvideostreampool-tagsitems-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-mediapipelinekinesisvideostreampool-tagsitems.html#cfn-chime-mediapipelinekinesisvideostreampool-tagsitems-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnMediaPipelineKinesisVideoStreamPoolPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-mediapipelinekinesisvideostreampool.html
 */
export interface CfnMediaPipelineKinesisVideoStreamPoolMixinProps {
    /**
     * The name of the Kinesis Video Stream Pool.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-mediapipelinekinesisvideostreampool.html#cfn-chime-mediapipelinekinesisvideostreampool-poolname
     */
    readonly poolName?: string;
    /**
     * The configuration settings for the Kinesis video stream.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-mediapipelinekinesisvideostreampool.html#cfn-chime-mediapipelinekinesisvideostreampool-streamconfiguration
     */
    readonly streamConfiguration?: cdk.IResolvable | CfnMediaPipelineKinesisVideoStreamPoolPropsMixin.StreamConfigurationProperty;
    /**
     * The tags associated with the Kinesis Video Stream Pool.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-mediapipelinekinesisvideostreampool.html#cfn-chime-mediapipelinekinesisvideostreampool-tags
     */
    readonly tags?: Array<CfnMediaPipelineKinesisVideoStreamPoolPropsMixin.TagsItemsProperty>;
}
/**
 * Resource Type definition for AWS::Chime::SipMediaApplication.
 *
 * @cloudformationResource AWS::Chime::SipMediaApplication
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-sipmediaapplication.html
 */
export declare class CfnSipMediaApplicationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSipMediaApplicationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Chime::SipMediaApplication`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSipMediaApplicationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSipMediaApplication;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnSipMediaApplicationPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-sipmediaapplication-sipmediaapplicationendpoint.html
     */
    interface SipMediaApplicationEndpointProperty {
        /**
         * Valid Amazon Resource Name (ARN) of the Lambda function.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-chime-sipmediaapplication-sipmediaapplicationendpoint.html#cfn-chime-sipmediaapplication-sipmediaapplicationendpoint-lambdaarn
         */
        readonly lambdaArn?: string;
    }
}
/**
 * Properties for CfnSipMediaApplicationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-sipmediaapplication.html
 */
export interface CfnSipMediaApplicationMixinProps {
    /**
     * The AWS Region in which the SIP media application is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-sipmediaapplication.html#cfn-chime-sipmediaapplication-awsregion
     */
    readonly awsRegion?: string;
    /**
     * List of endpoints (Lambda ARNs) specified for the SIP media application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-sipmediaapplication.html#cfn-chime-sipmediaapplication-endpoints
     */
    readonly endpoints?: Array<cdk.IResolvable | CfnSipMediaApplicationPropsMixin.SipMediaApplicationEndpointProperty> | cdk.IResolvable;
    /**
     * The name of the SIP media application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-sipmediaapplication.html#cfn-chime-sipmediaapplication-name
     */
    readonly name?: string;
    /**
     * Tags assigned to the SIP media application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-sipmediaapplication.html#cfn-chime-sipmediaapplication-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * An Amazon Chime SDK Voice Connector configuration, including outbound host name and encryption settings.
 *
 * @cloudformationResource AWS::Chime::VoiceConnector
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-voiceconnector.html
 */
export declare class CfnVoiceConnectorPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnVoiceConnectorMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Chime::VoiceConnector`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnVoiceConnectorMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnVoiceConnector;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnVoiceConnectorPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-voiceconnector.html
 */
export interface CfnVoiceConnectorMixinProps {
    /**
     * The AWS Region in which the Voice Connector is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-voiceconnector.html#cfn-chime-voiceconnector-awsregion
     */
    readonly awsRegion?: string;
    /**
     * The name of the Voice Connector.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-voiceconnector.html#cfn-chime-voiceconnector-name
     */
    readonly name?: string;
    /**
     * The type of network for the Voice Connector.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-voiceconnector.html#cfn-chime-voiceconnector-networktype
     */
    readonly networkType?: string;
    /**
     * Enables or disables encryption for the Voice Connector.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-voiceconnector.html#cfn-chime-voiceconnector-requireencryption
     */
    readonly requireEncryption?: boolean | cdk.IResolvable;
    /**
     * The tags assigned to the Voice Connector.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-chime-voiceconnector.html#cfn-chime-voiceconnector-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
