import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-scn";
/**
 * Represents an AWS Supply Chain data integration flow.
 *
 * @cloudformationResource AWS::SCN::DataIntegrationFlow
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataintegrationflow.html
 */
export declare class CfnDataIntegrationFlowPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnDataIntegrationFlowMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SCN::DataIntegrationFlow`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnDataIntegrationFlowMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDataIntegrationFlow;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnDataIntegrationFlowPropsMixin {
    /**
     * The DataIntegrationFlow source parameters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dataintegrationflowsource.html
     */
    interface DataIntegrationFlowSourceProperty {
        /**
         * The dataset source configuration parameters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dataintegrationflowsource.html#cfn-scn-dataintegrationflow-dataintegrationflowsource-datasetsource
         */
        readonly datasetSource?: CfnDataIntegrationFlowPropsMixin.DatasetSourceConfigurationProperty | cdk.IResolvable;
        /**
         * The S3 source configuration parameters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dataintegrationflowsource.html#cfn-scn-dataintegrationflow-dataintegrationflowsource-s3source
         */
        readonly s3Source?: cdk.IResolvable | CfnDataIntegrationFlowPropsMixin.S3SourceConfigurationProperty;
        /**
         * The source name that can be used as table alias in SQL transformation query.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dataintegrationflowsource.html#cfn-scn-dataintegrationflow-dataintegrationflowsource-sourcename
         */
        readonly sourceName?: string;
        /**
         * The source type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dataintegrationflowsource.html#cfn-scn-dataintegrationflow-dataintegrationflowsource-sourcetype
         */
        readonly sourceType?: string;
    }
    /**
     * The S3 source configuration parameters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-s3sourceconfiguration.html
     */
    interface S3SourceConfigurationProperty {
        /**
         * The S3 bucket name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-s3sourceconfiguration.html#cfn-scn-dataintegrationflow-s3sourceconfiguration-bucketname
         */
        readonly bucketName?: string;
        /**
         * The Amazon S3 options.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-s3sourceconfiguration.html#cfn-scn-dataintegrationflow-s3sourceconfiguration-options
         */
        readonly options?: cdk.IResolvable | CfnDataIntegrationFlowPropsMixin.S3OptionsProperty;
        /**
         * The S3 prefix.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-s3sourceconfiguration.html#cfn-scn-dataintegrationflow-s3sourceconfiguration-prefix
         */
        readonly prefix?: string;
    }
    /**
     * The Amazon S3 options.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-s3options.html
     */
    interface S3OptionsProperty {
        /**
         * The file type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-s3options.html#cfn-scn-dataintegrationflow-s3options-filetype
         */
        readonly fileType?: string;
    }
    /**
     * The dataset source configuration parameters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-datasetsourceconfiguration.html
     */
    interface DatasetSourceConfigurationProperty {
        /**
         * The ARN of the dataset.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-datasetsourceconfiguration.html#cfn-scn-dataintegrationflow-datasetsourceconfiguration-datasetidentifier
         */
        readonly datasetIdentifier?: string;
        /**
         * The dataset options.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-datasetsourceconfiguration.html#cfn-scn-dataintegrationflow-datasetsourceconfiguration-options
         */
        readonly options?: CfnDataIntegrationFlowPropsMixin.DatasetOptionsProperty | cdk.IResolvable;
    }
    /**
     * The dataset options.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-datasetoptions.html
     */
    interface DatasetOptionsProperty {
        /**
         * The option to perform deduplication on data records sharing same primary key values.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-datasetoptions.html#cfn-scn-dataintegrationflow-datasetoptions-deduperecords
         */
        readonly dedupeRecords?: boolean | cdk.IResolvable;
        /**
         * The deduplication strategy.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-datasetoptions.html#cfn-scn-dataintegrationflow-datasetoptions-dedupestrategy
         */
        readonly dedupeStrategy?: CfnDataIntegrationFlowPropsMixin.DedupeStrategyProperty | cdk.IResolvable;
        /**
         * The load type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-datasetoptions.html#cfn-scn-dataintegrationflow-datasetoptions-loadtype
         */
        readonly loadType?: string;
    }
    /**
     * The deduplication strategy.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dedupestrategy.html
     */
    interface DedupeStrategyProperty {
        /**
         * The field priority deduplication strategy configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dedupestrategy.html#cfn-scn-dataintegrationflow-dedupestrategy-fieldpriority
         */
        readonly fieldPriority?: CfnDataIntegrationFlowPropsMixin.FieldPriorityDedupeStrategyConfigurationProperty | cdk.IResolvable;
        /**
         * The deduplication strategy type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dedupestrategy.html#cfn-scn-dataintegrationflow-dedupestrategy-type
         */
        readonly type?: string;
    }
    /**
     * The field priority deduplication strategy configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-fieldprioritydedupestrategyconfiguration.html
     */
    interface FieldPriorityDedupeStrategyConfigurationProperty {
        /**
         * The list of field names and their sort order for deduplication.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-fieldprioritydedupestrategyconfiguration.html#cfn-scn-dataintegrationflow-fieldprioritydedupestrategyconfiguration-fields
         */
        readonly fields?: Array<CfnDataIntegrationFlowPropsMixin.FieldPriorityDedupeFieldProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * A deduplication field.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-fieldprioritydedupefield.html
     */
    interface FieldPriorityDedupeFieldProperty {
        /**
         * The name of the deduplication field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-fieldprioritydedupefield.html#cfn-scn-dataintegrationflow-fieldprioritydedupefield-name
         */
        readonly name?: string;
        /**
         * The sort order.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-fieldprioritydedupefield.html#cfn-scn-dataintegrationflow-fieldprioritydedupefield-sortorder
         */
        readonly sortOrder?: string;
    }
    /**
     * The DataIntegrationFlow transformation parameters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dataintegrationflowtransformation.html
     */
    interface DataIntegrationFlowTransformationProperty {
        /**
         * The SQL transformation configuration parameters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dataintegrationflowtransformation.html#cfn-scn-dataintegrationflow-dataintegrationflowtransformation-sqltransformation
         */
        readonly sqlTransformation?: cdk.IResolvable | CfnDataIntegrationFlowPropsMixin.SqlTransformationConfigurationProperty;
        /**
         * The transformation type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dataintegrationflowtransformation.html#cfn-scn-dataintegrationflow-dataintegrationflowtransformation-transformationtype
         */
        readonly transformationType?: string;
    }
    /**
     * The SQL transformation configuration parameters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-sqltransformationconfiguration.html
     */
    interface SqlTransformationConfigurationProperty {
        /**
         * The transformation SQL query body based on SparkSQL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-sqltransformationconfiguration.html#cfn-scn-dataintegrationflow-sqltransformationconfiguration-query
         */
        readonly query?: string;
    }
    /**
     * The DataIntegrationFlow target parameters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dataintegrationflowtarget.html
     */
    interface DataIntegrationFlowTargetProperty {
        /**
         * The dataset target configuration parameters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dataintegrationflowtarget.html#cfn-scn-dataintegrationflow-dataintegrationflowtarget-datasettarget
         */
        readonly datasetTarget?: CfnDataIntegrationFlowPropsMixin.DatasetTargetConfigurationProperty | cdk.IResolvable;
        /**
         * The target type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-dataintegrationflowtarget.html#cfn-scn-dataintegrationflow-dataintegrationflowtarget-targettype
         */
        readonly targetType?: string;
    }
    /**
     * The dataset target configuration parameters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-datasettargetconfiguration.html
     */
    interface DatasetTargetConfigurationProperty {
        /**
         * The dataset ARN.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-datasettargetconfiguration.html#cfn-scn-dataintegrationflow-datasettargetconfiguration-datasetidentifier
         */
        readonly datasetIdentifier?: string;
        /**
         * The dataset options.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataintegrationflow-datasettargetconfiguration.html#cfn-scn-dataintegrationflow-datasettargetconfiguration-options
         */
        readonly options?: CfnDataIntegrationFlowPropsMixin.DatasetOptionsProperty | cdk.IResolvable;
    }
}
/**
 * Properties for CfnDataIntegrationFlowPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataintegrationflow.html
 */
export interface CfnDataIntegrationFlowMixinProps {
    /**
     * The Amazon Web Services Supply Chain instance identifier.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataintegrationflow.html#cfn-scn-dataintegrationflow-instanceid
     */
    readonly instanceId?: string;
    /**
     * The name of the DataIntegrationFlow.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataintegrationflow.html#cfn-scn-dataintegrationflow-name
     */
    readonly name?: string;
    /**
     * The source configurations for the DataIntegrationFlow.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataintegrationflow.html#cfn-scn-dataintegrationflow-sources
     */
    readonly sources?: Array<CfnDataIntegrationFlowPropsMixin.DataIntegrationFlowSourceProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The tags for the DataIntegrationFlow.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataintegrationflow.html#cfn-scn-dataintegrationflow-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The DataIntegrationFlow target parameters.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataintegrationflow.html#cfn-scn-dataintegrationflow-target
     */
    readonly target?: CfnDataIntegrationFlowPropsMixin.DataIntegrationFlowTargetProperty | cdk.IResolvable;
    /**
     * The DataIntegrationFlow transformation parameters.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataintegrationflow.html#cfn-scn-dataintegrationflow-transformation
     */
    readonly transformation?: CfnDataIntegrationFlowPropsMixin.DataIntegrationFlowTransformationProperty | cdk.IResolvable;
}
/**
 * Represents an AWS Supply Chain data lake dataset.
 *
 * @cloudformationResource AWS::SCN::Dataset
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html
 */
export declare class CfnDatasetPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnDatasetMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SCN::Dataset`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnDatasetMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDataset;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnDatasetPropsMixin {
    /**
     * The schema of the dataset.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-schema.html
     */
    interface SchemaProperty {
        /**
         * The list of field details of the dataset schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-schema.html#cfn-scn-dataset-schema-fields
         */
        readonly fields?: Array<CfnDatasetPropsMixin.DataLakeDatasetSchemaFieldProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The name of the dataset schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-schema.html#cfn-scn-dataset-schema-name
         */
        readonly name?: string;
        /**
         * The list of primary key fields for the dataset.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-schema.html#cfn-scn-dataset-schema-primarykeys
         */
        readonly primaryKeys?: Array<CfnDatasetPropsMixin.DataLakeDatasetPrimaryKeyFieldProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * The dataset field details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetschemafield.html
     */
    interface DataLakeDatasetSchemaFieldProperty {
        /**
         * Indicate if the field is required or not.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetschemafield.html#cfn-scn-dataset-datalakedatasetschemafield-isrequired
         */
        readonly isRequired?: boolean | cdk.IResolvable;
        /**
         * The dataset field name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetschemafield.html#cfn-scn-dataset-datalakedatasetschemafield-name
         */
        readonly name?: string;
        /**
         * The dataset field type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetschemafield.html#cfn-scn-dataset-datalakedatasetschemafield-type
         */
        readonly type?: string;
    }
    /**
     * The primary key field details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetprimarykeyfield.html
     */
    interface DataLakeDatasetPrimaryKeyFieldProperty {
        /**
         * The name of the primary key field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetprimarykeyfield.html#cfn-scn-dataset-datalakedatasetprimarykeyfield-name
         */
        readonly name?: string;
    }
    /**
     * The partition specification of the dataset.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-partitionspec.html
     */
    interface PartitionSpecProperty {
        /**
         * The partition fields.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-partitionspec.html#cfn-scn-dataset-partitionspec-fields
         */
        readonly fields?: Array<CfnDatasetPropsMixin.DataLakeDatasetPartitionFieldProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * The partition field details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetpartitionfield.html
     */
    interface DataLakeDatasetPartitionFieldProperty {
        /**
         * The name of the partition field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetpartitionfield.html#cfn-scn-dataset-datalakedatasetpartitionfield-name
         */
        readonly name?: string;
        /**
         * The transformation of the partition field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetpartitionfield.html#cfn-scn-dataset-datalakedatasetpartitionfield-transform
         */
        readonly transform?: cdk.IResolvable | CfnDatasetPropsMixin.TransformProperty;
    }
    /**
     * The transformation of the partition field.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-transform.html
     */
    interface TransformProperty {
        /**
         * The type of partitioning transformation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-transform.html#cfn-scn-dataset-transform-type
         */
        readonly type?: string;
    }
}
/**
 * Properties for CfnDatasetPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html
 */
export interface CfnDatasetMixinProps {
    /**
     * The description of the dataset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-description
     */
    readonly description?: string;
    /**
     * The Amazon Web Services Supply Chain instance identifier.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-instanceid
     */
    readonly instanceId?: string;
    /**
     * The name of the dataset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-name
     */
    readonly name?: string;
    /**
     * The namespace of the dataset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-namespace
     */
    readonly namespace?: string;
    /**
     * The partition specification of the dataset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-partitionspec
     */
    readonly partitionSpec?: cdk.IResolvable | CfnDatasetPropsMixin.PartitionSpecProperty;
    /**
     * The schema of the dataset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-schema
     */
    readonly schema?: cdk.IResolvable | CfnDatasetPropsMixin.SchemaProperty;
    /**
     * The tags for the dataset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Definition of AWS::SCN::Namespace Resource Type.
 *
 * @cloudformationResource AWS::SCN::Namespace
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-namespace.html
 */
export declare class CfnNamespacePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnNamespaceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SCN::Namespace`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnNamespaceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnNamespace;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnNamespacePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-namespace.html
 */
export interface CfnNamespaceMixinProps {
    /**
     * The description of the namespace.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-namespace.html#cfn-scn-namespace-description
     */
    readonly description?: string;
    /**
     * The Amazon Web Services Supply Chain instance identifier.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-namespace.html#cfn-scn-namespace-instanceid
     */
    readonly instanceId?: string;
    /**
     * The name of the namespace.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-namespace.html#cfn-scn-namespace-name
     */
    readonly name?: string;
    /**
     * The tags for the namespace.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-namespace.html#cfn-scn-namespace-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
