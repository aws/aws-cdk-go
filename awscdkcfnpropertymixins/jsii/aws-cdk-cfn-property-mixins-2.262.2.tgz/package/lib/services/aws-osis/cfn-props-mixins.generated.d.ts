import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-osis";
/**
 * The AWS::OSIS::Pipeline resource creates an Amazon OpenSearch Ingestion pipeline.
 *
 * @cloudformationResource AWS::OSIS::Pipeline
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-osis-pipeline.html
 */
export declare class CfnPipelinePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPipelineMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::OSIS::Pipeline`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPipelineMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPipeline;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPipelinePropsMixin {
    /**
     * Options that specify the subnets and security groups for an OpenSearch Ingestion VPC endpoint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-vpcoptions.html
     */
    interface VpcOptionsProperty {
        /**
         * A list of security groups associated with the VPC endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-vpcoptions.html#cfn-osis-pipeline-vpcoptions-securitygroupids
         */
        readonly securityGroupIds?: Array<string>;
        /**
         * A list of subnet IDs associated with the VPC endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-vpcoptions.html#cfn-osis-pipeline-vpcoptions-subnetids
         */
        readonly subnetIds?: Array<string>;
        /**
         * Options for attaching a VPC to a pipeline.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-vpcoptions.html#cfn-osis-pipeline-vpcoptions-vpcattachmentoptions
         */
        readonly vpcAttachmentOptions?: cdk.IResolvable | CfnPipelinePropsMixin.VpcAttachmentOptionsProperty;
        /**
         * Defines whether you or Amazon OpenSearch Ingestion service create and manage the VPC endpoint configured for the pipeline.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-vpcoptions.html#cfn-osis-pipeline-vpcoptions-vpcendpointmanagement
         */
        readonly vpcEndpointManagement?: string;
    }
    /**
     * Options for attaching a VPC to pipeline.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-vpcattachmentoptions.html
     */
    interface VpcAttachmentOptionsProperty {
        /**
         * Whether a VPC is attached to the pipeline.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-vpcattachmentoptions.html#cfn-osis-pipeline-vpcattachmentoptions-attachtovpc
         */
        readonly attachToVpc?: boolean | cdk.IResolvable;
        /**
         * The CIDR block to be reserved for OpenSearch Ingestion to create elastic network interfaces (ENIs).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-vpcattachmentoptions.html#cfn-osis-pipeline-vpcattachmentoptions-cidrblock
         */
        readonly cidrBlock?: string;
    }
    /**
     * Container for the values required to configure logging for the pipeline.
     *
     * If you don't specify these values, OpenSearch Ingestion will not publish logs from your application to CloudWatch Logs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-logpublishingoptions.html
     */
    interface LogPublishingOptionsProperty {
        /**
         * The destination for OpenSearch Ingestion logs sent to Amazon CloudWatch Logs.
         *
         * This parameter is required if `IsLoggingEnabled` is set to `true` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-logpublishingoptions.html#cfn-osis-pipeline-logpublishingoptions-cloudwatchlogdestination
         */
        readonly cloudWatchLogDestination?: CfnPipelinePropsMixin.CloudWatchLogDestinationProperty | cdk.IResolvable;
        /**
         * Whether logs should be published.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-logpublishingoptions.html#cfn-osis-pipeline-logpublishingoptions-isloggingenabled
         */
        readonly isLoggingEnabled?: boolean | cdk.IResolvable;
    }
    /**
     * The destination for OpenSearch Ingestion logs sent to Amazon CloudWatch.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-cloudwatchlogdestination.html
     */
    interface CloudWatchLogDestinationProperty {
        /**
         * The name of the CloudWatch Logs group to send pipeline logs to.
         *
         * You can specify an existing log group or create a new one. For example, `/aws/vendedlogs/OpenSearchService/pipelines` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-cloudwatchlogdestination.html#cfn-osis-pipeline-cloudwatchlogdestination-loggroup
         */
        readonly logGroup?: string;
    }
    /**
     * Options that specify the configuration of a persistent buffer.
     *
     * To configure how OpenSearch Ingestion encrypts this data, set the `EncryptionAtRestOptions` . For more information, see [Persistent buffering](https://docs.aws.amazon.com/opensearch-service/latest/developerguide/osis-features-overview.html#persistent-buffering) .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-bufferoptions.html
     */
    interface BufferOptionsProperty {
        /**
         * Whether persistent buffering should be enabled.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-bufferoptions.html#cfn-osis-pipeline-bufferoptions-persistentbufferenabled
         */
        readonly persistentBufferEnabled?: boolean | cdk.IResolvable;
    }
    /**
     * Options to control how OpenSearch encrypts buffer data.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-encryptionatrestoptions.html
     */
    interface EncryptionAtRestOptionsProperty {
        /**
         * The ARN of the KMS key used to encrypt buffer data.
         *
         * By default, data is encrypted using an AWS owned key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-encryptionatrestoptions.html#cfn-osis-pipeline-encryptionatrestoptions-kmskeyarn
         */
        readonly kmsKeyArn?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-resourcepolicy.html
     */
    interface ResourcePolicyProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-resourcepolicy.html#cfn-osis-pipeline-resourcepolicy-policy
         */
        readonly policy?: any | cdk.IResolvable;
    }
    /**
     * An OpenSearch Ingestion-managed VPC endpoint that will access one or more pipelines.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-vpcendpoint.html
     */
    interface VpcEndpointProperty {
        /**
         * The unique identifier of the endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-vpcendpoint.html#cfn-osis-pipeline-vpcendpoint-vpcendpointid
         */
        readonly vpcEndpointId?: string;
        /**
         * The ID for your VPC.
         *
         * AWS PrivateLink generates this value when you create a VPC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-vpcendpoint.html#cfn-osis-pipeline-vpcendpoint-vpcid
         */
        readonly vpcId?: string;
        /**
         * Information about the VPC, including associated subnets and security groups.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-osis-pipeline-vpcendpoint.html#cfn-osis-pipeline-vpcendpoint-vpcoptions
         */
        readonly vpcOptions?: cdk.IResolvable | CfnPipelinePropsMixin.VpcOptionsProperty;
    }
}
/**
 * Properties for CfnPipelinePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-osis-pipeline.html
 */
export interface CfnPipelineMixinProps {
    /**
     * Options that specify the configuration of a persistent buffer.
     *
     * To configure how OpenSearch Ingestion encrypts this data, set the `EncryptionAtRestOptions` . For more information, see [Persistent buffering](https://docs.aws.amazon.com/opensearch-service/latest/developerguide/osis-features-overview.html#persistent-buffering) .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-osis-pipeline.html#cfn-osis-pipeline-bufferoptions
     */
    readonly bufferOptions?: CfnPipelinePropsMixin.BufferOptionsProperty | cdk.IResolvable;
    /**
     * Options to control how OpenSearch encrypts buffer data.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-osis-pipeline.html#cfn-osis-pipeline-encryptionatrestoptions
     */
    readonly encryptionAtRestOptions?: CfnPipelinePropsMixin.EncryptionAtRestOptionsProperty | cdk.IResolvable;
    /**
     * Key-value pairs that represent log publishing settings.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-osis-pipeline.html#cfn-osis-pipeline-logpublishingoptions
     */
    readonly logPublishingOptions?: cdk.IResolvable | CfnPipelinePropsMixin.LogPublishingOptionsProperty;
    /**
     * The maximum pipeline capacity, in Ingestion Compute Units (ICUs).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-osis-pipeline.html#cfn-osis-pipeline-maxunits
     */
    readonly maxUnits?: number;
    /**
     * The minimum pipeline capacity, in Ingestion Compute Units (ICUs).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-osis-pipeline.html#cfn-osis-pipeline-minunits
     */
    readonly minUnits?: number;
    /**
     * The Data Prepper pipeline configuration in YAML format.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-osis-pipeline.html#cfn-osis-pipeline-pipelineconfigurationbody
     */
    readonly pipelineConfigurationBody?: string;
    /**
     * The name of the pipeline.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-osis-pipeline.html#cfn-osis-pipeline-pipelinename
     */
    readonly pipelineName?: string;
    /**
     * The Amazon Resource Name (ARN) of the IAM role that the pipeline uses to access AWS resources.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-osis-pipeline.html#cfn-osis-pipeline-pipelinerolearn
     */
    readonly pipelineRoleArn?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-osis-pipeline.html#cfn-osis-pipeline-resourcepolicy
     */
    readonly resourcePolicy?: cdk.IResolvable | CfnPipelinePropsMixin.ResourcePolicyProperty;
    /**
     * List of tags to add to the pipeline upon creation.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-osis-pipeline.html#cfn-osis-pipeline-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Options that specify the subnets and security groups for an OpenSearch Ingestion VPC endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-osis-pipeline.html#cfn-osis-pipeline-vpcoptions
     */
    readonly vpcOptions?: cdk.IResolvable | CfnPipelinePropsMixin.VpcOptionsProperty;
}
