import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-controlcatalog";
/**
 * Resource Type definition for AWS::ControlCatalog::CommonControl.
 *
 * @cloudformationResource AWS::ControlCatalog::CommonControl
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-controlcatalog-commoncontrol.html
 */
export declare class CfnCommonControlPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnCommonControlMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ControlCatalog::CommonControl`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnCommonControlMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCommonControl;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnCommonControlPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-commoncontrol-objective.html
     */
    interface ObjectiveProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-commoncontrol-objective.html#cfn-controlcatalog-commoncontrol-objective-arn
         */
        readonly arn?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-commoncontrol-objective.html#cfn-controlcatalog-commoncontrol-objective-name
         */
        readonly name?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-commoncontrol-domain.html
     */
    interface DomainProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-commoncontrol-domain.html#cfn-controlcatalog-commoncontrol-domain-arn
         */
        readonly arn?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-commoncontrol-domain.html#cfn-controlcatalog-commoncontrol-domain-name
         */
        readonly name?: string;
    }
}
/**
 * Properties for CfnCommonControlPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-controlcatalog-commoncontrol.html
 */
export interface CfnCommonControlMixinProps {
}
/**
 * Resource Type definition for AWS::ControlCatalog::Control.
 *
 * @cloudformationResource AWS::ControlCatalog::Control
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-controlcatalog-control.html
 */
export declare class CfnControlPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnControlMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ControlCatalog::Control`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnControlMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnControl;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnControlPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-control-regionconfiguration.html
     */
    interface RegionConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-control-regionconfiguration.html#cfn-controlcatalog-control-regionconfiguration-deployableregions
         */
        readonly deployableRegions?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-control-regionconfiguration.html#cfn-controlcatalog-control-regionconfiguration-scope
         */
        readonly scope?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-control-implementationdetails.html
     */
    interface ImplementationDetailsProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-control-implementationdetails.html#cfn-controlcatalog-control-implementationdetails-identifier
         */
        readonly identifier?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-control-implementationdetails.html#cfn-controlcatalog-control-implementationdetails-type
         */
        readonly type?: string;
    }
}
/**
 * Properties for CfnControlPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-controlcatalog-control.html
 */
export interface CfnControlMixinProps {
}
