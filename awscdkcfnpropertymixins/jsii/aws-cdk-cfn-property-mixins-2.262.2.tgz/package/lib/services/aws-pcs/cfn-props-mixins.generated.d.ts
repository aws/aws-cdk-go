import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-pcs";
/**
 * Creates an AWS PCS cluster resource.
 *
 * For more information, see [Creating a cluster in Parallel Computing Service](https://docs.aws.amazon.com/pcs/latest/userguide/working-with_clusters_create.html) in the *AWS PCS User Guide* .
 *
 * @cloudformationResource AWS::PCS::Cluster
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-cluster.html
 */
export declare class CfnClusterPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnClusterMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::PCS::Cluster`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnClusterMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCluster;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnClusterPropsMixin {
    /**
     * The networking configuration for the cluster's control plane.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-networking.html
     */
    interface NetworkingProperty {
        /**
         * The IP address version the cluster uses.
         *
         * The default is `IPV4` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-networking.html#cfn-pcs-cluster-networking-networktype
         */
        readonly networkType?: string;
        /**
         * The list of security group IDs associated with the Elastic Network Interface (ENI) created in subnets.
         *
         * The following rules are required:
         *
         * - Inbound rule 1
         *
         * - Protocol: All
         * - Ports: All
         * - Source: Self
         * - Outbound rule 1
         *
         * - Protocol: All
         * - Ports: All
         * - Destination: 0.0.0.0/0 (IPv4) or ::/0 (IPv6)
         * - Outbound rule 2
         *
         * - Protocol: All
         * - Ports: All
         * - Destination: Self
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-networking.html#cfn-pcs-cluster-networking-securitygroupids
         */
        readonly securityGroupIds?: Array<string>;
        /**
         * The ID of the subnet where AWS PCS creates an Elastic Network Interface (ENI) to enable communication between managed controllers and AWS PCS resources.
         *
         * The subnet must have an available IP address, cannot reside in AWS Outposts , AWS Wavelength , or an AWS Local Zone.
         *
         * Example: `subnet-abcd1234`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-networking.html#cfn-pcs-cluster-networking-subnetids
         */
        readonly subnetIds?: Array<string>;
    }
    /**
     * The cluster management and job scheduling software associated with the cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-scheduler.html
     */
    interface SchedulerProperty {
        /**
         * The software AWS PCS uses to manage cluster scaling and job scheduling.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-scheduler.html#cfn-pcs-cluster-scheduler-type
         */
        readonly type?: string;
        /**
         * The version of the specified scheduling software that AWS PCS uses to manage cluster scaling and job scheduling.
         *
         * For more information, see [Slurm versions in AWS PCS](https://docs.aws.amazon.com/pcs/latest/userguide/slurm-versions.html) in the *AWS PCS User Guide* .
         *
         * Valid Values: `23.11 | 24.05 | 24.11`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-scheduler.html#cfn-pcs-cluster-scheduler-version
         */
        readonly version?: string;
    }
    /**
     * Additional options related to the Slurm scheduler.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmconfiguration.html
     */
    interface SlurmConfigurationProperty {
        /**
         * The accounting configuration includes configurable settings for Slurm accounting.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmconfiguration.html#cfn-pcs-cluster-slurmconfiguration-accounting
         */
        readonly accounting?: CfnClusterPropsMixin.AccountingProperty | cdk.IResolvable;
        /**
         * The shared Slurm key for authentication, also known as the *cluster secret* .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmconfiguration.html#cfn-pcs-cluster-slurmconfiguration-authkey
         */
        readonly authKey?: CfnClusterPropsMixin.AuthKeyProperty | cdk.IResolvable;
        /**
         * Additional cgroup-specific configuration that directly maps to cgroup.conf settings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmconfiguration.html#cfn-pcs-cluster-slurmconfiguration-cgroupcustomsettings
         */
        readonly cgroupCustomSettings?: Array<CfnClusterPropsMixin.CgroupCustomSettingProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The JWT authentication configuration for Slurm REST API access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmconfiguration.html#cfn-pcs-cluster-slurmconfiguration-jwtauth
         */
        readonly jwtAuth?: cdk.IResolvable | CfnClusterPropsMixin.JwtAuthProperty;
        /**
         * The time (in seconds) before an idle node is scaled down.
         *
         * Default: `600`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmconfiguration.html#cfn-pcs-cluster-slurmconfiguration-scaledownidletimeinseconds
         */
        readonly scaleDownIdleTimeInSeconds?: number;
        /**
         * Additional Slurm-specific configuration that directly maps to Slurm settings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmconfiguration.html#cfn-pcs-cluster-slurmconfiguration-slurmcustomsettings
         */
        readonly slurmCustomSettings?: Array<cdk.IResolvable | CfnClusterPropsMixin.SlurmCustomSettingProperty> | cdk.IResolvable;
        /**
         * Additional slurmdbd-specific configuration that directly maps to slurmdbd.conf settings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmconfiguration.html#cfn-pcs-cluster-slurmconfiguration-slurmdbdcustomsettings
         */
        readonly slurmdbdCustomSettings?: Array<cdk.IResolvable | CfnClusterPropsMixin.SlurmdbdCustomSettingProperty> | cdk.IResolvable;
        /**
         * The Slurm REST API configuration for the cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmconfiguration.html#cfn-pcs-cluster-slurmconfiguration-slurmrest
         */
        readonly slurmRest?: cdk.IResolvable | CfnClusterPropsMixin.SlurmRestProperty;
    }
    /**
     * The accounting configuration includes configurable settings for Slurm accounting.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-accounting.html
     */
    interface AccountingProperty {
        /**
         * The default value for all purge settings for `slurmdbd.conf` . For more information, see the [slurmdbd.conf documentation at SchedMD](https://docs.aws.amazon.com/https://slurm.schedmd.com/slurmdbd.conf.html) .
         *
         * The default value for `defaultPurgeTimeInDays` is `-1` .
         *
         * A value of `-1` means there is no purge time and records persist as long as the cluster exists.
         *
         * > `0` isn't a valid value.
         *
         * @default - -1
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-accounting.html#cfn-pcs-cluster-accounting-defaultpurgetimeindays
         */
        readonly defaultPurgeTimeInDays?: number;
        /**
         * The default value for `mode` is `NONE` .
         *
         * A value of `STANDARD` means Slurm accounting is enabled.
         *
         * @default - "NONE"
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-accounting.html#cfn-pcs-cluster-accounting-mode
         */
        readonly mode?: string;
    }
    /**
     * The Slurm REST API configuration includes settings for enabling and configuring the Slurm REST API.
     *
     * It's a property of the [ClusterSlurmConfiguration](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmconfiguration.html) object.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmrest.html
     */
    interface SlurmRestProperty {
        /**
         * The default value for `mode` is `NONE` .
         *
         * A value of `STANDARD` means the Slurm REST API is enabled.
         *
         * @default - "NONE"
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmrest.html#cfn-pcs-cluster-slurmrest-mode
         */
        readonly mode?: string;
    }
    /**
     * The shared Slurm key for authentication, also known as the *cluster secret* .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-authkey.html
     */
    interface AuthKeyProperty {
        /**
         * The Amazon Resource Name (ARN) of the shared Slurm key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-authkey.html#cfn-pcs-cluster-authkey-secretarn
         */
        readonly secretArn?: string;
        /**
         * The version of the shared Slurm key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-authkey.html#cfn-pcs-cluster-authkey-secretversion
         */
        readonly secretVersion?: string;
    }
    /**
     * The JWT authentication configuration for Slurm REST API access.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-jwtauth.html
     */
    interface JwtAuthProperty {
        /**
         * The JWT key for Slurm REST API authentication.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-jwtauth.html#cfn-pcs-cluster-jwtauth-jwtkey
         */
        readonly jwtKey?: cdk.IResolvable | CfnClusterPropsMixin.JwtKeyProperty;
    }
    /**
     * The JWT key stored in AWS Secrets Manager for Slurm REST API authentication.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-jwtkey.html
     */
    interface JwtKeyProperty {
        /**
         * The Amazon Resource Name (ARN) of the AWS Secrets Manager secret containing the JWT key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-jwtkey.html#cfn-pcs-cluster-jwtkey-secretarn
         */
        readonly secretArn?: string;
        /**
         * The version of the AWS Secrets Manager secret containing the JWT key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-jwtkey.html#cfn-pcs-cluster-jwtkey-secretversion
         */
        readonly secretVersion?: string;
    }
    /**
     * Additional settings that directly map to Slurm settings.
     *
     * > AWS PCS supports a subset of Slurm settings. For more information, see [Configuring custom Slurm settings in AWS PCS](https://docs.aws.amazon.com//pcs/latest/userguide/slurm-custom-settings.html) in the *AWS PCS User Guide* .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmcustomsetting.html
     */
    interface SlurmCustomSettingProperty {
        /**
         * AWS PCS supports custom Slurm settings for clusters, compute node groups, and queues.
         *
         * For more information, see [Configuring custom Slurm settings in AWS PCS](https://docs.aws.amazon.com//pcs/latest/userguide/slurm-custom-settings.html) in the *AWS PCS User Guide* .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmcustomsetting.html#cfn-pcs-cluster-slurmcustomsetting-parametername
         */
        readonly parameterName?: string;
        /**
         * The values for the configured Slurm settings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmcustomsetting.html#cfn-pcs-cluster-slurmcustomsetting-parametervalue
         */
        readonly parameterValue?: string;
    }
    /**
     * Additional cgroup configuration settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-cgroupcustomsetting.html
     */
    interface CgroupCustomSettingProperty {
        /**
         * The cgroup.conf parameter name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-cgroupcustomsetting.html#cfn-pcs-cluster-cgroupcustomsetting-parametername
         */
        readonly parameterName?: string;
        /**
         * The value for the cgroup.conf parameter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-cgroupcustomsetting.html#cfn-pcs-cluster-cgroupcustomsetting-parametervalue
         */
        readonly parameterValue?: string;
    }
    /**
     * Additional slurmdbd configuration settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmdbdcustomsetting.html
     */
    interface SlurmdbdCustomSettingProperty {
        /**
         * The slurmdbd.conf parameter name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmdbdcustomsetting.html#cfn-pcs-cluster-slurmdbdcustomsetting-parametername
         */
        readonly parameterName?: string;
        /**
         * The value for the slurmdbd.conf parameter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-slurmdbdcustomsetting.html#cfn-pcs-cluster-slurmdbdcustomsetting-parametervalue
         */
        readonly parameterValue?: string;
    }
    /**
     * An endpoint available for interaction with the scheduler.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-endpoint.html
     */
    interface EndpointProperty {
        /**
         * The endpoint's IPv6 address.
         *
         * Example: `2001:db8::1`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-endpoint.html#cfn-pcs-cluster-endpoint-ipv6address
         */
        readonly ipv6Address?: string;
        /**
         * The endpoint's connection port number.
         *
         * Example: `1234`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-endpoint.html#cfn-pcs-cluster-endpoint-port
         */
        readonly port?: string;
        /**
         * For clusters that use IPv4, this is the endpoint's private IP address.
         *
         * Example: `10.1.2.3`
         *
         * For clusters configured to use IPv6, this is an empty string.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-endpoint.html#cfn-pcs-cluster-endpoint-privateipaddress
         */
        readonly privateIpAddress?: string;
        /**
         * The endpoint's public IP address.
         *
         * Example: `192.0.2.1`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-endpoint.html#cfn-pcs-cluster-endpoint-publicipaddress
         */
        readonly publicIpAddress?: string;
        /**
         * Indicates the type of endpoint running at the specific IP address.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-endpoint.html#cfn-pcs-cluster-endpoint-type
         */
        readonly type?: string;
    }
    /**
     * An error that occurred during resource creation.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-errorinfo.html
     */
    interface ErrorInfoProperty {
        /**
         * The short-form error code.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-errorinfo.html#cfn-pcs-cluster-errorinfo-code
         */
        readonly code?: string;
        /**
         * The detailed error information.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-cluster-errorinfo.html#cfn-pcs-cluster-errorinfo-message
         */
        readonly message?: string;
    }
}
/**
 * Properties for CfnClusterPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-cluster.html
 */
export interface CfnClusterMixinProps {
    /**
     * The name that identifies the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-cluster.html#cfn-pcs-cluster-name
     */
    readonly name?: string;
    /**
     * The networking configuration for the cluster's control plane.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-cluster.html#cfn-pcs-cluster-networking
     */
    readonly networking?: cdk.IResolvable | CfnClusterPropsMixin.NetworkingProperty;
    /**
     * The cluster management and job scheduling software associated with the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-cluster.html#cfn-pcs-cluster-scheduler
     */
    readonly scheduler?: cdk.IResolvable | CfnClusterPropsMixin.SchedulerProperty;
    /**
     * The size of the cluster.
     *
     * - `SMALL` : 32 compute nodes and 256 jobs
     * - `MEDIUM` : 512 compute nodes and 8192 jobs
     * - `LARGE` : 2048 compute nodes and 16,384 jobs
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-cluster.html#cfn-pcs-cluster-size
     */
    readonly size?: string;
    /**
     * Additional options related to the Slurm scheduler.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-cluster.html#cfn-pcs-cluster-slurmconfiguration
     */
    readonly slurmConfiguration?: cdk.IResolvable | CfnClusterPropsMixin.SlurmConfigurationProperty;
    /**
     * 1 or more tags added to the resource.
     *
     * Each tag consists of a tag key and tag value. The tag value is optional and can be an empty string.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-cluster.html#cfn-pcs-cluster-tags
     */
    readonly tags?: Record<string, string>;
}
/**
 * Creates an AWS PCS compute node group resource.
 *
 * For more information, see [Creating a compute node group in AWS PCS](https://docs.aws.amazon.com/pcs/latest/userguide/working-with_cng_create.html) in the *AWS PCS User Guide* .
 *
 * @cloudformationResource AWS::PCS::ComputeNodeGroup
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html
 */
export declare class CfnComputeNodeGroupPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnComputeNodeGroupMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::PCS::ComputeNodeGroup`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnComputeNodeGroupMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnComputeNodeGroup;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnComputeNodeGroupPropsMixin {
    /**
     * Additional configuration when you specify `SPOT` as the `purchaseOption` for the `CreateComputeNodeGroup` API action.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-spotoptions.html
     */
    interface SpotOptionsProperty {
        /**
         * The Amazon EC2 allocation strategy AWS PCS uses to provision EC2 instances.
         *
         * AWS PCS supports *lowest price* , *capacity optimized* , and *price capacity optimized* . For more information, see [Use allocation strategies to determine how EC2 Fleet or Spot Fleet fulfills Spot and On-Demand capacity](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/spot-fleet-allocation-strategy.html) in the *Amazon Elastic Compute Cloud User Guide* . If you don't provide this option, it defaults to *price capacity optimized* .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-spotoptions.html#cfn-pcs-computenodegroup-spotoptions-allocationstrategy
         */
        readonly allocationStrategy?: string;
    }
    /**
     * Additional options related to the Slurm scheduler.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-slurmconfiguration.html
     */
    interface SlurmConfigurationProperty {
        /**
         * The time before an idle node is scaled down.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-slurmconfiguration.html#cfn-pcs-computenodegroup-slurmconfiguration-scaledownidletimeinseconds
         */
        readonly scaleDownIdleTimeInSeconds?: number;
        /**
         * Additional Slurm-specific configuration that directly maps to Slurm settings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-slurmconfiguration.html#cfn-pcs-computenodegroup-slurmconfiguration-slurmcustomsettings
         */
        readonly slurmCustomSettings?: Array<cdk.IResolvable | CfnComputeNodeGroupPropsMixin.SlurmCustomSettingProperty> | cdk.IResolvable;
    }
    /**
     * Additional settings that directly map to Slurm settings.
     *
     * > AWS PCS supports a subset of Slurm settings. For more information, see [Configuring custom Slurm settings in AWS PCS](https://docs.aws.amazon.com//pcs/latest/userguide/slurm-custom-settings.html) in the *AWS PCS User Guide* .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-slurmcustomsetting.html
     */
    interface SlurmCustomSettingProperty {
        /**
         * AWS PCS supports custom Slurm settings for clusters, compute node groups, and queues.
         *
         * For more information, see [Configuring custom Slurm settings in AWS PCS](https://docs.aws.amazon.com//pcs/latest/userguide/slurm-custom-settings.html) in the *AWS PCS User Guide* .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-slurmcustomsetting.html#cfn-pcs-computenodegroup-slurmcustomsetting-parametername
         */
        readonly parameterName?: string;
        /**
         * The values for the configured Slurm settings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-slurmcustomsetting.html#cfn-pcs-computenodegroup-slurmcustomsetting-parametervalue
         */
        readonly parameterValue?: string;
    }
    /**
     * Specifies the boundaries of the compute node group auto scaling.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-scalingconfiguration.html
     */
    interface ScalingConfigurationProperty {
        /**
         * The upper bound of the number of instances allowed in the compute fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-scalingconfiguration.html#cfn-pcs-computenodegroup-scalingconfiguration-maxinstancecount
         */
        readonly maxInstanceCount?: number;
        /**
         * The lower bound of the number of instances allowed in the compute fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-scalingconfiguration.html#cfn-pcs-computenodegroup-scalingconfiguration-mininstancecount
         */
        readonly minInstanceCount?: number;
    }
    /**
     * An EC2 instance configuration AWS PCS uses to launch compute nodes.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-instanceconfig.html
     */
    interface InstanceConfigProperty {
        /**
         * The EC2 instance type that AWS PCS can provision in the compute node group.
         *
         * Example: `t2.xlarge`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-instanceconfig.html#cfn-pcs-computenodegroup-instanceconfig-instancetype
         */
        readonly instanceType?: string;
    }
    /**
     * An Amazon EC2 launch template AWS PCS uses to launch compute nodes.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-customlaunchtemplate.html
     */
    interface CustomLaunchTemplateProperty {
        /**
         * The ID of the EC2 launch template to use to provision instances.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-customlaunchtemplate.html#cfn-pcs-computenodegroup-customlaunchtemplate-templateid
         */
        readonly templateId?: string;
        /**
         * The version of the EC2 launch template to use to provision instances.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-customlaunchtemplate.html#cfn-pcs-computenodegroup-customlaunchtemplate-version
         */
        readonly version?: string;
    }
    /**
     * An error that occurred during resource creation.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-errorinfo.html
     */
    interface ErrorInfoProperty {
        /**
         * The short-form error code.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-errorinfo.html#cfn-pcs-computenodegroup-errorinfo-code
         */
        readonly code?: string;
        /**
         * The detailed error information.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-computenodegroup-errorinfo.html#cfn-pcs-computenodegroup-errorinfo-message
         */
        readonly message?: string;
    }
}
/**
 * Properties for CfnComputeNodeGroupPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html
 */
export interface CfnComputeNodeGroupMixinProps {
    /**
     * The ID of the Amazon Machine Image (AMI) that AWS PCS uses to launch instances.
     *
     * If not provided, AWS PCS uses the AMI ID specified in the custom launch template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html#cfn-pcs-computenodegroup-amiid
     */
    readonly amiId?: string;
    /**
     * The ID of the cluster of the compute node group.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html#cfn-pcs-computenodegroup-clusterid
     */
    readonly clusterId?: string;
    /**
     * An Amazon EC2 launch template AWS PCS uses to launch compute nodes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html#cfn-pcs-computenodegroup-customlaunchtemplate
     */
    readonly customLaunchTemplate?: CfnComputeNodeGroupPropsMixin.CustomLaunchTemplateProperty | cdk.IResolvable;
    /**
     * The Amazon Resource Name (ARN) of the IAM instance profile used to pass an IAM role when launching EC2 instances.
     *
     * The role contained in your instance profile must have the `pcs:RegisterComputeNodeGroupInstance` permission and the role name must start with `AWSPCS` or must have the path `/aws-pcs/` . For more information, see [IAM instance profiles for AWS PCS](https://docs.aws.amazon.com//pcs/latest/userguide/security-instance-profiles.html) in the *AWS PCS User Guide* .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html#cfn-pcs-computenodegroup-iaminstanceprofilearn
     */
    readonly iamInstanceProfileArn?: string;
    /**
     * A list of EC2 instance configurations that AWS PCS can provision in the compute node group.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html#cfn-pcs-computenodegroup-instanceconfigs
     */
    readonly instanceConfigs?: Array<CfnComputeNodeGroupPropsMixin.InstanceConfigProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The name that identifies the compute node group.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html#cfn-pcs-computenodegroup-name
     */
    readonly name?: string;
    /**
     * Specifies how EC2 instances are purchased on your behalf.
     *
     * AWS PCS supports On-Demand Instances, Spot Instances, and Amazon EC2 Capacity Blocks for ML. For more information, see [Amazon EC2 billing and purchasing options](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/instance-purchasing-options.html) in the *Amazon Elastic Compute Cloud User Guide* . For more information about AWS PCS support for Capacity Blocks, see [Using Amazon EC2 Capacity Blocks for ML with AWS PCS](https://docs.aws.amazon.com/pcs/latest/userguide/capacity-blocks.html) in the *AWS PCS User Guide* . If you don't provide this option, it defaults to On-Demand.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html#cfn-pcs-computenodegroup-purchaseoption
     */
    readonly purchaseOption?: string;
    /**
     * Specifies the boundaries of the compute node group auto scaling.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html#cfn-pcs-computenodegroup-scalingconfiguration
     */
    readonly scalingConfiguration?: cdk.IResolvable | CfnComputeNodeGroupPropsMixin.ScalingConfigurationProperty;
    /**
     * Additional options related to the Slurm scheduler.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html#cfn-pcs-computenodegroup-slurmconfiguration
     */
    readonly slurmConfiguration?: cdk.IResolvable | CfnComputeNodeGroupPropsMixin.SlurmConfigurationProperty;
    /**
     * Additional configuration when you specify `SPOT` as the `purchaseOption` for the `CreateComputeNodeGroup` API action.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html#cfn-pcs-computenodegroup-spotoptions
     */
    readonly spotOptions?: cdk.IResolvable | CfnComputeNodeGroupPropsMixin.SpotOptionsProperty;
    /**
     * The list of subnet IDs where instances are provisioned by the compute node group.
     *
     * The subnets must be in the same VPC as the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html#cfn-pcs-computenodegroup-subnetids
     */
    readonly subnetIds?: Array<string>;
    /**
     * 1 or more tags added to the resource.
     *
     * Each tag consists of a tag key and tag value. The tag value is optional and can be an empty string.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-computenodegroup.html#cfn-pcs-computenodegroup-tags
     */
    readonly tags?: Record<string, string>;
}
/**
 * Creates an AWS PCS queue resource.
 *
 * For more information, see [Creating a queue in AWS PCS](https://docs.aws.amazon.com/pcs/latest/userguide/working-with_queues_create.html) in the *AWS PCS User Guide* .
 *
 * @cloudformationResource AWS::PCS::Queue
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-queue.html
 */
export declare class CfnQueuePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnQueueMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::PCS::Queue`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnQueueMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnQueue;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnQueuePropsMixin {
    /**
     * The compute node group configuration for a queue.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-queue-computenodegroupconfiguration.html
     */
    interface ComputeNodeGroupConfigurationProperty {
        /**
         * The compute node group ID for the compute node group configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-queue-computenodegroupconfiguration.html#cfn-pcs-queue-computenodegroupconfiguration-computenodegroupid
         */
        readonly computeNodeGroupId?: string;
    }
    /**
     * The Slurm configuration for the queue.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-queue-slurmconfiguration.html
     */
    interface SlurmConfigurationProperty {
        /**
         * Custom Slurm parameters that directly map to Slurm configuration settings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-queue-slurmconfiguration.html#cfn-pcs-queue-slurmconfiguration-slurmcustomsettings
         */
        readonly slurmCustomSettings?: Array<cdk.IResolvable | CfnQueuePropsMixin.SlurmCustomSettingProperty> | cdk.IResolvable;
    }
    /**
     * Additional settings that directly map to Slurm settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-queue-slurmcustomsetting.html
     */
    interface SlurmCustomSettingProperty {
        /**
         * AWS PCS supports configuration of the Slurm parameters for queues:.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-queue-slurmcustomsetting.html#cfn-pcs-queue-slurmcustomsetting-parametername
         */
        readonly parameterName?: string;
        /**
         * The value for the configured Slurm setting.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-queue-slurmcustomsetting.html#cfn-pcs-queue-slurmcustomsetting-parametervalue
         */
        readonly parameterValue?: string;
    }
    /**
     * An error that occurred during resource creation.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-queue-errorinfo.html
     */
    interface ErrorInfoProperty {
        /**
         * The short-form error code.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-queue-errorinfo.html#cfn-pcs-queue-errorinfo-code
         */
        readonly code?: string;
        /**
         * The detailed error information.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-pcs-queue-errorinfo.html#cfn-pcs-queue-errorinfo-message
         */
        readonly message?: string;
    }
}
/**
 * Properties for CfnQueuePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-queue.html
 */
export interface CfnQueueMixinProps {
    /**
     * The ID of the cluster of the queue.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-queue.html#cfn-pcs-queue-clusterid
     */
    readonly clusterId?: string;
    /**
     * The list of compute node group configurations associated with the queue.
     *
     * Queues assign jobs to associated compute node groups.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-queue.html#cfn-pcs-queue-computenodegroupconfigurations
     */
    readonly computeNodeGroupConfigurations?: Array<CfnQueuePropsMixin.ComputeNodeGroupConfigurationProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The name that identifies the queue.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-queue.html#cfn-pcs-queue-name
     */
    readonly name?: string;
    /**
     * Additional options related to the Slurm scheduler.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-queue.html#cfn-pcs-queue-slurmconfiguration
     */
    readonly slurmConfiguration?: cdk.IResolvable | CfnQueuePropsMixin.SlurmConfigurationProperty;
    /**
     * 1 or more tags added to the resource.
     *
     * Each tag consists of a tag key and tag value. The tag value is optional and can be an empty string.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-queue.html#cfn-pcs-queue-tags
     */
    readonly tags?: Record<string, string>;
}
