import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-mediapackagev2";
/**
 * Creates a channel to receive content.
 *
 * After it's created, a channel provides static input URLs. These URLs remain the same throughout the lifetime of the channel, regardless of any failures or upgrades that might occur. Use these URLs to configure the outputs of your upstream encoder.
 *
 * @cloudformationResource AWS::MediaPackageV2::Channel
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channel.html
 */
export declare class CfnChannelPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnChannelMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MediaPackageV2::Channel`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnChannelMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnChannel;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnChannelPropsMixin {
    /**
     * The configuration for input switching based on the media quality confidence score (MQCS) as provided from AWS Elemental MediaLive.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-channel-inputswitchconfiguration.html
     */
    interface InputSwitchConfigurationProperty {
        /**
         * When true, AWS Elemental MediaPackage performs input switching based on the MQCS.
         *
         * Default is false. This setting is valid only when `InputType` is `CMAF` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-channel-inputswitchconfiguration.html#cfn-mediapackagev2-channel-inputswitchconfiguration-mqcsinputswitching
         */
        readonly mqcsInputSwitching?: boolean | cdk.IResolvable;
        /**
         * For CMAF inputs, indicates which input MediaPackage should prefer when both inputs have equal MQCS scores.
         *
         * Select `1` to prefer the first ingest endpoint, or `2` to prefer the second ingest endpoint. If you don't specify a preferred input, MediaPackage uses its default switching behavior when MQCS scores are equal.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-channel-inputswitchconfiguration.html#cfn-mediapackagev2-channel-inputswitchconfiguration-preferredinput
         */
        readonly preferredInput?: number;
    }
    /**
     * The settings for what common media server data (CMSD) headers AWS Elemental MediaPackage includes in responses to the CDN.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-channel-outputheaderconfiguration.html
     */
    interface OutputHeaderConfigurationProperty {
        /**
         * When true, AWS Elemental MediaPackage includes the MQCS in responses to the CDN.
         *
         * This setting is valid only when `InputType` is `CMAF` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-channel-outputheaderconfiguration.html#cfn-mediapackagev2-channel-outputheaderconfiguration-publishmqcs
         */
        readonly publishMqcs?: boolean | cdk.IResolvable;
    }
    /**
     * The input URL where the source stream should be sent.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-channel-ingestendpoint.html
     */
    interface IngestEndpointProperty {
        /**
         * The identifier associated with the ingest endpoint of the channel.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-channel-ingestendpoint.html#cfn-mediapackagev2-channel-ingestendpoint-id
         */
        readonly id?: string;
        /**
         * The URL associated with the ingest endpoint of the channel.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-channel-ingestendpoint.html#cfn-mediapackagev2-channel-ingestendpoint-url
         */
        readonly url?: string;
    }
}
/**
 * Properties for CfnChannelPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channel.html
 */
export interface CfnChannelMixinProps {
    /**
     * The name of the channel group associated with the channel configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channel.html#cfn-mediapackagev2-channel-channelgroupname
     */
    readonly channelGroupName?: string;
    /**
     * The name of the channel.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channel.html#cfn-mediapackagev2-channel-channelname
     */
    readonly channelName?: string;
    /**
     * The description of the channel.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channel.html#cfn-mediapackagev2-channel-description
     */
    readonly description?: string;
    /**
     * The configuration for input switching based on the media quality confidence score (MQCS) as provided from AWS Elemental MediaLive.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channel.html#cfn-mediapackagev2-channel-inputswitchconfiguration
     */
    readonly inputSwitchConfiguration?: CfnChannelPropsMixin.InputSwitchConfigurationProperty | cdk.IResolvable;
    /**
     * The input type will be an immutable field which will be used to define whether the channel will allow CMAF ingest or HLS ingest.
     *
     * If unprovided, it will default to HLS to preserve current behavior.
     *
     * The allowed values are:
     *
     * - `HLS` - The HLS streaming specification (which defines M3U8 manifests and TS segments).
     * - `CMAF` - The DASH-IF CMAF Ingest specification (which defines CMAF segments with optional DASH manifests).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channel.html#cfn-mediapackagev2-channel-inputtype
     */
    readonly inputType?: string;
    /**
     * The settings for what common media server data (CMSD) headers AWS Elemental MediaPackage includes in responses to the CDN.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channel.html#cfn-mediapackagev2-channel-outputheaderconfiguration
     */
    readonly outputHeaderConfiguration?: cdk.IResolvable | CfnChannelPropsMixin.OutputHeaderConfigurationProperty;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channel.html#cfn-mediapackagev2-channel-outputlockingmode
     */
    readonly outputLockingMode?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channel.html#cfn-mediapackagev2-channel-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Specifies the configuration for a MediaPackage V2 channel group.
 *
 * @cloudformationResource AWS::MediaPackageV2::ChannelGroup
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channelgroup.html
 */
export declare class CfnChannelGroupPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnChannelGroupMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MediaPackageV2::ChannelGroup`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnChannelGroupMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnChannelGroup;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnChannelGroupPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channelgroup.html
 */
export interface CfnChannelGroupMixinProps {
    /**
     * The name of the channel group.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channelgroup.html#cfn-mediapackagev2-channelgroup-channelgroupname
     */
    readonly channelGroupName?: string;
    /**
     * The configuration for a MediaPackage V2 channel group.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channelgroup.html#cfn-mediapackagev2-channelgroup-description
     */
    readonly description?: string;
    /**
     * The tags associated with the channel group.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channelgroup.html#cfn-mediapackagev2-channelgroup-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Specifies the configuration parameters of a MediaPackage V2 channel policy.
 *
 * @cloudformationResource AWS::MediaPackageV2::ChannelPolicy
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channelpolicy.html
 */
export declare class CfnChannelPolicyPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnChannelPolicyMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MediaPackageV2::ChannelPolicy`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnChannelPolicyMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnChannelPolicy;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnChannelPolicyPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channelpolicy.html
 */
export interface CfnChannelPolicyMixinProps {
    /**
     * The name of the channel group associated with the channel policy.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channelpolicy.html#cfn-mediapackagev2-channelpolicy-channelgroupname
     */
    readonly channelGroupName?: string;
    /**
     * The name of the channel associated with the channel policy.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channelpolicy.html#cfn-mediapackagev2-channelpolicy-channelname
     */
    readonly channelName?: string;
    /**
     * The policy associated with the channel.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channelpolicy.html#cfn-mediapackagev2-channelpolicy-policy
     */
    readonly policy?: any | cdk.IResolvable;
}
/**
 * Specifies the configuration parameters for a MediaPackage V2 origin endpoint.
 *
 * @cloudformationResource AWS::MediaPackageV2::OriginEndpoint
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html
 */
export declare class CfnOriginEndpointPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnOriginEndpointMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MediaPackageV2::OriginEndpoint`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnOriginEndpointMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnOriginEndpoint;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnOriginEndpointPropsMixin {
    /**
     * Specify a low-latency HTTP live streaming (LL-HLS) manifest configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration.html
     */
    interface LowLatencyHlsManifestConfigurationProperty {
        /**
         * The name of the child manifest associated with the low-latency HLS (LL-HLS) manifest configuration of the origin endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration-childmanifestname
         */
        readonly childManifestName?: string;
        /**
         * Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration-filterconfiguration
         */
        readonly filterConfiguration?: CfnOriginEndpointPropsMixin.FilterConfigurationProperty | cdk.IResolvable;
        /**
         * A short string that's appended to the endpoint URL.
         *
         * The manifest name creates a unique path to this endpoint. If you don't enter a value, MediaPackage uses the default manifest name, `index` . MediaPackage automatically inserts the format extension, such as `.m3u8` . You can't use the same manifest name if you use HLS manifest and low-latency HLS manifest. The `manifestName` on the `HLSManifest` object overrides the `manifestName` you provided on the `originEndpoint` object.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration-manifestname
         */
        readonly manifestName?: string;
        /**
         * The total duration (in seconds) of the manifest's content.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration-manifestwindowseconds
         */
        readonly manifestWindowSeconds?: number;
        /**
         * Inserts `EXT-X-PROGRAM-DATE-TIME` tags in the output manifest at the interval that you specify.
         *
         * If you don't enter an interval, `EXT-X-PROGRAM-DATE-TIME` tags aren't included in the manifest. The tags sync the stream to the wall clock so that viewers can seek to a specific time in the playback timeline on the player.
         *
         * Irrespective of this parameter, if any `ID3Timed` metadata is in the HLS input, MediaPackage passes through that metadata to the HLS output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration-programdatetimeintervalseconds
         */
        readonly programDateTimeIntervalSeconds?: number;
        /**
         * The SCTE-35 HLS configuration associated with the low-latency HLS (LL-HLS) manifest configuration of the origin endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration-sctehls
         */
        readonly scteHls?: cdk.IResolvable | CfnOriginEndpointPropsMixin.ScteHlsProperty;
        /**
         * To insert an EXT-X-START tag in your HLS playlist, specify a StartTag configuration object with a valid TimeOffset.
         *
         * When you do, you can also optionally specify whether to include a PRECISE value in the EXT-X-START tag.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration-starttag
         */
        readonly startTag?: cdk.IResolvable | CfnOriginEndpointPropsMixin.StartTagProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration-uripathtype
         */
        readonly uriPathType?: string;
        /**
         * The URL of the low-latency HLS (LL-HLS) manifest configuration of the origin endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration-url
         */
        readonly url?: string;
        /**
         * When enabled, MediaPackage URL-encodes the query string for API requests for LL-HLS child manifests to comply with AWS Signature Version 4 (SigV4) signature signing protocol.
         *
         * For more information, see [AWS Signature Version 4 for API requests](https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_sigv.html) in *AWS Identity and Access Management User Guide* .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-lowlatencyhlsmanifestconfiguration-urlencodechildmanifest
         */
        readonly urlEncodeChildManifest?: boolean | cdk.IResolvable;
    }
    /**
     * The SCTE-35 HLS configuration associated with the origin endpoint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-sctehls.html
     */
    interface ScteHlsProperty {
        /**
         * The SCTE-35 HLS ad-marker configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-sctehls.html#cfn-mediapackagev2-originendpoint-sctehls-admarkerhls
         */
        readonly adMarkerHls?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-sctehls.html#cfn-mediapackagev2-originendpoint-sctehls-scteinmanifests
         */
        readonly scteInManifests?: string;
    }
    /**
     * Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-filterconfiguration.html
     */
    interface FilterConfigurationProperty {
        /**
         * Optionally specify the clip start time for all of your manifest egress requests.
         *
         * When you include clip start time, note that you cannot use clip start time query parameters for this manifest's endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-filterconfiguration.html#cfn-mediapackagev2-originendpoint-filterconfiguration-clipstarttime
         */
        readonly clipStartTime?: string;
        /**
         * <p>Optionally specify one or more DRM settings for all of your manifest egress requests.
         *
         * When you include a DRM setting, note that you cannot use an identical DRM setting query parameter for this manifest's endpoint URL.</p>
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-filterconfiguration.html#cfn-mediapackagev2-originendpoint-filterconfiguration-drmsettings
         */
        readonly drmSettings?: string;
        /**
         * Optionally specify the end time for all of your manifest egress requests.
         *
         * When you include end time, note that you cannot use end time query parameters for this manifest's endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-filterconfiguration.html#cfn-mediapackagev2-originendpoint-filterconfiguration-end
         */
        readonly end?: string;
        /**
         * Optionally specify one or more manifest filters for all of your manifest egress requests.
         *
         * When you include a manifest filter, note that you cannot use an identical manifest filter query parameter for this manifest's endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-filterconfiguration.html#cfn-mediapackagev2-originendpoint-filterconfiguration-manifestfilter
         */
        readonly manifestFilter?: string;
        /**
         * Optionally specify the start time for all of your manifest egress requests.
         *
         * When you include start time, note that you cannot use start time query parameters for this manifest's endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-filterconfiguration.html#cfn-mediapackagev2-originendpoint-filterconfiguration-start
         */
        readonly start?: string;
        /**
         * Optionally specify the time delay for all of your manifest egress requests.
         *
         * Enter a value that is smaller than your endpoint's startover window. When you include time delay, note that you cannot use time delay query parameters for this manifest's endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-filterconfiguration.html#cfn-mediapackagev2-originendpoint-filterconfiguration-timedelayseconds
         */
        readonly timeDelaySeconds?: number;
    }
    /**
     * To insert an EXT-X-START tag in your HLS playlist, specify a StartTag configuration object with a valid TimeOffset.
     *
     * When you do, you can also optionally specify whether to include a PRECISE value in the EXT-X-START tag.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-starttag.html
     */
    interface StartTagProperty {
        /**
         * Specify the value for PRECISE within your EXT-X-START tag.
         *
         * Leave blank, or choose false, to use the default value NO. Choose yes to use the value YES.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-starttag.html#cfn-mediapackagev2-originendpoint-starttag-precise
         */
        readonly precise?: boolean | cdk.IResolvable;
        /**
         * Specify the value for TIME-OFFSET within your EXT-X-START tag.
         *
         * Enter a signed floating point value which, if positive, must be less than the configured manifest duration minus three times the configured segment target duration. If negative, the absolute value must be larger than three times the configured segment target duration, and the absolute value must be smaller than the configured manifest duration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-starttag.html#cfn-mediapackagev2-originendpoint-starttag-timeoffset
         */
        readonly timeOffset?: number;
    }
    /**
     * The HLS manifest configuration associated with the origin endpoint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-hlsmanifestconfiguration.html
     */
    interface HlsManifestConfigurationProperty {
        /**
         * The name of the child manifest associated with the HLS manifest configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-hlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-hlsmanifestconfiguration-childmanifestname
         */
        readonly childManifestName?: string;
        /**
         * Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-hlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-hlsmanifestconfiguration-filterconfiguration
         */
        readonly filterConfiguration?: CfnOriginEndpointPropsMixin.FilterConfigurationProperty | cdk.IResolvable;
        /**
         * The name of the manifest associated with the HLS manifest configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-hlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-hlsmanifestconfiguration-manifestname
         */
        readonly manifestName?: string;
        /**
         * The duration of the manifest window, in seconds, for the HLS manifest configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-hlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-hlsmanifestconfiguration-manifestwindowseconds
         */
        readonly manifestWindowSeconds?: number;
        /**
         * The `EXT-X-PROGRAM-DATE-TIME` interval, in seconds, associated with the HLS manifest configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-hlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-hlsmanifestconfiguration-programdatetimeintervalseconds
         */
        readonly programDateTimeIntervalSeconds?: number;
        /**
         * THE SCTE-35 HLS configuration associated with the HLS manifest configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-hlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-hlsmanifestconfiguration-sctehls
         */
        readonly scteHls?: cdk.IResolvable | CfnOriginEndpointPropsMixin.ScteHlsProperty;
        /**
         * To insert an EXT-X-START tag in your HLS playlist, specify a StartTag configuration object with a valid TimeOffset.
         *
         * When you do, you can also optionally specify whether to include a PRECISE value in the EXT-X-START tag.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-hlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-hlsmanifestconfiguration-starttag
         */
        readonly startTag?: cdk.IResolvable | CfnOriginEndpointPropsMixin.StartTagProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-hlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-hlsmanifestconfiguration-uripathtype
         */
        readonly uriPathType?: string;
        /**
         * The URL of the HLS manifest configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-hlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-hlsmanifestconfiguration-url
         */
        readonly url?: string;
        /**
         * When enabled, MediaPackage URL-encodes the query string for API requests for HLS child manifests to comply with AWS Signature Version 4 (SigV4) signature signing protocol.
         *
         * For more information, see [AWS Signature Version 4 for API requests](https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_sigv.html) in *AWS Identity and Access Management User Guide* .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-hlsmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-hlsmanifestconfiguration-urlencodechildmanifest
         */
        readonly urlEncodeChildManifest?: boolean | cdk.IResolvable;
    }
    /**
     * The segment configuration, including the segment name, duration, and other configuration values.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-segment.html
     */
    interface SegmentProperty {
        /**
         * Whether to use encryption for the segment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-segment.html#cfn-mediapackagev2-originendpoint-segment-encryption
         */
        readonly encryption?: CfnOriginEndpointPropsMixin.EncryptionProperty | cdk.IResolvable;
        /**
         * Whether the segment includes I-frame-only streams.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-segment.html#cfn-mediapackagev2-originendpoint-segment-includeiframeonlystreams
         */
        readonly includeIframeOnlyStreams?: boolean | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-segment.html#cfn-mediapackagev2-originendpoint-segment-outputtimestampmode
         */
        readonly outputTimestampMode?: string;
        /**
         * The SCTE-35 configuration associated with the segment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-segment.html#cfn-mediapackagev2-originendpoint-segment-scte
         */
        readonly scte?: cdk.IResolvable | CfnOriginEndpointPropsMixin.ScteProperty;
        /**
         * The duration of the segment, in seconds.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-segment.html#cfn-mediapackagev2-originendpoint-segment-segmentdurationseconds
         */
        readonly segmentDurationSeconds?: number;
        /**
         * The name of the segment associated with the origin endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-segment.html#cfn-mediapackagev2-originendpoint-segment-segmentname
         */
        readonly segmentName?: string;
        /**
         * Whether the segment includes DVB subtitles.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-segment.html#cfn-mediapackagev2-originendpoint-segment-tsincludedvbsubtitles
         */
        readonly tsIncludeDvbSubtitles?: boolean | cdk.IResolvable;
        /**
         * Whether the segment is an audio rendition group.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-segment.html#cfn-mediapackagev2-originendpoint-segment-tsuseaudiorenditiongroup
         */
        readonly tsUseAudioRenditionGroup?: boolean | cdk.IResolvable;
    }
    /**
     * The SCTE-35 configuration associated with the origin endpoint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-scte.html
     */
    interface ScteProperty {
        /**
         * <p>A list of additional non-Ad SCTE-35 event types to treat as advertisements.
         *
         * When configured, events matching these types produce ad markers (such as <code>SCTE35-OUT</code> and <code>SCTE35-IN</code> in HLS DATERANGE tags) in manifests.</p> <p>Valid values: <code>PROGRAM</code> | <code>CHAPTER</code> | <code>UNSCHEDULED_EVENT</code> | <code>ALTERNATE_CONTENT_OPPORTUNITY</code> | <code>NETWORK</code> </p> <p>If you don't specify any values, the default is empty (only default ad types are used).</p>
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-scte.html#cfn-mediapackagev2-originendpoint-scte-customadtypes
         */
        readonly customAdTypes?: Array<string>;
        /**
         * The filter associated with the SCTE-35 configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-scte.html#cfn-mediapackagev2-originendpoint-scte-sctefilter
         */
        readonly scteFilter?: Array<string>;
        /**
         * Controls whether SCTE-35 messages are included in segment files.
         *
         * - None – SCTE-35 messages are not included in segments (default)
         * - All – SCTE-35 messages are embedded in segment data
         *
         * For DASH manifests, when set to `All` , an `InbandEventStream` tag signals that SCTE messages are present in segments. This setting works independently of manifest ad markers.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-scte.html#cfn-mediapackagev2-originendpoint-scte-scteinsegments
         */
        readonly scteInSegments?: string;
    }
    /**
     * The parameters for encrypting content.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-encryption.html
     */
    interface EncryptionProperty {
        /**
         * Excludes SEIG and SGPD boxes from segment metadata in CMAF containers.
         *
         * When set to `true` , MediaPackage omits these DRM metadata boxes from CMAF segments, which can improve compatibility with certain devices and players that don't support these boxes.
         *
         * Important considerations:
         *
         * - This setting only affects CMAF container formats
         * - Key rotation can still be handled through media playlist signaling
         * - PSSH and TENC boxes remain unaffected
         * - Default behavior is preserved when this setting is disabled
         *
         * Valid values: `true` | `false`
         *
         * Default: `false`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-encryption.html#cfn-mediapackagev2-originendpoint-encryption-cmafexcludesegmentdrmmetadata
         */
        readonly cmafExcludeSegmentDrmMetadata?: boolean | cdk.IResolvable;
        /**
         * A 128-bit, 16-byte hex value represented by a 32-character string, used in conjunction with the key for encrypting content.
         *
         * If you don't specify a value, then MediaPackage creates the constant initialization vector (IV).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-encryption.html#cfn-mediapackagev2-originendpoint-encryption-constantinitializationvector
         */
        readonly constantInitializationVector?: string;
        /**
         * The encryption method to use.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-encryption.html#cfn-mediapackagev2-originendpoint-encryption-encryptionmethod
         */
        readonly encryptionMethod?: CfnOriginEndpointPropsMixin.EncryptionMethodProperty | cdk.IResolvable;
        /**
         * The interval, in seconds, to rotate encryption keys for the origin endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-encryption.html#cfn-mediapackagev2-originendpoint-encryption-keyrotationintervalseconds
         */
        readonly keyRotationIntervalSeconds?: number;
        /**
         * The SPEKE key provider to use for encryption.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-encryption.html#cfn-mediapackagev2-originendpoint-encryption-spekekeyprovider
         */
        readonly spekeKeyProvider?: cdk.IResolvable | CfnOriginEndpointPropsMixin.SpekeKeyProviderProperty;
    }
    /**
     * The parameters for the SPEKE key provider.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-spekekeyprovider.html
     */
    interface SpekeKeyProviderProperty {
        /**
         * <p>The ARN for the certificate that you imported to Amazon Web Services Certificate Manager to add content key encryption to this endpoint.
         *
         * For this feature to work, your DRM key provider must support content key encryption.</p>
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-spekekeyprovider.html#cfn-mediapackagev2-originendpoint-spekekeyprovider-certificatearn
         */
        readonly certificateArn?: string;
        /**
         * The DRM solution provider you're using to protect your content during distribution.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-spekekeyprovider.html#cfn-mediapackagev2-originendpoint-spekekeyprovider-drmsystems
         */
        readonly drmSystems?: Array<string>;
        /**
         * The encryption contract configuration associated with the SPEKE key provider.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-spekekeyprovider.html#cfn-mediapackagev2-originendpoint-spekekeyprovider-encryptioncontractconfiguration
         */
        readonly encryptionContractConfiguration?: CfnOriginEndpointPropsMixin.EncryptionContractConfigurationProperty | cdk.IResolvable;
        /**
         * The unique identifier for the content.
         *
         * The service sends this identifier to the key server to identify the current endpoint. How unique you make this identifier depends on how fine-grained you want access controls to be. The service does not permit you to use the same ID for two simultaneous encryption processes. The resource ID is also known as the content ID.
         *
         * The following example shows a resource ID: `MovieNight20171126093045`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-spekekeyprovider.html#cfn-mediapackagev2-originendpoint-spekekeyprovider-resourceid
         */
        readonly resourceId?: string;
        /**
         * The ARN for the IAM role granted by the key provider that provides access to the key provider API.
         *
         * This role must have a trust policy that allows MediaPackage to assume the role, and it must have a sufficient permissions policy to allow access to the specific key retrieval URL. Get this from your DRM solution provider.
         *
         * Valid format: `arn:aws:iam::{accountID}:role/{name}` . The following example shows a role ARN: `arn:aws:iam::444455556666:role/SpekeAccess`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-spekekeyprovider.html#cfn-mediapackagev2-originendpoint-spekekeyprovider-rolearn
         */
        readonly roleArn?: string;
        /**
         * The URL of the SPEKE key provider.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-spekekeyprovider.html#cfn-mediapackagev2-originendpoint-spekekeyprovider-url
         */
        readonly url?: string;
    }
    /**
     * Use `encryptionContractConfiguration` to configure one or more content encryption keys for your endpoints that use SPEKE Version 2.0. The encryption contract defines which content keys are used to encrypt the audio and video tracks in your stream. To configure the encryption contract, specify which audio and video encryption presets to use.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-encryptioncontractconfiguration.html
     */
    interface EncryptionContractConfigurationProperty {
        /**
         * A collection of audio encryption presets.
         *
         * Value description:
         *
         * - `PRESET-AUDIO-1` - Use one content key to encrypt all of the audio tracks in your stream.
         * - `PRESET-AUDIO-2` - Use one content key to encrypt all of the stereo audio tracks and one content key to encrypt all of the multichannel audio tracks.
         * - `PRESET-AUDIO-3` - Use one content key to encrypt all of the stereo audio tracks, one content key to encrypt all of the multichannel audio tracks with 3 to 6 channels, and one content key to encrypt all of the multichannel audio tracks with more than 6 channels.
         * - `SHARED` - Use the same content key for all of the audio and video tracks in your stream.
         * - `UNENCRYPTED` - Don't encrypt any of the audio tracks in your stream.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-encryptioncontractconfiguration.html#cfn-mediapackagev2-originendpoint-encryptioncontractconfiguration-presetspeke20audio
         */
        readonly presetSpeke20Audio?: string;
        /**
         * The SPEKE Version 2.0 preset video associated with the encryption contract configuration of the origin endpoint.
         *
         * A collection of video encryption presets.
         *
         * Value description:
         *
         * - `PRESET-VIDEO-1` - Use one content key to encrypt all of the video tracks in your stream.
         * - `PRESET-VIDEO-2` - Use one content key to encrypt all of the SD video tracks and one content key for all HD and higher resolutions video tracks.
         * - `PRESET-VIDEO-3` - Use one content key to encrypt all of the SD video tracks, one content key for HD video tracks and one content key for all UHD video tracks.
         * - `PRESET-VIDEO-4` - Use one content key to encrypt all of the SD video tracks, one content key for HD video tracks, one content key for all UHD1 video tracks and one content key for all UHD2 video tracks.
         * - `PRESET-VIDEO-5` - Use one content key to encrypt all of the SD video tracks, one content key for HD1 video tracks, one content key for HD2 video tracks, one content key for all UHD1 video tracks and one content key for all UHD2 video tracks.
         * - `PRESET-VIDEO-6` - Use one content key to encrypt all of the SD video tracks, one content key for HD1 video tracks, one content key for HD2 video tracks and one content key for all UHD video tracks.
         * - `PRESET-VIDEO-7` - Use one content key to encrypt all of the SD+HD1 video tracks, one content key for HD2 video tracks and one content key for all UHD video tracks.
         * - `PRESET-VIDEO-8` - Use one content key to encrypt all of the SD+HD1 video tracks, one content key for HD2 video tracks, one content key for all UHD1 video tracks and one content key for all UHD2 video tracks.
         * - `SHARED` - Use the same content key for all of the video and audio tracks in your stream.
         * - `UNENCRYPTED` - Don't encrypt any of the video tracks in your stream.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-encryptioncontractconfiguration.html#cfn-mediapackagev2-originendpoint-encryptioncontractconfiguration-presetspeke20video
         */
        readonly presetSpeke20Video?: string;
    }
    /**
     * The encryption method associated with the origin endpoint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-encryptionmethod.html
     */
    interface EncryptionMethodProperty {
        /**
         * The encryption method to use.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-encryptionmethod.html#cfn-mediapackagev2-originendpoint-encryptionmethod-cmafencryptionmethod
         */
        readonly cmafEncryptionMethod?: string;
        /**
         * The encryption method used for Microsoft Smooth Streaming (MSS) content.
         *
         * This specifies how the MSS segments are encrypted to protect the content during delivery to client players.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-encryptionmethod.html#cfn-mediapackagev2-originendpoint-encryptionmethod-ismencryptionmethod
         */
        readonly ismEncryptionMethod?: string;
        /**
         * The encryption method to use.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-encryptionmethod.html#cfn-mediapackagev2-originendpoint-encryptionmethod-tsencryptionmethod
         */
        readonly tsEncryptionMethod?: string;
    }
    /**
     * The DASH manifest configuration associated with the origin endpoint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html
     */
    interface DashManifestConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-audiotimelinepattern
         */
        readonly audioTimelinePattern?: string;
        /**
         * <p>The configuration for the DASH <code>availabilityStartTime</code> attribute of the Media Presentation Description (MPD).
         *
         * Use this configuration to set a custom availability start time for your DASH manifest.</p>
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-availabilitystarttimeconfiguration
         */
        readonly availabilityStartTimeConfiguration?: CfnOriginEndpointPropsMixin.DashAvailabilityStartTimeConfigurationProperty | cdk.IResolvable;
        /**
         * The base URLs to use for retrieving segments.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-baseurls
         */
        readonly baseUrls?: Array<CfnOriginEndpointPropsMixin.DashBaseUrlProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The layout of the DASH manifest that MediaPackage produces.
         *
         * `STANDARD` indicates a default manifest, which is compacted. `NONE` indicates a full manifest.
         *
         * For information about compactness, see [DASH manifest compactness](https://docs.aws.amazon.com/mediapackage/latest/userguide/compacted.html) in the *AWS Elemental MediaPackage v2 User Guide* .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-compactness
         */
        readonly compactness?: string;
        /**
         * Determines how the DASH manifest signals the DRM content.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-drmsignaling
         */
        readonly drmSignaling?: string;
        /**
         * For endpoints that use the DVB-DASH profile only.
         *
         * The font download and error reporting information that you want MediaPackage to pass through to the manifest.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-dvbsettings
         */
        readonly dvbSettings?: CfnOriginEndpointPropsMixin.DashDvbSettingsProperty | cdk.IResolvable;
        /**
         * Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-filterconfiguration
         */
        readonly filterConfiguration?: CfnOriginEndpointPropsMixin.FilterConfigurationProperty | cdk.IResolvable;
        /**
         * A short string that's appended to the endpoint URL.
         *
         * The child manifest name creates a unique path to this endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-manifestname
         */
        readonly manifestName?: string;
        /**
         * The total duration (in seconds) of the manifest's content.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-manifestwindowseconds
         */
        readonly manifestWindowSeconds?: number;
        /**
         * Minimum amount of content (in seconds) that a player must keep available in the buffer.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-minbuffertimeseconds
         */
        readonly minBufferTimeSeconds?: number;
        /**
         * Minimum amount of time (in seconds) that the player should wait before requesting updates to the manifest.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-minupdateperiodseconds
         */
        readonly minUpdatePeriodSeconds?: number;
        /**
         * A list of triggers that controls when AWS Elemental MediaPackage separates the MPEG-DASH manifest into multiple periods.
         *
         * Type `ADS` to indicate that AWS Elemental MediaPackage must create periods in the output manifest that correspond to SCTE-35 ad markers in the input source. Leave this value empty to indicate that the manifest is contained all in one period. For more information about periods in the DASH manifest, see [Multi-period DASH in AWS Elemental MediaPackage](https://docs.aws.amazon.com/mediapackage/latest/userguide/multi-period.html) .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-periodtriggers
         */
        readonly periodTriggers?: Array<string>;
        /**
         * The profile that the output is compliant with.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-profiles
         */
        readonly profiles?: Array<string>;
        /**
         * Details about the content that you want MediaPackage to pass through in the manifest to the playback device.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-programinformation
         */
        readonly programInformation?: CfnOriginEndpointPropsMixin.DashProgramInformationProperty | cdk.IResolvable;
        /**
         * The SCTE configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-sctedash
         */
        readonly scteDash?: cdk.IResolvable | CfnOriginEndpointPropsMixin.ScteDashProperty;
        /**
         * Determines the type of variable used in the `media` URL of the `SegmentTemplate` tag in the manifest.
         *
         * Also specifies if segment timeline information is included in `SegmentTimeline` or `SegmentTemplate` .
         *
         * Value description:
         *
         * - `NUMBER_WITH_TIMELINE` - The `$Number$` variable is used in the `media` URL. The value of this variable is the sequential number of the segment. A full `SegmentTimeline` object is presented in each `SegmentTemplate` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-segmenttemplateformat
         */
        readonly segmentTemplateFormat?: string;
        /**
         * The configuration for DASH subtitles.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-subtitleconfiguration
         */
        readonly subtitleConfiguration?: CfnOriginEndpointPropsMixin.DashSubtitleConfigurationProperty | cdk.IResolvable;
        /**
         * The amount of time (in seconds) that the player should be from the end of the manifest.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-suggestedpresentationdelayseconds
         */
        readonly suggestedPresentationDelaySeconds?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-uripathtype
         */
        readonly uriPathType?: string;
        /**
         * Determines the type of UTC timing included in the DASH Media Presentation Description (MPD).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-dashmanifestconfiguration-utctiming
         */
        readonly utcTiming?: CfnOriginEndpointPropsMixin.DashUtcTimingProperty | cdk.IResolvable;
    }
    /**
     * The SCTE configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-sctedash.html
     */
    interface ScteDashProperty {
        /**
         * Choose how ad markers are included in the packaged content.
         *
         * If you include ad markers in the content stream in your upstream encoders, then you need to inform MediaPackage what to do with the ad markers in the output.
         *
         * Value description:
         *
         * - `Binary` - The SCTE-35 marker is expressed as a hex-string (Base64 string) rather than full XML.
         * - `XML` - The SCTE marker is expressed fully in XML.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-sctedash.html#cfn-mediapackagev2-originendpoint-sctedash-admarkerdash
         */
        readonly adMarkerDash?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-sctedash.html#cfn-mediapackagev2-originendpoint-sctedash-scteinmanifests
         */
        readonly scteInManifests?: string;
    }
    /**
     * Determines the type of UTC timing included in the DASH Media Presentation Description (MPD).
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashutctiming.html
     */
    interface DashUtcTimingProperty {
        /**
         * The UTC timing mode.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashutctiming.html#cfn-mediapackagev2-originendpoint-dashutctiming-timingmode
         */
        readonly timingMode?: string;
        /**
         * The the method that the player uses to synchronize to coordinated universal time (UTC) wall clock time.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashutctiming.html#cfn-mediapackagev2-originendpoint-dashutctiming-timingsource
         */
        readonly timingSource?: string;
    }
    /**
     * The base URLs to use for retrieving segments.
     *
     * You can specify multiple locations and indicate the priority and weight for when each should be used, for use in mutli-CDN workflows.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashbaseurl.html
     */
    interface DashBaseUrlProperty {
        /**
         * For use with DVB-DASH profiles only.
         *
         * The priority of this location for servings segments. The lower the number, the higher the priority.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashbaseurl.html#cfn-mediapackagev2-originendpoint-dashbaseurl-dvbpriority
         */
        readonly dvbPriority?: number;
        /**
         * For use with DVB-DASH profiles only.
         *
         * The weighting for source locations that have the same priority.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashbaseurl.html#cfn-mediapackagev2-originendpoint-dashbaseurl-dvbweight
         */
        readonly dvbWeight?: number;
        /**
         * The name of the source location.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashbaseurl.html#cfn-mediapackagev2-originendpoint-dashbaseurl-servicelocation
         */
        readonly serviceLocation?: string;
        /**
         * A source location for segments.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashbaseurl.html#cfn-mediapackagev2-originendpoint-dashbaseurl-url
         */
        readonly url?: string;
    }
    /**
     * Details about the content that you want MediaPackage to pass through in the manifest to the playback device.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashprograminformation.html
     */
    interface DashProgramInformationProperty {
        /**
         * A copyright statement about the content.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashprograminformation.html#cfn-mediapackagev2-originendpoint-dashprograminformation-copyright
         */
        readonly copyright?: string;
        /**
         * The language code for this manifest.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashprograminformation.html#cfn-mediapackagev2-originendpoint-dashprograminformation-languagecode
         */
        readonly languageCode?: string;
        /**
         * An absolute URL that contains more information about this content.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashprograminformation.html#cfn-mediapackagev2-originendpoint-dashprograminformation-moreinformationurl
         */
        readonly moreInformationUrl?: string;
        /**
         * Information about the content provider.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashprograminformation.html#cfn-mediapackagev2-originendpoint-dashprograminformation-source
         */
        readonly source?: string;
        /**
         * The title for the manifest.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashprograminformation.html#cfn-mediapackagev2-originendpoint-dashprograminformation-title
         */
        readonly title?: string;
    }
    /**
     * For endpoints that use the DVB-DASH profile only.
     *
     * The font download and error reporting information that you want MediaPackage to pass through to the manifest.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashdvbsettings.html
     */
    interface DashDvbSettingsProperty {
        /**
         * Playback device error reporting settings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashdvbsettings.html#cfn-mediapackagev2-originendpoint-dashdvbsettings-errormetrics
         */
        readonly errorMetrics?: Array<CfnOriginEndpointPropsMixin.DashDvbMetricsReportingProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Subtitle font settings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashdvbsettings.html#cfn-mediapackagev2-originendpoint-dashdvbsettings-fontdownload
         */
        readonly fontDownload?: CfnOriginEndpointPropsMixin.DashDvbFontDownloadProperty | cdk.IResolvable;
    }
    /**
     * For use with DVB-DASH profiles only.
     *
     * The settings for font downloads that you want AWS Elemental MediaPackage to pass through to the manifest.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashdvbfontdownload.html
     */
    interface DashDvbFontDownloadProperty {
        /**
         * The `fontFamily` name for subtitles, as described in [EBU-TT-D Subtitling Distribution Format](https://docs.aws.amazon.com/https://tech.ebu.ch/publications/tech3380) .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashdvbfontdownload.html#cfn-mediapackagev2-originendpoint-dashdvbfontdownload-fontfamily
         */
        readonly fontFamily?: string;
        /**
         * The `mimeType` of the resource that's at the font download URL.
         *
         * For information about font MIME types, see the [MPEG-DASH Profile for Transport of ISO BMFF Based DVB Services over IP Based Networks](https://docs.aws.amazon.com/https://dvb.org/wp-content/uploads/2021/06/A168r4_MPEG-DASH-Profile-for-Transport-of-ISO-BMFF-Based-DVB-Services_Draft-ts_103-285-v140_November_2021.pdf) document.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashdvbfontdownload.html#cfn-mediapackagev2-originendpoint-dashdvbfontdownload-mimetype
         */
        readonly mimeType?: string;
        /**
         * The URL for downloading fonts for subtitles.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashdvbfontdownload.html#cfn-mediapackagev2-originendpoint-dashdvbfontdownload-url
         */
        readonly url?: string;
    }
    /**
     * For use with DVB-DASH profiles only.
     *
     * The settings for error reporting from the playback device that you want AWS Elemental MediaPackage to pass through to the manifest.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashdvbmetricsreporting.html
     */
    interface DashDvbMetricsReportingProperty {
        /**
         * The number of playback devices per 1000 that will send error reports to the reporting URL.
         *
         * This represents the probability that a playback device will be a reporting player for this session.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashdvbmetricsreporting.html#cfn-mediapackagev2-originendpoint-dashdvbmetricsreporting-probability
         */
        readonly probability?: number;
        /**
         * The URL where playback devices send error reports.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashdvbmetricsreporting.html#cfn-mediapackagev2-originendpoint-dashdvbmetricsreporting-reportingurl
         */
        readonly reportingUrl?: string;
    }
    /**
     * The configuration for DASH subtitles.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashsubtitleconfiguration.html
     */
    interface DashSubtitleConfigurationProperty {
        /**
         * Settings for TTML subtitles.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashsubtitleconfiguration.html#cfn-mediapackagev2-originendpoint-dashsubtitleconfiguration-ttmlconfiguration
         */
        readonly ttmlConfiguration?: CfnOriginEndpointPropsMixin.DashTtmlConfigurationProperty | cdk.IResolvable;
    }
    /**
     * The settings for TTML subtitles.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashttmlconfiguration.html
     */
    interface DashTtmlConfigurationProperty {
        /**
         * The profile that MediaPackage uses when signaling subtitles in the manifest.
         *
         * `IMSC` is the default profile. `EBU-TT-D` produces subtitles that are compliant with the EBU-TT-D TTML profile. MediaPackage passes through subtitle styles to the manifest. For more information about EBU-TT-D subtitles, see [EBU-TT-D Subtitling Distribution Format](https://docs.aws.amazon.com/https://tech.ebu.ch/publications/tech3380) .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashttmlconfiguration.html#cfn-mediapackagev2-originendpoint-dashttmlconfiguration-ttmlprofile
         */
        readonly ttmlProfile?: string;
    }
    /**
     * <p>The configuration for the DASH <code>availabilityStartTime</code> attribute of the Media Presentation Description (MPD).
     *
     * Use this configuration to set a custom availability start time for your DASH manifest.</p>
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashavailabilitystarttimeconfiguration.html
     */
    interface DashAvailabilityStartTimeConfigurationProperty {
        /**
         * <p>The fixed availability start time for the DASH manifest, in ISO 8601 date-time format.
         *
         * The value must have hourly granularity, meaning that the minutes, seconds, and fractional seconds must be zero. The value must be on or after <code>2024-01-01T00:00:00Z</code> and must be at least 14 days before the current time.</p>
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-dashavailabilitystarttimeconfiguration.html#cfn-mediapackagev2-originendpoint-dashavailabilitystarttimeconfiguration-fixedavailabilitystarttime
         */
        readonly fixedAvailabilityStartTime?: string;
    }
    /**
     * The failover settings for the endpoint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-forceendpointerrorconfiguration.html
     */
    interface ForceEndpointErrorConfigurationProperty {
        /**
         * The failover conditions for the endpoint. The options are:.
         *
         * - `STALE_MANIFEST` - The manifest stalled and there are no new segments or parts.
         * - `INCOMPLETE_MANIFEST` - There is a gap in the manifest.
         * - `MISSING_DRM_KEY` - Key rotation is enabled but we're unable to fetch the key for the current key period.
         * - `SLATE_INPUT` - The segments which contain slate content are considered to be missing content.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-forceendpointerrorconfiguration.html#cfn-mediapackagev2-originendpoint-forceendpointerrorconfiguration-endpointerrorconditions
         */
        readonly endpointErrorConditions?: Array<string>;
    }
    /**
     * <p>Configuration details for a Microsoft Smooth Streaming (MSS) manifest associated with an origin endpoint.
     *
     * This includes all the settings and properties that define how the MSS content is packaged and delivered.</p>
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-mssmanifestconfiguration.html
     */
    interface MssManifestConfigurationProperty {
        /**
         * <p>Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest.
         *
         * </p>
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-mssmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-mssmanifestconfiguration-filterconfiguration
         */
        readonly filterConfiguration?: CfnOriginEndpointPropsMixin.FilterConfigurationProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-mssmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-mssmanifestconfiguration-manifestlayout
         */
        readonly manifestLayout?: string;
        /**
         * <p>The name of the MSS manifest.
         *
         * This name is appended to the origin endpoint URL to create the unique path for accessing this specific MSS manifest.</p>
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-mssmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-mssmanifestconfiguration-manifestname
         */
        readonly manifestName?: string;
        /**
         * <p>The duration (in seconds) of the manifest window.
         *
         * This represents the total amount of content available in the manifest at any given time.</p>
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpoint-mssmanifestconfiguration.html#cfn-mediapackagev2-originendpoint-mssmanifestconfiguration-manifestwindowseconds
         */
        readonly manifestWindowSeconds?: number;
    }
}
/**
 * Properties for CfnOriginEndpointPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html
 */
export interface CfnOriginEndpointMixinProps {
    /**
     * The name of the channel group associated with the origin endpoint configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-channelgroupname
     */
    readonly channelGroupName?: string;
    /**
     * The channel name associated with the origin endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-channelname
     */
    readonly channelName?: string;
    /**
     * The container type associated with the origin endpoint configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-containertype
     */
    readonly containerType?: string;
    /**
     * A DASH manifest configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-dashmanifests
     */
    readonly dashManifests?: Array<CfnOriginEndpointPropsMixin.DashManifestConfigurationProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The description associated with the origin endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-description
     */
    readonly description?: string;
    /**
     * The failover settings for the endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-forceendpointerrorconfiguration
     */
    readonly forceEndpointErrorConfiguration?: CfnOriginEndpointPropsMixin.ForceEndpointErrorConfigurationProperty | cdk.IResolvable;
    /**
     * The HLS manifests associated with the origin endpoint configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-hlsmanifests
     */
    readonly hlsManifests?: Array<CfnOriginEndpointPropsMixin.HlsManifestConfigurationProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The low-latency HLS (LL-HLS) manifests associated with the origin endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-lowlatencyhlsmanifests
     */
    readonly lowLatencyHlsManifests?: Array<cdk.IResolvable | CfnOriginEndpointPropsMixin.LowLatencyHlsManifestConfigurationProperty> | cdk.IResolvable;
    /**
     * A list of Microsoft Smooth Streaming (MSS) manifest configurations associated with the origin endpoint.
     *
     * Each configuration represents a different MSS streaming option available from this endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-mssmanifests
     */
    readonly mssManifests?: Array<cdk.IResolvable | CfnOriginEndpointPropsMixin.MssManifestConfigurationProperty> | cdk.IResolvable;
    /**
     * The name of the origin endpoint associated with the origin endpoint configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-originendpointname
     */
    readonly originEndpointName?: string;
    /**
     * The segment associated with the origin endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-segment
     */
    readonly segment?: cdk.IResolvable | CfnOriginEndpointPropsMixin.SegmentProperty;
    /**
     * The size of the window (in seconds) to specify a window of the live stream that's available for on-demand viewing.
     *
     * Viewers can start-over or catch-up on content that falls within the window.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-startoverwindowseconds
     */
    readonly startoverWindowSeconds?: number;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-streamnameoutputmode
     */
    readonly streamNameOutputMode?: string;
    /**
     * The tags associated with the origin endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpoint.html#cfn-mediapackagev2-originendpoint-uriseparator
     */
    readonly uriSeparator?: string;
}
/**
 * Specifies the configuration parameters of a policy associated with a MediaPackage V2 origin endpoint.
 *
 * @cloudformationResource AWS::MediaPackageV2::OriginEndpointPolicy
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpointpolicy.html
 */
export declare class CfnOriginEndpointPolicyPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnOriginEndpointPolicyMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MediaPackageV2::OriginEndpointPolicy`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnOriginEndpointPolicyMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnOriginEndpointPolicy;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnOriginEndpointPolicyPropsMixin {
    /**
     * The settings to enable CDN authorization headers in MediaPackage.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpointpolicy-cdnauthconfiguration.html
     */
    interface CdnAuthConfigurationProperty {
        /**
         * The ARN for the secret in Secrets Manager that your CDN uses for authorization to access the endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpointpolicy-cdnauthconfiguration.html#cfn-mediapackagev2-originendpointpolicy-cdnauthconfiguration-cdnidentifiersecretarns
         */
        readonly cdnIdentifierSecretArns?: Array<string>;
        /**
         * The ARN for the IAM role that gives MediaPackage read access to Secrets Manager and AWS  for CDN authorization.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mediapackagev2-originendpointpolicy-cdnauthconfiguration.html#cfn-mediapackagev2-originendpointpolicy-cdnauthconfiguration-secretsrolearn
         */
        readonly secretsRoleArn?: string;
    }
}
/**
 * Properties for CfnOriginEndpointPolicyPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpointpolicy.html
 */
export interface CfnOriginEndpointPolicyMixinProps {
    /**
     * The settings to enable CDN authorization headers in MediaPackage.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpointpolicy.html#cfn-mediapackagev2-originendpointpolicy-cdnauthconfiguration
     */
    readonly cdnAuthConfiguration?: CfnOriginEndpointPolicyPropsMixin.CdnAuthConfigurationProperty | cdk.IResolvable;
    /**
     * The name of the channel group associated with the origin endpoint policy.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpointpolicy.html#cfn-mediapackagev2-originendpointpolicy-channelgroupname
     */
    readonly channelGroupName?: string;
    /**
     * The channel name associated with the origin endpoint policy.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpointpolicy.html#cfn-mediapackagev2-originendpointpolicy-channelname
     */
    readonly channelName?: string;
    /**
     * The name of the origin endpoint associated with the origin endpoint policy.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpointpolicy.html#cfn-mediapackagev2-originendpointpolicy-originendpointname
     */
    readonly originEndpointName?: string;
    /**
     * The policy associated with the origin endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-originendpointpolicy.html#cfn-mediapackagev2-originendpointpolicy-policy
     */
    readonly policy?: any | cdk.IResolvable;
}
