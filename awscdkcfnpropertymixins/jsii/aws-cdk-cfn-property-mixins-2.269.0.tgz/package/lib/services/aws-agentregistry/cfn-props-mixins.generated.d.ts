import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-agentregistry";
/**
 * Definition of AWS::AgentRegistry::Registry Resource Type.
 *
 * @cloudformationResource AWS::AgentRegistry::Registry
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registry.html
 */
export declare class CfnRegistryPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnRegistryMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::AgentRegistry::Registry`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnRegistryMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnRegistry;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnRegistryPropsMixin {
    /**
     * Discovery configuration for the registry.
     *
     * Controls how consumers are authorized to search the registry and invoke its MCP endpoint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-discoveryconfiguration.html
     */
    interface DiscoveryConfigurationProperty {
        /**
         * The authorizer configuration for the registry.
         *
         * This is a union - specify exactly one member.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-discoveryconfiguration.html#cfn-agentregistry-registry-discoveryconfiguration-authorizerconfiguration
         */
        readonly authorizerConfiguration?: CfnRegistryPropsMixin.AuthorizerConfigurationProperty | cdk.IResolvable;
    }
    /**
     * The authorizer configuration for the registry.
     *
     * This is a union - specify exactly one member.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-authorizerconfiguration.html
     */
    interface AuthorizerConfigurationProperty {
        /**
         * Configuration for a custom JWT authorizer that validates inbound bearer tokens against an OpenID Connect identity provider.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-authorizerconfiguration.html#cfn-agentregistry-registry-authorizerconfiguration-customjwtauthorizer
         */
        readonly customJwtAuthorizer?: CfnRegistryPropsMixin.CustomJWTAuthorizerConfigurationProperty | cdk.IResolvable;
    }
    /**
     * Configuration for a custom JWT authorizer that validates inbound bearer tokens against an OpenID Connect identity provider.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-customjwtauthorizerconfiguration.html
     */
    interface CustomJWTAuthorizerConfigurationProperty {
        /**
         * The audience values accepted during JWT validation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-customjwtauthorizerconfiguration.html#cfn-agentregistry-registry-customjwtauthorizerconfiguration-allowedaudience
         */
        readonly allowedAudience?: Array<string>;
        /**
         * The client identifiers accepted during JWT validation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-customjwtauthorizerconfiguration.html#cfn-agentregistry-registry-customjwtauthorizerconfiguration-allowedclients
         */
        readonly allowedClients?: Array<string>;
        /**
         * The scopes accepted during JWT validation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-customjwtauthorizerconfiguration.html#cfn-agentregistry-registry-customjwtauthorizerconfiguration-allowedscopes
         */
        readonly allowedScopes?: Array<string>;
        /**
         * Additional custom claim validations applied to the inbound JWT.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-customjwtauthorizerconfiguration.html#cfn-agentregistry-registry-customjwtauthorizerconfiguration-customclaims
         */
        readonly customClaims?: Array<CfnRegistryPropsMixin.CustomClaimValidationTypeProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The OpenID Connect discovery URL used to retrieve the identity provider's metadata and signing keys.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-customjwtauthorizerconfiguration.html#cfn-agentregistry-registry-customjwtauthorizerconfiguration-discoveryurl
         */
        readonly discoveryUrl?: string;
    }
    /**
     * A validation rule applied to a single claim of an inbound JWT.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-customclaimvalidationtype.html
     */
    interface CustomClaimValidationTypeProperty {
        /**
         * The value and match operator used to authorize a claim during JWT validation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-customclaimvalidationtype.html#cfn-agentregistry-registry-customclaimvalidationtype-authorizingclaimmatchvalue
         */
        readonly authorizingClaimMatchValue?: CfnRegistryPropsMixin.AuthorizingClaimMatchValueTypeProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-customclaimvalidationtype.html#cfn-agentregistry-registry-customclaimvalidationtype-inboundtokenclaimname
         */
        readonly inboundTokenClaimName?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-customclaimvalidationtype.html#cfn-agentregistry-registry-customclaimvalidationtype-inboundtokenclaimvaluetype
         */
        readonly inboundTokenClaimValueType?: string;
    }
    /**
     * The value and match operator used to authorize a claim during JWT validation.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-authorizingclaimmatchvaluetype.html
     */
    interface AuthorizingClaimMatchValueTypeProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-authorizingclaimmatchvaluetype.html#cfn-agentregistry-registry-authorizingclaimmatchvaluetype-claimmatchoperator
         */
        readonly claimMatchOperator?: string;
        /**
         * The expected value used to match a claim.
         *
         * Exactly one member is set.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-authorizingclaimmatchvaluetype.html#cfn-agentregistry-registry-authorizingclaimmatchvaluetype-claimmatchvalue
         */
        readonly claimMatchValue?: CfnRegistryPropsMixin.ClaimMatchValueTypeProperty | cdk.IResolvable;
    }
    /**
     * The expected value used to match a claim.
     *
     * Exactly one member is set.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-claimmatchvaluetype.html
     */
    interface ClaimMatchValueTypeProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-claimmatchvaluetype.html#cfn-agentregistry-registry-claimmatchvaluetype-matchvaluestring
         */
        readonly matchValueString?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-claimmatchvaluetype.html#cfn-agentregistry-registry-claimmatchvaluetype-matchvaluestringlist
         */
        readonly matchValueStringList?: Array<string>;
    }
    /**
     * Configuration for the registry's record approval workflow.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-approvalconfiguration.html
     */
    interface ApprovalConfigurationProperty {
        /**
         * The rules that determine which registry records are automatically approved on submission.
         *
         * When omitted or empty, submitted records require manual review.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registry-approvalconfiguration.html#cfn-agentregistry-registry-approvalconfiguration-autoapprovalrules
         */
        readonly autoApprovalRules?: Array<string>;
    }
}
/**
 * Properties for CfnRegistryPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registry.html
 */
export interface CfnRegistryMixinProps {
    /**
     * Configuration for the registry's record approval workflow.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registry.html#cfn-agentregistry-registry-approvalconfiguration
     */
    readonly approvalConfiguration?: CfnRegistryPropsMixin.ApprovalConfigurationProperty | cdk.IResolvable;
    /**
     * The type of authorizer that controls how consumers access the registry's search and MCP invoke operations.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registry.html#cfn-agentregistry-registry-authorizertype
     */
    readonly authorizerType?: string;
    /**
     * The description of the registry.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registry.html#cfn-agentregistry-registry-description
     */
    readonly description?: string;
    /**
     * Discovery configuration for the registry.
     *
     * Controls how consumers are authorized to search the registry and invoke its MCP endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registry.html#cfn-agentregistry-registry-discoveryconfiguration
     */
    readonly discoveryConfiguration?: CfnRegistryPropsMixin.DiscoveryConfigurationProperty | cdk.IResolvable;
    /**
     * The name of the registry.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registry.html#cfn-agentregistry-registry-name
     */
    readonly name?: string;
    /**
     * Tags to assign to the registry.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registry.html#cfn-agentregistry-registry-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Definition of AWS::AgentRegistry::RegistryRecord Resource Type.
 *
 * @cloudformationResource AWS::AgentRegistry::RegistryRecord
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registryrecord.html
 */
export declare class CfnRegistryRecordPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnRegistryRecordMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::AgentRegistry::RegistryRecord`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnRegistryRecordMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnRegistryRecord;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnRegistryRecordPropsMixin {
    /**
     * The typed set of descriptors for a registry record.
     *
     * Exactly one descriptor field is populated based on the record type.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-descriptors.html
     */
    interface DescriptorsProperty {
        /**
         * The A2A agent card descriptor, populated when the record type is AGENT.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-descriptors.html#cfn-agentregistry-registryrecord-descriptors-a2aagentcard
         */
        readonly a2AAgentCard?: CfnRegistryRecordPropsMixin.A2aAgentCardDescriptorProperty | cdk.IResolvable;
        /**
         * The agent skills definition descriptor, populated when the record type is SKILL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-descriptors.html#cfn-agentregistry-registryrecord-descriptors-agentskillsdefinition
         */
        readonly agentSkillsDefinition?: CfnRegistryRecordPropsMixin.AgentSkillsDefinitionDescriptorProperty | cdk.IResolvable;
        /**
         * The custom descriptor, populated when the record type is CUSTOM.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-descriptors.html#cfn-agentregistry-registryrecord-descriptors-custom
         */
        readonly custom?: CfnRegistryRecordPropsMixin.CustomDescriptorProperty | cdk.IResolvable;
        /**
         * The MCP server descriptor, populated when the record type is MCP.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-descriptors.html#cfn-agentregistry-registryrecord-descriptors-mcpserver
         */
        readonly mcpServer?: cdk.IResolvable | CfnRegistryRecordPropsMixin.McpServerDescriptorProperty;
    }
    /**
     * The MCP server descriptor, populated when the record type is MCP.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-mcpserverdescriptor.html
     */
    interface McpServerDescriptorProperty {
        /**
         * Additional data associated with an MCP server descriptor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-mcpserverdescriptor.html#cfn-agentregistry-registryrecord-mcpserverdescriptor-additionaldata
         */
        readonly additionalData?: cdk.IResolvable | CfnRegistryRecordPropsMixin.McpServerAdditionalDataProperty;
        /**
         * Descriptor payload data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-mcpserverdescriptor.html#cfn-agentregistry-registryrecord-mcpserverdescriptor-data
         */
        readonly data?: string;
        /**
         * Version of the descriptor type schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-mcpserverdescriptor.html#cfn-agentregistry-registryrecord-mcpserverdescriptor-dataschemaversion
         */
        readonly dataSchemaVersion?: string;
        /**
         * The source configuration that defines where descriptor content is retrieved from.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-mcpserverdescriptor.html#cfn-agentregistry-registryrecord-mcpserverdescriptor-source
         */
        readonly source?: CfnRegistryRecordPropsMixin.DescriptorSourceProperty | cdk.IResolvable;
    }
    /**
     * Additional data associated with an MCP server descriptor.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-mcpserveradditionaldata.html
     */
    interface McpServerAdditionalDataProperty {
        /**
         * The MCP tools descriptor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-mcpserveradditionaldata.html#cfn-agentregistry-registryrecord-mcpserveradditionaldata-tools
         */
        readonly tools?: cdk.IResolvable | CfnRegistryRecordPropsMixin.McpToolsDescriptorProperty;
    }
    /**
     * The MCP tools descriptor.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-mcptoolsdescriptor.html
     */
    interface McpToolsDescriptorProperty {
        /**
         * Descriptor payload data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-mcptoolsdescriptor.html#cfn-agentregistry-registryrecord-mcptoolsdescriptor-data
         */
        readonly data?: string;
        /**
         * Version of the tools descriptor schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-mcptoolsdescriptor.html#cfn-agentregistry-registryrecord-mcptoolsdescriptor-dataschemaversion
         */
        readonly dataSchemaVersion?: string;
    }
    /**
     * The source configuration that defines where descriptor content is retrieved from.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-descriptorsource.html
     */
    interface DescriptorSourceProperty {
        /**
         * URL-based descriptor source configuration, with credential provider configurations for authenticated URL retrieval.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-descriptorsource.html#cfn-agentregistry-registryrecord-descriptorsource-fromurl
         */
        readonly fromUrl?: CfnRegistryRecordPropsMixin.DescriptorSourceFromUrlProperty | cdk.IResolvable;
    }
    /**
     * URL-based descriptor source configuration, with credential provider configurations for authenticated URL retrieval.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-descriptorsourcefromurl.html
     */
    interface DescriptorSourceFromUrlProperty {
        /**
         * The credential providers used to authenticate when fetching descriptor content from the source URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-descriptorsourcefromurl.html#cfn-agentregistry-registryrecord-descriptorsourcefromurl-credentialproviderconfigurations
         */
        readonly credentialProviderConfigurations?: Array<cdk.IResolvable | CfnRegistryRecordPropsMixin.RegistryRecordCredentialProviderConfigurationProperty> | cdk.IResolvable;
        /**
         * URL source for descriptor content.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-descriptorsourcefromurl.html#cfn-agentregistry-registryrecord-descriptorsourcefromurl-url
         */
        readonly url?: string;
    }
    /**
     * A credential provider configuration used for authenticated descriptor retrieval.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordcredentialproviderconfiguration.html
     */
    interface RegistryRecordCredentialProviderConfigurationProperty {
        /**
         * The credential provider details.
         *
         * Specify exactly one member.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordcredentialproviderconfiguration.html#cfn-agentregistry-registryrecord-registryrecordcredentialproviderconfiguration-credentialprovider
         */
        readonly credentialProvider?: cdk.IResolvable | CfnRegistryRecordPropsMixin.RegistryRecordCredentialProviderUnionProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordcredentialproviderconfiguration.html#cfn-agentregistry-registryrecord-registryrecordcredentialproviderconfiguration-credentialprovidertype
         */
        readonly credentialProviderType?: string;
    }
    /**
     * The credential provider details.
     *
     * Specify exactly one member.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordcredentialproviderunion.html
     */
    interface RegistryRecordCredentialProviderUnionProperty {
        /**
         * IAM credential provider configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordcredentialproviderunion.html#cfn-agentregistry-registryrecord-registryrecordcredentialproviderunion-iamcredentialprovider
         */
        readonly iamCredentialProvider?: cdk.IResolvable | CfnRegistryRecordPropsMixin.RegistryRecordIamCredentialProviderProperty;
        /**
         * OAuth credential provider configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordcredentialproviderunion.html#cfn-agentregistry-registryrecord-registryrecordcredentialproviderunion-oauthcredentialprovider
         */
        readonly oauthCredentialProvider?: cdk.IResolvable | CfnRegistryRecordPropsMixin.RegistryRecordOAuthCredentialProviderProperty;
    }
    /**
     * OAuth credential provider configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordoauthcredentialprovider.html
     */
    interface RegistryRecordOAuthCredentialProviderProperty {
        /**
         * Additional custom parameters for the OAuth flow.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordoauthcredentialprovider.html#cfn-agentregistry-registryrecord-registryrecordoauthcredentialprovider-customparameters
         */
        readonly customParameters?: cdk.IResolvable | Record<string, string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordoauthcredentialprovider.html#cfn-agentregistry-registryrecord-registryrecordoauthcredentialprovider-granttype
         */
        readonly grantType?: string;
        /**
         * The ARN of the OAuth credential provider.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordoauthcredentialprovider.html#cfn-agentregistry-registryrecord-registryrecordoauthcredentialprovider-providerarn
         */
        readonly providerArn?: string;
        /**
         * OAuth scopes to request.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordoauthcredentialprovider.html#cfn-agentregistry-registryrecord-registryrecordoauthcredentialprovider-scopes
         */
        readonly scopes?: Array<string>;
    }
    /**
     * IAM credential provider configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordiamcredentialprovider.html
     */
    interface RegistryRecordIamCredentialProviderProperty {
        /**
         * The SigV4 signing region.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordiamcredentialprovider.html#cfn-agentregistry-registryrecord-registryrecordiamcredentialprovider-region
         */
        readonly region?: string;
        /**
         * The ARN of the IAM role.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordiamcredentialprovider.html#cfn-agentregistry-registryrecord-registryrecordiamcredentialprovider-rolearn
         */
        readonly roleArn?: string;
        /**
         * The SigV4 signing service name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-registryrecordiamcredentialprovider.html#cfn-agentregistry-registryrecord-registryrecordiamcredentialprovider-service
         */
        readonly service?: string;
    }
    /**
     * The A2A agent card descriptor, populated when the record type is AGENT.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-a2aagentcarddescriptor.html
     */
    interface A2aAgentCardDescriptorProperty {
        /**
         * Descriptor payload data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-a2aagentcarddescriptor.html#cfn-agentregistry-registryrecord-a2aagentcarddescriptor-data
         */
        readonly data?: string;
        /**
         * Version of the descriptor type schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-a2aagentcarddescriptor.html#cfn-agentregistry-registryrecord-a2aagentcarddescriptor-dataschemaversion
         */
        readonly dataSchemaVersion?: string;
        /**
         * The source configuration that defines where descriptor content is retrieved from.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-a2aagentcarddescriptor.html#cfn-agentregistry-registryrecord-a2aagentcarddescriptor-source
         */
        readonly source?: CfnRegistryRecordPropsMixin.DescriptorSourceProperty | cdk.IResolvable;
    }
    /**
     * The agent skills definition descriptor, populated when the record type is SKILL.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-agentskillsdefinitiondescriptor.html
     */
    interface AgentSkillsDefinitionDescriptorProperty {
        /**
         * Additional data associated with an agent skills definition descriptor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-agentskillsdefinitiondescriptor.html#cfn-agentregistry-registryrecord-agentskillsdefinitiondescriptor-additionaldata
         */
        readonly additionalData?: CfnRegistryRecordPropsMixin.AgentSkillsAdditionalDataProperty | cdk.IResolvable;
        /**
         * Descriptor payload data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-agentskillsdefinitiondescriptor.html#cfn-agentregistry-registryrecord-agentskillsdefinitiondescriptor-data
         */
        readonly data?: string;
        /**
         * Version of the descriptor type schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-agentskillsdefinitiondescriptor.html#cfn-agentregistry-registryrecord-agentskillsdefinitiondescriptor-dataschemaversion
         */
        readonly dataSchemaVersion?: string;
    }
    /**
     * Additional data associated with an agent skills definition descriptor.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-agentskillsadditionaldata.html
     */
    interface AgentSkillsAdditionalDataProperty {
        /**
         * Markdown-format descriptor containing an agent skills document.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-agentskillsadditionaldata.html#cfn-agentregistry-registryrecord-agentskillsadditionaldata-skillmd
         */
        readonly skillMd?: CfnRegistryRecordPropsMixin.AgentSkillsMdDescriptorProperty | cdk.IResolvable;
    }
    /**
     * Markdown-format descriptor containing an agent skills document.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-agentskillsmddescriptor.html
     */
    interface AgentSkillsMdDescriptorProperty {
        /**
         * Descriptor payload data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-agentskillsmddescriptor.html#cfn-agentregistry-registryrecord-agentskillsmddescriptor-data
         */
        readonly data?: string;
        /**
         * Version of the descriptor type schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-agentskillsmddescriptor.html#cfn-agentregistry-registryrecord-agentskillsmddescriptor-dataschemaversion
         */
        readonly dataSchemaVersion?: string;
        /**
         * Source configuration for a SkillMd document.
         *
         * Unlike MCP/A2A sources, SkillMd does not support credential providers.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-agentskillsmddescriptor.html#cfn-agentregistry-registryrecord-agentskillsmddescriptor-source
         */
        readonly source?: cdk.IResolvable | CfnRegistryRecordPropsMixin.SkillMdSourceProperty;
    }
    /**
     * Source configuration for a SkillMd document.
     *
     * Unlike MCP/A2A sources, SkillMd does not support credential providers.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-skillmdsource.html
     */
    interface SkillMdSourceProperty {
        /**
         * URL-based source for SkillMd content (sync is skipped;
         *
         * content is provided inline via Data).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-skillmdsource.html#cfn-agentregistry-registryrecord-skillmdsource-fromurl
         */
        readonly fromUrl?: cdk.IResolvable | CfnRegistryRecordPropsMixin.SkillMdSourceFromUrlProperty;
    }
    /**
     * URL-based source for SkillMd content (sync is skipped;
     *
     * content is provided inline via Data).
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-skillmdsourcefromurl.html
     */
    interface SkillMdSourceFromUrlProperty {
        /**
         * URL source for the SkillMd document.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-skillmdsourcefromurl.html#cfn-agentregistry-registryrecord-skillmdsourcefromurl-url
         */
        readonly url?: string;
    }
    /**
     * The custom descriptor, populated when the record type is CUSTOM.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-customdescriptor.html
     */
    interface CustomDescriptorProperty {
        /**
         * Descriptor payload data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-agentregistry-registryrecord-customdescriptor.html#cfn-agentregistry-registryrecord-customdescriptor-data
         */
        readonly data?: string;
    }
}
/**
 * Properties for CfnRegistryRecordPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registryrecord.html
 */
export interface CfnRegistryRecordMixinProps {
    /**
     * The description of the registry record.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registryrecord.html#cfn-agentregistry-registryrecord-description
     */
    readonly description?: string;
    /**
     * The typed set of descriptors for a registry record.
     *
     * Exactly one descriptor field is populated based on the record type.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registryrecord.html#cfn-agentregistry-registryrecord-descriptors
     */
    readonly descriptors?: CfnRegistryRecordPropsMixin.DescriptorsProperty | cdk.IResolvable;
    /**
     * The human-readable display name of the registry record.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registryrecord.html#cfn-agentregistry-registryrecord-displayname
     */
    readonly displayName?: string;
    /**
     * The name of the registry record.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registryrecord.html#cfn-agentregistry-registryrecord-name
     */
    readonly name?: string;
    /**
     * The type of the registry record.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registryrecord.html#cfn-agentregistry-registryrecord-recordtype
     */
    readonly recordType?: string;
    /**
     * The version of the registry record.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registryrecord.html#cfn-agentregistry-registryrecord-recordversion
     */
    readonly recordVersion?: string;
    /**
     * The identifier of the registry in which to create the record.
     *
     * You can specify either the registry ID or the registry Amazon Resource Name (ARN). Use the ARN form to reference a registry shared from another account via AWS Resource Access Manager (RAM).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registryrecord.html#cfn-agentregistry-registryrecord-registryid
     */
    readonly registryId?: string;
    /**
     * Tags to assign to the registry record.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-agentregistry-registryrecord.html#cfn-agentregistry-registryrecord-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
