const VALIDATORS = { _aws_cdk_cfn_property_mixins_aws_accessanalyzer_CfnAnalyzerMixinProps: function _aws_cdk_cfn_property_mixins_aws_accessanalyzer_CfnAnalyzerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_accountaccess_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_accountaccess_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_acmpca_CfnCertificateAuthorityMixinProps: function _aws_cdk_cfn_property_mixins_aws_acmpca_CfnCertificateAuthorityMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_agentregistry_CfnRegistryMixinProps: function _aws_cdk_cfn_property_mixins_aws_agentregistry_CfnRegistryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_agentregistry_CfnRegistryRecordMixinProps: function _aws_cdk_cfn_property_mixins_aws_agentregistry_CfnRegistryRecordMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_aiops_CfnInvestigationGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_aiops_CfnInvestigationGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_amazonmq_CfnBrokerMixinProps: function _aws_cdk_cfn_property_mixins_aws_amazonmq_CfnBrokerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_amazonmq_CfnBrokerPropsMixin_TagsEntryProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_amplify_CfnAppMixinProps: function _aws_cdk_cfn_property_mixins_aws_amplify_CfnAppMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_amplify_CfnBranchMixinProps: function _aws_cdk_cfn_property_mixins_aws_amplify_CfnBranchMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_amplify_CfnWebhookMixinProps: function _aws_cdk_cfn_property_mixins_aws_amplify_CfnWebhookMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apigateway_CfnApiKeyMixinProps: function _aws_cdk_cfn_property_mixins_aws_apigateway_CfnApiKeyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apigateway_CfnClientCertificateMixinProps: function _aws_cdk_cfn_property_mixins_aws_apigateway_CfnClientCertificateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apigateway_CfnDeploymentPropsMixin_StageDescriptionProperty: function _aws_cdk_cfn_property_mixins_aws_apigateway_CfnDeploymentPropsMixin_StageDescriptionProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apigateway_CfnDomainNameMixinProps: function _aws_cdk_cfn_property_mixins_aws_apigateway_CfnDomainNameMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apigateway_CfnRestApiMixinProps: function _aws_cdk_cfn_property_mixins_aws_apigateway_CfnRestApiMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apigateway_CfnStageMixinProps: function _aws_cdk_cfn_property_mixins_aws_apigateway_CfnStageMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apigateway_CfnUsagePlanMixinProps: function _aws_cdk_cfn_property_mixins_aws_apigateway_CfnUsagePlanMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apigateway_CfnVpcLinkMixinProps: function _aws_cdk_cfn_property_mixins_aws_apigateway_CfnVpcLinkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apigateway_CfnDomainNameAccessAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_apigateway_CfnDomainNameAccessAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apigateway_CfnDomainNameV2MixinProps: function _aws_cdk_cfn_property_mixins_aws_apigateway_CfnDomainNameV2MixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apigatewayv2_CfnPortalProductMixinProps: function _aws_cdk_cfn_property_mixins_aws_apigatewayv2_CfnPortalProductMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appconfig_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_appconfig_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appconfig_CfnConfigurationProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_appconfig_CfnConfigurationProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appconfig_CfnDeploymentMixinProps: function _aws_cdk_cfn_property_mixins_aws_appconfig_CfnDeploymentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appconfig_CfnDeploymentStrategyMixinProps: function _aws_cdk_cfn_property_mixins_aws_appconfig_CfnDeploymentStrategyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appconfig_CfnEnvironmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_appconfig_CfnEnvironmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appconfig_CfnExtensionMixinProps: function _aws_cdk_cfn_property_mixins_aws_appconfig_CfnExtensionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appconfig_CfnExtensionAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_appconfig_CfnExtensionAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appconfig_CfnExperimentDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_appconfig_CfnExperimentDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appconfig_CfnExperimentRunMixinProps: function _aws_cdk_cfn_property_mixins_aws_appconfig_CfnExperimentRunMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appflow_CfnFlowMixinProps: function _aws_cdk_cfn_property_mixins_aws_appflow_CfnFlowMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appintegrations_CfnDataIntegrationMixinProps: function _aws_cdk_cfn_property_mixins_aws_appintegrations_CfnDataIntegrationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appintegrations_CfnEventIntegrationMixinProps: function _aws_cdk_cfn_property_mixins_aws_appintegrations_CfnEventIntegrationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appintegrations_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_appintegrations_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_applicationinsights_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_applicationinsights_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_applicationsignals_CfnServiceLevelObjectiveMixinProps: function _aws_cdk_cfn_property_mixins_aws_applicationsignals_CfnServiceLevelObjectiveMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appmesh_CfnGatewayRouteMixinProps: function _aws_cdk_cfn_property_mixins_aws_appmesh_CfnGatewayRouteMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appmesh_CfnMeshMixinProps: function _aws_cdk_cfn_property_mixins_aws_appmesh_CfnMeshMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appmesh_CfnRouteMixinProps: function _aws_cdk_cfn_property_mixins_aws_appmesh_CfnRouteMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appmesh_CfnVirtualGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_appmesh_CfnVirtualGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appmesh_CfnVirtualNodeMixinProps: function _aws_cdk_cfn_property_mixins_aws_appmesh_CfnVirtualNodeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appmesh_CfnVirtualRouterMixinProps: function _aws_cdk_cfn_property_mixins_aws_appmesh_CfnVirtualRouterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appmesh_CfnVirtualServiceMixinProps: function _aws_cdk_cfn_property_mixins_aws_appmesh_CfnVirtualServiceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apprunner_CfnAutoScalingConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_apprunner_CfnAutoScalingConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apprunner_CfnObservabilityConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_apprunner_CfnObservabilityConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apprunner_CfnServiceMixinProps: function _aws_cdk_cfn_property_mixins_aws_apprunner_CfnServiceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apprunner_CfnVpcConnectorMixinProps: function _aws_cdk_cfn_property_mixins_aws_apprunner_CfnVpcConnectorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_apprunner_CfnVpcIngressConnectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_apprunner_CfnVpcIngressConnectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appstream_CfnAppBlockMixinProps: function _aws_cdk_cfn_property_mixins_aws_appstream_CfnAppBlockMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appstream_CfnAppBlockBuilderMixinProps: function _aws_cdk_cfn_property_mixins_aws_appstream_CfnAppBlockBuilderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appstream_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_appstream_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appstream_CfnFleetMixinProps: function _aws_cdk_cfn_property_mixins_aws_appstream_CfnFleetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appstream_CfnImageBuilderMixinProps: function _aws_cdk_cfn_property_mixins_aws_appstream_CfnImageBuilderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appstream_CfnStackMixinProps: function _aws_cdk_cfn_property_mixins_aws_appstream_CfnStackMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appsync_CfnDataSourceMixinProps: function _aws_cdk_cfn_property_mixins_aws_appsync_CfnDataSourceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("elasticsearchConfig" in p)
                print("@aws-cdk/cfn-property-mixins.aws_appsync.CfnDataSourceMixinProps#elasticsearchConfig", "this property has been deprecated");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appsync_CfnDomainNameMixinProps: function _aws_cdk_cfn_property_mixins_aws_appsync_CfnDomainNameMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appsync_CfnGraphQLApiMixinProps: function _aws_cdk_cfn_property_mixins_aws_appsync_CfnGraphQLApiMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appsync_CfnApiMixinProps: function _aws_cdk_cfn_property_mixins_aws_appsync_CfnApiMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_appsync_CfnChannelNamespaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_appsync_CfnChannelNamespaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_aps_CfnRuleGroupsNamespaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_aps_CfnRuleGroupsNamespaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_aps_CfnWorkspaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_aps_CfnWorkspaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_aps_CfnAnomalyDetectorMixinProps: function _aws_cdk_cfn_property_mixins_aws_aps_CfnAnomalyDetectorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_aps_CfnScraperMixinProps: function _aws_cdk_cfn_property_mixins_aws_aps_CfnScraperMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_athena_CfnCapacityReservationMixinProps: function _aws_cdk_cfn_property_mixins_aws_athena_CfnCapacityReservationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_athena_CfnDataCatalogMixinProps: function _aws_cdk_cfn_property_mixins_aws_athena_CfnDataCatalogMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_athena_CfnWorkGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_athena_CfnWorkGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
            if ("workGroupConfigurationUpdates" in p)
                print("@aws-cdk/cfn-property-mixins.aws_athena.CfnWorkGroupMixinProps#workGroupConfigurationUpdates", "this property has been deprecated");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_auditmanager_CfnAssessmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_auditmanager_CfnAssessmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_auditmanager_CfnAssessmentFrameworkMixinProps: function _aws_cdk_cfn_property_mixins_aws_auditmanager_CfnAssessmentFrameworkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_autoscaling_CfnAutoScalingGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_autoscaling_CfnAutoScalingGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("notificationConfiguration" in p)
                print("@aws-cdk/cfn-property-mixins.aws_autoscaling.CfnAutoScalingGroupMixinProps#notificationConfiguration", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_autoscaling_CfnAutoScalingGroupPropsMixin_TagPropertyProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_awsexternalanthropic_CfnWorkspaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_awsexternalanthropic_CfnWorkspaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_b2bi_CfnCapabilityMixinProps: function _aws_cdk_cfn_property_mixins_aws_b2bi_CfnCapabilityMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_b2bi_CfnPartnershipMixinProps: function _aws_cdk_cfn_property_mixins_aws_b2bi_CfnPartnershipMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_b2bi_CfnProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_b2bi_CfnProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_b2bi_CfnTransformerMixinProps: function _aws_cdk_cfn_property_mixins_aws_b2bi_CfnTransformerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("ediType" in p)
                print("@aws-cdk/cfn-property-mixins.aws_b2bi.CfnTransformerMixinProps#ediType", "this property has been deprecated");
            if ("fileFormat" in p)
                print("@aws-cdk/cfn-property-mixins.aws_b2bi.CfnTransformerMixinProps#fileFormat", "this property has been deprecated");
            if ("mappingTemplate" in p)
                print("@aws-cdk/cfn-property-mixins.aws_b2bi.CfnTransformerMixinProps#mappingTemplate", "this property has been deprecated");
            if ("sampleDocument" in p)
                print("@aws-cdk/cfn-property-mixins.aws_b2bi.CfnTransformerMixinProps#sampleDocument", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_backup_CfnFrameworkMixinProps: function _aws_cdk_cfn_property_mixins_aws_backup_CfnFrameworkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.frameworkTags != null)
                for (const o of p.frameworkTags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_backup_CfnReportPlanMixinProps: function _aws_cdk_cfn_property_mixins_aws_backup_CfnReportPlanMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.reportPlanTags != null)
                for (const o of p.reportPlanTags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_backup_CfnLegalHoldMixinProps: function _aws_cdk_cfn_property_mixins_aws_backup_CfnLegalHoldMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_backup_CfnLegalHoldPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_backup_CfnRestoreTestingPlanMixinProps: function _aws_cdk_cfn_property_mixins_aws_backup_CfnRestoreTestingPlanMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_backupgateway_CfnHypervisorMixinProps: function _aws_cdk_cfn_property_mixins_aws_backupgateway_CfnHypervisorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bcm_CfnDashboardMixinProps: function _aws_cdk_cfn_property_mixins_aws_bcm_CfnDashboardMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bcmdataexports_CfnExportMixinProps: function _aws_cdk_cfn_property_mixins_aws_bcmdataexports_CfnExportMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_bcmdataexports_CfnExportPropsMixin_ResourceTagProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bcmpricingcalculator_CfnBillScenarioMixinProps: function _aws_cdk_cfn_property_mixins_aws_bcmpricingcalculator_CfnBillScenarioMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrock_CfnApplicationInferenceProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrock_CfnApplicationInferenceProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrock_CfnAutomatedReasoningPolicyMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrock_CfnAutomatedReasoningPolicyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrock_CfnAutomatedReasoningPolicyVersionMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrock_CfnAutomatedReasoningPolicyVersionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrock_CfnBlueprintMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrock_CfnBlueprintMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrock_CfnDataAutomationLibraryMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrock_CfnDataAutomationLibraryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrock_CfnDataAutomationProjectMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrock_CfnDataAutomationProjectMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrock_CfnGuardrailMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrock_CfnGuardrailMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrock_CfnIntelligentPromptRouterMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrock_CfnIntelligentPromptRouterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrock_CfnSessionMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrock_CfnSessionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnApiKeyCredentialProviderMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnApiKeyCredentialProviderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnCapacityProviderMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnCapacityProviderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnConfigurationBundleMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnConfigurationBundleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnDatasetMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnDatasetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnEvaluatorMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnEvaluatorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnHarnessMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnHarnessMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnHarnessEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnHarnessEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnOAuth2CredentialProviderMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnOAuth2CredentialProviderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnOnlineEvaluationConfigMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnOnlineEvaluationConfigMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnPaymentCredentialProviderMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnPaymentCredentialProviderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnPaymentManagerMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnPaymentManagerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnPolicyEngineMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnPolicyEngineMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnWorkloadIdentityMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockagentcore_CfnWorkloadIdentityMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_bedrockmantle_CfnProjectMixinProps: function _aws_cdk_cfn_property_mixins_aws_bedrockmantle_CfnProjectMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_billingconductor_CfnBillingGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_billingconductor_CfnBillingGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_billingconductor_CfnCustomLineItemMixinProps: function _aws_cdk_cfn_property_mixins_aws_billingconductor_CfnCustomLineItemMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_billingconductor_CfnPricingPlanMixinProps: function _aws_cdk_cfn_property_mixins_aws_billingconductor_CfnPricingPlanMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_billingconductor_CfnPricingRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_billingconductor_CfnPricingRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_braket_CfnSpendingLimitMixinProps: function _aws_cdk_cfn_property_mixins_aws_braket_CfnSpendingLimitMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_budgets_CfnBudgetsActionMixinProps: function _aws_cdk_cfn_property_mixins_aws_budgets_CfnBudgetsActionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.resourceTags != null)
                for (const o of p.resourceTags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_budgets_CfnBudgetsActionPropsMixin_ResourceTagProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cases_CfnCaseMixinProps: function _aws_cdk_cfn_property_mixins_aws_cases_CfnCaseMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cases_CfnCaseRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_cases_CfnCaseRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cases_CfnDomainMixinProps: function _aws_cdk_cfn_property_mixins_aws_cases_CfnDomainMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cases_CfnFieldMixinProps: function _aws_cdk_cfn_property_mixins_aws_cases_CfnFieldMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cases_CfnLayoutMixinProps: function _aws_cdk_cfn_property_mixins_aws_cases_CfnLayoutMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cases_CfnTemplateMixinProps: function _aws_cdk_cfn_property_mixins_aws_cases_CfnTemplateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cassandra_CfnKeyspaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_cassandra_CfnKeyspaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cassandra_CfnTablePropsMixin_CdcSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_cassandra_CfnTablePropsMixin_CdcSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cassandra_CfnTableMixinProps: function _aws_cdk_cfn_property_mixins_aws_cassandra_CfnTableMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ce_CfnAnomalySubscriptionMixinProps: function _aws_cdk_cfn_property_mixins_aws_ce_CfnAnomalySubscriptionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.resourceTags != null)
                for (const o of p.resourceTags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_ce_CfnAnomalySubscriptionPropsMixin_ResourceTagProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_certificatemanager_CfnCertificateMixinProps: function _aws_cdk_cfn_property_mixins_aws_certificatemanager_CfnCertificateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_certificatemanager_CfnAcmeDomainValidationMixinProps: function _aws_cdk_cfn_property_mixins_aws_certificatemanager_CfnAcmeDomainValidationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_certificatemanager_CfnAcmeDomainValidationPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_certificatemanager_CfnAcmeEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_certificatemanager_CfnAcmeEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_certificatemanager_CfnAcmeEndpointPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_certificatemanager_CfnAcmeExternalAccountBindingMixinProps: function _aws_cdk_cfn_property_mixins_aws_certificatemanager_CfnAcmeExternalAccountBindingMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_certificatemanager_CfnAcmeExternalAccountBindingPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_chatbot_CfnMicrosoftTeamsChannelConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_chatbot_CfnMicrosoftTeamsChannelConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_chatbot_CfnSlackChannelConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_chatbot_CfnSlackChannelConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_chatbot_CfnCustomActionMixinProps: function _aws_cdk_cfn_property_mixins_aws_chatbot_CfnCustomActionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_chime_CfnAppInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_chime_CfnAppInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_chime_CfnAppInstanceBotMixinProps: function _aws_cdk_cfn_property_mixins_aws_chime_CfnAppInstanceBotMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_chime_CfnAppInstanceUserMixinProps: function _aws_cdk_cfn_property_mixins_aws_chime_CfnAppInstanceUserMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_chime_CfnChannelFlowMixinProps: function _aws_cdk_cfn_property_mixins_aws_chime_CfnChannelFlowMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_chime_CfnMediaPipelineKinesisVideoStreamPoolMixinProps: function _aws_cdk_cfn_property_mixins_aws_chime_CfnMediaPipelineKinesisVideoStreamPoolMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_chime_CfnMediaPipelineKinesisVideoStreamPoolPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnAnalysisTemplateMixinProps: function _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnAnalysisTemplateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnCollaborationMixinProps: function _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnCollaborationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnConfiguredTableMixinProps: function _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnConfiguredTableMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnConfiguredTableAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnConfiguredTableAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnMembershipMixinProps: function _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnMembershipMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnIdMappingTableMixinProps: function _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnIdMappingTableMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnIdNamespaceAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnIdNamespaceAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnIntermediateTableMixinProps: function _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnIntermediateTableMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnPrivacyBudgetTemplateMixinProps: function _aws_cdk_cfn_property_mixins_aws_cleanrooms_CfnPrivacyBudgetTemplateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cleanroomsml_CfnConfiguredModelAlgorithmMixinProps: function _aws_cdk_cfn_property_mixins_aws_cleanroomsml_CfnConfiguredModelAlgorithmMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cleanroomsml_CfnConfiguredModelAlgorithmAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_cleanroomsml_CfnConfiguredModelAlgorithmAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cleanroomsml_CfnTrainingDatasetMixinProps: function _aws_cdk_cfn_property_mixins_aws_cleanroomsml_CfnTrainingDatasetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloud9_CfnEnvironmentEC2MixinProps: function _aws_cdk_cfn_property_mixins_aws_cloud9_CfnEnvironmentEC2MixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudformation_CfnStackMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudformation_CfnStackMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudformation_CfnStackSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudformation_CfnStackSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudformation_CfnChangeSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudformation_CfnChangeSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_cloudformation_CfnChangeSetPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnDistributionMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnDistributionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnFunctionMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnFunctionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnStreamingDistributionMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnStreamingDistributionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnAnycastIpListMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnAnycastIpListMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (!visitedObjects.has(p.tags))
                module.exports._aws_cdk_cfn_property_mixins_aws_cloudfront_CfnAnycastIpListPropsMixin_TagsProperty(p.tags);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnConnectionFunctionMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnConnectionFunctionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnConnectionGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnConnectionGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnDistributionTenantMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnDistributionTenantMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnKeyValueStoreMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnKeyValueStoreMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnTrustStoreMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnTrustStoreMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnVpcOriginMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudfront_CfnVpcOriginMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudhsm_CfnClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudhsm_CfnClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_cloudhsm_CfnClusterPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudtrail_CfnChannelMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudtrail_CfnChannelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudtrail_CfnEventDataStoreMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudtrail_CfnEventDataStoreMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudtrail_CfnTrailMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudtrail_CfnTrailMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudtrail_CfnDashboardMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudtrail_CfnDashboardMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnAlarmMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnAlarmMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnCompositeAlarmMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnCompositeAlarmMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnDashboardMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnDashboardMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnInsightRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnInsightRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnMetricStreamMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnMetricStreamMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnAlarmMuteRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnAlarmMuteRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnLogAlarmPropsMixin_ScheduledQueryConfigurationProperty: function _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnLogAlarmPropsMixin_ScheduledQueryConfigurationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnLogAlarmMixinProps: function _aws_cdk_cfn_property_mixins_aws_cloudwatch_CfnLogAlarmMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codeartifact_CfnDomainMixinProps: function _aws_cdk_cfn_property_mixins_aws_codeartifact_CfnDomainMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codeartifact_CfnRepositoryMixinProps: function _aws_cdk_cfn_property_mixins_aws_codeartifact_CfnRepositoryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codeartifact_CfnPackageGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_codeartifact_CfnPackageGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codebuild_CfnProjectMixinProps: function _aws_cdk_cfn_property_mixins_aws_codebuild_CfnProjectMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codebuild_CfnReportGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_codebuild_CfnReportGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codebuild_CfnFleetMixinProps: function _aws_cdk_cfn_property_mixins_aws_codebuild_CfnFleetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codecommit_CfnRepositoryMixinProps: function _aws_cdk_cfn_property_mixins_aws_codecommit_CfnRepositoryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codeconnections_CfnConnectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_codeconnections_CfnConnectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codeconnections_CfnHostMixinProps: function _aws_cdk_cfn_property_mixins_aws_codeconnections_CfnHostMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codedeploy_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_codedeploy_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codedeploy_CfnDeploymentGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_codedeploy_CfnDeploymentGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codeguruprofiler_CfnProfilingGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_codeguruprofiler_CfnProfilingGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codegurureviewer_CfnRepositoryAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_codegurureviewer_CfnRepositoryAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codepipeline_CfnCustomActionTypeMixinProps: function _aws_cdk_cfn_property_mixins_aws_codepipeline_CfnCustomActionTypeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codepipeline_CfnPipelineMixinProps: function _aws_cdk_cfn_property_mixins_aws_codepipeline_CfnPipelineMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codepipeline_CfnWebhookMixinProps: function _aws_cdk_cfn_property_mixins_aws_codepipeline_CfnWebhookMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codestarconnections_CfnConnectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_codestarconnections_CfnConnectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_codestarconnections_CfnRepositoryLinkMixinProps: function _aws_cdk_cfn_property_mixins_aws_codestarconnections_CfnRepositoryLinkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cognito_CfnIdentityPoolMixinProps: function _aws_cdk_cfn_property_mixins_aws_cognito_CfnIdentityPoolMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.identityPoolTags != null)
                for (const o of p.identityPoolTags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_comprehend_CfnDocumentClassifierMixinProps: function _aws_cdk_cfn_property_mixins_aws_comprehend_CfnDocumentClassifierMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_comprehend_CfnFlywheelMixinProps: function _aws_cdk_cfn_property_mixins_aws_comprehend_CfnFlywheelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_computeoptimizer_CfnAutomationRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_computeoptimizer_CfnAutomationRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_config_CfnAggregationAuthorizationMixinProps: function _aws_cdk_cfn_property_mixins_aws_config_CfnAggregationAuthorizationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_config_CfnConfigurationAggregatorMixinProps: function _aws_cdk_cfn_property_mixins_aws_config_CfnConfigurationAggregatorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_config_CfnConformancePackMixinProps: function _aws_cdk_cfn_property_mixins_aws_config_CfnConformancePackMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_config_CfnOrganizationConformancePackMixinProps: function _aws_cdk_cfn_property_mixins_aws_config_CfnOrganizationConformancePackMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_config_CfnStoredQueryMixinProps: function _aws_cdk_cfn_property_mixins_aws_config_CfnStoredQueryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_config_CfnConnectorMixinProps: function _aws_cdk_cfn_property_mixins_aws_config_CfnConnectorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnContactFlowMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnContactFlowMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnContactFlowModuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnContactFlowModuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnEvaluationFormMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnEvaluationFormMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnHoursOfOperationMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnHoursOfOperationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnIntegrationAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnIntegrationAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnPhoneNumberMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnPhoneNumberMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnPromptMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnPromptMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnQueueMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnQueueMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnQuickConnectMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnQuickConnectMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnRoutingProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnRoutingProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnSecurityProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnSecurityProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnTaskTemplateMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnTaskTemplateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnTrafficDistributionGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnTrafficDistributionGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnUserMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnUserMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnUserHierarchyGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnUserHierarchyGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnViewMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnViewMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnAgentStatusMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnAgentStatusMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnDataTableMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnDataTableMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnEmailAddressMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnEmailAddressMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnMetricMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnMetricMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnNotificationMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnNotificationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnTestCaseMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnTestCaseMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connect_CfnWorkspaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_connect_CfnWorkspaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connectcampaigns_CfnCampaignMixinProps: function _aws_cdk_cfn_property_mixins_aws_connectcampaigns_CfnCampaignMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_connectcampaignsv2_CfnCampaignMixinProps: function _aws_cdk_cfn_property_mixins_aws_connectcampaignsv2_CfnCampaignMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_controltower_CfnEnabledControlMixinProps: function _aws_cdk_cfn_property_mixins_aws_controltower_CfnEnabledControlMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_controltower_CfnEnabledBaselineMixinProps: function _aws_cdk_cfn_property_mixins_aws_controltower_CfnEnabledBaselineMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_controltower_CfnLandingZoneMixinProps: function _aws_cdk_cfn_property_mixins_aws_controltower_CfnLandingZoneMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_cur_CfnReportDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_cur_CfnReportDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnCalculatedAttributeDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnCalculatedAttributeDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnDomainMixinProps: function _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnDomainMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnEventStreamMixinProps: function _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnEventStreamMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnIntegrationMixinProps: function _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnIntegrationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnObjectTypeMixinProps: function _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnObjectTypeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnDomainObjectTypeMixinProps: function _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnDomainObjectTypeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnEventTriggerMixinProps: function _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnEventTriggerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnRecommenderMixinProps: function _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnRecommenderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnSegmentDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_customerprofiles_CfnSegmentDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_databrew_CfnDatasetMixinProps: function _aws_cdk_cfn_property_mixins_aws_databrew_CfnDatasetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_databrew_CfnJobMixinProps: function _aws_cdk_cfn_property_mixins_aws_databrew_CfnJobMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_databrew_CfnProjectMixinProps: function _aws_cdk_cfn_property_mixins_aws_databrew_CfnProjectMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_databrew_CfnRecipeMixinProps: function _aws_cdk_cfn_property_mixins_aws_databrew_CfnRecipeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_databrew_CfnRulesetMixinProps: function _aws_cdk_cfn_property_mixins_aws_databrew_CfnRulesetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_databrew_CfnScheduleMixinProps: function _aws_cdk_cfn_property_mixins_aws_databrew_CfnScheduleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dataexchange_CfnDataSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_dataexchange_CfnDataSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dataexchange_CfnEventActionMixinProps: function _aws_cdk_cfn_property_mixins_aws_dataexchange_CfnEventActionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datapipeline_CfnPipelineMixinProps: function _aws_cdk_cfn_property_mixins_aws_datapipeline_CfnPipelineMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.pipelineTags != null)
                for (const o of p.pipelineTags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_datapipeline_CfnPipelinePropsMixin_PipelineTagProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datasync_CfnAgentMixinProps: function _aws_cdk_cfn_property_mixins_aws_datasync_CfnAgentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationAzureBlobMixinProps: function _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationAzureBlobMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationEFSMixinProps: function _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationEFSMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationFSxLustreMixinProps: function _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationFSxLustreMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationFSxONTAPMixinProps: function _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationFSxONTAPMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationFSxOpenZFSMixinProps: function _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationFSxOpenZFSMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationFSxWindowsMixinProps: function _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationFSxWindowsMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationHDFSMixinProps: function _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationHDFSMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationNFSMixinProps: function _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationNFSMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationObjectStorageMixinProps: function _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationObjectStorageMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationS3MixinProps: function _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationS3MixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationSMBMixinProps: function _aws_cdk_cfn_property_mixins_aws_datasync_CfnLocationSMBMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datasync_CfnTaskMixinProps: function _aws_cdk_cfn_property_mixins_aws_datasync_CfnTaskMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_datazone_CfnDomainMixinProps: function _aws_cdk_cfn_property_mixins_aws_datazone_CfnDomainMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_deadline_CfnBudgetMixinProps: function _aws_cdk_cfn_property_mixins_aws_deadline_CfnBudgetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_deadline_CfnFarmMixinProps: function _aws_cdk_cfn_property_mixins_aws_deadline_CfnFarmMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_deadline_CfnFleetMixinProps: function _aws_cdk_cfn_property_mixins_aws_deadline_CfnFleetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_deadline_CfnLicenseEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_deadline_CfnLicenseEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_deadline_CfnMonitorMixinProps: function _aws_cdk_cfn_property_mixins_aws_deadline_CfnMonitorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_deadline_CfnQueueMixinProps: function _aws_cdk_cfn_property_mixins_aws_deadline_CfnQueueMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_deadline_CfnWorkerMixinProps: function _aws_cdk_cfn_property_mixins_aws_deadline_CfnWorkerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_deadline_CfnWorkerPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_detective_CfnGraphMixinProps: function _aws_cdk_cfn_property_mixins_aws_detective_CfnGraphMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_devicefarm_CfnDevicePoolMixinProps: function _aws_cdk_cfn_property_mixins_aws_devicefarm_CfnDevicePoolMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_devicefarm_CfnInstanceProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_devicefarm_CfnInstanceProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_devicefarm_CfnNetworkProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_devicefarm_CfnNetworkProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_devicefarm_CfnProjectMixinProps: function _aws_cdk_cfn_property_mixins_aws_devicefarm_CfnProjectMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_devicefarm_CfnTestGridProjectMixinProps: function _aws_cdk_cfn_property_mixins_aws_devicefarm_CfnTestGridProjectMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_devicefarm_CfnVPCEConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_devicefarm_CfnVPCEConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_devopsagent_CfnAgentSpaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_devopsagent_CfnAgentSpaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_devopsagent_CfnAssociationPropsMixin_SourceAwsConfigurationProperty: function _aws_cdk_cfn_property_mixins_aws_devopsagent_CfnAssociationPropsMixin_SourceAwsConfigurationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_devopsagent_CfnAssociationPropsMixin_KeyValuePairProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_devopsagent_CfnAssociationPropsMixin_AWSConfigurationProperty: function _aws_cdk_cfn_property_mixins_aws_devopsagent_CfnAssociationPropsMixin_AWSConfigurationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_devopsagent_CfnAssociationPropsMixin_KeyValuePairProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_devopsagent_CfnPrivateConnectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_devopsagent_CfnPrivateConnectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_devopsagent_CfnServiceMixinProps: function _aws_cdk_cfn_property_mixins_aws_devopsagent_CfnServiceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_devopsguru_CfnResourceCollectionPropsMixin_ResourceCollectionFilterProperty: function _aws_cdk_cfn_property_mixins_aws_devopsguru_CfnResourceCollectionPropsMixin_ResourceCollectionFilterProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_devopsguru_CfnResourceCollectionPropsMixin_TagCollectionProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_directconnect_CfnConnectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_directconnect_CfnConnectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_directconnect_CfnDirectConnectGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_directconnect_CfnDirectConnectGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_directconnect_CfnLagMixinProps: function _aws_cdk_cfn_property_mixins_aws_directconnect_CfnLagMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_directconnect_CfnPrivateVirtualInterfaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_directconnect_CfnPrivateVirtualInterfaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_directconnect_CfnPublicVirtualInterfaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_directconnect_CfnPublicVirtualInterfaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_directconnect_CfnTransitVirtualInterfaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_directconnect_CfnTransitVirtualInterfaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_directoryservice_CfnSimpleADMixinProps: function _aws_cdk_cfn_property_mixins_aws_directoryservice_CfnSimpleADMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dlm_CfnLifecyclePolicyMixinProps: function _aws_cdk_cfn_property_mixins_aws_dlm_CfnLifecyclePolicyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dms_CfnEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_dms_CfnEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dms_CfnEventSubscriptionMixinProps: function _aws_cdk_cfn_property_mixins_aws_dms_CfnEventSubscriptionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dms_CfnReplicationConfigMixinProps: function _aws_cdk_cfn_property_mixins_aws_dms_CfnReplicationConfigMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dms_CfnReplicationInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_dms_CfnReplicationInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dms_CfnReplicationSubnetGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_dms_CfnReplicationSubnetGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dms_CfnReplicationTaskMixinProps: function _aws_cdk_cfn_property_mixins_aws_dms_CfnReplicationTaskMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dms_CfnDataMigrationMixinProps: function _aws_cdk_cfn_property_mixins_aws_dms_CfnDataMigrationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dms_CfnDataProviderMixinProps: function _aws_cdk_cfn_property_mixins_aws_dms_CfnDataProviderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dms_CfnInstanceProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_dms_CfnInstanceProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dms_CfnMigrationProjectMixinProps: function _aws_cdk_cfn_property_mixins_aws_dms_CfnMigrationProjectMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("migrationProjectCreationTime" in p)
                print("@aws-cdk/cfn-property-mixins.aws_dms.CfnMigrationProjectMixinProps#migrationProjectCreationTime", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_docdb_CfnDBClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_docdb_CfnDBClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_docdb_CfnDBClusterParameterGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_docdb_CfnDBClusterParameterGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_docdb_CfnDBInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_docdb_CfnDBInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_docdb_CfnDBSubnetGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_docdb_CfnDBSubnetGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_docdb_CfnGlobalClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_docdb_CfnGlobalClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_docdbelastic_CfnClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_docdbelastic_CfnClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_drs_CfnSourceNetworkMixinProps: function _aws_cdk_cfn_property_mixins_aws_drs_CfnSourceNetworkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dsql_CfnClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_dsql_CfnClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dynamodb_CfnGlobalTablePropsMixin_ReplicaSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_dynamodb_CfnGlobalTablePropsMixin_ReplicaSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dynamodb_CfnGlobalTablePropsMixin_ReplicaStreamSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_dynamodb_CfnGlobalTablePropsMixin_ReplicaStreamSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dynamodb_CfnTablePropsMixin_StreamSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_dynamodb_CfnTablePropsMixin_StreamSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_dynamodb_CfnTableMixinProps: function _aws_cdk_cfn_property_mixins_aws_dynamodb_CfnTableMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnCapacityReservationPropsMixin_TagSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnCapacityReservationPropsMixin_TagSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnCapacityReservationFleetPropsMixin_TagSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnCapacityReservationFleetPropsMixin_TagSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnCarrierGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnCarrierGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnClientVpnEndpointPropsMixin_TagSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnClientVpnEndpointPropsMixin_TagSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnCustomerGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnCustomerGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnDHCPOptionsMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnDHCPOptionsMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnEC2FleetPropsMixin_TagSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnEC2FleetPropsMixin_TagSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnEIPMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnEIPMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnEIPAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnEIPAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("eip" in p)
                print("@aws-cdk/cfn-property-mixins.aws_ec2.CfnEIPAssociationMixinProps#eip", "this property has been deprecated");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnEgressOnlyInternetGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnEgressOnlyInternetGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnFlowLogMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnFlowLogMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnHostMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnHostMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMPoolMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMPoolMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMResourceDiscoveryMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMResourceDiscoveryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMResourceDiscoveryAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMResourceDiscoveryAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMScopeMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMScopeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnInstanceConnectEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnInstanceConnectEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnInternetGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnInternetGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnKeyPairMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnKeyPairMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnLaunchTemplatePropsMixin_TagSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnLaunchTemplatePropsMixin_TagSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnLaunchTemplatePropsMixin_LaunchTemplateTagSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnLaunchTemplatePropsMixin_LaunchTemplateTagSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnLocalGatewayRouteTableMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnLocalGatewayRouteTableMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnLocalGatewayRouteTableVPCAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnLocalGatewayRouteTableVPCAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnLocalGatewayRouteTableVirtualInterfaceGroupAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnLocalGatewayRouteTableVirtualInterfaceGroupAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnNatGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnNatGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnNetworkAclMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnNetworkAclMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnNetworkInsightsAccessScopeMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnNetworkInsightsAccessScopeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnNetworkInsightsAccessScopeAnalysisMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnNetworkInsightsAccessScopeAnalysisMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnNetworkInsightsAnalysisMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnNetworkInsightsAnalysisMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnNetworkInsightsPathMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnNetworkInsightsPathMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnNetworkInterfaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnNetworkInterfaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnPlacementGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnPlacementGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnPrefixListMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnPrefixListMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnRouteTableMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnRouteTableMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnSecurityGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnSecurityGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnSpotFleetPropsMixin_SpotFleetTagSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnSpotFleetPropsMixin_SpotFleetTagSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnSpotFleetMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnSpotFleetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnSubnetMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnSubnetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTrafficMirrorFilterMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTrafficMirrorFilterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTrafficMirrorFilterRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTrafficMirrorFilterRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTrafficMirrorSessionMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTrafficMirrorSessionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTrafficMirrorTargetMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTrafficMirrorTargetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayAttachmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayAttachmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayConnectMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayConnectMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayMulticastDomainMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayMulticastDomainMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayPeeringAttachmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayPeeringAttachmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayRouteTableMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayRouteTableMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayVpcAttachmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayVpcAttachmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPCMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPCMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPCEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPCEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPCEndpointServiceMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPCEndpointServiceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPCPeeringConnectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPCPeeringConnectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPNConnectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPNConnectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPNGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPNGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVerifiedAccessEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVerifiedAccessEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVerifiedAccessGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVerifiedAccessGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVerifiedAccessInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVerifiedAccessInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVerifiedAccessTrustProviderMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVerifiedAccessTrustProviderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVolumeMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVolumeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnApplicationStatusCheckMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnApplicationStatusCheckMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnCapacityManagerDataExportMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnCapacityManagerDataExportMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnFpgaImageMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnFpgaImageMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnIpamExternalResourceVerificationTokenMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnIpamExternalResourceVerificationTokenMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMPrefixListResolverMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMPrefixListResolverMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMPrefixListResolverTargetMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnIPAMPrefixListResolverTargetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnLocalGatewayVirtualInterfaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnLocalGatewayVirtualInterfaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnLocalGatewayVirtualInterfaceGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnLocalGatewayVirtualInterfaceGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnRouteServerMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnRouteServerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnRouteServerEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnRouteServerEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnRouteServerPeerMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnRouteServerPeerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayConnectPeerMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayConnectPeerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayMeteringPolicyMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayMeteringPolicyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayPolicyTableMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnTransitGatewayPolicyTableMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPCBlockPublicAccessExclusionMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPCBlockPublicAccessExclusionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPCEncryptionControlMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPCEncryptionControlMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPNConcentratorMixinProps: function _aws_cdk_cfn_property_mixins_aws_ec2_CfnVPNConcentratorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ecr_CfnPublicRepositoryMixinProps: function _aws_cdk_cfn_property_mixins_aws_ecr_CfnPublicRepositoryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ecr_CfnRepositoryMixinProps: function _aws_cdk_cfn_property_mixins_aws_ecr_CfnRepositoryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ecs_CfnCapacityProviderMixinProps: function _aws_cdk_cfn_property_mixins_aws_ecs_CfnCapacityProviderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ecs_CfnClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_ecs_CfnClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ecs_CfnServicePropsMixin_EBSTagSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_ecs_CfnServicePropsMixin_EBSTagSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ecs_CfnServiceMixinProps: function _aws_cdk_cfn_property_mixins_aws_ecs_CfnServiceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ecs_CfnTaskDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_ecs_CfnTaskDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("inferenceAccelerators" in p)
                print("@aws-cdk/cfn-property-mixins.aws_ecs.CfnTaskDefinitionMixinProps#inferenceAccelerators", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ecs_CfnTaskSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_ecs_CfnTaskSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ecs_CfnDaemonMixinProps: function _aws_cdk_cfn_property_mixins_aws_ecs_CfnDaemonMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ecs_CfnDaemonTaskDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_ecs_CfnDaemonTaskDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ecs_CfnExpressGatewayServiceMixinProps: function _aws_cdk_cfn_property_mixins_aws_ecs_CfnExpressGatewayServiceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_efs_CfnAccessPointMixinProps: function _aws_cdk_cfn_property_mixins_aws_efs_CfnAccessPointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.accessPointTags != null)
                for (const o of p.accessPointTags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_efs_CfnAccessPointPropsMixin_AccessPointTagProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_efs_CfnFileSystemMixinProps: function _aws_cdk_cfn_property_mixins_aws_efs_CfnFileSystemMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.fileSystemTags != null)
                for (const o of p.fileSystemTags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_efs_CfnFileSystemPropsMixin_ElasticFileSystemTagProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_eks_CfnAddonMixinProps: function _aws_cdk_cfn_property_mixins_aws_eks_CfnAddonMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_eks_CfnClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_eks_CfnClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_eks_CfnFargateProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_eks_CfnFargateProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_eks_CfnIdentityProviderConfigMixinProps: function _aws_cdk_cfn_property_mixins_aws_eks_CfnIdentityProviderConfigMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_eks_CfnAccessEntryMixinProps: function _aws_cdk_cfn_property_mixins_aws_eks_CfnAccessEntryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_eks_CfnCapabilityMixinProps: function _aws_cdk_cfn_property_mixins_aws_eks_CfnCapabilityMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_eks_CfnPodIdentityAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_eks_CfnPodIdentityAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticache_CfnCacheClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticache_CfnCacheClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("cacheSecurityGroupNames" in p)
                print("@aws-cdk/cfn-property-mixins.aws_elasticache.CfnCacheClusterMixinProps#cacheSecurityGroupNames", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticache_CfnParameterGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticache_CfnParameterGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticache_CfnReplicationGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticache_CfnReplicationGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("cacheSecurityGroupNames" in p)
                print("@aws-cdk/cfn-property-mixins.aws_elasticache.CfnReplicationGroupMixinProps#cacheSecurityGroupNames", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticache_CfnSecurityGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticache_CfnSecurityGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticache_CfnSubnetGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticache_CfnSubnetGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticache_CfnUserMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticache_CfnUserMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticache_CfnUserGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticache_CfnUserGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticache_CfnServerlessCacheMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticache_CfnServerlessCacheMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticache_CfnServerlessCacheSnapshotMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticache_CfnServerlessCacheSnapshotMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticbeanstalk_CfnEnvironmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticbeanstalk_CfnEnvironmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticloadbalancing_CfnLoadBalancerMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticloadbalancing_CfnLoadBalancerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticloadbalancingv2_CfnListenerMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticloadbalancingv2_CfnListenerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticloadbalancingv2_CfnListenerRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticloadbalancingv2_CfnListenerRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticloadbalancingv2_CfnLoadBalancerMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticloadbalancingv2_CfnLoadBalancerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticloadbalancingv2_CfnTargetGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticloadbalancingv2_CfnTargetGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticloadbalancingv2_CfnTrustStoreMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticloadbalancingv2_CfnTrustStoreMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_elasticsearch_CfnDomainMixinProps: function _aws_cdk_cfn_property_mixins_aws_elasticsearch_CfnDomainMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_emr_CfnClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_emr_CfnClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_emr_CfnStudioMixinProps: function _aws_cdk_cfn_property_mixins_aws_emr_CfnStudioMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_emr_CfnWALWorkspaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_emr_CfnWALWorkspaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_emrcontainers_CfnVirtualClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_emrcontainers_CfnVirtualClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_emrcontainers_CfnEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_emrcontainers_CfnEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_emrcontainers_CfnSecurityConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_emrcontainers_CfnSecurityConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_emrserverless_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_emrserverless_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_entityresolution_CfnMatchingWorkflowMixinProps: function _aws_cdk_cfn_property_mixins_aws_entityresolution_CfnMatchingWorkflowMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_entityresolution_CfnSchemaMappingMixinProps: function _aws_cdk_cfn_property_mixins_aws_entityresolution_CfnSchemaMappingMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_entityresolution_CfnIdMappingWorkflowMixinProps: function _aws_cdk_cfn_property_mixins_aws_entityresolution_CfnIdMappingWorkflowMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_entityresolution_CfnIdNamespaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_entityresolution_CfnIdNamespaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_eventschemas_CfnDiscovererMixinProps: function _aws_cdk_cfn_property_mixins_aws_eventschemas_CfnDiscovererMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_eventschemas_CfnDiscovererPropsMixin_TagsEntryProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_eventschemas_CfnRegistryMixinProps: function _aws_cdk_cfn_property_mixins_aws_eventschemas_CfnRegistryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_eventschemas_CfnRegistryPropsMixin_TagsEntryProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_evidently_CfnExperimentMixinProps: function _aws_cdk_cfn_property_mixins_aws_evidently_CfnExperimentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_evidently_CfnFeatureMixinProps: function _aws_cdk_cfn_property_mixins_aws_evidently_CfnFeatureMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_evidently_CfnLaunchMixinProps: function _aws_cdk_cfn_property_mixins_aws_evidently_CfnLaunchMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_evidently_CfnProjectMixinProps: function _aws_cdk_cfn_property_mixins_aws_evidently_CfnProjectMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_evidently_CfnSegmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_evidently_CfnSegmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_evs_CfnEnvironmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_evs_CfnEnvironmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_finspace_CfnEnvironmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_finspace_CfnEnvironmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("dataBundles" in p)
                print("@aws-cdk/cfn-property-mixins.aws_finspace.CfnEnvironmentMixinProps#dataBundles", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_fms_CfnPolicyMixinProps: function _aws_cdk_cfn_property_mixins_aws_fms_CfnPolicyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_fms_CfnPolicyPropsMixin_PolicyTagProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_fms_CfnResourceSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_fms_CfnResourceSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_forecast_CfnDatasetGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_forecast_CfnDatasetGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorPropsMixin_EventTypeProperty: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorPropsMixin_EventTypeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorPropsMixin_EntityTypeProperty: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorPropsMixin_EntityTypeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorPropsMixin_LabelProperty: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorPropsMixin_LabelProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorPropsMixin_EventVariableProperty: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorPropsMixin_EventVariableProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorPropsMixin_RuleProperty: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorPropsMixin_RuleProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorPropsMixin_OutcomeProperty: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorPropsMixin_OutcomeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorMixinProps: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnDetectorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnEntityTypeMixinProps: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnEntityTypeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnEventTypePropsMixin_EntityTypeProperty: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnEventTypePropsMixin_EntityTypeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnEventTypePropsMixin_LabelProperty: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnEventTypePropsMixin_LabelProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnEventTypePropsMixin_EventVariableProperty: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnEventTypePropsMixin_EventVariableProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnEventTypeMixinProps: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnEventTypeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnLabelMixinProps: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnLabelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnListMixinProps: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnListMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnOutcomeMixinProps: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnOutcomeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnVariableMixinProps: function _aws_cdk_cfn_property_mixins_aws_frauddetector_CfnVariableMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_fsx_CfnDataRepositoryAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_fsx_CfnDataRepositoryAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_fsx_CfnFileSystemMixinProps: function _aws_cdk_cfn_property_mixins_aws_fsx_CfnFileSystemMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_fsx_CfnSnapshotMixinProps: function _aws_cdk_cfn_property_mixins_aws_fsx_CfnSnapshotMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_fsx_CfnStorageVirtualMachineMixinProps: function _aws_cdk_cfn_property_mixins_aws_fsx_CfnStorageVirtualMachineMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_fsx_CfnVolumeMixinProps: function _aws_cdk_cfn_property_mixins_aws_fsx_CfnVolumeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_gamelift_CfnAliasMixinProps: function _aws_cdk_cfn_property_mixins_aws_gamelift_CfnAliasMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_gamelift_CfnBuildMixinProps: function _aws_cdk_cfn_property_mixins_aws_gamelift_CfnBuildMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_gamelift_CfnFleetMixinProps: function _aws_cdk_cfn_property_mixins_aws_gamelift_CfnFleetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("desiredEc2Instances" in p)
                print("@aws-cdk/cfn-property-mixins.aws_gamelift.CfnFleetMixinProps#desiredEc2Instances", "this property has been deprecated");
            if ("logPaths" in p)
                print("@aws-cdk/cfn-property-mixins.aws_gamelift.CfnFleetMixinProps#logPaths", "this property has been deprecated");
            if ("maxSize" in p)
                print("@aws-cdk/cfn-property-mixins.aws_gamelift.CfnFleetMixinProps#maxSize", "this property has been deprecated");
            if ("minSize" in p)
                print("@aws-cdk/cfn-property-mixins.aws_gamelift.CfnFleetMixinProps#minSize", "this property has been deprecated");
            if ("serverLaunchParameters" in p)
                print("@aws-cdk/cfn-property-mixins.aws_gamelift.CfnFleetMixinProps#serverLaunchParameters", "this property has been deprecated");
            if ("serverLaunchPath" in p)
                print("@aws-cdk/cfn-property-mixins.aws_gamelift.CfnFleetMixinProps#serverLaunchPath", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_gamelift_CfnGameServerGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_gamelift_CfnGameServerGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_gamelift_CfnGameSessionQueueMixinProps: function _aws_cdk_cfn_property_mixins_aws_gamelift_CfnGameSessionQueueMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_gamelift_CfnLocationMixinProps: function _aws_cdk_cfn_property_mixins_aws_gamelift_CfnLocationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_gamelift_CfnMatchmakingConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_gamelift_CfnMatchmakingConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_gamelift_CfnMatchmakingRuleSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_gamelift_CfnMatchmakingRuleSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_gamelift_CfnScriptMixinProps: function _aws_cdk_cfn_property_mixins_aws_gamelift_CfnScriptMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_gamelift_CfnContainerFleetMixinProps: function _aws_cdk_cfn_property_mixins_aws_gamelift_CfnContainerFleetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_gamelift_CfnContainerGroupDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_gamelift_CfnContainerGroupDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_globalaccelerator_CfnAcceleratorMixinProps: function _aws_cdk_cfn_property_mixins_aws_globalaccelerator_CfnAcceleratorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_globalaccelerator_CfnCrossAccountAttachmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_globalaccelerator_CfnCrossAccountAttachmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_glue_CfnRegistryMixinProps: function _aws_cdk_cfn_property_mixins_aws_glue_CfnRegistryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_glue_CfnSchemaMixinProps: function _aws_cdk_cfn_property_mixins_aws_glue_CfnSchemaMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_glue_CfnBlueprintMixinProps: function _aws_cdk_cfn_property_mixins_aws_glue_CfnBlueprintMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_glue_CfnCatalogMixinProps: function _aws_cdk_cfn_property_mixins_aws_glue_CfnCatalogMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_glue_CfnIntegrationMixinProps: function _aws_cdk_cfn_property_mixins_aws_glue_CfnIntegrationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_glue_CfnIntegrationResourcePropertyMixinProps: function _aws_cdk_cfn_property_mixins_aws_glue_CfnIntegrationResourcePropertyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_glue_CfnSessionMixinProps: function _aws_cdk_cfn_property_mixins_aws_glue_CfnSessionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_glue_CfnUsageProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_glue_CfnUsageProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_grafana_CfnWorkspaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_grafana_CfnWorkspaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_grafana_CfnWorkspacePropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_groundstation_CfnConfigMixinProps: function _aws_cdk_cfn_property_mixins_aws_groundstation_CfnConfigMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_groundstation_CfnDataflowEndpointGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_groundstation_CfnDataflowEndpointGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_groundstation_CfnMissionProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_groundstation_CfnMissionProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_groundstation_CfnDataflowEndpointGroupV2MixinProps: function _aws_cdk_cfn_property_mixins_aws_groundstation_CfnDataflowEndpointGroupV2MixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_guardduty_CfnDetectorMixinProps: function _aws_cdk_cfn_property_mixins_aws_guardduty_CfnDetectorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_guardduty_CfnDetectorPropsMixin_TagItemProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_guardduty_CfnFilterMixinProps: function _aws_cdk_cfn_property_mixins_aws_guardduty_CfnFilterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_guardduty_CfnIPSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_guardduty_CfnIPSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_guardduty_CfnThreatIntelSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_guardduty_CfnThreatIntelSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_guardduty_CfnMalwareProtectionPlanMixinProps: function _aws_cdk_cfn_property_mixins_aws_guardduty_CfnMalwareProtectionPlanMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_guardduty_CfnMalwareProtectionPlanPropsMixin_TagItemProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_guardduty_CfnPublishingDestinationMixinProps: function _aws_cdk_cfn_property_mixins_aws_guardduty_CfnPublishingDestinationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_guardduty_CfnPublishingDestinationPropsMixin_TagItemProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_guardduty_CfnThreatEntitySetMixinProps: function _aws_cdk_cfn_property_mixins_aws_guardduty_CfnThreatEntitySetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_guardduty_CfnThreatEntitySetPropsMixin_TagItemProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_guardduty_CfnTrustedEntitySetMixinProps: function _aws_cdk_cfn_property_mixins_aws_guardduty_CfnTrustedEntitySetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_guardduty_CfnTrustedEntitySetPropsMixin_TagItemProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_healthlake_CfnFHIRDatastoreMixinProps: function _aws_cdk_cfn_property_mixins_aws_healthlake_CfnFHIRDatastoreMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_healthlake_CfnDataTransformationProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_healthlake_CfnDataTransformationProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iam_CfnOIDCProviderMixinProps: function _aws_cdk_cfn_property_mixins_aws_iam_CfnOIDCProviderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iam_CfnRoleMixinProps: function _aws_cdk_cfn_property_mixins_aws_iam_CfnRoleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iam_CfnSAMLProviderMixinProps: function _aws_cdk_cfn_property_mixins_aws_iam_CfnSAMLProviderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iam_CfnServerCertificateMixinProps: function _aws_cdk_cfn_property_mixins_aws_iam_CfnServerCertificateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iam_CfnUserMixinProps: function _aws_cdk_cfn_property_mixins_aws_iam_CfnUserMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iam_CfnVirtualMFADeviceMixinProps: function _aws_cdk_cfn_property_mixins_aws_iam_CfnVirtualMFADeviceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_inspectorv2_CfnConnectorMixinProps: function _aws_cdk_cfn_property_mixins_aws_inspectorv2_CfnConnectorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_interconnect_CfnConnectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_interconnect_CfnConnectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("remoteOwnerAccount" in p)
                print("@aws-cdk/cfn-property-mixins.aws_interconnect.CfnConnectionMixinProps#remoteOwnerAccount", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_internetmonitor_CfnMonitorMixinProps: function _aws_cdk_cfn_property_mixins_aws_internetmonitor_CfnMonitorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_invoicing_CfnInvoiceUnitMixinProps: function _aws_cdk_cfn_property_mixins_aws_invoicing_CfnInvoiceUnitMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.resourceTags != null)
                for (const o of p.resourceTags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_invoicing_CfnInvoiceUnitPropsMixin_ResourceTagProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_invoicing_CfnProcurementPortalPreferenceMixinProps: function _aws_cdk_cfn_property_mixins_aws_invoicing_CfnProcurementPortalPreferenceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnAuthorizerMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnAuthorizerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnBillingGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnBillingGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnCACertificateMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnCACertificateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnCustomMetricMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnCustomMetricMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnDimensionMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnDimensionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnDomainConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnDomainConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnFleetMetricMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnFleetMetricMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnJobTemplateMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnJobTemplateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnMitigationActionMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnMitigationActionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnPolicyMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnPolicyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnProvisioningTemplateMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnProvisioningTemplateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnRoleAliasMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnRoleAliasMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnScheduledAuditMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnScheduledAuditMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnSecurityProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnSecurityProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnSoftwarePackageMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnSoftwarePackageMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnSoftwarePackageVersionMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnSoftwarePackageVersionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnThingGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnThingGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnThingTypeMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnThingTypeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnTopicRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnTopicRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnCertificateProviderMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnCertificateProviderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnCommandMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnCommandMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnJobMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnJobMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iot_CfnStreamMixinProps: function _aws_cdk_cfn_property_mixins_aws_iot_CfnStreamMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotanalytics_CfnChannelMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotanalytics_CfnChannelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotanalytics_CfnDatasetMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotanalytics_CfnDatasetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotanalytics_CfnDatastoreMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotanalytics_CfnDatastoreMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotanalytics_CfnPipelineMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotanalytics_CfnPipelineMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotcoredeviceadvisor_CfnSuiteDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotcoredeviceadvisor_CfnSuiteDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotevents_CfnAlarmModelMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotevents_CfnAlarmModelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotevents_CfnDetectorModelMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotevents_CfnDetectorModelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotevents_CfnInputMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotevents_CfnInputMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotfleethub_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotfleethub_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnCampaignMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnCampaignMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnDecoderManifestMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnDecoderManifestMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnFleetMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnFleetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnModelManifestMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnModelManifestMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnSignalCatalogMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnSignalCatalogMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnVehicleMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnVehicleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnStateTemplateMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotfleetwise_CfnStateTemplateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotsecuretunneling_CfnTunnelMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotsecuretunneling_CfnTunnelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnAssetMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnAssetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnAssetModelMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnAssetModelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnDashboardMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnDashboardMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnPortalMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnPortalMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnProjectMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnProjectMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnComputationModelMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnComputationModelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnDatasetMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnDatasetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnPipelineMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnPipelineMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnTaskMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnTaskMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnWorkspaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotsitewise_CfnWorkspaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnDestinationMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnDestinationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnDeviceProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnDeviceProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnFuotaTaskMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnFuotaTaskMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnMulticastGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnMulticastGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnNetworkAnalyzerConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnNetworkAnalyzerConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnPartnerAccountMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnPartnerAccountMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnServiceProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnServiceProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnTaskDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnTaskDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnWirelessDeviceMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnWirelessDeviceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnWirelessDeviceImportTaskMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnWirelessDeviceImportTaskMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnWirelessGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_iotwireless_CfnWirelessGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ivs_CfnChannelMixinProps: function _aws_cdk_cfn_property_mixins_aws_ivs_CfnChannelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ivs_CfnPlaybackKeyPairMixinProps: function _aws_cdk_cfn_property_mixins_aws_ivs_CfnPlaybackKeyPairMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ivs_CfnRecordingConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_ivs_CfnRecordingConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ivs_CfnStreamKeyMixinProps: function _aws_cdk_cfn_property_mixins_aws_ivs_CfnStreamKeyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ivs_CfnEncoderConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_ivs_CfnEncoderConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ivs_CfnIngestConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_ivs_CfnIngestConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ivs_CfnPlaybackRestrictionPolicyMixinProps: function _aws_cdk_cfn_property_mixins_aws_ivs_CfnPlaybackRestrictionPolicyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ivs_CfnPublicKeyMixinProps: function _aws_cdk_cfn_property_mixins_aws_ivs_CfnPublicKeyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ivs_CfnStageMixinProps: function _aws_cdk_cfn_property_mixins_aws_ivs_CfnStageMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ivs_CfnStorageConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_ivs_CfnStorageConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ivschat_CfnLoggingConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_ivschat_CfnLoggingConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ivschat_CfnRoomMixinProps: function _aws_cdk_cfn_property_mixins_aws_ivschat_CfnRoomMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kafkaconnect_CfnConnectorMixinProps: function _aws_cdk_cfn_property_mixins_aws_kafkaconnect_CfnConnectorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kafkaconnect_CfnCustomPluginMixinProps: function _aws_cdk_cfn_property_mixins_aws_kafkaconnect_CfnCustomPluginMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kafkaconnect_CfnWorkerConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_kafkaconnect_CfnWorkerConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kendra_CfnDataSourceMixinProps: function _aws_cdk_cfn_property_mixins_aws_kendra_CfnDataSourceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kendra_CfnFaqMixinProps: function _aws_cdk_cfn_property_mixins_aws_kendra_CfnFaqMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kendra_CfnIndexMixinProps: function _aws_cdk_cfn_property_mixins_aws_kendra_CfnIndexMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kendra_CfnQuerySuggestionsBlockListMixinProps: function _aws_cdk_cfn_property_mixins_aws_kendra_CfnQuerySuggestionsBlockListMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kendra_CfnThesaurusMixinProps: function _aws_cdk_cfn_property_mixins_aws_kendra_CfnThesaurusMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kendraranking_CfnExecutionPlanMixinProps: function _aws_cdk_cfn_property_mixins_aws_kendraranking_CfnExecutionPlanMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kinesis_CfnStreamMixinProps: function _aws_cdk_cfn_property_mixins_aws_kinesis_CfnStreamMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kinesis_CfnStreamConsumerMixinProps: function _aws_cdk_cfn_property_mixins_aws_kinesis_CfnStreamConsumerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kinesisanalyticsv2_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_kinesisanalyticsv2_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kinesisfirehose_CfnDeliveryStreamMixinProps: function _aws_cdk_cfn_property_mixins_aws_kinesisfirehose_CfnDeliveryStreamMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kinesisvideo_CfnSignalingChannelMixinProps: function _aws_cdk_cfn_property_mixins_aws_kinesisvideo_CfnSignalingChannelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kinesisvideo_CfnStreamMixinProps: function _aws_cdk_cfn_property_mixins_aws_kinesisvideo_CfnStreamMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kms_CfnKeyMixinProps: function _aws_cdk_cfn_property_mixins_aws_kms_CfnKeyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_kms_CfnReplicaKeyMixinProps: function _aws_cdk_cfn_property_mixins_aws_kms_CfnReplicaKeyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lambda_CfnCodeSigningConfigMixinProps: function _aws_cdk_cfn_property_mixins_aws_lambda_CfnCodeSigningConfigMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lambda_CfnEventSourceMappingMixinProps: function _aws_cdk_cfn_property_mixins_aws_lambda_CfnEventSourceMappingMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lambda_CfnFunctionMixinProps: function _aws_cdk_cfn_property_mixins_aws_lambda_CfnFunctionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lambda_CfnCapacityProviderMixinProps: function _aws_cdk_cfn_property_mixins_aws_lambda_CfnCapacityProviderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lambda_CfnMicrovmImageMixinProps: function _aws_cdk_cfn_property_mixins_aws_lambda_CfnMicrovmImageMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lambda_CfnNetworkConnectorMixinProps: function _aws_cdk_cfn_property_mixins_aws_lambda_CfnNetworkConnectorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_launchwizard_CfnDeploymentMixinProps: function _aws_cdk_cfn_property_mixins_aws_launchwizard_CfnDeploymentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lex_CfnBotMixinProps: function _aws_cdk_cfn_property_mixins_aws_lex_CfnBotMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.botTags != null)
                for (const o of p.botTags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lex_CfnBotAliasMixinProps: function _aws_cdk_cfn_property_mixins_aws_lex_CfnBotAliasMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.botAliasTags != null)
                for (const o of p.botAliasTags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_licensemanager_CfnGrantMixinProps: function _aws_cdk_cfn_property_mixins_aws_licensemanager_CfnGrantMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_licensemanager_CfnLicenseMixinProps: function _aws_cdk_cfn_property_mixins_aws_licensemanager_CfnLicenseMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_licensemanager_CfnLicenseAssetRuleSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_licensemanager_CfnLicenseAssetRuleSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lightsail_CfnBucketMixinProps: function _aws_cdk_cfn_property_mixins_aws_lightsail_CfnBucketMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lightsail_CfnCertificateMixinProps: function _aws_cdk_cfn_property_mixins_aws_lightsail_CfnCertificateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lightsail_CfnContainerMixinProps: function _aws_cdk_cfn_property_mixins_aws_lightsail_CfnContainerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lightsail_CfnDatabaseMixinProps: function _aws_cdk_cfn_property_mixins_aws_lightsail_CfnDatabaseMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lightsail_CfnDiskMixinProps: function _aws_cdk_cfn_property_mixins_aws_lightsail_CfnDiskMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lightsail_CfnDistributionMixinProps: function _aws_cdk_cfn_property_mixins_aws_lightsail_CfnDistributionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lightsail_CfnInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_lightsail_CfnInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lightsail_CfnLoadBalancerMixinProps: function _aws_cdk_cfn_property_mixins_aws_lightsail_CfnLoadBalancerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lightsail_CfnDatabaseSnapshotMixinProps: function _aws_cdk_cfn_property_mixins_aws_lightsail_CfnDatabaseSnapshotMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lightsail_CfnDiskSnapshotMixinProps: function _aws_cdk_cfn_property_mixins_aws_lightsail_CfnDiskSnapshotMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lightsail_CfnDomainMixinProps: function _aws_cdk_cfn_property_mixins_aws_lightsail_CfnDomainMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lightsail_CfnInstanceSnapshotMixinProps: function _aws_cdk_cfn_property_mixins_aws_lightsail_CfnInstanceSnapshotMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_location_CfnGeofenceCollectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_location_CfnGeofenceCollectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("pricingPlan" in p)
                print("@aws-cdk/cfn-property-mixins.aws_location.CfnGeofenceCollectionMixinProps#pricingPlan", "this property has been deprecated");
            if ("pricingPlanDataSource" in p)
                print("@aws-cdk/cfn-property-mixins.aws_location.CfnGeofenceCollectionMixinProps#pricingPlanDataSource", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_location_CfnMapMixinProps: function _aws_cdk_cfn_property_mixins_aws_location_CfnMapMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_location_CfnPlaceIndexMixinProps: function _aws_cdk_cfn_property_mixins_aws_location_CfnPlaceIndexMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_location_CfnRouteCalculatorMixinProps: function _aws_cdk_cfn_property_mixins_aws_location_CfnRouteCalculatorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_location_CfnTrackerMixinProps: function _aws_cdk_cfn_property_mixins_aws_location_CfnTrackerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("pricingPlan" in p)
                print("@aws-cdk/cfn-property-mixins.aws_location.CfnTrackerMixinProps#pricingPlan", "this property has been deprecated");
            if ("pricingPlanDataSource" in p)
                print("@aws-cdk/cfn-property-mixins.aws_location.CfnTrackerMixinProps#pricingPlanDataSource", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_location_CfnAPIKeyMixinProps: function _aws_cdk_cfn_property_mixins_aws_location_CfnAPIKeyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_logs_CfnDestinationMixinProps: function _aws_cdk_cfn_property_mixins_aws_logs_CfnDestinationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_logs_CfnLogGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_logs_CfnLogGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_logs_CfnDeliveryMixinProps: function _aws_cdk_cfn_property_mixins_aws_logs_CfnDeliveryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_logs_CfnDeliveryDestinationMixinProps: function _aws_cdk_cfn_property_mixins_aws_logs_CfnDeliveryDestinationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_logs_CfnDeliverySourceMixinProps: function _aws_cdk_cfn_property_mixins_aws_logs_CfnDeliverySourceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_logs_CfnScheduledQueryMixinProps: function _aws_cdk_cfn_property_mixins_aws_logs_CfnScheduledQueryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_logs_CfnScheduledQueryPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_lookoutequipment_CfnInferenceSchedulerMixinProps: function _aws_cdk_cfn_property_mixins_aws_lookoutequipment_CfnInferenceSchedulerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_macie_CfnAllowListMixinProps: function _aws_cdk_cfn_property_mixins_aws_macie_CfnAllowListMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_macie_CfnCustomDataIdentifierMixinProps: function _aws_cdk_cfn_property_mixins_aws_macie_CfnCustomDataIdentifierMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_macie_CfnFindingsFilterMixinProps: function _aws_cdk_cfn_property_mixins_aws_macie_CfnFindingsFilterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_managedblockchain_CfnAccessorMixinProps: function _aws_cdk_cfn_property_mixins_aws_managedblockchain_CfnAccessorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowPropsMixin_SourceProperty: function _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowPropsMixin_SourceProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowPropsMixin_VpcInterfaceProperty: function _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowPropsMixin_VpcInterfaceProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowPropsMixin_MediaStreamProperty: function _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowPropsMixin_MediaStreamProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowEntitlementMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowEntitlementMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowOutputMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowOutputMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowSourceMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowSourceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("entitlementArn" in p)
                print("@aws-cdk/cfn-property-mixins.aws_mediaconnect.CfnFlowSourceMixinProps#entitlementArn", "this property has been deprecated");
            if ("senderControlPort" in p)
                print("@aws-cdk/cfn-property-mixins.aws_mediaconnect.CfnFlowSourceMixinProps#senderControlPort", "this property has been deprecated");
            if ("senderIpAddress" in p)
                print("@aws-cdk/cfn-property-mixins.aws_mediaconnect.CfnFlowSourceMixinProps#senderIpAddress", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowVpcInterfaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnFlowVpcInterfaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnRouterInputMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnRouterInputMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnRouterNetworkInterfaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnRouterNetworkInterfaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnRouterOutputMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediaconnect_CfnRouterOutputMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_medialive_CfnChannelPlacementGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_medialive_CfnChannelPlacementGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_medialive_CfnClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_medialive_CfnClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_medialive_CfnMultiplexMixinProps: function _aws_cdk_cfn_property_mixins_aws_medialive_CfnMultiplexMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_medialive_CfnNetworkMixinProps: function _aws_cdk_cfn_property_mixins_aws_medialive_CfnNetworkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_medialive_CfnNodeMixinProps: function _aws_cdk_cfn_property_mixins_aws_medialive_CfnNodeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_medialive_CfnSdiSourceMixinProps: function _aws_cdk_cfn_property_mixins_aws_medialive_CfnSdiSourceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediapackage_CfnAssetMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediapackage_CfnAssetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediapackage_CfnChannelMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediapackage_CfnChannelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediapackage_CfnOriginEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediapackage_CfnOriginEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediapackage_CfnPackagingConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediapackage_CfnPackagingConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediapackage_CfnPackagingGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediapackage_CfnPackagingGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediapackagev2_CfnChannelMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediapackagev2_CfnChannelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediapackagev2_CfnChannelGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediapackagev2_CfnChannelGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediapackagev2_CfnOriginEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediapackagev2_CfnOriginEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediastore_CfnContainerMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediastore_CfnContainerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnChannelMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnChannelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnLiveSourceMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnLiveSourceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnPlaybackConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnPlaybackConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnSourceLocationMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnSourceLocationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnVodSourceMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnVodSourceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnFunctionMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnFunctionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnPrefetchScheduleMixinProps: function _aws_cdk_cfn_property_mixins_aws_mediatailor_CfnPrefetchScheduleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_memorydb_CfnACLMixinProps: function _aws_cdk_cfn_property_mixins_aws_memorydb_CfnACLMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_memorydb_CfnClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_memorydb_CfnClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_memorydb_CfnParameterGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_memorydb_CfnParameterGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_memorydb_CfnSubnetGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_memorydb_CfnSubnetGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_memorydb_CfnUserMixinProps: function _aws_cdk_cfn_property_mixins_aws_memorydb_CfnUserMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_memorydb_CfnMultiRegionClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_memorydb_CfnMultiRegionClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mgn_CfnNetworkMigrationDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_mgn_CfnNetworkMigrationDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mpa_CfnApprovalTeamMixinProps: function _aws_cdk_cfn_property_mixins_aws_mpa_CfnApprovalTeamMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_mpa_CfnIdentitySourceMixinProps: function _aws_cdk_cfn_property_mixins_aws_mpa_CfnIdentitySourceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_msk_CfnReplicatorMixinProps: function _aws_cdk_cfn_property_mixins_aws_msk_CfnReplicatorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_neptune_CfnDBClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_neptune_CfnDBClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_neptune_CfnDBClusterParameterGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_neptune_CfnDBClusterParameterGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_neptune_CfnDBInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_neptune_CfnDBInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("dbSnapshotIdentifier" in p)
                print("@aws-cdk/cfn-property-mixins.aws_neptune.CfnDBInstanceMixinProps#dbSnapshotIdentifier", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_neptune_CfnDBParameterGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_neptune_CfnDBParameterGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_neptune_CfnDBSubnetGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_neptune_CfnDBSubnetGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_neptune_CfnEventSubscriptionMixinProps: function _aws_cdk_cfn_property_mixins_aws_neptune_CfnEventSubscriptionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_neptune_CfnGlobalClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_neptune_CfnGlobalClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_neptunegraph_CfnGraphMixinProps: function _aws_cdk_cfn_property_mixins_aws_neptunegraph_CfnGraphMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_neptunegraph_CfnGraphSnapshotMixinProps: function _aws_cdk_cfn_property_mixins_aws_neptunegraph_CfnGraphSnapshotMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkfirewall_CfnFirewallMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkfirewall_CfnFirewallMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkfirewall_CfnFirewallPolicyMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkfirewall_CfnFirewallPolicyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkfirewall_CfnRuleGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkfirewall_CfnRuleGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkfirewall_CfnTLSInspectionConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkfirewall_CfnTLSInspectionConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkfirewall_CfnVpcEndpointAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkfirewall_CfnVpcEndpointAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkflowmonitor_CfnMonitorMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkflowmonitor_CfnMonitorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnConnectAttachmentPropsMixin_ProposedSegmentChangeProperty: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnConnectAttachmentPropsMixin_ProposedSegmentChangeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnConnectAttachmentPropsMixin_ProposedNetworkFunctionGroupChangeProperty: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnConnectAttachmentPropsMixin_ProposedNetworkFunctionGroupChangeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnConnectAttachmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnConnectAttachmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnConnectPeerMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnConnectPeerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnCoreNetworkMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnCoreNetworkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnDeviceMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnDeviceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnGlobalNetworkMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnGlobalNetworkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnLinkMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnLinkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnSiteMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnSiteMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnSiteToSiteVpnAttachmentPropsMixin_ProposedSegmentChangeProperty: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnSiteToSiteVpnAttachmentPropsMixin_ProposedSegmentChangeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnSiteToSiteVpnAttachmentPropsMixin_ProposedNetworkFunctionGroupChangeProperty: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnSiteToSiteVpnAttachmentPropsMixin_ProposedNetworkFunctionGroupChangeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnSiteToSiteVpnAttachmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnSiteToSiteVpnAttachmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnTransitGatewayPeeringMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnTransitGatewayPeeringMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnTransitGatewayRouteTableAttachmentPropsMixin_ProposedSegmentChangeProperty: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnTransitGatewayRouteTableAttachmentPropsMixin_ProposedSegmentChangeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnTransitGatewayRouteTableAttachmentPropsMixin_ProposedNetworkFunctionGroupChangeProperty: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnTransitGatewayRouteTableAttachmentPropsMixin_ProposedNetworkFunctionGroupChangeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnTransitGatewayRouteTableAttachmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnTransitGatewayRouteTableAttachmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnVpcAttachmentPropsMixin_ProposedSegmentChangeProperty: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnVpcAttachmentPropsMixin_ProposedSegmentChangeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnVpcAttachmentPropsMixin_ProposedNetworkFunctionGroupChangeProperty: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnVpcAttachmentPropsMixin_ProposedNetworkFunctionGroupChangeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnVpcAttachmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnVpcAttachmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnDirectConnectGatewayAttachmentPropsMixin_ProposedSegmentChangeProperty: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnDirectConnectGatewayAttachmentPropsMixin_ProposedSegmentChangeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnDirectConnectGatewayAttachmentPropsMixin_ProposedNetworkFunctionGroupChangeProperty: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnDirectConnectGatewayAttachmentPropsMixin_ProposedNetworkFunctionGroupChangeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnDirectConnectGatewayAttachmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_networkmanager_CfnDirectConnectGatewayAttachmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_notifications_CfnNotificationConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_notifications_CfnNotificationConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_notificationscontacts_CfnEmailContactMixinProps: function _aws_cdk_cfn_property_mixins_aws_notificationscontacts_CfnEmailContactMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_observabilityadmin_CfnOrganizationCentralizationRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_observabilityadmin_CfnOrganizationCentralizationRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_observabilityadmin_CfnOrganizationTelemetryRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_observabilityadmin_CfnOrganizationTelemetryRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_observabilityadmin_CfnS3TableIntegrationMixinProps: function _aws_cdk_cfn_property_mixins_aws_observabilityadmin_CfnS3TableIntegrationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_observabilityadmin_CfnTelemetryPipelinesPropsMixin_TelemetryPipelineProperty: function _aws_cdk_cfn_property_mixins_aws_observabilityadmin_CfnTelemetryPipelinesPropsMixin_TelemetryPipelineProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_observabilityadmin_CfnTelemetryPipelinesMixinProps: function _aws_cdk_cfn_property_mixins_aws_observabilityadmin_CfnTelemetryPipelinesMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_observabilityadmin_CfnTelemetryRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_observabilityadmin_CfnTelemetryRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_odb_CfnCloudAutonomousVmClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_odb_CfnCloudAutonomousVmClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_odb_CfnCloudExadataInfrastructureMixinProps: function _aws_cdk_cfn_property_mixins_aws_odb_CfnCloudExadataInfrastructureMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_odb_CfnCloudVmClusterPropsMixin_DbNodeProperty: function _aws_cdk_cfn_property_mixins_aws_odb_CfnCloudVmClusterPropsMixin_DbNodeProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_odb_CfnCloudVmClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_odb_CfnCloudVmClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_odb_CfnOdbNetworkMixinProps: function _aws_cdk_cfn_property_mixins_aws_odb_CfnOdbNetworkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_odb_CfnOdbPeeringConnectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_odb_CfnOdbPeeringConnectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_omics_CfnRunCacheMixinProps: function _aws_cdk_cfn_property_mixins_aws_omics_CfnRunCacheMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_opensearchserverless_CfnCollectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_opensearchserverless_CfnCollectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_opensearchserverless_CfnCollectionGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_opensearchserverless_CfnCollectionGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_opensearchservice_CfnDomainMixinProps: function _aws_cdk_cfn_property_mixins_aws_opensearchservice_CfnDomainMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_opensearchservice_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_opensearchservice_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_opsworks_CfnLayerMixinProps: function _aws_cdk_cfn_property_mixins_aws_opsworks_CfnLayerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_opsworks_CfnStackMixinProps: function _aws_cdk_cfn_property_mixins_aws_opsworks_CfnStackMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_opsworkscm_CfnServerMixinProps: function _aws_cdk_cfn_property_mixins_aws_opsworkscm_CfnServerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_organizations_CfnAccountMixinProps: function _aws_cdk_cfn_property_mixins_aws_organizations_CfnAccountMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_organizations_CfnOrganizationalUnitMixinProps: function _aws_cdk_cfn_property_mixins_aws_organizations_CfnOrganizationalUnitMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_organizations_CfnPolicyMixinProps: function _aws_cdk_cfn_property_mixins_aws_organizations_CfnPolicyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_organizations_CfnResourcePolicyMixinProps: function _aws_cdk_cfn_property_mixins_aws_organizations_CfnResourcePolicyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_osis_CfnPipelineMixinProps: function _aws_cdk_cfn_property_mixins_aws_osis_CfnPipelineMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_outposts_CfnSiteMixinProps: function _aws_cdk_cfn_property_mixins_aws_outposts_CfnSiteMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_panorama_CfnApplicationInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_panorama_CfnApplicationInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_panorama_CfnPackageMixinProps: function _aws_cdk_cfn_property_mixins_aws_panorama_CfnPackageMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_paymentcryptography_CfnKeyMixinProps: function _aws_cdk_cfn_property_mixins_aws_paymentcryptography_CfnKeyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_personalize_CfnDatasetMixinProps: function _aws_cdk_cfn_property_mixins_aws_personalize_CfnDatasetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_personalize_CfnDatasetGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_personalize_CfnDatasetGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_personalize_CfnSchemaMixinProps: function _aws_cdk_cfn_property_mixins_aws_personalize_CfnSchemaMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_personalize_CfnSolutionMixinProps: function _aws_cdk_cfn_property_mixins_aws_personalize_CfnSolutionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_personalize_CfnEventTrackerMixinProps: function _aws_cdk_cfn_property_mixins_aws_personalize_CfnEventTrackerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_pinpointemail_CfnConfigurationSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_pinpointemail_CfnConfigurationSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_pinpointemail_CfnDedicatedIpPoolMixinProps: function _aws_cdk_cfn_property_mixins_aws_pinpointemail_CfnDedicatedIpPoolMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_pinpointemail_CfnIdentityMixinProps: function _aws_cdk_cfn_property_mixins_aws_pinpointemail_CfnIdentityMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_pipes_CfnPipePropsMixin_PipeTargetEcsTaskParametersProperty: function _aws_cdk_cfn_property_mixins_aws_pipes_CfnPipePropsMixin_PipeTargetEcsTaskParametersProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_proton_CfnEnvironmentAccountConnectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_proton_CfnEnvironmentAccountConnectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_proton_CfnEnvironmentTemplateMixinProps: function _aws_cdk_cfn_property_mixins_aws_proton_CfnEnvironmentTemplateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_proton_CfnServiceTemplateMixinProps: function _aws_cdk_cfn_property_mixins_aws_proton_CfnServiceTemplateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnDataAccessorMixinProps: function _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnDataAccessorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnDataSourceMixinProps: function _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnDataSourceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnIndexMixinProps: function _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnIndexMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnPluginMixinProps: function _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnPluginMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnRetrieverMixinProps: function _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnRetrieverMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnWebExperienceMixinProps: function _aws_cdk_cfn_property_mixins_aws_qbusiness_CfnWebExperienceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_qldb_CfnLedgerMixinProps: function _aws_cdk_cfn_property_mixins_aws_qldb_CfnLedgerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_qldb_CfnStreamMixinProps: function _aws_cdk_cfn_property_mixins_aws_qldb_CfnStreamMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnAnalysisMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnAnalysisMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnDashboardMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnDashboardMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnDataSetPropsMixin_TagColumnOperationProperty: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnDataSetPropsMixin_TagColumnOperationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_quicksight_CfnDataSetPropsMixin_ColumnTagProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnDataSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnDataSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("logicalTableMap" in p)
                print("@aws-cdk/cfn-property-mixins.aws_quicksight.CfnDataSetMixinProps#logicalTableMap", "this property has been deprecated");
            if ("rowLevelPermissionDataSet" in p)
                print("@aws-cdk/cfn-property-mixins.aws_quicksight.CfnDataSetMixinProps#rowLevelPermissionDataSet", "this property has been deprecated");
            if ("rowLevelPermissionTagConfiguration" in p)
                print("@aws-cdk/cfn-property-mixins.aws_quicksight.CfnDataSetMixinProps#rowLevelPermissionTagConfiguration", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnDataSourceMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnDataSourceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnTemplateMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnTemplateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnThemeMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnThemeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnTopicMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnTopicMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnVPCConnectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnVPCConnectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnActionConnectorMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnActionConnectorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnAgentMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnAgentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_quicksight_CfnAgentPropsMixin_AgentTagProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnCustomPermissionsMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnCustomPermissionsMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnDLPSettingMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnDLPSettingMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnFolderMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnFolderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnKnowledgeBaseMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnKnowledgeBaseMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnOAuthClientApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnOAuthClientApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnSpaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnSpaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_quicksight_CfnTopicV2MixinProps: function _aws_cdk_cfn_property_mixins_aws_quicksight_CfnTopicV2MixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ram_CfnPermissionMixinProps: function _aws_cdk_cfn_property_mixins_aws_ram_CfnPermissionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ram_CfnResourceShareMixinProps: function _aws_cdk_cfn_property_mixins_aws_ram_CfnResourceShareMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rbin_CfnRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_rbin_CfnRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnCustomDBEngineVersionMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnCustomDBEngineVersionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnDBClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnDBClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnDBClusterParameterGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnDBClusterParameterGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnDBInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnDBInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
            if ("tdeCredentialArn" in p)
                print("@aws-cdk/cfn-property-mixins.aws_rds.CfnDBInstanceMixinProps#tdeCredentialArn", "this property has been deprecated");
            if ("tdeCredentialPassword" in p)
                print("@aws-cdk/cfn-property-mixins.aws_rds.CfnDBInstanceMixinProps#tdeCredentialPassword", "this property has been deprecated");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnDBParameterGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnDBParameterGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnDBProxyMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnDBProxyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_rds_CfnDBProxyPropsMixin_TagFormatProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnDBSecurityGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnDBSecurityGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnDBSubnetGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnDBSubnetGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnEventSubscriptionMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnEventSubscriptionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnGlobalClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnGlobalClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnOptionGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnOptionGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnClusterSnapshotMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnClusterSnapshotMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnDBShardGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnDBShardGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnDBSnapshotMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnDBSnapshotMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rds_CfnIntegrationMixinProps: function _aws_cdk_cfn_property_mixins_aws_rds_CfnIntegrationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_redshift_CfnClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_redshift_CfnClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_redshift_CfnClusterParameterGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_redshift_CfnClusterParameterGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_redshift_CfnClusterSecurityGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_redshift_CfnClusterSecurityGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_redshift_CfnClusterSubnetGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_redshift_CfnClusterSubnetGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_redshift_CfnEventSubscriptionMixinProps: function _aws_cdk_cfn_property_mixins_aws_redshift_CfnEventSubscriptionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_redshift_CfnIntegrationMixinProps: function _aws_cdk_cfn_property_mixins_aws_redshift_CfnIntegrationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_redshift_CfnSnapshotScheduleMixinProps: function _aws_cdk_cfn_property_mixins_aws_redshift_CfnSnapshotScheduleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_redshiftserverless_CfnNamespaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_redshiftserverless_CfnNamespaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_redshiftserverless_CfnWorkgroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_redshiftserverless_CfnWorkgroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_redshiftserverless_CfnSnapshotMixinProps: function _aws_cdk_cfn_property_mixins_aws_redshiftserverless_CfnSnapshotMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_refactorspaces_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_refactorspaces_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_refactorspaces_CfnEnvironmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_refactorspaces_CfnEnvironmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_refactorspaces_CfnRouteMixinProps: function _aws_cdk_cfn_property_mixins_aws_refactorspaces_CfnRouteMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_refactorspaces_CfnServiceMixinProps: function _aws_cdk_cfn_property_mixins_aws_refactorspaces_CfnServiceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rekognition_CfnCollectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_rekognition_CfnCollectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rekognition_CfnProjectMixinProps: function _aws_cdk_cfn_property_mixins_aws_rekognition_CfnProjectMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rekognition_CfnStreamProcessorMixinProps: function _aws_cdk_cfn_property_mixins_aws_rekognition_CfnStreamProcessorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rekognition_CfnDatasetMixinProps: function _aws_cdk_cfn_property_mixins_aws_rekognition_CfnDatasetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_resiliencehubv2_CfnPolicyMixinProps: function _aws_cdk_cfn_property_mixins_aws_resiliencehubv2_CfnPolicyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_resiliencehubv2_CfnServiceMixinProps: function _aws_cdk_cfn_property_mixins_aws_resiliencehubv2_CfnServiceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_resiliencehubv2_CfnSystemMixinProps: function _aws_cdk_cfn_property_mixins_aws_resiliencehubv2_CfnSystemMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_resourcegroups_CfnGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_resourcegroups_CfnGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rolesanywhere_CfnCRLMixinProps: function _aws_cdk_cfn_property_mixins_aws_rolesanywhere_CfnCRLMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rolesanywhere_CfnProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_rolesanywhere_CfnProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rolesanywhere_CfnTrustAnchorMixinProps: function _aws_cdk_cfn_property_mixins_aws_rolesanywhere_CfnTrustAnchorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53_CfnHealthCheckMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53_CfnHealthCheckMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.healthCheckTags != null)
                for (const o of p.healthCheckTags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_route53_CfnHealthCheckPropsMixin_HealthCheckTagProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53_CfnHostedZoneMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53_CfnHostedZoneMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.hostedZoneTags != null)
                for (const o of p.hostedZoneTags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_route53_CfnHostedZonePropsMixin_HostedZoneTagProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53globalresolver_CfnAccessSourceMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53globalresolver_CfnAccessSourceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53globalresolver_CfnAccessTokenMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53globalresolver_CfnAccessTokenMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53globalresolver_CfnDnsViewMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53globalresolver_CfnDnsViewMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53globalresolver_CfnFirewallDomainListMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53globalresolver_CfnFirewallDomainListMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53globalresolver_CfnGlobalResolverMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53globalresolver_CfnGlobalResolverMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53profiles_CfnProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53profiles_CfnProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53profiles_CfnProfileAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53profiles_CfnProfileAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53recoverycontrol_CfnClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53recoverycontrol_CfnClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53recoverycontrol_CfnControlPanelMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53recoverycontrol_CfnControlPanelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53recoverycontrol_CfnSafetyRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53recoverycontrol_CfnSafetyRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53recoveryreadiness_CfnCellMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53recoveryreadiness_CfnCellMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53recoveryreadiness_CfnReadinessCheckMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53recoveryreadiness_CfnReadinessCheckMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53recoveryreadiness_CfnRecoveryGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53recoveryreadiness_CfnRecoveryGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53recoveryreadiness_CfnResourceSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53recoveryreadiness_CfnResourceSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnFirewallDomainListMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnFirewallDomainListMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnFirewallRuleGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnFirewallRuleGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnFirewallRuleGroupAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnFirewallRuleGroupAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnOutpostResolverMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnOutpostResolverMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnResolverEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnResolverEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnResolverQueryLoggingConfigMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnResolverQueryLoggingConfigMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnResolverRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_route53resolver_CfnResolverRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rtbfabric_CfnInboundExternalLinkMixinProps: function _aws_cdk_cfn_property_mixins_aws_rtbfabric_CfnInboundExternalLinkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rtbfabric_CfnLinkMixinProps: function _aws_cdk_cfn_property_mixins_aws_rtbfabric_CfnLinkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rtbfabric_CfnLinkRoutingRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_rtbfabric_CfnLinkRoutingRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rtbfabric_CfnOutboundExternalLinkMixinProps: function _aws_cdk_cfn_property_mixins_aws_rtbfabric_CfnOutboundExternalLinkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rtbfabric_CfnRequesterGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_rtbfabric_CfnRequesterGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rtbfabric_CfnResponderGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_rtbfabric_CfnResponderGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_rum_CfnAppMonitorMixinProps: function _aws_cdk_cfn_property_mixins_aws_rum_CfnAppMonitorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3_CfnAccessPointMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3_CfnAccessPointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3_CfnBucketMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3_CfnBucketMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3_CfnStorageLensMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3_CfnStorageLensMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3_CfnAccessGrantMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3_CfnAccessGrantMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3_CfnAccessGrantsInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3_CfnAccessGrantsInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3_CfnAccessGrantsLocationMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3_CfnAccessGrantsLocationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3_CfnStorageLensGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3_CfnStorageLensGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3express_CfnAccessPointMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3express_CfnAccessPointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3express_CfnDirectoryBucketMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3express_CfnDirectoryBucketMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3files_CfnAccessPointMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3files_CfnAccessPointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_s3files_CfnAccessPointPropsMixin_AccessPointTagProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3files_CfnFileSystemMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3files_CfnFileSystemMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3outposts_CfnBucketMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3outposts_CfnBucketMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3tables_CfnTableMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3tables_CfnTableMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3tables_CfnTableBucketMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3tables_CfnTableBucketMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3vectors_CfnIndexMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3vectors_CfnIndexMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_s3vectors_CfnVectorBucketMixinProps: function _aws_cdk_cfn_property_mixins_aws_s3vectors_CfnVectorBucketMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnAppMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnAppMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnAppImageConfigMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnAppImageConfigMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnCodeRepositoryMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnCodeRepositoryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnDataQualityJobDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnDataQualityJobDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnDeviceMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnDeviceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnDeviceFleetMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnDeviceFleetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnDomainMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnDomainMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnEndpointConfigMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnEndpointConfigMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnFeatureGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnFeatureGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnImageMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnImageMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnInferenceExperimentMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnInferenceExperimentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelBiasJobDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelBiasJobDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelCardMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelCardMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelExplainabilityJobDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelExplainabilityJobDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelPackageMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelPackageMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelPackageGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelPackageGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelQualityJobDefinitionMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnModelQualityJobDefinitionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnMonitoringScheduleMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnMonitoringScheduleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnNotebookInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnNotebookInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnPipelineMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnPipelineMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnProjectMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnProjectMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnSpaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnSpaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnUserProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnUserProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnWorkteamMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnWorkteamMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnActionMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnActionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnAlgorithmMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnAlgorithmMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnArtifactMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnArtifactMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnContextMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnContextMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_sagemaker_CfnContextPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnExperimentTrialComponentMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnExperimentTrialComponentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_sagemaker_CfnExperimentTrialComponentPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnHubMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnHubMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnHumanTaskUiMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnHumanTaskUiMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnInferenceComponentMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnInferenceComponentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnMlflowAppMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnMlflowAppMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnMlflowTrackingServerMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnMlflowTrackingServerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnPartnerAppMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnPartnerAppMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("clientToken" in p)
                print("@aws-cdk/cfn-property-mixins.aws_sagemaker.CfnPartnerAppMixinProps#clientToken", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnProcessingJobMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnProcessingJobMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnStudioLifecycleConfigMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnStudioLifecycleConfigMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnTrialComponentMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnTrialComponentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_sagemaker_CfnTrialComponentPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnWorkforceMixinProps: function _aws_cdk_cfn_property_mixins_aws_sagemaker_CfnWorkforceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_scheduler_CfnScheduleGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_scheduler_CfnScheduleGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_scn_CfnDatasetMixinProps: function _aws_cdk_cfn_property_mixins_aws_scn_CfnDatasetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_scn_CfnNamespaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_scn_CfnNamespaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_secretsmanager_CfnSecretMixinProps: function _aws_cdk_cfn_property_mixins_aws_secretsmanager_CfnSecretMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_securityagent_CfnAgentSpaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_securityagent_CfnAgentSpaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_securityagent_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_securityagent_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_securityagent_CfnSecurityRequirementPackMixinProps: function _aws_cdk_cfn_property_mixins_aws_securityagent_CfnSecurityRequirementPackMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_securityagent_CfnTargetDomainMixinProps: function _aws_cdk_cfn_property_mixins_aws_securityagent_CfnTargetDomainMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_securitylake_CfnDataLakeMixinProps: function _aws_cdk_cfn_property_mixins_aws_securitylake_CfnDataLakeMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_securitylake_CfnSubscriberMixinProps: function _aws_cdk_cfn_property_mixins_aws_securitylake_CfnSubscriberMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_servicecatalog_CfnCloudFormationProductMixinProps: function _aws_cdk_cfn_property_mixins_aws_servicecatalog_CfnCloudFormationProductMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_servicecatalog_CfnCloudFormationProvisionedProductMixinProps: function _aws_cdk_cfn_property_mixins_aws_servicecatalog_CfnCloudFormationProvisionedProductMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_servicecatalog_CfnPortfolioMixinProps: function _aws_cdk_cfn_property_mixins_aws_servicecatalog_CfnPortfolioMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_servicediscovery_CfnHttpNamespaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_servicediscovery_CfnHttpNamespaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_servicediscovery_CfnPrivateDnsNamespaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_servicediscovery_CfnPrivateDnsNamespaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_servicediscovery_CfnPublicDnsNamespaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_servicediscovery_CfnPublicDnsNamespaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_servicediscovery_CfnServiceMixinProps: function _aws_cdk_cfn_property_mixins_aws_servicediscovery_CfnServiceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnConfigurationSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnConfigurationSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnContactListMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnContactListMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnDedicatedIpPoolMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnDedicatedIpPoolMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnEmailIdentityMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnEmailIdentityMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnTemplateMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnTemplateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnCustomVerificationEmailTemplateMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnCustomVerificationEmailTemplateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerAddonInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerAddonInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerAddonSubscriptionMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerAddonSubscriptionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerAddressListMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerAddressListMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerArchiveMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerArchiveMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerIngressPointMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerIngressPointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerRelayMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerRelayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerRuleSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerRuleSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerTrafficPolicyMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnMailManagerTrafficPolicyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnMultiRegionEndpointMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnMultiRegionEndpointMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ses_CfnTenantMixinProps: function _aws_cdk_cfn_property_mixins_aws_ses_CfnTenantMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_shield_CfnProtectionMixinProps: function _aws_cdk_cfn_property_mixins_aws_shield_CfnProtectionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_shield_CfnProtectionGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_shield_CfnProtectionGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_signer_CfnSigningProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_signer_CfnSigningProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnConfigurationSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnConfigurationSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnOptOutListMixinProps: function _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnOptOutListMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnPhoneNumberMixinProps: function _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnPhoneNumberMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnPoolMixinProps: function _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnPoolMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnProtectConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnProtectConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnRegistrationMixinProps: function _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnRegistrationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnSenderIdMixinProps: function _aws_cdk_cfn_property_mixins_aws_smsvoice_CfnSenderIdMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sns_CfnTopicMixinProps: function _aws_cdk_cfn_property_mixins_aws_sns_CfnTopicMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sqs_CfnQueueMixinProps: function _aws_cdk_cfn_property_mixins_aws_sqs_CfnQueueMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ssm_CfnAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_ssm_CfnAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ssm_CfnDocumentMixinProps: function _aws_cdk_cfn_property_mixins_aws_ssm_CfnDocumentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ssm_CfnMaintenanceWindowMixinProps: function _aws_cdk_cfn_property_mixins_aws_ssm_CfnMaintenanceWindowMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ssm_CfnPatchBaselineMixinProps: function _aws_cdk_cfn_property_mixins_aws_ssm_CfnPatchBaselineMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ssm_CfnCloudConnectorMixinProps: function _aws_cdk_cfn_property_mixins_aws_ssm_CfnCloudConnectorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ssm_CfnOpsItemMixinProps: function _aws_cdk_cfn_property_mixins_aws_ssm_CfnOpsItemMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ssmcontacts_CfnContactMixinProps: function _aws_cdk_cfn_property_mixins_aws_ssmcontacts_CfnContactMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ssmcontacts_CfnRotationMixinProps: function _aws_cdk_cfn_property_mixins_aws_ssmcontacts_CfnRotationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ssmincidents_CfnReplicationSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_ssmincidents_CfnReplicationSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_ssmincidents_CfnResponsePlanMixinProps: function _aws_cdk_cfn_property_mixins_aws_ssmincidents_CfnResponsePlanMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sso_CfnInstanceAccessControlAttributeConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_sso_CfnInstanceAccessControlAttributeConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("instanceAccessControlAttributeConfiguration" in p)
                print("@aws-cdk/cfn-property-mixins.aws_sso.CfnInstanceAccessControlAttributeConfigurationMixinProps#instanceAccessControlAttributeConfiguration", "this property has been deprecated");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sso_CfnPermissionSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_sso_CfnPermissionSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sso_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_sso_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_sso_CfnInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_sso_CfnInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_stepfunctions_CfnActivityMixinProps: function _aws_cdk_cfn_property_mixins_aws_stepfunctions_CfnActivityMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_stepfunctions_CfnActivityPropsMixin_TagsEntryProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_stepfunctions_CfnStateMachineMixinProps: function _aws_cdk_cfn_property_mixins_aws_stepfunctions_CfnStateMachineMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_stepfunctions_CfnStateMachinePropsMixin_TagsEntryProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_storagegateway_CfnTapePoolMixinProps: function _aws_cdk_cfn_property_mixins_aws_storagegateway_CfnTapePoolMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_supportauthz_CfnSupportPermitMixinProps: function _aws_cdk_cfn_property_mixins_aws_supportauthz_CfnSupportPermitMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_synthetics_CfnCanaryPropsMixin_ReplicaProperty: function _aws_cdk_cfn_property_mixins_aws_synthetics_CfnCanaryPropsMixin_ReplicaProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_synthetics_CfnCanaryMixinProps: function _aws_cdk_cfn_property_mixins_aws_synthetics_CfnCanaryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("deleteLambdaResourcesOnCanaryDeletion" in p)
                print("@aws-cdk/cfn-property-mixins.aws_synthetics.CfnCanaryMixinProps#deleteLambdaResourcesOnCanaryDeletion", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
            if ("visualReference" in p)
                print("@aws-cdk/cfn-property-mixins.aws_synthetics.CfnCanaryMixinProps#visualReference", "this property has been deprecated");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_synthetics_CfnGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_synthetics_CfnGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_systemsmanagersap_CfnApplicationMixinProps: function _aws_cdk_cfn_property_mixins_aws_systemsmanagersap_CfnApplicationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_textract_CfnAdapterMixinProps: function _aws_cdk_cfn_property_mixins_aws_textract_CfnAdapterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_timestream_CfnDatabaseMixinProps: function _aws_cdk_cfn_property_mixins_aws_timestream_CfnDatabaseMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_timestream_CfnScheduledQueryMixinProps: function _aws_cdk_cfn_property_mixins_aws_timestream_CfnScheduledQueryMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_timestream_CfnTableMixinProps: function _aws_cdk_cfn_property_mixins_aws_timestream_CfnTableMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_timestream_CfnInfluxDBClusterMixinProps: function _aws_cdk_cfn_property_mixins_aws_timestream_CfnInfluxDBClusterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_timestream_CfnInfluxDBInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_timestream_CfnInfluxDBInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_transcribe_CfnVocabularyFilterMixinProps: function _aws_cdk_cfn_property_mixins_aws_transcribe_CfnVocabularyFilterMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_transfer_CfnAgreementMixinProps: function _aws_cdk_cfn_property_mixins_aws_transfer_CfnAgreementMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_transfer_CfnCertificateMixinProps: function _aws_cdk_cfn_property_mixins_aws_transfer_CfnCertificateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_transfer_CfnConnectorMixinProps: function _aws_cdk_cfn_property_mixins_aws_transfer_CfnConnectorMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_transfer_CfnProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_transfer_CfnProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_transfer_CfnServerMixinProps: function _aws_cdk_cfn_property_mixins_aws_transfer_CfnServerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_transfer_CfnUserMixinProps: function _aws_cdk_cfn_property_mixins_aws_transfer_CfnUserMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_transfer_CfnWorkflowMixinProps: function _aws_cdk_cfn_property_mixins_aws_transfer_CfnWorkflowMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_transfer_CfnHostKeyMixinProps: function _aws_cdk_cfn_property_mixins_aws_transfer_CfnHostKeyMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_transfer_CfnWebAppMixinProps: function _aws_cdk_cfn_property_mixins_aws_transfer_CfnWebAppMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_translate_CfnParallelDataMixinProps: function _aws_cdk_cfn_property_mixins_aws_translate_CfnParallelDataMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_translate_CfnParallelDataPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_verifiedpermissions_CfnPolicyStoreMixinProps: function _aws_cdk_cfn_property_mixins_aws_verifiedpermissions_CfnPolicyStoreMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_voiceid_CfnDomainMixinProps: function _aws_cdk_cfn_property_mixins_aws_voiceid_CfnDomainMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnAccessLogSubscriptionMixinProps: function _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnAccessLogSubscriptionMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnListenerMixinProps: function _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnListenerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnServiceMixinProps: function _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnServiceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnServiceNetworkMixinProps: function _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnServiceNetworkMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnServiceNetworkServiceAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnServiceNetworkServiceAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnServiceNetworkVpcAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnServiceNetworkVpcAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnTargetGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnTargetGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnDomainVerificationMixinProps: function _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnDomainVerificationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnResourceConfigurationMixinProps: function _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnResourceConfigurationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnResourceGatewayMixinProps: function _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnResourceGatewayMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnServiceNetworkResourceAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_vpclattice_CfnServiceNetworkResourceAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_wafv2_CfnIPSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_wafv2_CfnIPSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_wafv2_CfnRegexPatternSetMixinProps: function _aws_cdk_cfn_property_mixins_aws_wafv2_CfnRegexPatternSetMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_wafv2_CfnRuleGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_wafv2_CfnRuleGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_wafv2_CfnWebACLMixinProps: function _aws_cdk_cfn_property_mixins_aws_wafv2_CfnWebACLMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_wellarchitected_CfnProfileMixinProps: function _aws_cdk_cfn_property_mixins_aws_wellarchitected_CfnProfileMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_wellarchitected_CfnWorkloadMixinProps: function _aws_cdk_cfn_property_mixins_aws_wellarchitected_CfnWorkloadMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_cfn_property_mixins_aws_wellarchitected_CfnWorkloadPropsMixin_TagsItemsProperty(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_wisdom_CfnAssistantMixinProps: function _aws_cdk_cfn_property_mixins_aws_wisdom_CfnAssistantMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_wisdom_CfnAssistantAssociationMixinProps: function _aws_cdk_cfn_property_mixins_aws_wisdom_CfnAssistantAssociationMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_wisdom_CfnKnowledgeBaseMixinProps: function _aws_cdk_cfn_property_mixins_aws_wisdom_CfnKnowledgeBaseMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_wisdom_CfnMessageTemplateMixinProps: function _aws_cdk_cfn_property_mixins_aws_wisdom_CfnMessageTemplateMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_wisdom_CfnQuickResponseMixinProps: function _aws_cdk_cfn_property_mixins_aws_wisdom_CfnQuickResponseMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspaces_CfnConnectionAliasMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspaces_CfnConnectionAliasMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspaces_CfnWorkspaceMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspaces_CfnWorkspaceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspaces_CfnWorkspaceIpGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspaces_CfnWorkspaceIpGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspaces_CfnWorkspacesPoolMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspaces_CfnWorkspacesPoolMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("tags" in p)
                print("@aws-cdk/cfn-property-mixins.aws_workspaces.CfnWorkspacesPoolMixinProps#tags", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesinstances_CfnVolumePropsMixin_TagSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_workspacesinstances_CfnVolumePropsMixin_TagSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesinstances_CfnWorkspaceInstancePropsMixin_TagSpecificationProperty: function _aws_cdk_cfn_property_mixins_aws_workspacesinstances_CfnWorkspaceInstancePropsMixin_TagSpecificationProperty(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesinstances_CfnWorkspaceInstanceMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspacesinstances_CfnWorkspaceInstanceMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesthinclient_CfnEnvironmentMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspacesthinclient_CfnEnvironmentMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnBrowserSettingsMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnBrowserSettingsMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnIdentityProviderMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnIdentityProviderMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnIpAccessSettingsMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnIpAccessSettingsMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnNetworkSettingsMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnNetworkSettingsMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnPortalMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnPortalMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnTrustStoreMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnTrustStoreMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnUserAccessLoggingSettingsMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnUserAccessLoggingSettingsMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnUserSettingsMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnUserSettingsMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnDataProtectionSettingsMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnDataProtectionSettingsMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnSessionLoggerMixinProps: function _aws_cdk_cfn_property_mixins_aws_workspacesweb_CfnSessionLoggerMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_xray_CfnGroupMixinProps: function _aws_cdk_cfn_property_mixins_aws_xray_CfnGroupMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_cfn_property_mixins_aws_xray_CfnSamplingRuleMixinProps: function _aws_cdk_cfn_property_mixins_aws_xray_CfnSamplingRuleMixinProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("ruleName" in p)
                print("@aws-cdk/cfn-property-mixins.aws_xray.CfnSamplingRuleMixinProps#ruleName", "this property has been deprecated");
            if ("samplingRuleRecord" in p)
                print("@aws-cdk/cfn-property-mixins.aws_xray.CfnSamplingRuleMixinProps#samplingRuleRecord", "this property has been deprecated");
            if ("samplingRuleUpdate" in p)
                print("@aws-cdk/cfn-property-mixins.aws_xray.CfnSamplingRuleMixinProps#samplingRuleUpdate", "this property has been deprecated");
            if (p.tags != null)
                for (const o of p.tags)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_CfnTag(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
