import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-observabilityadmin";
/**
 * Defines how telemetry data should be centralized across an AWS Organization, including source and destination configurations.
 *
 * @cloudformationResource AWS::ObservabilityAdmin::OrganizationCentralizationRule
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-organizationcentralizationrule.html
 */
export declare class CfnOrganizationCentralizationRulePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnOrganizationCentralizationRuleMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ObservabilityAdmin::OrganizationCentralizationRule`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnOrganizationCentralizationRuleMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnOrganizationCentralizationRule;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnOrganizationCentralizationRulePropsMixin {
    /**
     * Defines how telemetry data should be centralized across an AWS Organization, including source and destination configurations.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-centralizationrule.html
     */
    interface CentralizationRuleProperty {
        /**
         * Configuration determining where the telemetry data should be centralized, backed up, as well as encryption configuration for the primary and backup destinations.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-centralizationrule.html#cfn-observabilityadmin-organizationcentralizationrule-centralizationrule-destination
         */
        readonly destination?: CfnOrganizationCentralizationRulePropsMixin.CentralizationRuleDestinationProperty | cdk.IResolvable;
        /**
         * Configuration determining the source of the telemetry data to be centralized.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-centralizationrule.html#cfn-observabilityadmin-organizationcentralizationrule-centralizationrule-source
         */
        readonly source?: CfnOrganizationCentralizationRulePropsMixin.CentralizationRuleSourceProperty | cdk.IResolvable;
    }
    /**
     * Configuration specifying the source of telemetry data to be centralized.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-centralizationrulesource.html
     */
    interface CentralizationRuleSourceProperty {
        /**
         * The list of source regions from which telemetry data should be centralized.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-centralizationrulesource.html#cfn-observabilityadmin-organizationcentralizationrule-centralizationrulesource-regions
         */
        readonly regions?: Array<string>;
        /**
         * The organizational scope from which telemetry data should be centralized, specified using organization id, accounts or organizational unit ids.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-centralizationrulesource.html#cfn-observabilityadmin-organizationcentralizationrule-centralizationrulesource-scope
         */
        readonly scope?: string;
        /**
         * Log specific configuration for centralization source log groups.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-centralizationrulesource.html#cfn-observabilityadmin-organizationcentralizationrule-centralizationrulesource-sourcelogsconfiguration
         */
        readonly sourceLogsConfiguration?: cdk.IResolvable | CfnOrganizationCentralizationRulePropsMixin.SourceLogsConfigurationProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-centralizationrulesource.html#cfn-observabilityadmin-organizationcentralizationrule-centralizationrulesource-sourcemetricsconfiguration
         */
        readonly sourceMetricsConfiguration?: cdk.IResolvable | CfnOrganizationCentralizationRulePropsMixin.SourceMetricsConfigurationProperty;
    }
    /**
     * Configuration for selecting and handling source log groups for centralization.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-sourcelogsconfiguration.html
     */
    interface SourceLogsConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-sourcelogsconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-sourcelogsconfiguration-datasourceselectioncriteria
         */
        readonly dataSourceSelectionCriteria?: string;
        /**
         * A strategy determining whether to centralize source log groups that are encrypted with customer managed KMS keys (CMK).
         *
         * ALLOW will consider CMK encrypted source log groups for centralization while SKIP will skip CMK encrypted source log groups from centralization.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-sourcelogsconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-sourcelogsconfiguration-encryptedloggroupstrategy
         */
        readonly encryptedLogGroupStrategy?: string;
        /**
         * The selection criteria that specifies which source log groups to centralize.
         *
         * The selection criteria uses the same format as OAM link filters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-sourcelogsconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-sourcelogsconfiguration-loggroupselectioncriteria
         */
        readonly logGroupSelectionCriteria?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-sourcemetricsconfiguration.html
     */
    interface SourceMetricsConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-sourcemetricsconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-sourcemetricsconfiguration-metricsselectioncriteria
         */
        readonly metricsSelectionCriteria?: string;
    }
    /**
     * Configuration specifying the primary destination for centralized telemetry data.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-centralizationruledestination.html
     */
    interface CentralizationRuleDestinationProperty {
        /**
         * The destination account (within the organization) to which the telemetry data should be centralized.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-centralizationruledestination.html#cfn-observabilityadmin-organizationcentralizationrule-centralizationruledestination-account
         */
        readonly account?: string;
        /**
         * Log specific configuration for centralization destination log groups.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-centralizationruledestination.html#cfn-observabilityadmin-organizationcentralizationrule-centralizationruledestination-destinationlogsconfiguration
         */
        readonly destinationLogsConfiguration?: CfnOrganizationCentralizationRulePropsMixin.DestinationLogsConfigurationProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-centralizationruledestination.html#cfn-observabilityadmin-organizationcentralizationrule-centralizationruledestination-destinationmetricsconfiguration
         */
        readonly destinationMetricsConfiguration?: CfnOrganizationCentralizationRulePropsMixin.DestinationMetricsConfigurationProperty | cdk.IResolvable;
        /**
         * The primary destination region to which telemetry data should be centralized.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-centralizationruledestination.html#cfn-observabilityadmin-organizationcentralizationrule-centralizationruledestination-region
         */
        readonly region?: string;
    }
    /**
     * Configuration for centralization destination log groups, including encryption and backup settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-destinationlogsconfiguration.html
     */
    interface DestinationLogsConfigurationProperty {
        /**
         * Configuration defining the backup region and an optional KMS key for the backup destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-destinationlogsconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-destinationlogsconfiguration-backupconfiguration
         */
        readonly backupConfiguration?: cdk.IResolvable | CfnOrganizationCentralizationRulePropsMixin.LogsBackupConfigurationProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-destinationlogsconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-destinationlogsconfiguration-loggroupnameconfiguration
         */
        readonly logGroupNameConfiguration?: cdk.IResolvable | CfnOrganizationCentralizationRulePropsMixin.LogGroupNameConfigurationProperty;
        /**
         * The encryption configuration for centralization destination log groups.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-destinationlogsconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-destinationlogsconfiguration-logsencryptionconfiguration
         */
        readonly logsEncryptionConfiguration?: cdk.IResolvable | CfnOrganizationCentralizationRulePropsMixin.LogsEncryptionConfigurationProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-destinationlogsconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-destinationlogsconfiguration-tagpropagationconfiguration
         */
        readonly tagPropagationConfiguration?: cdk.IResolvable | CfnOrganizationCentralizationRulePropsMixin.TagPropagationConfigurationProperty;
    }
    /**
     * Configuration for encrypting centralized log groups.
     *
     * This configuration is only applied to destination log groups for which the corresponding source log groups are encrypted using Customer Managed KMS Keys.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-logsencryptionconfiguration.html
     */
    interface LogsEncryptionConfigurationProperty {
        /**
         * Conflict resolution strategy for centralization if the encryption strategy is set to CUSTOMER_MANAGED and the destination log group is encrypted with an AWS_OWNED KMS Key.
         *
         * ALLOW lets centralization go through while SKIP prevents centralization into the destination log group.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-logsencryptionconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-logsencryptionconfiguration-encryptionconflictresolutionstrategy
         */
        readonly encryptionConflictResolutionStrategy?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-logsencryptionconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-logsencryptionconfiguration-encryptionscope
         */
        readonly encryptionScope?: string;
        /**
         * Configuration that determines the encryption strategy of the destination log groups.
         *
         * CUSTOMER_MANAGED uses the configured KmsKeyArn to encrypt newly created destination log groups.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-logsencryptionconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-logsencryptionconfiguration-encryptionstrategy
         */
        readonly encryptionStrategy?: string;
        /**
         * KMS Key ARN belonging to the primary destination account and region, to encrypt newly created central log groups in the primary destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-logsencryptionconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-logsencryptionconfiguration-kmskeyarn
         */
        readonly kmsKeyArn?: string;
    }
    /**
     * Configuration for backing up centralized log data to a secondary region.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-logsbackupconfiguration.html
     */
    interface LogsBackupConfigurationProperty {
        /**
         * KMS Key ARN belonging to the primary destination account and backup region, to encrypt newly created central log groups in the backup destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-logsbackupconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-logsbackupconfiguration-kmskeyarn
         */
        readonly kmsKeyArn?: string;
        /**
         * Logs specific backup destination region within the primary destination account to which log data should be centralized.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-logsbackupconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-logsbackupconfiguration-region
         */
        readonly region?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-loggroupnameconfiguration.html
     */
    interface LogGroupNameConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-loggroupnameconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-loggroupnameconfiguration-loggroupnamepattern
         */
        readonly logGroupNamePattern?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-tagpropagationconfiguration.html
     */
    interface TagPropagationConfigurationProperty {
        /**
         * The ARN of the destination account IAM role used for tag propagation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-tagpropagationconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-tagpropagationconfiguration-destinationrolearn
         */
        readonly destinationRoleArn?: string;
        /**
         * The strategy to resolve tag conflicts during propagation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-tagpropagationconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-tagpropagationconfiguration-tagconflictresolutionstrategy
         */
        readonly tagConflictResolutionStrategy?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-destinationmetricsconfiguration.html
     */
    interface DestinationMetricsConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-destinationmetricsconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-destinationmetricsconfiguration-backupconfiguration
         */
        readonly backupConfiguration?: cdk.IResolvable | CfnOrganizationCentralizationRulePropsMixin.MetricsBackupConfigurationProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-metricsbackupconfiguration.html
     */
    interface MetricsBackupConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationcentralizationrule-metricsbackupconfiguration.html#cfn-observabilityadmin-organizationcentralizationrule-metricsbackupconfiguration-region
         */
        readonly region?: string;
    }
}
/**
 * Properties for CfnOrganizationCentralizationRulePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-organizationcentralizationrule.html
 */
export interface CfnOrganizationCentralizationRuleMixinProps {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-organizationcentralizationrule.html#cfn-observabilityadmin-organizationcentralizationrule-rule
     */
    readonly rule?: CfnOrganizationCentralizationRulePropsMixin.CentralizationRuleProperty | cdk.IResolvable;
    /**
     * The name of the organization centralization rule.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-organizationcentralizationrule.html#cfn-observabilityadmin-organizationcentralizationrule-rulename
     */
    readonly ruleName?: string;
    /**
     * A key-value pair to filter resources based on tags associated with the resource.
     *
     * For more information about tags, see [What are tags?](https://docs.aws.amazon.com/whitepapers/latest/tagging-best-practices/what-are-tags.html)
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-organizationcentralizationrule.html#cfn-observabilityadmin-organizationcentralizationrule-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Retrieves the details of a specific organization centralization rule.
 *
 * This operation can only be called by the organization's management account or a delegated administrator account.
 *
 * @cloudformationResource AWS::ObservabilityAdmin::OrganizationTelemetryRule
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-organizationtelemetryrule.html
 */
export declare class CfnOrganizationTelemetryRulePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnOrganizationTelemetryRuleMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ObservabilityAdmin::OrganizationTelemetryRule`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnOrganizationTelemetryRuleMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnOrganizationTelemetryRule;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnOrganizationTelemetryRulePropsMixin {
    /**
     * Defines how telemetry should be configured for specific AWS resources.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetryrule.html
     */
    interface TelemetryRuleProperty {
        /**
         * When true, configuration drift in managed telemetry resources will be detected and remediated for resource-level fields.
         *
         * @default - false
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetryrule.html#cfn-observabilityadmin-organizationtelemetryrule-telemetryrule-allowfieldupdates
         */
        readonly allowFieldUpdates?: boolean | cdk.IResolvable;
        /**
         * When true, the rule is replicated to all supported regions.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetryrule.html#cfn-observabilityadmin-organizationtelemetryrule-telemetryrule-allregions
         */
        readonly allRegions?: boolean | cdk.IResolvable;
        /**
         * Configuration specifying where and how the telemetry data should be delivered.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetryrule.html#cfn-observabilityadmin-organizationtelemetryrule-telemetryrule-destinationconfiguration
         */
        readonly destinationConfiguration?: cdk.IResolvable | CfnOrganizationTelemetryRulePropsMixin.TelemetryDestinationConfigurationProperty;
        /**
         * List of AWS region codes where the rule should be replicated.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetryrule.html#cfn-observabilityadmin-organizationtelemetryrule-telemetryrule-regions
         */
        readonly regions?: Array<string>;
        /**
         * The type of AWS resource to configure telemetry for (e.g., "AWS::EC2::VPC", "AWS::EKS::Cluster", "AWS::WAFv2::WebACL").
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetryrule.html#cfn-observabilityadmin-organizationtelemetryrule-telemetryrule-resourcetype
         */
        readonly resourceType?: string;
        /**
         * The organizational scope to which the rule applies, specified using accounts or organizational units.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetryrule.html#cfn-observabilityadmin-organizationtelemetryrule-telemetryrule-scope
         */
        readonly scope?: string;
        /**
         * Criteria for selecting which resources the rule applies to, such as resource tags.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetryrule.html#cfn-observabilityadmin-organizationtelemetryrule-telemetryrule-selectioncriteria
         */
        readonly selectionCriteria?: string;
        /**
         * The specific telemetry source types to configure for the resource, such as VPC_FLOW_LOGS or EKS_AUDIT_LOGS.
         *
         * TelemetrySourceTypes must be correlated with the specific resource type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetryrule.html#cfn-observabilityadmin-organizationtelemetryrule-telemetryrule-telemetrysourcetypes
         */
        readonly telemetrySourceTypes?: Array<string>;
        /**
         * The type of telemetry to collect (Logs, Metrics, or Traces).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetryrule.html#cfn-observabilityadmin-organizationtelemetryrule-telemetryrule-telemetrytype
         */
        readonly telemetryType?: string;
    }
    /**
     * Configuration specifying where and how telemetry data should be delivered for AWS resources.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration.html
     */
    interface TelemetryDestinationConfigurationProperty {
        /**
         * Configuration parameters specific to AWS CloudTrail when CloudTrail is the source type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration-cloudtrailparameters
         */
        readonly cloudtrailParameters?: CfnOrganizationTelemetryRulePropsMixin.CloudtrailParametersProperty | cdk.IResolvable;
        /**
         * The pattern used to generate the destination path or name, supporting macros like <resourceId> and <accountId>.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration-destinationpattern
         */
        readonly destinationPattern?: string;
        /**
         * The type of destination for the telemetry data (e.g., "Amazon CloudWatch Logs", "S3").
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration-destinationtype
         */
        readonly destinationType?: string;
        /**
         * Configuration parameters specific to ELB load balancer logging when ELB is the resource type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration-elbloadbalancerloggingparameters
         */
        readonly elbLoadBalancerLoggingParameters?: CfnOrganizationTelemetryRulePropsMixin.ELBLoadBalancerLoggingParametersProperty | cdk.IResolvable;
        /**
         * The Amazon Resource Name (ARN) of the customer-managed AWS KMS key used to encrypt the destination log groups specified in the Telemetry Rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration-kmskeyarn
         */
        readonly kmsKeyArn?: string;
        /**
         * Parameters for log delivery configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration-logdeliveryparameters
         */
        readonly logDeliveryParameters?: cdk.IResolvable | CfnOrganizationTelemetryRulePropsMixin.LogDeliveryParametersProperty;
        /**
         * The number of days to retain the telemetry data in the destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration-retentionindays
         */
        readonly retentionInDays?: number;
        /**
         * Configuration parameters specific to VPC Flow Logs when VPC is the resource type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration-vpcflowlogparameters
         */
        readonly vpcFlowLogParameters?: cdk.IResolvable | CfnOrganizationTelemetryRulePropsMixin.VPCFlowLogParametersProperty;
        /**
         * Configuration parameters specific to WAF logging when WAF is the resource type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-organizationtelemetryrule-telemetrydestinationconfiguration-wafloggingparameters
         */
        readonly wafLoggingParameters?: cdk.IResolvable | CfnOrganizationTelemetryRulePropsMixin.WAFLoggingParametersProperty;
    }
    /**
     * Configuration parameters specific to VPC Flow Logs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-vpcflowlogparameters.html
     */
    interface VPCFlowLogParametersProperty {
        /**
         * The format in which VPC Flow Log entries should be logged.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-vpcflowlogparameters.html#cfn-observabilityadmin-organizationtelemetryrule-vpcflowlogparameters-logformat
         */
        readonly logFormat?: string;
        /**
         * The maximum interval in seconds between the capture of flow log records.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-vpcflowlogparameters.html#cfn-observabilityadmin-organizationtelemetryrule-vpcflowlogparameters-maxaggregationinterval
         */
        readonly maxAggregationInterval?: number;
        /**
         * The type of traffic to log (ACCEPT, REJECT, or ALL).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-vpcflowlogparameters.html#cfn-observabilityadmin-organizationtelemetryrule-vpcflowlogparameters-traffictype
         */
        readonly trafficType?: string;
    }
    /**
     * Parameters specific to AWS CloudTrail telemetry configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-cloudtrailparameters.html
     */
    interface CloudtrailParametersProperty {
        /**
         * The advanced event selectors to use for filtering AWS CloudTrail events.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-cloudtrailparameters.html#cfn-observabilityadmin-organizationtelemetryrule-cloudtrailparameters-advancedeventselectors
         */
        readonly advancedEventSelectors?: Array<CfnOrganizationTelemetryRulePropsMixin.AdvancedEventSelectorProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * Advanced event selectors let you create fine-grained selectors for management, data, and network activity events.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-advancedeventselector.html
     */
    interface AdvancedEventSelectorProperty {
        /**
         * Contains all selector statements in an advanced event selector.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-advancedeventselector.html#cfn-observabilityadmin-organizationtelemetryrule-advancedeventselector-fieldselectors
         */
        readonly fieldSelectors?: Array<CfnOrganizationTelemetryRulePropsMixin.AdvancedFieldSelectorProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * An optional, descriptive name for an advanced event selector, such as "Log data events for only two S3 buckets".
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-advancedeventselector.html#cfn-observabilityadmin-organizationtelemetryrule-advancedeventselector-name
         */
        readonly name?: string;
    }
    /**
     * Defines criteria for selecting resources based on field values.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-advancedfieldselector.html
     */
    interface AdvancedFieldSelectorProperty {
        /**
         * Matches if the field value ends with the specified value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-advancedfieldselector.html#cfn-observabilityadmin-organizationtelemetryrule-advancedfieldselector-endswith
         */
        readonly endsWith?: Array<string>;
        /**
         * Matches if the field value equals the specified value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-advancedfieldselector.html#cfn-observabilityadmin-organizationtelemetryrule-advancedfieldselector-equals
         */
        readonly equalTo?: Array<string>;
        /**
         * The name of the field to use for selection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-advancedfieldselector.html#cfn-observabilityadmin-organizationtelemetryrule-advancedfieldselector-field
         */
        readonly field?: string;
        /**
         * Matches if the field value does not end with the specified value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-advancedfieldselector.html#cfn-observabilityadmin-organizationtelemetryrule-advancedfieldselector-notendswith
         */
        readonly notEndsWith?: Array<string>;
        /**
         * Matches if the field value does not equal the specified value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-advancedfieldselector.html#cfn-observabilityadmin-organizationtelemetryrule-advancedfieldselector-notequals
         */
        readonly notEquals?: Array<string>;
        /**
         * Matches if the field value does not start with the specified value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-advancedfieldselector.html#cfn-observabilityadmin-organizationtelemetryrule-advancedfieldselector-notstartswith
         */
        readonly notStartsWith?: Array<string>;
        /**
         * Matches if the field value starts with the specified value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-advancedfieldselector.html#cfn-observabilityadmin-organizationtelemetryrule-advancedfieldselector-startswith
         */
        readonly startsWith?: Array<string>;
    }
    /**
     * Configuration parameters for ELB load balancer logging, including output format and field delimiter settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-elbloadbalancerloggingparameters.html
     */
    interface ELBLoadBalancerLoggingParametersProperty {
        /**
         * The delimiter character used to separate fields in ELB access log entries when using plain text format.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-elbloadbalancerloggingparameters.html#cfn-observabilityadmin-organizationtelemetryrule-elbloadbalancerloggingparameters-fielddelimiter
         */
        readonly fieldDelimiter?: string;
        /**
         * The format for ELB access log entries (plain text or JSON format).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-elbloadbalancerloggingparameters.html#cfn-observabilityadmin-organizationtelemetryrule-elbloadbalancerloggingparameters-outputformat
         */
        readonly outputFormat?: string;
    }
    /**
     * Configuration parameters for WAF logging, including redacted fields and logging filters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-wafloggingparameters.html
     */
    interface WAFLoggingParametersProperty {
        /**
         * A filter configuration that determines which WAF log records to include or exclude.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-wafloggingparameters.html#cfn-observabilityadmin-organizationtelemetryrule-wafloggingparameters-loggingfilter
         */
        readonly loggingFilter?: cdk.IResolvable | CfnOrganizationTelemetryRulePropsMixin.LoggingFilterProperty;
        /**
         * The type of WAF logs to collect (currently supports WAF_LOGS).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-wafloggingparameters.html#cfn-observabilityadmin-organizationtelemetryrule-wafloggingparameters-logtype
         */
        readonly logType?: string;
        /**
         * The fields to redact from WAF logs to protect sensitive information.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-wafloggingparameters.html#cfn-observabilityadmin-organizationtelemetryrule-wafloggingparameters-redactedfields
         */
        readonly redactedFields?: Array<CfnOrganizationTelemetryRulePropsMixin.FieldToMatchProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * Specifies a field in the request to redact from WAF logs, such as headers, query parameters, or body content.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-fieldtomatch.html
     */
    interface FieldToMatchProperty {
        /**
         * Redacts the HTTP method from WAF logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-fieldtomatch.html#cfn-observabilityadmin-organizationtelemetryrule-fieldtomatch-method
         */
        readonly method?: string;
        /**
         * Redacts the entire query string from WAF logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-fieldtomatch.html#cfn-observabilityadmin-organizationtelemetryrule-fieldtomatch-querystring
         */
        readonly queryString?: string;
        /**
         * Redacts a specific header field by name from WAF logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-fieldtomatch.html#cfn-observabilityadmin-organizationtelemetryrule-fieldtomatch-singleheader
         */
        readonly singleHeader?: cdk.IResolvable | CfnOrganizationTelemetryRulePropsMixin.SingleHeaderProperty;
        /**
         * Redacts the URI path from WAF logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-fieldtomatch.html#cfn-observabilityadmin-organizationtelemetryrule-fieldtomatch-uripath
         */
        readonly uriPath?: string;
    }
    /**
     * Structure containing a name field limited to 64 characters for header or query parameter identification.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-singleheader.html
     */
    interface SingleHeaderProperty {
        /**
         * The name value, limited to 64 characters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-singleheader.html#cfn-observabilityadmin-organizationtelemetryrule-singleheader-name
         */
        readonly name?: string;
    }
    /**
     * Configuration that determines which WAF log records to keep or drop based on specified conditions.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-loggingfilter.html
     */
    interface LoggingFilterProperty {
        /**
         * The default action (KEEP or DROP) for log records that don't match any filter conditions.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-loggingfilter.html#cfn-observabilityadmin-organizationtelemetryrule-loggingfilter-defaultbehavior
         */
        readonly defaultBehavior?: string;
        /**
         * A list of filter conditions that determine log record handling behavior.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-loggingfilter.html#cfn-observabilityadmin-organizationtelemetryrule-loggingfilter-filters
         */
        readonly filters?: Array<CfnOrganizationTelemetryRulePropsMixin.FilterProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * A single filter condition that specifies behavior, requirement, and matching conditions for WAF log records.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-filter.html
     */
    interface FilterProperty {
        /**
         * The action to take for log records matching this filter (KEEP or DROP).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-filter.html#cfn-observabilityadmin-organizationtelemetryrule-filter-behavior
         */
        readonly behavior?: string;
        /**
         * The list of conditions that determine if a log record matches this filter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-filter.html#cfn-observabilityadmin-organizationtelemetryrule-filter-conditions
         */
        readonly conditions?: Array<CfnOrganizationTelemetryRulePropsMixin.ConditionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Whether the log record must meet all conditions (MEETS_ALL) or any condition (MEETS_ANY) to match this filter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-filter.html#cfn-observabilityadmin-organizationtelemetryrule-filter-requirement
         */
        readonly requirement?: string;
    }
    /**
     * A single condition that can match based on WAF rule action or label name.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-condition.html
     */
    interface ConditionProperty {
        /**
         * Matches log records based on the WAF rule action taken (ALLOW, BLOCK, COUNT, etc.).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-condition.html#cfn-observabilityadmin-organizationtelemetryrule-condition-actioncondition
         */
        readonly actionCondition?: CfnOrganizationTelemetryRulePropsMixin.ActionConditionProperty | cdk.IResolvable;
        /**
         * Matches log records based on WAF rule labels applied to the request.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-condition.html#cfn-observabilityadmin-organizationtelemetryrule-condition-labelnamecondition
         */
        readonly labelNameCondition?: cdk.IResolvable | CfnOrganizationTelemetryRulePropsMixin.LabelNameConditionProperty;
    }
    /**
     * Condition that matches based on the specific WAF action taken on the request.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-actioncondition.html
     */
    interface ActionConditionProperty {
        /**
         * The WAF action to match against (ALLOW, BLOCK, COUNT, CAPTCHA, CHALLENGE, EXCLUDED_AS_COUNT).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-actioncondition.html#cfn-observabilityadmin-organizationtelemetryrule-actioncondition-action
         */
        readonly action?: string;
    }
    /**
     * Condition that matches based on WAF rule labels, with label names limited to 1024 characters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-labelnamecondition.html
     */
    interface LabelNameConditionProperty {
        /**
         * The label name to match, supporting alphanumeric characters, underscores, hyphens, and colons.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-labelnamecondition.html#cfn-observabilityadmin-organizationtelemetryrule-labelnamecondition-labelname
         */
        readonly labelName?: string;
    }
    /**
     * Parameters for log delivery configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-logdeliveryparameters.html
     */
    interface LogDeliveryParametersProperty {
        /**
         * Types of logs to deliver.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-logdeliveryparameters.html#cfn-observabilityadmin-organizationtelemetryrule-logdeliveryparameters-logtypes
         */
        readonly logTypes?: Array<string>;
    }
    /**
     * Status of a telemetry rule in a specific region.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-regionstatus.html
     */
    interface RegionStatusProperty {
        /**
         * The AWS region code.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-regionstatus.html#cfn-observabilityadmin-organizationtelemetryrule-regionstatus-region
         */
        readonly region?: string;
        /**
         * The ARN of the rule in this region.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-regionstatus.html#cfn-observabilityadmin-organizationtelemetryrule-regionstatus-rulearn
         */
        readonly ruleArn?: string;
        /**
         * The replication status of the rule in this region.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-organizationtelemetryrule-regionstatus.html#cfn-observabilityadmin-organizationtelemetryrule-regionstatus-status
         */
        readonly status?: string;
    }
}
/**
 * Properties for CfnOrganizationTelemetryRulePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-organizationtelemetryrule.html
 */
export interface CfnOrganizationTelemetryRuleMixinProps {
    /**
     * The name of the organization telemetry rule.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-organizationtelemetryrule.html#cfn-observabilityadmin-organizationtelemetryrule-rule
     */
    readonly rule?: cdk.IResolvable | CfnOrganizationTelemetryRulePropsMixin.TelemetryRuleProperty;
    /**
     * The name of the organization centralization rule.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-organizationtelemetryrule.html#cfn-observabilityadmin-organizationtelemetryrule-rulename
     */
    readonly ruleName?: string;
    /**
     * Lists all tags attached to the specified resource.
     *
     * Supports telemetry rule resources and telemetry pipeline resources.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-organizationtelemetryrule.html#cfn-observabilityadmin-organizationtelemetryrule-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates an integration between CloudWatch and S3 Tables for analytics.
 *
 * This integration enables querying CloudWatch telemetry data using analytics engines like Amazon Athena, Amazon Redshift, and Apache Spark.
 *
 * @cloudformationResource AWS::ObservabilityAdmin::S3TableIntegration
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-s3tableintegration.html
 */
export declare class CfnS3TableIntegrationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnS3TableIntegrationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ObservabilityAdmin::S3TableIntegration`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnS3TableIntegrationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnS3TableIntegration;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnS3TableIntegrationPropsMixin {
    /**
     * Defines the encryption configuration for S3 Table integrations, including the encryption algorithm and KMS key settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-s3tableintegration-encryptionconfig.html
     */
    interface EncryptionConfigProperty {
        /**
         * The Amazon Resource Name (ARN) of the KMS key used for encryption when using customer-managed keys.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-s3tableintegration-encryptionconfig.html#cfn-observabilityadmin-s3tableintegration-encryptionconfig-kmskeyarn
         */
        readonly kmsKeyArn?: string;
        /**
         * The server-side encryption algorithm used for encrypting data in the S3 Table integration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-s3tableintegration-encryptionconfig.html#cfn-observabilityadmin-s3tableintegration-encryptionconfig-ssealgorithm
         */
        readonly sseAlgorithm?: string;
    }
    /**
     * A data source with an S3 Table integration for query access in the `logs` namespace.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-s3tableintegration-logsource.html
     */
    interface LogSourceProperty {
        /**
         * The unique identifier for the association between the data source and S3 Table integration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-s3tableintegration-logsource.html#cfn-observabilityadmin-s3tableintegration-logsource-identifier
         */
        readonly identifier?: string;
        /**
         * The name of the data source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-s3tableintegration-logsource.html#cfn-observabilityadmin-s3tableintegration-logsource-name
         */
        readonly name?: string;
        /**
         * The type of the data source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-s3tableintegration-logsource.html#cfn-observabilityadmin-s3tableintegration-logsource-type
         */
        readonly type?: string;
    }
}
/**
 * Properties for CfnS3TableIntegrationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-s3tableintegration.html
 */
export interface CfnS3TableIntegrationMixinProps {
    /**
     * Defines the encryption configuration for S3 Table integrations, including the encryption algorithm and KMS key settings.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-s3tableintegration.html#cfn-observabilityadmin-s3tableintegration-encryption
     */
    readonly encryption?: CfnS3TableIntegrationPropsMixin.EncryptionConfigProperty | cdk.IResolvable;
    /**
     * A data source with an S3 Table integration for query access in the `logs` namespace.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-s3tableintegration.html#cfn-observabilityadmin-s3tableintegration-logsources
     */
    readonly logSources?: Array<cdk.IResolvable | CfnS3TableIntegrationPropsMixin.LogSourceProperty> | cdk.IResolvable;
    /**
     * The Amazon Resource Name (ARN) of the IAM role that grants permissions for the S3 Table integration to access necessary resources.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-s3tableintegration.html#cfn-observabilityadmin-s3tableintegration-rolearn
     */
    readonly roleArn?: string;
    /**
     * The key-value pairs to associate with the S3 Table integration resource for categorization and management purposes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-s3tableintegration.html#cfn-observabilityadmin-s3tableintegration-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * AWS::ObservabilityAdmin::TelemetryEnrichment cloudformation resource enables the resource tags for telemetry feature in CloudWatch to enrich infrastructure metrics with AWS resource tags.
 *
 * For more details: https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/resource-tags-for-telemetry.html
 *
 * @cloudformationResource AWS::ObservabilityAdmin::TelemetryEnrichment
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-telemetryenrichment.html
 */
export declare class CfnTelemetryEnrichmentPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTelemetryEnrichmentMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ObservabilityAdmin::TelemetryEnrichment`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTelemetryEnrichmentMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTelemetryEnrichment;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnTelemetryEnrichmentPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-telemetryenrichment.html
 */
export interface CfnTelemetryEnrichmentMixinProps {
    /**
     * Scope of the Telemetry Enrichment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-telemetryenrichment.html#cfn-observabilityadmin-telemetryenrichment-scope
     */
    readonly scope?: string;
}
/**
 * Creates a telemetry pipeline for processing and transforming telemetry data.
 *
 * The pipeline defines how data flows from sources through processors to destinations, enabling data transformation and delivering capabilities.
 *
 * **Using CloudWatch as a pipeline source** The following is an example of a `Body` property value for the `Configuration` object. { "Type": "AWS::ObservabilityAdmin::TelemetryPipelines", "Properties": { "Configuration": { "Body": "pipeline:\n source:\n cloudwatch_logs:\n log_event_metadata:\n data_source_name: \"my_data_source\"\n data_source_type: \"default\"\n aws:\n sts_role_arn: \"arn:aws:iam::123456789012:role/MyPipelineAccessRole\"\n processor:\n - parse_json: {}\n sink:\n - cloudwatch_logs:\n log_group: \"@original\"" } }
 * } Type: AWS::ObservabilityAdmin::TelemetryPipelines
 * Properties: Configuration: Body: | pipeline: source: cloudwatch_logs: log_event_metadata: data_source_name: "my_data_source" data_source_type: "default" aws: sts_role_arn: "arn:aws:iam::123456789012:role/MyPipelineAccessRole" processor: - parse_json: {} sink: - cloudwatch_logs: log_group: "@original" **Using Amazon S3 as a pipeline source** The following is an example of a `Body` property value for the `Configuration` object. { "Type": "AWS::ObservabilityAdmin::TelemetryPipelines", "Properties": { "Configuration": { "Body": "pipeline:\n source:\n s3:\n sqs:\n visibility_timeout: \"PT60S\"\n visibility_duplication_protection: true\n maximum_messages: 10\n queue_url: \"https://sqs.us-east-1.amazonaws.com/123456789012/my-sqs-queue\"\n notification_type: \"sqs\"\n codec:\n ndjson: {}\n aws:\n region: \"us-east-1\"\n sts_role_arn: \"arn:aws:iam::123456789012:role/MyAccessRole\"\n data_source_name: \"crowdstrike_falcon\"\n processor:\n - ocsf:\n version: \"1.5\"\n mapping_version: \"1.5.0\"\n schema:\n crowdstrike_falcon:\n sink:\n - cloudwatch_logs:\n log_group: \"my-log-group\"" } }
 * } Type: AWS::ObservabilityAdmin::TelemetryPipelines
 * Properties: Configuration: Body: | pipeline: source: s3: sqs: visibility_timeout: "PT60S" visibility_duplication_protection: true maximum_messages: 10 queue_url: "https://sqs.us-east-1.amazonaws.com/123456789012/my-sqs-queue" notification_type: "sqs" codec: ndjson: {} aws: region: "us-east-1" sts_role_arn: "arn:aws:iam::123456789012:role/MyAccessRole" data_source_name: "crowdstrike_falcon" processor: - ocsf: version: "1.5" mapping_version: "1.5.0" schema: crowdstrike_falcon: sink: - cloudwatch_logs: log_group: "my-log-group"
 *
 * @cloudformationResource AWS::ObservabilityAdmin::TelemetryPipelines
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-telemetrypipelines.html
 */
export declare class CfnTelemetryPipelinesPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTelemetryPipelinesMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ObservabilityAdmin::TelemetryPipelines`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTelemetryPipelinesMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTelemetryPipelines;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnTelemetryPipelinesPropsMixin {
    /**
     * Defines the configuration for a pipeline, including how data flows from sources through processors to destinations.
     *
     * The configuration is specified in YAML format and must include a valid pipeline definition with required source and sink components. This pipeline enables end-to-end telemetry data collection, transformation, and delivery while supporting optional processing steps and extensions for enhanced functionality.
     *
     * The primary pipeline configuration section are:
     *
     * - *Source:* Defines where log data originates from (S3 buckets, CloudWatch Logs, third-party APIs). Each pipeline must have exactly one source.
     * - *Processors (optional):* Transform, parse, and enrich log data as it flows through the pipeline. Processors are applied sequentially in the order they are defined.
     * - *Sink:* Defines the destination where processed log data is sent. Each pipeline must have exactly one sink.
     * - *Extensions (optional):* Provide additional functionality such as AWS Secrets Manager integration for credential management.
     *
     * For more details on each configuration section see [CloudWatch pipelines User Guide](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/cloudwatch-pipelines.html) . Additional comprehensive configuration examples can be found in the [CreateTelemetryPipeline API docs](https://docs.aws.amazon.com/cloudwatch/latest/observabilityadmin/API_CreateTelemetryPipeline.html#API_CreateTelemetryPipeline_Examples) .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetrypipelines-telemetrypipelineconfiguration.html
     */
    interface TelemetryPipelineConfigurationProperty {
        /**
         * The pipeline configuration body that defines the data processing rules and transformations.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetrypipelines-telemetrypipelineconfiguration.html#cfn-observabilityadmin-telemetrypipelines-telemetrypipelineconfiguration-body
         */
        readonly body?: string;
    }
    /**
     * Represents a complete telemetry pipeline resource with configuration, status, and metadata for data processing and transformation.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetrypipelines-telemetrypipeline.html
     */
    interface TelemetryPipelineProperty {
        /**
         * The Amazon Resource Name (ARN) of the telemetry pipeline.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetrypipelines-telemetrypipeline.html#cfn-observabilityadmin-telemetrypipelines-telemetrypipeline-arn
         */
        readonly arn?: string;
        /**
         * The configuration that defines how the telemetry pipeline processes data.
         *
         * For more information, see the [Amazon CloudWatch User Guide](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/Creating-pipelines.html) .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetrypipelines-telemetrypipeline.html#cfn-observabilityadmin-telemetrypipelines-telemetrypipeline-configuration
         */
        readonly configuration?: cdk.IResolvable | CfnTelemetryPipelinesPropsMixin.TelemetryPipelineConfigurationProperty;
        /**
         * The timestamp when the telemetry pipeline was created.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetrypipelines-telemetrypipeline.html#cfn-observabilityadmin-telemetrypipelines-telemetrypipeline-createdtimestamp
         */
        readonly createdTimeStamp?: number;
        /**
         * The timestamp when the telemetry pipeline was last updated.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetrypipelines-telemetrypipeline.html#cfn-observabilityadmin-telemetrypipelines-telemetrypipeline-lastupdatetimestamp
         */
        readonly lastUpdateTimeStamp?: number;
        /**
         * The name of the telemetry pipeline.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetrypipelines-telemetrypipeline.html#cfn-observabilityadmin-telemetrypipelines-telemetrypipeline-name
         */
        readonly name?: string;
        /**
         * The current status of the telemetry pipeline.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetrypipelines-telemetrypipeline.html#cfn-observabilityadmin-telemetrypipelines-telemetrypipeline-status
         */
        readonly status?: string;
        /**
         * Additional information about the pipeline status, including reasons for failure states.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetrypipelines-telemetrypipeline.html#cfn-observabilityadmin-telemetrypipelines-telemetrypipeline-statusreason
         */
        readonly statusReason?: cdk.IResolvable | CfnTelemetryPipelinesPropsMixin.TelemetryPipelineStatusReasonProperty;
        /**
         * The key-value pairs associated with the telemetry pipeline resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetrypipelines-telemetrypipeline.html#cfn-observabilityadmin-telemetrypipelines-telemetrypipeline-tags
         */
        readonly tags?: Array<cdk.CfnTag>;
    }
    /**
     * Provides detailed information about the status of a telemetry pipeline, including reasons for specific states.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetrypipelines-telemetrypipelinestatusreason.html
     */
    interface TelemetryPipelineStatusReasonProperty {
        /**
         * A description of the pipeline status reason, providing additional context about the current state.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetrypipelines-telemetrypipelinestatusreason.html#cfn-observabilityadmin-telemetrypipelines-telemetrypipelinestatusreason-description
         */
        readonly description?: string;
    }
}
/**
 * Properties for CfnTelemetryPipelinesPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-telemetrypipelines.html
 */
export interface CfnTelemetryPipelinesMixinProps {
    /**
     * The configuration that defines how the telemetry pipeline processes data, including sources, processors, and destinations.
     *
     * For more information, see the [Amazon CloudWatch User Guide](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/Creating-pipelines.html) .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-telemetrypipelines.html#cfn-observabilityadmin-telemetrypipelines-configuration
     */
    readonly configuration?: cdk.IResolvable | CfnTelemetryPipelinesPropsMixin.TelemetryPipelineConfigurationProperty;
    /**
     * The name of the telemetry pipeline to create.
     *
     * The name must be unique within your account.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-telemetrypipelines.html#cfn-observabilityadmin-telemetrypipelines-name
     */
    readonly name?: string;
    /**
     * The key-value pairs to associate with the telemetry pipeline resource for categorization and management purposes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-telemetrypipelines.html#cfn-observabilityadmin-telemetrypipelines-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a telemetry rule that defines how telemetry should be configured for AWS resources in your account.
 *
 * The rule specifies which resources should have telemetry enabled and how that telemetry data should be collected based on resource type, telemetry type, and selection criteria.
 *
 * @cloudformationResource AWS::ObservabilityAdmin::TelemetryRule
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-telemetryrule.html
 */
export declare class CfnTelemetryRulePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTelemetryRuleMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ObservabilityAdmin::TelemetryRule`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTelemetryRuleMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTelemetryRule;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnTelemetryRulePropsMixin {
    /**
     * Defines how telemetry should be configured for specific AWS resources.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetryrule.html
     */
    interface TelemetryRuleProperty {
        /**
         * When true, configuration drift in managed telemetry resources will be detected and remediated for resource-level fields.
         *
         * @default - false
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetryrule.html#cfn-observabilityadmin-telemetryrule-telemetryrule-allowfieldupdates
         */
        readonly allowFieldUpdates?: boolean | cdk.IResolvable;
        /**
         * When true, the rule is replicated to all supported regions.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetryrule.html#cfn-observabilityadmin-telemetryrule-telemetryrule-allregions
         */
        readonly allRegions?: boolean | cdk.IResolvable;
        /**
         * Configuration specifying where and how the telemetry data should be delivered.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetryrule.html#cfn-observabilityadmin-telemetryrule-telemetryrule-destinationconfiguration
         */
        readonly destinationConfiguration?: cdk.IResolvable | CfnTelemetryRulePropsMixin.TelemetryDestinationConfigurationProperty;
        /**
         * List of AWS region codes where the rule should be replicated.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetryrule.html#cfn-observabilityadmin-telemetryrule-telemetryrule-regions
         */
        readonly regions?: Array<string>;
        /**
         * The type of AWS resource to configure telemetry for (e.g., "AWS::EC2::VPC", "AWS::EKS::Cluster", "AWS::WAFv2::WebACL").
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetryrule.html#cfn-observabilityadmin-telemetryrule-telemetryrule-resourcetype
         */
        readonly resourceType?: string;
        /**
         * Criteria for selecting which resources the rule applies to, such as resource tags.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetryrule.html#cfn-observabilityadmin-telemetryrule-telemetryrule-selectioncriteria
         */
        readonly selectionCriteria?: string;
        /**
         * The specific telemetry source types to configure for the resource, such as VPC_FLOW_LOGS or EKS_AUDIT_LOGS.
         *
         * TelemetrySourceTypes must be correlated with the specific resource type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetryrule.html#cfn-observabilityadmin-telemetryrule-telemetryrule-telemetrysourcetypes
         */
        readonly telemetrySourceTypes?: Array<string>;
        /**
         * The type of telemetry to collect (Logs, Metrics, or Traces).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetryrule.html#cfn-observabilityadmin-telemetryrule-telemetryrule-telemetrytype
         */
        readonly telemetryType?: string;
    }
    /**
     * Configuration specifying where and how telemetry data should be delivered for AWS resources.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetrydestinationconfiguration.html
     */
    interface TelemetryDestinationConfigurationProperty {
        /**
         * Configuration parameters specific to AWS CloudTrail when CloudTrail is the source type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-telemetryrule-telemetrydestinationconfiguration-cloudtrailparameters
         */
        readonly cloudtrailParameters?: CfnTelemetryRulePropsMixin.CloudtrailParametersProperty | cdk.IResolvable;
        /**
         * The pattern used to generate the destination path or name, supporting macros like <resourceId> and <accountId>.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-telemetryrule-telemetrydestinationconfiguration-destinationpattern
         */
        readonly destinationPattern?: string;
        /**
         * The type of destination for the telemetry data (e.g., "Amazon CloudWatch Logs", "S3").
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-telemetryrule-telemetrydestinationconfiguration-destinationtype
         */
        readonly destinationType?: string;
        /**
         * Configuration parameters specific to ELB load balancer logging when ELB is the resource type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-telemetryrule-telemetrydestinationconfiguration-elbloadbalancerloggingparameters
         */
        readonly elbLoadBalancerLoggingParameters?: CfnTelemetryRulePropsMixin.ELBLoadBalancerLoggingParametersProperty | cdk.IResolvable;
        /**
         * The Amazon Resource Name (ARN) of the customer-managed AWS KMS key used to encrypt the destination log groups specified in the Telemetry Rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-telemetryrule-telemetrydestinationconfiguration-kmskeyarn
         */
        readonly kmsKeyArn?: string;
        /**
         * Configuration parameters specific to Amazon Bedrock AgentCore logging when Amazon Bedrock AgentCore is the resource type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-telemetryrule-telemetrydestinationconfiguration-logdeliveryparameters
         */
        readonly logDeliveryParameters?: cdk.IResolvable | CfnTelemetryRulePropsMixin.LogDeliveryParametersProperty;
        /**
         * The number of days to retain the telemetry data in the destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-telemetryrule-telemetrydestinationconfiguration-retentionindays
         */
        readonly retentionInDays?: number;
        /**
         * Configuration parameters specific to VPC Flow Logs when VPC is the resource type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-telemetryrule-telemetrydestinationconfiguration-vpcflowlogparameters
         */
        readonly vpcFlowLogParameters?: cdk.IResolvable | CfnTelemetryRulePropsMixin.VPCFlowLogParametersProperty;
        /**
         * Configuration parameters specific to WAF logging when WAF is the resource type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-telemetrydestinationconfiguration.html#cfn-observabilityadmin-telemetryrule-telemetrydestinationconfiguration-wafloggingparameters
         */
        readonly wafLoggingParameters?: cdk.IResolvable | CfnTelemetryRulePropsMixin.WAFLoggingParametersProperty;
    }
    /**
     * Configuration parameters specific to VPC Flow Logs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-vpcflowlogparameters.html
     */
    interface VPCFlowLogParametersProperty {
        /**
         * The format in which VPC Flow Log entries should be logged.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-vpcflowlogparameters.html#cfn-observabilityadmin-telemetryrule-vpcflowlogparameters-logformat
         */
        readonly logFormat?: string;
        /**
         * The maximum interval in seconds between the capture of flow log records.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-vpcflowlogparameters.html#cfn-observabilityadmin-telemetryrule-vpcflowlogparameters-maxaggregationinterval
         */
        readonly maxAggregationInterval?: number;
        /**
         * The type of traffic to log (ACCEPT, REJECT, or ALL).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-vpcflowlogparameters.html#cfn-observabilityadmin-telemetryrule-vpcflowlogparameters-traffictype
         */
        readonly trafficType?: string;
    }
    /**
     * Parameters specific to AWS CloudTrail telemetry configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-cloudtrailparameters.html
     */
    interface CloudtrailParametersProperty {
        /**
         * The advanced event selectors to use for filtering AWS CloudTrail events.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-cloudtrailparameters.html#cfn-observabilityadmin-telemetryrule-cloudtrailparameters-advancedeventselectors
         */
        readonly advancedEventSelectors?: Array<CfnTelemetryRulePropsMixin.AdvancedEventSelectorProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * Advanced event selectors let you create fine-grained selectors for management, data, and network activity events.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-advancedeventselector.html
     */
    interface AdvancedEventSelectorProperty {
        /**
         * Contains all selector statements in an advanced event selector.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-advancedeventselector.html#cfn-observabilityadmin-telemetryrule-advancedeventselector-fieldselectors
         */
        readonly fieldSelectors?: Array<CfnTelemetryRulePropsMixin.AdvancedFieldSelectorProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * An optional, descriptive name for an advanced event selector, such as "Log data events for only two S3 buckets".
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-advancedeventselector.html#cfn-observabilityadmin-telemetryrule-advancedeventselector-name
         */
        readonly name?: string;
    }
    /**
     * Defines criteria for selecting resources based on field values.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-advancedfieldselector.html
     */
    interface AdvancedFieldSelectorProperty {
        /**
         * Matches if the field value ends with the specified value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-advancedfieldselector.html#cfn-observabilityadmin-telemetryrule-advancedfieldselector-endswith
         */
        readonly endsWith?: Array<string>;
        /**
         * Matches if the field value equals the specified value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-advancedfieldselector.html#cfn-observabilityadmin-telemetryrule-advancedfieldselector-equals
         */
        readonly equalTo?: Array<string>;
        /**
         * The name of the field to use for selection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-advancedfieldselector.html#cfn-observabilityadmin-telemetryrule-advancedfieldselector-field
         */
        readonly field?: string;
        /**
         * Matches if the field value does not end with the specified value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-advancedfieldselector.html#cfn-observabilityadmin-telemetryrule-advancedfieldselector-notendswith
         */
        readonly notEndsWith?: Array<string>;
        /**
         * Matches if the field value does not equal the specified value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-advancedfieldselector.html#cfn-observabilityadmin-telemetryrule-advancedfieldselector-notequals
         */
        readonly notEquals?: Array<string>;
        /**
         * Matches if the field value does not start with the specified value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-advancedfieldselector.html#cfn-observabilityadmin-telemetryrule-advancedfieldselector-notstartswith
         */
        readonly notStartsWith?: Array<string>;
        /**
         * Matches if the field value starts with the specified value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-advancedfieldselector.html#cfn-observabilityadmin-telemetryrule-advancedfieldselector-startswith
         */
        readonly startsWith?: Array<string>;
    }
    /**
     * Configuration parameters for ELB load balancer logging, including output format and field delimiter settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-elbloadbalancerloggingparameters.html
     */
    interface ELBLoadBalancerLoggingParametersProperty {
        /**
         * The delimiter character used to separate fields in ELB access log entries when using plain text format.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-elbloadbalancerloggingparameters.html#cfn-observabilityadmin-telemetryrule-elbloadbalancerloggingparameters-fielddelimiter
         */
        readonly fieldDelimiter?: string;
        /**
         * The format for ELB access log entries (plain text or JSON format).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-elbloadbalancerloggingparameters.html#cfn-observabilityadmin-telemetryrule-elbloadbalancerloggingparameters-outputformat
         */
        readonly outputFormat?: string;
    }
    /**
     * Configuration parameters for WAF logging, including redacted fields and logging filters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-wafloggingparameters.html
     */
    interface WAFLoggingParametersProperty {
        /**
         * A filter configuration that determines which WAF log records to include or exclude.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-wafloggingparameters.html#cfn-observabilityadmin-telemetryrule-wafloggingparameters-loggingfilter
         */
        readonly loggingFilter?: cdk.IResolvable | CfnTelemetryRulePropsMixin.LoggingFilterProperty;
        /**
         * The type of WAF logs to collect (currently supports WAF_LOGS).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-wafloggingparameters.html#cfn-observabilityadmin-telemetryrule-wafloggingparameters-logtype
         */
        readonly logType?: string;
        /**
         * The fields to redact from WAF logs to protect sensitive information.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-wafloggingparameters.html#cfn-observabilityadmin-telemetryrule-wafloggingparameters-redactedfields
         */
        readonly redactedFields?: Array<CfnTelemetryRulePropsMixin.FieldToMatchProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * Specifies a field in the request to redact from WAF logs, such as headers, query parameters, or body content.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-fieldtomatch.html
     */
    interface FieldToMatchProperty {
        /**
         * Redacts the HTTP method from WAF logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-fieldtomatch.html#cfn-observabilityadmin-telemetryrule-fieldtomatch-method
         */
        readonly method?: string;
        /**
         * Redacts the entire query string from WAF logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-fieldtomatch.html#cfn-observabilityadmin-telemetryrule-fieldtomatch-querystring
         */
        readonly queryString?: string;
        /**
         * Redacts a specific header field by name from WAF logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-fieldtomatch.html#cfn-observabilityadmin-telemetryrule-fieldtomatch-singleheader
         */
        readonly singleHeader?: cdk.IResolvable | CfnTelemetryRulePropsMixin.SingleHeaderProperty;
        /**
         * Redacts the URI path from WAF logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-fieldtomatch.html#cfn-observabilityadmin-telemetryrule-fieldtomatch-uripath
         */
        readonly uriPath?: string;
    }
    /**
     * Structure containing a name field limited to 64 characters for header or query parameter identification.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-singleheader.html
     */
    interface SingleHeaderProperty {
        /**
         * The name value, limited to 64 characters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-singleheader.html#cfn-observabilityadmin-telemetryrule-singleheader-name
         */
        readonly name?: string;
    }
    /**
     * Configuration that determines which WAF log records to keep or drop based on specified conditions.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-loggingfilter.html
     */
    interface LoggingFilterProperty {
        /**
         * The default action (KEEP or DROP) for log records that don't match any filter conditions.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-loggingfilter.html#cfn-observabilityadmin-telemetryrule-loggingfilter-defaultbehavior
         */
        readonly defaultBehavior?: string;
        /**
         * A list of filter conditions that determine log record handling behavior.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-loggingfilter.html#cfn-observabilityadmin-telemetryrule-loggingfilter-filters
         */
        readonly filters?: Array<CfnTelemetryRulePropsMixin.FilterProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * A single filter condition that specifies behavior, requirement, and matching conditions for WAF log records.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-filter.html
     */
    interface FilterProperty {
        /**
         * The action to take for log records matching this filter (KEEP or DROP).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-filter.html#cfn-observabilityadmin-telemetryrule-filter-behavior
         */
        readonly behavior?: string;
        /**
         * The list of conditions that determine if a log record matches this filter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-filter.html#cfn-observabilityadmin-telemetryrule-filter-conditions
         */
        readonly conditions?: Array<CfnTelemetryRulePropsMixin.ConditionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Whether the log record must meet all conditions (MEETS_ALL) or any condition (MEETS_ANY) to match this filter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-filter.html#cfn-observabilityadmin-telemetryrule-filter-requirement
         */
        readonly requirement?: string;
    }
    /**
     * A single condition that can match based on WAF rule action or label name.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-condition.html
     */
    interface ConditionProperty {
        /**
         * Matches log records based on the WAF rule action taken (ALLOW, BLOCK, COUNT, etc.).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-condition.html#cfn-observabilityadmin-telemetryrule-condition-actioncondition
         */
        readonly actionCondition?: CfnTelemetryRulePropsMixin.ActionConditionProperty | cdk.IResolvable;
        /**
         * Matches log records based on WAF rule labels applied to the request.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-condition.html#cfn-observabilityadmin-telemetryrule-condition-labelnamecondition
         */
        readonly labelNameCondition?: cdk.IResolvable | CfnTelemetryRulePropsMixin.LabelNameConditionProperty;
    }
    /**
     * Condition that matches based on the specific WAF action taken on the request.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-actioncondition.html
     */
    interface ActionConditionProperty {
        /**
         * The WAF action to match against (ALLOW, BLOCK, COUNT, CAPTCHA, CHALLENGE, EXCLUDED_AS_COUNT).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-actioncondition.html#cfn-observabilityadmin-telemetryrule-actioncondition-action
         */
        readonly action?: string;
    }
    /**
     * Condition that matches based on WAF rule labels, with label names limited to 1024 characters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-labelnamecondition.html
     */
    interface LabelNameConditionProperty {
        /**
         * The label name to match, supporting alphanumeric characters, underscores, hyphens, and colons.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-labelnamecondition.html#cfn-observabilityadmin-telemetryrule-labelnamecondition-labelname
         */
        readonly labelName?: string;
    }
    /**
     * Configuration parameters for Amazon Bedrock AgentCore logging, including `logType` settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-logdeliveryparameters.html
     */
    interface LogDeliveryParametersProperty {
        /**
         * The type of log that the source is sending.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-logdeliveryparameters.html#cfn-observabilityadmin-telemetryrule-logdeliveryparameters-logtypes
         */
        readonly logTypes?: Array<string>;
    }
    /**
     * Status of a telemetry rule in a specific region.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-regionstatus.html
     */
    interface RegionStatusProperty {
        /**
         * The AWS region code.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-regionstatus.html#cfn-observabilityadmin-telemetryrule-regionstatus-region
         */
        readonly region?: string;
        /**
         * The ARN of the rule in this region.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-regionstatus.html#cfn-observabilityadmin-telemetryrule-regionstatus-rulearn
         */
        readonly ruleArn?: string;
        /**
         * The replication status of the rule in this region.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-observabilityadmin-telemetryrule-regionstatus.html#cfn-observabilityadmin-telemetryrule-regionstatus-status
         */
        readonly status?: string;
    }
}
/**
 * Properties for CfnTelemetryRulePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-telemetryrule.html
 */
export interface CfnTelemetryRuleMixinProps {
    /**
     * Retrieves the details of a specific telemetry rule in your account.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-telemetryrule.html#cfn-observabilityadmin-telemetryrule-rule
     */
    readonly rule?: cdk.IResolvable | CfnTelemetryRulePropsMixin.TelemetryRuleProperty;
    /**
     * The name of the telemetry rule.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-telemetryrule.html#cfn-observabilityadmin-telemetryrule-rulename
     */
    readonly ruleName?: string;
    /**
     * Lists all tags attached to the specified resource.
     *
     * Supports telemetry rule resources and telemetry pipeline resources.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-observabilityadmin-telemetryrule.html#cfn-observabilityadmin-telemetryrule-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
